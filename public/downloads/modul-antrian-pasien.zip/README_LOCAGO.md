# Sistem Informasi Manajemen Rumah Sakit - Modul Antrian Pasien

```
========================================================================
📦 Sistem Informasi Manajemen Rumah Sakit - Modul Antrian Pasien
Kategori     : Kesehatan & Medis
Tech Stack   : PHP Native • PHP • MySQL
Database     : MySQL (.sql) (File: db/dbsimetris.sql)
Sumber Asli  : https://github.com/arditriheru/Modul-Antrian-Pasien (GitHub Open Source)
Stars GitHub : ⭐ 6 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/modul-antrian-pasien`
     * Untuk Laragon: `C:/laragon/www/modul-antrian-pasien`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `modul_antrian_pasien`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `db/dbsimetris.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = modul_antrian_pasien

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/modul-antrian-pasien

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
