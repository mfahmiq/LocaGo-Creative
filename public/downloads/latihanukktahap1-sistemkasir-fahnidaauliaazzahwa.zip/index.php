<?php
session_start();
include 'koneksi.php';

// Isian username dari percobaan login sebelumnya (flash)
$old_username = $_SESSION['login_old'] ?? '';
unset($_SESSION['login_old']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Daily Coffee & Toast</title>

    <link href="asset/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        :root {
            --c-primary: #1E293B;
            --c-accent: #B8860B; 
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            min-height: 100vh;
            background:
                linear-gradient(
                    135deg,
                    rgba(248, 250, 252, 0.92) 0%,
                    rgba(241, 245, 249, 0.95) 100%
                ),
                url('https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=1920&q=80')
                center/cover no-repeat;

            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem 1.5rem;
        }

        .login-wrapper {
            background: #FFFFFF;
            backdrop-filter: blur(20px);
            border: 1px solid #E2E8F0;
            border-radius: 32px;
            width: 100%;
            max-width: 950px;
            box-shadow: 0 20px 45px rgba(15, 23, 42, 0.08);
            overflow: hidden;
        }

        .login-visual-side {
            background:
                linear-gradient(
                    180deg,
                    rgba(30, 41, 59, 0.85) 0%,
                    rgba(15, 23, 42, 0.95) 100%
                ),
                url('https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=800&q=80')
                center/cover no-repeat;

            padding: 3.5rem 3rem;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            min-height: 520px;
            color: #FFFFFF;
        }

        .login-form-side {
            padding: 3.5rem 3.5rem;
            color: #1E293B;
        }

        .brand-logo-icon {
            width: 60px;
            height: 60px;
            background: #FEF3C7;
            border: 1px solid #FCD34D;
            color: #D97706;
            border-radius: 18px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
        }

        .form-control-custom {
            background: #F8FAFC;
            border: 1.5px solid #CBD5E1;
            color: #1E293B !important;
            border-radius: 14px;
            padding: 0.85rem 1.1rem;
            font-weight: 500;
        }

        .form-control-custom:focus {
            background: #FFFFFF;
            border-color: var(--c-accent);
            box-shadow: 0 0 0 4px rgba(184, 134, 11, 0.12);
        }

        .btn-login {
            background: linear-gradient(
                135deg,
                #1E293B 0%,
                #0F172A 100%
            );

            color: #FFFFFF;
            font-weight: 700;
            padding: 0.95rem;
            border-radius: 14px;
            border: none;
            box-shadow: 0 8px 20px rgba(15, 23, 42, 0.15);
            transition: all 0.2s ease;
        }

        .btn-login:hover {
            background: linear-gradient(
                135deg,
                #334155 0%,
                #1E293B 100%
            );

            transform: translateY(-1px);
        }

        .input-group-text-custom {
            background: #F1F5F9;
            border: 1.5px solid #CBD5E1;
            border-right: none;
            color: #64748B;
            border-top-left-radius: 14px;
            border-bottom-left-radius: 14px;
            padding-left: 1.2rem;
            padding-right: 1.2rem;
        }

        /* =====================================================
           POP-UP (gaya kartu modern seperti halaman kasir)
        ===================================================== */

        .swal2-container.swal2-backdrop-show {
            backdrop-filter: blur(3px);
            background: rgba(15, 23, 42, 0.55) !important;
        }

        .swal2-popup.pop-card {
            width: 31rem;
            max-width: 94vw;
            padding: 2.6rem 2rem 2rem !important;
            border: 2px solid #E5E7EB !important;
            border-radius: 28px !important;
            background: #FFFFFF !important;
            box-shadow: 0 22px 60px rgba(15, 23, 42, 0.20) !important;
            font-family: 'Plus Jakarta Sans', sans-serif !important;
        }

        .pop-card .swal2-html-container {
            margin: 0 !important;
            padding: 0 !important;
            overflow: visible !important;
        }

        .pop-icon {
            width: 76px;
            height: 76px;
            margin: 0 auto 1.3rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            font-size: 2.1rem;
            box-shadow: 0 10px 22px rgba(15, 23, 42, 0.08);
        }

        .pop-icon.warn   { color: #D97706; background: #FEF3A6; border: 3px solid #F59E0B; }
        .pop-icon.gold   { color: #C49A45; background: #FDF8ED; border: 3px solid #C49A45; }
        .pop-icon.danger { color: #DC2626; background: #FEE2E2; border: 3px solid #EF4444; }

        .pop-title {
            margin: 0 0 0.6rem;
            color: #1E293B;
            font-size: 1.35rem;
            font-weight: 800;
            letter-spacing: -0.6px;
            line-height: 1.3;
        }

        .pop-desc {
            max-width: 390px;
            margin: 0 auto;
            color: #718096;
            font-size: 0.94rem;
            line-height: 1.6;
        }

        .pop-desc strong { color: #334155; }

        /* Langkah aktivasi member */
        .pop-steps {
            margin: 1.2rem 0 0;
            padding: 0.9rem 1rem;
            list-style: none;
            text-align: left;
            background: #FDF8ED;
            border: 1px solid rgba(196, 154, 69, 0.35);
            border-radius: 18px;
        }

        .pop-steps li {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            padding: 0.4rem 0;
            color: #57534E;
            font-size: 0.85rem;
            line-height: 1.45;
        }

        .pop-steps li + li { border-top: 1px dashed rgba(196, 154, 69, 0.35); }

        .pop-steps .no {
            flex-shrink: 0;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: linear-gradient(135deg, #D4AF37, #A37B2C);
            color: #FFFFFF;
            font-size: 0.72rem;
            font-weight: 800;
        }

        /* Tombol */
        .pop-actions {
            width: 100%;
            margin: 2rem 0 0 !important;
            padding: 0 !important;
            display: flex !important;
            gap: 14px;
            flex-wrap: nowrap;
        }

        .pop-btn {
            flex: 1;
            min-height: 54px;
            padding: 0 1rem;
            border: 1px solid transparent;
            border-radius: 50rem;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-size: 0.94rem;
            font-weight: 800;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .pop-btn-confirm {
            color: #FFFFFF;
            background: #166534;
            box-shadow: 0 4px 9px rgba(22, 101, 52, 0.16);
        }

        .pop-btn-confirm:hover { background: #14532D; transform: translateY(-1px); }

        .pop-btn-confirm.navy  { background: #1E293B; box-shadow: 0 4px 9px rgba(15, 23, 42, 0.18); }
        .pop-btn-confirm.navy:hover { background: #0F172A; }

        .pop-btn-cancel {
            color: #687385;
            background: #F8FAFC;
            border-color: #DCE2E9;
        }

        .pop-btn-cancel:hover { color: #334155; background: #F1F5F9; }

        .pop-btn-cancel.gold {
            color: #8A6A22;
            background: #FDF8ED;
            border-color: rgba(196, 154, 69, 0.55);
        }

        .pop-btn-cancel.gold:hover { background: #FAF0D7; }

        .swal2-popup.pop-card .swal2-actions button:focus { box-shadow: 0 0 0 4px rgba(196, 154, 69, 0.25); }

        @media (max-width: 480px) {
            .pop-actions { flex-direction: column; }
        }
    </style>
</head>

<body>

<div class="login-wrapper">

    <div class="row g-0">

        <!-- ==================================================
             SISI KIRI
        ================================================== -->

        <div class="col-lg-5 d-none d-lg-flex login-visual-side">

            <div>

                <span
                    class="badge px-3 py-2 rounded-pill fw-semibold mb-3"
                    style="
                        background: rgba(255, 255, 255, 0.15);
                        backdrop-filter: blur(5px);
                        color: #FDE047;
                        border: 1px solid rgba(253, 224, 71, 0.3);
                        font-size: 0.78rem;
                    "
                >
                    <i class="bi bi-shop me-1"></i>
                    POS Management System
                </span>

                <h2 class="fw-extrabold text-white mb-1">
                    DAILY COFFEE
                </h2>

                <h5
                    class="fw-bold text-uppercase"
                    style="
                        color: #FACC15;
                        letter-spacing: 2px;
                        font-size: 0.85rem;
                    "
                >
                    & Daily Toast
                </h5>

            </div>

            <div>

                <div
                    class="p-3 rounded-4 mb-2"
                    style="
                        background: rgba(0, 0, 0, 0.25);
                        backdrop-filter: blur(10px);
                        border: 1px solid rgba(255, 255, 255, 0.12);
                    "
                >

                    <p class="fst-italic text-light small mb-1">
                        "Sistem terpadu untuk pencatatan penjualan dan manajemen kedai yang lebih akurat."
                    </p>

                    <small class="text-warning fw-bold">
                        — Daily Coffee & Toast
                    </small>

                </div>

            </div>

        </div>


        <!-- ==================================================
             SISI KANAN
        ================================================== -->

        <div class="col-lg-7 login-form-side">

            <div class="d-flex align-items-center gap-3 mb-4">

                <div class="brand-logo-icon">
                    <i class="bi bi-cup-hot-fill"></i>
                </div>

                <div>

                    <h4 class="fw-extrabold mb-0 text-dark">
                        Selamat Datang
                    </h4>

                    <span class="text-muted small">
                        Silakan masuk menggunakan akun Anda
                    </span>

                </div>

            </div>


            <!-- ==================================================
                 PESAN LOGIN GAGAL
            ================================================== -->

            <?php if (
                isset($_GET['pesan']) &&
                $_GET['pesan'] === 'gagal'
            ): ?>

                <div
                    class="alert alert-danger py-2 px-3 small rounded-3 mb-4 d-flex align-items-center gap-2 shadow-sm"
                    style="
                        background: #FEF2F2;
                        border: 1px solid #FECACA;
                        color: #DC2626;
                    "
                >

                    <i class="bi bi-exclamation-triangle-fill fs-5"></i>

                    <div>
                        Username / Nomor Telepon atau Password salah!
                        Periksa kembali input Anda.
                    </div>

                </div>

            <?php endif; ?>


            <!-- ==================================================
                 FORM LOGIN
            ================================================== -->

            <form
                method="POST"
                action="login-aksi.php"
            >

                <!-- USERNAME / NOMOR TELEPON -->

                <div class="mb-3">

                    <label class="form-label fw-bold small text-secondary">
                        Username / Nomor Telepon
                    </label>

                    <div class="input-group">

                        <span class="input-group-text input-group-text-custom">
                            <i class="bi bi-person-fill fs-5"></i>
                        </span>

                        <input
                            type="text"
                            name="username"
                            class="form-control form-control-custom border-start-0 ps-1"
                            placeholder="Username atau nomor telepon..."
                            value="<?= htmlspecialchars($old_username); ?>"
                            required
                            autofocus
                        >

                    </div>

                </div>


                <!-- PASSWORD -->

                <div class="mb-4">

                    <label class="form-label fw-bold small text-secondary">
                        Password
                    </label>

                    <div class="input-group">

                        <span class="input-group-text input-group-text-custom">
                            <i class="bi bi-lock-fill fs-5"></i>
                        </span>

                        <input
                            type="password"
                            name="password"
                            id="inputPassword"
                            class="form-control form-control-custom border-start-0 border-end-0 ps-1"
                            placeholder="Masukkan password..."
                            required
                        >

                        <button
                            type="button"
                            class="btn border-start-0"
                            style="
                                background: #F1F5F9;
                                border: 1.5px solid #CBD5E1;
                                border-left: none;
                                border-top-right-radius: 14px;
                                border-bottom-right-radius: 14px;
                                color: #64748B;
                            "
                            onclick="togglePassword()"
                        >
                            <i
                                class="bi bi-eye-fill"
                                id="eyeIcon"
                            ></i>
                        </button>

                    </div>

                </div>


                <!-- BUTTON LOGIN -->

                <button
                    type="submit"
                    name="masuk"
                    class="btn btn-login w-100 mb-3 py-3"
                >
                    Masuk Ke Sistem

                    <i class="bi bi-arrow-right-short ms-1 fs-5 align-middle"></i>

                </button>

            </form>

        </div>

    </div>

</div>


<script>

function togglePassword() {

    const pwd =
        document.getElementById('inputPassword');

    const icon =
        document.getElementById('eyeIcon');

    if (pwd.type === 'password') {

        pwd.type = 'text';

        icon.className =
            'bi bi-eye-slash-fill';

        icon.style.color =
            '#D97706';

    } else {

        pwd.type = 'password';

        icon.className =
            'bi bi-eye-fill';

        icon.style.color =
            '#64748B';

    }

}


/* =====================================================
   POP-UP (gaya kartu modern)
===================================================== */

function tampilPopup(o) {

    return Swal.fire({

        html: `
            <div class="pop-icon ${o.tone}"><i class="bi ${o.icon}"></i></div>
            <h2 class="pop-title">${o.title}</h2>
            <div class="pop-desc">${o.desc}</div>
        `,

        showCancelButton: !!o.cancelText,
        confirmButtonText: o.confirmText,
        cancelButtonText: o.cancelText || '',

        allowOutsideClick: false,
        buttonsStyling: false,

        customClass: {
            popup:         'pop-card',
            actions:       'pop-actions',
            confirmButton: 'pop-btn pop-btn-confirm ' + (o.confirmClass || ''),
            cancelButton:  'pop-btn pop-btn-cancel '  + (o.cancelClass  || '')
        }

    });

}


document.addEventListener("DOMContentLoaded", function () {

    const params =
        new URLSearchParams(window.location.search);

    const pesan = params.get('pesan');

    /* Hapus ?pesan= dari URL supaya pop-up tidak muncul lagi saat di-refresh */
    if (['diblokir', 'belum_member', 'belum_aktif'].includes(pesan)) {
        window.history.replaceState({}, '', 'index.php');
    }


    /* ---------- AKUN DIBLOKIR ---------- */

    if (pesan === 'diblokir') {

        tampilPopup({
            tone: 'danger',
            icon: 'bi-slash-circle-fill',
            title: 'Akun Diblokir',
            desc: `
                Akun yang kamu gunakan saat ini
                <strong>tidak dapat mengakses sistem</strong>.
                <br><br>
                Silakan hubungi administrator untuk mendapatkan akses kembali.
            `,
            confirmText: '<i class="bi bi-check-lg me-1"></i> Mengerti',
            confirmClass: 'navy'
        });

    }


    /* ---------- BELUM MEMBER: POP-UP 1 ---------- */

    if (pesan === 'belum_member') {

        tampilPopup({
            tone: 'warn',
            icon: 'bi-question-lg',
            title: 'Belum Terdaftar sebagai Member?',
            desc: `
                Akun dengan data tersebut <strong>tidak ditemukan</strong>.
                <br>
                Apakah Anda sudah memiliki akun member
                <strong>Daily Coffee &amp; Toast</strong>?
            `,
            confirmText: '<i class="bi bi-arrow-repeat me-1"></i> Sudah, Coba Lagi',
            cancelText:  '<i class="bi bi-person-plus me-1"></i> Belum Punya',
            cancelClass: 'gold'

        }).then(function (result) {

            /* SUDAH punya member -> kemungkinan salah ketik, kembali ke form */
            if (result.isConfirmed) {

                const kolom = document.querySelector('input[name="username"]');

                if (kolom) {
                    kolom.focus();
                    kolom.select();
                }

                return;
            }

            /* ---------- POP-UP 2: arahkan ke outlet ---------- */
            if (result.dismiss === Swal.DismissReason.cancel) {

                tampilPopup({
                    tone: 'gold',
                    icon: 'bi-shop',
                    title: 'Aktivasi Member di Outlet',
                    desc: `
                        Untuk memesan secara online, Anda perlu menjadi
                        <strong>Member</strong> terlebih dahulu.

                        <ul class="pop-steps">
                            <li><span class="no">1</span>
                                <span>Datang ke <strong>outlet Daily Coffee &amp; Toast</strong> terdekat</span></li>
                            <li><span class="no">2</span>
                                <span>Temui <strong>kasir</strong>, sebutkan nama &amp; nomor telepon</span></li>
                            <li><span class="no">3</span>
                                <span>Kasir mendaftarkan Anda dan membuatkan <strong>password</strong></span></li>
                            <li><span class="no">4</span>
                                <span>Login di sini dengan nomor telepon &amp; password tersebut</span></li>
                        </ul>
                    `,
                    confirmText: '<i class="bi bi-check-lg me-1"></i> Mengerti'
                });

            }

        });

    }


    /* ---------- MEMBER BELUM PUNYA PASSWORD ---------- */

    if (pesan === 'belum_aktif') {

        tampilPopup({
            tone: 'gold',
            icon: 'bi-key-fill',
            title: 'Akun Belum Aktif',
            desc: `
                Data member Anda sudah ada, tetapi
                <strong>password belum dibuat</strong>.
                <br><br>
                Silakan minta kasir di outlet untuk mengaturkan
                password / PIN akun Anda.
            `,
            confirmText: '<i class="bi bi-check-lg me-1"></i> Mengerti'
        });

    }

});

</script>

</body>
</html>