<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ==========================================================
// KONEKSI DATABASE
// ==========================================================

include 'koneksi.php';

date_default_timezone_set('Asia/Jakarta');


// ==========================================================
// CATAT LOGOUT KE AUDIT LOG
// HARUS DILAKUKAN SEBELUM SESSION DIHANCURKAN
// ==========================================================

if (isset($_SESSION['login']) && $_SESSION['login'] === true) {

    // ======================================================
    // AMBIL DATA USER DARI SESSION
    // ======================================================

    $username_logout = $_SESSION['Username'] ?? '';
    $nama_lengkap    = $_SESSION['NamaUser'] ?? '';
    $role_user       = $_SESSION['Role'] ?? 'User';


    // ======================================================
    // JIKA DATA SESSION TIDAK LENGKAP,
    // AMBIL DARI DATABASE BERDASARKAN UserID
    // ======================================================

    if (
        (empty($username_logout) || empty($nama_lengkap) || empty($role_user))
        && isset($_SESSION['IDUser'])
    ) {

        $id_user = (int) $_SESSION['IDUser'];

        $query_user = mysqli_query(
            $koneksi,
            "SELECT Username, NamaUser, Role
             FROM user
             WHERE UserID = $id_user
             LIMIT 1"
        );

        if ($query_user && mysqli_num_rows($query_user) > 0) {

            $data_user = mysqli_fetch_assoc($query_user);

            if (empty($username_logout)) {
                $username_logout = $data_user['Username'] ?? '';
            }

            if (empty($nama_lengkap)) {
                $nama_lengkap = $data_user['NamaUser'] ?? 'Administrator';
            }

            if (empty($role_user)) {
                $role_user = $data_user['Role'] ?? 'User';
            }
        }
    }


    // ======================================================
    // FORMAT ROLE
    // ======================================================

    $role_user = ucfirst(
        strtolower(
            trim($role_user)
        )
    );


    // ======================================================
    // SIMPAN AUDIT LOG
    // ======================================================

    if (!empty($username_logout)) {

        $aktivitas = 'LOGOUT';

        // Format:
        // Admin (Administrator) berhasil keluar dari sistem.
        $deskripsi =
            $role_user .
            " (" .
            $nama_lengkap .
            ") berhasil keluar dari sistem.";


        // ==================================================
        // INSERT AUDIT LOG
        // ==================================================

        $stmt = mysqli_prepare(
            $koneksi,
            "INSERT INTO audit_log
            (username, waktu, aktivitas, deskripsi)
            VALUES (?, NOW(), ?, ?)"
        );

        if ($stmt) {

            mysqli_stmt_bind_param(
                $stmt,
                "sss",
                $username_logout,
                $aktivitas,
                $deskripsi
            );

            mysqli_stmt_execute($stmt);

            mysqli_stmt_close($stmt);
        }
    }
}


// ==========================================================
// HAPUS SEMUA VARIABEL SESSION
// ==========================================================

$_SESSION = array();


// ==========================================================
// HAPUS COOKIE SESSION
// ==========================================================

if (ini_get("session.use_cookies")) {

    $params = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}


// ==========================================================
// HANCURKAN SESSION
// ==========================================================

session_destroy();


// ==========================================================
// KEMBALI KE LOGIN
// ==========================================================

header("Location: index.php?pesan=logout");
exit;

?>