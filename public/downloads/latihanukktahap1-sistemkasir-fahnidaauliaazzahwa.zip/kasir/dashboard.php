<?php 
// 1. Panggil koneksi database terlebih dahulu agar variabel $koneksi aktif
include '../koneksi.php'; 

// 2. Panggil header 
include 'header.php'; 

// Set zona waktu agar sinkron dengan waktu lokal (WIB)
date_default_timezone_set('Asia/Jakarta');

// Cek apakah yang login adalah pelanggan atau staf (admin/kasir)
$is_pelanggan = (isset($_SESSION['Role']) && $_SESSION['Role'] === 'pelanggan');
$pelanggan_id = $_SESSION['PelangganID'] ?? 0;

// 1. Query Total Transaksi Hari Ini (Hanya untuk Staf)
$total_transaksi = 0;
if (!$is_pelanggan) {
    $q_transaksi = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM penjualan WHERE DATE(TanggalPenjualan) = CURDATE()");
    $total_transaksi = mysqli_fetch_assoc($q_transaksi)['total'] ?? 0;
}

// 2a. Query Menu Makanan Terlaris Hari Ini
$q_top_makanan = mysqli_query($koneksi, "SELECT pr.NamaProduk, SUM(dp.JumlahProduk) AS total_terjual 
                                        FROM detailpenjualan dp 
                                        JOIN penjualan p ON dp.PenjualanID = p.PenjualanID 
                                        JOIN produk pr ON dp.ProdukID = pr.ProdukID 
                                        WHERE DATE(p.TanggalPenjualan) = CURDATE() AND pr.Kategori = 'Makanan' 
                                        GROUP BY dp.ProdukID 
                                        ORDER BY total_terjual DESC LIMIT 1");
$data_makanan = mysqli_fetch_assoc($q_top_makanan);
$top_makanan_nama = $data_makanan['NamaProduk'] ?? 'Belum ada';
$top_makanan_qty = $data_makanan['total_terjual'] ?? 0;

// 2b. Query Menu Minuman Terlaris Hari Ini
$q_top_minuman = mysqli_query($koneksi, "SELECT pr.NamaProduk, SUM(dp.JumlahProduk) AS total_terjual 
                                        FROM detailpenjualan dp 
                                        JOIN penjualan p ON dp.PenjualanID = p.PenjualanID 
                                        JOIN produk pr ON dp.ProdukID = pr.ProdukID 
                                        WHERE DATE(p.TanggalPenjualan) = CURDATE() AND pr.Kategori = 'Minuman' 
                                        GROUP BY dp.ProdukID 
                                        ORDER BY total_terjual DESC LIMIT 1");
$data_minuman = mysqli_fetch_assoc($q_top_minuman);
$top_minuman_nama = $data_minuman['NamaProduk'] ?? 'Belum ada';
$top_minuman_qty = $data_minuman['total_terjual'] ?? 0;

// 3. Query Total Produk Terjual Hari Ini (Hanya untuk Staf)
$total_item_terjual = 0;
if (!$is_pelanggan) {
    $q_item_terjual = mysqli_query($koneksi, "SELECT SUM(dp.JumlahProduk) AS total_qty 
                                           FROM detailpenjualan dp 
                                           JOIN penjualan p ON dp.PenjualanID = p.PenjualanID 
                                           WHERE DATE(p.TanggalPenjualan) = CURDATE()");
    $total_item_terjual = mysqli_fetch_assoc($q_item_terjual)['total_qty'] ?? 0;
}

// 4. Query 5 Transaksi Terakhir
if ($is_pelanggan) {
    // Jika pelanggan: Tampilkan hanya transaksi milik pelanggan yang sedang login
    $q_terakhir = mysqli_query($koneksi, "SELECT p.*, COALESCE(pel.NamaPelanggan, p.NamaPelanggan, 'Pelanggan Umum') AS NamaPelanggan 
                                           FROM penjualan p 
                                           LEFT JOIN pelanggan pel ON p.PelangganID = pel.PelangganID 
                                           WHERE p.PelangganID = '$pelanggan_id'
                                           ORDER BY p.PenjualanID DESC LIMIT 5");
} else {
    // Jika kasir/admin: Tampilkan 5 transaksi terakhir secara global
    $q_terakhir = mysqli_query($koneksi, "SELECT p.*, COALESCE(pel.NamaPelanggan, p.NamaPelanggan, 'Pelanggan Umum') AS NamaPelanggan 
                                           FROM penjualan p 
                                           LEFT JOIN pelanggan pel ON p.PelangganID = pel.PelangganID 
                                           ORDER BY p.PenjualanID DESC LIMIT 5");
}
?>

<style>
    /* Hero Banner Coffee Shop */
    .hero-banner-coffee {
        background: 
            linear-gradient(135deg, rgba(20, 18, 17, 0.9) 0%, rgba(45, 38, 33, 0.8) 100%), 
            url('https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1600&q=80') center/cover no-repeat;
        border-radius: 24px;
        padding: 3rem 2.5rem;
        color: #FFFFFF;
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
        border: 1px solid rgba(196, 154, 69, 0.35);
        position: relative;
        overflow: hidden;
    }

    .hero-banner-coffee::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -10%;
        width: 300px;
        height: 300px;
        background: radial-gradient(circle, rgba(196, 154, 69, 0.25) 0%, rgba(0,0,0,0) 70%);
        pointer-events: none;
    }

    /* Card Stat Premium */
    .stat-card-premium {
        background: #FFFFFF;
        border-radius: 20px;
        padding: 1.5rem;
        border: 1px solid rgba(231, 229, 228, 0.9);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.04);
        transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1);
        height: 100%;
        position: relative;
        overflow: hidden;
    }

    .stat-card-premium:hover {
        transform: translateY(-6px);
        box-shadow: 0 18px 35px rgba(196, 154, 69, 0.18);
        border-color: var(--c-accent);
    }

    .stat-icon-badge {
        width: 52px;
        height: 52px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        transition: transform 0.3s ease;
    }

    .stat-card-premium:hover .stat-icon-badge {
        transform: scale(1.1) rotate(-5deg);
    }

    /* Tabel Styling */
    .table-container-card {
        background: #FFFFFF;
        border-radius: 22px;
        border: 1px solid rgba(231, 229, 228, 0.9);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.04);
        overflow: hidden;
    }

    .custom-table thead {
        background-color: #FAF8F5;
        border-bottom: 2px solid rgba(196, 154, 69, 0.15);
    }

    .custom-table th {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 1px;
        color: #78716C;
        padding: 1.1rem 1.5rem;
        font-weight: 700;
    }

    .custom-table td {
        padding: 1.1rem 1.5rem;
        color: #292524;
        font-size: 0.9rem;
    }

    .custom-table tbody tr {
        transition: background-color 0.2s ease;
    }

    .custom-table tbody tr:hover {
        background-color: rgba(196, 154, 69, 0.04);
    }

    /* Style Tombol Detail */
    .btn-action-detail {
        border: 1px solid #0dcaf0;
        color: #0dcaf0;
        font-weight: 600;
        transition: all 0.25s ease;
        background: transparent;
    }

    .btn-action-detail:hover, 
    .btn-action-detail:focus {
        background: #0dcaf0;
        color: #FFFFFF;
        border-color: #0dcaf0;
        box-shadow: 0 4px 12px rgba(13, 202, 240, 0.3);
    }

    /* Style Tombol Cetak */
    .btn-action-print {
        border: 1px solid rgba(196, 154, 69, 0.6);
        color: #C49A45;
        font-weight: 600;
        transition: all 0.25s ease;
        background: transparent;
    }

    .btn-action-print:hover,
    .btn-action-print:focus {
        background: #C49A45;
        color: #FFFFFF;
        border-color: #C49A45;
        box-shadow: 0 4px 12px rgba(196, 154, 69, 0.3);
    }
</style>

<div class="app-container">
    <!-- Hero Operational Banner -->
    <div class="hero-banner-coffee mb-4">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <span class="badge px-3 py-2 rounded-pill mb-3 fw-bold" style="background: rgba(196, 154, 69, 0.25); color: #F59E0B; border: 1px solid rgba(196, 154, 69, 0.4); backdrop-filter: blur(5px);">
                    <i class="bi bi-person-badge me-1"></i> <?= $is_pelanggan ? 'Member Pelanggan' : 'Shift Operational'; ?> &bull; Active
                </span>
                <h1 class="fw-extrabold mb-2" style="font-size: 2.2rem; letter-spacing: -0.5px;">
                    Selamat Datang, <?= htmlspecialchars($user_nama ?? ($is_pelanggan ? 'Pelanggan' : 'Kasir')); ?>! ☕
                </h1>
                <p class="text-light opacity-75 mb-2" style="max-width: 580px; font-size: 0.95rem; line-height: 1.6;">
                    <?php if ($is_pelanggan): ?>
                        Nikmati kemudahan memesan menu favorit langsung dari akun member Anda di <strong>Daily Coffee, Daily Toast</strong>.
                    <?php else: ?>
                        Sistem Kasir &amp; Operasional Terpadu <strong>Daily Coffee, Daily Toast</strong>. Siap memberikan pelayanan terbaik untuk setiap cangkir &amp; sajian hari ini.
                    <?php endif; ?>
                </p>
                <!-- Waktu Real-Time -->
                <div class="text-warning fw-semibold" style="font-size: 0.9rem;">
                    <i class="bi bi-clock me-1"></i> <span id="realtime-clock">Memuat waktu...</span>
                </div>
            </div>
            <div class="col-lg-4 text-lg-end mt-4 mt-lg-0">
                <?php if ($is_pelanggan): ?>
                    <!-- Tombol khusus pelanggan -->
                    <a href="penjualan.php" class="btn px-4 py-3 fw-bold rounded-4 shadow-lg text-white d-inline-flex align-items-center gap-2" style="background: linear-gradient(135deg, var(--c-accent) 0%, var(--c-accent-hover) 100%); border: none;">
                        <i class="bi bi-cart-plus-fill fs-5"></i>
                        <span>Pesan Sekarang</span>
                    </a>
                <?php else: ?>
                    <!-- Tombol khusus kasir/admin -->
                    <a href="penjualan.php" class="btn px-4 py-3 fw-bold rounded-4 shadow-lg text-white d-inline-flex align-items-center gap-2" style="background: linear-gradient(135deg, var(--c-accent) 0%, var(--c-accent-hover) 100%); border: none;">
                        <i class="bi bi-plus-circle-fill fs-5"></i>
                        <span>Buka Kasir / Transaksi</span>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Ringkasan Statistik Utama -->
    <div class="row g-4 mb-4 justify-content-center">
        <?php if (!$is_pelanggan): ?>
            <!-- Card 1: Transaksi Hari Ini (Hanya Staf) -->
            <div class="col-xl-3 col-md-6">
                <div class="stat-card-premium">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <span class="text-muted fw-bold small text-uppercase" style="letter-spacing: 0.5px;">Transaksi Hari Ini</span>
                        <div class="stat-icon-badge" style="background: rgba(13, 110, 253, 0.1); color: #0D6EFD;">
                            <i class="bi bi-receipt"></i>
                        </div>
                    </div>
                    <h2 class="fw-extrabold mb-1" style="color: var(--c-primary);"><?= number_format($total_transaksi, 0, ',', '.'); ?></h2>
                    <small class="text-muted"><i class="bi bi-check-circle-fill text-success me-1"></i> Struk diterbitkan</small>
                </div>
            </div>
        <?php endif; ?>

        <!-- Card: Makanan Terlaris (Muncul untuk semua) -->
        <div class="<?= $is_pelanggan ? 'col-xl-5 col-md-6' : 'col-xl-3 col-md-6'; ?>">
            <div class="stat-card-premium">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <span class="text-muted fw-bold small text-uppercase" style="letter-spacing: 0.5px;">Makanan Terlaris</span>
                    <div class="stat-icon-badge" style="background: rgba(217, 119, 6, 0.12); color: #D97706;">
                        <i class="bi bi-egg-fried"></i>
                    </div>
                </div>
                <h2 class="fw-extrabold mb-1 text-truncate" style="color: var(--c-primary); font-size: 1.25rem;" title="<?= htmlspecialchars($top_makanan_nama); ?>">
                    <?= htmlspecialchars($top_makanan_nama); ?>
                </h2>
                <small class="text-muted">
                    <i class="bi bi-fire text-warning me-1"></i> 
                    <?= $top_makanan_qty > 0 ?$top_makanan_qty . ' porsi terjual' : 'Belum ada pesanan'; ?>
                </small>
            </div>
        </div>

        <!-- Card: Minuman Terlaris (Muncul untuk semua) -->
        <div class="<?= $is_pelanggan ? 'col-xl-5 col-md-6' : 'col-xl-3 col-md-6'; ?>">
            <div class="stat-card-premium">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <span class="text-muted fw-bold small text-uppercase" style="letter-spacing: 0.5px;">Minuman Terlaris</span>
                    <div class="stat-icon-badge" style="background: rgba(196, 154, 69, 0.12); color: var(--c-accent);">
                        <i class="bi bi-cup-hot"></i>
                    </div>
                </div>
                <h2 class="fw-extrabold mb-1 text-truncate" style="color: var(--c-primary); font-size: 1.25rem;" title="<?= htmlspecialchars($top_minuman_nama); ?>">
                    <?= htmlspecialchars($top_minuman_nama); ?>
                </h2>
                <small class="text-muted">
                    <i class="bi bi-award-fill text-warning me-1"></i> 
                    <?= $top_minuman_qty > 0 ?$top_minuman_qty . ' cangkir terjual' : 'Belum ada pesanan'; ?>
                </small>
            </div>
        </div>

        <?php if (!$is_pelanggan): ?>
            <!-- Card 4: Total Produk Terjual (Hanya Staf) -->
            <div class="col-xl-3 col-md-6">
                <div class="stat-card-premium">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <span class="text-muted fw-bold small text-uppercase" style="letter-spacing: 0.5px;">Total Item Keluar</span>
                        <div class="stat-icon-badge" style="background: rgba(25, 135, 84, 0.1); color: #198754;">
                            <i class="bi bi-box-seam"></i>
                        </div>
                    </div>
                    <h2 class="fw-extrabold mb-1" style="color: var(--c-primary);"><?= number_format($total_item_terjual, 0, ',', '.'); ?></h2>
                    <small class="text-muted"><i class="bi bi-check-circle text-success me-1"></i> Keseluruhan porsi &amp; cangkir</small>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Tabel Transaksi Terakhir -->
    <div class="table-container-card p-4">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <div>
                <h5 class="fw-bold mb-1 d-flex align-items-center gap-2">
                    <i class="bi bi-clock-history text-warning"></i>
                    <?= $is_pelanggan ? 'Riwayat Transaksi Anda' : 'Transaksi Terakhir'; ?>
                </h5>
                <small class="text-muted">
                    <?= $is_pelanggan ? 'Daftar pesanan terakhir yang Anda lakukan' : 'Aktivitas 5 transaksi paling baru yang tercatat'; ?>
                </small>
            </div>
            <a href="riwayat-penjualan.php" class="btn btn-sm btn-outline-warning rounded-3 fw-bold px-3 py-2 text-decoration-none" style="color: var(--c-accent); border-color: rgba(196, 154, 69, 0.4);">
                Lihat Semua <i class="bi bi-arrow-right ms-1"></i>
            </a>
        </div>

        <div class="table-responsive">
            <table class="table custom-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>ID Struk</th>
                        <th>Tanggal</th>
                        <?php if (!$is_pelanggan): ?>
                            <th>Pelanggan</th>
                        <?php endif; ?>
                        <th>Total Bayar</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($q_terakhir) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($q_terakhir)): ?>
                        <tr>
                            <td class="fw-bold text-uppercase" style="color: var(--c-accent);">
                                #TRX-<?= sprintf('%04d', $row['PenjualanID']); ?>
                            </td>
                            <td class="text-muted">
                                <?= date('d M Y, H:i', strtotime($row['TanggalPenjualan'])); ?>
                            </td>
                            <?php if (!$is_pelanggan): ?>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="rounded-circle bg-light d-flex align-items-center justify-content-center text-secondary fw-bold" style="width: 28px; height: 28px; font-size: 0.75rem;">
                                            <?= strtoupper(substr($row['NamaPelanggan'] ?? 'P', 0, 1)); ?>
                                        </div>
                                        <span class="fw-semibold"><?= htmlspecialchars($row['NamaPelanggan'] ?? 'Pelanggan Umum'); ?></span>
                                    </div>
                                </td>
                            <?php endif; ?>
                            <td class="fw-bold text-success" style="font-size: 0.95rem;">
                                Rp <?= number_format($row['TotalHarga'], 0, ',', '.'); ?>
                            </td>
                            <td class="text-end">
                                <div class="d-flex align-items-center justify-content-end gap-2">
                                    <!-- Tombol Detail -->
                                    <a href="detail-transaksi.php?id=<?= $row['PenjualanID']; ?>" class="btn btn-action-detail btn-sm rounded-pill px-3 py-1.5" style="font-size: 0.8rem;" title="Lihat Rincian Menu">
                                        <i class="bi bi-eye me-1"></i> Detail
                                    </a>
                                    <!-- Tombol Cetak Struk -->
                                    <a href="cetak-struk.php?id=<?= $row['PenjualanID']; ?>" target="_blank" class="btn btn-action-print btn-sm rounded-pill px-3 py-1.5" style="font-size: 0.8rem;" title="Cetak Struk">
                                        <i class="bi bi-printer me-1"></i> Cetak
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="<?= $is_pelanggan ? '4' : '5'; ?>" class="text-center py-5 text-muted">
                                <i class="bi bi-receipt-cutoff fs-1 d-block mb-2 text-warning opacity-50"></i>
                                <?= $is_pelanggan ? 'Anda belum memiliki riwayat transaksi.' : 'Belum ada transaksi yang tercatat sama sekali.'; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="../asset/js/bootstrap.bundle.min.js"></script>
<script>
    function updateClock() {
        const now = new Date();
        const optionsTime = { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false };
        const optionsDate = { timeZone: 'Asia/Jakarta', weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        
        const timeString = now.toLocaleTimeString('id-ID', optionsTime).replace(/\./g, ':');
        const dateString = now.toLocaleDateString('id-ID', optionsDate);
        
        const clockElement = document.getElementById('realtime-clock');
        if (clockElement) {
            clockElement.textContent = `${dateString} - ${timeString} WIB`;
        }
    }

    updateClock();
    setInterval(updateClock, 1000);
</script>
</body>
</html>