<?php
session_start();
include '../koneksi.php'; // Sesuaikan jika path koneksi berbeda

if (isset($_POST['edit_member'])) {
    $id_pelanggan = (int)$_POST['pelanggan_id'];
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama_pelanggan']);
    $alamat = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    $nomor_telepon = mysqli_real_escape_string($koneksi, $_POST['nomor_telepon']);

    $q_update = mysqli_query($koneksi, "UPDATE pelanggan SET NamaPelanggan = '$nama', Alamat = '$alamat', NomorTelepon = '$nomor_telepon' WHERE PelangganID = '$id_pelanggan'");

    if ($q_update) {
        // Catat ke Audit Log Aktivitas
        if (isset($_SESSION['username'])) {
            $user_log = $_SESSION['username'];
            $aktivitas_log = "Edit Member";
            $deskripsi_log = "Mengubah data member dengan ID: DAILYMBR" . $id_pelanggan . " (Nama baru: " . $nama . ")";
            mysqli_query($koneksi, "INSERT INTO log_aktivitas (username, aktivitas, deskripsi) VALUES ('$user_log', '$aktivitas_log', '$deskripsi_log')");
        }

        echo "<script>alert('Data member berhasil diperbarui!'); window.location='pelanggan.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data member!'); window.location='pelanggan.php';</script>";
    }
} else {
    header("Location: pelanggan.php");
    exit;
}
?>