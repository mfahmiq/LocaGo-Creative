<?php
session_start();
include '../koneksi.php'; // Sesuaikan jika path koneksi berbeda

if (isset($_GET['id'])) {
    $id_pelanggan = (int)$_GET['id'];

    // Ambil nama pelanggan untuk log aktivitas
    $q_cek_nama = mysqli_query($koneksi, "SELECT NamaPelanggan FROM pelanggan WHERE PelangganID = '$id_pelanggan'");
    $data_nama = mysqli_fetch_assoc($q_cek_nama);
    $nama_pelanggan = $data_nama ? $data_nama['NamaPelanggan'] : 'Unknown';

    // Cek ulang apakah ada transaksi di tabel penjualan
    $cek_transaksi = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM penjualan WHERE PelangganID = '$id_pelanggan'");
    $data_trx = mysqli_fetch_assoc($cek_transaksi);

    if ($data_trx['total'] > 0) {
        echo "<script>alert('Gagal menghapus! Member ini memiliki riwayat transaksi aktif dan dilindungi dari penghapusan.'); window.location='pelanggan.php';</script>";
    } else {
        $q_delete = mysqli_query($koneksi, "DELETE FROM pelanggan WHERE PelangganID = '$id_pelanggan'");
        
        if ($q_delete) {
            // Catat ke Audit Log Aktivitas
            if (isset($_SESSION['username'])) {
                $user_log = $_SESSION['username'];
                $aktivitas_log = "Hapus Member";
                $deskripsi_log = "Menghapus member: " . $nama_pelanggan . " (ID: DAILYMBR" . $id_pelanggan . ")";
                mysqli_query($koneksi, "INSERT INTO log_aktivitas (username, aktivitas, deskripsi) VALUES ('$user_log', '$aktivitas_log', '$deskripsi_log')");
            }

            echo "<script>alert('Data member berhasil dihapus.'); window.location='pelanggan.php';</script>";
        } else {
            echo "<script>alert('Gagal menghapus data member dari database!'); window.location='pelanggan.php';</script>";
        }
    }
} else {
    header("Location: pelanggan.php");
    exit;
}
?>