<?php
session_start();
include '../koneksi.php';

// Set zona waktu
date_default_timezone_set('Asia/Jakarta');

// ======================================================
// AMBIL PARAMETER
// ======================================================

$id  = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$aksi = isset($_GET['aksi']) ? strtolower(trim($_GET['aksi'])) : '';


// ======================================================
// VALIDASI PARAMETER
// ======================================================

if ($id <= 0 || empty($aksi)) {

    echo "<script>
        alert('Parameter transaksi tidak valid!');
        window.location.href = 'riwayat-transaksi.php';
    </script>";

    exit;
}


// ======================================================
// AMBIL USER LOGIN
// ======================================================

$username_log = isset($_SESSION['Username'])
    ? $_SESSION['Username']
    : 'admin';

$nama_user_log = isset($_SESSION['NamaUser'])
    ? $_SESSION['NamaUser']
    : 'Administrator';


// ======================================================
// AMBIL DATA TRANSAKSI
// ======================================================

$id_aman = (int)$id;

$query_cek = mysqli_query(
    $koneksi,
    "SELECT *
     FROM penjualan
     WHERE PenjualanID = '$id_aman'
     LIMIT 1"
);

if (!$query_cek || mysqli_num_rows($query_cek) == 0) {

    echo "<script>
        alert('Data transaksi tidak ditemukan di database!');
        window.location.href = 'riwayat-transaksi.php';
    </script>";

    exit;
}


$data_trx = mysqli_fetch_assoc($query_cek);


// ======================================================
// NORMALISASI STATUS SAAT INI
// ======================================================

$status_sekarang = strtolower(
    trim(
        $data_trx['status'] ?? 'proses'
    )
);

// Data lama yang mungkin menggunakan "batal"
if ($status_sekarang === 'batal') {
    $status_sekarang = 'dibatalkan';
}

// Data "berhasil" dianggap masih proses
if ($status_sekarang === 'berhasil') {
    $status_sekarang = 'proses';
}


// ======================================================
// FORMAT NOMOR TRANSAKSI
// ======================================================

$format_tgl_trx = date(
    'Ymd',
    strtotime($data_trx['TanggalPenjualan'])
);

$no_transaksi_formatted =
    'TRX-' .
    $format_tgl_trx .
    '-' .
    str_pad(
        $id,
        4,
        '0',
        STR_PAD_LEFT
    );


// ======================================================
// AKSI SELESAI
// ======================================================

if ($aksi === 'selesai') {


    // --------------------------------------------------
    // CEK STATUS
    // --------------------------------------------------

    if ($status_sekarang === 'selesai') {

        echo "<script>
            alert('Transaksi ini sudah berstatus Selesai!');
            window.location.href = 'riwayat-transaksi.php';
        </script>";

        exit;
    }


    if ($status_sekarang === 'dibatalkan') {

        echo "<script>
            alert('Transaksi yang sudah dibatalkan tidak dapat diselesaikan!');
            window.location.href = 'riwayat-transaksi.php';
        </script>";

        exit;
    }


    // --------------------------------------------------
    // UPDATE STATUS
    // --------------------------------------------------

    $update = mysqli_query(
        $koneksi,
        "UPDATE penjualan
         SET status = 'selesai'
         WHERE PenjualanID = '$id_aman'"
    );


    if (!$update) {

        echo "<script>
            alert('Gagal memperbarui status transaksi: " .
            addslashes(mysqli_error($koneksi)) .
            "');
            window.location.href = 'riwayat-transaksi.php';
        </script>";

        exit;
    }


    // --------------------------------------------------
    // CEK ULANG STATUS DARI DATABASE
    // --------------------------------------------------

    $cek_status_baru = mysqli_query(
        $koneksi,
        "SELECT status
         FROM penjualan
         WHERE PenjualanID = '$id_aman'
         LIMIT 1"
    );


    if (!$cek_status_baru) {

        echo "<script>
            alert('Status berhasil diperbarui tetapi gagal melakukan verifikasi!');
            window.location.href = 'riwayat-transaksi.php';
        </script>";

        exit;
    }


    $data_status_baru = mysqli_fetch_assoc(
        $cek_status_baru
    );


    $status_baru = strtolower(
        trim(
            $data_status_baru['status'] ?? ''
        )
    );


    // --------------------------------------------------
    // PASTIKAN BENAR-BENAR SELESAI
    // --------------------------------------------------

    if ($status_baru !== 'selesai') {

        echo "<script>
            alert('Status transaksi gagal tersimpan ke database!');
            window.location.href = 'riwayat-transaksi.php';
        </script>";

        exit;
    }


    // --------------------------------------------------
    // AUDIT LOG
    // --------------------------------------------------

    $aktivitas_log = 'SELESAI';

    $deskripsi_log =
        "User " .
        $nama_user_log .
        " menyelesaikan transaksi dengan ID " .
        $no_transaksi_formatted;


    $username_aman = mysqli_real_escape_string(
        $koneksi,
        $username_log
    );

    $aktivitas_aman = mysqli_real_escape_string(
        $koneksi,
        $aktivitas_log
    );

    $deskripsi_aman = mysqli_real_escape_string(
        $koneksi,
        $deskripsi_log
    );


    $insert_log = mysqli_query(
        $koneksi,
        "INSERT INTO audit_log
        (
            username,
            aktivitas,
            deskripsi,
            waktu
        )
        VALUES
        (
            '$username_aman',
            '$aktivitas_aman',
            '$deskripsi_aman',
            NOW()
        )"
    );


    // --------------------------------------------------
    // NOTIFIKASI
    // --------------------------------------------------

    if (!$insert_log) {

        echo "<script>
            alert('Transaksi berhasil diselesaikan, tetapi audit log gagal disimpan.');
            window.location.href = 'riwayat-transaksi.php';
        </script>";

        exit;
    }


    echo "<script>
        alert('Transaksi berhasil ditandai sebagai Selesai!');
        window.location.href = 'riwayat-transaksi.php';
    </script>";

    exit;
}


// ======================================================
// AKSI BATAL
// ======================================================

elseif ($aksi === 'batal') {


    // --------------------------------------------------
    // CEK STATUS
    // --------------------------------------------------

    if ($status_sekarang === 'selesai') {

        echo "<script>
            alert('Transaksi yang sudah selesai tidak dapat dibatalkan!');
            window.location.href = 'riwayat-transaksi.php';
        </script>";

        exit;
    }


    if ($status_sekarang === 'dibatalkan') {

        echo "<script>
            alert('Transaksi ini sudah dibatalkan sebelumnya!');
            window.location.href = 'riwayat-transaksi.php';
        </script>";

        exit;
    }


    // --------------------------------------------------
    // MULAI TRANSAKSI DATABASE
    // --------------------------------------------------

    mysqli_begin_transaction($koneksi);


    try {


        // ==============================================
        // 1. UPDATE STATUS MENJADI DIBATALKAN
        // ==============================================

        $update_status = mysqli_query(
            $koneksi,
            "UPDATE penjualan
             SET status = 'dibatalkan'
             WHERE PenjualanID = '$id_aman'
             AND status NOT IN ('selesai', 'dibatalkan', 'batal')"
        );


        if (!$update_status) {

            throw new Exception(
                "Gagal memperbarui status transaksi: " .
                mysqli_error($koneksi)
            );
        }


        // ==============================================
        // 2. CEK APAKAH STATUS BENAR-BENAR BERUBAH
        // ==============================================

        $cek_status_batal = mysqli_query(
            $koneksi,
            "SELECT status
             FROM penjualan
             WHERE PenjualanID = '$id_aman'
             LIMIT 1"
        );


        if (!$cek_status_batal) {

            throw new Exception(
                "Gagal memverifikasi status transaksi."
            );
        }


        $data_status_batal = mysqli_fetch_assoc(
            $cek_status_batal
        );


        $status_setelah_batal = strtolower(
            trim(
                $data_status_batal['status'] ?? ''
            )
        );


        if (
            $status_setelah_batal !== 'dibatalkan' &&
            $status_setelah_batal !== 'batal'
        ) {

            throw new Exception(
                "Status transaksi gagal diubah menjadi dibatalkan."
            );
        }


        // ==============================================
        // 3. AMBIL DETAIL PRODUK
        // ==============================================

        $query_detail = mysqli_query(
            $koneksi,
            "SELECT *
             FROM detailpenjualan
             WHERE PenjualanID = '$id_aman'"
        );


        if (!$query_detail) {

            throw new Exception(
                "Gagal mengambil detail transaksi: " .
                mysqli_error($koneksi)
            );
        }


        // ==============================================
        // 4. KEMBALIKAN STOK
        // ==============================================

        while (
            $detail = mysqli_fetch_assoc($query_detail)
        ) {

            $produk_id = (int)$detail['ProdukID'];

            $jumlah_beli = (int)$detail['JumlahProduk'];


            if ($produk_id <= 0 || $jumlah_beli <= 0) {
                continue;
            }


            $update_stok = mysqli_query(
                $koneksi,
                "UPDATE produk
                 SET Stok = Stok + $jumlah_beli
                 WHERE ProdukID = '$produk_id'"
            );


            if (!$update_stok) {

                throw new Exception(
                    "Gagal mengembalikan stok produk ID: " .
                    $produk_id
                );
            }
        }


        // ==============================================
        // 5. AUDIT LOG
        // ==============================================

        $aktivitas_log = 'BATAL';

        $deskripsi_log =
            "User " .
            $nama_user_log .
            " membatalkan transaksi dengan ID " .
            $no_transaksi_formatted;


        $username_aman = mysqli_real_escape_string(
            $koneksi,
            $username_log
        );

        $aktivitas_aman = mysqli_real_escape_string(
            $koneksi,
            $aktivitas_log
        );

        $deskripsi_aman = mysqli_real_escape_string(
            $koneksi,
            $deskripsi_log
        );


        $insert_log = mysqli_query(
            $koneksi,
            "INSERT INTO audit_log
            (
                username,
                aktivitas,
                deskripsi,
                waktu
            )
            VALUES
            (
                '$username_aman',
                '$aktivitas_aman',
                '$deskripsi_aman',
                NOW()
            )"
        );


        if (!$insert_log) {

            throw new Exception(
                "Gagal menyimpan audit log: " .
                mysqli_error($koneksi)
            );
        }


        // ==============================================
        // 6. COMMIT
        // ==============================================

        mysqli_commit($koneksi);


        // ==============================================
        // 7. NOTIFIKASI
        // ==============================================

        echo "<script>
            alert('Transaksi berhasil dibatalkan dan stok produk telah dikembalikan.');
            window.location.href = 'riwayat-transaksi.php';
        </script>";

        exit;


    } catch (Exception $e) {


        // ==============================================
        // ROLLBACK
        // ==============================================

        mysqli_rollback($koneksi);


        echo "<script>
            alert('Terjadi kesalahan: " .
            addslashes($e->getMessage()) .
            "');
            window.location.href = 'riwayat-transaksi.php';
        </script>";

        exit;
    }
}


// ======================================================
// AKSI TIDAK DIKENALI
// ======================================================

else {

    echo "<script>
        alert('Aksi tidak dikenali!');
        window.location.href = 'riwayat-transaksi.php';
    </script>";

    exit;
}

?>