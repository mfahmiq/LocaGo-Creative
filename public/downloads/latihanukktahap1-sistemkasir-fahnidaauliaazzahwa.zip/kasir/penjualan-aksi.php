<?php
// penjualan-aksi.php  --  versi v3 (tipe bind_param otomatis)
date_default_timezone_set('Asia/Jakarta');
session_start();
include '../koneksi.php';

// 1. CEK LOGIN
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: ../index.php?pesan=gagal");
    exit;
}

// 2. HANYA BOLEH DARI FORM PEMBAYARAN
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['proses_bayar'])) {
    header("Location: penjualan.php");
    exit;
}

// ======================================================
// FUNGSI BANTU DATABASE
// Tipe data (i/d/s) disusun OTOMATIS dari nilai yang dikirim, sehingga jumlah tipe
// dan jumlah variabel selalu sama (tidak mungkin lagi muncul error
// "number of elements in the type definition string must match...").
// ======================================================
function jalankan($koneksi, $sql, array $nilai = [])
{
    $st = mysqli_prepare($koneksi, $sql);
    if (!$st) {
        throw new Exception('Gagal menyiapkan query: ' . mysqli_error($koneksi));
    }
    if (count($nilai) > 0) {
        $tipe = '';
        foreach ($nilai as $v) {
            $tipe .= is_int($v) ? 'i' : (is_float($v) ? 'd' : 's');
        }
        mysqli_stmt_bind_param($st, $tipe, ...$nilai);
    }
    if (!mysqli_stmt_execute($st)) {
        $err = mysqli_stmt_error($st);
        mysqli_stmt_close($st);
        throw new Exception($err);
    }
    return $st;
}

function ambilSatu($koneksi, $sql, array $nilai = [])
{
    $st  = jalankan($koneksi, $sql, $nilai);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($st));
    mysqli_stmt_close($st);
    return $row ?: null;
}

function kolomAda($koneksi, $tabel, $kolom)
{
    $r = mysqli_query($koneksi, "SHOW COLUMNS FROM `" . $tabel . "` LIKE '" . mysqli_real_escape_string($koneksi, $kolom) . "'");
    return $r && mysqli_num_rows($r) > 0;
}

// 3. FUNGSI KEMBALI KE KASIR
function kembaliKeKasir($pesan)
{
    echo '<script>alert(' . json_encode($pesan) . '); window.location.href = "penjualan.php";</script>';
    exit;
}

// 4. USER ID LOGIN
$user_id = null;
if (isset($_SESSION['UserID']) && is_numeric($_SESSION['UserID']) && (int) $_SESSION['UserID'] > 0) {
    $user_id = (int) $_SESSION['UserID'];
}

// 5. USERNAME UNTUK AUDIT LOG
$username_audit = 'System';
foreach (['username', 'Username', 'nama', 'Nama'] as $key) {
    if (!empty($_SESSION[$key])) {
        $username_audit = $_SESSION[$key];
        break;
    }
}

// ======================================================
// KONFIGURASI ATURAN
// ======================================================
const MIN_BELANJA_DISKON_MEMBER = 50000; // minimal belanja diskon member
const DISKON_MEMBER_PERSEN      = 5;
const POTONGAN_KODE_DISKON      = 5000;  // kode DISKONPROMO
const KODE_DISKON               = 'DISKONPROMO';
const KODE_BONUS                = 'BONUSPRODUK';

// 6. DATA UTAMA
$tipe_pelanggan = ($_POST['tipe_pelanggan'] ?? 'non_member') === 'member' ? 'member' : 'non_member';
$metode_bayar   = in_array($_POST['metode_pembayaran'] ?? 'tunai', ['tunai', 'qris', 'transfer'], true) ? $_POST['metode_pembayaran'] : 'tunai';
$label_metode   = ['tunai' => 'Tunai', 'qris' => 'QRIS', 'transfer' => 'Transfer Bank'][$metode_bayar];
$uang_bayar     = isset($_POST['uang_bayar']) ? (float) $_POST['uang_bayar'] : 0;
$ambil_diskon   = ($_POST['ambil_diskon_member'] ?? '0') === '1';
$kode_promo     = strtoupper(trim($_POST['kode_promo_terpakai'] ?? ''));
$bonus_id_post  = isset($_POST['produk_bonus_id']) ? (int) $_POST['produk_bonus_id'] : 0;
$tanggal        = date('Y-m-d H:i:s');

// Tipe pesanan -> kolom TipePesanan (enum 'Dine-In' / 'Take-Away')
$tipe_pesanan = ($_POST['tipe_pesanan'] ?? 'Dine-In') === 'Take-Away' ? 'Take-Away' : 'Dine-In';
$label_tipe   = $tipe_pesanan;

// 7. DATA PRODUK
$produk_ids = $_POST['produk_id'] ?? [];
$qtys       = $_POST['qty'] ?? [];
$catatans   = $_POST['catatan'] ?? [];
$extras     = $_POST['extra_harga'] ?? [];

// 8. VALIDASI DATA PRODUK
if (!is_array($produk_ids) || count($produk_ids) === 0) {
    kembaliKeKasir('Tidak ada produk yang dipilih.');
}
if (!is_array($qtys)) {
    kembaliKeKasir('Data jumlah produk tidak valid.');
}
if (!is_array($catatans)) $catatans = [];
if (!is_array($extras))   $extras = [];

// 9. DATA PELANGGAN
$pelanggan_id = null;
$nama_pelanggan = null;

try {

    if ($tipe_pelanggan === 'member') {
        $id_post = isset($_POST['pelanggan_id']) ? (int) $_POST['pelanggan_id'] : 0;
        if ($id_post <= 0) kembaliKeKasir('Silakan masukkan ID member terlebih dahulu.');

        $data_pelanggan = ambilSatu($koneksi, "SELECT PelangganID, NamaPelanggan FROM pelanggan WHERE PelangganID = ?", [$id_post]);
        if (!$data_pelanggan) kembaliKeKasir('Data pelanggan member tidak ditemukan.');

        $pelanggan_id   = (int) $data_pelanggan['PelangganID'];
        $nama_pelanggan = $data_pelanggan['NamaPelanggan'];
    } else {
        $nama_pelanggan = trim($_POST['nama_pelanggan_baru'] ?? '');
        if ($nama_pelanggan === '') $nama_pelanggan = 'Pelanggan Umum';
        // Non-member tidak boleh memakai kode promo maupun diskon member
        $kode_promo = '';
        $ambil_diskon = false;
    }

    // 10. HITUNG TOTAL KOTOR & LOOP PRODUK (harga selalu diambil dari database)
    $total_harga_kotor = 0.0;
    $items = [];

    foreach ($produk_ids as $index => $produk_id) {
        $produk_id   = (int) $produk_id;
        $qty         = isset($qtys[$index]) ? (int) $qtys[$index] : 0;
        $catatan     = isset($catatans[$index]) ? trim((string) $catatans[$index]) : '';
        $extra_harga = isset($extras[$index]) ? (float) $extras[$index] : 0.0;

        if ($produk_id <= 0)  kembaliKeKasir('Ada produk yang tidak valid.');
        if ($qty <= 0)        kembaliKeKasir('Jumlah produk harus lebih dari 0.');
        if ($extra_harga < 0) $extra_harga = 0.0;

        $data_produk = ambilSatu($koneksi, "SELECT Harga, Stok, NamaProduk FROM produk WHERE ProdukID = ?", [$produk_id]);
        if (!$data_produk) kembaliKeKasir('Produk dengan ID ' . $produk_id . ' tidak ditemukan.');

        if ((int) $data_produk['Stok'] < $qty) {
            kembaliKeKasir('Stok produk ' . $data_produk['NamaProduk'] . ' tidak mencukupi. Stok tersedia: ' .
                (int) $data_produk['Stok'] . ', jumlah yang dipesan: ' . $qty . '.');
        }

        $subtotal_dasar = (float) $data_produk['Harga'] * $qty;
        $total_harga_kotor += $subtotal_dasar + $extra_harga;

        $items[] = [
            'produk_id'   => $produk_id,
            'qty'         => $qty,
            'catatan'     => $catatan,
            'extra_harga' => $extra_harga,
            'subtotal'    => $subtotal_dasar,
        ];
    }

    // 11. DISKON MEMBER 5% (khusus member, minimal belanja Rp 50.000)
    $nilai_diskon_member = 0.0;
    if ($tipe_pelanggan === 'member' && $ambil_diskon && $total_harga_kotor >= MIN_BELANJA_DISKON_MEMBER) {
        $nilai_diskon_member = $total_harga_kotor * DISKON_MEMBER_PERSEN / 100;
    }

    // 12. KODE PROMO (khusus member)
    $nilai_diskon_promo = 0.0;
    $info_promo = '';

    if ($kode_promo !== '') {
        if ($kode_promo === KODE_DISKON) {
            $nilai_diskon_promo = (float) min(POTONGAN_KODE_DISKON, $total_harga_kotor - $nilai_diskon_member);
            $info_promo = ' (Kode Promo ' . KODE_DISKON . ': -Rp ' . number_format($nilai_diskon_promo, 0, ',', '.') . ')';
        } elseif ($kode_promo === KODE_BONUS) {
            if ($bonus_id_post <= 0) kembaliKeKasir('Pilih produk bonus terlebih dahulu.');
            $d_bonus = ambilSatu($koneksi, "SELECT ProdukID, NamaProduk, Stok FROM produk WHERE ProdukID = ? AND Stok > 0", [$bonus_id_post]);
            if (!$d_bonus) kembaliKeKasir('Produk bonus tidak ditemukan atau stok habis.');

            $items[] = [
                'produk_id'   => (int) $d_bonus['ProdukID'],
                'qty'         => 1,
                'catatan'     => '🎁 Bonus Kode Promo ' . KODE_BONUS,
                'extra_harga' => 0.0,
                'subtotal'    => 0.0,
            ];
            $info_promo = ' (Kode Promo ' . KODE_BONUS . ': Bonus ' . $d_bonus['NamaProduk'] . ')';
        } else {
            kembaliKeKasir('Kode promo tidak valid atau kadaluarsa.');
        }
    }

    $total_harga = (float) max(0, $total_harga_kotor - $nilai_diskon_member - $nilai_diskon_promo);

    // 13. VALIDASI PEMBAYARAN
    if ($metode_bayar !== 'tunai') {
        $uang_bayar = $total_harga; // pembayaran digital selalu pas
    } elseif ($uang_bayar < $total_harga) {
        kembaliKeKasir('Uang pembayaran kurang. Total yang harus dibayar: Rp ' . number_format($total_harga, 0, ',', '.') . '.');
    }

    // 14. KEMBALIAN
    $kembalian = (float) ($uang_bayar - $total_harga);

} catch (Throwable $e) {
    error_log('ERROR PENJUALAN (persiapan): ' . $e->getMessage());
    kembaliKeKasir('Transaksi gagal diproses. Pesan: ' . $e->getMessage() . "\n\n[penjualan-aksi v3 - file: " . __FILE__ . ']');
}

// 15. TRANSAKSI DATABASE
mysqli_begin_transaction($koneksi);

try {

    // Kolom wajib
    $kolom = ['TanggalPenjualan', 'TotalHarga', 'PelangganID', 'Bayar', 'Kembali', 'UserID', 'NamaPelanggan'];
    $nilai = [$tanggal, $total_harga, $pelanggan_id, (float) $uang_bayar, $kembalian, $user_id, $nama_pelanggan];

    // Kolom opsional: hanya diisi jika memang ada di tabel (tidak error bila belum ditambahkan)
    if (kolomAda($koneksi, 'penjualan', 'Status')) {
        $kolom[] = 'Status';
        $nilai[] = 'proses';
    }
    if (kolomAda($koneksi, 'penjualan', 'jenis_pesanan')) {
        $kolom[] = 'jenis_pesanan';
        $nilai[] = 'kasir';
    }
    if (kolomAda($koneksi, 'penjualan', 'TipePesanan')) {
        $kolom[] = 'TipePesanan';
        $nilai[] = $tipe_pesanan;
    }
    if (kolomAda($koneksi, 'penjualan', 'MetodePembayaran')) {
        $kolom[] = 'MetodePembayaran';
        $nilai[] = $label_metode;
    }

    $sql = "INSERT INTO penjualan (" . implode(', ', $kolom) . ") VALUES (" . implode(', ', array_fill(0, count($kolom), '?')) . ")";
    $st = jalankan($koneksi, $sql, $nilai);
    $penjualan_id = mysqli_insert_id($koneksi);
    mysqli_stmt_close($st);
    if (!$penjualan_id) throw new Exception('ID transaksi tidak berhasil dibuat.');

    $nomor_transaksi = 'TRX-' . date('Ymd', strtotime($tanggal)) . '-' . str_pad((string) $penjualan_id, 4, '0', STR_PAD_LEFT);

    foreach ($items as $item) {
        $st = jalankan($koneksi,
            "INSERT INTO detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal, Catatan, BiayaExtra) VALUES (?, ?, ?, ?, ?, ?)",
            [(int) $penjualan_id, $item['produk_id'], $item['qty'], (float) $item['subtotal'], $item['catatan'], (float) $item['extra_harga']]
        );
        mysqli_stmt_close($st);

        $st = jalankan($koneksi,
            "UPDATE produk SET Stok = Stok - ? WHERE ProdukID = ? AND Stok >= ?",
            [$item['qty'], $item['produk_id'], $item['qty']]
        );
        $terpengaruh = mysqli_stmt_affected_rows($st);
        mysqli_stmt_close($st);
        if ($terpengaruh !== 1) {
            throw new Exception('Stok produk tidak mencukupi atau produk tidak ditemukan.');
        }
    }

    // AUDIT LOG
    $keterangan_audit = 'Menambahkan transaksi baru ' . $nomor_transaksi
        . ' (' . $label_metode . ')'
        . ' (' . $label_tipe . ')'
        . ($nilai_diskon_member > 0 ? ' (Diskon Member 5%: -Rp ' . number_format($nilai_diskon_member, 0, ',', '.') . ')' : '')
        . $info_promo;

    $st = jalankan($koneksi,
        "INSERT INTO audit_log (username, aktivitas, waktu, deskripsi) VALUES (?, ?, NOW(), ?)",
        [(string) $username_audit, 'TAMBAH', $keterangan_audit]
    );
    mysqli_stmt_close($st);

    mysqli_commit($koneksi);

    $_SESSION['transaksi_berhasil'] = ['id' => (int) $penjualan_id, 'kode' => $nomor_transaksi];
    header("Location: penjualan.php");
    exit;

} catch (Throwable $e) {
    mysqli_rollback($koneksi);
    error_log('ERROR PENJUALAN: ' . $e->getMessage());
    kembaliKeKasir('Transaksi gagal disimpan. Pesan: ' . $e->getMessage() . "\n\n[penjualan-aksi v3 - file: " . __FILE__ . ']');
}