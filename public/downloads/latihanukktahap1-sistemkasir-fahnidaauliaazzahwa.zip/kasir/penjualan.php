<?php
date_default_timezone_set('Asia/Jakarta');
session_start();
include '../koneksi.php';

$transaksiBerhasil = $_SESSION['transaksi_berhasil'] ?? null;
unset($_SESSION['transaksi_berhasil']);

if (!isset($_SESSION['login'])) {
    header("Location: ../index.php?pesan=gagal");
    exit;
}

$user_role = strtolower(trim($_SESSION['Role'] ?? 'kasir'));
$is_pelanggan = ($user_role === 'pelanggan');

$query_produk = mysqli_query($koneksi, "SELECT * FROM produk WHERE Stok > 0 ORDER BY NamaProduk ASC");
$query_member = mysqli_query($koneksi, "SELECT * FROM pelanggan ORDER BY NamaPelanggan ASC");

$pelanggan_list = [];
while ($row = mysqli_fetch_assoc($query_member)) {
    $pelanggan_list[] = [
        'id' => $row['PelangganID'],
        'nama' => $row['NamaPelanggan']
    ];
}

$produk_bonus_list = [];
mysqli_data_seek($query_produk, 0);
while ($row = mysqli_fetch_assoc($query_produk)) {
    $produk_bonus_list[] = [
        'id' => $row['ProdukID'],
        'nama' => $row['NamaProduk'],
        'stok' => $row['Stok']
    ];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasir - Daily Coffee & Toast</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body { background-color: #FAF8F5; font-family: 'Plus Jakarta Sans', sans-serif; }
        .wrapper-konten-kasir { margin-top: 105px; margin-left: 290px; padding-right: 35px; padding-bottom: 50px; }
        @media (max-width: 992px) { .wrapper-konten-kasir { margin-left: 20px; margin-right: 20px; padding-right: 0; } }
        .filter-pill-btn { background: #FFFFFF; border: 1.5px solid #E7E5E4; color: #78716C; font-weight: 700; font-size: 0.85rem; border-radius: 50rem; padding: 0.6rem 1.25rem; transition: all 0.25s ease; box-shadow: 0 2px 5px rgba(0,0,0,0.02); display: inline-flex; align-items: center; gap: 8px; cursor: pointer; text-decoration: none; }
        .filter-pill-btn:hover { border-color: #C49A45; color: #C49A45; transform: translateY(-2px); }
        .filter-pill-btn.active { background: #C49A45; border-color: #C49A45; color: #FFFFFF; box-shadow: 0 6px 15px rgba(196, 154, 69, 0.3); }
        .catalog-card { background: #FFFFFF; border-radius: 20px; border: 1px solid rgba(231, 229, 228, 0.9); box-shadow: 0 10px 25px rgba(0, 0, 0, 0.03); transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); overflow: hidden; height: 100%; display: flex; flex-direction: column; cursor: pointer; }
        .catalog-card:hover { transform: translateY(-6px); box-shadow: 0 18px 35px rgba(196, 154, 69, 0.18); border-color: #C49A45; }
        .catalog-img-wrapper { width: 100%; height: 150px; background-color: #FAF8F5; position: relative; overflow: hidden; }
        .catalog-img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.4s ease; }
        .catalog-card:hover .catalog-img { transform: scale(1.08); }
        .badge-float-stok { position: absolute; top: 10px; right: 10px; font-weight: 800; font-size: 0.72rem; padding: 5px 10px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25); color: #FFFFFF; }
        .stok-safe { background: #198754; }
        .stok-warning { background: #F59E0B; }
        .stok-danger { background: #DC3545; }
        .search-katalog-input { border-radius: 14px; padding: 0.75rem 1.25rem; border: 1px solid #E7E5E4; font-size: 0.95rem; background-color: #FFFFFF; }
        .search-katalog-input:focus { border-color: #C49A45; box-shadow: 0 0 0 4px rgba(196, 154, 69, 0.1); }
        .cart-container { background: #FFFFFF; border-radius: 22px; border: 1px solid rgba(231, 229, 228, 0.9); box-shadow: 0 12px 30px rgba(0, 0, 0, 0.04); position: sticky; top: 125px; }
        .cart-header { border-bottom: 2px dashed rgba(231, 229, 228, 0.8); padding-bottom: 1rem; }
        .total-box { background: linear-gradient(135deg, #141211 0%, #2D2621 100%); border-radius: 16px; padding: 1.25rem; color: #FFFFFF; }
        .nav-pills-pelanggan { background: #F1EFE9; padding: 4px; border-radius: 50rem; display: flex; gap: 4px; border: 1px solid #E7E5E4; }
        .nav-pills-pelanggan .nav-link { flex: 1; color: #78716C; font-weight: 700; font-size: 0.85rem; border-radius: 50rem; background: transparent; border: none; padding: 0.55rem 1rem; transition: all 0.25s ease-in-out; text-align: center; }
        .nav-pills-pelanggan .nav-link:hover { color: #1C1917; }
        .nav-pills-pelanggan .nav-link.active { background: #FFFFFF !important; color: #C49A45 !important; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08); transform: scale(1.02); }
        .btn-proses-estetik { background: linear-gradient(135deg, #D4AF37 0%, #C49A45 50%, #A37B2C 100%); color: #FFFFFF; font-weight: 800; padding: 0.95rem 1.5rem; border-radius: 50rem; border: none; transition: all 0.2s ease-in-out; letter-spacing: 0.5px; box-shadow: 0 4px 15px rgba(196, 154, 69, 0.25); }
        .btn-proses-estetik:not(:disabled):hover { background: linear-gradient(135deg, #E5C158 0%, #D4AF37 50%, #B88E3B 100%); transform: translateY(-2px); box-shadow: 0 6px 20px rgba(196, 154, 69, 0.35); color: #FFFFFF; }
        .btn-proses-estetik:disabled { background: #E7E5E4; color: #A8A29E; box-shadow: none; cursor: not-allowed; transform: none; }
        .qty-btn-group { display: inline-flex; align-items: center; background: #FAF8F5; border: 1px solid #E7E5E4; border-radius: 10px; overflow: hidden; padding: 2px; }
        .qty-btn { background: #FFFFFF; border: 1px solid rgba(231, 229, 228, 0.8); color: #44403C; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 0.85rem; border-radius: 8px; cursor: pointer; transition: all 0.2s ease; }
        .qty-btn:hover { background-color: #C49A45; color: #FFFFFF; border-color: #C49A45; }
        .qty-value { min-width: 28px; text-align: center; font-weight: 700; font-size: 0.85rem; color: #1c1917; }
        .modal-transaksi .modal-dialog { max-width: 500px; margin: 1.25rem auto; }
        .modal-transaksi .modal-content { border: 2px solid #E5E7EB; border-radius: 28px; background: #FFFFFF; box-shadow: 0 22px 60px rgba(15, 23, 42, 0.20); overflow: hidden; }
        .modal-transaksi .modal-body { padding: 42px 34px 30px; text-align: center; }
        .modal-transaksi-icon { width: 76px; height: 76px; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-size: 2.25rem; font-weight: 800; box-shadow: 0 10px 22px rgba(15, 23, 42, 0.08); }
        .modal-transaksi-icon.confirm { color: #D97706; background: #FEF3A6; border: 3px solid #F59E0B; }
        .modal-transaksi-icon.success { color: #15803D; background: #DCFCE7; border: 3px solid #22C55E; }
        .modal-transaksi-icon.promo { color: #C49A45; background: #FDF8ED; border: 3px solid #C49A45; }
        .modal-transaksi-title { color: #1E293B; font-size: 1.35rem; font-weight: 850; letter-spacing: -0.7px; line-height: 1.3; margin-bottom: 10px; }
        .modal-transaksi-desc { color: #718096; font-size: .94rem; line-height: 1.5; margin: 0 auto; max-width: 390px; }
        .modal-transaksi-actions { display: flex; gap: 14px; margin-top: 38px; }
        .modal-transaksi-btn { min-height: 54px; flex: 1; border-radius: 50rem; font-size: .94rem; font-weight: 800; border: 1px solid transparent; transition: all .2s ease; }
        .modal-transaksi-btn.confirm-yes { color: #FFFFFF; background: #166534; box-shadow: 0 4px 9px rgba(22, 101, 52, .16); }
        .modal-transaksi-btn.confirm-yes:hover { color: #FFFFFF; background: #14532D; transform: translateY(-1px); }
        .modal-transaksi-btn.confirm-no { color: #687385; background: #F8FAFC; border-color: #DCE2E9; }
        .modal-transaksi-btn.confirm-no:hover { color: #334155; background: #F1F5F9; }
        .modal-transaksi-btn.print { color: #FFFFFF; background: linear-gradient(135deg, #15803D, #166534); box-shadow: 0 5px 14px rgba(22, 101, 52, .2); }
        .modal-transaksi-btn.print:hover { color: #FFFFFF; background: linear-gradient(135deg, #166534, #14532D); transform: translateY(-1px); }
        .modal-transaksi-btn.history { color: #FFFFFF; background: linear-gradient(135deg, #C49A45, #A37B2C); box-shadow: 0 5px 14px rgba(196, 154, 69, .2); }
        .modal-transaksi-btn.history:hover { color: #FFFFFF; background: linear-gradient(135deg, #D4AF37, #A37B2C); transform: translateY(-1px); }
        .kode-transaksi-box { display: inline-flex; align-items: center; gap: 8px; margin-top: 18px; padding: 10px 16px; border: 1px solid #BBF7D0; border-radius: 12px; background: #F0FDF4; color: #166534; font-size: .9rem; font-weight: 800; letter-spacing: .3px; }
        .quick-cash-btn { background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.2); color: #FFFFFF; font-size: .72rem; font-weight: 700; border-radius: 50rem; padding: 3px 10px; transition: all .2s ease; }
        .quick-cash-btn:hover { background: #C49A45; border-color: #C49A45; }
        .info-nontunai { background: rgba(196,154,69,0.15); border: 1px dashed rgba(196,154,69,0.6); border-radius: 12px; padding: 8px 12px; font-size: .78rem; color: #F5E6BF; }
        .hint-diskon { background: #FDF8ED; border: 1px solid rgba(196,154,69,0.35); color: #8A6A22; border-radius: 12px; padding: 8px 12px; font-size: .78rem; font-weight: 700; }
        .progress-diskon { height: 6px; border-radius: 50rem; background: #F1EFE9; overflow: hidden; margin-top: 6px; }
        .progress-diskon > div { height: 100%; background: linear-gradient(90deg, #D4AF37, #A37B2C); transition: width .4s ease; }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="wrapper-konten-kasir">
    <div class="container-fluid">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 bg-white p-4 rounded-4 shadow-sm border">
            <div>
                <span class="badge px-3 py-1.5 rounded-pill fw-bold mb-2" style="background: rgba(196, 154, 69, 0.15); color: #C49A45; border: 1px solid rgba(196, 154, 69, 0.3);">
                    <i class="bi bi-shop me-1"></i> POS SYSTEM ACTIVE
                </span>
                <h3 class="fw-extrabold mb-1" style="color: #141211; letter-spacing: -0.5px;">Transaksi Kasir &amp; Katalog Menu</h3>
                <p class="text-muted small mb-0">Pilih sajian Coffee atau Toast dan tambahkan catatan serta biaya ekstra jika ada.</p>
            </div>
            <div class="d-flex align-items-center gap-3">
                <div class="d-inline-flex align-items-center gap-2 bg-light px-3 py-2 rounded-3 border">
                    <i class="bi bi-clock-history text-warning fs-5"></i>
                    <div class="text-start">
                        <span class="text-muted d-block" style="font-size: 11px; line-height: 1;">Waktu Akses Sistem</span>
                        <span id="live-clock" class="fw-bold text-dark" style="font-size: 13px;">Memuat waktu...</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-lg-7 col-xl-8">
                <div class="card border-0 rounded-4 p-4 shadow-sm bg-white">
                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-3">
                        <h6 class="fw-bold mb-0 d-flex align-items-center gap-2">
                            <i class="bi bi-grid-fill text-warning"></i> Pilih Menu Pesanan
                        </h6>
                        <div class="position-relative" style="min-width: 240px;">
                            <input type="text" id="searchKatalog" class="form-control search-katalog-input ps-5" placeholder="Cari nama menu..." onkeyup="jalankanFilter()">
                            <i class="bi bi-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
                        </div>
                    </div>

                    <div class="d-flex flex-wrap align-items-center gap-2 mb-4">
                        <button class="filter-pill-btn active" onclick="filterKategori('semua')" id="btnSemua">
                            <i class="bi bi-grid-fill"></i> Semua Menu
                        </button>
                        <button class="filter-pill-btn" onclick="filterKategori('coffee')" id="btnCoffee">
                            <i class="bi bi-cup-hot-fill"></i> Coffee Section
                        </button>
                        <button class="filter-pill-btn" onclick="filterKategori('toast')" id="btnToast">
                            <i class="bi bi-shop"></i> Toast Section
                        </button>
                    </div>

                    <div class="row g-3" id="containerKatalog">
                        <?php if (mysqli_num_rows($query_produk) > 0): ?>
                            <?php mysqli_data_seek($query_produk, 0); ?>

                            <?php while ($p = mysqli_fetch_assoc($query_produk)): ?>
                                <?php
                                $nama_produk_js = htmlspecialchars($p['NamaProduk'], ENT_QUOTES);
                                $nama_foto = !empty($p['foto']) ? $p['foto'] : '';
                                $path_foto = '../asset/img/' . $nama_foto;
                                $img_src = (empty($nama_foto) || !file_exists($path_foto))
                                    ? 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80'
                                    : $path_foto;

                                $stok = (int)$p['Stok'];
                                $nama_menu_lower = strtolower($p['NamaProduk']);
                                $kategori = 'coffee';

                                if (
                                    strpos($nama_menu_lower, 'toast') !== false ||
                                    strpos($nama_menu_lower, 'roti') !== false ||
                                    strpos($nama_menu_lower, 'sandwich') !== false
                                ) {
                                    $kategori = 'toast';
                                }
                                ?>

                                <div class="col-6 col-md-4 card-item-produk"
                                     data-nama="<?= htmlspecialchars($nama_menu_lower); ?>"
                                     data-kategori="<?= $kategori; ?>">

                                    <div class="catalog-card"
                                         onclick="tambahItem(<?= $p['ProdukID']; ?>, '<?= $nama_produk_js; ?>', <?= $p['Harga']; ?>, <?= $stok; ?>)">

                                        <div class="catalog-img-wrapper">
                                            <img src="<?= $img_src; ?>"
                                                 alt="<?= htmlspecialchars($p['NamaProduk']); ?>"
                                                 class="catalog-img">

                                            <span class="badge position-absolute top-0 start-0 m-2 px-2 py-1 shadow-sm"
                                                  style="font-size: 0.65rem; background: rgba(0,0,0,0.6); color: #fff; backdrop-filter: blur(4px);">
                                                <?= ($kategori === 'toast') ? '🍞 Toast' : '☕ Coffee'; ?>
                                            </span>

                                            <?php if ($stok > 10): ?>
                                                <span class="badge-float-stok stok-safe">Stok: <?= $stok; ?></span>
                                            <?php elseif ($stok > 0): ?>
                                                <span class="badge-float-stok stok-warning">Sisa: <?= $stok; ?></span>
                                            <?php else: ?>
                                                <span class="badge-float-stok stok-danger">Habis</span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="p-3 d-flex flex-column justify-content-between flex-grow-1">
                                            <div>
                                                <h6 class="fw-bold text-dark mb-1 text-truncate"
                                                    title="<?= htmlspecialchars($p['NamaProduk']); ?>">
                                                    <?= htmlspecialchars($p['NamaProduk']); ?>
                                                </h6>
                                                <small class="text-muted">Sisa: <?= $stok; ?> pcs</small>
                                            </div>

                                            <div class="mt-2 pt-2 border-top">
                                                <span class="fw-extrabold text-success" style="font-size: 1rem;">
                                                    Rp <?= number_format($p['Harga'], 0, ',', '.'); ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="col-12 text-center py-5 text-muted">
                                <i class="bi bi-cup-hot fs-1 d-block mb-2 text-warning opacity-50"></i>
                                Belum ada menu yang tersedia di kasir.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-5 col-xl-4">
                <div class="cart-container p-4">
                    <div class="cart-header mb-3">
                        <h6 class="fw-bold mb-1 d-flex align-items-center gap-2">
                            <i class="bi bi-cart-check-fill text-warning"></i> Keranjang Pesanan
                        </h6>
                        <small class="text-muted">Kelola pesanan, catatan, dan promo</small>
                    </div>

                    <form action="penjualan-aksi.php" method="POST" id="formPenjualan" onsubmit="return validasiBayar()">

                        <div class="mb-3">
                            <label class="form-label small fw-bold text-secondary mb-2">Tipe Pelanggan</label>

                            <div class="nav nav-pills-pelanggan mb-3" role="tablist">
                                <button class="nav-link active" type="button" onclick="setTipePelanggan('member')">
                                    <i class="bi bi-card-heading me-1"></i> Member
                                </button>
                                <button class="nav-link" type="button" onclick="setTipePelanggan('non_member')">
                                    <i class="bi bi-person-plus me-1"></i> Non-Member
                                </button>
                            </div>

                            <input type="hidden" name="tipe_pelanggan" id="tipePelangganInput" value="member">

                            <div id="sectionMember">
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text bg-light text-muted">ID Member</span>
                                    <input type="number"
                                           id="inputMemberID"
                                           class="form-control"
                                           placeholder="Masukkan ID (contoh: 1)"
                                           oninput="cariMember()">
                                </div>

                                <input type="hidden" name="pelanggan_id" id="hiddenPelangganID" value="">

                                <div id="hasilMember" class="mt-2 p-2 rounded-3 text-center small d-none"></div>
                                <div id="hintDiskonMember" class="hint-diskon mt-2 d-none"></div>
                            </div>

                            <div id="sectionNonMember" class="d-none">
                                <input type="text"
                                       name="nama_pelanggan_baru"
                                       id="inputNamaBaru"
                                       class="form-control form-control-sm"
                                       placeholder="Masukkan nama pelanggan...">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold text-secondary mb-2">Tipe Pesanan</label>

                            <div class="nav nav-pills-pelanggan mb-2">
                                <button class="nav-link active"
                                        type="button"
                                        id="btnDineIn"
                                        onclick="setTipePesanan('Dine-In')">
                                    <i class="bi bi-cup-hot me-1"></i> Dine In
                                </button>

                                <button class="nav-link"
                                        type="button"
                                        id="btnTakeAway"
                                        onclick="setTipePesanan('Take-Away')">
                                    <i class="bi bi-bag-check me-1"></i> Take Away
                                </button>
                            </div>

                            <input type="hidden" name="tipe_pesanan" id="inputTipePesanan" value="Dine-In">
                        </div>

                        <div class="mb-3" style="max-height: 280px; overflow-y: auto;">
                            <div id="containerKeranjangList"></div>

                            <div id="emptyRow" class="text-center text-muted small py-4">
                                <i class="bi bi-cart-x fs-2 d-block mb-2 opacity-50"></i>
                                Belum ada menu yang dipilih.
                            </div>
                        </div>

                        <div class="total-box mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span class="small text-uppercase opacity-75 fw-semibold">Total Tagihan</span>
                                <span class="badge bg-warning text-dark fw-bold" id="badgeTotalItem">0 Item</span>
                            </div>

                            <div id="rincianDiskonBox" class="small text-warning mb-1 d-none"></div>

                            <h3 class="fw-bold text-warning mb-3" id="textTotal">Rp 0</h3>

                            <input type="hidden" name="total_harga" id="inputTotal" value="0">
                            <input type="hidden" name="diskon_nominal" id="inputDiskonNominal" value="0">
                            <input type="hidden" name="ambil_diskon_member" id="inputAmbilDiskon" value="0">

                            <label class="form-label small text-white-50 fw-semibold mb-1">
                                Metode Pembayaran
                            </label>

                            <div class="nav nav-pills-pelanggan mb-2">
                                <button class="nav-link active"
                                        type="button"
                                        id="btnTunai"
                                        onclick="setMetodeBayar('tunai')">
                                    <i class="bi bi-cash-coin me-1"></i> Tunai
                                </button>

                                <button class="nav-link"
                                        type="button"
                                        id="btnQris"
                                        onclick="setMetodeBayar('qris')">
                                    <i class="bi bi-qr-code-scan me-1"></i> QRIS
                                </button>

                                <button class="nav-link"
                                        type="button"
                                        id="btnTransfer"
                                        onclick="setMetodeBayar('transfer')">
                                    <i class="bi bi-bank me-1"></i> Transfer
                                </button>
                            </div>

                            <input type="hidden"
                                   name="metode_pembayaran"
                                   id="inputMetodeBayar"
                                   value="tunai">

                            <div id="infoNonTunai" class="info-nontunai mb-2 d-none">
                                <div id="statusDigital"></div>

                                <button type="button"
                                        class="quick-cash-btn mt-2"
                                        onclick="bukaModalDigital()">
                                    <i class="bi bi-qr-code me-1"></i> Tampilkan QR / Instruksi
                                </button>
                            </div>

                            <div class="mb-2">
                                <label class="form-label small text-white-50 fw-semibold mb-1">
                                    Uang Diterima (Rp)
                                </label>

                                <input type="number"
                                       name="uang_bayar"
                                       id="inputUangBayar"
                                       class="form-control form-control-sm text-dark fw-bold"
                                       placeholder="0"
                                       oninput="hitungKembalian">

                                <div id="quickCash" class="d-flex flex-wrap gap-1 mt-2">
                                    <button type="button" class="quick-cash-btn" onclick="isiUang('pas')">Uang Pas</button>
                                    <button type="button" class="quick-cash-btn" onclick="isiUang(20000)">20rb</button>
                                    <button type="button" class="quick-cash-btn" onclick="isiUang(50000)">50rb</button>
                                    <button type="button" class="quick-cash-btn" onclick="isiUang(100000)">100rb</button>
                                </div>
                            </div>

                            <div class="d-flex justify-content-between align-items-center pt-2 border-top border-secondary">
                                <span class="small text-white-50">Kembalian:</span>
                                <span class="fw-bold fs-6 text-white" id="textKembalian">Rp 0</span>
                            </div>
                        </div>

                        <button type="submit"
                                name="proses_bayar"
                                id="btnSubmit"
                                class="btn btn-proses-estetik w-100 d-flex align-items-center justify-content-center gap-2"
                                disabled>

                            <i class="bi bi-receipt-cutoff fs-5"></i>
                            <span>Proses Transaksi</span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Promo -->
<div class="modal fade modal-transaksi"
     id="modalPromoMember"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">

                <div class="modal-transaksi-icon promo">
                    <i class="bi bi-stars"></i>
                </div>

                <h2 class="modal-transaksi-title">Promo Khusus Member!</h2>

                <p class="modal-transaksi-desc">
                    Selamat! Anda berhak mendapatkan diskon 5% karena berbelanja minimal Rp 50.000.
                </p>

                <div class="modal-transaksi-actions">
                    <button type="button"
                            class="modal-transaksi-btn confirm-yes"
                            onclick="putuskanDiskon(true)"
                            data-bs-dismiss="modal">
                        Ambil Promo
                    </button>

                    <button type="button"
                            class="modal-transaksi-btn confirm-no"
                            onclick="putuskanDiskon(false)"
                            data-bs-dismiss="modal">
                        Tidak
                    </button>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Modal Pembayaran Digital -->
<div class="modal fade modal-transaksi"
     id="modalPembayaranDigital"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">

                <div class="modal-transaksi-icon promo">
                    <i class="bi bi-qr-code-scan" id="ikonDigital"></i>
                </div>

                <h2 class="modal-transaksi-title" id="judulDigital">Pembayaran QRIS</h2>

                <p class="modal-transaksi-desc">Total yang harus dibayar</p>

                <h3 class="fw-bold mt-1 mb-3"
                    style="color:#C49A45;"
                    id="nominalDigital">
                    Rp 0
                </h3>

                <div id="areaQr"
                     class="mx-auto mb-3 p-3 bg-white border rounded-4"
                     style="width:210px;">
                </div>

                <div id="areaTransfer"
                     class="d-none text-start mx-auto mb-3 p-3 rounded-4"
                     style="max-width:320px;background:#FDF8ED;border:1px solid rgba(196,154,69,.35);font-size:.85rem;">

                    <div class="text-muted small">Bank Tujuan (simulasi)</div>
                    <div class="fw-bold">Bank Daily Coffee - a.n. Daily Coffee &amp; Toast</div>

                    <div class="text-muted small mt-2">No. Rekening</div>
                    <div class="fw-bold" style="letter-spacing:1px;">1234 5678 9012</div>
                </div>

                <p class="modal-transaksi-desc small" id="pesanDigital">
                    Silakan scan QRIS berikut. (Simulasi: Pastikan saldo masuk sebelum klik Proses)
                </p>

                <div class="modal-transaksi-actions">
                    <button type="button"
                            class="modal-transaksi-btn confirm-yes"
                            onclick="konfirmasiDigital()">
                        <i class="bi bi-check-lg me-1"></i> Pembayaran Diterima
                    </button>

                    <button type="button"
                            class="modal-transaksi-btn confirm-no"
                            onclick="batalDigital()">
                        Batal
                    </button>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Modal Konfirmasi Simpan -->
<div class="modal fade modal-transaksi"
     id="modalKonfirmasiTransaksi"
     tabindex="-1"
     aria-hidden="true"
     data-bs-backdrop="static"
     data-bs-keyboard="false">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body">

                <div class="modal-transaksi-icon confirm">?</div>

                <h2 class="modal-transaksi-title">
                    Yakin Ingin Mengirim Pesanan?
                </h2>

                <p class="modal-transaksi-desc">
                    Pastikan seluruh pesanan dan pembayaran sudah benar.
                    Pesanan akan dikirim dan disimpan ke dalam database sistem.
                </p>

                <div class="modal-transaksi-actions">

                    <button type="button"
                            class="modal-transaksi-btn confirm-yes"
                            id="btnKonfirmasiSimpan">
                        <i class="bi bi-check-lg me-1"></i> Ya, Kirim Pesanan
                    </button>

                    <button type="button"
                            class="modal-transaksi-btn confirm-no"
                            data-bs-dismiss="modal">
                        Nanti Saja
                    </button>

                </div>

            </div>
        </div>
    </div>
</div>

<?php if (!empty($transaksiBerhasil) && !empty($transaksiBerhasil['id'])): ?>

    <?php if ($is_pelanggan): ?>

        <!-- Popup sukses khusus pelanggan -->
        <div class="modal fade modal-transaksi"
             id="modalPesananBerhasil"
             tabindex="-1"
             aria-hidden="true"
             data-bs-backdrop="static"
             data-bs-keyboard="false">

            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body">

                        <div class="modal-transaksi-icon success">
                            <i class="bi bi-check-lg"></i>
                        </div>

                        <h2 class="modal-transaksi-title">
                            Pesanan Berhasil Dipesan!
                        </h2>

                        <p class="modal-transaksi-desc">
                            Pesanan dengan nomor transaksi
                        </p>

                        <div class="kode-transaksi-box">
                            <i class="bi bi-receipt"></i>
                            <?= htmlspecialchars($transaksiBerhasil['kode'], ENT_QUOTES, 'UTF-8'); ?>
                        </div>

                        <p class="modal-transaksi-desc mt-3">
                            telah berhasil dipesan dan masuk ke sistem.
                            Terima kasih sudah melakukan pemesanan!
                        </p>

                        <div class="modal-transaksi-actions">

                            <a class="modal-transaksi-btn history d-flex align-items-center justify-content-center text-decoration-none"
                               href="riwayat-transaksi.php">
                                <i class="bi bi-clock-history me-2"></i>
                                Lihat Riwayat Pesanan
                            </a>

                        </div>

                    </div>
                </div>
            </div>
        </div>

    <?php else: ?>

        <!-- Popup sukses admin/kasir -->
        <div class="modal fade modal-transaksi"
             id="modalTransaksiBerhasil"
             tabindex="-1"
             aria-hidden="true"
             data-bs-backdrop="static"
             data-bs-keyboard="false">

            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body">

                        <div class="modal-transaksi-icon success">
                            <i class="bi bi-check-lg"></i>
                        </div>

                        <h2 class="modal-transaksi-title">
                            Transaksi Berhasil Disimpan!
                        </h2>

                        <p class="modal-transaksi-desc">
                            Transaksi dengan kode
                        </p>

                        <div class="kode-transaksi-box">
                            <i class="bi bi-receipt"></i>
                            <?= htmlspecialchars($transaksiBerhasil['kode'], ENT_QUOTES, 'UTF-8'); ?>
                        </div>

                        <p class="modal-transaksi-desc mt-3">
                            telah berhasil disimpan ke database sistem kasir.
                        </p>

                        <div class="modal-transaksi-actions">

                            <a class="modal-transaksi-btn print d-flex align-items-center justify-content-center text-decoration-none"
                               href="cetak-struk.php?id=<?= (int)$transaksiBerhasil['id']; ?>">
                                <i class="bi bi-printer-fill me-2"></i>
                                Cetak Struk
                            </a>

                        </div>

                    </div>
                </div>
            </div>
        </div>

    <?php endif; ?>

<?php endif; ?>

<script>
const dataPelanggan = <?= json_encode($pelanggan_list, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
const MIN_BELANJA_DISKON = 50000;
const DISKON_MEMBER_PERSEN = 5;
const POTONGAN_PROMO = 5000;

let keranjang = [];
let globalTotalHarga = 0;
let kategoriAktif = 'semua';
let jenisPromoKode = '';
let diskonMemberDitolak = false;
let popupDiskonSudahTampil = false;
let metodeBayar = 'tunai';
let digitalTerkonfirmasiTotal = null;
let konfirmasiTransaksi = false;

function rupiah(n) {
    return 'Rp ' + Math.round(n).toLocaleString('id-ID');
}

function updateLiveClock() {
    const now = new Date();
    const dateStr = now.toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    });

    const timeStr = [now.getHours(), now.getMinutes(), now.getSeconds()]
        .map(v => String(v).padStart(2, '0'))
        .join(':');

    const el = document.getElementById('live-clock');
    if (el) el.innerText = `${dateStr}, ${timeStr} WIB`;
}

updateLiveClock();
setInterval(updateLiveClock, 1000);

function escapeHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function isMemberValid() {
    return document.getElementById('tipePelangganInput').value === 'member' &&
           document.getElementById('hiddenPelangganID').value !== '';
}

function setTipePelanggan(tipe) {
    document.getElementById('tipePelangganInput').value = tipe;

    const buttons = document.querySelectorAll('.nav-pills-pelanggan')[0].querySelectorAll('.nav-link');
    const isMember = tipe === 'member';

    buttons[0].classList.toggle('active', isMember);
    buttons[1].classList.toggle('active', !isMember);

    document.getElementById('sectionMember').classList.toggle('d-none', !isMember);
    document.getElementById('sectionNonMember').classList.toggle('d-none', isMember);
    document.getElementById('sectionPromo').classList.toggle('d-none', !isMember);

    if (!isMember) {
        document.getElementById('hasilMember').classList.add('d-none');
        document.getElementById('hiddenPelangganID').value = '';
        document.getElementById('inputMemberID').value = '';
        resetPromo();
    }

    renderKeranjang();
}

function cariMember() {
    const inputID = document.getElementById('inputMemberID').value;
    const hasilDiv = document.getElementById('hasilMember');
    const hiddenID = document.getElementById('hiddenPelangganID');

    if (!inputID) {
        hasilDiv.classList.add('d-none');
        hiddenID.value = '';
        renderKeranjang();
        return;
    }

    const found = dataPelanggan.find(p => p.id == inputID);

    hasilDiv.classList.remove(
        'd-none',
        'bg-success-subtle',
        'text-success',
        'bg-danger-subtle',
        'text-danger'
    );

    if (found) {
        hasilDiv.classList.add('bg-success-subtle', 'text-success');
        hasilDiv.innerHTML =
            `<i class="bi bi-check-circle-fill me-1"></i> Member: <strong>${escapeHtml(found.nama)}</strong>`;

        hiddenID.value = found.id;
    } else {
        hasilDiv.classList.add('bg-danger-subtle', 'text-danger');
        hasilDiv.innerHTML =
            `<i class="bi bi-x-circle-fill me-1"></i> ID Member tidak ditemukan!`;

        hiddenID.value = '';
    }

    renderKeranjang();
}

function putuskanDiskon(ambil) {
    diskonMemberDitolak = !ambil;
    renderKeranjang();
}

function resetPromo() {
    jenisPromoKode = '';
    document.getElementById('hiddenKodePromo').value = '';
    document.getElementById('inputKodePromo').value = '';
    document.getElementById('infoPromo').classList.add('d-none');
    document.getElementById('sectionBonusKasir').classList.add('d-none');
    document.getElementById('selectProdukBonus').value = '';
}

function terapkanKodePromo() {
    if (!isMemberValid()) {
        alert('Kode promo hanya untuk member. Masukkan ID Member yang valid terlebih dahulu!');
        return;
    }

    const kode = document.getElementById('inputKodePromo').value.trim().toUpperCase();
    const infoPromo = document.getElementById('infoPromo');
    const hiddenKode = document.getElementById('hiddenKodePromo');
    const sectionBonus = document.getElementById('sectionBonusKasir');

    if (!kode) {
        alert('Masukkan kode promo terlebih dahulu!');
        return;
    }

    if (kode === 'DISKONPROMO') {
        jenisPromoKode = 'diskon';
        hiddenKode.value = kode;

        infoPromo.classList.remove('d-none');
        infoPromo.innerHTML =
            `<i class="bi bi-check-circle-fill"></i> Kode promo diskon berhasil diterapkan! Potongan ${rupiah(POTONGAN_PROMO)}.`;

        sectionBonus.classList.add('d-none');

    } else if (kode === 'BONUSPRODUK') {
        jenisPromoKode = 'bonus';
        hiddenKode.value = kode;

        infoPromo.classList.remove('d-none');
        infoPromo.innerHTML =
            `<i class="bi bi-check-circle-fill"></i> Kode bonus produk aktif! Silakan pilih bonus di bawah.`;

        sectionBonus.classList.remove('d-none');

    } else {
        alert('Kode promo tidak valid atau kadaluarsa!');
        resetPromo();
    }

    renderKeranjang();
}

function filterKategori(kategori) {
    kategoriAktif = kategori;

    document.querySelectorAll('.filter-pill-btn')
        .forEach(btn => btn.classList.remove('active'));

    document.getElementById({
        semua: 'btnSemua',
        coffee: 'btnCoffee',
        toast: 'btnToast'
    }[kategori]).classList.add('active');

    jalankanFilter();
}

function jalankanFilter() {
    const q = document.getElementById('searchKatalog').value.toLowerCase();

    Array.from(document.getElementsByClassName('card-item-produk'))
        .forEach(item => {
            const cocokKategori =
                kategoriAktif === 'semua' ||
                item.getAttribute('data-kategori') === kategoriAktif;

            const cocokSearch =
                item.getAttribute('data-nama').includes(q);

            item.style.display =
                (cocokKategori && cocokSearch) ? 'block' : 'none';
        });
}

function tambahItem(id, nama, harga, stokMax) {
    const index = keranjang.findIndex(item => item.id === id);

    if (index !== -1) {
        if (keranjang[index].qty < stokMax) {
            keranjang[index].qty++;
        } else {
            alert('Stok menu mencapai batas maksimum (' + stokMax + ')!');
        }
    } else {
        keranjang.push({
            id,
            nama,
            hargaAsli: Number(harga),
            extraHarga: 0,
            qty: 1,
            stokMax,
            catatan: ''
        });
    }

    renderKeranjang();
}

function hapusItem(index) {
    keranjang.splice(index, 1);
    renderKeranjang();
}

function ubahQtyIndex(index, jumlah) {
    const item = keranjang[index];
    const qtyBaru = item.qty + jumlah;

    if (qtyBaru <= 0) {
        hapusItem(index);
        return;
    }

    if (qtyBaru > item.stokMax) {
        alert('Stok tidak mencukupi! Maksimal stok: ' + item.stokMax);
        return;
    }

    item.qty = qtyBaru;
    renderKeranjang();
}

function updateCatatan(index, nilai) {
    if (keranjang[index]) keranjang[index].catatan = nilai;
}

function updateExtraHarga(index, nilai) {
    if (!keranjang[index]) return;

    let extra = parseFloat(nilai) || 0;

    if (extra < 0) extra = 0;

    keranjang[index].extraHarga = extra;
    renderKeranjang(true);
}

function renderKeranjang(jagaFokus) {
    let fokusInfo = null;
    const aktif = document.activeElement;

    if (jagaFokus && aktif && aktif.name === 'extra_harga[]') {
        const all = Array.from(document.getElementsByName('extra_harga[]'));
        fokusInfo = {
            idx: all.indexOf(aktif),
            pos: aktif.selectionStart
        };
    }

    const container = document.getElementById('containerKeranjangList');
    const emptyRow = document.getElementById('emptyRow');

    container.innerHTML = '';

    let subtotalKotor = 0;
    let totalQtyItem = 0;

    if (keranjang.length === 0) {
        emptyRow.style.display = 'block';
    } else {
        emptyRow.style.display = 'none';

        keranjang.forEach((item, index) => {
            const subtotalItem =
                (item.hargaAsli * item.qty) + item.extraHarga;

            subtotalKotor += subtotalItem;
            totalQtyItem += item.qty;

            const extraValue =
                item.extraHarga > 0 ? item.extraHarga : '';

            const extraDisplayClass =
                item.extraHarga > 0 ? '' : 'd-none';

            container.innerHTML += `
                <div class="p-3 mb-2 rounded-3 border bg-light shadow-sm">

                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div>
                            <span class="fw-bold text-dark d-block">
                                ${escapeHtml(item.nama)}
                            </span>

                            <small class="text-muted">
                                Base: Rp ${item.hargaAsli.toLocaleString('id-ID')} / pcs
                            </small>
                        </div>

                        <button type="button"
                                class="btn btn-sm text-danger p-0 border-0 shadow-none"
                                onclick="hapusItem(${index})"
                                title="Hapus">
                            <i class="bi bi-x-circle-fill fs-5"></i>
                        </button>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-2">

                        <div class="qty-btn-group">
                            <button type="button"
                                    class="qty-btn"
                                    onclick="ubahQtyIndex(${index}, -1)"
                                    title="Kurangi">
                                <i class="bi bi-dash"></i>
                            </button>

                            <span class="qty-value">${item.qty}</span>

                            <button type="button"
                                    class="qty-btn"
                                    onclick="ubahQtyIndex(${index}, 1)"
                                    title="Tambah">
                                <i class="bi bi-plus"></i>
                            </button>
                        </div>

                        <span class="fw-bold text-success subtotal-item">
                            Rp ${subtotalItem.toLocaleString('id-ID')}
                        </span>
                    </div>

                    <div class="row g-1">

                        <div class="col-7">
                            <input type="text"
                                   name="catatan[]"
                                   class="form-control form-control-sm bg-white"
                                   placeholder="Catatan..."
                                   value="${escapeHtml(item.catatan)}"
                                   oninput="updateCatatan(${index}, this.value)">
                        </div>

                        <div class="col-5">
                            <input type="number"
                                   name="extra_harga[]"
                                   class="form-control form-control-sm bg-white"
                                   placeholder="+ Ekstra (Rp)"
                                   value="${extraValue}"
                                   min="0"
                                   step="1"
                                   oninput="updateExtraHarga(${index}, this.value)">
                        </div>

                    </div>

                    <div class="extra-display mt-2 small text-muted ${extraDisplayClass}">
                        + Extra Rp ${item.extraHarga.toLocaleString('id-ID')}
                    </div>

                    <input type="hidden" name="produk_id[]" value="${item.id}">
                    <input type="hidden" name="qty[]" value="${item.qty}">

                </div>`;
        });
    }

    document.getElementById('btnSubmit').disabled =
        keranjang.length === 0;

    if (fokusInfo && fokusInfo.idx >= 0) {
        const el =
            document.getElementsByName('extra_harga[]')[fokusInfo.idx];

        if (el) {
            el.focus();

            try {
                el.setSelectionRange(
                    fokusInfo.pos,
                    fokusInfo.pos
                );
            } catch (e) {}
        }
    }

    const memberOk = isMemberValid();
    const eligible =
        memberOk && subtotalKotor >= MIN_BELANJA_DISKON;

    if (eligible && !popupDiskonSudahTampil) {
        popupDiskonSudahTampil = true;

        bootstrap.Modal
            .getOrCreateInstance(
                document.getElementById('modalPromoMember')
            )
            .show();
    }

    if (!eligible) {
        popupDiskonSudahTampil = false;
        diskonMemberDitolak = false;
    }

    const diskonAktif =
        eligible && !diskonMemberDitolak;

    const hint =
        document.getElementById('hintDiskonMember');

    if (memberOk) {
        hint.classList.remove('d-none');

        if (eligible && diskonAktif) {
            hint.innerHTML =
                `<i class="bi bi-check-circle-fill me-1"></i>
                 Diskon member ${DISKON_MEMBER_PERSEN}% aktif!`;

        } else if (eligible) {
            hint.innerHTML =
                `<i class="bi bi-info-circle-fill me-1"></i>
                 Diskon member tidak diambil.
                 <a href="#" class="text-decoration-none fw-bold"
                    onclick="putuskanDiskon(true);return false;">
                    Ambil lagi
                 </a>`;

        } else {
            const sisa =
                MIN_BELANJA_DISKON - subtotalKotor;

            const persen =
                Math.min(
                    100,
                    Math.max(
                        0,
                        (subtotalKotor / MIN_BELANJA_DISKON) * 100
                    )
                );

            hint.innerHTML =
                `<i class="bi bi-gift-fill me-1"></i>
                 Belanja ${rupiah(sisa)} lagi untuk diskon ${DISKON_MEMBER_PERSEN}%
                 <div class="progress-diskon">
                    <div style="width:${persen}%"></div>
                 </div>`;
        }
    } else {
        hint.classList.add('d-none');
    }

    let totalDiskonNominal = 0;
    const rincian = [];

    if (diskonAktif) {
        const d =
            subtotalKotor * DISKON_MEMBER_PERSEN / 100;

        totalDiskonNominal += d;

        rincian.push(
            `Diskon Member ${DISKON_MEMBER_PERSEN}%: -${rupiah(d)}`
        );
    }

    if (
        memberOk &&
        jenisPromoKode === 'diskon' &&
        subtotalKotor > 0
    ) {
        const d =
            Math.min(
                POTONGAN_PROMO,
                subtotalKotor - totalDiskonNominal
            );

        totalDiskonNominal += d;

        rincian.push(
            `Diskon Kode Promo: -${rupiah(d)}`
        );
    }

    if (
        memberOk &&
        jenisPromoKode === 'bonus'
    ) {
        rincian.push(
            '🎁 Bonus produk gratis dari kode promo'
        );
    }

    globalTotalHarga =
        Math.max(
            0,
            Math.round(
                subtotalKotor - totalDiskonNominal
            )
        );

    const rincianBox =
        document.getElementById('rincianDiskonBox');

    rincianBox.classList.toggle(
        'd-none',
        rincian.length === 0
    );

    rincianBox.innerHTML =
        rincian.join('<br>');

    document.getElementById('textTotal').innerText =
        rupiah(globalTotalHarga);

    document.getElementById('inputTotal').value =
        globalTotalHarga;

    document.getElementById('inputDiskonNominal').value =
        Math.round(totalDiskonNominal);

    document.getElementById('inputAmbilDiskon').value =
        diskonAktif ? 1 : 0;

    document.getElementById('badgeTotalItem').innerText =
        totalQtyItem + ' Item';

    hitungKembalian();
}

function setTipePesanan(tipe) {
    document.getElementById('inputTipePesanan').value = tipe;

    document.getElementById('btnDineIn')
        .classList.toggle(
            'active',
            tipe === 'Dine-In'
        );

    document.getElementById('btnTakeAway')
        .classList.toggle(
            'active',
            tipe === 'Take-Away'
        );
}

function buatQrPalsu(seed) {
    const n = 25;
    const sz = 8;

    let x =
        (seed * 9301 + 49297) % 233280 || 1;

    const rnd = () => {
        x =
            (x * 9301 + 49297) % 233280;

        return x / 233280;
    };

    const finder = (r, c) =>
        (r < 7 && c < 7) ||
        (r < 7 && c >= n - 7) ||
        (r >= n - 7 && c < 7);

    const finderOn = (r, c) => {
        const rr =
            r >= n - 7
                ? r - (n - 7)
                : r;

        const cc =
            c >= n - 7
                ? c - (n - 7)
                : c;

        const edge =
            rr === 0 ||
            rr === 6 ||
            cc === 0 ||
            cc === 6;

        const core =
            rr >= 2 &&
            rr <= 4 &&
            cc >= 2 &&
            cc <= 4;

        return edge || core;
    };

    let rects = '';

    for (let r = 0; r < n; r++) {
        for (let c = 0; c < n; c++) {

            const on =
                finder(r, c)
                    ? finderOn(r, c)
                    : rnd() > 0.52;

            if (on) {
                rects +=
                    `<rect x="${c * sz}"
                           y="${r * sz}"
                           width="${sz}"
                           height="${sz}"/>`;
            }
        }
    }

    return `
        <svg viewBox="0 0 ${n * sz} ${n * sz}"
             width="100%"
             fill="#141211"
             shape-rendering="crispEdges">
            ${rects}
        </svg>`;
}

function setMetodeBayar(metode) {
    const input =
        document.getElementById('inputUangBayar');

    const digital =
        metode !== 'tunai';

    if (
        digital &&
        keranjang.length === 0
    ) {
        alert(
            'Pilih menu terlebih dahulu sebelum memilih pembayaran non-tunai!'
        );
        return;
    }

    metodeBayar = metode;

    document.getElementById('inputMetodeBayar').value =
        metode;

    ['Tunai', 'Qris', 'Transfer'].forEach(n => {
        document.getElementById('btn' + n)
            .classList.toggle(
                'active',
                n.toLowerCase() === metode
            );
    });

    document.getElementById('infoNonTunai')
        .classList.toggle(
            'd-none',
            !digital
        );

    document.getElementById('quickCash')
        .classList.toggle(
            'd-none',
            digital
        );

    input.readOnly = digital;

    digitalTerkonfirmasiTotal = null;

    if (!digital) {
        input.value = '';
        hitungKembalian();
        return;
    }

    input.value = '';
    hitungKembalian();
    bukaModalDigital();
}

function bukaModalDigital() {
    const isQris =
        metodeBayar === 'qris';

    document.getElementById('judulDigital').innerText =
        isQris
            ? 'Pembayaran QRIS'
            : 'Pembayaran Transfer Bank';

    document.getElementById('ikonDigital').className =
        'bi ' +
        (isQris
            ? 'bi-qr-code-scan'
            : 'bi-bank');

    document.getElementById('nominalDigital').innerText =
        rupiah(globalTotalHarga);

    document.getElementById('areaQr')
        .classList.toggle(
            'd-none',
            !isQris
        );

    document.getElementById('areaTransfer')
        .classList.toggle(
            'd-none',
            isQris
        );

    if (isQris) {
        document.getElementById('areaQr').innerHTML =
            buatQrPalsu(
                Math.round(globalTotalHarga) + 7
            );
    }

    document.getElementById('pesanDigital').innerText =
        isQris
            ? 'Silakan scan QRIS berikut. (Simulasi: Pastikan saldo masuk sebelum klik Proses)'
            : 'Silakan transfer sesuai nominal ke rekening di atas. (Simulasi: Pastikan saldo masuk sebelum klik Proses)';

    bootstrap.Modal
        .getOrCreateInstance(
            document.getElementById('modalPembayaranDigital')
        )
        .show();
}

function konfirmasiDigital() {
    digitalTerkonfirmasiTotal =
        globalTotalHarga;

    hitungKembalian();

    bootstrap.Modal
        .getOrCreateInstance(
            document.getElementById('modalPembayaranDigital')
        )
        .hide();
}

function batalDigital() {
    bootstrap.Modal
        .getOrCreateInstance(
            document.getElementById('modalPembayaranDigital')
        )
        .hide();

    if (digitalTerkonfirmasiTotal === null) {
        setMetodeBayar('tunai');
    }
}

function isiUang(nominal) {
    document.getElementById('inputUangBayar').value =
        nominal === 'pas'
            ? globalTotalHarga
            : nominal;

    hitungKembalian();
}

function hitungKembalian() {
    const input =
        document.getElementById('inputUangBayar');

    const digital =
        metodeBayar !== 'tunai';

    const el =
        document.getElementById('textKembalian');

    if (digital) {

        if (
            digitalTerkonfirmasiTotal !== null &&
            digitalTerkonfirmasiTotal !== globalTotalHarga
        ) {
            digitalTerkonfirmasiTotal = null;
        }

        const ok =
            digitalTerkonfirmasiTotal !== null;

        input.value =
            ok
                ? globalTotalHarga
                : '';

        const st =
            document.getElementById('statusDigital');

        if (st) {
            st.innerHTML = ok
                ? `<i class="bi bi-check-circle-fill me-1"></i>
                   Pembayaran ${metodeBayar === 'qris' ? 'QRIS' : 'Transfer'}
                   dikonfirmasi:
                   <strong>${rupiah(globalTotalHarga)}</strong>`
                : `<i class="bi bi-hourglass-split me-1"></i>
                   Menunggu konfirmasi pembayaran
                   ${metodeBayar === 'qris' ? 'QRIS' : 'Transfer'}...`;
        }

        el.innerText =
            ok
                ? 'Rp 0 (Pas)'
                : 'Rp 0';

        el.className =
            ok
                ? 'fw-bold fs-6 text-warning'
                : 'fw-bold fs-6 text-white';

        return;
    }

    const uangBayar =
        parseFloat(input.value) || 0;

    const kembalian =
        uangBayar - globalTotalHarga;

    if (uangBayar === 0) {

        el.innerText = 'Rp 0';
        el.className =
            'fw-bold fs-6 text-white';

    } else if (kembalian < 0) {

        el.innerText =
            'Kurang ' +
            rupiah(Math.abs(kembalian));

        el.className =
            'fw-bold fs-6 text-danger';

    } else {

        el.innerText =
            rupiah(kembalian);

        el.className =
            'fw-bold fs-6 text-warning';
    }
}

function validasiBayar() {

    if (
        document.getElementById('tipePelangganInput').value === 'member'
    ) {
        if (
            !document.getElementById('hiddenPelangganID').value
        ) {
            alert(
                'Silakan masukkan ID Member yang valid!'
            );
            return false;
        }

    } else if (
        !document.getElementById('inputNamaBaru').value.trim()
    ) {
        alert(
            'Silakan masukkan Nama Pelanggan!'
        );
        return false;
    }

    if (keranjang.length === 0) {
        alert(
            'Belum ada produk yang dipilih!'
        );
        return false;
    }

    if (
        jenisPromoKode === 'bonus' &&
        !document.getElementById('selectProdukBonus').value
    ) {
        alert(
            'Pilih produk bonus terlebih dahulu!'
        );
        return false;
    }

    if (metodeBayar === 'tunai') {

        const uangBayar =
            parseFloat(
                document.getElementById('inputUangBayar').value
            ) || 0;

        if (uangBayar < globalTotalHarga) {
            alert(
                'Nominal uang pembayaran kurang dari total tagihan!'
            );
            return false;
        }

    } else if (
        digitalTerkonfirmasiTotal !== globalTotalHarga
    ) {
        bukaModalDigital();
        return false;
    }

    if (!konfirmasiTransaksi) {

        bootstrap.Modal
            .getOrCreateInstance(
                document.getElementById('modalKonfirmasiTransaksi')
            )
            .show();

        return false;
    }

    return true;
}

document
    .getElementById('btnKonfirmasiSimpan')
    .addEventListener('click', function () {

        const form =
            document.getElementById('formPenjualan');

        const tombolSubmit =
            document.getElementById('btnSubmit');

        konfirmasiTransaksi = true;

        bootstrap.Modal
            .getOrCreateInstance(
                document.getElementById('modalKonfirmasiTransaksi')
            )
            .hide();

        if (form.requestSubmit) {
            form.requestSubmit(tombolSubmit);
        } else {
            tombolSubmit.click();
        }
    });

renderKeranjang();
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<?php if (!empty($transaksiBerhasil) && !empty($transaksiBerhasil['id'])): ?>

<script>
document.addEventListener('DOMContentLoaded', function () {

    <?php if ($is_pelanggan): ?>

        const modalPesanan =
            document.getElementById('modalPesananBerhasil');

        if (modalPesanan) {
            bootstrap.Modal
                .getOrCreateInstance(modalPesanan)
                .show();
        }

    <?php else: ?>

        const modalBerhasil =
            document.getElementById('modalTransaksiBerhasil');

        if (modalBerhasil) {
            bootstrap.Modal
                .getOrCreateInstance(modalBerhasil)
                .show();
        }

    <?php endif; ?>

});
</script>

<?php endif; ?>

</body>
</html>