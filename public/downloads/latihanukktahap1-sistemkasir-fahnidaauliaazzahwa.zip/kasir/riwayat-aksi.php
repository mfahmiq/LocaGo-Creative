<?php
session_start();
include '../koneksi.php';

// Validasi login
if (!isset($_SESSION['Role'])) {
    header("Location: ../login.php");
    exit;
}

$id   = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$aksi = isset($_GET['aksi']) ? strtolower(trim($_GET['aksi'])) : '';

if ($id <= 0 || empty($aksi)) {
    echo "<script>alert('Aksi atau ID transaksi tidak valid!'); window.location='riwayat-transaksi.php';</script>";
    exit;
}

$q_cek = mysqli_query($koneksi, "SELECT status FROM penjualan WHERE PenjualanID = $id");
if (!$q_cek || mysqli_num_rows($q_cek) == 0) {
    echo "<script>alert('Transaksi tidak ditemukan!'); window.location='riwayat_transaksi.php';</script>";
    exit;
}
$data_trx = mysqli_fetch_assoc($q_cek);
$status_lama = strtolower(trim($data_trx['status'] ?? 'proses'));

if ($aksi === 'proses') {
    $statusBaru = 'proses';
} elseif ($aksi === 'selesai') {
    $statusBaru = 'selesai';
} elseif ($aksi === 'batal') {
    $statusBaru = 'batal';
    
    // Kembalikan stok produk jika dibatalkan
    if ($status_lama !== 'batal' && $status_lama !== 'dibatalkan') {
        $q_detail = mysqli_query($koneksi, "SELECT ProdukID, JumlahPelanggan FROM detailpenjualan WHERE PenjualanID = $id");
        if ($q_detail) {
            while ($item = mysqli_fetch_assoc($q_detail)) {
                $produk_id = (int)$item['ProdukID'];
                $jumlah    = (int)$item['JumlahPelanggan'];
                
                mysqli_query($koneksi, "UPDATE produk SET Stok = Stok + $jumlah WHERE ProdukID = $produk_id");
            }
        }
    }
} else {
    echo "<script>alert('Aksi tidak dikenali!'); window.location='riwayat-transaksi.php';</script>";
    exit;
}

$update = mysqli_query($koneksi, "UPDATE penjualan SET status = '$statusBaru' WHERE PenjualanID = $id");

if ($update) {
    echo "<script>window.location='riwayat-transaksi.php';</script>";
} else {
    echo "<script>alert('Gagal memperbarui status transaksi: " . addslashes(mysqli_error($koneksi)) . "'); window.location='riwayat-transaksi.php';</script>";
}
exit;
?>