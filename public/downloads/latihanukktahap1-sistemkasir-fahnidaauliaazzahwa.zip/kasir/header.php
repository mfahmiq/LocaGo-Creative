<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include '../koneksi.php'; 

// Proteksi Akses
if (!isset($_SESSION['login'])) {
    header("Location: ../index.php?pesan=belum_login");
    exit;
}

$user_nama =$_SESSION['NamaUser'] ?? 'User';
$user_role =$_SESSION['Role'] ?? 'kasir'; // Bisa bernilai: admin, kasir, atau pelanggan
$current_page = basename($_SERVER['PHP_SELF']);
$request_uri =$_SERVER['PHP_SELF'];

// CEK POSISI FOLDER HALAMAN YANG SEDANG DIAKSES
$is_admin = (strpos($request_uri, '/admin/') !== false);
$is_pelanggan = (strpos($request_uri, '/pelanggan/') !== false);

// Tentukan prefix folder untuk link navigasi standar agar mengarah ke folder kasir / root yang benar
if ($is_admin || $is_pelanggan) {$p = '../kasir/';
} else {
    $p = '';
}

// --- DINAMIS ROUTING HALAMAN PESAN / TRANSAKSI ---
// Jika role pelanggan, arahkan ke pesan-mandiri.php. Jika admin/kasir, ke penjualan.php
if ($user_role === 'pelanggan') {
    $url_transaksi =$is_pelanggan ? 'pesan-mandiri.php' : '../pelanggan/pesan-mandiri.php';
} else {
    $url_transaksi = 'penjualan.php';
}

// URL Riwayat Pesanan disamakan agar selalu merujuk ke folder kasir tempat riwayat-transaksi.php berada
$url_riwayat = $is_pelanggan ? '../kasir/riwayat-transaksi.php' : $p . 'riwayat-transaksi.php';

$label_transaksi = ($user_role === 'pelanggan') ? 'Pesan Menu' : 'Transaksi Kasir';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS System - Daily Coffee & Toast</title>
    
    <!-- Bootstrap CSS & Icons -->
    <link href="<?= $p; ?>../asset/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <!-- SweetAlert2 CSS / JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        :root {
            --c-primary: #181614;
            --c-accent: #C29B38;  /* Soft champagne gold / muted amber */
            --c-accent-hover: #D4AF37;
            --c-light-bg: #F5F3EF;  /* Warm soft off-white background */
            --sidebar-width: 270px;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--c-light-bg);
            color: var(--c-primary);
            min-height: 100vh;
            margin: 0;
        }

        /* Top Bar Ringkas dengan Layout Grid */
        .top-navbar {
            background: linear-gradient(180deg, #141210 0%, #1D1A17 100%);
            border-bottom: 1px solid rgba(194, 155, 56, 0.25);
            padding: 0.75rem 2rem;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1030;
            height: 75px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.35);
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            align-items: center;
        }

        /* Desain Brand Badge Sejajar Menyamping & Elegan */
        .brand-badge-horizontal {
            background: linear-gradient(135deg, rgba(28, 25, 23, 0.95) 0%, rgba(18, 16, 15, 0.98) 100%);
            border: 1px solid rgba(194, 155, 56, 0.35);
            border-radius: 50rem;
            padding: 0.45rem 1.6rem;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2), inset 0 0 8px rgba(194, 155, 56, 0.05);
            transition: all 0.3s ease;
            text-decoration: none !important;
        }

        .brand-badge-horizontal:hover {
            border-color: rgba(194, 155, 56, 0.7);
            box-shadow: 0 4px 20px rgba(194, 155, 56, 0.15), inset 0 0 12px rgba(194, 155, 56, 0.1);
            transform: translateY(-1px);
        }

        .brand-icon-circle {
            width: 36px;
            height: 36px;
            background: linear-gradient(135deg, #C29B38 0%, #9E7A25 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #181614;
            font-size: 1.1rem;
            box-shadow: 0 2px 8px rgba(194, 155, 56, 0.25);
        }

        .brand-text-inline {
            display: flex;
            align-items: center;
            gap: 8px;
            white-space: nowrap;
        }

        .brand-name {
            font-size: 0.9rem;
            font-weight: 800;
            letter-spacing: 0.8px;
            color: #EFECE6;
        }

        .brand-separator {
            color: var(--c-accent);
            font-weight: 800;
            font-size: 1rem;
        }

        .user-pill {
            background: rgba(255, 255, 255, 0.04);
            border: 1px solid rgba(194, 155, 56, 0.2);
            border-radius: 50px;
            padding: 0.4rem 1.1rem;
            backdrop-filter: blur(5px);
        }

        /* Tombol Logout Gaya Pill Kustom */
        .btn-logout-pill {
            background: transparent;
            border: 1px solid rgba(217, 83, 79, 0.6);
            color: #E06C75;
            border-radius: 50rem;
            padding: 0.4rem 1.25rem;
            font-size: 0.85rem;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease-in-out;
            text-decoration: none;
            cursor: pointer;
        }

        .btn-logout-pill:hover {
            background: rgba(217, 83, 79, 0.15);
            border-color: #E06C75;
            color: #FF7B85;
            box-shadow: 0 4px 12px rgba(217, 83, 79, 0.2);
            transform: translateY(-1px);
        }

        /* Sidebar Aesthetic & Dynamic Background Kafe */
        .sidebar-menu {
            width: var(--sidebar-width);
            position: fixed;
            top: 75px;
            left: 0;
            bottom: 0;
            padding: 1.8rem 1.2rem;
            z-index: 1020;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            border-right: 1px solid rgba(194, 155, 56, 0.15);
            background: 
                linear-gradient(180deg, rgba(20, 18, 17, 0.94) 0%, rgba(26, 23, 21, 0.92) 50%, rgba(15, 14, 13, 0.97) 100%),
                url('https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=800&q=80') center/cover no-repeat;
            backdrop-filter: blur(8px);
            box-shadow: 5px 0 25px rgba(0, 0, 0, 0.25);
        }

        .sidebar-section-title {
            font-size: 0.68rem;
            letter-spacing: 1.5px;
            color: var(--c-accent);
            font-weight: 800;
            text-transform: uppercase;
            padding: 0 0.8rem;
            margin-bottom: 0.8rem;
            display: block;
            opacity: 0.85;
        }

        /* --- STYLING MENU UTAMA SIDEBAR (PILL DENGAN BORDER EMAS SAAT AKTIF) --- */
        .nav-link-side {
            color: #C8C3BC;
            font-weight: 600;
            font-size: 0.88rem;
            padding: 0.85rem 1.1rem;
            border-radius: 50rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            margin-bottom: 0.4rem;
            border: 1px solid transparent;
        }

        .nav-link-side:hover {
            color: #FFFFFF;
            background: rgba(255, 255, 255, 0.04);
            border-color: rgba(194, 155, 56, 0.25);
            transform: translateX(4px);
        }

        .nav-link-side.active {
            color: #FFFFFF;
            background: rgba(28, 25, 23, 0.85);
            border: 1px solid var(--c-accent);
            box-shadow: 0 0 15px rgba(194, 155, 56, 0.2);
            font-weight: 700;
        }

        .nav-link-side.active i {
            color: var(--c-accent) !important;
        }

        .status-widget {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(194, 155, 56, 0.18);
            border-radius: 14px;
            padding: 1rem;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
        }

        .app-container {
            margin-top: 75px;
            margin-left: var(--sidebar-width);
            padding: 2.5rem 3rem;
            min-height: calc(100vh - 75px);
        }

        .swal-custom-popup {
            border-radius: 28px !important;
            padding: 2rem 1.5rem !important;
            background: #FFFFFF !important;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25) !important;
            font-family: 'Plus Jakarta Sans', sans-serif !important;
        }

        .swal-custom-title {
            font-size: 1.35rem !important;
            font-weight: 800 !important;
            color: #111827 !important;
            margin-top: 10px !important;
        }

        .swal-custom-icon.swal2-icon.swal2-question {
            border-color: #F3E5AB !important;
            color: #D97706 !important;
            background: #FFFBEB !important;
            width: 75px !important;
            height: 75px !important;
            margin: 10px auto 15px auto !important;
            box-shadow: 0 10px 25px rgba(245, 158, 11, 0.15) !important;
        }

        .swal-custom-icon.swal2-icon.swal2-question .swal2-icon-content {
            font-size: 2.2rem !important;
            font-weight: 700 !important;
        }

        .swal-custom-popup .btn-danger-custom {
            background-color: #DC2626 !important;
            border-color: #DC2626 !important;
            color: #FFFFFF !important;
            transition: all 0.2s ease;
        }

        .swal-custom-popup .btn-danger-custom:hover {
            background-color: #B91C1C !important;
            border-color: #B91C1C !important;
            transform: translateY(-1px);
        }

        .swal-custom-popup .btn-outline-secondary {
            color: #4B5563 !important;
            border-color: #D1D5DB !important;
            background-color: transparent !important;
            transition: all 0.2s ease;
        }

        .swal-custom-popup .btn-outline-secondary:hover {
            background-color: #F3F4F6 !important;
            color: #1F2937 !important;
            border-color: #9CA3AF !important;
        }
    </style>
</head>
<body>

<!-- Header Top Navigation -->
<nav class="top-navbar">
    <div class="d-flex align-items-center gap-2 text-muted small">
        <span class="badge fw-bold px-2.5 py-1" style="background-color: rgba(194, 155, 56, 0.15) !important; color: var(--c-accent) !important; border: 1px solid rgba(194, 155, 56, 0.3); font-size: 0.68rem; letter-spacing: 0.5px;">
            POS SYSTEM
        </span>
        <span class="text-light opacity-50 d-none d-md-inline" style="font-size: 0.75rem;">&bull; Point of Sales</span>
    </div>

    <div class="mx-auto">
        <a href="<?= $p; ?>dashboard.php" class="brand-badge-horizontal">
            <div class="brand-icon-circle">
                <i class="bi bi-cup-hot-fill"></i>
            </div>
            <div class="brand-text-inline">
                <span class="brand-name">DAILY COFFEE</span>
                <span class="brand-separator">&bull;</span>
                <span class="brand-name">DAILY TOAST</span>
            </div>
        </a>
    </div>

    <div class="d-flex align-items-center justify-content-end gap-3">
        <div class="user-pill d-flex align-items-center gap-2 text-white">
            <i class="bi bi-person-circle fs-5" style="color: var(--c-accent);"></i>
            <div style="line-height: 1.1;">
                <div class="fw-bold" style="font-size: 0.85rem;"><?= htmlspecialchars($user_nama); ?></div>
                <small class="text-uppercase" style="font-size: 0.65rem; color: var(--c-accent); font-weight: 800; letter-spacing: 0.5px;"><?= htmlspecialchars($user_role); ?></small>
            </div>
        </div>
        
        <a id="btnLogout" href="<?= $p; ?>../logout.php" class="btn-logout-pill" title="Keluar Sistem">
            <i class="bi bi-box-arrow-right fs-6"></i>
            <span>Logout</span>
        </a>
    </div>
</nav>

<!-- Sidebar Navigasi -->
<aside class="sidebar-menu">
    <div>
        <span class="sidebar-section-title">Menu Utama</span>
        
        <!-- Dashboard -->
        <a class="nav-link-side <?= ($current_page == 'dashboard.php') ? 'active' : ''; ?>" href="<?= $p; ?>dashboard.php">
            <i class="bi bi-house-door me-1 fs-5"></i>
            <span>Dashboard</span>
        </a>

        <!-- Transaksi Kasir / Pesan Menu (Dinamis Berdasarkan Role) -->
        <a class="nav-link-side <?= ($current_page == 'penjualan.php' || $current_page == 'pesan-mandiri.php') ? 'active' : ''; ?>" href="<?= $p; ?><?=$url_transaksi; ?>">
            <i class="bi bi-receipt-cutoff fs-5"></i>
            <span><?= htmlspecialchars($label_transaksi); ?></span>
        </a>

        <!-- Menu & Stok / Katalog Produk -->
        <a class="nav-link-side <?= ($current_page == 'produk.php' || $current_page == 'produk-edit.php') ? 'active' : ''; ?>" href="<?= $p; ?>produk.php">
            <i class="bi bi-cup-straw fs-5"></i>
            <span><?= ($user_role === 'pelanggan') ? 'Katalog Produk' : 'Menu & Stok'; ?></span>
        </a>

        <!-- Menu Pelanggan (Hanya muncul untuk Admin & Kasir) -->
        <?php if ($user_role !== 'pelanggan'): ?>
        <a class="nav-link-side <?= ($current_page == 'pelanggan.php') ? 'active' : ''; ?>" href="<?= $p; ?>pelanggan.php">
            <i class="bi bi-people-fill fs-5"></i>
            <span>Pelanggan</span>
        </a>
        <?php endif; ?>

        <!-- Riwayat Pesanan -->
        <a class="nav-link-side <?= ($current_page == 'riwayat-transaksi.php') ? 'active' : ''; ?>" href="<?= $url_riwayat; ?>">
            <i class="bi bi-clock-history fs-5"></i>
            <span>Riwayat Pesanan</span>
        </a>

        <!-- Akses Administrator -->
        <?php if ($user_role === 'admin'): ?>
        <hr style="border-color: rgba(194, 155, 56, 0.15); margin: 1.2rem 0;">
        <span class="sidebar-section-title" style="color: var(--c-accent);">Akses Administrator</span>
        <a class="nav-link-side <?= ($current_page == 'laporan.php') ? 'active' : ''; ?>" href="../admin/laporan.php">
            <i class="bi bi-shield-lock-fill fs-5" style="color: var(--c-accent);"></i>
            <span>Laporan Admin</span>
        </a>
        <?php endif; ?>
    </div>

    <!-- Widget Info Status POS -->
    <div class="status-widget">
        <div class="d-flex align-items-center justify-content-center gap-2 mb-1">
            <span class="spinner-grow spinner-grow-sm" role="status" style="width: 7px; height: 7px; background-color: var(--c-accent);"></span>
            <small class="text-white fw-bold" style="font-size: 0.78rem; letter-spacing: 0.5px;">POS Active</small>
        </div>
        <small class="text-muted d-block" style="font-size: 0.7rem; color: #A8A29E !important;"><?= date('d M Y'); ?> &bull; Shift On</small>
    </div>
</aside>

<!-- Script SweetAlert2 Event Listener Logout -->
<script>
document.addEventListener("DOMContentLoaded", function () {
    const btnLogout = document.getElementById('btnLogout');

    if (btnLogout) {
        btnLogout.addEventListener('click', function (e) {
            e.preventDefault();
            const logoutUrl = this.getAttribute('href');

            Swal.fire({
                title: 'Keluar dari Sistem?',
                html: `
                    <div style="font-size: 0.92rem; color: #4B5563; line-height: 1.6; margin-top: 5px;">
                        Apakah kamu yakin ingin mengakhiri sesi dan keluar dari <strong style="color: #1F2937;">Daily Coffee Daily Toast</strong>?
                    </div>
                `,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Ya, Logout',
                cancelButtonText: 'Nanti Saja',
                reverseButtons: true,
                focusCancel: true,
                buttonsStyling: false,
                customClass: {
                    popup: 'swal-custom-popup',
                    icon: 'swal-custom-icon',
                    title: 'swal-custom-title',
                    confirmButton: 'btn btn-danger-custom rounded-pill px-5 py-2.5 fw-bold shadow-sm mx-1',
                    cancelButton: 'btn btn-outline-secondary rounded-pill px-5 py-2.5 fw-bold mx-1'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        title: 'Sedang Keluar...',
                        html: '<span style="font-size:0.85rem; color:#6B7280;">Membersihkan sesi dan mencatat log aktivitas.</span>',
                        allowOutsideClick: false,
                        showConfirmButton: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });

                    setTimeout(function () {
                        window.location.href = logoutUrl;
                    }, 600);
                }
            });
        });
    }
});
</script>
</body>
</html>