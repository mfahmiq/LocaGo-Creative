<?php
date_default_timezone_set('Asia/Jakarta');
session_start();
include '../koneksi.php';

// Cek apakah user sudah login
if (!isset($_SESSION['login'])) {
    header("Location: ../index.php?pesan=gagal");
    exit;
}

// Cek apakah ada parameter filter cepat "hari_ini"
if (isset($_GET['filter']) &&$_GET['filter'] == 'hari_ini') {
    $tanggal_mulai = date('Y-m-d');$tanggal_selesai = date('Y-m-d');
} else {
    // Ambil nilai filter dari URL (jika ada)
    $tanggal_mulai = isset($_GET['tanggal_mulai']) ? $_GET['tanggal_mulai'] : '';$tanggal_selesai = isset($_GET['tanggal_selesai']) ?$_GET['tanggal_selesai'] : '';
}

// Buat query dasar dengan COALESCE untuk menangani pelanggan member maupun non-member/umum
$query_sql = "SELECT p.*, COALESCE(pel.NamaPelanggan, p.NamaPelanggan, 'Pelanggan Umum') AS NamaPelanggan 
              FROM penjualan p 
              LEFT JOIN pelanggan pel ON p.PelangganID = pel.PelangganID";

// Jika user mengisi filter tanggal, tambahkan kondisi WHERE
if (!empty($tanggal_mulai) && !empty($tanggal_selesai)) {$query_sql .= " WHERE p.TanggalPenjualan BETWEEN '$tanggal_mulai 00:00:00' AND '$tanggal_selesai 23:59:59'";
} elseif (!empty($tanggal_mulai)) {$query_sql .= " WHERE p.TanggalPenjualan >= '$tanggal_mulai 00:00:00'";
} elseif (!empty($tanggal_selesai)) {$query_sql .= " WHERE p.TanggalPenjualan <= '$tanggal_selesai 23:59:59'";
}

// Urutkan dari yang terbaru
$query_sql .= " ORDER BY p.PenjualanID DESC";

$q_semua_transaksi = mysqli_query($koneksi,$query_sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Transaksi - Daily Coffee & Toast</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body { background-color: #FAF8F5; font-family: 'Plus Jakarta Sans', sans-serif; }
        .app-container { margin-top: 105px; margin-left: 290px; padding: 0 35px 50px 0; }
        
        /* Banner Header Styling dengan padding yang lebih kecil/ringkas */
        .page-header-banner {
            background: #FFFFFF;
            border-radius: 16px;
            padding: 1.25rem 1.75rem;
            border: 1px solid rgba(231, 229, 228, 0.9);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.03);
        }

        @media (max-width: 992px) { 
            .app-container { margin-left: 20px; margin-right: 20px; padding-right: 0; } 
        }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="app-container">
    <!-- Header Halaman / Banner yang Dikecilkan -->
    <div class="page-header-banner mb-4">
        <div class="row align-items-center justify-content-between">
            <div class="col-lg-8">
                <span class="badge px-2.5 py-1.5 rounded-pill mb-1 fw-bold" style="background: rgba(196, 154, 69, 0.15); color: #C49A45; border: 1px solid rgba(196, 154, 69, 0.3); font-size: 0.75rem;">
                    <i class="bi bi-shop me-1"></i> HISTORY SYSTEM ACTIVE
                </span>
                <h3 class="fw-extrabold mb-1" style="color: var(--c-primary); font-size: 1.5rem;">
                    Riwayat Seluruh Transaksi
                </h3>
                <p class="text-muted mb-0" style="font-size: 0.875rem;">
                    Daftar lengkap seluruh transaksi dan struk yang pernah tercatat di sistem Daily Coffee &amp; Toast.
                </p>
            </div>
            <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
                <div class="d-inline-block text-start px-3 py-2 rounded-3 bg-light border" style="border-color: rgba(231, 229, 228, 0.8) !important;">
                    <div class="text-muted fw-semibold" style="font-size: 0.75rem;">Waktu Akses Sistem</div>
                    <div class="fw-bold text-dark" style="font-size: 0.85rem;">
                        <i class="bi bi-clock text-warning me-1"></i> 
                        <span id="realtime-clock"><?= date('d M Y, H:i:s'); ?> WIB</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Form Filter Berdasarkan Rentang Tanggal & Tombol Lihat Hari Ini -->
    <div class="card border-0 shadow-sm rounded-4 mb-4 p-4" style="background: #FFFFFF; border: 1px solid rgba(196, 154, 69, 0.2) !important;">
        <form method="GET" action="" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label for="tanggal_mulai" class="form-label fw-bold small text-muted">Dari Tanggal</label>
                <input type="date" class="form-control rounded-3" id="tanggal_mulai" name="tanggal_mulai" value="<?= htmlspecialchars($tanggal_mulai); ?>">
            </div>
            <div class="col-md-3">
                <label for="tanggal_selesai" class="form-label fw-bold small text-muted">Sampai Tanggal</label>
                <input type="date" class="form-control rounded-3" id="tanggal_selesai" name="tanggal_selesai" value="<?= htmlspecialchars($tanggal_selesai); ?>">
            </div>
            <div class="col-md-6 d-flex gap-2">
                <button type="submit" class="btn text-white fw-bold px-3 rounded-pill flex-grow-1" style="background: linear-gradient(135deg, #C49A45 0%, #A37B2C 100%);">
                    <i class="bi bi-filter me-1"></i> Filter Data
                </button>
                <!-- Tombol Lihat Transaksi Hari Ini -->
                <a href="riwayat-penjualan.php?filter=hari_ini" class="btn btn-outline-warning fw-bold px-3 rounded-pill text-nowrap" style="color: #C49A45; border-color: rgba(196, 154, 69, 0.5);" title="Tampilkan Transaksi Hari Ini">
                    <i class="bi bi-calendar-check me-1"></i> Transaksi Hari Ini
                </a>
                <a href="riwayat-penjualan.php" class="btn btn-outline-secondary fw-bold px-3 rounded-pill" title="Reset Filter">
                    <i class="bi bi-arrow-counterclockwise"></i>
                </a>
            </div>
        </form>
    </div>

    <!-- Tabel Riwayat Transaksi -->
    <div class="table-container-card p-4 shadow-sm bg-white rounded-4 border">
        <div class="table-responsive">
            <table class="table custom-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>ID Struk</th>
                        <th>Tanggal Transaksi</th>
                        <th>Pelanggan</th>
                        <th>Total Bayar</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($q_semua_transaksi) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($q_semua_transaksi)): ?>
                        <tr>
                            <td class="fw-bold text-uppercase" style="color: var(--c-accent);">
                                #TRX-<?= sprintf('%04d', $row['PenjualanID']); ?>
                            </td>
                            <td class="text-muted">
                                <?= date('d M Y, H:i', strtotime($row['TanggalPenjualan'])); ?>
                            </td>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="rounded-circle bg-light d-flex align-items-center justify-content-center text-secondary fw-bold" style="width: 28px; height: 28px; font-size: 0.75rem;">
                                        <?= strtoupper(substr($row['NamaPelanggan'] ?? 'P', 0, 1)); ?>
                                    </div>
                                    <span class="fw-semibold"><?= htmlspecialchars($row['NamaPelanggan'] ?? 'Pelanggan Umum'); ?></span>
                                </div>
                            </td>
                            <td class="fw-bold text-success" style="font-size: 0.95rem;">
                                Rp <?= number_format($row['TotalHarga'], 0, ',', '.'); ?>
                            </td>
                            <td class="text-end">
                                <div class="d-flex justify-content-end gap-2">
                                    <!-- Tombol Lihat Detail Pesanan -->
                                    <a href="detail-transaksi.php?id=<?= $row['PenjualanID']; ?>" class="btn btn-sm btn-outline-info rounded-pill px-3 py-1.5 text-decoration-none fw-bold d-flex align-items-center gap-1">
                                        <i class="bi bi-eye"></i> Detail
                                    </a>
                                    <!-- Tombol Cetak Struk -->
                                    <a href="cetak-struk.php?id=<?= $row['PenjualanID']; ?>" target="_blank" class="btn btn-sm btn-outline-warning rounded-pill px-3 py-1.5 text-decoration-none fw-bold d-flex align-items-center gap-1" style="color: #C49A45; border-color: rgba(196, 154, 69, 0.4);">
                                        <i class="bi bi-printer"></i> Cetak
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="bi bi-receipt-cutoff fs-1 d-block mb-2 text-warning opacity-50"></i>
                                Tidak ada data transaksi yang ditemukan pada rentang tanggal tersebut.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function updateClock() {
        const now = new Date();
        const optionsTime = { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false };
        const optionsDate = { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'short', year: 'numeric' };
        
        const timeString = now.toLocaleTimeString('id-ID', optionsTime).replace(/\./g, ':');
        const dateParts = now.toLocaleDateString('id-ID', optionsDate).split(' ');
        const dateString = `${dateParts[0]} ${dateParts[1]} ${dateParts[2]}`;
        
        const clockElement = document.getElementById('realtime-clock');
        if (clockElement) {
            clockElement.textContent = `${dateString}, ${timeString} WIB`;
        }
    }

    setInterval(updateClock, 1000);
</script>
</body>
</html>