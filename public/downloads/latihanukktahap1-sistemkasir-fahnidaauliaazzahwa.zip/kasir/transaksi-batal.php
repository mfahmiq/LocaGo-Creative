<?php
session_start();
include '../koneksi.php';

date_default_timezone_set('Asia/Jakarta');

if (!isset($_SESSION['login'])) {
    header("Location: ../index.php");
    exit;
}

$role = strtolower(trim($_SESSION['Role'] ?? ''));
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$aksi = strtolower(trim($_GET['aksi'] ?? ''));
$username = $_SESSION['Username'] ?? 'User';
$pelanggan_id = (int)($_SESSION['PelangganID'] ?? 0);

if ($id <= 0 || $aksi !== 'batal') {
    echo "<script>alert('Permintaan tidak valid!'); window.location='riwayat-transaksi.php';</script>";
    exit;
}

if (!in_array($role, ['admin', 'kasir', 'pelanggan'])) {
    echo "<script>alert('Anda tidak memiliki akses!'); window.location='../index.php';</script>";
    exit;
}

$query = mysqli_query(
    $koneksi,
    "SELECT * FROM penjualan WHERE PenjualanID = $id LIMIT 1"
);

$data = mysqli_fetch_assoc($query);

if (!$data) {
    echo "<script>alert('Data transaksi tidak ditemukan!'); window.location='riwayat-transaksi.php';</script>";
    exit;
}

$status_lama = strtolower(trim($data['status'] ?? ''));

if ($status_lama === 'batal' || $status_lama === 'dibatalkan') {
    echo "<script>alert('Transaksi ini sudah dibatalkan sebelumnya!'); window.location='riwayat-transaksi.php';</script>";
    exit;
}

if ($status_lama === 'selesai') {
    echo "<script>alert('Transaksi yang sudah selesai tidak dapat dibatalkan!'); window.location='riwayat-transaksi.php';</script>";
    exit;
}

if ($role === 'pelanggan') {
    if ($pelanggan_id <= 0) {
        echo "<script>alert('Data pelanggan tidak ditemukan! Silakan login kembali.'); window.location='riwayat-transaksi.php';</script>";
        exit;
    }

    $pemilik_transaksi = (int)($data['PelangganID'] ?? 0);

    if ($pemilik_transaksi <= 0 || $pemilik_transaksi !== $pelanggan_id) {
        echo "<script>alert('Anda tidak dapat membatalkan transaksi milik pelanggan lain!'); window.location='riwayat-transaksi.php';</script>";
        exit;
    }
}

mysqli_begin_transaction($koneksi);

try {
    $update_status = mysqli_query(
        $koneksi,
        "UPDATE penjualan SET status = 'batal' WHERE PenjualanID = $id"
    );

    if (!$update_status) {
        throw new Exception("Gagal memperbarui status transaksi.");
    }

    $query_detail = mysqli_query(
        $koneksi,
        "SELECT ProdukID, JumlahProduk FROM detailpenjualan WHERE PenjualanID = $id"
    );

    if (!$query_detail) {
        throw new Exception("Gagal mengambil detail transaksi.");
    }

    while ($detail = mysqli_fetch_assoc($query_detail)) {
        $produk_id = (int)$detail['ProdukID'];
        $jumlah = (int)$detail['JumlahProduk'];

        if ($produk_id <= 0 || $jumlah <= 0) {
            continue;
        }

        $update_stok = mysqli_query(
            $koneksi,
            "UPDATE produk SET Stok = Stok + $jumlah WHERE ProdukID = $produk_id"
        );

        if (!$update_stok) {
            throw new Exception("Gagal mengembalikan stok produk.");
        }
    }

    $aktivitas = "BATALKAN TRANSAKSI";

    if ($role === 'pelanggan') {
        $deskripsi = "Pelanggan ($username) membatalkan Transaksi #$id. Status diubah menjadi batal dan stok dikembalikan.";
    } elseif ($role === 'kasir') {
        $deskripsi = "Kasir ($username) membatalkan Transaksi #$id. Status diubah menjadi batal dan stok dikembalikan.";
    } else {
        $deskripsi = "Admin ($username) membatalkan Transaksi #$id. Status diubah menjadi batal dan stok dikembalikan.";
    }

    $username_safe = mysqli_real_escape_string($koneksi, $username);
    $aktivitas_safe = mysqli_real_escape_string($koneksi, $aktivitas);
    $deskripsi_safe = mysqli_real_escape_string($koneksi, $deskripsi);

    $audit = mysqli_query(
        $koneksi,
        "INSERT INTO audit_log (username, aktivitas, waktu, deskripsi)
         VALUES ('$username_safe', '$aktivitas_safe', NOW(), '$deskripsi_safe')"
    );

    if (!$audit) {
        throw new Exception("Gagal mencatat aktivitas ke audit log.");
    }

    mysqli_commit($koneksi);

    echo "<script>
        window.location='riwayat-transaksi.php';
    </script>";
    exit;

} catch (Exception $e) {
    mysqli_rollback($koneksi);

    $error = htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');

    echo "<script>
        alert('Gagal membatalkan transaksi: $error');
        window.location='riwayat-transaksi.php';
    </script>";
    exit;
}
?>