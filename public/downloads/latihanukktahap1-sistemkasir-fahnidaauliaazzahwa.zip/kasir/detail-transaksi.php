```php
<?php
date_default_timezone_set('Asia/Jakarta');
session_start();
include '../koneksi.php';

// ======================================================
// 1. CEK LOGIN
// ======================================================
if (!isset($_SESSION['login'])) {
    header("Location: ../index.php?pesan=gagal");
    exit;
}


// ======================================================
// 2. AMBIL ID TRANSAKSI
// ======================================================
$penjualan_id = isset($_GET['id'])
    ? (int) $_GET['id']
    : 0;

if ($penjualan_id <= 0) {
    echo "<script>
        alert('ID transaksi tidak valid!');
        window.location='riwayat-penjualan.php';
    </script>";
    exit;
}


// ======================================================
// 3. AMBIL DATA TRANSAKSI
// ======================================================
$stmt_transaksi = mysqli_prepare(
    $koneksi,
    "SELECT
        p.*,

        COALESCE(
            NULLIF(TRIM(pel.NamaPelanggan), ''),
            NULLIF(TRIM(p.NamaPelanggan), ''),
            'Pelanggan Umum'
        ) AS NamaFinalPelanggan,

        pel.NamaPelanggan AS NamaMember,
        pel.Alamat,
        pel.NomorTelepon,

        u.NamaUser

     FROM penjualan p

     LEFT JOIN pelanggan pel
        ON p.PelangganID = pel.PelangganID

     LEFT JOIN user u
        ON p.UserID = u.UserID

     WHERE p.PenjualanID = ?

     LIMIT 1"
);

if (!$stmt_transaksi) {
    die(
        "Gagal menyiapkan data transaksi: " .
        htmlspecialchars(mysqli_error($koneksi))
    );
}

mysqli_stmt_bind_param(
    $stmt_transaksi,
    'i',
    $penjualan_id
);

if (!mysqli_stmt_execute($stmt_transaksi)) {
    die(
        "Gagal mengambil data transaksi: " .
        htmlspecialchars(mysqli_stmt_error($stmt_transaksi))
    );
}

$result_transaksi =
    mysqli_stmt_get_result($stmt_transaksi);

$transaksi =
    mysqli_fetch_assoc($result_transaksi);

mysqli_stmt_close($stmt_transaksi);

if (!$transaksi) {
    echo "<script>
        alert('Data transaksi tidak ditemukan!');
        window.location='riwayat-penjualan.php';
    </script>";
    exit;
}


// ======================================================
// 4. AMBIL DETAIL PRODUK
// ======================================================
$stmt_detail = mysqli_prepare(
    $koneksi,
    "SELECT
        dp.*,
        pr.NamaProduk,
        pr.Harga AS HargaProduk

     FROM detailpenjualan dp

     INNER JOIN produk pr
        ON dp.ProdukID = pr.ProdukID

     WHERE dp.PenjualanID = ?

     ORDER BY dp.DetailID ASC"
);

if (!$stmt_detail) {
    die(
        "Gagal menyiapkan detail transaksi: " .
        htmlspecialchars(mysqli_error($koneksi))
    );
}

mysqli_stmt_bind_param(
    $stmt_detail,
    'i',
    $penjualan_id
);

if (!mysqli_stmt_execute($stmt_detail)) {
    die(
        "Gagal mengambil detail transaksi: " .
        htmlspecialchars(mysqli_stmt_error($stmt_detail))
    );
}

$query_detail =
    mysqli_stmt_get_result($stmt_detail);


// ======================================================
// 5. NOMOR TRANSAKSI
// ======================================================
$format_tgl_trx = date(
    'Ymd',
    strtotime($transaksi['TanggalPenjualan'])
);

$no_transaksi_formatted =
    'TRX-' .
    $format_tgl_trx .
    '-' .
    str_pad(
        (string) $penjualan_id,
        4,
        '0',
        STR_PAD_LEFT
    );


// ======================================================
// 6. DATA PEMBAYARAN
// ======================================================
$tunai_diterima = (float) (
    $transaksi['Bayar']
    ?? $transaksi['Tunai']
    ?? 0
);


// Kembalian
if (
    isset($transaksi['Kembali']) &&
    $transaksi['Kembali'] !== null
) {

    $kembalian =
        (float) $transaksi['Kembali'];

} elseif (
    isset($transaksi['Kembalian']) &&
    $transaksi['Kembalian'] !== null
) {

    $kembalian =
        (float) $transaksi['Kembalian'];

} else {

    $kembalian =
        $tunai_diterima -
        (float) (
            $transaksi['TotalHarga'] ?? 0
        );
}


// ======================================================
// 7. DATA PELANGGAN
// ======================================================
$nama_customer =
    $transaksi['NamaFinalPelanggan'];

$pelanggan_id =
    !empty($transaksi['PelangganID'])
        ? (int) $transaksi['PelangganID']
        : null;


// ======================================================
// 8. STATUS
// ======================================================
$status_transaksi =
    trim(
        $transaksi['Status'] ?? 'Proses'
    );

$status_normal =
    strtolower($status_transaksi);


if ($status_normal === 'selesai') {

    $status_class =
        'status-selesai';

    $status_icon =
        'bi-check-circle-fill';

} elseif (
    $status_normal === 'dibatalkan'
) {

    $status_class =
        'status-dibatalkan';

    $status_icon =
        'bi-x-circle-fill';

} else {

    $status_class =
        'status-proses';

    $status_icon =
        'bi-hourglass-split';
}


// ======================================================
// 9. CATATAN TRANSAKSI
// ======================================================
$catatan_transaksi =
    trim(
        (string) (
            $transaksi['Catatan'] ?? ''
        )
    );


// ======================================================
// 10. HITUNG DETAIL PESANAN
// ======================================================
$detail_data = [];

$total_item_qty = 0;
$total_biaya_extra = 0;
$total_detail_harga = 0;
$jumlah_baris = 0;


while ($d = mysqli_fetch_assoc($query_detail)) {

    // --------------------------------------------------
    // QTY
    // --------------------------------------------------
    $qty_val =
        (int) (
            $d['JumlahProduk'] ?? 0
        );

    if ($qty_val < 0) {
        $qty_val = 0;
    }


    // --------------------------------------------------
    // SUBTOTAL DASAR
    // --------------------------------------------------
    $subtotal_dasar =
        (float) (
            $d['Subtotal'] ?? 0
        );


    // --------------------------------------------------
    // BIAYA EXTRA
    // --------------------------------------------------
    $biaya_extra =
        (float) (
            $d['BiayaExtra'] ?? 0
        );


    // --------------------------------------------------
    // HARGA SATUAN
    // --------------------------------------------------
    if ($qty_val > 0) {

        $harga_satuan =
            $subtotal_dasar / $qty_val;

    } else {

        $harga_satuan =
            (float) (
                $d['HargaProduk'] ?? 0
            );
    }


    // --------------------------------------------------
    // SUBTOTAL ITEM
    // --------------------------------------------------
    $subtotal_item =
        $subtotal_dasar +
        $biaya_extra;


    // --------------------------------------------------
    // CATATAN ITEM
    // --------------------------------------------------
    $catatan_item =
        trim(
            (string) (
                $d['Catatan'] ?? ''
            )
        );


    // --------------------------------------------------
    // TOTAL
    // --------------------------------------------------
    $total_item_qty += $qty_val;

    $total_biaya_extra += $biaya_extra;

    $total_detail_harga += $subtotal_item;

    $jumlah_baris++;


    // --------------------------------------------------
    // SIMPAN DATA
    // --------------------------------------------------
    $detail_data[] = [
        'NamaProduk' =>
            $d['NamaProduk'] ?? '-',

        'ProdukID' =>
            $d['ProdukID'] ?? 0,

        'JumlahProduk' =>
            $qty_val,

        'HargaSatuan' =>
            $harga_satuan,

        'SubtotalDasar' =>
            $subtotal_dasar,

        'Catatan' =>
            $catatan_item,

        'BiayaExtra' =>
            $biaya_extra,

        'SubtotalItem' =>
            $subtotal_item
    ];
}


// ======================================================
// 11. TOTAL TRANSAKSI
// ======================================================
$total_transaksi_database =
    (float) (
        $transaksi['TotalHarga'] ?? 0
    );


// ======================================================
// 12. TIPE PELANGGAN
// ======================================================
if ($pelanggan_id !== null) {

    $tipe_pelanggan_label =
        'Member';

    $tipe_pelanggan_class =
        'customer-member';

    $tipe_pelanggan_icon =
        'bi-person-badge-fill';

} else {

    $tipe_pelanggan_label =
        'Pelanggan Umum';

    $tipe_pelanggan_class =
        'customer-umum';

    $tipe_pelanggan_icon =
        'bi-person-fill';
}

// 13. TIPE PESANAN
$tipe_pesanan = trim($transaksi['TipePesanan'] ?? 'Dine-In');
$tipe_pesanan_normal = strtolower($tipe_pesanan);
if ($tipe_pesanan_normal === 'take-away') {
    $tipe_pesanan_label = 'Take-Away';
    $tipe_pesanan_class = 'order-type-takeaway';
    $tipe_pesanan_icon = 'bi-bag-fill';
} else {
    $tipe_pesanan_label = 'Dine-In';
    $tipe_pesanan_class = 'order-type-dinein';
    $tipe_pesanan_icon = 'bi-shop';
}

?>
<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Detail Transaksi
        <?= htmlspecialchars($no_transaksi_formatted); ?>
        - Daily Coffee & Toast
    </title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"
    >


    <style>

        /* ==================================================
           DASAR
           ================================================== */

        body {
            background-color: #FAF8F5;
            font-family:
                'Plus Jakarta Sans',
                sans-serif !important;
            color: #1E293B;
        }

        .app-container {
            margin-top: 105px;
            margin-left: 290px;
            padding: 0 35px 50px 0;
        }


        @media (max-width: 992px) {

            .app-container {
                margin-left: 20px;
                margin-right: 20px;
                padding-right: 0;
            }

        }


        /* ==================================================
           CARD
           ================================================== */

        .detail-card {
            background: #FFFFFF;
            border-radius: 20px;
            border: 1px solid #E5E0D8;
            box-shadow:
                0 10px 25px
                rgba(0, 0, 0, 0.03);
        }


        .page-header {
            background: #FFFFFF;
            border: 1px solid #E5E0D8;
            border-radius: 20px;
            box-shadow:
                0 8px 22px
                rgba(0, 0, 0, 0.03);
        }


        /* ==================================================
           CARD DAFTAR MENU
           ================================================== */

        .menu-card-inner {
            background: #FFFFFF;
            border: 1px solid #E7E5E4;
            border-radius: 14px;
            overflow: hidden;
        }


        /* ==================================================
           JUDUL
           ================================================== */

        .menu-card-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;

            padding: 0 0 12px 0;
            margin: 0 0 19px 0;

            border-bottom: 1px solid #D6D3D1;
            background: #FFFFFF;
        }


        .menu-card-title {
            display: flex;
            align-items: center;
            gap: 8px;

            color: #1C1917;
            font-size: 1rem;
            font-weight: 800;
        }


        .menu-card-title i {
            color: #F4B400;
            font-size: 1.08rem;
        }


        .menu-card-count {
            padding: 5px 9px;
            border-radius: 7px;

            background: #F8FAFC;
            border: 1px solid #DCE3EA;

            color: #475569;
            font-size: 0.68rem;
            font-weight: 600;

            white-space: nowrap;
        }


        /* ==================================================
           TABEL
           ================================================== */

        .menu-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }


        .menu-table thead th {
            background: #1E293B;
            color: #FFFFFF;

            padding: 15px 18px;

            font-size: 0.74rem;
            font-weight: 800;

            text-transform: uppercase;
            letter-spacing: 0.35px;

            border: none;
        }


        .menu-table thead th:first-child {
            border-top-left-radius: 11px;
            text-align: left;
        }


        .menu-table thead th:last-child {
            border-top-right-radius: 11px;
            text-align: right;
        }


        .menu-table thead th:nth-child(1) {
            width: 42%;
            text-align: left;
        }


        .menu-table thead th:nth-child(2) {
            width: 12%;
            text-align: center;
        }


        .menu-table thead th:nth-child(3) {
            width: 22%;
            text-align: right;
        }


        .menu-table thead th:nth-child(4) {
            width: 24%;
            text-align: right;
        }


        /* ==================================================
           ISI TABEL
           ================================================== */

        .menu-table tbody td {
            background: #FFFFFF;

            border-bottom: 1px solid #F1F5F9;

            vertical-align: top;

            font-size: 0.86rem;
        }


        .menu-table tbody tr:last-child td {
            border-bottom: none;
        }


        .menu-table tbody tr:hover td {
            background: #FCFBF9;
        }


        .product-content-cell {
            padding: 0 !important;
        }


        /* ==================================================
           BLOK PRODUK
           ================================================== */

        .product-block {
            width: 100%;
            position: relative;
        }


        .product-block + .product-block {
            border-top:
                1px solid
                #EDEAE6;
        }


        /* ==================================================
           BARIS UTAMA PRODUK
           ================================================== */

        .product-main-row {
            display: grid;

            grid-template-columns:
                minmax(0, 42%)
                12%
                minmax(0, 22%)
                24%;

            align-items: center;

            min-height: 72px;

            padding:
                15px
                18px
                10px;

            box-sizing: border-box;
        }


        .product-main-info {
            min-width: 0;

            padding-right: 14px;
        }


        .menu-product-name {
            color: #1C1917;

            font-size: 0.88rem;

            font-weight: 800;

            line-height: 1.4;

            overflow-wrap: anywhere;
        }


        .menu-product-qty-label {
            display: inline-flex;

            align-items: center;

            margin-top: 5px;

            padding: 3px 7px;

            border-radius: 5px;

            background: #F5F5F4;

            color: #78716C;

            font-size: 0.64rem;

            font-weight: 700;
        }


        /* ==================================================
           QTY
           ================================================== */

        .product-main-qty {
            text-align: center;

            color: #334155;

            font-size: 0.82rem;

            font-weight: 800;

            white-space: nowrap;
        }


        /* ==================================================
           HARGA SATUAN
           ================================================== */

        .product-main-price {
            text-align: right;

            color: #57534E;

            font-size: 0.82rem;

            font-weight: 600;

            white-space: nowrap;
        }


        .product-main-subtotal {
            min-height: 1px;
        }


        /* ==================================================
           DETAIL TAMBAHAN
           ================================================== */

        .product-extra-area {
            width: 100%;

            padding:
                0
                18px
                7px
                18px;

            box-sizing: border-box;
        }


        .product-detail-stack {
            width: 100%;

            display: flex;

            flex-direction: column;

            gap: 5px;
        }


        /* ==================================================
           CATATAN
           ================================================== */

        .product-note-box {
            width: 100%;

            display: flex;

            align-items: flex-start;

            gap: 8px;

            padding:
                7px
                10px;

            background: #FFFBEB;

            border:
                1px solid
                #FDE68A;

            border-radius: 7px;

            box-sizing: border-box;
        }


        .product-note-icon {
            width: 20px;
            height: 20px;

            display: flex;

            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            margin-top: 1px;

            background: #FEF3C7;

            color: #D97706;

            border-radius: 5px;

            font-size: 0.63rem;
        }


        .product-note-content {
            min-width: 0;

            flex: 1;
        }


        .product-note-title {
            display: inline;

            margin-right: 6px;

            color: #92400E;

            font-size: 0.63rem;

            font-weight: 800;

            text-transform: uppercase;

            letter-spacing: 0.35px;
        }


        .product-note-text {
            display: inline;

            color: #78350F;

            font-size: 0.72rem;

            font-weight: 600;

            line-height: 1.45;

            overflow-wrap: anywhere;
        }


        /* ==================================================
           BIAYA EXTRA
           ================================================== */

        .product-extra-box {
            width: 100%;

            display: flex;

            align-items: center;

            gap: 8px;

            padding:
                7px
                10px;

            background: #F8FAFC;

            border:
                1px solid
                #E2E8F0;

            border-radius: 7px;

            box-sizing: border-box;
        }


        .product-extra-icon {
            width: 20px;
            height: 20px;

            display: flex;

            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            background: #EFF6FF;

            color: #2563EB;

            border-radius: 5px;

            font-size: 0.63rem;
        }


        .product-extra-content {
            min-width: 0;

            flex: 1;

            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 12px;
        }


        .product-extra-title {
            color: #475569;

            font-size: 0.63rem;

            font-weight: 800;

            text-transform: uppercase;

            letter-spacing: 0.35px;
        }


        .product-extra-value {
            color: #2563EB;

            font-size: 0.72rem;

            font-weight: 800;

            white-space: nowrap;
        }


        /* ==================================================
           SUBTOTAL ITEM
           ================================================== */

        .product-subtotal-row {
            display: flex;

            align-items: center;

            justify-content: flex-end;

            gap: 10px;

            width: 100%;

            padding:
                7px
                18px
                14px;

            box-sizing: border-box;
        }


        .product-subtotal-label {
            color: #A8A29E;

            font-size: 0.65rem;

            font-weight: 700;

            text-transform: uppercase;

            letter-spacing: 0.3px;
        }


        .product-subtotal-value {
            color: #166534;

            font-size: 0.88rem;

            font-weight: 800;

            white-space: nowrap;
        }


        /* ==================================================
           TOTAL TRANSAKSI
           PEMBARUAN: LEBIH MENYATU DENGAN TABEL
           ================================================== */

        .transaction-total-wrapper {
            margin-top: 0;

            padding:
                15px
                18px
                16px;

            background: #FAFAF9;

            border-top:
                1px solid
                #E7E5E4;
        }


        .transaction-total-box {
            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 20px;

            width: 100%;

            padding:
                3px
                0
                1px;
        }


        .transaction-total-left {
            min-width: 0;
        }


        .transaction-total-label {
            display: flex;

            align-items: center;

            gap: 8px;

            color: #44403C;

            font-size: 0.72rem;

            font-weight: 800;

            text-transform: uppercase;

            letter-spacing: 0.4px;
        }


        .transaction-total-label i {
            width: 25px;
            height: 25px;

            display: flex;

            align-items: center;
            justify-content: center;

            flex-shrink: 0;

            background: #FEF3C7;

            color: #B45309;

            border-radius: 6px;

            font-size: 0.68rem;
        }


        .transaction-total-caption {
            margin-top: 4px;

            color: #A8A29E;

            font-size: 0.62rem;

            font-weight: 500;

            line-height: 1.4;
        }


        .transaction-total-value {
            color: #15803D;

            font-size: 1.15rem;

            font-weight: 800;

            white-space: nowrap;

            letter-spacing: -0.2px;
        }


        /* ==================================================
           STATUS
           ================================================== */

        .status-badge {
            display: inline-flex;

            align-items: center;
            justify-content: center;

            gap: 6px;

            padding: 8px 14px;

            border-radius: 50rem;

            font-size: 0.8rem;
            font-weight: 800;

            border: 1px solid transparent;

            white-space: nowrap;
        }


        .status-proses {
            background-color: #FEF3C7;
            color: #92400E;
            border-color: #FDE68A;
        }


        .status-selesai {
            background-color: #DCFCE7;
            color: #166534;
            border-color: #BBF7D0;
        }


        .status-dibatalkan {
            background-color: #FEE2E2;
            color: #991B1B;
            border-color: #FECACA;
        }


        /* ==================================================
           CUSTOMER
           ================================================== */

        .customer-badge {
            display: inline-flex;

            align-items: center;

            gap: 6px;

            padding: 6px 10px;

            border-radius: 8px;

            font-size: 0.75rem;

            font-weight: 700;
        }


        .customer-member {
            color: #1D4ED8;
            background: #EFF6FF;
            border: 1px solid #DBEAFE;
        }


        .customer-umum {
            color: #78716C;
            background: #F5F5F4;
            border: 1px solid #E7E5E4;
        }



        /* ==================================================
           TIPE PESANAN
           ================================================== */

        .order-type-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 10px;
            border-radius: 8px;
            font-size: 0.75rem;
            font-weight: 700;
            border: 1px solid transparent;
        }

        .order-type-dinein {
            color: #166534;
            background: #F0FDF4;
            border-color: #BBF7D0;
        }

        .order-type-takeaway {
            color: #92400E;
            background: #FFFBEB;
            border-color: #FDE68A;
        }

        /* ==================================================
           BUTTON
           ================================================== */

        .btn-kembali {
            border-radius: 50rem;

            padding: 10px 18px;

            font-weight: 700;

            background: #FFFFFF;

            border:
                1px solid
                #D6D3D1;

            color: #57534E;

            box-shadow:
                0 2px 5px
                rgba(0, 0, 0, 0.03);

            transition:
                all 0.2s ease;
        }


        .btn-kembali:hover {
            background: #F5F5F4;

            border-color: #A8A29E;

            color: #292524;

            transform:
                translateY(-1px);

            box-shadow:
                0 4px 10px
                rgba(0, 0, 0, 0.06);
        }


        .btn-kembali i {
            font-size: 0.9rem;

            transition:
                transform 0.2s ease;
        }


        .btn-kembali:hover i {
            transform:
                translateX(-2px);
        }


        .btn-cetak {
            background:
                linear-gradient(
                    135deg,
                    #C49A45 0%,
                    #A37B2C 100%
                );

            color: #FFFFFF;

            border: none;

            border-radius: 50rem;

            padding: 10px 20px;

            font-weight: 700;

            text-decoration: none;

            transition: 0.2s;

            box-shadow:
                0 3px 8px
                rgba(163, 123, 44, 0.15);
        }


        .btn-cetak:hover {
            background: #A37B2C;

            color: #FFFFFF;

            transform:
                translateY(-1px);

            box-shadow:
                0 5px 12px
                rgba(163, 123, 44, 0.22);
        }


        /* ==================================================
           INFO
           ================================================== */

        .info-label {
            color: #78716C;

            font-size: 0.8rem;

            display: block;

            margin-bottom: 4px;
        }


        .info-value {
            color: #1E293B;

            font-weight: 700;

            overflow-wrap: anywhere;
        }


        /* ==================================================
           PAYMENT
           ================================================== */

        .payment-box {
            background: #F8FAFC;

            border: 1px solid #E2E8F0;

            border-radius: 12px;

            padding: 15px;
        }


        .payment-row {
            display: flex;

            justify-content: space-between;

            gap: 15px;

            margin-bottom: 7px;

            font-size: 0.88rem;
        }


        .payment-row:last-child {
            margin-bottom: 0;
        }


        .payment-value {
            white-space: nowrap;

            font-weight: 700;

            text-align: right;
        }


        /* ==================================================
           TOTAL
           ================================================== */

        .total-box {
            background: #FAF8F5;

            border: 1px solid #E5E0D8;

            border-radius: 12px;

            padding: 16px;
        }


        .total-amount {
            color: #15803D;

            font-size: 1.6rem;

            font-weight: 800;

            line-height: 1.2;
        }


        /* ==================================================
           CATATAN TRANSAKSI
           ================================================== */

        .transaction-note {
            background: #FFFBEB;

            border: 1px solid #FDE68A;

            border-radius: 10px;

            padding: 11px 13px;

            color: #92400E;

            font-size: 0.82rem;

            line-height: 1.5;
        }


        /* ==================================================
           RESPONSIVE
           ================================================== */

        @media (max-width: 768px) {

            .menu-table thead th {
                padding:
                    12px
                    10px;

                font-size: 0.68rem;
            }


            .product-main-row {
                grid-template-columns:
                    minmax(0, 40%)
                    15%
                    minmax(0, 45%);

                gap: 0;

                padding:
                    14px
                    10px
                    9px;
            }


            .product-main-subtotal {
                display: none;
            }


            .product-main-info {
                padding-right: 8px;
            }


            .product-main-price {
                padding-left: 8px;
            }


            .product-extra-area {
                padding:
                    0
                    10px
                    7px
                    10px;
            }


            .product-subtotal-row {
                padding:
                    7px
                    10px
                    13px;
            }


            .product-note-text,
            .product-extra-value {
                font-size: 0.69rem;
            }


            .transaction-total-wrapper {
                padding:
                    13px
                    10px
                    15px;
            }


            .transaction-total-box {
                align-items: center;

                gap: 12px;
            }


            .transaction-total-value {
                font-size: 1rem;
            }


            .transaction-total-caption {
                max-width: 270px;
            }

        }


        @media (max-width: 576px) {

            .app-container {
                margin-top: 90px;

                margin-left: 10px;

                margin-right: 10px;
            }


            .detail-card {
                padding: 16px !important;
            }


            .total-amount {
                font-size: 1.35rem;
            }


            .menu-card-top {
                padding-bottom: 10px;

                margin-bottom: 14px;
            }


            .menu-card-title {
                font-size: 0.88rem;
            }


            .menu-card-count {
                font-size: 0.63rem;
            }


            .product-main-row {
                min-height: 66px;

                padding:
                    12px
                    8px
                    8px;
            }


            .product-main-qty {
                font-size: 0.75rem;
            }


            .product-main-price {
                font-size: 0.74rem;
            }


            .product-extra-area {
                padding:
                    0
                    8px
                    7px
                    8px;
            }


            .product-note-box,
            .product-extra-box {
                padding:
                    7px
                    9px;
            }


            .product-subtotal-row {
                padding:
                    6px
                    8px
                    12px;
            }


            .product-subtotal-label {
                font-size: 0.63rem;
            }


            .product-subtotal-value {
                font-size: 0.8rem;
            }


            .product-extra-content {
                align-items: flex-start;

                flex-direction: column;

                gap: 1px;
            }


            .product-extra-value {
                margin-left: 0;
            }


            .transaction-total-wrapper {
                padding:
                    12px
                    8px
                    14px;
            }


            .transaction-total-box {
                align-items: flex-start;

                flex-direction: column;

                gap: 6px;
            }


            .transaction-total-value {
                align-self: flex-end;

                font-size: 1rem;
            }

        }

    </style>

</head>


<body>


<?php include 'header.php'; ?>


<div class="app-container">


    <!-- ==================================================
         HEADER HALAMAN
         ================================================== -->

    <div
        class="
            page-header
            d-flex
            flex-column
            flex-lg-row
            justify-content-between
            align-items-lg-center
            gap-3
            mb-4
            bg-white
            p-4
        "
    >

        <div>

            <div
                class="
                    d-flex
                    align-items-center
                    gap-2
                    mb-2
                    flex-wrap
                "
            >

                <h3
                    class="fw-bold mb-0"
                    style="color:#141211;"
                >

                    Detail Transaksi

                    <span
                        style="
                            font-family:monospace;
                            color:#C49A45;
                        "
                    >

                        <?= htmlspecialchars(
                            $no_transaksi_formatted
                        ); ?>

                    </span>

                </h3>


                <span
                    class="
                        badge
                        px-3
                        py-2
                        rounded-pill
                        fw-bold
                    "
                    style="
                        background:
                            rgba(196,154,69,0.15);

                        color:#C49A45;

                        border:
                            1px solid
                            rgba(196,154,69,0.3);
                    "
                >

                    <i class="bi bi-receipt me-1"></i>

                    RINCIAN PESANAN

                </span>

            </div>


            <p class="text-muted small mb-0">

                Informasi lengkap rincian produk,
                catatan, biaya ekstra, dan pembayaran.

            </p>

        </div>


        <div
            class="
                d-flex
                align-items-center
                gap-2
                flex-wrap
            "
        >

            <a
                href="riwayat-penjualan.php"
                class="
                    btn
                    btn-kembali
                    text-decoration-none
                    d-flex
                    align-items-center
                    justify-content-center
                    gap-2
                "
            >

                <i class="bi bi-arrow-left"></i>

                <span>Kembali</span>

            </a>


            <a
                href="cetak-struk.php?id=<?= $penjualan_id; ?>"
                target="_blank"
                class="
                    btn-cetak
                    d-flex
                    align-items-center
                    justify-content-center
                    gap-2
                "
            >

                <i class="bi bi-printer"></i>

                <span>Cetak Struk</span>

            </a>

        </div>

    </div>


    <!-- ==================================================
         CONTENT
         ================================================== -->

    <div class="row g-4">


        <!-- ==================================================
             KIRI - DAFTAR MENU
             ================================================== -->

        <div class="col-lg-8">

            <div class="detail-card p-4 h-100">


                <div class="menu-card-inner">


                    <!-- ==========================================
                         JUDUL
                         ========================================== -->

                    <div class="menu-card-top">

                        <div class="menu-card-title">

                            <i
                                class="bi bi-basket-fill"
                            ></i>

                            <span>
                                Daftar Menu yang Dipesan
                            </span>

                        </div>


                        <div class="menu-card-count">

                            <?= $jumlah_baris; ?>

                            Jenis Menu

                        </div>

                    </div>


                    <!-- ==========================================
                         TABEL
                         ========================================== -->

                    <?php if (
                        count($detail_data) > 0
                    ): ?>

                        <div class="table-responsive">

                            <table class="menu-table">

                                <thead>

                                    <tr>

                                        <th>
                                            MENU PRODUK
                                        </th>

                                        <th>
                                            QTY
                                        </th>

                                        <th>
                                            HARGA SATUAN
                                        </th>

                                        <th>
                                            SUBTOTAL
                                        </th>

                                    </tr>

                                </thead>


                                <tbody>


                                    <?php foreach (
                                        $detail_data
                                        as $d
                                    ): ?>

                                        <tr>

                                            <td
                                                colspan="4"
                                                class="
                                                    product-content-cell
                                                "
                                            >

                                                <div
                                                    class="
                                                        product-block
                                                    "
                                                >


                                                    <!-- ==============================
                                                         INFORMASI UTAMA
                                                         ============================== -->

                                                    <div
                                                        class="
                                                            product-main-row
                                                        "
                                                    >

                                                        <!-- PRODUK -->

                                                        <div
                                                            class="
                                                                product-main-info
                                                            "
                                                        >

                                                            <div
                                                                class="
                                                                    menu-product-name
                                                                "
                                                            >

                                                                <?= htmlspecialchars(
                                                                    $d['NamaProduk']
                                                                ); ?>

                                                            </div>


                                                            <div
                                                                class="
                                                                    menu-product-qty-label
                                                                "
                                                            >

                                                                <?= $d['JumlahProduk']; ?>

                                                                item

                                                            </div>

                                                        </div>


                                                        <!-- QTY -->

                                                        <div
                                                            class="
                                                                product-main-qty
                                                            "
                                                        >

                                                            <?= $d['JumlahProduk']; ?>x

                                                        </div>


                                                        <!-- HARGA SATUAN -->

                                                        <div
                                                            class="
                                                                product-main-price
                                                            "
                                                        >

                                                            Rp
                                                            <?= number_format(
                                                                $d['HargaSatuan'],
                                                                0,
                                                                ',',
                                                                '.'
                                                            ); ?>

                                                        </div>


                                                        <div
                                                            class="
                                                                product-main-subtotal
                                                            "
                                                        ></div>

                                                    </div>


                                                    <!-- ==============================
                                                         CATATAN + EXTRA
                                                         ============================== -->

                                                    <?php if (
                                                        trim(
                                                            $d['Catatan']
                                                        ) !== '' ||
                                                        $d['BiayaExtra'] > 0
                                                    ): ?>

                                                        <div
                                                            class="
                                                                product-extra-area
                                                            "
                                                        >

                                                            <div
                                                                class="
                                                                    product-detail-stack
                                                                "
                                                            >

                                                                <!-- CATATAN -->

                                                                <?php if (
                                                                    trim(
                                                                        $d['Catatan']
                                                                    ) !== ''
                                                                ): ?>

                                                                    <div
                                                                        class="
                                                                            product-note-box
                                                                        "
                                                                    >

                                                                        <div
                                                                            class="
                                                                                product-note-icon
                                                                            "
                                                                        >

                                                                            <i
                                                                                class="
                                                                                    bi
                                                                                    bi-chat-left-text-fill
                                                                                "
                                                                            ></i>

                                                                        </div>


                                                                        <div
                                                                            class="
                                                                                product-note-content
                                                                            "
                                                                        >

                                                                            <span
                                                                                class="
                                                                                    product-note-title
                                                                                "
                                                                            >
                                                                                Catatan
                                                                            </span>

                                                                            <span
                                                                                class="
                                                                                    product-note-text
                                                                                "
                                                                            >

                                                                                <?= nl2br(
                                                                                    htmlspecialchars(
                                                                                        $d['Catatan']
                                                                                    )
                                                                                ); ?>

                                                                            </span>

                                                                        </div>

                                                                    </div>

                                                                <?php endif; ?>


                                                                <!-- BIAYA EXTRA -->

                                                                <?php if (
                                                                    $d['BiayaExtra'] > 0
                                                                ): ?>

                                                                    <div
                                                                        class="
                                                                            product-extra-box
                                                                        "
                                                                    >

                                                                        <div
                                                                            class="
                                                                                product-extra-icon
                                                                            "
                                                                        >

                                                                            <i
                                                                                class="
                                                                                    bi
                                                                                    bi-plus-circle-fill
                                                                                "
                                                                            ></i>

                                                                        </div>


                                                                        <div
                                                                            class="
                                                                                product-extra-content
                                                                            "
                                                                        >

                                                                            <span
                                                                                class="
                                                                                    product-extra-title
                                                                                "
                                                                            >

                                                                                Biaya Extra

                                                                            </span>


                                                                            <span
                                                                                class="
                                                                                    product-extra-value
                                                                                "
                                                                            >

                                                                                + Rp
                                                                                <?= number_format(
                                                                                    $d['BiayaExtra'],
                                                                                    0,
                                                                                    ',',
                                                                                    '.'
                                                                                ); ?>

                                                                            </span>

                                                                        </div>

                                                                    </div>

                                                                <?php endif; ?>

                                                            </div>

                                                        </div>

                                                    <?php endif; ?>


                                                    <!-- ==============================
                                                         SUBTOTAL ITEM
                                                         ============================== -->

                                                    <div
                                                        class="
                                                            product-subtotal-row
                                                        "
                                                    >

                                                        <span
                                                            class="
                                                                product-subtotal-label
                                                            "
                                                        >
                                                            Subtotal
                                                        </span>


                                                        <span
                                                            class="
                                                                product-subtotal-value
                                                            "
                                                        >

                                                            Rp
                                                            <?= number_format(
                                                                $d['SubtotalItem'],
                                                                0,
                                                                ',',
                                                                '.'
                                                            ); ?>

                                                        </span>

                                                    </div>


                                                </div>

                                            </td>

                                        </tr>

                                    <?php endforeach; ?>


                                </tbody>

                            </table>

                        </div>


                        <!-- ==========================================
                             TOTAL TRANSAKSI
                             ========================================== -->

                        <div class="transaction-total-wrapper">

                            <div class="transaction-total-box">

                                <div class="transaction-total-left">

                                    <div class="transaction-total-label">

                                        <i
                                            class="bi bi-calculator-fill"
                                        ></i>

                                        <span>
                                            Total Transaksi
                                        </span>

                                    </div>


                                    <div
                                        class="
                                            transaction-total-caption
                                        "
                                    >

                                        Total seluruh pesanan
                                        termasuk biaya extra.

                                    </div>

                                </div>


                                <div
                                    class="
                                        transaction-total-value
                                    "
                                >

                                    Rp
                                    <?= number_format(
                                        $total_transaksi_database,
                                        0,
                                        ',',
                                        '.'
                                    ); ?>

                                </div>

                            </div>

                        </div>


                    <?php else: ?>


                        <div
                            class="
                                menu-empty
                            "
                        >

                            <i
                                class="
                                    bi
                                    bi-basket
                                "
                            ></i>

                            Belum ada detail produk
                            pada transaksi ini.

                        </div>


                    <?php endif; ?>


                </div>

            </div>

        </div>


        <!-- ==================================================
             KANAN - INFORMASI TRANSAKSI
             ================================================== -->

        <div class="col-lg-4">

            <div
                class="
                    detail-card
                    p-4
                    h-100
                    d-flex
                    flex-column
                    justify-content-between
                "
            >

                <div>


                    <!-- HEADER -->
                    <h5
                        class="
                            fw-bold
                            mb-3
                            pb-2
                            border-bottom
                            text-dark
                            d-flex
                            align-items-center
                            gap-2
                        "
                    >

                        <i
                            class="
                                bi
                                bi-info-circle
                                text-warning
                            "
                        ></i>

                        Informasi Transaksi

                    </h5>


                    <!-- NOMOR -->
                    <div class="mb-3">

                        <span class="info-label">
                            Nomor Transaksi
                        </span>

                        <span
                            class="
                                info-value
                                font-monospace
                            "
                        >

                            <?= htmlspecialchars(
                                $no_transaksi_formatted
                            ); ?>

                        </span>

                    </div>


                    <!-- WAKTU -->
                    <div class="mb-3">

                        <span class="info-label">
                            Waktu Transaksi
                        </span>

                        <span class="info-value">

                            <?= date(
                                'd F Y, H:i:s',
                                strtotime(
                                    $transaksi[
                                        'TanggalPenjualan'
                                    ]
                                )
                            ); ?>

                            WIB

                        </span>

                    </div>


                    <!-- KASIR -->
                    <div class="mb-3">

                        <span class="info-label">
                            Kasir
                        </span>

                        <span class="info-value">

                            <?= !empty(
                                $transaksi['NamaUser']
                            )
                                ? htmlspecialchars(
                                    $transaksi['NamaUser']
                                )
                                : 'Administrator';
                            ?>

                        </span>

                    </div>



                    <!-- TIPE PESANAN -->
                    <div class="mb-3">
                        <span class="info-label">Tipe Pesanan</span>
                        <div class="mt-1">
                            <span class="order-type-badge <?= $tipe_pesanan_class; ?>">
                                <i class="bi <?= $tipe_pesanan_icon; ?>"></i>
                                <?= htmlspecialchars($tipe_pesanan_label); ?>
                            </span>
                        </div>
                    </div>

                    <!-- STATUS -->
                    <div class="mb-3">

                        <span class="info-label">
                            Status Transaksi
                        </span>

                        <div class="mt-1">

                            <span
                                class="
                                    status-badge
                                    <?= $status_class; ?>
                                "
                            >

                                <i
                                    class="
                                        bi
                                        <?= $status_icon; ?>
                                    "
                                ></i>

                                <?= htmlspecialchars(
                                    ucfirst(
                                        $status_transaksi
                                    )
                                ); ?>

                            </span>

                        </div>

                    </div>


                    <!-- PELANGGAN -->
                    <div class="mb-3">

                        <span class="info-label">
                            Tipe Pelanggan
                        </span>


                        <div class="mb-2">

                            <span
                                class="
                                    customer-badge
                                    <?= $tipe_pelanggan_class; ?>
                                "
                            >

                                <i
                                    class="
                                        bi
                                        <?= $tipe_pelanggan_icon; ?>
                                    "
                                ></i>

                                <?= htmlspecialchars(
                                    $tipe_pelanggan_label
                                ); ?>

                            </span>

                        </div>


                        <span class="info-label">
                            Nama Pelanggan
                        </span>

                        <span class="info-value">

                            <?= htmlspecialchars(
                                $nama_customer
                            ); ?>

                        </span>

                    </div>


                    <!-- ID MEMBER -->
                    <?php if (
                        $pelanggan_id !== null
                    ): ?>

                        <div class="mb-3">

                            <span class="info-label">
                                ID Member
                            </span>

                            <span
                                class="
                                    info-value
                                    font-monospace
                                "
                            >

                                #<?= $pelanggan_id; ?>

                            </span>

                        </div>

                    <?php endif; ?>


                    <!-- TELEPON -->
                    <div class="mb-3">

                        <span class="info-label">
                            Telepon / Kontak
                        </span>

                        <span class="info-value">

                            <?= !empty(
                                $transaksi['NomorTelepon']
                            )
                                ? htmlspecialchars(
                                    $transaksi['NomorTelepon']
                                )
                                : '-';
                            ?>

                        </span>

                    </div>


                    <!-- ALAMAT -->
                    <div class="mb-3">

                        <span class="info-label">
                            Alamat
                        </span>

                        <span class="info-value">

                            <?= !empty(
                                $transaksi['Alamat']
                            )
                                ? htmlspecialchars(
                                    $transaksi['Alamat']
                                )
                                : '-';
                            ?>

                        </span>

                    </div>


                    <!-- CATATAN TRANSAKSI -->
                    <?php if (
                        $catatan_transaksi !== ''
                    ): ?>

                        <div class="mb-3">

                            <span class="info-label">
                                Catatan Transaksi
                            </span>

                            <div
                                class="
                                    transaction-note
                                    mt-1
                                "
                            >

                                <i
                                    class="
                                        bi
                                        bi-journal-text
                                        me-1
                                    "
                                ></i>

                                <?= nl2br(
                                    htmlspecialchars(
                                        $catatan_transaksi
                                    )
                                ); ?>

                            </div>

                        </div>

                    <?php endif; ?>


                    <!-- PEMBAYARAN -->
                    <div
                        class="
                            payment-box
                            mb-3
                        "
                    >

                        <div
                            class="
                                payment-row
                            "
                        >

                            <span class="text-muted">
                                Total Pembelian
                            </span>

                            <span
                                class="
                                    payment-value
                                    text-dark
                                "
                            >

                                Rp
                                <?= number_format(
                                    $total_transaksi_database,
                                    0,
                                    ',',
                                    '.'
                                ); ?>

                            </span>

                        </div>


                        <div
                            class="
                                payment-row
                            "
                        >

                            <span class="text-muted">
                                Tunai Diterima
                            </span>

                            <span
                                class="
                                    payment-value
                                    text-dark
                                "
                            >

                                Rp
                                <?= number_format(
                                    $tunai_diterima,
                                    0,
                                    ',',
                                    '.'
                                ); ?>

                            </span>

                        </div>


                        <div
                            class="
                                payment-row
                                pt-2
                                border-top
                            "
                        >

                            <span class="text-muted">
                                Kembalian
                            </span>

                            <span
                                class="
                                    payment-value
                                    text-success
                                "
                            >

                                Rp
                                <?= number_format(
                                    $kembalian,
                                    0,
                                    ',',
                                    '.'
                                ); ?>

                            </span>

                        </div>

                    </div>

                </div>


                <!-- ==========================================
                     TOTAL TAGIHAN
                     ========================================== -->

                <div
                    class="
                        total-box
                        mt-2
                    "
                >

                    <div
                        class="
                            d-flex
                            align-items-center
                            justify-content-between
                            gap-2
                        "
                    >

                        <span
                            class="
                                text-muted
                                small
                                text-uppercase
                                fw-bold
                            "
                            style="
                                font-size:
                                    0.75rem;
                            "
                        >

                            Total Tagihan

                        </span>


                        <span
                            class="
                                status-badge
                                <?= $status_class; ?>
                            "
                        >

                            <i
                                class="
                                    bi
                                    <?= $status_icon; ?>
                                "
                            ></i>

                            <?= htmlspecialchars(
                                ucfirst(
                                    $status_transaksi
                                )
                            ); ?>

                        </span>

                    </div>


                    <div
                        class="
                            total-amount
                            mt-2
                        "
                    >

                        Rp
                        <?= number_format(
                            $total_transaksi_database,
                            0,
                            ',',
                            '.'
                        ); ?>

                    </div>


                    <?php if (
                        abs(
                            $total_detail_harga -
                            $total_transaksi_database
                        ) > 0.01
                    ): ?>

                        <small
                            class="
                                d-block
                                mt-2
                                text-muted
                            "
                        >

                            Rincian item:
                            Rp
                            <?= number_format(
                                $total_detail_harga,
                                0,
                                ',',
                                '.'
                            ); ?>

                        </small>

                    <?php endif; ?>

                </div>


            </div>

        </div>

    </div>

</div>


<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
></script>

</body>
</html>

<?php
mysqli_stmt_close($stmt_detail);
?>