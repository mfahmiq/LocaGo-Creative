<?php
// ======================================================
// 1. SETUP
// ======================================================
date_default_timezone_set('Asia/Jakarta');
session_start();
include '../koneksi.php';

if (!isset($_SESSION['login'])) {
    header("Location: ../index.php?pesan=gagal");
    exit;
}

$user_role = $_SESSION['Role'] ?? 'kasir';
$in_pelanggan_folder = (strpos($_SERVER['PHP_SELF'], '/pelanggan/') !== false);

// ======================================================
// 2. AMBIL ID TRANSAKSI
// ======================================================
$penjualan_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

$redirect_back = ($user_role === 'pelanggan') ? 'pesan-mandiri.php' : 'penjualan.php';

if ($penjualan_id <= 0) {
    echo "<script>
        alert('ID transaksi tidak valid!');
        window.location='" . $redirect_back . "';
    </script>";
    exit;
}

// ======================================================
// 3. AMBIL DATA TRANSAKSI
// ======================================================
$stmt = mysqli_prepare(
    $koneksi,
    "SELECT
        p.*,
        COALESCE(
            NULLIF(pel.NamaPelanggan, ''),
            NULLIF(p.NamaPelanggan, ''),
            'Pelanggan Umum'
        ) AS NamaFinalPelanggan,
        u.NamaUser
     FROM penjualan p
     LEFT JOIN pelanggan pel
        ON p.PelangganID = pel.PelangganID
     LEFT JOIN user u
        ON p.UserID = u.UserID
     WHERE p.PenjualanID = ?
     LIMIT 1"
);

if (!$stmt) {
    die('Gagal menyiapkan data transaksi: ' . htmlspecialchars(mysqli_error($koneksi)));
}

mysqli_stmt_bind_param($stmt, 'i', $penjualan_id);
mysqli_stmt_execute($stmt);
$result_transaksi = mysqli_stmt_get_result($stmt);
$transaksi = mysqli_fetch_assoc($result_transaksi);
mysqli_stmt_close($stmt);

if (!$transaksi) {
    echo "<script>
        alert('Data transaksi tidak ditemukan!');
        window.location='" . $redirect_back . "';
    </script>";
    exit;
}

// ======================================================
// 4. AMBIL DETAIL PRODUK
// ======================================================
$stmt_detail = mysqli_prepare(
    $koneksi,
    "SELECT
        dp.*,
        pr.NamaProduk,
        pr.Harga AS HargaProduk
     FROM detailpenjualan dp
     INNER JOIN produk pr
        ON dp.ProdukID = pr.ProdukID
     WHERE dp.PenjualanID = ?
     ORDER BY dp.DetailID ASC"
);

mysqli_stmt_bind_param($stmt_detail, 'i', $penjualan_id);
mysqli_stmt_execute($stmt_detail);
$query_detail = mysqli_stmt_get_result($stmt_detail);

// ======================================================
// 5. FORMAT NOMOR NOTA
// ======================================================
$format_tgl_trx = date('Ymd', strtotime($transaksi['TanggalPenjualan']));
$no_transaksi_formatted = 'TRX-' . $format_tgl_trx . '-' . str_pad((string) $transaksi['PenjualanID'], 4, '0', STR_PAD_LEFT);

// ======================================================
// 6. FUNGSI RUPIAH
// ======================================================
function rupiah($angka)
{
    return 'Rp ' . number_format((float) $angka, 0, ',', '.');
}

// ======================================================
// 7. HITUNG DETAIL
// ======================================================
$total_harga_kotor = 0;
$detail_items = [];

while ($item = mysqli_fetch_assoc($query_detail)) {
    $jumlah = (int) ($item['JumlahProduk'] ?? 0);
    $subtotal_dasar = (float) ($item['Subtotal'] ?? 0);
    $harga_satuan = (float) ($item['HargaProduk'] ?? 0);

    if ($harga_satuan <= 0 && $jumlah > 0) {
        $harga_satuan = $subtotal_dasar / $jumlah;
    }

    $total_biaya_extra = (float) ($item['BiayaExtra'] ?? 0);
    $subtotal_item = $subtotal_dasar + $total_biaya_extra;
    $total_harga_kotor += $subtotal_item;

    $item['_jumlah'] = $jumlah;
    $item['_subtotal_dasar'] = $subtotal_dasar;
    $item['_harga_satuan'] = $harga_satuan;
    $item['_total_ekstra'] = $total_biaya_extra;
    $item['_subtotal_item'] = $subtotal_item;

    $detail_items[] = $item;
}

mysqli_stmt_close($stmt_detail);

$total_harga_struk = (float) ($transaksi['TotalHarga'] ?? $total_harga_kotor);
$nilai_diskon = $total_harga_kotor - $total_harga_struk;
if ($nilai_diskon < 0) {
    $nilai_diskon = 0;
}

// ======================================================
// 8. DATA PEMBAYARAN
// ======================================================
$uang_bayar = (float) ($transaksi['Bayar'] ?? 0);
$kembalian_struk = $uang_bayar - $total_harga_struk;

// ======================================================
// 9. TIPE PESANAN
// ======================================================
$tipe_mentah = strtolower(preg_replace('/[^a-zA-Z]/', '', (string) ($transaksi['TipePesanan'] ?? $transaksi['tipe_pesanan'] ?? '')));
$label_tipe_pesanan = '';

if ($tipe_mentah === 'takeaway') {
    $label_tipe_pesanan = 'Take Away';
} elseif ($tipe_mentah === 'dinein') {
    $label_tipe_pesanan = 'Dine In';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($no_transaksi_formatted); ?> - Daily Coffee Daily Toast</title>
    <!-- Google Fonts untuk Tampilan Modern -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        * { box-sizing: border-box; }
        html, body { margin: 0; padding: 0; }
        body { 
            background: #EFECE6; 
            color: #181614; 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            font-size: 12.5px; 
            line-height: 1.5; 
        }

        .receipt { 
            width: 100%; 
            max-width: 390px; 
            margin: 30px auto; 
            background: #FFFFFF; 
            padding: 30px 24px; 
            border-radius: 16px; 
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08); 
            border: 1px solid rgba(194, 155, 56, 0.2);
        }

        .receipt-header { 
            text-align: center; 
            margin-bottom: 16px; 
        }

        .store-badge {
            display: inline-block;
            background: rgba(194, 155, 56, 0.12);
            color: #C29B38;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 1px;
            padding: 3px 10px;
            border-radius: 50px;
            margin-bottom: 8px;
            text-transform: uppercase;
        }

        .store-name { 
            margin: 0; 
            font-size: 17px; 
            font-weight: 800; 
            letter-spacing: 0.5px; 
            color: #141210;
        }

        .store-subtitle { 
            margin-top: 4px; 
            color: #666; 
            font-size: 11px; 
            line-height: 1.4; 
        }

        .header-line { 
            margin: 16px 0; 
            border-top: 1px dashed #D1D5DB; 
        }

        .transaction-info { 
            margin-bottom: 14px; 
            background: #F9FAFB;
            padding: 12px 14px;
            border-radius: 10px;
            border: 1px solid #F3F4F6;
        }

        .info-row { 
            display: flex; 
            justify-content: space-between; 
            margin-bottom: 5px; 
            align-items: center; 
        }

        .info-row:last-child {
            margin-bottom: 0;
        }

        .info-label { 
            color: #6B7280; 
            font-weight: 500;
            font-size: 11.5px;
        }

        .info-value { 
            font-weight: 600;
            color: #1F2937;
            text-align: right;
        }

        .order-type-badge { 
            display: inline-block; 
            padding: 2px 8px; 
            background: #111827;
            color: #fff;
            border-radius: 4px; 
            font-weight: 700; 
            letter-spacing: 0.5px; 
            text-transform: uppercase; 
            font-size: 10px; 
        }

        .items-section { 
            margin-top: 6px; 
        }

        .product-item { 
            padding: 12px 0; 
            border-bottom: 1px dashed #E5E7EB; 
        }

        .product-item:last-child {
            border-bottom: none;
        }

        .product-top { 
            display: flex; 
            justify-content: space-between; 
            gap: 10px; 
        }

        .product-name { 
            font-weight: 700; 
            font-size: 12.5px; 
            color: #111827; 
        }

        .product-price { 
            white-space: nowrap; 
            font-weight: 600; 
            color: #4B5563; 
        }

        .product-qty { 
            margin-top: 2px; 
            color: #6B7280; 
            font-size: 11px; 
        }

        .product-note { 
            margin-top: 6px; 
            padding: 6px 10px;
            background: #FFFBEB;
            border-left: 3px solid #F59E0B; 
            color: #92400E; 
            font-size: 11px; 
            border-radius: 0 6px 6px 0;
        }

        .product-extra { 
            display: flex; 
            justify-content: space-between; 
            margin-top: 4px; 
            color: #6B7280; 
            font-size: 11px; 
        }

        .product-subtotal { 
            display: flex; 
            justify-content: space-between; 
            margin-top: 6px; 
            font-weight: 700; 
            color: #1F2937;
        }

        .summary { 
            margin-top: 14px; 
            border-top: 1px dashed #D1D5DB; 
            padding-top: 14px;
        }

        .summary-row { 
            display: flex; 
            justify-content: space-between; 
            margin-bottom: 6px; 
            color: #4B5563;
            font-size: 12px;
        }

        .summary-row.discount {
            color: #0284C7;
            font-weight: 600;
        }

        .grand-total { 
            margin-top: 12px; 
            padding: 12px 14px; 
            background: #111827;
            color: #FFFFFF;
            border-radius: 10px;
            display: flex; 
            justify-content: space-between; 
            align-items: center;
            font-size: 14px; 
            font-weight: 800; 
        }

        .grand-total span:last-child { 
            color: #FBBF24; 
        }

        .receipt-footer { 
            text-align: center; 
            margin-top: 24px; 
            color: #6B7280; 
            font-size: 11px; 
        }

        .receipt-footer-main { 
            font-weight: 700; 
            color: #111827; 
            margin-bottom: 3px; 
        }

        .no-print { 
            margin-top: 20px; 
        }

        /* Container Tombol Aksi Berdampingan */
        .action-buttons-group {
            display: flex;
            gap: 10px;
            width: 100%;
        }

        .btn-action-custom { 
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            flex: 1;
            padding: 12px 10px; 
            border-radius: 50px; 
            font-size: 12px; 
            font-weight: 700; 
            text-decoration: none; 
            text-align: center; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transition: all 0.2s;
            cursor: pointer;
            border: none;
        }

        .btn-print-again {
            background: #C29B38;
            color: #181614;
        }

        .btn-print-again:hover {
            background: #D4AF37;
            transform: translateY(-1px);
        }

        .back-button { 
            background: #181614; 
            color: #fff; 
        }

        .back-button:hover { 
            background: #2D2A26; 
            transform: translateY(-1px);
        }

        @media print {
            @page { margin: 2mm; size: auto; }
            body { background: #fff !important; color: #000 !important; font-size: 11px; }
            .receipt { max-width: 100%; width: 100%; margin: 0; padding: 5px; border-radius: 0; box-shadow: none; border: none; }
            .no-print { display: none !important; }
            .transaction-info { background: none !important; border: 1px solid #000; padding: 6px; }
            .grand-total { background: #000 !important; color: #fff !important; border-radius: 0; }
            .grand-total span:last-child { color: #fff !important; }
        }
    </style>
</head>

<body onload="window.print()">

<div class="receipt">
    <!-- HEADER TOKO -->
    <div class="receipt-header">
        <span class="store-badge">Official Receipt</span>
        <h1 class="store-name">DAILY COFFEE & TOAST</h1>
        <div class="store-subtitle">
            Jl. Kedai Kopi No. 88, Nusantara<br>
            Telp: 0812-3456-7890
        </div>
    </div>

    <div class="header-line"></div>

    <!-- INFORMASI TRANSAKSI -->
    <div class="transaction-info">
        <div class="info-row">
            <span class="info-label">No. Nota</span>
            <span class="info-value"><strong><?= htmlspecialchars($no_transaksi_formatted); ?></strong></span>
        </div>
        <div class="info-row">
            <span class="info-label">Tanggal</span>
            <span class="info-value"><?= date('d/m/Y H:i', strtotime($transaksi['TanggalPenjualan'])); ?></span>
        </div>
        <div class="info-row">
            <span class="info-label">Kasir / Petugas</span>
            <span class="info-value"><?= !empty($transaksi['NamaUser']) ? htmlspecialchars($transaksi['NamaUser']) : 'Administrator'; ?></span>
        </div>
        <div class="info-row">
            <span class="info-label">Pelanggan</span>
            <span class="info-value"><strong><?= htmlspecialchars($transaksi['NamaFinalPelanggan']); ?></strong></span>
        </div>
        <?php if ($label_tipe_pesanan !== ''): ?>
        <div class="info-row" style="margin-top: 6px; padding-top: 6px; border-top: 1px solid #E5E7EB;">
            <span class="info-label">Tipe Pesanan</span>
            <span class="info-value"><span class="order-type-badge"><?= htmlspecialchars($label_tipe_pesanan); ?></span></span>
        </div>
        <?php endif; ?>
    </div>

    <!-- DETAIL PRODUK -->
    <div class="items-section">
        <?php if (count($detail_items) > 0): ?>
            <?php foreach ($detail_items as $item): ?>
                <div class="product-item">
                    <div class="product-top">
                        <div class="product-name"><?= htmlspecialchars($item['NamaProduk'] ?? '-'); ?></div>
                        <div class="product-price"><?= rupiah($item['_harga_satuan']); ?></div>
                    </div>

                    <div class="product-qty">Qty: <?= (int) $item['_jumlah']; ?>x</div>

                    <?php $catatan_teks = trim((string) ($item['Catatan'] ?? '')); ?>
                    <?php if ($catatan_teks !== ''): ?>
                        <div class="product-note">
                            <strong>Catatan:</strong> <?= nl2br(htmlspecialchars($catatan_teks)); ?>
                        </div>
                    <?php endif; ?>

                    <?php $total_ekstra = (float) ($item['_total_ekstra']); ?>
                    <?php if ($total_ekstra > 0): ?>
                        <div class="product-extra">
                            <span>Biaya Tambahan</span>
                            <span>+ <?= rupiah($total_ekstra); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="product-subtotal">
                        <span style="font-size: 11px; color: #6B7280; font-weight: 500;">Subtotal Item</span>
                        <span><?= rupiah($item['_subtotal_item']); ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align:center; padding:15px 0; color:#777;">
                Tidak ada detail produk.
            </div>
        <?php endif; ?>
    </div>

    <!-- RINGKASAN PEMBAYARAN -->
    <div class="summary">
        <div class="summary-row">
            <span>Subtotal Pembelian</span>
            <span><?= rupiah($total_harga_kotor); ?></span>
        </div>

        <?php if ($nilai_diskon > 0): ?>
        <div class="summary-row discount">
            <span>Diskon Member (5%)</span>
            <span>- <?= rupiah($nilai_diskon); ?></span>
        </div>
        <div class="summary-row" style="font-weight: 700; color: #111827;">
            <span>Total Akhir</span>
            <span><?= rupiah($total_harga_struk); ?></span>
        </div>
        <?php endif; ?>

        <div class="summary-row">
            <span>Tunai Diterima</span>
            <span><?= rupiah($uang_bayar); ?></span>
        </div>

        <div class="grand-total">
            <span>KEMBALIAN</span>
            <span><?= rupiah($kembalian_struk); ?></span>
        </div>
    </div>

    <!-- FOOTER -->
    <div class="receipt-footer">
        <div class="receipt-footer-main">Terima Kasih Atas Kunjungan Anda!</div>
        <div>Silakan Datang Kembali ☕✨</div>
    </div>

    <!-- TOMBOL AKSI (CETAK LAGI & KEMBALI) -->
    <div class="no-print">
        <div class="action-buttons-group">
            <button onclick="window.print()" class="btn-action-custom btn-print-again">
                <i class="bi bi-printer-fill"></i> Cetak Struk
            </button>
            <a href="<?= ($user_role === 'pelanggan') ? 'pesan-mandiri.php' : 'penjualan.php'; ?>" class="btn-action-custom back-button">
                <i class="bi bi-arrow-left"></i> Kembali
            </a>
        </div>
    </div>
</div>

</body>
</html>