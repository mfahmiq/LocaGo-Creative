<?php
include '../koneksi.php';
include 'header.php';

date_default_timezone_set('Asia/Jakarta');

$user_role_normalized = strtolower(trim($_SESSION['Role'] ?? 'kasir'));
$is_admin_login = ($user_role_normalized === 'admin');
$is_kasir_login = ($user_role_normalized === 'kasir');
$is_pelanggan_login = ($user_role_normalized === 'pelanggan');

$logged_user_id = (int)($_SESSION['UserID'] ?? 0);
$logged_pelanggan_id = (int)($_SESSION['PelangganID'] ?? 0);

$prefix_edit_admin = (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? '' : '../admin/';

/* ==========================================================
   FILTER
   ========================================================== */
$tgl_mulai = $_GET['tgl_mulai'] ?? '';
$tgl_selesai = $_GET['tgl_selesai'] ?? '';
$cari_id = trim($_GET['cari_id'] ?? '');

if (!empty($_GET['tgl'])) {
    $tgl_mulai = $_GET['tgl'];
    $tgl_selesai = $_GET['tgl'];
}

/* ==========================================================
   PAGINASI
   ========================================================== */
$limit = 20;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $limit;

/* ==========================================================
   WHERE
   ========================================================== */
$where_sql = "WHERE 1=1";
$where_sql_alias = "WHERE 1=1";

if ($tgl_mulai !== '' && $tgl_selesai !== '') {
    $mulai = mysqli_real_escape_string($koneksi, $tgl_mulai);
    $selesai = mysqli_real_escape_string($koneksi, $tgl_selesai);

    $where_sql .= " AND DATE(TanggalPenjualan) BETWEEN '$mulai' AND '$selesai'";
    $where_sql_alias .= " AND DATE(p.TanggalPenjualan) BETWEEN '$mulai' AND '$selesai'";
} elseif ($tgl_mulai !== '') {
    $mulai = mysqli_real_escape_string($koneksi, $tgl_mulai);

    $where_sql .= " AND DATE(TanggalPenjualan) >= '$mulai'";
    $where_sql_alias .= " AND DATE(p.TanggalPenjualan) >= '$mulai'";
} elseif ($tgl_selesai !== '') {
    $selesai = mysqli_real_escape_string($koneksi, $tgl_selesai);

    $where_sql .= " AND DATE(TanggalPenjualan) <= '$selesai'";
    $where_sql_alias .= " AND DATE(p.TanggalPenjualan) <= '$selesai'";
}

/* ==========================================================
   CARI ID TRANSAKSI
   ========================================================== */
if ($cari_id !== '' && ctype_digit($cari_id)) {
    $cari_aman = mysqli_real_escape_string($koneksi, $cari_id);

    $where_sql .= " AND CAST(PenjualanID AS CHAR) LIKE '%$cari_aman%'";
    $where_sql_alias .= " AND CAST(p.PenjualanID AS CHAR) LIKE '%$cari_aman%'";
}

/* ==========================================================
   HAK AKSES PELANGGAN
   ========================================================== */
if ($is_pelanggan_login) {
    if ($logged_pelanggan_id > 0) {
        $where_sql .= " AND PelangganID = $logged_pelanggan_id";
        $where_sql_alias .= " AND p.PelangganID = $logged_pelanggan_id";
    } else {
        $where_sql .= " AND 1=0";
        $where_sql_alias .= " AND 1=0";
    }
}

/* ==========================================================
   TOTAL DATA
   ========================================================== */
$query_count = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total FROM penjualan $where_sql"
);

if (!$query_count) {
    die("Query jumlah transaksi gagal: " . htmlspecialchars(mysqli_error($koneksi)));
}

$data_count = mysqli_fetch_assoc($query_count);
$total_data = (int)$data_count['total'];
$total_pages = $total_data > 0 ? ceil($total_data / $limit) : 1;

/* ==========================================================
   DATA TRANSAKSI
   ========================================================== */
$query = mysqli_query(
    $koneksi,
    "
    SELECT
        p.*,
        p.status AS StatusTransaksi,
        CASE
            WHEN p.PelangganID IS NOT NULL AND p.PelangganID > 0
                THEN pel.NamaPelanggan
            WHEN p.PelangganID IS NULL OR p.PelangganID = 0
                THEN p.NamaPelanggan
            ELSE 'Pelanggan Umum / Tamu'
        END AS NamaFinalPelanggan,
        u.NamaUser AS NamaKasir
    FROM penjualan p
    LEFT JOIN pelanggan pel ON p.PelangganID = pel.PelangganID
    LEFT JOIN user u ON p.UserID = u.UserID
    $where_sql_alias
    ORDER BY p.TanggalPenjualan DESC
    LIMIT $limit OFFSET $offset
    "
);

if (!$query) {
    die("Query transaksi gagal: " . htmlspecialchars(mysqli_error($koneksi)));
}
?>

<style>
html{scroll-behavior:smooth}
body{background:#F4F6F9!important;color:#333!important;margin:0!important;padding:0!important}
.riwayat-page-wrapper{position:relative;display:block;width:calc(100% - var(--sidebar-width))!important;min-height:100vh;padding-top:105px!important;padding-bottom:50px!important;margin:0 0 0 var(--sidebar-width)!important;box-sizing:border-box;z-index:1;clear:both}
.riwayat-page-wrapper *,.riwayat-page-wrapper *::before,.riwayat-page-wrapper *::after{box-sizing:border-box}
.riwayat-page-container{position:relative;z-index:1;width:100%;margin:0!important;padding-bottom:0!important}
.header-banner-custom{background:#FFF;border:1px solid #E2E8F0;border-radius:20px;box-shadow:0 10px 25px rgba(0,0,0,.04);padding:1.75rem 2rem}
.time-badge-box{background:#FFF;border:1px solid #E2E8F0;border-radius:12px;padding:.6rem 1rem;box-shadow:0 2px 6px rgba(0,0,0,.02)}
.card-light-custom{background:#FFF;border:1px solid #E2E8F0;border-radius:20px;box-shadow:0 10px 25px rgba(0,0,0,.05);color:#1E293B;overflow:hidden}
.search-card{background:#FFF;border:1px solid #E2E8F0;border-radius:16px;padding:1rem 1.2rem;box-shadow:0 5px 15px rgba(0,0,0,.03)}
.search-label{font-size:.72rem;font-weight:800;color:#64748B;text-transform:uppercase;letter-spacing:.5px;margin-bottom:5px}
.search-input{border:1px solid #D9E0E8!important;border-radius:50rem!important;padding:.55rem 1rem!important;font-size:.85rem!important;box-shadow:none!important}
.search-input:focus{border-color:#C49A45!important;box-shadow:0 0 0 3px rgba(196,154,69,.12)!important}
.table-custom-v2{border-collapse:separate;border-spacing:0;width:100%}
.table-custom-v2 thead th{background:#182232!important;color:#FFF!important;font-weight:700;font-size:.8rem;text-transform:uppercase;letter-spacing:.8px;padding:1.25rem 1.5rem!important;border:none;position:relative}
.table-custom-v2 thead th::after{content:'';position:absolute;bottom:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#D97706,#F59E0B)}
.table-custom-v2 td{background:#FFF!important;border-bottom:1px solid #F1F5F9!important;vertical-align:middle;color:#1E293B!important;padding:1.25rem 1.5rem!important;font-size:.9rem}
.table-custom-v2 tbody tr{transition:all .2s ease}
.table-custom-v2 tbody tr:hover td{background:#FAF8F5!important}
.time-icon-box{width:38px;height:38px;background:#FFFBEB;border:1px solid #FDE68A;border-radius:10px;display:flex;align-items:center;justify-content:center;color:#D97706;font-size:1.1rem;flex-shrink:0}
.action-container{display:flex;flex-direction:column;align-items:center;gap:7px;width:100%;min-width:180px;max-width:220px;margin:0 auto}
.action-row-top,.action-row-bottom{width:100%;display:flex;align-items:center;justify-content:center;gap:5px;flex-wrap:nowrap}
.action-divider{height:1px;background:#E2E8F0;width:100%;margin:1px 0}
.btn-action-pill,.btn-action-edit-admin{font-size:.7rem;font-weight:600;padding:4px 9px;border-radius:50rem;transition:all .2s ease;display:inline-flex;align-items:center;justify-content:center;gap:3px;text-decoration:none;background:transparent;white-space:nowrap;cursor:pointer}
.btn-action-detail{border:1px solid #0dcaf0;color:#0dcaf0}
.btn-action-detail:hover{background:#0dcaf0;color:#FFF;box-shadow:0 3px 8px rgba(13,202,240,.3)}
.btn-action-print{border:1px solid rgba(196,154,69,.6);color:#C49A45}
.btn-action-print:hover{background:#C49A45;color:#FFF;box-shadow:0 3px 8px rgba(196,154,69,.3)}
.btn-action-selesai{border:1px solid #198754;color:#198754}
.btn-action-selesai:hover{background:#198754;color:#FFF;box-shadow:0 3px 8px rgba(25,135,84,.3)}
.btn-action-batal{border:1px solid #dc3545;color:#dc3545}
.btn-action-batal:hover{background:#dc3545;color:#FFF;box-shadow:0 3px 8px rgba(220,53,69,.3)}
.btn-action-edit-admin{border:1px solid #ffc107;color:#A87900;background:#FFFDF5}
.btn-action-edit-admin:hover{background:#ffc107;color:#000;box-shadow:0 3px 8px rgba(255,193,7,.3);transform:translateY(-1px)}
.admin-edit-badge{font-size:.58rem;font-weight:800;color:#A87900;background:#FFFBEB;border:1px solid #FDE68A;border-radius:50rem;padding:2px 6px;margin-left:2px;line-height:1}
.swal2-popup{width:480px!important;max-width:calc(100% - 30px)!important;padding:2.6rem 2.2rem 2rem!important;border-radius:28px!important;border:2px solid #D9E0E8!important;box-shadow:0 20px 45px rgba(15,23,42,.25)!important;background:#FFF!important}
.swal2-html-container{margin:0!important;padding:0!important}
.popup-icon-wrap{display:flex;justify-content:center;margin-bottom:18px}
.popup-icon{width:76px;height:76px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:2.15rem;font-weight:700;border:3px solid var(--popup-color);color:var(--popup-color);background:var(--popup-bg);box-shadow:0 9px 22px var(--popup-shadow)}
.popup-title{margin:0 0 8px;color:#263247;font-size:1.4rem;font-weight:800}
.popup-message{margin:0 auto;max-width:390px;color:#71809A;font-size:.9rem;line-height:1.45}
.popup-number{color:#5E6E87;font-weight:800;white-space:nowrap}
.popup-actions{display:flex;gap:12px;width:100%;margin-top:38px}
.popup-btn{flex:1;min-height:54px;border-radius:30px!important;font-size:.95rem!important;font-weight:800!important;border:1px solid transparent!important;transition:all .2s ease!important;cursor:pointer}
.popup-btn-confirm{color:#FFF!important;background:var(--popup-button)!important;box-shadow:0 6px 14px var(--popup-shadow)}
.popup-btn-confirm:hover{transform:translateY(-2px);filter:brightness(.96)}
.popup-btn-cancel{color:#707A87!important;background:#F8FAFC!important;border:1px solid #D9E0E8!important}
.popup-btn-cancel:hover{background:#F1F5F9!important;color:#4B5563!important}
.popup-subtext{margin-top:13px;color:#94A3B8;font-size:.76rem}
.popup-selesai{--popup-color:#D97706;--popup-bg:#FFF4CC;--popup-button:#176B3A;--popup-shadow:rgba(22,101,52,.25)}
.popup-batal{--popup-color:#DC2626;--popup-bg:#FFE4E6;--popup-button:#C62828;--popup-shadow:rgba(220,38,38,.24)}
.popup-ubah{--popup-color:#B8860B;--popup-bg:#FFF4CC;--popup-button:#B8860B;--popup-shadow:rgba(184,134,11,.25)}
.popup-selesaiOk{--popup-color:#059669;--popup-bg:#DDF7EA;--popup-button:#087F5B;--popup-shadow:rgba(5,150,105,.25)}
.popup-batalOk{--popup-color:#64748B;--popup-bg:#EEF2F6;--popup-button:#475569;--popup-shadow:rgba(71,85,105,.22)}
.popup-gagal{--popup-color:#EA580C;--popup-bg:#FFEDD5;--popup-button:#C2410C;--popup-shadow:rgba(234,88,12,.25)}
@media(max-width:1200px){.action-container{min-width:175px;max-width:200px}.btn-action-pill,.btn-action-edit-admin{font-size:.65rem;padding:4px 7px}}
@media(max-width:768px){.riwayat-page-wrapper{padding-top:95px!important;padding-bottom:35px!important}.riwayat-page-container{padding-left:.75rem!important;padding-right:.75rem!important}.header-banner-custom{padding:1.35rem 1.25rem;border-radius:16px}.action-container{min-width:175px;max-width:190px}.swal2-popup{width:calc(100% - 30px)!important;padding:2.2rem 1.4rem 1.6rem!important;border-radius:24px!important}.popup-icon{width:68px;height:68px;font-size:1.9rem}}
@media(max-width:576px){.riwayat-page-wrapper{padding-top:90px!important}.riwayat-page-container{padding-left:.5rem!important;padding-right:.5rem!important}.action-container{min-width:170px;max-width:185px}.popup-actions{flex-direction:column}.popup-btn{width:100%}}
</style>

<div class="riwayat-page-wrapper">
    <div class="container-fluid px-4 riwayat-page-container">

        <div class="header-banner-custom mb-4">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <span class="badge px-3 py-1.5 rounded-pill mb-2 fw-bold"
                          style="background:rgba(234,179,8,.15);color:#B45309;border:1px solid rgba(234,179,8,.3);font-size:.75rem;letter-spacing:.5px;">
                        <i class="bi bi-receipt-cutoff me-1"></i>
                        MANAJEMEN PENJUALAN
                    </span>

                    <h3 class="fw-extrabold text-dark mb-1"
                        style="font-size:1.75rem;letter-spacing:-.5px;">
                        <?= $is_pelanggan_login ? 'Riwayat Pesanan Saya' : 'Riwayat Transaksi & Kasir'; ?>
                    </h3>

                    <p class="text-muted small mb-0">
                        <?= $is_pelanggan_login
                            ? 'Daftar pesanan yang dilakukan oleh akun Anda.'
                            : 'Daftar seluruh transaksi penjualan yang masuk secara real-time di Daily Coffee & Toast.'; ?>
                    </p>
                </div>

                <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">
                    <div class="d-inline-flex align-items-center gap-2 time-badge-box text-start">
                        <i class="bi bi-clock-history text-warning fs-4"></i>
                        <div>
                            <div class="text-muted"
                                 style="font-size:.7rem;text-transform:uppercase;font-weight:600;letter-spacing:.5px;">
                                Waktu Akses Sistem
                            </div>
                            <div class="fw-bold text-dark"
                                 style="font-size:.85rem;"
                                 id="realtime-clock">
                                Memuat waktu...
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="search-card mb-4">
            <form method="GET">
                <div class="row g-3 align-items-end">

                    <div class="col-lg-4 col-md-6">
                        <label class="search-label">
                            <i class="bi bi-search me-1"></i>
                            Cari Nomor Transaksi
                        </label>
                        <input type="text"
                               name="cari_id"
                               value="<?= htmlspecialchars($cari_id); ?>"
                               class="form-control search-input"
                               placeholder="Contoh: 73"
                               inputmode="numeric"
                               pattern="[0-9]*">
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <label class="search-label">Tanggal Mulai</label>
                        <input type="date"
                               name="tgl_mulai"
                               value="<?= htmlspecialchars($tgl_mulai); ?>"
                               class="form-control search-input">
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <label class="search-label">Tanggal Selesai</label>
                        <input type="date"
                               name="tgl_selesai"
                               value="<?= htmlspecialchars($tgl_selesai); ?>"
                               class="form-control search-input">
                    </div>

                    <div class="col-lg-2 col-md-6 d-flex gap-2">
                        <button type="submit"
                                class="btn btn-dark rounded-pill flex-grow-1 fw-semibold">
                            <i class="bi bi-search me-1"></i>
                            Cari
                        </button>

                        <a href="riwayat-transaksi.php"
                           class="btn btn-outline-secondary rounded-pill"
                           title="Reset">
                            <i class="bi bi-arrow-counterclockwise"></i>
                        </a>
                    </div>

                </div>
            </form>
        </div>

        <div class="row mb-4 align-items-center">
            <div class="col-md-6">
                <h5 class="fw-bold text-dark mb-0">
                    <?= $is_pelanggan_login ? 'Pesanan Saya' : 'Data Transaksi Penjualan'; ?>
                </h5>

                <?php if ($cari_id !== ''): ?>
                    <small class="text-muted">
                        Hasil pencarian ID mengandung:
                        <strong><?= htmlspecialchars($cari_id); ?></strong>
                    </small>
                <?php endif; ?>
            </div>

            <div class="col-md-6 text-md-end mt-3 mt-md-0">
                <a href="riwayat-transaksi.php"
                   class="btn btn-dark btn-sm rounded-pill px-3 fw-semibold me-1 shadow-sm">
                    Semua Transaksi
                </a>

                <a href="riwayat-transaksi.php?tgl=<?= date('Y-m-d'); ?>"
                   class="btn btn-outline-dark btn-sm rounded-pill px-3 fw-semibold">
                    Transaksi Hari Ini
                </a>
            </div>
        </div>

        <div class="card card-light-custom shadow-sm mb-4">
            <div class="table-responsive">

                <table class="table table-custom-v2 align-middle mb-0">

                    <thead>
                        <tr>
                            <th>No. Transaksi</th>
                            <th>Waktu &amp; Tanggal</th>
                            <th>Pelanggan</th>
                            <th>Total Harga</th>
                            <th>Keterangan Status</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php if (mysqli_num_rows($query) > 0): ?>

                        <?php while ($row = mysqli_fetch_assoc($query)): ?>

                            <?php
                            $id_transaksi = (int)$row['PenjualanID'];

                            $nama_pelanggan = !empty($row['NamaFinalPelanggan'])
                                ? $row['NamaFinalPelanggan']
                                : 'Pelanggan Umum / Tamu';

                            $status_transaksi = strtolower(
                                trim((string)($row['StatusTransaksi'] ?? 'proses'))
                            );

                            if ($status_transaksi === 'batal') {
                                $status_transaksi = 'dibatalkan';
                            }

                            if ($status_transaksi === 'berhasil') {
                                $status_transaksi = 'proses';
                            }

                            if ($status_transaksi === '') {
                                $status_transaksi = 'proses';
                            }

                            $format_tgl_trx = date(
                                'Ymd',
                                strtotime($row['TanggalPenjualan'])
                            );

                            $no_transaksi_formatted =
                                'TRX-' .
                                $format_tgl_trx .
                                '-' .
                                str_pad($id_transaksi, 4, '0', STR_PAD_LEFT);

                            $formatted_date = date(
                                'd M Y',
                                strtotime($row['TanggalPenjualan'])
                            );

                            $formatted_time =
                                date(
                                    'H:i:s',
                                    strtotime($row['TanggalPenjualan'])
                                ) . ' WIB';
                            ?>

                            <tr data-no="<?= htmlspecialchars($no_transaksi_formatted); ?>"
                                data-status="<?= htmlspecialchars($status_transaksi); ?>">

                                <td>
                                    <span class="badge bg-light text-dark border px-2.5 py-1.5 fw-bold"
                                          style="font-size:.8rem;font-family:monospace;">
                                        <?= htmlspecialchars($no_transaksi_formatted); ?>
                                    </span>
                                </td>

                                <td>
                                    <div class="d-flex align-items-center gap-3">
                                        <div class="time-icon-box">
                                            <i class="bi bi-clock-history"></i>
                                        </div>

                                        <div>
                                            <div class="fw-bold text-dark">
                                                <?= htmlspecialchars($formatted_date); ?>
                                            </div>

                                            <div class="text-muted" style="font-size:.8rem;">
                                                <?= htmlspecialchars($formatted_time); ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <td>
                                    <div class="fw-bold text-dark">
                                        <?= htmlspecialchars($nama_pelanggan); ?>
                                    </div>

                                    <?php if ($status_transaksi === 'selesai'): ?>

                                        <span class="badge mt-1 bg-success text-white"
                                              style="font-size:.7rem;font-weight:600;">
                                            <i class="bi bi-check-circle me-1"></i>
                                            Selesai (Lunas)
                                        </span>

                                    <?php elseif ($status_transaksi === 'dibatalkan'): ?>

                                        <span class="badge mt-1 bg-danger text-white"
                                              style="font-size:.7rem;font-weight:600;">
                                            <i class="bi bi-x-circle me-1"></i>
                                            Dibatalkan (Void)
                                        </span>

                                    <?php else: ?>

                                        <span class="badge mt-1"
                                              style="background:#FEF3C7;color:#D97706;font-size:.7rem;font-weight:600;border:1px solid #FDE68A;">
                                            <i class="bi bi-hourglass-split me-1"></i>
                                            Sedang Proses
                                        </span>

                                    <?php endif; ?>
                                </td>

                                <td class="fw-bold text-success" style="font-size:.95rem;">
                                    Rp <?= number_format(
                                        $row['TotalHarga'],
                                        0,
                                        ',',
                                        '.'
                                    ); ?>
                                </td>

                                <td class="text-muted"
                                    style="font-size:.85rem;max-width:250px;">

                                    <?php if ($status_transaksi === 'selesai'): ?>

                                        Pesanan lunas &amp; diserahkan ke pelanggan.

                                    <?php elseif ($status_transaksi === 'dibatalkan'): ?>

                                        Transaksi dibatalkan &amp; stok dikembalikan.

                                    <?php else: ?>

                                        Pesanan sedang disiapkan di bar/dapur.

                                    <?php endif; ?>

                                </td>

                                <td class="text-center">

                                    <div class="action-container">

                                        <!-- AKSI STATUS -->
                                        <div class="action-row-top">

                                            <?php if ($status_transaksi === 'proses'): ?>

                                                <!-- ADMIN & KASIR: SELESAI -->
                                                <?php if ($is_admin_login || $is_kasir_login): ?>

                                                    <button type="button"
                                                            class="btn-action-pill btn-action-selesai btn-konfirmasi-status"
                                                            data-aksi="selesai"
                                                            data-no="<?= htmlspecialchars($no_transaksi_formatted); ?>"
                                                            data-url="transaksi-status.php?id=<?= $id_transaksi; ?>&aksi=selesai">

                                                        <i class="bi bi-check-all"></i>
                                                        Selesai

                                                    </button>

                                                <?php endif; ?>

                                                <!-- ADMIN, KASIR & PELANGGAN: BATAL -->
                                                <?php if ($is_admin_login || $is_kasir_login || $is_pelanggan_login): ?>

                                                    <button type="button"
                                                            class="btn-action-pill btn-action-batal btn-konfirmasi-status"
                                                            data-aksi="batal"
                                                            data-no="<?= htmlspecialchars($no_transaksi_formatted); ?>"
                                                            data-url="transaksi-status.php?id=<?= $id_transaksi; ?>&aksi=batal">

                                                        <i class="bi bi-x-circle"></i>
                                                        Batal

                                                    </button>

                                                <?php endif; ?>

                                            <?php elseif ($status_transaksi === 'selesai'): ?>

                                                <span class="badge bg-light text-secondary border px-2 py-1"
                                                      style="font-size:.7rem;">
                                                    <i class="bi bi-lock-fill me-1"></i>
                                                    Terkunci
                                                </span>

                                            <?php elseif ($status_transaksi === 'dibatalkan'): ?>

                                                <span class="badge bg-light text-danger border px-2 py-1"
                                                      style="font-size:.7rem;">
                                                    <i class="bi bi-slash-circle me-1"></i>
                                                    Dibatalkan
                                                </span>

                                            <?php endif; ?>

                                        </div>

                                        <div class="action-divider"></div>

                                        <!-- DETAIL / CETAK / EDIT -->
                                        <div class="action-row-bottom">

                                            <a href="../kasir/detail-transaksi.php?id=<?= $id_transaksi; ?>"
                                               class="btn-action-pill btn-action-detail"
                                               title="Lihat Rincian Menu">

                                                <i class="bi bi-eye"></i>
                                                Detail

                                            </a>

                                            <a href="../kasir/cetak-struk.php?id=<?= $id_transaksi; ?>"
                                               target="_blank"
                                               class="btn-action-pill btn-action-print"
                                               title="Cetak Struk">

                                                <i class="bi bi-printer"></i>
                                                Cetak

                                            </a>

                                            <!-- EDIT HANYA ADMIN -->
                                            <?php if ($is_admin_login && $status_transaksi === 'proses'): ?>

                                                <a href="<?= $prefix_edit_admin; ?>admin-transaksi-edit.php?id=<?= $id_transaksi; ?>"
                                                   class="btn-action-edit-admin btn-konfirmasi-edit"
                                                   data-no="<?= htmlspecialchars($no_transaksi_formatted); ?>"
                                                   title="Edit Transaksi (Admin)">

                                                    <i class="bi bi-pencil-square"></i>
                                                    Edit

                                                </a>

                                            <?php endif; ?>

                                        </div>

                                    </div>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="6"
                                class="text-center text-muted py-5">

                                <i class="bi bi-inbox fs-2 d-block mb-2 text-warning opacity-50"></i>

                                <?php if ($is_pelanggan_login): ?>

                                    Belum ada pesanan yang dilakukan oleh akun Anda.

                                <?php elseif ($cari_id !== ''): ?>

                                    Transaksi dengan ID
                                    <strong><?= htmlspecialchars($cari_id); ?></strong>
                                    tidak ditemukan.

                                <?php else: ?>

                                    Belum ada data transaksi yang tercatat.

                                <?php endif; ?>

                            </td>
                        </tr>

                    <?php endif; ?>

                    </tbody>
                </table>
            </div>

            <?php if ($total_pages > 1): ?>

                <div class="card-footer bg-white border-0 py-3">
                    <nav>
                        <ul class="pagination justify-content-center mb-0">

                            <?php
                            $query_params = [
                                'cari_id' => $cari_id,
                                'tgl_mulai' => $tgl_mulai,
                                'tgl_selesai' => $tgl_selesai
                            ];
                            ?>

                            <li class="page-item <?= $page <= 1 ? 'disabled' : ''; ?>">

                                <?php $query_params['page'] = max(1, $page - 1); ?>

                                <a class="page-link"
                                   href="?<?= http_build_query($query_params); ?>">
                                    Sebelumnya
                                </a>

                            </li>

                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>

                                <?php $query_params['page'] = $i; ?>

                                <li class="page-item <?= $page == $i ? 'active' : ''; ?>">

                                    <a class="page-link <?= $page == $i ? 'bg-warning text-dark border-warning fw-bold' : ''; ?>"
                                       href="?<?= http_build_query($query_params); ?>">
                                        <?= $i; ?>
                                    </a>

                                </li>

                            <?php endfor; ?>

                            <li class="page-item <?= $page >= $total_pages ? 'disabled' : ''; ?>">

                                <?php $query_params['page'] = min($total_pages, $page + 1); ?>

                                <a class="page-link"
                                   href="?<?= http_build_query($query_params); ?>">
                                    Selanjutnya
                                </a>

                            </li>

                        </ul>
                    </nav>
                </div>

            <?php endif; ?>

        </div>
    </div>
</div>

<script src="../asset/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

<script>
function updateClock(){
    const now=new Date();

    const timeString=now.toLocaleTimeString('id-ID',{
        timeZone:'Asia/Jakarta',
        hour:'2-digit',
        minute:'2-digit',
        second:'2-digit',
        hour12:false
    }).replace(/\./g,':');

    const dateParts=now.toLocaleDateString('id-ID',{
        timeZone:'Asia/Jakarta',
        day:'numeric',
        month:'short',
        year:'numeric'
    }).split(' ');

    const clock=document.getElementById('realtime-clock');

    if(clock){
        clock.textContent=`${dateParts[0]} ${dateParts[1]} ${dateParts[2]}, ${timeString} WIB`;
    }
}

updateClock();
setInterval(updateClock,1000);

const POPUP={
    selesai:{
        warna:'#D97706',
        bg:'#FFF4CC',
        tombol:'#176B3A',
        shadow:'rgba(22,101,52,.25)',
        icon:'bi-question-lg',
        judul:'Yakin Ingin Menyelesaikan?',
        tombolYa:'Ya, Selesaikan'
    },

    batal:{
        warna:'#DC2626',
        bg:'#FFE4E6',
        tombol:'#C62828',
        shadow:'rgba(220,38,38,.25)',
        icon:'bi-x-lg',
        judul:'Yakin Ingin Membatalkan?',
        tombolYa:'Ya, Batalkan'
    },

    ubah:{
        warna:'#B8860B',
        bg:'#FFF4CC',
        tombol:'#B8860B',
        shadow:'rgba(184,134,11,.25)',
        icon:'bi-pencil',
        judul:'Yakin Ingin Mengubah?',
        tombolYa:'Ya, Ubah'
    },

    selesaiOk:{
        warna:'#059669',
        bg:'#DDF7EA',
        tombol:'#087F5B',
        shadow:'rgba(5,150,105,.25)',
        icon:'bi-check-lg',
        judul:'Transaksi Berhasil Diselesaikan',
        tombolYa:'Baik, Mengerti'
    },

    batalOk:{
        warna:'#64748B',
        bg:'#EEF2F6',
        tombol:'#475569',
        shadow:'rgba(71,85,105,.22)',
        icon:'bi-x-lg',
        judul:'Transaksi Berhasil Dibatalkan',
        tombolYa:'Baik, Mengerti'
    },

    gagal:{
        warna:'#EA580C',
        bg:'#FFEDD5',
        tombol:'#C2410C',
        shadow:'rgba(234,88,12,.25)',
        icon:'bi-exclamation-lg',
        judul:'Perubahan Belum Berhasil',
        tombolYa:'Coba Lagi'
    }
};

function tampilPopup(o){
    const t=POPUP[o.tema];

    const nomor=o.no
        ? `<span class="popup-number">${o.no}</span>`
        : '';

    return Swal.fire({
        html:`
            <div class="popup-icon-wrap">
                <div class="popup-icon"
                     style="--popup-color:${t.warna};--popup-bg:${t.bg};--popup-shadow:${t.shadow};">
                    <i class="bi ${t.icon}"></i>
                </div>
            </div>

            <h2 class="popup-title">${o.judul}</h2>

            <div class="popup-message">
                ${o.pesan || ''}
                ${nomor ? `<br>${nomor}` : ''}
            </div>

            <div class="popup-actions">

                <button type="button"
                        class="popup-btn popup-btn-confirm"
                        style="--popup-button:${t.tombol};--popup-shadow:${t.shadow};">
                    ${o.yaText || t.tombolYa}
                </button>

                ${o.batalText ? `
                    <button type="button"
                            class="popup-btn popup-btn-cancel">
                        ${o.batalText}
                    </button>
                ` : ''}

            </div>

            ${o.catatan ? `
                <div class="popup-subtext">
                    ${o.catatan}
                </div>
            ` : ''}
        `,

        showConfirmButton:false,
        showCancelButton:false,
        allowOutsideClick:!o.batalText,
        allowEscapeKey:true,
        background:'#FFFFFF',
        backdrop:'rgba(15,23,42,.58)',

        showClass:{
            popup:'animate__animated animate__zoomIn animate__faster'
        },

        hideClass:{
            popup:'animate__animated animate__zoomOut animate__faster'
        },

        customClass:{
            popup:'popup-'+o.tema
        },

        didOpen:function(){
            const popup=Swal.getPopup();

            if(!popup)return;

            const confirmBtn=popup.querySelector('.popup-btn-confirm');
            const cancelBtn=popup.querySelector('.popup-btn-cancel');

            if(confirmBtn){
                confirmBtn.addEventListener('click',function(){
                    Swal.close({
                        isConfirmed:true
                    });
                });
            }

            if(cancelBtn){
                cancelBtn.addEventListener('click',function(){
                    Swal.close({
                        isConfirmed:false
                    });
                });
            }
        }
    });
}

document.addEventListener('DOMContentLoaded',function(){

    /* ======================================================
       SELESAI & BATAL
       ====================================================== */
    document.querySelectorAll('.btn-konfirmasi-status')
        .forEach(function(button){

        button.addEventListener('click',function(e){

            e.preventDefault();

            const aksi=this.getAttribute('data-aksi');
            const no=this.getAttribute('data-no');
            const targetUrl=this.getAttribute('data-url');

            if(aksi==='selesai'){

                tampilPopup({
                    tema:'selesai',
                    judul:POPUP.selesai.judul,
                    pesan:'Anda akan menandai transaksi ini sebagai <b>Selesai</b>.',
                    no:no,
                    catatan:'Setelah selesai, transaksi akan terkunci dan tidak dapat diubah lagi.',
                    yaText:'<i class="bi bi-check2-all me-1"></i> Ya, Selesaikan',
                    batalText:'Nanti Saja'
                }).then(function(result){

                    if(result.isConfirmed){

                        sessionStorage.setItem(
                            'statusPending',
                            JSON.stringify({
                                no:no,
                                aksi:aksi,
                                harapan:'selesai'
                            })
                        );

                        window.location.href=targetUrl;
                    }
                });

            }else{

                tampilPopup({
                    tema:'batal',
                    judul:POPUP.batal.judul,
                    pesan:'Anda akan membatalkan transaksi ini.',
                    no:no,
                    catatan:'Pesanan yang dibatalkan tidak dapat diproses kembali.',
                    yaText:'<i class="bi bi-x-circle me-1"></i> Ya, Batalkan',
                    batalText:'Jangan Batalkan'
                }).then(function(result){

                    if(result.isConfirmed){

                        sessionStorage.setItem(
                            'statusPending',
                            JSON.stringify({
                                no:no,
                                aksi:aksi,
                                harapan:'dibatalkan'
                            })
                        );

                        window.location.href=targetUrl;
                    }
                });
            }
        });
    });

    /* ======================================================
       EDIT ADMIN
       ====================================================== */
    document.querySelectorAll('.btn-konfirmasi-edit')
        .forEach(function(link){

        link.addEventListener('click',function(e){

            e.preventDefault();

            const targetUrl=this.getAttribute('href');
            const no=this.getAttribute('data-no');

            tampilPopup({
                tema:'ubah',
                judul:POPUP.ubah.judul,
                pesan:'Anda akan membuka halaman untuk <b>mengubah data transaksi</b> ini.',
                no:no,
                catatan:'Pastikan perubahan yang dilakukan sudah sesuai sebelum disimpan.',
                yaText:'<i class="bi bi-pencil-square me-1"></i> Ya, Ubah',
                batalText:'Nanti Saja'
            }).then(function(result){

                if(result.isConfirmed){
                    window.location.href=targetUrl;
                }
            });
        });
    });

    /* ======================================================
       NOTIFIKASI HASIL STATUS
       ====================================================== */
    const pendingRaw=sessionStorage.getItem('statusPending');

    if(pendingRaw){

        sessionStorage.removeItem('statusPending');

        let pending=null;

        try{
            pending=JSON.parse(pendingRaw);
        }catch(err){
            pending=null;
        }

        if(pending){

            const baris=Array.from(
                document.querySelectorAll('tr[data-no]')
            ).find(function(tr){
                return tr.getAttribute('data-no')===pending.no;
            });

            const berhasil=
                !baris ||
                baris.getAttribute('data-status')===pending.harapan;

            if(!berhasil){

                tampilPopup({
                    tema:'gagal',
                    judul:POPUP.gagal.judul,
                    pesan:'Status transaksi belum berubah seperti yang diharapkan.',
                    no:pending.no,
                    catatan:'Silakan periksa transaksi tersebut dan coba kembali.',
                    yaText:'<i class="bi bi-arrow-repeat me-1"></i> Coba Lagi'
                });

            }else if(pending.aksi==='selesai'){

                tampilPopup({
                    tema:'selesaiOk',
                    judul:POPUP.selesaiOk.judul,
                    pesan:'Status transaksi <b>Selesai</b> telah berhasil disimpan.',
                    no:pending.no,
                    catatan:'Transaksi sekarang terkunci dan tidak dapat diubah lagi.',
                    yaText:'<i class="bi bi-check-lg me-1"></i> Baik, Mengerti'
                });

            }else{

                tampilPopup({
                    tema:'batalOk',
                    judul:POPUP.batalOk.judul,
                    pesan:'Status transaksi <b>Dibatalkan</b> telah berhasil disimpan.',
                    no:pending.no,
                    catatan:'Pesanan berhasil dibatalkan.',
                    yaText:'<i class="bi bi-check-lg me-1"></i> Baik, Mengerti'
                });
            }
        }
    }
});
</script>

</body>
</html>