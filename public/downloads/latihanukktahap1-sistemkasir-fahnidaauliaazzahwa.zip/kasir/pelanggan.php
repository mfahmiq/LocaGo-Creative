<?php
// Pastikan session sudah aktif dengan benar
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'header.php'; 

// Proses Tambah Member Baru jika Form Disubmit dari Modal Konfirmasi
if (isset($_POST['tambah_member'])) {
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama_pelanggan']);
    $alamat = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    $nomor_telepon = mysqli_real_escape_string($koneksi, $_POST['nomor_telepon']);

    $q_insert = mysqli_query($koneksi, "INSERT INTO pelanggan (NamaPelanggan, Alamat, NomorTelepon) VALUES ('$nama', '$alamat', '$nomor_telepon')");

    if ($q_insert) {
        // Catat ke Audit Log Aktivitas jika session Username tersedia
        if (isset($_SESSION['Username'])) {
            $user_log = $_SESSION['Username'];
            $aktivitas_log = "Tambah Member";
            $deskripsi_log = "Menambahkan member baru dengan nama: " . $nama;
            
            // Cek apakah tabel audit_log atau log_aktivitas yang digunakan di sistem Anda
            mysqli_query($koneksi, "INSERT INTO audit_log (username, aktivitas, waktu, deskripsi) VALUES ('$user_log', '$aktivitas_log', NOW(), '$deskripsi_log')");
        }

        echo "<script>alert('Member baru berhasil ditambahkan!'); window.location='pelanggan.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan member!');</script>";
    }
}

// Query Ambil Data Pelanggan beserta Tanggal Transaksi Terakhir & Jumlah Transaksi
$q_pelanggan = mysqli_query($koneksi, "
    SELECT p.*, MAX(penjualan.TanggalPenjualan) AS transaksi_terakhir,
    (SELECT COUNT(*) FROM penjualan WHERE penjualan.PelangganID = p.PelangganID) AS jumlah_transaksi
    FROM pelanggan p 
    LEFT JOIN penjualan ON p.PelangganID = penjualan.PelangganID 
    GROUP BY p.PelangganID 
    ORDER BY p.PelangganID DESC
");

// Deteksi Role User yang sedang login berdasarkan $_SESSION['Role'] dari proses-login.php
$role_user = '';
if (isset($_SESSION['Role'])) {
    $role_user = strtolower(trim($_SESSION['Role']));
} elseif (isset($_SESSION['role'])) {
    $role_user = strtolower(trim($_SESSION['role']));
} elseif (isset($_SESSION['level'])) {
    $role_user = strtolower(trim($_SESSION['level']));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Member Pelanggan - Daily Coffee & Toast</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <style>
        body {
            background-color: #FAF8F5;
        }

        .wrapper-konten-pelanggan {
            margin-top: 105px;
            margin-left: 290px;
            padding-right: 35px;
            padding-bottom: 50px;
        }

        @media (max-width: 992px) {
            .wrapper-konten-pelanggan {
                margin-left: 20px;
                margin-right: 20px;
            }
        }

        .table-container-card {
            background: #FFFFFF;
            border-radius: 22px;
            border: 1px solid rgba(231, 229, 228, 0.9);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.04);
            overflow: hidden;
        }

        .custom-table thead {
            background-color: #FAF8F5;
            border-bottom: 2px solid rgba(196, 154, 69, 0.15);
        }

        .custom-table th {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #78716C;
            padding: 1.1rem 1.5rem;
            font-weight: 700;
        }

        .custom-table td {
            padding: 1.1rem 1.5rem;
            color: #292524;
            font-size: 0.925rem;
        }

        .custom-table tbody tr {
            transition: all 0.2s ease;
        }

        .custom-table tbody tr:hover {
            background-color: rgba(196, 154, 69, 0.04);
        }

        .badge-member-id {
            background: rgba(196, 154, 69, 0.12);
            color: #C49A45;
            border: 1px solid rgba(196, 154, 69, 0.3);
            font-weight: 800;
            font-size: 0.8rem;
            padding: 6px 12px;
            border-radius: 10px;
            letter-spacing: 0.5px;
        }

        .search-input-custom {
            border-radius: 14px;
            padding: 0.65rem 1.2rem;
            border: 1px solid #E7E5E4;
            font-size: 0.9rem;
        }

        .search-input-custom:focus {
            border-color: #C49A45;
            box-shadow: 0 0 0 4px rgba(196, 154, 69, 0.1);
        }

        /* --- STYLING CUSTOM POP-UP / MODAL --- */
        .modal-custom-style .modal-content {
            border-radius: 28px;
            border: none;
            box-shadow: 0 20px 45px rgba(0, 0, 0, 0.12);
            padding: 1rem 1rem 1.5rem 1rem;
        }

        .popup-icon-container {
            width: 75px;
            height: 75px;
            background: #FEF3C7; 
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 15px auto 20px auto;
            color: #D97706; 
            font-size: 2.2rem;
            font-weight: bold;
            box-shadow: 0 4px 12px rgba(245, 158, 11, 0.15);
        }

        .popup-icon-danger {
            background: #FEE2E2; 
            color: #DC2626; 
            box-shadow: 0 4px 12px rgba(220, 38, 38, 0.15);
        }

        .btn-green-confirm {
            background-color: #195834 !important; 
            color: #FFFFFF !important;
            border-radius: 16px;
            padding: 0.75rem 1.5rem;
            font-weight: 700;
            border: none;
            transition: all 0.2s ease;
        }
        .btn-green-confirm:hover {
            background-color: #144629 !important;
            transform: translateY(-1px);
        }

        .btn-outline-cancel {
            background-color: #FFFFFF;
            color: #44403C;
            border: 1px solid #D6D3D1;
            border-radius: 16px;
            padding: 0.75rem 1.5rem;
            font-weight: 700;
            transition: all 0.2s ease;
        }
        .btn-outline-cancel:hover {
            background-color: #F5F5F4;
            color: #1C1917;
        }

        .btn-red-confirm {
            background-color: #DC2626 !important;
            color: #FFFFFF !important;
            border-radius: 16px;
            padding: 0.75rem 1.5rem;
            font-weight: 700;
            border: none;
            transition: all 0.2s ease;
        }
        .btn-red-confirm:hover {
            background-color: #B91C1C !important;
            transform: translateY(-1px);
        }
    </style>
</head>
<body>

<div class="wrapper-konten-pelanggan">
    <div class="container-fluid">
        
        <!-- Header Halaman & Tombol Aksi -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 bg-white p-4 rounded-4 shadow-sm border">
            <div>
                <span class="badge px-3 py-1.5 rounded-pill fw-bold mb-2" style="background: rgba(196, 154, 69, 0.15); color: #C49A45; border: 1px solid rgba(196, 154, 69, 0.3);">
                    <i class="bi bi-people-fill me-1"></i> MANAJEMEN MEMBER
                </span>
                <h3 class="fw-extrabold mb-1" style="color: #141211; letter-spacing: -0.5px;">
                    Data Member Pelanggan
                </h3>
                <p class="text-muted small mb-0">Kelola keanggotaan dan pantau jumlah transaksi pelanggan.</p>
            </div>

            <!-- Tombol Tambah Member -->
            <button type="button" class="btn px-4 py-2.5 fw-bold rounded-3 shadow-sm text-white d-inline-flex align-items-center justify-content-center gap-2 text-nowrap" style="background: linear-gradient(135deg, #C49A45 0%, #A37B2C 100%); border: none;" data-bs-toggle="modal" data-bs-target="#modalTambahMember">
                <i class="bi bi-person-plus-fill fs-6"></i>
                <span>Tambah Member Baru</span>
            </button>
        </div>

        <!-- Main Card Container -->
        <div class="table-container-card p-4">
            <!-- Search & Info Bar -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
                <div class="d-flex align-items-center gap-2">
                    <div class="rounded-circle d-flex align-items-center justify-content-center text-warning" style="background: rgba(196, 154, 69, 0.12); width: 40px; height: 40px;">
                        <i class="bi bi-card-heading fs-5"></i>
                    </div>
                    <div>
                        <h6 class="fw-bold mb-0">Daftar Member Active</h6>
                        <small class="text-muted">Gunakan ID Member saat transaksi di kasir</small>
                    </div>
                </div>

                <!-- Field Pencarian -->
                <div class="position-relative" style="min-width: 280px;">
                    <input type="text" id="searchMember" class="form-control search-input-custom ps-5" placeholder="Cari ID, Nama, No. HP..." onkeyup="filterMember()">
                    <i class="bi bi-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
                </div>
            </div>

            <!-- Tabel Member -->
            <div class="table-responsive">
                <table class="table custom-table align-middle mb-0" id="tabelPelanggan">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>ID Member</th>
                            <th>Nama Member</th>
                            <th>No. Telepon</th>
                            <th class="text-center">Total Transaksi</th>
                            <th>Transaksi Terakhir</th>
                            <th class="text-center" width="150">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($q_pelanggan) > 0): ?>
                            <?php $no = 1; while ($row = mysqli_fetch_assoc($q_pelanggan)): 
                                $formatted_id = "DAILYMBR" . $row['PelangganID'];
                                $jml_trx = $row['jumlah_transaksi'];
                                $ada_transaksi = ($jml_trx > 0);
                            ?>
                            <tr class="row-member" data-search="<?= strtolower($formatted_id . ' ' . $row['NamaPelanggan'] . ' ' . $row['NomorTelepon']); ?>">
                                <td class="fw-bold text-muted"><?= sprintf('%02d', $no++); ?></td>
                                <td>
                                    <span class="badge-member-id">
                                        <i class="bi bi-qr-code me-1"></i><?= $formatted_id; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="rounded-circle bg-light text-dark fw-bold d-flex align-items-center justify-content-center border" style="width: 32px; height: 32px; font-size: 0.8rem;">
                                            <?= strtoupper(substr($row['NamaPelanggan'], 0, 1)); ?>
                                        </div>
                                        <span class="fw-bold text-dark"><?= htmlspecialchars($row['NamaPelanggan']); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <span class="fw-semibold text-secondary">
                                        <i class="bi bi-telephone me-1 text-muted"></i><?= !empty($row['NomorTelepon']) ? htmlspecialchars($row['NomorTelepon']) : '-'; ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-light text-dark border px-3 py-2 fw-bold" style="font-size: 0.9rem;">
                                        <?= $jml_trx; ?>x Transaksi
                                    </span>
                                </td>
                                <td>
                                    <?php if (!empty($row['transaksi_terakhir'])): ?>
                                        <span class="text-muted small">
                                            <i class="bi bi-clock-history me-1 text-warning"></i><?= date('d M Y, H:i', strtotime($row['transaksi_terakhir'])); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted small fst-italic">Belum pernah</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if ($role_user !== 'kasir'): ?>
                                        <div class="d-flex justify-content-center gap-2">
                                            <!-- Tombol Edit -->
                                            <button type="button" class="btn btn-sm px-2.5 py-1.5 rounded-3 fw-bold text-white shadow-sm" 
                                                style="background: linear-gradient(135deg, #E6C567 0%, #C49A45 100%); border: none;" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#modalEditMember<?= $row['PelangganID']; ?>" 
                                                title="Edit Member">
                                                <i class="bi bi-pencil-square"></i>
                                            </button>

                                            <!-- Tombol Hapus -->
                                            <?php if ($ada_transaksi): ?>
                                                <button type="button" class="btn btn-sm px-2.5 py-1.5 rounded-3 fw-bold text-white shadow-sm" 
                                                    style="background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%); border: none;" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#modalProteksiHapus<?= $row['PelangganID']; ?>" 
                                                    title="Hapus Member">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            <?php else: ?>
                                                <button type="button" class="btn btn-sm px-2.5 py-1.5 rounded-3 fw-bold text-white shadow-sm" 
                                                    style="background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%); border: none;" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#modalYakinHapus<?= $row['PelangganID']; ?>" 
                                                    title="Hapus Member">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted small fst-italic">
                                            <i class="bi bi-shield-lock me-1"></i>Akses Terbatas
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <?php if ($role_user !== 'kasir'): ?>
                            <!-- MODAL EDIT MEMBER -->
                            <div class="modal fade" id="modalEditMember<?= $row['PelangganID']; ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content shadow">
                                        <div class="modal-header border-0 pb-0">
                                            <h6 class="modal-title fw-bold text-dark d-flex align-items-center gap-2">
                                                <i class="bi bi-pencil-square text-warning"></i> Edit Data Member: <?= $formatted_id; ?>
                                            </h6>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <form action="pelanggan-edit.php" method="POST" id="formEdit<?= $row['PelangganID']; ?>">
                                            <div class="modal-body p-3 text-start">
                                                <input type="hidden" name="pelanggan_id" value="<?= $row['PelangganID']; ?>">
                                                
                                                <div class="mb-3">
                                                    <label class="form-label small fw-bold text-secondary">Nama Lengkap Pelanggan <span class="text-danger">*</span></label>
                                                    <input type="text" name="nama_pelanggan" id="inputNama<?= $row['PelangganID']; ?>" class="form-control" value="<?= htmlspecialchars($row['NamaPelanggan']); ?>" required>
                                                </div>

                                                <div class="mb-3">
                                                    <label class="form-label small fw-bold text-secondary">Nomor Telepon / WhatsApp</label>
                                                    <input type="text" name="nomor_telepon" class="form-control" value="<?= htmlspecialchars($row['NomorTelepon']); ?>">
                                                </div>

                                                <div class="mb-3">
                                                    <label class="form-label small fw-bold text-secondary">Alamat</label>
                                                    <textarea name="alamat" class="form-control" rows="3"><?= htmlspecialchars($row['Alamat']); ?></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer border-0 pt-0 px-3 pb-3">
                                                <button type="button" class="btn btn-secondary btn-sm fw-bold px-3 rounded-2" data-bs-dismiss="modal">Batal</button>
                                                <button type="button" class="btn btn-warning btn-sm text-white fw-bold px-4 rounded-2" style="background: #C49A45; border: none;" onclick="tampilkanKonfirmasiEdit(<?= $row['PelangganID']; ?>)">Simpan Perubahan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- POP-UP KONFIRMASI SIMPAN PERUBAHAN -->
                            <div class="modal fade modal-custom-style" id="modalKonfirmEdit<?= $row['PelangganID']; ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" style="max-width: 440px;">
                                    <div class="modal-content text-center p-4">
                                        <div class="popup-icon-container">
                                            <i class="bi bi-question"></i>
                                        </div>
                                        <h4 class="fw-bold text-dark mb-2" style="font-size: 1.4rem;">Yakin Ingin Menyimpan?</h4>
                                        <p class="text-muted small px-2 mb-4">
                                            Anda akan memperbarui data member <strong class="text-dark" id="txtNamaPreview<?= $row['PelangganID']; ?>"><?= htmlspecialchars($row['NamaPelanggan']); ?></strong> ke dalam database sistem kasir.
                                        </p>
                                        <div class="d-flex gap-3 justify-content-center">
                                            <button type="button" class="btn btn-outline-cancel w-50" data-bs-dismiss="modal">Nanti Saja</button>
                                            <button type="button" class="btn btn-green-confirm w-50" onclick="submitFormEdit(<?= $row['PelangganID']; ?>)">Ya, Simpan</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- POP-UP KONFIRMASI HAPUS MEMBER -->
                            <div class="modal fade modal-custom-style" id="modalYakinHapus<?= $row['PelangganID']; ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" style="max-width: 440px;">
                                    <div class="modal-content text-center p-4">
                                        <div class="popup-icon-container popup-icon-danger">
                                            <i class="bi bi-trash"></i>
                                        </div>
                                        <h4 class="fw-bold text-dark mb-2" style="font-size: 1.4rem;">Yakin Ingin Menghapus?</h4>
                                        <p class="text-muted small px-2 mb-4">
                                            Member <strong class="text-dark"><?= htmlspecialchars($row['NamaPelanggan']); ?></strong> (<?= $formatted_id; ?>) akan dihapus permanen dari sistem database.
                                        </p>
                                        <div class="d-flex gap-3 justify-content-center">
                                            <button type="button" class="btn btn-outline-cancel w-50" data-bs-dismiss="modal">Nanti Saja</button>
                                            <a href="pelanggan-hapus.php?id=<?= $row['PelangganID']; ?>" class="btn btn-red-confirm w-50 d-flex align-items-center justify-content-center text-decoration-none">Ya, Hapus</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- MODAL PROTEKSI HAPUS -->
                            <div class="modal fade modal-custom-style" id="modalProteksiHapus<?= $row['PelangganID']; ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" style="max-width: 440px;">
                                    <div class="modal-content text-center p-4">
                                        <div class="popup-icon-container popup-icon-danger">
                                            <i class="bi bi-shield-exclamation"></i>
                                        </div>
                                        <h4 class="fw-bold text-dark mb-2" style="font-size: 1.3rem;">Tidak Dapat Dihapus</h4>
                                        <p class="text-muted small px-2 mb-4">
                                            Member <strong class="text-dark"><?= htmlspecialchars($row['NamaPelanggan']); ?></strong> memiliki riwayat transaksi aktif dan dilindungi agar integritas laporan kasir tetap terjaga.
                                        </p>
                                        <button type="button" class="btn btn-outline-cancel w-100" data-bs-dismiss="modal">Mengerti</button>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted">
                                    <i class="bi bi-people fs-1 d-block mb-2 text-warning opacity-50"></i>
                                    Belum ada data member yang terdaftar.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- MODAL TAMBAH MEMBER BARU -->
<div class="modal fade" id="modalTambahMember" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow">
            <div class="modal-header border-0 pb-0">
                <h6 class="modal-title fw-bold text-dark d-flex align-items-center gap-2">
                    <i class="bi bi-person-plus-fill text-warning"></i> Registrasi Member Baru
                </h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="POST" id="formTambah">
                <div class="modal-body p-3">
                    <input type="hidden" name="tambah_member" value="1">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary">Nama Lengkap Pelanggan <span class="text-danger">*</span></label>
                        <input type="text" name="nama_pelanggan" id="inputTambahNama" class="form-control" placeholder="Contoh: Budi Santoso" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary">Nomor Telepon / WhatsApp</label>
                        <input type="text" name="nomor_telepon" class="form-control" placeholder="Contoh: 081234567890">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary">Alamat</label>
                        <textarea name="alamat" class="form-control" rows="3" placeholder="Masukkan alamat pelanggan..."></textarea>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0 px-3 pb-3">
                    <button type="button" class="btn btn-secondary btn-sm fw-bold px-3 rounded-2" data-bs-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-warning btn-sm text-white fw-bold px-4 rounded-2" style="background: #C49A45; border: none;" onclick="tampilkanKonfirmasiTambah()">Simpan Member</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- POP-UP KONFIRMASI TAMBAH MEMBER -->
<div class="modal fade modal-custom-style" id="modalKonfirmTambah" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 440px;">
        <div class="modal-content text-center p-4">
            <div class="popup-icon-container">
                <i class="bi bi-question"></i>
            </div>
            <h4 class="fw-bold text-dark mb-2" style="font-size: 1.4rem;">Yakin Ingin Menyimpan?</h4>
            <p class="text-muted small px-2 mb-4">
                Anda akan mendaftarkan member baru <strong class="text-dark" id="previewNamaBaru">Baru</strong> ke dalam database sistem kasir.
            </p>
            <div class="d-flex gap-3 justify-content-center">
                <button type="button" class="btn btn-outline-cancel w-50" data-bs-dismiss="modal">Nanti Saja</button>
                <button type="button" class="btn btn-green-confirm w-50" onclick="submitFormTambah()">Ya, Simpan</button>
            </div>
        </div>
    </div>
</div>

<script>
// Fungsi Filter Search Real-time
function filterMember() {
    let input = document.getElementById('searchMember').value.toLowerCase();
    let rows = document.getElementsByClassName('row-member');

    Array.from(rows).forEach(function(row) {
        let textData = row.getAttribute('data-search');
        if (textData.includes(input)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

// Handler Pop-Up Tambah
function tampilkanKonfirmasiTambah() {
    let namaInput = document.getElementById('inputTambahNama').value;
    if (!namaInput.trim()) {
        alert('Nama lengkap pelanggan wajib diisi!');
        document.getElementById('inputTambahNama').focus();
        return;
    }
    document.getElementById('previewNamaBaru').innerText = namaInput;
    
    let modalInputEl = document.getElementById('modalTambahMember');
    let modalInput = bootstrap.Modal.getInstance(modalInputEl) || new bootstrap.Modal(modalInputEl);
    modalInput.hide();

    let modalKonfirm = new bootstrap.Modal(document.getElementById('modalKonfirmTambah'));
    modalKonfirm.show();
}

function submitFormTambah() {
    document.getElementById('formTambah').submit();
}

// Handler Pop-Up Edit
function tampilkanKonfirmasiEdit(id) {
    let namaInput = document.getElementById('inputNama' + id).value;
    if (!namaInput.trim()) {
        alert('Nama lengkap pelanggan wajib diisi!');
        document.getElementById('inputNama' + id).focus();
        return;
    }
    document.getElementById('txtNamaPreview' + id).innerText = namaInput;

    let modalInputEl = document.getElementById('modalEditMember' + id);
    let modalInput = bootstrap.Modal.getInstance(modalInputEl) || new bootstrap.Modal(modalInputEl);
    modalInput.hide();

    let modalKonfirm = new bootstrap.Modal(document.getElementById('modalKonfirmEdit' + id));
    modalKonfirm.show();
}

function submitFormEdit(id) {
    document.getElementById('formEdit' + id).submit();
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>