<?php
date_default_timezone_set('Asia/Jakarta');
session_start();
include '../koneksi.php';

// Pesan sukses (flash) setelah simpan, ditampilkan sebagai pop-up
$flash = $_SESSION['edit_berhasil'] ?? null;
unset($_SESSION['edit_berhasil']);

function fmtTeks($v) {
    $v = trim((string) $v);
    return $v === '' ? '(kosong)' : '“' . $v . '”';
}

// ======================================================
// PENGATURAN HAK AKSES KASIR
// true  = kasir hanya boleh mengoreksi transaksi yang ia input sendiri (admin bebas)
// false = semua kasir boleh mengoreksi transaksi berstatus "proses"
// ======================================================
const HANYA_TRANSAKSI_SENDIRI = true;

// 1. CEK LOGIN
if (!isset($_SESSION['login'])) {
    header("Location: ../index.php?pesan=gagal");
    exit;
}

$role_login   = strtolower(trim($_SESSION['Role'] ?? 'kasir'));
$user_id_login = (int) ($_SESSION['UserID'] ?? 0);
$username_log = $_SESSION['Username'] ?? ($_SESSION['NamaUser'] ?? 'Kasir');
$label_role   = ($role_login === 'admin') ? 'Admin' : 'Kasir';

// 2. ID TRANSAKSI
$penjualan_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($penjualan_id <= 0) {
    echo "<script>alert('ID transaksi tidak valid!'); window.location='riwayat-penjualan.php';</script>";
    exit;
}

// 3. DATA TRANSAKSI
$stmt = mysqli_prepare($koneksi, "
    SELECT p.*,
        COALESCE(NULLIF(TRIM(pel.NamaPelanggan), ''), NULLIF(TRIM(p.NamaPelanggan), ''), 'Pelanggan Umum') AS NamaFinalPelanggan,
        pel.Alamat, pel.NomorTelepon, u.NamaUser
    FROM penjualan p
    LEFT JOIN pelanggan pel ON p.PelangganID = pel.PelangganID
    LEFT JOIN user u ON p.UserID = u.UserID
    WHERE p.PenjualanID = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, "i", $penjualan_id);
mysqli_stmt_execute($stmt);
$transaksi = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$transaksi) {
    echo "<script>alert('Data transaksi tidak ditemukan!'); window.location='riwayat-penjualan.php';</script>";
    exit;
}

// 4. ATURAN AKSES & STATUS
$status_normal = strtolower(trim((string) ($transaksi['Status'] ?? 'proses')));
if ($status_normal === '' || $status_normal === 'berhasil') $status_normal = 'proses';
if ($status_normal === 'batal') $status_normal = 'dibatalkan';

if ($status_normal !== 'proses') {
    echo "<script>alert('Hanya transaksi berstatus Proses yang dapat dikoreksi!'); window.location='detail-transaksi.php?id=$penjualan_id';</script>";
    exit;
}
if (HANYA_TRANSAKSI_SENDIRI && $role_login !== 'admin' && (int) $transaksi['UserID'] !== $user_id_login) {
    echo "<script>alert('Anda hanya dapat mengoreksi transaksi yang Anda input sendiri!'); window.location='detail-transaksi.php?id=$penjualan_id';</script>";
    exit;
}

$is_member  = !empty($transaksi['PelangganID']);
$total_lama = (float) $transaksi['TotalHarga'];
$bayar_db   = (float) ($transaksi['Bayar'] ?? 0);
$kembali_db = (float) ($transaksi['Kembali'] ?? 0);

$no_transaksi = 'TRX-' . date('Ymd', strtotime($transaksi['TanggalPenjualan'])) . '-' . str_pad((string) $penjualan_id, 4, '0', STR_PAD_LEFT);

// 5. METODE PEMBAYARAN (kolom MetodePembayaran jika ada, jika tidak dari audit log)
$metode = 'Tunai';
$cek_kolom = mysqli_query($koneksi, "SHOW COLUMNS FROM penjualan LIKE 'MetodePembayaran'");
if ($cek_kolom && mysqli_num_rows($cek_kolom) > 0 && !empty($transaksi['MetodePembayaran'])) {
    $m = strtolower($transaksi['MetodePembayaran']);
    $metode = $m === 'qris' ? 'QRIS' : (strpos($m, 'transfer') !== false ? 'Transfer Bank' : 'Tunai');
} else {
    $like = 'Menambahkan transaksi baru ' . $no_transaksi . '%';
    $st = mysqli_prepare($koneksi, "SELECT deskripsi FROM audit_log WHERE deskripsi LIKE ? LIMIT 1");
    if ($st) {
        mysqli_stmt_bind_param($st, "s", $like);
        mysqli_stmt_execute($st);
        $row = mysqli_fetch_assoc(mysqli_stmt_get_result($st));
        mysqli_stmt_close($st);
        if ($row) {
            if (strpos($row['deskripsi'], '(QRIS)') !== false) $metode = 'QRIS';
            elseif (strpos($row['deskripsi'], '(Transfer Bank)') !== false) $metode = 'Transfer Bank';
        }
    }
}
$is_tunai = ($metode === 'Tunai');

// 6. DETAIL ITEM
$details = [];
$stmt = mysqli_prepare($koneksi, "
    SELECT dp.DetailID, dp.JumlahProduk, dp.Subtotal, dp.Catatan, dp.BiayaExtra, pr.NamaProduk
    FROM detailpenjualan dp INNER JOIN produk pr ON dp.ProdukID = pr.ProdukID
    WHERE dp.PenjualanID = ? ORDER BY dp.DetailID ASC");
mysqli_stmt_bind_param($stmt, "i", $penjualan_id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
while ($r = mysqli_fetch_assoc($res)) $details[] = $r;
mysqli_stmt_close($stmt);

$gross_lama = 0;
foreach ($details as $d) $gross_lama += (float) $d['Subtotal'] + (float) $d['BiayaExtra'];
$diskon_lama = max(0, $gross_lama - $total_lama);

$error = '';

// 7. PROSES SIMPAN
if (isset($_POST['update_transaksi'])) {
    $catatan_post = $_POST['catatan_item'] ?? [];
    $extra_post   = $_POST['biaya_extra_item'] ?? [];

    $gross_baru = 0;
    $perubahan  = [];
    $baru = [];
    foreach ($details as $d) {
        $did = (int) $d['DetailID'];
        $cat = trim((string) ($catatan_post[$did] ?? $d['Catatan']));
        $ext = max(0, (float) ($extra_post[$did] ?? $d['BiayaExtra']));
        if ((float) $d['Subtotal'] == 0) $ext = 0; // item bonus tidak boleh diberi biaya
        $gross_baru += (float) $d['Subtotal'] + $ext;
        $baru[$did] = [$cat, $ext];
        if ($cat !== (string) $d['Catatan']) $perubahan[] = 'Catatan ' . $d['NamaProduk'] . ': ' . fmtTeks($d['Catatan']) . ' → ' . fmtTeks($cat);
        if ($ext != (float) $d['BiayaExtra']) $perubahan[] = 'Biaya extra ' . $d['NamaProduk'] . ': Rp ' . number_format((float) $d['BiayaExtra'], 0, ',', '.') . ' → Rp ' . number_format($ext, 0, ',', '.');
    }
    $total_baru = max(0, $gross_baru - $diskon_lama);

    // Nama pelanggan: hanya non-member
    $nama_baru = $transaksi['NamaFinalPelanggan'];
    if (!$is_member) {
        $nama_baru = trim($_POST['NamaPelanggan'] ?? '');
        if ($nama_baru === '') $error = 'Nama pelanggan tidak boleh kosong.';
        elseif ($nama_baru !== $transaksi['NamaFinalPelanggan']) $perubahan[] = 'Nama pelanggan: ' . fmtTeks($transaksi['NamaFinalPelanggan']) . ' → ' . fmtTeks($nama_baru);
    }

    // Pembayaran terkunci
    $kembali_baru = $bayar_db - $total_baru;
    if ($is_tunai) {
        if ($total_baru > $bayar_db) {
            $error = 'Total baru (Rp ' . number_format($total_baru, 0, ',', '.') . ') melebihi uang yang sudah diterima (Rp ' . number_format($bayar_db, 0, ',', '.') . '). Uang tidak dapat diedit, silakan batalkan transaksi dan buat ulang.';
        }
    } else {
        $kembali_baru = $kembali_db;
        if (abs($total_baru - $total_lama) > 0.009) {
            $error = 'Pembayaran ' . $metode . ' sudah lunas dan nominalnya tidak dapat diubah. Biaya extra tidak boleh mengubah total. Jika perlu, batalkan transaksi dan buat ulang.';
        }
    }

    if ($error === '' && count($perubahan) === 0) {
        $error = 'Tidak ada perubahan yang perlu disimpan.';
    }

    if ($error === '') {
        mysqli_begin_transaction($koneksi);
        try {
            $st = mysqli_prepare($koneksi, "UPDATE detailpenjualan SET Catatan = ?, BiayaExtra = ? WHERE DetailID = ? AND PenjualanID = ?");
            foreach ($baru as $did => [$cat, $ext]) {
                mysqli_stmt_bind_param($st, "sdii", $cat, $ext, $did, $penjualan_id);
                if (!mysqli_stmt_execute($st)) throw new Exception('Gagal memperbarui detail item.');
            }
            mysqli_stmt_close($st);

            if ($is_member) {
                $st = mysqli_prepare($koneksi, "UPDATE penjualan SET TotalHarga = ?, Kembali = ? WHERE PenjualanID = ?");
                mysqli_stmt_bind_param($st, "ddi", $total_baru, $kembali_baru, $penjualan_id);
            } else {
                $st = mysqli_prepare($koneksi, "UPDATE penjualan SET TotalHarga = ?, Kembali = ?, NamaPelanggan = ? WHERE PenjualanID = ?");
                mysqli_stmt_bind_param($st, "ddsi", $total_baru, $kembali_baru, $nama_baru, $penjualan_id);
            }
            if (!mysqli_stmt_execute($st)) throw new Exception('Gagal memperbarui transaksi.');
            mysqli_stmt_close($st);

            $aktivitas = 'UBAH';
            $deskripsi = "$label_role ($username_log) mengoreksi transaksi $no_transaksi ($metode). "
                . (count($perubahan) ? 'Perubahan: ' . implode('; ', $perubahan) . '. ' : 'Tanpa perubahan data. ')
                . 'Total: Rp ' . number_format($total_lama, 0, ',', '.') . ' -> Rp ' . number_format($total_baru, 0, ',', '.');
            $st = mysqli_prepare($koneksi, "INSERT INTO audit_log (username, aktivitas, waktu, deskripsi) VALUES (?, ?, NOW(), ?)");
            if ($st) {
                mysqli_stmt_bind_param($st, "sss", $username_log, $aktivitas, $deskripsi);
                mysqli_stmt_execute($st);
                mysqli_stmt_close($st);
            }
            mysqli_commit($koneksi);
            $_SESSION['edit_berhasil'] = [
                'no' => $no_transaksi,
                'perubahan' => $perubahan,
                'total_lama' => $total_lama,
                'total_baru' => $total_baru,
            ];
            header("Location: " . basename($_SERVER['PHP_SELF']) . "?id=" . $penjualan_id);
            exit;
        } catch (Throwable $e) {
            mysqli_rollback($koneksi);
            $error = 'Gagal menyimpan: ' . $e->getMessage();
        }
    }
}

// Tipe pelanggan
$tipe_label = $is_member ? 'Member' : 'Pelanggan Umum';
$tipe_class = $is_member ? 'customer-member' : 'customer-umum';
$tipe_icon  = $is_member ? 'bi-person-badge-fill' : 'bi-person-fill';
$rp = fn($n) => number_format((float) $n, 0, ',', '.');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Koreksi Transaksi <?= htmlspecialchars($no_transaksi); ?> - Daily Coffee & Toast</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        :root { color-scheme: light; }
        body { background-color: #FAF8F5; font-family: 'Plus Jakarta Sans', sans-serif !important; color: #1E293B; }
        .edit-kasir-wrap { margin-top: 75px; margin-left: var(--sidebar-width, 270px); padding: 2rem 2.5rem 3rem; box-sizing: border-box; min-height: calc(100vh - 75px); }
        @media (max-width: 992px) { .edit-kasir-wrap { padding: 1.5rem 1rem 2rem; } }

        .detail-card { background: #FFFFFF; border-radius: 20px; border: 1px solid #E5E0D8; box-shadow: 0 10px 25px rgba(0,0,0,0.03); }
        .page-header { background: #FFFFFF; border: 1px solid #E5E0D8; border-radius: 20px; box-shadow: 0 8px 22px rgba(0,0,0,0.03); }
        .menu-card-inner { background: #FFFFFF; border: 1px solid #E7E5E4; border-radius: 14px; overflow: hidden; }
        .menu-card-top { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 0 0 12px 0; margin: 0 0 19px 0; border-bottom: 1px solid #D6D3D1; background: #FFFFFF; }
        .menu-card-title { display: flex; align-items: center; gap: 8px; color: #1C1917; font-size: 1rem; font-weight: 800; }
        .menu-card-title i { color: #F4B400; font-size: 1.08rem; }
        .menu-card-count { padding: 5px 9px; border-radius: 7px; background: #F8FAFC; border: 1px solid #DCE3EA; color: #475569; font-size: .68rem; font-weight: 600; white-space: nowrap; }

        .menu-table { width: 100%; border-collapse: separate; border-spacing: 0; }
        .menu-table thead th { background: #1E293B; color: #FFFFFF; padding: 15px 18px; font-size: .74rem; font-weight: 800; text-transform: uppercase; letter-spacing: .35px; border: none; }
        .menu-table thead th:first-child { border-top-left-radius: 11px; text-align: left; width: 42%; }
        .menu-table thead th:nth-child(2) { width: 12%; text-align: center; }
        .menu-table thead th:nth-child(3) { width: 22%; text-align: right; }
        .menu-table thead th:last-child { border-top-right-radius: 11px; text-align: right; width: 24%; }
        .menu-table tbody td { background: #FFFFFF; border-bottom: 1px solid #F1F5F9; vertical-align: top; font-size: .86rem; }
        .menu-table tbody tr:last-child td { border-bottom: none; }
        .product-content-cell { padding: 0 !important; }
        .product-block { width: 100%; position: relative; }
        .product-main-row { display: grid; grid-template-columns: minmax(0,42%) 12% minmax(0,22%) 24%; align-items: center; min-height: 72px; padding: 15px 18px 10px; box-sizing: border-box; }
        .product-main-info { min-width: 0; padding-right: 14px; }
        .menu-product-name { color: #1C1917; font-size: .88rem; font-weight: 800; line-height: 1.4; overflow-wrap: anywhere; }
        .menu-product-qty-label { display: inline-flex; align-items: center; margin-top: 5px; padding: 3px 7px; border-radius: 5px; background: #F5F5F4; color: #78716C; font-size: .64rem; font-weight: 700; }
        .product-main-qty { text-align: center; color: #334155; font-size: .82rem; font-weight: 800; white-space: nowrap; }
        .product-main-price { text-align: right; color: #57534E; font-size: .82rem; font-weight: 600; white-space: nowrap; }
        .product-extra-area { width: 100%; padding: 0 18px 7px 18px; box-sizing: border-box; }
        .product-detail-stack { width: 100%; display: flex; flex-direction: column; gap: 5px; }

        .product-note-box { width: 100%; display: flex; align-items: center; gap: 8px; padding: 7px 10px; background: #FFFBEB; border: 1px solid #FDE68A; border-radius: 7px; box-sizing: border-box; }
        .product-note-icon { width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; background: #FEF3C7; color: #D97706; border-radius: 5px; font-size: .63rem; }
        .product-note-title { color: #92400E; font-size: .63rem; font-weight: 800; text-transform: uppercase; letter-spacing: .35px; white-space: nowrap; }
        .product-extra-box { width: 100%; display: flex; align-items: center; gap: 8px; padding: 7px 10px; background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 7px; box-sizing: border-box; }
        .product-extra-icon { width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; background: #EFF6FF; color: #2563EB; border-radius: 5px; font-size: .63rem; }
        .product-extra-title { color: #475569; font-size: .63rem; font-weight: 800; text-transform: uppercase; letter-spacing: .35px; white-space: nowrap; }
        .inline-input { flex: 1; min-width: 0; background: #FFFFFF; border: 1px solid #D6D3D1; border-radius: 8px; padding: 5px 10px; font-size: .78rem; font-weight: 600; color: #1E293B; }
        .inline-input:focus { outline: none; border-color: #C49A45; box-shadow: 0 0 0 3px rgba(196,154,69,.15); }
        .inline-input.num { text-align: right; max-width: 160px; }
        .inline-input[readonly] { background: #F5F5F4; color: #A8A29E; }

        .product-subtotal-row { display: flex; align-items: center; justify-content: flex-end; gap: 10px; width: 100%; padding: 7px 18px 14px; box-sizing: border-box; }
        .product-subtotal-label { color: #A8A29E; font-size: .65rem; font-weight: 700; text-transform: uppercase; letter-spacing: .3px; }
        .product-subtotal-value { color: #166534; font-size: .88rem; font-weight: 800; white-space: nowrap; }
        .product-block + .product-block { border-top: 1px solid #EDEAE6; }

        .transaction-total-wrapper { padding: 15px 18px 16px; background: #FAFAF9; border-top: 1px solid #E7E5E4; }
        .transaction-total-box { display: flex; align-items: center; justify-content: space-between; gap: 20px; width: 100%; }
        .transaction-total-label { display: flex; align-items: center; gap: 8px; color: #44403C; font-size: .72rem; font-weight: 800; text-transform: uppercase; letter-spacing: .4px; }
        .transaction-total-label i { width: 25px; height: 25px; display: flex; align-items: center; justify-content: center; background: #FEF3C7; color: #B45309; border-radius: 6px; font-size: .68rem; }
        .transaction-total-caption { margin-top: 4px; color: #A8A29E; font-size: .62rem; font-weight: 500; line-height: 1.4; }
        .transaction-total-value { color: #15803D; font-size: 1.15rem; font-weight: 800; white-space: nowrap; letter-spacing: -.2px; }

        .status-badge { display: inline-flex; align-items: center; justify-content: center; gap: 6px; padding: 8px 14px; border-radius: 50rem; font-size: .8rem; font-weight: 800; border: 1px solid transparent; white-space: nowrap; }
        .status-proses { background-color: #FEF3C7; color: #92400E; border-color: #FDE68A; }
        .customer-badge { display: inline-flex; align-items: center; gap: 6px; padding: 6px 10px; border-radius: 8px; font-size: .75rem; font-weight: 700; }
        .customer-member { color: #1D4ED8; background: #EFF6FF; border: 1px solid #DBEAFE; }
        .customer-umum { color: #78716C; background: #F5F5F4; border: 1px solid #E7E5E4; }

        .btn-kembali { border-radius: 50rem; padding: 10px 18px; font-weight: 700; background: #FFFFFF; border: 1px solid #D6D3D1; color: #57534E; box-shadow: 0 2px 5px rgba(0,0,0,.03); transition: all .2s ease; }
        .btn-kembali:hover { background: #F5F5F4; border-color: #A8A29E; color: #292524; transform: translateY(-1px); }
        .btn-simpan { background: linear-gradient(135deg, #C49A45 0%, #A37B2C 100%); color: #FFFFFF; border: none; border-radius: 50rem; padding: 10px 20px; font-weight: 700; transition: .2s; box-shadow: 0 3px 8px rgba(163,123,44,.15); }
        .btn-simpan:hover { background: #A37B2C; color: #FFFFFF; transform: translateY(-1px); }

        .info-label { color: #78716C; font-size: .8rem; display: block; margin-bottom: 4px; }
        .info-value { color: #1E293B; font-weight: 700; overflow-wrap: anywhere; }
        .nama-input { width: 100%; background: #FFFFFF; border: 1px solid #D6D3D1; border-radius: 10px; padding: 8px 12px; font-weight: 700; color: #1E293B; font-size: .88rem; }
        .nama-input:focus { outline: none; border-color: #C49A45; box-shadow: 0 0 0 3px rgba(196,154,69,.15); }
        .nama-input[readonly] { background: #F5F5F4; color: #78716C; }
        .payment-box { background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 12px; padding: 15px; }
        .payment-row { display: flex; justify-content: space-between; gap: 15px; margin-bottom: 7px; font-size: .88rem; }
        .payment-row:last-child { margin-bottom: 0; }
        .payment-value { white-space: nowrap; font-weight: 700; text-align: right; }
        .total-box { background: #FAF8F5; border: 1px solid #E5E0D8; border-radius: 12px; padding: 16px; }
        .total-amount { color: #15803D; font-size: 1.6rem; font-weight: 800; line-height: 1.2; }
        .lock-note { background: #FFFDF5; border: 1px solid #FDE68A; border-radius: 10px; padding: 10px 12px; color: #92400E; font-size: .76rem; line-height: 1.5; }

        .modal-content-custom { border-radius: 28px; border: none; box-shadow: 0 15px 40px rgba(0,0,0,0.15); padding: 1.5rem; }
    .modal-icon-wrapper { width: 80px; height: 80px; background: #FFF8E1; border: 2px solid #FFD54F; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem auto; box-shadow: 0 4px 15px rgba(255,193,7,.2); }
    .btn-modal-yes { background-color: #1B5E20; color: #FFFFFF; font-weight: 700; border-radius: 50px; padding: 0.75rem 2rem; border: none; transition: all .2s ease; }
    .btn-modal-yes:hover { background-color: #2E7D32; color: #FFFFFF; }
    .btn-modal-cancel { background-color: #FFFFFF; color: #495057; font-weight: 700; border-radius: 50px; padding: 0.75rem 2rem; border: 2px solid #CED4DA; transition: all .2s ease; }
    .btn-modal-cancel:hover { background-color: #F8F9FA; color: #212529; border-color: #ADB5BD; }

        @media (max-width: 768px) {
            .menu-table thead th { padding: 12px 10px; font-size: .68rem; }
            .product-main-row { grid-template-columns: minmax(0,40%) 15% minmax(0,45%); padding: 14px 10px 9px; }
            .product-main-row > :nth-child(4) { display: none; }
            .product-extra-area { padding: 0 10px 7px 10px; }
            .product-subtotal-row { padding: 7px 10px 13px; }
            .transaction-total-wrapper { padding: 13px 10px 15px; }
        }
        @media (max-width: 576px) {
            .edit-kasir-wrap { padding: 1.25rem .75rem 2rem; }
            .detail-card { padding: 16px !important; }
            .product-note-box, .product-extra-box { flex-wrap: wrap; }
        }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="edit-kasir-wrap">

    <!-- HEADER HALAMAN -->
    <div class="page-header d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3 mb-4 bg-white p-4">
        <div>
            <div class="d-flex align-items-center gap-2 mb-2 flex-wrap">
                <h3 class="fw-bold mb-0" style="color:#141211;">
                    Koreksi Transaksi
                    <span style="font-family:monospace;color:#C49A45;"><?= htmlspecialchars($no_transaksi); ?></span>
                </h3>
                <span class="badge px-3 py-2 rounded-pill fw-bold" style="background:rgba(196,154,69,.15);color:#C49A45;border:1px solid rgba(196,154,69,.3);">
                    <i class="bi bi-pencil-square me-1"></i> MODE KOREKSI
                </span>
            </div>
            <p class="text-muted small mb-0">Hanya catatan item, biaya extra, dan nama pelanggan non-member yang dapat dikoreksi.</p>
        </div>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <a href="detail-transaksi.php?id=<?= $penjualan_id; ?>" class="btn btn-kembali text-decoration-none d-flex align-items-center justify-content-center gap-2">
                <i class="bi bi-arrow-left"></i><span>Batal &amp; Kembali</span>
            </a>
            <button type="button" class="btn-simpan d-flex align-items-center justify-content-center gap-2" data-bs-toggle="modal" data-bs-target="#konfirmasiSimpanModal">
                <i class="bi bi-check2-circle"></i><span>Simpan Koreksi</span>
            </button>
        </div>
    </div>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger rounded-4 mb-4"><i class="bi bi-exclamation-triangle-fill me-1"></i> <?= htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST" id="formEditTransaksi">
    <div class="row g-4">

        <!-- KIRI: DAFTAR MENU -->
        <div class="col-lg-8">
            <div class="detail-card p-4 h-100">
                <div class="menu-card-inner">
                    <div class="menu-card-top">
                        <div class="menu-card-title"><i class="bi bi-basket-fill"></i><span>Daftar Menu yang Dipesan</span></div>
                        <div class="menu-card-count"><?= count($details); ?> Jenis Menu</div>
                    </div>

                    <?php if (count($details) > 0): ?>
                    <div class="table-responsive">
                        <table class="menu-table">
                            <thead><tr><th>MENU PRODUK</th><th>QTY</th><th>HARGA SATUAN</th><th>SUBTOTAL</th></tr></thead>
                            <tbody>
                            <?php foreach ($details as $d):
                                $did   = (int) $d['DetailID'];
                                $qty   = (int) $d['JumlahProduk'];
                                $dasar = (float) $d['Subtotal'];
                                $extra = (float) $d['BiayaExtra'];
                                $satuan = $qty > 0 ? $dasar / $qty : 0;
                                $bonus = ($dasar == 0);
                            ?>
                                <tr>
                                    <td colspan="4" class="product-content-cell">
                                        <div class="product-block">
                                            <div class="product-main-row">
                                                <div class="product-main-info">
                                                    <div class="menu-product-name">
                                                        <?= htmlspecialchars($d['NamaProduk']); ?>
                                                        <?php if ($bonus): ?><span class="badge bg-success ms-1" style="font-size:.6rem;">🎁 Bonus</span><?php endif; ?>
                                                    </div>
                                                    <div class="menu-product-qty-label"><?= $qty; ?> item</div>
                                                </div>
                                                <div class="product-main-qty"><?= $qty; ?>x</div>
                                                <div class="product-main-price">Rp <?= $rp($satuan); ?></div>
                                                <div></div>
                                            </div>

                                            <div class="product-extra-area">
                                                <div class="product-detail-stack">
                                                    <div class="product-note-box">
                                                        <div class="product-note-icon"><i class="bi bi-chat-left-text-fill"></i></div>
                                                        <span class="product-note-title">Catatan</span>
                                                        <input type="text" name="catatan_item[<?= $did; ?>]" class="inline-input" maxlength="255"
                                                               value="<?= htmlspecialchars((string) $d['Catatan']); ?>" placeholder="Misal: less ice, extra topping...">
                                                    </div>
                                                    <div class="product-extra-box">
                                                        <div class="product-extra-icon"><i class="bi bi-plus-circle-fill"></i></div>
                                                        <span class="product-extra-title">Biaya Extra (Rp)</span>
                                                        <input type="number" name="biaya_extra_item[<?= $did; ?>]" class="inline-input num input-extra" min="0" step="1"
                                                               data-dasar="<?= $dasar; ?>" data-id="<?= $did; ?>" value="<?= $extra; ?>"
                                                               <?= $bonus ? 'readonly title="Item bonus tidak dapat diberi biaya"' : ''; ?> oninput="hitungSemua()">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="product-subtotal-row">
                                                <span class="product-subtotal-label">Subtotal</span>
                                                <span class="product-subtotal-value" id="sub_<?= $did; ?>">Rp <?= $rp($dasar + $extra); ?></span>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="transaction-total-wrapper">
                        <div class="transaction-total-box">
                            <div>
                                <div class="transaction-total-label"><i class="bi bi-calculator-fill"></i><span>Total Transaksi</span></div>
                                <div class="transaction-total-caption">
                                    Total seluruh pesanan termasuk biaya extra<?= $diskon_lama > 0 ? ' dikurangi diskon awal Rp ' . $rp($diskon_lama) : ''; ?>.
                                </div>
                            </div>
                            <div class="transaction-total-value" id="totalKiri">Rp <?= $rp($total_lama); ?></div>
                        </div>
                    </div>
                    <?php else: ?>
                        <div class="text-center text-muted py-5"><i class="bi bi-basket fs-2 d-block mb-2"></i>Belum ada detail produk pada transaksi ini.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- KANAN: INFORMASI TRANSAKSI -->
        <div class="col-lg-4">
            <div class="detail-card p-4 h-100 d-flex flex-column justify-content-between">
                <div>
                    <h5 class="fw-bold mb-3 pb-2 border-bottom text-dark d-flex align-items-center gap-2">
                        <i class="bi bi-info-circle text-warning"></i> Informasi Transaksi
                    </h5>

                    <div class="mb-3"><span class="info-label">Nomor Transaksi</span><span class="info-value font-monospace"><?= htmlspecialchars($no_transaksi); ?></span></div>
                    <div class="mb-3"><span class="info-label">Waktu Transaksi</span><span class="info-value"><?= date('d F Y, H:i:s', strtotime($transaksi['TanggalPenjualan'])); ?> WIB</span></div>
                    <div class="mb-3"><span class="info-label">Kasir</span><span class="info-value"><?= !empty($transaksi['NamaUser']) ? htmlspecialchars($transaksi['NamaUser']) : 'Administrator'; ?></span></div>
                    <div class="mb-3">
                        <span class="info-label">Status Transaksi</span>
                        <span class="status-badge status-proses"><i class="bi bi-hourglass-split"></i> Proses</span>
                    </div>

                    <div class="mb-3">
                        <span class="info-label">Tipe Pelanggan</span>
                        <div class="mb-2"><span class="customer-badge <?= $tipe_class; ?>"><i class="bi <?= $tipe_icon; ?>"></i> <?= $tipe_label; ?></span></div>

                        <span class="info-label">Nama Pelanggan <?= $is_member ? '(Terkunci)' : '(Dapat Dikoreksi)'; ?></span>
                        <input type="text" name="NamaPelanggan" class="nama-input" maxlength="100"
                               value="<?= htmlspecialchars($transaksi['NamaFinalPelanggan']); ?>"
                               <?= $is_member ? 'readonly title="Nama member tidak dapat diubah"' : 'required'; ?>>
                        <?php if ($is_member): ?><small class="text-muted" style="font-size:.72rem;">*Member resmi, nama tidak dapat diubah.</small><?php endif; ?>
                    </div>

                    <?php if ($is_member): ?>
                        <div class="mb-3"><span class="info-label">ID Member</span><span class="info-value font-monospace">#<?= (int) $transaksi['PelangganID']; ?></span></div>
                    <?php endif; ?>
                    <div class="mb-3"><span class="info-label">Telepon / Kontak</span><span class="info-value"><?= !empty($transaksi['NomorTelepon']) ? htmlspecialchars($transaksi['NomorTelepon']) : '-'; ?></span></div>
                    <div class="mb-3"><span class="info-label">Alamat</span><span class="info-value"><?= !empty($transaksi['Alamat']) ? htmlspecialchars($transaksi['Alamat']) : '-'; ?></span></div>

                    <div class="payment-box mb-3">
                        <div class="payment-row">
                            <span class="text-muted">Metode Pembayaran</span>
                            <span class="payment-value text-dark"><i class="bi bi-lock-fill text-muted me-1"></i><?= htmlspecialchars($metode); ?></span>
                        </div>
                        <div class="payment-row">
                            <span class="text-muted">Total Pembelian</span>
                            <span class="payment-value text-dark" id="totalKanan">Rp <?= $rp($total_lama); ?></span>
                        </div>
                        <div class="payment-row">
                            <span class="text-muted"><?= $is_tunai ? 'Tunai Diterima' : 'Dibayar'; ?></span>
                            <span class="payment-value text-dark">Rp <?= $rp($bayar_db); ?></span>
                        </div>
                        <div class="payment-row pt-2 border-top">
                            <span class="text-muted">Kembalian</span>
                            <span class="payment-value text-success" id="textKembalian">Rp <?= $rp($kembali_db); ?></span>
                        </div>
                    </div>

                    <div class="lock-note mb-3">
                        <i class="bi bi-info-circle-fill me-1"></i>
                        Pembayaran tidak dapat diedit. Jika nominal uang perlu diubah, <strong>batalkan transaksi</strong> lalu buat transaksi baru.
                        <?php if (!$is_tunai): ?>Karena dibayar via <?= htmlspecialchars($metode); ?>, biaya extra tidak boleh mengubah total.<?php endif; ?>
                    </div>
                </div>

                <div class="total-box mt-2">
                    <div class="d-flex align-items-center justify-content-between gap-2">
                        <span class="text-muted small text-uppercase fw-bold" style="font-size:.75rem;">Total Tagihan Baru</span>
                        <span class="status-badge status-proses"><i class="bi bi-hourglass-split"></i> Proses</span>
                    </div>
                    <div class="total-amount mt-2" id="totalBaru">Rp <?= $rp($total_lama); ?></div>
                    <small class="d-block mt-2 text-muted">Sebelumnya: Rp <?= $rp($total_lama); ?> · Selisih: <strong id="textSelisih">Rp 0</strong></small>
                </div>
            </div>
        </div>
    </div>

    </form>
</div>

<script src="../asset/js/bootstrap.bundle.min.js"></script>
<script>
const DISKON_AWAL = <?= json_encode($diskon_lama); ?>;
const TOTAL_LAMA  = <?= json_encode($total_lama); ?>;
const BAYAR       = <?= $is_tunai ? json_encode($bayar_db) : 'null'; ?>;
const KEMBALI_DB  = <?= json_encode($kembali_db); ?>;
const rp = n => 'Rp ' + Math.round(n).toLocaleString('id-ID');

function hitungSemua() {
    let gross = 0;
    document.querySelectorAll('.input-extra').forEach(inp => {
        const dasar = parseFloat(inp.dataset.dasar) || 0;
        const extra = Math.max(0, parseFloat(inp.value) || 0);
        document.getElementById('sub_' + inp.dataset.id).innerText = rp(dasar + extra);
        gross += dasar + extra;
    });
    const total = Math.max(0, gross - DISKON_AWAL);
    window.totalBaruTerakhir = total;
    const selisih = total - TOTAL_LAMA;
    ['totalKiri', 'totalKanan', 'totalBaru'].forEach(id => document.getElementById(id).innerText = rp(total));

    const s = document.getElementById('textSelisih');
    s.innerText = (selisih > 0 ? '+' : selisih < 0 ? '−' : '') + rp(Math.abs(selisih));
    s.style.color = selisih > 0 ? '#dc3545' : selisih < 0 ? '#198754' : '#6c757d';

    const k = document.getElementById('textKembalian');
    if (BAYAR !== null) {
        const kembali = BAYAR - total;
        k.innerText = kembali < 0 ? 'Melebihi uang diterima (' + rp(Math.abs(kembali)) + ')' : rp(kembali);
        k.style.color = kembali < 0 ? '#dc3545' : '#198754';
    } else {
        k.innerText = rp(KEMBALI_DB);
    }
}
window.addEventListener('load', hitungSemua);
</script>

    <!-- MODAL KONFIRMASI -->
    <div class="modal fade" id="konfirmasiSimpanModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content modal-content-custom text-center">
                <div class="modal-body p-4">
                    <div class="modal-icon-wrapper"><i class="bi bi-question-lg text-warning fs-1 fw-bold"></i></div>
                    <h4 class="fw-bold text-dark mb-3">Yakin Ingin Menyimpan?</h4>
                    <p class="text-muted mb-3 px-2" style="font-size:.95rem;line-height:1.5;">
                                            Periksa kembali perubahan pada transaksi <strong class="text-dark"><?= htmlspecialchars($no_transaksi); ?></strong>:
                                        </p>
                                        <div id="ringkasPerubahan" class="text-start mb-4"></div>
                    <div class="d-flex justify-content-center gap-3">
                        <button type="button" class="btn btn-modal-cancel px-4" data-bs-dismiss="modal">Nanti Saja</button>
                        <button type="submit" form="formEditTransaksi" id="btnYaSimpan" name="update_transaksi" class="btn btn-modal-yes px-4">Ya, Simpan</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

<style>
    .ringkas-list { list-style: none; margin: 0; padding: 0; max-height: 240px; overflow-y: auto; }
    .ringkas-item { background: #FFFDF5; border: 1px solid #FDE68A; border-radius: 12px; padding: 9px 12px; margin-bottom: 8px; text-align: left; }
    .ringkas-label { font-size: .72rem; font-weight: 800; text-transform: uppercase; letter-spacing: .3px; color: #92400E; }
    .ringkas-nilai { font-size: .85rem; color: #1E293B; overflow-wrap: anywhere; }
    .ringkas-nilai .dari { color: #A8A29E; text-decoration: line-through; }
    .ringkas-nilai .ke { color: #166534; }
    .ringkas-kosong { background: #F8FAFC; border: 1px dashed #CBD5E1; border-radius: 12px; padding: 14px; text-align: center; color: #64748B; font-size: .85rem; }
    .modal-icon-sukses { width: 80px; height: 80px; background: #DCFCE7; border: 3px solid #22C55E; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem; color: #15803D; font-size: 2.2rem; }
</style>

<?php if (!empty($flash)): ?>
<div class="modal fade" id="modalBerhasil" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content modal-content-custom text-center">
            <div class="modal-body p-4">
                <div class="modal-icon-sukses"><i class="bi bi-check-lg"></i></div>
                <h4 class="fw-bold text-dark mb-2">Perubahan Berhasil Disimpan!</h4>
                <p class="text-muted mb-3 px-2" style="font-size:.92rem;">
                    Transaksi <strong class="text-dark"><?= htmlspecialchars($flash['no']); ?></strong> telah diperbarui dan dicatat di audit log. Yang diubah:
                </p>
                <ul class="ringkas-list mb-3">
                    <?php foreach ($flash['perubahan'] as $p): ?>
                        <li class="ringkas-item"><div class="ringkas-nilai"><?= htmlspecialchars($p); ?></div></li>
                    <?php endforeach; ?>
                    <?php if ((float) $flash['total_lama'] !== (float) $flash['total_baru']): ?>
                        <li class="ringkas-item">
                            <div class="ringkas-label">Total transaksi</div>
                            <div class="ringkas-nilai">Rp <?= number_format($flash['total_lama'], 0, ',', '.'); ?> → <strong class="text-success">Rp <?= number_format($flash['total_baru'], 0, ',', '.'); ?></strong></div>
                        </li>
                    <?php endif; ?>
                </ul>
                <div class="d-flex justify-content-center gap-3 mt-4">
                    <button type="button" class="btn btn-modal-cancel px-4" data-bs-dismiss="modal">Lanjut Mengedit</button>
                    <a href="detail-transaksi.php?id=<?= $penjualan_id; ?>" class="btn btn-modal-yes px-4 text-decoration-none">Lihat Detail</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
const ORIGINAL = <?= json_encode([
    'nama'  => $transaksi['NamaFinalPelanggan'],
    'items' => array_reduce($details, function ($c, $d) {
        $c[(int) $d['DetailID']] = ['nama' => $d['NamaProduk'], 'cat' => trim((string) $d['Catatan']), 'extra' => (float) $d['BiayaExtra']];
        return $c;
    }, []),
], JSON_UNESCAPED_UNICODE); ?>;
const fmtRp = n => 'Rp ' + Math.round(n).toLocaleString('id-ID');

function ambilPerubahan() {
    const out = [];
    const namaInp = document.querySelector('[name="NamaPelanggan"]');
    if (namaInp && !namaInp.readOnly && namaInp.value.trim() !== ORIGINAL.nama) {
        out.push(['Nama pelanggan', ORIGINAL.nama, namaInp.value.trim() || '(kosong)']);
    }
    Object.keys(ORIGINAL.items).forEach(id => {
        const it = ORIGINAL.items[id];
        const c = document.querySelector('[name="catatan_item[' + id + ']"]');
        const e = document.querySelector('[name="biaya_extra_item[' + id + ']"]');
        if (c && c.value.trim() !== it.cat) out.push(['Catatan ' + it.nama, it.cat || '(kosong)', c.value.trim() || '(kosong)']);
        if (e && !e.readOnly) {
            const v = Math.max(0, parseFloat(e.value) || 0);
            if (v !== it.extra) out.push(['Biaya extra ' + it.nama, fmtRp(it.extra), fmtRp(v)]);
        }
    });
    return out;
}

function barisRingkas(label, dari, ke) {
    const li = document.createElement('li'); li.className = 'ringkas-item';
    const l = document.createElement('div'); l.className = 'ringkas-label'; l.textContent = label;
    const n = document.createElement('div'); n.className = 'ringkas-nilai';
    const a = document.createElement('span'); a.className = 'dari'; a.textContent = dari;
    const k = document.createElement('strong'); k.className = 'ke'; k.textContent = ke;
    n.append(a, document.createTextNode(' → '), k);
    li.append(l, n);
    return li;
}

document.getElementById('konfirmasiSimpanModal').addEventListener('show.bs.modal', function () {
    if (typeof hitungSemua === 'function') hitungSemua();
    const box = document.getElementById('ringkasPerubahan');
    const btn = document.getElementById('btnYaSimpan');
    const daftar = ambilPerubahan();
    box.innerHTML = '';
    if (daftar.length === 0) {
        box.innerHTML = '<div class="ringkas-kosong"><i class="bi bi-info-circle me-1"></i> Belum ada perubahan yang dilakukan.</div>';
        btn.disabled = true;
        return;
    }
    btn.disabled = false;
    const ul = document.createElement('ul'); ul.className = 'ringkas-list';
    daftar.forEach(r => ul.appendChild(barisRingkas(r[0], r[1], r[2])));
    const totalBaru = window.totalBaruTerakhir;
    if (typeof totalBaru === 'number' && Math.round(totalBaru) !== Math.round(TOTAL_LAMA)) {
        ul.appendChild(barisRingkas('Total transaksi', fmtRp(TOTAL_LAMA), fmtRp(totalBaru)));
    }
    box.appendChild(ul);
});

<?php if (!empty($flash)): ?>
window.addEventListener('load', function () {
    bootstrap.Modal.getOrCreateInstance(document.getElementById('modalBerhasil')).show();
});
<?php endif; ?>
</script>
</body>
</html>