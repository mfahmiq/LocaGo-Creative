<?php
// Pastikan path header.php sudah sesuai (karena file ini di folder kasir, panggil header.php langsung)
include 'header.php'; 

// Query data produk diurutkan berdasarkan ID terbaru
$q_produk = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY ProdukID DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog Menu & Stok - Daily Coffee & Toast</title>
    
    <!-- Bootstrap CSS (Disesuaikan path-nya ke folder asset dari posisi kasir) -->
    <link href="../asset/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        body {
            background-color: #FAF8F5;
        }

        /* Penyesuaian wrapper konten agar pas dengan sidebar di folder kasir */
        .wrapper-konten-admin {
            margin-top: 20px;
            padding-right: 15px;
            padding-bottom: 50px;
        }

        /* Tombol Kategori Tab */
        .btn-tab-kategori {
            background: #FFFFFF;
            border: 1.5px solid #E7E5E4;
            color: #78716C;
            font-weight: 600;
            border-radius: 12px;
            padding: 0.6rem 1.25rem;
            transition: all 0.2s ease;
        }

        .btn-tab-kategori.active, .btn-tab-kategori:hover {
            background: #C49A45;
            color: #FFFFFF;
            border-color: #C49A45;
            box-shadow: 0 4px 12px rgba(196, 154, 69, 0.25);
        }

        /* Card Katalog Produk Visual */
        .catalog-card {
            background: #FFFFFF;
            border-radius: 20px;
            border: 1px solid rgba(231, 229, 228, 0.9);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.03);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            overflow: hidden;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .catalog-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 18px 35px rgba(196, 154, 69, 0.18);
            border-color: #C49A45;
        }

        .catalog-img-wrapper {
            width: 100%;
            height: 180px;
            background-color: #FAF8F5;
            position: relative;
            overflow: hidden;
        }

        .catalog-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.4s ease;
        }

        .catalog-card:hover .catalog-img {
            transform: scale(1.08);
        }

        .badge-float-stok {
            position: absolute;
            top: 12px;
            right: 12px;
            font-weight: 800;
            font-size: 0.8rem;
            padding: 6px 14px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
            color: #FFFFFF;
        }

        .stok-safe { background: #198754; }
        .stok-warning { background: #F59E0B; }
        .stok-danger { background: #DC3545; }

        .search-katalog-input {
            border-radius: 14px;
            padding: 0.75rem 1.25rem;
            border: 1px solid #E7E5E4;
            font-size: 0.95rem;
            background-color: #FFFFFF;
        }

        .search-katalog-input:focus {
            border-color: #C49A45;
            box-shadow: 0 0 0 4px rgba(196, 154, 69, 0.1);
        }

        .btn-action-circle {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        }

        .btn-edit-katalog {
            background: #FAF8F5;
            color: #141211;
            border: 1px solid #E7E5E4;
        }

        .btn-edit-katalog:hover {
            background: #C49A45;
            color: #FFFFFF;
            border-color: #C49A45;
        }

        .btn-delete-katalog {
            background: #FFF5F5;
            color: #DC3545;
            border: 1px solid #FFE3E3;
        }

        .btn-delete-katalog:hover {
            background: #DC3545;
            color: #FFFFFF;
            border-color: #DC3545;
        }
    </style>
</head>
<body>

<!-- app-container adalah pembungkus bawaan header.php kasir -->
<div class="app-container">
    <div class="wrapper-konten-admin">
        <div class="container-fluid px-0">
            
            <!-- Header Halaman & Pencarian -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 bg-white p-4 rounded-4 shadow-sm border">
                <div>
                    <span class="badge px-3 py-1.5 rounded-pill fw-bold mb-2" style="background: rgba(196, 154, 69, 0.15); color: #C49A45; border: 1px solid rgba(196, 154, 69, 0.3);">
                        <i class="bi bi-grid-fill me-1"></i> MANAJEMEN MENU
                    </span>
                    <h3 class="fw-extrabold mb-1" style="color: #141211; letter-spacing: -0.5px;">
                        Katalog Menu &amp; Stok
                    </h3>
                    <p class="text-muted small mb-0">Kelola sajian khusus Daily Coffee &amp; Toast secara terpisah.</p>
                </div>

                <div class="d-flex flex-column flex-sm-row align-items-stretch align-items-sm-center gap-3">
                    <div class="position-relative" style="min-width: 260px;">
                        <input type="text" id="searchKatalog" class="form-control search-katalog-input ps-5" placeholder="Cari nama menu..." onkeyup="filterKatalog()">
                        <i class="bi bi-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
                    </div>

                    <!-- Tombol Tambah Menu khusus Admin (Jalur diarahkan keluar ke ../admin/) -->
                    <?php if (isset($user_role) && $user_role === 'admin'): ?>
                        <a href="../admin/produk-tambah.php" class="btn px-4 py-2.5 fw-bold rounded-3 shadow-sm text-white d-inline-flex align-items-center justify-content-center gap-2 text-nowrap" style="background: linear-gradient(135deg, #C49A45 0%, #A37B2C 100%); border: none;">
                            <i class="bi bi-plus-circle-fill fs-6"></i>
                            <span>Tambah Menu</span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Tombol Filter Kategori (Coffee & Toast) -->
            <div class="d-flex align-items-center gap-2 mb-4">
                <button class="btn btn-tab-kategori active" onclick="filterKategori('semua')" id="btnSemua">
                    <i class="bi bi-ui-checks-grid me-1"></i> Semua Menu
                </button>
                <button class="btn btn-tab-kategori" onclick="filterKategori('coffee')" id="btnCoffee">
                    <i class="bi bi-cup-hot-fill me-1"></i> Coffee Section
                </button>
                <button class="btn btn-tab-kategori" onclick="filterKategori('toast')" id="btnToast">
                    <i class="bi bi-shop me-1"></i> Toast Section
                </button>
            </div>

            <!-- Grid Katalog Produk -->
            <div class="row g-4" id="containerKatalog">
                <?php if (mysqli_num_rows($q_produk) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($q_produk)): 
                        $nama_foto = !empty($row['foto']) ? $row['foto'] : 'default.jpg';
                        // Path folder asset gambar dari sudut pandang folder kasir
                        $path_foto = '../asset/img/' . $nama_foto;
                        
                        if (!file_exists($path_foto) || empty($row['foto'])) {
                            $path_foto = 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80';
                        }

                        $stok = (int)$row['Stok'];
                        $nama_menu_lower = strtolower($row['NamaProduk']);
                        
                        // Deteksi otomatis kategori berdasarkan nama produk
                        $kategori = 'coffee';
                        if (str_contains($nama_menu_lower, 'toast') || str_contains($nama_menu_lower, 'roti') || str_contains($nama_menu_lower, 'sandwich')) {
                            $kategori = 'toast';
                        }
                    ?>
                    <div class="col-6 col-md-4 col-lg-3 card-item-produk" data-nama="<?= htmlspecialchars($nama_menu_lower); ?>" data-kategori="<?= $kategori; ?>">
                        <div class="catalog-card">
                            
                            <div class="catalog-img-wrapper">
                                <img src="<?= $path_foto; ?>" alt="<?= htmlspecialchars($row['NamaProduk']); ?>" class="catalog-img">
                                
                                <!-- Label Badge Kategori Kecil di Pojok Kiri Atas -->
                                <span class="badge position-absolute top-0 start-0 m-2 px-2 py-1 shadow-sm" style="font-size: 0.68rem; background: rgba(0,0,0,0.6); color: #fff; backdrop-filter: blur(4px);">
                                    <?= ($kategori === 'toast') ? '🍞 Toast' : '☕ Coffee'; ?>
                                </span>

                                <?php if ($stok > 10): ?>
                                    <span class="badge-float-stok stok-safe"><i class="bi bi-box-seam me-1"></i>Stok: <?= $stok; ?></span>
                                <?php elseif ($stok > 0): ?>
                                    <span class="badge-float-stok stok-warning"><i class="bi bi-exclamation-triangle me-1"></i>Sisa: <?= $stok; ?></span>
                                <?php else: ?>
                                    <span class="badge-float-stok stok-danger"><i class="bi bi-x-circle me-1"></i>Habis</span>
                                <?php endif; ?>
                            </div>

                            <div class="p-3 d-flex flex-column justify-content-between flex-grow-1">
                                <div>
                                    <h6 class="fw-bold text-dark mb-1 text-truncate" title="<?= htmlspecialchars($row['NamaProduk']); ?>">
                                        <?= htmlspecialchars($row['NamaProduk']); ?>
                                    </h6>
                                    <div class="mb-2">
                                        <small class="text-muted">Sisa Stok: </small>
                                        <span class="fw-bold <?= ($stok > 10) ? 'text-success' : (($stok > 0) ? 'text-warning' : 'text-danger'); ?>">
                                            <?= $stok; ?> pcs
                                        </span>
                                    </div>
                                    <h6 class="fw-extrabold text-success mb-0" style="font-size: 1.05rem;">
                                        Rp <?= number_format($row['Harga'], 0, ',', '.'); ?>
                                    </h6>
                                </div>

                                <!-- Tombol Aksi Edit & Hapus khusus Admin (Jalur diarahkan keluar ke ../admin/) -->
                                <?php if (isset($user_role) && $user_role === 'admin'): ?>
                                    <div class="d-flex align-items-center justify-content-end gap-2 mt-3 pt-2 border-top">
                                        <a href="../admin/produk-edit.php?id=<?= $row['ProdukID']; ?>" class="btn-action-circle btn-edit-katalog text-decoration-none" title="Edit Menu">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>
                                        <a href="../admin/produk-hapus.php?id=<?= $row['ProdukID']; ?>" class="btn-action-circle btn-delete-katalog text-decoration-none" onclick="return confirm('Apakah Anda yakin ingin menghapus menu ini?')" title="Hapus Menu">
                                            <i class="bi bi-trash3-fill"></i>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="col-12 text-center py-5 text-muted">
                        <i class="bi bi-cup-hot fs-1 d-block mb-2 text-warning opacity-50"></i>
                        Belum ada menu yang terdaftar di katalog.
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

<script>
let kategoriAktif = 'semua';

function filterKategori(kategori) {
    kategoriAktif = kategori;
    
    // Ubah status aktif tombol tab
    document.querySelectorAll('.btn-tab-kategori').forEach(btn => btn.classList.remove('active'));
    if (kategori === 'semua') document.getElementById('btnSemua').classList.add('active');
    if (kategori === 'coffee') document.getElementById('btnCoffee').classList.add('active');
    if (kategori === 'toast') document.getElementById('btnToast').classList.add('active');

    jalankanFilter();
}

function filterKatalog() {
    jalankanFilter();
}

function jalankanFilter() {
    let inputSearch = document.getElementById('searchKatalog').value.toLowerCase();
    let items = document.getElementsByClassName('card-item-produk');

    Array.from(items).forEach(function(item) {
        let nama = item.getAttribute('data-nama');
        let kat = item.getAttribute('data-kategori');
        
        let cocokKategori = (kategoriAktif === 'semua' || kat === kategoriAktif);
        let cocokSearch = nama.includes(inputSearch);

        if (cocokKategori && cocokSearch) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}
</script>

<!-- Bootstrap JS Bundle (Disesuaikan path-nya ke folder asset dari posisi kasir) -->
<script src="../asset/js/bootstrap.bundle.min.js"></script>
</body>
</html>