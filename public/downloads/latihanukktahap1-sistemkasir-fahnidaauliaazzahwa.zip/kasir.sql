-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Okt 2026 pada 07.55
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kasir`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `audit_log`
--

CREATE TABLE `audit_log` (
  `id` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `aktivitas` text DEFAULT NULL,
  `deskripsi` text NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `audit_log`
--

INSERT INTO `audit_log` (`id`, `username`, `aktivitas`, `deskripsi`, `waktu`) VALUES
(17, 'Admin Kedai', 'BATALKAN TRANSAKSI', 'Admin (Admin Kedai) membatalkan Transaksi #31 (Status diubah menjadi Dibatalkan & stok dikembalikan).', '2026-09-24 04:48:32'),
(18, 'admin', 'TAMBAH TRANSAKSI', 'Menambahkan transaksi baru #32', '2026-09-24 05:57:44'),
(19, 'Kasir1', 'LOGIN SISTEM', 'Kasir (Baneswara Syailendra) berhasil masuk ke dalam sistem.', '2026-09-24 06:17:49'),
(20, 'Kasir1', 'TAMBAH TRANSAKSI', 'Menambahkan transaksi baru #33', '2026-09-24 06:29:18'),
(21, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-24 06:49:51'),
(22, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-24 06:50:47'),
(23, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-24 14:54:55'),
(24, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Toast mix Berries and Banana', '2026-09-24 15:04:19'),
(25, 'Admin', 'Ubah', 'Mengubah data menu/produk: Choco Crunch Toast (Harga: Rp 18.000, Stok: 34)', '2026-09-24 15:06:40'),
(26, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Cheesy Scrambled Eeg Toast ', '2026-09-24 15:13:01'),
(27, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Butterscotch Sea Salt Latte', '2026-09-24 15:33:36'),
(28, 'Admin', 'Ubah', 'Mengubah data menu/produk: Butterscotch Sea Salt Latte (Harga: Rp 32.000, Stok: 15)', '2026-09-24 15:34:36'),
(29, 'Admin', 'Ubah', 'Mengubah data menu/produk: butter tock (Harga: Rp 70.000, Stok: 0)', '2026-09-24 15:38:39'),
(30, 'Admin', 'Ubah', 'Mengubah data menu produk PRD-00001 — Nama: butter tock → baju, Harga: Rp70.000 → Rp20.000, Stok: 0 → 3, Foto produk diubah', '2026-09-24 15:46:17'),
(31, 'Admin', 'TAMBAH TRANSAKSI', 'Menambahkan transaksi baru #34', '2026-09-24 16:05:06'),
(32, NULL, 'User \'Administrator\' mengubah status transaksi TRX-20260924-0032 menjadi SELESAI.', '', '2026-09-24 16:17:32'),
(33, NULL, 'User \'Administrator\' membatalkan transaksi TRX-20260923-0027 (Void) dan stok dikembalikan.', '', '2026-09-24 16:24:51'),
(34, NULL, 'User \'Administrator\' mengubah status transaksi TRX-20260924-0030 menjadi SELESAI.', '', '2026-09-24 16:28:02'),
(35, NULL, 'User \'Administrator\' membatalkan transaksi TRX-20260924-0029 (Void) dan stok dikembalikan.', '', '2026-09-24 16:28:11'),
(36, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260924-0028', '2026-09-24 16:30:31'),
(37, 'Admin', 'BATAL', 'User Administrator membatalkan transaksi dengan ID TRX-20260923-0023', '2026-09-24 16:30:37'),
(38, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-25 00:17:12'),
(39, 'Kasir1', 'LOGIN SISTEM', 'Kasir (Baneswara Syailendra) berhasil masuk ke dalam sistem.', '2026-09-25 03:01:58'),
(40, 'Kasir1', 'LOGIN SISTEM', 'Kasir (Baneswara Syailendra) berhasil masuk ke dalam sistem.', '2026-09-25 03:06:13'),
(41, 'Kasir1', 'LOGIN SISTEM', 'Kasir (Baneswara Syailendra) berhasil masuk ke dalam sistem.', '2026-09-25 03:11:29'),
(42, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-25 03:12:20'),
(43, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-25 03:19:53'),
(44, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260923-0026', '2026-09-25 03:31:13'),
(45, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260923-0025', '2026-09-25 03:31:26'),
(46, 'Admin', 'BATAL', 'User Administrator membatalkan transaksi dengan ID TRX-20260923-0024', '2026-09-25 03:31:35'),
(47, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-25 03:45:37'),
(48, 'Kasir1', 'LOGIN SISTEM', 'Kasir (Baneswara Syailendra) berhasil masuk ke dalam sistem.', '2026-09-27 06:50:51'),
(49, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-27 06:58:38'),
(50, 'Admin', 'Ubah', 'Mengubah data menu produk PRD-00001 — Nama: baju → Ice Chocolate, Stok: 3 → 15, Foto produk diubah', '2026-09-27 06:59:32'),
(51, 'Admin', 'Ubah', 'Mengubah data menu produk PRD-00003 — Nama: Americano Warm → Americano Warm/Iced', '2026-09-27 07:01:06'),
(52, 'Admin', 'Ubah', 'Mengubah data menu produk PRD-00001 — Nama: Ice Chocolate → Chocolate Warm/Iced', '2026-09-27 07:01:36'),
(53, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Lychee Tea', '2026-09-27 07:03:13'),
(54, 'Admin', 'Ubah', 'Mengubah data menu produk PRD-00013 — Foto produk diubah', '2026-09-27 07:04:14'),
(55, 'Admin', 'Ubah', 'Mengubah data menu produk PRD-00013 — Foto produk diubah', '2026-09-27 07:05:28'),
(56, 'Admin', 'Ubah', 'Mengubah data menu produk PRD-00013 — Foto produk diubah', '2026-09-27 07:06:50'),
(57, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Red Velvet Latte', '2026-09-27 07:11:10'),
(58, 'Admin', 'Ubah', 'Mengubah data menu produk PRD-00014 — Foto produk diubah', '2026-09-27 07:12:40'),
(59, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Garlic Cheese Toast', '2026-09-27 07:14:16'),
(60, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Avocado Toast', '2026-09-27 07:15:10'),
(61, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Taro Latte', '2026-09-27 07:16:13'),
(62, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Earl Grey Milk Tea', '2026-09-27 07:17:58'),
(63, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Dirty Matcha', '2026-09-27 07:18:58'),
(64, 'Admin', 'Ubah', 'Mengubah data menu produk PRD-00019 — Foto produk diubah', '2026-09-27 07:19:52'),
(65, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Kopi Susu Aren Signature', '2026-09-27 07:21:41'),
(66, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Spicy Tuna Mayo Toast', '2026-09-27 07:23:50'),
(67, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Lotus Biscoff Toast', '2026-09-27 07:26:28'),
(68, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Nutella Banana Toast', '2026-09-27 07:28:08'),
(69, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Lemon Curd Lavender Toast', '2026-09-27 07:29:43'),
(70, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Strawberry Cream Cheese Toast', '2026-09-27 07:31:13'),
(71, 'Admin', 'TAMBAH PRODUK', 'Menambahkan produk baru: Lemonade Yakult', '2026-09-27 07:33:22'),
(72, 'Admin', 'TAMBAH', 'Menambahkan data user dengan ID DAILYUSR7, Nama: Jivala, Username: @Kasir2, Role: Kasir', '2026-09-27 08:25:53'),
(73, 'Admin', 'UBAH', 'Mengubah data user dengan ID DAILYUSR7, Nama: Jivala Kirana, Username: @Kasir6, Role: Admin', '2026-09-27 08:26:24'),
(74, 'Admin', 'HAPUS', 'Menghapus data user dengan ID DAILYUSR7, Nama: Jivala Kirana, Username: @Kasir6, Role: Admin', '2026-09-27 08:26:32'),
(75, 'Admin', 'TAMBAH', 'Menambahkan data user dengan ID DAILYUSR8, Nama: Jivala Kirana, Username: @Kasir2, Role: Admin', '2026-09-27 08:27:14'),
(76, 'Admin', 'UBAH', 'Mengubah data user dengan ID DAILYUSR8, Nama: Jivala Kirana, Username: @admin2, Role: Admin', '2026-09-27 08:27:45'),
(77, 'Admin', 'UBAH', 'Mengubah data user dengan ID DAILYUSR3, Nama: Chika Anastasya, Username: @kasir2, Role: Kasir', '2026-09-27 08:28:05'),
(78, 'Admin', 'UBAH', 'Mengubah data user dengan ID DAILYUSR2, Nama: Baneswara Syailendra, Username: @kasir1, Role: Kasir', '2026-09-27 08:28:23'),
(79, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-27 09:08:31'),
(80, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-27 09:24:21'),
(81, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-27 09:30:51'),
(82, 'Admin', 'LOGOUT', 'Pengguna dengan username Admin keluar dari sistem', '2026-09-27 09:32:41'),
(83, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-27 09:32:51'),
(84, 'Admin', 'LOGOUT', 'Pengguna dengan username Admin keluar dari sistem', '2026-09-27 09:35:21'),
(85, 'kasir1', 'LOGIN SISTEM', 'Kasir (Baneswara Syailendra) berhasil masuk ke dalam sistem.', '2026-09-27 09:36:41'),
(86, 'kasir1', 'LOGOUT', 'Pengguna dengan username kasir1 keluar dari sistem', '2026-09-27 09:36:50'),
(87, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-27 09:37:01'),
(88, 'Admin', 'LOGOUT', 'Admin (Administrator) berhasil keluar dari sistem.', '2026-09-27 09:43:19'),
(89, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-27 09:43:32'),
(90, 'kasir1', 'LOGIN SISTEM', 'Kasir (Baneswara Syailendra) berhasil masuk ke dalam sistem.', '2026-09-27 09:55:36'),
(91, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-27 09:58:36'),
(92, 'Admin', 'TAMBAH TRANSAKSI', 'Menambahkan transaksi baru #35', '2026-09-27 10:10:52'),
(93, 'Admin', 'TAMBAH TRANSAKSI', 'Menambahkan transaksi baru #36', '2026-09-27 10:29:11'),
(94, 'Admin', 'TAMBAH TRANSAKSI', 'Menambahkan transaksi baru #37', '2026-09-27 10:51:05'),
(95, 'Admin', 'TAMBAH TRANSAKSI', 'Menambahkan transaksi baru #38', '2026-09-27 11:02:16'),
(96, 'Admin', 'LOGOUT', 'Admin (Administrator) berhasil keluar dari sistem.', '2026-09-27 13:10:48'),
(97, 'kasir1', 'LOGIN SISTEM', 'Kasir (Baneswara Syailendra) berhasil masuk ke dalam sistem.', '2026-09-27 13:11:17'),
(98, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-28 10:02:09'),
(99, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-28 10:30:27'),
(101, 'Admin', 'TAMBAH', 'Menambahkan transaksi baru TRX-20260928-0052', '2026-09-28 11:51:15'),
(102, 'kasir1', 'LOGIN SISTEM', 'Kasir (Baneswara Syailendra) berhasil masuk ke dalam sistem.', '2026-09-29 09:20:20'),
(103, 'kasir1', 'TAMBAH', 'Menambahkan transaksi baru TRX-20260929-0053', '2026-09-29 09:35:41'),
(104, 'kasir1', 'TAMBAH', 'Menambahkan transaksi baru TRX-20260929-0054', '2026-09-29 10:00:55'),
(105, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-29 10:04:55'),
(106, 'Admin', 'TAMBAH', 'Menambahkan transaksi baru TRX-20260929-0055', '2026-09-29 10:10:34'),
(107, 'Admin', 'TAMBAH', 'Menambahkan transaksi baru TRX-20260929-0056', '2026-09-29 10:14:23'),
(108, 'Admin', 'LOGOUT', 'Admin (Administrator) berhasil keluar dari sistem.', '2026-09-29 10:27:05'),
(109, 'kasir1', 'LOGIN SISTEM', 'Kasir (Baneswara Syailendra) berhasil masuk ke dalam sistem.', '2026-09-29 10:27:20'),
(110, 'kasir1', 'SELESAI', 'User Baneswara Syailendra menyelesaikan transaksi dengan ID TRX-20260929-0056', '2026-09-29 10:28:33'),
(111, 'kasir1', 'LOGIN SISTEM', 'Kasir (Baneswara Syailendra) berhasil masuk ke dalam sistem.', '2026-09-29 10:29:02'),
(112, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-29 10:34:33'),
(113, 'Admin', 'LOGOUT', 'Admin (Administrator) berhasil keluar dari sistem.', '2026-09-29 10:54:10'),
(114, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-29 10:54:23'),
(115, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-29 11:05:23'),
(116, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260929-0056', '2026-09-29 11:06:09'),
(117, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260929-0056', '2026-09-29 11:06:14'),
(118, 'Admin', 'BATAL', 'User Administrator membatalkan transaksi dengan ID TRX-20260929-0056', '2026-09-29 11:09:59'),
(119, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260929-0056', '2026-09-29 11:10:50'),
(120, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260929-0056', '2026-09-29 11:16:09'),
(121, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260929-0056', '2026-09-29 11:16:15'),
(122, 'Admin', 'BATAL', 'User Administrator membatalkan transaksi dengan ID TRX-20260929-0055', '2026-09-29 11:17:09'),
(123, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260929-0054', '2026-09-29 11:22:39'),
(124, 'Admin', 'BATAL', 'User Administrator membatalkan transaksi dengan ID TRX-20260929-0053', '2026-09-29 11:22:45'),
(125, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260928-0052', '2026-09-29 11:47:51'),
(126, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260928-0051', '2026-09-29 11:51:17'),
(127, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260928-0050', '2026-09-29 11:51:40'),
(128, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260928-0049', '2026-09-29 11:56:25'),
(129, 'Admin', 'BATAL', 'User Administrator membatalkan transaksi dengan ID TRX-20260928-0048', '2026-09-29 11:56:51'),
(130, 'Admin', 'SELESAI', 'User Administrator menyelesaikan transaksi dengan ID TRX-20260927-0047', '2026-09-29 12:00:16'),
(131, 'Admin', 'BATAL', 'User Administrator membatalkan transaksi dengan ID TRX-20260927-0046', '2026-09-29 12:00:26'),
(132, 'Admin', 'LOGOUT', 'Admin (Administrator) berhasil keluar dari sistem.', '2026-09-29 12:00:38'),
(133, 'kasir1', 'LOGIN SISTEM', 'Kasir (Baneswara Syailendra) berhasil masuk ke dalam sistem.', '2026-09-29 12:00:47'),
(134, 'kasir1', 'SELESAI', 'User Baneswara Syailendra menyelesaikan transaksi dengan ID TRX-20260927-0045', '2026-09-29 12:01:01'),
(135, 'kasir1', 'BATAL', 'User Baneswara Syailendra membatalkan transaksi dengan ID TRX-20260927-0044', '2026-09-29 12:01:11'),
(136, 'kasir1', 'LOGOUT', 'Kasir (Baneswara Syailendra) berhasil keluar dari sistem.', '2026-09-29 12:03:08'),
(137, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-29 12:03:17'),
(138, 'Admin', 'LOGOUT', 'Admin (Administrator) berhasil keluar dari sistem.', '2026-09-29 12:04:30'),
(139, 'kasir2', 'LOGIN SISTEM', 'Kasir (Chika Anastasya) berhasil masuk ke dalam sistem.', '2026-09-29 12:05:26'),
(140, 'kasir2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20260929-0057', '2026-09-29 12:06:31'),
(141, 'kasir2', 'SELESAI', 'User Chika Anastasya menyelesaikan transaksi dengan ID TRX-20260929-0057', '2026-09-29 12:07:09'),
(142, 'kasir2', 'LOGOUT', 'Kasir (Chika Anastasya) berhasil keluar dari sistem.', '2026-09-29 12:08:19'),
(143, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-09-29 12:09:07'),
(144, 'admin2', 'TAMBAH PRODUK', 'Menambahkan produk baru: Sweet Mango Cloud Toast ', '2026-09-29 12:11:31'),
(145, 'admin2', 'TAMBAH PRODUK', 'Menambahkan produk baru: Rose & Pistachio Indulgence Toast', '2026-09-29 12:14:32'),
(146, 'admin2', 'TAMBAH PRODUK', 'Menambahkan produk baru: High Protein Berry Loaded Toast', '2026-09-29 12:15:57'),
(147, 'admin2', 'TAMBAH PRODUK', 'Menambahkan produk baru: xws', '2026-09-29 12:18:58'),
(148, 'admin2', 'Ubah', 'Mengubah data menu produk PRD-00030 — Nama: xws → Caramel Macchiato, Harga: Rp121 → Rp29.000, Stok: 12 → 15, Foto produk diubah', '2026-09-29 12:20:17'),
(149, 'admin2', 'TAMBAH PRODUK', 'Menambahkan produk baru: Wanita mantep', '2026-09-29 12:21:29'),
(150, 'admin2', 'LOGOUT', 'Admin (Jivala Kirana) berhasil keluar dari sistem.', '2026-09-29 12:24:53'),
(151, 'Admin', 'LOGIN SISTEM', 'Admin (Administrator) berhasil masuk ke dalam sistem.', '2026-09-30 02:23:44'),
(152, 'Admin', 'LOGOUT', 'Admin (Administrator) berhasil keluar dari sistem.', '2026-09-30 03:08:44'),
(153, 'kasir2', 'LOGIN SISTEM', 'Kasir (Chika Anastasya) berhasil masuk ke dalam sistem.', '2026-09-30 03:09:54'),
(154, 'kasir2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20260930-0058', '2026-09-30 03:12:42'),
(155, 'kasir2', 'LOGOUT', 'Kasir (Chika Anastasya) berhasil keluar dari sistem.', '2026-09-30 03:23:05'),
(156, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-09-30 03:23:15'),
(157, 'admin2', 'LOGOUT', 'Admin (Jivala Kirana) berhasil keluar dari sistem.', '2026-09-30 03:24:50'),
(158, 'kasir2', 'LOGIN SISTEM', 'Kasir (Chika Anastasya) berhasil masuk ke dalam sistem.', '2026-09-30 03:25:49'),
(159, 'kasir2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20260930-0059', '2026-09-30 03:29:17'),
(160, 'kasir2', 'SELESAI', 'User Chika Anastasya menyelesaikan transaksi dengan ID TRX-20260930-0059', '2026-09-30 03:29:44'),
(161, 'kasir2', 'BATAL', 'User Chika Anastasya membatalkan transaksi dengan ID TRX-20260930-0058', '2026-09-30 03:29:50'),
(162, 'kasir2', 'LOGOUT', 'Kasir (Chika Anastasya) berhasil keluar dari sistem.', '2026-09-30 03:30:17'),
(163, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-09-30 03:30:24'),
(164, 'admin2', 'TAMBAH PRODUK', 'Menambahkan produk baru: Signature Prime', '2026-09-30 03:31:44'),
(165, 'admin2', 'LOGOUT', 'Admin (Jivala Kirana) berhasil keluar dari sistem.', '2026-09-30 03:41:21'),
(166, 'kasir2', 'LOGIN SISTEM', 'Kasir (Chika Anastasya) berhasil masuk ke dalam sistem.', '2026-09-30 03:41:30'),
(167, 'kasir2', 'LOGOUT', 'Kasir (Chika Anastasya) berhasil keluar dari sistem.', '2026-09-30 03:44:46'),
(168, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-09-30 03:44:59'),
(169, 'admin2', 'LOGOUT', 'Admin (Jivala Kirana) berhasil keluar dari sistem.', '2026-09-30 03:45:38'),
(170, 'kasir2', 'LOGIN SISTEM', 'Kasir (Chika Anastasya) berhasil masuk ke dalam sistem.', '2026-09-30 03:45:53'),
(171, 'kasir2', 'LOGOUT', 'Kasir (Chika Anastasya) berhasil keluar dari sistem.', '2026-09-30 03:53:26'),
(172, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-09-30 03:53:32'),
(173, 'admin2', 'EDIT TRANSAKSI & DETAIL', 'Admin (admin2) memperbarui Transaksi TRX-20260927-0040. Total Lama: Rp 52.000 -> Total Baru: Rp 52.000', '2026-09-30 04:17:55'),
(174, 'admin2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20260930-0060', '2026-09-30 04:26:37'),
(175, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-09-30 06:32:33'),
(176, 'admin2', 'EDIT TRANSAKSI & DETAIL', 'Admin (admin2) memperbarui Transaksi TRX-20260930-0060. Total Lama: Rp 48.000 -> Total Baru: Rp 53.000', '2026-09-30 06:33:26'),
(177, 'admin2', 'SELESAI', 'User Jivala Kirana menyelesaikan transaksi dengan ID TRX-20260930-0060', '2026-09-30 06:33:56'),
(178, 'admin2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20260930-0061', '2026-09-30 07:07:27'),
(179, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-09-30 11:21:17'),
(180, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-01 05:54:15'),
(181, 'admin2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20261001-0062', '2026-10-01 05:55:49'),
(182, 'admin2', 'SELESAI', 'User Jivala Kirana menyelesaikan transaksi dengan ID TRX-20261001-0062', '2026-10-01 05:56:25'),
(183, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-01 06:22:04'),
(184, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-02 03:12:33'),
(185, 'admin2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20261002-0063 (Diskon Member 5%) (Termasuk Bonus Gratis: Caramel Latte Ice)', '2026-10-02 04:49:19'),
(186, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-02 09:30:25'),
(187, 'admin2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20261002-0064 (Tunai)', '2026-10-02 10:07:27'),
(188, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-02 11:10:05'),
(189, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-02 11:12:17'),
(190, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-02 11:12:30'),
(191, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-02 11:13:24'),
(192, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-02 11:14:05'),
(193, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-02 11:18:18'),
(194, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-02 11:49:24'),
(195, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-02 11:51:59'),
(196, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-03 10:39:25'),
(197, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-03 10:41:01'),
(198, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-03 10:45:04'),
(199, 'admin2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20261003-0065 (QRIS) (Diskon Member 5%: -Rp 3.500)', '2026-10-03 10:51:15'),
(200, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-03 11:57:00'),
(201, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-03 11:57:21'),
(202, 'admin2', 'EDIT', 'Admin (admin2) mengoreksi transaksi TRX-20261002-0064 (Tunai). Perubahan: catatan Sweet Mango Cloud Toast , extra Sweet Mango Cloud Toast  Rp 10.000. Total: Rp 28.000 -> Rp 38.000', '2026-10-03 11:59:45'),
(203, 'admin2', 'EDIT', 'Kasir (admin2) mengoreksi transaksi TRX-20261002-0064. Detail perubahan: Catatan item Sweet Mango Cloud Toast  (\"extra keju\" -> \"extra keju pedas wahahhah\"), Biaya extra Sweet Mango Cloud Toast  (Rp 10.000 -> Rp 15.000). Total: Rp 38.000 -> Rp 43.000', '2026-10-03 12:01:38'),
(204, 'admin2', 'UBAH', 'Admin (admin2) mengoreksi transaksi TRX-20261002-0064 (Tunai). Perubahan: Catatan Sweet Mango Cloud Toast : “extra keju pedas wahahhah” → “extra keju pedas wahahhah duar”; Biaya extra Sweet Mango Cloud Toast : Rp 15.000 → Rp 20.000. Total: Rp 43.000 -> Rp 48.000', '2026-10-03 12:15:53'),
(205, 'admin2', 'UBAH', 'Admin (admin2) mengoreksi transaksi TRX-20261002-0064 (Tunai). Perubahan: Catatan Sweet Mango Cloud Toast : “extra keju pedas wahahhah duar” → “extra keju pedas wahahhah duar mampus”; Biaya extra Sweet Mango Cloud Toast : Rp 20.000 → Rp 25.000. Total: Rp 48.000 -> Rp 53.000', '2026-10-03 12:18:07'),
(206, 'admin2', 'UBAH', 'Admin (admin2) mengoreksi transaksi TRX-20261002-0064 (Tunai). Perubahan: Catatan Sweet Mango Cloud Toast : “extra keju pedas wahahhah duar mampus” → “extra keju pedas wahahhah duar mampus jiakh”; Biaya extra Sweet Mango Cloud Toast : Rp 25.000 → Rp 18.000. Total: Rp 53.000 -> Rp 46.000', '2026-10-03 12:22:04'),
(207, 'admin2', 'UBAH', 'Admin (admin2) mengoreksi transaksi TRX-20261002-0064 (Tunai). Perubahan: Catatan Sweet Mango Cloud Toast : “extra keju pedas wahahhah duar mampus jiakh” → “extra keju pedas wahahhah duar mampus jiakh cuih”; Biaya extra Sweet Mango Cloud Toast : Rp 18.000 → Rp 16.000. Total: Rp 46.000 -> Rp 44.000', '2026-10-03 12:22:44'),
(208, 'admin2', 'UBAH', 'Admin (admin2) mengoreksi transaksi TRX-20261002-0064 (Tunai). Perubahan: Catatan Sweet Mango Cloud Toast : “extra keju pedas wahahhah duar mampus jiakh cuih” → “extra keju pedas wahahhah duar mampus jiakh  anjay”; Biaya extra Sweet Mango Cloud Toast : Rp 16.000 → Rp 23.000. Total: Rp 44.000 -> Rp 51.000', '2026-10-03 12:25:20'),
(209, 'admin2', 'Tambah Member', 'Menambahkan member baru dengan nama: Andin', '2026-10-03 12:28:47'),
(210, 'admin2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20261003-0066 (Tunai) (Diskon Member 5%: -Rp 3.700)', '2026-10-03 12:30:17'),
(211, 'admin2', 'SELESAI', 'User Jivala Kirana menyelesaikan transaksi dengan ID TRX-20261003-0066', '2026-10-03 12:32:06'),
(212, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-04 01:08:59'),
(213, 'admin2', 'LOGOUT', 'Admin (Jivala Kirana) berhasil keluar dari sistem.', '2026-10-04 01:34:15'),
(214, 'Andin', 'LOGIN SISTEM', 'Pelanggan (Andin) berhasil masuk ke dalam sistem.', '2026-10-04 02:03:37'),
(215, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-04 02:04:38'),
(216, 'admin2', 'LOGOUT', 'Admin (Jivala Kirana) berhasil keluar dari sistem.', '2026-10-04 02:07:10'),
(217, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-04 02:08:50'),
(218, 'Andin', 'LOGIN SISTEM', 'Pelanggan (Andin) berhasil masuk ke dalam sistem.', '2026-10-04 02:18:22'),
(219, 'Andin', 'LOGIN SISTEM', 'Pelanggan (Andin) berhasil masuk ke dalam sistem.', '2026-10-04 02:21:30'),
(220, 'admin2', 'LOGOUT', 'Admin (Jivala Kirana) berhasil keluar dari sistem.', '2026-10-04 02:22:55'),
(221, 'Andin', 'LOGIN SISTEM', 'Pelanggan (Andin) berhasil masuk ke dalam sistem.', '2026-10-04 02:23:15'),
(222, 'Andin', 'LOGIN SISTEM', 'Pelanggan (Andin) berhasil masuk ke dalam sistem.', '2026-10-04 02:23:37'),
(223, 'Andin', 'LOGIN SISTEM', 'Pelanggan (Andin) berhasil masuk ke dalam sistem.', '2026-10-04 02:24:13'),
(224, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-04 02:24:24'),
(225, 'admin2', 'LOGOUT', 'Admin (Jivala Kirana) berhasil keluar dari sistem.', '2026-10-04 02:25:28'),
(226, 'Andin', 'LOGIN SISTEM', 'Pelanggan (Andin) berhasil masuk ke dalam sistem.', '2026-10-04 02:26:30'),
(227, 'Andin', 'LOGIN SISTEM', 'Pelanggan (Andin) berhasil masuk ke dalam sistem.', '2026-10-04 02:27:20'),
(228, 'Andin', 'LOGIN SISTEM', 'Pelanggan (Andin) berhasil masuk ke dalam sistem.', '2026-10-04 02:27:32'),
(229, 'Budi Santoso', 'LOGIN SISTEM', 'Pelanggan (Budi Santoso) berhasil masuk ke dalam sistem.', '2026-10-04 02:30:18'),
(230, 'Budi Santoso', 'LOGIN SISTEM', 'Pelanggan (Budi Santoso) berhasil masuk ke dalam sistem.', '2026-10-04 02:34:57'),
(231, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-04 02:40:20'),
(232, 'admin2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20261004-0067 (Transfer Bank) (Diskon Member 5%: -Rp 7.650)', '2026-10-04 02:41:37'),
(233, 'Budi Santoso', 'LOGIN SISTEM', 'Pelanggan (Budi Santoso) berhasil masuk ke dalam sistem.', '2026-10-04 03:34:34'),
(234, 'System', 'TAMBAH', 'Pelanggan membuat pesanan mandiri TRX-20261004-0068 (Take-Away - QRIS)', '2026-10-04 03:38:19'),
(235, 'System', 'TAMBAH', 'Pelanggan membuat pesanan mandiri TRX-20261004-0069 (Take-Away - Tunai di Kasir)', '2026-10-04 03:40:03'),
(236, 'Budi Santoso', 'LOGIN SISTEM', 'Pelanggan (Budi Santoso) berhasil masuk ke dalam sistem.', '2026-10-04 03:44:21'),
(237, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-04 04:49:00'),
(238, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-04 10:49:05'),
(239, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-04 10:49:30'),
(240, 'admin2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20261004-0070 (Tunai)', '2026-10-04 10:57:58'),
(241, 'admin2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20261004-0071 (Tunai) (Diskon Member 5%: -Rp 3.350)', '2026-10-04 10:58:58'),
(242, 'admin2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20261004-0072 (Tunai) (Take-Away) (Diskon Member 5%: -Rp 3.900)', '2026-10-04 11:51:11'),
(243, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-06 11:33:38'),
(244, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-06 11:40:10'),
(245, 'admin2', 'SELESAI', 'User Jivala Kirana menyelesaikan transaksi dengan ID TRX-20261004-0071', '2026-10-06 11:40:44'),
(246, 'admin2', 'BATAL', 'User Jivala Kirana membatalkan transaksi dengan ID TRX-20261004-0070', '2026-10-06 11:40:50'),
(247, 'admin2', 'SELESAI', 'User Jivala Kirana menyelesaikan transaksi dengan ID TRX-20261004-0068', '2026-10-06 11:42:29'),
(248, 'admin2', 'SELESAI', 'User Jivala Kirana menyelesaikan transaksi dengan ID TRX-20261003-0065', '2026-10-06 12:12:05'),
(249, 'admin2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20261006-0073 (Tunai) (Take-Away)', '2026-10-06 12:14:53'),
(250, 'admin2', 'LOGOUT', 'Admin (Jivala Kirana) berhasil keluar dari sistem.', '2026-10-06 12:15:56'),
(251, 'Seonghyeon', 'LOGIN SISTEM', 'Pelanggan (Seonghyeon) berhasil masuk ke dalam sistem.', '2026-10-06 12:17:58'),
(252, 'System', 'TAMBAH', 'Pelanggan membuat pesanan mandiri TRX-20261006-0074 (Dine-In - QRIS)', '2026-10-06 12:30:19'),
(253, 'System', 'TAMBAH', 'Pelanggan membuat pesanan mandiri TRX-20261006-0075 (Take-Away - Transfer Bank)', '2026-10-06 12:36:30'),
(254, 'System', 'TAMBAH', 'Pelanggan membuat pesanan mandiri TRX-20261006-0076 (Take-Away - Tunai di Kasir)', '2026-10-06 12:42:01'),
(255, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-06 12:56:32'),
(256, 'admin2', 'LOGOUT', 'Admin (Jivala Kirana) berhasil keluar dari sistem.', '2026-10-06 12:56:39'),
(257, 'kasir2', 'LOGIN SISTEM', 'Kasir (Chika Anastasya) berhasil masuk ke dalam sistem.', '2026-10-06 12:56:48'),
(258, 'kasir2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20261006-0077 (Tunai) (Dine-In) (Diskon Member 5%: -Rp 2.850)', '2026-10-06 12:58:21'),
(259, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-08 00:33:19'),
(260, 'admin2', 'TAMBAH', 'Menambahkan transaksi baru TRX-20261008-0078 (Tunai) (Dine-In) (Diskon Member 5%: -Rp 5.200)', '2026-10-08 00:47:16'),
(261, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-14 22:19:44'),
(262, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-14 22:20:04'),
(263, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-15 03:51:31'),
(264, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-15 03:52:26'),
(265, 'admin2', 'LOGOUT', 'Admin (Jivala Kirana) berhasil keluar dari sistem.', '2026-10-15 06:58:30'),
(266, 'Andin', 'LOGIN SISTEM', 'Pelanggan (Andin) berhasil masuk ke dalam sistem.', '2026-10-15 07:00:22'),
(267, 'System', 'TAMBAH', 'Menambahkan transaksi baru TRX-20261015-0079 (QRIS) (Take-Away) (Diskon Member 5%: -Rp 3.700)', '2026-10-15 07:03:38'),
(268, 'admin', 'BATAL', 'User Andin membatalkan transaksi dengan ID TRX-20261008-0078', '2026-10-15 07:04:58'),
(269, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-15 07:05:18'),
(270, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-15 21:54:23'),
(271, 'admin2', 'LOGIN SISTEM', 'Admin (Jivala Kirana) berhasil masuk ke dalam sistem.', '2026-10-16 04:35:40');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bonus_member`
--

CREATE TABLE `bonus_member` (
  `id` int(11) NOT NULL,
  `id_pelanggan` int(11) DEFAULT NULL,
  `target_transaksi` int(11) DEFAULT NULL,
  `nama_bonus` varchar(100) DEFAULT NULL,
  `status_ambil` varchar(50) DEFAULT 'Belum'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `detailpenjualan`
--

CREATE TABLE `detailpenjualan` (
  `DetailID` int(11) NOT NULL,
  `PenjualanID` int(11) NOT NULL,
  `ProdukID` int(11) NOT NULL,
  `JumlahProduk` int(11) NOT NULL,
  `Subtotal` decimal(10,2) NOT NULL,
  `Catatan` text DEFAULT NULL,
  `BiayaExtra` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `detailpenjualan`
--

INSERT INTO `detailpenjualan` (`DetailID`, `PenjualanID`, `ProdukID`, `JumlahProduk`, `Subtotal`, `Catatan`, `BiayaExtra`) VALUES
(1, 4, 1, 1, 50000.00, NULL, 0.00),
(2, 5, 1, 1, 50000.00, NULL, 0.00),
(3, 6, 1, 1, 50000.00, NULL, 0.00),
(4, 6, 6, 2, 28000.00, NULL, 0.00),
(5, 6, 3, 1, 15000.00, NULL, 0.00),
(6, 7, 8, 5, 100000.00, NULL, 0.00),
(7, 13, 7, 1, 18000.00, '', 0.00),
(8, 14, 7, 1, 18000.00, '', 0.00),
(9, 15, 5, 1, 24000.00, 'less sugar', 0.00),
(10, 16, 8, 1, 20000.00, '', 0.00),
(11, 17, 6, 3, 72000.00, 'extra keju | Ekstra (+Rp 10.000)', 0.00),
(12, 18, 4, 2, 64000.00, 'less sugar | Ekstra (+Rp 10.000)', 0.00),
(13, 19, 7, 2, 76000.00, 'extra keju | Ekstra (+Rp 10.000)', 0.00),
(14, 20, 2, 1, 38000.00, 'extra keju | Ekstra (+Rp 10.000)', 0.00),
(15, 21, 3, 1, 35000.00, 'extra keju | Ekstra (+Rp 10.000)', 0.00),
(16, 22, 8, 1, 20000.00, '', 0.00),
(17, 22, 5, 1, 44000.00, 'extra keju | Ekstra (+Rp 10.000)', 0.00),
(18, 23, 3, 1, 25000.00, 'extra keju | Ekstra (+Rp 10.000)', 0.00),
(19, 24, 5, 1, 24000.00, 'less sugar', 0.00),
(20, 24, 7, 1, 28000.00, 'extra keju | Ekstra (+Rp 10.000)', 0.00),
(21, 25, 5, 1, 24000.00, '', 0.00),
(22, 25, 6, 1, 14000.00, '', 0.00),
(23, 26, 5, 1, 24000.00, '', 0.00),
(24, 26, 9, 1, 25000.00, '', 0.00),
(28, 30, 8, 1, 25000.00, 'extra keju | Ekstra (+Rp 5.000)', 0.00),
(29, 31, 4, 3, 66000.00, '', 0.00),
(30, 32, 3, 2, 50000.00, 'extra keju | Ekstra (+Rp 10.000)', 0.00),
(31, 33, 4, 1, 22000.00, '', 0.00),
(32, 33, 3, 1, 25000.00, 'extra keju | Ekstra (+Rp 10.000)', 0.00),
(33, 33, 6, 1, 24000.00, 'less sugar | Ekstra (+Rp 10.000)', 0.00),
(34, 34, 3, 1, 20000.00, 'less sugar | Ekstra (+Rp 5.000)', 0.00),
(35, 35, 19, 1, 28000.00, 'extra matcha | Ekstra (+Rp 2.000)', 0.00),
(36, 35, 16, 1, 33000.00, 'extra avocado | Ekstra (+Rp 5.000)', 0.00),
(37, 36, 16, 1, 30000.00, 'extra keju | Ekstra (+Rp 2.000)', 0.00),
(38, 36, 19, 1, 31000.00, 'extra matcha | Ekstra (+Rp 5.000)', 0.00),
(39, 36, 15, 1, 28000.00, 'extra keju | Ekstra (+Rp 10.000)', 0.00),
(40, 37, 7, 1, 28000.00, 'extra choco crunch', 10000.00),
(41, 37, 4, 1, 27000.00, 'extra caramel', 5000.00),
(42, 38, 11, 1, 48000.00, 'extra keju', 10000.00),
(43, 38, 1, 1, 30000.00, 'extra ice', 5000.00),
(44, 39, 16, 1, 38000.00, 'extra avocado', 10000.00),
(45, 39, 3, 1, 20000.00, 'extra iced', 5000.00),
(46, 40, 16, 1, 35000.00, '', 7000.00),
(47, 40, 3, 1, 17000.00, '', 2000.00),
(48, 41, 3, 9, 135000.00, 'less sugar', 2000.00),
(49, 41, 6, 9, 126000.00, 'extra keju 5', 5000.00),
(50, 42, 7, 5, 90000.00, 'extra ice cream 4', 0.00),
(51, 42, 2, 5, 90000.00, 'extra creamy all', 0.00),
(52, 43, 5, 2, 48000.00, 'extra matcha low milk', 0.00),
(53, 44, 3, 2, 30000.00, 'extra ice', 0.00),
(54, 45, 16, 1, 28000.00, 'extra avocado', 0.00),
(55, 46, 6, 2, 28000.00, '0', 0.00),
(56, 47, 9, 1, 25000.00, 'extra keju', 0.00),
(57, 48, 6, 1, 14000.00, 'extra keju', 0.00),
(58, 49, 9, 2, 50000.00, 'extra keju', 10000.00),
(59, 50, 6, 1, 14000.00, 'extra keju', 10000.00),
(60, 51, 9, 1, 25000.00, 'extra keju', 10000.00),
(61, 52, 12, 1, 32000.00, 'extra choco crunch', 5000.00),
(62, 53, 4, 2, 44000.00, 'extra keju', 10000.00),
(63, 53, 9, 1, 25000.00, 'extra choco crunch', 10000.00),
(64, 53, 7, 2, 36000.00, 'extra avocado', 10000.00),
(65, 54, 21, 1, 25000.00, '', 0.00),
(66, 55, 3, 1, 15000.00, '', 0.00),
(67, 56, 16, 1, 28000.00, '', 0.00),
(68, 56, 6, 1, 14000.00, '', 0.00),
(69, 57, 6, 1, 14000.00, 'extra cheese', 10000.00),
(70, 57, 9, 1, 25000.00, 'extra ham', 10000.00),
(71, 58, 3, 1, 15000.00, 'less sugar', 2000.00),
(72, 59, 1, 2, 40000.00, 'extra choco crunch', 10000.00),
(73, 59, 16, 1, 28000.00, '', 0.00),
(74, 60, 29, 1, 53000.00, 'extra berry and oat', 15000.00),
(75, 61, 3, 1, 15000.00, '', 0.00),
(76, 62, 3, 1, 15000.00, '', 0.00),
(77, 62, 16, 1, 28000.00, '', 0.00),
(78, 62, 6, 1, 14000.00, '', 0.00),
(79, 62, 12, 1, 32000.00, '', 0.00),
(80, 62, 7, 1, 18000.00, '', 0.00),
(81, 63, 19, 1, 26000.00, '', 0.00),
(82, 63, 14, 1, 22000.00, 'less sugar', 0.00),
(83, 63, 6, 1, 14000.00, '', 0.00),
(84, 63, 9, 1, 25000.00, '', 0.00),
(85, 63, 4, 1, 0.00, '🎁 Bonus Gratis Random oleh Sistem', 0.00),
(86, 64, 27, 1, 28000.00, 'extra keju pedas wahahhah duar mampus jiakh  anjay', 23000.00),
(87, 65, 15, 1, 18000.00, '', 0.00),
(88, 65, 5, 1, 24000.00, '', 0.00),
(89, 65, 27, 1, 28000.00, '', 0.00),
(90, 66, 12, 1, 32000.00, '', 0.00),
(91, 66, 5, 1, 24000.00, '', 0.00),
(92, 66, 15, 1, 18000.00, '', 0.00),
(93, 67, 3, 1, 15000.00, '', 0.00),
(94, 67, 19, 2, 52000.00, '', 0.00),
(95, 67, 10, 1, 30000.00, '', 0.00),
(96, 67, 27, 2, 56000.00, '', 0.00),
(97, 68, 16, 1, 28000.00, '', 0.00),
(98, 69, 17, 1, 22000.00, '', 0.00),
(99, 69, 21, 1, 25000.00, '', 0.00),
(100, 70, 14, 1, 22000.00, '', 0.00),
(101, 70, 13, 1, 18000.00, '', 0.00),
(102, 70, 5, 1, 24000.00, '', 0.00),
(103, 70, 6, 10, 140000.00, '', 0.00),
(104, 71, 16, 1, 28000.00, '', 0.00),
(105, 71, 6, 1, 14000.00, '', 0.00),
(106, 71, 9, 1, 25000.00, '', 0.00),
(107, 72, 8, 1, 20000.00, '', 0.00),
(108, 72, 28, 1, 35000.00, '', 0.00),
(109, 72, 25, 1, 23000.00, '', 0.00),
(110, 73, 6, 5, 70000.00, 'extra choco crunch', 10000.00),
(111, 74, 9, 1, 25000.00, '', 0.00),
(112, 74, 7, 1, 18000.00, '', 0.00),
(113, 74, 19, 1, 26000.00, '', 0.00),
(114, 74, 2, 1, 18000.00, '', 0.00),
(115, 75, 6, 1, 14000.00, '', 0.00),
(116, 75, 13, 1, 18000.00, '', 0.00),
(117, 75, 5, 1, 24000.00, '', 0.00),
(118, 75, 23, 1, 22000.00, '', 0.00),
(119, 76, 17, 1, 22000.00, '', 0.00),
(120, 76, 27, 1, 28000.00, '', 0.00),
(121, 76, 25, 1, 23000.00, '', 0.00),
(122, 77, 16, 1, 28000.00, '', 0.00),
(123, 77, 6, 1, 14000.00, '', 0.00),
(124, 77, 3, 1, 15000.00, '', 0.00),
(125, 78, 3, 1, 15000.00, '', 0.00),
(126, 78, 4, 1, 22000.00, '', 0.00),
(127, 78, 7, 1, 18000.00, '', 0.00),
(128, 78, 5, 1, 24000.00, '', 0.00),
(129, 78, 21, 1, 25000.00, '', 0.00),
(130, 79, 17, 1, 22000.00, '', 0.00),
(131, 79, 14, 1, 22000.00, '', 0.00),
(132, 79, 10, 1, 30000.00, '', 0.00);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kode_promo`
--

CREATE TABLE `kode_promo` (
  `PromoID` int(11) NOT NULL,
  `KodePromo` varchar(50) NOT NULL,
  `JenisDiskon` enum('persen','nominal') NOT NULL,
  `NilaiDiskon` decimal(10,2) NOT NULL,
  `MinimalBelanja` decimal(10,2) DEFAULT 0.00,
  `Status` enum('aktif','nonaktif') DEFAULT 'aktif'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kode_promo`
--

INSERT INTO `kode_promo` (`PromoID`, `KodePromo`, `JenisDiskon`, `NilaiDiskon`, `MinimalBelanja`, `Status`) VALUES
(1, 'HEMAT10', 'persen', 10.00, 30000.00, 'aktif'),
(2, 'PROMO5RIBU', 'nominal', 5000.00, 20000.00, 'aktif');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `PelangganID` int(11) NOT NULL,
  `NamaPelanggan` varchar(255) NOT NULL,
  `Alamat` text DEFAULT NULL,
  `NomorTelepon` varchar(15) DEFAULT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`PelangganID`, `NamaPelanggan`, `Alamat`, `NomorTelepon`, `Password`) VALUES
(1, 'Fahnida Aulia', 'Semarang', '083862417443', ''),
(9, 'Ammabel', 'Boja', '08386241744336', ''),
(10, 'Indira', 'Indonesia', '0838624174634', ''),
(14, 'Kynen Laras', 'Cangkiran', '0853264278328', ''),
(21, 'Celine', 'Jakarta Utara', '085375238481', ''),
(22, 'Seonghyeon', 'South Korea', '0897136665215', '$2y$10$4SpxMxg7C3hTDoYhw9J3gOTKIakEUkXAufavi45mjiuBjEACXKIP.'),
(24, 'Bu Lilik', 'SKANEGA\r\n', '0893948762', ''),
(25, 'Andin', 'Texas', '082367452374', '$2y$10$ZRmTF7rmOS.4nH3zu994qe4ag8.X.sSD4suNF22uYl8BPc0CRJtzq'),
(26, 'Budi Santoso', 'Jl. Ungaran Raya No. 10', '081234567890', '$2y$10$7R2mIwbzL1IZxKe2/Tzu/.gOXkFeq6mfQcRKiYoUkQ2dGZbsnoYHW');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualan`
--

CREATE TABLE `penjualan` (
  `PenjualanID` int(11) NOT NULL,
  `TanggalPenjualan` timestamp NOT NULL DEFAULT current_timestamp(),
  `TotalHarga` decimal(10,2) NOT NULL DEFAULT 0.00,
  `TipePesanan` enum('Dine-In','Take-Away') DEFAULT 'Dine-In',
  `Bayar` decimal(10,2) DEFAULT 0.00,
  `Kembali` decimal(10,2) DEFAULT 0.00,
  `PelangganID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `NamaPelanggan` varchar(250) DEFAULT NULL,
  `Status` enum('pending','proses','selesai','dibatalkan') DEFAULT 'proses',
  `JenisPesanan` enum('kasir','pelanggan') DEFAULT 'kasir'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `penjualan`
--

INSERT INTO `penjualan` (`PenjualanID`, `TanggalPenjualan`, `TotalHarga`, `TipePesanan`, `Bayar`, `Kembali`, `PelangganID`, `UserID`, `NamaPelanggan`, `Status`, `JenisPesanan`) VALUES
(4, '2026-09-17 23:12:52', 50000.00, 'Dine-In', 50000.00, 0.00, NULL, 2, 'ajeng', '', 'kasir'),
(5, '2026-09-17 23:15:04', 50000.00, 'Dine-In', 100000.00, 50000.00, 1, 2, NULL, '', 'kasir'),
(6, '2026-09-18 00:39:16', 93000.00, 'Dine-In', 290000.00, 197000.00, 1, 2, NULL, '', 'kasir'),
(7, '2026-09-22 08:07:56', 120000.00, 'Dine-In', 590000.00, 490000.00, NULL, 2, 'bagus', '', 'kasir'),
(13, '2026-09-22 22:14:08', 18000.00, 'Dine-In', 20000.00, 2000.00, NULL, 1, NULL, '', 'kasir'),
(14, '2026-09-22 22:14:41', 18000.00, 'Dine-In', 20000.00, 2000.00, NULL, 1, NULL, '', 'kasir'),
(15, '2026-09-22 22:31:20', 24000.00, 'Dine-In', 50000.00, 26000.00, 1, 1, NULL, '', 'kasir'),
(16, '2026-09-23 03:34:08', 20000.00, 'Dine-In', 50000.00, 30000.00, 1, 1, NULL, '', 'kasir'),
(17, '2026-09-23 03:37:43', 72000.00, 'Dine-In', 100000.00, 28000.00, 1, 1, NULL, '', 'kasir'),
(18, '2026-09-23 03:39:23', 64000.00, 'Dine-In', 100000.00, 36000.00, 1, 1, NULL, '', 'kasir'),
(19, '2026-09-23 03:40:47', 56000.00, 'Dine-In', 120000.00, 64000.00, 1, 1, NULL, '', 'kasir'),
(20, '2026-09-23 03:42:16', 28000.00, 'Dine-In', 30000.00, 2000.00, 1, 1, NULL, '', 'kasir'),
(21, '2026-09-23 03:43:07', 25000.00, 'Dine-In', 30000.00, 5000.00, 1, 1, NULL, '', 'kasir'),
(22, '2026-09-23 03:45:48', 54000.00, 'Dine-In', 100015.00, 46015.00, 1, 1, NULL, '', 'kasir'),
(23, '2026-09-23 03:48:21', 25000.00, 'Dine-In', 50016.00, 25016.00, 1, 1, NULL, 'dibatalkan', 'kasir'),
(24, '2026-09-23 03:52:31', 52000.00, 'Dine-In', 100000.00, 48000.00, 1, 2, NULL, 'dibatalkan', 'kasir'),
(25, '2026-09-23 06:49:56', 38000.00, 'Dine-In', 40000.00, 2000.00, 9, 2, NULL, 'selesai', 'kasir'),
(26, '2026-09-23 06:54:23', 49000.00, 'Dine-In', 100000.00, 51000.00, 10, 2, NULL, 'selesai', 'kasir'),
(30, '2026-09-24 04:04:57', 25000.00, 'Dine-In', 50000.00, 25000.00, 1, 1, NULL, 'selesai', 'kasir'),
(31, '2026-09-24 04:43:22', 66000.00, 'Dine-In', 150000.00, 84000.00, 1, 1, NULL, 'dibatalkan', 'kasir'),
(32, '2026-09-24 05:57:44', 50000.00, 'Dine-In', 100000.00, 50000.00, 1, 1, NULL, 'selesai', 'kasir'),
(33, '2026-09-24 06:29:18', 71000.00, 'Dine-In', 100000.00, 29000.00, NULL, 2, NULL, 'dibatalkan', 'kasir'),
(34, '2026-09-24 16:05:06', 20000.00, 'Dine-In', 50000.00, 30000.00, 1, 1, NULL, 'selesai', 'kasir'),
(35, '2026-09-27 10:10:52', 61000.00, 'Dine-In', 100000.00, 39000.00, NULL, 1, NULL, 'proses', 'kasir'),
(36, '2026-09-27 10:29:11', 89000.00, 'Dine-In', 100000.00, 11000.00, NULL, 1, NULL, 'proses', 'kasir'),
(37, '2026-09-27 10:51:05', 55000.00, 'Dine-In', 100000.00, 45000.00, NULL, 1, NULL, 'proses', 'kasir'),
(38, '2026-09-27 11:02:16', 63000.00, 'Dine-In', 70000.00, 7000.00, NULL, 1, NULL, 'proses', 'kasir'),
(39, '2026-09-27 11:11:35', 58000.00, 'Dine-In', 60000.00, 2000.00, NULL, 1, NULL, 'proses', 'kasir'),
(40, '2026-09-27 12:55:58', 52000.00, 'Dine-In', 100000.00, 48000.00, NULL, 1, 'Pelanggan Umum / Tamu', 'proses', 'kasir'),
(41, '2026-09-27 13:18:33', 324000.00, 'Dine-In', 325000.00, 1000.00, NULL, 2, 'citra', 'proses', 'kasir'),
(42, '2026-09-27 13:32:00', 180000.00, 'Dine-In', 400000.00, 220000.00, NULL, 2, 'kania', 'proses', 'kasir'),
(43, '2026-09-27 13:35:23', 48000.00, 'Dine-In', 100000.00, 52000.00, NULL, 2, 'nabila', 'proses', 'kasir'),
(44, '2026-09-27 13:43:35', 30000.00, 'Dine-In', 40000.00, 10000.00, NULL, 2, 'kenzie', 'dibatalkan', 'kasir'),
(45, '2026-09-27 13:47:46', 28000.00, 'Dine-In', 50000.00, 22000.00, NULL, 2, 'filza', 'selesai', 'kasir'),
(46, '2026-09-27 13:55:26', 28000.00, 'Dine-In', 50000.00, 22000.00, NULL, 2, 'andin', 'dibatalkan', 'kasir'),
(47, '2026-09-27 14:01:10', 25000.00, 'Dine-In', 40000.00, 15000.00, NULL, 2, 'kynen', 'selesai', 'kasir'),
(48, '2026-09-28 10:03:02', 14000.00, 'Dine-In', 100000.00, 86000.00, 10, 1, NULL, 'dibatalkan', 'kasir'),
(49, '2026-09-28 10:23:11', 60000.00, 'Dine-In', 70000.00, 10000.00, NULL, 1, 'bintang', 'selesai', 'kasir'),
(50, '2026-09-28 11:32:58', 24000.00, 'Dine-In', 50000.00, 26000.00, 1, 1, NULL, 'selesai', 'kasir'),
(51, '2026-09-28 11:47:17', 35000.00, 'Dine-In', 40000.00, 5000.00, 1, 1, NULL, 'selesai', 'kasir'),
(52, '2026-09-28 11:51:15', 37000.00, 'Dine-In', 40000.00, 3000.00, 1, 1, NULL, 'selesai', 'kasir'),
(53, '2026-09-29 09:35:41', 135000.00, 'Dine-In', 200000.00, 65000.00, NULL, 2, 'Bunga', 'dibatalkan', 'kasir'),
(54, '2026-09-29 10:00:55', 25000.00, 'Dine-In', 50000.00, 25000.00, 1, 2, NULL, 'selesai', 'kasir'),
(55, '2026-09-29 10:10:34', 15000.00, 'Dine-In', 20000.00, 5000.00, 9, 1, NULL, 'dibatalkan', 'kasir'),
(56, '2026-09-29 10:14:23', 42000.00, 'Dine-In', 50000.00, 8000.00, 1, 1, NULL, 'selesai', 'kasir'),
(57, '2026-09-29 12:06:31', 59000.00, 'Dine-In', 100000.00, 41000.00, 9, 3, NULL, 'selesai', 'kasir'),
(58, '2026-09-30 03:12:42', 17000.00, 'Dine-In', 20000.00, 3000.00, 9, 3, NULL, 'dibatalkan', 'kasir'),
(59, '2026-09-30 03:29:17', 78000.00, 'Dine-In', 100000.00, 22000.00, 24, 3, NULL, 'selesai', 'kasir'),
(60, '2026-09-30 04:26:37', 53000.00, 'Dine-In', 50000.00, 2000.00, 1, 8, 'Fahnida Aulia Az', 'selesai', 'kasir'),
(61, '2026-09-30 07:07:27', 15000.00, 'Dine-In', 20000.00, 5000.00, 1, 8, NULL, 'proses', 'kasir'),
(62, '2026-10-01 05:55:49', 107000.00, 'Dine-In', 200000.00, 93000.00, 24, 8, NULL, 'selesai', 'kasir'),
(63, '2026-10-02 04:49:19', 82650.00, 'Dine-In', 100000.00, 17350.00, 14, 8, 'Kynen Laras', 'proses', 'kasir'),
(64, '2026-10-02 10:07:27', 51000.00, 'Dine-In', 100000.00, 49000.00, 1, 8, 'Fahnida Aulia', 'proses', 'kasir'),
(65, '2026-10-03 10:51:15', 66500.00, 'Dine-In', 66500.00, 0.00, 1, 8, 'Fahnida Aulia', 'selesai', 'kasir'),
(66, '2026-10-03 12:30:17', 70300.00, 'Dine-In', 100000.00, 29700.00, 25, 8, 'Andin', 'selesai', 'kasir'),
(67, '2026-10-04 02:41:37', 145350.00, 'Dine-In', 145350.00, 0.00, 24, 8, 'Bu Lilik', 'selesai', 'kasir'),
(68, '2026-10-04 03:38:19', 28000.00, '', 28000.00, 0.00, 26, NULL, 'Budi Santoso', 'selesai', 'pelanggan'),
(69, '2026-10-04 03:40:03', 47000.00, '', 0.00, 0.00, 26, NULL, 'Budi Santoso', 'selesai', 'pelanggan'),
(70, '2026-10-04 10:57:58', 204000.00, 'Dine-In', 300000.00, 96000.00, NULL, 8, 'Juhoon', 'dibatalkan', 'kasir'),
(71, '2026-10-04 10:58:58', 63650.00, 'Dine-In', 100000.00, 36350.00, 24, 8, 'Bu Lilik', 'selesai', 'kasir'),
(72, '2026-10-04 11:51:11', 74100.00, 'Take-Away', 100000.00, 25900.00, 14, 8, 'Kynen Laras', 'selesai', 'kasir'),
(73, '2026-10-06 12:14:53', 80000.00, 'Take-Away', 100000.00, 20000.00, NULL, 8, 'Keonho', 'proses', 'kasir'),
(74, '2026-10-06 12:30:19', 87000.00, '', 87000.00, 0.00, 22, NULL, 'Seonghyeon', 'pending', 'pelanggan'),
(75, '2026-10-06 12:36:30', 78000.00, '', 78000.00, 0.00, 22, NULL, 'Seonghyeon', 'pending', 'pelanggan'),
(76, '2026-10-06 12:42:01', 73000.00, '', 0.00, 0.00, 22, NULL, 'Seonghyeon', 'pending', 'pelanggan'),
(77, '2026-10-06 12:58:21', 54150.00, 'Dine-In', 100000.00, 45850.00, 9, 3, 'Ammabel', 'proses', 'kasir'),
(78, '2026-10-08 00:47:16', 98800.00, 'Dine-In', 100000.00, 1200.00, 25, 8, 'Andin', 'dibatalkan', 'kasir'),
(79, '2026-10-15 07:03:37', 70300.00, 'Take-Away', 70300.00, 0.00, 1, NULL, 'Fahnida Aulia', 'proses', 'kasir');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `ProdukID` int(11) NOT NULL,
  `NamaProduk` varchar(255) NOT NULL,
  `Harga` decimal(10,2) NOT NULL,
  `Stok` int(11) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `kategori` enum('makanan','minuman','','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`ProdukID`, `NamaProduk`, `Harga`, `Stok`, `foto`, `kategori`) VALUES
(1, 'Chocolate Warm/Iced', 20000.00, 12, 'menu_1790492372.jpg', 'makanan'),
(2, 'Es Kopi Susu Daily', 18000.00, 43, 'kopi-susu-daily.jpg', 'minuman'),
(3, 'Americano Warm/Iced', 15000.00, 20, 'americano.jpg', 'minuman'),
(4, 'Caramel Latte Ice', 22000.00, 31, 'caramel-latte.jpg', 'minuman'),
(5, 'Matcha Cream Latte', 24000.00, 20, 'matcha-latte.jpg', 'minuman'),
(6, 'Butter Toast Classic', 14000.00, 18, 'toast-butter.jpg', 'makanan'),
(7, 'Choco Crunch Toast', 18000.00, 28, 'menu_1790262400.jpg', 'makanan'),
(8, 'Srikaya Toast Special', 20000.00, 16, 'toast-srikaya.jpg', 'makanan'),
(9, 'Cheese & Ham Toast', 25000.00, 21, 'toast-cheese.jpg', 'makanan'),
(10, 'Mix Berries and Banana Toast', 30000.00, 13, 'prod_1790262259.jpg', 'makanan'),
(11, 'Cheesy Scrambled Eeg Toast ', 28000.00, 14, 'prod_1790262781.jpg', 'makanan'),
(12, 'Butterscotch Sea Salt Latte', 32000.00, 12, 'menu_1790264076.jpg', 'minuman'),
(13, 'Lychee Tea', 18000.00, 14, 'menu_1790492810.jpg', 'minuman'),
(14, 'Red Velvet Latte', 22000.00, 13, 'menu_1790493160.jpg', 'minuman'),
(15, 'Garlic Cheese Toast', 18000.00, 12, 'prod_1790493256.jpg', 'makanan'),
(16, 'Avocado Toast', 28000.00, 5, 'prod_1790493310.jpg', 'makanan'),
(17, 'Taro Latte', 22000.00, 12, 'prod_1790493373.jpg', 'makanan'),
(18, 'Earl Grey Milk Tea', 18000.00, 15, 'prod_1790493478.jpg', 'minuman'),
(19, 'Dirty Matcha', 26000.00, 9, 'menu_1790493592.jpg', 'minuman'),
(20, 'Kopi Susu Aren Signature', 18000.00, 15, 'prod_1790493701.jpg', 'minuman'),
(21, 'Spicy Tuna Mayo Toast', 25000.00, 13, 'prod_1790493830.jpg', 'makanan'),
(22, 'Lotus Biscoff Toast', 24000.00, 15, 'prod_1790493988.jpg', 'makanan'),
(23, 'Nutella Banana Toast', 22000.00, 14, 'prod_1790494088.jpg', 'makanan'),
(24, 'Lemon Curd Lavender Toast', 26000.00, 15, 'prod_1790494183.jpg', 'makanan'),
(25, 'Strawberry Cream Cheese Toast', 23000.00, 13, 'prod_1790494273.jpg', 'makanan'),
(26, 'Lemonade Yakult', 18000.00, 15, 'prod_1790494402.jpg', 'minuman'),
(27, 'Sweet Mango Cloud Toast ', 28000.00, 10, 'prod_1790683891.jpg', 'makanan'),
(28, 'Rose & Pistachio Indulgence Toast', 35000.00, 14, 'prod_1790684072.jpg', 'makanan'),
(29, 'High Protein Berry Loaded Toast', 38000.00, 14, 'prod_1790684157.jpg', 'makanan'),
(30, 'Caramel Macchiato', 29000.00, 15, 'menu_1790684417.jpg', 'makanan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `NamaUser` varchar(100) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Role` enum('admin','kasir') NOT NULL,
  `status` enum('aktif','diblokir') NOT NULL DEFAULT 'aktif'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`UserID`, `NamaUser`, `Username`, `Password`, `Role`, `status`) VALUES
(1, 'Administrator', 'Admin', '0192023a7bbd73250516f069df18b500', 'admin', 'aktif'),
(2, 'Baneswara Syailendra', 'kasir1', '29c748d4d8f4bd5cbc0f3f60cb7ed3d0', 'kasir', 'aktif'),
(3, 'Chika Anastasya', 'kasir2', '8c86013d8ba23d9b5ade4d6463f81c45', 'kasir', 'aktif'),
(8, 'Jivala Kirana', 'admin2', 'c84258e9c39059a89ab77d846ddab909', 'admin', 'aktif');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `bonus_member`
--
ALTER TABLE `bonus_member`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `detailpenjualan`
--
ALTER TABLE `detailpenjualan`
  ADD PRIMARY KEY (`DetailID`),
  ADD KEY `fk_detail_penjualan` (`PenjualanID`),
  ADD KEY `fk_detail_produk` (`ProdukID`);

--
-- Indeks untuk tabel `kode_promo`
--
ALTER TABLE `kode_promo`
  ADD PRIMARY KEY (`PromoID`),
  ADD UNIQUE KEY `KodePromo` (`KodePromo`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`PelangganID`);

--
-- Indeks untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`PenjualanID`),
  ADD KEY `fk_penjualan_pelanggan` (`PelangganID`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`ProdukID`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=272;

--
-- AUTO_INCREMENT untuk tabel `bonus_member`
--
ALTER TABLE `bonus_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `detailpenjualan`
--
ALTER TABLE `detailpenjualan`
  MODIFY `DetailID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT untuk tabel `kode_promo`
--
ALTER TABLE `kode_promo`
  MODIFY `PromoID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `PelangganID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `PenjualanID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `ProdukID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `detailpenjualan`
--
ALTER TABLE `detailpenjualan`
  ADD CONSTRAINT `fk_detail_penjualan` FOREIGN KEY (`PenjualanID`) REFERENCES `penjualan` (`PenjualanID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_detail_produk` FOREIGN KEY (`ProdukID`) REFERENCES `produk` (`ProdukID`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `penjualan`
--
ALTER TABLE `penjualan`
  ADD CONSTRAINT `fk_penjualan_pelanggan` FOREIGN KEY (`PelangganID`) REFERENCES `pelanggan` (`PelangganID`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
