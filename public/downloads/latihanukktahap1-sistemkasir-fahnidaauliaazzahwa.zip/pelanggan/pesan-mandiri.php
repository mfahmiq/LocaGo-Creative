<?php
date_default_timezone_set('Asia/Jakarta');
session_start();
include '../koneksi.php';

$transaksiBerhasil = $_SESSION['pesanan_berhasil'] ?? null;
unset($_SESSION['pesanan_berhasil']);

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: ../index.php?pesan=gagal");
    exit;
}
$role_login = strtolower(trim($_SESSION['Role'] ?? $_SESSION['role'] ?? ''));
if ($role_login !== 'pelanggan') {
    header("Location: ../kasir/penjualan.php");
    exit;
}

$query_produk = mysqli_query($koneksi, "SELECT * FROM produk WHERE Stok > 0 ORDER BY NamaProduk ASC");
$query_member = mysqli_query($koneksi, "SELECT * FROM pelanggan ORDER BY NamaPelanggan ASC");

$pelanggan_list = [];
while ($row = mysqli_fetch_assoc($query_member)) {
    $pelanggan_list[] = ['id' => $row['PelangganID'], 'nama' => $row['NamaPelanggan']];
}

$produk_bonus_list = [];
mysqli_data_seek($query_produk, 0);
while ($row = mysqli_fetch_assoc($query_produk)) {
    $produk_bonus_list[] = ['id' => $row['ProdukID'], 'nama' => $row['NamaProduk'], 'stok' => $row['Stok']];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesan Mandiri - Daily Coffee & Toast</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body { background-color: #FAF8F5; font-family: 'Plus Jakarta Sans', sans-serif; }
        .wrapper-konten-kasir { margin-top: 105px; margin-left: 290px; padding-right: 35px; padding-bottom: 50px; }
        @media (max-width: 992px) { .wrapper-konten-kasir { margin-left: 20px; margin-right: 20px; padding-right: 0; } }
        .filter-pill-btn { background: #FFFFFF; border: 1.5px solid #E7E5E4; color: #78716C; font-weight: 700; font-size: 0.85rem; border-radius: 50rem; padding: 0.6rem 1.25rem; transition: all 0.25s ease; box-shadow: 0 2px 5px rgba(0,0,0,0.02); display: inline-flex; align-items: center; gap: 8px; cursor: pointer; text-decoration: none; }
        .filter-pill-btn:hover { border-color: #C49A45; color: #C49A45; transform: translateY(-2px); }
        .filter-pill-btn.active { background: #C49A45; border-color: #C49A45; color: #FFFFFF; box-shadow: 0 6px 15px rgba(196, 154, 69, 0.3); }
        .catalog-card { background: #FFFFFF; border-radius: 20px; border: 1px solid rgba(231, 229, 228, 0.9); box-shadow: 0 10px 25px rgba(0, 0, 0, 0.03); transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); overflow: hidden; height: 100%; display: flex; flex-direction: column; cursor: pointer; }
        .catalog-card:hover { transform: translateY(-6px); box-shadow: 0 18px 35px rgba(196, 154, 69, 0.18); border-color: #C49A45; }
        .catalog-img-wrapper { width: 100%; height: 150px; background-color: #FAF8F5; position: relative; overflow: hidden; }
        .catalog-img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.4s ease; }
        .catalog-card:hover .catalog-img { transform: scale(1.08); }
        .badge-float-stok { position: absolute; top: 10px; right: 10px; font-weight: 800; font-size: 0.72rem; padding: 5px 10px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25); color: #FFFFFF; }
        .stok-safe { background: #198754; }
        .stok-warning { background: #F59E0B; }
        .stok-danger { background: #DC3545; }
        .search-katalog-input { border-radius: 14px; padding: 0.75rem 1.25rem; border: 1px solid #E7E5E4; font-size: 0.95rem; background-color: #FFFFFF; }
        .search-katalog-input:focus { border-color: #C49A45; box-shadow: 0 0 0 4px rgba(196, 154, 69, 0.1); }
        .cart-container { background: #FFFFFF; border-radius: 22px; border: 1px solid rgba(231, 229, 228, 0.9); box-shadow: 0 12px 30px rgba(0, 0, 0, 0.04); position: sticky; top: 125px; }
        .cart-header { border-bottom: 2px dashed rgba(231, 229, 228, 0.8); padding-bottom: 1rem; }
        .total-box { background: linear-gradient(135deg, #141211 0%, #2D2621 100%); border-radius: 16px; padding: 1.25rem; color: #FFFFFF; }
        .nav-pills-pelanggan { background: #F1EFE9; padding: 4px; border-radius: 50rem; display: flex; gap: 4px; border: 1px solid #E7E5E4; }
        .nav-pills-pelanggan .nav-link { flex: 1; color: #78716C; font-weight: 700; font-size: 0.85rem; border-radius: 50rem; background: transparent; border: none; padding: 0.55rem 1rem; transition: all 0.25s ease-in-out; text-align: center; }
        .nav-pills-pelanggan .nav-link:hover { color: #1C1917; }
        .nav-pills-pelanggan .nav-link.active { background: #FFFFFF !important; color: #C49A45 !important; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08); transform: scale(1.02); }
        .btn-proses-estetik { background: linear-gradient(135deg, #D4AF37 0%, #C49A45 50%, #A37B2C 100%); color: #FFFFFF; font-weight: 800; padding: 0.95rem 1.5rem; border-radius: 50rem; border: none; transition: all 0.2s ease-in-out; letter-spacing: 0.5px; box-shadow: 0 4px 15px rgba(196, 154, 69, 0.25); }
        .btn-proses-estetik:not(:disabled):hover { background: linear-gradient(135deg, #E5C158 0%, #D4AF37 50%, #B88E3B 100%); transform: translateY(-2px); box-shadow: 0 6px 20px rgba(196, 154, 69, 0.35); color: #FFFFFF; }
        .btn-proses-estetik:disabled { background: #E7E5E4; color: #A8A29E; box-shadow: none; cursor: not-allowed; transform: none; }
        .qty-btn-group { display: inline-flex; align-items: center; background: #FAF8F5; border: 1px solid #E7E5E4; border-radius: 10px; overflow: hidden; padding: 2px; }
        .qty-btn { background: #FFFFFF; border: 1px solid rgba(231, 229, 228, 0.8); color: #44403C; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 0.85rem; border-radius: 8px; cursor: pointer; transition: all 0.2s ease; }
        .qty-btn:hover { background-color: #C49A45; color: #FFFFFF; border-color: #C49A45; }
        .qty-value { min-width: 28px; text-align: center; font-weight: 700; font-size: 0.85rem; color: #1c1917; }
        .modal-transaksi .modal-dialog { max-width: 500px; margin: 1.25rem auto; }
        .modal-transaksi .modal-content { border: 2px solid #E5E7EB; border-radius: 28px; background: #FFFFFF; box-shadow: 0 22px 60px rgba(15, 23, 42, 0.20); overflow: hidden; }
        .modal-transaksi .modal-body { padding: 42px 34px 30px; text-align: center; }
        .modal-transaksi-icon { width: 76px; height: 76px; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-size: 2.25rem; font-weight: 800; box-shadow: 0 10px 22px rgba(15, 23, 42, 0.08); }
        .modal-transaksi-icon.confirm { color: #D97706; background: #FEF3A6; border: 3px solid #F59E0B; }
        .modal-transaksi-icon.promo { color: #C49A45; background: #FDF8ED; border: 3px solid #C49A45; }
        .modal-transaksi-title { color: #1E293B; font-size: 1.35rem; font-weight: 850; letter-spacing: -0.7px; line-height: 1.3; margin-bottom: 10px; }
        .modal-transaksi-desc { color: #718096; font-size: .94rem; line-height: 1.5; margin: 0 auto; max-width: 390px; }
        .modal-transaksi-actions { display: flex; gap: 14px; margin-top: 38px; }
        .modal-transaksi-btn { min-height: 54px; flex: 1; border-radius: 50rem; font-size: .94rem; font-weight: 800; border: 1px solid transparent; transition: all .2s ease; }
        .modal-transaksi-btn.confirm-yes { color: #FFFFFF; background: #166534; box-shadow: 0 4px 9px rgba(22, 101, 52, .16); }
        .modal-transaksi-btn.confirm-yes:hover { color: #FFFFFF; background: #14532D; transform: translateY(-1px); }
        .modal-transaksi-btn.confirm-no { color: #687385; background: #F8FAFC; border-color: #DCE2E9; }
        .modal-transaksi-btn.confirm-no:hover { color: #334155; background: #F1F5F9; }
        .quick-cash-btn { background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.2); color: #FFFFFF; font-size: .72rem; font-weight: 700; border-radius: 50rem; padding: 3px 10px; transition: all .2s ease; }
        .quick-cash-btn:hover { background: #C49A45; border-color: #C49A45; }
        .info-nontunai { background: rgba(196,154,69,0.15); border: 1px dashed rgba(196,154,69,0.6); border-radius: 12px; padding: 8px 12px; font-size: .78rem; color: #F5E6BF; }
    </style>
</head>
<body>
<?php include '../kasir/header.php'; ?>
<div class="wrapper-konten-kasir">
<div class="container-fluid">
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 bg-white p-4 rounded-4 shadow-sm border">
<div>
<span class="badge px-3 py-1.5 rounded-pill fw-bold mb-2" style="background: rgba(196, 154, 69, 0.15); color: #C49A45; border: 1px solid rgba(196, 154, 69, 0.3);">
<i class="bi bi-shop me-1"></i> SELF SERVICE ACTIVE
</span>
<h3 class="fw-extrabold mb-1" style="color: #141211; letter-spacing: -0.5px;">Pesan Mandiri &amp; Katalog Menu</h3>
<p class="text-muted small mb-0">Pilih sajian Coffee atau Toast, tentukan tipe pesanan, lalu kirim pesanan Anda.</p>
</div>
<div class="d-flex align-items-center gap-3">
<div class="d-inline-flex align-items-center gap-2 bg-light px-3 py-2 rounded-3 border">
<i class="bi bi-clock-history text-warning fs-5"></i>
<div class="text-start">
<span class="text-muted d-block" style="font-size: 11px; line-height: 1;">Waktu Akses Sistem</span>
<span id="live-clock" class="fw-bold text-dark" style="font-size: 13px;">Memuat waktu...</span>
</div>
</div>
</div>
</div>

<div class="row g-4">
<div class="col-lg-7 col-xl-8">
<div class="card border-0 rounded-4 p-4 shadow-sm bg-white">
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-3">
<h6 class="fw-bold mb-0 d-flex align-items-center gap-2"><i class="bi bi-grid-fill text-warning"></i> Pilih Menu Pesanan</h6>
<div class="position-relative" style="min-width: 240px;">
<input type="text" id="searchKatalog" class="form-control search-katalog-input ps-5" placeholder="Cari nama menu..." onkeyup="jalankanFilter()">
<i class="bi bi-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
</div>
</div>
<div class="d-flex flex-wrap align-items-center gap-2 mb-4">
<button class="filter-pill-btn active" onclick="filterKategori('semua')" id="btnSemua"><i class="bi bi-grid-fill"></i> Semua Menu</button>
<button class="filter-pill-btn" onclick="filterKategori('coffee')" id="btnCoffee"><i class="bi bi-cup-hot-fill"></i> Coffee Section</button>
<button class="filter-pill-btn" onclick="filterKategori('toast')" id="btnToast"><i class="bi bi-shop"></i> Toast Section</button>
</div>
<div class="row g-3" id="containerKatalog">
    <?php if (mysqli_num_rows($query_produk) > 0): ?>
        <?php mysqli_data_seek($query_produk, 0); ?>
        <?php while ($p = mysqli_fetch_assoc($query_produk)): ?>
            <?php
            $nama_produk_js = htmlspecialchars($p['NamaProduk'], ENT_QUOTES);
            $nama_foto = !empty($p['foto']) ? $p['foto'] : '';
            $path_foto = '../asset/img/' . $nama_foto;
            $img_src = (empty($nama_foto) || !file_exists($path_foto))
                ? 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80'
                : $path_foto;
            $stok = (int)$p['Stok'];
            $nama_menu_lower = strtolower($p['NamaProduk']);
            $kategori = 'coffee';
            if (strpos($nama_menu_lower, 'toast') !== false || strpos($nama_menu_lower, 'roti') !== false || strpos($nama_menu_lower, 'sandwich') !== false) {$kategori = 'toast';
            }
            ?>
            <div class="col-6 col-md-4 card-item-produk" data-nama="<?= htmlspecialchars($nama_menu_lower); ?>" data-kategori="<?= $kategori; ?>">
                <div class="catalog-card" onclick="tambahItem(<?= $p['ProdukID']; ?>, '<?=$nama_produk_js; ?>', <?= $p['Harga']; ?>, <?=$stok; ?>)">
                    <div class="catalog-img-wrapper">
                        <img src="<?= $img_src; ?>" alt="<?= htmlspecialchars($p['NamaProduk']); ?>" class="catalog-img">
                        <span class="badge position-absolute top-0 start-0 m-2 px-2 py-1 shadow-sm" style="font-size: 0.65rem; background: rgba(0,0,0,0.6); color: #fff; backdrop-filter: blur(4px);">
                            <?= ($kategori === 'toast') ? '🍞 Toast' : '☕ Coffee'; ?>
                        </span>
                        <?php if ($stok > 10): ?>
                            <span class="badge-float-stok stok-safe">Stok: <?= $stok; ?></span>
                        <?php elseif ($stok > 0): ?>
                            <span class="badge-float-stok stok-warning">Sisa: <?= $stok; ?></span>
                        <?php else: ?>
                            <span class="badge-float-stok stok-danger">Habis</span>
                        <?php endif; ?>
                    </div>
                    <div class="p-3 d-flex flex-column justify-content-between flex-grow-1">
                        <div>
                            <h6 class="fw-bold text-dark mb-1 text-truncate" title="<?= htmlspecialchars($p['NamaProduk']); ?>"><?= htmlspecialchars($p['NamaProduk']); ?></h6>
                            <small class="text-muted">Sisa: <?= $stok; ?> pcs</small>
                        </div>
                        <div class="mt-2 pt-2 border-top">
                            <span class="fw-extrabold text-success" style="font-size: 1rem;">Rp <?= number_format($p['Harga'], 0, ',', '.'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="col-12 text-center py-5 text-muted">
            <i class="bi bi-cup-hot fs-1 d-block mb-2 text-warning opacity-50"></i>
            Belum ada menu yang tersedia.
        </div>
    <?php endif; ?>
</div>
</div>
</div>

<div class="col-lg-5 col-xl-4">
<div class="cart-container p-4">
<div class="cart-header mb-3">
<h6 class="fw-bold mb-1 d-flex align-items-center gap-2"><i class="bi bi-cart-check-fill text-warning"></i> Pesanan Anda</h6>
<small class="text-muted">Atur tipe pesanan, menu, dan metode pembayaran</small>
</div>

<!-- Form mengarah ke file aksi pesanan mandiri -->
<form action="pesan-mandiri-aksi.php" method="POST" id="formPesanan" onsubmit="return validasiPesanan()">
<input type="hidden" name="jenis_pesanan" value="pelanggan">
<input type="hidden" name="status" value="proses">

<!-- Opsi Tipe Pesanan Dine-In / Take-Away -->
<div class="mb-3">
<label class="form-label small fw-bold text-muted mb-1"><i class="bi bi-bag-check-fill text-warning me-1"></i> Tipe Pesanan</label>
<div class="nav nav-pills-pelanggan mb-2">
<button class="nav-link active" type="button" id="btnDineIn" onclick="setTipePesanan('Dine-In')"><i class="bi bi-shop me-1"></i> Dine-In</button>
<button class="nav-link" type="button" id="btnTakeAway" onclick="setTipePesanan('Take-Away')"><i class="bi bi-bag me-1"></i> Take-Away</button>
</div>
<input type="hidden" name="tipe_pesanan" id="inputTipePesanan" value="Dine-In">
</div>

<div class="mb-3" style="max-height: 250px; overflow-y: auto;">
<div id="containerKeranjangList"></div>
<div id="emptyRow" class="text-center text-muted small py-5">
<i class="bi bi-cart-x fs-2 d-block mb-2 opacity-50"></i>
Belum ada menu yang dipilih.
</div>
</div>

<div class="total-box mb-3">
<div class="d-flex justify-content-between align-items-center mb-1">
<span class="small text-uppercase opacity-75 fw-semibold">Total Pesanan</span>
<span class="badge bg-warning text-dark fw-bold" id="badgeTotalItem">0 Item</span>
</div>
<h3 class="fw-bold text-warning mb-3" id="textTotal">Rp 0</h3>
<input type="hidden" name="total_harga" id="inputTotal" value="0">

<label class="form-label small text-white-50 fw-semibold mb-1">Metode Pembayaran</label>
<div class="nav nav-pills-pelanggan mb-2">
<button class="nav-link active" type="button" id="btnTunai" onclick="setMetodeBayar('tunai')"><i class="bi bi-cash-coin me-1"></i> Tunai di Kasir</button>
<button class="nav-link" type="button" id="btnQris" onclick="setMetodeBayar('qris')"><i class="bi bi-qr-code-scan me-1"></i> QRIS</button>
<button class="nav-link" type="button" id="btnTransfer" onclick="setMetodeBayar('transfer')"><i class="bi bi-bank me-1"></i> Transfer</button>
</div>
<input type="hidden" name="metode_pembayaran" id="inputMetodeBayar" value="tunai">

<div id="infoNonTunai" class="info-nontunai mb-2 d-none">
<div id="statusDigital"></div>
<button type="button" class="quick-cash-btn mt-2" onclick="bukaModalDigital()"><i class="bi bi-qr-code me-1"></i> Tampilkan QR / Instruksi</button>
</div>

<div id="bagianTunai" class="text-white-50 small p-2 bg-dark rounded-3 border border-secondary">
    <i class="bi bi-info-circle text-warning me-1"></i> Pesanan akan dicatat. Silakan tunjukkan nomor pesanan / struk digital Anda ke kasir untuk melakukan pelunasan tunai.
</div>
</div>

<button type="submit" name="kirim_pesanan" id="btnSubmit" class="btn btn-proses-estetik w-100 d-flex align-items-center justify-content-center gap-2" disabled>
<i class="bi bi-send-check-fill fs-5"></i>
<span>Kirim Pesanan</span>
</button>
</form>
</div>
</div>
</div>
</div>
</div>

<!-- Modal Pembayaran Digital -->
<div class="modal fade modal-transaksi" id="modalPembayaranDigital" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-body">
<div class="modal-transaksi-icon promo"><i class="bi bi-qr-code-scan" id="ikonDigital"></i></div>
<h2 class="modal-transaksi-title" id="judulDigital">Pembayaran QRIS</h2>
<p class="modal-transaksi-desc">Total yang harus dibayar</p>
<h3 class="fw-bold mt-1 mb-3" style="color:#C49A45;" id="nominalDigital">Rp 0</h3>
<div id="areaQr" class="mx-auto mb-3 p-3 bg-white border rounded-4" style="width:210px;"></div>
<div id="areaTransfer" class="d-none text-start mx-auto mb-3 p-3 rounded-4" style="max-width:320px;background:#FDF8ED;border:1px solid rgba(196,154,69,.35);font-size:.85rem;">
<div class="text-muted small">Bank Tujuan (simulasi)</div>
<div class="fw-bold">Bank Daily Coffee - a.n. Daily Coffee &amp; Toast</div>
<div class="text-muted small mt-2">No. Rekening</div>
<div class="fw-bold" style="letter-spacing:1px;">1234 5678 9012</div>
</div>
<p class="modal-transaksi-desc small" id="pesanDigital">Silakan scan QRIS berikut.</p>
<div class="modal-transaksi-actions">
<button type="button" class="modal-transaksi-btn confirm-yes" onclick="konfirmasiDigital()"><i class="bi bi-check-lg me-1"></i> Pembayaran Diterima</button>
<button type="button" class="modal-transaksi-btn confirm-no" onclick="batalDigital()">Batal</button>
</div>
</div>
</div>
</div>
</div>

<!-- Modal Konfirmasi Pesanan -->
<div class="modal fade modal-transaksi" id="modalKonfirmasiPesanan" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-body">
<div class="modal-transaksi-icon confirm">?</div>
<h2 class="modal-transaksi-title">Yakin Ingin Mengirim Pesanan?</h2>
<p class="modal-transaksi-desc">Pastikan seluruh pilihan menu, tipe pesanan, dan metode pembayaran sudah benar sebelum dikirim ke dapur.</p>
<div class="modal-transaksi-actions">
<button type="button" class="modal-transaksi-btn confirm-yes" id="btnKonfirmasiPesanan"><i class="bi bi-check-lg me-1"></i> Ya, Kirim</button>
<button type="button" class="modal-transaksi-btn confirm-no" data-bs-dismiss="modal">Periksa Lagi</button>
</div>
</div>
</div>
</div>
</div>

<script>
let keranjang = [], globalTotalHarga = 0, kategoriAktif = 'semua', metodeBayar = 'tunai', tipePesanan = 'Dine-In', digitalTerkonfirmasiTotal = null, konfirmasiPesananFlag = false;

function rupiah(n){ return 'Rp ' + Math.round(n).toLocaleString('id-ID'); }

function updateLiveClock(){
    const n = new Date();
    const d = n.toLocaleDateString('id-ID', {day: '2-digit', month: 'short', year: 'numeric'});
    const t = [n.getHours(), n.getMinutes(), n.getSeconds()].map(v => String(v).padStart(2, '0')).join(':');
    const clockEl = document.getElementById('live-clock');
    if(clockEl) clockEl.innerText = `${d}, ${t} WIB`;
}
updateLiveClock(); 
setInterval(updateLiveClock, 1000);

function escapeHtml(v){ 
    return String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;'); 
}

function filterKategori(k){
    kategoriAktif = k;
    document.querySelectorAll('.filter-pill-btn').forEach(b => b.classList.remove('active'));
    const btnMap = {semua: 'btnSemua', coffee: 'btnCoffee', toast: 'btnToast'};
    if(document.getElementById(btnMap[k])) {
        document.getElementById(btnMap[k]).classList.add('active');
    }
    jalankanFilter();
}

function jalankanFilter(){
    const q = document.getElementById('searchKatalog').value.toLowerCase();
    Array.from(document.getElementsByClassName('card-item-produk')).forEach(i => {
        const a = (kategoriAktif === 'semua' || i.dataset.kategori === kategoriAktif);
        const b = i.dataset.nama.includes(q);
        i.style.display = (a && b) ? 'block' : 'none';
    });
}

function setTipePesanan(tipe) {
    tipePesanan = tipe;
    document.getElementById('inputTipePesanan').value = tipe;
    document.getElementById('btnDineIn').classList.toggle('active', tipe === 'Dine-In');
    document.getElementById('btnTakeAway').classList.toggle('active', tipe === 'Take-Away');
}

function tambahItem(id, nama, harga, stokMax){
    const i = keranjang.findIndex(x => x.id === id);
    if(i !== -1){
        if(keranjang[i].qty < stokMax) {
            keranjang[i].qty++;
        } else {
            alert('Stok menu mencapai batas maksimum (' + stokMax + ')!');
        }
    } else {
        keranjang.push({id, nama, harga: Number(harga), qty: 1, stokMax, catatan: ''});
    }
    renderKeranjang();
}

function hapusItem(i){
    keranjang.splice(i, 1);
    renderKeranjang();
}

function ubahQtyIndex(i, j){
    const x = keranjang[i], q = x.qty + j;
    if(q <= 0){ hapusItem(i); return; }
    if(q > x.stokMax){ alert('Stok tidak mencukupi! Maksimal stok: ' + x.stokMax); return; }
    x.qty = q;
    renderKeranjang();
}

function updateCatatan(i, v){
    if(keranjang[i]) keranjang[i].catatan = v;
}

function renderKeranjang(){
    const c = document.getElementById('containerKeranjangList');
    const e = document.getElementById('emptyRow');
    c.innerHTML = '';
    let total = 0, qty = 0;
    
    if(keranjang.length === 0){
        e.style.display = 'block';
    } else {
        e.style.display = 'none';
        keranjang.forEach((x, i) => {
            const sub = x.harga * x.qty;
            total += sub;
            qty += x.qty;
            c.innerHTML += `<div class="p-3 mb-2 rounded-3 border bg-light shadow-sm"><div class="d-flex justify-content-between align-items-start mb-2"><div><span class="fw-bold text-dark d-block">${escapeHtml(x.nama)}</span><small class="text-muted">Rp ${x.harga.toLocaleString('id-ID')} / pcs</small></div><button type="button" class="btn btn-sm text-danger p-0 border-0 shadow-none" onclick="hapusItem(${i})"><i class="bi bi-x-circle-fill fs-5"></i></button></div><div class="d-flex justify-content-between align-items-center mb-2"><div class="qty-btn-group"><button type="button" class="qty-btn" onclick="ubahQtyIndex(${i},-1)"><i class="bi bi-dash"></i></button><span class="qty-value">${x.qty}</span><button type="button" class="qty-btn" onclick="ubahQtyIndex(${i},1)"><i class="bi bi-plus"></i></button></div><span class="fw-bold text-success">Rp ${sub.toLocaleString('id-ID')}</span></div><input type="text" name="catatan[]" class="form-control form-control-sm bg-white" placeholder="Catatan..." value="${escapeHtml(x.catatan)}" oninput="updateCatatan(${i},this.value)"><input type="hidden" name="produk_id[]" value="${x.id}"><input type="hidden" name="qty[]" value="${x.qty}"></div>`;
        });
    }
    globalTotalHarga = total;
    document.getElementById('btnSubmit').disabled = (keranjang.length === 0);
    document.getElementById('textTotal').innerText = rupiah(total);
    document.getElementById('inputTotal').value = total;
    document.getElementById('badgeTotalItem').innerText = qty + ' Item';
    cekStatusBayarNonTunai();
}

function setMetodeBayar(m){
    const digital = (m !== 'tunai');
    if(digital && keranjang.length === 0){
        alert('Pilih menu terlebih dahulu sebelum memilih pembayaran non-tunai!');
        return;
    }
    metodeBayar = m;
    document.getElementById('inputMetodeBayar').value = m;
    ['tunai', 'qris', 'transfer'].forEach(n => {
        const btn = document.getElementById('btn' + n.charAt(0).toUpperCase() + n.slice(1));
        if(btn) btn.classList.toggle('active', n === m);
    });
    document.getElementById('infoNonTunai').classList.toggle('d-none', !digital);
    document.getElementById('bagianTunai').classList.toggle('d-none', digital);
    
    digitalTerkonfirmasiTotal = null;
    if(digital) {
        bukaModalDigital();
    }
}

function cekStatusBayarNonTunai(){
    if(metodeBayar !== 'tunai'){
        const ok = (digitalTerkonfirmasiTotal === globalTotalHarga);
        const st = document.getElementById('statusDigital');
        if(st){
            st.innerHTML = ok ? `<i class="bi bi-check-circle-fill me-1"></i> Pembayaran dikonfirmasi: <strong>${rupiah(globalTotalHarga)}</strong>` : `<i class="bi bi-hourglass-split me-1"></i> Menunggu konfirmasi pembayaran...`;
        }
    }
}

function buatQrPalsu(seed){
    const n = 25, s = 8;
    let x = (seed * 9301 + 49297) % 233280 || 1, r = () => { x = (x * 9301 + 49297) % 233280; return x / 233280; }, f = (a, b) => { const rr = a >= n - 7 ? a - (n - 7) : a, cc = b >= n - 7 ? b - (n - 7) : b; return rr === 0 || rr === 6 || cc === 0 || cc === 6 || (rr >= 2 && rr <= 4 && cc >= 2 && cc <= 4); }, g = (a, b) => (a < 7 && b < 7) || (a < 7 && b >= n - 7) || (a >= n - 7 && b < 7);
    let z = '';
    for(let a = 0; a < n; a++) for(let b = 0; b < n; b++) if(g(a, b) ? f(a, b) : r() > 0.52) z += `<rect x="${b * s}" y="${a * s}" width="${s}" height="${s}"/>`;
    return `<svg viewBox="0 0 ${n * s} ${n * s}" width="100%" fill="#141211" shape-rendering="crispEdges">${z}</svg>`;
}

function bukaModalDigital(){
    const q = (metodeBayar === 'qris');
    document.getElementById('judulDigital').innerText = q ? 'Pembayaran QRIS' : 'Pembayaran Transfer Bank';
    document.getElementById('ikonDigital').className = 'bi ' + (q ? 'bi-qr-code-scan' : 'bi-bank');
    document.getElementById('nominalDigital').innerText = rupiah(globalTotalHarga);
    document.getElementById('areaQr').classList.toggle('d-none', !q);
    document.getElementById('areaTransfer').classList.toggle('d-none', q);
    if(q) document.getElementById('areaQr').innerHTML = buatQrPalsu(Math.round(globalTotalHarga) + 7);
    document.getElementById('pesanDigital').innerText = q ? 'Silakan scan QRIS berikut. (Simulasi)' : 'Silakan transfer sesuai nominal ke rekening di atas. (Simulasi)';
    bootstrap.Modal.getOrCreateInstance(document.getElementById('modalPembayaranDigital')).show();
}

function konfirmasiDigital(){
    digitalTerkonfirmasiTotal = globalTotalHarga;
    cekStatusBayarNonTunai();
    bootstrap.Modal.getOrCreateInstance(document.getElementById('modalPembayaranDigital')).hide();
}

function batalDigital(){
    bootstrap.Modal.getOrCreateInstance(document.getElementById('modalPembayaranDigital')).hide();
    setMetodeBayar('tunai');
}

function validasiPesanan(){
    if(keranjang.length === 0){
        alert('Belum ada produk yang dipilih!');
        return false;
    }
    if(metodeBayar !== 'tunai' && digitalTerkonfirmasiTotal !== globalTotalHarga){
        bukaModalDigital();
        return false;
    }
    if(!konfirmasiPesananFlag){
        bootstrap.Modal.getOrCreateInstance(document.getElementById('modalKonfirmasiPesanan')).show();
        return false;
    }
    return true;
}

document.getElementById('btnKonfirmasiPesanan').addEventListener('click', () => {
    konfirmasiPesananFlag = true;
    bootstrap.Modal.getOrCreateInstance(document.getElementById('modalKonfirmasiPesanan')).hide();
    const f = document.getElementById('formPesanan'), b = document.getElementById('btnSubmit');
    if(f.requestSubmit) f.requestSubmit(b); else b.click();
});

renderKeranjang();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>