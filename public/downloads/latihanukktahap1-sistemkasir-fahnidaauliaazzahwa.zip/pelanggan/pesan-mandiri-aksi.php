<?php
date_default_timezone_set('Asia/Jakarta');
session_start();
include '../koneksi.php';

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: ../login.php");
    exit;
}

$role_login = strtolower(trim($_SESSION['Role'] ?? $_SESSION['role'] ?? ''));
if ($role_login !== 'pelanggan') {
    header("Location: ../kasir/penjualan.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['kirim_pesanan'])) {
    header("Location: pesan-mandiri.php");
    exit;
}

function kembaliKePesanan($pesan) {
    echo '<script>alert(' . json_encode($pesan) . '); window.location.href = "pesan-mandiri.php";</script>';
    exit;
}

$user_id = null;
if (isset($_SESSION['UserID']) && is_numeric($_SESSION['UserID']) && (int)$_SESSION['UserID'] > 0) {
    $user_id = (int)$_SESSION['UserID'];
}

$username_audit = 'System';
foreach (['username', 'Username', 'nama', 'Nama'] as $key) {
    if (!empty($_SESSION[$key])) {
        $username_audit = $_SESSION[$key];
        break;
    }
}

// Tangkap metode pembayaran
$metode_bayar = $_POST['metode_pembayaran'] ?? 'tunai';
if (!in_array($metode_bayar, ['tunai', 'qris', 'transfer'], true)) $metode_bayar = 'tunai';
$label_metode = ['tunai' => 'Tunai di Kasir', 'qris' => 'QRIS', 'transfer' => 'Transfer Bank'][$metode_bayar];

// Tangkap tipe pesanan (Dine-In / Take-Away) sesuai struktur kolom TipePesanan
$tipe_pesanan = $_POST['tipe_pesanan'] ?? 'Dine-In';
if (!in_array($tipe_pesanan, ['Dine-In', 'Take-Away'], true)) $tipe_pesanan = 'Dine-In';

$tanggal = date('Y-m-d H:i:s');

$produk_ids = $_POST['produk_id'] ?? [];
$qtys = $_POST['qty'] ?? [];
$catatans = $_POST['catatan'] ?? [];

if (!is_array($produk_ids) || count($produk_ids) === 0) {
    kembaliKePesanan('Belum ada produk yang dipilih.');
}
if (!is_array($qtys)) kembaliKePesanan('Data jumlah produk tidak valid.');
if (!is_array($catatans)) $catatans = [];

$pelanggan_id = null;
if (isset($_SESSION['PelangganID']) && is_numeric($_SESSION['PelangganID']) && (int)$_SESSION['PelangganID'] > 0) {
    $pelanggan_id = (int)$_SESSION['PelangganID'];
}
$nama_pelanggan = trim($_SESSION['NamaPelanggan'] ?? $_SESSION['nama_pelanggan'] ?? '');
if ($nama_pelanggan === '') $nama_pelanggan = 'Pelanggan';

if ($pelanggan_id !== null) {
    $stmt_pelanggan = mysqli_prepare($koneksi, "SELECT PelangganID, NamaPelanggan FROM pelanggan WHERE PelangganID = ?");
    if (!$stmt_pelanggan) kembaliKePesanan('Gagal memeriksa data pelanggan.');
    mysqli_stmt_bind_param($stmt_pelanggan, "i", $pelanggan_id);
    mysqli_stmt_execute($stmt_pelanggan);
    $data_pelanggan = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_pelanggan));
    mysqli_stmt_close($stmt_pelanggan);
    if (!$data_pelanggan) kembaliKePesanan('Data pelanggan tidak ditemukan.');
    $nama_pelanggan = $data_pelanggan['NamaPelanggan'];
}

$total_harga = 0;
$items = [];
$stmt_produk = mysqli_prepare($koneksi, "SELECT Harga, Stok, NamaProduk FROM produk WHERE ProdukID = ?");
if (!$stmt_produk) kembaliKePesanan('Gagal mengambil data produk.');

foreach ($produk_ids as $index => $produk_id) {
    $produk_id = (int)$produk_id;
    $qty = isset($qtys[$index]) ? (int)$qtys[$index] : 0;
    $catatan = isset($catatans[$index]) ? trim($catatans[$index]) : '';

    if ($produk_id <= 0) kembaliKePesanan('Ada produk yang tidak valid.');
    if ($qty <= 0) kembaliKePesanan('Jumlah produk harus lebih dari 0.');

    mysqli_stmt_bind_param($stmt_produk, "i", $produk_id);
    mysqli_stmt_execute($stmt_produk);
    $data_produk = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_produk));

    if (!$data_produk) kembaliKePesanan('Produk dengan ID ' . $produk_id . ' tidak ditemukan.');
    if ((int)$data_produk['Stok'] < $qty) {
        kembaliKePesanan('Stok produk ' . $data_produk['NamaProduk'] . ' tidak mencukupi. Stok tersedia: ' . (int)$data_produk['Stok'] . ', jumlah yang dipesan: ' . $qty . '.');
    }

    $harga = (float)$data_produk['Harga'];
    $subtotal = $harga * $qty;
    $total_harga += $subtotal;

    $items[] = [
        'produk_id' => $produk_id,
        'qty' => $qty,
        'catatan' => $catatan,
        'subtotal' => $subtotal
    ];
}
mysqli_stmt_close($stmt_produk);

// Logika Bayar: Jika non-tunai, bayar lunas otomatis. Jika tunai, bayar = 0 dulu menunggu kasir.
$uang_bayar = ($metode_bayar !== 'tunai') ? $total_harga : 0;
$kembalian = 0;

// Nilai tambahan untuk kolom Status dan JenisPesanan
$status_pesanan = 'pending'; // Pesanan mandiri baru berstatus pending
$jenis_pesanan  = 'pelanggan'; // Karena ini dilakukan dari modul pelanggan

mysqli_begin_transaction($koneksi);

try {
    // Query disesuaikan dengan kolom tabel: TanggalPenjualan, TotalHarga, TipePesanan, Bayar, Kembali, PelangganID, UserID, NamaPelanggan, Status, JenisPesanan
    $stmt_penjualan = mysqli_prepare($koneksi, "INSERT INTO penjualan (TanggalPenjualan, TotalHarga, TipePesanan, Bayar, Kembali, PelangganID, UserID, NamaPelanggan, Status, JenisPesanan) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt_penjualan) throw new Exception('Gagal menyiapkan data pesanan.');

    mysqli_stmt_bind_param($stmt_penjualan, "sddsdiisss", $tanggal, $total_harga, $tipe_pesanan, $uang_bayar, $kembalian, $pelanggan_id, $user_id, $nama_pelanggan, $status_pesanan, $jenis_pesanan);
    if (!mysqli_stmt_execute($stmt_penjualan)) throw new Exception('Gagal menyimpan pesanan.');

    $penjualan_id = mysqli_insert_id($koneksi);
    mysqli_stmt_close($stmt_penjualan);
    if (!$penjualan_id) throw new Exception('ID pesanan tidak berhasil dibuat.');

    $nomor_transaksi = 'TRX-' . date('Ymd', strtotime($tanggal)) . '-' . str_pad($penjualan_id, 4, '0', STR_PAD_LEFT);

    $stmt_detail = mysqli_prepare($koneksi, "INSERT INTO detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal, Catatan, BiayaExtra) VALUES (?, ?, ?, ?, ?, ?)");
    if (!$stmt_detail) throw new Exception('Gagal menyiapkan detail pesanan.');

    $stmt_stok = mysqli_prepare($koneksi, "UPDATE produk SET Stok = Stok - ? WHERE ProdukID = ? AND Stok >= ?");
    if (!$stmt_stok) throw new Exception('Gagal menyiapkan update stok.');

    foreach ($items as $item) {
        $p_id = $item['produk_id'];
        $qty = $item['qty'];
        $subtotal = $item['subtotal'];
        $catatan = $item['catatan'];
        $extra = 0;

        mysqli_stmt_bind_param($stmt_detail, "iiidsd", $penjualan_id, $p_id, $qty, $subtotal, $catatan, $extra);
        if (!mysqli_stmt_execute($stmt_detail)) throw new Exception('Gagal menyimpan detail pesanan.');

        mysqli_stmt_bind_param($stmt_stok, "iii", $qty, $p_id, $qty);
        if (!mysqli_stmt_execute($stmt_stok) || mysqli_stmt_affected_rows($stmt_stok) !== 1) {
            throw new Exception('Stok produk tidak mencukupi atau produk tidak ditemukan.');
        }
    }

    mysqli_stmt_close($stmt_detail);
    mysqli_stmt_close($stmt_stok);

    $aksi_audit = 'TAMBAH';
    $keterangan_audit = 'Pelanggan membuat pesanan mandiri ' . $nomor_transaksi . ' (' . $tipe_pesanan . ' - ' . $label_metode . ')';
    $stmt_audit = mysqli_prepare($koneksi, "INSERT INTO audit_log (username, aktivitas, deskripsi) VALUES (?, ?, ?)");
    if ($stmt_audit) {
        mysqli_stmt_bind_param($stmt_audit, "sss", $username_audit, $aksi_audit, $keterangan_audit);
        mysqli_stmt_execute($stmt_audit);
        mysqli_stmt_close($stmt_audit);
    }

    mysqli_commit($koneksi);

    // Simpan informasi berhasil ke session
    $_SESSION['pesanan_berhasil'] = [
        'id' => (int)$penjualan_id, 
        'kode' => $nomor_transaksi,
        'tipe' => $tipe_pesanan,
        'metode' => $label_metode,
        'total' => $total_harga
    ];
    
    header("Location: pesan-mandiri.php");
    exit;
} catch (Throwable $e) {
    mysqli_rollback($koneksi);
    error_log('ERROR PESANAN MANDIRI: ' . $e->getMessage());
    kembaliKePesanan('Pesanan gagal disimpan. Pesan: ' . $e->getMessage());
}
?>