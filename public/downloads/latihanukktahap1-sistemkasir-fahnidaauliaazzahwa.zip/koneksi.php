<?php
    $koneksi = mysqli_connect("localhost", "root", "", "kasir");

    if (mysqli_connect_errno()) {
        echo "Koneksi Database gagal : ".mysqli_connect_error();
    }
    mysqli_query($koneksi, "SET time_zone = '+07:00'");
?>