<?php
session_start();
include 'koneksi.php';
date_default_timezone_set('Asia/Jakarta');

/* ==========================================================
   CEK FORM LOGIN
========================================================== */
if (!isset($_POST['masuk'])) {
    header("Location: index.php");
    exit;
}

/* ==========================================================
   AMBIL & VALIDASI INPUT
========================================================== */
$username       = isset($_POST['username']) ? trim($_POST['username']) : '';
$password_input = $_POST['password'] ?? '';

if ($username === '' || $password_input === '') {
    balik('gagal');
}

/* ==========================================================
   FUNGSI BANTU
========================================================== */
function balik($pesan)
{
    $_SESSION['login_old'] = trim($_POST['username'] ?? '');
    header("Location: index.php?pesan=" . $pesan);
    exit;
}

function catatAudit($koneksi, $username, $aktivitas, $deskripsi)
{
    $st = mysqli_prepare($koneksi, "INSERT INTO audit_log (username, aktivitas, waktu, deskripsi) VALUES (?, ?, NOW(), ?)");
    if ($st) {
        mysqli_stmt_bind_param($st, "sss", $username, $aktivitas, $deskripsi);
        mysqli_stmt_execute($st);
        mysqli_stmt_close($st);
    }
}

function normalisasiTelepon($no)
{
    $no = preg_replace('/[^0-9+]/', '', $no);
    if (strpos($no, '+62') === 0) $no = '0' . substr($no, 3);
    elseif (strpos($no, '62') === 0) $no = '0' . substr($no, 2);
    return $no;
}

/* ==========================================================
   1. COBA LOGIN SEBAGAI ADMIN / KASIR (tabel user)
========================================================== */
$password_md5 = md5($password_input);

$stmt = mysqli_prepare($koneksi, "SELECT * FROM user WHERE Username = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if ($user) {
    $pw_db = (string) $user['Password'];
    if (!hash_equals($pw_db, $password_md5) && !hash_equals($pw_db, $password_input)) {
        balik('gagal');
    }

    $status_user = strtolower(trim($user['Status'] ?? 'aktif'));
    if ($status_user === 'diblokir') {
        balik('diblokir');
    }

    session_regenerate_id(true);
    $_SESSION['login']    = true;
    $_SESSION['UserID']   = $user['UserID'];
    $_SESSION['Username'] = $user['Username'];
    $_SESSION['NamaUser'] = $user['NamaUser'];
    $_SESSION['Role']     = $user['Role']; // 'admin' atau 'kasir'

    $role_user = ucfirst($user['Role']);
    catatAudit($koneksi, $user['Username'], 'LOGIN SISTEM', "$role_user ({$user['NamaUser']}) berhasil masuk ke dalam sistem.");

    // Tujuan sama ke dashboard kasir
    header("Location: kasir/dashboard.php");
    exit;
}

/* ==========================================================
   2. BUKAN STAF -> COBA LOGIN SEBAGAI PELANGGAN (tabel pelanggan)
========================================================== */
$telepon = normalisasiTelepon($username);

if (preg_match('/^0[0-9]{8,14}$/', $telepon)) {

    $stmt = mysqli_prepare($koneksi, "
        SELECT PelangganID, NamaPelanggan, Alamat, NomorTelepon, Password
        FROM pelanggan
        WHERE REPLACE(REPLACE(REPLACE(NomorTelepon, '-', ''), ' ', ''), '+62', '0') = ?
        LIMIT 1");
    mysqli_stmt_bind_param($stmt, "s", $telepon);
    mysqli_stmt_execute($stmt);
    $pel = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);

    if (!$pel) {
        balik('belum_member');
    }

    if (empty($pel['Password'])) {
        balik('belum_aktif');
    }

    $pw_db = (string) $pel['Password'];
    $cocok = false;
    $perlu_upgrade = false;

    if (password_verify($password_input, $pw_db)) {
        $cocok = true;
        $perlu_upgrade = password_needs_rehash($pw_db, PASSWORD_DEFAULT);
    } elseif (hash_equals($pw_db, $password_md5) || hash_equals($pw_db, $password_input)) {
        $cocok = true;
        $perlu_upgrade = true;
    }

    if ($cocok) {
        if ($perlu_upgrade) {
            $hash_baru = password_hash($password_input, PASSWORD_DEFAULT);
            $up = mysqli_prepare($koneksi, "UPDATE pelanggan SET Password = ? WHERE PelangganID = ?");
            if ($up) {
                $id_up = (int) $pel['PelangganID'];
                mysqli_stmt_bind_param($up, "si", $hash_baru, $id_up);
                mysqli_stmt_execute($up);
                mysqli_stmt_close($up);
            }
        }

        session_regenerate_id(true);
        // KUNCI UTAMA: Kita set $_SESSION['login'] = true dan role-nya 'pelanggan'
        // agar bisa masuk dan membaca layout dashboard kasir yang sama
        $_SESSION['login']        = true;
        $_SESSION['PelangganID']  = (int) $pel['PelangganID'];
        $_SESSION['NamaUser']     = $pel['NamaPelanggan']; // Disamakan agar terbaca di header kasir
        $_SESSION['Role']         = 'pelanggan';

        catatAudit($koneksi, $pel['NamaPelanggan'], 'LOGIN SISTEM', "Pelanggan ({$pel['NamaPelanggan']}) berhasil masuk ke dalam sistem.");

        // Langsung arahkan ke dashboard kasir
        header("Location: kasir/dashboard.php");
        exit;
    } else {
        balik('gagal');
    }

} else {
    balik('belum_member');
}

/* ==========================================================
   GAGAL UTAMA
========================================================== */
balik('gagal');