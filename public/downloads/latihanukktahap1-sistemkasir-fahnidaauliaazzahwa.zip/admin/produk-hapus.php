<?php
session_start();
include '../koneksi.php'; 

// Cek apakah user sudah login dan rolenya admin
if (!isset($_SESSION['login']) || (isset($_SESSION['user_role']) && $_SESSION['user_role'] !== 'admin')) {
    header("Location: ../index.php?pesan=gagal");
    exit;
}

// Cek apakah parameter ID ada di URL
if (isset($_GET['id'])) {
    $produk_id = (int)$_GET['id'];

    // Ambil data foto produk terlebih dahulu
    $q_cek = mysqli_query($koneksi, "SELECT foto FROM produk WHERE ProdukID = '$produk_id'");
    $data_produk = mysqli_fetch_assoc($q_cek);

    if ($data_produk) {
        $foto_lama = $data_produk['foto'];

        // Coba hapus data produk dari database menggunakan try-catch untuk menangkap error foreign key
        try {
            $query_hapus = mysqli_query($koneksi, "DELETE FROM produk WHERE ProdukID = '$produk_id'");

            if ($query_hapus) {
                // Jika berhasil hapus dari database, hapus file fisik gambarnya jika ada
                if (!empty($foto_lama) && $foto_lama != 'default.jpg') {
                    $path_file = '../asset/img/' . $foto_lama;
                    if (file_exists($path_file)) {
                        unlink($path_file);
                    }
                }

                echo "<script>alert('Menu berhasil dihapus!'); window.location='../kasir/produk.php';</script>";
                exit;
            }
        } catch (\mysqli_sql_exception $e) {
            // Error code 1451 adalah kode SQL untuk foreign key constraint violation (data sudah pernah dipakai transaksi)
            if ($e->getCode() == 1451) {
                echo "<script>alert('Gagal Menghapus! Menu ini sudah pernah terjual/masuk dalam riwayat transaksi kasir. Disarankan untuk mengubah stoknya menjadi 0 saja.'); window.location='../kasir/produk.php';</script>";
                exit;
            } else {
                echo "<script>alert('Terjadi kesalahan database: " . addslashes($e->getMessage()) . "'); window.location='../kasir/produk.php';</script>";
                exit;
            }
        }
    } else {
        echo "<script>alert('Data menu tidak ditemukan!'); window.location='../kasir/produk.php';</script>";
        exit;
    }
} else {
    header("Location: ../kasir/produk.php");
    exit;
}
?>