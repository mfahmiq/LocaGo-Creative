<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include '../koneksi.php';

// Pesan sukses (flash) setelah simpan, ditampilkan sebagai pop-up
$flash = $_SESSION['edit_berhasil'] ?? null;
unset($_SESSION['edit_berhasil']);

function fmtTeks($v) {
    $v = trim((string) $v);
    return $v === '' ? '(kosong)' : '“' . $v . '”';
}

// Keamanan: hanya admin yang boleh mengakses halaman edit
if (!isset($_SESSION['login']) || ($_SESSION['Role'] ?? '') !== 'admin') {
    header("Location: ../index.php?pesan=gagal");
    exit;
}

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$username_admin = $_SESSION['Username'] ?? 'Administrator';

// ======================================================
// DATA TRANSAKSI UTAMA
// ======================================================
$stmt = mysqli_prepare($koneksi, "
    SELECT p.*, COALESCE(pel.NamaPelanggan, p.NamaPelanggan, 'Pelanggan Umum / Tamu') AS NamaFinalPelanggan
    FROM penjualan p
    LEFT JOIN pelanggan pel ON p.PelangganID = pel.PelangganID
    WHERE p.PenjualanID = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);

if (!$data) {
    echo "<script>alert('Data transaksi tidak ditemukan!'); window.location='transaksi.php';</script>";
    exit;
}

$id_trans   = (int) $data['PenjualanID'];
$is_member  = !empty($data['PelangganID']);
$total_lama = (float) $data['TotalHarga'];

// Transaksi yang sudah selesai tidak boleh diedit (SOP)
if (isset($data['Status']) && $data['Status'] == 'Selesai') {
    echo "<script>alert('Transaksi yang sudah selesai tidak dapat diedit!'); window.location='transaksi.php';</script>";
    exit;
}

$no_transaksi = 'TRX-' . date('Ymd', strtotime($data['TanggalPenjualan'])) . '-' . str_pad($id_trans, 4, '0', STR_PAD_LEFT);

// ======================================================
// METODE PEMBAYARAN (dari kolom MetodePembayaran jika ada, jika tidak dari audit log)
// ======================================================
$metode = 'Tunai';
$cek_kolom = mysqli_query($koneksi, "SHOW COLUMNS FROM penjualan LIKE 'MetodePembayaran'");
if ($cek_kolom && mysqli_num_rows($cek_kolom) > 0 && !empty($data['MetodePembayaran'])) {
    $m = strtolower($data['MetodePembayaran']);
    $metode = $m === 'qris' ? 'QRIS' : (strpos($m, 'transfer') !== false ? 'Transfer Bank' : 'Tunai');
} else {
    $like = 'Menambahkan transaksi baru ' . $no_transaksi . '%';
    $stmt = mysqli_prepare($koneksi, "SELECT deskripsi FROM audit_log WHERE deskripsi LIKE ? LIMIT 1");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $like);
        mysqli_stmt_execute($stmt);
        $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        mysqli_stmt_close($stmt);
        if ($row) {
            if (strpos($row['deskripsi'], '(QRIS)') !== false) $metode = 'QRIS';
            elseif (strpos($row['deskripsi'], '(Transfer Bank)') !== false) $metode = 'Transfer Bank';
        }
    }
}
$is_tunai = ($metode === 'Tunai');

// ======================================================
// RINCIAN ITEM (Subtotal di DB = harga x qty, biaya extra terpisah)
// ======================================================
$details = [];
$stmt = mysqli_prepare($koneksi, "
    SELECT dp.DetailID, dp.JumlahProduk, dp.Subtotal, dp.Catatan, dp.BiayaExtra, pr.NamaProduk
    FROM detailpenjualan dp JOIN produk pr ON dp.ProdukID = pr.ProdukID
    WHERE dp.PenjualanID = ? ORDER BY dp.DetailID ASC");
mysqli_stmt_bind_param($stmt, "i", $id_trans);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
while ($r = mysqli_fetch_assoc($res)) $details[] = $r;
mysqli_stmt_close($stmt);

// Diskon yang dulu diberikan dipertahankan (nominal tetap)
$gross_lama = 0;
foreach ($details as $d) $gross_lama += (float) $d['Subtotal'] + (float) $d['BiayaExtra'];
$diskon_lama = max(0, $gross_lama - $total_lama);

$error = '';

// ======================================================
// PROSES SIMPAN
// ======================================================
if (isset($_POST['update_transaksi'])) {
    $catatan_post = $_POST['catatan_item'] ?? [];
    $extra_post   = $_POST['biaya_extra_item'] ?? [];

    $gross_baru = 0;
    $perubahan  = [];
    $baru = [];
    foreach ($details as $d) {
        $did = (int) $d['DetailID'];
        $cat = trim($catatan_post[$did] ?? (string) $d['Catatan']);
        $ext = max(0, (float) ($extra_post[$did] ?? $d['BiayaExtra']));
        if ((float) $d['Subtotal'] == 0) $ext = 0; // item bonus tidak boleh diberi biaya
        $gross_baru += (float) $d['Subtotal'] + $ext;
        $baru[$did] = [$cat, $ext];
        if ($cat !== (string) $d['Catatan']) $perubahan[] = 'Catatan ' . $d['NamaProduk'] . ': ' . fmtTeks($d['Catatan']) . ' → ' . fmtTeks($cat);
        if ($ext != (float) $d['BiayaExtra']) $perubahan[] = 'Biaya extra ' . $d['NamaProduk'] . ': Rp ' . number_format((float) $d['BiayaExtra'], 0, ',', '.') . ' → Rp ' . number_format($ext, 0, ',', '.');
    }
    $total_baru = max(0, $gross_baru - $diskon_lama);

    // Nama pelanggan: hanya non-member
    $nama_baru = $data['NamaFinalPelanggan'];
    if (!$is_member) {
        $nama_baru = trim($_POST['NamaPelanggan'] ?? '');
        if ($nama_baru === '') $error = 'Nama pelanggan tidak boleh kosong.';
        elseif ($nama_baru !== $data['NamaFinalPelanggan']) $perubahan[] = 'Nama pelanggan: ' . fmtTeks($data['NamaFinalPelanggan']) . ' → ' . fmtTeks($nama_baru);
    }

    // Pembayaran: uang yang diterima TIDAK bisa diedit
    $uang_bayar = (float) $data['Bayar'];
    $kembali = $uang_bayar - $total_baru;
    if ($is_tunai) {
        if ($total_baru > $uang_bayar) {
            $error = 'Total baru (Rp ' . number_format($total_baru, 0, ',', '.') . ') melebihi uang yang sudah diterima (Rp ' . number_format($uang_bayar, 0, ',', '.') . '). Uang tidak bisa diedit, silakan batalkan transaksi dan buat ulang.';
        }
    } else {
        $kembali = (float) $data['Kembali'];
        if (abs($total_baru - $total_lama) > 0.009) {
            $error = 'Pembayaran ' . $metode . ' sudah lunas dan nominalnya tidak bisa diubah. Biaya extra tidak boleh mengubah total. Jika perlu mengubah nominal, silakan batalkan transaksi dan buat ulang.';
        }
    }

    if ($error === '' && count($perubahan) === 0) {
        $error = 'Tidak ada perubahan yang perlu disimpan.';
    }

    if ($error === '') {
        mysqli_begin_transaction($koneksi);
        try {
            $st = mysqli_prepare($koneksi, "UPDATE detailpenjualan SET Catatan = ?, BiayaExtra = ? WHERE DetailID = ? AND PenjualanID = ?");
            foreach ($baru as $did => [$cat, $ext]) {
                mysqli_stmt_bind_param($st, "sdii", $cat, $ext, $did, $id_trans);
                if (!mysqli_stmt_execute($st)) throw new Exception('Gagal memperbarui detail item.');
            }
            mysqli_stmt_close($st);

            if ($is_member) {
                $st = mysqli_prepare($koneksi, "UPDATE penjualan SET TotalHarga = ?, Kembali = ? WHERE PenjualanID = ?");
                mysqli_stmt_bind_param($st, "ddi", $total_baru, $kembali, $id_trans);
            } else {
                $st = mysqli_prepare($koneksi, "UPDATE penjualan SET TotalHarga = ?, Kembali = ?, NamaPelanggan = ? WHERE PenjualanID = ?");
                mysqli_stmt_bind_param($st, "ddsi", $total_baru, $kembali, $nama_baru, $id_trans);
            }
            if (!mysqli_stmt_execute($st)) throw new Exception('Gagal memperbarui transaksi.');
            mysqli_stmt_close($st);

            $aktivitas = 'UBAH';
            $deskripsi = "Admin ($username_admin) mengoreksi transaksi $no_transaksi ($metode). "
                . (count($perubahan) ? 'Perubahan: ' . implode('; ', $perubahan) . '. ' : 'Tanpa perubahan data. ')
                . 'Total: Rp ' . number_format($total_lama, 0, ',', '.') . ' -> Rp ' . number_format($total_baru, 0, ',', '.');
            $st = mysqli_prepare($koneksi, "INSERT INTO audit_log (username, aktivitas, waktu, deskripsi) VALUES (?, ?, NOW(), ?)");
            if ($st) {
                mysqli_stmt_bind_param($st, "sss", $username_admin, $aktivitas, $deskripsi);
                mysqli_stmt_execute($st);
                mysqli_stmt_close($st);
            }
            mysqli_commit($koneksi);
            $_SESSION['edit_berhasil'] = [
                'no' => $no_transaksi,
                'perubahan' => $perubahan,
                'total_lama' => $total_lama,
                'total_baru' => $total_baru,
            ];
            header("Location: " . basename($_SERVER['PHP_SELF']) . "?id=" . $id_trans);
            exit;
        } catch (Throwable $e) {
            mysqli_rollback($koneksi);
            $error = 'Gagal menyimpan: ' . $e->getMessage();
        }
    }
}

include 'header.php';
?>

<style>
    :root { color-scheme: light; }
    .container, .card, .modal-content, .table, .form-control, .alert { color-scheme: light; }
    body { background: #FAF8F5 !important; color: #212529 !important; }
    /* Navbar admin berada di atas (tanpa sidebar): konten dilebarkan penuh dan diberi jarak dari navbar */
    .wrapper-edit { width: 100%; max-width: 1560px; margin: 0 auto; padding: 140px 24px 3rem; box-sizing: border-box; }
    @media (max-width: 992px) { .wrapper-edit { padding: 125px 12px 2rem; } }
    .card-premium { background: #FFFFFF; border: 1px solid #D4AF37; border-radius: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); width: 100%; }
    .card-header-premium { background: linear-gradient(135deg, #FFFDF5 0%, #F8F9FA 100%); padding: 2.5rem; border-bottom: 2px solid #D4AF37; border-top-left-radius: 24px; border-top-right-radius: 24px; }
    .form-control-premium { background: #FFFFFF; border: 2px solid #CED4DA; color: #212529 !important; border-radius: 10px; padding: 0.5rem 0.75rem; font-size: 0.9rem; }
    .form-control-premium:focus { background: #FFFFFF; border-color: #D4AF37; box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.15); }
    .form-control-premium[readonly] { background: #F1F3F5; color: #6C757D !important; }
    .table-edit th { background-color: #F1F3F5 !important; color: #495057 !important; border-color: #DEE2E6 !important; font-size: 0.75rem; text-transform: uppercase; }
    .table-edit td { background-color: #FFFFFF !important; color: #212529 !important; border-color: #DEE2E6 !important; vertical-align: middle; }
    .preview-box { background: linear-gradient(135deg, rgba(212,175,55,0.08) 0%, rgba(212,175,55,0.02) 100%); border: 1px solid #D4AF37; border-radius: 16px; padding: 1.25rem; }
    .btn-save-premium { background: linear-gradient(135deg, #D4AF37 0%, #B89728 100%); color: #FFFFFF; font-weight: 800; border-radius: 12px; border: none; padding: 0.75rem 2rem; transition: all 0.3s ease; }
    .btn-save-premium:hover { background: linear-gradient(135deg, #E5C158 0%, #D4AF37 100%); transform: translateY(-2px); color: #FFFFFF; }
    .metode-pills { display: flex; gap: 4px; background: #F1EFE9; padding: 4px; border-radius: 50rem; border: 1px solid #E7E5E4; }
    .metode-pills .pill { flex: 1; text-align: center; font-weight: 700; font-size: .85rem; color: #A8A29E; padding: .5rem .75rem; border-radius: 50rem; }
    .metode-pills .pill.active { background: #FFFFFF; color: #C49A45; box-shadow: 0 4px 12px rgba(0,0,0,.08); }
    .modal-content-custom { border-radius: 28px; border: none; box-shadow: 0 15px 40px rgba(0,0,0,0.15); padding: 1.5rem; }
    .modal-icon-wrapper { width: 80px; height: 80px; background: #FFF8E1; border: 2px solid #FFD54F; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem auto; box-shadow: 0 4px 15px rgba(255,193,7,.2); }
    .btn-modal-yes { background-color: #1B5E20; color: #FFFFFF; font-weight: 700; border-radius: 50px; padding: 0.75rem 2rem; border: none; transition: all .2s ease; }
    .btn-modal-yes:hover { background-color: #2E7D32; color: #FFFFFF; }
    .btn-modal-cancel { background-color: #FFFFFF; color: #495057; font-weight: 700; border-radius: 50px; padding: 0.75rem 2rem; border: 2px solid #CED4DA; transition: all .2s ease; }
    .btn-modal-cancel:hover { background-color: #F8F9FA; color: #212529; border-color: #ADB5BD; }
</style>

<div class="wrapper-edit">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card card-premium">

                <div class="card-header-premium text-center">
                    <div class="d-inline-flex align-items-center justify-content-center bg-warning bg-opacity-20 text-dark rounded-circle mb-3 shadow-sm" style="width:60px;height:60px;border:1px solid #D4AF37;">
                        <i class="bi bi-pencil-fill fs-4 text-dark"></i>
                    </div>
                    <h3 class="fw-extrabold mb-1 text-dark">Koreksi Transaksi</h3>
                    <p class="text-muted small mb-0">Hanya untuk koreksi catatan item, biaya extra, dan nama pelanggan non-member</p>
                </div>

                <div class="card-body p-4 p-md-5">
                    <?php if ($error !== ''): ?>
                        <div class="alert alert-danger rounded-4"><i class="bi bi-exclamation-triangle-fill me-1"></i> <?= htmlspecialchars($error); ?></div>
                    <?php endif; ?>

                    <form method="POST" id="formEditTransaksi">

                        <div class="row mb-4 g-3">
                            <div class="col-md-4">
                                <label class="form-label small text-uppercase fw-bold text-muted">Nomor Transaksi</label>
                                <input type="text" class="form-control form-control-premium font-monospace fw-bold" value="<?= htmlspecialchars($no_transaksi); ?>" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label small text-uppercase fw-bold text-muted d-flex justify-content-between align-items-center">
                                    <span>Nama Pelanggan</span>
                                    <?php if ($is_member): ?>
                                        <span class="badge bg-warning text-dark px-2 py-1" style="font-size:.7rem;"><i class="bi bi-lock-fill"></i> Member (Terkunci)</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary text-white px-2 py-1" style="font-size:.7rem;">Non-Member (Dapat Diedit)</span>
                                    <?php endif; ?>
                                </label>
                                <input type="text" name="NamaPelanggan" class="form-control form-control-premium"
                                       value="<?= htmlspecialchars($data['NamaFinalPelanggan']); ?>"
                                       <?= $is_member ? 'readonly title="Nama member tidak dapat diubah dari sini"' : 'required'; ?>>
                                <?php if ($is_member): ?>
                                    <small class="text-muted" style="font-size:.75rem;">*Member resmi, nama tidak dapat diubah.</small>
                                <?php endif; ?>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label small text-uppercase fw-bold text-muted">Metode Pembayaran (Terkunci)</label>
                                <div class="metode-pills">
                                    <span class="pill <?= $metode === 'Tunai' ? 'active' : ''; ?>"><i class="bi bi-cash-coin"></i> Tunai</span>
                                    <span class="pill <?= $metode === 'QRIS' ? 'active' : ''; ?>"><i class="bi bi-qr-code-scan"></i> QRIS</span>
                                    <span class="pill <?= $metode === 'Transfer Bank' ? 'active' : ''; ?>"><i class="bi bi-bank"></i> Transfer</span>
                                </div>
                                <small class="text-muted" style="font-size:.75rem;">*Metode tidak bisa diubah karena pembayaran sudah diterima.</small>
                            </div>
                        </div>

                        <!-- RINCIAN ITEM -->
                        <div class="mb-4">
                            <label class="form-label small text-uppercase fw-bold text-dark mb-2">
                                <i class="bi bi-list-check text-warning me-1"></i> Rincian Produk, Catatan Item, &amp; Biaya Extra
                            </label>
                            <div class="table-responsive border border-light rounded-3 shadow-sm">
                                <table class="table table-edit align-middle mb-0">
                                    <thead>
                                        <tr>
                                            <th style="width:25%;">Nama Produk</th>
                                            <th class="text-center" style="width:8%;">Qty</th>
                                            <th class="text-end" style="width:14%;">Harga Satuan</th>
                                            <th style="width:25%;">Catatan Khusus Item</th>
                                            <th class="text-end" style="width:14%;">Biaya Extra (Rp)</th>
                                            <th class="text-end" style="width:14%;">Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach ($details as $d):
                                        $did = (int) $d['DetailID'];
                                        $dasar = (float) $d['Subtotal'];
                                        $extra = (float) $d['BiayaExtra'];
                                        $bonus = ($dasar == 0);
                                    ?>
                                        <tr>
                                            <td>
                                                <span class="fw-bold"><?= htmlspecialchars($d['NamaProduk']); ?></span>
                                                <?php if ($bonus): ?><span class="badge bg-success ms-1">🎁 Bonus</span><?php endif; ?>
                                            </td>
                                            <td class="text-center fw-bold text-primary"><?= (int) $d['JumlahProduk']; ?>x</td>
                                            <td class="text-end text-muted">Rp <?= number_format($dasar / max(1, (int) $d['JumlahProduk']), 0, ',', '.'); ?></td>
                                            <td>
                                                <input type="text" name="catatan_item[<?= $did; ?>]" class="form-control form-control-premium"
                                                       value="<?= htmlspecialchars((string) $d['Catatan']); ?>" placeholder="Misal: Less ice, extra cheese...">
                                            </td>
                                            <td>
                                                <input type="number" name="biaya_extra_item[<?= $did; ?>]" class="form-control form-control-premium text-end input-extra"
                                                       data-dasar="<?= $dasar; ?>" data-id="<?= $did; ?>" value="<?= $extra; ?>" min="0"
                                                       <?= $bonus ? 'readonly title="Item bonus tidak dapat diberi biaya"' : ''; ?> oninput="hitungSemua()">
                                            </td>
                                            <td class="text-end fw-bold text-success"><span id="sub_<?= $did; ?>">Rp <?= number_format($dasar + $extra, 0, ',', '.'); ?></span></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- PEMBAYARAN (TERKUNCI) -->
                        <div class="row mb-4 g-3">
                            <div class="col-md-6">
                                <label class="form-label small text-uppercase fw-bold text-dark">Uang Diterima (Terkunci)</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light text-success"><i class="bi bi-lock-fill"></i></span>
                                    <input type="text" class="form-control form-control-premium fw-bold" value="Rp <?= number_format($data['Bayar'], 0, ',', '.'); ?>" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small text-uppercase fw-bold text-dark">Kembalian</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light text-primary"><i class="bi bi-arrow-counterclockwise"></i></span>
                                    <input type="text" id="outputKembalian" class="form-control form-control-premium fw-bold" value="Rp <?= number_format($data['Kembali'], 0, ',', '.'); ?>" readonly>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="alert alert-light border rounded-4 mb-0 small" style="background:#FFFDF5;border-color:#D4AF37 !important;">
                                    <i class="bi bi-info-circle-fill text-warning me-1"></i>
                                    Pembayaran <strong><?= htmlspecialchars($metode); ?></strong> tidak dapat diedit.
                                    Jika nominal uang perlu diubah, <strong>batalkan transaksi</strong> ini lalu buat transaksi baru.
                                </div>
                            </div>
                        </div>

                        <!-- PREVIEW TOTAL -->
                        <div class="preview-box mb-4 text-center">
                            <span class="text-muted small fw-semibold d-block mb-1">Total Akhir Transaksi (Item + Extra<?= $diskon_lama > 0 ? ' − Diskon Awal Rp ' . number_format($diskon_lama, 0, ',', '.') : ''; ?>)</span>
                            <h3 class="text-dark fw-extrabold mb-1" id="previewTotalAkhir">Rp 0</h3>
                            <small class="text-muted">Total sebelumnya: Rp <?= number_format($total_lama, 0, ',', '.'); ?> · Selisih: <strong id="textSelisih">Rp 0</strong></small>
                        </div>

                        <div class="d-flex justify-content-between align-items-center pt-3 border-top border-light">
                            <a href="transaksi.php" class="btn btn-outline-secondary px-4 py-2 rounded-pill fw-bold"><i class="bi bi-arrow-left me-1"></i> Batal</a>
                            <button type="button" class="btn btn-save-premium px-5 py-2.5 shadow-sm" data-bs-toggle="modal" data-bs-target="#konfirmasiSimpanModal">
                                <i class="bi bi-check2-circle me-1 fs-5 align-middle"></i> Simpan Koreksi
                            </button>
                        </div>

                        <div class="modal fade" id="konfirmasiSimpanModal" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content modal-content-custom text-center">
                                    <div class="modal-body p-4">
                                        <div class="modal-icon-wrapper"><i class="bi bi-question-lg text-warning fs-1 fw-bold"></i></div>
                                        <h4 class="fw-bold text-dark mb-3">Yakin Ingin Menyimpan?</h4>
                                        <p class="text-muted mb-3 px-2" style="font-size:.95rem;line-height:1.5;">
                                            Periksa kembali perubahan pada transaksi <strong class="text-dark"><?= htmlspecialchars($no_transaksi); ?></strong>:
                                        </p>
                                        <div id="ringkasPerubahan" class="text-start mb-4"></div>
                                        <div class="d-flex justify-content-center gap-3">
                                            <button type="button" class="btn btn-modal-cancel px-4" data-bs-dismiss="modal">Nanti Saja</button>
                                            <button type="submit" id="btnYaSimpan" name="update_transaksi" class="btn btn-modal-yes px-4">Ya, Simpan</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const DISKON_AWAL = <?= json_encode($diskon_lama); ?>;
const TOTAL_LAMA = <?= json_encode($total_lama); ?>;
const BAYAR = <?= $is_tunai ? json_encode((float) $data['Bayar']) : 'null'; ?>;
const rp = n => 'Rp ' + Math.round(n).toLocaleString('id-ID');

function hitungSemua() {
    let gross = 0;
    document.querySelectorAll('.input-extra').forEach(inp => {
        const dasar = parseFloat(inp.dataset.dasar) || 0;
        const extra = Math.max(0, parseFloat(inp.value) || 0);
        document.getElementById('sub_' + inp.dataset.id).innerText = rp(dasar + extra);
        gross += dasar + extra;
    });
    const total = Math.max(0, gross - DISKON_AWAL);
    window.totalBaruTerakhir = total;
    const selisih = total - TOTAL_LAMA;
    document.getElementById('previewTotalAkhir').innerText = rp(total);
    const s = document.getElementById('textSelisih');
    s.innerText = (selisih > 0 ? '+' : selisih < 0 ? '−' : '') + rp(Math.abs(selisih));
    s.style.color = selisih > 0 ? '#dc3545' : selisih < 0 ? '#198754' : '#6c757d';

    const out = document.getElementById('outputKembalian');
    if (out && BAYAR !== null) {
        const kembali = BAYAR - total;
        out.value = kembali < 0 ? 'Melebihi uang diterima (' + rp(Math.abs(kembali)) + ')' : rp(kembali);
        out.style.color = kembali < 0 ? '#dc3545' : '#198754';
    }
}
window.onload = hitungSemua;
</script>
<script src="../asset/js/bootstrap.bundle.min.js"></script>

<style>
    .ringkas-list { list-style: none; margin: 0; padding: 0; max-height: 240px; overflow-y: auto; }
    .ringkas-item { background: #FFFDF5; border: 1px solid #FDE68A; border-radius: 12px; padding: 9px 12px; margin-bottom: 8px; text-align: left; }
    .ringkas-label { font-size: .72rem; font-weight: 800; text-transform: uppercase; letter-spacing: .3px; color: #92400E; }
    .ringkas-nilai { font-size: .85rem; color: #1E293B; overflow-wrap: anywhere; }
    .ringkas-nilai .dari { color: #A8A29E; text-decoration: line-through; }
    .ringkas-nilai .ke { color: #166534; }
    .ringkas-kosong { background: #F8FAFC; border: 1px dashed #CBD5E1; border-radius: 12px; padding: 14px; text-align: center; color: #64748B; font-size: .85rem; }
    .modal-icon-sukses { width: 80px; height: 80px; background: #DCFCE7; border: 3px solid #22C55E; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem; color: #15803D; font-size: 2.2rem; }
</style>

<?php if (!empty($flash)): ?>
<div class="modal fade" id="modalBerhasil" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content modal-content-custom text-center">
            <div class="modal-body p-4">
                <div class="modal-icon-sukses"><i class="bi bi-check-lg"></i></div>
                <h4 class="fw-bold text-dark mb-2">Perubahan Berhasil Disimpan!</h4>
                <p class="text-muted mb-3 px-2" style="font-size:.92rem;">
                    Transaksi <strong class="text-dark"><?= htmlspecialchars($flash['no']); ?></strong> telah diperbarui dan dicatat di audit log. Yang diubah:
                </p>
                <ul class="ringkas-list mb-3">
                    <?php foreach ($flash['perubahan'] as $p): ?>
                        <li class="ringkas-item"><div class="ringkas-nilai"><?= htmlspecialchars($p); ?></div></li>
                    <?php endforeach; ?>
                    <?php if ((float) $flash['total_lama'] !== (float) $flash['total_baru']): ?>
                        <li class="ringkas-item">
                            <div class="ringkas-label">Total transaksi</div>
                            <div class="ringkas-nilai">Rp <?= number_format($flash['total_lama'], 0, ',', '.'); ?> → <strong class="text-success">Rp <?= number_format($flash['total_baru'], 0, ',', '.'); ?></strong></div>
                        </li>
                    <?php endif; ?>
                </ul>
                <div class="d-flex justify-content-center gap-3 mt-4">
                    <button type="button" class="btn btn-modal-cancel px-4" data-bs-dismiss="modal">Lanjut Mengedit</button>
                    <a href="transaksi.php" class="btn btn-modal-yes px-4 text-decoration-none">Kembali ke Data Transaksi</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
const ORIGINAL = <?= json_encode([
    'nama'  => $data['NamaFinalPelanggan'],
    'items' => array_reduce($details, function ($c, $d) {
        $c[(int) $d['DetailID']] = ['nama' => $d['NamaProduk'], 'cat' => trim((string) $d['Catatan']), 'extra' => (float) $d['BiayaExtra']];
        return $c;
    }, []),
], JSON_UNESCAPED_UNICODE); ?>;
const fmtRp = n => 'Rp ' + Math.round(n).toLocaleString('id-ID');

function ambilPerubahan() {
    const out = [];
    const namaInp = document.querySelector('[name="NamaPelanggan"]');
    if (namaInp && !namaInp.readOnly && namaInp.value.trim() !== ORIGINAL.nama) {
        out.push(['Nama pelanggan', ORIGINAL.nama, namaInp.value.trim() || '(kosong)']);
    }
    Object.keys(ORIGINAL.items).forEach(id => {
        const it = ORIGINAL.items[id];
        const c = document.querySelector('[name="catatan_item[' + id + ']"]');
        const e = document.querySelector('[name="biaya_extra_item[' + id + ']"]');
        if (c && c.value.trim() !== it.cat) out.push(['Catatan ' + it.nama, it.cat || '(kosong)', c.value.trim() || '(kosong)']);
        if (e && !e.readOnly) {
            const v = Math.max(0, parseFloat(e.value) || 0);
            if (v !== it.extra) out.push(['Biaya extra ' + it.nama, fmtRp(it.extra), fmtRp(v)]);
        }
    });
    return out;
}

function barisRingkas(label, dari, ke) {
    const li = document.createElement('li'); li.className = 'ringkas-item';
    const l = document.createElement('div'); l.className = 'ringkas-label'; l.textContent = label;
    const n = document.createElement('div'); n.className = 'ringkas-nilai';
    const a = document.createElement('span'); a.className = 'dari'; a.textContent = dari;
    const k = document.createElement('strong'); k.className = 'ke'; k.textContent = ke;
    n.append(a, document.createTextNode(' → '), k);
    li.append(l, n);
    return li;
}

document.getElementById('konfirmasiSimpanModal').addEventListener('show.bs.modal', function () {
    if (typeof hitungSemua === 'function') hitungSemua();
    const box = document.getElementById('ringkasPerubahan');
    const btn = document.getElementById('btnYaSimpan');
    const daftar = ambilPerubahan();
    box.innerHTML = '';
    if (daftar.length === 0) {
        box.innerHTML = '<div class="ringkas-kosong"><i class="bi bi-info-circle me-1"></i> Belum ada perubahan yang dilakukan.</div>';
        btn.disabled = true;
        return;
    }
    btn.disabled = false;
    const ul = document.createElement('ul'); ul.className = 'ringkas-list';
    daftar.forEach(r => ul.appendChild(barisRingkas(r[0], r[1], r[2])));
    const totalBaru = window.totalBaruTerakhir;
    if (typeof totalBaru === 'number' && Math.round(totalBaru) !== Math.round(TOTAL_LAMA)) {
        ul.appendChild(barisRingkas('Total transaksi', fmtRp(TOTAL_LAMA), fmtRp(totalBaru)));
    }
    box.appendChild(ul);
});

<?php if (!empty($flash)): ?>
window.addEventListener('load', function () {
    bootstrap.Modal.getOrCreateInstance(document.getElementById('modalBerhasil')).show();
});
<?php endif; ?>
</script>
</body>
</html>