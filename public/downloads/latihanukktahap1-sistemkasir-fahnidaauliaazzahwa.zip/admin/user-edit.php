<?php
// ==========================================================
// SESSION & KONEKSI
// ==========================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../koneksi.php';

// ==========================================================
// CEK LOGIN & HAK AKSES (KHUSUS ADMIN)
// ==========================================================

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: ../index.php?pesan=belum_login");
    exit;
}

$role = strtolower(trim($_SESSION['Role'] ?? ''));

if ($role !== 'admin') {
    header("Location: ../index.php?pesan=akses_ditolak");
    exit;
}

date_default_timezone_set('Asia/Jakarta');


// ==========================================================
// AMBIL USERNAME ADMIN YANG SEDANG LOGIN
// ==========================================================

$username_login = '';

if (isset($_SESSION['UserID'])) {

    $user_id_login = (int) $_SESSION['UserID'];

    $query_login_user = mysqli_query(
        $koneksi,
        "SELECT Username
         FROM user
         WHERE UserID = $user_id_login
         LIMIT 1"
    );

    if ($query_login_user && mysqli_num_rows($query_login_user) > 0) {

        $data_login_user = mysqli_fetch_assoc(
            $query_login_user
        );

        $username_login = $data_login_user['Username'];
    }
}

if (empty($username_login) && isset($_SESSION['Username'])) {
    $username_login = $_SESSION['Username'];
}


// ==========================================================
// AMBIL ID USER DARI URL
// ==========================================================

$id_user = isset($_GET['id'])
    ? (int) $_GET['id']
    : 0;

if ($id_user <= 0) {

    header(
        "Location: data-user.php?pesan=id_tidak_valid"
    );

    exit;
}


// ==========================================================
// AMBIL DATA USER YANG AKAN DIEDIT
// ==========================================================

$query_user = mysqli_query(
    $koneksi,
    "SELECT *
     FROM user
     WHERE UserID = $id_user"
);

$user = mysqli_fetch_assoc($query_user);

if (!$user) {

    header(
        "Location: data-user.php?pesan=tidak_ditemukan"
    );

    exit;
}


$pesan_error = '';


// ==========================================================
// PROSES FORM SUBMIT (UPDATE)
// ==========================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nama_user = trim(
        $_POST['NamaUser'] ?? ''
    );

    $username = trim(
        $_POST['Username'] ?? ''
    );

    $password = $_POST['Password'] ?? '';

    $user_role = $_POST['Role'] ?? '';


    // ======================================================
    // VALIDASI INPUT WAJIB
    // ======================================================

    if (
        empty($nama_user) ||
        empty($username) ||
        empty($user_role)
    ) {

        $pesan_error =
            "Nama, Username, dan Role wajib diisi!";

    } else {

        // ==================================================
        // CEK USERNAME
        // ==================================================

        $username_safe =
            mysqli_real_escape_string(
                $koneksi,
                $username
            );

        $cek_username = mysqli_query(
            $koneksi,
            "SELECT *
             FROM user
             WHERE Username = '$username_safe'
             AND UserID != $id_user"
        );


        if (mysqli_num_rows($cek_username) > 0) {

            $pesan_error =
                "Username <b>@" .
                htmlspecialchars($username) .
                "</b> sudah digunakan oleh akun lain. Silakan gunakan username lain.";

        } else {

            // ==============================================
            // AMANKAN DATA
            // ==============================================

            $nama_user_safe =
                mysqli_real_escape_string(
                    $koneksi,
                    $nama_user
                );

            $user_role_safe =
                mysqli_real_escape_string(
                    $koneksi,
                    $user_role
                );


            // ==============================================
            // UPDATE DATA
            // ==============================================

            if (!empty($password)) {

                $password_hashed =
                    password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );

                $query_update = "
                    UPDATE user SET
                        NamaUser = '$nama_user_safe',
                        Username = '$username_safe',
                        Password = '$password_hashed',
                        Role = '$user_role_safe'
                    WHERE UserID = $id_user
                ";

            } else {

                $query_update = "
                    UPDATE user SET
                        NamaUser = '$nama_user_safe',
                        Username = '$username_safe',
                        Role = '$user_role_safe'
                    WHERE UserID = $id_user
                ";
            }


            // ==============================================
            // JALANKAN UPDATE
            // ==============================================

            if (mysqli_query($koneksi, $query_update)) {


                // ==========================================
                // FORMAT ID USER
                // ==========================================

                $format_user_id =
                    'DAILYUSR' . $id_user;


                // ==========================================
                // FORMAT ROLE
                // ==========================================

                $role_tampil =
                    ucfirst(
                        strtolower(
                            trim($user_role)
                        )
                    );


                // ==========================================
                // DESKRIPSI AUDIT
                // ==========================================

                $deskripsi_audit =
                    "Mengubah data user dengan ID " .
                    $format_user_id .
                    ", Nama: " .
                    $nama_user .
                    ", Username: @" .
                    $username .
                    ", Role: " .
                    $role_tampil;


                // ==========================================
                // AMANKAN DATA AUDIT
                // ==========================================

                $username_login_safe =
                    mysqli_real_escape_string(
                        $koneksi,
                        $username_login
                    );

                $deskripsi_audit_safe =
                    mysqli_real_escape_string(
                        $koneksi,
                        $deskripsi_audit
                    );


                // ==========================================
                // SIMPAN AUDIT LOG
                // ==========================================

                mysqli_query(
                    $koneksi,
                    "INSERT INTO audit_log
                    (
                        username,
                        waktu,
                        aktivitas,
                        deskripsi
                    )
                    VALUES
                    (
                        '$username_login_safe',
                        NOW(),
                        'UBAH',
                        '$deskripsi_audit_safe'
                    )"
                );


                // ==========================================
                // REDIRECT
                // ==========================================

                header(
                    "Location: data-user.php?pesan=sukses_edit"
                );

                exit;

            } else {

                $pesan_error =
                    "Gagal memperbarui data: " .
                    mysqli_error($koneksi);
            }
        }
    }
}


// ==========================================================
// HEADER
// ==========================================================

include 'header.php';

?>

<style>

body {
    background: #F4F6F9 !important;
    color: #333333 !important;
}

/* ==========================================================
   HEADER BANNER
========================================================== */

.header-banner-custom {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.04);
    padding: 1.75rem 2rem;
}

.time-badge-box {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 12px;
    padding: 0.6rem 1rem;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.02);
}

.card-light-custom {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
    color: #1E293B;
}

/* ==========================================================
   FORM
========================================================== */

.form-control-custom,
.form-select-custom {
    border-radius: 12px;
    border: 1.5px solid #E2E8F0;
    padding: 0.7rem 1rem;
    font-size: 0.9rem;
    transition: all 0.25s ease;
}

.form-control-custom:focus,
.form-select-custom:focus {
    border-color: #D97706;
    box-shadow: 0 0 0 4px rgba(217, 119, 6, 0.12);
}

.form-label {
    font-weight: 600;
    font-size: 0.85rem;
    color: #475569;
    margin-bottom: 0.5rem;
}

/* ==========================================================
   SWEETALERT CUSTOM
========================================================== */

.swal-edit-popup {
    border-radius: 24px !important;
    padding: 2rem 2rem 1.75rem !important;
    box-shadow: 0 22px 60px rgba(15, 23, 42, 0.20) !important;
}

.swal-edit-title {
    color: #182232 !important;
    font-size: 1.35rem !important;
    font-weight: 800 !important;
    margin-top: 8px !important;
}

.swal-edit-text {
    color: #64748B !important;
    font-size: 0.92rem !important;
    line-height: 1.65 !important;
}

.swal-edit-confirm {
    min-width: 170px;
    border-radius: 50rem !important;
    padding: 10px 20px !important;
    font-weight: 700 !important;
    background: #198754 !important;
    color: #FFFFFF !important;
    border: none !important;
    box-shadow: 0 5px 14px rgba(25, 135, 84, 0.25) !important;
    transition: all 0.2s ease !important;
}

.swal-edit-confirm:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(25, 135, 84, 0.32) !important;
}

.swal-edit-cancel {
    min-width: 120px;
    border-radius: 50rem !important;
    padding: 10px 20px !important;
    font-weight: 600 !important;
    background: #F8FAFC !important;
    color: #475569 !important;
    border: 1px solid #E2E8F0 !important;
    transition: all 0.2s ease !important;
}

.swal-edit-cancel:hover {
    background: #F1F5F9 !important;
    transform: translateY(-2px);
}

.swal2-actions {
    gap: 8px !important;
    margin-top: 1.35rem !important;
}

/* ==========================================================
   ANIMASI IKON
========================================================== */

.swal-question-icon {
    animation: questionPop 0.45s ease-out;
}

@keyframes questionPop {

    0% {
        transform: scale(0.65);
        opacity: 0;
    }

    70% {
        transform: scale(1.08);
    }

    100% {
        transform: scale(1);
        opacity: 1;
    }
}

/* ==========================================================
   TOMBOL UPDATE
========================================================== */

.btn-update-custom {
    background: #F59E0B !important;
    border: none !important;
    color: #1F2937 !important;
    transition: all 0.2s ease;
}

.btn-update-custom:hover {
    background: #D97706 !important;
    color: #FFFFFF !important;
    transform: translateY(-1px);
    box-shadow: 0 6px 14px rgba(245, 158, 11, 0.28) !important;
}

</style>


<div class="container-fluid px-0"
     style="margin-top: 25px; max-width: 800px;">

<div class="header-banner-custom mb-4">

    <div class="row align-items-center">

        <div class="col-lg-8">

            <span class="badge px-3 py-1.5 rounded-pill mb-2 fw-bold"
                  style="
                    background: rgba(234, 179, 8, 0.15);
                    color: #B45309;
                    border: 1px solid rgba(234, 179, 8, 0.3);
                    font-size: 0.75rem;
                    letter-spacing: 0.5px;
                  ">

                <i class="bi bi-pencil-square me-1"></i>
                EDIT USER

            </span>

            <h3 class="fw-extrabold text-dark mb-1"
                style="
                    font-size: 1.75rem;
                    letter-spacing: -0.5px;
                ">

                Ubah Akun Pengguna

            </h3>

            <p class="text-muted small mb-0">

                Perbarui informasi akun administrator atau kasir
                sesuai kebutuhan sistem.

            </p>

        </div>

        <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">

            <div class="d-inline-flex align-items-center gap-2 time-badge-box text-start">

                <i class="bi bi-clock-history text-warning fs-4"></i>

                <div>

                    <div class="text-muted"
                         style="
                            font-size: 0.7rem;
                            text-transform: uppercase;
                            font-weight: 600;
                            letter-spacing: 0.5px;
                         ">

                        Waktu Akses

                    </div>

                    <div class="fw-bold text-dark"
                         style="font-size: 0.85rem;"
                         id="realtime-clock">

                        Memuat waktu...

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<div class="card card-light-custom shadow-sm mb-4">

    <div class="card-body p-4 p-md-5">

        <?php if (!empty($pesan_error)): ?>

            <div class="alert alert-danger alert-dismissible fade show rounded-4 mb-4 border-0 shadow-sm"
                 role="alert"
                 style="
                    background: rgba(239, 68, 68, 0.1);
                    color: #B91C1C;
                 ">

                <div class="d-flex align-items-center gap-2">

                    <i class="bi bi-exclamation-triangle-fill fs-5"></i>

                    <div>
                        <?= $pesan_error; ?>
                    </div>

                </div>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="alert"
                        aria-label="Close">
                </button>

            </div>

        <?php endif; ?>


        <form action=""
              method="POST"
              id="formEditUser">


            <div class="mb-3">

                <label for="NamaUser"
                       class="form-label">

                    Nama Lengkap
                    <span class="text-danger">*</span>

                </label>

                <div class="input-group">

                    <span class="input-group-text bg-light border-end-0 text-muted"
                          style="
                            border-radius: 12px 0 0 12px;
                            border-color: #E2E8F0;
                          ">

                        <i class="bi bi-person"></i>

                    </span>

                    <input type="text"
                           class="form-control form-control-custom border-start-0"
                           id="NamaUser"
                           name="NamaUser"
                           value="<?= htmlspecialchars($user['NamaUser']); ?>"
                           required
                           style="border-radius: 0 12px 12px 0;">

                </div>

            </div>


            <div class="mb-3">

                <label for="Username"
                       class="form-label">

                    Username (Untuk Login)
                    <span class="text-danger">*</span>

                </label>

                <div class="input-group">

                    <span class="input-group-text bg-light border-end-0 text-muted"
                          style="
                            border-radius: 12px 0 0 12px;
                            border-color: #E2E8F0;
                          ">

                        <i class="bi bi-at"></i>

                    </span>

                    <input type="text"
                           class="form-control form-control-custom border-start-0"
                           id="Username"
                           name="Username"
                           value="<?= htmlspecialchars($user['Username']); ?>"
                           required
                           style="border-radius: 0 12px 12px 0;">

                </div>

            </div>


            <div class="mb-3">

                <label for="Password"
                       class="form-label">

                    Password Baru
                    <span class="text-muted fw-normal">
                        (Opsional)
                    </span>

                </label>

                <div class="input-group">

                    <span class="input-group-text bg-light border-end-0 text-muted"
                          style="
                            border-radius: 12px 0 0 12px;
                            border-color: #E2E8F0;
                          ">

                        <i class="bi bi-key"></i>

                    </span>

                    <input type="password"
                           class="form-control form-control-custom border-start-0 border-end-0"
                           id="Password"
                           name="Password"
                           placeholder="Kosongkan jika tidak ingin mengubah password">

                    <button class="btn btn-light border text-muted"
                            type="button"
                            id="togglePassword"
                            style="
                                border-radius: 0 12px 12px 0;
                                border-color: #E2E8F0 !important;
                            ">

                        <i class="bi bi-eye"
                           id="iconEye">
                        </i>

                    </button>

                </div>

                <div class="form-text text-muted"
                     style="font-size: 0.75rem;">

                    Biarkan kosong jika password tidak ingin diganti.

                </div>

            </div>


            <div class="mb-4">

                <label for="Role"
                       class="form-label">

                    Hak Akses / Role
                    <span class="text-danger">*</span>

                </label>

                <select class="form-select form-select-custom"
                        id="Role"
                        name="Role"
                        required>

                    <option value="admin"
                        <?= (strtolower($user['Role']) === 'admin')
                            ? 'selected'
                            : ''; ?>>

                        Administrator

                    </option>

                    <option value="kasir"
                        <?= (strtolower($user['Role']) === 'kasir')
                            ? 'selected'
                            : ''; ?>>

                        Kasir

                    </option>

                </select>

            </div>


            <hr class="my-4 text-muted opacity-25">


            <div class="d-flex align-items-center justify-content-end gap-2">

                <a href="data-user.php"
                   class="btn btn-outline-secondary rounded-pill px-4 py-2 fw-semibold">

                    <i class="bi bi-arrow-left me-1"></i>
                    Batal

                </a>

                <button type="submit"
                        id="btnUpdate"
                        class="btn btn-warning rounded-pill px-5 py-2 fw-bold shadow-sm btn-update-custom">

                    <i class="bi bi-check-circle-fill me-1"></i>
                    Perbarui Perubahan

                </button>

            </div>

        </form>

    </div>

</div>

</div>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>

function updateClock() {

    const now = new Date();

    const options = {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };

    const clock =
        document.getElementById('realtime-clock');

    if (clock) {

        clock.innerText =
            now.toLocaleDateString('id-ID', options) +
            ' WIB';

    }

}

setInterval(updateClock, 1000);

updateClock();


const togglePassword =
    document.getElementById('togglePassword');

const passwordInput =
    document.getElementById('Password');

const iconEye =
    document.getElementById('iconEye');

if (togglePassword && passwordInput && iconEye) {

    togglePassword.addEventListener('click', function () {

        const type =
            passwordInput.getAttribute('type') === 'password'
                ? 'text'
                : 'password';

        passwordInput.setAttribute('type', type);

        if (type === 'text') {

            iconEye.classList.remove('bi-eye');

            iconEye.classList.add('bi-eye-slash');

        } else {

            iconEye.classList.remove('bi-eye-slash');

            iconEye.classList.add('bi-eye');

        }

    });

}


const formEditUser =
    document.getElementById('formEditUser');

if (formEditUser) {

    formEditUser.addEventListener('submit', function (event) {

        event.preventDefault();

        Swal.fire({

            title: 'Yakin Ingin Menyimpan Perubahan?',

            html:
                'Perubahan data akun ini akan ' +
                '<b>disimpan ke dalam sistem</b>.<br>' +
                'Pastikan informasi yang Anda masukkan sudah benar.',

            icon: 'question',

            iconColor: '#F59E0B',

            showCancelButton: true,

            confirmButtonText:
                '<i class="bi bi-check-circle-fill me-1"></i> Ya, Simpan Perubahan',

            cancelButtonText:
                '<i class="bi bi-x-lg me-1"></i> Batal',

            reverseButtons: true,

            focusCancel: true,

            allowOutsideClick: false,

            customClass: {

                popup: 'swal-edit-popup',

                title: 'swal-edit-title',

                htmlContainer: 'swal-edit-text',

                confirmButton: 'swal-edit-confirm',

                cancelButton: 'swal-edit-cancel'

            },

            buttonsStyling: false,

            showClass: {

                popup:
                    'animate__animated animate__fadeInDown'

            },

            hideClass: {

                popup:
                    'animate__animated animate__fadeOutUp'

            },

            didOpen: () => {

                const icon =
                    Swal.getIcon();

                if (icon) {

                    icon.classList.add(
                        'swal-question-icon'
                    );

                }

            }

        }).then((result) => {

            if (result.isConfirmed) {

                formEditUser.submit();

            }

        });

    });

}

</script>