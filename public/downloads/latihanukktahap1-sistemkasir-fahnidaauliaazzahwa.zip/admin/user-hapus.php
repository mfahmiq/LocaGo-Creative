<?php
// ==========================================================
// SESSION & KONEKSI
// ==========================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../koneksi.php';

date_default_timezone_set('Asia/Jakarta');

// ==========================================================
// CEK LOGIN & HAK AKSES (KHUSUS ADMIN)
// ==========================================================

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: ../index.php?pesan=belum_login");
    exit;
}

$role = strtolower(trim($_SESSION['Role'] ?? ''));

if ($role !== 'admin') {
    header("Location: ../index.php?pesan=akses_ditolak");
    exit;
}


// ==========================================================
// AMBIL USERNAME ADMIN YANG SEDANG LOGIN
// ==========================================================

$username_login = '';

if (isset($_SESSION['UserID'])) {

    $user_id_login = (int) $_SESSION['UserID'];

    $query_login_user = mysqli_query(
        $koneksi,
        "SELECT Username
         FROM user
         WHERE UserID = $user_id_login
         LIMIT 1"
    );

    if (
        $query_login_user &&
        mysqli_num_rows($query_login_user) > 0
    ) {

        $data_login_user =
            mysqli_fetch_assoc(
                $query_login_user
            );

        $username_login =
            $data_login_user['Username'];
    }
}

if (
    empty($username_login) &&
    isset($_SESSION['Username'])
) {

    $username_login =
        $_SESSION['Username'];
}


// ==========================================================
// PROSES HAPUS USER
// ==========================================================

if (isset($_GET['id'])) {

    $id_user =
        (int) $_GET['id'];


    // ======================================================
    // MENCEGAH ADMIN MENGHAPUS AKUN SENDIRI
    // ======================================================

    if (
        isset($_SESSION['UserID']) &&
        $id_user == (int) $_SESSION['UserID']
    ) {

        header(
            "Location: data-user.php?pesan=gagal_hapus_sendiri"
        );

        exit;
    }


    // ======================================================
    // AMBIL DATA USER SEBELUM DIHAPUS
    // ======================================================

    $query_user = mysqli_query(
        $koneksi,
        "SELECT
            UserID,
            NamaUser,
            Username,
            Role
         FROM user
         WHERE UserID = $id_user
         LIMIT 1"
    );


    // ======================================================
    // CEK DATA USER
    // ======================================================

    if (
        !$query_user ||
        mysqli_num_rows($query_user) === 0
    ) {

        header(
            "Location: data-user.php?pesan=tidak_ditemukan"
        );

        exit;
    }


    $data_user =
        mysqli_fetch_assoc(
            $query_user
        );


    // ======================================================
    // FORMAT DATA USER UNTUK AUDIT
    // ======================================================

    $format_user_id =
        'DAILYUSR' .
        $data_user['UserID'];


    $nama_user =
        $data_user['NamaUser'];


    $username_target =
        $data_user['Username'];


    $role_target =
        ucfirst(
            strtolower(
                trim(
                    $data_user['Role']
                )
            )
        );


    // ======================================================
    // JALANKAN QUERY HAPUS
    // ======================================================

    $query_hapus = mysqli_query(
        $koneksi,
        "DELETE FROM user
         WHERE UserID = $id_user"
    );


    // ======================================================
    // JIKA BERHASIL
    // ======================================================

    if ($query_hapus) {


        // ==================================================
        // BUAT DESKRIPSI AUDIT
        // ==================================================

        $deskripsi_audit =
            "Menghapus data user dengan ID " .
            $format_user_id .
            ", Nama: " .
            $nama_user .
            ", Username: @" .
            $username_target .
            ", Role: " .
            $role_target;


        // ==================================================
        // AMANKAN DATA AUDIT
        // ==================================================

        $username_login_safe =
            mysqli_real_escape_string(
                $koneksi,
                $username_login
            );


        $deskripsi_audit_safe =
            mysqli_real_escape_string(
                $koneksi,
                $deskripsi_audit
            );


        // ==================================================
        // SIMPAN AUDIT LOG
        // ==================================================

        mysqli_query(
            $koneksi,
            "INSERT INTO audit_log
            (
                username,
                waktu,
                aktivitas,
                deskripsi
            )
            VALUES
            (
                '$username_login_safe',
                NOW(),
                'HAPUS',
                '$deskripsi_audit_safe'
            )"
        );


        // ==================================================
        // REDIRECT BERHASIL
        // ==================================================

        header(
            "Location: data-user.php?pesan=sukses_hapus"
        );

        exit;


    } else {


        // ==================================================
        // GAGAL HAPUS
        // ==================================================

        header(
            "Location: data-user.php?pesan=gagal_relasi"
        );

        exit;
    }


} else {


    // ======================================================
    // JIKA ID TIDAK ADA
    // ======================================================

    header(
        "Location: data-user.php"
    );

    exit;
}

?>