<?php
session_start();
include '../koneksi.php';

// Proteksi Akses: Hanya Admin yang boleh cetak laporan
if (!isset($_SESSION['login']) || $_SESSION['Role'] !== 'admin') {
    header("Location: ../index.php?pesan=gagal");
    exit;
}

// Ambil parameter tanggal dari URL jika ada
$tgl_mulai = isset($_GET['tgl_mulai']) ? $_GET['tgl_mulai'] : '';
$tgl_selesai = isset($_GET['tgl_selesai']) ? $_GET['tgl_selesai'] : '';

// Buat kondisi WHERE berdasarkan apakah filter tanggal diisi atau tidak (menggunakan 'and')
$where_sql = "WHERE 1=1";
$where_sql_alias = "WHERE 1=1";

if (!empty($tgl_mulai) and !empty($tgl_selesai)) {
    $where_sql .= " AND DATE(TanggalPenjualan) BETWEEN '$tgl_mulai' AND '$tgl_selesai'";
    $where_sql_alias .= " AND DATE(p.TanggalPenjualan) BETWEEN '$tgl_mulai' AND '$tgl_selesai'";
    $keterangan_periode = "Periode: " . date('d M Y', strtotime($tgl_mulai)) . " s/d " . date('d M Y', strtotime($tgl_selesai));
} elseif (!empty($tgl_mulai)) {
    $where_sql .= " AND DATE(TanggalPenjualan) >= '$tgl_mulai'";
    $where_sql_alias .= " AND DATE(p.TanggalPenjualan) >= '$tgl_mulai'";
    $keterangan_periode = "Mulai Tanggal: " . date('d M Y', strtotime($tgl_mulai));
} elseif (!empty($tgl_selesai)) {
    $where_sql .= " AND DATE(TanggalPenjualan) <= '$tgl_selesai'";
    $where_sql_alias .= " AND DATE(p.TanggalPenjualan) <= '$tgl_selesai'";
    $keterangan_periode = "Sampai Tanggal: " . date('d M Y', strtotime($tgl_selesai));
} else {
    // Jika tanpa filter, cari otomatis tanggal transaksi pertama dan terakhir di database
    $q_range = mysqli_query($koneksi, "SELECT MIN(TanggalPenjualan) as awal, MAX(TanggalPenjualan) as akhir FROM penjualan");
    $d_range = mysqli_fetch_assoc($q_range);
    if (!empty($d_range['awal']) and !empty($d_range['akhir'])) {
        $tgl_awal_fmt = date('d M Y', strtotime($d_range['awal']));
        $tgl_akhir_fmt = date('d M Y', strtotime($d_range['akhir']));
        $keterangan_periode = "Semua Riwayat Penjualan (Rentang: $tgl_awal_fmt s/d $tgl_akhir_fmt)";
    } else {
        $keterangan_periode = "Semua Riwayat Penjualan (Belum ada data transaksi)";
    }
}

// Eksekusi Query Penjualan dengan JOIN ke tabel user agar nama kasir akurat
$query = mysqli_query($koneksi, "SELECT p.*, u.NamaUser as nama_kasir,
                                       COALESCE(pel.NamaPelanggan, p.NamaPelanggan, 'Pelanggan Umum / Tamu') AS NamaFinalPelanggan
                               FROM penjualan p 
                               LEFT JOIN user u ON p.UserID = u.UserID 
                               LEFT JOIN pelanggan pel ON p.PelangganID = pel.PelangganID
                               $where_sql_alias 
                               ORDER BY p.TanggalPenjualan DESC");

// Hitung Pendapatan & Total Transaksi
$query_tot = mysqli_query($koneksi, "SELECT SUM(TotalHarga) as total_pendapatan FROM penjualan $where_sql");
$data_tot = mysqli_fetch_assoc($query_tot);
$total_pendapatan = $data_tot['total_pendapatan'] ?? 0;
$total_transaksi = mysqli_num_rows($query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Laporan Penjualan - Daily Coffee & Toast</title>
    <link href="../asset/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: #1E293B;
            background: #FFFFFF;
            padding: 2rem 0;
        }
        .print-header {
            border-bottom: 3px double #CBD5E1;
            padding-bottom: 1.5rem;
            margin-bottom: 2rem;
        }
        .badge-periode {
            background: #F8FAFC;
            border: 1px solid #E2E8F0;
            color: #475569;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-weight: 600;
        }
        .table-print {
            border-collapse: collapse;
            width: 100%;
        }
        .table-print th {
            background-color: #1E293B !important;
            color: #FFFFFF !important;
            font-weight: 700;
            text-transform: uppercase;
            font-size: 11px;
            letter-spacing: 0.5px;
            padding: 10px 12px;
            border: 1px solid #1E293B;
        }
        .table-print td {
            border: 1px solid #E2E8F0;
            padding: 10px 12px;
            vertical-align: middle;
            font-size: 13px;
        }
        .table-print tbody tr:nth-child(even) {
            background-color: #F8FAFC;
        }
        .summary-box {
            background: #F8FAFC;
            border: 1px solid #E2E8F0;
            border-radius: 12px;
            padding: 1rem;
        }
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                padding: 0;
            }
            .table-print th {
                background-color: #000 !important;
                -webkit-print-color-adjust: exact;
            }
        }
    </style>
</head>
<body onload="window.print()">

    <div class="container">
        <!-- Panel Tombol Navigasi (Hilang saat diprint) -->
        <div class="d-flex justify-content-between align-items-center mb-4 no-print bg-light p-3 rounded-4 shadow-sm">
            <a href="laporan.php" class="btn btn-outline-secondary btn-sm px-3 rounded-pill fw-semibold">
                <i class="bi bi-arrow-left me-1"></i> Kembali ke Panel Laporan
            </a>
            <button onclick="window.print()" class="btn btn-dark btn-sm px-4 rounded-pill fw-bold shadow-sm">
                <i class="bi bi-printer-fill me-1 text-warning"></i> Cetak Dokumen / Simpan PDF
            </button>
        </div>

        <!-- Kop Surat / Judul Laporan -->
        <div class="print-header text-center">
            <h2 class="fw-extrabold text-dark mb-1">DAILY COFFEE & TOAST</h2>
            <p class="text-secondary small mb-2">Laporan Resmi Rekapitulasi Pendapatan & Transaksi Penjualan</p>
            <div class="d-inline-block mt-2">
                <span class="badge-periode"><i class="bi bi-calendar-range me-2 text-warning"></i><?= htmlspecialchars($keterangan_periode); ?></span>
            </div>
        </div>

        <!-- Ringkasan Statistik -->
        <div class="row mb-4 align-items-center">
            <div class="col-6">
                <div class="summary-box">
                    <span class="text-muted small d-block">Total Transaksi Berhasil</span>
                    <h5 class="fw-bold text-dark mb-0"><?= $total_transaksi; ?> Transaksi</h5>
                </div>
            </div>
            <div class="col-6 text-end">
                <div class="summary-box">
                    <span class="text-muted small d-block">Akumulasi Pendapatan</span>
                    <h4 class="text-success fw-bold mb-0">Rp <?= number_format($total_pendapatan, 0, ',', '.'); ?></h4>
                </div>
            </div>
        </div>

        <!-- Tabel Data Rinci -->
        <div class="table-responsive mb-5">
            <table class="table table-print align-middle mb-0">
                <thead>
                    <tr>
                        <th class="text-center" style="width: 50px;">No</th>
                        <th>No. Transaksi</th>
                        <th>Waktu Transaksi</th>
                        <th>Kasir / Petugas</th>
                        <th>Nama Customer</th>
                        <th class="text-end">Total Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($total_transaksi > 0): ?>
                        <?php 
                        $no = 1; 
                        while ($row = mysqli_fetch_assoc($query)): 
                            $nama_kasir = $row['nama_kasir'] ?? 'Kasir Shift';
                            $nama_customer = $row['NamaFinalPelanggan'];
                            $id_transaksi = $row['PenjualanID'] ?? $row['id_penjualan'];
                            
                            // Format Nomor Transaksi (TRX-YYYYMMDD-ID)
                            $format_tgl_trx = date('Ymd', strtotime($row['TanggalPenjualan']));
                            $no_transaksi_formatted = 'TRX-' . $format_tgl_trx . '-' . str_pad($id_transaksi, 4, '0', STR_PAD_LEFT);
                        ?>
                        <tr>
                            <td class="text-center text-muted"><?= $no++; ?></td>
                            <td>
                                <span class="badge bg-light text-dark border px-2 py-1 fw-bold" style="font-size: 11px; font-family: monospace;">
                                    <?= $no_transaksi_formatted; ?>
                                </span>
                            </td>
                            <td><i class="bi bi-clock me-1 text-muted"></i> <?= htmlspecialchars($row['TanggalPenjualan']); ?></td>
                            <td><span class="badge bg-secondary bg-opacity-15 text-dark border px-2 py-1"><?= htmlspecialchars($nama_kasir); ?></span></td>
                            <td><span class="fw-semibold text-dark"><?= htmlspecialchars($nama_customer); ?></span></td>
                            <td class="text-end fw-bold text-success">Rp <?= number_format($row['TotalHarga'], 0, ',', '.'); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center py-5 text-muted">Tidak ada data transaksi yang tercatat.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Tanda Tangan Pengesahan -->
        <div class="row mt-5 pt-3">
            <div class="col-7">
                <p class="text-muted small mb-1">Catatan Sistem:</p>
                <p class="text-muted small fst-italic mb-0">Laporan ini digenerate secara otomatis oleh sistem manajemen Daily Coffee & Toast pada <?= date('d-m-Y H:i:s'); ?>.</p>
            </div>
            <div class="col-5 text-center">
                <p class="mb-5 small text-secondary">Mengetahui,<br><strong>Manager / Administrator</strong></p>
                <br><br>
                <p class="mb-0 fw-bold text-dark border-top d-inline-block px-4 pt-1">(Fahnida Aulia A.)</p>
            </div>
        </div>
    </div>

</body>
</html>