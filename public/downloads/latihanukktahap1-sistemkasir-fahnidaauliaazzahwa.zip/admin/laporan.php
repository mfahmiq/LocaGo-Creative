<?php
include '../koneksi.php';
include 'header.php';

// Ambil input filter tanggal (kosong by default jika tidak diisi)
$tgl_mulai = isset($_GET['tgl_mulai']) ? $_GET['tgl_mulai'] : '';$tgl_selesai = isset($_GET['tgl_selesai']) ?$_GET['tgl_selesai'] : '';

// Shortcut tanggal cepat untuk tombol filter tampilan
$tgl_hari_ini = date('Y-m-d');$tgl_minggu_lalu = date('Y-m-d', strtotime('-6 days')); // 7 hari terakhir
$tgl_awal_bulan = date('Y-m-01');$tgl_akhir_bulan = date('Y-m-t');

// Cek apakah tombol shortcut cepat diklik melalui parameter URL 'filter'
$filter_mode = isset($_GET['filter']) ?$_GET['filter'] : '';
if ($filter_mode === 'hari_ini') {
    $tgl_mulai =$tgl_hari_ini;
    $tgl_selesai =$tgl_hari_ini;
} elseif ($filter_mode === 'minggu_ini') {
    $tgl_mulai =$tgl_minggu_lalu;
    $tgl_selesai =$tgl_hari_ini;
} elseif ($filter_mode === 'bulan_ini') {
    $tgl_mulai =$tgl_awal_bulan;
    $tgl_selesai =$tgl_akhir_bulan;
}

// Konfigurasi Paginasi (Maks 20 data per halaman)
$limit = 20;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) *$limit;

// Buat kondisi WHERE berdasarkan filter tanggal jika diisi
$where_sql = "WHERE 1=1";
$where_sql_alias = "WHERE 1=1";
if (!empty($tgl_mulai) && !empty($tgl_selesai)) {$where_sql .= " AND DATE(TanggalPenjualan) BETWEEN '$tgl_mulai' AND '$tgl_selesai'";
    $where_sql_alias .= " AND DATE(p.TanggalPenjualan) BETWEEN '$tgl_mulai' AND '$tgl_selesai'";
} elseif (!empty($tgl_mulai)) {$where_sql .= " AND DATE(TanggalPenjualan) >= '$tgl_mulai'";
    $where_sql_alias .= " AND DATE(p.TanggalPenjualan) >= '$tgl_mulai'";
} elseif (!empty($tgl_selesai)) {$where_sql .= " AND DATE(TanggalPenjualan) <= '$tgl_selesai'";
    $where_sql_alias .= " AND DATE(p.TanggalPenjualan) <= '$tgl_selesai'";
}

// Hitung total data untuk paginasi & informasi ringkas
$query_count = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM penjualan $where_sql");
$data_count = mysqli_fetch_assoc($query_count);$total_data = $data_count['total'];$total_pages = ceil($total_data / $limit);

// Ambil data penjualan dengan JOIN ke tabel user & pelanggan
$query = mysqli_query($koneksi, "
    SELECT p.*, 
           u.NamaUser AS nama_petugas, 
           u.Role AS role_petugas,
           COALESCE(pel.NamaPelanggan, p.NamaPelanggan, 'Pelanggan Umum / Tamu') AS NamaFinalPelanggan
    FROM penjualan p 
    LEFT JOIN user u ON p.UserID = u.UserID 
    LEFT JOIN pelanggan pel ON p.PelangganID = pel.PelangganID
    $where_sql_alias 
    ORDER BY p.TanggalPenjualan DESC 
    LIMIT $limit OFFSET $offset
");

// Hitung total pendapatan sesuai filter
$query_tot = mysqli_query($koneksi, "SELECT SUM(TotalHarga) as total_pendapatan FROM penjualan $where_sql");
$data_tot = mysqli_fetch_assoc($query_tot);
$total_pendapatan =$data_tot['total_pendapatan'] ?? 0;
?>

<!-- CSS KHUSUS HALAMAN LAPORAN -->
<style>
    body {
        background: #F4F6F9 !important;
        color: #333333 !important;
    }

    /* Card Banner Header Halaman */
    .card-header-banner {
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 20px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.04);
        color: #1E293B;
        padding: 1.75rem 2rem;
    }

    .page-title {
        color: #1E293B;
        font-weight: 800;
        letter-spacing: -0.5px;
        font-size: 1.75rem;
    }
    
    .page-subtitle {
        color: #64748B;
        font-size: 0.9rem;
    }

    .badge-banner-status {
        background: rgba(234, 179, 8, 0.15);
        color: #B45309;
        border: 1px solid rgba(234, 179, 8, 0.3);
        font-weight: 700;
        font-size: 0.75rem;
        letter-spacing: 0.5px;
        padding: 0.3rem 0.8rem;
        border-radius: 50rem;
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        margin-bottom: 0.5rem;
    }

    .card-light-custom {
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 20px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
        color: #1E293B;
        overflow: hidden;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .card-light-custom:hover {
        box-shadow: 0 12px 30px rgba(0, 0, 0, 0.08);
    }

    /* --- STAT CARD UTAMA --- */
    .stat-card-main {
        padding: 1.25rem 1.5rem;
        border-radius: 20px;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .stat-icon-box {
        width: 48px;
        height: 48px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.35rem;
    }

    /* --- TOMBOL FILTER CEPAT --- */
    .btn-filter-quick {
        font-weight: 600;
        border-radius: 12px;
        padding: 0.6rem 1rem;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.04);
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        text-decoration: none;
        font-size: 0.82rem;
        width: 100%;
        border: 1px solid #E7E5E4;
        background: #FAF8F5;
        color: #2D2621;
    }

    .btn-filter-quick:hover, .btn-filter-quick.active {
        background: #C49A45;
        color: #FFFFFF;
        border-color: #C49A45;
    }

    .form-control-light {
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        color: #1E293B !important;
        border-radius: 10px;
        padding: 0.6rem 1rem;
        font-size: 0.9rem;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.02);
    }

    .form-control-light:focus {
        background: #FFFFFF;
        border-color: #C49A45;
        box-shadow: 0 0 10px rgba(196, 154, 69, 0.15);
    }

    .btn-gold-light {
        background: #182232;
        color: #F59E0B;
        font-weight: 600;
        border-radius: 10px;
        border: 1px solid #182232;
        transition: all 0.2s ease;
        font-size: 0.85rem;
    }

    .btn-gold-light:hover {
        background: #273548;
        color: #FFFFFF;
    }

    /* Tombol Cetak Utama */
    .btn-print-main {
        background: #182232;
        color: #FFFFFF;
        font-weight: 600;
        border-radius: 12px;
        padding: 0.6rem 1.5rem;
        border: 1px solid #182232;
        transition: all 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        font-size: 0.9rem;
    }
    .btn-print-main:hover {
        background: #273548;
        color: #FACC15;
    }

    /* --- STYLE TOMBOL DETAIL & CETAK DALAM TABEL --- */
    .btn-action-detail {
        border: 1.5px solid #0dcaf0;
        color: #0dcaf0;
        font-weight: 600;
        border-radius: 50rem;
        background: transparent;
        transition: all 0.25s ease;
        padding: 0.35rem 1rem;
        font-size: 0.8rem;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .btn-action-detail:hover {
        background: #0dcaf0;
        color: #FFFFFF;
        box-shadow: 0 4px 12px rgba(13, 202, 240, 0.3);
    }

    .btn-action-print {
        border: 1.5px solid #C49A45;
        color: #C49A45;
        font-weight: 600;
        border-radius: 50rem;
        background: transparent;
        transition: all 0.25s ease;
        padding: 0.35rem 1rem;
        font-size: 0.8rem;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .btn-action-print:hover {
        background: #C49A45;
        color: #FFFFFF;
        box-shadow: 0 4px 12px rgba(196, 154, 69, 0.3);
    }

    /* Tabel Diselaraskan */
    .table-vibrant {
        border-collapse: separate;
        border-spacing: 0;
        width: 100%;
    }

    .table-vibrant th {
        background: #182232 !important;
        color: #FFFFFF !important;
        font-weight: 700;
        text-transform: uppercase;
        font-size: 0.8rem;
        letter-spacing: 0.8px;
        padding: 1.25rem 1.5rem !important;
        border: none;
        position: relative;
    }

    .table-vibrant th::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: linear-gradient(90deg, #D97706, #F59E0B);
    }

    .table-vibrant td {
        background-color: #FFFFFF !important;
        border-bottom: 1px solid #F1F5F9 !important;
        vertical-align: middle;
        color: #1E293B !important;
        padding: 1.25rem 1.5rem !important;
        font-size: 0.9rem;
    }

    .table-vibrant tbody tr {
        transition: all 0.2s ease;
    }

    .table-vibrant tbody tr:hover {
        background-color: #FAF8F5 !important;
    }

    .time-icon-box {
        width: 38px;
        height: 38px;
        background: #FFFBEB;
        border: 1px solid #FDE68A;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #D97706;
        font-size: 1.1rem;
    }
</style>

<div class="container-fluid px-0">

    <!-- Banner Header Halaman -->
    <div class="card card-header-banner p-4 mb-4">
        <div class="row align-items-center gy-3">
            <div class="col-lg-7">
                <div class="badge-banner-status">
                    <i class="bi bi-file-earmark-bar-graph text-warning"></i> SALES REPORT ACTIVE
                </div>
                <h2 class="page-title mb-1">Laporan Penjualan</h2>
                <p class="page-subtitle mb-0">Rekap transaksi keseluruhan operasional kedai kopi secara berkala.</p>
            </div>
            <div class="col-lg-5 text-lg-end">
                <div class="d-inline-flex align-items-center gap-2 bg-white px-3 py-2 rounded-3 border shadow-sm">
                    <i class="bi bi-clock-history text-warning fs-5"></i>
                    <div class="text-start">
                        <span class="text-muted d-block" style="font-size: 11px; line-height: 1;">Waktu Akses Sistem</span>
                        <span id="live-clock" class="fw-bold text-dark" style="font-size: 13px;">Memuat waktu...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 1. Statistik Utama (Omset & Total Nota) -->
    <div class="row mb-4 g-4">
        <div class="col-xl-6 col-md-6">
            <div class="card card-light-custom stat-card-main border-warning border-2">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <span class="text-secondary fw-bold text-uppercase" style="font-size: 0.75rem; letter-spacing: 0.5px;">Total Pendapatan (Omset)</span>
                        <h3 class="text-dark fw-extrabold mb-1 mt-1" style="font-size: 1.65rem; font-weight: 800;">
                            Rp <?= number_format($total_pendapatan, 0, ',', '.'); ?>
                        </h3>
                        <span class="text-muted" style="font-size: 0.8rem;"><i class="bi bi-check-circle-fill text-success me-1"></i> Berdasarkan filter tabel aktif</span>
                    </div>
                    <div class="stat-icon-box bg-warning bg-opacity-10 text-warning flex-shrink-0">
                        <i class="bi bi-wallet2"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-6 col-md-6">
            <div class="card card-light-custom stat-card-main border-primary border-2">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <span class="text-secondary fw-bold text-uppercase" style="font-size: 0.75rem; letter-spacing: 0.5px;">Total Nota Transaksi</span>
                        <h3 class="text-dark fw-extrabold mb-1 mt-1" style="font-size: 1.65rem; font-weight: 800;">
                            <?= number_format($total_data, 0, ',', '.'); ?> <span class="fs-6 fw-semibold text-secondary">Nota</span>
                        </h3>
                        <span class="text-muted" style="font-size: 0.8rem;"><i class="bi bi-receipt text-primary me-1"></i> Jumlah transaksi tercatat</span>
                    </div>
                    <div class="stat-icon-box bg-primary bg-opacity-10 text-primary flex-shrink-0">
                        <i class="bi bi-receipt-cutoff"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 2. Tombol Shortcut Filter Tampilan Tabel & Tombol Print Utama -->
    <div class="card card-light-custom p-4 mb-4">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-3">
            <h6 class="fw-bold mb-0 text-dark d-flex align-items-center gap-2">
                <i class="bi bi-funnel-fill" style="color: #C49A45;"></i> Filter Cepat Tampilan Tabel
            </h6>
            <div>
                <a href="laporan-cetak.php?tgl_mulai=<?= $tgl_mulai; ?>&tgl_selesai=<?=$tgl_selesai; ?>" target="_blank" class="btn-print-main shadow-sm">
                    <i class="bi bi-printer-fill text-warning"></i> Print Laporan Saat Ini
                </a>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-xl-4 col-md-4">
                <a href="laporan.php?filter=hari_ini" class="btn-filter-quick <?= ($filter_mode === 'hari_ini') ? 'active' : ''; ?>">
                    <i class="bi bi-calendar-check text-success"></i> Lihat Hari Ini
                </a>
            </div>
            <div class="col-xl-4 col-md-4">
                <a href="laporan.php?filter=minggu_ini" class="btn-filter-quick <?= ($filter_mode === 'minggu_ini') ? 'active' : ''; ?>">
                    <i class="bi bi-calendar-week text-warning"></i> Lihat 7 Hari Terakhir
                </a>
            </div>
            <div class="col-xl-4 col-md-4">
                <a href="laporan.php?filter=bulan_ini" class="btn-filter-quick <?= ($filter_mode === 'bulan_ini') ? 'active' : ''; ?>">
                    <i class="bi bi-calendar-range text-primary"></i> Lihat Bulan Ini (<?= date('M Y'); ?>)
                </a>
            </div>
        </div>
    </div>

    <!-- Filter Card Kustom Tanggal -->
    <div class="card card-light-custom p-4 mb-4">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label small text-secondary fw-semibold mb-1">Dari Tanggal (Opsional)</label>
                <input type="date" name="tgl_mulai" class="form-control form-control-light" value="<?= $tgl_mulai; ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label small text-secondary fw-semibold mb-1">Sampai Tanggal (Opsional)</label>
                <input type="date" name="tgl_selesai" class="form-control form-control-light" value="<?= $tgl_selesai; ?>">
            </div>
            <div class="col-md-4 d-flex gap-2">
                <button type="submit" class="btn btn-gold-light w-100 py-2 shadow-sm"><i class="bi bi-filter me-1"></i> Terapkan Filter</button>
                <?php if (!empty($tgl_mulai) || !empty($tgl_selesai)): ?>
                    <a href="laporan.php" class="btn btn-outline-secondary py-2 px-3 rounded-2 d-flex align-items-center justify-content-center" title="Reset Filter" style="border-radius: 10px !important;"><i class="bi bi-arrow-counterclockwise"></i></a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Tabel Laporan -->
    <div class="card card-light-custom shadow-sm mb-4">
        <div class="table-responsive">
            <table class="table table-vibrant align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width: 16%;">No. Transaksi</th>
                        <th style="width: 18%;">Tanggal / Waktu</th>
                        <th style="width: 20%;">Petugas (Kasir / Admin)</th>
                        <th style="width: 16%;">Nama Customer</th>
                        <th style="width: 15%;">Total Harga</th>
                        <th style="width: 15%;" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($query) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($query)):$nama_petugas = $row['nama_petugas'] ?? 'Petugas Sistem';$role_petugas = !empty($row['role_petugas']) ? strtolower(trim($row['role_petugas'])) : 'kasir';
                            $role_petugas_label = ucfirst($role_petugas);

                            // Pembedaan warna badge berdasarkan role: Admin (Merah) vs Kasir (Kuning/Orange hangat)
                            if ($role_petugas === 'admin') {$badge_style = 'background: #FEE2E2; color: #DC2626; border: 1px solid #FECACA;';
                                $badge_icon = 'bi-shield-fill-check';
                            } else {
                                $badge_style = 'background: #FEF3C7; color: #D97706; border: 1px solid #FDE68A;';
                                $badge_icon = 'bi bi-person-badge';
                            }

                            $nama_customer =$row['NamaFinalPelanggan'];
                            $id_transaksi =$row['PenjualanID'] ?? $row['id_penjualan'];$format_tgl_trx = date('Ymd', strtotime($row['TanggalPenjualan']));$no_transaksi_formatted = 'TRX-' . $format_tgl_trx . '-' . str_pad($id_transaksi, 4, '0', STR_PAD_LEFT);
                        ?>
                        <tr>
                            <td>
                                <span class="badge bg-light text-dark border px-2.5 py-1.5 fw-bold" style="font-size: 0.8rem; font-family: monospace;">
                                    <?= $no_transaksi_formatted; ?>
                                </span>
                            </td>
                            <td>
                                <div class="d-flex align-items-center gap-3">
                                    <div class="time-icon-box">
                                        <i class="bi bi-calendar3"></i>
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark"><?= date('d M Y', strtotime($row['TanggalPenjualan'])); ?></div>
                                        <div class="text-muted" style="font-size: 0.8rem;"><?= date('H:i:s', strtotime($row['TanggalPenjualan'])); ?> WIB</div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="fw-bold text-dark"><?= htmlspecialchars($nama_petugas); ?></div>
                                <span class="badge mt-1 px-2 py-1" style="<?= $badge_style; ?> font-size: 0.7rem; font-weight: 600;">
                                    <i class="bi <?= $badge_icon; ?> me-1"></i><?= htmlspecialchars($role_petugas_label); ?>
                                </span>
                            </td>
                            <td>
                                <span class="fw-bold text-dark"><?= htmlspecialchars($nama_customer); ?></span>
                            </td>
                            <td class="fw-bold text-success" style="font-size: 0.95rem;">
                                Rp <?= number_format($row['TotalHarga'], 0, ',', '.'); ?>
                            </td>
                            <td class="text-center">
                                <div class="d-flex align-items-center justify-content-center gap-2">
                                    <!-- Tombol Detail -->
                                    <a href="../kasir/detail-transaksi.php?id=<?= $id_transaksi; ?>" class="btn-action-detail" title="Lihat Rincian Menu">
                                        <i class="bi bi-eye"></i> Detail
                                    </a>
                                    <!-- Tombol Cetak -->
                                    <a href="../kasir/cetak-struk.php?id=<?= $id_transaksi; ?>" target="_blank" class="btn-action-print" title="Cetak Struk">
                                        <i class="bi bi-printer"></i> Cetak
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-5">
                                <i class="bi bi-inbox fs-2 d-block mb-2 text-warning opacity-50"></i>
                                Tidak ada data transaksi yang ditemukan.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Paginasi -->
        <?php if ($total_pages > 1): ?>
        <div class="card-footer bg-white border-0 py-3">
            <nav>
                <ul class="pagination justify-content-center mb-0">
                    <li class="page-item <?= ($page <= 1) ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?tgl_mulai=<?= $tgl_mulai; ?>&tgl_selesai=<?=$tgl_selesai; ?>&filter=<?= $filter_mode; ?>&page=<?=$page - 1; ?>">Sebelumnya</a>
                    </li>

                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= ($page ==$i) ? 'active' : ''; ?>">
                            <a class="page-link <?= ($page ==$i) ? 'bg-warning text-dark border-warning fw-bold' : ''; ?>" href="?tgl_mulai=<?= $tgl_mulai; ?>&tgl_selesai=<?= $tgl_selesai; ?>&filter=<?=$filter_mode; ?>&page=<?= $i; ?>"><?= $i; ?></a>
                        </li>
                    <?php endfor; ?>

                    <li class="page-item <?= ($page >=$total_pages) ? 'disabled' : ''; ?>">
                        <a class="page-link" href="?tgl_mulai=<?= $tgl_mulai; ?>&tgl_selesai=<?=$tgl_selesai; ?>&filter=<?= $filter_mode; ?>&page=<?=$page + 1; ?>">Selanjutnya</a>
                    </li>
                </ul>
            </nav>
        </div>
        <?php endif; ?>
    </div>

</div>

<script src="../asset/js/bootstrap.bundle.min.js"></script>

<!-- Script Jam Real-Time -->
<script>
    function updateLiveClock() {
        const now = new Date();
        const optionsDate = { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'short', year: 'numeric' };
        const dateStr = now.toLocaleDateString('id-ID', optionsDate);
        
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');
        
        const timeStr = `${hours}:${minutes}:${seconds}`;
        const clockElem = document.getElementById('live-clock');
        if(clockElem) {
            clockElem.innerText = `${dateStr}, ${timeStr} WIB`;
        }
    }

    updateLiveClock();
    setInterval(updateLiveClock, 1000);
</script>
</body>
</html>