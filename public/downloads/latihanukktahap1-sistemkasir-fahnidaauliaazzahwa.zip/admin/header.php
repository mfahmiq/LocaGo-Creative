<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../koneksi.php';

if (!isset($_SESSION['login']) ||$_SESSION['Role'] !== 'admin') {
    header("Location: ../index.php?pesan=gagal");
    exit;
}

$current_page = basename($_SERVER['PHP_SELF']);
$user_nama =$_SESSION['NamaUser'] ?? 'Administrator';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Daily Coffee & Daily Toast</title>
    
    <link href="../asset/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        :root {
            --c-bg-dark: #0A0908;
            --c-navbar: #141210;
            --c-gold: #F3E5AB;
            --c-gold-dark: #D4AF37;
            --c-text-main: #F5F5F4;
            --c-text-muted: #D1D5DB;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, #0A0908 0%, #1A1714 50%, #0F0D0B 100%), 
                        url('https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=1920&q=80') center/cover fixed no-repeat;
            color: var(--c-text-main);
            padding-bottom: 3rem;
        }

        .navbar-custom {
            background: rgba(15, 13, 11, 0.95) !important;
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border-bottom: 2px solid var(--c-gold-dark);
            box-shadow: 0 12px 35px rgba(0, 0, 0, 0.7);
            transition: all 0.3s ease;
        }

        .navbar-brand .brand-icon {
            background: linear-gradient(135deg, #F3E5AB 0%, #C5A059 100%);
            color: #0A0908;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 0 20px rgba(243, 229, 171, 0.4);
        }

        .navbar-brand:hover .brand-icon {
            transform: scale(1.08) rotate(5deg);
            box-shadow: 0 0 30px rgba(243, 229, 171, 0.7);
        }

        .nav-link {
            color: var(--c-text-muted) !important;
            font-weight: 600;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border-radius: 12px;
            padding: 0.6rem 1.1rem !important;
            position: relative;
        }

        .nav-link:hover,
        .nav-link.active,
        .dropdown-toggle.show {
            color: #FFFFFF !important;
            background: linear-gradient(
                135deg,
                rgba(243, 229, 171, 0.18) 0%,
                rgba(197, 160, 89, 0.12) 100%
            );
            border: 1px solid var(--c-gold-dark);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(197, 160, 89, 0.25);
        }

        .dropdown-menu-custom {
            background: rgba(18, 15, 13, 0.98) !important;
            backdrop-filter: blur(25px);
            border: 1px solid var(--c-gold-dark);
            border-radius: 16px;
            padding: 0.6rem;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.8);
            animation: dropdownFadeIn 0.25s ease forwards;
        }

        @keyframes dropdownFadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .dropdown-item-custom {
            color: var(--c-text-muted) !important;
            border-radius: 10px;
            padding: 0.7rem 1rem;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        .dropdown-item-custom:hover {
            color: #FFFFFF !important;
            background: linear-gradient(
                135deg,
                rgba(243, 229, 171, 0.25) 0%,
                rgba(197, 160, 89, 0.15) 100%
            );
            transform: translateX(6px);
            border-left: 4px solid var(--c-gold);
        }

        .admin-badge {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(243, 229, 171, 0.35);
            padding: 0.4rem 1rem;
            border-radius: 50rem;
            display: flex;
            align-items: center;
            gap: 0.7rem;
            box-shadow: inset 0 1px 3px rgba(255,255,255,0.15);
        }

        .live-dot {
            width: 9px;
            height: 9px;
            background-color: #34D399;
            border-radius: 50%;
            box-shadow: 0 0 10px #34D399;
            animation: pulse-green 2s infinite;
        }

        @keyframes pulse-green {
            0% {
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(52, 211, 153, 0.8);
            }

            70% {
                transform: scale(1);
                box-shadow: 0 0 0 8px rgba(52, 211, 153, 0);
            }

            100% {
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(52, 211, 153, 0);
            }
        }

        .btn-outline-custom-danger {
            color: #F87171;
            border: 1px solid rgba(248, 113, 113, 0.4);
            background: rgba(248, 113, 113, 0.08);
            transition: all 0.25s ease;
            border-radius: 50rem;
            padding: 0.4rem 1.1rem;
            font-weight: 600;
        }

        .btn-outline-custom-danger:hover {
            background: #EF4444;
            color: #FFFFFF;
            border-color: #EF4444;
            box-shadow: 0 0 20px rgba(239, 68, 68, 0.5);
            transform: translateY(-2px);
        }

        /* Styling Kustom SweetAlert2 agar mirip gambar referensi */
        .swal2-popup {
            border-radius: 28px !important;
            font-family: 'Plus Jakarta Sans', sans-serif !important;
            padding: 2rem !important;
            width: 32em !important;
        }

        .swal2-icon.swal2-question {
            border-color: #F3E5AB !important;
            color: #D4AF37 !important;
            background: #FFFDF5 !important;
            box-shadow: 0 10px 25px rgba(212, 175, 55, 0.15) !important;
            font-weight: 700 !important;
        }

        .swal2-title {
            font-size: 1.5rem !important;
            font-weight: 800 !important;
            color: #111827 !important;
            margin-top: 1rem !important;
        }

        .swal2-html-container {
            font-size: 0.95rem !important;
            color: #4B5563 !important;
            margin-top: 0.5rem !important;
        }

        .swal2-actions {
            margin-top: 1.8rem !important;
            gap: 12px !important;
        }

        .brand-name-coffee {
            font-size: 0.9rem;
            font-weight: 800;
            letter-spacing: 0.8px;
            color: #EFECE6;
        }

        .brand-separator {
            color: var(--c-accent);
            font-weight: 800;
            font-size: 1rem;
        }
    </style>
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-custom sticky-top py-3 mb-4">

    <div class="container">

        <!-- Brand Logo -->
        <a class="navbar-brand fw-extrabold text-white d-flex align-items-center gap-2 text-decoration-none"
           href="laporan.php">

            <div class="brand-icon p-2 rounded-3 d-flex align-items-center justify-content-center shadow">
                <i class="bi bi-shield-shaded fs-5"></i>
            </div>

            <div class="d-flex flex-column">
                <span style="
                    letter-spacing: 0.8px;
                    font-weight: 800;
                    font-size: 1.05rem;
                    color: #FFFFFF;
                ">
                    ADMIN PANEL
                </span>

                <span style="
                    color: var(--c-gold);
                    font-size: 0.68rem;
                    font-weight: 700;
                    letter-spacing: 2px;
                    margin-top: -3px;
                ">
                <span class="brand-name">DAILY COFFEE</span>
                <span class="brand-separator">&bull;</span>
                <span class="brand-name">DAILY TOAST</span>
                </span>
            </div>

        </a>

        <!-- Toggle Mobile -->
        <button
            class="navbar-toggler border-0 text-white shadow-none"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#adminNavbar"
        >
            <i class="bi bi-grid-fill fs-2" style="color: var(--c-gold);"></i>
        </button>

        <div class="collapse navbar-collapse" id="adminNavbar">

            <ul class="navbar-nav mx-auto align-items-lg-center gap-1 mt-3 mt-lg-0">

                <!-- Dashboard -->
                <li class="nav-item">
                    <a
                        class="nav-link <?= $current_page == 'dashboard.php' ? 'active' : ''; ?>"
                        href="../kasir/dashboard.php"
                    >
                        <i class="bi bi-house-door me-1" style="color: var(--c-gold);"></i>
                        Dashboard
                    </a>
                </li>

                <!-- Laporan -->
                <li class="nav-item">
                    <a
                        class="nav-link <?= $current_page == 'laporan.php' ? 'active' : ''; ?>"
                        href="laporan.php"
                    >
                        <i class="bi bi-file-earmark-bar-graph me-1"
                           style="color: var(--c-gold);"></i>
                        Laporan Penjualan
                    </a>
                </li>

                <!-- Audit Log -->
                <li class="nav-item">
                    <a
                        class="nav-link <?= $current_page == 'audit-log.php' ? 'active' : ''; ?>"
                        href="audit-log.php"
                    >
                        <i class="bi bi-activity me-1"
                           style="color: var(--c-gold);"></i>
                        Aktivitas Sistem
                    </a>
                </li>

                <!-- Dropdown Kelola Data -->
                <li class="nav-item dropdown">

                    <a
                        class="nav-link dropdown-toggle
                        <?= in_array(
                            $current_page,
                            [
                                'produk.php',
                                'transaksi.php',
                                'pelanggan.php',
                                'data-user.php',
                                'user-tambah.php',
                                'user-edit.php'
                            ]
                        ) ? 'active' : ''; ?>"
                        href="#"
                        id="kelolaDropdown"
                        role="button"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                    >
                        <i class="bi bi-folder2-open me-1"
                           style="color: var(--c-gold);"></i>
                        Kelola Data
                    </a>

                    <ul
                        class="dropdown-menu dropdown-menu-custom shadow"
                        aria-labelledby="kelolaDropdown"
                    >

                        <!-- Kelola Produk -->
                        <li>
                            <a
                                class="dropdown-item dropdown-item-custom d-flex align-items-center gap-2"
                                href="../kasir/produk.php"
                            >
                                <i class="bi bi-cup-hot fs-6"
                                   style="color: var(--c-gold);"></i>
                                Kelola Produk
                            </a>
                        </li>

                        <!-- Kelola Transaksi -->
                        <li>
                            <a
                                class="dropdown-item dropdown-item-custom d-flex align-items-center gap-2"
                                href="transaksi.php"
                            >
                                <i class="bi bi-receipt fs-6"
                                   style="color: var(--c-gold);"></i>
                                Kelola Transaksi
                            </a>
                        </li>

                        <!-- Kelola Pelanggan -->
                        <li>
                            <a
                                class="dropdown-item dropdown-item-custom d-flex align-items-center gap-2"
                                href="../kasir/pelanggan.php"
                            >
                                <i class="bi bi-people fs-6"
                                   style="color: var(--c-gold);"></i>
                                Kelola Pelanggan
                            </a>
                        </li>

                        <!-- PEMBATAS -->
                        <li>
                            <hr
                                class="dropdown-divider"
                                style="border-color: rgba(243, 229, 171, 0.2);"
                            >
                        </li>

                        <!-- DATA USER / KARYAWAN -->
                        <li>
                            <a
                                class="dropdown-item dropdown-item-custom d-flex align-items-center gap-2"
                                href="data-user.php"
                            >
                                <i class="bi bi-person-badge-fill fs-6"
                                   style="color: var(--c-gold);"></i>
                                Data User / Karyawan
                            </a>
                        </li>

                    </ul>
                </li>

            </ul>

            <!-- Bagian Kanan: Info Admin & Logout -->
            <div class="d-flex align-items-center gap-3 mt-3 mt-lg-0 pt-3 pt-lg-0 border-top border-secondary border-opacity-25 border-top-0-lg">

                <!-- Info Admin -->
            <div class="admin-badge px-3 py-2 d-flex align-items-center gap-2">
                <i class="bi bi-person-circle fs-3" style="color: var(--c-gold);"></i>
                <div class="d-flex flex-column">
                    <span class="text-white fw-bold" style="font-size: 0.85rem; line-height: 1.2;">
                        <?= htmlspecialchars($user_nama); ?>
                    </span>
                    <span style="color: var(--c-gold); font-size: 0.7rem; font-weight: 700; letter-spacing: 0.5px;">
                        ADMIN
                    </span>
                </div>
            </div>

                <!-- LOGOUT -->
                <a
                    href="../logout.php"
                    id="btnLogout"
                    class="btn btn-outline-custom-danger btn-sm d-flex align-items-center gap-1"
                >
                    <i class="bi bi-box-arrow-right"></i>
                    <span class="d-none d-xl-inline">Logout</span>
                </a>

            </div>

        </div>

    </div>

</nav>


<!-- Bootstrap JS -->
<script src="../asset/js/bootstrap.bundle.min.js"></script>

<script>
document.addEventListener("DOMContentLoaded", function () {

    /* =====================================================
        DROPDOWN KELOLA DATA
    ===================================================== */

    var dropdownElement = document.getElementById('kelolaDropdown');

    if (dropdownElement) {

        dropdownElement.addEventListener('click', function (e) {

            var dropdownMenu = this.nextElementSibling;

            if (
                dropdownMenu &&
                dropdownMenu.classList.contains('dropdown-menu')
            ) {

                e.preventDefault();

                var bsDropdown =
                    bootstrap.Dropdown.getInstance(this) ||
                    new bootstrap.Dropdown(this);

                bsDropdown.toggle();
            }

        });

    }


    /* =====================================================
        POPUP LOGOUT (SWEETALERT2)
    ===================================================== */

    var btnLogout = document.getElementById('btnLogout');

    if (btnLogout) {

        btnLogout.addEventListener('click', function (e) {

            e.preventDefault();
            var logoutUrl = this.getAttribute('href');

            Swal.fire({

                icon: 'question',

                title: 'Keluar dari Sistem?',

                html: `
                    Apakah kamu yakin ingin mengakhiri sesi dan keluar dari
                    <br><strong>Daily Coffee Daily Toast</strong>?
                `,

                showCancelButton: true,

                confirmButtonText: 'Ya, Logout',

                cancelButtonText: 'Nanti Saja',

                reverseButtons: true,

                focusCancel: true,

                buttonsStyling: false,

                customClass: {

                    confirmButton: 'btn btn-danger rounded-pill px-5 py-2.5 fw-bold shadow-sm',

                    cancelButton: 'btn btn-light border rounded-pill px-5 py-2.5 fw-bold text-secondary shadow-sm'

                }

            }).then((result) => {

                if (result.isConfirmed) {

                    Swal.fire({

                        title: 'Sedang Logout...',

                        html: `
                            <span style="font-size:0.85rem; color:#6B7280;">
                                Mengakhiri sesi administrator
                            </span>
                        `,

                        allowOutsideClick: false,

                        allowEscapeKey: false,

                        showConfirmButton: false,

                        didOpen: () => {

                            Swal.showLoading();

                        }

                    });

                    setTimeout(function () {

                        window.location.href = logoutUrl;

                    }, 700);

                }

            });

        });

    }

});
</script>


<div class="container">