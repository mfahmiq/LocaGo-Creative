<?php
// ==========================================================
// SESSION & KONEKSI
// ==========================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../koneksi.php';

// ==========================================================
// CEK LOGIN & HAK AKSES (KHUSUS ADMIN)
// ==========================================================

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: ../index.php?pesan=belum_login");
    exit;
}

$role = strtolower(trim($_SESSION['Role'] ?? ''));

if ($role !== 'admin') {
    header("Location: ../index.php?pesan=akses_ditolak");
    exit;
}

date_default_timezone_set('Asia/Jakarta');

$pesan_error = '';

// ==========================================================
// AMBIL USERNAME ADMIN YANG SEDANG LOGIN
// ==========================================================

$username_login = '';

if (isset($_SESSION['UserID'])) {

    $user_id_login = (int) $_SESSION['UserID'];

    $query_login_user = mysqli_query(
        $koneksi,
        "SELECT Username
         FROM user
         WHERE UserID = $user_id_login
         LIMIT 1"
    );

    if ($query_login_user && mysqli_num_rows($query_login_user) > 0) {

        $data_login_user = mysqli_fetch_assoc(
            $query_login_user
        );

        $username_login = $data_login_user['Username'];
    }
}

// Jika session Username tersedia, gunakan sebagai cadangan
if (empty($username_login) && isset($_SESSION['Username'])) {
    $username_login = $_SESSION['Username'];
}


// ==========================================================
// PROSES FORM SUBMIT
// ==========================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nama_user = trim($_POST['NamaUser'] ?? '');
    $username  = trim($_POST['Username'] ?? '');
    $password  = $_POST['Password'] ?? '';
    $user_role = $_POST['Role'] ?? '';

    // ======================================================
    // VALIDASI SEDERHANA
    // ======================================================

    if (
        empty($nama_user) ||
        empty($username) ||
        empty($password) ||
        empty($user_role)
    ) {

        $pesan_error = "Semua kolom wajib diisi!";

    } else {

        // ==================================================
        // CEK APAKAH USERNAME SUDAH ADA
        // ==================================================

        $username_safe = mysqli_real_escape_string(
            $koneksi,
            $username
        );

        $cek_user = mysqli_query(
            $koneksi,
            "SELECT *
             FROM user
             WHERE Username = '$username_safe'"
        );

        if (mysqli_num_rows($cek_user) > 0) {

            $pesan_error =
                "Username <b>@" .
                htmlspecialchars($username) .
                "</b> sudah digunakan oleh akun lain. Silakan gunakan username yang berbeda.";

        } else {

            // ==============================================
            // AMANKAN DATA INPUTAN
            // ==============================================

            $nama_user_safe = mysqli_real_escape_string(
                $koneksi,
                $nama_user
            );

            $user_role_safe = mysqli_real_escape_string(
                $koneksi,
                $user_role
            );

            // ==============================================
            // HASH PASSWORD
            // ==============================================

            $password_hashed = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            // ==============================================
            // INSERT USER
            // ==============================================

            $query_insert = "
                INSERT INTO user
                (
                    NamaUser,
                    Username,
                    Password,
                    Role,
                    status
                )
                VALUES
                (
                    '$nama_user_safe',
                    '$username_safe',
                    '$password_hashed',
                    '$user_role_safe',
                    'Aktif'
                )
            ";

            if (mysqli_query($koneksi, $query_insert)) {

                // ==========================================
                // AMBIL ID USER YANG BARU DIBUAT
                // ==========================================

                $id_user_baru = mysqli_insert_id($koneksi);

                $format_user_id =
                    'DAILYUSR' . $id_user_baru;


                // ==========================================
                // FORMAT ROLE
                // ==========================================

                $role_tampil =
                    ucfirst(
                        strtolower(
                            trim($user_role)
                        )
                    );


                // ==========================================
                // BUAT DESKRIPSI AUDIT
                // ==========================================

                $deskripsi_audit =
                    "Menambahkan data user dengan ID " .
                    $format_user_id .
                    ", Nama: " .
                    $nama_user .
                    ", Username: @" .
                    $username .
                    ", Role: " .
                    $role_tampil;


                // ==========================================
                // AMANKAN DATA AUDIT
                // ==========================================

                $username_login_safe =
                    mysqli_real_escape_string(
                        $koneksi,
                        $username_login
                    );

                $deskripsi_audit_safe =
                    mysqli_real_escape_string(
                        $koneksi,
                        $deskripsi_audit
                    );


                // ==========================================
                // SIMPAN AUDIT LOG
                // ==========================================

                mysqli_query(
                    $koneksi,
                    "INSERT INTO audit_log
                    (
                        username,
                        waktu,
                        aktivitas,
                        deskripsi
                    )
                    VALUES
                    (
                        '$username_login_safe',
                        NOW(),
                        'TAMBAH',
                        '$deskripsi_audit_safe'
                    )"
                );


                // ==========================================
                // REDIRECT
                // ==========================================

                header(
                    "Location: data-user.php?pesan=sukses_tambah"
                );

                exit;

            } else {

                $pesan_error =
                    "Terjadi kesalahan pada database: " .
                    mysqli_error($koneksi);
            }
        }
    }
}


// ==========================================================
// HEADER
// ==========================================================

include 'header.php';
?>

<!-- ==========================================================
     CSS STYLING KHUSUS (SELARAS DENGAN HALAMAN LAINNYA)
========================================================== -->

<style>
body {
    background: #F4F6F9 !important;
    color: #333333 !important;
}

/* Header Banner */
.header-banner-custom {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.04);
    padding: 1.75rem 2rem;
}

.time-badge-box {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 12px;
    padding: 0.6rem 1rem;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.02);
}

.card-light-custom {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
    color: #1E293B;
}

.form-control-custom, .form-select-custom {
    border-radius: 12px;
    border: 1.5px solid #E2E8F0;
    padding: 0.7rem 1rem;
    font-size: 0.9rem;
    transition: all 0.25s ease;
}

.form-control-custom:focus, .form-select-custom:focus {
    border-color: #D97706;
    box-shadow: 0 0 0 4px rgba(217, 119, 6, 0.12);
}

.form-label {
    font-weight: 600;
    font-size: 0.85rem;
    color: #475569;
    margin-bottom: 0.5rem;
}
</style>

<!-- ==========================================================
     KONTEN UTAMA
========================================================== -->

<div class="container-fluid px-0" style="margin-top: 25px; max-width: 800px;">

    <!-- HEADER BANNER -->
    <div class="header-banner-custom mb-4">
        <div class="row align-items-center">
            <div class="col-lg-8">

                <span class="badge px-3 py-1.5 rounded-pill mb-2 fw-bold"
                      style="background: rgba(234, 179, 8, 0.15); color: #B45309; border: 1px solid rgba(234, 179, 8, 0.3); font-size: 0.75rem; letter-spacing: 0.5px;">

                    <i class="bi bi-person-plus-fill me-1"></i>
                    TAMBAH USER

                </span>

                <h3 class="fw-extrabold text-dark mb-1"
                    style="font-size: 1.75rem; letter-spacing: -0.5px;">

                    Tambah Akun Baru

                </h3>

                <p class="text-muted small mb-0">

                    Daftarkan akun administrator atau kasir baru untuk mengakses sistem POS Daily Coffee &amp; Toast.

                </p>

            </div>

            <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">

                <div class="d-inline-flex align-items-center gap-2 time-badge-box text-start">

                    <i class="bi bi-clock-history text-warning fs-4"></i>

                    <div>

                        <div class="text-muted"
                             style="font-size: 0.7rem; text-transform: uppercase; font-weight: 600; letter-spacing: 0.5px;">

                            Waktu Akses

                        </div>

                        <div class="fw-bold text-dark"
                             style="font-size: 0.85rem;"
                             id="realtime-clock">

                            Memuat waktu...

                        </div>

                    </div>

                </div>

            </div>
        </div>
    </div>


    <!-- KARTU FORM TAMBAH USER -->
    <div class="card card-light-custom shadow-sm mb-4">

        <div class="card-body p-4 p-md-5">

            <?php if (!empty($pesan_error)): ?>

                <div class="alert alert-danger alert-dismissible fade show rounded-4 mb-4 border-0 shadow-sm"
                     role="alert"
                     style="background: rgba(239, 68, 68, 0.1); color: #B91C1C;">

                    <div class="d-flex align-items-center gap-2">

                        <i class="bi bi-exclamation-triangle-fill fs-5"></i>

                        <div><?= $pesan_error; ?></div>

                    </div>

                    <button type="button"
                            class="btn-close"
                            data-bs-dismiss="alert"
                            aria-label="Close">
                    </button>

                </div>

            <?php endif; ?>


            <form action="" method="POST">

                <div class="mb-3">

                    <label for="NamaUser"
                           class="form-label">

                        Nama Lengkap
                        <span class="text-danger">*</span>

                    </label>

                    <div class="input-group">

                        <span class="input-group-text bg-light border-end-0 text-muted"
                              style="border-radius: 12px 0 0 12px; border-color: #E2E8F0;">

                            <i class="bi bi-person"></i>

                        </span>

                        <input type="text"
                               class="form-control form-control-custom border-start-0"
                               id="NamaUser"
                               name="NamaUser"
                               placeholder="Contoh: Budi Santoso"
                               value="<?= htmlspecialchars($_POST['NamaUser'] ?? ''); ?>"
                               required
                               style="border-radius: 0 12px 12px 0;">

                    </div>

                </div>


                <div class="mb-3">

                    <label for="Username"
                           class="form-label">

                        Username (Untuk Login)
                        <span class="text-danger">*</span>

                    </label>

                    <div class="input-group">

                        <span class="input-group-text bg-light border-end-0 text-muted"
                              style="border-radius: 12px 0 0 12px; border-color: #E2E8F0;">

                            <i class="bi bi-at"></i>

                        </span>

                        <input type="text"
                               class="form-control form-control-custom border-start-0"
                               id="Username"
                               name="Username"
                               placeholder="Contoh: budikasir"
                               value="<?= htmlspecialchars($_POST['Username'] ?? ''); ?>"
                               required
                               style="border-radius: 0 12px 12px 0;">

                    </div>

                </div>


                <div class="mb-3">

                    <label for="Password"
                           class="form-label">

                        Password
                        <span class="text-danger">*</span>

                    </label>

                    <div class="input-group">

                        <span class="input-group-text bg-light border-end-0 text-muted"
                              style="border-radius: 12px 0 0 12px; border-color: #E2E8F0;">

                            <i class="bi bi-key"></i>

                        </span>

                        <input type="password"
                               class="form-control form-control-custom border-start-0 border-end-0"
                               id="Password"
                               name="Password"
                               placeholder="Masukkan password akun"
                               required>

                        <button class="btn btn-light border text-muted"
                                type="button"
                                id="togglePassword"
                                style="border-radius: 0 12px 12px 0; border-color: #E2E8F0 !important;">

                            <i class="bi bi-eye"
                               id="iconEye">
                            </i>

                        </button>

                    </div>

                </div>


                <div class="mb-4">

                    <label for="Role"
                           class="form-label">

                        Hak Akses / Role
                        <span class="text-danger">*</span>

                    </label>

                    <select class="form-select form-select-custom"
                            id="Role"
                            name="Role"
                            required>

                        <option value=""
                                disabled
                                selected>

                            -- Pilih Hak Akses --

                        </option>

                        <option value="admin"
                            <?= (isset($_POST['Role']) && $_POST['Role'] === 'admin') ? 'selected' : ''; ?>>

                            Administrator
                            (Akses Penuh: Laporan, Kelola Menu & User)

                        </option>

                        <option value="kasir"
                            <?= (isset($_POST['Role']) && $_POST['Role'] === 'kasir') ? 'selected' : ''; ?>>

                            Kasir
                            (Akses Transaksi Penjualan & Pelanggan)

                        </option>

                    </select>

                </div>


                <hr class="my-4 text-muted opacity-25">


                <div class="d-flex align-items-center justify-content-end gap-2">

                    <a href="data-user.php"
                       class="btn btn-outline-secondary rounded-pill px-4 py-2 fw-semibold">

                        <i class="bi bi-arrow-left me-1"></i>
                        Batal

                    </a>

                    <button type="submit"
                            class="btn btn-warning rounded-pill px-5 py-2 fw-bold shadow-sm text-dark"
                            style="background: #F59E0B; border: none;">

                        <i class="bi bi-check-circle-fill me-1"></i>
                        Simpan User

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


<script>

function updateClock() {

    const now = new Date();

    const options = {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };

    document.getElementById('realtime-clock').innerText =
        now.toLocaleDateString('id-ID', options) + ' WIB';

}

setInterval(updateClock, 1000);

updateClock();


const togglePassword =
    document.getElementById('togglePassword');

const passwordInput =
    document.getElementById('Password');

const iconEye =
    document.getElementById('iconEye');


togglePassword.addEventListener('click', function () {

    const type =
        passwordInput.getAttribute('type') === 'password'
            ? 'text'
            : 'password';

    passwordInput.setAttribute('type', type);

    if (type === 'text') {

        iconEye.classList.remove('bi-eye');

        iconEye.classList.add('bi-eye-slash');

    } else {

        iconEye.classList.remove('bi-eye-slash');

        iconEye.classList.add('bi-eye');

    }

});

</script>