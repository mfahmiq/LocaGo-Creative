<?php
// 1. Panggil koneksi database terlebih dahulu
include '../koneksi.php';

// 2. Panggil header kasir/admin
include '../kasir/header.php';

// Ambil ID produk dari URL
$produk_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Ambil data produk berdasarkan ID
$query = mysqli_query($koneksi, "SELECT * FROM produk WHERE ProdukID = '$produk_id'");
$data = mysqli_fetch_assoc($query);

if (!$data) {
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Data menu tidak ditemukan!',
                confirmButtonColor: '#C49A45'
            }).then(() => {
                window.location='produk.php';
            });
        });
    </script>";
    exit;
}

$berhasil_update = false;

// Proses form saat disubmit
if (isset($_POST['update_produk']) || isset($_POST['trigger_update'])) {

    $nama_produk = mysqli_real_escape_string(
        $koneksi,
        trim($_POST['NamaProduk'] ?? '')
    );

    $harga = (float)($_POST['Harga'] ?? 0);
    $stok  = (int)($_POST['Stok'] ?? 0);

    // =========================================================
    // SIMPAN DATA LAMA UNTUK AUDIT LOG
    // =========================================================

    $nama_lama  = $data['NamaProduk'] ?? '';
    $harga_lama = (float)($data['Harga'] ?? 0);
    $stok_lama  = (int)($data['Stok'] ?? 0);
    $foto_lama  = $data['foto'] ?? '';

    $nama_file_foto = $foto_lama;

    // Penanda apakah foto diganti
    $foto_berubah = false;
    $foto_baru_terupload = '';

    // =========================================================
    // CEK UPLOAD FOTO BARU
    // =========================================================

    if (
        isset($_FILES['foto']) &&
        $_FILES['foto']['error'] === UPLOAD_ERR_OK
    ) {

        $file_tmp  = $_FILES['foto']['tmp_name'];
        $file_name = $_FILES['foto']['name'];
        $file_ext  = strtolower(
            pathinfo($file_name, PATHINFO_EXTENSION)
        );

        $allowed_ext = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($file_ext, $allowed_ext)) {

            $nama_file_foto = 'menu_' . time() . '.' . $file_ext;

            $target_dir = '../asset/img/';

            if (
                move_uploaded_file(
                    $file_tmp,
                    $target_dir . $nama_file_foto
                )
            ) {

                $foto_berubah = true;
                $foto_baru_terupload = $nama_file_foto;
            }
        }
    }

    // =========================================================
    // UPDATE DATA PRODUK
    // =========================================================

    $query_update = "UPDATE produk SET 
                        NamaProduk = '$nama_produk', 
                        Harga = '$harga', 
                        Stok = '$stok', 
                        foto = '$nama_file_foto' 
                     WHERE ProdukID = '$produk_id'";

    if (mysqli_query($koneksi, $query_update)) {

        // =====================================================
        // BUAT ID PRODUK CUSTOM
        // Contoh: PRD-00001
        // =====================================================

        $id_produk_custom = 'PRD-' . str_pad(
            $produk_id,
            5,
            '0',
            STR_PAD_LEFT
        );

        // =====================================================
        // CEK APA SAJA YANG BERUBAH
        // =====================================================

        $perubahan = [];

        // -----------------------------------------------------
        // PERUBAHAN NAMA
        // -----------------------------------------------------

        if ($nama_lama !== $nama_produk) {

            $perubahan[] =
                'Nama: ' .
                $nama_lama .
                ' → ' .
                $nama_produk;
        }

        // -----------------------------------------------------
        // PERUBAHAN HARGA
        // -----------------------------------------------------

        if ($harga_lama != $harga) {

            $harga_lama_format = 'Rp' . number_format(
                $harga_lama,
                0,
                ',',
                '.'
            );

            $harga_baru_format = 'Rp' . number_format(
                $harga,
                0,
                ',',
                '.'
            );

            $perubahan[] =
                'Harga: ' .
                $harga_lama_format .
                ' → ' .
                $harga_baru_format;
        }

        // -----------------------------------------------------
        // PERUBAHAN STOK
        // -----------------------------------------------------

        if ($stok_lama != $stok) {

            $perubahan[] =
                'Stok: ' .
                $stok_lama .
                ' → ' .
                $stok;
        }

        // -----------------------------------------------------
        // PERUBAHAN FOTO
        // -----------------------------------------------------

        if ($foto_berubah) {

            $perubahan[] = 'Foto produk diubah';
        }

        // =====================================================
        // AMBIL USERNAME YANG LOGIN
        // =====================================================

        $username_login = isset($_SESSION['Username'])
            ? $_SESSION['Username']
            : (
                isset($_SESSION['username'])
                    ? $_SESSION['username']
                    : 'System'
            );

        // =====================================================
        // SIMPAN AUDIT LOG
        // =====================================================

        if (!empty($perubahan)) {

            $deskripsi_log =
                'Mengubah data menu produk ' .
                $id_produk_custom .
                ' — ' .
                implode(', ', $perubahan);

            $deskripsi_log = mysqli_real_escape_string(
                $koneksi,
                $deskripsi_log
            );

            $username_login = mysqli_real_escape_string(
                $koneksi,
                $username_login
            );

            mysqli_query(
                $koneksi,
                "INSERT INTO audit_log
                (username, aktivitas, waktu, deskripsi)
                VALUES
                ('$username_login', 'Ubah', NOW(), '$deskripsi_log')"
            );
        }

        // =====================================================
        // HAPUS FOTO LAMA SETELAH DATABASE BERHASIL UPDATE
        // =====================================================

        if (
            $foto_berubah &&
            !empty($foto_lama) &&
            $foto_lama != 'default.jpg' &&
            file_exists('../asset/img/' . $foto_lama)
        ) {

            unlink('../asset/img/' . $foto_lama);
        }

        $berhasil_update = true;

    } else {

        // =====================================================
        // JIKA UPDATE DATABASE GAGAL,
        // HAPUS FOTO BARU AGAR TIDAK MENJADI FILE SISA
        // =====================================================

        if (
            $foto_berubah &&
            !empty($foto_baru_terupload) &&
            file_exists('../asset/img/' . $foto_baru_terupload)
        ) {

            unlink('../asset/img/' . $foto_baru_terupload);
        }

        $error_msg = addslashes(mysqli_error($koneksi));

        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal Memperbarui',
                    text: 'Gagal memperbarui menu: $error_msg',
                    confirmButtonColor: '#C49A45'
                });
            });
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Edit Menu - Daily Coffee & Toast</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"
    >

    <!-- SweetAlert2 CSS & Animate.css -->

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
    />

    <style>

        body {
            background-color: #FAF8F5;
        }

        .wrapper-konten-admin {
            margin-top: 115px;
            margin-left: 290px;
            padding-right: 35px;
            padding-bottom: 50px;
        }

        @media (max-width: 992px) {

            .wrapper-konten-admin {
                margin-left: 20px;
                margin-right: 20px;
                margin-top: 90px;
            }
        }

        .form-card {
            background: #FFFFFF;
            border-radius: 20px;
            border: 1px solid rgba(231, 229, 228, 0.9);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.03);
        }

        .form-control {
            border-radius: 12px;
            padding: 0.75rem 1rem;
            border: 1px solid #E7E5E4;
        }

        .form-control:focus {
            border-color: #C49A45;
            box-shadow: 0 0 0 4px rgba(196, 154, 69, 0.1);
        }

        @media (min-width: 768px) {

            .border-custom-end {
                border-right: 1px solid #E7E5E4;
            }
        }

        /* Styling Garis Tepi Popup agar hidup dan selaras */

        .swal2-popup {
            border: 3px solid #E2E8F0 !important;
            box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.25) !important;
        }

    </style>

</head>

<body>

<div class="wrapper-konten-admin">

    <div
        class="container-fluid"
        style="max-width: 950px;"
    >

        <!-- Header Judul Halaman -->

        <div
            class="d-flex align-items-center justify-content-between mb-4 p-3 bg-white rounded-4 shadow-sm border"
        >

            <div>

                <h4
                    class="fw-bold mb-1"
                    style="color: #141211;"
                >
                    <i class="bi bi-pencil-square text-warning me-2"></i>
                    Edit Menu Produk
                </h4>

                <p class="text-muted small mb-0">
                    Perbarui informasi sajian menu Daily Coffee & Toast.
                </p>

            </div>

            <a
                href="../kasir/produk.php"
                class="btn btn-outline-dark rounded-pill px-3 py-2 small fw-bold"
            >
                <i class="bi bi-arrow-left me-1"></i>
                Kembali
            </a>

        </div>

        <div class="form-card p-4 p-md-5">

            <form
                id="formEditProduk"
                action=""
                method="POST"
                enctype="multipart/form-data"
            >

                <input
                    type="hidden"
                    name="foto_lama"
                    value="<?= htmlspecialchars($data['foto'] ?? ''); ?>"
                >

                <!-- Layout Menyamping yang Rapih & Seimbang -->

                <div class="row align-items-center g-4">

                    <!-- Kolom Kiri: Informasi Teks -->

                    <div class="col-md-7 border-custom-end pe-md-4">

                        <div class="mb-3">

                            <label class="form-label fw-bold small text-muted">
                                NAMA MENU
                            </label>

                            <input
                                type="text"
                                name="NamaProduk"
                                id="inputNama"
                                class="form-control"
                                value="<?= htmlspecialchars($data['NamaProduk'] ?? ''); ?>"
                                required
                            >

                        </div>

                        <div class="row">

                            <div class="col-sm-6 mb-3">

                                <label class="form-label fw-bold small text-muted">
                                    HARGA (Rp)
                                </label>

                                <input
                                    type="number"
                                    name="Harga"
                                    class="form-control"
                                    value="<?= $data['Harga'] ?? 0; ?>"
                                    min="0"
                                    required
                                >

                            </div>

                            <div class="col-sm-6 mb-3">

                                <label class="form-label fw-bold small text-muted">
                                    JUMLAH STOK
                                </label>

                                <input
                                    type="number"
                                    name="Stok"
                                    class="form-control"
                                    value="<?= $data['Stok'] ?? 0; ?>"
                                    min="0"
                                    required
                                >

                            </div>

                        </div>

                    </div>

                    <!-- Kolom Kanan: Manajemen Foto Produk -->

                    <div class="col-md-5 ps-md-4 text-center text-md-start">

                        <label class="form-label fw-bold small text-muted d-block text-md-start">
                            FOTO MENU SAAT INI
                        </label>

                        <div class="mb-3 d-flex justify-content-center justify-content-md-start">

                            <?php

                            $img_path = '../asset/img/' . ($data['foto'] ?? '');

                            if (
                                empty($data['foto']) ||
                                !file_exists($img_path)
                            ) {

                                $img_path = 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=300&q=80';
                            }

                            ?>

                            <img
                                src="<?= $img_path; ?>"
                                alt="Preview"
                                class="rounded-3 border shadow-sm"
                                style="width: 110px; height: 110px; object-fit: cover;"
                            >

                        </div>

                        <div class="mb-2">

                            <label class="form-label fw-bold small text-muted d-block text-md-start">
                                GANTI FOTO BARU (Opsional)
                            </label>

                            <input
                                type="file"
                                name="foto"
                                class="form-control"
                                accept=".jpg, .jpeg, .png, .webp"
                            >

                            <div class="form-text small text-muted mt-1 text-md-start">
                                Format: JPG, JPEG, PNG, WEBP.
                            </div>

                        </div>

                    </div>

                </div>

                <!-- Tombol Aksi di Bawah -->

                <div class="row mt-4 pt-3 border-top">

                    <div class="col-12 d-flex justify-content-end gap-2">

                        <a
                            href="../kasir/produk.php"
                            class="btn btn-light px-4 py-2 rounded-3 border fw-bold text-muted"
                        >
                            Batal
                        </a>

                        <button
                            type="submit"
                            name="update_produk"
                            class="btn text-white fw-bold px-5 py-2 rounded-3 shadow-sm"
                            style="background: linear-gradient(135deg, #C49A45 0%, #A37B2C 100%); border: none;"
                        >
                            <i class="bi bi-check-circle-fill me-1"></i>
                            Simpan Perubahan
                        </button>

                    </div>

                </div>

            </form>

        </div>

    </div>

</div>

<script src="../asset/js/bootstrap.bundle.min.js"></script>

<!-- SweetAlert2 JS -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>

    // 1. Pop-up Konfirmasi Pertama
    const formEdit = document.getElementById('formEditProduk');

    if (formEdit) {

        formEdit.addEventListener('submit', function(e) {

            if (!this.dataset.submitted) {

                e.preventDefault();

                let namaMenuVal =
                    document.getElementById('inputNama').value ||
                    'Menu Ini';

                Swal.fire({

                    html: `
                        <div style="display: flex; justify-content: center; margin-bottom: 20px; margin-top: 10px;">
                            <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 20px rgba(245, 158, 11, 0.2); border: 3px solid #F59E0B;">
                                <i class="bi bi-question-lg" style="font-size: 40px; color: #D97706; font-weight: 900;"></i>
                            </div>
                        </div>

                        <h3 style="font-weight: 900; color: #1E293B; font-size: 1.4rem; margin-bottom: 10px; letter-spacing: -0.5px;">
                            Yakin Ingin Menyimpan?
                        </h3>

                        <p style="color: #64748B; font-size: 14px; margin-bottom: 25px; padding: 0 10px;">
                            Anda akan memperbarui data menu
                            <b style="color: #1E293B;">` + namaMenuVal + `</b>
                            ke dalam database sistem kasir.
                        </p>
                    `,

                    showCancelButton: true,

                    confirmButtonText: 'Ya, Simpan',

                    cancelButtonText: 'Nanti Saja',

                    background: '#FFFFFF',

                    backdrop: `rgba(15, 23, 42, 0.65) backdrop-filter blur(8px)`,

                    showClass: {
                        popup: 'animate__animated animate__zoomIn animate__faster'
                    },

                    buttonsStyling: false,

                    customClass: {
                        popup: 'rounded-5 shadow-2lg px-4 py-4',
                        actions: 'w-100 d-flex gap-3 px-3 mb-2',
                        confirmButton: 'btn flex-grow-1 py-3 rounded-pill fw-bold text-white shadow-sm',
                        cancelButton: 'btn flex-grow-1 py-3 rounded-pill fw-bold border text-secondary bg-light'
                    },

                    didOpen: () => {

                        const confirmBtn = Swal.getConfirmButton();
                        const cancelBtn = Swal.getCancelButton();

                        if (confirmBtn) {

                            confirmBtn.style.background = '#166534';
                            confirmBtn.style.border = 'none';
                        }

                        if (cancelBtn) {

                            cancelBtn.style.background = '#F1F5F9';
                            cancelBtn.style.borderColor = '#CBD5E1';
                            cancelBtn.style.color = '#475569';
                        }
                    }

                }).then((result) => {

                    if (result.isConfirmed) {

                        formEdit.dataset.submitted = 'true';

                        // Buat input tersembunyi agar terbaca oleh backend PHP

                        let hiddenInput =
                            document.createElement('input');

                        hiddenInput.type = 'hidden';
                        hiddenInput.name = 'trigger_update';
                        hiddenInput.value = '1';

                        formEdit.appendChild(hiddenInput);

                        formEdit.submit();
                    }
                });
            }
        });
    }

    // 2. Pop-up Notifikasi Kedua
    // Setelah Update Berhasil di Database

    <?php if ($berhasil_update): ?>

    document.addEventListener('DOMContentLoaded', function() {

        Swal.fire({

            html: `
                <div style="display: flex; justify-content: center; margin-bottom: 20px; margin-top: 10px;">
                    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 20px rgba(245, 158, 11, 0.2); border: 3px solid #F59E0B;">
                        <i class="bi bi-check-lg" style="font-size: 40px; color: #D97706; font-weight: 900;"></i>
                    </div>
                </div>

                <h3 style="font-weight: 900; color: #1E293B; font-size: 1.5rem; margin-bottom: 10px; letter-spacing: -0.5px;">
                    Perubahan Berhasil!
                </h3>

                <p style="color: #64748B; font-size: 14px; margin-bottom: 20px; padding: 0 10px;">
                    Anda telah mengedit dan memperbarui data menu ke dalam sistem kasir.
                </p>
            `,

            showConfirmButton: true,

            confirmButtonText: 'Keren, Lanjutkan',

            background: '#FFFFFF',

            backdrop: `rgba(15, 23, 42, 0.65) backdrop-filter blur(8px)`,

            allowOutsideClick: false,

            showClass: {
                popup: 'animate__animated animate__zoomIn animate__faster'
            },

            buttonsStyling: false,

            customClass: {
                popup: 'rounded-5 shadow-2lg px-4 py-4',
                actions: 'w-100 d-flex px-3 mb-2',
                confirmButton: 'btn flex-grow-1 py-3 rounded-pill fw-bold text-white shadow-sm'
            },

            didOpen: () => {

                const confirmBtn = Swal.getConfirmButton();

                if (confirmBtn) {

                    confirmBtn.style.background = '#166534';
                    confirmBtn.style.border = 'none';
                }
            }

        }).then(() => {

            window.location = '../kasir/produk.php';

        });

    });

    <?php endif; ?>

</script>

</body>

</html>