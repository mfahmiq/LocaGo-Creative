<?php
include '../koneksi.php';
session_start();

// Cek sesi login & hak akses
if (!isset($_SESSION['login'])) {
    header("Location: ../index.php");
    exit;
}

$notif_script = "";

// Deteksi apakah form sudah dikirimkan
if (isset($_POST['simpan']) || isset($_POST['trigger_simpan'])) {

    $nama_produk = mysqli_real_escape_string(
        $koneksi,
        $_POST['nama_produk']
    );

    $harga = mysqli_real_escape_string(
        $koneksi,
        $_POST['harga']
    );

    $stok = mysqli_real_escape_string(
        $koneksi,
        $_POST['stok']
    );

    $kategori = mysqli_real_escape_string(
        $koneksi,
        $_POST['kategori']
    );

    // Logika Upload Foto Produk
    $nama_file_foto = "";

    if (
        isset($_FILES['foto_produk']) &&
        $_FILES['foto_produk']['error'] === UPLOAD_ERR_OK
    ) {

        $file_tmp = $_FILES['foto_produk']['tmp_name'];
        $file_name = $_FILES['foto_produk']['name'];
        $file_ext = strtolower(
            pathinfo($file_name, PATHINFO_EXTENSION)
        );

        $allowed_ext = ['jpg', 'jpeg', 'png', 'webp'];

        if (in_array($file_ext, $allowed_ext)) {

            $nama_file_foto = 'prod_' . time() . '.' . $file_ext;

            $target_dir = '../asset/img/';

            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0777, true);
            }

            move_uploaded_file(
                $file_tmp,
                $target_dir . $nama_file_foto
            );
        }
    }

    // Simpan produk ke database
    $query = mysqli_query(
        $koneksi,
        "INSERT INTO produk 
        (NamaProduk, Harga, Stok, Kategori, Foto) 
        VALUES 
        ('$nama_produk', '$harga', '$stok', '$kategori', '$nama_file_foto')"
    );

    if ($query) {

        // Ambil username yang sedang login
        $user = $_SESSION['Username'] ?? 'Admin';

        // Simpan aktivitas ke audit log
        mysqli_query(
            $koneksi,
            "INSERT INTO audit_log 
            (username, aktivitas, waktu, deskripsi) 
            VALUES 
            ('$user', 'TAMBAH PRODUK', NOW(), 'Menambahkan produk baru: $nama_produk')"
        );

        // Pop-up Tahap 2: Sukses
        $notif_script = '
            Swal.fire({
                html: `
                    <div style="display: flex; justify-content: center; margin-bottom: 20px; margin-top: 10px;">
                        <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 20px rgba(245, 158, 11, 0.2); border: 3px solid #F59E0B;">
                            <i class="bi bi-check-lg" style="font-size: 40px; color: #D97706; font-weight: 900;"></i>
                        </div>
                    </div>

                    <h3 style="font-weight: 900; color: #1E293B; font-size: 1.5rem; margin-bottom: 10px; letter-spacing: -0.5px;">
                        Produk Berhasil Ditambahkan!
                    </h3>

                    <p style="color: #64748B; font-size: 14px; margin-bottom: 20px; padding: 0 10px;">
                        Menu baru <b>' . $nama_produk . '</b> telah resmi terdaftar dan disinkronkan ke sistem kasir.
                    </p>

                    <div style="background: #F8FAFC; border: 1.5px dashed #CBD5E1; border-radius: 16px; padding: 15px; margin-bottom: 10px; text-align: left;">
                        <div style="font-size: 12px; font-weight: 800; color: #64748B; text-transform: uppercase; margin-bottom: 6px;">
                            Rincian Menu:
                        </div>

                        <div style="font-size: 13px; color: #334155; margin-bottom: 4px;">
                            Kategori:
                            <span class="badge bg-warning text-dark text-uppercase">
                                ' . $kategori . '
                            </span>
                        </div>

                        <div style="font-size: 13px; color: #334155; margin-bottom: 4px;">
                            Stok Awal: <b>' . $stok . ' Pcs</b>
                        </div>

                        <div style="font-size: 13px; color: #334155;">
                            Harga:
                            <b style="color: #059669;">
                                Rp ' . number_format($harga, 0, ',', '.') . '
                            </b>
                        </div>
                    </div>
                `,

                showConfirmButton: true,
                confirmButtonText: "Keren, Lanjutkan",
                background: "#FFFFFF",
                backdrop: "rgba(15, 23, 42, 0.65)",
                allowOutsideClick: false,

                showClass: {
                    popup: "animate__animated animate__zoomIn animate__faster"
                },

                buttonsStyling: false,

                customClass: {
                    popup: "rounded-5 shadow-2lg px-4 py-4",
                    actions: "w-100 d-flex px-3 mb-2",
                    confirmButton: "btn flex-grow-1 py-3 rounded-pill fw-bold text-white shadow-sm"
                },

                didOpen: () => {

                    const confirmBtn = Swal.getConfirmButton();

                    if (confirmBtn) {
                        confirmBtn.style.background = "#166534";
                        confirmBtn.style.border = "none";
                    }
                }

            }).then((result) => {

                if (result.isConfirmed) {
                    window.location = "../kasir/produk.php";
                }

            });
        ';

    } else {

        $error_msg = mysqli_error($koneksi);

        $notif_script = '
            Swal.fire({
                icon: "error",
                title: "Gagal Menyimpan",
                text: "Kendala: ' . $error_msg . '",
                confirmButtonText: "Coba Lagi",
                background: "#FFFFFF",
                backdrop: "rgba(15, 23, 42, 0.65)",

                customClass: {
                    popup: "rounded-5 shadow-2lg border-2 border-danger px-4 py-4"
                }
            });
        ';
    }
}

include '../kasir/header.php';
?>

<!-- CDN SweetAlert2 & Animate.css -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
/>

<style>

    body {
        background-color: #FAF8F5 !important;
        font-family: 'Plus Jakarta Sans', sans-serif !important;
        color: #1E293B;
    }

    .app-container {
        margin-top: 105px;
        margin-left: 290px;
        padding: 0 35px 50px 0;
    }

    @media (max-width: 992px) {

        .app-container {
            margin-left: 20px;
            margin-right: 20px;
            padding-right: 0;
        }

    }

    .header-banner-custom {
        background: #FFFFFF;
        border: 1px solid #E5E0D8;
        border-radius: 20px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.03);
        padding: 1.75rem 2rem;
    }

    .card-custom-light {
        background: #FFFFFF;
        border: 1px solid #E5E0D8;
        border-radius: 20px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.03);
        overflow: hidden;
    }

    .form-control-custom-light {
        background: #F8FAFC;
        border: 2px solid #E2E8F0;
        color: #1E293B !important;
        border-radius: 14px;
        padding: 0.85rem 1.15rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .form-control-custom-light:focus {
        background: #FFFFFF;
        border-color: #C49A45;
        box-shadow: 0 0 0 4px rgba(196, 154, 69, 0.15);
    }

    .btn-gold-custom {
        background: linear-gradient(135deg, #C49A45 0%, #A37B2C 100%);
        color: #FFFFFF;
        font-weight: 700;
        border-radius: 14px;
        border: none;
        padding: 0.85rem 2rem;
        box-shadow: 0 8px 20px rgba(196, 154, 69, 0.3);
        transition: all 0.3s ease;
    }

    .btn-gold-custom:hover {
        background: linear-gradient(135deg, #D4A955, #B3863C);
        transform: translateY(-2px);
        box-shadow: 0 12px 25px rgba(196, 154, 69, 0.4);
        color: #FFFFFF;
    }

    /* Kustomisasi Garis Tepi Kotak Pop-up */
    .swal2-popup {
        border: 3px solid #E2E8F0 !important;
        box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.25) !important;
    }

</style>

<div class="app-container">

    <div class="header-banner-custom mb-4 d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3">

        <div>

            <div class="d-flex align-items-center gap-2 mb-1 flex-wrap">

                <h3
                    class="fw-extrabold mb-0"
                    style="color: #141211; letter-spacing: -0.5px;"
                >
                    Tambah Produk Baru
                </h3>

                <span
                    class="badge px-2.5 py-1 rounded-pill fw-bold"
                    style="background: rgba(196, 154, 69, 0.15); color: #C49A45; border: 1px solid rgba(196, 154, 69, 0.3); font-size: 0.75rem;"
                >
                    <i class="bi bi-plus-circle me-1"></i>
                    MANAJEMEN STOK
                </span>

            </div>

            <p class="text-muted small mb-0">
                Input menu dan rincian produk baru ke dalam sistem kasir.
            </p>

        </div>

        <div>

            <a
                href="../kasir/produk.php"
                class="btn btn-outline-secondary rounded-pill px-4 py-2 fw-bold text-decoration-none d-flex align-items-center gap-2"
            >
                <i class="bi bi-arrow-left"></i>
                Kembali
            </a>

        </div>

    </div>


    <div class="row justify-content-center">

        <div class="col-lg-9">

            <div class="card card-custom-light p-4 p-md-5">

                <form
                    method="POST"
                    enctype="multipart/form-data"
                    id="formProduk"
                >

                    <div class="mb-4">

                        <label class="form-label small text-uppercase fw-bold text-muted">
                            Nama Produk
                        </label>

                        <input
                            type="text"
                            name="nama_produk"
                            id="inputNama"
                            class="form-control form-control-custom-light"
                            placeholder="Contoh: Caramel Macchiato / Toast Choco Cheese"
                            required
                        >

                    </div>


                    <div class="row mb-4">

                        <div class="col-md-6 mb-3 mb-md-0">

                            <label class="form-label small text-uppercase fw-bold text-muted">
                                Harga (Rp)
                            </label>

                            <div class="input-group">

                                <span class="input-group-text bg-light fw-bold border-2 text-dark">
                                    Rp
                                </span>

                                <input
                                    type="number"
                                    name="harga"
                                    class="form-control form-control-custom-light"
                                    placeholder="Contoh: 25000"
                                    required
                                >

                            </div>

                        </div>


                        <div class="col-md-6">

                            <label class="form-label small text-uppercase fw-bold text-muted">
                                Stok Awal
                            </label>

                            <input
                                type="number"
                                name="stok"
                                class="form-control form-control-custom-light"
                                placeholder="Contoh: 50"
                                required
                            >

                        </div>

                    </div>


                    <div class="row mb-4">

                        <div class="col-md-6 mb-3 mb-md-0">

                            <label class="form-label small text-uppercase fw-bold text-muted">
                                Kategori
                            </label>

                            <select
                                name="kategori"
                                class="form-select form-control-custom-light"
                                required
                            >

                                <option value="" disabled selected>
                                    Pilih Kategori...
                                </option>

                                <option value="makanan">
                                    Makanan
                                </option>

                                <option value="minuman">
                                    Minuman
                                </option>

                            </select>

                        </div>


                        <div class="col-md-6">

                            <label class="form-label small text-uppercase fw-bold text-muted">
                                Foto Produk (Opsional)
                            </label>

                            <input
                                type="file"
                                name="foto_produk"
                                class="form-control form-control-custom-light"
                                accept=".jpg, .jpeg, .png, .webp"
                            >

                            <div
                                class="form-text text-muted"
                                style="font-size: 11px;"
                            >
                                Format yang didukung: JPG, JPEG, PNG, WEBP.
                            </div>

                        </div>

                    </div>


                    <div class="pt-3 border-top mt-4">

                        <button
                            type="submit"
                            name="simpan"
                            class="btn btn-gold-custom w-100 py-3"
                        >

                            <i class="bi bi-save me-1 fs-5 align-middle"></i>
                            Simpan Produk Baru

                        </button>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>


<!-- Script Pop-up Dua Tahap dengan Pemicu Input Tersembunyi -->
<script>

    document.getElementById('formProduk').addEventListener('submit', function(e) {

        if (this.dataset.submitted) {
            return;
        }

        e.preventDefault();

        let namaProdukVal =
            document.getElementById('inputNama').value ||
            'Produk Ini';


        // Pop-up Tahap 1: Konfirmasi
        Swal.fire({

            html: `

                <div style="display: flex; justify-content: center; margin-bottom: 20px; margin-top: 10px;">

                    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 20px rgba(245, 158, 11, 0.2); border: 3px solid #F59E0B;">

                        <i
                            class="bi bi-question-lg"
                            style="font-size: 40px; color: #D97706; font-weight: 900;"
                        ></i>

                    </div>

                </div>


                <h3
                    style="font-weight: 900; color: #1E293B; font-size: 1.4rem; margin-bottom: 10px; letter-spacing: -0.5px;"
                >
                    Yakin Ingin Menyimpan?
                </h3>


                <p
                    style="color: #64748B; font-size: 14px; margin-bottom: 25px; padding: 0 10px;"
                >
                    Anda akan mendaftarkan produk
                    <b style="color: #1E293B;">${namaProdukVal}</b>
                    ke dalam database sistem kasir.
                </p>

            `,

            showCancelButton: true,

            confirmButtonText: 'Ya, Simpan',

            cancelButtonText: 'Nanti Saja',

            background: '#FFFFFF',

            backdrop: 'rgba(15, 23, 42, 0.65)',

            showClass: {
                popup: 'animate__animated animate__zoomIn animate__faster'
            },

            buttonsStyling: false,

            customClass: {

                popup: 'rounded-5 shadow-2lg px-4 py-4',

                actions: 'w-100 d-flex gap-3 px-3 mb-2',

                confirmButton:
                    'btn flex-grow-1 py-3 rounded-pill fw-bold text-white shadow-sm',

                cancelButton:
                    'btn flex-grow-1 py-3 rounded-pill fw-bold border text-secondary bg-light'

            },

            didOpen: () => {

                const confirmBtn =
                    Swal.getConfirmButton();

                const cancelBtn =
                    Swal.getCancelButton();


                if (confirmBtn) {

                    confirmBtn.style.background =
                        '#166534';

                    confirmBtn.style.border =
                        'none';

                }


                if (cancelBtn) {

                    cancelBtn.style.background =
                        '#F1F5F9';

                    cancelBtn.style.borderColor =
                        '#CBD5E1';

                    cancelBtn.style.color =
                        '#475569';

                }

            }

        }).then((result) => {

            if (result.isConfirmed) {

                this.dataset.submitted = 'true';

                // Tambahkan input tersembunyi agar terdeteksi PHP
                let hiddenInput =
                    document.createElement('input');

                hiddenInput.type = 'hidden';

                hiddenInput.name = 'trigger_simpan';

                hiddenInput.value = '1';

                this.appendChild(hiddenInput);

                this.submit();

            }

        });

    });


    // Eksekusi Pop-up Tahap 2 (Sukses)
    <?php
    if (!empty($notif_script)) {
        echo $notif_script;
    }
    ?>

</script>

<script src="../asset/js/bootstrap.bundle.min.js"></script>

</body>
</html>