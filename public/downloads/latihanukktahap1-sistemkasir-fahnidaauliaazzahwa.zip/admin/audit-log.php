<?php
include '../koneksi.php';
include 'header.php';

date_default_timezone_set('Asia/Jakarta');

$query_total = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM audit_log");
$total_all = mysqli_fetch_assoc($query_total)['total'];

$query_today = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM audit_log WHERE DATE(waktu) = CURDATE()");
$total_today = mysqli_fetch_assoc($query_today)['total'];

$query_users = mysqli_query($koneksi, "SELECT COUNT(DISTINCT username) AS total FROM audit_log");
$total_active_users = mysqli_fetch_assoc($query_users)['total'];

$query_login = mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM audit_log WHERE LOWER(aktivitas) = 'login'");
$total_login = mysqli_fetch_assoc($query_login)['total'];

$logs = mysqli_query($koneksi, "SELECT a.*, u.NamaUser, u.Role FROM audit_log a LEFT JOIN user u ON a.username = u.Username ORDER BY a.waktu DESC");
?>

<style>
body {
    background: #F4F6F9 !important;
    color: #333333 !important;
}

.card-header-banner {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.04);
    color: #1E293B;
    padding: 1.75rem 2rem;
}

.page-title {
    color: #1E293B;
    font-weight: 800;
    letter-spacing: -0.5px;
    font-size: 1.75rem;
}

.page-subtitle {
    color: #64748B;
    font-size: 0.9rem;
}

.badge-banner-status {
    background: rgba(234, 179, 8, 0.15);
    color: #B45309;
    border: 1px solid rgba(234, 179, 8, 0.3);
    font-weight: 700;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
    padding: 0.3rem 0.8rem;
    border-radius: 50rem;
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    margin-bottom: 0.5rem;
}

.audit-time-box {
    background: #FFFFFF;
    padding: 0.6rem 0.9rem;
    border-radius: 10px;
    border: 1px solid #E2E8F0;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.02);
}

.card-light-custom {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
    color: #1E293B;
    overflow: hidden;
}

.search-box-custom {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    color: #1E293B;
    border-radius: 10px;
    padding: 0.6rem 1rem;
    font-size: 0.9rem;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.02);
}

.search-box-custom:focus {
    background: #FFFFFF;
    border-color: #C49A45;
    box-shadow: 0 0 10px rgba(196, 154, 69, 0.15);
}

/* --- TOMBOL FILTER AKTIVITAS --- */
.filter-btn-custom {
    font-weight: 600;
    border-radius: 12px;
    padding: 0.55rem 0.95rem;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.04);
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 0.8rem;
    border: 1px solid #E7E5E4;
    background: #FAF8F5;
    color: #2D2621;
    cursor: pointer;
    text-decoration: none;
}

.filter-btn-custom:hover, 
.filter-btn-custom.active {
    background: #C49A45;
    color: #FFFFFF;
    border-color: #C49A45;
    box-shadow: 0 6px 15px rgba(196, 154, 69, 0.25);
}

.table-vibrant {
    border-collapse: separate;
    border-spacing: 0;
    width: 100%;
}

.table-vibrant th {
    background: #182232 !important;
    color: #FFFFFF !important;
    font-weight: 700;
    text-transform: uppercase;
    font-size: 0.8rem;
    letter-spacing: 0.8px;
    padding: 1.25rem 1.5rem !important;
    border: none;
    position: relative;
}

.table-vibrant th::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #D97706, #F59E0B);
}

.table-vibrant td {
    background-color: #FFFFFF !important;
    border-bottom: 1px solid #F1F5F9 !important;
    vertical-align: middle;
    color: #1E293B !important;
    padding: 1.25rem 1.5rem !important;
    font-size: 0.9rem;
}

.table-vibrant tbody tr {
    transition: all 0.2s ease;
}

.table-vibrant tbody tr:hover td {
    background-color: #FAF8F5 !important;
}

.time-icon-box {
    width: 38px;
    height: 38px;
    background: #FFFBEB;
    border: 1px solid #FDE68A;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #D97706;
    font-size: 1.1rem;
    flex-shrink: 0;
}

.user-name {
    font-size: 0.9rem;
    font-weight: 700;
    color: #1E293B;
}

/* --- BADGE ROLE --- */
.badge-role {
    font-size: 0.75rem;
    font-weight: 700;
    padding: 0.3rem 0.7rem;
    border-radius: 50rem;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    margin-top: 4px;
    letter-spacing: 0.3px;
}

.badge-role-admin {
    background-color: #FEE2E2; 
    color: #DC2626;         
    border: 1px solid #FECACA;
}

.badge-role-kasir {
    background-color: #FEF3C7; 
    color: #D97706;         
    border: 1px solid #FDE68A;
}

/* Tambahan Style untuk Role Pelanggan / Member */
.badge-role-pelanggan {
    background-color: #E0F2FE; 
    color: #0284C7;         
    border: 1px solid #BAE6FD;
}

.action-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 0.38rem 0.65rem;
    border-radius: 7px;
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 0.2px;
    white-space: nowrap;
}

.action-badge i {
    font-size: 0.85rem;
    line-height: 1;
}

.description-text {
    color: #64748B;
    font-size: 0.85rem;
    line-height: 1.5;
}

@media (max-width: 768px) {
    .card-header-banner {
        padding: 1.5rem;
    }

    .page-title {
        font-size: 1.5rem;
    }

    .table-vibrant th,
    .table-vibrant td {
        padding: 1rem !important;
    }
}
</style>

<div class="container-fluid px-0">
    <div class="card card-header-banner p-4 mb-4">
        <div class="row align-items-center gy-3">
            <div class="col-lg-7">
                <div class="badge-banner-status">
                    <i class="bi bi-shield-fill-exclamation text-warning"></i>
                    SECURITY AUDIT ACTIVE
                </div>
                <h2 class="page-title mb-1">Aktivitas Sistem &amp; Keamanan</h2>
                <p class="page-subtitle mb-0">
                    Riwayat seluruh aktivitas pengguna dan perubahan
                    data di dalam sistem secara berkala.
                </p>
            </div>
            <div class="col-lg-5 text-lg-end">
                <div class="d-inline-flex align-items-center gap-2 audit-time-box">
                    <i class="bi bi-clock-history text-warning fs-5"></i>
                    <div class="text-start">
                        <span class="text-muted d-block" style="font-size: 11px; line-height: 1;">
                            Waktu Akses Sistem
                        </span>
                        <span id="realtime-clock" class="fw-bold text-dark" style="font-size: 13px;">
                            Memuat waktu...
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-4 align-items-center gy-3">
        <div class="col-xl-3 col-md-6">
            <div class="card card-light-custom px-3 py-3 border-dark border-2 d-flex flex-row align-items-center gap-3 h-100">
                <div class="rounded-circle bg-dark bg-opacity-10 p-2 text-dark d-flex align-items-center justify-content-center flex-shrink-0" style="width: 45px; height: 45px;">
                    <i class="bi bi-journal-text fs-5"></i>
                </div>
                <div>
                    <span class="text-muted d-block" style="font-size: 10px; font-weight: 700; text-transform: uppercase;">
                        Total Rekaman
                    </span>
                    <h6 class="text-dark fw-bold mb-0" style="font-size: 15px;">
                        <?= number_format($total_all, 0, ',', '.'); ?>
                        <span class="fw-normal text-muted" style="font-size: 12px;">Aktivitas</span>
                    </h6>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card card-light-custom px-3 py-3 border-success border-2 d-flex flex-row align-items-center gap-3 h-100">
                <div class="rounded-circle bg-success bg-opacity-10 p-2 text-success d-flex align-items-center justify-content-center flex-shrink-0" style="width: 45px; height: 45px;">
                    <i class="bi bi-calendar-check fs-5"></i>
                </div>
                <div>
                    <span class="text-muted d-block" style="font-size: 10px; font-weight: 700; text-transform: uppercase;">
                        Aktivitas Hari Ini
                    </span>
                    <h6 class="text-dark fw-bold mb-0" style="font-size: 15px;">
                        <?= number_format($total_today, 0, ',', '.'); ?>
                        <span class="fw-normal text-muted" style="font-size: 12px;">Aktivitas</span>
                    </h6>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card card-light-custom px-3 py-3 border-primary border-2 d-flex flex-row align-items-center gap-3 h-100">
                <div class="rounded-circle bg-primary bg-opacity-10 p-2 text-primary d-flex align-items-center justify-content-center flex-shrink-0" style="width: 45px; height: 45px;">
                    <i class="bi bi-people fs-5"></i>
                </div>
                <div>
                    <span class="text-muted d-block" style="font-size: 10px; font-weight: 700; text-transform: uppercase;">
                        Pengguna Terlibat
                    </span>
                    <h6 class="text-dark fw-bold mb-0" style="font-size: 15px;">
                        <?= number_format($total_active_users, 0, ',', '.'); ?>
                        <span class="fw-normal text-muted" style="font-size: 12px;">User</span>
                    </h6>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card card-light-custom px-3 py-3 border-warning border-2 d-flex flex-row align-items-center gap-3 h-100">
                <div class="rounded-circle bg-warning bg-opacity-10 p-2 text-warning d-flex align-items-center justify-content-center flex-shrink-0" style="width: 45px; height: 45px;">
                    <i class="bi bi-box-arrow-in-right fs-5"></i>
                </div>
                <div>
                    <span class="text-muted d-block" style="font-size: 10px; font-weight: 700; text-transform: uppercase;">
                        Total Login
                    </span>
                    <h6 class="text-dark fw-bold mb-0" style="font-size: 15px;">
                        <?= number_format($total_login, 0, ',', '.'); ?>
                        <span class="fw-normal text-muted" style="font-size: 12px;">Sesi</span>
                    </h6>
                </div>
            </div>
        </div>
    </div>

    <div class="card card-light-custom p-4 mb-4">
        <div class="row gy-3 align-items-center">
            <div class="col-lg-4">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0 text-muted" style="border-radius: 10px 0 0 10px; border-color: #E2E8F0;">
                        <i class="bi bi-search"></i>
                    </span>
                    <input type="text" id="cariLog" class="form-control search-box-custom border-start-0" placeholder="Cari aktivitas atau nama pengguna..." style="border-radius: 0 10px 10px 0;">
                </div>
            </div>
            <div class="col-lg-8">
                <div class="d-flex flex-wrap justify-content-lg-end gap-2 align-items-center">
                    <span class="text-muted small me-1 fw-bold">Filter:</span>
                    <button type="button" class="filter-btn-custom active" onclick="filterAksi('today', this)">
                        <i class="bi bi-calendar-day"></i>Today
                    </button>
                    <button type="button" class="filter-btn-custom" onclick="filterAksi('login', this)">
                        <i class="bi bi-box-arrow-in-right"></i>Login
                    </button>
                    <button type="button" class="filter-btn-custom" onclick="filterAksi('logout', this)">
                        <i class="bi bi-box-arrow-right"></i>Logout
                    </button>
                    <button type="button" class="filter-btn-custom" onclick="filterAksi('tambah', this)">
                        <i class="bi bi-plus-circle"></i>Tambah
                    </button>
                    <button type="button" class="filter-btn-custom" onclick="filterAksi('ubah', this)">
                        <i class="bi bi-pencil-square"></i>Ubah
                    </button>
                    <button type="button" class="filter-btn-custom" onclick="filterAksi('selesai', this)">
                        <i class="bi bi-check-circle"></i>Selesai
                    </button>
                    <button type="button" class="filter-btn-custom" onclick="filterAksi('batal', this)">
                        <i class="bi bi-x-circle"></i>Batal
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="card card-light-custom shadow-sm mb-4">
        <div class="table-responsive">
            <table class="table table-vibrant align-middle mb-0" id="tabelLog">
                <thead>
                    <tr>
                        <th style="width: 22%;">Waktu &amp; Tanggal</th>
                        <th style="width: 18%;">Nama Pengguna</th>
                        <th style="width: 15%;">Aksi</th>
                        <th style="width: 45%;">Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($logs) > 0): ?>
                        <?php while ($log = mysqli_fetch_assoc($logs)): ?>
                            <?php
                            $nama_user = !empty($log['NamaUser']) ? $log['NamaUser'] : $log['username'];
                            
                            // Jika Role kosong di database, anggap sebagai 'Pelanggan' atau sesuaikan identifier-nya
                            $role_user = !empty($log['Role']) ? ucfirst(strtolower(trim($log['Role']))) : 'Pelanggan';
                            
                            $role_lower = strtolower(trim($role_user));
                            if ($role_lower === 'admin') {
                                $role_class = 'badge-role-admin';
                            } elseif ($role_lower === 'kasir') {
                                $role_class = 'badge-role-kasir';
                            } else {
                                $role_class = 'badge-role-pelanggan';
                            }

                            $aksi_lower = strtolower(trim($log['aktivitas']));

                            if (str_contains($aksi_lower, 'login')) {
                                $aktivitas_teks = 'LOGIN';
                            } elseif (str_contains($aksi_lower, 'logout')) {
                                $aktivitas_teks = 'LOGOUT';
                            } elseif (str_contains($aksi_lower, 'tambah') || str_contains($aksi_lower, 'buat')) {
                                $aktivitas_teks = 'TAMBAH';
                            } elseif (str_contains($aksi_lower, 'ubah') || str_contains($aksi_lower, 'edit') || str_contains($aksi_lower, 'pembenaran')) {
                                $aktivitas_teks = 'UBAH';
                            } elseif (str_contains($aksi_lower, 'selesai')) {
                                $aktivitas_teks = 'SELESAI';
                            } elseif (str_contains($aksi_lower, 'batal') || str_contains($aksi_lower, 'hapus')) {
                                $aktivitas_teks = 'BATAL';
                            } else {
                                $aktivitas_teks = strtoupper($log['aktivitas']);
                            }

                            $formatted_date = date('d M Y', strtotime($log['waktu']));
                            $formatted_time = date('H:i:s', strtotime($log['waktu'])) . ' WIB';

                            $badge_bg = '#FEF3C7';
                            $badge_color = '#B45309';
                            $badge_border = '#FDE68A';

                            if ($aktivitas_teks === 'LOGIN') {
                                $badge_bg = '#DBEAFE';
                                $badge_color = '#1D4ED8';
                                $badge_border = '#93C5FD';
                            } elseif ($aktivitas_teks === 'LOGOUT') {
                                $badge_bg = '#FFEDD5';
                                $badge_color = '#C2410C';
                                $badge_border = '#FDBA74';
                            } elseif ($aktivitas_teks === 'TAMBAH') {
                                $badge_bg = '#DCFCE7';
                                $badge_color = '#15803D';
                                $badge_border = '#86EFAC';
                            } elseif ($aktivitas_teks === 'UBAH') {
                                $badge_bg = '#F3E8FF';
                                $badge_color = '#7E22CE';
                                $badge_border = '#D8B4FE';
                            } elseif ($aktivitas_teks === 'SELESAI') {
                                $badge_bg = '#CCFBF1';
                                $badge_color = '#0F766E';
                                $badge_border = '#99F6E4';
                            } elseif ($aktivitas_teks === 'BATAL') {
                                $badge_bg = '#FEE2E2';
                                $badge_color = '#B91C1C';
                                $badge_border = '#FCA5A5';
                            }

                            $format_tgl_log = date('Ymd', strtotime($log['waktu']));
                            $deskripsi_formatted = preg_replace_callback(
                                '/#(\d+)/',
                                function ($matches) use ($format_tgl_log) {
                                    return 'TRX-' . $format_tgl_log . '-' . str_pad($matches[1], 4, '0', STR_PAD_LEFT);
                                },
                                $log['deskripsi']
                            );
                            ?>

                            <tr data-aksi="<?= htmlspecialchars($aksi_lower); ?>" data-tanggal="<?= date('Y-m-d', strtotime($log['waktu'])); ?>">
                                <td>
                                    <div class="d-flex align-items-center gap-3">
                                        <div class="time-icon-box">
                                            <i class="bi bi-calendar3"></i>
                                        </div>
                                        <div>
                                            <div class="fw-bold text-dark" style="font-size: 0.9rem;">
                                                <?= htmlspecialchars($formatted_date); ?>
                                            </div>
                                            <div class="text-muted" style="font-size: 0.8rem;">
                                                <?= htmlspecialchars($formatted_time); ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="user-name">
                                        <?= htmlspecialchars($nama_user); ?>
                                    </div>
                                    <span class="badge-role <?= $role_class; ?>">
                                        <?php if ($role_lower === 'admin'): ?>
                                            <i class="bi bi-shield-fill-check"></i>
                                        <?php elseif ($role_lower === 'kasir'): ?>
                                            <i class="bi bi-person-badge"></i>
                                        <?php else: ?>
                                            <i class="bi bi-person-heart"></i>
                                        <?php endif; ?>
                                        <?= htmlspecialchars($role_user); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="action-badge" style="background: <?= $badge_bg; ?>; color: <?= $badge_color; ?>; border: 1px solid <?= $badge_border; ?>;">
                                        <?php if ($aktivitas_teks === 'LOGIN'): ?>
                                            <i class="bi bi-box-arrow-in-right"></i>
                                        <?php elseif ($aktivitas_teks === 'LOGOUT'): ?>
                                            <i class="bi bi-box-arrow-right"></i>
                                        <?php elseif ($aktivitas_teks === 'TAMBAH'): ?>
                                            <i class="bi bi-plus-circle"></i>
                                        <?php elseif ($aktivitas_teks === 'UBAH'): ?>
                                            <i class="bi bi-pencil-square"></i>
                                        <?php elseif ($aktivitas_teks === 'SELESAI'): ?>
                                            <i class="bi bi-check-circle"></i>
                                        <?php elseif ($aktivitas_teks === 'BATAL'): ?>
                                            <i class="bi bi-x-circle"></i>
                                        <?php else: ?>
                                            <i class="bi bi-activity"></i>
                                        <?php endif; ?>
                                        <?= htmlspecialchars($aktivitas_teks); ?>
                                    </span>
                                </td>
                                <td class="description-text">
                                    <?= htmlspecialchars($deskripsi_formatted); ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr class="empty-log-row">
                            <td colspan="4" class="text-center text-muted py-5">
                                <i class="bi bi-shield-check fs-2 d-block mb-2 text-warning opacity-50"></i>
                                Belum ada catatan aktivitas sistem yang tercatat.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
let filterAktif = 'today';

function getTodayWIB() {
    return new Intl.DateTimeFormat('en-CA', {
        timeZone: 'Asia/Jakarta',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    }).format(new Date());
}

document.getElementById('cariLog').addEventListener('input', tampilkanData);

function filterAksi(kategori, button) {
    filterAktif = kategori;
    document.querySelectorAll('.filter-btn-custom').forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    tampilkanData();
}

function tampilkanData() {
    const keyword = document.getElementById('cariLog').value.toLowerCase().trim();
    const rows = document.querySelectorAll('#tabelLog tbody tr');
    const today = getTodayWIB();

    rows.forEach(row => {
        if (row.classList.contains('empty-log-row')) {
            row.style.display = '';
            return;
        }

        const aksiData = (row.getAttribute('data-aksi') || '').toLowerCase();
        const tanggalData = row.getAttribute('data-tanggal') || '';
        const text = row.textContent.toLowerCase();

        let cocokFilter = false;

        if (filterAktif === 'today') {
            cocokFilter = tanggalData === today;
        } else if (filterAktif === 'login') {
            cocokFilter = aksiData.includes('login');
        } else if (filterAktif === 'logout') {
            cocokFilter = aksiData.includes('logout');
        } else if (filterAktif === 'tambah') {
            cocokFilter = aksiData.includes('tambah') || aksiData.includes('buat');
        } else if (filterAktif === 'ubah') {
            cocokFilter = aksiData.includes('ubah') || aksiData.includes('edit') || aksiData.includes('pembenaran');
        } else if (filterAktif === 'selesai') {
            cocokFilter = aksiData.includes('selesai');
        } else if (filterAktif === 'batal') {
            cocokFilter = aksiData.includes('batal') || aksiData.includes('hapus');
        }

        const cocokSearch = keyword === '' || text.includes(keyword);
        row.style.display = cocokFilter && cocokSearch ? '' : 'none';
    });
}

function updateClock() {
    const now = new Date();
    const dateStr = now.toLocaleDateString('id-ID', {
        timeZone: 'Asia/Jakarta',
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    });

    const timeStr = now.toLocaleTimeString('id-ID', {
        timeZone: 'Asia/Jakarta',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    }).replace(/\./g, ':');

    const clockElem = document.getElementById('realtime-clock');

    if (clockElem) {
        clockElem.innerText = `${dateStr}, ${timeStr} WIB`;
    }
}

updateClock();
setInterval(updateClock, 1000);
document.addEventListener('DOMContentLoaded', tampilkanData);
</script>

</body>
</html>