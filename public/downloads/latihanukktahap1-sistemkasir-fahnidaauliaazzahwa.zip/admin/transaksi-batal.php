<?php
include '../koneksi.php';
session_start();

if (!isset($_SESSION['login']) || $_SESSION['Role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$username_admin = $_SESSION['Username'] ?? 'Admin Kedai';

// Ambil data transaksi berdasarkan ID
$query = mysqli_query($koneksi, "SELECT * FROM penjualan WHERE PenjualanID = '$id'");
$data = mysqli_fetch_assoc($query);

if (!$data) {
    echo "<script>alert('Data transaksi tidak ditemukan!'); window.location='transaksi.php';</script>";
    exit;
}

// Cek apakah transaksi sudah dibatalkan sebelumnya
if (isset($data['status']) && $data['status'] === 'Dibatalkan') {
    echo "<script>alert('Transaksi ini sudah pernah dibatalkan sebelumnya!'); window.location='transaksi.php';</script>";
    exit;
}

// Mulai transaksi database untuk keamanan data (ACID)
mysqli_begin_transaction($koneksi);

try {
    // 1. Ubah status penjualan menjadi 'Dibatalkan'
    $update_status = mysqli_query($koneksi, "UPDATE penjualan SET status = 'Dibatalkan' WHERE PenjualanID = '$id'");
    if (!$update_status) {
        throw new Exception("Gagal memperbarui status transaksi: " . mysqli_error($koneksi));
    }

    // 2. Ambil detail produk yang dibeli untuk dikembalikan stoknya
    $query_detail = mysqli_query($koneksi, "SELECT * FROM detailpenjualan WHERE PenjualanID = '$id'");
    while ($detail = mysqli_fetch_assoc($query_detail)) {
        $produk_id = (int)$detail['ProdukID'];
        $jumlah = (int)$detail['JumlahProduk'];

        // Kembalikan stok produk
        $update_stok = mysqli_query($koneksi, "UPDATE produk SET Stok = Stok + $jumlah WHERE ProdukID = '$produk_id'");
        if (!$update_stok) {
            throw new Exception("Gagal mengembalikan stok produk ID $produk_id");
        }
    }

    // 3. Catat ke Audit Log otomatis
    $aktivitas = "BATALKAN TRANSAKSI";
    $deskripsi = "Admin ($username_admin) membatalkan Transaksi #$id (Status diubah menjadi Dibatalkan & stok dikembalikan).";
    mysqli_query($koneksi, "INSERT INTO audit_log (username, aktivitas, waktu, deskripsi) VALUES ('$username_admin', '$aktivitas', NOW(), '$deskripsi')");

    // Commit perubahan jika semua sukses
    mysqli_commit($koneksi);

    echo "<script>alert('Transaksi #$id berhasil dibatalkan dan stok dikembalikan!'); window.location='transaksi.php';</script>";
    exit;

} catch (Exception $e) {
    // Batalkan jika ada error
    mysqli_rollback($koneksi);
    $error_msg = addslashes($e->getMessage());
    echo "<script>alert('Terjadi kesalahan: $error_msg'); window.location='transaksi.php';</script>";
    exit;
}
?>