<?php
// ==========================================================
// SESSION & KONEKSI
// ==========================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../koneksi.php';

// ==========================================================
// CEK LOGIN & HAK AKSES (KHUSUS ADMIN)
// ==========================================================

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: ../index.php?pesan=belum_login");
    exit;
}

$role = strtolower(trim($_SESSION['Role'] ?? ''));

if ($role !== 'admin') {
    header("Location: ../index.php?pesan=akses_ditolak");
    exit;
}

// ==========================================================
// HEADER
// ==========================================================

include 'header.php';

// Set zona waktu WIB
date_default_timezone_set('Asia/Jakarta');

// ==========================================================
// PAGINASI
// ==========================================================

$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

if ($page < 1) {
    $page = 1;
}

$offset = ($page - 1) * $limit;

// ==========================================================
// PENCARIAN & FILTER BERDASARKAN ROLE
// ==========================================================

$cari = isset($_GET['cari'])
    ? mysqli_real_escape_string($koneksi, trim($_GET['cari']))
    : '';

$filter_role = isset($_GET['role'])
    ? mysqli_real_escape_string($koneksi, trim($_GET['role']))
    : '';

$where_sql = "WHERE 1=1";

if (!empty($cari)) {
    $where_sql .= " AND (NamaUser LIKE '%$cari%' OR Username LIKE '%$cari%')";
}

if (!empty($filter_role)) {
    $where_sql .= " AND Role = '$filter_role'";
}

// ==========================================================
// HITUNG TOTAL DATA USER
// ==========================================================

$query_count = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total FROM user $where_sql"
);

$data_count = mysqli_fetch_assoc($query_count);
$total_data = $data_count['total'];
$total_pages = ceil($total_data / $limit);

// ==========================================================
// QUERY UTAMA DATA USER
// ==========================================================

$query = mysqli_query(
    $koneksi,
    "SELECT * FROM user
     $where_sql
     ORDER BY UserID DESC
     LIMIT $limit OFFSET $offset"
);

?>

<!-- ==========================================================
     CSS STYLING
========================================================== -->

<style>
body {
    background: #F4F6F9 !important;
    color: #333333 !important;
}

/* ==========================================================
   HEADER BANNER
========================================================== */

.header-banner-custom {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.04);
    padding: 1.75rem 2rem;
}

.time-badge-box {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 12px;
    padding: 0.6rem 1rem;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.02);
}

.card-light-custom {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
    color: #1E293B;
    overflow: hidden;
}

/* ==========================================================
   FILTER PILL
========================================================== */

.btn-filter-pill {
    border-radius: 50rem;
    font-size: 0.8rem;
    font-weight: 600;
    padding: 0.45rem 1.1rem;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    transition: all 0.2s ease-in-out;
    text-decoration: none;
    border: 1.5px solid #cbd5e1;
    background: #ffffff;
    color: #475569;
}

.btn-filter-pill:hover {
    border-color: #94a3b8;
    background: #f8fafc;
    color: #1e293b;
    transform: translateY(-1px);
}

.btn-filter-pill.active-filter {
    background-color: #161e29 !important;
    border-color: #161e29 !important;
    color: #ffffff !important;
    box-shadow: 0 4px 12px rgba(15, 23, 42, 0.2);
}

.btn-filter-pill.active-filter i {
    color: #f59e0b !important;
}

/* ==========================================================
   TABEL
========================================================== */

.table-custom-v2 {
    border-collapse: separate;
    border-spacing: 0;
    width: 100%;
}

.table-custom-v2 thead th {
    background: #182232 !important;
    color: #FFFFFF !important;
    font-weight: 700;
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    padding: 1.25rem 1.5rem !important;
    border: none;
    position: relative;
}

.table-custom-v2 thead th::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #D97706, #F59E0B);
}

.table-custom-v2 td {
    background-color: #FFFFFF !important;
    border-bottom: 1px solid #F1F5F9 !important;
    vertical-align: middle;
    color: #1E293B !important;
    padding: 1.25rem 1.5rem !important;
    font-size: 0.9rem;
}

.table-custom-v2 tbody tr {
    transition: all 0.2s ease;
}

.table-custom-v2 tbody tr:hover {
    background-color: #FAF8F5 !important;
}

/* ==========================================================
   BADGE FORMAT ID USER
   STYLE SAMA SEPERTI ID MEMBER
========================================================== */

.badge-user-id {
    background: rgba(196, 154, 69, 0.12);
    color: #C49A45;
    border: 1px solid rgba(196, 154, 69, 0.3);
    font-weight: 800;
    font-size: 0.8rem;
    padding: 6px 12px;
    border-radius: 10px;
    letter-spacing: 0.5px;
    display: inline-flex;
    align-items: center;
}

/* ==========================================================
   AKSI PILL BUTTONS
========================================================== */

.action-container {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
}

.btn-action-pill {
    font-size: 0.72rem;
    font-weight: 600;
    padding: 5px 11px;
    border-radius: 50rem;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    text-decoration: none;
    background: transparent;
}

.btn-action-edit {
    border: 1px solid #f59e0b;
    color: #d97706;
}

.btn-action-edit:hover {
    background: #f59e0b;
    color: #FFFFFF;
    box-shadow: 0 3px 8px rgba(245, 158, 11, 0.3);
    transform: translateY(-1px);
}

.btn-action-hapus {
    border: 1px solid #dc3545;
    color: #dc3545;
}

.btn-action-hapus:hover {
    background: #dc3545;
    color: #FFFFFF;
    box-shadow: 0 3px 8px rgba(220, 53, 69, 0.3);
    transform: translateY(-1px);
}

/* ==========================================================
   SWEETALERT CUSTOM
========================================================== */

.swal2-popup-custom {
    border-radius: 24px !important;
    padding: 2rem 2rem 1.75rem !important;
    box-shadow: 0 20px 55px rgba(15, 23, 42, 0.18) !important;
}

.swal2-title-custom {
    color: #182232 !important;
    font-size: 1.35rem !important;
    font-weight: 800 !important;
    margin-top: 8px !important;
}

.swal2-html-custom {
    color: #64748B !important;
    font-size: 0.92rem !important;
    line-height: 1.6 !important;
}

.swal2-confirm-custom {
    min-width: 125px;
    border-radius: 50rem !important;
    padding: 10px 20px !important;
    font-weight: 700 !important;
    border: none !important;
    box-shadow: 0 5px 14px rgba(25, 135, 84, 0.22) !important;
    transition: all 0.2s ease !important;
}

.swal2-confirm-custom:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 18px rgba(25, 135, 84, 0.3) !important;
}

.swal2-cancel-custom {
    min-width: 125px;
    border-radius: 50rem !important;
    padding: 10px 20px !important;
    font-weight: 600 !important;
    border: 1px solid #E2E8F0 !important;
    background: #F8FAFC !important;
    color: #475569 !important;
    transition: all 0.2s ease !important;
}

.swal2-cancel-custom:hover {
    background: #F1F5F9 !important;
    transform: translateY(-2px);
}

.swal2-icon {
    margin-bottom: 10px !important;
}

.swal2-actions {
    gap: 8px !important;
    margin-top: 1.35rem !important;
}

/* Icon sukses lebih hidup */
.swal-success-icon {
    animation: successPop 0.45s ease-out;
}

@keyframes successPop {
    0% {
        transform: scale(0.65);
        opacity: 0;
    }

    70% {
        transform: scale(1.08);
    }

    100% {
        transform: scale(1);
        opacity: 1;
    }
}
</style>

<!-- ==========================================================
     KONTEN UTAMA
========================================================== -->

<div class="container-fluid px-0" style="margin-top: 25px;">

<!-- HEADER BANNER -->
<div class="header-banner-custom mb-4">
    <div class="row align-items-center">

        <div class="col-lg-8">

            <span class="badge px-3 py-1.5 rounded-pill mb-2 fw-bold"
                  style="background: rgba(234, 179, 8, 0.15);
                         color: #B45309;
                         border: 1px solid rgba(234, 179, 8, 0.3);
                         font-size: 0.75rem;
                         letter-spacing: 0.5px;">

                <i class="bi bi-people-fill me-1"></i>
                MANAJEMEN USER
            </span>

            <h3 class="fw-extrabold text-dark mb-1"
                style="font-size: 1.75rem; letter-spacing: -0.5px;">

                Data Pengguna Sistem
            </h3>

            <p class="text-muted small mb-0">
                Kelola akun Administrator dan Kasir, ubah informasi data,
                atau hapus akun dari sistem.
            </p>

        </div>

        <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">

            <div class="d-inline-flex align-items-center gap-2 time-badge-box text-start">

                <i class="bi bi-clock-history text-warning fs-4"></i>

                <div>

                    <div class="text-muted"
                         style="font-size: 0.7rem;
                                text-transform: uppercase;
                                font-weight: 600;
                                letter-spacing: 0.5px;">

                        Waktu Akses Sistem

                    </div>

                    <div class="fw-bold text-dark"
                         style="font-size: 0.85rem;"
                         id="realtime-clock">

                        Memuat waktu...

                    </div>

                </div>

            </div>

        </div>

    </div>
</div>

<!-- ==========================================================
     FILTER & PENCARIAN
========================================================== -->

<div class="card card-light-custom p-4 mb-4 shadow-sm">

    <?php $current_role = $_GET['role'] ?? ''; ?>

    <div class="row align-items-center justify-content-between gy-3">

        <!-- PENCARIAN DI KIRI -->
        <div class="col-lg-4">

            <form action=""
                  method="GET"
                  class="d-flex align-items-center gap-2">

                <?php if (!empty($current_role)): ?>

                    <input type="hidden"
                           name="role"
                           value="<?= htmlspecialchars($current_role); ?>">

                <?php endif; ?>

                <div class="input-group input-group-sm"
                     style="max-width: 220px;">

                    <input type="text"
                           name="cari"
                           class="form-control rounded-pill px-3"
                           placeholder="Cari user..."
                           value="<?= htmlspecialchars($cari); ?>">

                </div>

            </form>

        </div>

        <!-- FILTER + TAMBAH DI KANAN -->
        <div class="col-lg-8">

            <div class="d-flex align-items-center justify-content-lg-end gap-2 flex-wrap">

                <!-- FILTER ROLE -->

                <div class="d-flex align-items-center gap-2 flex-wrap">

                    <span class="fw-bold text-secondary me-1"
                          style="font-size: 0.85rem;">

                        <i class="bi bi-funnel-fill me-1 text-warning"></i>
                        Filter Role:

                    </span>

                    <a href="data-user.php<?= !empty($cari) ? '?cari=' . urlencode($cari) : ''; ?>"
                       class="btn-filter-pill <?= ($current_role == '') ? 'active-filter' : ''; ?>">

                        <i class="bi bi-grid-fill"></i>
                        Semua Role

                    </a>

                    <a href="data-user.php?role=admin<?= !empty($cari) ? '&cari=' . urlencode($cari) : ''; ?>"
                       class="btn-filter-pill <?= ($current_role == 'admin') ? 'active-filter' : ''; ?>">

                        <i class="bi bi-shield-lock"></i>
                        Administrator

                    </a>

                    <a href="data-user.php?role=kasir<?= !empty($cari) ? '&cari=' . urlencode($cari) : ''; ?>"
                       class="btn-filter-pill <?= ($current_role == 'kasir') ? 'active-filter' : ''; ?>">

                        <i class="bi bi-person-badge"></i>
                        Kasir

                    </a>

                </div>

                <!-- PEMBATAS -->

                <div class="vr d-none d-lg-block mx-1"
                     style="height: 30px; opacity: 0.15;">
                </div>

                <!-- TOMBOL TAMBAH -->

                <a href="user-tambah.php"
                   class="btn btn-warning btn-sm rounded-pill px-3 fw-bold text-dark d-inline-flex align-items-center gap-1 shadow-sm flex-shrink-0"
                   style="background: #F59E0B; border: none;"
                   title="Tambah User">

                    <i class="bi bi-plus-lg"></i>
                    Tambah User

                </a>

            </div>

        </div>

    </div>

</div>

<!-- ==========================================================
     TABEL DATA USER
========================================================== -->

<div class="card card-light-custom shadow-sm mb-4">

    <div class="table-responsive">

        <table class="table table-custom-v2 align-middle mb-0">

            <thead>

                <tr>

                    <th style="width: 7%;">No</th>
                    <th>ID User</th>
                    <th>Nama Lengkap</th>
                    <th>Username</th>
                    <th>Role Sistem</th>
                    <th class="text-center" style="width: 22%;">Aksi</th>

                </tr>

            </thead>

            <tbody>

                <?php if (mysqli_num_rows($query) > 0): ?>

                    <?php

                    $no = $offset + 1;

                    while ($row = mysqli_fetch_assoc($query)):

                        $id_user = $row['UserID'];

                        // Format ID User mengikuti struktur ID Member
                        $format_user_id = 'DAILYUSR' . $id_user;

                        $nama_user = $row['NamaUser'];
                        $username = $row['Username'];
                        $user_role = strtolower($row['Role']);

                    ?>

                    <tr>

                        <!-- NO -->
                        <td class="fw-bold text-secondary">
                            <?= $no++; ?>
                        </td>

                        <!-- ID USER -->
                        <td>
                            <span class="badge-user-id">
                                <i class="bi bi-qr-code me-1"></i>
                                <?= htmlspecialchars($format_user_id); ?>
                            </span>
                        </td>

                        <!-- NAMA LENGKAP -->
                        <td>

                            <div class="fw-bold text-dark d-flex align-items-center gap-2">

                                <div class="rounded-circle bg-warning bg-opacity-10 text-warning d-flex align-items-center justify-content-center fw-bold shadow-sm"
                                     style="width: 34px;
                                            height: 34px;
                                            font-size: 0.85rem;">

                                    <?= strtoupper(substr($nama_user, 0, 1)); ?>

                                </div>

                                <div>
                                    <?= htmlspecialchars($nama_user); ?>
                                </div>

                            </div>

                        </td>

                        <!-- USERNAME -->
                        <td>

                            <span class="text-muted font-monospace small bg-light px-2 py-1 rounded border">

                                @<?= htmlspecialchars($username); ?>

                            </span>

                        </td>

                        <!-- ROLE -->
                        <td>

                            <?php if ($user_role === 'admin'): ?>

                                <span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 px-2.5 py-1 rounded-pill fw-semibold"
                                      style="font-size: 0.72rem;">

                                    <i class="bi bi-shield-lock-fill me-1"></i>
                                    Administrator

                                </span>

                            <?php else: ?>

                                <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-2.5 py-1 rounded-pill fw-semibold"
                                      style="font-size: 0.72rem;">

                                    <i class="bi bi-person-badge-fill me-1"></i>
                                    Kasir

                                </span>

                            <?php endif; ?>

                        </td>

                        <!-- AKSI -->
                        <td class="text-center">

                            <div class="action-container">

                                <!-- EDIT -->

                                <a href="user-edit.php?id=<?= $id_user; ?>"
                                   class="btn-action-pill btn-action-edit"
                                   title="Edit Akun">

                                    <i class="bi bi-pencil-square"></i>
                                    Edit

                                </a>

                                <!-- HAPUS -->

                                <?php if ($id_user != $_SESSION['UserID']): ?>

                                    <button type="button"
                                            onclick="konfirmasiHapus(
                                                <?= (int)$id_user; ?>,
                                                <?= htmlspecialchars(
                                                    json_encode($nama_user),
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ); ?>
                                            )"
                                            class="btn-action-pill btn-action-hapus"
                                            title="Hapus Akun">

                                        <i class="bi bi-trash"></i>
                                        Hapus

                                    </button>

                                <?php else: ?>

                                    <span class="text-muted small fst-italic px-2"
                                          style="font-size: 0.7rem;">

                                        (Akun Anda)

                                    </span>

                                <?php endif; ?>

                            </div>

                        </td>

                    </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="6"
                            class="text-center text-muted py-5">

                            <i class="bi bi-people fs-2 d-block mb-2 text-warning opacity-50"></i>

                            Tidak ada data pengguna/user yang sesuai dengan filter.

                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

    <!-- ======================================================
         PAGINASI
    ======================================================= -->

    <?php if ($total_pages > 1): ?>

        <div class="card-footer bg-white border-0 py-3">

            <nav>

                <ul class="pagination justify-content-center mb-0">

                    <li class="page-item <?= ($page <= 1) ? 'disabled' : ''; ?>">

                        <a class="page-link"
                           href="?page=<?= $page - 1; ?><?= !empty($cari) ? '&cari=' . urlencode($cari) : ''; ?><?= !empty($filter_role) ? '&role=' . urlencode($filter_role) : ''; ?>">

                            Sebelumnya

                        </a>

                    </li>

                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>

                        <li class="page-item <?= ($page == $i) ? 'active' : ''; ?>">

                            <a class="page-link"
                               href="?page=<?= $i; ?><?= !empty($cari) ? '&cari=' . urlencode($cari) : ''; ?><?= !empty($filter_role) ? '&role=' . urlencode($filter_role) : ''; ?>">

                                <?= $i; ?>

                            </a>

                        </li>

                    <?php endfor; ?>

                    <li class="page-item <?= ($page >= $total_pages) ? 'disabled' : ''; ?>">

                        <a class="page-link"
                           href="?page=<?= $page + 1; ?><?= !empty($cari) ? '&cari=' . urlencode($cari) : ''; ?><?= !empty($filter_role) ? '&role=' . urlencode($filter_role) : ''; ?>">

                            Selanjutnya

                        </a>

                    </li>

                </ul>

            </nav>

        </div>

    <?php endif; ?>

</div>

</div>

<!-- ==========================================================
     SWEETALERT2
========================================================== -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>

// ==========================================================
// REALTIME CLOCK
// ==========================================================

function updateClock() {

    const now = new Date();

    const options = {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };

    const clock = document.getElementById('realtime-clock');

    if (clock) {

        clock.innerText =
            now.toLocaleDateString('id-ID', options) + ' WIB';

    }

}

setInterval(updateClock, 1000);
updateClock();


// ==========================================================
// KONFIRMASI HAPUS
// ==========================================================

function konfirmasiHapus(id, nama) {

    Swal.fire({

        title: 'Yakin Ingin Menghapus?',

        html:
            'Akun <b>' +
            nama +
            '</b> akan dihapus secara permanen dari database sistem kasir.',

        icon: 'question',

        iconColor: '#F59E0B',

        showCancelButton: true,

        confirmButtonText:
            '<i class="bi bi-trash3-fill me-1"></i> Ya, Hapus',

        cancelButtonText:
            '<i class="bi bi-x-lg me-1"></i> Nanti Saja',

        reverseButtons: true,

        focusCancel: true,

        customClass: {

            popup: 'swal2-popup-custom',

            title: 'swal2-title-custom',

            htmlContainer: 'swal2-html-custom',

            confirmButton:
                'btn btn-danger swal2-confirm-custom',

            cancelButton:
                'btn btn-light swal2-cancel-custom'

        },

        buttonsStyling: false,

        showClass: {
            popup: 'animate__animated animate__fadeInDown'
        },

        hideClass: {
            popup: 'animate__animated animate__fadeOutUp'
        }

    }).then((result) => {

        if (result.isConfirmed) {

            window.location.href =
                'user-hapus.php?id=' + id;

        }

    });

}


// ==========================================================
// NOTIFIKASI REDIRECT
// ==========================================================

<?php if (isset($_GET['pesan'])): ?>

document.addEventListener("DOMContentLoaded", function() {

    const pesan = <?= json_encode($_GET['pesan']); ?>;


    // ======================================================
    // SUKSES TAMBAH
    // ======================================================

    if (pesan === 'sukses_tambah') {

        Swal.fire({

            title: 'Berhasil Disimpan!',

            html:
                'Data pengguna baru telah berhasil ' +
                'ditambahkan ke dalam sistem.',

            icon: 'success',

            iconColor: '#198754',

            confirmButtonText:
                '<i class="bi bi-check-lg me-1"></i> OK',

            customClass: {

                popup: 'swal2-popup-custom',

                title: 'swal2-title-custom',

                htmlContainer: 'swal2-html-custom',

                confirmButton:
                    'btn btn-success swal2-confirm-custom'

            },

            buttonsStyling: false,

            timer: 3200,

            timerProgressBar: true,

            didOpen: () => {

                const icon =
                    Swal.getIcon();

                if (icon) {
                    icon.classList.add('swal-success-icon');
                }

            }

        });

    }


    // ======================================================
    // SUKSES EDIT
    // ======================================================

    else if (pesan === 'sukses_edit') {

        Swal.fire({

            title: 'Data Berhasil Diperbarui!',

            html:
                'Data pengguna yang Anda ubah ' +
                '<b>telah berhasil disimpan</b> ' +
                'ke dalam sistem.',

            icon: 'success',

            iconColor: '#198754',

            confirmButtonText:
                '<i class="bi bi-check-circle-fill me-1"></i> Selesai',

            customClass: {

                popup: 'swal2-popup-custom',

                title: 'swal2-title-custom',

                htmlContainer: 'swal2-html-custom',

                confirmButton:
                    'btn btn-success swal2-confirm-custom'

            },

            buttonsStyling: false,

            timer: 3500,

            timerProgressBar: true,

            didOpen: () => {

                const icon =
                    Swal.getIcon();

                if (icon) {
                    icon.classList.add('swal-success-icon');
                }

            }

        });

    }


    // ======================================================
    // SUKSES HAPUS
    // ======================================================

    else if (pesan === 'sukses_hapus') {

        Swal.fire({

            title: 'Berhasil Dihapus!',

            html:
                'Data pengguna telah ' +
                '<b>berhasil dihapus</b> ' +
                'dari sistem.',

            icon: 'success',

            iconColor: '#198754',

            confirmButtonText:
                '<i class="bi bi-check-circle-fill me-1"></i> OK',

            customClass: {

                popup: 'swal2-popup-custom',

                title: 'swal2-title-custom',

                htmlContainer: 'swal2-html-custom',

                confirmButton:
                    'btn btn-success swal2-confirm-custom'

            },

            buttonsStyling: false,

            timer: 3200,

            timerProgressBar: true,

            didOpen: () => {

                const icon =
                    Swal.getIcon();

                if (icon) {
                    icon.classList.add('swal-success-icon');
                }

            }

        });

    }


    // ======================================================
    // GAGAL HAPUS AKUN SENDIRI
    // ======================================================

    else if (pesan === 'gagal_hapus_sendiri') {

        Swal.fire({

            title: 'Aksi Ditolak!',

            html:
                'Anda tidak dapat menghapus akun ' +
                '<b>yang sedang Anda gunakan</b> ' +
                'saat ini.',

            icon: 'warning',

            iconColor: '#F59E0B',

            confirmButtonText:
                '<i class="bi bi-exclamation-circle me-1"></i> Mengerti',

            customClass: {

                popup: 'swal2-popup-custom',

                title: 'swal2-title-custom',

                htmlContainer: 'swal2-html-custom',

                confirmButton:
                    'btn btn-warning text-dark swal2-confirm-custom'

            },

            buttonsStyling: false

        });

    }


    // ======================================================
    // GAGAL RELASI
    // ======================================================

    else if (pesan === 'gagal_relasi') {

        Swal.fire({

            title: 'Gagal Menghapus!',

            html:
                'Data user ini masih terikat dengan ' +
                '<b>riwayat transaksi aktif</b> ' +
                'di database.',

            icon: 'error',

            iconColor: '#DC3545',

            confirmButtonText:
                '<i class="bi bi-x-circle-fill me-1"></i> Tutup',

            customClass: {

                popup: 'swal2-popup-custom',

                title: 'swal2-title-custom',

                htmlContainer: 'swal2-html-custom',

                confirmButton:
                    'btn btn-danger swal2-confirm-custom'

            },

            buttonsStyling: false

        });

    }

});

<?php endif; ?>

</script>