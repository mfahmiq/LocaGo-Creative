<?php
include '../koneksi.php';
include 'header.php';

// Set zona waktu WIB
date_default_timezone_set('Asia/Jakarta');

// ==========================================================
// FILTER TANGGAL
// ==========================================================
$tgl_mulai = isset($_GET['tgl_mulai']) ? $_GET['tgl_mulai'] : '';
$tgl_selesai = isset($_GET['tgl_selesai']) ? $_GET['tgl_selesai'] : '';

// Jika tombol "Transaksi Hari Ini" menggunakan parameter ?tgl=
if (isset($_GET['tgl']) && !empty($_GET['tgl'])) {
    $tgl_mulai = $_GET['tgl'];
    $tgl_selesai = $_GET['tgl'];
}

// ==========================================================
// PAGINASI
// ==========================================================
$limit = 20;

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

if ($page < 1) {
    $page = 1;
}

$offset = ($page - 1) * $limit;

// ==========================================================
// KONDISI WHERE
// ==========================================================
$where_sql = "WHERE 1=1";
$where_sql_alias = "WHERE 1=1";

if (!empty($tgl_mulai) && !empty($tgl_selesai)) {

    $tgl_mulai_aman = mysqli_real_escape_string($koneksi, $tgl_mulai);
    $tgl_selesai_aman = mysqli_real_escape_string($koneksi, $tgl_selesai);

    $where_sql .= " AND DATE(TanggalPenjualan) BETWEEN '$tgl_mulai_aman' AND '$tgl_selesai_aman'";

    $where_sql_alias .= " AND DATE(p.TanggalPenjualan) BETWEEN '$tgl_mulai_aman' AND '$tgl_selesai_aman'";

} elseif (!empty($tgl_mulai)) {

    $tgl_mulai_aman = mysqli_real_escape_string($koneksi, $tgl_mulai);

    $where_sql .= " AND DATE(TanggalPenjualan) >= '$tgl_mulai_aman'";

    $where_sql_alias .= " AND DATE(p.TanggalPenjualan) >= '$tgl_mulai_aman'";

} elseif (!empty($tgl_selesai)) {

    $tgl_selesai_aman = mysqli_real_escape_string($koneksi, $tgl_selesai);

    $where_sql .= " AND DATE(TanggalPenjualan) <= '$tgl_selesai_aman'";

    $where_sql_alias .= " AND DATE(p.TanggalPenjualan) <= '$tgl_selesai_aman'";
}

// ==========================================================
// HITUNG TOTAL DATA
// ==========================================================
$query_count = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total FROM penjualan $where_sql"
);

$data_count = mysqli_fetch_assoc($query_count);

$total_data = $data_count['total'];

$total_pages = ceil($total_data / $limit);

// ==========================================================
// QUERY UTAMA
// ==========================================================
$query = mysqli_query(
    $koneksi,
    "
    SELECT 
        p.*,

        /* ==================================================
           STATUS DIBACA SECARA EKSPLISIT
           ================================================== */
        p.status AS StatusTransaksi,

        CASE
            WHEN p.PelangganID IS NOT NULL
                 AND p.PelangganID > 0
            THEN pel.NamaPelanggan

            WHEN p.PelangganID IS NULL
                 OR p.PelangganID = 0
            THEN p.NamaPelanggan

            ELSE 'Pelanggan Umum / Tamu'
        END AS NamaFinalPelanggan,

        u.NamaUser AS NamaKasir

    FROM penjualan p

    LEFT JOIN pelanggan pel
        ON p.PelangganID = pel.PelangganID

    LEFT JOIN user u
        ON p.UserID = u.UserID

    $where_sql_alias

    ORDER BY p.TanggalPenjualan DESC

    LIMIT $limit OFFSET $offset
    "
);

/*
|--------------------------------------------------------------------------
| CEK QUERY
|--------------------------------------------------------------------------
| Jika query gagal, tampilkan pesan yang jelas.
*/
if (!$query) {
    die(
        "Query transaksi gagal dijalankan: " .
        htmlspecialchars(mysqli_error($koneksi))
    );
}
?>

<!-- ==========================================================
     CSS
========================================================== -->
<style>

body {
    background: #F4F6F9 !important;
    color: #333333 !important;
}

/* Header Banner */
.header-banner-custom {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.04);
    padding: 1.75rem 2rem;
}

.time-badge-box {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 12px;
    padding: 0.6rem 1rem;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.02);
}

.card-light-custom {
    background: #FFFFFF;
    border: 1px solid #E2E8F0;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
    color: #1E293B;
    overflow: hidden;
}

/* Tabel */
.table-custom-v2 {
    border-collapse: separate;
    border-spacing: 0;
    width: 100%;
}

.table-custom-v2 thead th {
    background: #182232 !important;
    color: #FFFFFF !important;
    font-weight: 700;
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    padding: 1.25rem 1.5rem !important;
    border: none;
    position: relative;
}

.table-custom-v2 thead th::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #D97706, #F59E0B);
}

.table-custom-v2 td {
    background-color: #FFFFFF !important;
    border-bottom: 1px solid #F1F5F9 !important;
    vertical-align: middle;
    color: #1E293B !important;
    padding: 1.25rem 1.5rem !important;
    font-size: 0.9rem;
}

.table-custom-v2 tbody tr {
    transition: all 0.2s ease;
}

.table-custom-v2 tbody tr:hover {
    background-color: #FAF8F5 !important;
}

/* Icon Waktu */
.time-icon-box {
    width: 38px;
    height: 38px;
    background: #FFFBEB;
    border: 1px solid #FDE68A;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #D97706;
    font-size: 1.1rem;
}

/* ==========================================================
   AKSI BERTINGKAT
========================================================== */

.action-container {
    display: flex;
    flex-direction: column;
    gap: 6px;
    min-width: 150px;
}

.action-row-top {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
}

.action-row-bottom {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
}

.action-divider {
    height: 1px;
    background: #E2E8F0;
    width: 100%;
    margin: 1px 0;
}

.btn-action-pill {
    font-size: 0.7rem;
    font-weight: 600;
    padding: 4px 9px;
    border-radius: 50rem;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    gap: 3px;
    text-decoration: none;
    background: transparent;
}

/* Detail */
.btn-action-detail {
    border: 1px solid #0dcaf0;
    color: #0dcaf0;
}

.btn-action-detail:hover {
    background: #0dcaf0;
    color: #FFFFFF;
    box-shadow: 0 3px 8px rgba(13, 202, 240, 0.3);
}

/* Print */
.btn-action-print {
    border: 1px solid rgba(196, 154, 69, 0.6);
    color: #C49A45;
}

.btn-action-print:hover {
    background: #C49A45;
    color: #FFFFFF;
    box-shadow: 0 3px 8px rgba(196, 154, 69, 0.3);
}

/* Selesai */
.btn-action-selesai {
    border: 1px solid #198754;
    color: #198754;
}

.btn-action-selesai:hover {
    background: #198754;
    color: #FFFFFF;
    box-shadow: 0 3px 8px rgba(25, 135, 84, 0.3);
}

/* Edit */
.btn-action-edit {
    border: 1px solid #ffc107;
    color: #b38600;
}

.btn-action-edit:hover {
    background: #ffc107;
    color: #000000;
    box-shadow: 0 3px 8px rgba(255, 193, 7, 0.3);
}

/* Batal */
.btn-action-batal {
    border: 1px solid #dc3545;
    color: #dc3545;
}

.btn-action-batal:hover {
    background: #dc3545;
    color: #FFFFFF;
    box-shadow: 0 3px 8px rgba(220, 53, 69, 0.3);
}

/* SweetAlert */
.swal2-popup {
    border: 3px solid #E2E8F0 !important;
    box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.25) !important;
    border-radius: 2rem !important;
}

</style>


<div class="container-fluid px-4" style="margin-top: 25px; padding-bottom: 50px;">

    <!-- ======================================================
         HEADER
    ======================================================= -->
    <div class="header-banner-custom mb-4">

        <div class="row align-items-center">

            <div class="col-lg-8">

                <span
                    class="badge px-3 py-1.5 rounded-pill mb-2 fw-bold"
                    style="
                        background: rgba(234, 179, 8, 0.15);
                        color: #B45309;
                        border: 1px solid rgba(234, 179, 8, 0.3);
                        font-size: 0.75rem;
                        letter-spacing: 0.5px;
                    "
                >
                    <i class="bi bi-receipt-cutoff me-1"></i>
                    MANAJEMEN PENJUALAN
                </span>

                <h3
                    class="fw-extrabold text-dark mb-1"
                    style="font-size: 1.75rem; letter-spacing: -0.5px;"
                >
                    Riwayat Transaksi &amp; Kasir
                </h3>

                <p class="text-muted small mb-0">
                    Daftar seluruh transaksi penjualan yang masuk secara real-time di Daily Coffee &amp; Toast.
                </p>

            </div>

            <div class="col-lg-4 text-lg-end mt-3 mt-lg-0">

                <div class="d-inline-flex align-items-center gap-2 time-badge-box text-start">

                    <i class="bi bi-clock-history text-warning fs-4"></i>

                    <div>

                        <div
                            class="text-muted"
                            style="
                                font-size: 0.7rem;
                                text-transform: uppercase;
                                font-weight: 600;
                                letter-spacing: 0.5px;
                            "
                        >
                            Waktu Akses Sistem
                        </div>

                        <div
                            class="fw-bold text-dark"
                            style="font-size: 0.85rem;"
                            id="realtime-clock"
                        >
                            Memuat waktu...
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- ======================================================
         FILTER & AKSI
    ======================================================= -->
    <div class="row mb-4 align-items-center">

        <div class="col-md-6">

            <h5 class="fw-bold text-dark mb-0">
                Data Transaksi Penjualan
            </h5>

        </div>

        <div class="col-md-6 text-md-end mt-3 mt-md-0">

            <a
                href="transaksi.php"
                class="btn btn-dark btn-sm rounded-pill px-3 fw-semibold me-1 shadow-sm"
            >
                Semua Transaksi
            </a>

            <a
                href="transaksi.php?tgl=<?= date('Y-m-d'); ?>"
                class="btn btn-outline-dark btn-sm rounded-pill px-3 fw-semibold"
            >
                Transaksi Hari Ini
            </a>

        </div>

    </div>


    <!-- ======================================================
         TABEL TRANSAKSI
    ======================================================= -->
    <div class="card card-light-custom shadow-sm mb-4">

        <div class="table-responsive">

            <table class="table table-custom-v2 align-middle mb-0">

                <thead>

                    <tr>

                        <th>No. Transaksi</th>

                        <th>Waktu &amp; Tanggal</th>

                        <th>Pelanggan</th>

                        <th>Total Harga</th>

                        <th>Keterangan Status</th>

                        <th class="text-center">
                            Aksi
                        </th>

                    </tr>

                </thead>

                <tbody>

                    <?php if (mysqli_num_rows($query) > 0): ?>

                        <?php while ($row = mysqli_fetch_assoc($query)): ?>

                            <?php

                            $id_transaksi = (int)$row['PenjualanID'];

                            // ==================================================
                            // NAMA PELANGGAN
                            // ==================================================

                            $nama_pelanggan = !empty($row['NamaFinalPelanggan'])
                                ? $row['NamaFinalPelanggan']
                                : 'Pelanggan Umum / Tamu';


                            // ==================================================
                            // STATUS TRANSAKSI
                            // ==================================================
                            // STATUS SEKARANG DIBACA DARI:
                            // p.status AS StatusTransaksi
                            //
                            // dibatalkan -> dibatalkan
                            // batal      -> dibatalkan
                            // selesai    -> selesai
                            // berhasil   -> proses
                            // proses     -> proses
                            // kosong     -> proses
                            // ==================================================

                            $status_transaksi = strtolower(
                                trim(
                                    (string)($row['StatusTransaksi'] ?? 'proses')
                                )
                            );

                            if ($status_transaksi === 'batal') {
                                $status_transaksi = 'dibatalkan';
                            }

                            if ($status_transaksi === 'berhasil') {
                                $status_transaksi = 'proses';
                            }

                            if ($status_transaksi === '') {
                                $status_transaksi = 'proses';
                            }


                            // ==================================================
                            // NOMOR TRANSAKSI
                            // ==================================================

                            $format_tgl_trx = date(
                                'Ymd',
                                strtotime($row['TanggalPenjualan'])
                            );

                            $no_transaksi_formatted =
                                'TRX-' .
                                $format_tgl_trx .
                                '-' .
                                str_pad(
                                    $id_transaksi,
                                    4,
                                    '0',
                                    STR_PAD_LEFT
                                );


                            // ==================================================
                            // FORMAT TANGGAL
                            // ==================================================

                            $formatted_date = date(
                                'd M Y',
                                strtotime($row['TanggalPenjualan'])
                            );


                            // ==================================================
                            // FORMAT WAKTU
                            // ==================================================

                            $formatted_time = date(
                                'H:i:s',
                                strtotime($row['TanggalPenjualan'])
                            ) . ' WIB';

                            ?>

                            <tr>

                                <!-- ==================================================
                                     NOMOR TRANSAKSI
                                =================================================== -->
                                <td>

                                    <span
                                        class="badge bg-light text-dark border px-2.5 py-1.5 fw-bold"
                                        style="
                                            font-size: 0.8rem;
                                            font-family: monospace;
                                        "
                                    >
                                        <?= htmlspecialchars($no_transaksi_formatted); ?>
                                    </span>

                                </td>


                                <!-- ==================================================
                                     WAKTU
                                =================================================== -->
                                <td>

                                    <div class="d-flex align-items-center gap-3">

                                        <div class="time-icon-box">
                                            <i class="bi bi-clock-history"></i>
                                        </div>

                                        <div>

                                            <div class="fw-bold text-dark">
                                                <?= htmlspecialchars($formatted_date); ?>
                                            </div>

                                            <div
                                                class="text-muted"
                                                style="font-size: 0.8rem;"
                                            >
                                                <?= htmlspecialchars($formatted_time); ?>
                                            </div>

                                        </div>

                                    </div>

                                </td>


                                <!-- ==================================================
                                     PELANGGAN + STATUS
                                =================================================== -->
                                <td>

                                    <div class="fw-bold text-dark">
                                        <?= htmlspecialchars($nama_pelanggan); ?>
                                    </div>


                                    <?php if ($status_transaksi === 'selesai'): ?>

                                        <span
                                            class="badge mt-1 bg-success text-white"
                                            style="
                                                font-size: 0.7rem;
                                                font-weight: 600;
                                            "
                                        >
                                            <i class="bi bi-check-circle me-1"></i>
                                            Selesai (Lunas)
                                        </span>


                                    <?php elseif ($status_transaksi === 'dibatalkan'): ?>

                                        <span
                                            class="badge mt-1 bg-danger text-white"
                                            style="
                                                font-size: 0.7rem;
                                                font-weight: 600;
                                            "
                                        >
                                            <i class="bi bi-x-circle me-1"></i>
                                            Dibatalkan (Void)
                                        </span>


                                    <?php else: ?>

                                        <span
                                            class="badge mt-1"
                                            style="
                                                background: #FEF3C7;
                                                color: #D97706;
                                                font-size: 0.7rem;
                                                font-weight: 600;
                                                border: 1px solid #FDE68A;
                                            "
                                        >
                                            <i class="bi bi-hourglass-split me-1"></i>
                                            Sedang Proses
                                        </span>

                                    <?php endif; ?>

                                </td>


                                <!-- ==================================================
                                     TOTAL HARGA
                                =================================================== -->
                                <td
                                    class="fw-bold text-success"
                                    style="font-size: 0.95rem;"
                                >

                                    Rp
                                    <?= number_format(
                                        $row['TotalHarga'],
                                        0,
                                        ',',
                                        '.'
                                    ); ?>

                                </td>


                                <!-- ==================================================
                                     KETERANGAN STATUS
                                =================================================== -->
                                <td
                                    class="text-muted"
                                    style="
                                        font-size: 0.85rem;
                                        max-width: 250px;
                                    "
                                >

                                    <?php if ($status_transaksi === 'selesai'): ?>

                                        Pesanan lunas &amp; diserahkan ke pelanggan.

                                    <?php elseif ($status_transaksi === 'dibatalkan'): ?>

                                        Transaksi dibatalkan &amp; stok dikembalikan.

                                    <?php else: ?>

                                        Pesanan sedang disiapkan di bar/dapur.

                                    <?php endif; ?>

                                </td>


                                <!-- ==================================================
                                     AKSI
                                =================================================== -->
                                <td class="text-center">

                                    <div class="action-container">


                                        <!-- ==================================================
                                             BARIS ATAS
                                        =================================================== -->
                                        <div class="action-row-top">

                                            <?php if (
                                                $status_transaksi === 'proses'
                                            ): ?>

                                                <!-- SELESAI -->
                                                <button
                                                    type="button"
                                                    class="btn-action-pill btn-action-selesai btn-konfirmasi-status"
                                                    data-url="transaksi-status.php?id=<?= $id_transaksi; ?>&aksi=selesai"
                                                    data-notif="Anda akan menandai transaksi <b><?= htmlspecialchars($no_transaksi_formatted); ?></b> sebagai Selesai."
                                                    data-btntext="Ya, Selesai"
                                                >

                                                    <i class="bi bi-check-all"></i>
                                                    Selesai

                                                </button>


                                                <!-- BATAL -->
                                                <button
                                                    type="button"
                                                    class="btn-action-pill btn-action-batal btn-konfirmasi-status"
                                                    data-url="transaksi-status.php?id=<?= $id_transaksi; ?>&aksi=batal"
                                                    data-notif="Anda akan membatalkan transaksi <b><?= htmlspecialchars($no_transaksi_formatted); ?></b> (Stok akan dikembalikan)."
                                                    data-btntext="Ya, Batalkan"
                                                >

                                                    <i class="bi bi-x-circle"></i>
                                                    Batal

                                                </button>


                                            <?php elseif ($status_transaksi === 'selesai'): ?>

                                                <span
                                                    class="badge bg-light text-secondary border px-2 py-1 w-100"
                                                    style="font-size: 0.7rem;"
                                                >

                                                    <i class="bi bi-lock-fill me-1"></i>
                                                    Terkunci

                                                </span>


                                            <?php elseif ($status_transaksi === 'dibatalkan'): ?>

                                                <span
                                                    class="badge bg-light text-danger border px-2 py-1 w-100"
                                                    style="font-size: 0.7rem;"
                                                >

                                                    <i class="bi bi-slash-circle me-1"></i>
                                                    Dibatalkan

                                                </span>


                                            <?php else: ?>

                                                <span
                                                    class="badge bg-light text-warning border px-2 py-1 w-100"
                                                    style="font-size: 0.7rem;"
                                                >

                                                    <i class="bi bi-hourglass-split me-1"></i>
                                                    Sedang Proses

                                                </span>

                                            <?php endif; ?>

                                        </div>


                                        <!-- ==================================================
                                             GARIS PEMISAH
                                        =================================================== -->
                                        <div class="action-divider"></div>


                                        <!-- ==================================================
                                             BARIS BAWAH
                                        =================================================== -->
                                        <div class="action-row-bottom">


                                            <!-- DETAIL -->
                                            <a
                                                href="../kasir/detail-transaksi.php?id=<?= $id_transaksi; ?>"
                                                class="btn-action-pill btn-action-detail"
                                                title="Lihat Rincian Menu"
                                            >

                                                <i class="bi bi-eye"></i>
                                                Detail

                                            </a>


                                            <!-- CETAK -->
                                            <a
                                                href="../kasir/cetak-struk.php?id=<?= $id_transaksi; ?>"
                                                target="_blank"
                                                class="btn-action-pill btn-action-print"
                                                title="Cetak Struk"
                                            >

                                                <i class="bi bi-printer"></i>
                                                Cetak

                                            </a>


                                            <!-- EDIT -->
                                            <?php if ($status_transaksi === 'proses'): ?>

                                                <a
                                                    href="transaksi-edit.php?id=<?= $id_transaksi; ?>"
                                                    class="btn-action-pill btn-action-edit"
                                                    title="Edit Transaksi"
                                                >

                                                    <i class="bi bi-pencil-square"></i>
                                                    Edit

                                                </a>

                                            <?php endif; ?>

                                        </div>

                                    </div>

                                </td>

                            </tr>

                        <?php endwhile; ?>


                    <?php else: ?>

                        <tr>

                            <td
                                colspan="6"
                                class="text-center text-muted py-5"
                            >

                                <i
                                    class="bi bi-inbox fs-2 d-block mb-2 text-warning opacity-50"
                                ></i>

                                Belum ada data transaksi yang tercatat.

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>


        <!-- ==================================================
             PAGINASI
        =================================================== -->
        <?php if ($total_pages > 1): ?>

            <div class="card-footer bg-white border-0 py-3">

                <nav>

                    <ul class="pagination justify-content-center mb-0">


                        <!-- SEBELUMNYA -->
                        <li
                            class="page-item <?= ($page <= 1) ? 'disabled' : ''; ?>"
                        >

                            <a
                                class="page-link"
                                href="?tgl_mulai=<?= urlencode($tgl_mulai); ?>&tgl_selesai=<?= urlencode($tgl_selesai); ?>&page=<?= $page - 1; ?>"
                            >
                                Sebelumnya
                            </a>

                        </li>


                        <!-- NOMOR HALAMAN -->
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>

                            <li
                                class="page-item <?= ($page == $i) ? 'active' : ''; ?>"
                            >

                                <a
                                    class="page-link <?= ($page == $i) ? 'bg-warning text-dark border-warning fw-bold' : ''; ?>"
                                    href="?tgl_mulai=<?= urlencode($tgl_mulai); ?>&tgl_selesai=<?= urlencode($tgl_selesai); ?>&page=<?= $i; ?>"
                                >

                                    <?= $i; ?>

                                </a>

                            </li>

                        <?php endfor; ?>


                        <!-- SELANJUTNYA -->
                        <li
                            class="page-item <?= ($page >= $total_pages) ? 'disabled' : ''; ?>"
                        >

                            <a
                                class="page-link"
                                href="?tgl_mulai=<?= urlencode($tgl_mulai); ?>&tgl_selesai=<?= urlencode($tgl_selesai); ?>&page=<?= $page + 1; ?>"
                            >
                                Selanjutnya
                            </a>

                        </li>

                    </ul>

                </nav>

            </div>

        <?php endif; ?>

    </div>

</div>


<!-- ==========================================================
     JAVASCRIPT
========================================================== -->

<script src="../asset/js/bootstrap.bundle.min.js"></script>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Animate.css -->
<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
/>


<script>

    // ==========================================================
    // JAM REALTIME WIB
    // ==========================================================

    function updateClock() {

        const now = new Date();

        const optionsTime = {
            timeZone: 'Asia/Jakarta',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        };

        const optionsDate = {
            timeZone: 'Asia/Jakarta',
            day: 'numeric',
            month: 'short',
            year: 'numeric'
        };

        const timeString =
            now
                .toLocaleTimeString('id-ID', optionsTime)
                .replace(/\./g, ':');

        const dateParts =
            now
                .toLocaleDateString('id-ID', optionsDate)
                .split(' ');

        const formattedDate =
            `${dateParts[0]} ${dateParts[1]} ${dateParts[2]}, ${timeString} WIB`;

        const clockElement =
            document.getElementById('realtime-clock');

        if (clockElement) {
            clockElement.textContent = formattedDate;
        }

    }

    updateClock();

    setInterval(updateClock, 1000);


    // ==========================================================
    // SWEETALERT KONFIRMASI STATUS
    // ==========================================================

    document.addEventListener('DOMContentLoaded', function () {

        const tombolKonfirmasi =
            document.querySelectorAll('.btn-konfirmasi-status');

        tombolKonfirmasi.forEach(function (button) {

            button.addEventListener('click', function (e) {

                e.preventDefault();

                const targetUrl =
                    this.getAttribute('data-url');

                const pesanNotif =
                    this.getAttribute('data-notif');

                const textBtnConfirm =
                    this.getAttribute('data-btntext');


                Swal.fire({

                    html: `
                        <div style="
                            display: flex;
                            justify-content: center;
                            margin-bottom: 20px;
                            margin-top: 10px;
                        ">

                            <div style="
                                width: 80px;
                                height: 80px;
                                background: linear-gradient(
                                    135deg,
                                    #FEF3C7 0%,
                                    #FDE68A 100%
                                );
                                border-radius: 50%;
                                display: flex;
                                align-items: center;
                                justify-content: center;
                                box-shadow:
                                    0 10px 20px
                                    rgba(245, 158, 11, 0.2);
                                border: 3px solid #F59E0B;
                            ">

                                <i
                                    class="bi bi-question-lg"
                                    style="
                                        font-size: 40px;
                                        color: #D97706;
                                        font-weight: 900;
                                    "
                                ></i>

                            </div>

                        </div>

                        <h3 style="
                            font-weight: 900;
                            color: #1E293B;
                            font-size: 1.4rem;
                            margin-bottom: 10px;
                            letter-spacing: -0.5px;
                        ">
                            Yakin Ingin Menyimpan?
                        </h3>

                        <p style="
                            color: #64748B;
                            font-size: 14px;
                            margin-bottom: 25px;
                            padding: 0 10px;
                        ">
                            ${pesanNotif}
                        </p>
                    `,

                    showCancelButton: true,

                    confirmButtonText: textBtnConfirm,

                    cancelButtonText: 'Nanti Saja',

                    background: '#FFFFFF',

                    backdrop:
                        `rgba(15, 23, 42, 0.65) backdrop-filter blur(8px)`,

                    showClass: {
                        popup:
                            'animate__animated animate__zoomIn animate__faster'
                    },

                    buttonsStyling: false,

                    customClass: {

                        popup:
                            'rounded-5 shadow-2lg px-4 py-4',

                        actions:
                            'w-100 d-flex gap-3 px-3 mb-2',

                        confirmButton:
                            'btn flex-grow-1 py-3 rounded-pill fw-bold text-white shadow-sm',

                        cancelButton:
                            'btn flex-grow-1 py-3 rounded-pill fw-bold border text-secondary bg-light'

                    },

                    didOpen: function () {

                        const confirmBtn =
                            Swal.getConfirmButton();

                        const cancelBtn =
                            Swal.getCancelButton();


                        if (confirmBtn) {

                            confirmBtn.style.background =
                                '#166534';

                            confirmBtn.style.border =
                                'none';

                        }


                        if (cancelBtn) {

                            cancelBtn.style.background =
                                '#F1F5F9';

                            cancelBtn.style.borderColor =
                                '#CBD5E1';

                            cancelBtn.style.color =
                                '#475569';

                        }

                    }

                }).then(function (result) {

                    if (result.isConfirmed) {

                        window.location.href =
                            targetUrl;

                    }

                });

            });

        });

    });

</script>

</body>
</html>