<?php
session_start();
include '../koneksi.php';

// Cek apakah user sudah login dan memiliki hak akses
if (!isset($_SESSION['login'])) {
    header("Location: ../index.php?pesan=gagal");
    exit;
}

// Ambil statistik data untuk ditampilkan di dashboard
$query_pendapatan = mysqli_query($koneksi, "SELECT SUM(TotalHarga) as total FROM penjualan");
$data_pendapatan = mysqli_fetch_assoc($query_pendapatan);
$total_pendapatan = $data_pendapatan['total'] ?? 0;

$query_transaksi = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM penjualan");
$data_transaksi = mysqli_fetch_assoc($query_transaksi);
$total_transaksi = $data_transaksi['total'] ?? 0;

$query_produk = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM produk");
$data_produk = mysqli_fetch_assoc($query_produk);
$total_produk = $data_produk['total'] ?? 0;

// Sertakan header (biasanya berisi navbar/sidebar admin)
include 'header.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Daily Coffee & Toast</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    
    <style>
        body {
            background-color: #FAF8F5;
        }

        .wrapper-konten-admin {
            margin-top: 105px;
            margin-left: 290px;
            padding-right: 35px;
            padding-bottom: 50px;
        }

        @media (max-width: 992px) {
            .wrapper-konten-admin {
                margin-left: 20px;
                margin-right: 20px;
            }
        }

        .card-custom {
            background: #FFFFFF;
            border-radius: 20px;
            border: 1px solid rgba(231, 229, 228, 0.9);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.03);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .card-custom:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 30px rgba(196, 154, 69, 0.12);
            border-color: #C49A45;
        }

        .btn-shortcut {
            background: #FFFFFF;
            border: 1.5px solid #E7E5E4;
            color: #44403C;
            transition: all 0.2s ease;
        }

        .btn-shortcut:hover {
            background: #FAF8F5;
            border-color: #C49A45;
            color: #1c1917;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>

<div class="wrapper-konten-admin">
    <div class="container-fluid">
        
        <!-- Header Judul Dashboard -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4 bg-white p-4 rounded-4 shadow-sm border">
            <div>
                <span class="badge px-3 py-1.5 rounded-pill fw-bold mb-2" style="background: rgba(196, 154, 69, 0.15); color: #C49A45; border: 1px solid rgba(196, 154, 69, 0.3);">
                    <i class="bi bi-speedometer2 me-1"></i> ADMIN DASHBOARD
                </span>
                <h3 class="fw-extrabold mb-1 text-dark" style="letter-spacing: -0.5px;">Dashboard Admin</h3>
                <p class="text-muted small mb-0">Selamat datang kembali, Admin! Berikut ringkasan operasional kedai hari ini.</p>
            </div>
            
            <div class="text-end d-none d-lg-block">
                <span class="d-block small text-muted">Tanggal Hari Ini</span>
                <strong class="text-dark small"><i class="bi bi-calendar-event me-1 text-warning"></i> <?= date('d M Y'); ?></strong>
            </div>
        </div>

        <!-- Kartu Statistik -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="card card-custom p-4 border-warning" style="border-width: 1px !important;">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <span class="text-muted small d-block mb-1 fw-semibold">Total Pendapatan</span>
                            <h4 class="fw-bold mb-0" style="color: #C49A45;">Rp <?= number_format($total_pendapatan, 0, ',', '.'); ?></h4>
                        </div>
                        <div class="p-3 rounded-4 fs-3 shadow-sm" style="background: rgba(196, 154, 69, 0.15); color: #C49A45;">
                            <i class="bi bi-wallet2"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card card-custom p-4">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <span class="text-muted small d-block mb-1 fw-semibold">Total Transaksi</span>
                            <h4 class="text-dark fw-bold mb-0"><?= number_format($total_transaksi, 0, ',', '.'); ?> Pesanan</h4>
                        </div>
                        <div class="p-3 rounded-4 fs-3 text-primary shadow-sm" style="background: rgba(13, 110, 253, 0.1);">
                            <i class="bi bi-receipt"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card card-custom p-4">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <span class="text-muted small d-block mb-1 fw-semibold">Menu Produk Kedai</span>
                            <h4 class="text-dark fw-bold mb-0"><?= number_format($total_produk, 0, ',', '.'); ?> Item</h4>
                        </div>
                        <div class="p-3 rounded-4 fs-3 text-success shadow-sm" style="background: rgba(25, 135, 84, 0.1);">
                            <i class="bi bi-cup-hot"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Menu Pintas Cepat -->
        <div class="card card-custom p-4 mb-4">
            <h5 class="fw-bold text-dark mb-3 d-flex align-items-center gap-2">
                <i class="bi bi-grid-fill text-warning"></i> Akses Cepat Menu Admin
            </h5>
            <div class="row g-3">
                <div class="col-md-4">
                    <a href="laporan.php" class="btn btn-shortcut w-100 p-3 text-start d-flex align-items-center gap-3 rounded-4 shadow-sm">
                        <div class="p-2 rounded-3 fs-5" style="background: rgba(196, 154, 69, 0.15); color: #C49A45;"><i class="bi bi-file-earmark-bar-graph"></i></div>
                        <div>
                            <div class="fw-bold text-dark">Laporan Penjualan</div>
                            <small class="text-muted">Cek rekap dan cetak data</small>
                        </div>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="audit-log.php" class="btn btn-shortcut w-100 p-3 text-start d-flex align-items-center gap-3 rounded-4 shadow-sm">
                        <div class="p-2 rounded-3 fs-5 text-primary" style="background: rgba(13, 110, 253, 0.1);"><i class="bi bi-journal-text"></i></div>
                        <div>
                            <div class="fw-bold text-dark">Audit Log</div>
                            <small class="text-muted">Pantau aktivitas user</small>
                        </div>
                    </a>
                </div>
                <div class="col-md-4">
                    <a href="../kasir/produk.php" class="btn btn-shortcut w-100 p-3 text-start d-flex align-items-center gap-3 rounded-4 shadow-sm">
                        <div class="p-2 rounded-3 fs-5 text-success" style="background: rgba(25, 135, 84, 0.1);"><i class="bi bi-cup-hot"></i></div>
                        <div>
                            <div class="fw-bold text-dark">Kelola Produk</div>
                            <small class="text-muted">Tambah/edit menu kedai</small>
                        </div>
                    </a>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>