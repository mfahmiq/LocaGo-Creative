# 100+ Open-Source Pengganti SaaS Berbayar (Edisi 2026)

## A. AI Agents, Coding & Local LLM (1 - 20)
1. **Ollama** (https://github.com/ollama/ollama) — Pengganti OpenAI API berbayar. Jalankan Llama 3, DeepSeek, Qwen lokal.
2. **OpenWebUI** (https://github.com/open-webui/open-webui) — Pengganti ChatGPT Plus UI. Antarmuka chat lokal multi-model.
3. **Aider** (https://github.com/Aider-AI/aider) — AI pair programming langsung di terminal git.
4. **Continue.dev** (https://github.com/continuedev/continue) — Pengganti GitHub Copilot di VS Code & JetBrains.
5. **Dify** (https://github.com/langgenius/dify) — Platform workflow LLM & RAG visual siap produksi.
6. **Flowise** (https://github.com/FlowiseAI/Flowise) — Drag & drop UI untuk bangun LangChain agents.
7. **AnythingLLM** (https://github.com/Mintplex-Labs/anything-llm) — Chat dengan dokumen PDF/kode perusahaan secara privat.
8. **Tabby** (https://github.com/TabbyML/tabby) — Self-hosted AI coding assistant.
9. **GPT-Researcher** (https://github.com/assafelovic/gpt-researcher) — Autonomous agent untuk riset mendalam + sitasi.
10. **Crawl4AI** (https://github.com/unclecode/crawl4ai) — Web crawler open-source khusus ekstraksi markdown LLM.
11. **Firecrawl** (https://github.com/mendableai/firecrawl) — Ubah seluruh website menjadi data bersih untuk RAG.
12. **LocalAI** (https://github.com/mudler/LocalAI) — Drop-in replacement REST API OpenAI untuk CPU/GPU lokal.
13. **Jan.ai** (https://github.com/janhq/jan) — Aplikasi desktop ChatGPT offline 100%.
14. **Vanna.ai** (https://github.com/vanna-ai/vanna) — Text-to-SQL AI agent akurat untuk database PostgreSQL/MySQL.
15. **CrewAI** (https://github.com/crewAIInc/crewAI) — Orkestrasi multi-agent role-playing Python.
16. **AutoGen** (https://github.com/microsoft/autogen) — Framework multi-agent percakapan dari Microsoft.
17. **Langfuse** (https://github.com/langfuse/langfuse) — Observability, metrik biaya, dan tracing prompt LLM.
18. **Quivr** (https://github.com/QuivrHQ/quivr) — Second brain generatif AI di cloud sendiri.
19. **PrivateGPT** (https://github.com/zylon-ai/private-gpt) — Interaksi dokumen rahasia tanpa koneksi internet.
20. **Fabric** (https://github.com/danielmiessler/fabric) — Kumpulan ribuan prompt crowd-sourced modular di CLI.

## B. Workflow Automation & Scraping (21 - 40)
21. **n8n** (https://github.com/n8n-io/n8n) — Pengganti Zapier & Make.com. Fair-code workflow automation 400+ integrasi.
22. **Activepieces** (https://github.com/activepieces/activepieces) — Alternatif Zapier open-source paling ringan & modern.
23. **Windmill** (https://github.com/windmill-labs/windmill) — Ubah script Python/TS/Go jadi internal UI & cron workflow.
24. **Playwright** (https://github.com/microsoft/playwright) — Otomasi browser headless modern anti-flaky.
25. **Crawlee** (https://github.com/apify/crawlee) — Library web scraping & browser automation Node.js/Python.
26. **ChangeDetection.io** (https://github.com/dgtlmoon/changedetection.io) — Pantau perubahan harga kompetitor & restock barang.
27. **Huginn** (https://github.com/huginn/huginn) — Agen pribadi pemantau web & pemicu webhook otomatis.
28. **Skyvern** (https://github.com/Skyvern-AI/skyvern) — Otomasi form web kompleks berbasis Computer Vision + LLM.
29. **Scrapy** (https://github.com/scrapy/scrapy) — Framework ekstraksi data skala besar berkecepatan tinggi.
30. **Browserless** (https://github.com/browserless/browserless) — Headless Chrome di Docker untuk scraping & PDF render.
31. **CyberChef** (https://github.com/gchq/CyberChef) — Swiss Army Knife untuk decode, enkripsi, dan parsing data.
32. **Mitmproxy** (https://github.com/mitmproxy/mitmproxy) — Inspect & reverse-engineer trafik HTTPS API mobile/web.
33. **Hoppscotch** (https://github.com/hoppscotch/hoppscotch) — Pengganti Postman ringan langsung di browser.
34. **Bruno** (https://github.com/usebruno/bruno) — API client offline berbasis file Git-friendly tanpa cloud paksa.
35. **RSSHub** (https://github.com/DIYgod/RSSHub) — Buat RSS feed dari sosmed apapun (IG, Telegram, X, YouTube).
36. **ArchiveBox** (https://github.com/ArchiveBox/ArchiveBox) — Self-hosted internet archive penyimpan halaman web utuh.
37. **Meilisearch** (https://github.com/meilisearch/meilisearch) — Pengganti Algolia. Mesin pencari instan typo-tolerant.
38. **Typesense** (https://github.com/typesense/typesense) — Alternatif Algolia hemat RAM dan super kencang.
39. **Gotenberg** (https://github.com/gotenberg/gotenberg) — Docker API untuk konversi HTML/Markdown/Word ke PDF.
40. **Stirling-PDF** (https://github.com/Stirling-Tools/Stirling-PDF) — Pengganti Adobe Acrobat Pro & iLovePDF self-hosted.

## C. Bisnis, CRM, Kasir & Produktivitas (41 - 65)
41. **Twenty CRM** (https://github.com/twentyhq/twenty) — Pengganti Salesforce & HubSpot modern berbasis React/GraphQL.
42. **Chatwoot** (https://github.com/chatwoot/chatwoot) — Pengganti Intercom & Zendesk. Omnichannel WA, IG, Telegram, Livechat.
43. **Cal.com** (https://github.com/calcom/cal.com) — Pengganti Calendly untuk penjadwalan meeting konsultasi klien.
44. **Documenso** (https://github.com/documenso/documenso) — Pengganti DocuSign untuk tanda tangan kontrak digital resmi.
45. **InvoiceNinja** (https://github.com/invoiceninja/invoiceninja) — Sistem invoice, quotation, dan penagihan klien otomatis.
46. **Akaunting** (https://github.com/akaunting/akaunting) — Pengganti Xero/Jurnal. Software akuntansi pembukuan UMKM gratis.
47. **NocoDB** (https://github.com/nocodb/nocodb) — Pengganti Airtable. Ubah database MySQL/Postgres jadi spreadsheet pintar.
48. **Baserow** (https://github.com/baserow/baserow) — Database kolaboratif no-code alternatif Airtable.
49. **AppFlowy** (https://github.com/AppFlowy-IO/AppFlowy) — Pengganti Notion open-source berbasis Rust & Flutter (offline-first).
50. **AFFiNE** (https://github.com/toeverything/AFFiNE) — Gabungan Notion + Miro whiteboard dalam satu workspace.
51. **Plane** (https://github.com/makeplane/plane) — Pengganti Jira & Linear untuk manajemen tiket proyek software.
52. **Focalboard / Vikunja** (https://github.com/go-vikunja/vikunja) — Pengganti Trello & Todoist untuk kanban tim.
53. **Mattermost** (https://github.com/mattermost/mattermost) — Pengganti Slack untuk komunikasi internal tim engineering.
54. **Listmonk** (https://github.com/knadh/listmonk) — Pengganti Mailchimp. Newsletter & email marketing manager performa tinggi.
55. **Mautic** (https://github.com/mautic/mautic) — Marketing automation lengkap dengan drip campaign & lead scoring.
56. **Formbricks** (https://github.com/formbricks/formbricks) — Pengganti Typeform untuk survei produk & feedback user.
57. **MedusaJS** (https://github.com/medusajs/medusa) — Pengganti Shopify. Headless commerce engine berbasis Node.js.
58. **Bagisto** (https://github.com/bagisto/bagisto) — E-commerce lengkap berbasis Laravel siap kustomisasi lokal.
59. **ERPNext** (https://github.com/frappe/erpnext) — Sistem ERP manufaktur, stok, HRD, dan akuntansi skala penuh.
60. **Odoo Community** (https://github.com/odoo/odoo) — Suite aplikasi bisnis modular open-source.
61. **Ghost** (https://github.com/TryGhost/Ghost) — Platform publikasi blog, newsletter berbayar, dan SEO kencang.
62. **Directus** (https://github.com/directus/directus) — Headless CMS instan di atas database SQL apa pun.
63. **Payload CMS** (https://github.com/payloadcms/payload) — Next.js native headless CMS dan application framework.
64. **Strapi** (https://github.com/strapi/strapi) — Headless CMS populer untuk pembuatan REST/GraphQL API cepat.
65. **Shlink** (https://github.com/shlinkio/shlink) — Pengganti Bitly. URL shortener dengan analitik klik mendalam.

## D. Desain, Media, Analytics & DevOps (66 - 100)
66. **Penpot** (https://github.com/penpot/penpot) — Pengganti Figma open-source berbasis standar web SVG & CSS Grid.
67. **Excalidraw** (https://github.com/excalidraw/excalidraw) — Papan tulis diagram arsitektur bergaya hand-drawn.
68. **LosslessCut** (https://github.com/mifi/lossless-cut) — Potong video/audio super cepat tanpa render ulang.
69. **HandBrake** (https://github.com/HandBrake/HandBrake) — Kompres ukuran video MP4 hingga 70% tanpa pecah.
70. **OBS Studio** (https://github.com/obsproject/obs-studio) — Standar emas rekam layar tutorial & live streaming.
71. **Remotion** (https://github.com/remotion-dev/remotion) — Buat video motion graphic 60fps menggunakan kode React.
72. **Upscayl** (https://github.com/upscayl/upscayl) — AI Image Upscaler desktop gratis perbesar foto buram jadi 4K.
73. **IOPaint** (https://github.com/Sanster/IOPaint) — Hapus watermark/objek foto otomatis menggunakan model AI lokal.
74. **Plausible Analytics** (https://github.com/plausible/analytics) — Pengganti Google Analytics yang ringan dan bebas cookie banner.
75. **Umami** (https://github.com/umami-software/umami) — Web analytics simpel, modern, dan mudah di-deploy di Vercel/VPS.
76. **PostHog** (https://github.com/PostHog/posthog) — Product analytics lengkap dengan session replay, heatmap, dan A/B test.
77. **Matomo** (https://github.com/matomo-org/matomo) — Alternatif Google Analytics lengkap dengan kepemilikan data 100%.
78. **Uptime Kuma** (https://github.com/louislam/uptime-kuma) — Dashboard monitoring server/website cantik + alert Telegram/WA.
79. **Coolify** (https://github.com/coollabsio/coolify) — Pengganti Heroku, Vercel, dan Netlify di VPS milik sendiri.
80. **Dokploy** (https://github.com/Dokploy/dokploy) — PaaS deployment aplikasi & database super ringan berbasis Docker.
81. **CapRover** (https://github.com/caprover/caprover) — One-click app deployment dengan Nginx & Let's Encrypt otomatis.
82. **PocketBase** (https://github.com/pocketbase/pocketbase) — Backend lengkap (SQLite + Auth + Realtime + Storage) dalam 1 file Go.
83. **Supabase** (https://github.com/supabase/supabase) — Pengganti Firebase berbasis PostgreSQL lengkap dengan Edge Functions.
84. **Appwrite** (https://github.com/appwrite/appwrite) — Backend-as-a-Service untuk web, Flutter, dan mobile.
85. **Infisical** (https://github.com/Infisical/infisical) — Manajemen `.env` dan secret API keys tim secara terenkripsi.
86. **Vaultwarden** (https://github.com/dani-garcia/vaultwarden) — Server Bitwarden ringan untuk simpan password tim.
87. **AdGuard Home** (https://github.com/AdguardTeam/AdGuardHome) — Pemblokir iklan & tracker tingkat jaringan (DNS sinkhole).
88. **Pi-hole** (https://github.com/pi-hole/pi-hole) — Blokir iklan di seluruh perangkat rumah/kantor termasuk Smart TV.
89. **SmartTube / Aerial** (https://github.com/yuliskov/SmartTube) — YouTube bebas iklan untuk Android TV & Google TV.
90. **Sherlock** (https://github.com/sherlock-project/sherlock) — OSINT tool pelacak username di 400+ jejaring sosial.
91. **SpiderFoot** (https://github.com/smicallef/spiderfoot) — Otomasi OSINT untuk audit keamanan domain & IP.
92. **Nuclei** (https://github.com/projectdiscovery/nuclei) — Vulnerability scanner cepat berbasis template YAML.
93. **Subfinder** (https://github.com/projectdiscovery/subfinder) — Enumerasi subdomain pasif super cepat.
94. **lazydocker** (https://github.com/jesseduffield/lazydocker) — UI terminal untuk memantau container Docker tanpa hafal command.
95. **btop** (https://github.com/aristocratos/btop) — Monitor CPU, RAM, Disk, dan Network server di terminal.
96. **Caddy** (https://github.com/caddyserver/caddy) — Web server modern dengan HTTPS otomatis tanpa ribet certbot.
97. **Nginx Proxy Manager** (https://github.com/NginxProxyManager/nginx-proxy-manager) — GUI pengelolaan reverse proxy & SSL gratis.
98. **WireGuard / wg-easy** (https://github.com/WeeJeWel/wg-easy) — Setup VPN pribadi di VPS dalam 2 menit lengkap dengan Web UI.
99. **Syncthing** (https://github.com/syncthing/syncthing) — Sinkronisasi folder antar laptop/server real-time tanpa cloud pihak ketiga.
100. **Immich** (https://github.com/immich-app/immich) — Pengganti Google Photos self-hosted dengan pengenalan wajah AI.
