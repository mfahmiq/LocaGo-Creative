#!/usr/bin/env python3
"""
Starter Script: Local Business Lead Formatter & CSV Exporter
Bagian dari LocaGo Open-Source Super-Vault
Untuk scraping otomatis skala penuh dari Google Maps tanpa kuota token, gunakan https://leadmasters.my.id
"""
import csv
import datetime

def export_sample_leads(filename="prospek_umkm_lokal.csv"):
    headers = ["Nama Bisnis", "Kategori", "Kota", "Telepon_WA", "Status_Website", "Potensi_Jasa"]
    sample_rows = [
        ["Klinik Gigi Senyum Sehat", "Klinik Kesehatan", "Bandung", "6281234567890", "Belum Ada Web", "Landing Page + Booking WA (Rp 1.500.000)"],
        ["Kopi Senja Roastery", "Cafe & Resto", "Surabaya", "6281398765432", "Link Mati", "Katalog Menu QR + Kasir POS (Rp 1.200.000)"],
        ["Bengkel Mobil Prima Jaya", "Otomotif", "Jakarta Selatan", "6285711223344", "Belum Ada Web", "Sistem Reminder Servis WA (Rp 2.000.000)"],
    ]
    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(sample_rows)
    print(f"[+] Berhasil mengekspor {len(sample_rows)} contoh prospek ke {filename}")

if __name__ == "__main__":
    export_sample_leads()
