# Panduan Setup VPS Murah (Rp 50rb/Bulan) untuk Host Semua Aplikasi Sendiri

1. **Sewa Cloud VPS Ubuntu 24.04 LTS** (1-2 vCPU, 2GB RAM).
2. **Aktifkan Swap Memory 4GB** agar server tidak pernah kehabisan RAM saat build:
   ```bash
   sudo fallocate -l 4G /swapfile
   sudo chmod 600 /swapfile
   sudo mkswap /swapfile
   sudo swapon /swapfile
   echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
   ```
3. **Install Docker & Caddy Web Server** untuk auto-HTTPS semua domain/subdomain Anda dalam hitungan detik.
