# LocaGo Open-Source Super-Vault (100+ Curated Tools, AI Prompts & Automation Scripts)
Disusun oleh Tim Engineer LocaGo Creative (https://www.locagocreative.my.id)

## Isi Paket Bundle Ini:
1. `01_100_Open_Source_Alternatives_SaaS.md` — Daftar 100+ repositori open-source pengganti software berlangganan mahal (CRM, Analytics, Design, Automation, Video, Security, DevTools).
2. `02_Claude_Code_Cursor_System_Prompts.md` — 20 System Prompt arsitektur full-stack, scraper anti-blokir, audit keamanan, dan UI/UX anti-AI-slop.
3. `03_Automated_Lead_Scraper_Starter.py` — Script starter Python untuk ekstraksi prospek lokal dan automasi CSV.
4. `04_Self_Hosted_VPS_Setup_Guide.md` — Panduan setup VPS murah Rp 50rb/bulan dengan Docker, Nginx Reverse Proxy, dan SSL otomatis.

---
Butuh tool desktop siap pakai untuk cari klien bisnis lokal dari Google Maps tanpa kuota token?
Cek **LeadMasters Desktop**: https://leadmasters.my.id/ (Sekali bayar Rp 149.000 seumur hidup).
