# Sistem Pendukung Keputusan (SPK) - Dss Kolaborasi Ahp Saw

```
========================================================================
📦 Sistem Pendukung Keputusan (SPK) - Dss Kolaborasi Ahp Saw
Kategori     : Kecerdasan Buatan & SPK
Tech Stack   : CodeIgniter • PHP • MySQL • Bootstrap
Database     : MySQL (.sql) (File: database.sql)
Sumber Asli  : https://github.com/Rafie93/DSS_Kolaborasi_AHP-SAW (GitHub Open Source)
Stars GitHub : ⭐ 17 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/dss-kolaborasi-ahp-saw`
     * Untuk Laragon: `C:/laragon/www/dss-kolaborasi-ahp-saw`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `dss_kolaborasi_ahp_saw`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `database.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = dss_kolaborasi_ahp_saw

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/dss-kolaborasi-ahp-saw

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
