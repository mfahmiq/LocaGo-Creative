<?php
require_once "admin/config/koneksi.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $no_ktp = trim($_POST['no_ktp'] ?? '');
    $nama_pelanggan = trim($_POST['nama_pelanggan'] ?? '');
    $email_pelanggan = trim($_POST['email_pelanggan'] ?? '');
    $no_tlp = trim($_POST['no_tlp'] ?? '');
    $tgl_pinjam = $_POST['tgl_pinjam'] ?? '';
    $tgl_kembali = $_POST['tgl_kembali'] ?? '';
    $pilih_mobil = trim($_POST['pilih_mobil'] ?? '');
    $opsi_driver = $_POST['opsi_driver'] ?? 'Lepas Kunci';
    $alamat_pelanggan = trim($_POST['alamat_pelanggan'] ?? '');
    $catatan = trim($_POST['catatan'] ?? '');

    // Validasi Kolom Wajib
    if (empty($no_ktp) || empty($nama_pelanggan) || empty($email_pelanggan) || empty($no_tlp) || empty($tgl_pinjam) || empty($tgl_kembali) || empty($pilih_mobil) || empty($alamat_pelanggan)) {
        die("<div style='font-family:sans-serif;text-align:center;padding:50px;'>
            <h3 style='color:red;'>Peringatan: Data belum lengkap!</h3>
            <p>Mohon isi semua kolom yang bertanda bintang (*).</p>
            <a href='javascript:history.back()'>&larr; Kembali ke Formulir</a>
        </div>");
    }

    // Hitung Durasi Sewa (Hari)
    $d1 = new DateTime($tgl_pinjam);
    $d2 = new DateTime($tgl_kembali);
    $diff = $d1->diff($d2);
    $durasi_hari = max(1, (int)$diff->days);
    if ($d2 < $d1) {
        $durasi_hari = 1;
        $tgl_kembali = $tgl_pinjam;
    }

    // Ambil harga mobil dari database
    $harga_harian = 350000;
    $id_mobil = null;
    $q_car = mysqli_prepare($koneksi, "SELECT id_mobil, harga_harian FROM mobil WHERE nama_mobil = ? LIMIT 1");
    mysqli_stmt_bind_param($q_car, "s", $pilih_mobil);
    mysqli_stmt_execute($q_car);
    $res_car = mysqli_stmt_get_result($q_car);
    if ($car_row = mysqli_fetch_assoc($res_car)) {
        $harga_harian = (float)$car_row['harga_harian'];
        $id_mobil = (int)$car_row['id_mobil'];
    }

    // Hitung Biaya Supir
    $biaya_driver_per_hari = ($opsi_driver === 'Dengan Supir') ? 150000 : 0;

    // Total Biaya
    $total_biaya = ($harga_harian * $durasi_hari) + ($biaya_driver_per_hari * $durasi_hari);

    // Generate Kode Booking Unik
    $kode_booking = generate_kode_booking();
    
    // Pastikan kode booking belum pernah ada
    $cek_kode = mysqli_query($koneksi, "SELECT id_pesan FROM pemesanan WHERE kode_booking = '$kode_booking'");
    while (mysqli_num_rows($cek_kode) > 0) {
        $kode_booking = generate_kode_booking();
        $cek_kode = mysqli_query($koneksi, "SELECT id_pesan FROM pemesanan WHERE kode_booking = '$kode_booking'");
    }

    $status_awal = 'Menunggu Konfirmasi';

    // Insert ke tabel pemesanan
    $stmt = mysqli_prepare($koneksi, "INSERT INTO pemesanan 
        (kode_booking, no_ktp, nama_pelanggan, email_pelanggan, no_tlp, tgl_pinjam, tgl_kembali, durasi_hari, id_mobil, pilih_mobil, opsi_driver, total_biaya, alamat_pelanggan, catatan, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    mysqli_stmt_bind_param($stmt, "sssssssiissdsss", 
        $kode_booking, $no_ktp, $nama_pelanggan, $email_pelanggan, $no_tlp, $tgl_pinjam, $tgl_kembali, $durasi_hari, $id_mobil, $pilih_mobil, $opsi_driver, $total_biaya, $alamat_pelanggan, $catatan, $status_awal
    );

    if (mysqli_stmt_execute($stmt)) {
        header("Location: invoice.php?kode=" . urlencode($kode_booking));
        exit();
    } else {
        die("<div style='font-family:sans-serif;text-align:center;padding:50px;'>
            <h3 style='color:red;'>Gagal Memproses Pemesanan</h3>
            <p>" . mysqli_error($koneksi) . "</p>
            <a href='javascript:history.back()'>&larr; Kembali</a>
        </div>");
    }
} else {
    header("Location: index.php");
    exit();
}
?>
