<?php
require_once "admin/config/koneksi.php";

$keyword = trim($_GET['keyword'] ?? '');
$booking = null;
$searched = false;

if (!empty($keyword)) {
    $searched = true;
    $stmt = mysqli_prepare($koneksi, "SELECT p.*, m.gambar, m.kategori, m.transmisi, m.muatan 
        FROM pemesanan p 
        LEFT JOIN mobil m ON p.pilih_mobil = m.nama_mobil 
        WHERE p.kode_booking = ? OR p.no_ktp = ? OR p.no_tlp = ? 
        ORDER BY p.id_pesan DESC LIMIT 1");
    mysqli_stmt_bind_param($stmt, "sss", $keyword, $keyword, $keyword);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $booking = mysqli_fetch_assoc($res);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cek Status Pemesanan - Nearental Mobil Bandung</title>
    
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #2563eb;
            --bg-light: #f8fafc;
        }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-light);
            color: #1e293b;
        }
        .navbar-custom {
            background: #ffffff;
            border-bottom: 1px solid #e2e8f0;
        }
        .search-card {
            background: #ffffff;
            border-radius: 1.25rem;
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            padding: 2.5rem 2rem;
        }
        .result-card {
            background: #ffffff;
            border-radius: 1.25rem;
            border: 1px solid #e2e8f0;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }
        /* Step Tracker */
        .track-step {
            position: relative;
            text-align: center;
            flex: 1;
        }
        .track-step::before {
            content: '';
            position: absolute;
            top: 20px;
            left: -50%;
            right: 50%;
            height: 3px;
            background: #e2e8f0;
            z-index: 1;
        }
        .track-step:first-child::before {
            display: none;
        }
        .track-step.active::before {
            background: var(--primary);
        }
        .track-icon {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: #e2e8f0;
            color: #64748b;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            position: relative;
            z-index: 2;
            font-size: 1rem;
            margin-bottom: 0.5rem;
        }
        .track-step.active .track-icon {
            background: var(--primary);
            color: #ffffff;
            box-shadow: 0 0 0 5px rgba(37, 99, 235, 0.2);
        }
        .track-step.done .track-icon {
            background: #16a34a;
            color: #ffffff;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom sticky-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center fw-bold text-primary" href="index.php">
            <i class="fa-solid fa-car-side me-2 fs-4"></i>
            <span>NEARENTAL MOBIL</span>
        </a>
        <div class="ms-auto">
            <a href="index.php" class="btn btn-outline-secondary btn-sm rounded-pill">
                <i class="fa-solid fa-arrow-left me-1"></i> Beranda
            </a>
        </div>
    </div>
</nav>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="search-card mb-4 text-center">
                <i class="fa-solid fa-file-circle-check text-primary fs-1 mb-2"></i>
                <h3 class="fw-extrabold text-dark mb-1">Cek Status Reservasi Mobil</h3>
                <p class="text-muted small mb-4">Masukkan <strong>Kode Booking</strong>, <strong>No. KTP</strong>, atau <strong>Nomor Telepon/HP</strong> Anda yang terdaftar.</p>

                <form action="cek_booking.php" method="GET" class="d-flex flex-column flex-sm-row gap-2">
                    <div class="input-group">
                        <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-magnifying-glass text-muted"></i></span>
                        <input type="text" name="keyword" class="form-control border-start-0 py-3" placeholder="Contoh: NR-20260901-0001 atau 08123456789" value="<?= htmlspecialchars($keyword) ?>" required autofocus>
                    </div>
                    <button type="submit" class="btn btn-primary px-4 fw-bold py-3">
                        Lacak Status
                    </button>
                </form>
            </div>

            <?php if ($searched): ?>
                <?php if ($booking): ?>
                    <?php
                    $stat = $booking['status'];
                    $step1_active = true;
                    $step2_active = ($stat === 'Pinjam' || $stat === 'Selesai');
                    $step3_active = ($stat === 'Selesai');
                    $is_canceled = ($stat === 'Dibatalkan');
                    ?>
                    <div class="result-card shadow">
                        <div class="p-4 bg-light border-bottom d-flex justify-content-between align-items-center">
                            <div>
                                <span class="text-muted small">Kode Booking:</span>
                                <h5 class="fw-bold text-primary font-monospace mb-0"><?= htmlspecialchars($booking['kode_booking']) ?></h5>
                            </div>
                            <div>
                                <?php if ($is_canceled): ?>
                                    <span class="badge bg-danger px-3 py-2 rounded-pill">Dibatalkan</span>
                                <?php elseif ($stat === 'Pinjam'): ?>
                                    <span class="badge bg-primary px-3 py-2 rounded-pill">Sedang Dipinjam</span>
                                <?php elseif ($stat === 'Selesai'): ?>
                                    <span class="badge bg-success px-3 py-2 rounded-pill">Selesai / Dikembalikan</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark px-3 py-2 rounded-pill">Menunggu Konfirmasi</span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="p-4 p-md-5">
                            <?php if (!$is_canceled): ?>
                            <!-- Step Tracker -->
                            <div class="d-flex justify-content-between mb-5">
                                <div class="track-step <?= $step1_active ? ($step2_active ? 'done' : 'active') : '' ?>">
                                    <div class="track-icon">
                                        <i class="fa-solid fa-clock"></i>
                                    </div>
                                    <h6 class="small fw-bold mb-0">1. Booking Masuk</h6>
                                    <small class="text-muted" style="font-size: 0.75rem;">Menunggu Konfirmasi</small>
                                </div>
                                <div class="track-step <?= $step2_active ? ($step3_active ? 'done' : 'active') : '' ?>">
                                    <div class="track-icon">
                                        <i class="fa-solid fa-key"></i>
                                    </div>
                                    <h6 class="small fw-bold mb-0">2. Disetujui & Jalan</h6>
                                    <small class="text-muted" style="font-size: 0.75rem;">Sedang Dipinjam</small>
                                </div>
                                <div class="track-step <?= $step3_active ? 'done active' : '' ?>">
                                    <div class="track-icon">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </div>
                                    <h6 class="small fw-bold mb-0">3. Selesai</h6>
                                    <small class="text-muted" style="font-size: 0.75rem;">Unit Dikembalikan</small>
                                </div>
                            </div>
                            <?php else: ?>
                            <div class="alert alert-danger rounded-3 mb-4">
                                <i class="fa-solid fa-ban me-2"></i> Pemesanan ini telah dibatalkan oleh admin atau pelanggan.
                            </div>
                            <?php endif; ?>

                            <!-- Detail Data -->
                            <div class="row g-3">
                                <div class="col-6 col-md-4">
                                    <small class="text-muted">Nama Pemesan</small>
                                    <div class="fw-bold"><?= htmlspecialchars($booking['nama_pelanggan']) ?></div>
                                </div>
                                <div class="col-6 col-md-4">
                                    <small class="text-muted">Mobil Sewa</small>
                                    <div class="fw-bold text-primary"><?= htmlspecialchars($booking['pilih_mobil']) ?></div>
                                </div>
                                <div class="col-6 col-md-4">
                                    <small class="text-muted">Layanan</small>
                                    <div class="fw-semibold"><?= htmlspecialchars($booking['opsi_driver'] ?? 'Lepas Kunci') ?></div>
                                </div>
                                <div class="col-6 col-md-4">
                                    <small class="text-muted">Tanggal Pinjam</small>
                                    <div class="fw-semibold text-success"><?= tgl_indo($booking['tgl_pinjam']) ?></div>
                                </div>
                                <div class="col-6 col-md-4">
                                    <small class="text-muted">Tanggal Kembali</small>
                                    <div class="fw-semibold text-danger"><?= tgl_indo($booking['tgl_kembali']) ?></div>
                                </div>
                                <div class="col-6 col-md-4">
                                    <small class="text-muted">Total Pembayaran</small>
                                    <div class="fw-bold text-dark fs-5"><?= rupiah($booking['total_biaya']) ?></div>
                                </div>
                            </div>

                            <hr class="my-4">

                            <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center">
                                <a href="invoice.php?kode=<?= urlencode($booking['kode_booking']) ?>" target="_blank" class="btn btn-outline-primary rounded-3 btn-sm">
                                    <i class="fa-solid fa-receipt me-1"></i> Buka Bukti Booking / Invoice
                                </a>
                                <a href="https://wa.me/6285316472000?text=Halo%20Admin%20Nearental,%20saya%20ingin%20tanya%20status%20booking%20kode:%20<?= urlencode($booking['kode_booking']) ?>" target="_blank" class="btn btn-success rounded-3 btn-sm">
                                    <i class="fa-brands fa-whatsapp me-1"></i> Hubungi CS via WhatsApp
                                </a>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning rounded-4 p-4 text-center shadow-sm">
                        <i class="fa-solid fa-triangle-exclamation fs-1 text-warning mb-2"></i>
                        <h5 class="fw-bold mb-1">Data Tidak Ditemukan</h5>
                        <p class="mb-0 small text-muted">Tidak ditemukan data reservasi yang cocok dengan pencarian "<strong><?= htmlspecialchars($keyword) ?></strong>". Pastikan kode booking, KTP, atau nomor telepon sudah benar.</p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
