<?php
require_once "admin/config/koneksi.php";

$preselected_car = $_GET['mobil'] ?? '';
$preselected_driver = $_GET['opsi_driver'] ?? 'Lepas Kunci';
$preselected_start = $_GET['tgl_pinjam'] ?? date('Y-m-d');
$preselected_end = $_GET['tgl_kembali'] ?? date('Y-m-d', strtotime('+1 day'));

// Ambil semua mobil yang ada di database
$cars_query = mysqli_query($koneksi, "SELECT id_mobil, nama_mobil, kategori, harga_harian, harga_mingguan, harga_bulanan, gambar, status_mobil, muatan, transmisi FROM mobil ORDER BY (nama_mobil = '$preselected_car') DESC, id_mobil ASC");

$cars_data = [];
while ($car = mysqli_fetch_assoc($cars_query)) {
    $cars_data[] = $car;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Form Pemesanan Sewa Mobil - Nearental Mobil Bandung</title>
    
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --bg-light: #f8fafc;
        }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-light);
            color: #1e293b;
        }
        .navbar-custom {
            background: #ffffff;
            border-bottom: 1px solid #e2e8f0;
        }
        .form-card {
            background: #ffffff;
            border-radius: 1.25rem;
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            padding: 2rem;
        }
        .summary-card {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            color: #ffffff;
            border-radius: 1.25rem;
            padding: 2rem;
            position: sticky;
            top: 100px;
        }
        .form-control, .form-select {
            padding: 0.75rem 1rem;
            border-radius: 0.75rem;
            border: 1px solid #cbd5e1;
            font-size: 0.95rem;
        }
        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
        }
        .step-badge {
            width: 28px;
            height: 28px;
            background: var(--primary);
            color: #ffffff;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.85rem;
            font-weight: 700;
            margin-right: 0.5rem;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom sticky-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center fw-bold text-primary" href="index.php">
            <i class="fa-solid fa-car-side me-2 fs-4"></i>
            <span>NEARENTAL MOBIL</span>
        </a>
        <div class="ms-auto d-flex align-items-center gap-3">
            <a href="index.php#armada" class="text-decoration-none text-muted small fw-semibold">
                <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Katalog
            </a>
            <a href="cek_booking.php" class="btn btn-outline-primary btn-sm rounded-pill">
                Cek Booking
            </a>
        </div>
    </div>
</nav>

<div class="container py-5">
    <div class="row justify-content-center mb-4">
        <div class="col-lg-10 text-center">
            <h2 class="fw-extrabold text-dark mb-2">Formulir Reservasi Mobil</h2>
            <p class="text-muted">Lengkapi formulir di bawah ini untuk memesan unit mobil pilihan Anda secara instan.</p>
        </div>
    </div>

    <div class="row g-4 justify-content-center">
        <!-- Form Column -->
        <div class="col-lg-7">
            <form action="proses_pesan.php" method="POST" id="bookingForm">
                <!-- Section 1: Kendaraan & Jadwal -->
                <div class="form-card mb-4">
                    <h5 class="fw-bold mb-3 d-flex align-items-center text-dark">
                        <span class="step-badge">1</span> Pilih Kendaraan & Jadwal Sewa
                    </h5>
                    
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Pilih Mobil <span class="text-danger">*</span></label>
                        <select name="pilih_mobil" id="pilih_mobil" class="form-select" required>
                            <?php foreach ($cars_data as $c): ?>
                                <option value="<?= htmlspecialchars($c['nama_mobil']) ?>" 
                                        data-price="<?= $c['harga_harian'] ?>" 
                                        data-img="<?= htmlspecialchars($c['gambar']) ?>"
                                        data-cat="<?= htmlspecialchars($c['kategori']) ?>"
                                        data-trans="<?= htmlspecialchars($c['transmisi']) ?>"
                                        data-muatan="<?= htmlspecialchars($c['muatan']) ?>"
                                        <?= ($preselected_car === $c['nama_mobil']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($c['nama_mobil']) ?> - Rp <?= number_format($c['harga_harian'], 0, ',', '.') ?>/hari (<?= $c['kategori'] ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold text-secondary">Tanggal Mulai Pinjam <span class="text-danger">*</span></label>
                            <input type="date" name="tgl_pinjam" id="tgl_pinjam" class="form-control" value="<?= $preselected_start ?>" min="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold text-secondary">Tanggal Pengembalian <span class="text-danger">*</span></label>
                            <input type="date" name="tgl_kembali" id="tgl_kembali" class="form-control" value="<?= $preselected_end ?>" min="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>

                    <div class="mb-2">
                        <label class="form-label small fw-semibold text-secondary">Pilihan Layanan Supir <span class="text-danger">*</span></label>
                        <select name="opsi_driver" id="opsi_driver" class="form-select" required>
                            <option value="Lepas Kunci" <?= ($preselected_driver === 'Lepas Kunci') ? 'selected' : '' ?>>Lepas Kunci (Setir Sendiri) - Rp 0</option>
                            <option value="Dengan Supir" <?= ($preselected_driver === 'Dengan Supir') ? 'selected' : '' ?>>Dengan Supir (+ Rp 150.000 / hari)</option>
                        </select>
                    </div>
                </div>

                <!-- Section 2: Data Diri Pelanggan -->
                <div class="form-card mb-4">
                    <h5 class="fw-bold mb-3 d-flex align-items-center text-dark">
                        <span class="step-badge">2</span> Data Diri Pemesan
                    </h5>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold text-secondary">Nomor KTP / NIK <span class="text-danger">*</span></label>
                            <input type="text" name="no_ktp" id="no_ktp" class="form-control" placeholder="16 digit nomor KTP" required maxlength="20" pattern="[0-9]{10,20}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold text-secondary">Nama Lengkap Sesuai KTP <span class="text-danger">*</span></label>
                            <input type="text" name="nama_pelanggan" class="form-control" placeholder="Nama Lengkap" required>
                        </div>
                    </div>

                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold text-secondary">Nomor WhatsApp / HP Aktif <span class="text-danger">*</span></label>
                            <input type="tel" name="no_tlp" id="no_tlp" class="form-control" placeholder="Contoh: 081234567890" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold text-secondary">Alamat Email <span class="text-danger">*</span></label>
                            <input type="email" name="email_pelanggan" class="form-control" placeholder="nama@email.com" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Alamat Domisili / Tempat Tinggal <span class="text-danger">*</span></label>
                        <textarea name="alamat_pelanggan" class="form-control" rows="2" placeholder="Alamat lengkap sesuai domisili saat ini..." required></textarea>
                    </div>

                    <div class="mb-2">
                        <label class="form-label small fw-semibold text-secondary">Catatan Tambahan (Opsional)</label>
                        <textarea name="catatan" class="form-control" rows="2" placeholder="Contoh: Titik temu di Stasiun Bandung jam 09.00 WIB, mohon unit warna hitam..."></textarea>
                    </div>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" name="submit" class="btn btn-primary btn-lg rounded-3 py-3 fw-bold shadow">
                        <i class="fa-solid fa-check-circle me-2"></i> Konfirmasi & Pesan Sekarang
                    </button>
                    <small class="text-center text-muted">Dengan menekan tombol di atas, Anda menyetujui syarat & ketentuan rental.</small>
                </div>
            </form>
        </div>

        <!-- Summary Sticky Column -->
        <div class="col-lg-5">
            <div class="summary-card shadow-lg">
                <h5 class="fw-bold text-white mb-3 d-flex align-items-center">
                    <i class="fa-solid fa-receipt text-warning me-2"></i> Ringkasan Estimasi Biaya
                </h5>

                <div class="text-center py-2 mb-3 bg-dark-subtle rounded-3 p-2">
                    <img id="summaryCarImg" src="sedan/img/sedan1.jpg" alt="Preview Mobil" class="img-fluid rounded-3 mb-2" style="max-height: 140px; object-fit: cover;">
                    <h6 class="fw-bold text-white mb-0" id="summaryCarName">-</h6>
                    <small class="text-white-50" id="summaryCarSpecs">-</small>
                </div>

                <div class="py-2 border-top border-secondary-subtle">
                    <div class="d-flex justify-content-between text-white-50 small mb-2">
                        <span>Tarif Harian Mobil:</span>
                        <span class="text-white fw-semibold" id="summaryDailyRate">Rp 0</span>
                    </div>
                    <div class="d-flex justify-content-between text-white-50 small mb-2">
                        <span>Durasi Sewa:</span>
                        <span class="text-white fw-semibold" id="summaryDuration">1 Hari</span>
                    </div>
                    <div class="d-flex justify-content-between text-white-50 small mb-2">
                        <span>Subtotal Sewa Mobil:</span>
                        <span class="text-white fw-semibold" id="summaryCarSubtotal">Rp 0</span>
                    </div>
                    <div class="d-flex justify-content-between text-white-50 small mb-2">
                        <span>Layanan Supir:</span>
                        <span class="text-white fw-semibold" id="summaryDriverSubtotal">Rp 0</span>
                    </div>
                </div>

                <div class="py-3 border-top border-secondary mt-2">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <span class="text-white-50 small d-block">TOTAL PEMBAYARAN:</span>
                            <h3 class="fw-extrabold text-warning mb-0" id="summaryTotal">Rp 0</h3>
                        </div>
                        <i class="fa-solid fa-wallet fs-2 text-white-50"></i>
                    </div>
                </div>

                <div class="mt-4 p-3 bg-white bg-opacity-10 rounded-3 small">
                    <div class="d-flex align-items-start">
                        <i class="fa-solid fa-shield-halved text-success me-2 mt-1"></i>
                        <div>
                            <strong>Pembayaran Aman:</strong>
                            <p class="mb-0 text-white-50" style="font-size: 0.8rem;">
                                Pembayaran dapat dilakukan via transfer bank resmi atau bayar tunai di tempat saat serah terima kunci.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap 5.3 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Live Price Calculation Script -->
<script>
function formatRupiah(number) {
    return 'Rp ' + new Intl.NumberFormat('id-ID').format(number);
}

function calculateSummary() {
    const carSelect = document.getElementById('pilih_mobil');
    const selectedOption = carSelect.options[carSelect.selectedIndex];
    
    if (!selectedOption) return;

    const carName = selectedOption.value;
    const dailyPrice = parseFloat(selectedOption.dataset.price || 0);
    const carImg = selectedOption.dataset.img || 'img/header.jpg';
    const carCat = selectedOption.dataset.cat || '';
    const carTrans = selectedOption.dataset.trans || '';
    const carMuatan = selectedOption.dataset.muatan || '';

    const tglPinjam = new Date(document.getElementById('tgl_pinjam').value);
    const tglKembali = new Date(document.getElementById('tgl_kembali').value);
    
    // Hitung selisih hari (minimal 1 hari)
    let diffTime = tglKembali.getTime() - tglPinjam.getTime();
    let diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    if (isNaN(diffDays) || diffDays < 1) {
        diffDays = 1;
    }

    const opsiDriver = document.getElementById('opsi_driver').value;
    const driverDailyFee = (opsiDriver === 'Dengan Supir') ? 150000 : 0;

    const carSubtotal = dailyPrice * diffDays;
    const driverSubtotal = driverDailyFee * diffDays;
    const grandTotal = carSubtotal + driverSubtotal;

    // Update UI Summary Box
    document.getElementById('summaryCarName').textContent = carName;
    document.getElementById('summaryCarSpecs').textContent = carCat + ' | ' + carTrans + ' | ' + carMuatan;
    document.getElementById('summaryCarImg').src = carImg;
    document.getElementById('summaryDailyRate').textContent = formatRupiah(dailyPrice) + ' /hari';
    document.getElementById('summaryDuration').textContent = diffDays + ' Hari';
    document.getElementById('summaryCarSubtotal').textContent = formatRupiah(carSubtotal);
    document.getElementById('summaryDriverSubtotal').textContent = (driverSubtotal > 0) ? formatRupiah(driverSubtotal) : 'Gratis (Lepas Kunci)';
    document.getElementById('summaryTotal').textContent = formatRupiah(grandTotal);
}

// Event Listeners
document.getElementById('pilih_mobil').addEventListener('change', calculateSummary);
document.getElementById('tgl_pinjam').addEventListener('change', function() {
    const tglPinjamVal = this.value;
    const tglKembaliInput = document.getElementById('tgl_kembali');
    if (tglKembaliInput.value < tglPinjamVal) {
        tglKembaliInput.value = tglPinjamVal;
    }
    tglKembaliInput.min = tglPinjamVal;
    calculateSummary();
});
document.getElementById('tgl_kembali').addEventListener('change', calculateSummary);
document.getElementById('opsi_driver').addEventListener('change', calculateSummary);

// Run initial calculation on page load
window.addEventListener('DOMContentLoaded', calculateSummary);
</script>
</body>
</html>
