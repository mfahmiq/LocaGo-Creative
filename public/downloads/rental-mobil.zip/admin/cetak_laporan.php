<?php
require_once "config/koneksi.php";
check_admin_auth();

$filter_status = $_GET['status'] ?? '';
$where = !empty($filter_status) ? "WHERE status = '" . mysqli_real_escape_string($koneksi, $filter_status) . "'" : "";

$query = mysqli_query($koneksi, "SELECT * FROM pemesanan $where ORDER BY id_pesan DESC");

$total_omset = 0;
$total_transaksi = 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Laporan Pemesanan Rental - Nearental Mobil Bandung</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: sans-serif; color: #1e293b; font-size: 13px; }
        .kop-surat { border-bottom: 3px double #000; margin-bottom: 20px; padding-bottom: 10px; }
        @media print {
            .no-print { display: none !important; }
            @page { size: landscape; margin: 15mm; }
        }
    </style>
</head>
<body class="p-4">

<div class="no-print mb-4 d-flex justify-content-between">
    <a href="homeadmin.php" class="btn btn-secondary btn-sm">&larr; Kembali ke Dashboard</a>
    <button onclick="window.print()" class="btn btn-primary btn-sm">&#128438; Cetak Dokumen</button>
</div>

<div class="kop-surat text-center">
    <h3 class="fw-bold mb-0 text-uppercase">Nearental Mobil Bandung</h3>
    <p class="mb-0">Pusat Layanan Sewa & Rental Mobil Terlengkap di Bandung dan Sekitarnya</p>
    <p class="mb-0 text-muted small">Jl. Raya Rental No. 88, Bandung, Jawa Barat | Telp / WhatsApp: +62 853-1647-2000</p>
</div>

<div class="text-center mb-4">
    <h5 class="fw-bold text-decoration-underline mb-1">LAPORAN DATA PEMESANAN KENDARAAN</h5>
    <small class="text-muted">Dicetak pada: <?= date('d F Y, H:i') ?> WIB | Oleh: <?= htmlspecialchars($_SESSION['nama_admin']) ?></small>
</div>

<table class="table table-bordered table-striped align-middle">
    <thead class="table-dark small text-center">
        <tr>
            <th width="4%">No</th>
            <th width="12%">Kode Booking</th>
            <th>Nama Pelanggan</th>
            <th>No. Telp / HP</th>
            <th>Mobil</th>
            <th>Layanan</th>
            <th>Tgl Pinjam</th>
            <th>Tgl Kembali</th>
            <th>Durasi</th>
            <th>Total Biaya</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $no = 0;
        if ($query && mysqli_num_rows($query) > 0):
            while ($r = mysqli_fetch_assoc($query)):
                $no++;
                $total_transaksi++;
                if ($r['status'] !== 'Dibatalkan') {
                    $total_omset += $r['total_biaya'];
                }
        ?>
        <tr>
            <td class="text-center"><?= $no ?></td>
            <td class="fw-bold"><?= htmlspecialchars($r['kode_booking']) ?></td>
            <td><?= htmlspecialchars($r['nama_pelanggan']) ?></td>
            <td><?= htmlspecialchars($r['no_tlp']) ?></td>
            <td class="fw-semibold"><?= htmlspecialchars($r['pilih_mobil']) ?></td>
            <td><?= htmlspecialchars($r['opsi_driver'] ?? 'Lepas Kunci') ?></td>
            <td><?= date('d/m/Y', strtotime($r['tgl_pinjam'])) ?></td>
            <td><?= date('d/m/Y', strtotime($r['tgl_kembali'])) ?></td>
            <td class="text-center"><?= $r['durasi_hari'] ?> Hari</td>
            <td class="text-end fw-semibold"><?= rupiah($r['total_biaya']) ?></td>
            <td class="text-center"><?= htmlspecialchars($r['status']) ?></td>
        </tr>
        <?php 
            endwhile;
        else:
        ?>
        <tr>
            <td colspan="11" class="text-center py-4">Belum ada data pemesanan.</td>
        </tr>
        <?php endif; ?>
    </tbody>
    <tfoot>
        <tr class="table-secondary fw-bold">
            <td colspan="9" class="text-end">TOTAL OMSET BERSIH (Non-Batal):</td>
            <td class="text-end text-success"><?= rupiah($total_omset) ?></td>
            <td class="text-center"><?= $total_transaksi ?> Pesanan</td>
        </tr>
    </tfoot>
</table>

<div class="row mt-5">
    <div class="col-8"></div>
    <div class="col-4 text-center">
        <p class="mb-5">Bandung, <?= date('d F Y') ?><br>Penanggung Jawab / Admin,</p>
        <p class="fw-bold text-decoration-underline mb-0"><?= htmlspecialchars($_SESSION['nama_admin']) ?></p>
        <small class="text-muted">Nearental Mobil Bandung</small>
    </div>
</div>

<script>
    window.addEventListener('DOMContentLoaded', () => {
        // Auto trigger print when opened directly
        // window.print();
    });
</script>
</body>
</html>
