<?php
require_once "config/koneksi.php";
check_admin_auth();

$idpesan = (int)($_GET['id'] ?? 0);

if ($idpesan > 0) {
    // Ambil data pemesanan
    $q = mysqli_query($koneksi, "SELECT pilih_mobil FROM pemesanan WHERE id_pesan = $idpesan");
    if ($row = mysqli_fetch_assoc($q)) {
        $mobil = $row['pilih_mobil'];
        
        $stmt = mysqli_prepare($koneksi, "UPDATE pemesanan SET status = 'Pinjam' WHERE id_pesan = ?");
        mysqli_stmt_bind_param($stmt, "i", $idpesan);
        mysqli_stmt_execute($stmt);

        // Update status mobil menjadi Disewa
        $u = mysqli_prepare($koneksi, "UPDATE mobil SET status_mobil = 'Disewa' WHERE nama_mobil = ?");
        mysqli_stmt_bind_param($u, "s", $mobil);
        mysqli_stmt_execute($u);

        set_flash('success', 'Pemesanan berhasil divalidasi dan status diubah menjadi Sedang Dipinjam.');
    } else {
        set_flash('danger', 'Data pemesanan tidak ditemukan.');
    }
} else {
    set_flash('danger', 'ID Pemesanan tidak valid.');
}

header("Location: homeadmin.php");
exit();
?>