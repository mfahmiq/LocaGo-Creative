<?php
require_once "config/koneksi.php";

// Jika sudah login, redirect langsung ke homeadmin.php
if (isset($_SESSION['id_admin'])) {
    header("Location: homeadmin.php");
    exit();
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = trim($_POST['user_admin'] ?? '');
    $password = trim($_POST['pass_admin'] ?? '');

    if (empty($username) || empty($password)) {
        $error = "Username dan Password wajib diisi!";
    } else {
        $stmt = mysqli_prepare($koneksi, "SELECT id_admin, nama_admin, user_admin, pass_admin FROM admin WHERE user_admin = ?");
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if ($row = mysqli_fetch_assoc($result)) {
            $is_valid = false;
            // Cek password hash bcrypt atau plain text fallback
            if (password_verify($password, $row['pass_admin'])) {
                $is_valid = true;
            } elseif ($row['pass_admin'] === $password) {
                $is_valid = true;
                // Rehash ke bcrypt jika sebelumnya plain text
                $new_hash = password_hash($password, PASSWORD_DEFAULT);
                $update_stmt = mysqli_prepare($koneksi, "UPDATE admin SET pass_admin = ? WHERE id_admin = ?");
                mysqli_stmt_bind_param($update_stmt, "si", $new_hash, $row['id_admin']);
                mysqli_stmt_execute($update_stmt);
            }

            if ($is_valid) {
                $_SESSION['id_admin'] = $row['id_admin'];
                $_SESSION['nama_admin'] = $row['nama_admin'];
                $_SESSION['username'] = $row['user_admin'];
                
                set_flash('success', 'Selamat datang kembali, ' . htmlspecialchars($row['nama_admin']) . '!');
                header("Location: homeadmin.php");
                exit();
            } else {
                $error = "Username atau Password yang Anda masukkan salah!";
            }
        } else {
            $error = "Akun admin tidak ditemukan!";
        }
    }
}

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Admin - Nearental Mobil Bandung</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-card {
            background: #ffffff;
            border-radius: 1.25rem;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.25);
            overflow: hidden;
            width: 100%;
            max-width: 440px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .login-header {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            padding: 2.25rem 2rem;
            color: #ffffff;
            text-align: center;
        }
        .login-header .icon-box {
            width: 65px;
            height: 65px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 1.75rem;
            margin-bottom: 1rem;
            backdrop-filter: blur(5px);
        }
        .login-body {
            padding: 2.25rem 2rem;
        }
        .form-control {
            padding: 0.75rem 1rem;
            border-radius: 0.75rem;
            border: 1px solid #e2e8f0;
            font-size: 0.95rem;
        }
        .form-control:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.1);
        }
        .btn-primary {
            background: #2563eb;
            border-color: #2563eb;
            padding: 0.75rem;
            border-radius: 0.75rem;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.2s ease;
        }
        .btn-primary:hover {
            background: #1d4ed8;
            border-color: #1d4ed8;
            transform: translateY(-1px);
        }
        .input-group-text {
            border-radius: 0.75rem;
            border: 1px solid #e2e8f0;
            background-color: #f8fafc;
        }
    </style>
</head>
<body>

<div class="container p-3">
    <div class="login-card mx-auto">
        <div class="login-header">
            <div class="icon-box">
                <i class="fa-solid fa-car-side"></i>
            </div>
            <h4 class="fw-bold mb-1">Nearental Mobil</h4>
            <p class="mb-0 text-white-50 small">Panel Administrasi & Manajemen Rental</p>
        </div>
        
        <div class="login-body">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center py-2 px-3 mb-3 small" role="alert">
                    <i class="fa-solid fa-triangle-exclamation me-2"></i>
                    <div><?= htmlspecialchars($error) ?></div>
                    <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if ($flash): ?>
                <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show d-flex align-items-center py-2 px-3 mb-3 small" role="alert">
                    <div><?= htmlspecialchars($flash['message']) ?></div>
                    <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <form action="index.php" method="POST">
                <div class="mb-3">
                    <label for="user_admin" class="form-label small fw-semibold text-secondary">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-solid fa-user text-muted"></i></span>
                        <input type="text" name="user_admin" id="user_admin" class="form-control" placeholder="Masukkan username" required autofocus value="<?= htmlspecialchars($_POST['user_admin'] ?? '') ?>">
                    </div>
                </div>

                <div class="mb-4">
                    <label for="pass_admin" class="form-label small fw-semibold text-secondary">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-solid fa-lock text-muted"></i></span>
                        <input type="password" name="pass_admin" id="pass_admin" class="form-control" placeholder="Masukkan password" required>
                        <button class="btn btn-outline-secondary" type="button" id="togglePass" style="border-radius: 0 0.75rem 0.75rem 0; border: 1px solid #e2e8f0;">
                            <i class="fa-regular fa-eye" id="eyeIcon"></i>
                        </button>
                    </div>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" name="login" class="btn btn-primary">
                        <i class="fa-solid fa-arrow-right-to-bracket me-1"></i> Masuk ke Dashboard
                    </button>
                </div>
            </form>

            <div class="text-center mt-4 pt-3 border-top">
                <a href="../index.php" class="text-decoration-none text-muted small hover-primary">
                    <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Halaman Utama
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const togglePass = document.getElementById('togglePass');
    const passInput = document.getElementById('pass_admin');
    const eyeIcon = document.getElementById('eyeIcon');

    togglePass.addEventListener('click', function () {
        const type = passInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passInput.setAttribute('type', type);
        eyeIcon.classList.toggle('fa-eye');
        eyeIcon.classList.toggle('fa-eye-slash');
    });
</script>
</body>
</html>