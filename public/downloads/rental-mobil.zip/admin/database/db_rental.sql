-- Database Schema for Rental Mobil
-- Charset: utf8mb4

CREATE DATABASE IF NOT EXISTS `db_rental` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `db_rental`;

-- Table: admin
CREATE TABLE IF NOT EXISTS `admin` (
    `id_admin` INT AUTO_INCREMENT PRIMARY KEY,
    `nama_admin` VARCHAR(100) NOT NULL,
    `user_admin` VARCHAR(50) NOT NULL UNIQUE,
    `pass_admin` VARCHAR(255) NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: mobil
CREATE TABLE IF NOT EXISTS `mobil` (
    `id_mobil` INT AUTO_INCREMENT PRIMARY KEY,
    `nama_mobil` VARCHAR(100) NOT NULL,
    `kategori` ENUM('Sedan', 'Hatchback', 'Minivan', 'SUV') NOT NULL DEFAULT 'Sedan',
    `harga_harian` DECIMAL(12,2) NOT NULL DEFAULT 0,
    `harga_mingguan` DECIMAL(12,2) NOT NULL DEFAULT 0,
    `harga_bulanan` DECIMAL(12,2) NOT NULL DEFAULT 0,
    `muatan` VARCHAR(30) NOT NULL DEFAULT '4-5 Penumpang',
    `transmisi` VARCHAR(50) NOT NULL DEFAULT 'Manual & Matic',
    `bahan_bakar` VARCHAR(50) NOT NULL DEFAULT 'Bensin',
    `ac` VARCHAR(50) NOT NULL DEFAULT 'Double Blower',
    `gambar` VARCHAR(255) NOT NULL,
    `status_mobil` ENUM('Tersedia', 'Disewa', 'Perawatan') NOT NULL DEFAULT 'Tersedia',
    `deskripsi` TEXT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: pemesanan
CREATE TABLE IF NOT EXISTS `pemesanan` (
    `id_pesan` INT AUTO_INCREMENT PRIMARY KEY,
    `kode_booking` VARCHAR(30) NOT NULL UNIQUE,
    `no_ktp` VARCHAR(25) NOT NULL,
    `nama_pelanggan` VARCHAR(100) NOT NULL,
    `email_pelanggan` VARCHAR(100) NOT NULL,
    `no_tlp` VARCHAR(25) NOT NULL,
    `tgl_pinjam` DATE NOT NULL,
    `tgl_kembali` DATE NOT NULL,
    `durasi_hari` INT NOT NULL DEFAULT 1,
    `id_mobil` INT NULL,
    `pilih_mobil` VARCHAR(100) NOT NULL,
    `opsi_driver` VARCHAR(30) NOT NULL DEFAULT 'Lepas Kunci',
    `total_biaya` DECIMAL(12,2) NOT NULL DEFAULT 0,
    `alamat_pelanggan` TEXT NOT NULL,
    `catatan` TEXT NULL,
    `status` ENUM('Menunggu Konfirmasi', 'Pinjam', 'Selesai', 'Dibatalkan') NOT NULL DEFAULT 'Menunggu Konfirmasi',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX (`kode_booking`),
    INDEX (`status`),
    INDEX (`no_ktp`),
    INDEX (`no_tlp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default Admin Account: user = maul, pass = maul (with bcrypt hash)
INSERT INTO `admin` (`id_admin`, `nama_admin`, `user_admin`, `pass_admin`)
VALUES (1, 'Maulana Firdaus Nurrokhim', 'maul', '$2y$10$wE47E6hF.GZ.l1GqY12GguK4Yd30m3W.R6e7f8g9h0i1j2k3l4m5n')
ON DUPLICATE KEY UPDATE `nama_admin` = VALUES(`nama_admin`);

-- Default Fleet Cars
INSERT INTO `mobil` (`id_mobil`, `nama_mobil`, `kategori`, `harga_harian`, `harga_mingguan`, `harga_bulanan`, `muatan`, `transmisi`, `bahan_bakar`, `ac`, `gambar`, `status_mobil`, `deskripsi`) VALUES
(1, 'All New Toyota Camry', 'Sedan', 550000, 3250000, 6200000, '4 Penumpang', 'Automatic', 'Bensin', 'Dual Zone Climate', 'sedan/img/sedan1.jpg', 'Tersedia', 'Sedan premium dengan kenyamanan maksimal dan performa tangguh.'),
(2, 'Honda Civic', 'Sedan', 500000, 3200000, 6100000, '4 Penumpang', 'Manual & Matic', 'Bensin', 'Single Blower', 'sedan/img/sedan2.jpg', 'Tersedia', 'Desain sporty, lincah dan sangat bertenaga untuk perjalanan luar & dalam kota.'),
(3, 'BMW 320i', 'Sedan', 450000, 2650000, 5830000, '4 Penumpang', 'Automatic', 'Bensin', 'Dual Zone Climate', 'sedan/img/sedan3.jpg', 'Tersedia', 'Kemewahan eropa dengan handling presisi dan interior mewah berkelas.'),
(4, 'Mercedes-Benz S63 AMG', 'Sedan', 650000, 4100000, 7800000, '4 Penumpang', 'Automatic', 'Bensin', 'Multi Zone AC', 'sedan/img/sedan4.jpg', 'Tersedia', 'Super luxury sedan, prestige tinggi untuk acara penting dan VIP.'),
(5, 'Hyundai Elantra', 'Sedan', 460000, 3350000, 6280000, '4 Penumpang', 'Manual & Matic', 'Bensin', 'Single Blower', 'sedan/img/sedan5.jpg', 'Tersedia', 'Sedan modern nan elegan dengan efisiensi bahan bakar yang luar biasa.'),
(6, 'New Toyota Yaris', 'Hatchback', 350000, 2100000, 5200000, '4-5 Penumpang', 'Manual & Matic', 'Bensin', 'Single Blower', 'hatchback/img/hatchback1.jpg', 'Tersedia', 'Hatchback lincah, stylish, dan sangat irit untuk aktivitas harian di perkotaan.'),
(7, 'New Honda Jazz', 'Hatchback', 450000, 2300000, 5500000, '4-5 Penumpang', 'Manual & Matic', 'Bensin', 'Single Blower', 'hatchback/img/hatchback2.jpg', 'Tersedia', 'Kabin ultra-seat lega, performa responsif dan sangat fleksibel.'),
(8, 'Suzuki Swift Sport', 'Hatchback', 350000, 2000000, 5000000, '4 Penumpang', 'Manual & Matic', 'Bensin', 'Single Blower', 'hatchback/img/hatchback3.jpg', 'Tersedia', 'Karakter sporty dengan suspensi mantap dan akselerasi gesit.'),
(9, 'New Datsun GO', 'Hatchback', 250000, 1600000, 4300000, '4-5 Penumpang', 'Manual', 'Bensin', 'Single Blower', 'hatchback/img/hatchback4.jpg', 'Tersedia', 'Pilihan paling ekonomis, hemat bahan bakar, cocok untuk keliling kota.'),
(10, 'Toyota Agya', 'Hatchback', 350000, 2150000, 5300000, '4 Penumpang', 'Manual & Matic', 'Bensin', 'Double Blower', 'hatchback/img/hatchback5.jpg', 'Tersedia', 'City car compact yang praktis, mudah parkir, dan sangat efisien.'),
(11, 'Honda Freed', 'Minivan', 450000, 2450000, 5600000, '6 Penumpang', 'Automatic', 'Bensin', 'Double Blower', 'minivan/img/minivan1.png', 'Tersedia', 'Pintu geser otomatis, captain seat nyaman untuk keluarga tercinta.'),
(12, 'Suzuki Ertiga Elegant', 'Minivan', 300000, 2250000, 5200000, '7 Penumpang', 'Manual & Matic', 'Bensin', 'Double Blower', 'minivan/img/minivan2.jpg', 'Tersedia', 'MPV keluarga idaman yang senyap, empuk, dan irit bensin.'),
(13, 'Suzuki APV', 'Minivan', 250000, 2000000, 5000000, '7-8 Penumpang', 'Manual & Matic', 'Bensin', 'Double Blower', 'minivan/img/minivan3.gif', 'Tersedia', 'Kapasitas muatan besar, ruang bagasi lapang untuk rombongan.'),
(14, 'Toyota Innova', 'Minivan', 450000, 2350000, 5520000, '7-8 Penumpang', 'Manual & Matic', 'Bensin & Solar', 'Double Blower', 'minivan/img/minivan4.jpg', 'Tersedia', 'Ketangguhan legendaris dengan kenyamanan premium untuk perjalanan jauh.'),
(15, 'Suzuki Ertiga Sporty', 'Minivan', 300000, 2250000, 5350000, '7 Penumpang', 'Manual & Matic', 'Bensin', 'Double Blower', 'minivan/img/minivan5.jpg', 'Tersedia', 'Tampilan agresif berjiwa muda dengan kenyamanan maksimal keluarga.')
ON DUPLICATE KEY UPDATE `nama_mobil` = VALUES(`nama_mobil`);
