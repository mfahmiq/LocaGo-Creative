<?php
require_once "config/koneksi.php";
check_admin_auth();

// Redirect ke homeadmin
header("Location: homeadmin.php");
exit();
?>
