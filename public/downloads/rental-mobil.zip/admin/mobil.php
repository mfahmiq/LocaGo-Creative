<?php
require_once "config/koneksi.php";
check_admin_auth();

$flash = get_flash();
$error = "";

// Handle Tambah / Edit Mobil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action_type = $_POST['action_type'] ?? '';
    
    $nama_mobil = trim($_POST['nama_mobil'] ?? '');
    $kategori = $_POST['kategori'] ?? 'Sedan';
    $harga_harian = (float)($_POST['harga_harian'] ?? 0);
    $harga_mingguan = (float)($_POST['harga_mingguan'] ?? ($harga_harian * 6));
    $harga_bulanan = (float)($_POST['harga_bulanan'] ?? ($harga_harian * 20));
    $muatan = trim($_POST['muatan'] ?? '4 Penumpang');
    $transmisi = trim($_POST['transmisi'] ?? 'Manual & Matic');
    $bahan_bakar = trim($_POST['bahan_bakar'] ?? 'Bensin');
    $ac = trim($_POST['ac'] ?? 'Double Blower');
    $status_mobil = $_POST['status_mobil'] ?? 'Tersedia';
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    
    // Handle Gambar Upload / URL
    $gambar = $_POST['gambar_lama'] ?? 'sedan/img/sedan1.jpg';
    
    if (isset($_FILES['gambar_file']) && $_FILES['gambar_file']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['gambar_file']['tmp_name'];
        $file_name = $_FILES['gambar_file']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_exts = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
        
        if (in_array($file_ext, $allowed_exts)) {
            $new_name = 'car_' . time() . '_' . rand(100, 999) . '.' . $file_ext;
            $upload_dir = '../uploads/mobil/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            if (move_uploaded_file($file_tmp, $upload_dir . $new_name)) {
                $gambar = 'uploads/mobil/' . $new_name;
            }
        }
    } elseif (!empty($_POST['gambar_url'])) {
        $gambar = trim($_POST['gambar_url']);
    }

    if (empty($nama_mobil) || $harga_harian <= 0) {
        set_flash('danger', 'Nama Mobil dan Harga Harian wajib diisi dengan benar!');
    } else {
        if ($action_type === 'add') {
            $stmt = mysqli_prepare($koneksi, "INSERT INTO mobil (nama_mobil, kategori, harga_harian, harga_mingguan, harga_bulanan, muatan, transmisi, bahan_bakar, ac, gambar, status_mobil, deskripsi) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "ssdddsssssss", $nama_mobil, $kategori, $harga_harian, $harga_mingguan, $harga_bulanan, $muatan, $transmisi, $bahan_bakar, $ac, $gambar, $status_mobil, $deskripsi);
            
            if (mysqli_stmt_execute($stmt)) {
                set_flash('success', "Mobil <strong>" . htmlspecialchars($nama_mobil) . "</strong> berhasil ditambahkan ke armada!");
            } else {
                set_flash('danger', 'Gagal menambahkan mobil: ' . mysqli_error($koneksi));
            }
        } elseif ($action_type === 'edit') {
            $id_mobil = (int)($_POST['id_mobil'] ?? 0);
            if ($id_mobil > 0) {
                $stmt = mysqli_prepare($koneksi, "UPDATE mobil SET nama_mobil = ?, kategori = ?, harga_harian = ?, harga_mingguan = ?, harga_bulanan = ?, muatan = ?, transmisi = ?, bahan_bakar = ?, ac = ?, gambar = ?, status_mobil = ?, deskripsi = ? WHERE id_mobil = ?");
                mysqli_stmt_bind_param($stmt, "ssdddsssssssi", $nama_mobil, $kategori, $harga_harian, $harga_mingguan, $harga_bulanan, $muatan, $transmisi, $bahan_bakar, $ac, $gambar, $status_mobil, $deskripsi, $id_mobil);
                
                if (mysqli_stmt_execute($stmt)) {
                    set_flash('success', "Data mobil <strong>" . htmlspecialchars($nama_mobil) . "</strong> berhasil diperbarui!");
                } else {
                    set_flash('danger', 'Gagal memperbarui mobil: ' . mysqli_error($koneksi));
                }
            }
        }
        header("Location: mobil.php");
        exit();
    }
}

// Filter Kategori Mobil
$kat_filter = $_GET['kat'] ?? 'all';
$where = ($kat_filter !== 'all' && !empty($kat_filter)) ? "WHERE kategori = '" . mysqli_real_escape_string($koneksi, $kat_filter) . "'" : "";

$mobil_list = mysqli_query($koneksi, "SELECT * FROM mobil $where ORDER BY id_mobil ASC");

// Total armada stats
$total_mobil = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM mobil"))['jml'] ?? 0;
$mobil_tersedia = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM mobil WHERE status_mobil = 'Tersedia'"))['jml'] ?? 0;
$mobil_disewa = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM mobil WHERE status_mobil = 'Disewa'"))['jml'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kelola Armada Mobil - Nearental Admin</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #2563eb;
            --bg-light: #f8fafc;
            --card-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -2px rgba(0, 0, 0, 0.05);
        }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-light);
            color: #1e293b;
        }
        .navbar {
            background: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .main-card {
            background: #ffffff;
            border-radius: 1rem;
            border: 1px solid #e2e8f0;
            box-shadow: var(--card-shadow);
            overflow: hidden;
        }
        .car-thumb {
            width: 80px;
            height: 55px;
            object-fit: cover;
            border-radius: 0.5rem;
            border: 1px solid #e2e8f0;
        }
        .badge-tersedia { background-color: #dcfce7; color: #166534; }
        .badge-disewa { background-color: #dbeafe; color: #1e40af; }
        .badge-perawatan { background-color: #fee2e2; color: #991b1b; }
        .nav-pills .nav-link {
            border-radius: 0.75rem;
            font-weight: 600;
            color: #475569;
            padding: 0.5rem 1rem;
        }
        .nav-pills .nav-link.active {
            background-color: var(--primary);
            color: #ffffff;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container-fluid px-lg-4">
        <a class="navbar-brand d-flex align-items-center fw-bold text-primary" href="homeadmin.php">
            <i class="fa-solid fa-car-side fs-4 me-2"></i>
            <span>Nearental Admin</span>
        </a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="adminNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3">
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-secondary" href="homeadmin.php">
                        <i class="fa-solid fa-list-check me-1"></i> Pemesanan
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active fw-semibold text-primary" href="mobil.php">
                        <i class="fa-solid fa-car me-1"></i> Kelola Mobil (<?= $total_mobil ?>)
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-secondary" href="admin_kelola.php">
                        <i class="fa-solid fa-users-gear me-1"></i> Admin & Akun
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-secondary" href="../index.php" target="_blank">
                        <i class="fa-solid fa-arrow-up-right-from-square me-1"></i> Lihat Website
                    </a>
                </li>
            </ul>

            <div class="d-flex align-items-center gap-3">
                <div class="dropdown">
                    <button class="btn btn-light rounded-pill border dropdown-toggle d-flex align-items-center px-3 py-1" type="button" data-bs-toggle="dropdown">
                        <i class="fa-solid fa-circle-user fs-5 text-primary me-2"></i>
                        <span class="small fw-semibold"><?= htmlspecialchars($_SESSION['nama_admin'] ?? 'Admin') ?></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 rounded-3 mt-2">
                        <li><a class="dropdown-item py-2" href="admin_kelola.php"><i class="fa-solid fa-user-pen me-2 text-muted"></i> Profil & Password</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item py-2 text-danger" href="logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i> Keluar</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="container-fluid px-lg-4 py-4">
    <!-- Flash Messages -->
    <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show d-flex align-items-center shadow-sm mb-4" role="alert">
            <i class="fa-solid <?= $flash['type'] === 'success' ? 'fa-circle-check' : 'fa-triangle-exclamation' ?> fs-5 me-2"></i>
            <div><?= $flash['message'] ?></div>
            <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Title & Action -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <h3 class="fw-bold mb-1">Daftar Armada Mobil</h3>
            <p class="text-muted mb-0 small">Kelola ketersediaan armada, spesifikasi, dan tarif rental mobil harian, mingguan, serta bulanan.</p>
        </div>
        <div>
            <button type="button" class="btn btn-primary rounded-3" data-bs-toggle="modal" data-bs-target="#addMobilModal">
                <i class="fa-solid fa-plus me-1"></i> Tambah Mobil Baru
            </button>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-card">
        <div class="p-3 border-bottom bg-light d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
            <!-- Filter Kategori -->
            <ul class="nav nav-pills gap-1">
                <li class="nav-item">
                    <a class="nav-link <?= $kat_filter == 'all' ? 'active' : '' ?>" href="mobil.php">Semua Mobil (<?= $total_mobil ?>)</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $kat_filter == 'Sedan' ? 'active' : '' ?>" href="mobil.php?kat=Sedan">Sedan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $kat_filter == 'Hatchback' ? 'active' : '' ?>" href="mobil.php?kat=Hatchback">Hatchback</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $kat_filter == 'Minivan' ? 'active' : '' ?>" href="mobil.php?kat=Minivan">Minivan</a>
                </li>
            </ul>

            <div class="d-flex gap-2">
                <span class="badge bg-success-subtle text-success py-2 px-3 rounded-pill small">
                    <i class="fa-solid fa-circle-check me-1"></i> Tersedia: <?= $mobil_tersedia ?>
                </span>
                <span class="badge bg-primary-subtle text-primary py-2 px-3 rounded-pill small">
                    <i class="fa-solid fa-car-side me-1"></i> Disewa: <?= $mobil_disewa ?>
                </span>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light text-secondary text-uppercase small" style="font-size: 0.75rem;">
                    <tr>
                        <th class="ps-3">Mobil</th>
                        <th>Kategori</th>
                        <th>Tarif Sewa (Hari / Minggu / Bulan)</th>
                        <th>Spesifikasi</th>
                        <th>Status</th>
                        <th class="text-end pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if ($mobil_list && mysqli_num_rows($mobil_list) > 0):
                        while ($car = mysqli_fetch_assoc($mobil_list)):
                            $badge_stat = 'badge-tersedia';
                            if ($car['status_mobil'] === 'Disewa') $badge_stat = 'badge-disewa';
                            if ($car['status_mobil'] === 'Perawatan') $badge_stat = 'badge-perawatan';

                            // Determine image path
                            $img_src = '../' . $car['gambar'];
                            if (!file_exists($img_src) && !file_exists('../' . ltrim($car['gambar'], '/'))) {
                                $img_src = '../img/header.jpg';
                            }
                    ?>
                    <tr>
                        <td class="ps-3">
                            <div class="d-flex align-items-center">
                                <img src="<?= htmlspecialchars($img_src) ?>" alt="<?= htmlspecialchars($car['nama_mobil']) ?>" class="car-thumb me-3">
                                <div>
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($car['nama_mobil']) ?></div>
                                    <div class="small text-muted" style="max-width: 250px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                        <?= htmlspecialchars($car['deskripsi'] ?? '') ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge bg-light text-dark border"><?= htmlspecialchars($car['kategori']) ?></span>
                        </td>
                        <td>
                            <div class="fw-bold text-primary"><?= rupiah($car['harga_harian']) ?> <small class="text-muted fw-normal">/hari</small></div>
                            <div class="small text-muted">
                                <span>Minggu: <?= rupiah($car['harga_mingguan']) ?></span> | 
                                <span>Bulan: <?= rupiah($car['harga_bulanan']) ?></span>
                            </div>
                        </td>
                        <td>
                            <div class="small text-secondary">
                                <div><i class="fa-solid fa-users me-1 text-muted"></i> <?= htmlspecialchars($car['muatan']) ?></div>
                                <div><i class="fa-solid fa-gear me-1 text-muted"></i> <?= htmlspecialchars($car['transmisi']) ?></div>
                                <div><i class="fa-solid fa-gas-pump me-1 text-muted"></i> <?= htmlspecialchars($car['bahan_bakar']) ?></div>
                            </div>
                        </td>
                        <td>
                            <span class="badge rounded-pill <?= $badge_stat ?> px-3 py-2 small"><?= htmlspecialchars($car['status_mobil']) ?></span>
                        </td>
                        <td class="text-end pe-3">
                            <div class="btn-group btn-group-sm">
                                <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editMobilModal<?= $car['id_mobil'] ?>" title="Edit Mobil">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </button>
                                <a href="hapus.php?type=mobil&id=<?= $car['id_mobil'] ?>" class="btn btn-outline-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus mobil ini dari armada?');" title="Hapus Mobil">
                                    <i class="fa-solid fa-trash-can"></i>
                                </a>
                            </div>

                            <!-- Modal Edit Mobil -->
                            <div class="modal fade text-start" id="editMobilModal<?= $car['id_mobil'] ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-lg modal-dialog-centered">
                                    <div class="modal-content rounded-4 border-0 shadow">
                                        <form action="mobil.php" method="POST" enctype="multipart/form-data">
                                            <input type="hidden" name="action_type" value="edit">
                                            <input type="hidden" name="id_mobil" value="<?= $car['id_mobil'] ?>">
                                            <input type="hidden" name="gambar_lama" value="<?= htmlspecialchars($car['gambar']) ?>">
                                            
                                            <div class="modal-header border-bottom bg-light">
                                                <h5 class="modal-title fw-bold">Edit Mobil - <?= htmlspecialchars($car['nama_mobil']) ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body p-4">
                                                <div class="row g-3">
                                                    <div class="col-md-8">
                                                        <label class="form-label small fw-semibold">Nama Mobil</label>
                                                        <input type="text" name="nama_mobil" class="form-control" value="<?= htmlspecialchars($car['nama_mobil']) ?>" required>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="form-label small fw-semibold">Kategori</label>
                                                        <select name="kategori" class="form-select" required>
                                                            <option value="Sedan" <?= $car['kategori'] === 'Sedan' ? 'selected' : '' ?>>Sedan</option>
                                                            <option value="Hatchback" <?= $car['kategori'] === 'Hatchback' ? 'selected' : '' ?>>Hatchback</option>
                                                            <option value="Minivan" <?= $car['kategori'] === 'Minivan' ? 'selected' : '' ?>>Minivan</option>
                                                            <option value="SUV" <?= $car['kategori'] === 'SUV' ? 'selected' : '' ?>>SUV</option>
                                                        </select>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <label class="form-label small fw-semibold">Harga Harian (Rp)</label>
                                                        <input type="number" name="harga_harian" class="form-control" value="<?= (int)$car['harga_harian'] ?>" required>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="form-label small fw-semibold">Harga Mingguan (Rp)</label>
                                                        <input type="number" name="harga_mingguan" class="form-control" value="<?= (int)$car['harga_mingguan'] ?>" required>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <label class="form-label small fw-semibold">Harga Bulanan (Rp)</label>
                                                        <input type="number" name="harga_bulanan" class="form-control" value="<?= (int)$car['harga_bulanan'] ?>" required>
                                                    </div>

                                                    <div class="col-md-3">
                                                        <label class="form-label small fw-semibold">Kapasitas Muatan</label>
                                                        <input type="text" name="muatan" class="form-control" value="<?= htmlspecialchars($car['muatan']) ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label small fw-semibold">Transmisi</label>
                                                        <input type="text" name="transmisi" class="form-control" value="<?= htmlspecialchars($car['transmisi']) ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label small fw-semibold">Bahan Bakar</label>
                                                        <input type="text" name="bahan_bakar" class="form-control" value="<?= htmlspecialchars($car['bahan_bakar']) ?>">
                                                    </div>
                                                    <div class="col-md-3">
                                                        <label class="form-label small fw-semibold">Tipe AC</label>
                                                        <input type="text" name="ac" class="form-control" value="<?= htmlspecialchars($car['ac']) ?>">
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label class="form-label small fw-semibold">Status Ketersediaan</label>
                                                        <select name="status_mobil" class="form-select">
                                                            <option value="Tersedia" <?= $car['status_mobil'] === 'Tersedia' ? 'selected' : '' ?>>Tersedia (Ready)</option>
                                                            <option value="Disewa" <?= $car['status_mobil'] === 'Disewa' ? 'selected' : '' ?>>Sedang Disewa</option>
                                                            <option value="Perawatan" <?= $car['status_mobil'] === 'Perawatan' ? 'selected' : '' ?>>Perawatan / Bengkel</option>
                                                        </select>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <label class="form-label small fw-semibold">Ganti Foto Mobil (Opsional)</label>
                                                        <input type="file" name="gambar_file" class="form-control" accept="image/*">
                                                        <div class="form-text small">Foto saat ini: <?= htmlspecialchars($car['gambar']) ?></div>
                                                    </div>

                                                    <div class="col-12">
                                                        <label class="form-label small fw-semibold">Deskripsi Singkat</label>
                                                        <textarea name="deskripsi" class="form-control" rows="2"><?= htmlspecialchars($car['deskripsi'] ?? '') ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer bg-light border-top">
                                                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan Perubahan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php 
                        endwhile;
                    else:
                    ?>
                    <tr>
                        <td colspan="6" class="text-center py-5 text-muted">
                            <i class="fa-solid fa-car fs-1 mb-2 text-secondary-subtle"></i>
                            <p class="mb-0">Tidak ada data mobil.</p>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Tambah Mobil Baru -->
<div class="modal fade" id="addMobilModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <form action="mobil.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action_type" value="add">
                
                <div class="modal-header border-bottom bg-light">
                    <h5 class="modal-title fw-bold"><i class="fa-solid fa-plus text-primary me-2"></i> Tambah Mobil Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label small fw-semibold">Nama Mobil <span class="text-danger">*</span></label>
                            <input type="text" name="nama_mobil" class="form-control" placeholder="Contoh: Mitsubishi Xpander Ultimate" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold">Kategori <span class="text-danger">*</span></label>
                            <select name="kategori" class="form-select" required>
                                <option value="Sedan">Sedan</option>
                                <option value="Hatchback">Hatchback</option>
                                <option value="Minivan" selected>Minivan / MPV</option>
                                <option value="SUV">SUV</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label small fw-semibold">Harga Sewa Harian (Rp) <span class="text-danger">*</span></label>
                            <input type="number" name="harga_harian" class="form-control" placeholder="350000" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold">Harga Sewa Mingguan (Rp)</label>
                            <input type="number" name="harga_mingguan" class="form-control" placeholder="2100000">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold">Harga Sewa Bulanan (Rp)</label>
                            <input type="number" name="harga_bulanan" class="form-control" placeholder="5200000">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label small fw-semibold">Kapasitas Muatan</label>
                            <input type="text" name="muatan" class="form-control" value="6-7 Penumpang">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-semibold">Transmisi</label>
                            <input type="text" name="transmisi" class="form-control" value="Manual & Matic">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-semibold">Bahan Bakar</label>
                            <input type="text" name="bahan_bakar" class="form-control" value="Bensin">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small fw-semibold">Tipe AC</label>
                            <input type="text" name="ac" class="form-control" value="Double Blower">
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Status Ketersediaan</label>
                            <select name="status_mobil" class="form-select">
                                <option value="Tersedia" selected>Tersedia (Ready)</option>
                                <option value="Disewa">Sedang Disewa</option>
                                <option value="Perawatan">Perawatan / Bengkel</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label small fw-semibold">Upload Foto Mobil</label>
                            <input type="file" name="gambar_file" class="form-control" accept="image/*">
                        </div>

                        <div class="col-12">
                            <label class="form-label small fw-semibold">Deskripsi Singkat Mobil</label>
                            <textarea name="deskripsi" class="form-control" rows="2" placeholder="Deskripsi fitur unggulan kendaraan..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light border-top">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus me-1"></i> Simpan Mobil</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
