<?php
require_once "config/koneksi.php";
check_admin_auth();

$flash = get_flash();

// Filter Status & Pencarian
$filter_status = $_GET['status'] ?? '';
$search = trim($_GET['search'] ?? '');

$where_clauses = [];
$params = [];
$types = "";

if (!empty($filter_status) && $filter_status !== 'all') {
    $where_clauses[] = "p.status = ?";
    $params[] = $filter_status;
    $types .= "s";
}

if (!empty($search)) {
    $where_clauses[] = "(p.kode_booking LIKE ? OR p.nama_pelanggan LIKE ? OR p.no_tlp LIKE ? OR p.no_ktp LIKE ? OR p.pilih_mobil LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "sssss";
}

$where_sql = count($where_clauses) > 0 ? "WHERE " . implode(" AND ", $where_clauses) : "";

// Query Data Pemesanan
$sql = "SELECT p.*, m.gambar as gambar_mobil FROM pemesanan p LEFT JOIN mobil m ON p.pilih_mobil = m.nama_mobil $where_sql ORDER BY p.id_pesan DESC";

if (count($params) > 0) {
    $stmt = mysqli_prepare($koneksi, $sql);
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    $result = mysqli_query($koneksi, $sql);
}

// Statistik KPI
$stats = [
    'total' => 0,
    'pending' => 0,
    'pinjam' => 0,
    'selesai' => 0,
    'batal' => 0,
    'pendapatan' => 0
];

$stat_query = mysqli_query($koneksi, "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'Menunggu Konfirmasi' OR status = 'Belum Pinjam' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN status = 'Pinjam' THEN 1 ELSE 0 END) as pinjam,
    SUM(CASE WHEN status = 'Selesai' THEN 1 ELSE 0 END) as selesai,
    SUM(CASE WHEN status = 'Dibatalkan' THEN 1 ELSE 0 END) as batal,
    SUM(CASE WHEN status != 'Dibatalkan' THEN total_biaya ELSE 0 END) as pendapatan
FROM pemesanan");

if ($row_stat = mysqli_fetch_assoc($stat_query)) {
    $stats = $row_stat;
}

$total_mobil = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM mobil"))['jml'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Admin - Nearental Mobil Bandung</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary: #64748b;
            --bg-light: #f8fafc;
            --card-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -2px rgba(0, 0, 0, 0.05);
        }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-light);
            color: #1e293b;
        }
        .navbar {
            background: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .stat-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 1rem;
            padding: 1.5rem;
            box-shadow: var(--card-shadow);
            transition: all 0.2s ease;
        }
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.08);
        }
        .stat-icon {
            width: 52px;
            height: 52px;
            border-radius: 0.85rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
        }
        .main-card {
            background: #ffffff;
            border-radius: 1rem;
            border: 1px solid #e2e8f0;
            box-shadow: var(--card-shadow);
            overflow: hidden;
        }
        .table > :not(caption) > * > * {
            padding: 1rem 1rem;
            vertical-align: middle;
        }
        .badge-status {
            padding: 0.45rem 0.75rem;
            border-radius: 2rem;
            font-size: 0.78rem;
            font-weight: 600;
            letter-spacing: 0.3px;
        }
        .status-pending { background-color: #fef3c7; color: #92400e; }
        .status-pinjam { background-color: #dbeafe; color: #1e40af; }
        .status-selesai { background-color: #dcfce7; color: #166534; }
        .status-batal { background-color: #fee2e2; color: #991b1b; }
        .nav-pills .nav-link {
            border-radius: 0.75rem;
            font-weight: 600;
            color: #475569;
            padding: 0.6rem 1rem;
        }
        .nav-pills .nav-link.active {
            background-color: var(--primary);
            color: #ffffff;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container-fluid px-lg-4">
        <a class="navbar-brand d-flex align-items-center fw-bold text-primary" href="homeadmin.php">
            <i class="fa-solid fa-car-side fs-4 me-2"></i>
            <span>Nearental Admin</span>
        </a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="adminNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3">
                <li class="nav-item">
                    <a class="nav-link active fw-semibold text-primary" href="homeadmin.php">
                        <i class="fa-solid fa-list-check me-1"></i> Pemesanan
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-secondary" href="mobil.php">
                        <i class="fa-solid fa-car me-1"></i> Kelola Mobil (<?= $total_mobil ?>)
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-secondary" href="admin_kelola.php">
                        <i class="fa-solid fa-users-gear me-1"></i> Admin & Akun
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-secondary" href="../index.php" target="_blank">
                        <i class="fa-solid fa-arrow-up-right-from-square me-1"></i> Lihat Website
                    </a>
                </li>
            </ul>

            <div class="d-flex align-items-center gap-3">
                <div class="dropdown">
                    <button class="btn btn-light rounded-pill border dropdown-toggle d-flex align-items-center px-3 py-1" type="button" data-bs-toggle="dropdown">
                        <i class="fa-solid fa-circle-user fs-5 text-primary me-2"></i>
                        <span class="small fw-semibold"><?= htmlspecialchars($_SESSION['nama_admin'] ?? 'Admin') ?></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 rounded-3 mt-2">
                        <li><a class="dropdown-item py-2" href="admin_kelola.php"><i class="fa-solid fa-user-pen me-2 text-muted"></i> Profil & Password</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item py-2 text-danger" href="logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i> Keluar</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="container-fluid px-lg-4 py-4">
    <!-- Flash Messages -->
    <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show d-flex align-items-center shadow-sm mb-4" role="alert">
            <i class="fa-solid <?= $flash['type'] === 'success' ? 'fa-circle-check' : 'fa-triangle-exclamation' ?> fs-5 me-2"></i>
            <div><?= htmlspecialchars($flash['message']) ?></div>
            <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Welcome & Quick Stats -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <h3 class="fw-bold mb-1">Manajemen Pemesanan Rental</h3>
            <p class="text-muted mb-0 small">Pantau status penyewaan kendaraan, konfirmasi pesanan pelanggan, dan rekap omset.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="cetak_laporan.php" target="_blank" class="btn btn-outline-secondary rounded-3">
                <i class="fa-solid fa-print me-1"></i> Cetak Rekap
            </a>
            <a href="mobil.php" class="btn btn-primary rounded-3">
                <i class="fa-solid fa-plus me-1"></i> Tambah Mobil
            </a>
        </div>
    </div>

    <!-- Stat Cards -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
            <div class="stat-card d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-muted small fw-medium">Total Pemesanan</span>
                    <h3 class="fw-bold mb-0 mt-1"><?= number_format($stats['total']) ?></h3>
                </div>
                <div class="stat-icon bg-primary-subtle text-primary">
                    <i class="fa-solid fa-receipt"></i>
                </div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="stat-card d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-muted small fw-medium">Menunggu Konfirmasi</span>
                    <h3 class="fw-bold mb-0 mt-1 text-warning"><?= number_format($stats['pending']) ?></h3>
                </div>
                <div class="stat-icon bg-warning-subtle text-warning">
                    <i class="fa-solid fa-clock"></i>
                </div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="stat-card d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-muted small fw-medium">Sedang Dipinjam</span>
                    <h3 class="fw-bold mb-0 mt-1 text-primary"><?= number_format($stats['pinjam']) ?></h3>
                </div>
                <div class="stat-icon bg-info-subtle text-info">
                    <i class="fa-solid fa-car-side"></i>
                </div>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="stat-card d-flex align-items-center justify-content-between">
                <div>
                    <span class="text-muted small fw-medium">Total Pendapatan</span>
                    <h4 class="fw-bold mb-0 mt-1 text-success"><?= rupiah($stats['pendapatan']) ?></h4>
                </div>
                <div class="stat-icon bg-success-subtle text-success">
                    <i class="fa-solid fa-money-bill-wave"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter & Data Table -->
    <div class="main-card">
        <div class="p-3 border-bottom bg-light d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
            <!-- Filter Tabs -->
            <ul class="nav nav-pills gap-1">
                <li class="nav-item">
                    <a class="nav-link <?= empty($filter_status) || $filter_status == 'all' ? 'active' : '' ?>" href="homeadmin.php?search=<?= urlencode($search) ?>">Semua (<?= $stats['total'] ?>)</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $filter_status == 'Menunggu Konfirmasi' || $filter_status == 'Belum Pinjam' ? 'active' : '' ?>" href="homeadmin.php?status=Menunggu+Konfirmasi&search=<?= urlencode($search) ?>">Pending (<?= $stats['pending'] ?>)</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $filter_status == 'Pinjam' ? 'active' : '' ?>" href="homeadmin.php?status=Pinjam&search=<?= urlencode($search) ?>">Dipinjam (<?= $stats['pinjam'] ?>)</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $filter_status == 'Selesai' ? 'active' : '' ?>" href="homeadmin.php?status=Selesai&search=<?= urlencode($search) ?>">Selesai (<?= $stats['selesai'] ?>)</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $filter_status == 'Dibatalkan' ? 'active' : '' ?>" href="homeadmin.php?status=Dibatalkan&search=<?= urlencode($search) ?>">Batal (<?= $stats['batal'] ?>)</a>
                </li>
            </ul>

            <!-- Search Form -->
            <form action="homeadmin.php" method="GET" class="d-flex gap-2">
                <?php if (!empty($filter_status)): ?>
                    <input type="hidden" name="status" value="<?= htmlspecialchars($filter_status) ?>">
                <?php endif; ?>
                <div class="input-group">
                    <input type="text" name="search" class="form-control form-control-sm" placeholder="Cari kode/nama/mobil..." value="<?= htmlspecialchars($search) ?>">
                    <button class="btn btn-outline-primary btn-sm" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                    <?php if (!empty($search)): ?>
                        <a href="homeadmin.php<?= !empty($filter_status) ? '?status=' . urlencode($filter_status) : '' ?>" class="btn btn-outline-secondary btn-sm"><i class="fa-solid fa-xmark"></i></a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light text-secondary text-uppercase small" style="font-size: 0.75rem; letter-spacing: 0.5px;">
                    <tr>
                        <th class="ps-3">No</th>
                        <th>Kode / Tgl Pesan</th>
                        <th>Pelanggan</th>
                        <th>Mobil & Opsi</th>
                        <th>Jadwal Sewa</th>
                        <th>Total Biaya</th>
                        <th>Status</th>
                        <th class="text-end pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 0;
                    if ($result && mysqli_num_rows($result) > 0):
                        while ($row = mysqli_fetch_assoc($result)):
                            $no++;
                            $status = $row['status'];
                            $badge_class = 'status-pending';
                            $status_label = 'Menunggu Konfirmasi';

                            if ($status === 'Pinjam') {
                                $badge_class = 'status-pinjam';
                                $status_label = 'Sedang Dipinjam';
                            } elseif ($status === 'Selesai') {
                                $badge_class = 'status-selesai';
                                $status_label = 'Selesai / Dikembalikan';
                            } elseif ($status === 'Dibatalkan') {
                                $badge_class = 'status-batal';
                                $status_label = 'Dibatalkan';
                            } elseif ($status === 'Belum Pinjam') {
                                $badge_class = 'status-pending';
                                $status_label = 'Menunggu Konfirmasi';
                            }

                            // WhatsApp Clean Phone
                            $wa_phone = preg_replace('/[^0-9]/', '', $row['no_tlp']);
                            if (substr($wa_phone, 0, 1) === '0') {
                                $wa_phone = '62' . substr($wa_phone, 1);
                            }
                    ?>
                    <tr>
                        <td class="ps-3 text-muted small fw-semibold"><?= $no ?></td>
                        <td>
                            <div class="fw-bold text-primary"><?= htmlspecialchars($row['kode_booking'] ?? ('NR-'.str_pad($row['id_pesan'], 4, '0', STR_PAD_LEFT))) ?></div>
                            <div class="text-muted" style="font-size: 0.78rem;">
                                <i class="fa-regular fa-calendar-days me-1"></i><?= date('d/m/Y H:i', strtotime($row['created_at'] ?? 'now')) ?>
                            </div>
                        </td>
                        <td>
                            <div class="fw-semibold text-dark"><?= htmlspecialchars($row['nama_pelanggan']) ?></div>
                            <div class="small text-muted">
                                <a href="https://wa.me/<?= $wa_phone ?>" target="_blank" class="text-success text-decoration-none me-2" title="Chat via WhatsApp">
                                    <i class="fa-brands fa-whatsapp"></i> <?= htmlspecialchars($row['no_tlp']) ?>
                                </a>
                            </div>
                            <div class="text-muted" style="font-size: 0.75rem;">NIK: <?= htmlspecialchars($row['no_ktp']) ?></div>
                        </td>
                        <td>
                            <div class="fw-semibold"><?= htmlspecialchars($row['pilih_mobil']) ?></div>
                            <div class="badge bg-secondary-subtle text-secondary small py-1 px-2" style="font-size: 0.72rem;">
                                <?= htmlspecialchars($row['opsi_driver'] ?? 'Lepas Kunci') ?>
                            </div>
                        </td>
                        <td>
                            <div class="small">
                                <span class="fw-medium text-success"><i class="fa-solid fa-arrow-right-from-bracket me-1"></i><?= date('d M Y', strtotime($row['tgl_pinjam'])) ?></span>
                                <br>
                                <span class="fw-medium text-danger"><i class="fa-solid fa-arrow-right-to-bracket me-1"></i><?= date('d M Y', strtotime($row['tgl_kembali'])) ?></span>
                            </div>
                            <span class="badge bg-light text-dark border small mt-1"><?= $row['durasi_hari'] ?> Hari</span>
                        </td>
                        <td>
                            <div class="fw-bold text-dark"><?= rupiah($row['total_biaya']) ?></div>
                        </td>
                        <td>
                            <span class="badge badge-status <?= $badge_class ?>"><?= $status_label ?></span>
                        </td>
                        <td class="text-end pe-3">
                            <div class="btn-group btn-group-sm">
                                <!-- Detail Modal Button -->
                                <button type="button" class="btn btn-outline-info" data-bs-toggle="modal" data-bs-target="#detailModal<?= $row['id_pesan'] ?>" title="Lihat Detail">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                                
                                <!-- Status Changer Dropdown -->
                                <button type="button" class="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown" title="Ubah Status">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                                    <li><h6 class="dropdown-header">Ubah Status Pemesanan</h6></li>
                                    <li>
                                        <a class="dropdown-item text-primary" href="aksi.php?act=set_status&status=Pinjam&id=<?= $row['id_pesan'] ?>">
                                            <i class="fa-solid fa-key me-2"></i> Konfirmasi & Pinjamkan
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item text-success" href="aksi.php?act=set_status&status=Selesai&id=<?= $row['id_pesan'] ?>">
                                            <i class="fa-solid fa-circle-check me-2"></i> Selesai / Dikembalikan
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item text-warning" href="aksi.php?act=set_status&status=Menunggu+Konfirmasi&id=<?= $row['id_pesan'] ?>">
                                            <i class="fa-solid fa-clock me-2"></i> Menunggu Konfirmasi
                                        </a>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <a class="dropdown-item text-danger" href="aksi.php?act=set_status&status=Dibatalkan&id=<?= $row['id_pesan'] ?>" onclick="return confirm('Yakin ingin membatalkan pemesanan ini?');">
                                            <i class="fa-solid fa-ban me-2"></i> Batalkan Pemesanan
                                        </a>
                                    </li>
                                </ul>

                                <!-- Print Invoice -->
                                <a href="../invoice.php?kode=<?= urlencode($row['kode_booking']) ?>" target="_blank" class="btn btn-outline-secondary" title="Cetak Bukti Booking">
                                    <i class="fa-solid fa-print"></i>
                                </a>

                                <!-- Delete -->
                                <a href="hapus.php?id=<?= $row['id_pesan'] ?>" class="btn btn-outline-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data pemesanan ini? Data yang dihapus tidak dapat dikembalikan.');" title="Hapus">
                                    <i class="fa-solid fa-trash-can"></i>
                                </a>
                            </div>

                            <!-- Modal Detail -->
                            <div class="modal fade text-start" id="detailModal<?= $row['id_pesan'] ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content rounded-4 border-0 shadow">
                                        <div class="modal-header border-bottom bg-light">
                                            <h5 class="modal-title fw-bold">
                                                <i class="fa-solid fa-file-invoice text-primary me-2"></i>
                                                Detail Pemesanan <?= htmlspecialchars($row['kode_booking']) ?>
                                            </h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body p-4">
                                            <div class="row g-3">
                                                <div class="col-6">
                                                    <small class="text-muted">Nama Pelanggan</small>
                                                    <div class="fw-bold"><?= htmlspecialchars($row['nama_pelanggan']) ?></div>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted">Nomor KTP (NIK)</small>
                                                    <div class="fw-semibold"><?= htmlspecialchars($row['no_ktp']) ?></div>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted">Email</small>
                                                    <div class="fw-semibold"><?= htmlspecialchars($row['email_pelanggan']) ?></div>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted">Nomor WhatsApp / HP</small>
                                                    <div class="fw-semibold"><?= htmlspecialchars($row['no_tlp']) ?></div>
                                                </div>
                                                <div class="col-12">
                                                    <small class="text-muted">Alamat Lengkap</small>
                                                    <div class="p-2 bg-light rounded-3 small"><?= nl2br(htmlspecialchars($row['alamat_pelanggan'])) ?></div>
                                                </div>
                                                <hr class="my-2">
                                                <div class="col-6">
                                                    <small class="text-muted">Mobil Pilihan</small>
                                                    <div class="fw-bold text-primary"><?= htmlspecialchars($row['pilih_mobil']) ?></div>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted">Opsi Layanan</small>
                                                    <div class="fw-bold"><?= htmlspecialchars($row['opsi_driver'] ?? 'Lepas Kunci') ?></div>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted">Tanggal Mulai Sewa</small>
                                                    <div class="fw-semibold text-success"><?= tgl_indo($row['tgl_pinjam']) ?></div>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted">Tanggal Selesai Sewa</small>
                                                    <div class="fw-semibold text-danger"><?= tgl_indo($row['tgl_kembali']) ?></div>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted">Durasi Rental</small>
                                                    <div class="fw-bold"><?= $row['durasi_hari'] ?> Hari</div>
                                                </div>
                                                <div class="col-6">
                                                    <small class="text-muted">Total Pembayaran</small>
                                                    <div class="fw-bold text-success fs-5"><?= rupiah($row['total_biaya']) ?></div>
                                                </div>
                                                <?php if (!empty($row['catatan'])): ?>
                                                <div class="col-12">
                                                    <small class="text-muted">Catatan Pelanggan</small>
                                                    <div class="p-2 bg-light rounded-3 small text-muted"><?= nl2br(htmlspecialchars($row['catatan'])) ?></div>
                                                </div>
                                                <?php endif; ?>
                                                <div class="col-12">
                                                    <small class="text-muted">Status Saat Ini</small>
                                                    <div><span class="badge badge-status <?= $badge_class ?>"><?= $status_label ?></span></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer bg-light border-top">
                                            <a href="../invoice.php?kode=<?= urlencode($row['kode_booking']) ?>" target="_blank" class="btn btn-outline-primary btn-sm">
                                                <i class="fa-solid fa-print me-1"></i> Buka Bukti Booking
                                            </a>
                                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php 
                        endwhile;
                    else:
                    ?>
                    <tr>
                        <td colspan="8" class="text-center py-5">
                            <div class="text-muted">
                                <i class="fa-solid fa-folder-open fs-1 mb-3 text-secondary-subtle"></i>
                                <h5 class="fw-bold">Belum Ada Data Pemesanan</h5>
                                <p class="small mb-0">Tidak ditemukan data pemesanan yang sesuai dengan filter pencarian.</p>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
