<?php
// Koneksi Database & Helper Utilities untuk Nearental Mobil Bandung

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Konfigurasi Database
$dbHost = "localhost";
$dbUser = "root";
$dbPass = "";
$dbName = "db_rental";

// Inisialisasi Koneksi MySQLi
$koneksi = @mysqli_connect($dbHost, $dbUser, $dbPass, $dbName);

if (!$koneksi) {
    die("<div style='font-family:sans-serif;padding:30px;text-align:center;'>
        <h2 style='color:#e74c3c;'>Gagal Terkoneksi ke Database</h2>
        <p>Pastikan MySQL di XAMPP sudah berjalan dan database <code>$dbName</code> sudah dibuat.</p>
        <p><small>" . mysqli_connect_error() . "</small></p>
    </div>");
}

// Set Charset ke UTF-8
mysqli_set_charset($koneksi, "utf8mb4");

/**
 * Format Angka ke Rupiah
 */
function rupiah($angka) {
    return "Rp " . number_format((float)$angka, 0, ',', '.');
}

/**
 * Format Tanggal Indonesia (contoh: 01 September 2026)
 */
function tgl_indo($tanggal) {
    if (!$tanggal || $tanggal == '0000-00-00') return '-';
    $bulan = [
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    $pecahkan = explode('-', date('Y-m-d', strtotime($tanggal)));
    return (int)$pecahkan[2] . ' ' . $bulan[(int)$pecahkan[1]] . ' ' . $pecahkan[0];
}

/**
 * Generate Kode Booking Unik (contoh: NR-20260901-8X2A)
 */
function generate_kode_booking() {
    $prefix = "NR-" . date("Ymd") . "-";
    $random = strtoupper(substr(bin2hex(random_bytes(3)), 0, 4));
    return $prefix . $random;
}

/**
 * Sanitasi Input String
 */
function sanitize($koneksi, $data) {
    if (is_array($data)) {
        return array_map(function($item) use ($koneksi) {
            return sanitize($koneksi, $item);
        }, $data);
    }
    return mysqli_real_escape_string($koneksi, trim(htmlspecialchars($data, ENT_QUOTES, 'UTF-8')));
}

/**
 * Flash Message Handler
 */
function set_flash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

function get_flash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Cek Autentikasi Admin
 */
function check_admin_auth() {
    if (!isset($_SESSION['id_admin']) || empty($_SESSION['id_admin'])) {
        set_flash('danger', 'Silakan login terlebih dahulu untuk mengakses halaman admin.');
        header("Location: index.php");
        exit();
    }
}
?>