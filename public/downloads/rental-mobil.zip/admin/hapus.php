<?php
require_once "config/koneksi.php";
check_admin_auth();

$idpesan = (int)($_GET['id'] ?? 0);
$type = $_GET['type'] ?? 'pesanan';

if ($type === 'mobil') {
    $idmobil = (int)($_GET['id'] ?? 0);
    if ($idmobil > 0) {
        $stmt = mysqli_prepare($koneksi, "DELETE FROM mobil WHERE id_mobil = ?");
        mysqli_stmt_bind_param($stmt, "i", $idmobil);
        mysqli_stmt_execute($stmt);
        set_flash('success', 'Mobil berhasil dihapus dari daftar armada.');
    } else {
        set_flash('danger', 'ID Mobil tidak valid.');
    }
    header("Location: mobil.php");
    exit();
}

if ($idpesan > 0) {
    $stmt = mysqli_prepare($koneksi, "DELETE FROM pemesanan WHERE id_pesan = ?");
    mysqli_stmt_bind_param($stmt, "i", $idpesan);
    mysqli_stmt_execute($stmt);

    set_flash('success', 'Data pemesanan berhasil dihapus.');
} else {
    set_flash('danger', 'ID Pemesanan tidak valid.');
}

header("Location: homeadmin.php");
exit();
?>