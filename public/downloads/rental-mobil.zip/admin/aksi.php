<?php
require_once "config/koneksi.php";
check_admin_auth();

$action = $_GET['act'] ?? '';

// Update Status Pemesanan
if ($action === 'set_status') {
    $id = (int)($_GET['id'] ?? 0);
    $status = $_GET['status'] ?? '';
    $allowed_status = ['Menunggu Konfirmasi', 'Pinjam', 'Selesai', 'Dibatalkan'];

    if ($id > 0 && in_array($status, $allowed_status)) {
        // Ambil data pemesanan terlebih dahulu
        $q_pesan = mysqli_query($koneksi, "SELECT pilih_mobil, status FROM pemesanan WHERE id_pesan = $id");
        if ($data_pesan = mysqli_fetch_assoc($q_pesan)) {
            $mobil_nama = $data_pesan['pilih_mobil'];

            // Update status pesanan
            $stmt = mysqli_prepare($koneksi, "UPDATE pemesanan SET status = ? WHERE id_pesan = ?");
            mysqli_stmt_bind_param($stmt, "si", $status, $id);
            mysqli_stmt_execute($stmt);

            // Sinkronisasi status mobil di tabel armada mobil
            if ($status === 'Pinjam') {
                $u_mobil = mysqli_prepare($koneksi, "UPDATE mobil SET status_mobil = 'Disewa' WHERE nama_mobil = ?");
                mysqli_stmt_bind_param($u_mobil, "s", $mobil_nama);
                mysqli_stmt_execute($u_mobil);
            } elseif ($status === 'Selesai' || $status === 'Dibatalkan') {
                $u_mobil = mysqli_prepare($koneksi, "UPDATE mobil SET status_mobil = 'Tersedia' WHERE nama_mobil = ?");
                mysqli_stmt_bind_param($u_mobil, "s", $mobil_nama);
                mysqli_stmt_execute($u_mobil);
            }

            set_flash('success', "Status pemesanan berhasil diperbarui menjadi: <strong>$status</strong>");
        } else {
            set_flash('danger', 'Data pemesanan tidak ditemukan.');
        }
    } else {
        set_flash('danger', 'Parameter status tidak valid.');
    }

    header("Location: homeadmin.php");
    exit();
}

header("Location: homeadmin.php");
exit();
?>
