<?php
require_once "config/koneksi.php";
check_admin_auth();

$flash = get_flash();

// Handle Tambah / Ganti Password Admin
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action_type = $_POST['action_type'] ?? '';

    if ($action_type === 'add') {
        $nama_admin = trim($_POST['nama_admin'] ?? '');
        $user_admin = trim($_POST['user_admin'] ?? '');
        $pass_admin = trim($_POST['pass_admin'] ?? '');

        if (empty($nama_admin) || empty($user_admin) || empty($pass_admin)) {
            set_flash('danger', 'Semua kolom wajib diisi!');
        } else {
            // Cek duplikasi username
            $cek = mysqli_prepare($koneksi, "SELECT id_admin FROM admin WHERE user_admin = ?");
            mysqli_stmt_bind_param($cek, "s", $user_admin);
            mysqli_stmt_execute($cek);
            $res = mysqli_stmt_get_result($cek);

            if (mysqli_num_rows($res) > 0) {
                set_flash('danger', 'Username <strong>' . htmlspecialchars($user_admin) . '</strong> sudah digunakan. Silakan gunakan username lain!');
            } else {
                $hash = password_hash($pass_admin, PASSWORD_DEFAULT);
                $stmt = mysqli_prepare($koneksi, "INSERT INTO admin (nama_admin, user_admin, pass_admin) VALUES (?, ?, ?)");
                mysqli_stmt_bind_param($stmt, "sss", $nama_admin, $user_admin, $hash);
                
                if (mysqli_stmt_execute($stmt)) {
                    set_flash('success', "Admin baru <strong>" . htmlspecialchars($nama_admin) . "</strong> berhasil ditambahkan!");
                } else {
                    set_flash('danger', 'Gagal menambahkan admin: ' . mysqli_error($koneksi));
                }
            }
        }
        header("Location: admin_kelola.php");
        exit();
    } elseif ($action_type === 'change_pass') {
        $id_admin = (int)($_POST['id_admin'] ?? 0);
        $new_pass = trim($_POST['new_pass'] ?? '');

        if ($id_admin > 0 && !empty($new_pass)) {
            $hash = password_hash($new_pass, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($koneksi, "UPDATE admin SET pass_admin = ? WHERE id_admin = ?");
            mysqli_stmt_bind_param($stmt, "si", $hash, $id_admin);
            
            if (mysqli_stmt_execute($stmt)) {
                set_flash('success', 'Password admin berhasil diperbarui!');
            } else {
                set_flash('danger', 'Gagal memperbarui password: ' . mysqli_error($koneksi));
            }
        } else {
            set_flash('danger', 'Password baru tidak boleh kosong.');
        }
        header("Location: admin_kelola.php");
        exit();
    }
}

// Handle Hapus Admin
if (isset($_GET['del'])) {
    $del_id = (int)$_GET['del'];
    $total_admins = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM admin"))['jml'] ?? 0;

    if ($total_admins <= 1) {
        set_flash('danger', 'Tidak dapat menghapus satu-satunya akun admin yang tersisa!');
    } elseif ($del_id == $_SESSION['id_admin']) {
        set_flash('danger', 'Anda tidak dapat menghapus akun Anda sendiri saat sedang login!');
    } else {
        $stmt = mysqli_prepare($koneksi, "DELETE FROM admin WHERE id_admin = ?");
        mysqli_stmt_bind_param($stmt, "i", $del_id);
        mysqli_stmt_execute($stmt);
        set_flash('success', 'Akun admin berhasil dihapus.');
    }
    header("Location: admin_kelola.php");
    exit();
}

$admins = mysqli_query($koneksi, "SELECT * FROM admin ORDER BY id_admin ASC");
$total_mobil = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM mobil"))['jml'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kelola Akun Admin - Nearental Admin</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #2563eb;
            --bg-light: #f8fafc;
            --card-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -2px rgba(0, 0, 0, 0.05);
        }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-light);
            color: #1e293b;
        }
        .navbar {
            background: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        .main-card {
            background: #ffffff;
            border-radius: 1rem;
            border: 1px solid #e2e8f0;
            box-shadow: var(--card-shadow);
            overflow: hidden;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container-fluid px-lg-4">
        <a class="navbar-brand d-flex align-items-center fw-bold text-primary" href="homeadmin.php">
            <i class="fa-solid fa-car-side fs-4 me-2"></i>
            <span>Nearental Admin</span>
        </a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#adminNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="adminNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3">
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-secondary" href="homeadmin.php">
                        <i class="fa-solid fa-list-check me-1"></i> Pemesanan
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-secondary" href="mobil.php">
                        <i class="fa-solid fa-car me-1"></i> Kelola Mobil (<?= $total_mobil ?>)
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active fw-semibold text-primary" href="admin_kelola.php">
                        <i class="fa-solid fa-users-gear me-1"></i> Admin & Akun
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-semibold text-secondary" href="../index.php" target="_blank">
                        <i class="fa-solid fa-arrow-up-right-from-square me-1"></i> Lihat Website
                    </a>
                </li>
            </ul>

            <div class="d-flex align-items-center gap-3">
                <div class="dropdown">
                    <button class="btn btn-light rounded-pill border dropdown-toggle d-flex align-items-center px-3 py-1" type="button" data-bs-toggle="dropdown">
                        <i class="fa-solid fa-circle-user fs-5 text-primary me-2"></i>
                        <span class="small fw-semibold"><?= htmlspecialchars($_SESSION['nama_admin'] ?? 'Admin') ?></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 rounded-3 mt-2">
                        <li><a class="dropdown-item py-2 text-danger" href="logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i> Keluar</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="container-fluid px-lg-4 py-4">
    <!-- Flash Messages -->
    <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show d-flex align-items-center shadow-sm mb-4" role="alert">
            <i class="fa-solid <?= $flash['type'] === 'success' ? 'fa-circle-check' : 'fa-triangle-exclamation' ?> fs-5 me-2"></i>
            <div><?= $flash['message'] ?></div>
            <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <h3 class="fw-bold mb-1">Manajemen Akun Pengelola / Admin</h3>
            <p class="text-muted mb-0 small">Atur hak akses staf dan perbarui kata sandi admin secara aman.</p>
        </div>
        <div>
            <button type="button" class="btn btn-primary rounded-3" data-bs-toggle="modal" data-bs-target="#addAdminModal">
                <i class="fa-solid fa-user-plus me-1"></i> Tambah Admin Baru
            </button>
        </div>
    </div>

    <div class="main-card">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light text-secondary text-uppercase small" style="font-size: 0.75rem;">
                    <tr>
                        <th class="ps-3">ID</th>
                        <th>Nama Pengelola</th>
                        <th>Username</th>
                        <th>Dibuat Pada</th>
                        <th class="text-end pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if ($admins && mysqli_num_rows($admins) > 0):
                        while ($adm = mysqli_fetch_assoc($admins)):
                    ?>
                    <tr>
                        <td class="ps-3 text-muted fw-semibold">#<?= $adm['id_admin'] ?></td>
                        <td>
                            <div class="fw-bold text-dark"><?= htmlspecialchars($adm['nama_admin']) ?></div>
                            <?php if ($adm['id_admin'] == $_SESSION['id_admin']): ?>
                                <span class="badge bg-success-subtle text-success small py-1 px-2">Akun Anda (Aktif)</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-light text-dark border font-monospace"><?= htmlspecialchars($adm['user_admin']) ?></span>
                        </td>
                        <td class="small text-muted">
                            <?= !empty($adm['created_at']) ? date('d M Y H:i', strtotime($adm['created_at'])) : '-' ?>
                        </td>
                        <td class="text-end pe-3">
                            <button type="button" class="btn btn-sm btn-outline-primary me-1" data-bs-toggle="modal" data-bs-target="#passModal<?= $adm['id_admin'] ?>" title="Ganti Password">
                                <i class="fa-solid fa-key me-1"></i> Ganti Password
                            </button>
                            <?php if ($adm['id_admin'] != $_SESSION['id_admin']): ?>
                                <a href="admin_kelola.php?del=<?= $adm['id_admin'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Yakin ingin menghapus admin ini?');" title="Hapus Admin">
                                    <i class="fa-solid fa-trash-can"></i>
                                </a>
                            <?php endif; ?>

                            <!-- Modal Ganti Password -->
                            <div class="modal fade text-start" id="passModal<?= $adm['id_admin'] ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered">
                                    <div class="modal-content rounded-4 border-0 shadow">
                                        <form action="admin_kelola.php" method="POST">
                                            <input type="hidden" name="action_type" value="change_pass">
                                            <input type="hidden" name="id_admin" value="<?= $adm['id_admin'] ?>">
                                            
                                            <div class="modal-header border-bottom bg-light">
                                                <h5 class="modal-title fw-bold">Ganti Password - <?= htmlspecialchars($adm['nama_admin']) ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body p-4">
                                                <div class="mb-3">
                                                    <label class="form-label small fw-semibold">Password Baru</label>
                                                    <input type="password" name="new_pass" class="form-control" placeholder="Masukkan password baru" required minlength="4">
                                                </div>
                                            </div>
                                            <div class="modal-footer bg-light border-top">
                                                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                                                <button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-check me-1"></i> Perbarui Password</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php 
                        endwhile;
                    endif; 
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Tambah Admin -->
<div class="modal fade" id="addAdminModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow">
            <form action="admin_kelola.php" method="POST">
                <input type="hidden" name="action_type" value="add">
                
                <div class="modal-header border-bottom bg-light">
                    <h5 class="modal-title fw-bold"><i class="fa-solid fa-user-plus text-primary me-2"></i> Tambah Admin Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Nama Lengkap Admin <span class="text-danger">*</span></label>
                        <input type="text" name="nama_admin" class="form-control" placeholder="Contoh: Budi Pratama" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Username <span class="text-danger">*</span></label>
                        <input type="text" name="user_admin" class="form-control" placeholder="Contoh: budi_admin" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Password <span class="text-danger">*</span></label>
                        <input type="password" name="pass_admin" class="form-control" placeholder="Password minimal 4 karakter" required minlength="4">
                    </div>
                </div>
                <div class="modal-footer bg-light border-top">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus me-1"></i> Simpan Admin</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
