<?php
header("Location: ../index.php?kategori=Sedan#armada");
exit();
?>
