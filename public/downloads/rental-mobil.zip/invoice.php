<?php
require_once "admin/config/koneksi.php";

$kode = trim($_GET['kode'] ?? '');

if (empty($kode)) {
    header("Location: index.php");
    exit();
}

$stmt = mysqli_prepare($koneksi, "SELECT p.*, m.gambar, m.kategori, m.transmisi, m.muatan 
    FROM pemesanan p 
    LEFT JOIN mobil m ON p.pilih_mobil = m.nama_mobil 
    WHERE p.kode_booking = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, "s", $kode);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$order = mysqli_fetch_assoc($res);

if (!$order) {
    die("<div style='font-family:sans-serif;text-align:center;padding:50px;'>
        <h3>Pemesanan Tidak Ditemukan</h3>
        <p>Kode booking <strong>" . htmlspecialchars($kode) . "</strong> tidak ditemukan dalam sistem kami.</p>
        <a href='index.php'>&larr; Kembali ke Beranda</a> | <a href='cek_booking.php'>Cari Pesanan Lain</a>
    </div>");
}

// WhatsApp Message Format
$wa_phone = "6285316472000";
$wa_msg = urlencode("Halo Admin Nearental Mobil Bandung,\n\nSaya ingin konfirmasi pesanan sewa mobil:\n- *Kode Booking*: {$order['kode_booking']}\n- *Nama*: {$order['nama_pelanggan']}\n- *Mobil*: {$order['pilih_mobil']}\n- *Layanan*: {$order['opsi_driver']}\n- *Tgl Sewa*: " . date('d/m/Y', strtotime($order['tgl_pinjam'])) . " s/d " . date('d/m/Y', strtotime($order['tgl_kembali'])) . " ({$order['durasi_hari']} Hari)\n- *Total Biaya*: " . rupiah($order['total_biaya']) . "\n\nMohon petunjuk untuk konfirmasi dan proses selanjutnya. Terima kasih.");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bukti Reservasi #<?= htmlspecialchars($order['kode_booking']) ?> - Nearental Mobil</title>
    
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #2563eb;
            --bg-light: #f8fafc;
        }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-light);
            color: #1e293b;
        }
        .invoice-card {
            background: #ffffff;
            border-radius: 1.25rem;
            border: 1px solid #e2e8f0;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }
        .invoice-header {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            color: #ffffff;
            padding: 2.5rem 2rem;
        }
        .bank-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 0.75rem;
            padding: 1rem;
        }
        @media print {
            .no-print { display: none !important; }
            body { background: #ffffff !important; }
            .invoice-card { border: none !important; box-shadow: none !important; }
            .invoice-header { background: #1e293b !important; -webkit-print-color-adjust: exact; }
        }
    </style>
</head>
<body class="py-4">

<div class="container py-3">
    <!-- Action buttons (No print) -->
    <div class="d-flex justify-content-between align-items-center mb-4 no-print">
        <a href="index.php" class="btn btn-outline-secondary rounded-pill btn-sm">
            <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Beranda
        </a>
        <div class="d-flex gap-2">
            <button onclick="window.print()" class="btn btn-outline-primary rounded-pill btn-sm">
                <i class="fa-solid fa-print me-1"></i> Cetak Bukti Booking
            </button>
            <a href="cek_booking.php" class="btn btn-primary rounded-pill btn-sm">
                <i class="fa-solid fa-search me-1"></i> Cek Status Pesanan
            </a>
        </div>
    </div>

    <!-- Main Invoice Card -->
    <div class="invoice-card mx-auto" style="max-width: 850px;">
        <!-- Header -->
        <div class="invoice-header">
            <div class="row align-items-center g-3">
                <div class="col-md-7">
                    <div class="d-flex align-items-center mb-2">
                        <i class="fa-solid fa-car-side fs-2 text-primary me-2" style="color: #60a5fa !important;"></i>
                        <h4 class="fw-extrabold mb-0">NEARENTAL MOBIL</h4>
                    </div>
                    <p class="text-white-50 small mb-0">Jl. Raya Rental No. 88, Kota Bandung | WA: +62 853-1647-2000</p>
                </div>
                <div class="col-md-5 text-md-end">
                    <span class="badge bg-primary px-3 py-2 rounded-pill fw-semibold mb-2">Bukti Reservasi</span>
                    <h5 class="fw-bold mb-0 text-warning font-monospace"><?= htmlspecialchars($order['kode_booking']) ?></h5>
                    <small class="text-white-50">Tgl Pesan: <?= date('d M Y, H:i', strtotime($order['created_at'] ?? 'now')) ?></small>
                </div>
            </div>
        </div>

        <div class="p-4 p-md-5">
            <!-- Alert Info -->
            <div class="alert alert-success d-flex align-items-center rounded-3 mb-4 no-print" role="alert">
                <i class="fa-solid fa-circle-check fs-4 me-3 text-success"></i>
                <div>
                    <strong>Pemesanan Berhasil Didaftarkan!</strong>
                    <div class="small">Silakan simpan <strong>Kode Booking</strong> Anda untuk memeriksa status pemesanan atau konfirmasi ke tim kami.</div>
                </div>
            </div>

            <!-- Customer & Rental Info -->
            <div class="row g-4 mb-4">
                <div class="col-md-6">
                    <h6 class="text-uppercase text-secondary fw-bold small mb-2" style="letter-spacing: 0.5px;">Data Pelanggan</h6>
                    <div class="bg-light p-3 rounded-3">
                        <table class="table table-sm table-borderless mb-0 small">
                            <tr>
                                <td class="text-muted" width="38%">Nama Lengkap:</td>
                                <td class="fw-bold"><?= htmlspecialchars($order['nama_pelanggan']) ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">No. KTP (NIK):</td>
                                <td class="fw-semibold"><?= htmlspecialchars($order['no_ktp']) ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">No. WhatsApp/HP:</td>
                                <td class="fw-semibold"><?= htmlspecialchars($order['no_tlp']) ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Alamat Email:</td>
                                <td><?= htmlspecialchars($order['email_pelanggan']) ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Alamat:</td>
                                <td><?= nl2br(htmlspecialchars($order['alamat_pelanggan'])) ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="col-md-6">
                    <h6 class="text-uppercase text-secondary fw-bold small mb-2" style="letter-spacing: 0.5px;">Detail Jadwal & Layanan</h6>
                    <div class="bg-light p-3 rounded-3">
                        <table class="table table-sm table-borderless mb-0 small">
                            <tr>
                                <td class="text-muted" width="40%">Unit Mobil:</td>
                                <td class="fw-bold text-primary"><?= htmlspecialchars($order['pilih_mobil']) ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Pilihan Layanan:</td>
                                <td class="fw-semibold"><?= htmlspecialchars($order['opsi_driver'] ?? 'Lepas Kunci') ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Tgl Mulai Pinjam:</td>
                                <td class="fw-bold text-success"><?= tgl_indo($order['tgl_pinjam']) ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Tgl Pengembalian:</td>
                                <td class="fw-bold text-danger"><?= tgl_indo($order['tgl_kembali']) ?></td>
                            </tr>
                            <tr>
                                <td class="text-muted">Durasi Sewa:</td>
                                <td class="fw-bold"><?= $order['durasi_hari'] ?> Hari</td>
                            </tr>
                            <tr>
                                <td class="text-muted">Status Pesanan:</td>
                                <td><span class="badge bg-warning text-dark"><?= htmlspecialchars($order['status']) ?></span></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Price Breakdown Table -->
            <div class="table-responsive mb-4">
                <table class="table table-bordered align-middle">
                    <thead class="table-light small text-secondary">
                        <tr>
                            <th>Deskripsi Item</th>
                            <th class="text-center">Durasi</th>
                            <th class="text-end">Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <div class="fw-bold"><?= htmlspecialchars($order['pilih_mobil']) ?></div>
                                <small class="text-muted">Layanan: <?= htmlspecialchars($order['opsi_driver'] ?? 'Lepas Kunci') ?></small>
                                <?php if (!empty($order['catatan'])): ?>
                                    <div class="small text-muted fst-italic mt-1">Catatan: <?= htmlspecialchars($order['catatan']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="text-center"><?= $order['durasi_hari'] ?> Hari</td>
                            <td class="text-end fw-bold"><?= rupiah($order['total_biaya']) ?></td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr class="table-light">
                            <td colspan="2" class="text-end fw-bold">TOTAL PEMBAYARAN:</td>
                            <td class="text-end fw-extrabold text-primary fs-5"><?= rupiah($order['total_biaya']) ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <!-- Payment & WhatsApp Confirmation Box -->
            <div class="row g-4 mb-4">
                <div class="col-md-6">
                    <h6 class="fw-bold text-dark mb-2"><i class="fa-solid fa-building-columns text-primary me-1"></i> Rekening Pembayaran Resmi</h6>
                    <div class="bank-card mb-2">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <span class="fw-bold text-dark">BCA (Bank Central Asia)</span>
                                <div class="font-monospace text-primary fw-bold fs-6">8870-1234-5678</div>
                                <small class="text-muted">a/n Nearental Mobil Bandung</small>
                            </div>
                            <i class="fa-regular fa-credit-card fs-3 text-secondary"></i>
                        </div>
                    </div>
                    <div class="bank-card">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <span class="fw-bold text-dark">Bank Mandiri</span>
                                <div class="font-monospace text-primary fw-bold fs-6">131-00-9876543-2</div>
                                <small class="text-muted">a/n Nearental Mobil Bandung</small>
                            </div>
                            <i class="fa-regular fa-credit-card fs-3 text-secondary"></i>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 d-flex flex-column justify-content-between">
                    <div class="bg-success-subtle p-3 rounded-3 mb-3 border border-success-subtle">
                        <h6 class="fw-bold text-success mb-1"><i class="fa-brands fa-whatsapp me-1"></i> Konfirmasi Instan via WhatsApp</h6>
                        <p class="small text-secondary mb-3">
                            Kirimkan kode booking ini ke Customer Service kami untuk konfirmasi ketersediaan unit dan jadwal pengantaran.
                        </p>
                        <a href="https://wa.me/<?= $wa_phone ?>?text=<?= $wa_msg ?>" target="_blank" class="btn btn-success w-100 fw-bold rounded-3 shadow-sm">
                            <i class="fa-brands fa-whatsapp me-2 fs-5"></i> Konfirmasi Sekarang via WA
                        </a>
                    </div>
                </div>
            </div>

            <!-- Terms & Note -->
            <div class="border-top pt-3 text-muted small">
                <strong>Ketentuan Pengambilan Unit:</strong>
                <ol class="mb-0 ps-3 mt-1">
                    <li>Harap membawa e-KTP dan SIM A asli pada saat serah terima unit kendaraan.</li>
                    <li>Pengembalian unit mobil melewati batas waktu sewa akan dikenakan biaya overtime per jam.</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
