<?php
// Forward ke proses_pesan.php
require_once "proses_pesan.php";
?>
