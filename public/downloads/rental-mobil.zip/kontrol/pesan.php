<?php
// Redirect / Forward ke pesan.php utama untuk menjaga konsistensi
$query_string = $_SERVER['QUERY_STRING'] ?? '';
$target = '../pesan.php' . (!empty($query_string) ? '?' . $query_string : '');
header("Location: $target");
exit();
?>
