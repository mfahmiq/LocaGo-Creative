<?php
require_once "../admin/config/koneksi.php";

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $nama_admin = trim($_POST['nama_admin'] ?? '');
    $user_admin = trim($_POST['user_admin'] ?? '');
    $pass_admin = trim($_POST['pass_admin'] ?? '');

    if (empty($nama_admin) || empty($user_admin) || empty($pass_admin)) {
        $error = "Semua kolom wajib diisi!";
    } else {
        // Cek username sudah ada atau belum
        $stmt_cek = mysqli_prepare($koneksi, "SELECT id_admin FROM admin WHERE user_admin = ?");
        mysqli_stmt_bind_param($stmt_cek, "s", $user_admin);
        mysqli_stmt_execute($stmt_cek);
        $res = mysqli_stmt_get_result($stmt_cek);

        if (mysqli_num_rows($res) > 0) {
            $error = "Username '$user_admin' sudah terdaftar. Silakan gunakan username lain.";
        } else {
            $hash = password_hash($pass_admin, PASSWORD_DEFAULT);
            $stmt_ins = mysqli_prepare($koneksi, "INSERT INTO admin (nama_admin, user_admin, pass_admin) VALUES (?, ?, ?)");
            mysqli_stmt_bind_param($stmt_ins, "sss", $nama_admin, $user_admin, $hash);

            if (mysqli_stmt_execute($stmt_ins)) {
                $success = "Pendaftaran admin berhasil! Silakan login di panel admin.";
            } else {
                $error = "Terjadi kesalahan saat menyimpan data: " . mysqli_error($koneksi);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Daftar Pengelola - Nearental Mobil</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .register-card {
            background: #ffffff;
            border-radius: 1.25rem;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.25);
            overflow: hidden;
            width: 100%;
            max-width: 460px;
        }
        .register-header {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            padding: 2rem;
            color: #ffffff;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container p-3">
    <div class="register-card mx-auto">
        <div class="register-header">
            <i class="fa-solid fa-user-plus fs-1 mb-2"></i>
            <h4 class="fw-bold mb-1">Registrasi Admin</h4>
            <p class="mb-0 text-white-50 small">Nearental Mobil Bandung</p>
        </div>

        <div class="p-4">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show small" role="alert">
                    <i class="fa-solid fa-triangle-exclamation me-1"></i> <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="alert alert-success alert-dismissible fade show small" role="alert">
                    <i class="fa-solid fa-circle-check me-1"></i> <?= htmlspecialchars($success) ?>
                    <div class="mt-2">
                        <a href="../admin/index.php" class="btn btn-sm btn-success">Login Sekarang</a>
                    </div>
                </div>
            <?php endif; ?>

            <form action="daftar.php" method="POST">
                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Nama Lengkap</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-solid fa-id-card text-muted"></i></span>
                        <input type="text" name="nama_admin" class="form-control" placeholder="Nama Lengkap" required value="<?= htmlspecialchars($_POST['nama_admin'] ?? '') ?>">
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-solid fa-user text-muted"></i></span>
                        <input type="text" name="user_admin" class="form-control" placeholder="Username untuk login" required value="<?= htmlspecialchars($_POST['user_admin'] ?? '') ?>">
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label small fw-semibold text-secondary">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-solid fa-lock text-muted"></i></span>
                        <input type="password" name="pass_admin" class="form-control" placeholder="Password minimal 4 karakter" required minlength="4">
                    </div>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" name="submit" class="btn btn-primary py-2 fw-semibold">
                        <i class="fa-solid fa-check me-1"></i> Daftar Sekarang
                    </button>
                    <a href="../admin/index.php" class="btn btn-outline-secondary py-2">
                        <i class="fa-solid fa-arrow-left me-1"></i> Sudah Punya Akun? Login
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>