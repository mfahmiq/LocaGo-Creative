# 🚗 Nearental Mobil Bandung - Sistem Informasi Rental Mobil

[![PHP Version](https://img.shields.io/badge/PHP-8.0%2B%20%7C%208.3-777BB4?style=flat&logo=php&logoColor=white)](https://www.php.net/)
[![MySQL](https://img.shields.io/badge/Database-MySQL-4479A1?style=flat&logo=mysql&logoColor=white)](https://www.mysql.com/)
[![Bootstrap](https://img.shields.io/badge/UI-Bootstrap%205.3-7952B3?style=flat&logo=bootstrap&logoColor=white)](https://getbootstrap.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

Aplikasi Web Sistem Informasi Rental & Sewa Mobil **Nearental Mobil Bandung** berbasis **PHP 8.x (MySQLi)** dan **Bootstrap 5.3 & FontAwesome 6**. Dilengkapi dengan panel administrasi modern, manajemen armada mobil (CRUD Mobil), sistem reservasi interaktif, pelacakan pesanan (Cek Status Booking), cetak bukti booking / invoice, serta integrasi chat konfirmasi via WhatsApp.

---

## 🌟 Fitur Utama

### 👤 1. Halaman Pengunjung / Pelanggan (Frontend)
- **Katalog Armada Dinamis & Terfilter**: Pilihan kategori mobil (*Sedan, Hatchback, Minivan/MPV, SUV*) langsung dari database beserta spesifikasi, foto, tarif sewa harian/mingguan/bulanan, dan status ketersediaan unit (*Ready / Sedang Disewa*).
- **Formulir Booking Interaktif & Kalkulator Tarif Otomatis**:
  - Pilihan mobil otomatis terhubung dengan tarif dan spesifikasi.
  - Perhitungan durasi hari sewa dan estimasi total biaya secara *real-time*.
  - Opsi layanan: **Lepas Kunci (Setir Sendiri)** atau **Dengan Supir (+ Rp 150.000 / hari)**.
  - Validasi NIK/KTP 16 digit dan Nomor Telepon/WhatsApp.
- **Bukti Reservasi / Invoice Resmi**: Menghasilkan **Kode Booking Unik** (contoh: `NR-20260901-XXXX`), rincian biaya, rekening pembayaran resmi, dan tombol cetak bukti pesanan (*Print View*).
- **Konfirmasi Instan via WhatsApp**: Tombol otomatis dengan format pesan lengkap (Kode booking, nama pelanggan, mobil, durasi, dan total bayar) langsung terhubung ke WhatsApp admin.
- **Lacak Status Pesanan (*Cek Booking*)**: Pelanggan dapat melacak status sewa kapan saja menggunakan Kode Booking, No. KTP, atau No. Telepon.

### 🛡️ 2. Panel Pengelola / Admin Dashboard
- **Autentikasi & Keamanan**: Login aman dengan enkripsi kata sandi (*Bcrypt Password Hashing*) dan proteksi session middleware.
- **Dashboard & Statistik KPI Real-time**:
  - Ringkasan: Total Pemesanan, Pesanan Menunggu Konfirmasi, Mobil Sedang Dipinjam, dan Estimasi Total Omset.
  - Filter pesanan berdasarkan status: *Semua, Menunggu Konfirmasi, Dipinjam, Selesai, Dibatalkan*.
  - Fitur pencarian instan (berdasarkan kode booking, nama pemesan, no telp, no KTP, atau nama mobil).
- **Manajemen Pemesanan (Order Management)**:
  - Detail lengkap pemesan (Modal Popup).
  - Ubah status pemesanan: *Konfirmasi & Pinjamkan, Selesai / Dikembalikan, Batalkan*.
  - **Sinkronisasi Otomatis Armada**: Saat pesanan disetujui (*Pinjam*), status mobil otomatis berubah menjadi *Disewa*; saat selesai/batal, mobil otomatis kembali *Tersedia*.
  - Cetak Rekap Laporan Pemesanan & Cetak Invoice per pelanggan.
  - Hapus data pemesanan dengan konfirmasi keamanan.
- **Kelola Armada Mobil (Fleet CRUD)**:
  - Tambah unit mobil baru dengan upload gambar/foto mobil.
  - Edit spesifikasi, harga sewa (harian, mingguan, bulanan), dan status unit (*Tersedia, Disewa, Perawatan*).
  - Hapus unit mobil dari armada.
- **Kelola Akun Admin**: Tambah staf admin baru dan fitur ganti kata sandi secara aman.

---

## 🔑 Informasi Akun Default Admin

| Username | Password | Hak Akses |
| :--- | :--- | :--- |
| `maul` | `maul` | Administrator Utama |

> **Catatan**: Password dienkripsi dengan standar aman `password_hash()` (Bcrypt). Anda dapat mengganti password atau membuat akun admin baru melalui menu **Admin & Akun** di dashboard admin.

---

## 🛠️ Persyaratan Sistem & Instalasi

### Prasyarat
- **Web Server**: Apache (XAMPP / Laragon / WAMP / LEMP).
- **PHP Version**: PHP 7.4 / 8.0 / 8.1 / 8.2 / **PHP 8.3+** (*Dukungan penuh MySQLi & UTF8MB4*).
- **Database**: MySQL 5.7+ / MariaDB 10.3+.

### Langkah Instalasi di Localhost (XAMPP):

1. **Clone Repository**:
   ```bash
   cd C:/xampp/htdocs
   git clone https://github.com/mafin16/Rental_Mobil.git
   ```

2. **Jalankan Apache & MySQL** di XAMPP Control Panel.

3. **Import Database**:
   - Buka phpMyAdmin di `http://localhost/phpmyadmin/`.
   - Buat database baru bernama `db_rental`.
   - Import file `admin/database/db_rental.sql` ke dalam database `db_rental`.
   *(Atau buka file `http://localhost/Rental_Mobil/admin/config/migrate.php` di browser untuk migrasi otomatis)*.

4. **Konfigurasi Database (Jika Diperlukan)**:
   - File konfigurasi koneksi berada di `admin/config/koneksi.php`:
   ```php
   $dbHost = "localhost";
   $dbUser = "root";
   $dbPass = "";
   $dbName = "db_rental";
   ```

5. **Akses Aplikasi**:
   - **Halaman Utama (Frontend)**: [http://localhost/Rental_Mobil/](http://localhost/Rental_Mobil/)
   - **Halaman Booking**: [http://localhost/Rental_Mobil/pesan.php](http://localhost/Rental_Mobil/pesan.php)
   - **Cek Status Booking**: [http://localhost/Rental_Mobil/cek_booking.php](http://localhost/Rental_Mobil/cek_booking.php)
   - **Panel Admin**: [http://localhost/Rental_Mobil/admin/](http://localhost/Rental_Mobil/admin/)

---

## 📁 Struktur Direktori

```text
Rental_Mobil/
├── admin/                      # Modul Pengelola / Admin Panel
│   ├── config/
│   │   ├── koneksi.php         # Koneksi database & utility functions
│   │   └── migrate.php         # Script migrasi skema database
│   ├── database/
│   │   └── db_rental.sql       # Skema SQL database & data awal
│   ├── index.php               # Halaman login admin
│   ├── homeadmin.php           # Dashboard utama & kelola pemesanan
│   ├── mobil.php               # CRUD & manajemen armada mobil
│   ├── admin_kelola.php        # Manajemen akun admin & ganti password
│   ├── aksi.php                # Action dispatcher untuk status & armada
│   ├── cetak_laporan.php       # Cetak laporan & rekap transaksi
│   ├── hapus.php               # Handler hapus data aman
│   ├── logout.php              # Logout & pembersihan session
│   └── validasi.php            # Handler validasi pesanan
├── kontrol/
│   ├── daftar.php              # Registrasi admin
│   └── pesan.php               # Forwarder pemesanan
├── uploads/
│   └── mobil/                  # Direktori upload foto mobil baru (.gitkeep)
├── sedan/, hatchback/, minivan/# Direktori aset foto armada mobil
├── img/                        # Banner header & aset gambar
├── index.php                   # Halaman utama (Homepage modern)
├── pesan.php                   # Halaman formulir sewa interaktif
├── proses_pesan.php            # Pemroses pemesanan & kalkulasi server-side
├── invoice.php                 # Bukti reservasi & konfirmasi WhatsApp
├── cek_booking.php             # Pelacak status pemesanan pelanggan
├── .gitignore                  # Git ignore rule
├── LICENSE                     # Lisensi open source (MIT)
└── README.md                   # Dokumentasi project
```

---

## 📄 Lisensi

Didistribusikan di bawah lisensi **MIT License**. Lihat [`LICENSE`](LICENSE) untuk informasi lebih lanjut.