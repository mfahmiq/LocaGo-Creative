<?php
require_once "admin/config/koneksi.php";

// Ambil daftar kategori mobil
$kategori_filter = $_GET['kategori'] ?? 'Semua';

$where = "";
if ($kategori_filter !== 'Semua' && in_array($kategori_filter, ['Sedan', 'Hatchback', 'Minivan', 'SUV'])) {
    $safe_kat = mysqli_real_escape_string($koneksi, $kategori_filter);
    $where = "WHERE kategori = '$safe_kat'";
}

$query_mobil = mysqli_query($koneksi, "SELECT * FROM mobil $where ORDER BY status_mobil ASC, id_mobil ASC");

// Total armada
$total_armada = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as jml FROM mobil"))['jml'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Nearental Mobil Bandung - Layanan rental dan sewa mobil terlengkap, termurah, dan terpercaya di Bandung. Tersedia lepas kunci dan dengan supir.">
    <meta name="author" content="Nearental Mobil Bandung">
    
    <title>Nearental Mobil Bandung - Rental & Sewa Mobil Murah & Terpercaya</title>

    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary: #0f172a;
            --accent: #f59e0b;
            --bg-light: #f8fafc;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: #334155;
            background-color: #ffffff;
            overflow-x: hidden;
        }

        /* Navbar */
        .navbar-custom {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(226, 232, 240, 0.8);
            transition: all 0.3s ease;
        }
        .navbar-brand {
            font-weight: 800;
            font-size: 1.35rem;
            color: var(--primary) !important;
            letter-spacing: -0.5px;
        }
        .nav-link {
            font-weight: 600;
            color: #475569 !important;
            font-size: 0.95rem;
            padding: 0.5rem 1rem !important;
            transition: color 0.2s ease;
        }
        .nav-link:hover, .nav-link.active {
            color: var(--primary) !important;
        }

        /* Hero Section */
        .hero-section {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #1e3a8a 100%);
            color: #ffffff;
            padding: 120px 0 80px;
            position: relative;
            overflow: hidden;
        }
        .hero-section::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: radial-gradient(circle at 80% 20%, rgba(37, 99, 235, 0.25) 0%, transparent 60%);
            pointer-events: none;
        }
        .badge-highlight {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #93c5fd;
            font-weight: 600;
            padding: 0.4rem 1rem;
            border-radius: 50rem;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
        }

        /* Feature Cards */
        .feature-card {
            background: #ffffff;
            border-radius: 1.25rem;
            padding: 2rem 1.5rem;
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            height: 100%;
        }
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
            border-color: #cbd5e1;
        }
        .feature-icon {
            width: 60px;
            height: 60px;
            border-radius: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.6rem;
            margin-bottom: 1.25rem;
        }

        /* Car Cards */
        .car-card {
            background: #ffffff;
            border-radius: 1.25rem;
            border: 1px solid #e2e8f0;
            overflow: hidden;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        .car-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }
        .car-img-box {
            position: relative;
            height: 200px;
            overflow: hidden;
            background: #f1f5f9;
        }
        .car-img-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.4s ease;
        }
        .car-card:hover .car-img-box img {
            transform: scale(1.05);
        }
        .car-badge-cat {
            position: absolute;
            top: 12px;
            left: 12px;
            background: rgba(15, 23, 42, 0.85);
            color: #ffffff;
            padding: 0.35rem 0.8rem;
            border-radius: 50rem;
            font-size: 0.75rem;
            font-weight: 700;
            backdrop-filter: blur(4px);
        }
        .car-badge-status {
            position: absolute;
            top: 12px;
            right: 12px;
            padding: 0.35rem 0.8rem;
            border-radius: 50rem;
            font-size: 0.75rem;
            font-weight: 700;
            backdrop-filter: blur(4px);
        }
        .status-ready { background: rgba(22, 163, 74, 0.9); color: #ffffff; }
        .status-rented { background: rgba(220, 38, 38, 0.9); color: #ffffff; }

        /* Filter Buttons */
        .filter-btn {
            border-radius: 50rem;
            font-weight: 600;
            padding: 0.5rem 1.25rem;
            font-size: 0.9rem;
            border: 1px solid #cbd5e1;
            color: #475569;
            background: #ffffff;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-block;
        }
        .filter-btn:hover, .filter-btn.active {
            background: var(--primary);
            color: #ffffff;
            border-color: var(--primary);
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);
        }

        /* Floating WhatsApp Button */
        .float-wa {
            position: fixed;
            bottom: 25px;
            right: 25px;
            background-color: #25d366;
            color: #ffffff;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            box-shadow: 0 10px 25px rgba(37, 211, 102, 0.4);
            z-index: 999;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        .float-wa:hover {
            transform: scale(1.1);
            color: #ffffff;
        }
    </style>
</head>
<body id="home">

<!-- Floating WhatsApp Button -->
<a href="https://wa.me/6285316472000?text=Halo%20Admin%20Nearental%20Mobil%20Bandung,%20saya%20ingin%20tanya%20sewa%20mobil." target="_blank" class="float-wa" title="Hubungi Kami di WhatsApp">
    <i class="fa-brands fa-whatsapp"></i>
</a>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom fixed-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <i class="fa-solid fa-car-side me-2 fs-4"></i>
            <span>NEARENTAL</span>
        </a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-lg-center">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#armada">Pilihan Mobil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#layanan">Layanan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#tentang">Tentang</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cek_booking.php">
                        <i class="fa-solid fa-magnifying-glass me-1"></i> Cek Booking
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#kontak">Kontak</a>
                </li>
                <li class="nav-item ms-lg-2 mt-2 mt-lg-0">
                    <a href="pesan.php" class="btn btn-primary rounded-pill px-4 fw-semibold shadow-sm">
                        <i class="fa-solid fa-calendar-check me-1"></i> Booking Online
                    </a>
                </li>
                <li class="nav-item ms-lg-2 mt-2 mt-lg-0">
                    <a href="admin/index.php" class="btn btn-outline-secondary rounded-pill px-3 btn-sm" title="Panel Admin">
                        <i class="fa-solid fa-lock"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<header class="hero-section">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-7">
                <div class="badge-highlight mb-3">
                    <i class="fa-solid fa-shield-halved text-warning"></i> Solusi Rental Mobil No. 1 di Bandung
                </div>
                <h1 class="display-4 fw-extrabold mb-3 lh-sm">
                    Perjalanan Nyaman & Aman Bersama <span class="text-primary" style="color: #60a5fa !important;">Nearental Mobil</span>
                </h1>
                <p class="lead text-white-50 mb-4">
                    Sedia berbagai pilihan armada sedan mewah, hatchback lincah, hingga minivan keluarga. Bersih, terawat, siap lepas kunci atau dengan supir ramah & berpengalaman.
                </p>
                <div class="d-flex flex-wrap gap-3 mb-4">
                    <a href="#armada" class="btn btn-primary btn-lg rounded-pill px-4 fw-bold">
                        <i class="fa-solid fa-car me-2"></i> Pilih Mobil Sekarang
                    </a>
                    <a href="cek_booking.php" class="btn btn-outline-light btn-lg rounded-pill px-4 fw-bold">
                        <i class="fa-solid fa-search me-2"></i> Cek Status Pesanan
                    </a>
                </div>
                
                <div class="row g-3 pt-3 border-top border-secondary-subtle">
                    <div class="col-4">
                        <h4 class="fw-bold mb-0 text-white"><?= $total_armada ?>+</h4>
                        <small class="text-white-50">Unit Armada Ready</small>
                    </div>
                    <div class="col-4">
                        <h4 class="fw-bold mb-0 text-white">24/7</h4>
                        <small class="text-white-50">Layanan CS Siaga</small>
                    </div>
                    <div class="col-4">
                        <h4 class="fw-bold mb-0 text-white">100%</h4>
                        <small class="text-white-50">Kepuasan Pelanggan</small>
                    </div>
                </div>
            </div>

            <!-- Quick Booking Card -->
            <div class="col-lg-5">
                <div class="bg-white text-dark rounded-4 p-4 shadow-lg border border-light">
                    <h5 class="fw-bold text-dark mb-1 d-flex align-items-center">
                        <i class="fa-solid fa-bolt text-warning me-2 fs-4"></i> Booking Cepat & Mudah
                    </h5>
                    <p class="text-muted small mb-4">Hitung estimasi tarif dan pesan mobil dalam hitungan menit.</p>

                    <form action="pesan.php" method="GET">
                        <div class="mb-3">
                            <label class="form-label small fw-semibold text-secondary">Pilih Tipe Mobil</label>
                            <select name="kategori" class="form-select rounded-3">
                                <option value="Semua">Semua Kategori (Sedan, Minivan, Hatchback)</option>
                                <option value="Sedan">Sedan (Camry, Civic, BMW, Mercy)</option>
                                <option value="Hatchback">Hatchback (Yaris, Jazz, Swift, Agya)</option>
                                <option value="Minivan">Minivan / MPV (Innova, Ertiga, Freed, APV)</option>
                            </select>
                        </div>
                        <div class="row g-2 mb-3">
                            <div class="col-6">
                                <label class="form-label small fw-semibold text-secondary">Tgl Pinjam</label>
                                <input type="date" name="tgl_pinjam" class="form-control rounded-3" value="<?= date('Y-m-d') ?>" min="<?= date('Y-m-d') ?>" required>
                            </div>
                            <div class="col-6">
                                <label class="form-label small fw-semibold text-secondary">Tgl Kembali</label>
                                <input type="date" name="tgl_kembali" class="form-control rounded-3" value="<?= date('Y-m-d', strtotime('+1 day')) ?>" min="<?= date('Y-m-d') ?>" required>
                            </div>
                        </div>
                        <div class="mb-4">
                            <label class="form-label small fw-semibold text-secondary">Pilihan Layanan</label>
                            <select name="opsi_driver" class="form-select rounded-3">
                                <option value="Lepas Kunci">Lepas Kunci (Setir Sendiri)</option>
                                <option value="Dengan Supir">Dengan Supir (+ Rp 150.000 / hari)</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-3 rounded-3 fw-bold shadow-sm">
                            <i class="fa-solid fa-arrow-right me-2"></i> Lanjutkan Pemesanan
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Fleet Showcase Section -->
<section id="armada" class="py-5 bg-light">
    <div class="container py-4">
        <div class="text-center max-w-xl mx-auto mb-4">
            <h6 class="text-primary fw-bold text-uppercase tracking-wider">Pilihan Armada Terbaik</h6>
            <h2 class="fw-extrabold text-dark mb-2">Mobil Bersih, Wangi & Siap Jalan</h2>
            <p class="text-muted">Pilih kendaraan sesuai dengan kebutuhan perjalanan bisnis, liburan keluarga, ataupun acara spesial Anda.</p>
            
            <!-- Filter Tabs -->
            <div class="d-flex flex-wrap justify-content-center gap-2 mt-4">
                <a href="index.php?kategori=Semua#armada" class="filter-btn <?= $kategori_filter == 'Semua' ? 'active' : '' ?>">Semua Mobil</a>
                <a href="index.php?kategori=Sedan#armada" class="filter-btn <?= $kategori_filter == 'Sedan' ? 'active' : '' ?>"><i class="fa-solid fa-car-side me-1"></i> Sedan</a>
                <a href="index.php?kategori=Hatchback#armada" class="filter-btn <?= $kategori_filter == 'Hatchback' ? 'active' : '' ?>"><i class="fa-solid fa-car-rear me-1"></i> Hatchback</a>
                <a href="index.php?kategori=Minivan#armada" class="filter-btn <?= $kategori_filter == 'Minivan' ? 'active' : '' ?>"><i class="fa-solid fa-van-shuttle me-1"></i> Minivan / MPV</a>
            </div>
        </div>

        <!-- Car Grid -->
        <div class="row g-4 mt-2">
            <?php 
            if ($query_mobil && mysqli_num_rows($query_mobil) > 0):
                while ($car = mysqli_fetch_assoc($query_mobil)):
                    $is_ready = $car['status_mobil'] === 'Tersedia';
                    $img_src = $car['gambar'];
                    if (!file_exists($img_src)) {
                        $img_src = 'img/header.jpg';
                    }
            ?>
            <div class="col-md-6 col-lg-4">
                <div class="car-card">
                    <div class="car-img-box">
                        <img src="<?= htmlspecialchars($img_src) ?>" alt="<?= htmlspecialchars($car['nama_mobil']) ?>">
                        <span class="car-badge-cat"><?= htmlspecialchars($car['kategori']) ?></span>
                        <span class="car-badge-status <?= $is_ready ? 'status-ready' : 'status-rented' ?>">
                            <i class="fa-solid <?= $is_ready ? 'fa-check' : 'fa-clock' ?> me-1"></i>
                            <?= $is_ready ? 'Ready Unit' : 'Sedang Disewa' ?>
                        </span>
                    </div>

                    <div class="p-4 d-flex flex-column flex-grow-1">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="fw-bold text-dark mb-0"><?= htmlspecialchars($car['nama_mobil']) ?></h5>
                        </div>
                        
                        <p class="text-muted small mb-3 flex-grow-1" style="font-size: 0.85rem;">
                            <?= htmlspecialchars($car['deskripsi'] ?? 'Mobil terawat dengan performa terbaik dan AC dingin.') ?>
                        </p>

                        <!-- Specs Pills -->
                        <div class="row g-2 mb-3 py-2 border-top border-bottom bg-light rounded-3 text-center small text-secondary" style="font-size: 0.78rem;">
                            <div class="col-3 border-end">
                                <i class="fa-solid fa-users text-primary mb-1 d-block"></i>
                                <span><?= htmlspecialchars($car['muatan']) ?></span>
                            </div>
                            <div class="col-3 border-end">
                                <i class="fa-solid fa-gear text-primary mb-1 d-block"></i>
                                <span><?= htmlspecialchars($car['transmisi']) ?></span>
                            </div>
                            <div class="col-3 border-end">
                                <i class="fa-solid fa-snowflake text-primary mb-1 d-block"></i>
                                <span><?= htmlspecialchars($car['ac']) ?></span>
                            </div>
                            <div class="col-3">
                                <i class="fa-solid fa-gas-pump text-primary mb-1 d-block"></i>
                                <span><?= htmlspecialchars($car['bahan_bakar']) ?></span>
                            </div>
                        </div>

                        <!-- Pricing & CTA -->
                        <div class="d-flex align-items-center justify-content-between mt-auto">
                            <div>
                                <small class="text-muted d-block" style="font-size: 0.75rem;">Mulai dari</small>
                                <span class="fw-bold text-primary fs-5"><?= rupiah($car['harga_harian']) ?></span>
                                <small class="text-muted">/hari</small>
                            </div>
                            <a href="pesan.php?mobil=<?= urlencode($car['nama_mobil']) ?>" class="btn btn-primary rounded-pill px-4 fw-semibold btn-sm">
                                Sewa <i class="fa-solid fa-chevron-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php 
                endwhile;
            endif; 
            ?>
        </div>
    </div>
</section>

<!-- Services / Why Choose Us -->
<section id="layanan" class="py-5">
    <div class="container py-4">
        <div class="text-center max-w-xl mx-auto mb-5">
            <h6 class="text-primary fw-bold text-uppercase tracking-wider">Keunggulan Kami</h6>
            <h2 class="fw-extrabold text-dark">Mengapa Memilih Nearental Mobil?</h2>
            <p class="text-muted">Kami menjamin kenyamanan, keamanan, dan kemudahan dalam setiap perjalanan Anda di Kota Bandung dan sekitarnya.</p>
        </div>

        <div class="row g-4">
            <div class="col-md-6 col-lg-3">
                <div class="feature-card text-center">
                    <div class="feature-icon bg-primary-subtle text-primary mx-auto">
                        <i class="fa-solid fa-tags"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Harga Bersahabat</h5>
                    <p class="text-muted small mb-0">Tarif sewa kompetitif, jujur, tanpa biaya tersembunyi, dengan paket hemat harian, mingguan, dan bulanan.</p>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="feature-card text-center">
                    <div class="feature-icon bg-success-subtle text-success mx-auto">
                        <i class="fa-solid fa-shield-heart"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Unit Prima & Bersih</h5>
                    <p class="text-muted small mb-0">Seluruh armada menjalani servis berkala resmi, selalu dicuci bersih dan wangi sebelum serah terima.</p>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="feature-card text-center">
                    <div class="feature-icon bg-warning-subtle text-warning mx-auto">
                        <i class="fa-solid fa-user-tie"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Supir Profesional</h5>
                    <p class="text-muted small mb-0">Supir berpengalaman, paham rute wisata & jalan tikus Kota Bandung, ramah dan mengutamakan keselamatan.</p>
                </div>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="feature-card text-center">
                    <div class="feature-icon bg-info-subtle text-info mx-auto">
                        <i class="fa-solid fa-headset"></i>
                    </div>
                    <h5 class="fw-bold mb-2">Layanan 24 Jam</h5>
                    <p class="text-muted small mb-0">Tim customer service dan bantuan darurat jalan raya kami siap melayani Anda kapan pun dibutuhkan.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- About Section -->
<section id="tentang" class="py-5 bg-light">
    <div class="container py-4">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <img src="img/header1.jpg" alt="Tentang Nearental Mobil" class="img-fluid rounded-4 shadow-lg">
            </div>
            <div class="col-lg-6">
                <h6 class="text-primary fw-bold text-uppercase tracking-wider">Tentang Nearental Mobil</h6>
                <h2 class="fw-extrabold text-dark mb-3">Partner Terbaik Perjalanan Anda di Bandung</h2>
                <p class="text-muted mb-4">
                    Nearental Mobil Bandung berdiri untuk memberikan kemudahan mobilitas bagi warga lokal maupun wisatawan yang berkunjung ke Bandung. Kami menyediakan armada lengkap mulai dari mobil keluarga, city car irit bensin, hingga kendaraan eksekutif untuk keperluan dinas dan acara formal.
                </p>
                <div class="row g-3">
                    <div class="col-sm-6">
                        <div class="d-flex align-items-center">
                            <i class="fa-solid fa-circle-check text-success fs-4 me-3"></i>
                            <div>
                                <h6 class="fw-bold mb-0">Proses Booking Cepat</h6>
                                <small class="text-muted">Cukup via website / WA</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="d-flex align-items-center">
                            <i class="fa-solid fa-circle-check text-success fs-4 me-3"></i>
                            <div>
                                <h6 class="fw-bold mb-0">Lepas Kunci / Supir</h6>
                                <small class="text-muted">Fleksibel sesuai keinginan</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="d-flex align-items-center">
                            <i class="fa-solid fa-circle-check text-success fs-4 me-3"></i>
                            <div>
                                <h6 class="fw-bold mb-0">Antar Jemput Unit</h6>
                                <small class="text-muted">Bandara, Stasiun, & Hotel</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="d-flex align-items-center">
                            <i class="fa-solid fa-circle-check text-success fs-4 me-3"></i>
                            <div>
                                <h6 class="fw-bold mb-0">Asuransi & Keamanan</h6>
                                <small class="text-muted">Unit terlindungi asuransi</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="py-5">
    <div class="container py-4">
        <div class="text-center max-w-xl mx-auto mb-5">
            <h6 class="text-primary fw-bold text-uppercase tracking-wider">Informasi & Bantuan</h6>
            <h2 class="fw-extrabold text-dark">Pertanyaan Umum (FAQ)</h2>
            <p class="text-muted">Hal yang sering ditanyakan oleh pelanggan sebelum menyewa mobil.</p>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="accordion" id="faqAccordion">
                    <div class="accordion-item rounded-3 mb-3 border">
                        <h2 class="accordion-header">
                            <button class="accordion-button fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                Apa saja syarat untuk sewa mobil lepas kunci?
                            </button>
                        </h2>
                        <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                            <div class="accordion-body text-muted small">
                                Untuk layanan lepas kunci (tanpa supir), pelanggan wajib melampirkan foto e-KTP asli, SIM A aktif, Kartu Keluarga (KK) / ID Pegawai, serta akun media sosial aktif untuk verifikasi.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item rounded-3 mb-3 border">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                Apakah mobil bisa diantar ke stasiun atau bandara?
                            </button>
                        </h2>
                        <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body text-muted small">
                                Ya! Kami melayani layanan delivery antar-jemput unit ke Stasiun Bandung, Stasiun Cimahi, Bandara Husein Sastranegara, maupun hotel tempat Anda menginap di area Bandung.
                            </div>
                        </div>
                    </div>

                    <div class="accordion-item rounded-3 mb-3 border">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                Bagaimana cara pembayaran sewanya?
                            </button>
                        </h2>
                        <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body text-muted small">
                                Anda dapat melakukan pembayaran via Transfer Bank (BCA, Mandiri, BRI) atau tunai saat serah terima kendaraan setelah melakukan reservasi di website.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Contact Section -->
<section id="kontak" class="py-5 bg-dark text-white">
    <div class="container py-4">
        <div class="row g-5">
            <div class="col-lg-5">
                <h4 class="fw-bold text-primary mb-3">Nearental Mobil Bandung</h4>
                <p class="text-white-50 mb-4">
                    Penyedia jasa transportasi dan rental mobil terkemuka di Kota Bandung. Nikmati kemudahan berkendara dengan kenyamanan bintang lima.
                </p>
                <div class="d-flex align-items-center mb-3">
                    <i class="fa-solid fa-location-dot text-primary fs-5 me-3"></i>
                    <span>Jl. Raya Rental No. 88, Kota Bandung, Jawa Barat</span>
                </div>
                <div class="d-flex align-items-center mb-3">
                    <i class="fa-solid fa-phone text-primary fs-5 me-3"></i>
                    <span>+62 853-1647-2000</span>
                </div>
                <div class="d-flex align-items-center mb-3">
                    <i class="fa-solid fa-envelope text-primary fs-5 me-3"></i>
                    <span>nearentalbandung@gmail.com</span>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="bg-secondary-subtle p-4 rounded-4 text-dark">
                    <h5 class="fw-bold mb-3"><i class="fa-solid fa-paper-plane text-primary me-2"></i> Kirim Pesan & Tanya CS</h5>
                    <p class="text-muted small mb-4">Ingin konsultasi rute wisata atau butuh armada dalam jumlah banyak? Tim kami siap merespon cepat.</p>
                    <a href="https://wa.me/6285316472000?text=Halo%20Admin%20Nearental%20Mobil,%20saya%20ingin%20konsultasi%20sewa%20mobil." target="_blank" class="btn btn-success btn-lg w-100 py-3 rounded-3 fw-bold">
                        <i class="fa-brands fa-whatsapp me-2 fs-5"></i> Chat Langsung via WhatsApp
                    </a>
                </div>
            </div>
        </div>

        <div class="border-top border-secondary mt-5 pt-4 text-center text-white-50 small">
            <p class="mb-0">&copy; <?= date('Y') ?> Nearental Mobil Bandung. All Rights Reserved.</p>
        </div>
    </div>
</section>

<!-- Bootstrap 5.3 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
