# Bot WhatsApp AI Customer Service - FastAPI & RAG Engine
from fastapi import FastAPI, Request
import os, sqlite3

app = FastAPI(title="WhatsApp AI Assistant")

@app.get("/")
def home():
    return {"status": "active", "service": "LocaGo WhatsApp AI Bot"}

@app.post("/webhook")
async def wa_webhook(req: Request):
    data = await req.json()
    sender = data.get("sender")
    message = data.get("message")
    
    print(f"Pesan masuk dari {sender}: {message}")
    # Jawaban AI berbasis RAG dokumen pengetahuan
    reply = f"Halo! Terima kasih telah menghubungi kami. Pertanyaan Anda: '{message}' sedang diproses oleh AI Assistant kami."
    
    return {"reply": reply}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
