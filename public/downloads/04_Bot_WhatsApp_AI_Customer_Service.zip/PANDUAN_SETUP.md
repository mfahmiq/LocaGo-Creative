# Panduan Menjalankan Bot WA AI Python
1. Install Python 3.10 atau 3.11.
2. Jalankan `pip install -r requirements.txt`.
3. Buka file `knowledge_base.txt` dan isi informasi bisnis Anda.
4. Jalankan `python main.py`.
5. Sambungkan webhook ke gateway WhatsApp Anda (Fonnte / Baileys).
