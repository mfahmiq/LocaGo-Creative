# Aplikasi Ujian Online CBT & E-Learning - Ujian Online Siswa

```
========================================================================
📦 Aplikasi Ujian Online CBT & E-Learning - Ujian Online Siswa
Kategori     : Pendidikan & Akademik
Tech Stack   : CodeIgniter • PHP • MySQL • Bootstrap • AdminLTE
Database     : MySQL (.sql) (File: database/smpnseda_ujian.sql)
Sumber Asli  : https://github.com/bagussatoto/Ujian-Online-Siswa (GitHub Open Source)
Stars GitHub : ⭐ 10 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/ujian-online-siswa`
     * Untuk Laragon: `C:/laragon/www/ujian-online-siswa`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `ujian_online_siswa`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `database/smpnseda_ujian.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = ujian_online_siswa

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/ujian-online-siswa

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
