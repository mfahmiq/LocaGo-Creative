# UniPortal : système de gestion de scolarité

Portail universitaire en **PHP / MySQL** avec trois espaces séparés (administrateur, enseignant, étudiant) pour gérer les étudiants, les modules, les notes et les relevés de notes.

![PHP](https://img.shields.io/badge/PHP-8-777BB4?logo=php&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-8-4479A1?logo=mysql&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-vanilla-F7DF1E?logo=javascript&logoColor=black)
![Projet](https://img.shields.io/badge/USTHB-module%20PWEB-1E3A8A)

![Tableau de bord administrateur](docs/screenshots/admin-dashboard.png)

## Contexte

Projet d'équipe réalisé pour le module **Programmation Web (PWEB)** de la licence Informatique, parcours ISIL, à l'USTHB (2025-2026).

Le but était de concevoir un petit système d'information complet : modéliser les données d'une scolarité, puis construire une application web qui en gère l'accès selon le rôle de chaque utilisateur.

## Fonctionnalités

**Administrateur**

- Tableau de bord avec le nombre d'étudiants, d'enseignants et de modules
- Gestion complète (ajout, modification, suppression, recherche) des étudiants et des enseignants
- Gestion des modules : code, intitulé, coefficient, enseignant responsable
- Saisie des notes, avec calcul de la moyenne pondérée de chaque étudiant

**Enseignant**

- Liste de ses modules avec le nombre d'étudiants et la moyenne de la classe
- Saisie des notes de tout un module en une seule fois
- Contrôle côté serveur : un enseignant ne peut noter que ses propres modules

**Étudiant**

- Tableau de bord avec son profil et ses notes
- Détail des notes par module, avec admis / ajourné
- Relevé de notes imprimable, avec une mise en page dédiée à l'impression

## Captures d'écran

| Gestion des étudiants (admin) | Saisie des notes (enseignant) |
|---|---|
| ![Liste des étudiants](docs/screenshots/admin-etudiants.png) | ![Saisie des notes](docs/screenshots/enseignant-saisie-notes.png) |

| Relevé de notes (étudiant) |
|---|
| ![Relevé de notes](docs/screenshots/etudiant-releve.png) |

## Base de données

Cinq tables, définies dans [`sql/schema.sql`](sql/schema.sql) avec un jeu de données de test :

```
admins      (indépendante)

teachers 1 ──── N modules 1 ──── N grades N ──── 1 students
```

| Table | Rôle |
|---|---|
| `admins` | comptes administrateurs |
| `teachers` | comptes enseignants |
| `students` | étudiants : matricule, niveau (L1 à M2), date de naissance |
| `modules` | modules : code unique, coefficient, enseignant (clé étrangère) |
| `grades` | une note sur 20 par couple étudiant / module (clés étrangères vers `students` et `modules`) |

La moyenne est calculée comme la somme des `note × coefficient` divisée par la somme des coefficients.

## Sécurité

- Toutes les requêtes qui reçoivent une saisie utilisateur passent par des **requêtes préparées PDO**.
- Mots de passe hachés avec `password_hash()` (bcrypt) et vérifiés avec `password_verify()`.
- `session_regenerate_id(true)` après la connexion, contre la fixation de session.
- Accès aux pages protégé par rôle (`requireRole()` dans `includes/auth.php`).
- Affichage échappé avec `htmlspecialchars()` contre les failles XSS.

## Stack technique

| Couche | Technologies |
|---|---|
| Back-end | PHP 8, PDO |
| Base de données | MySQL / MariaDB |
| Front-end | HTML, CSS (responsive, feuille d'impression), JavaScript sans framework |

## Installation

**Prérequis :** PHP 8 avec l'extension `pdo_mysql`, et MySQL ou MariaDB.

```bash
git clone https://github.com/medazero01-art/progressv2.git
cd progressv2

# 1. Créer la base et importer le schéma et les données de test
mysql -u root -p -e "CREATE DATABASE school_management CHARACTER SET utf8mb4;"
mysql -u root -p --default-character-set=utf8mb4 school_management < sql/schema.sql

# 2. Adapter les identifiants MySQL si besoin dans config/database.php

# 3. Lancer le serveur PHP depuis la racine du projet
php -S localhost:8000
```

Ouvrir ensuite http://localhost:8000.

L'application peut aussi tourner sous XAMPP ou WAMP, à condition que le projet soit servi à la racine du serveur (les redirections utilisent des chemins absolus comme `/auth/login.php`).

### Comptes de test

Tous les comptes du jeu de données utilisent le mot de passe `password`.

| Rôle | E-mail |
|---|---|
| Administrateur | `admin@university.dz` |
| Enseignant | `ahmed.benmoussa@university.dz` |
| Étudiant | `mohamed.benali@student.dz` |

> Ces comptes sont prévus pour un usage local. Changez-les avant tout déploiement.

## Structure du projet

```
├── admin/        # Pages administrateur : tableau de bord, étudiants, enseignants, modules, notes
├── teacher/      # Pages enseignant : modules, saisie des notes
├── student/      # Pages étudiant : tableau de bord, notes, relevé
├── auth/         # Connexion et déconnexion
├── includes/     # En-tête, barre latérale, pied de page, fonctions d'authentification
├── config/       # Connexion PDO à la base
├── assets/       # CSS et JavaScript
├── sql/          # Schéma et données de test
└── index.php     # Page d'accueil
```

## Pistes d'amélioration

- Export du relevé de notes en PDF
- Pagination côté serveur pour les grandes listes
- Récupération de mot de passe par e-mail
- Jeton CSRF sur les formulaires

## Licence

Distribué sous licence MIT.
