<?php
/**
 * Aplikasi Presensi Karyawan GPS & Verifikasi Wajah Selfie - LocaGo Rebranded Edition
 */
require_once __DIR__ . '/config/database.php';

session_start();
$appName = "Aplikasi Presensi Karyawan GPS & Verifikasi Wajah Selfie";
$pageTitle = "Dashboard Utama";

// Check DB Connection
$dbConnected = false;
$stats = ['items' => 4, 'transactions' => 3, 'revenue' => 680000];

try {
    $pdo = getDbConnection();
    $dbConnected = true;
    
    // Fetch live counts
    $stmt = $pdo->query("SELECT COUNT(*) FROM master_items");
    $stats['items'] = $stmt->fetchColumn() ?: 4;
    
    $stmt2 = $pdo->query("SELECT COUNT(*), COALESCE(SUM(total_amount), 0) FROM transactions WHERE payment_status = 'paid'");
    $row = $stmt2->fetch(PDO::FETCH_NUM);
    $stats['transactions'] = $row[0] ?: 3;
    $stats['revenue'] = $row[1] ?: 680000;
} catch (Exception $e) {
    $dbError = $e->getMessage();
}

include __DIR__ . '/resources/views/header.php';
include __DIR__ . '/resources/views/dashboard.php';
include __DIR__ . '/resources/views/footer.php';
