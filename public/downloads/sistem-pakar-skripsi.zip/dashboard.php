<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: index.php");
    exit;
}

header("Location: dashboard/index.php");
exit;
?>