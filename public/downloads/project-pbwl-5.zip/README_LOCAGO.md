# Sistem Akademik Project 5 - PHP OOP + Composer

```
========================================================================
📦 Sistem Akademik Project 5 - PHP OOP + Composer
Kategori     : Pendidikan & Akademik
Tech Stack   : PHP 8.0+ OOP • Composer (PSR-4) • PDO MySQL • Bootstrap
Database     : MySQL (.sql) (File: database.sql, database: pbwl_samples_5)
Sumber Asli  : https://github.com/Neuron700/project-pbwl-5 (GitHub Open Source)
Stars GitHub : ⭐ 0 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

Aplikasi Sistem Akademik: manajemen data Mahasiswa, Dosen, dan
Matakuliah (CRUD lengkap) dengan PHP OOP, autoload Composer (PSR-4),
dan PDO MySQL. Dashboard langsung terbuka tanpa halaman login.

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/project-pbwl-5`
     * Untuk Laragon: `C:/laragon/www/project-pbwl-5`

2. BUAT DATABASE + IMPORT (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - File `database.sql` TIDAK membuat database sendiri — buat dulu
     database bernama `pbwl_samples_5` di phpMyAdmin
     (http://localhost/phpmyadmin), lalu import `database.sql` ke
     database tersebut. Tabel yang dibuat: tb_mhsw, tb_dosen,
     tb_matakuliah (beserta data contoh).

3. KONFIGURASI KONEKSI DATABASE:
   - Koneksi ada di `inc/Koneksi.php`:
     * DB_HOST = 127.0.0.1
     * DB_PORT = 3307 (port MySQL yang dipakai aplikasi ini)
     * DB_NAME = pbwl_samples_5
     * DB_USER = root
     * DB_PASS = (kosong)
   - Sesuaikan host/port bila MySQL Anda berjalan di port lain
     (default XAMPP: 3306 — ubah port di atas menjadi 3306).

4. COMPOSER (BILA PERLU):
   - Bila folder `vendor/` belum ada, jalankan `composer install`
     di folder proyek (autoload PSR-4 `App\` -> `app/`).

5. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/project-pbwl-5
   - Dashboard Sistem Akademik langsung terbuka (tanpa login).
     Menu: Home, Mahasiswa, Dosen, Matakuliah.

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
