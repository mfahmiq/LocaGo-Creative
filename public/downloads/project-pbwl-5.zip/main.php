<div class="mb-4">
    <h2 class="fw-bold mb-1">Dashboard</h2>
    <p class="text-secondary mb-0">Dashboard aplikasi akademik.</p>
</div>

<div class="alert alert-primary d-flex align-items-center" role="alert">
    <i class="bi bi-info-circle-fill fs-4 me-3"></i>
    <div>Selamat datang di aplikasi akademik menggunakan PHP OOP dan Composer.</div>
</div>
