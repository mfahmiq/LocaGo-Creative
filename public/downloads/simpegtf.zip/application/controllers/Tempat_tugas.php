<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Tempat_tugas extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Data Tempat Tugas";
         $data['tempat_tugas'] = $this->admin->getTempat_tugas();
        template_view('tempat_tugas/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('nama_tempat', 'Nama tempat', 'required|trim');
        $this->form_validation->set_rules('id_jabatan', 'ID Jabatan', 'required');
    }

    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Tambah Tempat Tugas";
            $data['user'] = $this->admin->getPegawai();
            template_view('tempat_tugas/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('tempat_tugas', $input);
            if ($insert) {
                set_pesan('data berhasil disimpan');
                redirect('tempat_tugas');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('tempat_tugas/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Edit Tempat Tugas";
            $data['tempat_tugas'] = $this->admin->get('tempat_tugas', ['id_tempat' => $id]);
            template_view('tempat_tugas/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('tempat_tugas', 'id_tempat', $id, $input);

            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('tempat_tugas');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('tempat_tugas/edit/' . $id);
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('tempat_tugas', 'id_tempat', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('tempat_tugas');
    }
}
