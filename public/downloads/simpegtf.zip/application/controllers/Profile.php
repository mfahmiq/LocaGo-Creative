<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Profile extends CI_Controller
{
    protected $user;

    public function __construct()
    {
        parent::__construct();
        // cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');

        $userId = $this->session->userdata('login_session')['user'];
        $this->user = $this->admin->get('user', ['id_user' => $userId]);
    }

    public function index()
    {
        $data['title'] = "Profile";
        $data['user'] = $this->user;
        $data['user'] = $this->admin->getBiodata();
        template_view('profile/user', $data);
    }
    
    public function user($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_user' => $id];

        $data['title'] = "Profile";
        $data['user'] = $this->user;
        $data['user1'] = $this->admin->getBiodataDetail($where);
        $data['user2'] = $this->admin->getBiodataDetail($where);
        $data['pekerjaan'] = $this->admin->getPekerjaanDetail($where);
        $data['pekerjaan1'] = $this->admin->getPekerjaanDetail($where);
        $data['pendidikan'] = $this->admin->getPendidikan($where);
        $data['pelatihan'] = $this->admin->getPelatihanDetail($where);
        $data['perizinan'] = $this->admin->getPerizinanDetail($where);
        template_view('profile/user', $data);
    }

    private function _validasi()
    {
        $db = $this->admin->get('user', ['id_user' => $this->input->post('id_user', true)]);
        $username = $this->input->post('username', true);

        $uniq_username = $db['username'] == $username ? '' : '|is_unique[user.username]';

        $this->form_validation->set_rules('username', 'Username', 'required|trim|alpha_numeric' . $uniq_username);
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
    }

    private function _config()
    {
        $config['upload_path']      = "./template/assets/user";
        $config['allowed_types']    = 'gif|jpg|jpeg|png';
        $config['encrypt_name']     = FALSE;
        $config['max_size']         = '2048';
        $this->load->library('upload', $config);
    }

    public function setting()
    {
        $this->_validasi();
        $this->_config();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Edit Profile";
            $data['user'] = $this->user;
            template_view('profile/setting', $data);
        } else {
            $input = $this->input->post(null, true);
            if (empty($_FILES['foto']['name'])) {
                $insert = $this->admin->update('user', 'id_user', $input['id_user'], $input);
                if ($insert) {
                    set_pesan('perubahan berhasil disimpan.');
                } else {
                    set_pesan('perubahan tidak disimpan.');
                }
                redirect('profile/user/' . userdata('id_user'));
            } else {
                if ($this->upload->do_upload('foto') == false) {
                    echo $this->upload->display_errors();
                    die;
                } else {
                    if (userdata('foto') != 'user.png') {
                        $old_image = FCPATH . 'template/assets/user/' . userdata('foto');
                        if (!unlink($old_image)) {
                            set_pesan('gagal hapus foto lama.');
                             redirect('profile/user/' . userdata('id_user'));
                        }
                    }
                    $input['foto'] = $this->upload->data('file_name');
                    $update = $this->admin->update('user', 'id_user', $input['id_user'], $input);
                    if ($update) {
                        set_pesan('perubahan berhasil disimpan.');
                    } else {
                        set_pesan('gagal menyimpan perubahan');
                    }
                     redirect('profile/user/' . userdata('id_user'));
                }
            }
        }
    }

    public function ubahpassword()
    {
        $this->form_validation->set_rules('password_lama', 'Password Lama', 'required|trim');
        $this->form_validation->set_rules('password_baru', 'Password Baru', 'required|trim|min_length[3]|differs[password_lama]');
        $this->form_validation->set_rules('konfirmasi_password', 'Konfirmasi Password', 'matches[password_baru]');
        if ($this->form_validation->run() == false) {
            $data['title'] = "Ubah Password";
            template_view('profile/ubahpassword', $data);
        } else {
            $input = $this->input->post(null, true);
            if (password_verify($input['password_lama'], userdata('password'))) {
                $new_pass = ['password' => password_hash($input['password_baru'], PASSWORD_DEFAULT)];
                $query = $this->admin->update('user', 'id_user', userdata('id_user'), $new_pass);
                if ($query) {
                    set_pesan('password berhasil diubah.');
                    redirect('auth/logout');
                } else {
                    set_pesan('gagal ubah password', false);
                }
            } else {
                set_pesan('password lama salah.', false);
            }
            redirect('profile');
        }
    }
}
