<?php
defined('BASEPATH') or exit('No direct script access allowed');

class bagian extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Data bagian";
        $data['bagian'] = $this->admin->getbagian();
        template_view('bagian/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('nama_bagian', 'Nama bagian', 'required|trim');
        $this->form_validation->set_rules('id_user', 'ID User', 'required');
        $this->form_validation->set_rules('id_bidang', 'ID Bidang', 'required');
    }

    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Tambah bagian";
            $data['user'] = $this->admin->getKasi();
            $data['bidang'] = $this->admin->get('bidang');
            template_view('bagian/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $input_data = [
                'nama_bagian' => $input['nama_bagian'],
                'id_user' => $input['id_user'],
                'id_bidang' => $input['id_bidang']
            ];
            $insert = $this->admin->insert('bagian', $input_data);
            if ($insert) {
                set_pesan('data berhasil disimpan');
                redirect('bagian');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('bagian/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Edit bagian";
            $data['user'] = $this->admin->getKasi();
            $data['bidang'] = $this->admin->get('bidang');
            $data['bagian'] = $this->admin->get('bagian', ['id_bagian' => $id]);
            template_view('bagian/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $input_data = [
                'nama_bagian' => $input['nama_bagian'],
                'id_user' => $input['id_user'],
                'id_bidang' => $input['id_bidang']
            ];
            $update = $this->admin->update('bagian', 'id_bagian', $id, $input_data);

            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('bagian');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('bagian/edit/' . $id);
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('bagian', 'id_bagian', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('bagian');
    }
}
