<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // cek_login();

        $this->load->model('Admin_model', 'admin');
        $userId = $this->session->userdata('login_session')['user'];
        $this->user = $this->admin->get('user', ['id_user' => $userId]);
    }

    public function index()
    {
        $data['title'] = "Dashboard"; 
        $data['jlh_petinggi'] = $this->admin->JlhPetinggi();
        $data['jlh_pegawai'] = $this->admin->JlhPegawai();
        $data['jlh_jabatan'] = $this->admin->JlhJabatan();
        $data['jlh_tempatTugas'] = $this->admin->JlhTempat_tugas();
        $data['pekerjaan'] = $this->admin->getpekerjaan_admin();
        $data['graph'] = $this->admin->getjumlahpegawai_tempat();
        template_view('dashboard', $data);
    }

    public function pegawai($getId){ 

        $id = encode_php_tags($getId);
        $where = ['id_user' => $id];
        $data['title'] = "Dashboard";

        $data['user'] = $this->user;
        $data['jlh_biodata'] = $this->admin->jlhBiodata();
        $data['biodata'] = $this->admin->getBiodataDetail($where);
        $data['jlh_pekerjaan'] = $this->admin->jlhPekerjaan();
        $data['pekerjaan'] = $this->admin->getPekerjaanDetail($where);
        // $data['pendidikan'] = $this->admin->getPendidikan($where);
         $data['pendidikan'] = $this->admin->getpendidikan_sudah();
        $data['jlh_pendidikan'] = $this->admin->jlhPendidikan_sudah();
        $data['perizinan'] = $this->admin->getPerizinanDetail($where);
        $data['jlh_perizinan'] = $this->admin->jlhPerizinan_sudah();
        $data['pelatihan'] = $this->admin->getPelatihanDetail($where);
        $data['jlh_pelatihan_sudah'] = $this->admin->JlhPelatihan_sudah();
        $data['jlh_pelatihan_belum'] = $this->admin->JlhPelatihan_belum();
        template_view('dashboard_pegawai', $data);
    }
}
