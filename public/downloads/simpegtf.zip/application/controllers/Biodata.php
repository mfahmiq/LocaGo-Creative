<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Biodata extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Data Biodata";
        $data['user'] = $this->admin->getBiodata();
        $data['user1'] = $this->admin->getBiodata();
        template_view('biodata/data', $data);
    }

    // public function index_before()
    // {
    //     $data['title'] = "Data biodata";
    //     $data['biodata'] = $this->admin->getbiodata_belum();
    //     template_view('biodata/data_belum', $data);
    // }

    // public function biodata_user(){
    //     $status = $this->admin->getbiodata_belum();
    //     if($status = $this->admin->getbiodata_belum()){
    //         redirect('biodata/index_before');
            
    //     }
    //     elseif($status = $this->admin->getbiodata_sudah()){
    //         redirect('biodata');
    //     }
    //     else{
    //         redirect('biodata/index_before');
    //     }
    // }


    private function _config()
    {
        $config['upload_path']      = './template/assets/biodata/';
        $config['allowed_types']    = 'jpg|jpeg|png|pdf';
        $config['max_size']         = '2048';
        $config['encrypt_name']     = FALSE;

        $this->load->library('upload', $config);
    }


    public function pegawai()
    {
        $data['title'] = "Data Biodata";
        $data['biodata'] = $this->admin->getBiodata();
        template_view('pegawai/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required|trim');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required|trim');
        $this->form_validation->set_rules('tempat_lahir', 'Tempat Lahir', 'required|trim');
        $this->form_validation->set_rules('tanggal_lahir', 'Tanggal Lahir', 'required|trim');
        $this->form_validation->set_rules('no_telp', 'No. Telp', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|trim');
        $this->form_validation->set_rules('status_kawin', 'Status Kawin', 'required|trim');
        $this->form_validation->set_rules('agama', 'Agama', 'required|trim');
        $this->form_validation->set_rules('id_user', 'ID User', 'required');
    }

    public function add($getId)
    {
        $id = encode_php_tags($getId);
        $this->_config();
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['user'] = $this->admin->get('user', ['id_user' => $id]);
            if ($this->upload->display_errors()) {
                set_pesan('danger', $this->upload->display_errors('', ''));
            }
            $data['title'] = "Tambah biodata";
            template_view('biodata/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $input['status'] = "Sudah";
            if (!empty($_FILES['ktp']['name'])) {
                if ($this->upload->do_upload('ktp')) {
                    if ($this->upload->data()) {
                        $input['ktp'] = $this->upload->data('file_name');
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        set_pesan($this->upload->display_errors('', ''));
                        redirect('biodata/add');
                    }
                }
            }

            if (!empty($_FILES['kk']['name'])) {
                if ($this->upload->do_upload('kk')) {
                    if ($this->upload->data()) {
                        $input['kk'] = $this->upload->data('file_name');

                       
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        set_pesan($this->upload->display_errors('', ''));
                        redirect('biodata/add');
                    }
                }
            }
            $update = $this->admin->update('user', 'id_user', $id, $input);
            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('biodata');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('biodata/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_config();
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Edit biodata";
            $data['user'] = $this->admin->get('user', ['id_user' => $id]);
            template_view('biodata/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $input['status'] = "Sudah";
            if (!empty($_FILES['ktp']['name'])) {
                if ($this->upload->do_upload('ktp')) {
                    if ($this->upload->data()) {
                        $input['ktp'] = $this->upload->data('file_name');
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        set_pesan($this->upload->display_errors('', ''));
                        redirect('biodata/edit' . $id);
                    }
                }
            }

            if (!empty($_FILES['kk']['name'])) {
                if ($this->upload->do_upload('kk')) {
                    if ($this->upload->data()) {
                        $input['kk'] = $this->upload->data('file_name');

                       
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        set_pesan($this->upload->display_errors('', ''));
                        redirect('biodata/edit' . $id);
                    }
                }
            }
            $update = $this->admin->update('user', 'id_user', $id, $input);
            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('biodata');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('biodata/edit/' . $id);
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('biodata', 'id_biodata', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('biodata');
    }

    public function download_ktp($id) {
        $this->load->helper('download');
        $data = $this->db->get_where('user',['id_user'=>$id])->row();
		force_download('template/assets/biodata/'.$data->ktp,NULL);
    }

    public function download_kk($id) {
        $this->load->helper('download');
        $data = $this->db->get_where('user',['id_user'=>$id])->row();
		force_download('template/assets/biodata/'.$data->kk,NULL);
    }
}
