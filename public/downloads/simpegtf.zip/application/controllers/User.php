<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // cek_login();
        // if (!is_admin()) {
        //     redirect('dashboard');
        // }

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');

        $userId = $this->session->userdata('login_session')['user'];
        $this->user = $this->admin->get('user', ['id_user' => $userId]);
    }

    private function _config()
    {
        $config['upload_path']      = './template/assets/user/';
        $config['allowed_types']    = 'jpg|jpeg|png|webp';
        $config['max_size']         = '2048';
        $config['encrypt_name']     = FALSE;

        $this->load->library('upload', $config);
    }

    public function index()
    {
        $data['title'] = "Data Pegawai";
        $data['user'] = $this->admin->get('user');

        template_view('user/data', $data);
    }

    public function atasan()
    {
        $data['title'] = "Data Pegawai";
        $data['user'] = $this->admin->getPetinggi();

        template_view('user/data', $data);
    }

    public function listpegawai()
    {
        $data['title'] = "Data Pegawai";
        $data['user'] = $this->admin->getPegawai();

        template_view('user/data', $data);
    }

    public function pegawai()
    {
        $data['title'] = "Detail Pegawai";
        $data['user'] = $this->admin->getUser();

        template_view('pegawai/data', $data);
    }

    private function _validasi($mode)
    {
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
        $this->form_validation->set_rules('role', 'Role', 'required|trim');

        if ($mode == 'add') {
            $this->form_validation->set_rules('username', 'Username', 'required|trim|is_unique[user.username]|alpha_numeric');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[3]|trim');
            $this->form_validation->set_rules('password2', 'Konfirmasi Password', 'matches[password]|trim');
        } else {
            $db = $this->admin->get('user', ['id_user' => $this->input->post('id_user', true)]);
            $username = $this->input->post('username', true);

            $uniq_username = $db['username'] == $username ? '' : '|is_unique[user.username]';

            $this->form_validation->set_rules('username', 'Username', 'required|trim|alpha_numeric' . $uniq_username);
        }
    }

    public function add()
    {
        $this->_config();
        $this->_validasi('add');

        if ($this->form_validation->run() == false || $this->upload->do_upload('foto') == false) {
            $data['title'] = "Tambah User";
            template_view('user/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $foto = $this->upload->data('file_name');
            $input_data = [
                'nama'          => $input['nama'],
                'username'      => $input['username'],
                'role'   => $input['role'],
                'password'      => password_hash($input['password'], PASSWORD_DEFAULT),
                'tanggal_bergabung' => date('Y-m-d'),
                'foto'          => $foto
            ];

            if ($this->admin->insert('user', $input_data)) {
                set_pesan('data berhasil disimpan.');
                redirect('user');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('user/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
        $db = $this->admin->get('user', ['id_user' => $this->input->post('id_user', true)]);
        $username = $this->input->post('username', true);
        $uniq_username = $db['username'] == $username ? '' : '|is_unique[user.username]';
        $this->form_validation->set_rules('username', 'Username', 'required|trim|alpha_numeric' . $uniq_username);
        $this->_config();
        if ($this->form_validation->run() == false || $this->upload->do_upload('foto') == false) {
            $data['title'] = "Edit User";
            $data['user'] = $this->admin->get('user', ['id_user' => $id]);
            template_view('user/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            if (!empty($_FILES['foto']['name'])) {
                if ($this->upload->do_upload('foto')) {
                    if ($this->upload->data()) {
                        $input['foto'] = $this->upload->data('file_name');

                        $dir = FCPATH . 'template/assets/user/';
                        // $oldfoto = $data['user']['foto'];
                        // if (file_exists($dir . $oldfoto) && $oldfoto != 'user.png') {
                        //     if (!unlink($dir . $oldfoto)) {
                        //         echo "gagal hapus foto";
                        //         die;
                        //     }
                        // }
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        set_pesan($this->upload->display_errors('', ''));
                        redirect('user/edit/' . $id);
                    }
                }
            }
            if ($this->admin->update('user', 'id_user', $id, $input)) {
                set_pesan('data berhasil diubah.');
                redirect('user');
            } else {
                set_pesan('data gagal diubah.', false);
                redirect('user/edit/' . $id);
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('user', 'id_user', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('user');
    }

    public function toggle($getId)
    {
        $id = encode_php_tags($getId);
        $status = $this->admin->get('user', ['id_user' => $id])['is_active'];
        $toggle = $status ? 0 : 1; //Jika user aktif maka nonaktifkan, begitu pula sebaliknya
        $pesan = $toggle ? 'user diaktifkan.' : 'user dinonaktifkan.';

        if ($this->admin->update('user', 'id_user', $id, ['is_active' => $toggle])) {
            set_pesan($pesan);
        }
        redirect('user');
    }

    public function download_user($id) {
        $this->load->helper('download');
        $data = $this->db->get_where('user',['id_user'=>$id])->row();
		force_download('template/assets/user/'.$data->foto,NULL);
    }

    public function detail($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_user' => $id];

        $data['title'] = "Profile";
        $data['user'] = $this->admin->get('user', ['id_user' => $id]);
        $data['user1'] = $this->admin->getBiodataDetail_user($id);
        $data['user2'] = $this->admin->getBiodataDetail_user($id);
        $data['pekerjaan'] = $this->admin->getPekerjaanDetail_user($id);
        $data['pekerjaan1'] = $this->admin->getPekerjaanDetail_user($id);
        $data['pendidikan'] = $this->admin->getPendidikan_user($id);
        $data['pelatihan'] = $this->admin->getPelatihanDetail_user($id);
        $data['perizinan'] = $this->admin->getPerizinanDetail_user($id);
        template_view('admin/detail', $data);
    }

    public function detail_pelatihan_user($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pelatihan' => $id];

        $data['title'] = 'Detail';
        $data['pelatihan'] = $this->admin->getPelatihanDetail2($where);
        template_view('admin/detail_pelatihan', $data);
    }
}
