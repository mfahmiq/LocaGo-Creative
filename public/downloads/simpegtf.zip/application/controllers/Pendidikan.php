<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pendidikan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Data pendidikan";
        $data['pendidikan'] = $this->admin->getpendidikan_belum();
        template_view('pendidikan/data', $data);
    }

    public function data_after()
    {
        $data['title'] = "Data pendidikan";
        
        $data['pendidikan'] = $this->admin->getpendidikan_sudah();
        template_view('pendidikan/data_after', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('id_user', 'ID User', 'required');
        $this->form_validation->set_rules('sekolah', 'sekolah', 'required|trim');
        $this->form_validation->set_rules('jurusan', 'Jurusan', 'required|trim');
        $this->form_validation->set_rules('tahun_lulus', 'Tahun Lulus', 'required|max_length[4]|trim');
    }

    private function _config()
    {
        $config['upload_path']      = './template/assets/pendidikan/';
        $config['allowed_types']    = 'jpg|jpeg|png|pdf';
        $config['max_size']         = '2048';
        $config['encrypt_name']     = FALSE;

        $this->load->library('upload', $config);
    }

    public function add()
    {
        $this->_config();
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            if ($this->upload->display_errors()) {
                set_pesan('danger', $this->upload->display_errors('', ''));
            }
            $data['title'] = "Tambah pendidikan";
            template_view('pendidikan/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $input['status'] = "Belum";
            if (!empty($_FILES['bukti_ijazah']['name'])) {
                if ($this->upload->do_upload('bukti_ijazah')) {
                    if ($this->upload->data()) {
                        $input['bukti_ijazah'] = $this->upload->data('file_name');
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        set_pesan($this->upload->display_errors('', ''));
                        redirect('pendidikan/add');
                    }
                }
            }

            if (!empty($_FILES['transkrip_nilai']['name'])) {
                if ($this->upload->do_upload('transkrip_nilai')) {
                    if ($this->upload->data()) {
                        $input['transkrip_nilai'] = $this->upload->data('file_name');

                       
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        set_pesan($this->upload->display_errors('', ''));
                        redirect('pendidikan/add');
                    }
                }
            }
            $insert = $this->admin->insert('pendidikan', $input);
            if ($insert) {
                set_pesan('data berhasil disimpan');
                redirect('pendidikan');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('pendidikan/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_config();
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Edit pendidikan";
            $data['pendidikan'] = $this->admin->get('pendidikan', ['id_pendidikan' => $id]);
            template_view('pendidikan/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $input['status'] = "Belum";
            if (!empty($_FILES['bukti_ijazah']['name'])) {
                if ($this->upload->do_upload('bukti_ijazah')) {
                    if ($this->upload->data()) {
                        $input['bukti_ijazah'] = $this->upload->data('file_name');
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        set_pesan($this->upload->display_errors('', ''));
                         redirect('pendidikan/edit/' .$id);
                    }
                }
            }

            if (!empty($_FILES['transkrip_nilai']['name'])) {
                if ($this->upload->do_upload('transkrip_nilai')) {
                    if ($this->upload->data()) {
                        $input['transkrip_nilai'] = $this->upload->data('file_name');
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        set_pesan($this->upload->display_errors('', ''));
                        redirect('pendidikan/edit/' .$id);
                    }
                }
            }
            $update = $this->admin->update('pendidikan', 'id_pendidikan', $id, $input);
            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('pendidikan');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('pendidikan/edit/' . $id);
            }
        }
    }

    public function kirim($getId)
    {
        $id = encode_php_tags($getId);
            $data['title'] = "Edit pendidikan";
            $data['pendidikan'] = $this->admin->get('pendidikan', ['id_pendidikan' => $id]);
            $input_data = [
                'status' => "Sudah"
            ];
            $update = $this->admin->update('pendidikan', 'id_pendidikan', $id, $input_data);

            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('pendidikan/data_after');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('pendidikan/data');
            }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('pendidikan', 'id_pendidikan', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('pendidikan');
    }

    public function download_ijazah($id) {
        $this->load->helper('download');
        $data = $this->db->get_where('pendidikan',['id_pendidikan'=>$id])->row();
		force_download('template/assets/pendidikan/'.$data->bukti_ijazah,NULL);
    }

    public function download_transkripnilai($id) {
        $this->load->helper('download');
        $data = $this->db->get_where('pendidikan',['id_pendidikan'=>$id])->row();
		force_download('template/assets/pendidikan/'.$data->transkrip_nilai,NULL);
    }
}
