<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SearchController extends CI_Controller {

	public function index()
	{
		$this->load->model('SearchModel');
        $this->load->model('Admin_model', 'admin');
		$keyword = $this->input->get('keyword');
		$data = $this->SearchModel->ambil_data($keyword);
		$data = array(
			'keyword'	=> $keyword,
			'data'		=> $data
		);
        template_view('admin/pegawai', $data);
	}

	public function cariDataUser()
	{
		$this->load->model('SearchModel');
        $this->load->model('Admin_model', 'admin');
		$keyword = $this->input->get('keyword');
		$data = $this->SearchModel->getUserData($keyword);
		$data = array(
			'keyword'	=> $keyword,
			'data'		=> $data
		);
        template_view('user/data_lengkap', $data);
	}

}
?>