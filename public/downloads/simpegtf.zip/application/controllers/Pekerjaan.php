<?php
defined('BASEPATH') or exit('No direct script access allowed');

class pekerjaan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    // public function index()
    // {
    //     $data['title'] = "Data Pekerjaan";

    //     $data['pekerjaan'] = $this->admin->getPekerjaan();
    //     template_view('pekerjaan/data', $data);
    // }

    // public function index_before()
    // {
    //     $data['title'] = "Data Pekerjaan";
    //     $data['pekerjaan'] = $this->admin->getPekerjaan();
    //     template_view('pekerjaan/data_belum', $data);
    // }

    // public function pekerjaan_user(){
    //     $input['status'] = "Belum";
    //     if($input['status'] = "Belum"){
    //                    redirect('pekerjaan');

    //     }
    //     else{
    //                     redirect('pekerjaan/index_before');

    //     }
    // }

    public function index()
    {
        $data['title'] = "Data pekerjaan";
        $data['pekerjaan'] = $this->admin->getpekerjaan_sudah();
        $data['pekerjaan1'] = $this->admin->getpekerjaan();
        template_view('pekerjaan/data', $data);
    }

    public function index_before()
    {
        $data['title'] = "Data pekerjaan";
        $data['pekerjaan'] = $this->admin->getpekerjaan_belum();
        template_view('pekerjaan/data_belum', $data);
    }

    public function detail_pekerjaan($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pekerjaan' => $id];
        $data['title'] = "Data pekerjaan";
        $data['pekerjaan'] = $this->admin->getpekerjaan_detailadmin($where);
        $data['pekerjaan1'] = $this->admin->getpekerjaan_detailadmin($where);
        template_view('pekerjaan/data', $data);
    }

    public function pekerjaan_user(){
        $status = $this->admin->getpekerjaan_belum();
        if($status = $this->admin->getpekerjaan_belum()){
            redirect('pekerjaan/index_before');
            
        }
        elseif($status = $this->admin->getpekerjaan_sudah()){
            redirect('pekerjaan');
        }
        else{
            redirect('pekerjaan/index_before');
        }
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('id_jabatan', 'Jabatan', 'required');
        $this->form_validation->set_rules('id_user', 'ID User', 'required');
        $this->form_validation->set_rules('id_tempat', 'id_tempat', 'required');
        $this->form_validation->set_rules('nip', 'nip', 'required|trim');
        $this->form_validation->set_rules('status_pegawai', 'Tempat Lahir', 'required|trim');
        $this->form_validation->set_rules('mulai', 'Tanggal Lahir', 'required|trim');
        $this->form_validation->set_rules('akhir', 'No. Telp', 'required|trim');
        $this->form_validation->set_rules('pangkat', 'pangkat', 'required|trim');
    }

    private function _config()
    {
        $config['upload_path']      = './template/assets/pekerjaan/';
        $config['allowed_types']    = 'jpg|jpeg|png|pdf';
        $config['max_size']         = '2048';
        $config['encrypt_name']     = FALSE;

        $this->load->library('upload', $config);
    }

    public function add()
    {
        $this->_config();
        $this->_validasi();
        if ($this->form_validation->run() == false || $this->upload->do_upload('bukti_kontrak') == false) {
            $data['title'] = "Tambah pekerjaan";
            $data['jabatan'] = $this->admin->get('jabatan');
            $data['tempat_tugas'] = $this->admin->get('tempat_tugas');
            template_view('pekerjaan/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $input['status'] = "Sudah";
            $input['bukti_kontrak'] = $this->upload->data('file_name');
            $insert = $this->admin->insert('pekerjaan', $input);
            if ($insert) {
                set_pesan('data berhasil disimpan');
                redirect('pekerjaan');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('pekerjaan/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_config();
        $this->_validasi();
        if ($this->form_validation->run() == false || $this->upload->do_upload('bukti_kontrak') == false) {
            $data['title'] = "Edit pekerjaan";
            $data['jabatan'] = $this->admin->get('jabatan');
            $data['tempat_tugas'] = $this->admin->get('tempat_tugas');
            $data['pekerjaan'] = $this->admin->get('pekerjaan', ['id_pekerjaan' => $id]);
            template_view('pekerjaan/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            // if (!empty($_FILES['bukti_kontrak']['name'])) {
            //     if ($this->upload->do_upload('bukti_kontrak')) {
            //         if ($this->upload->data()) {

            //             $dir = FCPATH . 'template/assets/pekerjaan/';
            //         }
            //     } else {
            //         if ($this->upload->display_errors()) {
            //             setMsg('danger', $this->upload->display_errors('', ''));
            //             redirect('pekerjaan/edit/' . $id);
            //         }
            //     }
            // }
            $input['status'] = "Sudah";
           $input['bukti_kontrak'] = $this->upload->data('file_name');
            $update = $this->admin->update('pekerjaan', 'id_pekerjaan', $id, $input);

            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('pekerjaan');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('pekerjaan/edit/' . $id);
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('pekerjaan', 'id_pekerjaan', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('pekerjaan');
    }

    public function download_kontrak($id) {
        $this->load->helper('download');
        $data = $this->db->get_where('pekerjaan',['id_pekerjaan'=>$id])->row();
		force_download('template/assets/pekerjaan/'.$data->bukti_kontrak,NULL);
    }
}
