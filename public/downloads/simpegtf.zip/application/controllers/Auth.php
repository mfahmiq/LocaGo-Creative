<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Auth_model', 'auth');
        $this->load->model('Admin_model', 'admin');
    }

    private function _has_login()
    {
        if($this->session->has_userdata('login_session')){
            redirect('profile/user/' . userdata('id_user'));
        }
            
    }

    public function index()
    {
        $this->_has_login();

        $this->form_validation->set_rules('username', 'Username', 'required|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Login';
           $this->load->view('auth/login', $data);
        } else {
            $input = $this->input->post(null, true);

            $cek_username = $this->auth->cek_username($input['username']);
            if ($cek_username > 0) {
                $password = $this->auth->get_password($input['username']);
                if (password_verify($input['password'], $password)) {
                    $user_db = $this->auth->userdata($input['username']);
                    if ($user_db['is_active'] != 1) {
                        set_pesan('akun anda belum aktif/dinonaktifkan. Silahkan hubungi admin.', false);
                        redirect('login');
                    } else {
                        $userdata = [
                            'user'  => $user_db['id_user'],
                            'role'  => $user_db['role'],
                            'timestamp' => time()
                        ];
                        $this->session->set_userdata('login_session', $userdata);
                        redirect('profile/user/' . userdata('id_user'));
                    }
                } else {
                    set_pesan('password salah', false);
                    redirect('auth');
                }
            } else {
                set_pesan('username belum terdaftar', false);
                redirect('auth');
            }
        }
    }

    public function logout()
    {
        
        $this->session->unset_userdata('login_session');

        set_pesan('anda telah berhasil logout');
        redirect('auth');
    }

    public function register()
    {

        $this->form_validation->set_rules('username', 'Username', 'required|min_length[3]|trim|is_unique[user.username]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[5]|trim');
        $this->form_validation->set_rules('konfpass', 'Konfirmasi Password', 'required|matches[password]');
        $this->form_validation->set_rules('nama', 'nama', 'required|trim');

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Registrasi';
            $this->load->view('auth/register', $data);
        } else {
            $input = $this->input->post(null, true);
            unset($input['konfpass']);
            $input['password']      = password_hash($input['password'], PASSWORD_DEFAULT);
            $input['role']         = 'Pegawai';
            $input['foto']          = 'user.png';
            $input['tanggal_bergabung']    = date('Y-m-d');
            $input['is_active']     = 1;

            $query = $this->admin->insert('user', $input);
            if ($query) {
                set_pesan('Registrasi berhasil, silahkan login!');
                redirect('auth');
            } else {
                set_pesan('Gagal Registrasi, Silahkan coba lagi!');
                redirect('auth/register');
            }
        }
    }
}
