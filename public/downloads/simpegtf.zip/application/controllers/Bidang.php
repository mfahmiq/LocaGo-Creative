<?php
defined('BASEPATH') or exit('No direct script access allowed');

class bidang extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Data bidang";
        $data['bidang'] = $this->admin->getBidang();
        template_view('bidang/data', $data);
    }

    public function bagian($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_bidang' => $id];

        $data['title'] = "Data Bagian";
        $data['bidang'] = $this->admin->getBidang();
        $data['bagian'] = $this->admin->getBagianDetail($id);
        
        template_view('bidang/data_bagian', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('nama_bidang', 'Nama bidang', 'required|trim');
        $this->form_validation->set_rules('id_user', 'ID User', 'required');
    }

    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Tambah bidang";
            $data['user'] = $this->admin->getKabid();
            template_view('bidang/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $input_data = [
                'nama_bidang' => $input['nama_bidang'],
                'id_user' => $input['id_user']
            ];
            $insert = $this->admin->insert('bidang', $input_data);
            if ($insert) {
                set_pesan('data berhasil disimpan');
                redirect('bidang');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('bidang/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Edit bidang";
            $data['user'] = $this->admin->getKabid();
            $data['bidang'] = $this->admin->get('bidang', ['id_bidang' => $id]);
            template_view('bidang/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('bidang', 'id_bidang', $id, $input);

            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('bidang');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('bidang/edit/' . $id);
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('bidang', 'id_bidang', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('bidang');
    }
}
