<?php
defined('BASEPATH') or exit('No direct script access allowed');

class pelatihan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Data pelatihan";
        $data['pelatihan'] = $this->admin->getpelatihan_belum();
        template_view('pelatihan/data', $data);
    }

    public function data_after()
    {
        $data['title'] = "Data Pelatihan";
        
        $data['pelatihan'] = $this->admin->getpelatihan_sudah();
        template_view('pelatihan/data_after', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('id_user', 'ID User', 'required');
        $this->form_validation->set_rules('nama_pelatihan', 'nama_pelatihan', 'required|trim');
        $this->form_validation->set_rules('media', 'Tempat Lahir', 'required|trim');
        $this->form_validation->set_rules('tanggal_pelatihan', 'Tanggal Lahir', 'required|trim');
    }

    private function _config()
    {
        $config['upload_path']      = './template/assets/pelatihan/';
        $config['allowed_types']    = 'jpg|jpeg|png|pdf';
        $config['max_size']         = '2048';
        $config['encrypt_name']     = FALSE;

        $this->load->library('upload', $config);
    }

    public function add()
    {
        $this->_config();
        $this->_validasi();
        if ($this->form_validation->run() == false || $this->upload->do_upload('bukti_pelatihan') == false) {
            $data['title'] = "Tambah pelatihan";
            template_view('pelatihan/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $input_data = [
                'id_user' => $this->session->userdata('login_session')['user'],
                'nama_pelatihan' => $input['nama_pelatihan'],
                'media' => $input['media'],
                'tanggal_pelatihan' => $input['tanggal_pelatihan'],
                'tempat' => $input['tempat'],
                'link' => $input['link'],
                'bukti_pelatihan' =>  $this->upload->data('file_name'),
                'status' => "Belum"
            ];
            $insert = $this->admin->insert('pelatihan', $input_data);
            if ($insert) {
                set_pesan('data berhasil disimpan');
                redirect('pelatihan');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('pelatihan/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_config();
        $this->_validasi();
        if ($this->form_validation->run() == false || $this->upload->do_upload('bukti_pelatihan') == false) {
            $data['title'] = "Edit pelatihan";
            $data['pelatihan'] = $this->admin->get('pelatihan', ['id_pelatihan' => $id]);
            template_view('pelatihan/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            if (!empty($_FILES['bukti_pelatihan']['name'])) {
                if ($this->upload->do_upload('bukti_pelatihan')) {
                    if ($this->upload->data()) {
                        $input['bukti_pelatihan'] = $this->upload->data('file_name');
                        $dir = FCPATH . 'template/assets/pelatihan/';
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        setMsg('danger', $this->upload->display_errors('', ''));
                        redirect('pelatihan/edit/' . $id);
                    }
                }
            }
            $media = "Offline";
            if($input['media'] == 'Offline'){
                $input_data = [
                'id_user' => $this->session->userdata('login_session')['user'],
                'nama_pelatihan' => $input['nama_pelatihan'],
                'tanggal_pelatihan' => $input['tanggal_pelatihan'],
                'bukti_pelatihan' =>  $this->upload->data('file_name'),
                'status' => "Belum",
                'tempat' => $input['tempat'],
                'link' => ""
                ];
            }
            else{
                $input_data = [
                'id_user' => $this->session->userdata('login_session')['user'],
                'nama_pelatihan' => $input['nama_pelatihan'],
                'tanggal_pelatihan' => $input['tanggal_pelatihan'],
                'bukti_pelatihan' =>  $this->upload->data('file_name'),
                'status' => "Belum",
                'link' => $input['link'],
                'tempat' => ""
                ];
            }
            $update = $this->admin->update('pelatihan', 'id_pelatihan', $id, $input_data);
            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('pelatihan');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('pelatihan/edit/' . $id);
            }
        }
    }

    public function kirim($getId)
    {
        $id = encode_php_tags($getId);
            $data['title'] = "Edit pelatihan";
            $data['pelatihan'] = $this->admin->get('pelatihan', ['id_pelatihan' => $id]);
            $input_data = [
                'status' => "Sudah"
            ];
            $update = $this->admin->update('pelatihan', 'id_pelatihan', $id, $input_data);

            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('pelatihan/data_after');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('pelatihan/data');
            }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('pelatihan', 'id_pelatihan', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('pelatihan');
    }

    public function detail_pelatihan($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pelatihan' => $id];

        $data['title'] = 'Detail';
        $data['pelatihan'] = $this->admin->getPelatihanDetail2($where);
        template_view('pelatihan/detail', $data);
    }

    public function detail_pelatihan_after($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pelatihan' => $id];

        $data['title'] = 'Detail';
        $data['pelatihan'] = $this->admin->getPelatihanDetail2($where);
        template_view('pelatihan/detail_after', $data);
    }

    public function detail_pelatihan_user($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pelatihan' => $id];

        $data['title'] = 'Detail';
        $data['pelatihan'] = $this->admin->getPelatihanDetail2($where);
        template_view('pelatihan/detail_pelatihan', $data);
    }

    public function download_pelatihan($id) {
        $this->load->helper('download');
        $data = $this->db->get_where('pelatihan',['id_pelatihan'=>$id])->row();
		force_download('template/assets/pelatihan/'.$data->bukti_pelatihan,NULL);
    }
    
}
