<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Perizinan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Data perizinan";
        $data['perizinan'] = $this->admin->getperizinan_belum();
        template_view('perizinan/data', $data);
    }

    public function data_after()
    {
        $data['title'] = "Data perizinan";
        $data['perizinan'] = $this->admin->getperizinan_sudah();
        template_view('perizinan/data_after', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('id_user', 'ID User', 'required');
        $this->form_validation->set_rules('no_str', 'No. STR', 'required|trim');
        $this->form_validation->set_rules('tanggal_str', 'Tanggal STR', 'required|trim');
        $this->form_validation->set_rules('no_sip', 'No. SIP', 'required|trim');
        $this->form_validation->set_rules('tanggal_sip', 'Tanggal SIP', 'required|trim');
    }

    private function _config()
    {
        $config['upload_path']      = './template/assets/perizinan/';
        $config['allowed_types']    = 'jpg|jpeg|png|pdf';
        $config['max_size']         = '2048';
        $config['encrypt_name']     = FALSE;

        $this->load->library('upload', $config);
    }

    public function add()
    {
        $this->_config();
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            if ($this->upload->display_errors()) {
                set_pesan('danger', $this->upload->display_errors('', ''));
            }
            $data['title'] = "Tambah perizinan";
            template_view('perizinan/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $input['status'] = "Belum";
            if (!empty($_FILES['bukti_str']['name'])) {
                if ($this->upload->do_upload('bukti_str')) {
                    if ($this->upload->data()) {
                        $input['bukti_str'] = $this->upload->data('file_name');
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        set_pesan($this->upload->display_errors('', ''));
                        redirect('perizinan/add');
                    }
                }
            }

            if (!empty($_FILES['bukti_sip']['name'])) {
                if ($this->upload->do_upload('bukti_sip')) {
                    if ($this->upload->data()) {
                        $input['bukti_sip'] = $this->upload->data('file_name');

                       
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        set_pesan($this->upload->display_errors('', ''));
                        redirect('perizinan/add');
                    }
                }
            }
            $insert = $this->admin->insert('perizinan', $input);
            if ($insert) {
                set_pesan('data berhasil disimpan');
                redirect('perizinan');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('perizinan/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_config();
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Edit perizinan";
            $data['perizinan'] = $this->admin->get('perizinan', ['id_perizinan' => $id]);
            template_view('perizinan/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $input['status'] = "Belum";
            if (!empty($_FILES['bukti_str']['name'])) {
                if ($this->upload->do_upload('bukti_str')) {
                    if ($this->upload->data()) {
                        $input['bukti_str'] = $this->upload->data('file_name');
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        set_pesan($this->upload->display_errors('', ''));
                        redirect('perizinan/add');
                    }
                }
            }

            if (!empty($_FILES['bukti_sip']['name'])) {
                if ($this->upload->do_upload('bukti_sip')) {
                    if ($this->upload->data()) {
                        $input['bukti_sip'] = $this->upload->data('file_name');

                       
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        set_pesan($this->upload->display_errors('', ''));
                        redirect('perizinan/add');
                    }
                }
            }
            $update = $this->admin->update('perizinan', 'id_perizinan', $id, $input);
            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('perizinan');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('perizinan/edit/' . $id);
            }
        }
    }

    public function kirim($getId)
    {
        $id = encode_php_tags($getId);
            $data['title'] = "Edit perizinan";
            $data['perizinan'] = $this->admin->get('perizinan', ['id_perizinan' => $id]);
            $input_data = [
                'status' => "Sudah"
            ];
            $update = $this->admin->update('perizinan', 'id_perizinan', $id, $input_data);

            if ($update) {
                set_pesan('data berhasil disimpan');
                redirect('perizinan/data_after');
            } else {
                set_pesan('gagal menyimpan data');
                redirect('perizinan/data');
            }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('perizinan', 'id_perizinan', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('perizinan');
    }

    public function download_str($id) {
        $this->load->helper('download');
        $data = $this->db->get_where('perizinan',['id_perizinan'=>$id])->row();
		force_download('template/assets/perizinan/'.$data->bukti_str,NULL);
    }

    public function download_sip($id) {
        $this->load->helper('download');
        $data = $this->db->get_where('perizinan',['id_perizinan'=>$id])->row();
		force_download('template/assets/perizinan/'.$data->bukti_sip,NULL);
    }
}
