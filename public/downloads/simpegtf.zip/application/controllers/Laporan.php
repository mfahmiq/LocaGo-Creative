<?php
defined('BASEPATH') or exit('No direct script access allowed');
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Fpdf\Fpdf;

class Laporan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index() { 

        $data['title'] = "Laporan Pegawai";
        $data['pekerjaan'] = $this->admin->getPekerjaan_laporan();
        template_view('admin/laporan', $data);
    }
    
    public function pegawai() { 

        $data['title'] = "Laporan Pegawai";
        $data['user'] = $this->admin->getUser_laporan();
        $data['biodata']  = $this->admin->getBiodata_laporan();
        $data['pekerjaan'] = $this->admin->getPekerjaan_laporan();
        $data['biodata1']  = $this->admin->getBiodata_laporan();
        $data['pekerjaan1'] = $this->admin->getPekerjaan_laporan();
        template_view('admin/laporan', $data);
    }

    public function download(){
        $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $sheet->setCellValue('A1', 'No');
            $sheet->setCellValue('B1', 'Nama');
            $sheet->setCellValue('C1', 'Jenis Kelamin');
            $sheet->setCellValue('D1', 'Alamat');
            $sheet->setCellValue('E1', 'Tempat, Tanggal Lahir');
            $sheet->setCellValue('F1', 'No Telp');
            $sheet->setCellValue('G1', 'Status Kawin');
            $sheet->setCellValue('H1', 'Agama');
            $sheet->setCellValue('I1', 'Jabatan');
            $sheet->setCellValue('J1', 'NIP');
            $sheet->setCellValue('K1', 'Tanggal Kontrak');
            $sheet->setCellValue('L1', 'Tempat Tugas');
            $sheet->setCellValue('M1', 'Pangkat');

            $pekerjaan = $this->admin->getPekerjaan_laporan();
            $no = 1;
            $x = 2;
            foreach($pekerjaan as $row)
            {
                $sheet->setCellValue('A'.$x, $no++);
                $sheet->setCellValue('B'.$x, $row['nama']);
                $sheet->setCellValue('C'.$x, $row['jenis_kelamin']);
                $sheet->setCellValue('D'.$x, $row['alamat']);
                $sheet->setCellValue('E'.$x, $row['tempat_lahir'].", ".indo_date($row['tanggal_lahir']));
                $sheet->setCellValue('F'.$x, $row['no_telp']);
                $sheet->setCellValue('G'.$x, $row['status_kawin']);
                $sheet->setCellValue('H'.$x, $row['agama']);
                $sheet->setCellValue('I'.$x, $row['nama_jabatan']);
                $sheet->setCellValue('J'.$x, $row['nip']);
                $sheet->setCellValue('K'.$x, indo_date($row['mulai'])." s/d ".indo_date($row['akhir']));
                $sheet->setCellValue('L'.$x, $row['nama_tempat']);
                $sheet->setCellValue('M'.$x, $row['pangkat']);
                $x++;
            }
            $writer = new Xlsx($spreadsheet);
            $filename = 'laporan_pegawai_'.date('Y-m-d');
            
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
            header('Cache-Control: max-age=0');
    
            $writer->save('php://output');
    }
}
?>