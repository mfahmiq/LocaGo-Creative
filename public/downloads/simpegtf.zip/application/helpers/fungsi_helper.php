<?php
function template_view($view, $data)
{
    $ci = get_instance();
    $ci->load->view('templates/header', $data);
    $ci->load->view('templates/topnav');
    $ci->load->view('templates/sidenav');
    $ci->load->view($view);
    $ci->load->view('templates/footer');
}

function cek_login()
{
    $ci = get_instance();
    if (!$ci->session->has_userdata('login_session')) {
        set_pesan('silahkan login.');
        redirect('auth');
    }
}

function is_admin()
{
    $ci = get_instance();
    $role = $ci->session->userdata('login_session')['role'];

    $status = true;

    if ($role != 'Admin') {
        $status = false;
    }

    return $status;
}

function is_pegawai()
{
    $ci = get_instance();
    $role = $ci->session->userdata('login_session')['role'];

    $status = true;

    if ($role != 'Pegawai') {
        $status = false;
    }

    return $status;
}

function is_direktur()
{
    $ci = get_instance();
    $role = $ci->session->userdata('login_session')['role'];

    $status = true;

    if ($role != 'Direktur') {
        $status = false;
    }

    return $status;
}

function set_pesan($pesan, $tipe = true)
{
    $ci = get_instance();
    if ($tipe) {
        $ci->session->set_flashdata('pesan',
        "<div class='alert text-white bg-success' role='alert'>
                        <div class='iq-alert-icon'>
                           <i class='ri-alert-line'></i>
                        </div>
                        <div class='iq-alert-text'><b>Success!</b> {$pesan} </div>
                        <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <i class='ri-close-line'></i>
                        </button>
                     </div>"
        );
    } else {
        $ci->session->set_flashdata('pesan',
        "<div class='alert text-white bg-danger' role='alert'>
                            <div class='iq-alert-icon'>
                            <i class='ri-information-line'></i>
                            </div>
                            <div class='iq-alert-text'><b>Error!</b> {$pesan} </div>
                            <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                            <i class='ri-close-line'></i>
                            </button>
                        </div>");
    }
}

function userdata($field)
{
    $ci = get_instance();
    $ci->load->model('Admin_model', 'admin');

    $userId = $ci->session->userdata('login_session')['user'];
    return $ci->admin->get('user', ['id_user' => $userId])[$field];
}

function output_json($data)
{
    $ci = get_instance();
    $data = json_encode($data);
    $ci->output->set_content_type('application/json')->set_output($data);
}

function indo_date($date, $print_day = false)
{
    $day        = [1 => 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
    $month      = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    $split      = explode('-', $date);
    $nice_date  = $split[2] . ' ' . $month[(int) $split[1]] . ' ' . $split[0];

    if ($print_day) {
        $num = date('N', strtotime($date));
        return $day[$num] . ', ' . $nice_date;
    }
    return $nice_date;
}
