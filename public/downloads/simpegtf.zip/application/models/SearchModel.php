<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SearchModel extends CI_Model {

	public function ambil_data($keyword=null){
		// $role = "Admin";
        // $this->db->where('role !=', $role);
        // $this->db->order_by('role asc');
		// if(!empty($keyword)){
		// 	$this->db->like('nama',$keyword);
        //     $this->db->like('role',$keyword);
		// }
		// return $this->db->get('user')->result_array();
		if(!empty($keyword)){
			$this->db->like('nama',$keyword);
            $this->db->or_like('role', $keyword);
		}
        $role = "Pegawai";
        $this->db->where('role', $role);
		return $this->db->get('user')->result_array();
	}
    

    public function getUserData($keyword=null){
		// $role = "Admin";
        // $this->db->where('role !=', $role);
        // $this->db->order_by('role asc');
		// if(!empty($keyword)){
		// 	$this->db->like('nama',$keyword);
        //     $this->db->like('role',$keyword);
		// }
		// return $this->db->get('user')->result_array();
		if(!empty($keyword)){
			$this->db->like('nama',$keyword);
            $this->db->or_like('role', $keyword);
            $this->db->or_like('tanggal_bergabung', $keyword);
            $this->db->or_like('status', $keyword);
		}
		return $this->db->get('user')->result_array();
	}

    // public function getPegawai()
    // {
    //     $role = "Admin";
    //     $this->db->where('role !=', $role);
    //     $this->db->order_by('role asc');
    //     return $this->db->get('user')->result_array();
    // }

}
?>