<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    public function get($table, $data = null, $where = null)
    {
        if ($data != null) {
            return $this->db->get_where($table, $data)->row_array();
        } else {
            return $this->db->get_where($table, $where)->result_array();
        }
    }
    
    public function update($table, $pk, $id, $data)
    {
        $this->db->where($pk, $id);
        return $this->db->update($table, $data);
    }

    public function insert($table, $data, $batch = false)
    {
        return $batch ? $this->db->insert_batch($table, $data) : $this->db->insert($table, $data);
    }

    public function delete($table, $pk, $id)
    {
        return $this->db->delete($table, [$pk => $id]);
    }

    public function getUsers($id)
    {
        /**
         * ID disini adalah untuk data yang tidak ingin ditampilkan. 
         * Maksud saya disini adalah 
         * tidak ingin menampilkan data user yang digunakan, 
         * pada managemen data user
         */
        
        $this->db->where('id_user !=', $id);
        return $this->db->get('user')->result_array();
    }

    function getjumlahpegawai_tempat() {
        // $status_arsip = "Sudah";
        // $this->db->select('j.role bidang, count(b.id_user) total');
        // $this->db->from('surat b');
        // $this->db->join('user j', 'b.id_user = j.id_user');
        // $this->db->join('klasifikasi k', 'b.id_klasifikasi = k.id_klasifikasi');
        // $this->db->where('b.status_arsip', $status_arsip);
        // $this->db->order_by('b.id_user');
        // $this->db->group_by('b.id_user');
        // $query = $this->db->get();
        // return $query->result_array();

        $status = "Sudah";
        $this->db->select('a.nama_jabatan jabatan, count(b.id_user) total');
        $this->db->from('pekerjaan b');
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->join('tempat_tugas t', 'b.id_tempat = t.id_tempat');
        $this->db->join('jabatan a', 'b.id_jabatan = a.id_jabatan');
        $this->db->where('b.status', $status);
        $this->db->order_by('b.id_pekerjaan');
        $this->db->group_by('b.id_pekerjaan');
        $query = $this->db->get();
        return $query->result_array();
  }

    public function getKabid()
    {
        $role = "Kabid";
        $this->db->where('role', $role);
        return $this->db->get('user')->result_array();
    }

    public function getKasi()
    {
        $role = "Kasi";
        $this->db->where('role', $role);
        return $this->db->get('user')->result_array();
    }

    public function getPetinggi()
    {
        $role = "Pegawai";
        $role1 = "Admin";
        $this->db->where('role !=', $role);
        $this->db->where('role !=', $role1);
        $this->db->order_by('id_user desc');
        return $this->db->get('user')->result_array();
    }

    public function JlhPetinggi()
    {
        $role = "Pegawai";
        $role1 = "Admin";
        $this->db->where('role !=', $role);
        $this->db->where('role !=', $role1);
        $query = $this->db->get('user b');
        return $query->num_rows();
    }

    public function getPegawai()
    {
        $role = "Pegawai";
        $this->db->where('role', $role);
        $this->db->order_by('id_user');
        return $this->db->get('user')->result_array();
    }

    public function JlhPegawai()
    {
        $role = "Pegawai";
        $this->db->where('role', $role);
        $query = $this->db->get('user b');
        return $query->num_rows();
    }

    public function getUser()
    {
        $role = "Admin";
        $this->db->where('role !=', $role);
        $this->db->order_by('id_user');
        return $this->db->get('user')->result_array();
    }

   public function getBidang()
    {
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->order_by('id_bidang desc');
        return $this->db->get('bidang b')->result_array();
    }

    public function getTempat_tugas()
    {
        $this->db->order_by('b.nama_tempat asc');
        return $this->db->get('tempat_tugas b')->result_array();
    }

    public function getJabatan()
    {
        $this->db->order_by('nama_jabatan asc');
        return $this->db->get('jabatan b')->result_array();
    }

    public function JlhTempat_tugas()
    {
        $query = $this->db->get('tempat_tugas');
        return $query->num_rows();
    }

    public function JlhJabatan()
    {
        $query = $this->db->get('jabatan');
        return $query->num_rows();
    }

    public function getBagian()
    {
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->join('bidang i', 'b.id_bidang = i.id_bidang');
        $this->db->order_by('id_bagian desc');
        return $this->db->get('bagian b')->result_array();
    }

    public function getBagianDetail($id)
    {
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->join('bidang i', 'b.id_bidang = i.id_bidang');
        $this->db->where('b.id_bidang =', $id);
        $this->db->order_by('id_bagian desc');
        return $this->db->get_where('bagian b')->result_array();
    }

    public function getPelatihanDetail2($where)
    {
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->order_by('id_pelatihan desc');
        return $this->db->get_where('pelatihan b')->result_array();
    }

    public function getBiodataDetail($where)
    {
        $status = "Sudah";
        $this->db->where('status', $status);
        $this->db->where('id_user', $this->session->userdata('login_session')['user']);
        return $this->db->get_where('user')->result_array();
    }

    public function getUserDetail($where)
    {
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        return $this->db->get_where('user')->result_array();
    }

    

    public function getPelatihan_sudah()
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_pelatihan desc');
        return $this->db->get('pelatihan b')->result_array();
    }

    public function getPelatihan_belum()
    {
        $status = "Belum";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_pelatihan desc');
        return $this->db->get('pelatihan b')->result_array();
    }

    public function getPerizinan_sudah()
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_perizinan desc');
        return $this->db->get('perizinan b')->result_array();
    }

    public function getPerizinan_belum()
    {
        $status = "Belum";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_perizinan desc');
        return $this->db->get('perizinan b')->result_array();
    }

    public function getPendidikan_sudah()
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_pendidikan desc');
        return $this->db->get('pendidikan b')->result_array();
    }

    public function getPendidikan_belum()
    {
        $status = "Belum";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_pendidikan desc');
        return $this->db->get('pendidikan b')->result_array();
    }

    public function getPendidikan($where)
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_pendidikan desc');
        return $this->db->get_where('pendidikan b')->result_array();
    }

    public function getPekerjaanDetail($where)
    {
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->join('jabatan a', 'b.id_jabatan = a.id_jabatan');
        $this->db->join('tempat_tugas t', 'b.id_tempat = t.id_tempat');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        return $this->db->get_where('pekerjaan b')->result_array();
    }

    public function getPelatihanDetail($where)
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_pelatihan desc');
        return $this->db->get_where('pelatihan b')->result_array();
    }

    public function getPerizinanDetail($where)
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_perizinan desc');
        return $this->db->get_where('perizinan b')->result_array();
    }

    public function JlhPelatihan_sudah()
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $query = $this->db->get('pelatihan b');
        return $query->num_rows();
    }

    public function JlhPelatihan_belum()
    {
        $status = "Belum";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $query = $this->db->get('pelatihan b');
        return $query->num_rows();
    }

    public function jlhBiodata()
    {
        $status = "Sudah";
        if($status = "Sudah"){
             $this->db->join('user j', 'b.id_user = j.id_user');
            $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
            $this->db->order_by('id_biodata desc');
            $this->db->where('b.status', $status);
            $query = $this->db->get('biodata b');
            return $query->num_rows();
        }
        else{
            $this->db->join('user j', 'b.id_user = j.id_user');
            $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
            $this->db->order_by('id_biodata desc');
            $this->db->where('b.status', $status);
            $query = $this->db->get('biodata b');
            return $query->num_rows();
        }
    }

    public function jlhPekerjaan()
    {
        $status = "Sudah";
        if($status = "Sudah"){
            $this->db->join('user j', 'b.id_user = j.id_user');
            $this->db->join('jabatan a', 'b.id_jabatan = a.id_jabatan');
            $this->db->join('tempat_tugas t', 'b.id_tempat = t.id_tempat');           
            $this->db->where('b.status', $status);
            $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
            $query = $this->db->get('pekerjaan b');
            return $query->num_rows();
        }
        else{
            $this->db->join('user j', 'b.id_user = j.id_user');
            $this->db->join('jabatan a', 'b.id_jabatan = a.id_jabatan');
            $this->db->join('tempat_tugas t', 'b.id_tempat = t.id_tempat');           
            $this->db->where('b.status', $status);
            $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
            $query = $this->db->get('pekerjaan b');
            return $query->num_rows();
        }
    }

    public function JlhPerizinan_sudah()
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $query = $this->db->get('perizinan b');
            return $query->num_rows();
    }

    public function JlhPendidikan_sudah()
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_pendidikan desc');
        $query = $this->db->get('pendidikan b');
            return $query->num_rows();
    }

    public function getBiodata_belum()
    {
        $status = "Belum";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_biodata desc');
        return $this->db->get('biodata b')->result_array();
    }

    public function getBiodata_sudah()
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_biodata desc');
        return $this->db->get('biodata b')->result_array();
    }

    public function getBiodata()
    {
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->order_by('id_user desc');
        return $this->db->get('user b')->result_array();
    }

    public function getPekerjaan_belum()
    {
        $status = "Belum";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->join('jabatan a', 'b.id_jabatan = a.id_jabatan');
        $this->db->join('tempat_tugas t', 'b.id_tempat = t.id_tempat');
        $this->db->where('b.status', $status);
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->order_by('id_pekerjaan desc');
        return $this->db->get('pekerjaan b')->result_array();
    }

    public function getPekerjaan_sudah()
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->join('jabatan a', 'b.id_jabatan = a.id_jabatan');
        $this->db->join('tempat_tugas t', 'b.id_tempat = t.id_tempat');
        $this->db->where('b.status', $status);
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->order_by('id_pekerjaan desc');
        return $this->db->get('pekerjaan b')->result_array();
    }

    public function getPekerjaan_admin()
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->join('jabatan a', 'b.id_jabatan = a.id_jabatan');
        $this->db->join('tempat_tugas t', 'b.id_tempat = t.id_tempat');
        $this->db->where('b.status', $status);
        $this->db->order_by('id_pekerjaan desc');
        return $this->db->get('pekerjaan b')->result_array();
    }

    public function getPekerjaan_detailadmin($where)
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->join('jabatan a', 'b.id_jabatan = a.id_jabatan');
        $this->db->join('tempat_tugas t', 'b.id_tempat = t.id_tempat');
        $this->db->where('b.status', $status);
        $this->db->order_by('id_pekerjaan desc');
        return $this->db->get_where('pekerjaan b',$where)->result_array();
    }

    public function getPekerjaan()
    {
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->join('jabatan a', 'b.id_jabatan = a.id_jabatan');
        $this->db->join('tempat_tugas t', 'b.id_tempat = t.id_tempat');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->order_by('id_pekerjaan desc');
        return $this->db->get('pekerjaan b')->result_array();
    }

    public function getBiodataDetail_user($id)
    {
        $this->db->where('id_user', $id);
        return $this->db->get_where('user b')->result_array();
    }

    public function getPekerjaanDetail_user($id)
    {
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->join('jabatan a', 'b.id_jabatan = a.id_jabatan');
        $this->db->join('tempat_tugas t', 'b.id_tempat = t.id_tempat');
        $this->db->where('b.id_user', $id);
        return $this->db->get_where('pekerjaan b')->result_array();
    }

    public function getPendidikan_user($id)
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $id);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_pendidikan desc');
        return $this->db->get_where('pendidikan b')->result_array();
    }

    public function getPelatihanDetail_user($id)
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $id);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_pelatihan desc');
        return $this->db->get('pelatihan b')->result_array();
    }

     public function getPerizinanDetail_user($id)
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $id);
        $this->db->where('b.status', $status);
        $this->db->order_by('id_perizinan desc');
        return $this->db->get_where('perizinan b')->result_array();
    }

    public function getUser_laporan()
    {
        $this->db->order_by('id_user');
        return $this->db->get('user')->result_array();
    }

    public function getBiodata_laporan()
    {
        $this->db->join('user j', 'b.id_user = j.id_user');
        return $this->db->get('biodata b')->result_array();
    }
    
    public function getPekerjaan_laporan()
    {
        $status = "Sudah";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->join('jabatan a', 'b.id_jabatan = a.id_jabatan');
        $this->db->join('tempat_tugas t', 'b.id_tempat = t.id_tempat');
        $this->db->where('b.status', $status);
        $this->db->where('j.status', $status);
        return $this->db->get('pekerjaan b')->result_array();
    }
}
