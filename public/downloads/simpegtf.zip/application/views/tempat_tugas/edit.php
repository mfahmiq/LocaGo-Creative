<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12 col-lg-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title?></h4>
                     </div>
                  </div>
                  <div class="card-body">
                     <p>Tanda dengan <span style="color:red">*</span>) wajib diisi!</p>
                <?= form_open('', [], ['id_tempat' => $tempat_tugas['id_tempat']]); ?>
                        <div class="form-group">
                           <label for="namatempat">Nama tempat: <span style="color:red">*</span>)</label>
                           <input type="text" class="form-control" id="nama_tempat" name="nama_tempat" value="<?= set_value('nama_tempat', $tempat_tugas['nama_tempat']); ?>" placeholder="Nama tempat">
                           <?= form_error('nama_tempat', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <!-- <div class="form-group">
                           <label for="kabid">Kabid: <span style="color:red">*</span>)</label>
                           <select name="id_user" class="selectpicker form-control" data-style="py-0" id="id_user">
                                <option value="" selected disabled>Pilih Kabid</option>
                                <?php foreach ($user as $s) : ?>
                                    <option <?= $tempat['id_user'] == $s['id_user'] ? 'selected' : ''; ?> <?= set_select('id_user', $s['id_user']) ?> value="<?= $s['id_user'] ?>"><?= $s['nama'] ?></option>
                                <?php endforeach; ?>
                              </select>
                        </div> -->
                        <a href="<?= base_url('tempat_tugas') ?>" class="btn btn-danger">Cancel</a>
                        <button type="submit" class="btn btn-primary">Add</button>
                <?= form_close(); ?>
                  </div>
               </div>
            </div>
            
         </div>
      </div>
      </div>