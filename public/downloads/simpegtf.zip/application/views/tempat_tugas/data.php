<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title; ?></h4>
                     </div>
                     <div class="col-auto">
                        <a href="<?= base_url('tempat_tugas/add') ?>" class="btn btn-primary">
                            <span class="icon">
                                <i class="fa fa-user-plus"></i>
                            </span>
                            <span class="text">
                                Add
                            </span>
                        </a>
                    </div>
                  </div>
                  <div class="card-body">
                    <?= $this->session->flashdata('pesan'); ?>
                     <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped">
                           <thead>
                              <tr class="ligth">
                                 <th>No.</th>
                                 <th>Tempat</th>
                                 <th>Aksi</th>
                              </tr>
                           </thead>
                           <tbody>
                                                <?php
                $no = 1;
                    foreach ($tempat_tugas as $tempat_tugas) :
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $tempat_tugas['nama_tempat']; ?></td>
                            <td>
                                                        <a class="btn btn-sm btn-icon btn-warning" data-toggle="tooltip" data-placement="top" title="Edit" data-original-title="Edit" href="<?= base_url('tempat_tugas/edit/') . $tempat_tugas['id_tempat'] ?>">
                                                           <i class="ri-pencil-line mr-0"></i>
                                                        </a>
                                                        <a onclick="return confirm('Yakin ingin menghapus data?')" class="btn btn-sm btn-icon btn-danger" data-toggle="tooltip" data-placement="top" title="Delete" data-original-title="Delete" href="<?= base_url('tempat_tugas/delete/') . $tempat_tugas['id_tempat'] ?>">
                                                            <i class="ri-delete-bin-line mr-0"></i>
                                                        </a>
                               
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>