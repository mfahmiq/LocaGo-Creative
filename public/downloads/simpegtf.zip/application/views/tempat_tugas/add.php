<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12 col-lg-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title?></h4>
                     </div>
                  </div>
                  <div class="card-body">
                     <p>Tanda dengan <span style="color:red">*</span>) wajib diisi!</p>
                            <?= form_open(); ?>
                        <div class="form-group">
                           <label for="namatempat_tugas">Nama Tempat: <span style="color:red">*</span>)</label>
                           <input type="text" class="form-control" id="nama_tempat" name="nama_tempat" value="<?= set_value('nama_tempat'); ?>" placeholder="Nama Tempat">
                           <?= form_error('nama_tempat', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <div class="form-group">
                           <label for="jabatan">Nama Jabatan: <span style="color:red">*</span>)</label>
                           <select name="id_jabatan" class="form-control selectpicker" data-style="py-0" data-live-search="true" id="id_jabatan">
                                <option value="" selected disabled>Pilih Jabatan</option>
                                <?php foreach ($jabatan as $s) : ?>
                                    <option <?= set_select('id_jabatan', $s['id_jabatan']) ?> value="<?= $s['id_jabatan'] ?>"><?= $s['nama_jabatan'] ?></option>
                                <?php endforeach; ?>
                              </select>
                        </div>
                        <a href="<?= base_url('tempat_tugas') ?>" class="btn btn-danger">Cancel</a>
                        <button type="submit" class="btn btn-primary">Add</button>
                <?= form_close(); ?>
                  </div>
               </div>
            </div>
            
         </div>
      </div>
      </div>