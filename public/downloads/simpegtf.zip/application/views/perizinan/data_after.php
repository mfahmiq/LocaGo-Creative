<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title; ?></h4>
                     </div>
                     <div class="col-auto">
                        <a href="<?= base_url('perizinan/add') ?>" class="btn btn-primary">
                            <span class="icon">
                                <i class="fa fa-user-plus"></i>
                            </span>
                            <span class="text">
                                Add
                            </span>
                        </a>
                    </div>
                  </div>
                  <div class="card-body">
                    <?= $this->session->flashdata('pesan'); ?>
                     <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped">
                           <thead>
                              <tr class="ligth">
                                 <th>No.</th>
                                 <th>STR</th>
                                 <th>Tanggal STR</th>
                                 <th>SIP</th>
                                 <th>Tanggal SIP</th>
                                 <th>Status</th>
                              </tr>
                           </thead>
                           <tbody>
                                                <?php
                $no = 1;
                    foreach ($perizinan as $perizinan) :
                        ?>
                        <tr>
                           <td><?= $no++; ?></td>
                            <td>
                              <a title ="Download Bukti" href="<?= base_url('perizinan/download_str/') . $perizinan['id_perizinan'] ?>"><?= $perizinan['no_str']; ?></a>
                           </td>
                            <td><?= indo_date($perizinan['tanggal_str']); ?></td>
                            <td>
                              <a title ="Download Bukti" href="<?= base_url('perizinan/download_sip/') . $perizinan['id_perizinan'] ?>"><?= $perizinan['no_sip']; ?></a>
                           </td>
                            <td><?= indo_date($perizinan['tanggal_sip']); ?></td>
                           <td>
                              <?php if ($perizinan['status'] == "Sudah") { ?>
                                 <span class="badge bg-success-light">Sudah</span>
                            <?php } ?>
                              <?php if ($perizinan['status'] == "Belum") { ?>
                                 <span class="badge bg-danger-light">Belum</span>
                            <?php } ?>
                              </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>