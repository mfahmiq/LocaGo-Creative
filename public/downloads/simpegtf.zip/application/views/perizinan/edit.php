<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12 col-lg-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title?></h4>
                     </div>
                  </div>
                  <div class="card-body">
                     <p>Tanda dengan <span style="color:red">*</span>) wajib diisi!</p>
                            <?= form_open_multipart('', [], ['id_user' => $this->session->userdata('login_session')['user']]); ?>
                     <div class="form-row">
                        <div class="col-md-6 mb-3">
                           <label for="no_str">Nomor STR: <span style="color:red">*</span>)</label>
                           <input type="text" class="form-control" id="no_str" name="no_str" value="<?= set_value('no_str', $perizinan['no_str']); ?>" placeholder="Nomor STR">
                           <?= form_error('no_str', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                           <label for="tanggalstr">Tanggal STR: <span style="color:red">*</span>)</label>
                           <input type="date" class="form-control" id="tanggal_str" name="tanggal_str" value="<?= set_value('tanggal_str', $perizinan['tanggal_str']); ?>" placeholder="Tanggal STR">
                           <?= form_error('tanggal_str', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                           <label>Bukti STR <span style="color:red">*</span>)</label>
                           <div class="custom-file">
                              <input type="file" name="bukti_str" class="custom-file-input" id="bukti_str">
                              <label class="custom-file-label" for="bukti_str">Pilih File</label>
                           </div>
                           <?= form_error('bukti_str', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                           <label for="no_sip">Nomor SIP: <span style="color:red">*</span>)</label>
                           <input type="text" class="form-control" id="no_sip" name="no_sip" value="<?= set_value('no_sip' , $perizinan['no_sip']); ?>" placeholder="Nomor SIP">
                           <?= form_error('no_sip', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                           <label for="tanggalsip">Tanggal STR: <span style="color:red">*</span>)</label>
                           <input type="date" class="form-control" id="tanggal_sip" name="tanggal_sip" value="<?= set_value('tanggal_sip' , $perizinan['tanggal_sip']); ?>" placeholder="Tanggal SIP">
                           <?= form_error('tanggal_sip', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                           <label>Bukti SIP <span style="color:red">*</span>)</label>
                           <div class="custom-file">
                              <input type="file" name="bukti_sip" class="custom-file-input" id="bukti_sip">
                              <label class="custom-file-label" for="bukti_sip">Pilih File</label>
                           </div>
                           <?= form_error('bukti_sip', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                     </div>
                        <a href="<?= base_url('perizinan') ?>" class="btn btn-danger">Cancel</a>
                        <button type="submit" class="btn btn-primary">Add</button>
                <?= form_close(); ?>
                  </div>
               </div>
            </div>
            
         </div>
      </div>
      </div>
      