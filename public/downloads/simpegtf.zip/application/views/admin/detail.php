<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-lg-12">
               <div class="card car-transparent">
                  <div class="card-body p-0">
                     <div class="profile-image position-relative">
                        <img src="<?= base_url('template/'); ?>assets/images/page-img/bgprofile.jpg" height="50px" class="img-fluid rounded w-100" alt="profile-image">
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="row m-sm-0 px-3">            
            <div class="col-lg-4 card-profile">
               <div class="card card-block card-stretch card-height">
                  <div class="card-body">
                     <div class="d-flex align-items-center mb-3">
                        <div class="profile-img position-relative">
                           <img src="<?= base_url('template/assets/user/') . $user['foto']; ?>" class="img-fluid rounded avatar-110" alt="profile-image">
                        </div>
                        <div class="ml-3">
                           <h4 class="mb-1"><?= $user['nama']; ?></h4>
                           <p class="mb-2"><?= $user['role']; ?></p>
                           <a href="" class="btn btn-primary font-size-14">Cetak</a>
                        </div>
                     </div>
                      
                     <ul class="list-inline p-0 m-0">
                        <?php
                           foreach ($pekerjaan as $pekerjaan) :
                        ?>
                        <li class="mb-2">
                           <div class="d-flex align-items-center">
                              <svg class="svg-icon mr-3" height="16" width="16" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                              </svg>
                              <p class="mb-0"><?= $pekerjaan['nama_jabatan']; ?></p>   
                           </div>
                        </li>
                        <?php endforeach; ?>

                        <?php
                           foreach ($user1 as $user) :
                        ?>
                        <li class="mb-2">
                           <div class="d-flex align-items-center">
                              <svg class="svg-icon mr-3" height="16" width="16" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                              </svg>
                              <p class="mb-0"><?= $user['alamat']; ?></p>   
                           </div>
                        </li>
                        

                        
                        <li class="mb-2">
                           <div class="d-flex align-items-center">
                              <svg class="svg-icon mr-3" height="16" width="16" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 15.546c-.523 0-1.046.151-1.5.454a2.704 2.704 0 01-3 0 2.704 2.704 0 00-3 0 2.704 2.704 0 01-3 0 2.704 2.704 0 00-3 0 2.704 2.704 0 01-3 0 2.701 2.701 0 00-1.5-.454M9 6v2m3-2v2m3-2v2M9 3h.01M12 3h.01M15 3h.01M21 21v-7a2 2 0 00-2-2H5a2 2 0 00-2 2v7h18zm-3-9v-2a2 2 0 00-2-2H8a2 2 0 00-2 2v2h12z" />
                              </svg>
                              <p class="mb-0"><?= $user['tempat_lahir']; ?>, <?= indo_date($user['tanggal_lahir']); ?></p>   
                           </div>
                        </li>
                        <li class="mb-2">
                           <div class="d-flex align-items-center">
                              <svg class="svg-icon mr-3" height="16" width="16" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                              </svg>
                              <p class="mb-0"><?= $user['no_telp']; ?></p>   
                           </div>
                        </li>
                        <li>
                           <div class="d-flex align-items-center">
                              <svg class="svg-icon mr-3" height="16" width="16" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                              </svg>
                              <p class="mb-0"><?= $user['email']; ?></p>   
                           </div>
                        </li>
                        <?php endforeach; ?>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-lg-8 card-profile">
               <div class="card card-block card-stretch card-height">
                  <div class="card-body">
                     <ul class="d-flex nav nav-pills mb-3 text-center profile-tab" id="profile-pills-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#profile1" role="tab" aria-selected="false">Biodata</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#profile2" role="tab" aria-selected="false">Pendidikan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#profile3" role="tab" aria-selected="false">Pekerjaan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#profile4" role="tab" aria-selected="false">Pelatihan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#profile5" role="tab" aria-selected="true">Perizinan</a>
                        </li>
                    </ul>
                     <div class="profile-content tab-content">
                        
                        <div id="profile1" class="tab-pane">
                           <div class="row">
                              <div class="card-body">
                                 <div class="table-responsive">  
	                           <table class="table table-bordered">
                              <?php
                                 foreach ($user2 as $user) :
                              ?>
                                 <tr>
                                    <td width="30%">Nama</td>
                                    <td width="70%"><?= $user['nama']; ?></td>
                                 </tr>
                                 <tr>
                                    <td width="30%">Jenis Kelamin</td>
                                    <td width="70%"><?= $user['jenis_kelamin']; ?></td>
                                 </tr>
                                 <tr>
                                    <td width="30%">Status Kawin</td>
                                    <td width="70%"><?= $user['status_kawin']; ?></td>
                                 </tr>
                                 <tr>
                                    <td width="30%">Agama</td>
                                    <td width="70%"><?= $user['agama']; ?></td>
                                 </tr>
                                 <tr>
                                    <td width="30%">KTP</td>
                                    <td width="70%">                              
                                       <a href="<?= base_url('biodata/download_ktp/') . $user['id_user'] ?>"><?= $user['ktp']; ?></a>
                                    </td>
                                 </tr>
                                 <tr>
                                    <td width="30%">KK</td>
                                    <td width="70%">                              
                                       <a href="<?= base_url('biodata/download_kk/') . $user['id_user'] ?>"><?= $user['kk']; ?></a>
                                    </td>
                                 </tr>
                              <?php endforeach; ?>
                              </table>
                              </div>
                               </div>
                           </div>
                        </div>
                        <div id="profile2" class="tab-pane fade">
                           <div class="row">
                              <div class="col-sm-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title">Pendidikan</h4>
                     </div>
                     
                  </div>
                  <div class="card-body">
                     <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped">
                           <thead>
                              <tr class="ligth">
                                 <th>No.</th>
                                 <th>Sekolah</th>
                                 <th>Jurusan</th>
                                 <th>Tahun Lulus</th>
                                 <th>Ijazah</th>
                                 <th>Transkrip Nilai</th>
                              </tr>
                           </thead>
                           <tbody>
                                                <?php
                $no = 1;
                    foreach ($pendidikan as $pendidikan) :
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $pendidikan['sekolah']; ?></td>
                            <td><?= $pendidikan['jurusan']; ?></td>
                            <td><?= $pendidikan['tahun_lulus']; ?></td>
                            <td>                              
                              <a href="<?= base_url('pendidikan/download_ijazah/') . $pendidikan['id_pendidikan'] ?>">DOWNLOAD</a>
                           </td>
                           <td>                              
                              <a href="<?= base_url('pendidikan/download_transkripnilai/') . $pendidikan['id_pendidikan'] ?>">DOWNLOAD</a>
                           </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
                           </div>
                        </div>
                        <div id="profile3" class="tab-pane fade">
                           <div class="row"> 
                              <div class="card-body">
                                 <div class="table-responsive">  
	                           <table class="table table-bordered">
                              <?php
                                 foreach ($pekerjaan1 as $pekerjaan) :
                              ?>
                                 <tr>
                                    <td width="30%">Jabatan</td>
                                    <td width="70%"><?= $pekerjaan['nama_jabatan']; ?></td>
                                 </tr>
                                 <tr>
                                    <td width="30%">Tempat Tugas</td>
                                    <td width="70%"><?= $pekerjaan['nama_tempat']; ?></td>
                                 </tr>
                                 <tr>
                                    <td width="30%">NIP/No. Reg</td>
                                    <td width="70%"><?= $pekerjaan['nip']; ?></td>
                                 </tr>
                                 <tr>
                                    <td width="30%">Pangkat</td>
                                    <td width="70%"><?= $pekerjaan['pangkat']; ?></td>
                                 </tr>
                                 <tr>
                                    <td width="30%">Status Pegawai</td>
                                    <td width="70%"><?= $pekerjaan['status_pegawai']; ?></td>
                                 </tr>
                                 <tr>
                                    <td width="30%">Masa Kerja</td>
                                    <td width="70%"><?= indo_date($pekerjaan['mulai']); ?> s/d <?= indo_date($pekerjaan['akhir']); ?></td>
                                 </tr>
                                 <tr>
                                    <td width="30%">Bukti Kontrak</td>
                                    <td width="70%">
                                       <a href="<?= base_url('pekerjaan/download_kontrak/') . $pekerjaan['id_pekerjaan']; ?>"><?= $pekerjaan['bukti_kontrak']; ?></a>
                                    </td>
                                 </tr>
                              <?php endforeach; ?>
                              </table>
                              </div>
                               </div>
                           </div>
                        </div>
                        <div id="profile4" class="tab-pane fade">
                           <div class="row">
                  <div class="card-body">
                     <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped">
                           <thead>
                              <tr class="ligth">
                                 <th>No.</th>
                                 <th>Kegiatan</th>
                                 <th>Tanggal</th>
                                 <th>Media</th>
                                 <th>Bukti Pelatihan</th>
                              </tr>
                           </thead>
                           <tbody>
                <?php
                $no = 1;
                    foreach ($pelatihan as $pelatihan) :
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><a title="Detail" href="<?= base_url('pelatihan/detail_pelatihan_user/') . $pelatihan['id_pelatihan'] ?>"><?= $pelatihan['nama_pelatihan']; ?></a></td>
                            <td><?= indo_date($pelatihan['tanggal_pelatihan']); ?></td>
                            <td><?= $pelatihan['media']; ?></td>
                            <td>
                              <a href="<?= base_url('pelatihan/download_pelatihan/') . $pelatihan['id_pelatihan']; ?>"><?= $pelatihan['bukti_pelatihan']; ?></a>
                              </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                        </table>
                     </div>
                  </div>
                           </div>
                        </div>
                        <div id="profile5" class="tab-pane fade">
                           <div class="row">
                                                <div class="card-body">
                     <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped">
                           <thead>
                              <tr class="ligth">
                                 <th>No.</th>
                                 <th>STR</th>
                                 <th>Tanggal STR</th>
                                 <th>SIP</th>
                                 <th>Tanggal SIP</th>
                              </tr>
                           </thead>
                           <tbody>
                                                <?php
                $no = 1;
                    foreach ($perizinan as $perizinan) :
                        ?>
                        <tr>
                           <td><?= $no++; ?></td>
                            <td>
                              <a title ="Download Bukti" href="<?= base_url('perizinan/download_str/') . $perizinan['id_perizinan'] ?>"><?= $perizinan['no_str']; ?></a>
                           </td>
                            <td><?= indo_date($perizinan['tanggal_str']); ?></td>
                            <td>
                              <a title ="Download Bukti" href="<?= base_url('perizinan/download_sip/') . $perizinan['id_perizinan'] ?>"><?= $perizinan['no_sip']; ?></a>
                           </td>
                            <td><?= indo_date($perizinan['tanggal_sip']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                        </table>
                     </div>
                  </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>