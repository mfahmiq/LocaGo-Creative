<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title; ?></h4>
                     </div>
                     <div class="col-auto">
                        <a href="<?= base_url('laporan/download') ?>" class="btn btn-primary">
                            <span class="icon">
                                <i class="fa fa-user-plus"></i>
                            </span>
                            <span class="text">
                                Download
                            </span>
                        </a>
                    </div>
                  </div>
                  <div class="card-body">
                    <?= $this->session->flashdata('pesan'); ?>
                     <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped">
                           <thead>
                              <tr class="ligth">
                                 <th>No.</th>
                                 <th>Nama</th>
                                 <th>TTL</th>
                                 <th>No. Telp</th>
                                 <th>Email</th>
                                 <th>Status Kawin</th>
                                 <th>Agama</th>
                                 <th>Jabatan</th>
                                 <th>NIP/No. Reg</th>
                                 <th>Tanggal Kontrak</th>
                                 <th>Tempat Tugas</th>
                                 <th>Pangkat</th>
                              </tr>
                           </thead>
                           <tbody>
                                                <?php
                $no = 1;
                    foreach ($pekerjaan as $pekerjaan) :
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $pekerjaan['nama']; ?></td>
                            <td><?= $pekerjaan['tempat_lahir']; ?>, <?= indo_date($pekerjaan['tanggal_lahir']); ?></td>
                            <td><?= $pekerjaan['no_telp']; ?></td>
                            <td><?= $pekerjaan['email']; ?></td>
                            <td><?= $pekerjaan['status_kawin']; ?></td>
                            <td><?= $pekerjaan['agama']; ?></td>
                            <td><?= $pekerjaan['nama_jabatan']; ?></td>
                            <td><?= $pekerjaan['nip']; ?></td>
                            <td><?= indo_date($pekerjaan['mulai']); ?> s/d <?= indo_date($pekerjaan['mulai']); ?></td>
                            <td><?= $pekerjaan['nama_tempat']; ?></td>
                            <td><?= $pekerjaan['pangkat']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>