<div class="content-page">
     <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between breadcrumb-content">
                            <h5>Data Pegawai</h5>
                            <div class="iq-search-bar device-search">
                                      <form action="<?= base_url('SearchController') ?>" method="get" class="searchbox">
                                          <button class="search-link" type="submit"><i class="ri-search-line"></i></button>
                                          <input type="text" name="keyword" class="text search-input" placeholder="Search here...">
                                      </form>
                                  </div>
                                  
                        </div>
                        
                    </div>
                    <!-- <?php if(!empty($keyword)){ ?>
                                    <p style="color:orange"><b>Menampilkan data dengan kata kunci : "<?= $keyword; ?>"</b></p>
                                 <?php } ?> -->
                </div>
            </div>
        </div>
       
        <div id="grid" class="item-content animate__animated animate__fadeIn active" data-toggle-extra="tab-content">
             
            <div class="row">
                <?php foreach ($data as $row) { ?>
                <div class="col-lg-4 col-md-6">
                     
                    <div class="card-transparent card-block card-stretch card-height">
                        <div class="card-body text-center p-0"> 
                                  
                            <div class="item">
     
                                <div class="odr-img">
                                    <img src="<?= base_url() ?>template/assets/user/<?= $row['foto'] ?>" alt="<?= $row['nama']; ?>" class="img-fluid rounded-circle avatar-90 m-auto">
                                </div>                        
                                <div class="odr-content rounded">                                          
                                    <h4 class="mb-2"><?= $row['nama'] ?></h4>
                                    <p class="mb-3"><?= $row['role'] ?></p>
                                    <!-- <ul class="list-unstyled mb-3">
                                        <li class="bg-secondary-light rounded-circle iq-card-icon-small mr-4"><i class="ri-mail-open-line m-0"></i></li>
                                        <li class="bg-primary-light rounded-circle iq-card-icon-small mr-4"><i class="ri-chat-3-line m-0"></i></li>
                                        <li class="bg-success-light rounded-circle iq-card-icon-small"><i class="ri-phone-line m-0"></i></li>
                                    </ul>                                     -->
                                    <div class="pt-3 border-top">
                                        <a href="<?= base_url('user/detail/') . $row['id_user'] ?>" class="btn btn-primary">Detail</a>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
                    </div>
                </div>
                <?php }?>
            </div>
             
        </div>
    </div>
      </div>