<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title; ?></h4>
                     </div>
                     <div class="col-auto">
                        <a href="<?= base_url('pendidikan/add') ?>" class="btn btn-primary">
                            <span class="icon">
                                <i class="fa fa-user-plus"></i>
                            </span>
                            <span class="text">
                                Add
                            </span>
                        </a>
                    </div>
                  </div>
                  <div class="card-body">
                    <?= $this->session->flashdata('pesan'); ?>
                     <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped">
                           <thead>
                              <tr class="ligth">
                                 <th>No.</th>
                                 <th>Sekolah</th>
                                 <th>Jurusan</th>
                                 <th>Tahun Lulus</th>
                                 <th>Ijazah</th>
                                 <th>Transkrip Nilai</th>
                                 <th>Status</th>
                                 <th>Aksi</th>
                              </tr>
                           </thead>
                           <tbody>
                                                <?php
                $no = 1;
                    foreach ($pendidikan as $pendidikan) :
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $pendidikan['sekolah']; ?></td>
                            <td><?= $pendidikan['jurusan']; ?></td>
                            <td><?= $pendidikan['tahun_lulus']; ?></td>
                            <td>                              
                              <a href="<?= base_url('pendidikan/download_ijazah/') . $pendidikan['id_pendidikan'] ?>">DOWNLOAD</a>
                           </td>
                           <td>                              
                              <a href="<?= base_url('pendidikan/download_transkripnilai/') . $pendidikan['id_pendidikan'] ?>">DOWNLOAD</a>
                           </td>
                           <td>
                              <?php if ($pendidikan['status'] == "Sudah") { ?>
                                 <span class="badge bg-success-light">Sudah</span>
                            <?php } ?>
                              <?php if ($pendidikan['status'] == "Belum") { ?>
                                 <span class="badge bg-danger-light">Belum</span>
                            <?php } ?>
                              </td>
                              <td>
                              <a class="btn btn-sm bg-warning-light" data-toggle="tooltip" data-placement="top" title=""
                                    data-original-title="Kirim" href="<?= base_url('pendidikan/kirim/') . $pendidikan['id_pendidikan'] ?>"><i class="ri-user-add-line mr-0"></i></a>
                                                        <a class="btn btn-sm btn-icon btn-info" data-toggle="tooltip" data-placement="top" title="Edit" data-original-title="Edit" href="<?= base_url('pendidikan/edit/') . $pendidikan['id_pendidikan'] ?>">
                                                           <i class="ri-pencil-line mr-0"></i>
                                                        </a>
                                                        <a onclick="return confirm('Yakin ingin menghapus data?')" class="btn btn-sm btn-icon btn-danger" data-toggle="tooltip" data-placement="top" title="Delete" data-original-title="Delete" href="<?= base_url('pendidikan/delete/') . $pendidikan['id_pendidikan'] ?>">
                                                            <i class="ri-delete-bin-line mr-0"></i>
                                                        </a>
                               
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>