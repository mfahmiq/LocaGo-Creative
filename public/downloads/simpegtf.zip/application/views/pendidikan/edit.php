<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12 col-lg-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title?></h4>
                     </div>
                  </div>
                  <div class="card-body">
                     <p>Tanda dengan <span style="color:red">*</span>) wajib diisi!</p>
                            <?= form_open_multipart('', [], ['id_user' => $this->session->userdata('login_session')['user']]); ?>
                     <div class="form-row">
                        <div class="col-md-12 mb-3">
                           <label for="sekolah">Sekolah: <span style="color:red">*</span>)</label>
                           <input type="text" class="form-control" id="sekolah" name="sekolah" value="<?= set_value('sekolah', $pendidikan['sekolah']); ?>" placeholder="Nomor STR">
                           <?= form_error('sekolah', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                           <label for="jurusan">Jurusan: <span style="color:red">*</span>)</label>
                           <input type="text" class="form-control" id="jurusan" name="jurusan" value="<?= set_value('jurusan', $pendidikan['jurusan']); ?>" placeholder="Nomor SIP">
                           <?= form_error('jurusan', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                           <label for="tanggal_lulus">Tahun Lulus: <span style="color:red">*</span>)</label>
                           <input type="number" class="form-control" id="tahun_lulus" name="tahun_lulus" value="<?= set_value('tahun_lulus', $pendidikan['tahun_lulus']); ?>" placeholder="Tanggal STR">
                           <?= form_error('tahun_lulus', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                           <label>Bukti Ijazah <span style="color:red">*</span>)</label>
                           <div class="custom-file">
                              <input type="file" name="bukti_ijazah" class="custom-file-input" id="bukti_ijazah">
                              <label class="custom-file-label" for="bukti_ijazah">Pilih File</label>
                           </div>
                           <?= form_error('bukti_ijazah', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                           <label>Transkrip Nilai <span style="color:red">*</span>)</label>
                           <div class="custom-file">
                              <input type="file" name="transkrip_nilai" class="custom-file-input" id="transkrip_nilai">
                              <label class="custom-file-label" for="transkrip_nilai">Pilih File</label>
                           </div>
                           <?= form_error('transkrip_nilai', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                     </div>
                        <a href="<?= base_url('pendidikan') ?>" class="btn btn-danger">Cancel</a>
                        <button type="submit" class="btn btn-primary">Add</button>
                <?= form_close(); ?>
                  </div>
               </div>
            </div>
            
         </div>
      </div>
      </div>
      