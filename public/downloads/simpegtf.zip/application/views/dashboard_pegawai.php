<div class="content-page">
     <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-lg-6">
                <div class="card card-block card-stretch card-height">
                    <div class="card-body">
                        <div class="top-block d-flex align-items-center justify-content-between">
                            <h5>Jumlah Pelatihan</h5>
                            <a href="<?= base_url('pelatihan/data_after'); ?>"><span class="badge badge-primary">Sudah</span></a>
                        </div>
                        <h3><span class="counter"><?= $jlh_pelatihan_sudah; ?></span></h3>
                        <div class="d-flex align-items-center justify-content-between mt-1">
                            <p class="mb-0">Total Pelatihan</p>
                            <span class="text-primary"><?= $jlh_pelatihan_sudah; ?>%</span>
                        </div>
                        <div class="iq-progress-bar bg-primary-light mt-2">
                            <span class="bg-primary iq-progress progress-1" data-percent="<?= $jlh_pelatihan_sudah; ?>"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-6">
                <div class="card card-block card-stretch card-height">
                    <div class="card-body">
                        <div class="top-block d-flex align-items-center justify-content-between">
                            <h5>Jumlah Pelatihan</h5>
                            <a href="<?= base_url('pelatihan'); ?>"><span class="badge badge-warning">Belum</span></a>
                        </div>
                        <h3><span class="counter"><?= $jlh_pelatihan_belum; ?></span></h3>
                        <div class="d-flex align-items-center justify-content-between mt-1">
                            <p class="mb-0">Total Pelatihan</p>
                            <span class="text-warning"><?= $jlh_pelatihan_belum; ?>%</span>
                        </div>
                        <div class="iq-progress-bar bg-warning-light mt-2">
                            <span class="bg-warning iq-progress progress-1" data-percent="<?= $jlh_pelatihan_belum; ?>"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-8">
                <div class="card-transparent card-block card-stretch card-height">
                    <div class="card-body p-0">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Kelengkapan Data</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <ul class="list-inline p-0 mb-0">
                                    <li class="mb-1">
                                        <div class="d-flex align-items-center justify-content-between row">
                                            <div class="col-sm-3">
                                                <a href="<?= base_url('biodata/biodata_user') ?>"><p class="mb-0">Kelengkapan Biodata</p></a>
                                            </div>
                                                        <?php foreach ($biodata as $biodata) : ?>
                                                            <?php 
                                                            $biodata['status'] == "Sudah";
                                                            if($biodata['status'] == "Sudah"){
                                                               echo "<div class='col-sm-6'>
                                                                <div class='d-flex align-items-center justify-content-between'>
                                                                    <div class='iq-progress-bar bg-secondary-light'>
                                                               <span class='bg-secondary iq-progress progress-1' data-percent='100'></span>
                                                               </div>
                                                                    <span class='ml-3'>".$jlh_biodata."00%</span>
                                                                </div>                                                                  
                                                            </div>";
                                                            }
                                                            else{
                                                                echo "<div class='col-sm-6'>
                                                                <div class='d-flex align-items-center justify-content-between'>
                                                                    <div class='iq-progress-bar bg-secondary-light'>
                                                               <span class='bg-secondary iq-progress progress-1' data-percent='0'></span>
                                                               </div>
                                                                    <span class='ml-3'>".$jlh_biodata."%</span>
                                                                </div>                                                                  
                                                            </div>";
                                                            }
                                                            ?>
                                                        <?php endforeach; ?>
                                        </div>
                                    </li>
                                    <li class="mb-1">
                                        <div class="d-flex align-items-center justify-content-between row">
                                            <div class="col-sm-3">
                                                <a href="<?= base_url('pekerjaan/pekerjaan_user') ?>"><p class="mb-0">Kelengkapan Pekerjaan</p></a>
                                            </div>
                                            <?php foreach ($pekerjaan as $pekerjaan) : ?>
                                            <?php 
                                                            $pekerjaan['status'] == "Sudah";
                                                            if($pekerjaan['status'] == "Sudah"){
                                                               echo "<div class='col-sm-6'>
                                                                <div class='d-flex align-items-center justify-content-between'>
                                                                    <div class='iq-progress-bar bg-secondary-light'>
                                                               <span class='bg-primary iq-progress progress-1' data-percent='100'></span>
                                                               </div>
                                                                    <span class='ml-3'>".$jlh_pekerjaan."00%</span>
                                                                </div>                                                                  
                                                            </div>";
                                                            }
                                                            else{
                                                                echo "<div class='col-sm-6'>
                                                                <div class='d-flex align-items-center justify-content-between'>
                                                                    <div class='iq-progress-bar bg-secondary-light'>
                                                               <span class='bg-primary iq-progress progress-1' data-percent='0'></span>
                                                               </div>
                                                                    <span class='ml-3'>".$jlh_pekerjaan."%</span>
                                                                </div>                                                                  
                                                            </div>";
                                                            }
                                                            ?>
                                            <?php endforeach; ?>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                       <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="row align-items-center">
                                                    <div class="col-md-3">
                                                        <div id="circle-progress-22" class="circle-progress-01 circle-progress circle-progress-secondary" data-min-value="0" data-max-value="100" data-value="<?= $jlh_perizinan; ?>" data-type="percent"></div>
                                                    </div>
                                                    <div class="col-md-9">
                                                        <div class="mt-3 mt-md-0">
                                                            <h5 class="mb-1">Perizinan</h5>
                                                            <p class="mb-0">Silahkan menambahkan data SIP dan STR terbaru <a href="<?= base_url('perizinan'); ?>">disini</a></p>
                                                    </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                <div class="card-transparent mb-0">
                    <div class="card-header d-flex align-items-center justify-content-between p-0 pb-3">
                        <div class="header-title">
                            <a href="<?= base_url('pendidikan') ?>"><h4 class="card-title">Pendidikan</h4></a>
                        </div>
                        <div class="card-header-toolbar d-flex align-items-center">
                            <div id="top-project-slick-arrow" class="slick-aerrow-block">
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-unstyled row top-projects mb-0">
                            <?php $i = 1; ?>
                            <?php foreach ($pendidikan as $pendidikan) :
                                         ?>
                            <li class="col-lg-4">                                  
                                <div class="card">
                                    <div class="card-body"> 
                                        
                                        <h5 class="mb-3"><?= $pendidikan['sekolah']; ?> - <?= $pendidikan['jurusan']; ?></h5>
                                        <p class="mb-3"><i class="las la-calendar-check mr-2"></i><?= $pendidikan['tahun_lulus']; ?></p>
                                        <div class="iq-progress-bar bg-secondary-light mb-4">
                                            <span class="bg-secondary iq-progress progress-1" data-percent="100"></span>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div>
                                                <a href="<?= base_url('pendidikan/detail/').$pendidikan['id_pendidikan'] ?>" class="btn bg-secondary-light">Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            
                        <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
                        </div>
                    </div>
                </div>
                
            </div>
            
            <div class="col-xl-4">
                <div class="card card-block card-stretch card-height">
                    <div class="card-body">
                        <div class="card border-bottom pb-2 shadow-none">
                            <div class="card-body text-center inln-date flet-datepickr">
                                <input type="text" id="inline-date" class="date-input basicFlatpickr d-none" readonly="readonly">
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            
        </div>
        <!-- Page end  -->
    </div>
      </div>