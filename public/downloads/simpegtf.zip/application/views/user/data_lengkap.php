<div class="content-page">
<div class="container-fluid">
   <div class="row">
      <div class="col-sm-12">
         <div class="card">
            <div class="card-header d-flex justify-content-between">
               <div class="header-title">
                  <h4 class="card-title">Data User</h4>
               </div>
            </div>
            <div class="card-body">
               <div class="table-responsive">
                  <div class="row justify-content-between">
                     <div class="col-sm-6 col-md-6">
                        <div id="user_list_datatable_info" method="get" class="dataTables_filter">
                           <form action="<?= base_url('SearchController/cariDataUser') ?>" class="mr-3 position-relative">
                              <div class="form-group mb-0">
                                 <input name="keyword" type="search" class="form-control" placeholder="Search"
                                    aria-controls="user-list-table">
                              </div>
                           </form>
                        </div>
                     </div>
                     <div class="col-sm-6 col-md-6">
                        <div class="user-list-files d-flex">
                           <a class="bg-primary" href="<?= base_url('user/add') ?>">
                              Add
                           </a>
                        </div>
                     </div>
                  </div>
                  <table id="user-list-table" class="table table-striped dataTable mt-4" role="grid"
                     aria-describedby="user-list-page-info">
                     <thead>
                        <tr class="ligth">
                           <th>No.</th>
                           <th>Foto</th>
                           <th>Nama</th>
                           <th>Username</th>
                           <th>Role</th>
                           <th>Status</th>
                           <th>Tanggal Bergabung</th>
                           <th style="min-width: 100px">Action</th>
                        </tr>
                     </thead>
                     <tbody>
                                    
                        <?php $no = 1;
                         foreach ($data as $row) { ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td>
                                <img src="<?= base_url() ?>template/assets/user/<?= $row['foto'] ?>" alt="<?= $row['nama']; ?>" class="rounded img-fluid avatar-40">
                            </td>
                            <td><?= $row['nama']; ?></td>
                            <td><?= $row['username']; ?></td>
                            <td><?= $row['role']; ?></td>
                            <td>
                                <?php if ($row['is_active'] == 1) { ?>
                                    <span class="badge bg-primary">Active</span>
                                <?php } ?>
                                 <?php if ($row['is_active'] == 0) { ?>
                                    <span class="badge bg-danger">Inactive</span>
                                <?php } ?>
                            </td>
                            <td><?= indo_date($row['tanggal_bergabung']); ?></td>

                            <td>
                                 <div class="flex align-items-center list-user-action">
                                    <a class="btn btn-sm btn-icon <?= $row['is_active'] ? 'btn-success' : 'btn-secondary' ?>" 
                                        data-toggle="tooltip" data-placement="top" 
                                        title="<?= $row['is_active'] ? 'Nonaktifkan User' : 'Aktifkan User' ?>" data-original-title="Aktif" 
                                        href="<?= base_url('user/toggle/') . $row['id_user'] ?>">
                                        <i class="ri-user-add-line mr-0"></i>
                                    </a>
                                    <a class="btn btn-sm bg-primary" data-toggle="tooltip" data-placement="top" title=""
                                        data-original-title="Edit" href="<?= base_url('user/edit/') . $row['id_user'] ?>"><i class="ri-pencil-line mr-0"></i></a>
                                    <a onclick="return confirm('Yakin ingin menghapus data?')" class="btn btn-sm btn-icon btn-primary" data-toggle="tooltip" data-placement="top" title="Delete" data-original-title="Delete" href="<?= base_url('user/delete/') . $row['id_user'] ?>">
                                                            <i class="ri-delete-bin-line mr-0"></i>
                                                        </a>
                              </div>
                            </td>
                        <?php }?>
                     </tbody>
                  </table>
               </div>
               <div class="row justify-content-between mt-3">
                  <div id="user-list-page-info" class="col-md-6">
                     <span>Showing 1 to 5 of 5 entries</span>
                  </div>
                  <div class="col-md-6">
                     <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-end mb-0">
                           <li class="page-item disabled">
                              <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                           </li>
                           <li class="page-item active"><a class="page-link" href="#">1</a></li>
                           <li class="page-item"><a class="page-link" href="#">2</a></li>
                           <li class="page-item"><a class="page-link" href="#">3</a></li>
                           <li class="page-item">
                              <a class="page-link" href="#">Next</a>
                           </li>
                        </ul>
                     </nav>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
      </div>