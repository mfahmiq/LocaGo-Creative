<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-xl-3 col-lg-4">
                  <div class="card">
                     <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                           <h4 class="card-title"><?= $title; ?></h4>
                        </div>
                     </div>
                     <div class="card-body">
                <?= form_open_multipart('', [], ['id_user' => $user['id_user']]); ?>
                           <div class="form-group">
                              <div class="profile-img-edit position-relative">
                                 <img class="profile-pic rounded avatar-100" src="<?= base_url('template/assets/user/') . $user['foto']; ?>" alt="profile-pic">
                                 <div class="crm-p-image bg-primary">
                                    <i class="las la-pen upload-button"></i>
                                    <input class="file-upload" name="foto" type="file" accept="image/*">
                                 </div>
                              </div>
                           <div class="img-extension mt-3">
                              <div class="d-inline-block align-items-center">
                                    <span>Only</span>
                                 <a href="javascript:void();">.jpg</a>
                                 <a href="javascript:void();">.png</a>
                                 <a href="javascript:void();">.jpeg</a>
                                 <span>allowed</span>
                              </div>
                           </div>
                           </div>
                     </div>
                  </div>
            </div>
            <div class="col-xl-9 col-lg-8">
                  <div class="card">
                     <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                           <h4 class="card-title">Detail User</h4>
                        </div>
                     </div>
                     <div class="card-body">
                        <div class="new-user-info">
                              <div class="row">
                                 <div class="form-group col-md-12">
                                    <label for="fname">Nama Lengkap:</label>
                                    <input type="text" class="form-control" name="nama" id="nama" placeholder="Nama Lengkap"  value="<?= set_value('nama', $user['nama']); ?>">
                                                        <?= form_error('nama', '<span class="text-danger small">', '</span>'); ?>
 
                                </div>
                              </div>
                              <hr>
                              <h5 class="mb-3">Security</h5>
                              <div class="row">
                                 <div class="form-group col-md-12">
                                    <label for="uname">User Name:</label>
                                    <input type="text" class="form-control" id="username" name="username" placeholder="User Name" value="<?= set_value('username', $user['username']); ?>">
                                                        <?= form_error('username', '<span class="text-danger small">', '</span>'); ?>
 
                                </div>
                              </div>
                              
                              <a href="<?= base_url('user') ?>" class="btn btn-danger">Cancel</a>
                              <button type="submit" class="btn btn-primary">Add</button>
                <?= form_close(); ?>
                        </div>
                     </div>
                  </div>
            </div>
         </div>
      </div>
      </div>