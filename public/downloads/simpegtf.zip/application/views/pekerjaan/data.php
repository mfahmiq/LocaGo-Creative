<div class="content-page">
<div class="container-fluid">
   <div class="card">
      <div class="card-body">
         <div class="pekerjaan">
            <div class="col-lg-12">
               <div class="d-flex align-items-center border-bottom justify-content-between mb-4">
                  <div class="form-name">
                     <h3 class="mb-2"><?= $title; ?></h3>
                  </div>
                  <div class="col-auto">
                        <a href="<?= base_url('pekerjaan/export') ?>" class="btn btn-primary">
                            <span class="icon">
                                <i class="fa fa-user-plus"></i>
                            </span>
                            <span class="text">
                                Cetak
                            </span>
                        </a>
                    </div>
               </div>
            </div>
         </div>
         <div class="pekerjaan">
            <div class="col-lg-12">
                     <div class="pekerjaan">
                        <div class="col-sm-12">
                           <table border="0" cellpadding="8" width="100%">
<?php foreach ($pekerjaan as $pekerjaan) : ?>
   <?php 
   if($pekerjaan['status'] == "Sudah"){
   echo "<tr align='left'>
    <td>Nama Lengkap</td>
    <td>:</td>
    <td>".$pekerjaan['nama']."</td>
 </tr>
 <tr align='left'>
 <td>Tempat Tugas</td>
  <td>:</td>
  <td>".$pekerjaan['nama_tempat']."</td>
 </tr>
 <tr align='left'>
    <td>NIP/ No. Reg</td>
    <td>:</td>
    <td>".$pekerjaan['nip']."</td>
 </tr>
 <tr align='left'>
    <td>Status Pegawai</td>
    <td>:</td>
    <td>".$pekerjaan['status_pegawai']."</td>
 </tr>
  <tr align='left'>
    <td>Pangkat</td>
    <td>:</td>
    <td>".$pekerjaan['pangkat']."</td>
 </tr>
<tr align='left'>
 <td>Jabatan</td>
 <td>:</td>
 <td>".$pekerjaan['nama_jabatan']."</td>
 </tr>
 <tr align='left'>
 <td>Masa Kerja</td>
 <td>:</td>
 <td>".indo_date($pekerjaan['mulai'])." s/d ".indo_date($pekerjaan['akhir'])."</td>
 </tr>
<tr align='left'>
 <td>Bukti Kontrak</td>
 <td>:</td>
 <td>
   <a href=". base_url('pekerjaan/download_kontrak/') . $pekerjaan['id_pekerjaan'].">".$pekerjaan['bukti_kontrak']."</a>
 </td>
 </tr>";
   }
   else{
     echo "<tr align='left'>
    <td>Nama Lengkap</td>
    <td>:</td>
    <td>-</td>
 </tr>
 <tr align='left'>
 <td>Tempat Tugas</td>
  <td>:</td>
  <td>-</td>
 </tr>
 <tr align='left'>
    <td>NIP/ No. Reg</td>
    <td>:</td>
    <td>-</td>
 </tr>
 <tr align='left'>
    <td>Status Pegawai</td>
    <td>:</td>
    <td>-</td>
 </tr>
  <tr align='left'>
    <td>Pangkat</td>
    <td>:</td>
    <td>-</td>
 </tr>
<tr align='left'>
 <td>Jabatan</td>
 <td>:</td>
 <td>-</td>
 </tr>
 <tr align='left'>
 <td>Masa Kerja</td>
 <td>:</td>
 <td>-</td>
 </tr>
<tr align='left'>
 <td>Bukti Kontrak</td>
 <td>:</td>
 <td>
- </td>
 </tr>";
   }
   ?>
 
 
<?php endforeach; ?>
</table>
 <?php foreach ($pekerjaan1 as $pekerjaan) : ?>
   <?php if (is_pegawai()) : ?>
   <?php 
   if($pekerjaan['status'] == "Sudah"){
       echo "
<a href=".base_url('dashboard/pegawai/') . userdata('id_user')." class='btn btn-danger btn-lg mt-4'>Cancel</a>
                               <a href=". base_url('pekerjaan/edit/') . $pekerjaan['id_pekerjaan']." class='btn btn-primary btn-lg mt-4'>Edit</a>
 ";
   }
   else if($pekerjaan['status'] == "Belum"){
      echo "
<a href=".base_url('dashboard/pegawai/') . userdata('id_user')." class='btn btn-danger btn-lg mt-4'>Cancel</a>
                               <a href=". base_url('pekerjaan/add')." class='btn btn-primary btn-lg mt-4'>Add</a>
 ";
   }
   else{
      echo "";
   }
   ?>
   <?php endif; ?>
   <?php if (is_admin()) : ?>
      <?php 
   if($pekerjaan['status'] == "Sudah"){
       echo "
<a href=".base_url('dashboard')." class='btn btn-danger btn-lg mt-4'>Cancel</a>
 ";
   }
   else if($pekerjaan['status'] == "Belum"){
      echo "
<a href=".base_url('dashboard')." class='btn btn-danger btn-lg mt-4'>Cancel</a>
 ";
   }
   else{
      echo "";
   }
   ?>
      <?php endif; ?>
   <?php endforeach; ?>

                        </div>
                  
                  
               </div>
            </div>
         </div>

      </div>
   </div>
      </div>