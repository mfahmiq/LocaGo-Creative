<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12 col-lg-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title; ?></h4>
                     </div>
                  </div>
                  <div class="card-body">
                     <p>Tanda dengan <span style="color:red">*</span>) wajib diisi!</p>
                            <?= form_open_multipart('', [], ['id_user' => $this->session->userdata('login_session')['user']]); ?>
                        <div class="form-row">
                           <div class="col-md-12 mb-3">
                              <label for="id_jabatan">Jabatan</label>
                                <select class="form-control selectpicker" data-style="py-0" data-live-search="true" id="id_jabatan" name="id_jabatan">
                                 <option selected disabled value="">Pilih Jabatan</option>
                                  <?php foreach ($jabatan as $s) : ?>
                                    <option <?= $pekerjaan['id_jabatan'] == $s['id_jabatan'] ? 'selected' : ''; ?> <?= set_select('id_jabatan', $s['id_jabatan']) ?> value="<?= $s['id_jabatan'] ?>"><?= $s['nama_jabatan'] ?></option>
                                <?php endforeach; ?>
                              </select>
                            </div>
                           <div class="col-md-6 mb-3">
                              <label for="nip">NIG/NO. REG</label>
                              <input type="number" name="nip" class="form-control" id="nip" value="<?= set_value('nip', $pekerjaan['nip']) ?>">
                           </div>
                           <div class="col-md-6 mb-3">
                             <label>Status Pegawai</label>
                              <select id="status_pegawai" name="status_pegawai" class="form-control selectpicker" data-style="py-0" data-live-search="true">
                                 <option selected disabled value="">Pilih Status Pegawai</option>
                                 <option value="Honor BLUD">Honor BLUD</option>
                                                  <option value="Honor Daerah">Honor Daerah</option>
                                                  <option value="Honor Kantor">Honor Kantor</option>
                                                  <option value="Kontrak">Kontrak</option>
                                                  <option value="PNS">PNS</option>
                                                  <option value="PPPK">PPPK</option>
                                                  <option value="PTT Daerah">PTT Daerah</option>
                                                  <option value="PTT Dinkes">PTT Dinkes</option>
                                                  <option value="TBK">TBK</option>
                              </select>                                                
                              <?= form_error('pangkat', '<small class="text-danger pl-3">', '</small>'); ?>
                           </div>
                           <div class="col-md-6 mb-3">
                              <label for="mulai">Tanggal Mulai</label>
                              <input type="date" class="form-control" id="mulai" name="mulai" value="<?= set_value('mulai', $pekerjaan['mulai']) ?>">
                           </div>
                           <div class="col-md-6 mb-3">
                              <label for="akhir">Tanggal Akhir</label>
                                <input type="date" class="form-control" id="akhir" name="akhir" value="<?= set_value('akhir', $pekerjaan['akhir']) ?>">
                           </div>
                           <div class="col-md-6 mb-3">
                              <label for="no_telp">Tempat Tugas</label>
                                 <select class="form-control selectpicker" data-style="py-0" data-live-search="true" id="id_tempat" name="id_tempat">
                                    <option selected disabled value="">Pilih Tempat Tugas</option>
                                    <?php foreach ($tempat_tugas as $s) : ?>
                                    <option <?= $pekerjaan['id_tempat'] == $s['id_tempat'] ? 'selected' : ''; ?> <?= set_select('id_tempat', $s['id_tempat']) ?> value="<?= $s['id_tempat'] ?>"><?= $s['nama_tempat'] ?></option>
                                <?php endforeach; ?>
                                 </select>
                           </div>
                           <div class="col-md-6 mb-3">
                             <label>Pangkat</label>
                                                <select id="pangkat" name="pangkat" class="form-control selectpicker" data-style="py-0" data-live-search="true">
                                                    <option selected disabled value="">Pilih Pangkat</option>
                                                    <option value="-">-</option>
                                                 <option value="Pembina Utama (IV/e)">Pembina Utama (IV/e)</option>
                                                  <option value="Pembina Utama Madya (IV/d)">Pembina Utama Madya (IV/d)</option>
                                                  <option value="Pembina Utama Muda (IV/c)">Pembina Utama Muda (IV/c)</option>
                                                  <option value="Pembina Tk.I (IV/b)">Pembina Tk.I (IV/b)</option>
                                                  <option value="Pembina (IV/a)">Pembina (IV/a)</option>
                                                  <!-- Golongan III -->
                                                  <option value="Penata Tk.I (III/d)">Penata Tk.I (III/d)</option>
                                                  <option value="Penata (III/c)">Penata (III/c)</option>
                                                  <option value="Penata Muda Tk.I (III/b)">Penata Muda Tk.I (III/b)</option>
                                                  <option value="Penata Muda (III/a)">Penata Muda (III/a)</option>
                                                  <!-- Golongan II -->
                                                  <option value="Pengatur Tk.I (II/d)">Pengatur Tk.I (II/d)</option>
                                                  <option value="Pengatur (II/c)">Pengatur Tk.I (II/c)</option>
                                                  <option value="Pengatur Muda Tk.I (II/b)">Pengatur Muda Tk.I (II/b)</option>
                                                  <option value="Pengatur Muda (II/a)">Pengatur Muda (II/a)</option>
                                                  <!-- Golongan I -->
                                                  <option value="Juru Tk.I (I/d)">Juru Tk.I (I/d)</option>
                                                  <option value="Juru (I/c)">Juru (I/d)</option>
                                                  <option value="Juru Muda Tk.I (I/b)">Juru Muda Tk.I (I/d)</option>
                                                  <option value="Juru Muda (I/a)">Juru Muda (I/a)</option>
                                                  <option value="Juru Tk.I (I/d)">Juru Tk.I (I/d)</option>
                                                </select>                                                
                                                <?= form_error('pangkat', '<small class="text-danger pl-3">', '</small>'); ?>
                           </div>
                           <div class="col-md-12 mb-3">
                             <label>Bukti Kontrak</label>
                                                <div class="custom-file">
                              <input type="file" name="bukti_kontrak" class="custom-file-input" id="bukti_kontrak">
                              <label class="custom-file-label" for="bukti_kontrak">Pilih File</label>
                           </div>
                                                <?= form_error('bukti_kontrak', '<small class="text-danger pl-3">', '</small>'); ?>
                           </div>
                        </div>
                        <div class="form-group">
                             <a href="<?= base_url('dashboard/pegawai/') . userdata('id_user'); ?>" class="btn btn-danger">Cancel</a>
                           <button class="btn btn-primary" type="submit">Simpan</button>
                        </div>
                     <?= form_close(); ?>
                  </div>
               </div>
            </div>
            
         </div>
      </div>
      </div>