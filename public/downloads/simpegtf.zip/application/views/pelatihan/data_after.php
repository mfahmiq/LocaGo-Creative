<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title; ?></h4>
                     </div>
                     <div class="col-auto">
                        <a href="<?= base_url('pelatihan/add') ?>" class="btn btn-primary">
                            <span class="icon">
                                <i class="fa fa-user-plus"></i>
                            </span>
                            <span class="text">
                                Add
                            </span>
                        </a>
                    </div>
                  </div>
                  <div class="card-body">
                    <?= $this->session->flashdata('pesan'); ?>
                     <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped">
                           <thead>
                              <tr class="ligth">
                                 <th>No.</th>
                                 <th>Kegiatan</th>
                                 <th>Tanggal</th>
                                 <th>Media</th>
                                 <th>Status</th>
                              </tr>
                           </thead>
                           <tbody>
                <?php
                $no = 1;
                    foreach ($pelatihan as $pelatihan) :
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><a href="<?= base_url('pelatihan/detail_pelatihan_after/') . $pelatihan['id_pelatihan'] ?>"><?= $pelatihan['nama_pelatihan']; ?></a></td>
                            <td><?= indo_date($pelatihan['tanggal_pelatihan']); ?></td>
                            <td><?= $pelatihan['media']; ?></td>
                            <td>
                              <?php if ($pelatihan['status'] == "Sudah") { ?>
                                 <span class="badge bg-success-light">Sudah</span>
                            <?php } ?>
                              <?php if ($pelatihan['status'] == "Belum") { ?>
                                 <span class="badge bg-danger-light">Belum</span>
                            <?php } ?>
                              </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>