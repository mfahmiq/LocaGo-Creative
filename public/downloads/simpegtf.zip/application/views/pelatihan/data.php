<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title; ?></h4>
                     </div>
                     <div class="col-auto">
                        <a href="<?= base_url('pelatihan/add') ?>" class="btn btn-primary">
                            <span class="icon">
                                <i class="fa fa-user-plus"></i>
                            </span>
                            <span class="text">
                                Add
                            </span>
                        </a>
                    </div>
                  </div>
                  <div class="card-body">
                    <?= $this->session->flashdata('pesan'); ?>
                     <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped">
                           <thead>
                              <tr class="ligth">
                                 <th>No.</th>
                                 <th>Kegiatan</th>
                                 <th>User</th>
                                 <th>Status</th>
                                 <th>Aksi</th>
                              </tr>
                           </thead>
                           <tbody>
                                                <?php
                $no = 1;
                    foreach ($pelatihan as $pelatihan) :
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><a title="Detail" href="<?= base_url('pelatihan/detail_pelatihan/') . $pelatihan['id_pelatihan'] ?>"><?= $pelatihan['nama_pelatihan']; ?></a></td>
                            <td><?= $pelatihan['nama']; ?></td>
                           <td>
                              <?php if ($pelatihan['status'] == "Sudah") { ?>
                                 <span class="badge bg-success-light">Sudah</span>
                            <?php } ?>
                              <?php if ($pelatihan['status'] == "Belum") { ?>
                                 <span class="badge bg-danger-light">Belum</span>
                            <?php } ?>
                              </td>
                              <td>
                              <a class="btn btn-sm bg-warning-light" data-toggle="tooltip" data-placement="top" title=""
                                    data-original-title="Kirim" href="<?= base_url('pelatihan/kirim/') . $pelatihan['id_pelatihan'] ?>"><i class="ri-user-add-line mr-0"></i></a>
                                                        <a class="btn btn-sm btn-icon btn-info" data-toggle="tooltip" data-placement="top" title="Edit" data-original-title="Edit" href="<?= base_url('pelatihan/edit/') . $pelatihan['id_pelatihan'] ?>">
                                                           <i class="ri-pencil-line mr-0"></i>
                                                        </a>
                                                        <a onclick="return confirm('Yakin ingin menghapus data?')" class="btn btn-sm btn-icon btn-danger" data-toggle="tooltip" data-placement="top" title="Delete" data-original-title="Delete" href="<?= base_url('pelatihan/delete/') . $pelatihan['id_pelatihan'] ?>">
                                                            <i class="ri-delete-bin-line mr-0"></i>
                                                        </a>
                               
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>