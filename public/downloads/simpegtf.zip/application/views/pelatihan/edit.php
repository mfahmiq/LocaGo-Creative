<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12 col-lg-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title?></h4>
                     </div>
                  </div>
                  <div class="card-body">
                     <p>Tanda dengan <span style="color:red">*</span>) wajib diisi!</p>
                            <?= form_open_multipart('', [], ['id_user' => $this->session->userdata('login_session')['user']]); ?>
                     <div class="form-row">
                        <div class="col-md-12 mb-3">
                           <label for="namapelatihan">Nama pelatihan: <span style="color:red">*</span>)</label>
                           <input type="text" class="form-control" id="nama_pelatihan" name="nama_pelatihan" value="<?= set_value('nama_pelatihan', $pelatihan['nama_pelatihan']); ?>" placeholder="Nama pelatihan">
                           <?= form_error('nama_pelatihan', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                             <label>Media: <span style="color:red">*</span>)</label>
                             <br>
                             
                     <div class="radio d-inline-block mr-2">
                        
                                                    <label><input type="radio" class="mediaCB" name="media" value="Offline" <?php if($pelatihan['media']=='Offline') echo 'checked'?>>Offline</label>

                     </div>
                     <div class="radio d-inline-block mr-2">
                                                      <label><input type="radio" class="mediaCB"  name="media" value="Online" <?php if($pelatihan['media']=='Online') echo 'checked'?>>Online</label>
                     </div>
                        </div>
                                                      <?= form_error('media', '<small class="text-danger pl-3">', '</small>'); ?>

                        <div class="col-md-6 mb-3">
                           <label for="tanggalpelatihan">Tanggal: <span style="color:red">*</span>)</label>
                           <input type="date" class="form-control" id="tanggal_pelatihan" name="tanggal_pelatihan" value="<?= set_value('tanggal_pelatihan', $pelatihan['tanggal_pelatihan']); ?>" placeholder="Tanggal Pelatihan">
                           <?= form_error('tanggal_pelatihan', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <div class="col-md-12 mb-3" id="ifOnline">
                           <label for="tempat">Link: <span style="color:red">*</span>)</label>
                           <input type="url" class="form-control" id="link" name="link" value="<?= set_value('link', $pelatihan['link']); ?>" placeholder="Link">
                           <?= form_error('link', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <div class="col-md-12 mb-3" id="ifOffline">
                           <label for="tempat">Tempat: <span style="color:red">*</span>)</label>
                           <input type="text" class="form-control" id="tempat" name="tempat" value="<?= set_value('tempat', $pelatihan['tempat']); ?>" placeholder="Tempat">
                           <?= form_error('tempat', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <div class="col-md-12 mb-3">
                           <label>Bukti Pelatihan <span style="color:red">*</span>)</label>
                           <div class="custom-file">
                              <input type="file" name="bukti_pelatihan" class="custom-file-input" id="bukti_pelatihan">
                              <label class="custom-file-label" for="bukti_pelatihan">Pilih File</label>
                           </div>
                           <?= form_error('bukti_pelatihan', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                     </div>
                        <a href="<?= base_url('pelatihan') ?>" class="btn btn-danger">Cancel</a>
                        <button type="submit" class="btn btn-primary">Add</button>
                <?= form_close(); ?>
                  </div>
               </div>
            </div>
            
         </div>
      </div>
      </div>
      