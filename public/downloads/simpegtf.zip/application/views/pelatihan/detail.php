<div class="content-page">
<div class="container-fluid">
   <div class="card">
      <div class="card-body">
         <div class="pelatihan">
            <div class="col-lg-12">
               <div class="d-flex align-items-center border-bottom justify-content-between mb-4">
                  <div class="form-name">
                     <h3 class="mb-2"><?= $title; ?></h3>
                  </div>
                  <div class="col-auto">
                        <a href="<?= base_url('pelatihan/export') ?>" class="btn btn-primary">
                            <span class="icon">
                                <i class="fa fa-user-plus"></i>
                            </span>
                            <span class="text">
                                Cetak
                            </span>
                        </a>
                    </div>
               </div>
            </div>
         </div>
         <div class="pelatihan">
            <div class="col-lg-12">
                     <div class="pelatihan">
                        <div class="col-sm-12">
                           <table border="0" cellpadding="8" width="100%">
<?php foreach ($pelatihan as $pelatihan) : ?>
 <tr align='left'>
 <td>Kegiatan</td>
  <td>:</td>
  <td><?= $pelatihan['nama_pelatihan']; ?></td>
 </tr>
 <tr align='left'>
    <td>Media</td>
    <td>:</td>
    <td>
        <?= $pelatihan['media']; ?></td>
 </tr>
 <tr align='left'>
    <td>Bukti Pelatihan</td>
    <td>:</td>
    <td>
   <a href="<?= base_url('pelatihan/download_pelatihan/') . $pelatihan['id_pelatihan']; ?>" title="Detail"><?= $pelatihan['bukti_pelatihan']; ?></a>
</tr>
<?php if($pelatihan['media'] == "Offline"){
    echo "<tr align='left'>
    <td>Tempat</td>
    <td>:</td>
    <td>".$pelatihan['tempat']."</td>
 </tr>";
}
elseif($pelatihan['media'] == "Online"){
    echo "<tr align='left'>
    <td>Link</td>
    <td>:</td>
    <td>".$pelatihan['link']."</td>
 </tr>";
}
else{
    echo "";
}
?>
<?php endforeach; ?>
</table>
                             <a href="<?= base_url('pelatihan') ?>" class="btn btn-danger btn-lg mt-4">Cancel</a>


                        </div>
                  
                  
               </div>
            </div>
         </div>

      </div>
   </div>
      </div>