<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12 col-lg-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title?></h4>
                     </div>
                  </div>
                  <div class="card-body">
                     <p>Tanda dengan <span style="color:red">*</span>) wajib diisi!</p>
                    <?= form_open(); ?>
                        <div class="form-group">
                                                <label class="form-label" for="add1">Password Lama: <span style="color:red">*</span>)</label>
                                                 <input value="<?= set_value('password_lama'); ?>" name="password_lama" id="password_lama" type="password" class="form-control" placeholder="Password Lama...">
                        <?= form_error('password_lama', '<small class="text-danger">', '</small>'); ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="form-label" for="add1">Password Baru: <span style="color:red">*</span>)</label>
                                                 <input value="<?= set_value('password_baru'); ?>" name="password_baru" id="password_baru" type="password" class="form-control" placeholder="Password Baru...">
                        <?= form_error('password_baru', '<small class="text-danger">', '</small>'); ?>
                                            </div>
                                            <div class="form-group">
                                                <label class="form-label" for="add1">Konfirmasi Password: <span style="color:red">*</span>)</label>
                                                 <input value="<?= set_value('konfirmasi_password'); ?>" name="konfirmasi_password" id="konfirmasi_password" type="password" class="form-control" placeholder="Konfirmasi Password...">
                        <?= form_error('konfirmasi_password', '<small class="text-danger">', '</small>'); ?>
                                            </div>
                        
                        <button type="submit" class="btn btn-primary">Update</button>
                <?= form_close(); ?>
                  </div>
               </div>
            </div>
            
         </div>
      </div>
      </div>