<div class="iq-sidebar  sidebar-default ">
          <div class="iq-sidebar-logo d-flex align-items-center">
              <a href="" class="header-logo">
                  <img src="<?= base_url('template/'); ?>assets/images/logo.svg" alt="logo">
                  <h3 class="logo-title light-logo">SIMPEGTF</h3>
              </a>
              <div class="iq-menu-bt-sidebar ml-0">
                  <i class="las la-bars wrapper-menu"></i>
              </div>
          </div>
          <div class="data-scrollbar" data-scroll="1">
              <nav class="iq-sidebar-menu">
                  <ul id="iq-sidebar-toggle" class="iq-menu">
                    <?php if (is_admin()) : ?>
                      <li>
                          <a href="<?= base_url('dashboard'); ?>" class="svg-icon">                        
                              <svg class="svg-icon" width="25" height="25" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                  <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                  <polyline points="9 22 9 12 15 12 15 22"></polyline>
                              </svg>
                              <span class="ml-4">Dashboard</span>
                          </a>
                      </li>
                       <li class=" ">
                                      <a href="#master" class="collapsed" data-toggle="collapse" aria-expanded="false">
                                          <svg class="svg-icon" id="p-dash16" width="25" height="25" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                              <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>
                                          </svg>
                                          <span class="ml-4">Data Master</span>
                                          <i class="las la-angle-right iq-arrow-right arrow-active"></i>
                                          <i class="las la-angle-down iq-arrow-right arrow-hover"></i>
                                      </a>
                                      <ul id="master" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                              <li class="">
                                                  <a href="<?= base_url('tempat_tugas/'); ?>">
                                                      <i class="las la-minus"></i><span>Tempat Tugas</span>
                                                  </a>
                                              </li>
                                              <li class="">
                                                  <a href="<?= base_url('jabatan/'); ?>">
                                                      <i class="las la-minus"></i><span>jabatan</span>
                                                  </a>
                                              </li>
                                                <!-- <li class="">
                                                  <a href="<?= base_url('bidang'); ?>">
                                                      <i class="las la-minus"></i><span>Bidang</span>
                                                  </a>
                                              </li>
                                            <li class="">
                                                  <a href="<?= base_url('bagian/'); ?>">
                                                      <i class="las la-minus"></i><span>Bagian</span>
                                                  </a>
                                              </li> -->
                                      </ul>
                                  </li>
                                  <li class=" ">
                                      <a href="#user" class="collapsed" data-toggle="collapse" aria-expanded="false">
                                          <svg class="svg-icon" id="p-dash10" width="25" height="25" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                              <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><polyline points="17 11 19 13 23 9"></polyline>
                                          </svg>
                                          <span class="ml-4">User Details</span>
                                          <i class="las la-angle-right iq-arrow-right arrow-active"></i>
                                          <i class="las la-angle-down iq-arrow-right arrow-hover"></i>
                                      </a>
                                      <ul id="user" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                              <li class="">
                                                  <a href="<?= base_url('user/atasan'); ?>">
                                                      <i class="las la-minus"></i><span>Data Atasan</span>
                                                  </a>
                                              </li>
                                              <li class="">
                                                  <a href="<?= base_url('user/listpegawai'); ?>">
                                                      <i class="las la-minus"></i><span>Data Pegawai</span>
                                                  </a>
                                              </li>
                                              <li class="">
                                                  <a href="<?= base_url('user'); ?>">
                                                      <i class="las la-minus"></i><span>Data Lengkap</span>
                                                  </a>
                                              </li>
                                      </ul>
                                  </li>
                        <li class="">
                          <a href="<?= base_url('user/pegawai'); ?>" class="svg-icon">                        
                              <svg class="svg-icon" width="25" height="25" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle>
                              </svg>
                              <span class="ml-4">Detail Pegawai</span>
                          </a>
                      </li>
                      <li class="">
                          <a href="<?= base_url('laporan')?>" class="svg-icon">                        
                              <svg class="svg-icon" width="25" height="25" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                  <polyline points="6 9 6 2 18 2 18 9"></polyline>
                                  <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
                                  <rect x="6" y="14" width="12" height="8"></rect>
                              </svg>
                              <span class="ml-4">Laporan</span>
                          </a>
                      </li>
                      <?php endif; ?>
                      <?php if (is_pegawai() || is_direktur()) : ?>
                        <li>
                          <a href="<?= base_url('dashboard/pegawai/') . userdata('id_user'); ?>" class="svg-icon">                        
                              <svg class="svg-icon" width="25" height="25" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                  <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                  <polyline points="9 22 9 12 15 12 15 22"></polyline>
                              </svg>
                              <span class="ml-4">Dashboard</span>
                          </a>
                      </li>
                      <li class=" ">
                                      <a href="<?= base_url('biodata')?>" class="svg-icon">
                                          <svg class="svg-icon" id="p-dash14" width="25" height="25" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                              <rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect>
                                          </svg>
                                          <span class="ml-4">Biodata</span>
                      </a>
                    </li>
                                   <li class="">
                                      <a href="<?= base_url('pendidikan/data_after') ?>" class="svg-icon">
                                          <svg class="svg-icon" id="p-dash16" width="25" height="25" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                              <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>
                                          </svg>
                                          <span class="ml-4">Pendidikan</span>
                                      </a>
                                  </li>
                    <li class="">
                          <a href="<?= base_url('pekerjaan/pekerjaan_user') ?>" class="svg-icon">                        
                              <svg class="svg-icon" width="25" height="25" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                  <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
                                  <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
                              </svg>
                              <span class="ml-4">Pekerjaan</span>
                          </a>
                      </li>
                      <li class="">
                                      <a href="<?= base_url('pelatihan/data_after') ?>" class="svg-icon">
                                          <svg class="svg-icon" id="p-dash07" width="25" height="25" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline>
                                          </svg>
                                          <span class="ml-4">Pelatihan</span>
                                      </a>
                                  </li>
                                  <li class="">
                                      <a href="<?= base_url('perizinan/data_after') ?>" class="svg-icon">
                                          <svg class="svg-icon" width="25" height="25" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                  <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
                              </svg>
                                          <span class="ml-4">Perizinan</span>
                                      </a>
                                  </li>
                      <?php endif; ?>
                          </ul>
                      </li>
                  </ul>
              </nav>
             
          </div>
      </div>    