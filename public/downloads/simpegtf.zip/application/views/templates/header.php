

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>SIMPEGTF | <?= $title; ?></title>
      
      <!-- Favicon -->
      <link rel="shortcut icon" href="<?= base_url('template/'); ?>assets/images/favicon.ico" />
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/css/backend-plugin.min.css">
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/css/backend.css?v=1.0.0">
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/vendor/line-awesome/dist/line-awesome/css/line-awesome.min.css">
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/vendor/remixicon/fonts/remixicon.css">
      
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/vendor/tui-calendar/tui-calendar/dist/tui-calendar.css">
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/vendor/tui-calendar/tui-date-picker/dist/tui-date-picker.css">
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/vendor/tui-calendar/tui-time-picker/dist/tui-time-picker.css">  </head>
      
	    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/css/select2.min.css">
  

  <body class="  ">
    <!-- loader Start -->
    <div id="loading">
          <div id="loading-center">
          </div>
    </div>
    <!-- loader END -->
    <!-- Wrapper Start -->
    <div class="wrapper">