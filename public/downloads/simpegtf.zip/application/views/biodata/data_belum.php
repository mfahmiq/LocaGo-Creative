<div class="content-page">
<div class="container-fluid">
   <div class="card">
      <div class="card-body">
         <div class="row">
            <div class="col-lg-12">
               <div class="d-flex align-items-center border-bottom justify-content-between mb-4">
                  <div class="form-name">
                     <h3 class="mb-2"><?= $title; ?></h3>
                  </div>
                  <div class="col-auto">
                        <a href="<?= base_url('biodata/export') ?>" class="btn btn-primary">
                            <span class="icon">
                                <i class="fa fa-user-plus"></i>
                            </span>
                            <span class="text">
                                Cetak
                            </span>
                        </a>
                    </div>
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-lg-12">
                     <div class="row">
                        <div class="col-sm-12">
                           <table border="0" cellpadding="8" width="100%">
<?php foreach ($user as $user) : ?>
 <tr align='left'>
    <td>Nama Lengkap</td>
    <td>:</td>
    <td><?= $user['nama']; ?></td>
 </tr>
  <tr align='left'>
  <td>No. Telp</td>
  <td>:</td>
  <td><?= $user['no_telp']; ?></td>
 </tr>
 <tr align='left'>
  <td>Email</td>
  <td>:</td>
  <td><?= $user['email']; ?></td>
 </tr>
<tr align='left'>
 <td>Jenis Kelamin</td>
 <td>:</td>
 <td><?=$user['jenis_kelamin']; ?></td>
 </tr>
 <tr align='left'>
 <td>Tempat, Tanggal Lahir</td>
 <td>:</td>
 <td><?=$user['tempat_lahir']; ?>, <?= indo_date($user['tanggal_lahir']); ?></td>
 </tr>
<tr align='left'>
 <td>Alamat</td>
  <td>:</td>
  <td><?= $user['alamat']; ?></td>
 </tr>
 <tr align='left'>
 <td>Agama</td>
  <td>:</td>
  <td><?= $user['agama']; ?></td>
 </tr>
  <tr align='left'>
 <td>Status Kawin</td>
  <td>:</td>
  <td><?= $user['status_kawin']; ?></td>
 </tr>
 <tr align='left'>
 <td>KTP</td>
  <td>:</td>
  <td><a href="<?= base_url('biodata/download_ktp/') . $user['id_user'] ?>"><?= $user['ktp']; ?></a></td>
 </tr>
 <tr align='left'>
 <td>KK</td>
  <td>:</td>
  <td><a href="<?= base_url('biodata/download_kk/') . $user['id_user'] ?>"><?= $user['kk']; ?></a></td>
 </tr>

<?php endforeach; ?>
</table>

 <a href="<?= base_url('dashboard/pegawai/') . userdata('id_user'); ?>" class="btn btn-danger btn-lg mt-4">Cancel</a>
                               <a href="<?php echo base_url('biodata/add/') ?>" class="btn btn-primary btn-lg mt-4">Add</a>
                        </div>
                 

                  
               </div>
            </div>
         </div>

      </div>
   </div>
      </div>