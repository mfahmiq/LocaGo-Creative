<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12 col-lg-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title; ?></h4>
                     </div>
                  </div>
                  <div class="card-body">
                     <p>Tanda dengan <span style="color:red">*</span>) wajib diisi!</p>
                        <?= form_open_multipart('', [], ['id_user' => $this->session->userdata('login_session')['user']]); ?>
                        <div class="form-row">
                           <div class="col-md-6 mb-3">
                              <label for="jenis_kelamin">Jenis Kelamin</label>
                                <select class="selectpicker form-control" data-style="py-0" class="form-control" id="jenis_kelamin" name="jenis_kelamin">
                                 <option selected disabled value="">Pilih Jenis Kelamin</option>
                                 <option value="Laki-laki">Laki-laki</option>
                                 <option value="Perempuan">Perempuan</option>
                              </select>
                            </div>
                           <div class="col-md-6 mb-3">
                              <label for="alamat">Alamat</label>
                              <textarea type="text" name="alamat" class="form-control" id="alamat"></textarea>
                           </div>
                           <div class="col-md-6 mb-3">
                              <label for="tempat_lahir">Tempat Lahir</label>
                              <input type="text" class="form-control" id="tempat_lahir" name="tempat_lahir">
                           </div>
                           <div class="col-md-6 mb-3">
                              <label for="tanggal_lahir">Tanggal Lahir</label>
                                <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir">
                           </div>
                           <div class="col-md-6 mb-3">
                              <label for="no_telp">No Telp</label>
                                 <input type="number" class="form-control" id="no_telp" name="no_telp">
                           </div>
                           <div class="col-md-6 mb-3">
                              <label for="email">Email</label>
                              <input type="text" class="form-control" id="email" name="email">
                           </div>
                           <div class="col-md-6 mb-3">
                             <label>Status Kawin</label>
                                                <select id="status_kawin" name="status_kawin" class="selectpicker form-control" data-style="py-0">
                                                    <option selected disabled value="">Pilih Status Kawin</option>
                                                  <option value="Belum Kawin">Belum Kawin</option>
                                                  <option value="Kawin">Kawin</option>
                                                  <option value="Cerai Hidup">Cerai Hidup</option>
                                                  <option value="Cerai Mati">Cerai Mati</option>
                                                </select>                                                
                                                <?= form_error('status_kawin', '<small class="text-danger pl-3">', '</small>'); ?>
                           </div>
                           <div class="col-md-6 mb-3">
                             <label>Agama</label>
                                                <select id="agama" name="agama" class="form-control selectpicker" data-style="py-0" data-live-search="true">
                                                    <option selected disabled value="">Pilih Agama</option>
                                                  <option value="Islam">Islam</option>
                                                  <option value="Protestan">Protestan</option>
                                                  <option value="Hindu">Hindu</option>
                                                  <option value="Buddha">Buddha</option>
                                                  <option value="Katolik">Katolik</option>
                                                  <option value="Khonghucu">Khonghucu</option>
                                                </select>
                                                <?= form_error('agama', '<small class="text-danger pl-3">', '</small>'); ?>
                           </div>
                        <div class="col-md-6 mb-3">
                           <label>Bukti KTP <span style="color:red">*</span>)</label>
                           <div class="custom-file">
                              <input type="file" name="ktp" class="custom-file-input" id="ktp">
                              <label class="custom-file-label" for="ktp">Pilih File</label>
                           </div>
                           <?= form_error('ktp', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                           <label>Bukti KK <span style="color:red">*</span>)</label>
                           <div class="custom-file">
                              <input type="file" name="kk" class="custom-file-input" id="kk">
                              <label class="custom-file-label" for="kk">Pilih File</label>
                           </div>
                           <?= form_error('kk', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                        </div>
                        <div class="form-group">
                             <a href="<?= base_url('dashboard/pegawai/') . userdata('id_user'); ?>" class="btn btn-danger">Cancel</a>
                           <button class="btn btn-primary" type="submit">Simpan</button>
                        </div>
                     <?= form_close(); ?>
                  </div>
               </div>
            </div>
            
         </div>
      </div>
      </div>