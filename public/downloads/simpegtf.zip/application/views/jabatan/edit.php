<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12 col-lg-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title?></h4>
                     </div>
                  </div>
                  <div class="card-body">
                     <p>Tanda dengan <span style="color:red">*</span>) wajib diisi!</p>
                            <?= form_open(); ?>
                        <div class="form-group">
                           <label for="namajabatan">Nama jabatan: <span style="color:red">*</span>)</label>
                           <input type="text" class="form-control" id="nama_jabatan" name="nama_jabatan" value="<?= set_value('nama_jabatan', $jabatan['nama_jabatan']); ?>" placeholder="Nama jabatan">
                           <?= form_error('nama_jabatan', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <a href="<?= base_url('jabatan') ?>" class="btn btn-danger">Cancel</a>
                        <button type="submit" class="btn btn-primary">Add</button>
                <?= form_close(); ?>
                  </div>
               </div>
            </div>
            
         </div>
      </div>
      </div>