<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12 col-lg-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title?></h4>
                     </div>
                  </div>
                  <div class="card-body">
                     <p>Tanda dengan <span style="color:red">*</span>) wajib diisi!</p>
                <?= form_open('', [], ['id_bidang' => $bidang['id_bidang']]); ?>
                        <div class="form-group">
                           <label for="namabidang">Nama Bidang: <span style="color:red">*</span>)</label>
                           <input type="text" class="form-control" id="nama_bidang" name="nama_bidang" value="<?= set_value('nama_bidang', $bidang['nama_bidang']); ?>" placeholder="Nama Bidang">
                           <?= form_error('nama_bidang', '<span class="text-danger small">', '</span>'); ?>
                        </div>
                        <div class="form-group">
                           <label for="kabid">Kabid: <span style="color:red">*</span>)</label>
                           <select name="id_user" class="form-control selectpicker" data-style="py-0" data-live-search="true" id="id_user">
                                <option value="" selected disabled>Pilih Kabid</option>
                                <?php foreach ($user as $s) : ?>
                                    <option <?= $bidang['id_user'] == $s['id_user'] ? 'selected' : ''; ?> <?= set_select('id_user', $s['id_user']) ?> value="<?= $s['id_user'] ?>"><?= $s['nama'] ?></option>
                                <?php endforeach; ?>
                              </select>
                        </div>
                        <a href="<?= base_url('bidang') ?>" class="btn btn-danger">Cancel</a>
                        <button type="submit" class="btn btn-primary">Add</button>
                <?= form_close(); ?>
                  </div>
               </div>
            </div>
            
         </div>
      </div>
      </div>