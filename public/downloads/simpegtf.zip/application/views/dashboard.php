<div class="content-page">
     <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-lg-3">
                <div class="card card-block card-stretch card-height">
                    <div class="card-body">
                        <div class="top-block d-flex align-items-center justify-content-between">
                            <h5>Atasan</h5>
                            <a href="<?= base_url('user/atasan') ?>"><span class="badge badge-primary">Total</span></a>
                        </div>
                        <h3><span class="counter"><?= $jlh_petinggi; ?></span></h3>
                        <div class="d-flex align-items-center justify-content-between mt-1">
                            <p class="mb-0">Total</p>
                            <span class="text-primary"><?= $jlh_petinggi; ?></span>
                        </div>
                        <div class="iq-progress-bar bg-primary-light mt-2">
                            <span class="bg-primary iq-progress progress-1" data-percent="<?= $jlh_petinggi; ?>"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card card-block card-stretch card-height">
                    <div class="card-body">
                        <div class="top-block d-flex align-items-center justify-content-between">
                            <h5>Pegawai</h5>
                            <a href="<?= base_url('user/listpegawai') ?>"><span class="badge badge-warning">Total</span></a>
                        </div>
                        <h3><span class="counter"><?= $jlh_pegawai; ?></span></h3>
                        <div class="d-flex align-items-center justify-content-between mt-1">
                            <p class="mb-0">Total</p>
                            <span class="text-warning"><?= $jlh_pegawai; ?></span>
                        </div>
                        <div class="iq-progress-bar bg-warning-light mt-2">
                            <span class="bg-warning iq-progress progress-1" data-percent="<?= $jlh_pegawai; ?>"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card card-block card-stretch card-height">
                    <div class="card-body">
                        <div class="top-block d-flex align-items-center justify-content-between">
                            <h5>Jabatan</h5>
                            <a href="<?= base_url('jabatan') ?>"><span class="badge badge-success">Total</span></a>
                        </div>
                        <h3><span class="counter"><?= $jlh_jabatan; ?></span></h3>
                        <div class="d-flex align-items-center justify-content-between mt-1">
                            <p class="mb-0">Total</p>
                            <span class="text-success"><?= $jlh_jabatan; ?></span>
                        </div>
                        <div class="iq-progress-bar bg-success-light mt-2">
                            <span class="bg-success iq-progress progress-1" data-percent="<?= $jlh_jabatan; ?>"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card card-block card-stretch card-height">
                    <div class="card-body">
                        <div class="top-block d-flex align-items-center justify-content-between">
                            <h5>Tempat Tugas</h5>
                            <a href="<?= base_url('tempat_tugas') ?>"><span class="badge badge-info">Total</span></a>
                        </div>
                        <h3><span class="counter"><?= $jlh_tempatTugas; ?></span></h3>
                        <div class="d-flex align-items-center justify-content-between mt-1">
                            <p class="mb-0">Total</p>
                            <span class="text-info"><?= $jlh_tempatTugas; ?></span>
                        </div>
                        <div class="iq-progress-bar bg-info-light mt-2">
                            <span class="bg-info iq-progress progress-1" data-percent="<?= $jlh_tempatTugas; ?>"></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-8">
                <div class="card-transparent card-block card-stretch card-height">
                    <div class="card-body p-0">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Grafik Pegawai Berdasarkan Tempat Tugas</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <canvas id="myChart"></canvas>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="card card-block card-stretch card-height">
                    <div class="card-body">
                        <div class="card border-bottom pb-2 shadow-none">
                            <div class="card-body text-center inln-date flet-datepickr">
                                <input type="text" id="inline-date" class="date-input basicFlatpickr d-none" readonly="readonly">
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card-transparent mb-0">
                    <div class="card-header d-flex align-items-center justify-content-between p-0 pb-3">
                        <div class="header-title">
                            <h4 class="card-title">Tempat Tugas</h4>
                        </div>
                        <div class="card-header-toolbar d-flex align-items-center">
                            <div id="top-project-slick-arrow" class="slick-aerrow-block">
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-unstyled row top-projects mb-0">
                            <?php $i = 1; ?>
                            <?php foreach ($pekerjaan as $pekerjaan) :
                                         ?>
                            <li class="col-lg-4">                                  
                                <div class="card">
                                    <div class="card-body"> 
                                        
                                        <h5 class="mb-3"><?= $pekerjaan['nama']; ?> - <?= $pekerjaan['nip']; ?> </h5>
                                        <p class="mb-3"><i class="las la-calendar-check mr-2"></i><?= $pekerjaan['nama_tempat']; ?></p>
                                        <div class="iq-progress-bar bg-secondary-light mb-4">
                                            <span class="bg-secondary iq-progress progress-1" data-percent="100"></span>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div>
                                                <a href="<?=  base_url('pekerjaan/detail_pekerjaan/') . $pekerjaan['id_pekerjaan']?>" class="btn bg-secondary-light">Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            
                        <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page end  -->
    </div>
      </div>