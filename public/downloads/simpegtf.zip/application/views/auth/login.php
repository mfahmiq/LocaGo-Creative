


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>SIMPEGTF | Login</title>
      
      <!-- Favicon -->
      <link rel="shortcut icon" href="<?= base_url('template/'); ?>assets/images/favicon.ico" />
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/css/backend-plugin.min.css">
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/css/backend.css?v=1.0.0">
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/vendor/line-awesome/dist/line-awesome/css/line-awesome.min.css">
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/vendor/remixicon/fonts/remixicon.css">
      
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/vendor/tui-calendar/tui-calendar/dist/tui-calendar.css">
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/vendor/tui-calendar/tui-date-picker/dist/tui-date-picker.css">
      <link rel="stylesheet" href="<?= base_url('template/'); ?>assets/vendor/tui-calendar/tui-time-picker/dist/tui-time-picker.css">  </head>
  <body class=" ">
    <!-- loader Start -->
    <div id="loading">
          <div id="loading-center">
          </div>
    </div>
    <!-- loader END -->
    
      <div class="wrapper">
      <section class="login-content">
         <div class="container">
            <div class="row align-items-center justify-content-center height-self-center">
               <div class="col-lg-8">
                  <div class="card auth-card">
                     <div class="card-body p-0">
                        <div class="d-flex align-items-center auth-content">
                           <div class="col-lg-6 bg-primary content-left">
                              <div class="p-3">
                                 <h2 class="mb-2 text-white"><?= $title; ?></h2>
                                 <?= $this->session->flashdata('pesan'); ?>
                                 <?= form_open(); ?>
                                    <div class="row">
                                       <div class="col-lg-12">
                                          <div class="floating-label form-group">
                                            <?= form_error('username', '<small class="text-danger">', '</small>'); ?>
                                             <input class="floating-input form-control" name="username" value="<?= set_value('username'); ?>" type="text" placeholder=" ">
                                             <label>Username</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-12">
                                          <div class="floating-label form-group">
                                            <?= form_error('password', '<small class="text-danger">', '</small>'); ?>
                                             <input class="floating-input form-control" name="password"  type="password" placeholder=" ">
                                             <label>Password</label>
                                          </div>
                                       </div>
                                    </div>
                                    <button type="submit" class="btn btn-white">Sign In</button>
                                    <p class="mt-3">
                                       Create an Account <a href="<?= base_url('auth/register'); ?>" class="text-white text-underline">Sign Up</a>
                                    </p>
                                 <?= form_close(); ?>
                              </div>
                           </div>
                           <div class="col-lg-6 content-right">
                              <img src="<?= base_url('template/'); ?>assets/images/login/01.png" class="img-fluid image-right" alt="">
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      </div>
    
    <!-- Backend Bundle JavaScript -->
    <script src="<?= base_url('template/'); ?>assets/js/backend-bundle.min.js"></script>
    
    <!-- Table Treeview JavaScript -->
    <script src="<?= base_url('template/'); ?>assets/js/table-treeview.js"></script>
    
    <!-- Chart Custom JavaScript -->
    <script src="<?= base_url('template/'); ?>assets/js/customizer.js"></script>
    
    <!-- Chart Custom JavaScript -->
    <script async src="<?= base_url('template/'); ?>assets/js/chart-custom.js"></script>
    <!-- Chart Custom JavaScript -->
    <script async src="<?= base_url('template/'); ?>assets/js/slider.js"></script>
    
    <!-- app JavaScript -->
    <script src="<?= base_url('template/'); ?>assets/js/app.js"></script>
    
    <script src="<?= base_url('template/'); ?>assets/vendor/moment.min.js"></script>
  </body>
</html>