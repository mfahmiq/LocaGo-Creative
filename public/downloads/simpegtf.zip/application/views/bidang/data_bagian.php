<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title; ?></h4>
                     </div>
                     <div class="col-auto">
                        <a href="<?= base_url('bidang') ?>" class="btn btn-primary">
                            <span class="icon">
                                <i class="fa fa-user-plus"></i>
                            </span>
                            <span class="text">
                                Cancel
                            </span>
                        </a>
                    </div>
                  </div>
                  <div class="card-body">
                    <?= $this->session->flashdata('pesan'); ?>
                     <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped">
                           <thead>
                              <tr class="ligth">
                                 <th>No.</th>
                                 <th>Nama</th>
                                 <th>Kasi</th>
                                 <th>Bidang</th>
                              </tr>
                           </thead>
                           <tbody>
                                                <?php
                $no = 1;
                    foreach ($bagian as $bagian) :
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $bagian['nama_bagian']; ?></td>
                            <td><?= $bagian['nama']; ?></td>
                            <td><?= $bagian['nama_bidang']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>