<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
               <div class="card">
                  <div class="card-header d-flex justify-content-between">
                     <div class="header-title">
                        <h4 class="card-title"><?= $title; ?></h4>
                     </div>
                     <div class="col-auto">
                        <a href="<?= base_url('bidang/add') ?>" class="btn btn-primary">
                            <span class="icon">
                                <i class="fa fa-user-plus"></i>
                            </span>
                            <span class="text">
                                Add
                            </span>
                        </a>
                    </div>
                  </div>
                  <div class="card-body">
                    <?= $this->session->flashdata('pesan'); ?>
                     <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped">
                           <thead>
                              <tr class="ligth">
                                 <th>No.</th>
                                 <th>Nama</th>
                                 <th>Kabid</th>
                                 <th>Aksi</th>
                              </tr>
                           </thead>
                           <tbody>
                                                <?php
                $no = 1;
                    foreach ($bidang as $bidang) :
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $bidang['nama_bidang']; ?></td>
                            <td><?= $bidang['nama']; ?></td>
                            <td>
                              <a class="btn btn-sm btn-icon btn-success" data-placement="top" title="Bagian" href="<?= base_url('bidang/bagian/') . $bidang['id_bidang'] ?>" data-original-title="Bagian">
                                 <i class="ri-user-add-line mr-0"></i>
                              </a>
                              
                                                        <a class="btn btn-sm btn-icon btn-warning" data-toggle="tooltip" data-placement="top" title="Edit" data-original-title="Edit" href="<?= base_url('bidang/edit/') . $bidang['id_bidang'] ?>">
                                                           <i class="ri-pencil-line mr-0"></i>
                                                        </a>
                                                        <a onclick="return confirm('Yakin ingin menghapus data?')" class="btn btn-sm btn-icon btn-danger" data-toggle="tooltip" data-placement="top" title="Delete" data-original-title="Delete" href="<?= base_url('bidang/delete/') . $bidang['id_bidang'] ?>">
                                                            <i class="ri-delete-bin-line mr-0"></i>
                                                        </a>
                               
                            </td>
                        </tr>
                        
                    <?php endforeach; ?>
                    </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>
      <!-- <button class="btn btn-sm btn-icon btn-success" title="Bagian" href="#modalBagian<?= $bidang['id_bidang']; ?>" data-toggle="modal">
                                 <i class="ri-user-add-line mr-0"></i>
                    </button>
                              <div class="modal fade bd-example-modal-lg" role="dialog" aria-modal="true" id="modalBagian<?= $bidang['id_bidang']; ?>">
        <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header d-block text-center pb-3 border-bttom">
                    <h3 class="modal-title" id="exampleModalCenterTitle02">Data Bagian</h3>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                             <div class="card-body">
                    <?= $this->session->flashdata('pesan'); ?>
                     <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped">
                           <thead>
                              <tr class="ligth">
                                 <th>No.</th>
                                 <th>Nama</th>
                                 <th>Kasi</th>
                              </tr>
                           </thead>
                           <tbody>
                <?php
                $no = 1;
                    foreach ($bagian as $bagian) :
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $bagian['nama_bagian']; ?></td>
                            <td><?= $bagian['nama']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                        </table>
                     </div>
                  </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="d-flex flex-wrap align-items-ceter justify-content-center mt-4">
                                <div class="btn btn-primary" data-dismiss="modal">Kembali</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>   -->
