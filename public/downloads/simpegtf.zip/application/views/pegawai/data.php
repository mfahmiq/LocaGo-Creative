<div class="content-page">
     <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-wrap align-items-center justify-content-between breadcrumb-content">
                            <h5><?= $title; ?></h5>
                            <div class="iq-search-bar device-search">
                                      <form action="<?= base_url('SearchController') ?>" method="get" class="searchbox">
                                          <button class="search-link" type="submit"><i class="ri-search-line"></i></button>
                                          <input type="text" name="keyword" class="text search-input" placeholder="Search here...">
                                      </form>
                                  </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
        <div id="grid" class="item-content animate__animated animate__fadeIn active" data-toggle-extra="tab-content">
             
            <div class="row">
                <?php $i = 1; ?>
                <?php                   
                foreach ($user as $user) :
                ?>
                <div class="col-lg-4 col-md-6">
                     
                    <div class="card-transparent card-block card-stretch card-height">
                        <div class="card-body text-center p-0"> 
                                  
                            <div class="item">
     
                                <div class="odr-img">
                                    <img src="<?= base_url() ?>template/assets/user/<?= $user['foto'] ?>" alt="<?= $user['nama']; ?>" class="img-fluid rounded-circle avatar-90 m-auto">
                                </div>                        
                                <div class="odr-content rounded">                                          
                                    <h4 class="mb-2"><?= $user['nama'] ?></h4>
                                    <p class="mb-3"><?= $user['role'] ?></p>
                                    
                                    <div class="pt-3 border-top">
                                        <a href="<?= base_url('user/detail/') . $user['id_user'] ?>" class="btn btn-primary">Detail</a>
                                    </div>
                                </div>
                                
                            </div>
                            
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
             
        </div>
    </div>
      </div>