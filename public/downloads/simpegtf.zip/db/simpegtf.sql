-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2023 at 10:24 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simpegtf`
--

-- --------------------------------------------------------

--
-- Table structure for table `bagian`
--

CREATE TABLE `bagian` (
  `id_bagian` int(11) NOT NULL,
  `nama_bagian` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_bidang` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `bidang`
--

CREATE TABLE `bidang` (
  `id_bidang` int(11) NOT NULL,
  `nama_bidang` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bidang`
--

INSERT INTO `bidang` (`id_bidang`, `nama_bidang`, `id_user`) VALUES
(1, 'Bidang Tata Usaha', 4);

-- --------------------------------------------------------

--
-- Table structure for table `biodata`
--

CREATE TABLE `biodata` (
  `id_biodata` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan') NOT NULL,
  `alamat` text NOT NULL,
  `tempat_lahir` varchar(100) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `no_telp` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `status_kawin` varchar(50) DEFAULT NULL,
  `agama` varchar(50) DEFAULT NULL,
  `ktp` varchar(100) NOT NULL,
  `kk` varchar(100) NOT NULL,
  `status` enum('Belum','Sudah') NOT NULL DEFAULT 'Belum'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `biodata`
--

INSERT INTO `biodata` (`id_biodata`, `id_user`, `jenis_kelamin`, `alamat`, `tempat_lahir`, `tanggal_lahir`, `no_telp`, `email`, `status_kawin`, `agama`, `ktp`, `kk`, `status`) VALUES
(2, 7, 'Laki-laki', 'jl. raja kecik', 'Pekanbaru', '2002-06-11', '081372755556', 'harry@gmail.com', 'Belum Kawin', 'Islam', 'MMShop_-_Home18.pdf', 'user_(1)23.png', 'Sudah'),
(4, 2, 'Laki-laki', 'aaaa', 'Pekanbaru', '2023-06-22', '081372755556', 'louis@gmail.com', 'Belum Kawin', 'Islam', 'user_(1)25.png', 'MMShop_-_Home20.pdf', 'Sudah'),
(5, 8, 'Laki-laki', 'aasjasjaas', 'Pekanbaru', '2023-06-22', '08788970002', 'liam@gmail.com', 'Belum Kawin', 'Islam', 'MMShop_-_Home21.pdf', 'Surat_Izin_Bang_Chan3.pdf', 'Sudah');

-- --------------------------------------------------------

--
-- Table structure for table `jabatan`
--

CREATE TABLE `jabatan` (
  `id_jabatan` int(11) NOT NULL,
  `nama_jabatan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jabatan`
--

INSERT INTO `jabatan` (`id_jabatan`, `nama_jabatan`) VALUES
(1, 'Direktur'),
(2, 'Kabid Tata Usaha'),
(3, 'Kabid Keperawatan'),
(4, 'Kabid Pelayanan dan Penunjang Medis'),
(5, 'Kabid Pengendalian dan Operasional'),
(6, 'Kasi Umum, Kepegawaian dan Humas'),
(7, 'Kasi Program dan Pelaporan'),
(8, 'Kasi Keuangan'),
(9, 'Kasi Penunjang Non Medik'),
(10, 'Kasi Sarana dan Prasarana'),
(11, 'Kasi Penunjang Medis'),
(12, 'Kasi Pelayanan Medis'),
(13, 'Kasi Pelayanan Keperawatan'),
(14, 'Kasi Asuhan Keperawatan'),
(15, 'Koordinator Hukum Kesehatan dan Layanan Pengaduan'),
(16, 'Koordinator Kemitraan dan Pemasaran'),
(17, 'Koordinator Taman'),
(18, 'Dokter Umum'),
(19, 'Dokter Spesialis Penyakit Dalam'),
(20, 'Dokter Spesialis THT'),
(21, 'Dokter Spesialis Mata'),
(22, 'Dokter Spesialis Obstetri dan Ginekologi'),
(23, 'Dokter Spesialis Bedah'),
(24, 'Dokter Spesialis Paru dan Pernafasan'),
(25, 'Dokter Spesialis Kulit dan Kelamin'),
(26, 'Dokter Spesialis Anak'),
(27, 'Dokter Spesialis Kedokteran Fisik dan Rehabilitasi Medik'),
(28, 'Dokter Spesialis Patologi Anatomik'),
(29, 'Dokter Spesialis Patologi Klinik'),
(30, 'Dokter Spesialis Radiologi'),
(31, 'Dokter Spesialis Neurologi'),
(32, 'Dokter Spesialis Bedah Orthopaedi dan Traumatologi'),
(33, 'Dokter Spesialis Anestesiologi dan Terapi Intensif'),
(34, 'Dokter Spesialis THT'),
(35, 'Dokter Spesialis Kedokteran Jiwa'),
(36, 'Dokter Gigi'),
(37, 'Pengadministrasian Kepegawaian'),
(38, 'Analis Humas'),
(39, 'Pengadministrasian Umum'),
(40, 'Perawat'),
(41, 'Pengemudi Ambulan'),
(42, 'Analis Laporan dan Transaksi Keuangan'),
(43, 'Bendahara Pengeluaran BLUD'),
(44, 'Pengadministrasian Keuangan'),
(45, 'Auditor'),
(46, 'Bidan'),
(47, 'Analis Kesehatan'),
(48, 'Tekniker Gigi'),
(49, 'Fisioterapis'),
(50, 'Terapi Wicara'),
(51, 'Nutrisionis'),
(52, 'Radiografer'),
(53, 'Pekarya'),
(54, 'Penata Anestesi'),
(55, 'Analis'),
(56, 'Apoteker'),
(57, 'Asisten Apoteker'),
(58, 'Asisten Tenaga Kesehatan'),
(59, 'Perekam Medis'),
(60, 'Pengadministrasi Rekam Medis dan Informasi'),
(61, 'Inspektur Sarana dan Prasarana Fasilitas'),
(62, 'Tenaga Informasi dan Teknologi'),
(63, 'Ahli Gizi'),
(64, 'Sanitarian'),
(65, 'Petugas Juru Masak'),
(66, 'Petugas Pramusaji'),
(67, 'Petugas CSSD'),
(68, 'Petugas Limbah'),
(69, 'Petugas Operator Komputer'),
(70, 'Petugas Humas'),
(71, 'Petugas Elektromedik'),
(72, 'Petugas Mesin dan Listrik'),
(73, 'Petugas Oksigen'),
(74, 'Petugas Loundry'),
(75, 'Petugas Keamanan'),
(76, 'Petugas Kamar Jenazah'),
(77, 'Petugas Kebersihan'),
(78, 'Petugas Supir'),
(79, 'Petugas Porter Obat'),
(80, 'Petugas Pengelola Keuangan RS'),
(81, 'Petugas Pustaka RS'),
(82, 'Petugas Loket'),
(83, 'Petugas Labor'),
(84, 'Petugas UTDRS'),
(85, 'Petugas Gudang Obat'),
(86, 'Petugas Rekam Medik');

-- --------------------------------------------------------

--
-- Table structure for table `pekerjaan`
--

CREATE TABLE `pekerjaan` (
  `id_pekerjaan` int(11) NOT NULL,
  `id_jabatan` int(11) NOT NULL,
  `nip` varchar(50) NOT NULL,
  `status_pegawai` varchar(50) NOT NULL,
  `mulai` date NOT NULL,
  `akhir` date NOT NULL,
  `bukti_kontrak` varchar(50) NOT NULL,
  `id_tempat` int(11) NOT NULL,
  `pangkat` varchar(100) NOT NULL,
  `status` enum('Sudah','Belum') NOT NULL DEFAULT 'Belum',
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pekerjaan`
--

INSERT INTO `pekerjaan` (`id_pekerjaan`, `id_jabatan`, `nip`, `status_pegawai`, `mulai`, `akhir`, `bukti_kontrak`, `id_tempat`, `pangkat`, `status`, `id_user`) VALUES
(4, 1, '12113', 'PNS', '2023-06-22', '2023-06-22', 'user_(1)5.png', 1, 'Pembina Utama (IV/e)', 'Sudah', 2),
(5, 2, '7282828', 'Honor BLUD', '2023-06-22', '2024-06-22', 'Surat_Izin_Bang_Chan.pdf', 2, 'Pembina Utama Madya (IV/d)', 'Sudah', 7),
(6, 8, '12121212', 'Honor BLUD', '2023-06-22', '2023-06-22', 'user.png', 8, '-', 'Sudah', 8),
(7, 31, '1122121', 'Honor BLUD', '2023-06-24', '2023-06-24', 'user_(1)7.png', 20, 'Pengatur Muda Tk.I (II/b)', 'Sudah', 3),
(8, 42, '121212', 'Kontrak', '2023-06-24', '2023-07-01', 'user_(1)8.png', 8, '-', 'Sudah', 4);

-- --------------------------------------------------------

--
-- Table structure for table `pelatihan`
--

CREATE TABLE `pelatihan` (
  `id_pelatihan` int(11) NOT NULL,
  `nama_pelatihan` varchar(100) NOT NULL,
  `id_user` int(11) NOT NULL,
  `media` enum('Offline','Online') NOT NULL,
  `bukti_pelatihan` varchar(100) NOT NULL,
  `tanggal_pelatihan` date NOT NULL,
  `tempat` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pelatihan`
--

INSERT INTO `pelatihan` (`id_pelatihan`, `nama_pelatihan`, `id_user`, `media`, `bukti_pelatihan`, `tanggal_pelatihan`, `tempat`, `link`, `status`) VALUES
(1, 'aaaa', 2, 'Online', 'user_(1)58.png', '2023-06-21', '', 'https://www.google.com/aclk?sa=l&ai=DChcSEwiv9eei8Lj_AhXGkmYCHWC6A-YYABAAGgJzbQ&sig=AOD64_1WQ9XBC2zb', 'Sudah');

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan`
--

CREATE TABLE `pendidikan` (
  `id_pendidikan` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `sekolah` varchar(100) NOT NULL,
  `jurusan` varchar(100) NOT NULL,
  `bukti_ijazah` varchar(100) NOT NULL,
  `transkrip_nilai` varchar(100) NOT NULL,
  `tahun_lulus` year(4) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pendidikan`
--

INSERT INTO `pendidikan` (`id_pendidikan`, `id_user`, `sekolah`, `jurusan`, `bukti_ijazah`, `transkrip_nilai`, `tahun_lulus`, `status`) VALUES
(1, 2, 'Politeknik Caltex Riau', 'Teknik Informatika', 'MMShop_-_Home.pdf', 'Surat_Izin_Bang_Chan.pdf', 2023, 'Sudah'),
(2, 2, 'Universitas Indonesia', 'Teknik Komputer dan Informasi', 'Laporan-Pertanyaan-08-06-2023.pdf', 'Laporan-Balasan-08-06-2023_2.pdf', 2022, 'Sudah'),
(3, 2, 'Universitas Abdurrab', 'Teknik Komputer', 'Surat_Izin_Bang_Chan3.pdf', 'MMShop_-_Home3.pdf', 2024, 'Sudah'),
(4, 2, 'Universitas Riau', 'Sistem Informasi', 'Surat_Izin_Bang_Chan4.pdf', 'MMShop_-_Home4.pdf', 2021, 'Sudah');

-- --------------------------------------------------------

--
-- Table structure for table `perizinan`
--

CREATE TABLE `perizinan` (
  `id_perizinan` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `no_str` varchar(100) NOT NULL,
  `tanggal_str` date NOT NULL,
  `bukti_str` varchar(100) NOT NULL,
  `no_sip` varchar(100) NOT NULL,
  `tanggal_sip` date NOT NULL,
  `bukti_sip` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `perizinan`
--

INSERT INTO `perizinan` (`id_perizinan`, `id_user`, `no_str`, `tanggal_str`, `bukti_str`, `no_sip`, `tanggal_sip`, `bukti_sip`, `status`) VALUES
(1, 2, '111', '2023-06-18', 'Surat_Izin_Bang_Chan2.pdf', '1233', '2023-06-21', 'MMShop_-_Home11.pdf', 'Sudah');

-- --------------------------------------------------------

--
-- Table structure for table `tempat_tugas`
--

CREATE TABLE `tempat_tugas` (
  `id_tempat` int(11) NOT NULL,
  `nama_tempat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tempat_tugas`
--

INSERT INTO `tempat_tugas` (`id_tempat`, `nama_tempat`) VALUES
(1, 'Direktur'),
(2, 'Bidang Tata Usaha'),
(3, 'Bidang Pengendalian dan Operasional'),
(4, 'Bidang Pelayanan dan Penunjang Medis'),
(5, 'Bidang Keperawatan'),
(6, 'Seksi Umum, Kepegawaian dan Humas'),
(7, 'Seksi Program dan Pelaporan'),
(8, 'Seksi Keuangan'),
(9, 'Seksi Pelayanan Keperawatan'),
(10, 'Seksi Asuhan dan Keperawatan'),
(11, 'Seksi Pelayanan Medis'),
(12, 'Seksi Penunjang Medis'),
(13, 'Seksi Penunjang Non Medis'),
(14, 'Seksi Sarana dan Prasarana'),
(15, 'Instalasi Gawat Darurat Non Trauma'),
(16, 'Komite Medik'),
(17, 'Pelayanan Jaminan Kesehatan'),
(18, 'Kasir'),
(19, 'Satuan Pengawas Internal (SPI)'),
(20, 'UPTD RSUD Tengku Rafi\'an'),
(21, 'PMKP'),
(22, 'Ruangan Screening'),
(23, 'Anestesi'),
(24, 'Instalasi Perekam Medik'),
(25, 'Instalasi Rawat Jalan'),
(26, 'Instalasi Radiologi'),
(27, 'Instalasi rawat Inap Paru & Pernafasan'),
(28, 'Instalasi Gawat Darurat Non Trauma'),
(29, 'Instalasi Gawat Darurat (IGD) Kebidanan'),
(30, 'Instalasi Rawat Inap VIP'),
(31, 'Instalasi Rawat Inap Kebidanan'),
(32, 'Instalasi Rawat Inap Shafa Internis'),
(33, 'Instalasi Rawat Inap Shafa Bedah'),
(34, 'Instalasi Rawat Inap Perinatologi'),
(35, 'Instalasi Rawat Inap Anak'),
(36, 'Instalasi Bedah Central'),
(37, 'Instalasi Rawat Inap ICU'),
(38, 'Instalasi Rawat Inap ICU Covid & Non Covid'),
(39, 'Instalasi Laboratorium'),
(40, 'Instalasi Farmasi'),
(42, 'Instalasi Gawat Darurat'),
(43, 'Instalasi Gizi'),
(44, 'Instalasi CSSD'),
(45, 'Instalasi Sanitasi Kesehatan Lingkungan & Loundry'),
(46, 'Instalasi Pemeliharaan Sarana dan Prasarana Rumah Sakit (IPSRS)'),
(47, 'Komite Keselamatan Kerja RS'),
(48, 'Promosi Kesehatan Rumah Sakit'),
(49, 'Poliklinik Umum'),
(50, 'Poliklinik Geriatri'),
(51, 'Poliklinik Kulit dan Kelamin'),
(52, 'Poliklinik Bedah'),
(53, 'Poliklinik Penyakit Dalam'),
(54, 'Poliklinik Kebidanan dan KB'),
(55, 'Poliklinik Anak'),
(56, 'Poli tumbuh Kembang'),
(57, 'Poliklinik Paru dan Pernafasan'),
(58, 'Poliklinik Neurologi/Saraf'),
(59, 'Poliklinik Mata'),
(60, 'Poliklinik THT'),
(61, 'Poliklinik Endoscopy'),
(62, 'Poliklinik Orthopedi'),
(63, 'Poliklinik Gigi dan Mulut'),
(64, 'Poliklinik Fisioterapi'),
(65, 'Laboratorium Teknik Gigi'),
(66, 'Unit Pencegahan Pengendalian Infeksi Rumah Sakit'),
(67, 'Pinere'),
(68, 'Pinere I'),
(69, 'Pinere II'),
(70, 'Haemodialisa'),
(71, 'Laboratorium Patologi Anatomi'),
(72, 'Skrinning'),
(73, 'Paru & Pinere I');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `role` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tanggal_bergabung` date NOT NULL,
  `foto` text NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan') NOT NULL,
  `alamat` text NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `no_telp` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `status_kawin` varchar(50) NOT NULL,
  `agama` varchar(50) NOT NULL,
  `ktp` varchar(100) NOT NULL,
  `kk` varchar(100) NOT NULL,
  `status` enum('Sudah','Belum') NOT NULL DEFAULT 'Belum'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama`, `username`, `role`, `password`, `tanggal_bergabung`, `foto`, `is_active`, `jenis_kelamin`, `alamat`, `tempat_lahir`, `tanggal_lahir`, `no_telp`, `email`, `status_kawin`, `agama`, `ktp`, `kk`, `status`) VALUES
(1, 'Admin', 'admin', 'Admin', '$2y$10$MSGben7dmXKCdEQ5ryU1DOJVDNkksPIoQJReWX7F.LBdTEs/Ryk3a', '2023-06-24', 'IMG_20220702_194652_0591.jpg', 1, 'Laki-laki', '', '', '0000-00-00', '', '', '', '', '', '', 'Belum'),
(2, 'Louis', 'direktur', 'Direktur', '$2y$10$eowpX3Bav0QkwDXPSDgDoOvKgaWIYlsw./X.tGj/WxgOSaDtCM9Cy', '2023-06-24', 'user3.png', 1, 'Laki-laki', 'aaaa', 'Pekanbaru', '2023-06-24', '081372755556', 'louis@gmail.com', 'Belum Kawin', 'Islam', 'user_(1)29.png', 'MMShop_-_Home23.pdf', 'Sudah'),
(3, 'Louis', 'louis', 'Pegawai', '$2y$10$BROK.pwjQVlKOoxtebf4UOCnMAaeyrwGstQLfATyESkp6kC1OwtRe', '2023-06-24', 'user.png', 1, 'Laki-laki', 'jl. raja kecik', 'pekanbaru', '2023-06-24', '081372755556', 'louis@gmail.com', 'Belum Kawin', 'Katolik', 'user_(1)27.png', 'Surat_Izin_Bang_Chan4.pdf', 'Sudah'),
(4, 'harry', 'harry', 'Pegawai', '$2y$10$bc/oO76Y3yydSjEGHDcFPuuqdU..4fPikCd/ynLa7C6.ZMZSpNddS', '2023-06-24', 'user.png', 1, 'Laki-laki', 'jl. sutomo', 'Siak', '2023-06-26', '081372755556', 'harry@gmail.com', 'Belum Kawin', 'Katolik', 'user_(1)28.png', 'MMShop_-_Home22.pdf', 'Sudah');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bagian`
--
ALTER TABLE `bagian`
  ADD PRIMARY KEY (`id_bagian`);

--
-- Indexes for table `bidang`
--
ALTER TABLE `bidang`
  ADD PRIMARY KEY (`id_bidang`);

--
-- Indexes for table `biodata`
--
ALTER TABLE `biodata`
  ADD PRIMARY KEY (`id_biodata`);

--
-- Indexes for table `jabatan`
--
ALTER TABLE `jabatan`
  ADD PRIMARY KEY (`id_jabatan`);

--
-- Indexes for table `pekerjaan`
--
ALTER TABLE `pekerjaan`
  ADD PRIMARY KEY (`id_pekerjaan`);

--
-- Indexes for table `pelatihan`
--
ALTER TABLE `pelatihan`
  ADD PRIMARY KEY (`id_pelatihan`);

--
-- Indexes for table `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD PRIMARY KEY (`id_pendidikan`);

--
-- Indexes for table `perizinan`
--
ALTER TABLE `perizinan`
  ADD PRIMARY KEY (`id_perizinan`);

--
-- Indexes for table `tempat_tugas`
--
ALTER TABLE `tempat_tugas`
  ADD PRIMARY KEY (`id_tempat`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bagian`
--
ALTER TABLE `bagian`
  MODIFY `id_bagian` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bidang`
--
ALTER TABLE `bidang`
  MODIFY `id_bidang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `biodata`
--
ALTER TABLE `biodata`
  MODIFY `id_biodata` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jabatan`
--
ALTER TABLE `jabatan`
  MODIFY `id_jabatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `pekerjaan`
--
ALTER TABLE `pekerjaan`
  MODIFY `id_pekerjaan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `pelatihan`
--
ALTER TABLE `pelatihan`
  MODIFY `id_pelatihan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pendidikan`
--
ALTER TABLE `pendidikan`
  MODIFY `id_pendidikan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `perizinan`
--
ALTER TABLE `perizinan`
  MODIFY `id_perizinan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tempat_tugas`
--
ALTER TABLE `tempat_tugas`
  MODIFY `id_tempat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
