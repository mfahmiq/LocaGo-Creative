# Sistem Pendukung Keputusan (SPK) - Spk Metode Saw Php

```
========================================================================
📦 Sistem Pendukung Keputusan (SPK) - Spk Metode Saw Php
Kategori     : Kecerdasan Buatan & SPK
Tech Stack   : PHP Native • PHP • MySQL
Database     : MySQL (.sql) (File: spksaw.sql)
Sumber Asli  : https://github.com/dms-p/spk-metode-saw-php (GitHub Open Source)
Stars GitHub : ⭐ 72 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/spk-metode-saw-php`
     * Untuk Laragon: `C:/laragon/www/spk-metode-saw-php`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `spk_metode_saw_php`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `spksaw.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = spk_metode_saw_php

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/spk-metode-saw-php

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
