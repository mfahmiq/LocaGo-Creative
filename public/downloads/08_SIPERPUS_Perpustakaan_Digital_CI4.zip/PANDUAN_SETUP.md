# Panduan SIPERPUS CodeIgniter 4
1. Ekstrak ke server web lokal Anda.
2. Import `database.sql` ke database MySQL `db_siperpus`.
3. Buka browser: `http://localhost/08_SIPERPUS_Perpustakaan_Digital_CI4/public`.
