CREATE DATABASE IF NOT EXISTS `db_siperpus`;
USE `db_siperpus`;

CREATE TABLE IF NOT EXISTS `buku` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode_buku` varchar(50) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `pengarang` varchar(150) NOT NULL,
  `stok` int(11) NOT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `buku` (`kode_buku`, `judul`, `pengarang`, `stok`) VALUES
('BK-0091', 'Pemrograman Web Modern React 19', 'Fahmi Eka', 12),
('BK-0142', 'Database MySQL & Query Optimization', 'Siti Rahma', 8),
('BK-0310', 'Struktur Data & Algoritma Python', 'Rian Hidayat', 15);
