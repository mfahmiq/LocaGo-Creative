<?php
/**
 * SIPUS - CRUD Anggota (Admin).
 * Menambah anggota otomatis membuat akun `users` role sesuai pilihan (siswa/admin)
 * dalam SATU transaksi PDO (beginTransaction/commit) agar data sinkron.
 */
declare(strict_types=1);

$pageTitle = 'Data Anggota — SIPUS';
require __DIR__ . '/../includes/header.php';

// ── RBAC: hanya admin ──
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

$pdo    = db();
$errors = [];
$notice = '';

// ── Daftar kelas untuk SARAN datalist (kelas kini boleh diketik manual juga) ──
$daftarKelas = ['X TKJ', 'XI TKJ', 'XII TKJ', 'X RPL', 'XI RPL', 'XII RPL', 'Staff/Admin'];

// ── Daftar role yang diizinkan (dipakai untuk render dropdown & validasi server-side) ──
$daftarRole = ['siswa' => 'User', 'admin' => 'Admin'];

$form = ['id_anggota' => 0, 'nomor_anggota' => '', 'nama' => '', 'kelas' => '', 'username' => '', 'role' => 'siswa'];

// ══════════════════ PROSES POST ══════════════════
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ─── Aksi HAPUS ───
    if (($_POST['aksi'] ?? '') === 'hapus') {
        $idHapus = filter_var($_POST['id_anggota'] ?? '', FILTER_VALIDATE_INT);
        if ($idHapus === false || $idHapus <= 0) {
            $errors[] = 'ID anggota tidak valid.';
        } else {
            try {
                $stmt = $pdo->prepare('SELECT COUNT(*) FROM peminjaman WHERE id_anggota = :id');
                $stmt->execute([':id' => $idHapus]);
                if ((int) $stmt->fetchColumn() > 0) {
                    $errors[] = 'Anggota tidak dapat dihapus karena memiliki riwayat peminjaman.';
                } else {
                    // Hapus anggota; akun users ikut terhapus via FK ON DELETE CASCADE
                    $stmt = $pdo->prepare('DELETE FROM anggota WHERE id_anggota = :id');
                    $stmt->execute([':id' => $idHapus]);
                    $notice = 'Anggota beserta akun login-nya berhasil dihapus.';
                }
            } catch (PDOException $e) {
                error_log('[SIPUS] Hapus anggota error: ' . $e->getMessage());
                $errors[] = 'Gagal menghapus anggota.';
            }
        }
    }

    // ─── Aksi TAMBAH / EDIT ───
    elseif (($_POST['aksi'] ?? '') === 'simpan') {
        $form['id_anggota'] = filter_var($_POST['id_anggota'] ?? '0', FILTER_VALIDATE_INT) ?: 0;
        $form['nomor_anggota'] = trim((string) ($_POST['nomor_anggota'] ?? ''));
        $form['nama']          = trim((string) ($_POST['nama'] ?? ''));
        $form['kelas']         = trim((string) ($_POST['kelas'] ?? ''));
        $form['username']      = trim((string) ($_POST['username'] ?? ''));
        $form['role']          = trim((string) ($_POST['role'] ?? ''));
        $password              = (string) ($_POST['password'] ?? '');

        // ── Validasi server-side ──
        if (!preg_match('/^[A-Za-z0-9]{3,20}$/', $form['nomor_anggota'])) {
            $errors[] = 'Nomor anggota wajib 3-20 karakter alfanumerik.';
        }
        if ($form['nama'] === '' || mb_strlen($form['nama']) > 100) {
            $errors[] = 'Nama wajib diisi (maks 100 karakter).';
        }
        // Kelas: boleh dipilih dari saran (datalist) ATAU diketik manual bebas,
        // jadi validasinya bukan lagi in_array ke daftar tetap, melainkan format umum.
        if ($form['kelas'] === '' || mb_strlen($form['kelas']) > 50) {
            $errors[] = 'Kelas wajib diisi (maks 50 karakter).';
        } elseif (!preg_match('/^[\p{L}\p{N}\s\/\-\.]+$/u', $form['kelas'])) {
            $errors[] = 'Kelas hanya boleh berisi huruf, angka, spasi, titik, strip, dan garis miring.';
        }
        if (!preg_match('/^[a-zA-Z0-9_.]{3,50}$/', $form['username'])) {
            $errors[] = 'Username wajib 3-50 karakter (huruf/angka/titik/garis bawah).';
        }
        // Role wajib salah satu dari daftar dropdown yang diizinkan (bukan input bebas)
        if (!array_key_exists($form['role'], $daftarRole)) {
            $errors[] = 'Role wajib dipilih (User atau Admin).';
        }

        // Password: wajib saat tambah; opsional saat edit (kosong = tidak diubah)
        $isEdit = $form['id_anggota'] > 0;
        if (!$isEdit && strlen($password) < 6) {
            $errors[] = 'Password minimal 6 karakter.';
        }
        if (strlen($password) > 0 && strlen($password) < 6) {
            $errors[] = 'Password minimal 6 karakter.';
        }
        if (strlen($password) > 100) {
            $errors[] = 'Password maksimal 100 karakter.';
        }

        // Uniqueness checks via prepared statement
        if (empty($errors)) {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM anggota WHERE nomor_anggota = :na AND id_anggota <> :id');
            $stmt->execute([':na' => $form['nomor_anggota'], ':id' => $form['id_anggota']]);
            if ((int) $stmt->fetchColumn() > 0) $errors[] = 'Nomor anggota sudah terdaftar.';

            $stmt = $pdo->prepare('SELECT COUNT(*) FROM anggota WHERE username = :u AND id_anggota <> :id');
            $stmt->execute([':u' => $form['username'], ':id' => $form['id_anggota']]);
            if ((int) $stmt->fetchColumn() > 0) $errors[] = 'Username sudah dipakai anggota lain.';

            $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE username = :u AND username <> (SELECT username FROM anggota WHERE id_anggota = :id)');
            $stmt->execute([':u' => $form['username'], ':id' => $form['id_anggota']]);
            if ((int) $stmt->fetchColumn() > 0) $errors[] = 'Username sudah dipakai pengguna lain.';
        }

        // ── Simpan dalam TRANSAKSI (anggota + users tetap sinkron) ──
        if (empty($errors)) {
            try {
                $pdo->beginTransaction();

                if ($isEdit) {
                    // Ambil username lama untuk sinkronisasi FK
                    $stmt = $pdo->prepare('SELECT username FROM anggota WHERE id_anggota = :id FOR UPDATE');
                    $stmt->execute([':id' => $form['id_anggota']]);
                    $usernameLama = $stmt->fetchColumn();
                    if ($usernameLama === false) {
                        throw new RuntimeException('Anggota tidak ditemukan.');
                    }

                    // Update username di users dulu (FK anggota ON UPDATE CASCADE akan mengikuti)
                    if ($usernameLama !== $form['username']) {
                        $stmt = $pdo->prepare('UPDATE users SET username = :uBaru WHERE username = :uLama');
                        $stmt->execute([':uBaru' => $form['username'], ':uLama' => $usernameLama]);
                    }

                    // Update role selalu disinkronkan sesuai pilihan pada form
                    $stmt = $pdo->prepare('UPDATE users SET role = :role WHERE username = :u');
                    $stmt->execute([':role' => $form['role'], ':u' => $form['username']]);

                    // Update password hanya jika diisi
                    if (strlen($password) > 0) {
                        $stmt = $pdo->prepare('UPDATE users SET password = :pw WHERE username = :u');
                        $stmt->execute([':pw' => password_hash($password, PASSWORD_BCRYPT), ':u' => $form['username']]);
                    }

                    $stmt = $pdo->prepare('UPDATE anggota SET nomor_anggota = :na, nama = :nm, kelas = :kls, username = :u
                                           WHERE id_anggota = :id');
                    $stmt->execute([
                        ':na' => $form['nomor_anggota'], ':nm' => $form['nama'],
                        ':kls'=> $form['kelas'],         ':u'  => $form['username'],
                        ':id' => $form['id_anggota'],
                    ]);
                    $notice = 'Data anggota berhasil diperbarui.';

                } else {
                    // CREATE: buat akun users (role sesuai pilihan) lalu data anggota
                    $stmt = $pdo->prepare('INSERT INTO users (username, password, role) VALUES (:u, :pw, :role)');
                    $stmt->execute([
                        ':u'    => $form['username'],
                        ':pw'   => password_hash($password, PASSWORD_BCRYPT),
                        ':role' => $form['role'],
                    ]);

                    $stmt = $pdo->prepare('INSERT INTO anggota (nomor_anggota, nama, kelas, username)
                                           VALUES (:na, :nm, :kls, :u)');
                    $stmt->execute([
                        ':na' => $form['nomor_anggota'], ':nm' => $form['nama'],
                        ':kls'=> $form['kelas'],         ':u'  => $form['username'],
                    ]);
                    $notice = 'Anggota baru berhasil ditambahkan beserta akun loginnya.';
                }

                $pdo->commit();
                $form = ['id_anggota' => 0, 'nomor_anggota' => '', 'nama' => '', 'kelas' => '', 'username' => '', 'role' => 'siswa'];

            } catch (PDOException|RuntimeException $e) {
                $pdo->rollBack();
                error_log('[SIPUS] Simpan anggota error: ' . $e->getMessage());
                $errors[] = 'Gagal menyimpan data anggota. Periksa kembali isian Anda.';
            }
        }
    }
}

// ─── Mode edit via GET ?edit=N ───
if (isset($_GET['edit'])) {
    $idEdit = filter_var($_GET['edit'], FILTER_VALIDATE_INT);
    if ($idEdit !== false && $idEdit > 0) {
        $stmt = $pdo->prepare('SELECT ag.*, u.role AS role
                               FROM anggota ag
                               LEFT JOIN users u ON u.username = ag.username
                               WHERE ag.id_anggota = :id');
        $stmt->execute([':id' => $idEdit]);
        $row = $stmt->fetch();
        if ($row) {
            $form = [
                'id_anggota'   => (int) $row['id_anggota'],
                'nomor_anggota'=> $row['nomor_anggota'],
                'nama'         => $row['nama'],
                'kelas'        => $row['kelas'],
                'username'     => $row['username'],
                'role'         => array_key_exists($row['role'] ?? '', $daftarRole) ? $row['role'] : 'siswa',
            ];
        }
    }
}

// ─── Data anggota (pencarian sekarang dilakukan LIVE di JS, query tetap mengambil semua
//      agar filter instan tanpa reload; parameter ?q= tetap didukung sebagai fallback) ───
$keyword = trim((string) ($_GET['q'] ?? ''));
$stmt = $pdo->prepare('SELECT ag.*,
                              (SELECT COUNT(*) FROM peminjaman p WHERE p.id_anggota = ag.id_anggota AND p.status = "dipinjam") AS aktif
                       FROM anggota ag
                       ORDER BY ag.id_anggota DESC
                       LIMIT 300');
$stmt->execute();
$daftarAnggota = $stmt->fetchAll();

// Jumlah anggota per halaman (pagination dijalankan di JS, mengikuti hasil pencarian live)
$perPage = 10;
?>

<style>
  /* Background solid biru muda — disamakan dengan dashboard, peminjaman, dan buku */
  html {
    height: 100%;
    background: #bfdbfe !important;
  }
  body {
    min-height: 100%;
    background: #bfdbfe !important;
  }

  /* Navbar semi-transparan agar menyatu dengan background */
  body > nav,
  nav.bg-white,
  header nav {
    background: rgba(255, 255, 255, 0.55) !important;
    background-image: none !important;
    backdrop-filter: blur(6px);
  }

  /* ══════════════════ Popup konfirmasi hapus anggota (custom) ══════════════════ */
  .hapus-overlay {
    position: fixed;
    inset: 0;
    z-index: 100;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 1rem;
    background: rgba(15, 23, 42, 0.45);
    backdrop-filter: blur(3px);
    animation: hapusFadeIn .18s ease-out;
  }
  .hapus-overlay.is-open { display: flex; }

  .hapus-card {
    width: 100%;
    max-width: 380px;
    border-radius: 20px;
    background: #ffffff;
    box-shadow: 0 20px 45px -10px rgba(30, 41, 59, 0.35);
    overflow: hidden;
    animation: hapusPopIn .22s cubic-bezier(.34,1.56,.64,1);
  }

  .hapus-card__banner {
    background: linear-gradient(135deg, #fb7185 0%, #be123c 100%);
    padding: 1.75rem 1.5rem 1.5rem;
    text-align: center;
    color: #fff;
    position: relative;
  }
  .hapus-card__banner::after {
    content: "";
    position: absolute;
    left: 0; right: 0; bottom: -1px;
    height: 18px;
    background: #fff;
    border-radius: 50% 50% 0 0 / 100% 100% 0 0;
  }
  .hapus-card__icon {
    width: 56px;
    height: 56px;
    margin: 0 auto .75rem;
    border-radius: 9999px;
    background: rgba(255,255,255,0.18);
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .hapus-card__icon svg { width: 28px; height: 28px; }

  .hapus-card__title {
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .08em;
  }

  .hapus-card__body {
    padding: 1.25rem 1.5rem 1.5rem;
    text-align: center;
  }
  .hapus-card__judul {
    font-size: 1.05rem;
    font-weight: 700;
    color: #1e293b;
    line-height: 1.4;
    margin-bottom: .35rem;
  }
  .hapus-card__sub {
    font-size: 0.85rem;
    color: #64748b;
    margin-bottom: 1.4rem;
  }

  .hapus-card__actions {
    display: flex;
    gap: .6rem;
  }
  .hapus-card__actions button {
    flex: 1;
    border-radius: 12px;
    padding: .65rem 1rem;
    font-size: .875rem;
    font-weight: 600;
    cursor: pointer;
    transition: transform .12s ease, box-shadow .12s ease, background .12s ease;
    border: none;
  }
  .hapus-btn-batal {
    background: #f1f5f9;
    color: #475569;
  }
  .hapus-btn-batal:hover { background: #e2e8f0; }

  .hapus-btn-ok {
    background: linear-gradient(135deg, #fb7185 0%, #be123c 100%);
    color: #fff;
    box-shadow: 0 8px 16px -4px rgba(190, 18, 60, .55);
  }
  .hapus-btn-ok:hover { transform: translateY(-1px); box-shadow: 0 10px 20px -4px rgba(190, 18, 60, .65); }
  .hapus-btn-ok:active { transform: translateY(0); }

  @keyframes hapusFadeIn {
    from { opacity: 0; }
    to   { opacity: 1; }
  }
  @keyframes hapusPopIn {
    from { opacity: 0; transform: scale(.92) translateY(6px); }
    to   { opacity: 1; transform: scale(1) translateY(0); }
  }
</style>

<div class="mb-6 flex flex-wrap items-start justify-between gap-3">
  <div class="flex items-start gap-3">
    <div>
      <div class="flex items-center gap-2">
        <h1 class="text-2xl font-bold text-slate-800">Data Anggota</h1>
      </div>
      <p class="text-sm text-slate-500">Tambah anggota otomatis membuat akun login sesuai role yang dipilih.</p>
    </div>
  </div>

  <!-- Search bar dengan saran (live search) disesuaikan persis seperti Data Buku -->
  <div class="relative w-full sm:w-80" id="searchWrap">
    <div class="flex gap-2">
      <div class="relative flex-1">
        <input type="text" id="liveSearch" autocomplete="off" value="<?= e($keyword) ?>"
               placeholder="Cari judul / penulis / nomor..."
               class="w-full rounded-lg border border-slate-200 bg-white/80 py-2 px-3 text-sm outline-none transition focus:border-[#5252ea] focus:bg-white focus:ring-2 focus:ring-indigo-100">
        <!-- Dropdown saran nama -->
        <div id="searchSuggestions"
             class="absolute z-20 mt-1 hidden w-full overflow-hidden rounded-lg border border-slate-200 bg-white shadow-lg"></div>
      </div>
      <button type="button" id="resetSearch"
              class="hidden shrink-0 rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-600 hover:bg-slate-50">
        Reset
      </button>
      <button type="button" class="rounded-lg bg-[#5252ea] px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-[#4343d6]">
        Cari
      </button>
    </div>
    <p class="mt-1 text-xs text-slate-400"><span id="searchCount"><?= count($daftarAnggota) ?></span> anggota ditemukan</p>
  </div>
</div>

<div id="noticeBox" class="<?= $notice !== '' ? '' : 'hidden' ?> mb-4 flex items-center justify-between rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 transition-opacity duration-500">
  <span><?= e($notice) ?></span>
</div>
<?php if (!empty($errors)): ?>
  <div class="mb-4 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
    <ul class="list-inside list-disc">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<div class="grid gap-6 lg:grid-cols-3">
  <!-- Form Tambah/Edit -->
  <div class="h-fit overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
    <div class="border-b border-slate-100 bg-white px-5 py-4">
      <h2 class="font-semibold text-slate-800"><?= $form['id_anggota'] > 0 ? 'Edit Anggota' : 'Tambah Anggota' ?></h2>
    </div>
    <form method="post" action="anggota.php" class="space-y-3 p-5" id="formAnggota">
      <input type="hidden" name="aksi" value="simpan">
      <input type="hidden" name="id_anggota" value="<?= (int) $form['id_anggota'] ?>">

      <div>
        <label class="mb-1 block text-xs font-medium text-slate-600">Nomor Anggota *</label>
        <input type="text" name="nomor_anggota" required maxlength="20" value="<?= e($form['nomor_anggota']) ?>"
               placeholder="cth: AG003"
               class="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm transition focus:border-[#5252ea] focus:ring-2 focus:ring-indigo-100 outline-none">
      </div>
      <div>
        <label class="mb-1 block text-xs font-medium text-slate-600">Nama Lengkap *</label>
        <input type="text" name="nama" required maxlength="100" value="<?= e($form['nama']) ?>"
               class="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm transition focus:border-[#5252ea] focus:ring-2 focus:ring-indigo-100 outline-none">
      </div>
      <div>
        <label class="mb-1 block text-xs font-medium text-slate-600">Kelas *</label>
        <!-- Combobox: input teks + datalist, sehingga bisa PILIH dari saran ATAU KETIK MANUAL bebas -->
        <input type="text" name="kelas" list="daftarKelasList" required maxlength="50"
               value="<?= e($form['kelas']) ?>"
               placeholder="Pilih dari daftar atau ketik manual..."
               autocomplete="off"
               class="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition focus:border-[#5252ea] focus:ring-2 focus:ring-indigo-100 outline-none">
        <datalist id="daftarKelasList">
          <?php foreach ($daftarKelas as $opsiKelas): ?>
            <option value="<?= e($opsiKelas) ?>">
          <?php endforeach; ?>
        </datalist>
        <p class="mt-1 text-xs text-slate-400">Ketik untuk melihat saran, atau isi kelas baru secara bebas.</p>
      </div>
      <div>
        <label class="mb-1 block text-xs font-medium text-slate-600">Username (untuk login) *</label>
        <input type="text" name="username" required maxlength="50" value="<?= e($form['username']) ?>"
               placeholder="cth: siswa03" pattern="[A-Za-z0-9_.]{3,50}"
               class="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm transition focus:border-[#5252ea] focus:ring-2 focus:ring-indigo-100 outline-none">
      </div>
      <div>
        <label class="mb-1 block text-xs font-medium text-slate-600">Role *</label>
        <select name="role" required
                class="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm transition focus:border-[#5252ea] focus:ring-2 focus:ring-indigo-100 outline-none">
          <?php foreach ($daftarRole as $nilaiRole => $labelRole): ?>
            <option value="<?= e($nilaiRole) ?>" <?= $form['role'] === $nilaiRole ? 'selected' : '' ?>><?= e($labelRole) ?></option>
          <?php endforeach; ?>
        </select>
        <p class="mt-1 text-xs text-slate-400">Menentukan hak akses akun login yang dibuat.</p>
      </div>

      <!-- ══════════════════ FITUR BARU: Hint & toggle lihat password ══════════════════ -->
      <div>
        <label class="mb-1 block text-xs font-medium text-slate-600">
          Password <?= $form['id_anggota'] > 0 ? '(kosongkan jika tidak diubah)' : '*' ?>
        </label>
        <div class="relative">
          <input type="password" name="password" id="inputPassword" minlength="6" maxlength="100"
                 <?= $form['id_anggota'] > 0 ? '' : 'required' ?> autocomplete="new-password"
                 class="w-full rounded-lg border border-slate-200 px-3 py-2 pr-10 text-sm transition focus:border-[#5252ea] focus:ring-2 focus:ring-indigo-100 outline-none">
          <button type="button" id="togglePassword" tabindex="-1"
                  class="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
            <svg id="iconEyeOpen" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
            </svg>
            <svg id="iconEyeClosed" xmlns="http://www.w3.org/2000/svg" class="hidden h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a21.62 21.62 0 0 1 5.06-6.06M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a21.6 21.6 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
              <line x1="1" y1="1" x2="23" y2="23"/>
            </svg>
          </button>
        </div>
        <p id="hintPassword" class="mt-1 text-xs text-slate-400">
          <?= $form['id_anggota'] > 0 ? 'Kosongkan jika tidak ingin mengubah password.' : 'Disimpan ter-hash dengan Bcrypt. Minimal 6 karakter.' ?>
        </p>
      </div>
      <!-- ══════════════════ akhir fitur baru ══════════════════ -->

      <div class="flex gap-2 pt-2">
        <button type="submit" id="btnSubmit"
                class="flex-1 rounded-lg bg-[#5252ea] py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-[#4343d6] disabled:cursor-not-allowed disabled:opacity-60">
          <?= $form['id_anggota'] > 0 ? 'Perbarui' : 'Tambah' ?>
        </button>
        <?php if ($form['id_anggota'] > 0): ?>
          <a href="anggota.php" class="rounded-lg border border-slate-300 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50">Batal</a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <!-- Tabel (desktop) + kartu (mobile) -->
  <div class="overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 lg:col-span-2">
    <div class="border-b border-slate-100 bg-white px-5 py-4">
      <h2 class="font-semibold text-slate-800">Daftar Anggota <span class="text-sm font-normal text-slate-400">(<?= count($daftarAnggota) ?>)</span></h2>
    </div>

    <!-- Tampilan tabel: md ke atas -->
    <div class="hidden overflow-x-auto md:block">
      <table class="w-full text-left text-sm">
        <thead class="bg-slate-50/80 text-xs uppercase tracking-wide text-slate-500">
          <tr>
            <th class="px-4 py-3">No. Anggota</th>
            <th class="px-4 py-3">Nama</th>
            <th class="px-4 py-3">Kelas</th>
            <th class="px-4 py-3">Username</th>
            <th class="px-4 py-3">Pinjaman Aktif</th>
            <th class="px-4 py-3 text-right">Aksi</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-100" id="tabelBody">
          <?php foreach ($daftarAnggota as $i => $ag): ?>
            <tr class="row-anggota hover:bg-slate-50 <?= $i >= $perPage ? 'hidden' : '' ?>"
                data-idx="<?= $i ?>"
                data-search="<?= e(mb_strtolower($ag['nama'] . ' ' . $ag['nomor_anggota'] . ' ' . $ag['kelas'] . ' ' . $ag['username'])) ?>"
                data-nama="<?= e($ag['nama']) ?>">
              <td class="px-4 py-3 font-mono text-xs"><?= e($ag['nomor_anggota']) ?></td>
              <td class="px-4 py-3 font-medium text-slate-800"><?= e($ag['nama']) ?></td>
              <td class="px-4 py-3 text-slate-600"><?= e($ag['kelas']) ?></td>
              <td class="px-4 py-3 text-slate-500"><?= e($ag['username']) ?></td>
              <td class="px-4 py-3">
                <?php if ((int) $ag['aktif'] > 0): ?>
                  <span class="inline-block rounded-md bg-amber-100/70 px-2.5 py-1 text-xs font-semibold text-amber-700"><?= (int) $ag['aktif'] ?> dipinjam</span>
                <?php else: ?>
                  <span class="text-xs text-slate-400">Tidak ada</span>
                <?php endif; ?>
              </td>
              <td class="px-4 py-3">
                <div class="flex justify-end gap-2">
                  <a href="anggota.php?edit=<?= (int) $ag['id_anggota'] ?>"
                     class="rounded-md bg-[#eef2ff] px-3 py-1 text-xs font-medium text-[#6366f1] transition hover:bg-indigo-100">Edit</a>
                  <form method="post" action="anggota.php" class="form-hapus" data-nama="<?= e($ag['nama']) ?>">
                    <input type="hidden" name="aksi" value="hapus">
                    <input type="hidden" name="id_anggota" value="<?= (int) $ag['id_anggota'] ?>">
                    <button type="submit" class="rounded-md bg-[#fff1f2] px-3 py-1 text-xs font-medium text-[#f43f5e] transition hover:bg-rose-100">Hapus</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <!-- Tampilan kartu: di bawah md (mobile) -->
    <div class="divide-y divide-slate-100 md:hidden" id="cardBody">
      <?php foreach ($daftarAnggota as $i => $ag): ?>
        <div class="row-anggota p-4 <?= $i >= $perPage ? 'hidden' : '' ?>"
             data-idx="<?= $i ?>"
             data-search="<?= e(mb_strtolower($ag['nama'] . ' ' . $ag['nomor_anggota'] . ' ' . $ag['kelas'] . ' ' . $ag['username'])) ?>"
             data-nama="<?= e($ag['nama']) ?>">
          <div class="flex items-start justify-between gap-3">
            <div>
              <p class="font-medium text-slate-800"><?= e($ag['nama']) ?></p>
              <p class="font-mono text-xs text-slate-400"><?= e($ag['nomor_anggota']) ?> · <?= e($ag['kelas']) ?></p>
              <p class="mt-0.5 text-xs text-slate-500">@<?= e($ag['username']) ?></p>
            </div>
            <?php if ((int) $ag['aktif'] > 0): ?>
              <span class="shrink-0 rounded-md bg-amber-100/70 px-2.5 py-1 text-xs font-semibold text-amber-700"><?= (int) $ag['aktif'] ?> dipinjam</span>
            <?php else: ?>
              <span class="shrink-0 text-xs text-slate-400">Tidak ada</span>
            <?php endif; ?>
          </div>
          <div class="mt-3 flex gap-2">
            <a href="anggota.php?edit=<?= (int) $ag['id_anggota'] ?>"
               class="flex-1 rounded-md bg-[#eef2ff] px-3 py-1.5 text-center text-xs font-medium text-[#6366f1] transition hover:bg-indigo-100">Edit</a>
            <form method="post" action="anggota.php" class="form-hapus flex-1" data-nama="<?= e($ag['nama']) ?>">
              <input type="hidden" name="aksi" value="hapus">
              <input type="hidden" name="id_anggota" value="<?= (int) $ag['id_anggota'] ?>">
              <button type="submit" class="w-full rounded-md bg-[#fff1f2] px-3 py-1.5 text-xs font-medium text-[#f43f5e] transition hover:bg-rose-100">Hapus</button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Pesan kosong (muncul saat hasil pencarian nihil) -->
    <div id="emptyState" class="hidden px-4 py-10 text-center text-slate-400">
      Tidak ada anggota yang cocok dengan pencarian.
    </div>
  </div>
</div>

<!-- Pagination (dirender oleh JS, mengikuti hasil pencarian live) -->
<div id="paginationAnggota"></div>

<!-- ══════════════════ Popup konfirmasi hapus anggota (custom, menggantikan confirm() bawaan) ══════════════════ -->
<div id="hapusOverlay" class="hapus-overlay" role="dialog" aria-modal="true" aria-labelledby="hapusJudul">
  <div class="hapus-card">
    <div class="hapus-card__banner">
      <div class="hapus-card__icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="3 6 5 6 21 6"/>
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
        </svg>
      </div>
      <div class="hapus-card__title">Konfirmasi Hapus</div>
    </div>
    <div class="hapus-card__body">
      <div id="hapusJudul" class="hapus-card__judul">&mdash;</div>
      <div class="hapus-card__sub">Akun login anggota ini akan ikut terhapus. Tindakan ini tidak bisa dibatalkan.</div>
      <div class="hapus-card__actions">
        <button type="button" class="hapus-btn-batal" id="hapusBatal">Batal</button>
        <button type="button" class="hapus-btn-ok" id="hapusOk">Ya, Hapus</button>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  const searchInput   = document.getElementById('liveSearch');
  const suggestBox    = document.getElementById('searchSuggestions');
  const resetBtn      = document.getElementById('resetSearch');
  const searchCountEl = document.getElementById('searchCount');
  const emptyState    = document.getElementById('emptyState');
  const noticeBox     = document.getElementById('noticeBox');
  const paginasi      = document.getElementById('paginationAnggota');

  // Kumpulkan semua baris (tabel desktop + kartu mobile tetap disinkronkan sekaligus)
  const rows = Array.from(document.querySelectorAll('.row-anggota'));

  // ── Pagination (client-side, mengikuti hasil pencarian) ──
  const PER_PAGE = <?= (int) $perPage ?>;
  let halaman    = 1;
  let kataAktif  = searchInput.value;

  // Satu entri per anggota (baris tabel & kartu mobile berbagi data-idx yang sama)
  const daftar = [];
  const sudahAda = new Set();
  rows.forEach((r) => {
    if (sudahAda.has(r.dataset.idx)) return;
    sudahAda.add(r.dataset.idx);
    daftar.push({ idx: r.dataset.idx, search: r.dataset.search });
  });

  // Debounce kecil supaya pencarian terasa instan tapi tidak "gugup" saat mengetik cepat
  function debounce(fn, delay) {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), delay); };
  }

  // Render kontrol halaman (gaya sama dengan Data Buku & Daftar Buku siswa)
  function renderPagination(total, totalPages) {
    paginasi.innerHTML = '';
    if (total <= 0 || totalPages <= 1) return;

    const dari = (halaman - 1) * PER_PAGE + 1;
    const ke   = Math.min(halaman * PER_PAGE, total);

    const nav = document.createElement('nav');
    nav.className = 'mt-8 flex flex-col items-center gap-3';
    nav.setAttribute('aria-label', 'Navigasi halaman');

    const row = document.createElement('div');
    row.className = 'flex flex-wrap items-center justify-center gap-1.5';

    function tombolLink(label, p, angka) {
      const b = document.createElement('button');
      b.type = 'button';
      b.setAttribute('data-page', p);
      b.className = 'rounded-lg border border-slate-300 bg-white ' + (angka ? 'px-3.5' : 'px-3') + ' py-2 text-sm font-medium text-slate-600 hover:bg-slate-50';
      b.textContent = label;
      return b;
    }
    function tombolMati(label) {
      const s = document.createElement('span');
      s.className = 'cursor-not-allowed rounded-lg border border-slate-200 bg-white/60 px-3 py-2 text-sm font-medium text-slate-300';
      s.textContent = label;
      return s;
    }

    row.appendChild(halaman > 1 ? tombolLink('\u00ab Sebelumnya', halaman - 1, false) : tombolMati('\u00ab Sebelumnya'));

    let terakhirTitik = false;
    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || Math.abs(i - halaman) <= 1) {
        terakhirTitik = false;
        if (i === halaman) {
          const aktif = document.createElement('span');
          aktif.className = 'rounded-lg bg-indigo-600 px-3.5 py-2 text-sm font-semibold text-white shadow-sm';
          aktif.textContent = i;
          row.appendChild(aktif);
        } else {
          row.appendChild(tombolLink(String(i), i, true));
        }
      } else if (!terakhirTitik) {
        terakhirTitik = true;
        const titik = document.createElement('span');
        titik.className = 'px-2 text-sm text-slate-500';
        titik.textContent = '\u2026';
        row.appendChild(titik);
      }
    }

    row.appendChild(halaman < totalPages ? tombolLink('Berikutnya \u00bb', halaman + 1, false) : tombolMati('Berikutnya \u00bb'));

    const info = document.createElement('p');
    info.className = 'text-xs text-slate-600';
    info.textContent = 'Menampilkan ' + dari + '\u2013' + ke + ' dari ' + total + ' anggota';

    nav.appendChild(row);
    nav.appendChild(info);
    paginasi.appendChild(nav);
  }

  // tetapHalaman = true dipakai saat pindah halaman; pencarian baru selalu kembali ke halaman 1
  function applyFilter(keyword, tetapHalaman) {
    const kw = keyword.trim().toLowerCase();
    kataAktif = keyword;
    if (!tetapHalaman) halaman = 1;

    const cocok = daftar
      .filter((d) => kw === '' || d.search.includes(kw))
      .map((d) => d.idx);

    const total      = cocok.length;
    const totalPages = Math.max(1, Math.ceil(total / PER_PAGE));
    if (halaman > totalPages) halaman = totalPages;

    const mulai  = (halaman - 1) * PER_PAGE;
    const tampil = new Set(cocok.slice(mulai, mulai + PER_PAGE));

    rows.forEach((row) => {
      row.classList.toggle('hidden', !tampil.has(row.dataset.idx));
    });

    searchCountEl.textContent = total;
    emptyState.classList.toggle('hidden', total !== 0);
    resetBtn.classList.toggle('hidden', kw === '');
    renderPagination(total, totalPages);
  }

  function buildSuggestions(keyword) {
    const kw = keyword.trim().toLowerCase();
    if (kw === '') { suggestBox.classList.add('hidden'); suggestBox.innerHTML = ''; return; }

    const namaUnik = [...new Set(rows.map(r => r.dataset.nama))]
      .filter(nama => nama.toLowerCase().includes(kw))
      .slice(0, 5);

    if (namaUnik.length === 0) { suggestBox.classList.add('hidden'); suggestBox.innerHTML = ''; return; }

    suggestBox.innerHTML = namaUnik.map(nama =>
      `<button type="button" class="suggestion-item block w-full px-4 py-2 text-left text-sm text-slate-700 hover:bg-indigo-50">${nama}</button>`
    ).join('');
    suggestBox.classList.remove('hidden');
  }

  const onType = debounce((value) => {
    applyFilter(value);
    buildSuggestions(value);
  }, 150);

  searchInput.addEventListener('input', (e) => onType(e.target.value));

  // Klik salah satu saran -> isi input, filter, sorot baris terkait
  suggestBox.addEventListener('click', (e) => {
    const item = e.target.closest('.suggestion-item');
    if (!item) return;
    const nama = item.textContent;
    searchInput.value = nama;
    applyFilter(nama);
    suggestBox.classList.add('hidden');

    const target = rows.find(r => r.dataset.nama === nama && !r.classList.contains('hidden'));
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'center' });
      target.classList.add('bg-indigo-50');
      setTimeout(() => target.classList.remove('bg-indigo-50'), 1200);
    }
  });

  // Klik nomor halaman / Sebelumnya / Berikutnya
  paginasi.addEventListener('click', (e) => {
    const tombol = e.target.closest('button[data-page]');
    if (!tombol) return;
    halaman = parseInt(tombol.getAttribute('data-page'), 10) || 1;
    applyFilter(kataAktif, true);

    // Gulir ke atas tabel supaya user langsung melihat data halaman baru.
    const kartu = document.getElementById('tabelBody').closest('.rounded-2xl');
    if (kartu && kartu.scrollIntoView) kartu.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  // Tutup dropdown saat klik di luar, atau saat Escape ditekan
  document.addEventListener('click', (e) => {
    if (!document.getElementById('searchWrap').contains(e.target)) {
      suggestBox.classList.add('hidden');
    }
  });
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') suggestBox.classList.add('hidden');
  });

  resetBtn.addEventListener('click', () => {
    searchInput.value = '';
    applyFilter('');
    suggestBox.classList.add('hidden');
    searchInput.focus();
  });

  // Render awal (memakai ?q= dari server bila ada, sekaligus menampilkan halaman 1 + pagination)
  applyFilter(searchInput.value);

  // Notifikasi sukses otomatis memudar setelah beberapa detik
  if (noticeBox && !noticeBox.classList.contains('hidden')) {
    setTimeout(() => {
      noticeBox.style.opacity = '0';
      setTimeout(() => noticeBox.classList.add('hidden'), 500);
    }, 4000);
  }

  // Cegah submit ganda saat menyimpan data
  const formAnggota = document.getElementById('formAnggota');
  const btnSubmit    = document.getElementById('btnSubmit');
  if (formAnggota && btnSubmit) {
    formAnggota.addEventListener('submit', () => {
      btnSubmit.disabled = true;
      btnSubmit.textContent = 'Menyimpan...';
    });
  }

  // ══════════════════ Popup konfirmasi hapus (custom, menggantikan confirm()) ══════════════════
  const hapusOverlay = document.getElementById('hapusOverlay');
  const hapusJudulEl = document.getElementById('hapusJudul');
  const hapusBtnOk    = document.getElementById('hapusOk');
  const hapusBtnBatal = document.getElementById('hapusBatal');
  let formHapusAktif  = null;

  function bukaHapusPopup(form) {
    formHapusAktif = form;
    hapusJudulEl.textContent = form.getAttribute('data-nama') || 'anggota ini';
    hapusOverlay.classList.add('is-open');
  }
  function tutupHapusPopup() {
    hapusOverlay.classList.remove('is-open');
    formHapusAktif = null;
  }

  document.querySelectorAll('form.form-hapus').forEach((form) => {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      bukaHapusPopup(form);
    });
  });

  hapusBtnOk.addEventListener('click', () => {
    if (formHapusAktif) {
      const f = formHapusAktif;
      tutupHapusPopup();
      f.submit();
    }
  });
  hapusBtnBatal.addEventListener('click', tutupHapusPopup);

  hapusOverlay.addEventListener('click', (e) => {
    if (e.target === hapusOverlay) tutupHapusPopup();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && hapusOverlay.classList.contains('is-open')) tutupHapusPopup();
  });

  // ══════════════════ FITUR BARU: Hint & toggle lihat password ══════════════════
  const inputPassword  = document.getElementById('inputPassword');
  const hintPassword   = document.getElementById('hintPassword');
  const togglePassword = document.getElementById('togglePassword');
  const iconEyeOpen    = document.getElementById('iconEyeOpen');
  const iconEyeClosed  = document.getElementById('iconEyeClosed');
  const isEditMode     = <?= $form['id_anggota'] > 0 ? 'true' : 'false' ?>;

  if (inputPassword && hintPassword) {
    inputPassword.addEventListener('input', () => {
      const len = inputPassword.value.length;
      if (len === 0) {
        hintPassword.textContent = isEditMode
          ? 'Kosongkan jika tidak ingin mengubah password.'
          : 'Disimpan ter-hash dengan Bcrypt. Minimal 6 karakter.';
        hintPassword.className = 'mt-1 text-xs text-slate-400';
      } else if (len < 6) {
        hintPassword.textContent = `Kurang ${6 - len} karakter lagi (minimal 6).`;
        hintPassword.className = 'mt-1 text-xs text-rose-500';
      } else if (len > 100) {
        hintPassword.textContent = 'Password melebihi batas maksimal 100 karakter.';
        hintPassword.className = 'mt-1 text-xs text-rose-500';
      } else {
        hintPassword.textContent = 'Password valid. Akan disimpan ter-hash dengan Bcrypt.';
        hintPassword.className = 'mt-1 text-xs text-emerald-500';
      }
    });
  }

  if (togglePassword && inputPassword) {
    togglePassword.addEventListener('click', () => {
      const tampil = inputPassword.type === 'text';
      inputPassword.type = tampil ? 'password' : 'text';
      iconEyeOpen.classList.toggle('hidden', !tampil);
      iconEyeClosed.classList.toggle('hidden', tampil);
    });
  }
})();
</script>

<?php require __DIR__ . '/../includes/footer.php'; ?>