<p align="center">
  <img src="https://img.shields.io/badge/Laravel-12.x-FF2D20?style=for-the-badge&logo=laravel&logoColor=white" alt="Laravel">
  <img src="https://img.shields.io/badge/PHP-8.2-777BB4?style=for-the-badge&logo=php&logoColor=white" alt="PHP">
  <img src="https://img.shields.io/badge/MySQL-4479A1?style=for-the-badge&logo=mysql&logoColor=white" alt="MySQL">
  <img src="https://img.shields.io/badge/Bootstrap-5-7952B3?style=for-the-badge&logo=bootstrap&logoColor=white" alt="Bootstrap">
  <img src="https://img.shields.io/badge/Sanctum-4.x-FF2D20?style=for-the-badge&logo=laravel&logoColor=white" alt="Sanctum">
</p>

<h1 align="center">Hotel Booking Management System</h1>

<p align="center">
  A comprehensive full-stack hotel booking platform built with Laravel 12 featuring role-based access control, real-time chat, premium subscriptions, multi-vendor support, and integrated car & travel booking services.
</p>

<p align="center">
  <a href="#features">Features</a> •
  <a href="#tech-stack">Tech Stack</a> •
  <a href="#screenshots">Screenshots</a> •
  <a href="#installation">Installation</a> •
  <a href="#api-documentation">API Docs</a> •
  <a href="#project-structure">Structure</a> •
  <a href="#contributing">Contributing</a>
</p>

---

## Features

### 👥 Role-Based Access Control

| Role | Permissions |
|------|-------------|
| **Customer** | Browse rooms/services, make bookings, chat with staff, subscribe to premium, view booking history |
| **Manager** | Manage hotels/rooms/services, confirm/reject bookings, respond to chat, view reports |
| **Admin** | Full system access, manage all users, system configuration, manage managers & premium plans |

### 🏨 Hotel & Room Management
- Multi-hotel support with manager assignment
- Room types: Standard, Deluxe, Suite, Presidential
- Room image uploads and amenity tagging
- Real-time availability status (Available / Occupied / Maintenance)
- Dynamic pricing per night

### 🛎️ Booking System
- Date-based room availability checking
- Overlapping booking prevention
- Add-on service selection (Spa, Restaurant, Gym, etc.)
- Premium discount auto-application
- Booking lifecycle: Pending → Confirmed → Completed / Cancelled
- 15-minute free cancellation policy for customers

### 💳 Multi-Method Payment & Wallet
- **Payment Methods:** Wallet, Card, bKash, Nagad, Rocket
- **Wallet System:** Deposit and pay from balance
- **Partial Payments:** Pay in installments
- **Auto Status Update:** Full payment confirms booking
- BDT (Taka) currency support

### 🚗 Car Rental Management
- Car CRUD with brand, model, transmission, fuel type
- City-based pickup & drop-off
- Inter-city surcharge calculation
- Rental booking management

### ✈️ Travel Package Booking
- Travel package management with destination filtering
- Durations and pricing
- Booking with guest count

### 💎 Premium Subscription System
- **Silver Tier:** 5% discount on bookings
- **Gold Tier:** 10% discount on bookings
- **Requirements:** Completed booking thresholds
- Subscription duration: 1–12 months
- Auto-discount on all bookings
- Extend/cancel subscription anytime

### 💬 Real-Time Chat System
- Customer ↔ Staff messaging
- Unified support inbox for managers/admins
- Unread message count notifications
- Message history persistence
- "Platform Support" auto-routing

### 📊 Admin Dashboard
- System-wide statistics (users, rooms, bookings, revenue)
- User management with role assignment
- Premium plan CRUD
- Booking oversight across all hotels
- Revenue tracking

### 📱 Responsive Frontend
- Bootstrap 5 powered UI
- Mobile-first responsive design
- Card-based room/car displays
- Modal-based booking interactions
- Clean, modern interface

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| **Backend** | Laravel 12.x, PHP 8.2 |
| **Frontend** | Blade Templates, Bootstrap 5, JavaScript |
| **API Auth** | Laravel Sanctum (Token-based) |
| **Database** | MySQL / SQLite |
| **Real-time** | Pusher (WebSocket for chat) |
| **File Storage** | Local disk (public/) |
| **Build Tool** | Vite |

---

## Screenshots

> *Screenshots coming soon. The project includes: Welcome page, Customer dashboard, Manager dashboard, Admin dashboard, Booking interface, Chat interface, and Payment portal.*

---

## Installation

### Prerequisites
- PHP 8.2+
- Composer 2.x
- Node.js & NPM
- MySQL or SQLite
- Git

### Step-by-Step Setup

```bash
# 1. Clone the repository
git clone https://github.com/muhammadrakib2299/Hotel-Booking-Management-System.git
cd Hotel-Booking-Management-System

# 2. Install PHP dependencies
composer install

# 3. Install frontend dependencies
npm install

# 4. Environment setup
cp .env.example .env
php artisan key:generate

# 5. Configure database in .env file
# DB_CONNECTION=mysql
# DB_HOST=127.0.0.1
# DB_PORT=3306
# DB_DATABASE=hotel_booking
# DB_USERNAME=root
# DB_PASSWORD=

# 6. Run migrations and seeders
php artisan migrate --seed

# 7. Build frontend assets
npm run build

# 8. Start the development server
php artisan serve

# 9. (Optional) Start queue for chat
php artisan queue:listen

# 10. Visit http://localhost:8000
```

### Default Credentials

| Role | Email | Password |
|------|-------|----------|
| **Admin** | admin@hotel.com | password123 |
| **Manager** | manager@hotel.com | password123 |
| **Customer** | john@example.com | password123 |

---

## API Documentation

The system provides a comprehensive RESTful API protected by Laravel Sanctum.

### Public Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/register` | User registration |
| POST | `/api/login` | User login |
| GET | `/api/rooms` | List all rooms |
| GET | `/api/rooms/{id}` | Get room details |
| GET | `/api/cars` | List available cars |
| GET | `/api/hotels/{id}` | Get hotel details |
| GET | `/api/cities` | Get distinct cities |
| GET | `/api/services` | List all services |
| GET | `/api/travel-packages` | List travel packages |
| GET | `/api/premium-plans` | View premium plans |
| POST | `/api/contact` | Submit contact form |

### Authenticated Endpoints (Requires `Bearer Token`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/user` | Get authenticated user |
| POST | `/api/logout` | Logout |
| GET | `/api/bookings` | List bookings (role-based) |
| POST | `/api/bookings` | Create booking |
| GET | `/api/bookings/my` | My bookings |
| POST | `/api/wallet/deposit` | Deposit to wallet |
| POST | `/api/bookings/{id}/pay` | Pay for booking |
| GET | `/api/chat/conversations` | Get conversations |
| POST | `/api/chat/send` | Send message |
| GET | `/api/chat/unread` | Unread count |

### Admin Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/dashboard` | Dashboard stats |
| GET | `/api/admin/users` | List all users |
| PUT | `/api/admin/users/{id}` | Update user |
| POST | `/api/admin/premium-plans` | Create plan |
| PUT | `/api/admin/premium-plans/{id}` | Update plan |

> Full API reference is available in `routes/api.php`.

---

## Project Structure

```
hotel-booking-system/
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── Auth/           # Authentication controllers
│   │   │   ├── AdminController.php
│   │   │   ├── BookingController.php
│   │   │   ├── CarController.php
│   │   │   ├── ChatController.php
│   │   │   ├── ContactController.php
│   │   │   ├── HotelController.php
│   │   │   ├── PaymentController.php
│   │   │   ├── PremiumController.php
│   │   │   ├── RoomController.php
│   │   │   ├── ServiceController.php
│   │   │   ├── TravelBookingController.php
│   │   │   └── TravelPackageController.php
│   │   └── Middleware/
│   │       ├── AuthMiddleware.php
│   │       └── RoleMiddleware.php
│   ├── Models/
│   │   ├── Booking.php
│   │   ├── Car.php
│   │   ├── CarBooking.php
│   │   ├── ContactMessage.php
│   │   ├── Hotel.php
│   │   ├── Message.php
│   │   ├── PremiumPlan.php
│   │   ├── PremiumSubscription.php
│   │   ├── Room.php
│   │   ├── Service.php
│   │   ├── TravelBooking.php
│   │   ├── TravelPackage.php
│   │   └── User.php
│   └── Providers/
├── config/                     # Laravel config files
├── database/
│   ├── migrations/             # 25+ migration files
│   └── seeders/
│       ├── DatabaseSeeder.php
│       ├── MultiVendorSeeder.php
│       └── PremiumPlanSeeder.php
├── resources/
│   └── views/
│       ├── admin/              # Admin dashboard views
│       ├── auth/               # Login/Register views
│       ├── customer/           # Customer views
│       ├── layouts/            # Layout templates
│       ├── manager/            # Manager views
│       │   ├── cars/           # Car management
│       │   └── travel/         # Travel management
│       └── welcome.blade.php   # Landing page
├── routes/
│   ├── api.php                 # API routes
│   ├── auth.php                # Auth routes
│   ├── console.php             # Console commands
│   └── web.php                 # Web routes
├── public/                     # Public assets
├── storage/                    # App storage
├── tests/                      # Tests
├── composer.json
├── package.json
└── vite.config.js
```

---

## Database Schema

The application uses **25+ migration files** covering:

- `users` — User accounts with roles, premium status, wallet balance
- `hotels` — Multi-hotel management
- `rooms` — Room details with pricing, amenities, availability
- `services` — Add-on services (spa, restaurant, gym, etc.)
- `bookings` — Room bookings with payment tracking
- `booking_services` — Pivot for booking-service relationships
- `messages` — Chat messages between users
- `premium_plans` — Subscription plan configuration
- `premium_subscriptions` — User premium subscriptions
- `travel_packages` — Travel packages by vendors
- `travel_bookings` — Travel package bookings
- `cars` — Rental car inventory
- `car_bookings` — Car rental bookings
- `contact_messages` — Contact form submissions
- `personal_access_tokens` — Sanctum API tokens

---

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## License

This project is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).

---

<p align="center">
  Built with ❤️ using <a href="https://laravel.com">Laravel</a> | Developed by <a href="https://github.com/muhammadrakib2299">Muhammad Rakib</a>
</p>
