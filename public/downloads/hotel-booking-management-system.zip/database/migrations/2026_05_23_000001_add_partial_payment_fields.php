<?php
 
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // 1. Modify payment_status to include 'partial' in the enum
        DB::statement("ALTER TABLE bookings MODIFY COLUMN payment_status ENUM('unpaid', 'partial', 'paid') NOT NULL DEFAULT 'unpaid'");
        DB::statement("ALTER TABLE travel_bookings MODIFY COLUMN payment_status ENUM('unpaid', 'partial', 'paid') NOT NULL DEFAULT 'unpaid'");
        DB::statement("ALTER TABLE car_bookings MODIFY COLUMN payment_status ENUM('unpaid', 'partial', 'paid') NOT NULL DEFAULT 'unpaid'");

        // 2. Add paid_amount decimal column to all three tables
        Schema::table('bookings', function (Blueprint $table) {
            $table->decimal('paid_amount', 10, 2)->default(0.00)->after('payment_status');
        });

        Schema::table('travel_bookings', function (Blueprint $table) {
            $table->decimal('paid_amount', 10, 2)->default(0.00)->after('payment_status');
        });

        Schema::table('car_bookings', function (Blueprint $table) {
            $table->decimal('paid_amount', 10, 2)->default(0.00)->after('payment_status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // 1. Drop paid_amount column
        Schema::table('bookings', function (Blueprint $table) {
            $table->dropColumn('paid_amount');
        });

        Schema::table('travel_bookings', function (Blueprint $table) {
            $table->dropColumn('paid_amount');
        });

        Schema::table('car_bookings', function (Blueprint $table) {
            $table->dropColumn('paid_amount');
        });

        // 2. Modify payment_status back to enum('unpaid', 'paid')
        DB::statement("ALTER TABLE bookings MODIFY COLUMN payment_status ENUM('unpaid', 'paid') NOT NULL DEFAULT 'unpaid'");
        DB::statement("ALTER TABLE travel_bookings MODIFY COLUMN payment_status ENUM('unpaid', 'paid') NOT NULL DEFAULT 'unpaid'");
        DB::statement("ALTER TABLE car_bookings MODIFY COLUMN payment_status ENUM('unpaid', 'paid') NOT NULL DEFAULT 'unpaid'");
    }
};
