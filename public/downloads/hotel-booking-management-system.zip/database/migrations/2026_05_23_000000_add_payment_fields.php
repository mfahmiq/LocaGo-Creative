<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->decimal('balance', 10, 2)->default(5000.00)->after('premium_tier');
        });

        Schema::table('bookings', function (Blueprint $table) {
            $table->enum('payment_status', ['unpaid', 'paid'])->default('unpaid')->after('status');
            $table->string('transaction_id')->nullable()->after('payment_status');
        });

        Schema::table('travel_bookings', function (Blueprint $table) {
            $table->enum('payment_status', ['unpaid', 'paid'])->default('unpaid')->after('status');
            $table->string('transaction_id')->nullable()->after('payment_status');
        });

        Schema::table('car_bookings', function (Blueprint $table) {
            $table->enum('payment_status', ['unpaid', 'paid'])->default('unpaid')->after('status');
            $table->string('transaction_id')->nullable()->after('payment_status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('balance');
        });

        Schema::table('bookings', function (Blueprint $table) {
            $table->dropColumn(['payment_status', 'transaction_id']);
        });

        Schema::table('travel_bookings', function (Blueprint $table) {
            $table->dropColumn(['payment_status', 'transaction_id']);
        });

        Schema::table('car_bookings', function (Blueprint $table) {
            $table->dropColumn(['payment_status', 'transaction_id']);
        });
    }
};
