<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\Hotel;
use App\Models\Room;
use App\Models\Booking;
use App\Models\TravelPackage;
use App\Models\TravelBooking;
use App\Models\Car;
use App\Models\CarBooking;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class PaymentSystemTest extends TestCase
{
    use DatabaseTransactions;

    protected $user;
    protected $manager;

    protected function setUp(): void
    {
        parent::setUp();

        // Create a test manager/vendor user
        $this->manager = User::create([
            'name' => 'Manager User',
            'email' => 'manager_' . uniqid() . '@example.com',
            'password' => bcrypt('password'),
            'role' => 'manager',
        ]);

        // Create a test customer user
        $this->user = User::create([
            'name' => 'John Doe',
            'email' => 'customer_' . uniqid() . '@example.com',
            'password' => bcrypt('password'),
            'role' => 'customer',
            'balance' => 5000.00,
        ]);
    }

    public function test_wallet_deposit_endpoint()
    {
        Sanctum::actingAs($this->user);

        $response = $this->postJson('/api/wallet/deposit', [
            'amount' => 1500.50,
            'payment_method' => 'bkash'
        ]);

        $response->assertStatus(200)
            ->assertJsonStructure(['message', 'balance', 'transaction_id'])
            ->assertJson([
                'message' => 'Deposit successful!',
                'balance' => 6500.50,
            ]);

        $this->assertEquals(6500.50, $this->user->fresh()->balance);
    }

    public function test_wallet_deposit_validation()
    {
        Sanctum::actingAs($this->user);

        // Test missing parameters
        $response = $this->postJson('/api/wallet/deposit', []);
        $response->assertStatus(422)
            ->assertJsonValidationErrors(['amount', 'payment_method']);

        // Test invalid amount
        $response = $this->postJson('/api/wallet/deposit', [
            'amount' => -100,
            'payment_method' => 'card'
        ]);
        $response->assertStatus(422);
    }

    public function test_room_booking_payment_via_wallet()
    {
        Sanctum::actingAs($this->user);

        // Setup hotel & room
        $hotel = Hotel::create([
            'name' => 'Ocean View Hotel',
            'city' => 'Cox\'s Bazar',
            'address' => 'Beach Road',
            'manager_id' => $this->manager->id,
        ]);

        $room = Room::create([
            'hotel_id' => $hotel->id,
            'room_number' => 'A-101-' . uniqid(),
            'room_type' => 'deluxe',
            'description' => 'Test Room Description',
            'price_per_night' => 1000.00,
            'status' => 'available',
            'capacity' => 2,
        ]);

        // Create an unpaid, pending booking
        $booking = Booking::create([
            'user_id' => $this->user->id,
            'hotel_id' => $hotel->id,
            'room_id' => $room->id,
            'check_in_date' => now()->addDays(1)->format('Y-m-d'),
            'check_out_date' => now()->addDays(3)->format('Y-m-d'),
            'total_price' => 2000.00,
            'status' => 'pending',
            'payment_status' => 'unpaid',
        ]);

        $response = $this->postJson("/api/bookings/{$booking->id}/pay", [
            'payment_method' => 'wallet'
        ]);

        $response->assertStatus(200)
            ->assertJsonStructure(['message', 'booking', 'balance']);

        // Assert user balance is deducted
        $this->assertEquals(3000.00, $this->user->fresh()->balance);

        // Assert booking is confirmed and paid
        $updatedBooking = $booking->fresh();
        $this->assertEquals('paid', $updatedBooking->payment_status);
        $this->assertEquals('confirmed', $updatedBooking->status);
        $this->assertNotEmpty($updatedBooking->transaction_id);

        // Assert room status changed to occupied
        $this->assertEquals('occupied', $room->fresh()->status);
    }

    public function test_room_booking_payment_insufficient_wallet_balance()
    {
        Sanctum::actingAs($this->user);

        $hotel = Hotel::create([
            'name' => 'Ocean View Hotel',
            'city' => 'Cox\'s Bazar',
            'address' => 'Beach Road',
            'manager_id' => $this->manager->id,
        ]);

        $room = Room::create([
            'hotel_id' => $hotel->id,
            'room_number' => 'A-102-' . uniqid(),
            'room_type' => 'deluxe',
            'description' => 'Test Room Description',
            'price_per_night' => 4000.00,
            'status' => 'available',
            'capacity' => 2,
        ]);

        // Booking total is 8000, but user only has 5000
        $booking = Booking::create([
            'user_id' => $this->user->id,
            'hotel_id' => $hotel->id,
            'room_id' => $room->id,
            'check_in_date' => now()->addDays(1)->format('Y-m-d'),
            'check_out_date' => now()->addDays(3)->format('Y-m-d'),
            'total_price' => 8000.00,
            'status' => 'pending',
            'payment_status' => 'unpaid',
        ]);

        $response = $this->postJson("/api/bookings/{$booking->id}/pay", [
            'payment_method' => 'wallet'
        ]);

        $response->assertStatus(422)
            ->assertJson(['message' => 'Insufficient wallet balance']);

        // Assert balance remained intact
        $this->assertEquals(5000.00, $this->user->fresh()->balance);
        $this->assertEquals('unpaid', $booking->fresh()->payment_status);
    }

    public function test_room_booking_payment_via_direct_gateway_card()
    {
        Sanctum::actingAs($this->user);

        $hotel = Hotel::create([
            'name' => 'Ocean View Hotel',
            'city' => 'Cox\'s Bazar',
            'address' => 'Beach Road',
            'manager_id' => $this->manager->id,
        ]);

        $room = Room::create([
            'hotel_id' => $hotel->id,
            'room_number' => 'A-103-' . uniqid(),
            'room_type' => 'deluxe',
            'description' => 'Test Room Description',
            'price_per_night' => 1000.00,
            'status' => 'available',
            'capacity' => 2,
        ]);

        $booking = Booking::create([
            'user_id' => $this->user->id,
            'hotel_id' => $hotel->id,
            'room_id' => $room->id,
            'check_in_date' => now()->addDays(1)->format('Y-m-d'),
            'check_out_date' => now()->addDays(3)->format('Y-m-d'),
            'total_price' => 2000.00,
            'status' => 'pending',
            'payment_status' => 'unpaid',
        ]);

        // Direct payment via Card doesn't deduct wallet balance
        $response = $this->postJson("/api/bookings/{$booking->id}/pay", [
            'payment_method' => 'card'
        ]);

        $response->assertStatus(200);

        // Wallet balance remains 5000.00
        $this->assertEquals(5000.00, $this->user->fresh()->balance);

        // Booking is confirmed and paid
        $updatedBooking = $booking->fresh();
        $this->assertEquals('paid', $updatedBooking->payment_status);
        $this->assertEquals('confirmed', $updatedBooking->status);
    }

    public function test_travel_booking_payment()
    {
        Sanctum::actingAs($this->user);

        $package = TravelPackage::create([
            'title' => 'Sundarbans Adventure',
            'destination' => 'Sundarbans',
            'price' => 1500.00,
            'duration_days' => 3,
            'vendor_id' => $this->manager->id,
        ]);

        $booking = TravelBooking::create([
            'user_id' => $this->user->id,
            'travel_package_id' => $package->id,
            'travel_date' => now()->addDays(5)->format('Y-m-d'),
            'guests' => 2,
            'total_price' => 3000.00,
            'status' => 'pending',
            'payment_status' => 'unpaid',
        ]);

        $response = $this->postJson("/api/travel-bookings/{$booking->id}/pay", [
            'payment_method' => 'wallet'
        ]);

        $response->assertStatus(200);
        $this->assertEquals(2000.00, $this->user->fresh()->balance);
        $this->assertEquals('paid', $booking->fresh()->payment_status);
        $this->assertEquals('confirmed', $booking->fresh()->status);
    }

    public function test_car_booking_payment()
    {
        Sanctum::actingAs($this->user);

        $car = Car::create([
            'name' => 'Toyota Noah',
            'brand' => 'Toyota',
            'model_year' => '2018',
            'type' => 'microbus',
            'transmission' => 'auto',
            'fuel_type' => 'octane',
            'price_per_day' => 2500.00,
            'capacity' => 7,
            'status' => 'available',
            'manager_id' => $this->manager->id,
        ]);

        $booking = CarBooking::create([
            'user_id' => $this->user->id,
            'car_id' => $car->id,
            'pickup_city' => 'Dhaka',
            'dropoff_city' => 'Dhaka',
            'pickup_date' => now()->addDays(1)->format('Y-m-d'),
            'return_date' => now()->addDays(2)->format('Y-m-d'),
            'pickup_location' => 'Airport',
            'return_location' => 'Airport',
            'total_price' => 2500.00,
            'status' => 'pending',
            'payment_status' => 'unpaid',
        ]);

        $response = $this->postJson("/api/car-bookings/{$booking->id}/pay", [
            'payment_method' => 'wallet'
        ]);

        $response->assertStatus(200);
        $this->assertEquals(2500.00, $this->user->fresh()->balance);
        $this->assertEquals('paid', $booking->fresh()->payment_status);
        $this->assertEquals('confirmed', $booking->fresh()->status);
    }

    public function test_room_booking_partial_payment_via_wallet()
    {
        Sanctum::actingAs($this->user);

        $hotel = Hotel::create([
            'name' => 'Ocean View Hotel',
            'city' => 'Cox\'s Bazar',
            'address' => 'Beach Road',
            'manager_id' => $this->manager->id,
        ]);

        $room = Room::create([
            'hotel_id' => $hotel->id,
            'room_number' => 'A-104-' . uniqid(),
            'room_type' => 'deluxe',
            'description' => 'Test Room Description',
            'price_per_night' => 1000.00,
            'status' => 'available',
            'capacity' => 2,
        ]);

        $booking = Booking::create([
            'user_id' => $this->user->id,
            'hotel_id' => $hotel->id,
            'room_id' => $room->id,
            'check_in_date' => now()->addDays(1)->format('Y-m-d'),
            'check_out_date' => now()->addDays(3)->format('Y-m-d'),
            'total_price' => 2000.00,
            'status' => 'pending',
            'payment_status' => 'unpaid',
        ]);

        // Pay TK 500 partially
        $response = $this->postJson("/api/bookings/{$booking->id}/pay", [
            'payment_method' => 'wallet',
            'amount' => 500.00
        ]);

        $response->assertStatus(200);

        // Assert user balance is deducted by 500
        $this->assertEquals(4500.00, $this->user->fresh()->balance);

        // Assert booking is confirmed but payment is partial
        $updatedBooking = $booking->fresh();
        $this->assertEquals('partial', $updatedBooking->payment_status);
        $this->assertEquals(500.00, $updatedBooking->paid_amount);
        $this->assertEquals('confirmed', $updatedBooking->status);

        // Assert room status changed to occupied
        $this->assertEquals('occupied', $room->fresh()->status);
    }

    public function test_room_booking_consecutive_partial_payments()
    {
        Sanctum::actingAs($this->user);

        $hotel = Hotel::create([
            'name' => 'Ocean View Hotel',
            'city' => 'Cox\'s Bazar',
            'address' => 'Beach Road',
            'manager_id' => $this->manager->id,
        ]);

        $room = Room::create([
            'hotel_id' => $hotel->id,
            'room_number' => 'A-105-' . uniqid(),
            'room_type' => 'deluxe',
            'description' => 'Test Room Description',
            'price_per_night' => 1000.00,
            'status' => 'available',
            'capacity' => 2,
        ]);

        $booking = Booking::create([
            'user_id' => $this->user->id,
            'hotel_id' => $hotel->id,
            'room_id' => $room->id,
            'check_in_date' => now()->addDays(1)->format('Y-m-d'),
            'check_out_date' => now()->addDays(3)->format('Y-m-d'),
            'total_price' => 2000.00,
            'status' => 'pending',
            'payment_status' => 'unpaid',
        ]);

        // 1st pay: TK 500
        $response = $this->postJson("/api/bookings/{$booking->id}/pay", [
            'payment_method' => 'wallet',
            'amount' => 500.00
        ]);
        $response->assertStatus(200);
        $this->assertEquals(4500.00, $this->user->fresh()->balance);
        $this->assertEquals('partial', $booking->fresh()->payment_status);

        // 2nd pay: TK 1500 (covers remaining)
        $response2 = $this->postJson("/api/bookings/{$booking->id}/pay", [
            'payment_method' => 'wallet',
            'amount' => 1500.00
        ]);
        $response2->assertStatus(200);
        $this->assertEquals(3000.00, $this->user->fresh()->balance);
        $this->assertEquals('paid', $booking->fresh()->payment_status);
        $this->assertEquals(2000.00, $booking->fresh()->paid_amount);
    }

    public function test_payment_exceeding_remaining_balance_fails()
    {
        Sanctum::actingAs($this->user);

        $hotel = Hotel::create([
            'name' => 'Ocean View Hotel',
            'city' => 'Cox\'s Bazar',
            'address' => 'Beach Road',
            'manager_id' => $this->manager->id,
        ]);

        $room = Room::create([
            'hotel_id' => $hotel->id,
            'room_number' => 'A-106-' . uniqid(),
            'room_type' => 'deluxe',
            'description' => 'Test Room Description',
            'price_per_night' => 1000.00,
            'status' => 'available',
            'capacity' => 2,
        ]);

        $booking = Booking::create([
            'user_id' => $this->user->id,
            'hotel_id' => $hotel->id,
            'room_id' => $room->id,
            'check_in_date' => now()->addDays(1)->format('Y-m-d'),
            'check_out_date' => now()->addDays(3)->format('Y-m-d'),
            'total_price' => 2000.00,
            'status' => 'pending',
            'payment_status' => 'unpaid',
        ]);

        // Attempt to pay TK 2500 (greater than remaining 2000)
        $response = $this->postJson("/api/bookings/{$booking->id}/pay", [
            'payment_method' => 'wallet',
            'amount' => 2500.00
        ]);

        $response->assertStatus(422);
        $response->assertJsonFragment(['message' => 'Payment amount cannot exceed the remaining balance of TK 2,000.00']);
        
        $this->assertEquals(5000.00, $this->user->fresh()->balance);
        $this->assertEquals('unpaid', $booking->fresh()->payment_status);
    }
}
