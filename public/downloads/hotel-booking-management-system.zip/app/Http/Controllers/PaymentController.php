<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\TravelBooking;
use App\Models\CarBooking;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class PaymentController extends Controller
{
    public function deposit(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:1',
            'payment_method' => 'required|string|in:card,bkash,nagad,rocket',
        ]);

        $user = Auth::user();
        $user->balance += $request->amount;
        $user->save();

        return response()->json([
            'message' => 'Deposit successful!',
            'balance' => $user->balance,
            'transaction_id' => 'DEP-' . strtoupper(Str::random(8))
        ]);
    }

    public function payRoomBooking(Request $request, Booking $booking)
    {
        $user = Auth::user();

        if ($booking->user_id !== $user->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $remaining = round($booking->total_price - $booking->paid_amount, 2);
        if ($remaining <= 0) {
            return response()->json(['message' => 'Booking is already paid'], 422);
        }

        $request->validate([
            'payment_method' => 'required|string|in:wallet,card,bkash,nagad,rocket',
            'amount' => 'nullable|numeric|min:1',
        ]);

        $amountToPay = $request->has('amount') ? floatval($request->amount) : $remaining;
        $amountToPay = round($amountToPay, 2);

        if ($amountToPay > $remaining) {
            return response()->json(['message' => 'Payment amount cannot exceed the remaining balance of TK ' . number_format($remaining, 2)], 422);
        }

        if ($request->payment_method === 'wallet') {
            if ($user->balance < $amountToPay) {
                return response()->json(['message' => 'Insufficient wallet balance'], 422);
            }
            $user->balance -= $amountToPay;
            $user->save();
        }

        // Update booking details
        $newPaidAmount = round($booking->paid_amount + $amountToPay, 2);
        $newPaymentStatus = ($newPaidAmount >= round($booking->total_price, 2)) ? 'paid' : 'partial';

        $booking->update([
            'paid_amount' => $newPaidAmount,
            'payment_status' => $newPaymentStatus,
            'status' => 'confirmed',
            'transaction_id' => 'TXN-' . strtoupper(Str::random(8))
        ]);

        // Occupy the room
        $booking->room->update(['status' => 'occupied']);

        return response()->json([
            'message' => $newPaymentStatus === 'paid' ? 'Payment successful and booking confirmed!' : 'Partial payment successful!',
            'booking' => $booking->load(['room', 'hotel']),
            'balance' => $user->balance
        ]);
    }

    public function payTravelBooking(Request $request, TravelBooking $travelBooking)
    {
        $user = Auth::user();

        if ($travelBooking->user_id !== $user->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $remaining = round($travelBooking->total_price - $travelBooking->paid_amount, 2);
        if ($remaining <= 0) {
            return response()->json(['message' => 'Booking is already paid'], 422);
        }

        $request->validate([
            'payment_method' => 'required|string|in:wallet,card,bkash,nagad,rocket',
            'amount' => 'nullable|numeric|min:1',
        ]);

        $amountToPay = $request->has('amount') ? floatval($request->amount) : $remaining;
        $amountToPay = round($amountToPay, 2);

        if ($amountToPay > $remaining) {
            return response()->json(['message' => 'Payment amount cannot exceed the remaining balance of TK ' . number_format($remaining, 2)], 422);
        }

        if ($request->payment_method === 'wallet') {
            if ($user->balance < $amountToPay) {
                return response()->json(['message' => 'Insufficient wallet balance'], 422);
            }
            $user->balance -= $amountToPay;
            $user->save();
        }

        // Update travel booking details
        $newPaidAmount = round($travelBooking->paid_amount + $amountToPay, 2);
        $newPaymentStatus = ($newPaidAmount >= round($travelBooking->total_price, 2)) ? 'paid' : 'partial';

        $travelBooking->update([
            'paid_amount' => $newPaidAmount,
            'payment_status' => $newPaymentStatus,
            'status' => 'confirmed',
            'transaction_id' => 'TXN-TR-' . strtoupper(Str::random(8))
        ]);

        return response()->json([
            'message' => $newPaymentStatus === 'paid' ? 'Payment successful and booking confirmed!' : 'Partial payment successful!',
            'booking' => $travelBooking->load('package'),
            'balance' => $user->balance
        ]);
    }

    public function payCarBooking(Request $request, CarBooking $carBooking)
    {
        $user = Auth::user();

        if ($carBooking->user_id !== $user->id) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $remaining = round($carBooking->total_price - $carBooking->paid_amount, 2);
        if ($remaining <= 0) {
            return response()->json(['message' => 'Booking is already paid'], 422);
        }

        $request->validate([
            'payment_method' => 'required|string|in:wallet,card,bkash,nagad,rocket',
            'amount' => 'nullable|numeric|min:1',
        ]);

        $amountToPay = $request->has('amount') ? floatval($request->amount) : $remaining;
        $amountToPay = round($amountToPay, 2);

        if ($amountToPay > $remaining) {
            return response()->json(['message' => 'Payment amount cannot exceed the remaining balance of TK ' . number_format($remaining, 2)], 422);
        }

        if ($request->payment_method === 'wallet') {
            if ($user->balance < $amountToPay) {
                return response()->json(['message' => 'Insufficient wallet balance'], 422);
            }
            $user->balance -= $amountToPay;
            $user->save();
        }

        // Update car booking details
        $newPaidAmount = round($carBooking->paid_amount + $amountToPay, 2);
        $newPaymentStatus = ($newPaidAmount >= round($carBooking->total_price, 2)) ? 'paid' : 'partial';

        $carBooking->update([
            'paid_amount' => $newPaidAmount,
            'payment_status' => $newPaymentStatus,
            'status' => 'confirmed',
            'transaction_id' => 'TXN-CR-' . strtoupper(Str::random(8))
        ]);

        return response()->json([
            'message' => $newPaymentStatus === 'paid' ? 'Payment successful and booking confirmed!' : 'Partial payment successful!',
            'booking' => $carBooking->load('car'),
            'balance' => $user->balance
        ]);
    }
}
