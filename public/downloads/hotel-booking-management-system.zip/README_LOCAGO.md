# Sistem Manajemen Hotel - Hotel Booking Management System

```
========================================================================
📦 Sistem Manajemen Hotel - Hotel Booking Management System
Kategori     : Layanan & Jasa
Tech Stack   : Laravel • PHP • MySQL • Bootstrap
Database     : MySQL (.sql) (File: DB/hotelbooking.sql)
Sumber Asli  : https://github.com/muhammadrakib2299/Hotel-Booking-Management-System (GitHub Open Source)
Stars GitHub : ⭐ 0 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/hotel-booking-management-system`
     * Untuk Laragon: `C:/laragon/www/hotel-booking-management-system`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database kosong `hotel_booking` dulu di phpMyAdmin (file SQL ini
     TIDAK membuat database sendiri — tidak ada perintah CREATE DATABASE di
     dalamnya; nama database `hotel_booking` sesuai README repo asli).
     Lalu klik tab 'Import', pilih file SQL yang disertakan pada:
     `DB/hotelbooking.sql`, pastikan database `hotel_booking` yang dipilih
     sebagai tujuan import.
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = hotel_booking   (sesuai README repo asli)

4. JALANKAN APLIKASI:
   - Cara yang disarankan README repo asli (Laravel): dari folder proyek,
     jalankan `composer install`, buat file `.env` baru (repo ini TIDAK
     menyertakan `.env.example`), isi DB_CONNECTION=mysql,
     DB_HOST=127.0.0.1, DB_PORT=3306, DB_DATABASE=hotel_booking,
     DB_USERNAME=root, DB_PASSWORD= (kosong untuk XAMPP default), lalu
     `php artisan key:generate`, `npm install && npm run build`,
     `php artisan serve`, dan buka http://127.0.0.1:8000
   - Alternatif XAMPP/Laragon: arahkan document root web server ke folder
     `public` di dalam proyek, lalu buka
     http://localhost/hotel-booking-management-system (akses langsung ke
     folder proyek tanpa `public` TIDAK akan jalan karena ini aplikasi
     Laravel).

5. AKUN LOGIN DEMO (terverifikasi terhadap database .sql bawaan):
   - Admin: admin@hotel.com / password123  (tabel demo di README repo asli;
     hash bcrypt di DB/hotelbooking.sql terverifikasi cocok)
   - Manager: manager@hotel.com / password123  (sama, terverifikasi)
   - Catatan: README repo asli juga mendokumentasikan Customer
     john@example.com / password123 — akun itu TIDAK ADA di file .sql
     bawaan (hanya dibuat oleh seeder, lihat langkah 6); jangan login
     dengan akun itu setelah import .sql.

6. INSTALASI BARU VIA SEEDER (ALTERNATIF — ganti langkah 2, jangan keduanya):
   - Sebagai pengganti import .sql, Anda bisa membangun database dari nol:
     php artisan migrate --seed
     (atau `php artisan migrate:fresh --seed` untuk reset & isi ulang data demo)
   - Perintah ini membuat ulang semua tabel + akun demo dari README
     (admin@hotel.com, manager@hotel.com, dan john@example.com — ketiganya
     dengan password password123) + data contoh.
   - JANGAN jalankan ini setelah import .sql — migrate:fresh MENGHAPUS
     semua data hasil import.
========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
