@extends('layouts.frontend')

@section('content')
<div class="hero-bg py-5" style="height: 250px; display: flex; align-items: center; background-image: linear-gradient(rgba(30, 58, 95, 0.8), rgba(30, 58, 95, 0.9)), url('https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=1600'); margin-bottom: 50px;">
    <div class="container text-white">
        <h1 class="display-5 fw-bold mb-0">My Concierge</h1>
        <p class="lead opacity-75">Review your journey, tour packages, and car rentals.</p>
    </div>
</div>

<div class="container pb-5">
    <div class="row g-4 mb-5">
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white h-100">
                <div class="card-body d-flex align-items-center">
                    <div class="bg-primary bg-opacity-10 rounded-3 p-3 me-3">
                        <i class="fas fa-history text-primary fa-lg"></i>
                    </div>
                    <div>
                        <h6 class="text-muted small fw-bold text-uppercase mb-1">Total Stays</h6>
                        <h4 class="fw-bold mb-0" id="totalStays">...</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white h-100">
                <div class="card-body d-flex align-items-center">
                    <div class="bg-success bg-opacity-10 rounded-3 p-3 me-3">
                        <i class="fas fa-check-circle text-success fa-lg"></i>
                    </div>
                    <div>
                        <h6 class="text-muted small fw-bold text-uppercase mb-1">Member Status</h6>
                        <h4 class="fw-bold mb-0" id="memberTier">...</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white h-100">
                <div class="card-body d-flex align-items-center">
                    <div class="bg-warning bg-opacity-10 rounded-3 p-3 me-3">
                        <i class="fas fa-star text-warning fa-lg"></i>
                    </div>
                    <div>
                        <h6 class="text-muted small fw-bold text-uppercase mb-1">Loyalty Points</h6>
                        <h4 class="fw-bold mb-0" id="loyaltyPoints">...</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white h-100">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center">
                        <div class="bg-info bg-opacity-10 rounded-3 p-3 me-3">
                            <i class="fas fa-wallet text-info fa-lg"></i>
                        </div>
                        <div>
                            <h6 class="text-muted small fw-bold text-uppercase mb-1">Wallet Balance</h6>
                            <h4 class="fw-bold mb-0" id="walletBalance">...</h4>
                        </div>
                    </div>
                    <button class="btn btn-sm btn-info text-white rounded-pill px-3 py-2 ms-2 shadow-sm" onclick="openDepositModal()"><i class="fas fa-plus"></i></button>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
        <div class="card-header bg-white py-4 px-4 border-0">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="fw-bold mb-0"><i class="fas fa-list-ul me-2 text-primary"></i>My Reservations</h4>
                <div class="d-flex gap-2">
                    <a href="/#rooms" class="btn btn-primary px-4 rounded-pill fw-bold btn-sm shadow-sm"><i class="fas fa-plus me-2"></i>New Stay</a>
                </div>
            </div>
            
            <ul class="nav nav-pills custom-pills mb-0" id="bookingTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active rounded-pill px-4 fw-bold" id="rooms-tab" data-bs-toggle="pill" data-bs-target="#rooms-pane" type="button" role="tab"><i class="fas fa-bed me-2"></i>Room Stays</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link rounded-pill px-4 fw-bold" id="travel-tab" data-bs-toggle="pill" data-bs-target="#travel-pane" type="button" role="tab"><i class="fas fa-map-marked-alt me-2"></i>Travel Packages</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link rounded-pill px-4 fw-bold" id="cars-tab" data-bs-toggle="pill" data-bs-target="#cars-pane" type="button" role="tab"><i class="fas fa-car me-2"></i>Car Rentals</button>
                </li>
            </ul>
        </div>
        <div class="card-body p-0">
            <div class="tab-content" id="bookingTabsContent">
                <!-- Room Stays Pane -->
                <div class="tab-pane fade show active" id="rooms-pane" role="tabpanel">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light text-uppercase small fw-bold text-muted" style="letter-spacing: 1px;">
                                <tr>
                                    <th class="ps-4 py-3">Reference</th>
                                    <th class="py-3">Room Details</th>
                                    <th class="py-3">Period</th>
                                    <th class="py-3">Total Amount</th>
                                    <th class="py-3">Status</th>
                                    <th class="text-end pe-4 py-3">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="bookingsTable">
                                <tr><td colspan="6" class="text-center py-5"><div class="spinner-border text-primary" role="status"></div></td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Travel Packages Pane -->
                <div class="tab-pane fade" id="travel-pane" role="tabpanel">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light text-uppercase small fw-bold text-muted" style="letter-spacing: 1px;">
                                <tr>
                                    <th class="ps-4 py-3">Reference</th>
                                    <th class="py-3">Package Details</th>
                                    <th class="py-3">Travel Date</th>
                                    <th class="py-3">Total Amount</th>
                                    <th class="py-3">Status</th>
                                    <th class="text-end pe-4 py-3">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="travelTable">
                                <tr><td colspan="6" class="text-center py-5"><div class="spinner-border text-primary" role="status"></div></td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Car Rentals Pane -->
                <div class="tab-pane fade" id="cars-pane" role="tabpanel">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light text-uppercase small fw-bold text-muted" style="letter-spacing: 1px;">
                                <tr>
                                    <th class="ps-4 py-3">Reference</th>
                                    <th class="py-3">Car Details</th>
                                    <th class="py-3">Rental Period</th>
                                    <th class="py-3">Total Amount</th>
                                    <th class="py-3">Status</th>
                                    <th class="text-end pe-4 py-3">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="carsTable">
                                <tr><td colspan="6" class="text-center py-5"><div class="spinner-border text-primary" role="status"></div></td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Booking Details Modal -->
<div class="modal fade" id="viewBookingModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow-lg overflow-hidden">
            <div class="modal-header bg-primary text-white py-4 px-4 border-0">
                <h5 class="modal-title fw-bold">Reservation Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4" id="bookingDetailsContent">
                <!-- Loaded via JS -->
            </div>
        </div>
    </div>
</div>

<!-- Deposit Modal -->
<div class="modal fade" id="depositModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow-lg overflow-hidden">
            <div class="modal-header bg-info text-white border-0 py-4 px-4">
                <h5 class="modal-title fw-bold"><i class="fas fa-wallet me-2"></i>Deposit Money</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4 p-md-5">
                <form id="depositForm">
                    <div class="mb-4">
                        <label class="form-label small fw-bold text-muted text-uppercase">Amount (TK)</label>
                        <input type="number" id="depositAmount" class="form-control bg-light border-0 py-3 rounded-3" placeholder="Enter amount to deposit" min="100" value="1000" required>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label small fw-bold text-muted text-uppercase">Payment Method</label>
                        <div class="row g-2">
                            <div class="col-6">
                                <input type="radio" class="btn-check" name="depositMethod" id="dep_card" value="card" checked>
                                <label class="btn btn-outline-info w-100 py-3 rounded-3" for="dep_card">
                                    <i class="fas fa-credit-card d-block mb-1"></i> Card
                                </label>
                            </div>
                            <div class="col-6">
                                <input type="radio" class="btn-check" name="depositMethod" id="dep_bkash" value="bkash">
                                <label class="btn btn-outline-info w-100 py-3 rounded-3" for="dep_bkash">
                                    <i class="fas fa-mobile-alt d-block mb-1"></i> bKash
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Payment Fields (Card) -->
                    <div id="dep_card_fields" class="payment-fields-dep">
                        <div class="mb-3">
                            <label class="form-label small">Card Number</label>
                            <input type="text" class="form-control bg-light border-0 py-2 rounded-3" placeholder="4242 4242 4242 4242">
                        </div>
                        <div class="row g-2">
                            <div class="col-6">
                                <label class="form-label small">Expiry Date</label>
                                <input type="text" class="form-control bg-light border-0 py-2 rounded-3" placeholder="MM/YY">
                            </div>
                            <div class="col-6">
                                <label class="form-label small">CVV</label>
                                <input type="password" class="form-control bg-light border-0 py-2 rounded-3" placeholder="***">
                            </div>
                        </div>
                    </div>

                    <!-- Payment Fields (bKash) -->
                    <div id="dep_bkash_fields" class="payment-fields-dep d-none">
                        <div class="mb-3">
                            <label class="form-label small">bKash Account Number</label>
                            <input type="text" class="form-control bg-light border-0 py-2 rounded-3" placeholder="01XXXXXXXXX">
                        </div>
                        <div class="mb-3">
                            <label class="form-label small">PIN/OTP</label>
                            <input type="password" class="form-control bg-light border-0 py-2 rounded-3" placeholder="****">
                        </div>
                    </div>

                    <div class="pt-3">
                        <button type="submit" class="btn btn-info text-white w-100 py-3 rounded-pill fw-bold shadow-lg">
                            <i class="fas fa-check-circle me-2"></i>DEPOSIT NOW
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Payment Checkout Modal -->
<div class="modal fade" id="checkoutModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow-lg overflow-hidden">
            <div class="modal-header bg-navy-gradient text-white border-0 py-4 px-4">
                <h5 class="modal-title fw-bold text-white"><i class="fas fa-shield-alt me-2 text-warning"></i>Secure Checkout</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4 p-md-5">
                <div class="text-center mb-4">
                    <p class="text-muted small mb-1 text-uppercase fw-bold" style="letter-spacing: 1px;">Booking Reference</p>
                    <div class="badge bg-light text-muted mb-3 border" id="checkoutBookingRef" style="font-size: 0.9rem;">#BK-X</div>
                    <div class="d-flex justify-content-around bg-light p-3 rounded-3 border mb-3">
                        <div>
                            <small class="text-muted d-block text-uppercase" style="font-size: 0.65rem;">Total Price</small>
                            <span class="fw-bold text-dark" id="checkoutTotalAmount" style="font-size: 0.95rem;">TK 0.00</span>
                        </div>
                        <div class="border-end"></div>
                        <div>
                            <small class="text-muted d-block text-uppercase" style="font-size: 0.65rem;">Already Paid</small>
                            <span class="fw-bold text-success" id="checkoutAlreadyPaid" style="font-size: 0.95rem;">TK 0.00</span>
                        </div>
                        <div class="border-end"></div>
                        <div>
                            <small class="text-muted d-block text-uppercase" style="font-size: 0.65rem;">Remaining</small>
                            <span class="fw-bold text-danger" id="checkoutRemainingAmount" style="font-size: 0.95rem;">TK 0.00</span>
                        </div>
                    </div>
                </div>

                <form id="checkoutForm">
                    <input type="hidden" id="checkoutBookingId">
                    <input type="hidden" id="checkoutBookingType"> <!-- 'room', 'travel', 'car' -->
                    <input type="hidden" id="checkoutBookingAmount"> <!-- hidden remaining amount -->

                    <!-- Payment Custom Option -->
                    <div class="mb-4 bg-light p-3 rounded-3 border text-start">
                        <label class="form-label small fw-bold text-muted text-uppercase mb-2">Payment Options</label>
                        <div class="d-flex gap-4">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="paymentOption" id="pay_option_full" value="full" checked>
                                <label class="form-check-label small fw-bold text-dark" for="pay_option_full">
                                    Pay Full Remaining
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="paymentOption" id="pay_option_custom" value="custom">
                                <label class="form-check-label small fw-bold text-dark" for="pay_option_custom">
                                    Pay Custom Amount
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Custom Amount Input Field (Hidden initially) -->
                    <div id="custom_amount_container" class="mb-4 d-none text-start">
                        <label class="form-label small fw-bold text-muted text-uppercase">Enter Custom Amount (TK)</label>
                        <input type="number" class="form-control bg-light border-0 py-2 rounded-3" id="customAmountInput" min="1" step="any" placeholder="Enter amount to pay">
                        <div class="form-text text-muted" id="customAmountHelp">Maximum you can pay is TK 0.00</div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-bold text-muted text-uppercase">Payment Method</label>
                        <div class="row g-2">
                            <div class="col-4">
                                <input type="radio" class="btn-check" name="checkoutMethod" id="pay_wallet" value="wallet" checked>
                                <label class="btn btn-outline-navy w-100 py-3 rounded-3" for="pay_wallet">
                                    <i class="fas fa-wallet d-block mb-1"></i> Wallet
                                    <small class="d-block text-muted" style="font-size: 0.65rem;" id="checkoutWalletBalance">TK 0</small>
                                </label>
                            </div>
                            <div class="col-4">
                                <input type="radio" class="btn-check" name="checkoutMethod" id="pay_card" value="card">
                                <label class="btn btn-outline-navy w-100 py-3 rounded-3" for="pay_card">
                                    <i class="fas fa-credit-card d-block mb-1"></i> Card
                                </label>
                            </div>
                            <div class="col-4">
                                <input type="radio" class="btn-check" name="checkoutMethod" id="pay_bkash" value="bkash">
                                <label class="btn btn-outline-navy w-100 py-3 rounded-3" for="pay_bkash">
                                    <i class="fas fa-mobile-alt d-block mb-1"></i> bKash
                                </label>
                            </div>
                        </div>
                    </div>

                    <!-- Payment Fields (Wallet Information/Notice) -->
                    <div id="pay_wallet_fields" class="payment-fields-checkout alert alert-info py-3 mb-4">
                        <i class="fas fa-info-circle me-2"></i> Amount will be deducted from your virtual wallet balance.
                    </div>

                    <!-- Payment Fields (Card) -->
                    <div id="pay_card_fields" class="payment-fields-checkout d-none mb-4">
                        <div class="mb-3">
                            <label class="form-label small">Card Number</label>
                            <input type="text" class="form-control bg-light border-0 py-2 rounded-3" placeholder="4242 4242 4242 4242">
                        </div>
                        <div class="row g-2">
                            <div class="col-6">
                                <label class="form-label small">Expiry Date</label>
                                <input type="text" class="form-control bg-light border-0 py-2 rounded-3" placeholder="MM/YY">
                            </div>
                            <div class="col-6">
                                <label class="form-label small">CVV</label>
                                <input type="password" class="form-control bg-light border-0 py-2 rounded-3" placeholder="***">
                            </div>
                        </div>
                    </div>

                    <!-- Payment Fields (bKash) -->
                    <div id="pay_bkash_fields" class="payment-fields-checkout d-none mb-4">
                        <div class="mb-3">
                            <label class="form-label small">bKash Account Number</label>
                            <input type="text" class="form-control bg-light border-0 py-2 rounded-3" placeholder="01XXXXXXXXX">
                        </div>
                        <div class="mb-3">
                            <label class="form-label small">PIN/OTP</label>
                            <input type="password" class="form-control bg-light border-0 py-2 rounded-3" placeholder="****">
                        </div>
                    </div>

                    <div class="pt-2">
                        <button type="submit" id="checkoutSubmitBtn" class="btn btn-navy w-100 py-3 rounded-pill fw-bold shadow-lg">
                            <i class="fas fa-lock me-2 text-warning"></i>PAY SECURELY
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

    <style>
        .custom-pills .nav-link {
            color: #666;
            background: #f8f9fa;
            margin-right: 10px;
            transition: all 0.3s ease;
            border: 1px solid #eee;
        }
        .custom-pills .nav-link.active {
            background: var(--primary-navy, #1e3a5f) !important;
            color: #fff !important;
            box-shadow: 0 4px 15px rgba(30, 58, 95, 0.2);
            border-color: var(--primary-navy, #1e3a5f);
        }
        .custom-pills .nav-link:hover:not(.active) {
            background: #e9ecef;
        }
        .btn-outline-navy {
            border: 2px solid var(--primary-navy, #1e3a5f);
            color: var(--primary-navy, #1e3a5f);
            background: transparent;
            transition: all 0.3s ease;
        }
        .btn-outline-navy:hover, .btn-check:checked + .btn-outline-navy {
            background: var(--primary-navy, #1e3a5f) !important;
            color: #fff !important;
            box-shadow: 0 4px 10px rgba(30, 58, 95, 0.15);
        }
        .btn-navy {
            background: var(--primary-navy, #1e3a5f);
            color: #fff;
            border: none;
            transition: all 0.3s ease;
        }
        .btn-navy:hover {
            background: #162a45;
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(30, 58, 95, 0.2);
        }
        .bg-navy-gradient {
            background: linear-gradient(135deg, #1e3a5f, #0d1e33);
        }
    </style>

@section('scripts')
<script>
    const authToken = localStorage.getItem('auth_token');
    let viewModal;
    let depositModalObj;
    let checkoutModalObj;
    let currentBalance = 0;
    
    document.addEventListener('DOMContentLoaded', () => {
        viewModal = new bootstrap.Modal(document.getElementById('viewBookingModal'));
        depositModalObj = new bootstrap.Modal(document.getElementById('depositModal'));
        checkoutModalObj = new bootstrap.Modal(document.getElementById('checkoutModal'));
        
        loadBookings();
        loadTravelBookings();
        loadCarBookings();
        loadMemberStatus();

        // Handle tab query parameter
        const urlParams = new URLSearchParams(window.location.search);
        const tab = urlParams.get('tab');
        if (tab === 'travel') {
            const travelTab = document.getElementById('travel-tab');
            if (travelTab) travelTab.click();
        } else if (tab === 'cars') {
            const carsTab = document.getElementById('cars-tab');
            if (carsTab) carsTab.click();
        }

        // Setup radio listeners for deposit modal
        document.querySelectorAll('input[name="depositMethod"]').forEach(el => {
            el.addEventListener('change', (e) => {
                const method = e.target.value;
                document.querySelectorAll('.payment-fields-dep').forEach(f => f.classList.add('d-none'));
                const targetFields = document.getElementById(`dep_${method}_fields`);
                if (targetFields) {
                    targetFields.classList.remove('d-none');
                }
            });
        });

        // Setup radio listeners for checkout modal
        document.querySelectorAll('input[name="checkoutMethod"]').forEach(el => {
            el.addEventListener('change', (e) => {
                const method = e.target.value;
                document.querySelectorAll('.payment-fields-checkout').forEach(f => f.classList.add('d-none'));
                const targetFields = document.getElementById(`pay_${method}_fields`);
                if (targetFields) {
                    targetFields.classList.remove('d-none');
                }
            });
        });

        // Setup radio listeners for paymentOption
        document.querySelectorAll('input[name="paymentOption"]').forEach(el => {
            el.addEventListener('change', () => {
                togglePaymentOption();
            });
        });

        // Setup input listener for customAmountInput
        document.getElementById('customAmountInput').addEventListener('input', (e) => {
            const val = e.target.value;
            const remaining = parseFloat(document.getElementById('checkoutBookingAmount').value);
            const helpText = document.getElementById('customAmountHelp');
            const submitBtn = document.getElementById('checkoutSubmitBtn');
            const amountToPay = parseFloat(val || 0);

            if (amountToPay > remaining) {
                e.target.classList.add('is-invalid');
                if (helpText) {
                    helpText.classList.remove('text-muted');
                    helpText.classList.add('text-danger');
                    helpText.textContent = `Error: Amount cannot exceed remaining balance of TK ${remaining.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}.`;
                }
                if (submitBtn) {
                    submitBtn.disabled = true;
                }
            } else if (amountToPay <= 0 && val !== '') {
                e.target.classList.add('is-invalid');
                if (helpText) {
                    helpText.classList.remove('text-muted');
                    helpText.classList.add('text-danger');
                    helpText.textContent = `Error: Please enter a positive amount.`;
                }
                if (submitBtn) {
                    submitBtn.disabled = true;
                }
            } else {
                e.target.classList.remove('is-invalid');
                if (helpText) {
                    helpText.classList.remove('text-danger');
                    helpText.classList.add('text-muted');
                    helpText.textContent = `Maximum you can pay is TK ${remaining.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
                }
                if (submitBtn) {
                    submitBtn.disabled = false;
                }
            }

            updateWalletState(amountToPay);
        });

        // Setup deposit form submission
        document.getElementById('depositForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const amount = parseFloat(document.getElementById('depositAmount').value);
            const method = document.querySelector('input[name="depositMethod"]:checked').value;
            
            if (amount <= 0 || isNaN(amount)) {
                Swal.fire({ icon: 'error', title: 'Invalid Amount', text: 'Please enter a valid amount to deposit.' });
                return;
            }
            
            Swal.fire({
                title: 'Processing Deposit...',
                html: 'Connecting to secure mock gateway...',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
            
            try {
                const response = await fetch('/api/wallet/deposit', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({ amount, payment_method: method })
                });
                
                const data = await response.json();
                if (response.ok) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Deposit Successful!',
                        html: `Successfully deposited <b>TK ${amount.toLocaleString()}</b>.<br>Transaction ID: <span class="text-uppercase fw-bold">${data.transaction_id}</span>`,
                        confirmButtonColor: '#1E3A5F'
                    }).then(() => {
                        depositModalObj.hide();
                        loadMemberStatus();
                    });
                } else {
                    Swal.fire({ icon: 'error', title: 'Deposit Failed', text: data.message || 'Error processing deposit.' });
                }
            } catch (error) {
                console.error(error);
                Swal.fire({ icon: 'error', title: 'Error', text: 'Something went wrong. Please try again.' });
            }
        });

        // Setup checkout form submission
        document.getElementById('checkoutForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const id = document.getElementById('checkoutBookingId').value;
            const type = document.getElementById('checkoutBookingType').value;
            const method = document.querySelector('input[name="checkoutMethod"]:checked').value;
            const payOption = document.querySelector('input[name="paymentOption"]:checked').value;
            const remaining = parseFloat(document.getElementById('checkoutBookingAmount').value);
            
            let amount = remaining;
            if (payOption === 'custom') {
                amount = parseFloat(document.getElementById('customAmountInput').value);
                if (isNaN(amount) || amount <= 0) {
                    Swal.fire({ icon: 'error', title: 'Invalid Amount', text: 'Please enter a valid custom amount.' });
                    return;
                }
                if (amount > remaining) {
                    Swal.fire({ icon: 'error', title: 'Invalid Amount', text: `Amount cannot exceed remaining balance of TK ${remaining.toFixed(2)}.` });
                    return;
                }
            }
            
            let endpoint = '';
            if (type === 'room') {
                endpoint = `/api/bookings/${id}/pay`;
            } else if (type === 'travel') {
                endpoint = `/api/travel-bookings/${id}/pay`;
            } else if (type === 'car') {
                endpoint = `/api/car-bookings/${id}/pay`;
            }
            
            Swal.fire({
                title: 'Processing Payment...',
                html: 'Confirming your secure reservation...',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
            
            try {
                const response = await fetch(endpoint, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${authToken}`,
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({ payment_method: method, amount: amount })
                });
                
                const data = await response.json();
                if (response.ok) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Payment Successful!',
                        html: `Successfully paid <b>TK ${amount.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</b>.<br>Transaction ID: <span class="text-uppercase fw-bold">${data.booking?.transaction_id || data.transaction_id || ''}</span>`,
                        confirmButtonColor: '#1E3A5F'
                    }).then(() => {
                        checkoutModalObj.hide();
                        loadMemberStatus();
                        loadBookings();
                        loadTravelBookings();
                        loadCarBookings();
                    });
                } else {
                    Swal.fire({ icon: 'error', title: 'Payment Failed', text: data.message || 'Error processing payment.' });
                }
            } catch (error) {
                console.error(error);
                Swal.fire({ icon: 'error', title: 'Error', text: 'Something went wrong. Please try again.' });
            }
        });
    });
    
    function formatDate(dateString) {
        return new Date(dateString).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
    }

    async function loadMemberStatus() {
        if (!authToken) return;
        try {
            const res = await fetch('/api/premium/status', {
                headers: { 'Authorization': `Bearer ${authToken}`, 'Accept': 'application/json' }
            });
            const data = await res.json();
            document.getElementById('memberTier').textContent = data.premium ? (data.subscription?.tier?.toUpperCase() || 'PREMIUM') : 'REGULAR';
            document.getElementById('totalStays').textContent = data.completed_bookings || 0;
            document.getElementById('loyaltyPoints').textContent = (data.completed_bookings || 0) * 100;
            
            currentBalance = parseFloat(data.balance || 0);
            document.getElementById('walletBalance').textContent = `TK ${currentBalance.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
            document.getElementById('checkoutWalletBalance').textContent = `TK ${currentBalance.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
        } catch (e) { console.error(e); }
    }

    function openDepositModal() {
        document.getElementById('depositAmount').value = 1000;
        document.getElementById('dep_card').checked = true;
        document.querySelectorAll('.payment-fields-dep').forEach(f => f.classList.add('d-none'));
        document.getElementById('dep_card_fields').classList.remove('d-none');
        depositModalObj.show();
    }

    function openCheckoutModal(id, type, total, paid, reference) {
        total = parseFloat(total || 0);
        paid = parseFloat(paid || 0);
        const remaining = total - paid;

        document.getElementById('checkoutBookingId').value = id;
        document.getElementById('checkoutBookingType').value = type;
        document.getElementById('checkoutBookingAmount').value = remaining;
        
        document.getElementById('checkoutTotalAmount').textContent = `TK ${total.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
        document.getElementById('checkoutAlreadyPaid').textContent = `TK ${paid.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
        document.getElementById('checkoutRemainingAmount').textContent = `TK ${remaining.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
        document.getElementById('checkoutBookingRef').textContent = `Booking Reference: ${reference}`;
        
        // Reset payment option
        document.getElementById('pay_option_full').checked = true;
        document.getElementById('custom_amount_container').classList.add('d-none');
        const customInput = document.getElementById('customAmountInput');
        customInput.value = '';
        customInput.max = remaining;
        document.getElementById('customAmountHelp').textContent = `Maximum you can pay is TK ${remaining.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;

        document.getElementById('pay_wallet').checked = true;
        document.querySelectorAll('.payment-fields-checkout').forEach(f => f.classList.add('d-none'));
        document.getElementById('pay_wallet_fields').classList.remove('d-none');
        
        updateWalletState(remaining);
        
        checkoutModalObj.show();
    }

    function togglePaymentOption() {
        const option = document.querySelector('input[name="paymentOption"]:checked').value;
        const remaining = parseFloat(document.getElementById('checkoutBookingAmount').value);
        const container = document.getElementById('custom_amount_container');
        const customInput = document.getElementById('customAmountInput');
        const helpText = document.getElementById('customAmountHelp');
        const submitBtn = document.getElementById('checkoutSubmitBtn');
        
        if (option === 'custom') {
            container.classList.remove('d-none');
            customInput.required = true;
            customInput.dispatchEvent(new Event('input'));
        } else {
            container.classList.add('d-none');
            customInput.required = false;
            customInput.value = '';
            customInput.classList.remove('is-invalid');
            if (helpText) {
                helpText.classList.remove('text-danger');
                helpText.classList.add('text-muted');
                helpText.textContent = `Maximum you can pay is TK ${remaining.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
            }
            if (submitBtn) {
                submitBtn.disabled = false;
            }
            updateWalletState(remaining);
        }
    }

    function updateWalletState(amountToPay) {
        const walletLabel = document.querySelector('label[for="pay_wallet"]');
        if (currentBalance < amountToPay || amountToPay <= 0) {
            if (document.getElementById('pay_wallet').checked) {
                document.getElementById('pay_card').checked = true;
                document.querySelectorAll('.payment-fields-checkout').forEach(f => f.classList.add('d-none'));
                document.getElementById('pay_card_fields').classList.remove('d-none');
            }
            walletLabel.style.opacity = '0.5';
            walletLabel.style.pointerEvents = 'none';
            document.getElementById('pay_wallet').disabled = true;
        } else {
            walletLabel.style.opacity = '1';
            walletLabel.style.pointerEvents = 'auto';
            document.getElementById('pay_wallet').disabled = false;
        }
    }
    
    async function loadBookings() {
        try {
            const response = await fetch('/api/bookings/my', {
                headers: { 'Authorization': `Bearer ${authToken}`, 'Accept': 'application/json' }
            });
            const bookings = await response.json();
            const tbody = document.getElementById('bookingsTable');
            
            if (!bookings || bookings.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="text-center py-5 text-muted"><i class="fas fa-calendar-times fa-2x mb-3 opacity-25"></i><br>No reservations found.</td></tr>';
                return;
            }
            
            tbody.innerHTML = bookings.map(booking => {
                const statusClass = booking.status === 'confirmed' ? 'success' : (booking.status === 'pending' ? 'warning' : 'danger');
                const payStatus = booking.payment_status || 'unpaid';
                let payStatusClass = 'secondary';
                if (payStatus === 'paid') payStatusClass = 'success';
                else if (payStatus === 'partial') payStatusClass = 'warning';
                
                // Cancelable check (within 15 minutes and pending)
                const createdAt = new Date(booking.created_at);
                const now = new Date();
                const diffMs = now - createdAt;
                const diffMins = Math.floor(diffMs / 60000);
                const isCancelable = booking.status === 'pending' && diffMins < 15;

                return `
                <tr>
                    <td class="ps-4 fw-bold text-primary">#BK-${booking.id}</td>
                    <td>
                        <div class="d-flex align-items-center">
                            <div class="bg-light rounded p-2 me-3"><i class="fas fa-door-open text-primary"></i></div>
                            <div>
                                <div class="fw-bold">Room ${booking.room?.room_number || 'N/A'}</div>
                                <div class="small text-muted">${booking.room?.room_type || 'Luxury Suite'}</div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="small fw-bold text-dark"><i class="far fa-calendar-alt me-1 text-primary"></i> ${formatDate(booking.check_in_date)}</div>
                        <div class="small text-muted ps-3">to ${formatDate(booking.check_out_date)}</div>
                    </td>
                    <td>
                        <span class="fw-bold text-dark">TK ${parseFloat(booking.total_price).toLocaleString()}</span>
                        <div class="small text-muted" style="font-size: 0.72rem;">Paid: TK ${parseFloat(booking.paid_amount || 0).toLocaleString()}</div>
                    </td>
                    <td>
                        <div class="d-flex flex-column gap-1">
                            <span class="badge bg-${statusClass} bg-opacity-10 text-${statusClass} border border-${statusClass} border-opacity-25 px-3 py-1.5 rounded-pill text-center">${booking.status.toUpperCase()}</span>
                            <span class="badge bg-${payStatusClass} bg-opacity-10 text-${payStatusClass} border border-${payStatusClass} border-opacity-25 px-3 py-1.5 rounded-pill text-center">${payStatus.toUpperCase()}</span>
                        </div>
                    </td>
                    <td class="text-end pe-4">
                        <div class="d-flex justify-content-end gap-2 align-items-center">
                            ${payStatus !== 'paid' ? `
                                <button onclick="openCheckoutModal(${booking.id}, 'room', ${booking.total_price}, ${booking.paid_amount || 0}, '#BK-${booking.id}')" class="btn btn-primary btn-sm rounded-pill px-3 shadow-sm"><i class="fas fa-credit-card me-1"></i>Pay Now</button>
                            ` : ''}
                            ${isCancelable ? `<button onclick="cancelBooking(${booking.id})" class="btn btn-danger btn-sm rounded-pill px-3">Cancel</button>` : ''}
                            <button onclick="viewBooking(${booking.id})" class="btn btn-outline-primary btn-sm rounded-pill px-3">Details</button>
                        </div>
                    </td>
                </tr>`;
            }).join('');
        } catch (error) { 
            console.error('Error:', error);
            document.getElementById('bookingsTable').innerHTML = '<tr><td colspan="6" class="text-center py-5 text-danger">Failed to load reservations.</td></tr>';
        }
    }

    async function loadTravelBookings() {
        try {
            const response = await fetch('/api/travel-bookings', {
                headers: { 'Authorization': `Bearer ${authToken}`, 'Accept': 'application/json' }
            });
            const data = await response.json();
            const bookings = data.data || data;
            const tbody = document.getElementById('travelTable');
            
            if (!bookings || bookings.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="text-center py-5 text-muted"><i class="fas fa-map-marked-alt fa-2x mb-3 opacity-25"></i><br>No travel packages booked.</td></tr>';
                return;
            }
            
            tbody.innerHTML = bookings.map(booking => {
                const statusClass = booking.status === 'confirmed' ? 'success' : (booking.status === 'pending' ? 'warning' : 'danger');
                const payStatus = booking.payment_status || 'unpaid';
                let payStatusClass = 'secondary';
                if (payStatus === 'paid') payStatusClass = 'success';
                else if (payStatus === 'partial') payStatusClass = 'warning';
                return `
                <tr>
                    <td class="ps-4 fw-bold text-primary">#TR-${booking.id}</td>
                    <td>
                        <div class="d-flex align-items-center">
                            <div class="bg-light rounded p-2 me-3"><i class="fas fa-globe-asia text-primary"></i></div>
                            <div>
                                <div class="fw-bold">${booking.package?.title || 'Tour Package'}</div>
                                <div class="small text-muted">${booking.package?.destination || 'Destination'}</div>
                            </div>
                        </div>
                    </td>
                    <td><div class="small fw-bold text-dark"><i class="far fa-calendar-check me-1 text-primary"></i> ${formatDate(booking.travel_date)}</div></td>
                    <td>
                        <span class="fw-bold text-dark">TK ${parseFloat(booking.total_price).toLocaleString()}</span>
                        <div class="small text-muted" style="font-size: 0.72rem;">Paid: TK ${parseFloat(booking.paid_amount || 0).toLocaleString()}</div>
                    </td>
                    <td>
                        <div class="d-flex flex-column gap-1">
                            <span class="badge bg-${statusClass} bg-opacity-10 text-${statusClass} border border-${statusClass} border-opacity-25 px-3 py-1.5 rounded-pill text-center">${booking.status.toUpperCase()}</span>
                            <span class="badge bg-${payStatusClass} bg-opacity-10 text-${payStatusClass} border border-${payStatusClass} border-opacity-25 px-3 py-1.5 rounded-pill text-center">${payStatus.toUpperCase()}</span>
                        </div>
                    </td>
                    <td class="text-end pe-4">
                        <div class="d-flex justify-content-end gap-2 align-items-center">
                            ${payStatus !== 'paid' ? `
                                <button onclick="openCheckoutModal(${booking.id}, 'travel', ${booking.total_price}, ${booking.paid_amount || 0}, '#TR-${booking.id}')" class="btn btn-primary btn-sm rounded-pill px-3 shadow-sm"><i class="fas fa-credit-card me-1"></i>Pay Now</button>
                            ` : ''}
                            <button onclick="viewTravelBooking(${booking.id})" class="btn btn-outline-primary btn-sm rounded-pill px-3">Details</button>
                        </div>
                    </td>
                </tr>`;
            }).join('');
        } catch (error) { console.error(error); }
    }

    async function loadCarBookings() {
        try {
            const response = await fetch('/api/car-bookings/my', {
                headers: { 'Authorization': `Bearer ${authToken}`, 'Accept': 'application/json' }
            });
            const bookings = await response.json();
            const tbody = document.getElementById('carsTable');
            
            if (!bookings || bookings.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" class="text-center py-5 text-muted"><i class="fas fa-car fa-2x mb-3 opacity-25"></i><br>No car rentals found.</td></tr>';
                return;
            }
            
            tbody.innerHTML = bookings.map(booking => {
                const statusClass = booking.status === 'confirmed' ? 'success' : (booking.status === 'pending' ? 'warning' : 'danger');
                const payStatus = booking.payment_status || 'unpaid';
                let payStatusClass = 'secondary';
                if (payStatus === 'paid') payStatusClass = 'success';
                else if (payStatus === 'partial') payStatusClass = 'warning';
                return `
                <tr>
                    <td class="ps-4 fw-bold text-primary">#CR-${booking.id}</td>
                    <td>
                        <div class="d-flex align-items-center">
                            <div class="bg-light rounded p-2 me-3"><i class="fas fa-car-side text-primary"></i></div>
                            <div>
                                <div class="fw-bold">${booking.car?.name || 'Rental Car'}</div>
                                <div class="small text-muted">${booking.car?.brand || 'Premium'}</div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="small fw-bold text-dark"><i class="far fa-clock me-1 text-primary"></i> ${formatDate(booking.pickup_date)}</div>
                        <div class="small text-muted ps-3">to ${formatDate(booking.return_date)}</div>
                    </td>
                    <td>
                        <span class="fw-bold text-dark">TK ${parseFloat(booking.total_price).toLocaleString()}</span>
                        <div class="small text-muted" style="font-size: 0.72rem;">Paid: TK ${parseFloat(booking.paid_amount || 0).toLocaleString()}</div>
                    </td>
                    <td>
                        <div class="d-flex flex-column gap-1">
                            <span class="badge bg-${statusClass} bg-opacity-10 text-${statusClass} border border-${statusClass} border-opacity-25 px-3 py-1.5 rounded-pill text-center">${booking.status.toUpperCase()}</span>
                            <span class="badge bg-${payStatusClass} bg-opacity-10 text-${payStatusClass} border border-${payStatusClass} border-opacity-25 px-3 py-1.5 rounded-pill text-center">${payStatus.toUpperCase()}</span>
                        </div>
                    </td>
                    <td class="text-end pe-4">
                        <div class="d-flex justify-content-end gap-2 align-items-center">
                            ${payStatus !== 'paid' ? `
                                <button onclick="openCheckoutModal(${booking.id}, 'car', ${booking.total_price}, ${booking.paid_amount || 0}, '#CR-${booking.id}')" class="btn btn-primary btn-sm rounded-pill px-3 shadow-sm"><i class="fas fa-credit-card me-1"></i>Pay Now</button>
                            ` : ''}
                            <button onclick="viewCarBooking(${booking.id})" class="btn btn-outline-primary btn-sm rounded-pill px-3">Details</button>
                        </div>
                    </td>
                </tr>`;
            }).join('');
        } catch (error) { console.error(error); }
    }

    async function viewBooking(id) {
        const content = document.getElementById('bookingDetailsContent');
        content.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div></div>';
        document.querySelector('#viewBookingModal .modal-title').textContent = 'Room Reservation Details';
        viewModal.show();
        
        try {
            const response = await fetch(`/api/bookings/my`, {
                headers: { 'Authorization': `Bearer ${authToken}`, 'Accept': 'application/json' }
            });
            const bookings = await response.json();
            const booking = bookings.find(b => b.id == id);
            
            if (booking) {
                const payStatus = booking.payment_status || 'unpaid';
                let payStatusClass = 'secondary';
                if (payStatus === 'paid') payStatusClass = 'success';
                else if (payStatus === 'partial') payStatusClass = 'warning';
                
                const txnIdHtml = booking.transaction_id ? `<div class="d-flex justify-content-between mb-2"><span class="text-muted">Transaction ID</span><span class="fw-bold text-dark text-uppercase">${booking.transaction_id}</span></div>` : '';
                
                content.innerHTML = `
                    <div class="booking-detail-item mb-4 text-center">
                        <div class="display-6 fw-bold text-primary mb-1">TK ${parseFloat(booking.total_price).toLocaleString()}</div>
                        <div class="badge bg-${payStatusClass} bg-opacity-10 text-${payStatusClass} rounded-pill px-3">${payStatus.toUpperCase()}</div>
                    </div>
                    <div class="row g-3 mb-4">
                        <div class="col-6">
                            <label class="small text-muted text-uppercase fw-bold">Check-In</label>
                            <div class="fw-bold text-dark"><i class="fas fa-sign-in-alt text-primary me-1"></i> ${formatDate(booking.check_in_date)}</div>
                        </div>
                        <div class="col-6">
                            <label class="small text-muted text-uppercase fw-bold">Check-Out</label>
                            <div class="fw-bold text-dark"><i class="fas fa-sign-out-alt text-primary me-1"></i> ${formatDate(booking.check_out_date)}</div>
                        </div>
                    </div>
                    <div class="bg-light rounded-4 p-4 mb-4">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Hotel Name</span>
                            <span class="fw-bold text-dark">${booking.hotel?.name || 'The Grand Azure'}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">City</span>
                            <span class="fw-bold text-dark">${booking.hotel?.city || 'Dhaka'}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Room Type</span>
                            <span class="fw-bold text-dark">${booking.room?.room_type || 'Luxury Suite'}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Room Number</span>
                            <span class="fw-bold text-dark">${booking.room?.room_number || 'N/A'}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Booking Reference</span>
                            <span class="fw-bold text-dark">#BK-${booking.id}</span>
                        </div>
                        <div class="border-top my-2"></div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Total Price</span>
                            <span class="fw-bold text-dark">TK ${parseFloat(booking.total_price).toLocaleString()}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Already Paid</span>
                            <span class="fw-bold text-success">TK ${parseFloat(booking.paid_amount || 0).toLocaleString()}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Remaining Balance</span>
                            <span class="fw-bold text-danger">TK ${parseFloat(booking.total_price - (booking.paid_amount || 0)).toLocaleString()}</span>
                        </div>
                        ${txnIdHtml}
                    </div>
                    <div class="text-center">
                        ${payStatus !== 'paid' ? `
                            <button class="btn btn-primary w-100 py-3 rounded-pill fw-bold shadow-sm mb-3" onclick="viewModal.hide(); setTimeout(() => openCheckoutModal(${booking.id}, 'room', ${booking.total_price}, ${booking.paid_amount || 0}, '#BK-${booking.id}'), 400)"><i class="fas fa-credit-card me-2"></i>Pay Now</button>
                        ` : ''}
                        <p class="small text-muted mb-4"><i class="fas fa-info-circle me-1"></i> Show this reference during check-in.</p>
                        <button class="btn btn-outline-primary w-100 py-3 rounded-pill fw-bold shadow-sm" onclick="window.print()"><i class="fas fa-print me-2"></i>Download Receipt</button>
                    </div>
                `;
            }
        } catch (e) { console.error(e); }
    }

    async function viewTravelBooking(id) {
        const content = document.getElementById('bookingDetailsContent');
        content.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div></div>';
        document.querySelector('#viewBookingModal .modal-title').textContent = 'Travel Package Details';
        viewModal.show();
        
        try {
            const response = await fetch('/api/travel-bookings', {
                headers: { 'Authorization': `Bearer ${authToken}`, 'Accept': 'application/json' }
            });
            const data = await response.json();
            const bookings = data.data || data;
            const booking = bookings.find(b => b.id == id);
            
            if (booking) {
                const payStatus = booking.payment_status || 'unpaid';
                let payStatusClass = 'secondary';
                if (payStatus === 'paid') payStatusClass = 'success';
                else if (payStatus === 'partial') payStatusClass = 'warning';
                
                const txnIdHtml = booking.transaction_id ? `<div class="d-flex justify-content-between mb-2"><span class="text-muted">Transaction ID</span><span class="fw-bold text-dark text-uppercase">${booking.transaction_id}</span></div>` : '';
                
                content.innerHTML = `
                    <div class="booking-detail-item mb-4 text-center">
                        <div class="display-6 fw-bold text-primary mb-1">TK ${parseFloat(booking.total_price).toLocaleString()}</div>
                        <div class="badge bg-${payStatusClass} bg-opacity-10 text-${payStatusClass} rounded-pill px-3">${payStatus.toUpperCase()}</div>
                    </div>
                    <div class="row g-3 mb-4">
                        <div class="col-6">
                            <label class="small text-muted text-uppercase fw-bold">Travel Date</label>
                            <div class="fw-bold text-dark"><i class="far fa-calendar-check text-primary me-1"></i> ${formatDate(booking.travel_date)}</div>
                        </div>
                        <div class="col-6">
                            <label class="small text-muted text-uppercase fw-bold">Guests</label>
                            <div class="fw-bold text-dark"><i class="fas fa-users text-primary me-1"></i> ${booking.guests} Person(s)</div>
                        </div>
                    </div>
                    <div class="bg-light rounded-4 p-4 mb-4">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Package Title</span>
                            <span class="fw-bold text-dark">${booking.package?.title || 'Tour Package'}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Destination</span>
                            <span class="fw-bold text-dark">${booking.package?.destination || 'Destination'}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Duration</span>
                            <span class="fw-bold text-dark">${booking.package?.duration_days || 'N/A'} Days</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Price Per Guest</span>
                            <span class="fw-bold text-dark">TK ${parseFloat(booking.package?.price || 0).toLocaleString()}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Booking Reference</span>
                            <span class="fw-bold text-dark">#TR-${booking.id}</span>
                        </div>
                        <div class="border-top my-2"></div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Total Price</span>
                            <span class="fw-bold text-dark">TK ${parseFloat(booking.total_price).toLocaleString()}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Already Paid</span>
                            <span class="fw-bold text-success">TK ${parseFloat(booking.paid_amount || 0).toLocaleString()}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Remaining Balance</span>
                            <span class="fw-bold text-danger">TK ${parseFloat(booking.total_price - (booking.paid_amount || 0)).toLocaleString()}</span>
                        </div>
                        ${txnIdHtml}
                    </div>
                    ${booking.package?.description ? `
                    <div class="mb-4">
                        <label class="small text-muted text-uppercase fw-bold mb-2">Description</label>
                        <div class="text-muted small">${booking.package.description}</div>
                    </div>
                    ` : ''}
                    <div class="text-center">
                        ${payStatus !== 'paid' ? `
                            <button class="btn btn-primary w-100 py-3 rounded-pill fw-bold shadow-sm mb-3" onclick="viewModal.hide(); setTimeout(() => openCheckoutModal(${booking.id}, 'travel', ${booking.total_price}, ${booking.paid_amount || 0}, '#TR-${booking.id}'), 400)"><i class="fas fa-credit-card me-2"></i>Pay Now</button>
                        ` : ''}
                        <p class="small text-muted mb-4"><i class="fas fa-info-circle me-1"></i> Show this reference to the travel coordinator.</p>
                        <button class="btn btn-outline-primary w-100 py-3 rounded-pill fw-bold shadow-sm" onclick="window.print()"><i class="fas fa-print me-2"></i>Download Receipt</button>
                    </div>
                `;
            } else {
                content.innerHTML = '<div class="text-center py-5 text-danger">Booking details not found.</div>';
            }
        } catch (e) {
            console.error(e);
            content.innerHTML = '<div class="text-center py-5 text-danger">Failed to load booking details.</div>';
        }
    }

    async function viewCarBooking(id) {
        const content = document.getElementById('bookingDetailsContent');
        content.innerHTML = '<div class="text-center py-5"><div class="spinner-border text-primary"></div></div>';
        document.querySelector('#viewBookingModal .modal-title').textContent = 'Car Rental Details';
        viewModal.show();
        
        try {
            const response = await fetch('/api/car-bookings/my', {
                headers: { 'Authorization': `Bearer ${authToken}`, 'Accept': 'application/json' }
            });
            const bookings = await response.json();
            const booking = bookings.find(b => b.id == id);
            
            if (booking) {
                const payStatus = booking.payment_status || 'unpaid';
                let payStatusClass = 'secondary';
                if (payStatus === 'paid') payStatusClass = 'success';
                else if (payStatus === 'partial') payStatusClass = 'warning';
                
                const txnIdHtml = booking.transaction_id ? `<div class="d-flex justify-content-between mb-2"><span class="text-muted">Transaction ID</span><span class="fw-bold text-dark text-uppercase">${booking.transaction_id}</span></div>` : '';
                
                content.innerHTML = `
                    <div class="booking-detail-item mb-4 text-center">
                        <div class="display-6 fw-bold text-primary mb-1">TK ${parseFloat(booking.total_price).toLocaleString()}</div>
                        <div class="badge bg-${payStatusClass} bg-opacity-10 text-${payStatusClass} rounded-pill px-3">${payStatus.toUpperCase()}</div>
                    </div>
                    <div class="row g-3 mb-4">
                        <div class="col-6">
                            <label class="small text-muted text-uppercase fw-bold">Pickup</label>
                            <div class="fw-bold text-dark"><i class="fas fa-calendar-alt text-primary me-1"></i> ${formatDate(booking.pickup_date)}</div>
                        </div>
                        <div class="col-6">
                            <label class="small text-muted text-uppercase fw-bold">Return</label>
                            <div class="fw-bold text-dark"><i class="fas fa-calendar-alt text-primary me-1"></i> ${formatDate(booking.return_date)}</div>
                        </div>
                    </div>
                    <div class="bg-light rounded-4 p-4 mb-4">
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Car Model</span>
                            <span class="fw-bold text-dark">${booking.car?.name || 'Rental Car'}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Brand</span>
                            <span class="fw-bold text-dark">${booking.car?.brand || 'Premium'}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Pickup Location</span>
                            <span class="fw-bold text-dark">${booking.pickup_location} (${booking.pickup_city})</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Dropoff Location</span>
                            <span class="fw-bold text-dark">${booking.return_location} (${booking.dropoff_city})</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Booking Reference</span>
                            <span class="fw-bold text-dark">#CR-${booking.id}</span>
                        </div>
                        <div class="border-top my-2"></div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Total Price</span>
                            <span class="fw-bold text-dark">TK ${parseFloat(booking.total_price).toLocaleString()}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Already Paid</span>
                            <span class="fw-bold text-success">TK ${parseFloat(booking.paid_amount || 0).toLocaleString()}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Remaining Balance</span>
                            <span class="fw-bold text-danger">TK ${parseFloat(booking.total_price - (booking.paid_amount || 0)).toLocaleString()}</span>
                        </div>
                        ${txnIdHtml}
                    </div>
                    ${booking.notes ? `
                    <div class="mb-4">
                        <label class="small text-muted text-uppercase fw-bold mb-2">Notes</label>
                        <div class="text-muted small">${booking.notes}</div>
                    </div>
                    ` : ''}
                    <div class="text-center">
                        ${payStatus !== 'paid' ? `
                            <button class="btn btn-primary w-100 py-3 rounded-pill fw-bold shadow-sm mb-3" onclick="viewModal.hide(); setTimeout(() => openCheckoutModal(${booking.id}, 'car', ${booking.total_price}, ${booking.paid_amount || 0}, '#CR-${booking.id}'), 400)"><i class="fas fa-credit-card me-2"></i>Pay Now</button>
                        ` : ''}
                        <p class="small text-muted mb-4"><i class="fas fa-info-circle me-1"></i> Show this reference when picking up the vehicle.</p>
                        <button class="btn btn-outline-primary w-100 py-3 rounded-pill fw-bold shadow-sm" onclick="window.print()"><i class="fas fa-print me-2"></i>Download Receipt</button>
                    </div>
                `;
            } else {
                content.innerHTML = '<div class="text-center py-5 text-danger">Booking details not found.</div>';
            }
        } catch (e) {
            console.error(e);
            content.innerHTML = '<div class="text-center py-5 text-danger">Failed to load booking details.</div>';
        }
    }
    
    async function cancelBooking(id) {
        const confirmCancel = await Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to cancel this booking?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, Cancel it!',
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6'
        });

        if (!confirmCancel.isConfirmed) return;

        try {
            const response = await fetch(`/api/bookings/${id}`, {
                method: 'DELETE',
                headers: { 
                    'Authorization': `Bearer ${authToken}`, 
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            });

            if (response.ok) {
                Swal.fire({
                    icon: 'success',
                    title: 'Cancelled!',
                    text: 'Your booking has been cancelled.',
                    confirmButtonColor: '#1E3A5F'
                }).then(() => {
                    loadBookings();
                });
            } else {
                const result = await response.json();
                Swal.fire({ icon: 'error', title: 'Cancellation Failed', text: result.message || 'Error cancelling booking.' });
            }
        } catch (error) { console.error('Cancellation Error:', error); }
    }
</script>
@endsection