@extends('layouts.admin')

@section('title', 'Manage Travel Bookings')
@section('header_title', 'Tour Bookings')

@section('content')
<div class="data-card">
    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h3>Incoming Tour Reservations</h3>
    </div>
    
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Package</th>
                    <th>Travel Date</th>
                    <th>Guests</th>
                    <th>Total Price</th>
                    <th>Payment</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($bookings as $booking)
                <tr>
                    <td>
                        <div style="font-weight: 600;">{{ $booking->user->name }}</div>
                        <div style="font-size: 0.8rem; color: var(--text-muted);">{{ $booking->user->email }}</div>
                    </td>
                    <td>{{ $booking->package->title }}</td>
                    <td>{{ \Carbon\Carbon::parse($booking->travel_date)->format('M d, Y') }}</td>
                    <td>{{ $booking->guests }}</td>
                    <td>
                        <div>TK {{ number_format($booking->total_price, 2) }}</div>
                        <div style="font-size: 0.72rem; color: var(--text-muted);">Paid: TK {{ number_format($booking->paid_amount ?? 0, 2) }}</div>
                    </td>
                    <td>
                        @if($booking->payment_status === 'paid')
                            <span class="badge" style="background-color: #2ECC71; color: white; font-weight: 600;">Paid</span>
                        @elseif($booking->payment_status === 'partial')
                            <span class="badge" style="background-color: #F1C40F; color: black; font-weight: 600;">Partial</span>
                        @else
                            <span class="badge" style="background-color: #E74C3C; color: white; font-weight: 600;">Unpaid</span>
                        @endif
                        @if($booking->transaction_id)
                            <div style="font-size: 0.7rem; color: var(--text-muted); margin-top: 3px; font-family: monospace;" title="Transaction ID">{{ $booking->transaction_id }}</div>
                        @endif
                    </td>
                    <td>
                        <span class="badge badge-{{ $booking->status }}">
                            {{ ucfirst($booking->status) }}
                        </span>
                    </td>
                    <td>
                        <form action="{{ route('manager.travel_bookings.update', $booking->id) }}" method="POST" style="display: inline;">
                            @csrf
                            @method('PUT')
                            <select name="status" onchange="this.form.submit()" class="form-control" style="font-size: 0.8rem; padding: 5px;">
                                <option value="pending" {{ $booking->status === 'pending' ? 'selected' : '' }}>Pending</option>
                                <option value="confirmed" {{ $booking->status === 'confirmed' ? 'selected' : '' }}>Confirm</option>
                                <option value="completed" {{ $booking->status === 'completed' ? 'selected' : '' }}>Complete</option>
                                <option value="cancelled" {{ $booking->status === 'cancelled' ? 'selected' : '' }}>Cancel</option>
                            </select>
                        </form>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="8" style="text-align: center; padding: 40px;">No travel bookings found.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
        <div style="margin-top: 20px;">
            {{ $bookings->links() }}
        </div>
    </div>
</div>
@endsection
