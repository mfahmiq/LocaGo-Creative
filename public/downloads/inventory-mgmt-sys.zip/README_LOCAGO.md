# Warehouse & Inventory Management System - Inventory Mgmt Sys

```
========================================================================
📦 Warehouse & Inventory Management System - Inventory Mgmt Sys
Kategori     : Bisnis & Manajemen
Tech Stack   : PHP Native • PHP • MySQL • Tailwind CSS
Database     : MySQL (.sql) (File: schema.sql)
Sumber Asli  : https://github.com/yitmeng00/inventory-mgmt-sys (GitHub Open Source)
Stars GitHub : ⭐ 0 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/inventory-mgmt-sys`
     * Untuk Laragon: `C:/laragon/www/inventory-mgmt-sys`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - File SQL ini membuat database `inventory_db` sendiri — tidak perlu membuat
     database manual. Klik tab 'Import', pilih file SQL yang disertakan pada:
     `schema.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.
   - (OPSIONAL) DATA CONTOH: setelah schema.sql berhasil, import juga
     `seed.sql` (tab 'Import' yang sama) untuk data contoh: 5 user, 7 kategori,
     5 supplier, 20 produk, dan ~58 transaksi. Jalankan SETELAH schema.sql,
     karena seed.sql memakai tabel yang dibuat schema.sql.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = inventory_db

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/inventory-mgmt-sys

5. AKUN LOGIN DEMO (terverifikasi dari file SQL repo asli):
   - Admin  : username `admin` / password `password`
     (hash bcrypt di schema.sql terverifikasi cocok dengan "password").
   - PERHATIAN: tabel "Default Credentials" di README.md repo menulis
     admin/admin123, john.doe/staff123, dan jane.smith/staff123 — itu TIDAK
     cocok dengan database yang dikirim: password admin yang benar adalah
     "password" (bukan "admin123"), dan john.doe / jane.smith tidak ada di
     file .sql manapun. Pakai akun admin di atas.
   - User contoh dari seed.sql (alice.tan, bob.lim, carol.ng, david.wong,
     mary.chen) password-nya TIDAK didokumentasikan di repo — jangan ditebak;
     bila butuh akun staff, buat user baru lewat aplikasi setelah login admin.
   - Ganti semua password default sebelum dipakai di lingkungan production.

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
