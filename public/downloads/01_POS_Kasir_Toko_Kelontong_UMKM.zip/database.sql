-- Database Dump: db_pos_toko
CREATE DATABASE IF NOT EXISTS `db_pos_toko`;
USE `db_pos_toko`;

CREATE TABLE IF NOT EXISTS `produk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(50) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `stok` int(11) NOT NULL DEFAULT 0,
  `harga` decimal(10,2) NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `produk` (`kode`, `nama`, `stok`, `harga`) VALUES
('BRG-001', 'Beras Ramos Premium 5kg', 25, 68000),
('BRG-002', 'Minyak Goreng SunCo 2L', 40, 34500),
('BRG-003', 'Gula Pasir Gulaku 1kg', 50, 17500),
('BRG-004', 'Kecap Manis Bango 550ml', 30, 24000),
('BRG-005', 'Indomie Goreng Spesial (Karton)', 15, 118000);
