# Panduan Instalasi POS Kasir Toko Kelontong UMKM
1. Ekstrak file ZIP ini ke folder `htdocs` (XAMPP) atau `www` (Laragon).
2. Buka phpMyAdmin di browser: `http://localhost/phpmyadmin`.
3. Buat database baru bernama `db_pos_toko`.
4. Import file `database.sql` ke dalam database tersebut.
5. Sesuaikan username dan password di `config/database.php` jika diperlukan.
6. Buka `http://localhost/01_POS_Kasir_Toko_Kelontong_UMKM` di browser Anda. Selesai!
