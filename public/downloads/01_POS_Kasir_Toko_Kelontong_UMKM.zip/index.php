<?php
// POS Kasir Toko Kelontong UMKM - LocaGo Creative
session_start();
require_once 'config/database.php';
$stmt = $pdo->query("SELECT * FROM produk ORDER BY id DESC LIMIT 10");
$produk = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>POS Toko Kelontong - Kasir</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <nav class="navbar navbar-dark bg-success mb-4">
        <div class="container">
            <span class="navbar-brand mb-0 h1">🏪 POS Toko Kelontong UMKM</span>
            <span class="text-white font-monospace">Versi 2.0 • WhatsApp Gateway Ready</span>
        </div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="card shadow-sm mb-4">
                    <div class="card-header bg-white font-weight-bold">Daftar Produk & Scan Barcode</div>
                    <div class="card-body">
                        <input type="text" id="barcode" class="form-control mb-3" placeholder="Scan Barcode atau ketik nama produk...">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead><tr><th>Kode</th><th>Nama</th><th>Stok</th><th>Harga</th><th>Aksi</th></tr></thead>
                                <tbody>
                                    <?php foreach($produk as $p): ?>
                                    <tr>
                                        <td><code><?= htmlspecialchars($p['kode']) ?></code></td>
                                        <td><strong><?= htmlspecialchars($p['nama']) ?></strong></td>
                                        <td><span class="badge bg-info"><?= $p['stok'] ?></span></td>
                                        <td>Rp <?= number_format($p['harga'], 0, ',', '.') ?></td>
                                        <td><button class="btn btn-sm btn-success" onclick="tambahItem('<?= $p['kode'] ?>')">+ Tambah</button></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-header bg-dark text-white font-weight-bold">Keranjang & Struk WA</div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">No. WhatsApp Pelanggan:</label>
                            <input type="text" class="form-control" placeholder="Contoh: 08123456789">
                        </div>
                        <div class="d-grid gap-2">
                            <button class="btn btn-primary">Bayar & Kirim Struk WhatsApp</button>
                            <button class="btn btn-outline-secondary">Cetak Struk Thermal (58mm)</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
