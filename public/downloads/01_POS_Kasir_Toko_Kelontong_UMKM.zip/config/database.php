<?php
// Konfigurasi Database MySQL
$host = 'localhost';
$db   = 'db_pos_toko';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     // fallback demo array jika belum import SQL
     class DummyPDO {
         public function query($q) {
             return new class {
                 public function fetchAll($mode) {
                     return [
                         ['id'=>1, 'kode'=>'BRG-001', 'nama'=>'Beras Ramos 5kg', 'stok'=>24, 'harga'=>68000],
                         ['id'=>2, 'kode'=>'BRG-002', 'nama'=>'Minyak Goreng 2L', 'stok'=>40, 'harga'=>34000],
                         ['id'=>3, 'kode'=>'BRG-003', 'nama'=>'Gula Pasir 1kg', 'stok'=>50, 'harga'=>17500],
                         ['id'=>4, 'kode'=>'BRG-004', 'nama'=>'Telur Ayam 1kg', 'stok'=>30, 'harga'=>28000]
                     ];
                 }
             };
         }
     }
     $pdo = new DummyPDO();
}
