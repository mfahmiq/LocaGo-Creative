# Aplikasi Penggajian Karyawan & Payroll - Sistem Akuntansi Gaji Dan Upah Pegawai

```
========================================================================
📦 Aplikasi Penggajian Karyawan & Payroll - Sistem Akuntansi Gaji Dan Upah Pegawai
Kategori     : HRD & Keuangan
Tech Stack   : CodeIgniter • PHP • MySQL • Bootstrap • AdminLTE
Database     : MySQL (.sql) (File: gaji.sql)
Sumber Asli  : https://github.com/adityaharist/sistem-akuntansi-gaji-dan-upah-pegawai (GitHub Open Source)
Stars GitHub : ⭐ 2 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/sistem-akuntansi-gaji-dan-upah-pegawai`
     * Untuk Laragon: `C:/laragon/www/sistem-akuntansi-gaji-dan-upah-pegawai`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `sistem_akuntansi_gaji_dan_upah_pegawai`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `gaji.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = sistem_akuntansi_gaji_dan_upah_pegawai

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/sistem-akuntansi-gaji-dan-upah-pegawai

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
