# Aplikasi Ujian Online CBT & E-Learning - Cat

```
========================================================================
📦 Aplikasi Ujian Online CBT & E-Learning - Cat
Kategori     : Pendidikan & Akademik
Tech Stack   : CodeIgniter • PHP • MySQL • Bootstrap
Database     : MySQL (.sql) (File: db_cat.sql)
Sumber Asli  : https://github.com/yusuffakhruddin/cat (GitHub Open Source)
Stars GitHub : ⭐ 14 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/cat`
     * Untuk Laragon: `C:/laragon/www/cat`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `cat`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `db_cat.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = cat

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/cat

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
