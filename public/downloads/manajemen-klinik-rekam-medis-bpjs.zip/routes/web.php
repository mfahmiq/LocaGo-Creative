<?php // Web routes definitions
Route::get('/', [DashboardController::class, 'index']);
