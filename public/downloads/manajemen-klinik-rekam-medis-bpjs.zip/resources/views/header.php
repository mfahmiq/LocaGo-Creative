<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?> - <?= htmlspecialchars($appName) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen flex flex-col">
    <nav class="bg-slate-900 border-b border-slate-800 px-6 py-4 flex items-center justify-between">
        <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-xl bg-emerald-500 text-slate-950 font-extrabold flex items-center justify-center text-sm">LC</div>
            <div>
                <h1 class="text-sm font-bold text-white"><?= htmlspecialchars($appName) ?></h1>
                <span class="text-xs text-emerald-400 font-mono">v2.6.0 Enterprise</span>
            </div>
        </div>
        <div class="flex items-center gap-4 text-xs">
            <span class="px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono">
                ● Database: <?= $dbConnected ? 'Terhubung' : 'Lokal (Mock)' ?>
            </span>
            <span class="text-slate-400 font-mono">admin@locago.my.id</span>
        </div>
    </nav>
