
    <footer class="bg-slate-900 border-t border-slate-800 px-6 py-4 text-center text-xs text-slate-500">
        <?= date('Y') ?> &copy; LocaGo Creative • Source Code Siap Pakai Bebas Modifikasi.
    </footer>
</body>
</html>
