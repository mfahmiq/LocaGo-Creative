
    <main class="flex-1 max-w-7xl w-full mx-auto p-6 space-y-6">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
                <span class="text-xs font-mono uppercase text-slate-400">Total Item / Data</span>
                <div class="text-3xl font-extrabold text-white mt-2"><?= number_format($stats['items']) ?></div>
            </div>
            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
                <span class="text-xs font-mono uppercase text-slate-400">Total Transaksi</span>
                <div class="text-3xl font-extrabold text-emerald-400 mt-2"><?= number_format($stats['transactions']) ?></div>
            </div>
            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
                <span class="text-xs font-mono uppercase text-slate-400">Omzet / Nilai Transaksi</span>
                <div class="text-3xl font-extrabold text-white mt-2">Rp <?= number_format($stats['revenue'], 0, ',', '.') ?></div>
            </div>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-base font-bold text-white">Data Transaksi & Aktivitas Terkini</h2>
                <span class="text-xs font-mono text-emerald-400">Sinkronisasi Real-Time</span>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs border-collapse">
                    <thead>
                        <tr class="border-b border-slate-800 text-slate-400">
                            <th class="py-3 px-4">INVOICE</th>
                            <th class="py-3 px-4">PELANGGAN</th>
                            <th class="py-3 px-4">TELEPON WA</th>
                            <th class="py-3 px-4">TOTAL</th>
                            <th class="py-3 px-4">METODE</th>
                            <th class="py-3 px-4">STATUS</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800/60 text-slate-200">
                        <tr>
                            <td class="py-3 px-4 font-mono">#INV-20261110-001</td>
                            <td class="py-3 px-4 font-semibold">Budi Santoso</td>
                            <td class="py-3 px-4">081234567890</td>
                            <td class="py-3 px-4 font-mono font-bold text-emerald-400">Rp 215.000</td>
                            <td class="py-3 px-4">QRIS Dinamis</td>
                            <td class="py-3 px-4"><span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 font-bold border border-emerald-800">LUNAS</span></td>
                        </tr>
                        <tr>
                            <td class="py-3 px-4 font-mono">#INV-20261110-002</td>
                            <td class="py-3 px-4 font-semibold">Siti Nurhaliza</td>
                            <td class="py-3 px-4">085711223344</td>
                            <td class="py-3 px-4 font-mono font-bold text-emerald-400">Rp 375.000</td>
                            <td class="py-3 px-4">Transfer Bank</td>
                            <td class="py-3 px-4"><span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 font-bold border border-emerald-800">LUNAS</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
