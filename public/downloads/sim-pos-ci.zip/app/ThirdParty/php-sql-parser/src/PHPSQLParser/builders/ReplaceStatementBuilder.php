<?php
/**
 * ReplaceStatement.php
 *
 * Builds the REPLACE statement
 *
 * PHP version 5
 *
 * LICENSE:
 * Copyright (c) 2010-2014 Justin Swanhart and André Rothe
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @copyright 2010-2014 Justin Swanhart and André Rothe
 * @license   http://www.debian.org/misc/bsd.license  BSD License (3 Clause)
 *
 * @version   SVN: $Id$
 */

namespace PHPSQLParser\builders;

/**
 * This class implements the builder for the whole Replace statement. You can overwrite
 * all functions to achieve another handling.
 *
 * @license http://www.debian.org/misc/bsd.license  BSD License (3 Clause)
 */
class ReplaceStatementBuilder implements Builder
{
    protected function buildVALUES($parsed)
    {
        $builder = new ValuesBuilder();

        return $builder->build($parsed);
    }

    protected function buildREPLACE($parsed)
    {
        $builder = new ReplaceBuilder();

        return $builder->build($parsed);
    }

    protected function buildSELECT($parsed)
    {
        $builder = new SelectStatementBuilder();

        return $builder->build($parsed);
    }

    protected function buildSET($parsed)
    {
        $builder = new SetBuilder();

        return $builder->build($parsed);
    }

    public function build(array $parsed)
    {
        // TODO: are there more than one tables possible (like [REPLACE][1])
        $sql = $this->buildREPLACE($parsed['REPLACE']);
        if (isset($parsed['VALUES'])) {
            $sql .= ' ' . $this->buildVALUES($parsed['VALUES']);
        }
        if (isset($parsed['SET'])) {
            $sql .= ' ' . $this->buildSET($parsed['SET']);
        }
        if (isset($parsed['SELECT'])) {
            $sql .= ' ' . $this->buildSELECT($parsed);
        }

        return $sql;
    }
}
