# Panduan POS Kasir Ritel Multi-Cabang
1. Ekstrak file ke folder server web lokal.
2. Import `db_pos_ritel.sql` ke database MySQL.
3. Buka di browser: `http://localhost/10_POS_Kasir_Ritel_Modern_Multi_Cabang`.
