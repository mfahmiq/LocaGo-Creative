CREATE DATABASE IF NOT EXISTS `db_pos_ritel`;
USE `db_pos_ritel`;

CREATE TABLE IF NOT EXISTS `transaksi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_nota` varchar(50) NOT NULL,
  `kasir` varchar(100) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `metode` varchar(50) NOT NULL,
  `status_wa` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `transaksi` (`no_nota`, `kasir`, `total`, `metode`, `status_wa`) VALUES
('INV-20261102-001', 'Kasir 01', 145000.00, 'QRIS Dinamis', 'Sent'),
('INV-20261102-002', 'Kasir 01', 82500.00, 'Tunai', 'Printed');
