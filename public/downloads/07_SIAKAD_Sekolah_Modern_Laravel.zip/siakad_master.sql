CREATE DATABASE IF NOT EXISTS `db_siakad_sekolah`;
USE `db_siakad_sekolah`;

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL UNIQUE,
  `role` enum('admin','kepsek','guru','siswa') NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `siswa` (
  `nisn` varchar(20) NOT NULL PRIMARY KEY,
  `nama` varchar(150) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `wali_kelas` varchar(100) NOT NULL,
  `nilai_rata` decimal(5,2) NOT NULL
);

INSERT INTO `siswa` VALUES
('005829101', 'Ahmad Rizky Pratama', 'XII IPA 1', 'Dra. Sri Mulyani', 88.50),
('005829102', 'Bunga Citra Lestari', 'XII IPA 1', 'Dra. Sri Mulyani', 91.20),
('005829103', 'Dimas Arya Pamungkas', 'XII IPA 2', 'Budi Santoso, M.Pd', 82.00);
