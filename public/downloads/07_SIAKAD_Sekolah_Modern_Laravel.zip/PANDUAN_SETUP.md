# Panduan SIAKAD Sekolah Laravel Modern
1. Ekstrak ke folder htdocs/Laragon.
2. Buat database `db_siakad_sekolah` dan import `siakad_master.sql`.
3. Login default admin: `admin@sekolah.sch.id` / `admin123`.
