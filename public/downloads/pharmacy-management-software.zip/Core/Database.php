<?php 
namespace Core;
use PDO;
use PDOException;

class Database
{
    public $connection;
    public $statement;

    public function __construct($config, $username = null, $password = null)
    {

         // Fallback to environment variables if username or password is not provided
    $username = $username ?? $_ENV['DB_USERNAME'];
    $password = $password ?? $_ENV['DB_PASSWORD'];
    $dsn = $_ENV['DB_CONNECTION']. ':' . http_build_query($config, '', ';');

        $this->connection = new PDO($dsn, $username, $password, [
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
    }

    
    public function query($query, $params = [])
    {
        $this->statement = $this->connection->prepare($query);

        $this->statement->execute($params);

        return $this;
    }

    public function get()
    {
        return $this->statement->fetchAll();
    }

    public function find()
    {
        return $this->statement->fetch();
    }

    public function findOrFail()
    {
        $result = $this->find();

        if (!$result) {
            abort(); // Implement your abort logic here
        }

        return $result;
    }

    // Transaction management methods
    public function beginTransaction()
    {
        $this->connection->beginTransaction();
    }

    public function commit()
    {
        $this->connection->commit();
    }


    public function rollBack()
    {
        $this->connection->rollBack();
    }

    public function rowCount()
{
    return $this->statement->rowCount(); 
}
}