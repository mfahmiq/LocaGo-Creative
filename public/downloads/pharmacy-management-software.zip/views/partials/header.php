   <?php 
 $logged_user_firstname = $_SESSION['user']['firstname'];
 $logged_user_lastname = $_SESSION['user']['lastname'];
  $logged_user_email = $_SESSION['user']['email'];
 ?>
  <div class="nk-header nk-header-fixed nk-header-fluid">
          <div class="container-fluid">
            <div class="nk-header-wrap">
              <div class="nk-menu-trigger d-xl-none ml-n1"><a href="#" class="nk-nav-toggle nk-quick-nav-icon" data-target="sidebarMenu"><em class="icon ni ni-menu"></em></a></div>
              <div class="nk-header-brand d-xl-none"><a href="" class="logo-link"><img loading="lazy" class="logo-light logo-img" src="/images/logo.png" srcset="/demo7/images/logo2x.png 2x" alt="logo"><img loading="lazy" class="logo-dark logo-img" src="../images/logo-dark.png" srcset="/demo7/images/logo-dark2x.png 2x" alt="logo-dark"></a></div>
              <div class="nk-header-search ml-3 ml-xl-0"><em class="icon ni ni-search"></em><input type="text" class="form-control border-transparent form-focus-none" placeholder="Search anything"></div>
              <div class="nk-header-tools">
                <ul class="nk-quick-nav">
                  <li class="dropdown chats-dropdown hide-mb-xs"><a href="#" class="dropdown-toggle nk-quick-nav-icon" data-bs-toggle="dropdown">
                      <div class="icon-status icon-status-na"><em class="icon ni ni-comments"></em></div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-xl dropdown-menu-end">
                      <div class="dropdown-head"><span class="sub-title nk-dropdown-title">Recent Chats</span><a href="#">Setting</a></div>
                      <div class="dropdown-body">
                        <ul class="chat-list">
                          <li class="chat-item"><a class="chat-link" href="/PMS/support">
                              <div class="chat-media user-avatar"><span>IH</span><span class="status dot dot-lg dot-gray"></span></div>
                              <div class="chat-info">
                                <div class="chat-from">
                                  <div class="name">Iliash Hossain</div><span class="time">Now</span>
                                </div>
                                <div class="chat-context">
                                  <div class="text">You: Please confrim if you got my last messages.</div>
                                  <div class="status delivered"><em class="icon ni ni-check-circle-fill"></em></div>
                                </div>
                              </div>
                            </a></li>
                          <li class="chat-item is-unread"><a class="chat-link" href="/PMS/support">
                              <div class="chat-media user-avatar bg-pink"><span>AB</span><span class="status dot dot-lg dot-success"></span></div>
                              <div class="chat-info">
                                <div class="chat-from">
                                  <div class="name">Abu Bin Ishtiyak</div><span class="time">4:49 AM</span>
                                </div>
                                <div class="chat-context">
                                  <div class="text">Hi, I am Ishtiyak, can you help me with this problem ?</div>
                                  <div class="status unread"><em class="icon ni ni-bullet-fill"></em></div>
                                </div>
                              </div>
                            </a></li>
                          <li class="chat-item"><a class="chat-link" href="/PMS/support">
                              <div class="chat-media user-avatar"><img loading="lazy" src="Public/assets/images/avatar/b-sm.jpg" alt=""></div>
                              <div class="chat-info">
                                <div class="chat-from">
                                  <div class="name">George Philips</div><span class="time">6 Apr</span>
                                </div>
                                <div class="chat-context">
                                  <div class="text">Have you seen the claim from Rose?</div>
                                </div>
                              </div>
                            </a></li>
                          <li class="chat-item"><a class="chat-link" href="/PMS/support">
                              <div class="chat-media user-avatar user-avatar-multiple">
                                <div class="user-avatar"><img loading="lazy" src="Public/assets/images/avatar/c-sm.jpg" alt=""></div>
                                <div class="user-avatar"><span>AB</span></div>
                              </div>
                              <div class="chat-info">
                                <div class="chat-from">
                                  <div class="name">Softnio Group</div><span class="time">27 Mar</span>
                                </div>
                                <div class="chat-context">
                                  <div class="text">You: I just bought a new computer but i am having some problem</div>
                                  <div class="status sent"><em class="icon ni ni-check-circle"></em></div>
                                </div>
                              </div>
                            </a></li>
                          <li class="chat-item"><a class="chat-link" href="/PMS/support">
                              <div class="chat-media user-avatar"><img loading="lazy" src="Public/assets/images/avatar/a-sm.jpg" alt=""><span class="status dot dot-lg dot-success"></span></div>
                              <div class="chat-info">
                                <div class="chat-from">
                                  <div class="name">Larry Hughes</div><span class="time">3 Apr</span>
                                </div>
                                <div class="chat-context">
                                  <div class="text">Hi Frank! How is you doing?</div>
                                </div>
                              </div>
                            </a></li>
                          <li class="chat-item"><a class="chat-link" href="/PMS/support">
                              <div class="chat-media user-avatar bg-purple"><span>TW</span></div>
                              <div class="chat-info">
                                <div class="chat-from">
                                  <div class="name">Tammy Wilson</div><span class="time">27 Mar</span>
                                </div>
                                <div class="chat-context">
                                  <div class="text">You: I just bought a new computer but i am having some problem</div>
                                  <div class="status sent"><em class="icon ni ni-check-circle"></em></div>
                                </div>
                              </div>
                            </a></li>
                        </ul>
                      </div>
                      <div class="dropdown-foot center"><a href="/PMS/support">View All</a></div>
                    </div>
                  </li>
                  <li class="dropdown notification-dropdown"><a href="#" class="dropdown-toggle nk-quick-nav-icon" data-bs-toggle="dropdown">
                      <div class="icon-status icon-status-info"><em class="icon ni ni-bell"></em></div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-xl dropdown-menu-end">
                      <div class="dropdown-head"><span class="sub-title nk-dropdown-title">Notifications</span><a href="#">Mark All as Read</a></div>
                      <div class="dropdown-body">
                        <div class="nk-notification">
                          <div class="nk-notification-item dropdown-inner">
                            <div class="nk-notification-icon"><em class="icon icon-circle bg-warning-dim ni ni-curve-down-right"></em></div>
                            <div class="nk-notification-content">
                              <div class="nk-notification-text">You have requested to <span>Widthdrawl</span></div>
                              <div class="nk-notification-time">2 hrs ago</div>
                            </div>
                          </div>
                          <div class="nk-notification-item dropdown-inner">
                            <div class="nk-notification-icon"><em class="icon icon-circle bg-success-dim ni ni-curve-down-left"></em></div>
                            <div class="nk-notification-content">
                              <div class="nk-notification-text">Your <span>Deposit Order</span> is placed</div>
                              <div class="nk-notification-time">2 hrs ago</div>
                            </div>
                          </div>
                          <div class="nk-notification-item dropdown-inner">
                            <div class="nk-notification-icon"><em class="icon icon-circle bg-warning-dim ni ni-curve-down-right"></em></div>
                            <div class="nk-notification-content">
                              <div class="nk-notification-text">You have requested to <span>Withdraw</span></div>
                              <div class="nk-notification-time">2 hrs ago</div>
                            </div>
                          </div>
                          <div class="nk-notification-item dropdown-inner">
                            <div class="nk-notification-icon"><em class="icon icon-circle bg-success-dim ni ni-curve-down-left"></em></div>
                            <div class="nk-notification-content">
                              <div class="nk-notification-text">Your <span>Deposit Order</span> is placed</div>
                              <div class="nk-notification-time">2 hrs ago</div>
                            </div>
                          </div>
                          <div class="nk-notification-item dropdown-inner">
                            <div class="nk-notification-icon"><em class="icon icon-circle bg-warning-dim ni ni-curve-down-right"></em></div>
                            <div class="nk-notification-content">
                              <div class="nk-notification-text">You have requested to <span>Withdraw</span></div>
                              <div class="nk-notification-time">2 hrs ago</div>
                            </div>
                          </div>
                          <div class="nk-notification-item dropdown-inner">
                            <div class="nk-notification-icon"><em class="icon icon-circle bg-success-dim ni ni-curve-down-left"></em></div>
                            <div class="nk-notification-content">
                              <div class="nk-notification-text">Your <span>Deposit Order</span> is placed</div>
                              <div class="nk-notification-time">2 hrs ago</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="dropdown-foot center"><a href="#">View All</a></div>
                    </div>
                  </li>
                  <li class="dropdown user-dropdown"><a href="#" class="dropdown-toggle mr-n1" data-bs-toggle="dropdown">
                      <div class="user-toggle">
                        <div class="user-avatar sm"><em class="icon ni ni-user-alt"></em></div>
                      </div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-md dropdown-menu-end">
                      <div class="dropdown-inner user-card-wrap bg-lighter">
                        <div class="user-card">
                          <div class="user-avatar"><span>AB</span></div>
                          <div class="user-info"><span class="lead-text"><?=  $logged_user_firstname .' '. $logged_user_lastname ?></span><span class="sub-text"><?= $logged_user_email ?></span></div>
                        </div>
                      </div>
                      <div class="dropdown-inner">
                        <ul class="link-list">
                          <?php if ($logged_user_type == 'admin'): ?>
                          <li><a href="/PMS/member-profile"><em class="icon ni ni-user-alt"></em><span>View Profile</span></a></li>
                          <li><a href="/PMS/settings"><em class="icon ni ni-setting-alt"></em><span>Account Setting</span></a></li>

                       
                           <?php endif; ?>
                              <li><a href="/PMS/account-log"><em class="icon ni ni-activity-alt"></em><span>Login Activity</span></a></li>
                        </ul>
                      </div>
                      <div class="dropdown-inner">
                        <ul class="link-list">
                          <li>
                              <form action="/PMS/logout" method="POST" style="margin: 0;">
                            <input type="hidden" name="_method" value="DELETE">
                            <em class="icon ni ni-signout"></em><button type="submit" style="background: none; border: none; cursor: pointer;">
                             <span>Sign out</span>
                             </button>
                           </form>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>