<?php 
 $logged_user_type = $_SESSION['user']['UserType'] ?? 'guest';
 ?>
<?php require('partials/head.php') ?>
<body class="nk-body ui-rounder npc-default has-sidebar ">
  <div class="nk-app-root">
     <!-- Sidebar wrapper starts -->
      <?php require('partials/Sidenav.php') ?>
      <!-- Sidebar wrapper ends -->
    <div class="nk-main ">
      <div class="nk-wrap">
    <!-- App header start -->
        <?php require('partials/header.php') ?>
                <!-- App header ends -->
        <div class="nk-content ">
          <div class="container-fluid">
            <div class="nk-content-inner">
              <div class="nk-content-body">
                  <!-- App top-nav start -->
              <?php require('partials/TopNav.php') ?>
                <!-- App top-nav ends -->
                <div class="nk-block">
                  <div class="row g-gs">
                    <?php if (in_array($logged_user_type, ['admin', 'accountant'])): ?>
                    <div class="col-xxl-3 col-sm-6">
                      <div class="card">
                        <div class="nk-ecwg nk-ecwg6">
                          <div class="card-inner">
                            <div class="card-title-group">
                              <div class="card-title">
                                <h6 class="title">Today's Sales</h6>
                              </div>
                            </div>
                            <div class="data">
                              <div class="data-group">
                                <div class="amount">$10,945</div>
                                <div class="nk-ecwg6-ck"><canvas class="ecommerce-line-chart-s3" id="ipdIncome"></canvas></div>
                              </div>
                              <div class="info"><span class="change up text-danger"><em class="icon ni ni-arrow-long-up"></em>4.63%</span><span> vs. last week</span></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-xxl-3 col-sm-6">
                      <div class="card">
                        <div class="nk-ecwg nk-ecwg6">
                          <div class="card-inner">
                            <div class="card-title-group">
                              <div class="card-title">
                                <h6 class="title">Today's Revenue</h6>
                              </div>
                            </div>
                            <div class="data">
                              <div class="data-group">
                                <div class="amount">$12,338</div>
                                <div class="nk-ecwg6-ck"><canvas class="ecommerce-line-chart-s3" id="opdIncome"></canvas></div>
                              </div>
                              <div class="info"><span class="change down text-danger"><em class="icon ni ni-arrow-long-down"></em>2.34%</span><span> vs. last week</span></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-xxl-3 col-sm-6">
                      <div class="card">
                        <div class="nk-ecwg nk-ecwg6">
                          <div class="card-inner">
                            <div class="card-title-group">
                              <div class="card-title ">
                                <h6 class="title">Today's Customer</h6>
                              </div>
                            </div>
                            <div class="data">
                              <div class="data-group">
                                <div class="amount">$20,847</div>
                                <div class="nk-ecwg6-ck"><canvas class="ecommerce-line-chart-s3" id="labIncome"></canvas></div>
                              </div>
                              <div class="info"><span class="change up text-danger"><em class="icon ni ni-arrow-long-up"></em>4.63%</span><span> vs. last week</span></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-xxl-3 col-sm-6">
                      <div class="card">
                        <div class="nk-ecwg nk-ecwg6">
                          <div class="card-inner">
                            <div class="card-title-group">
                              <div class="card-title">
                                <h6 class="title">Today's Expense</h6>
                              </div>
                            </div>
                            <div class="data">
                              <div class="data-group">
                                <div class="amount">$23,485</div>
                                <div class="nk-ecwg6-ck"><canvas class="ecommerce-line-chart-s3" id="todayExpense"></canvas></div>
                              </div>
                              <div class="info"><span class="change up text-primary"><em class="icon ni ni-arrow-long-down"></em>1.34%</span><span> vs. last week</span></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-xxl-4 col-md-6">
                      <div class="card is-dark h-100">
                        <div class="nk-ecwg nk-ecwg1">
                          <div class="card-inner">
                            <div class="card-title-group">
                              <div class="card-title">
                                <h6 class="title">Total Sales</h6>
                              </div>
                              <div class="card-tools"><a href="#" class="link">View Report</a></div>
                            </div>
                            <div class="data">
                              <div class="amount">$74,958.49</div>
                              <div class="info"><strong>$7,395.37</strong> in last month</div>
                            </div>
                            <div class="data">
                              <h6 class="sub-title">This week so far</h6>
                              <div class="data-group">
                                <div class="amount">$1,338.72</div>
                                <div class="info text-right"><span class="change up text-danger"><em class="icon ni ni-arrow-long-up"></em>4.63%</span><br><span>vs. last week</span></div>
                              </div>
                            </div>
                          </div>
                          <div class="nk-ecwg1-ck">
                            <canvas class="ecommerce-line-chart-s1" id="totalSales"></canvas></div>
                        </div>
                      </div>
                    </div>
                  <?php endif; ?>
                  <div class="col-xxl-5 col-md-6">
                      <div class="card card-full">
                        <div class="nk-ecwg nk-ecwg8 h-100">
                          <div class="card-inner">
                            <div class="card-title-group mb-3">
                              <div class="card-title">
                                <h6 class="title">Store Visitors</h6>
                              </div>
                              <div class="card-tools">
                                <div class="dropdown"><a href="#" class="dropdown-toggle link link-light link-sm dropdown-indicator" data-bs-toggle="dropdown">Weekly</a>
                                  <div class="dropdown-menu dropdown-menu-sm dropdown-menu-end">
                                    <ul class="link-list-opt no-bdr">
                                      <li><a href="#"><span>Daily</span></a></li>
                                      <li><a href="#" class="active"><span>Weekly</span></a></li>
                                      <li><a href="#"><span>Monthly</span></a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <ul class="nk-ecwg8-legends">
                              <li>
                                <div class="title"><span class="dot dot-lg sq" data-bg="#0fac81" style="background: rgb(15, 172, 129);"></span><span>Physically</span></div>
                              </li>
                              <li>
                                <div class="title"><span class="dot dot-lg sq" data-bg="#eb6459" style="background: rgb(235, 100, 89);"></span><span>Online</span></div>
                              </li>
                            </ul>
                            <div class="nk-ecwg8-ck"><canvas class="ecommerce-line-chart-s4" id="salesStatistics" width="434" height="179" style="display: block; box-sizing: border-box; height: 200px; width: 482px;"></canvas></div>
                            <div class="chart-label-group ps-5">
                              <div class="chart-label">01 Jul, 2020</div>
                              <div class="chart-label">30 Jul, 2020</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-xxl-3 col-md-6">
                      <div class="card h-100">
                        <div class="card-inner">
                          <div class="card-title-group mb-2">
                            <div class="card-title">
                              <h6 class="title">Store Statistics</h6>
                            </div>
                          </div>
                          <ul class="nk-store-statistics">
                            <li class="item">
                              <div class="info">
                                <div class="title">Sales</div>
                                <div class="count">1,795</div>
                              </div><em class="icon bg-primary-dim ni ni-bag"></em>
                            </li>
                            <li class="item">
                              <div class="info">
                                <div class="title">Customers</div>
                                <div class="count">2,327</div>
                              </div><em class="icon bg-info-dim ni ni-users"></em>
                            </li>
                            <li class="item">
                              <div class="info">
                                <div class="title">Products</div>
                                <div class="count">674</div>
                              </div><em class="icon bg-pink-dim ni ni-box"></em>
                            </li>
                            <li class="item">
                              <div class="info">
                                <div class="title">Categories</div>
                                <div class="count">68</div>
                              </div><em class="icon bg-purple-dim ni ni-server"></em>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6 col-xxl-4">
                      <div class="card card-bordered card-full">
                        <div class="card-inner-group">
                          <div class="card-inner">
                            <div class="card-title-group">
                              <div class="card-title">
                                <h6 class="title">New Customers</h6>
                              </div>
                              <div class="card-tools"><a href="" class="link">View All</a></div>
                            </div>
                          </div>
                          <div class="card-inner card-inner-md">
                            <div class="user-card">
                              <div class="user-avatar bg-primary-dim"><span>AB</span></div>
                              <div class="user-info"><span class="lead-text">Abu Bin Ishtiyak</span><span class="sub-text">info@softnio.com</span></div>
                              <div class="user-action">
                                <div class="dropdown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger me-n1" data-bs-toggle="dropdown" aria-expanded="false"><em class="icon ni ni-more-h"></em></a>
                                  <div class="dropdown-menu dropdown-menu-end">
                                    <ul class="link-list-opt no-bdr">
                                      <li><a href="/PMS/settings"><em class="icon ni ni-setting"></em><span>Action Settings</span></a></li>
                                      <li><a href="#"><em class="icon ni ni-notify"></em><span>Push Notification</span></a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="card-inner card-inner-md">
                            <div class="user-card">
                              <div class="user-avatar bg-pink-dim"><span>SW</span></div>
                              <div class="user-info"><span class="lead-text">Sharon Walker</span><span class="sub-text">sharon-90@example.com</span></div>
                              <div class="user-action">
                                <div class="dropdown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger me-n1" data-bs-toggle="dropdown" aria-expanded="false"><em class="icon ni ni-more-h"></em></a>
                                  <div class="dropdown-menu dropdown-menu-end">
                                    <ul class="link-list-opt no-bdr">
                                      <li><a href="/PMS/settings"><em class="icon ni ni-setting"></em><span>Action Settings</span></a></li>
                                      <li><a href="#"><em class="icon ni ni-notify"></em><span>Push Notification</span></a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="card-inner card-inner-md">
                            <div class="user-card">
                              <div class="user-avatar bg-warning-dim"><span>GO</span></div>
                              <div class="user-info"><span class="lead-text">Gloria Oliver</span><span class="sub-text">gloria_72@example.com</span></div>
                              <div class="user-action">
                                <div class="dropdown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger me-n1" data-bs-toggle="dropdown" aria-expanded="false"><em class="icon ni ni-more-h"></em></a>
                                  <div class="dropdown-menu dropdown-menu-end">
                                    <ul class="link-list-opt no-bdr">
                                      <li><a href="/PMS/settings"><em class="icon ni ni-setting"></em><span>Action Settings</span></a></li>
                                      <li><a href="#"><em class="icon ni ni-notify"></em><span>Push Notification</span></a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="card-inner card-inner-md">
                            <div class="user-card">
                              <div class="user-avatar bg-success-dim"><span>PS</span></div>
                              <div class="user-info"><span class="lead-text">Phillip Sullivan</span><span class="sub-text">phillip-85@example.com</span></div>
                              <div class="user-action">
                                <div class="dropdown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger me-n1" data-bs-toggle="dropdown" aria-expanded="false"><em class="icon ni ni-more-h"></em></a>
                                  <div class="dropdown-menu dropdown-menu-end">
                                    <ul class="link-list-opt no-bdr">
                                      <li><a href="/PMS/settings"><em class="icon ni ni-setting"></em><span>Action Settings</span></a></li>
                                      <li><a href="#"><em class="icon ni ni-notify"></em><span>Push Notification</span></a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="col-xxl-8">
                      <div class="card card-bordered card-full">
                        <div class="card-inner">
                          <div class="card-title-group">
                            <div class="card-title">
                              <h6 class="title"><span class="me-2">Transaction</span> <a href="#" class="link d-none d-sm-inline">See History</a></h6>
                            </div>
                            <div class="card-tools">
                              <ul class="card-tools-nav">
                                <li><a href="#"><span>Paid</span></a></li>
                                <li><a href="#"><span>Pending</span></a></li>
                                <li class="active"><a href="#"><span>All</span></a></li>
                              </ul>
                            </div>
                          </div>
                        </div>
                        <div class="card-inner p-0 border-top">
                          <div class="nk-tb-list nk-tb-orders">
                            <div class="nk-tb-item nk-tb-head">
                              <div class="nk-tb-col"><span>Invoice No</span></div>
                              <div class="nk-tb-col tb-col-sm"><span>Customer</span></div>
                              <div class="nk-tb-col tb-col-md"><span>Date</span></div>
                              <div class="nk-tb-col tb-col-lg"><span>Ref</span></div>
                              <div class="nk-tb-col"><span>Amount</span></div>
                              <div class="nk-tb-col"><span class="d-none d-sm-inline">Status</span></div>
                              <div class="nk-tb-col"><span>&nbsp;</span></div>
                            </div>
                            <div class="nk-tb-item">
                              <div class="nk-tb-col"><span class="tb-lead"><a href="#">#95954</a></span></div>
                              <div class="nk-tb-col tb-col-sm">
                                <div class="user-card">
                                  <div class="user-avatar user-avatar-sm bg-purple"><span>AB</span></div>
                                  <div class="user-name"><span class="tb-lead">Abu Bin Ishtiyak</span></div>
                                </div>
                              </div>
                              <div class="nk-tb-col tb-col-md"><span class="tb-sub">02/11/2020</span></div>
                              <div class="nk-tb-col tb-col-lg"><span class="tb-sub text-primary">SUB-2309232</span></div>
                              <div class="nk-tb-col"><span class="tb-sub tb-amount">4,596.75 <span>USD</span></span></div>
                              <div class="nk-tb-col"><span class="badge badge-dot badge-dot-xs text-success">Paid</span></div>
                              <div class="nk-tb-col nk-tb-col-action">
                                <div class="dropdown"><a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                  <div class="dropdown-menu dropdown-menu-end dropdown-menu-xs">
                                    <ul class="link-list-plain">
                                      <li><a href="#">View</a></li>
                                      <li><a href="#">Invoice</a></li>
                                      <li><a href="#">Print</a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="nk-tb-item">
                              <div class="nk-tb-col"><span class="tb-lead"><a href="#">#95812</a></span></div>
                              <div class="nk-tb-col tb-col-sm">
                                <div class="user-card">
                                  <div class="user-avatar user-avatar-sm bg-warning"><img loading="lazy" src="Public/assets/images/avatar/b-sm.jpg" alt=""></div>
                                  <div class="user-name"><span class="tb-lead">Blanca Schultz</span></div>
                                </div>
                              </div>
                              <div class="nk-tb-col tb-col-md"><span class="tb-sub">02/01/2020</span></div>
                              <div class="nk-tb-col tb-col-lg"><span class="tb-sub text-primary">SUB-2309143</span></div>
                              <div class="nk-tb-col"><span class="tb-sub tb-amount">199.99 <span>USD</span></span></div>
                              <div class="nk-tb-col"><span class="badge badge-dot badge-dot-xs text-success">Paid</span></div>
                              <div class="nk-tb-col nk-tb-col-action">
                                <div class="dropdown"><a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                  <div class="dropdown-menu dropdown-menu-end dropdown-menu-xs">
                                    <ul class="link-list-plain">
                                      <li><a href="#">View</a></li>
                                      <li><a href="#">Invoice</a></li>
                                      <li><a href="#">Print</a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="nk-tb-item">
                              <div class="nk-tb-col"><span class="tb-lead"><a href="#">#95256</a></span></div>
                              <div class="nk-tb-col tb-col-sm">
                                <div class="user-card">
                                  <div class="user-avatar user-avatar-sm bg-purple"><span>NL</span></div>
                                  <div class="user-name"><span class="tb-lead">Naomi Lawrence</span></div>
                                </div>
                              </div>
                              <div class="nk-tb-col tb-col-md"><span class="tb-sub">01/29/2020</span></div>
                              <div class="nk-tb-col tb-col-lg"><span class="tb-sub text-primary">SUB-2305684</span></div>
                              <div class="nk-tb-col"><span class="tb-sub tb-amount">1099.99 <span>USD</span></span></div>
                              <div class="nk-tb-col"><span class="badge badge-dot badge-dot-xs text-success">Paid</span></div>
                              <div class="nk-tb-col nk-tb-col-action">
                                <div class="dropdown"><a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                  <div class="dropdown-menu dropdown-menu-end dropdown-menu-xs">
                                    <ul class="link-list-plain">
                                      <li><a href="#">View</a></li>
                                      <li><a href="#">Invoice</a></li>
                                      <li><a href="#">Print</a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="nk-tb-item">
                              <div class="nk-tb-col"><span class="tb-lead"><a href="#">#95135</a></span></div>
                              <div class="nk-tb-col tb-col-sm">
                                <div class="user-card">
                                  <div class="user-avatar user-avatar-sm bg-success"><span>CH</span></div>
                                  <div class="user-name"><span class="tb-lead">Cassandra Hogan</span></div>
                                </div>
                              </div>
                              <div class="nk-tb-col tb-col-md"><span class="tb-sub">01/29/2020</span></div>
                              <div class="nk-tb-col tb-col-lg"><span class="tb-sub text-primary">SUB-2305564</span></div>
                              <div class="nk-tb-col"><span class="tb-sub tb-amount">1099.99 <span>USD</span></span></div>
                              <div class="nk-tb-col"><span class="badge badge-dot badge-dot-xs text-warning">Due</span></div>
                              <div class="nk-tb-col nk-tb-col-action">
                                <div class="dropdown"><a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                  <div class="dropdown-menu dropdown-menu-end dropdown-menu-xs">
                                    <ul class="link-list-plain">
                                      <li><a href="#">View</a></li>
                                      <li><a href="#">Invoice</a></li>
                                      <li><a href="#">Notify</a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="card-inner-sm border-top text-center d-sm-none"><a href="#" class="btn btn-link btn-block">See History</a></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- right Sidebar  starts -->
      <?php require('partials/rightnav.php') ?>
      <!--right  Sidebar  ends -->
  
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="Public/assets/js/bundle9b70.js?ver=<?php echo time(); ?>"></script>
  <script src="Public/assets/js/scripts9b70.js?ver=<?php echo time(); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="Public/assets/js/charts/gd-pharmacy9b70.js?ver=<?php echo time(); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/js-cookie@3.0.5/dist/js.cookie.min.js"></script>
  <script src="Public/assets/js/demo-settings9b70.js?ver=<?php echo time(); ?>"></script>

</body>
</html>