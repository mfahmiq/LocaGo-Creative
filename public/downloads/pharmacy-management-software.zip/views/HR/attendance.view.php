<?php include __DIR__ . '/../partials/head.php' ?>
<body class="nk-body ui-rounder npc-default has-sidebar ">
  <div class="nk-app-root">
   <!-- Sidebar wrapper starts -->
      <?php include __DIR__ . '/../partials/Sidenav.php' ?>
      <!-- Sidebar wrapper ends -->
    <div class="nk-main ">
      <div class="nk-wrap ">
      <!-- App header start -->
        <?php include __DIR__ . '/../partials/header.php' ?>
                <!-- App header ends -->
        <div class="nk-content ">
          <div class="container-fluid">
            <div class="nk-content-inner">
              <div class="nk-content-body">
                   <!-- App top-nav start -->
            <?php include __DIR__ . '/../partials/TopNav.php' ?>
                <!-- App top-nav ends -->
                <div class="nk-block">
                  <div class="row gy-5">
                    <div class="col-lg-12">
                      <div class="nk-block-head">
                        <div class="nk-block-head-content">
                          <h5 class="nk-block-title title">Add an attendence</h5>
                        </div>
                      </div>
                      <div class="card card-bordered">
                        <div class="card-inner">
                          <form action="#">
                            <div class="row gy-4">
                              <div class="col-xxl-4 col-sm-6">
                                <div class="form-group"><label class="form-label" for="member">Member</label><input type="text" class="form-control" id="member" placeholder="Member" required></div>
                              </div>
                              <div class="col-xxl-4 col-sm-6">
                                <div class="form-group"><label class="form-label">Date</label>
                                  <div class="form-control-wrap">
                                    <div class="form-icon form-icon-right"><em class="icon ni ni-calendar"></em></div><input type="text" class="form-control date-picker" data-date-format="yyyy-mm-dd" placeholder="yyyy-mm-dd">
                                  </div>
                                </div>
                              </div>
                              <div class="col-xxl-4 col-sm-6">
                                <div class="form-group"><label class="form-label">Sign In</label>
                                  <div class="form-control-wrap"><input type="text" class="form-control time-picker" placeholder="06.00 AM"></div>
                                </div>
                              </div>
                              <div class="col-12">
                                <div class="form-group">
                                  <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                    <li><button type="submit" id="demo-lock-btn14" class="btn btn-primary ">Save Information</button></li>
                                    <li><button data-bs-dismiss="modal" class="btn btn-danger">Cancel</button></li>
                                  </ul>
                                </div>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-12">
                      <div class="nk-block-head">
                        <div class="nk-block-head-content">
                          <h5 class="nk-block-title title">Attendence List</h5>
                        </div>
                      </div>
                      <div class="nk-block">
                        <div class="card card-bordered card-stretch">
                          <div class="card-inner-group">
                            <div class="card-inner position-relative card-tools-toggle">
                              <div class="card-title-group">
                                <div class="card-tools">
                                  <div class="form-control-wrap">
                                    <div class="input-daterange date-picker-range input-group"><input type="text" class="form-control" placeholder="Start Date" />
                                      <div class="input-group-addon">TO</div><input type="text" class="form-control" placeholder="End Date" />
                                    </div>
                                  </div>
                                </div>
                                <div class="card-tools me-n1">
                                  <ul class="btn-toolbar gx-1">
                                    <li><a href="#" class="btn btn-icon search-toggle toggle-search" data-target="search"><em class="icon ni ni-search"></em></a></li>
                                  </ul>
                                </div>
                                <div class="card-search search-wrap" data-search="search">
                                  <div class="card-body">
                                    <div class="search-content"><a href="#" class="search-back btn btn-icon toggle-search" data-target="search"><em class="icon ni ni-arrow-left"></em></a><input type="text" class="form-control border-transparent form-focus-none" placeholder="Search by name"><button class="search-submit btn btn-icon"><em class="icon ni ni-search"></em></button></div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="card-inner p-0">
                              <div class="nk-tb-list nk-tb-ulist">
                                <div class="nk-tb-item nk-tb-head  bg-lighter">
                                  <div class="nk-tb-col"><span class="sub-text">Member</span></div>
                                  <div class="nk-tb-col tb-col-sm"><span class="sub-text">Date</span></div>
                                  <div class="nk-tb-col tb-col-md"><span class="sub-text">Sign In</span></div>
                                  <div class="nk-tb-col tb-col-md"><span class="sub-text">Sign Out</span></div>
                                  <div class="nk-tb-col"><span class="sub-text">Stay Time</span></div>
                                  <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-1 my-n1">
                                      <li>
                                        <div class="drodown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger me-n1" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                          <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                              <li><a data-bs-toggle="modal" href="#editAttendence"><em class="icon ni ni-edit"></em><span>Edit Selected</span></a></li>
                                              <li><a data-bs-toggle="modal" href="#modalDelete"><em class="icon ni ni-trash"></em><span>Remove Selected</span></a></li>
                                            </ul>
                                          </div>
                                        </div>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="nk-tb-item">
                                  <div class="nk-tb-col"><a href="#">
                                      <div class="user-card">
                                        <div class="user-info"><span class="tb-lead">Abu Bin Ishtiyak</span></div>
                                      </div>
                                    </a></div>
                                  <div class="nk-tb-col tb-col-sm"><span>19/12/2020</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>09:00 am</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>06:00 am</span></div>
                                  <div class="nk-tb-col"><span class="badge badge-dim bg-danger">9hr 0min</span></div>
                                  <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-1">
                                      <li>
                                        <div class="drodown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                          <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                              <li><a data-bs-toggle="modal" href="#editAttendence"><em class="icon ni ni-edit"></em><span>Edit</span></a></li>
                                              <li><a data-bs-toggle="modal" href="#modalDelete"><em class="icon ni ni-trash"></em><span>Remove</span></a></li>
                                            </ul>
                                          </div>
                                        </div>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="nk-tb-item">
                                  <div class="nk-tb-col"><a href="#">
                                      <div class="user-card">
                                        <div class="user-info"><span class="tb-lead">Ashley Lawson</span></div>
                                      </div>
                                    </a></div>
                                  <div class="nk-tb-col tb-col-sm"><span>17/05/2021</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>08:43 am</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>06:10 am</span></div>
                                  <div class="nk-tb-col"><span class="badge badge-dim bg-primary">9hr 27min</span></div>
                                  <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-1">
                                      <li>
                                        <div class="drodown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                          <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                              <li><a data-bs-toggle="modal" href="#editAttendence"><em class="icon ni ni-edit"></em><span>Edit</span></a></li>
                                              <li><a data-bs-toggle="modal" href="#modalDelete"><em class="icon ni ni-trash"></em><span>Remove</span></a></li>
                                            </ul>
                                          </div>
                                        </div>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="nk-tb-item">
                                  <div class="nk-tb-col"><a href="#">
                                      <div class="user-card">
                                        <div class="user-info"><span class="tb-lead">Joe Larson </span></div>
                                      </div>
                                    </a></div>
                                  <div class="nk-tb-col tb-col-sm"><span>19/12/2020</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>08:40 am</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>06:02 am</span></div>
                                  <div class="nk-tb-col"><span class="badge badge-dim bg-success">9hr 22min</span></div>
                                  <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-1">
                                      <li>
                                        <div class="drodown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                          <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                              <li><a data-bs-toggle="modal" href="#editAttendence"><em class="icon ni ni-edit"></em><span>Edit</span></a></li>
                                              <li><a data-bs-toggle="modal" href="#modalDelete"><em class="icon ni ni-trash"></em><span>Remove</span></a></li>
                                            </ul>
                                          </div>
                                        </div>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="nk-tb-item">
                                  <div class="nk-tb-col"><a href="#">
                                      <div class="user-card">
                                        <div class="user-info"><span class="tb-lead">Jane Montgomery</span></div>
                                      </div>
                                    </a></div>
                                  <div class="nk-tb-col tb-col-sm"><span>02/04/2021</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>08:55 am</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>06:00 am</span></div>
                                  <div class="nk-tb-col"><span class="badge badge-dim bg-danger">8hr 55min</span></div>
                                  <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-1">
                                      <li>
                                        <div class="drodown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                          <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                              <li><a data-bs-toggle="modal" href="#editAttendence"><em class="icon ni ni-edit"></em><span>Edit</span></a></li>
                                              <li><a data-bs-toggle="modal" href="#modalDelete"><em class="icon ni ni-trash"></em><span>Remove</span></a></li>
                                            </ul>
                                          </div>
                                        </div>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="nk-tb-item">
                                  <div class="nk-tb-col"><a href="#">
                                      <div class="user-card">
                                        <div class="user-info"><span class="tb-lead">Frances Burns</span></div>
                                      </div>
                                    </a></div>
                                  <div class="nk-tb-col tb-col-sm"><span>01/05/2022</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>08:58 am</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>06:20 am</span></div>
                                  <div class="nk-tb-col"><span class="badge badge-dim bg-warning">9hr 18min</span></div>
                                  <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-1">
                                      <li>
                                        <div class="drodown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                          <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                              <li><a data-bs-toggle="modal" href="#editAttendence"><em class="icon ni ni-edit"></em><span>Edit</span></a></li>
                                              <li><a data-bs-toggle="modal" href="#modalDelete"><em class="icon ni ni-trash"></em><span>Remove</span></a></li>
                                            </ul>
                                          </div>
                                        </div>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="nk-tb-item">
                                  <div class="nk-tb-col"><a href="#">
                                      <div class="user-card">
                                        <div class="user-info"><span class="tb-lead">Alan Butler </span></div>
                                      </div>
                                    </a></div>
                                  <div class="nk-tb-col tb-col-sm"><span>07/07/2022</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>09:04 am</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>06:30 am</span></div>
                                  <div class="nk-tb-col"><span class="badge badge-dim bg-info">9hr 26min</span></div>
                                  <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-1">
                                      <li>
                                        <div class="drodown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                          <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                              <li><a data-bs-toggle="modal" href="#editAttendence"><em class="icon ni ni-edit"></em><span>Edit</span></a></li>
                                              <li><a data-bs-toggle="modal" href="#modalDelete"><em class="icon ni ni-trash"></em><span>Remove</span></a></li>
                                            </ul>
                                          </div>
                                        </div>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="nk-tb-item">
                                  <div class="nk-tb-col"><a href="#">
                                      <div class="user-card">
                                        <div class="user-info"><span class="tb-lead">Victoria Lynch </span></div>
                                      </div>
                                    </a></div>
                                  <div class="nk-tb-col tb-col-sm"><span>19/12/2020</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>08:55 am</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>06:00 am</span></div>
                                  <div class="nk-tb-col"><span class="badge badge-dim bg-dark">9hr 25min</span></div>
                                  <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-1">
                                      <li>
                                        <div class="drodown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                          <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                              <li><a data-bs-toggle="modal" href="#editAttendence"><em class="icon ni ni-edit"></em><span>Edit</span></a></li>
                                              <li><a data-bs-toggle="modal" href="#modalDelete"><em class="icon ni ni-trash"></em><span>Remove</span></a></li>
                                            </ul>
                                          </div>
                                        </div>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="nk-tb-item">
                                  <div class="nk-tb-col"><a href="#">
                                      <div class="user-card">
                                        <div class="user-info"><span class="tb-lead">Patrick Newman</span></div>
                                      </div>
                                    </a></div>
                                  <div class="nk-tb-col tb-col-sm"><span>03/04/2021</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>09:20 am</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>06:40 am</span></div>
                                  <div class="nk-tb-col"><span class="badge badge-dim bg-success">9hr 20min</span></div>
                                  <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-1">
                                      <li>
                                        <div class="drodown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                          <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                              <li><a data-bs-toggle="modal" href="#editAttendence"><em class="icon ni ni-edit"></em><span>Edit</span></a></li>
                                              <li><a data-bs-toggle="modal" href="#modalDelete"><em class="icon ni ni-trash"></em><span>Remove</span></a></li>
                                            </ul>
                                          </div>
                                        </div>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="nk-tb-item">
                                  <div class="nk-tb-col"><a href="#">
                                      <div class="user-card">
                                        <div class="user-info"><span class="tb-lead">Jane Harris</span></div>
                                      </div>
                                    </a></div>
                                  <div class="nk-tb-col tb-col-sm"><span>02/04/2022</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>09:00 am</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>06:00 am</span></div>
                                  <div class="nk-tb-col"><span class="badge badge-dim bg-warning">9hr 0min</span></div>
                                  <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-1">
                                      <li>
                                        <div class="drodown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                          <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                              <li><a data-bs-toggle="modal" href="#editAttendence"><em class="icon ni ni-edit"></em><span>Edit</span></a></li>
                                              <li><a data-bs-toggle="modal" href="#modalDelete"><em class="icon ni ni-trash"></em><span>Remove</span></a></li>
                                            </ul>
                                          </div>
                                        </div>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="nk-tb-item">
                                  <div class="nk-tb-col"><a href="#">
                                      <div class="user-card">
                                        <div class="user-info"><span class="tb-lead">Emma Walker</span></div>
                                      </div>
                                    </a></div>
                                  <div class="nk-tb-col tb-col-sm"><span>12/12/2021</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>08:52 am</span></div>
                                  <div class="nk-tb-col tb-col-md"><span>06:00 am</span></div>
                                  <div class="nk-tb-col"><span class="badge badge-dim bg-gray">8hr 58min</span></div>
                                  <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-1">
                                      <li>
                                        <div class="drodown"><a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                          <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                              <li><a data-bs-toggle="modal" href="#editAttendence"><em class="icon ni ni-edit"></em><span>Edit</span></a></li>
                                              <li><a data-bs-toggle="modal" href="#modalDelete"><em class="icon ni ni-trash"></em><span>Remove</span></a></li>
                                            </ul>
                                          </div>
                                        </div>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="card-inner">
                              <div class="nk-block-between-md g-3">
                                <div class="g">
                                  <ul class="pagination justify-content-center justify-content-md-start">
                                    <li class="page-item"><a class="page-link" href="#">Prev</a></li>
                                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><span class="page-link"><em class="icon ni ni-more-h"></em></span></li>
                                    <li class="page-item"><a class="page-link" href="#">6</a></li>
                                    <li class="page-item"><a class="page-link" href="#">7</a></li>
                                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                  </ul>
                                </div>
                                <div class="g">
                                  <div class="pagination-goto d-flex justify-content-center justify-content-md-start gx-3">
                                    <div>Page</div>
                                    <div><select class="form-select form-select-sm js-select2" data-search="on" data-dropdown="xs center">
                                        <option value="page-1">1</option>
                                        <option value="page-2">2</option>
                                        <option value="page-4">4</option>
                                        <option value="page-5">5</option>
                                        <option value="page-6">6</option>
                                        <option value="page-7">7</option>
                                        <option value="page-8">8</option>
                                        <option value="page-9">9</option>
                                        <option value="page-10">10</option>
                                        <option value="page-11">11</option>
                                        <option value="page-12">12</option>
                                        <option value="page-13">13</option>
                                        <option value="page-14">14</option>
                                        <option value="page-15">15</option>
                                        <option value="page-16">16</option>
                                        <option value="page-17">17</option>
                                        <option value="page-18">18</option>
                                        <option value="page-19">19</option>
                                        <option value="page-20">20</option>
                                      </select></div>
                                    <div>OF 102</div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="modal fade" tabindex="-1" id="modalDelete">
    <div class="modal-dialog" role="document">
      <div class="modal-content"><a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross"></em></a>
        <div class="modal-body modal-body-lg text-center">
          <div class="nk-modal py-4"><em class="nk-modal-icon icon icon-circle icon-circle-xxl ni ni-cross bg-danger"></em>
            <h4 class="nk-modal-title">Are You Sure ?</h4>
            <div class="nk-modal-text mt-n2">
              <p class="text-soft">This event data will be removed permanently.</p>
            </div>
            <ul class="d-flex justify-content-center gx-4 mt-4">
              <li><button data-bs-dismiss="modal" id="deleteEvent" class="btn btn-success">Yes, Delete it</button></li>
              <li><button data-bs-dismiss="modal" data-bs-toggle="modal" data-bs-target="#editEventPopup" class="btn btn-danger btn-dim">Cancel</button></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="modal fade" tabindex="-1" role="dialog" id="editAttendence">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content"><a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
        <div class="modal-body modal-body-md">
          <h5 class="modal-title">Edit Attendance</h5>
          <form action="#" class="mt-4">
            <div class="row g-gs">
              <div class="col-md-6">
                <div class="form-group"><label class="form-label" for="member">Member</label><input type="text" class="form-control" id="member" placeholder="Member" required></div>
              </div>
              <div class="col-md-6">
                <div class="form-group"><label class="form-label">Date</label>
                  <div class="form-control-wrap">
                    <div class="form-icon form-icon-right"><em class="icon ni ni-calendar"></em></div><input type="text" class="form-control date-picker" data-date-format="yyyy-mm-dd" placeholder="yyyy-mm-dd">
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group"><label class="form-label">Sign In</label>
                  <div class="form-control-wrap"><input type="text" class="form-control time-picker" placeholder="06.00 AM"></div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group"><label class="form-label">Sign Out</label>
                  <div class="form-control-wrap"><input type="text" class="form-control time-picker" placeholder="06.00 AM"></div>
                </div>
              </div>
              <div class="col-12">
                <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                  <li><a href="#" id="demo-lock-btn15" data-bs-dismiss="modal" class="btn btn-primary">Edit Attendance</a></li>
                  <li><a href="#" data-bs-dismiss="modal" class="link link-light">Cancel</a></li>
                </ul>
              </div>
            </div>
        </div>
        </form>
      </div>
    </div>
  </div>

 <!-- right Sidebar  starts -->
    <?php include __DIR__ . '/../partials/rightnav.php' ?>
      <!--right  Sidebar  ends -->  
  <script src="Public/assets/js/bundle9b70.js?ver=3.3.0"></script>
  <script src="Public/assets/js/scripts9b70.js?ver=3.3.0"></script>
  <script src="Public/assets/js/demo-settings9b70.js?ver=3.3.0"></script>

  <script>
  document.addEventListener('DOMContentLoaded', function () {
    const demoAlert = "⚠️ This is a demo version.\nTo get full access, please purchase the product.\nContact us: info@relicedge.com";

   
    const buttonIds = [
      'demo-lock-btn14',
      'demo-lock-btn15',  
    ];

    buttonIds.forEach(id => {
      const btn = document.getElementById(id);
      if (btn) {
        btn.addEventListener('click', function (e) {
          e.preventDefault();
          alert(demoAlert);
        });
      }
    });
  });
</script>
</body>
</html>