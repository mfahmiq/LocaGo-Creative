<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\SPKController;
use App\Http\Controllers\KriteriaController;
use App\Http\Controllers\AlternatifController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Temporary route to run migration
Route::get('/run-migrate', function () {
    \Illuminate\Support\Facades\Artisan::call('migrate', ['--force' => true]);
    return 'Migrasi berhasil dijalankan! Silakan kembali ke aplikasi dan coba import lagi.';
});

// Auth Routes
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Protected Routes
Route::middleware(['auth'])->group(function () {
    Route::get('/', [SPKController::class, 'dashboard'])->name('dashboard');
    Route::get('/hitung', [SPKController::class, 'hitung'])->name('hitung.index');
    Route::post('/hitung/simpan', [SPKController::class, 'simpanHasil'])->name('hitung.simpan');
    Route::get('/hitung/excel', [SPKController::class, 'exportExcel'])->name('hitung.excel');

    Route::resource('kriteria', KriteriaController::class)
        ->parameters(['kriteria' => 'kriteria'])
        ->only(['index', 'store', 'update', 'destroy']);
        
    Route::get('/alternatif/template', [AlternatifController::class, 'template'])->name('alternatif.template');
    Route::post('/alternatif/import', [AlternatifController::class, 'import'])->name('alternatif.import');
    Route::resource('alternatif', AlternatifController::class)
        ->parameters(['alternatif' => 'alternatif'])
        ->only(['index', 'store', 'update', 'destroy']);
    
    Route::get('/penilaian', [SPKController::class, 'penilaian'])->name('penilaian.index');
    Route::post('/penilaian', [SPKController::class, 'storePenilaian'])->name('penilaian.store');
});
