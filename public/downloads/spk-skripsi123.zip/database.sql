-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 13 Jun 2026 pada 05.57
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spk_saw`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `alternatifs`
--

CREATE TABLE `alternatifs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) NOT NULL,
  `keterangan` text DEFAULT NULL,
  `topik` enum('Pemrograman Web','Data Mining','Kecerdasan Buatan (AI)','Internet of Things (IoT)') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `alternatifs`
--

INSERT INTO `alternatifs` (`id`, `nama`, `keterangan`, `topik`, `created_at`, `updated_at`) VALUES
(1, 'Budi Santoso', 'Pengembangan Aplikasi Mobile untuk Manajemen Inventaris menggunakan Teknologi Barcode', 'Pemrograman Web', '2025-12-06 00:34:23', '2025-12-06 19:28:22'),
(2, 'Siti Aminah', 'Analisis Sentimen pada Data Media Sosial menggunakan Teknik Natural Language Processing', 'Data Mining', '2025-12-06 00:34:23', '2025-12-06 19:28:44'),
(3, 'Rudi Hermawan', 'Pengembangan Aplikasi E-learning dengan Fitur Interaktif dan Adaptive Learning', 'Kecerdasan Buatan (AI)', '2025-12-06 00:34:23', '2025-12-06 19:29:15'),
(4, 'Dewi Lestari', 'Analisis Performa Algoritma Machine Learning dalam Deteksi Intrusi pada Jaringan IoT', 'Internet of Things (IoT)', '2025-12-06 00:34:23', '2025-12-06 19:30:01'),
(5, 'Andi Wijaya', 'Pengembangan Aplikasi Mobile untuk Sistem Manajemen Keuangan Personal', 'Pemrograman Web', '2025-12-06 00:34:23', '2025-12-06 19:30:19'),
(6, 'Ridwan Arifin', 'Implementasi Sistem Manajemen Pembelajaran Berbasis Web untuk Meningkatkan Efisiensi Proses Belajar Mengajar di Pendidikan Teknik Informatika', 'Pemrograman Web', '2025-12-29 02:43:41', '2025-12-29 02:43:41'),
(8, 'Marwahdah', 'Aplikasi Pendeteksi Kehadiran Mahasiswa Menggunakan QR Code Berbasis Android', 'Internet of Things (IoT)', '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(9, 'Lintang', 'Deteksi Wajah dan Emosi Menggunakan Deep Learning untuk Aplikasi Smart Home', 'Kecerdasan Buatan (AI)', '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(10, 'Fena', 'Analisis Data Transaksi E-Commerce Menggunakan Data Mining', 'Data Mining', '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(11, 'Syawal', 'Sistem Kendali Robot Menggunakan Raspberry Pi Berbasis Wireless', 'Internet of Things (IoT)', '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(12, 'Dontera', 'Aplikasi Konsultasi Online untuk Pelajar Berbasis Web dengan Fitur Chatbot', 'Pemrograman Web', '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(13, 'Surata', 'Prediksi Kinerja Mahasiswa Menggunakan Data Mining di Universitas XYZ', 'Data Mining', '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(14, 'Bambang', 'Pengembangan Database Perguruan Tinggi Berbasis Web', 'Pemrograman Web', '2026-05-21 06:58:21', '2026-05-21 06:58:21');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kriterias`
--

CREATE TABLE `kriterias` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kode` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `bobot` double NOT NULL,
  `jenis` enum('benefit','cost') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `kriterias`
--

INSERT INTO `kriterias` (`id`, `kode`, `nama`, `bobot`, `jenis`, `created_at`, `updated_at`) VALUES
(1, 'C1', 'Nilai Akademik Mata Kuliah', 0.25, 'benefit', '2025-12-06 00:22:50', '2026-06-02 23:18:49'),
(2, 'C2', 'Minat Mahasiswa', 0.2, 'benefit', '2025-12-06 00:22:50', '2026-06-02 23:19:08'),
(3, 'C3', 'Keahlian Penelitian', 0.1, 'benefit', '2025-12-06 00:22:50', '2026-06-09 00:36:23'),
(4, 'C4', 'Tren Penelitian Terkini', 0.15, 'cost', '2025-12-06 00:22:50', '2026-06-09 00:36:35'),
(6, 'C5', 'Ketersediaan Data', 0.2, 'benefit', '2026-06-02 23:20:41', '2026-06-02 23:20:41');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2025_12_06_071434_create_alternatifs_table', 1),
(6, '2025_12_06_071434_create_kriterias_table', 1),
(7, '2025_12_06_071435_create_penilaians_table', 1),
(8, '2025_12_07_022137_add_topik_to_alternatifs_table', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `penilaians`
--

CREATE TABLE `penilaians` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `alternatif_id` bigint(20) UNSIGNED NOT NULL,
  `kriteria_id` bigint(20) UNSIGNED NOT NULL,
  `nilai` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `penilaians`
--

INSERT INTO `penilaians` (`id`, `alternatif_id`, `kriteria_id`, `nilai`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 2, '2025-12-06 00:34:23', '2026-02-13 04:53:34'),
(2, 1, 2, 1.75, '2025-12-06 00:34:23', '2025-12-06 19:41:20'),
(3, 1, 3, 1, '2025-12-06 00:34:23', '2025-12-06 19:41:20'),
(4, 1, 4, 1, '2025-12-06 00:34:23', '2026-06-02 23:22:20'),
(5, 2, 1, 1, '2025-12-06 00:34:23', '2026-02-13 04:53:34'),
(6, 2, 2, 2, '2025-12-06 00:34:23', '2025-12-06 19:41:20'),
(7, 2, 3, 1.75, '2025-12-06 00:34:23', '2025-12-06 19:41:20'),
(8, 2, 4, 1.75, '2025-12-06 00:34:23', '2026-06-02 23:22:20'),
(9, 3, 1, 1.75, '2025-12-06 00:34:23', '2026-02-13 04:53:34'),
(10, 3, 2, 1, '2025-12-06 00:34:23', '2025-12-06 19:41:20'),
(11, 3, 3, 2, '2025-12-06 00:34:23', '2025-12-06 19:41:20'),
(12, 3, 4, 2, '2025-12-06 00:34:23', '2026-06-02 23:22:20'),
(13, 4, 1, 1, '2025-12-06 00:34:23', '2026-02-13 04:53:34'),
(14, 4, 2, 2, '2025-12-06 00:34:23', '2025-12-29 02:45:05'),
(15, 4, 3, 2, '2025-12-06 00:34:23', '2025-12-06 19:17:03'),
(16, 4, 4, 1, '2025-12-06 00:34:23', '2026-06-02 23:22:20'),
(17, 5, 1, 2, '2025-12-06 00:34:23', '2026-02-13 04:53:34'),
(18, 5, 2, 1.75, '2025-12-06 00:34:23', '2025-12-06 19:41:20'),
(19, 5, 3, 2, '2025-12-06 00:34:23', '2025-12-06 19:41:20'),
(20, 5, 4, 0.75, '2025-12-06 00:34:23', '2026-06-02 23:22:20'),
(26, 6, 1, 1.75, '2025-12-29 02:45:05', '2026-02-13 04:53:34'),
(27, 6, 2, 1, '2025-12-29 02:45:05', '2025-12-29 02:45:05'),
(28, 6, 3, 0.75, '2025-12-29 02:45:05', '2025-12-29 02:45:05'),
(29, 6, 4, 1.77, '2025-12-29 02:45:05', '2026-06-02 23:22:20'),
(34, 8, 1, 75.5, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(35, 8, 2, 1.75, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(36, 8, 3, 1, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(37, 8, 4, 1, '2026-05-21 06:58:21', '2026-06-02 23:22:20'),
(38, 9, 1, 84, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(39, 9, 2, 0.75, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(40, 9, 3, 2, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(41, 9, 4, 0.75, '2026-05-21 06:58:21', '2026-06-02 23:22:20'),
(42, 10, 1, 78, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(43, 10, 2, 1, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(44, 10, 3, 1.75, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(45, 10, 4, 1, '2026-05-21 06:58:21', '2026-06-02 23:23:45'),
(46, 11, 1, 87.5, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(47, 11, 2, 2, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(48, 11, 3, 1, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(49, 11, 4, 1.75, '2026-05-21 06:58:21', '2026-06-02 23:23:45'),
(50, 12, 1, 74, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(51, 12, 2, 1, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(52, 12, 3, 2, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(53, 12, 4, 2, '2026-05-21 06:58:21', '2026-06-02 23:23:45'),
(54, 13, 1, 90.5, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(55, 13, 2, 1.75, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(56, 13, 3, 1.75, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(57, 13, 4, 0.75, '2026-05-21 06:58:21', '2026-06-02 23:23:45'),
(58, 14, 1, 86, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(59, 14, 2, 0.75, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(60, 14, 3, 0.75, '2026-05-21 06:58:21', '2026-05-21 06:58:21'),
(61, 14, 4, 1.75, '2026-05-21 06:58:21', '2026-06-02 23:23:45'),
(62, 1, 6, 2, '2026-06-02 23:22:20', '2026-06-02 23:23:45'),
(63, 2, 6, 3, '2026-06-02 23:22:20', '2026-06-02 23:23:45'),
(64, 3, 6, 4, '2026-06-02 23:22:20', '2026-06-02 23:23:45'),
(65, 4, 6, 2, '2026-06-02 23:22:20', '2026-06-02 23:23:45'),
(66, 5, 6, 1, '2026-06-02 23:22:20', '2026-06-02 23:23:45'),
(67, 6, 6, 2, '2026-06-02 23:22:20', '2026-06-02 23:23:45'),
(68, 8, 6, 3, '2026-06-02 23:22:20', '2026-06-02 23:23:45'),
(69, 9, 6, 3, '2026-06-02 23:22:20', '2026-06-02 23:23:45'),
(70, 10, 6, 4, '2026-06-02 23:22:20', '2026-06-02 23:23:45'),
(71, 11, 6, 2, '2026-06-02 23:22:20', '2026-06-02 23:23:45'),
(72, 12, 6, 3, '2026-06-02 23:22:20', '2026-06-02 23:23:45'),
(73, 13, 6, 1, '2026-06-02 23:22:20', '2026-06-02 23:23:45'),
(74, 14, 6, 4, '2026-06-02 23:22:20', '2026-06-02 23:23:45');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hasil_saw`
--

CREATE TABLE `hasil_saw` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `alternatif_id` bigint(20) UNSIGNED NOT NULL,
  `skor_saw` double NOT NULL,
  `peringkat` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','mahasiswa') NOT NULL DEFAULT 'mahasiswa',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 'admin@example.com', NULL, '$2y$10$PTg2kV39NOU3Xor8yFhu6ewfZ8M9tGpA5H8kSlQRYccbiq.bS9nTa', 'admin', NULL, '2025-12-06 00:22:50', '2025-12-06 00:22:50'),
(3, 'Yanoah Aditama', 'Bintang214@gmail.com', NULL, '$2y$10$8WvLCG4ILOwL67UZZTXrBeMBFb3Olrr7cnktqWFz38R1OnxyGeyV2', 'mahasiswa', NULL, '2026-02-22 21:31:24', '2026-04-07 07:55:41');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `alternatifs`
--
ALTER TABLE `alternatifs`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kriterias`
--
ALTER TABLE `kriterias`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indeks untuk tabel `penilaians`
--
ALTER TABLE `penilaians`
  ADD PRIMARY KEY (`id`),
  ADD KEY `penilaians_alternatif_id_foreign` (`alternatif_id`),
  ADD KEY `penilaians_kriteria_id_foreign` (`kriteria_id`);

--
-- Indeks untuk tabel `hasil_saw`
--
ALTER TABLE `hasil_saw`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hasil_saw_alternatif_id_foreign` (`alternatif_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `alternatifs`
--
ALTER TABLE `alternatifs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `kriterias`
--
ALTER TABLE `kriterias`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `penilaians`
--
ALTER TABLE `penilaians`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT untuk tabel `hasil_saw`
--
ALTER TABLE `hasil_saw`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `penilaians`
--
ALTER TABLE `penilaians`
  ADD CONSTRAINT `penilaians_alternatif_id_foreign` FOREIGN KEY (`alternatif_id`) REFERENCES `alternatifs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `penilaians_kriteria_id_foreign` FOREIGN KEY (`kriteria_id`) REFERENCES `kriterias` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `hasil_saw`
--
ALTER TABLE `hasil_saw`
  ADD CONSTRAINT `hasil_saw_alternatif_id_foreign` FOREIGN KEY (`alternatif_id`) REFERENCES `alternatifs` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
