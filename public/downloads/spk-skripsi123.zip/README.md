# SPK SAW — Sistem Pendukung Keputusan (Simple Additive Weighting)

Aplikasi web berbasis **Laravel** untuk Sistem Pendukung Keputusan menggunakan metode **SAW (Simple Additive Weighting)**. Sistem ini digunakan untuk membantu pengambilan keputusan berdasarkan kriteria dan alternatif yang telah ditentukan.

---

## 🛠️ Teknologi

- **Framework**: Laravel 10
- **Database**: MySQL
- **Frontend**: Bootstrap 5
- **Server lokal**: XAMPP (Apache + MySQL) + `php artisan serve`

---

## ⚙️ Cara Instalasi & Menjalankan

```bash
# 1. Clone / download project ke folder htdocs
# 2. Install dependencies
composer install

# 3. Salin file .env
cp .env.example .env

# 4. Generate app key
php artisan key:generate

# 5. Sesuaikan konfigurasi database di .env
DB_DATABASE=spk_saw
DB_USERNAME=root
DB_PASSWORD=

# 6. Jalankan migrasi & seeder
php artisan migrate
php artisan db:seed

# 7. Jalankan server
php artisan serve
```

Akses aplikasi di: **http://127.0.0.1:8000**

---

## 👤 Akun Login Default

> Akun-akun berikut dibuat otomatis melalui `DatabaseSeeder` saat menjalankan `php artisan db:seed`.

### 🔴 Admin

| Field    | Value                   |
|----------|-------------------------|
| Email    | `admin@example.com`     |
| Password | `password`              |
| Role     | `admin`                 |

**Akses Admin:**
- ✅ Dashboard
- ✅ Manajemen Kriteria (tambah, edit, hapus)
- ✅ Manajemen Alternatif (tambah, edit, hapus)
- ✅ Input Penilaian
- ✅ Lihat Hasil Perhitungan SAW

---

### 🔵 Mahasiswa (Akun Default)

| Field    | Value                   |
|----------|-------------------------|
| Email    | `mhs@example.com`       |
| Password | `password`              |
| Role     | `mahasiswa`             |

**Akses Mahasiswa:**
- ✅ Dashboard
- ✅ Lihat Hasil Perhitungan SAW
- ❌ Tidak bisa mengelola Kriteria, Alternatif, dan Penilaian

---

### 🟢 Mahasiswa (Registrasi Mandiri)

Mahasiswa baru dapat mendaftar sendiri melalui halaman registrasi:

**URL:** `http://127.0.0.1:8000/register`

| Field                | Keterangan                        |
|----------------------|-----------------------------------|
| Nama Lengkap         | Bebas (wajib diisi)               |
| Email                | Email unik, belum terdaftar       |
| Password             | Minimal 8 karakter                |
| Konfirmasi Password  | Harus sama dengan password        |
| Role                 | Otomatis `mahasiswa`              |

> ⚠️ Registrasi hanya tersedia untuk role **mahasiswa**. Role **admin** hanya bisa dibuat melalui seeder atau langsung di database.

---

## 🔐 Keamanan Login

- Password disimpan menggunakan **bcrypt hash** (`Hash::make()`)
- Login menggunakan `Auth::attempt()` yang otomatis memverifikasi hash
- Session di-regenerate setelah login untuk mencegah session fixation
- Dilindungi **CSRF token** di setiap form
- Role-based access control menggunakan middleware `CheckRole`

---

## 📁 Struktur Halaman

| URL               | Deskripsi                        | Akses        |
|-------------------|----------------------------------|--------------|
| `/login`          | Halaman login                    | Semua        |
| `/register`       | Halaman registrasi mahasiswa     | Tamu         |
| `/`               | Dashboard utama                  | Login        |
| `/hitung`         | Hasil perhitungan SAW            | Login        |
| `/kriteria`       | Manajemen kriteria               | Admin        |
| `/alternatif`     | Manajemen alternatif             | Admin        |
| `/penilaian`      | Input penilaian                  | Admin        |

---

## 📄 Lisensi

Project ini dibuat untuk keperluan akademik.
