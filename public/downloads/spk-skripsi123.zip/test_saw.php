<?php
require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Alternatif;
use App\Models\Kriteria;
use App\Models\Penilaian;

$alternatifs = Alternatif::with('penilaians.kriteria')->get();
$kriterias = Kriteria::all();

$minMax = [];
foreach ($kriterias as $kriteria) {
    $nilai = Penilaian::where('kriteria_id', $kriteria->id)->pluck('nilai')->toArray();
    if (empty($nilai)) {
        $minMax[$kriteria->id] = ['min' => 0, 'max' => 0];
        continue;
    }
    $minMax[$kriteria->id] = [
        'min' => min($nilai),
        'max' => max($nilai),
    ];
}

$normalized = [];
foreach ($alternatifs as $alternatif) {
    foreach ($kriterias as $kriteria) {
        $penilaian = $alternatif->penilaians->where('kriteria_id', $kriteria->id)->first();
        $nilai = $penilaian ? $penilaian->nilai : 0;
        
        if ($kriteria->jenis == 'benefit') {
            $norm = $minMax[$kriteria->id]['max'] > 0 ? $nilai / $minMax[$kriteria->id]['max'] : 0;
        } else {
            $norm = $nilai > 0 ? $minMax[$kriteria->id]['min'] / $nilai : 0;
        }
        
        $normalized[$alternatif->id][$kriteria->id] = [
            'nilai' => $nilai,
            'norm' => $norm
        ];
    }
}

$ranks = [];
$details = [];
foreach ($alternatifs as $alternatif) {
    $score = 0;
    $detail = [];
    foreach ($kriterias as $kriteria) {
        $val = $normalized[$alternatif->id][$kriteria->id]['norm'] * $kriteria->bobot;
        $score += $val;
        $detail[] = [
            'kriteria' => $kriteria->nama_kriteria,
            'bobot' => $kriteria->bobot,
            'nilai' => $normalized[$alternatif->id][$kriteria->id]['nilai'],
            'norm' => $normalized[$alternatif->id][$kriteria->id]['norm'],
            'val' => $val
        ];
    }
    $ranks[$alternatif->id] = $score;
    $details[$alternatif->nama] = [
        'score' => $score,
        'breakdown' => $detail
    ];
}

arsort($ranks);

echo "Ranks:\n";
foreach ($ranks as $id => $score) {
    $alt = Alternatif::find($id);
    echo $alt->nama . ": " . $score . "\n";
}

echo "\nDetails for lucky:\n";
foreach($details as $nama => $data) {
    if (stripos($nama, 'lucky') !== false || stripos($nama, 'colin') !== false) {
        echo "\n" . $nama . ": " . $data['score'] . "\n";
        print_r($data['breakdown']);
    }
}

echo "\nMinMax:\n";
print_r($minMax);

echo "\nKriteria:\n";
foreach($kriterias as $k) {
    echo $k->id . " - " . $k->nama_kriteria . " - " . $k->jenis . " - " . $k->bobot . "\n";
}
