<?php

namespace Database\Seeders;

use App\Models\Kriteria;
use Illuminate\Database\Seeder;

class KriteriaSeeder extends Seeder
{
    public function run()
    {
        $kriterias = [
            [
                'kode' => 'C1',
                'nama' => 'Nilai Akademik Mata Kuliah',
                'bobot' => 0.25,
                'jenis' => 'benefit',
            ],
            [
                'kode' => 'C2',
                'nama' => 'Ketersediaan Data',
                'bobot' => 0.25,
                'jenis' => 'benefit',
            ],
            [
                'kode' => 'C3',
                'nama' => 'Minat Mahasiswa',
                'bobot' => 0.25,
                'jenis' => 'benefit',
            ],
            [
                'kode' => 'C4',
                'nama' => 'Keahlian Penelitian',
                'bobot' => 0.25,
                'jenis' => 'benefit',
            ],
            [
                'kode' => 'C5',
                'nama' => 'Tren Penelitian Terkini',
                'bobot' => 0.25,
                'jenis' => 'benefit',
            ],
        ];

        foreach ($kriterias as $k) {
            Kriteria::create($k);
        }
    }
}
