<?php

namespace Database\Seeders;

use App\Models\Alternatif;
use App\Models\Kriteria;
use App\Models\Penilaian;
use Illuminate\Database\Seeder;

class DummyDataSeeder extends Seeder
{
    public function run()
    {
        $students = ['Budi Santoso', 'Siti Aminah', 'Rudi Hermawan', 'Dewi Lestari', 'Andi Wijaya'];
        
        $kriterias = Kriteria::all();

        foreach ($students as $name) {
            $alternatif = Alternatif::create([
                'nama' => $name,
                'keterangan' => 'Mahasiswa Informatika',
            ]);

            foreach ($kriterias as $kriteria) {
                Penilaian::create([
                    'alternatif_id' => $alternatif->id,
                    'kriteria_id' => $kriteria->id,
                    'nilai' => rand(60, 100), // Random score between 60 and 100
                ]);
            }
        }
    }
}
