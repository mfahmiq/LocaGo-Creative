<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * Membuat tabel hasil_saw untuk menyimpan hasil perhitungan metode SAW.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('hasil_saw', function (Blueprint $table) {
            $table->id();
            $table->foreignId('alternatif_id')
                  ->constrained('alternatifs')
                  ->onDelete('cascade');
            $table->double('skor_saw');       // Skor akhir SAW
            $table->integer('peringkat');      // Nomor urut ranking
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('hasil_saw');
    }
};
