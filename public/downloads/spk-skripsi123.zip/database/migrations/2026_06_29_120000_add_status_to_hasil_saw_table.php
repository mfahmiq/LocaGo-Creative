<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * Menambahkan kolom status ke tabel hasil_saw.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('hasil_saw', function (Blueprint $table) {
            $table->string('status')->nullable()->after('peringkat');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('hasil_saw', function (Blueprint $table) {
            $table->dropColumn('status');
        });
    }
};
