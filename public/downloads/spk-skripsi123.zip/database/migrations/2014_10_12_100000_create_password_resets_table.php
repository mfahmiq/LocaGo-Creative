<?php

use Illuminate\Database\Migrations\Migration;

/**
 * Tabel password_resets tidak digunakan pada sistem ini.
 * Migration ini dibiarkan kosong (no-op) agar tidak error.
 * Tabel telah dihapus dari database pada 2026-06-13.
 */
return new class extends Migration
{
    public function up(): void
    {
        // password_resets tidak digunakan — tabel telah dihapus
    }

    public function down(): void
    {
        // tidak ada yang perlu di-rollback
    }
};
