<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        // Ubah kolom role menjadi ENUM yang mendukung admin dan mahasiswa
        DB::statement("ALTER TABLE users MODIFY COLUMN role ENUM('admin','mahasiswa') NOT NULL DEFAULT 'mahasiswa'");
    }

    public function down()
    {
        DB::statement("ALTER TABLE users MODIFY COLUMN role ENUM('admin') NOT NULL DEFAULT 'admin'");
    }
};
