INSERT INTO `alternatifs` (`id`, `nama`, `keterangan`, `topik`, `created_at`, `updated_at`) VALUES
INSERT INTO `kriterias` (`id`, `kode`, `nama`, `bobot`, `jenis`, `created_at`, `updated_at`) VALUES
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
INSERT INTO `penilaians` (`id`, `alternatif_id`, `kriteria_id`, `nilai`, `created_at`, `updated_at`) VALUES
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
