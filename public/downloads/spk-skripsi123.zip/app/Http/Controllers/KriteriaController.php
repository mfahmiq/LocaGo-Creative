<?php

namespace App\Http\Controllers;

use App\Models\Kriteria;
use Illuminate\Http\Request;

class KriteriaController extends Controller
{
    public function index()
    {
        $kriterias = Kriteria::all();
        return view('kriteria.index', compact('kriterias'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'kode' => 'required|unique:kriterias',
            'nama' => 'required',
            'bobot' => 'required|numeric',
            'jenis' => 'required|in:benefit,cost',
        ]);

        Kriteria::create($request->all());
        return redirect()->route('kriteria.index')->with('success', 'Kriteria created successfully.');
    }

    public function update(Request $request, Kriteria $kriteria)
    {
        $request->validate([
            'kode' => ['required', \Illuminate\Validation\Rule::unique('kriterias')->ignore($kriteria->id)],
            'nama' => 'required',
            'bobot' => 'required|numeric',
            'jenis' => 'required|in:benefit,cost',
        ], [
            'kode.unique' => 'Kode sudah digunakan oleh kriteria lain.',
            'kode.required' => 'Kode harus diisi.',
            'nama.required' => 'Nama harus diisi.',
            'bobot.required' => 'Bobot harus diisi.',
            'bobot.numeric' => 'Bobot harus berupa angka.',
            'jenis.required' => 'Jenis harus dipilih.',
            'jenis.in' => 'Jenis harus Benefit atau Cost.',
        ]);

        $kriteria->update($request->all());
        return redirect()->route('kriteria.index')->with('success', 'Kriteria updated successfully.');
    }

    public function destroy(Kriteria $kriteria)
    {
        $kriteria->delete();
        return redirect()->route('kriteria.index')->with('success', 'Kriteria deleted successfully.');
    }
}
