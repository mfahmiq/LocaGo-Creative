<?php

namespace App\Http\Controllers;

use App\Models\Alternatif;
use App\Models\Kriteria;
use App\Models\Penilaian;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

class AlternatifController extends Controller
{
    public function index()
    {
        $alternatifs = Alternatif::all();
        return view('alternatif.index', compact('alternatifs'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'npm' => 'required',
            'nama' => 'required',
            'topik' => 'required|in:Pemrograman Web,Data Mining,Kecerdasan Buatan (AI),Internet of Things (IoT)',
        ]);

        Alternatif::create($request->all());
        return redirect()->route('alternatif.index')->with('success', 'Alternatif created successfully.');
    }

    public function update(Request $request, Alternatif $alternatif)
    {
        $request->validate([
            'npm' => 'required',
            'nama' => 'required',
            'topik' => 'required|in:Pemrograman Web,Data Mining,Kecerdasan Buatan (AI),Internet of Things (IoT)',
        ]);

        $alternatif->update($request->all());
        return redirect()->route('alternatif.index')->with('success', 'Alternatif updated successfully.');
    }

    public function template()
    {
        $kriterias = Kriteria::all();
        
        return response()->view('alternatif.template', compact('kriterias'))
            ->header('Content-Type', 'application/vnd.ms-excel')
            ->header('Content-Disposition', 'attachment; filename="template_import_spk.xls"')
            ->header('Cache-Control', 'max-age=0');
    }

    public function import(Request $request)
    {
        $request->validate([
            'file_csv' => 'required|max:2048'
        ], [
            'file_csv.required' => 'File template wajib diunggah.',
        ]);

        $file = $request->file('file_csv');
        $extension = strtolower($file->getClientOriginalExtension());
        if (!in_array($extension, ['csv', 'xls', 'txt'])) {
            return redirect()->back()->withErrors('Format file harus berupa .csv atau .xls');
        }

        $kriterias = Kriteria::all();
        $count = 0;

        if ($extension === 'xls') {
            // Parse HTML Table dari file XLS
            $htmlContent = file_get_contents($file->path());
            
            $dom = new \DOMDocument();
            libxml_use_internal_errors(true);
            $dom->loadHTML($htmlContent);
            libxml_clear_errors();

            $table = $dom->getElementsByTagName('table')->item(0);
            if (!$table) {
                return redirect()->back()->withErrors('Format file Excel (.xls) template tidak valid atau tabel tidak ditemukan.');
            }

            // Dapatkan header dengan mencari baris yang memiliki kolom Nama dan Topik
            $header = [];
            $headerRowIndex = -1;
            $trs = $table->getElementsByTagName('tr');
            if ($trs->length === 0) {
                return redirect()->back()->withErrors('File Excel (.xls) tidak memiliki baris data.');
            }

            for ($r = 0; $r < $trs->length; $r++) {
                $row = $trs->item($r);
                $cells = $row->getElementsByTagName('th');
                if ($cells->length === 0) {
                    $cells = $row->getElementsByTagName('td');
                }
                
                $tempHeader = [];
                foreach ($cells as $cell) {
                    // Hapus BOM, non-breaking space, dan trim
                    $val = str_replace("\xC2\xA0", ' ', $cell->nodeValue);
                    $val = trim(preg_replace('/[\xef\xbb\xbf]/', '', $val));
                    $tempHeader[] = $val;
                }
                
                if (in_array('NPM', $tempHeader) && in_array('Nama', $tempHeader) && in_array('Topik', $tempHeader)) {
                    $header = $tempHeader;
                    $headerRowIndex = $r;
                    break;
                }
            }

            if ($headerRowIndex === -1) {
                return redirect()->back()->withErrors('Format header Excel tidak sesuai template. Pastikan ada kolom "NPM", "Nama", dan "Topik".');
            }

            $npmIdx = array_search('NPM', $header);
            $namaIdx = array_search('Nama', $header);
            $topikIdx = array_search('Topik', $header);
            $keteranganIdx = array_search('Keterangan Judul', $header);

            $kriteriaMap = [];
            foreach ($kriterias as $k) {
                $idx = array_search($k->kode, $header);
                if ($idx !== false) {
                    $kriteriaMap[$k->id] = $idx;
                }
            }

            // Iterasi baris data (mulai setelah baris header)
            for ($i = $headerRowIndex + 1; $i < $trs->length; $i++) {
                $rowTr = $trs->item($i);
                $tds = $rowTr->getElementsByTagName('td');
                if ($tds->length === 0) continue;

                $row = [];
                foreach ($tds as $td) {
                    $row[] = trim($td->nodeValue);
                }

                if (empty(array_filter($row))) continue;

                $npm = $npmIdx !== false ? ($row[$npmIdx] ?? '') : '';
                $nama = $row[$namaIdx] ?? '';
                $topik = $row[$topikIdx] ?? '';
                $keterangan = $keteranganIdx !== false ? ($row[$keteranganIdx] ?? '') : '';

                if (empty($nama)) continue;

                $alternatif = Alternatif::create([
                    'npm' => $npm,
                    'nama' => $nama,
                    'topik' => $topik,
                    'keterangan' => $keterangan,
                ]);

                foreach ($kriteriaMap as $kriteriaId => $colIdx) {
                    $rawVal = isset($row[$colIdx]) ? $row[$colIdx] : '0';
                    $rawVal = str_replace(',', '.', $rawVal);
                    $nilai = is_numeric($rawVal) ? (float)$rawVal : 0;
                    
                    try {
                        Penilaian::create([
                            'alternatif_id' => $alternatif->id,
                            'kriteria_id' => $kriteriaId,
                            'nilai' => $nilai,
                        ]);
                    } catch (\Exception $e) {
                        dd([
                            'error' => $e->getMessage(),
                            'kriteria_id_value' => $kriteriaId,
                            'kriteria_id_type' => gettype($kriteriaId),
                            'kriterias_in_db' => \App\Models\Kriteria::pluck('id')->toArray(),
                            'kriteria_map' => $kriteriaMap,
                        ]);
                    }
                }
                $count++;
            }
        } else {
            // Parse CSV biasa
            $handle = fopen($file->path(), 'r');
            
            // Deteksi delimiter (; atau ,)
            $firstLine = fgets($handle);
            $delimiter = strpos($firstLine, ';') !== false ? ';' : ',';
            rewind($handle);
            
            $header = fgetcsv($handle, 1000, $delimiter);
            if (!$header) {
                return redirect()->back()->withErrors('Format file CSV tidak valid atau kosong.');
            }

            $header = array_map(function($item) {
                return trim(preg_replace('/[\xef\xbb\xbf]/', '', $item));
            }, $header);

            $npmIdx = array_search('NPM', $header);
            $namaIdx = array_search('Nama', $header);
            $topikIdx = array_search('Topik', $header);
            $keteranganIdx = array_search('Keterangan Judul', $header);

            if ($namaIdx === false || $topikIdx === false || $npmIdx === false) {
                fclose($handle);
                return redirect()->back()->withErrors('Format header CSV tidak sesuai template. Pastikan ada kolom "NPM", "Nama", dan "Topik".');
            }

            $kriteriaMap = [];
            foreach ($kriterias as $k) {
                $idx = array_search($k->kode, $header);
                if ($idx !== false) {
                    $kriteriaMap[$k->id] = $idx;
                }
            }

            while (($row = fgetcsv($handle, 1000, $delimiter)) !== false) {
                if (empty(array_filter($row))) continue;

                $npm = $npmIdx !== false ? ($row[$npmIdx] ?? '') : '';
                $nama = $row[$namaIdx] ?? '';
                $topik = $row[$topikIdx] ?? '';
                $keterangan = $keteranganIdx !== false ? ($row[$keteranganIdx] ?? '') : '';

                if (empty($nama)) continue; 

                $alternatif = Alternatif::create([
                    'npm' => $npm,
                    'nama' => $nama,
                    'topik' => $topik,
                    'keterangan' => $keterangan,
                ]);

                foreach ($kriteriaMap as $kriteriaId => $colIdx) {
                    $rawVal = isset($row[$colIdx]) ? $row[$colIdx] : '0';
                    $rawVal = str_replace(',', '.', $rawVal);
                    $nilai = is_numeric($rawVal) ? (float)$rawVal : 0;
                    
                    try {
                        Penilaian::create([
                            'alternatif_id' => $alternatif->id,
                            'kriteria_id' => $kriteriaId,
                            'nilai' => $nilai,
                        ]);
                    } catch (\Exception $e) {
                        dd([
                            'error' => $e->getMessage(),
                            'kriteria_id_value' => $kriteriaId,
                            'kriteria_id_type' => gettype($kriteriaId),
                            'kriterias_in_db' => \App\Models\Kriteria::pluck('id')->toArray(),
                            'kriteria_map' => $kriteriaMap,
                        ]);
                    }
                }
                $count++;
            }
            fclose($handle);
        }

        return redirect()->route('alternatif.index')->with('success', "$count data Alternatif beserta nilai berhasil diimpor.");
    }

    public function destroy(Alternatif $alternatif)
    {
        $alternatif->delete();
        return redirect()->route('alternatif.index')->with('success', 'Alternatif deleted successfully.');
    }
}
