<?php

namespace App\Http\Controllers;

use App\Models\Alternatif;
use App\Models\HasilSaw;
use App\Models\Kriteria;
use App\Models\Penilaian;
use App\Models\User;
use Illuminate\Http\Request;

class SPKController extends Controller
{
    public function dashboard()
    {
        $data = $this->calculateSAW();
        $topRanks = collect($data['ranks'])->take(3);
        return view('dashboard', compact('topRanks', 'data'));
    }

    // ... (Other methods)

    // Hitung (SAW Calculation)
    public function hitung()
    {
        $data = $this->calculateSAW();
        return view('hitung.index', $data);
    }

    private function calculateSAW()
    {
        $alternatifs = Alternatif::with('penilaians.kriteria')->get();
        $kriterias = Kriteria::all();

        // 1. Normalization
        $minMax = [];
        foreach ($kriterias as $kriteria) {
            $nilai = Penilaian::where('kriteria_id', $kriteria->id)->pluck('nilai')->toArray();
            if (empty($nilai)) {
                $minMax[$kriteria->id] = ['min' => 0, 'max' => 0];
                continue;
            }
            $minMax[$kriteria->id] = [
                'min' => min($nilai),
                'max' => max($nilai),
            ];
        }

        $normalized = [];
        foreach ($alternatifs as $alternatif) {
            foreach ($kriterias as $kriteria) {
                $penilaian = $alternatif->penilaians->where('kriteria_id', $kriteria->id)->first();
                $nilai = $penilaian ? $penilaian->nilai : 0;
                
                if ($kriteria->jenis == 'benefit') {
                    $norm = $minMax[$kriteria->id]['max'] > 0 ? $nilai / $minMax[$kriteria->id]['max'] : 0;
                } else {
                    $norm = $nilai > 0 ? $minMax[$kriteria->id]['min'] / $nilai : 0;
                }
                
                $normalized[$alternatif->id][$kriteria->id] = $norm;
            }
        }

        // Normalisasi Bobot (Pastikan total bobot = 1 atau 100%)
        $totalBobot = $kriterias->sum('bobot');
        $bobotRelatif = [];
        foreach ($kriterias as $kriteria) {
            $bobotRelatif[$kriteria->id] = $totalBobot > 0 ? ($kriteria->bobot / $totalBobot) : 0;
        }

        // 2. Ranking
        $ranks = [];
        foreach ($alternatifs as $alternatif) {
            $score = 0;
            foreach ($kriterias as $kriteria) {
                $score += $normalized[$alternatif->id][$kriteria->id] * $bobotRelatif[$kriteria->id];
            }
            $ranks[$alternatif->id] = $score;
        }

        arsort($ranks);

        return compact('alternatifs', 'kriterias', 'normalized', 'ranks');
    }
    // Menampilkan Form Penilaian
    public function penilaian()
    {
        $alternatifs = Alternatif::with('penilaians')->get();
        $kriterias = Kriteria::all();
        return view('penilaian.index', compact('alternatifs', 'kriterias'));
    }

    // Menyimpan Penilaian
    public function storePenilaian(Request $request)
    {
        // Validasi input array
        $request->validate([
            'nilai' => 'required|array',
            'nilai.*.*' => 'required|numeric|min:0',
        ]);

        foreach ($request->nilai as $alternatif_id => $kriteria_nilai) {
            foreach ($kriteria_nilai as $kriteria_id => $nilai) {
                Penilaian::updateOrCreate(
                    [
                        'alternatif_id' => $alternatif_id,
                        'kriteria_id' => $kriteria_id
                    ],
                    [
                        'nilai' => $nilai
                    ]
                );
            }
        }

        return redirect()->route('penilaian.index')->with('success', 'Data penilaian berhasil diperbarui!');
    }

    /**
     * Simpan hasil perhitungan SAW ke tabel hasil_saw.
     * Data lama akan dihapus dulu, kemudian diganti dengan hasil terbaru.
     */
    public function simpanHasil()
    {
        $data = $this->calculateSAW();

        // Hapus hasil lama agar tidak duplikat
        HasilSaw::truncate();

        $peringkat = 1;
        foreach ($data['ranks'] as $alternatifId => $skor) {
            // Tentukan status berdasarkan skor
            if ($skor > 0.70) {
                $status = 'Prioritas Utama';
            } elseif ($skor >= 0.60) {
                $status = 'Direkomendasikan';
            } else {
                $status = 'Dipertimbangkan / Perlu Revisi Judul';
            }

            HasilSaw::create([
                'alternatif_id' => $alternatifId,
                'skor_saw'      => round($skor, 4),
                'peringkat'     => $peringkat,
                'status'        => $status,
            ]);
            $peringkat++;
        }

        return redirect()->route('hitung.index')
            ->with('success', 'Hasil perhitungan SAW berhasil disimpan! Total ' . count($data['ranks']) . ' alternatif.');
    }

    // Ekspor Hasil Perhitungan ke Excel
    public function exportExcel()
    {
        $data = $this->calculateSAW();
        
        $filename = "surat_penetapan_minat_dan_judul_skripsi_" . date('Ymd_His') . ".xls";
        
        return response()->view('hitung.excel', $data)
            ->header('Content-Type', 'application/vnd.ms-excel')
            ->header('Content-Disposition', 'attachment; filename="' . $filename . '"')
            ->header('Cache-Control', 'max-age=0');
    }
}
