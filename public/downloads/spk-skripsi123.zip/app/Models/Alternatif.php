<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Alternatif extends Model
{
    use HasFactory;

    protected $fillable = [
        'npm',
        'nama',
        'keterangan',
        'topik',
    ];

    public function penilaians()
    {
        return $this->hasMany(Penilaian::class);
    }

    /**
     * Relasi ke tabel hasil_saw.
     */
    public function hasilSaw()
    {
        return $this->hasMany(HasilSaw::class);
    }
}
