<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HasilSaw extends Model
{
    use HasFactory;

    protected $table = 'hasil_saw';

    protected $fillable = [
        'alternatif_id',
        'skor_saw',
        'peringkat',
        'status',
    ];

    /**
     * Relasi ke tabel alternatifs.
     */
    public function alternatif()
    {
        return $this->belongsTo(Alternatif::class);
    }
}
