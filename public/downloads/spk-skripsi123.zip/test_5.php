<?php
require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Alternatif;
use App\Models\Kriteria;
use App\Models\Penilaian;

$names = ['LUCKY PRIMANDA S.', 'COLIN YUDISTIA SANTOSO', 'MUHAMMAD FAIZAL', 'NAYUDA GIGIH FAYRUZ Q.', 'MUHAMMAD ABBAS'];
$alternatifs = Alternatif::whereIn('nama', $names)->with('penilaians.kriteria')->get();

foreach($alternatifs as $a) {
    echo $a->nama . ":\n";
    foreach($a->penilaians as $p) {
        echo "  " . $p->kriteria->kode . " (" . $p->kriteria->jenis . ") = " . $p->nilai . "\n";
    }
}
