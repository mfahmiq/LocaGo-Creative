<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
    <table>
        <tr>
            <td colspan="6" style="font-family: Arial, sans-serif; font-size: 14pt; font-weight: bold; text-align: center;">DAFTAR FINAL PEMETAAN MINAT TOPIK DAN JUDUL SKRIPSI MAHASISWA</td>
        </tr>
        <tr>
            <td colspan="6" style="font-family: Arial, sans-serif; font-size: 14pt; font-weight: bold; text-align: center;">PROGRAM STUDI INFORMATIKA UNIVERSITAS PANCASAKTI TEGAL</td>
        </tr>
        <tr>
            <td colspan="6" style="font-family: Arial, sans-serif; font-size: 14pt; font-weight: bold; text-align: center;">TAHUN AKADEMIK {{ date('Y') }}/{{ date('Y') + 1 }}</td>
        </tr>
        <tr>
            <td colspan="6" style="height: 20px;"></td>
        </tr>
        <thead>
            <tr>
                <th style="font-family: Arial, sans-serif; font-size: 10pt; font-weight: bold; background-color: #1E2A3A; color: #FFFFFF; border: 1px solid #000000; text-align: center; vertical-align: middle; width: 60px; height: 35px;">No</th>
                <th style="font-family: Arial, sans-serif; font-size: 10pt; font-weight: bold; background-color: #1E2A3A; color: #FFFFFF; border: 1px solid #000000; text-align: center; vertical-align: middle; width: 200px; height: 35px;">Nama Mahasiswa</th>
                <th style="font-family: Arial, sans-serif; font-size: 10pt; font-weight: bold; background-color: #1E2A3A; color: #FFFFFF; border: 1px solid #000000; text-align: center; vertical-align: middle; width: 220px; height: 35px;">Minat Topik</th>
                <th style="font-family: Arial, sans-serif; font-size: 10pt; font-weight: bold; background-color: #1E2A3A; color: #FFFFFF; border: 1px solid #000000; text-align: center; vertical-align: middle; width: 450px; height: 35px;">Judul Skripsi</th>
                <th style="font-family: Arial, sans-serif; font-size: 10pt; font-weight: bold; background-color: #1E2A3A; color: #FFFFFF; border: 1px solid #000000; text-align: center; vertical-align: middle; width: 120px; height: 35px;">Nilai Final</th>
                <th style="font-family: Arial, sans-serif; font-size: 10pt; font-weight: bold; background-color: #1E2A3A; color: #FFFFFF; border: 1px solid #000000; text-align: center; vertical-align: middle; width: 150px; height: 35px;">Keterangan</th>
            </tr>
        </thead>
        <tbody>
            @php $rank = 1; @endphp
            @foreach($ranks as $id => $score)
            @php 
                $alternatif = $alternatifs->find($id);
            @endphp
            <tr>
                <td style="font-family: Arial, sans-serif; font-size: 10pt; border: 1px solid #000000; text-align: center; vertical-align: middle; padding: 5px;">{{ $rank }}</td>
                <td style="font-family: Arial, sans-serif; font-size: 10pt; border: 1px solid #000000; text-align: center; vertical-align: middle; font-weight: bold; padding: 5px;">{{ $alternatif->nama }}</td>
                <td style="font-family: Arial, sans-serif; font-size: 10pt; border: 1px solid #000000; text-align: center; vertical-align: middle; white-space: normal; padding: 5px;">{{ $alternatif->topik }}</td>
                <td style="font-family: Arial, sans-serif; font-size: 10pt; border: 1px solid #000000; text-align: center; vertical-align: middle; white-space: normal; padding: 5px;">{{ $alternatif->keterangan }}</td>
                <td style="font-family: Arial, sans-serif; font-size: 10pt; border: 1px solid #000000; text-align: center; vertical-align: middle; mso-number-format: '0\.0000'; padding: 5px;">{{ number_format($score, 4, '.', '') }}</td>
                <td style="font-family: Arial, sans-serif; font-size: 10pt; border: 1px solid #000000; text-align: center; vertical-align: middle; padding: 5px;">
                    @if($score > 0.70)
                        Prioritas Utama
                    @elseif($score >= 0.60)
                        Direkomendasikan
                    @else
                        Dipertimbangkan
                    @endif
                </td>
            </tr>
            @php $rank++; @endphp
            @endforeach
        </tbody>
    </table>
</body>
</html>
