@extends('layouts.app')

@section('content')
<style>
    /* ===== DESKTOP ENHANCEMENTS & CUSTOM STYLING ===== */
    
    /* 1. Custom Hover & Zebra Striping */
    .table-custom tbody tr {
        transition: background-color 0.15s ease, box-shadow 0.15s ease;
    }
    .table-custom tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 0, 0, 0.015);
    }
    .table-custom tbody tr:hover {
        background-color: rgba(13, 110, 253, 0.04) !important;
        box-shadow: inset 3px 0 0 #0d6efd;
    }
    
    /* 2. Sticky Table Header & High Contrast */
    .table-sticky-header {
        position: relative;
    }
    .table-sticky-header thead th {
        position: sticky;
        top: 0;
        z-index: 10;
        background-color: #f8f9fa !important;
        color: #212529 !important; /* Darker text for higher contrast */
        font-weight: 700 !important;
        border-bottom: 2px solid #dee2e6 !important;
    }
    
    /* 3. Clickable Row pointer */
    .clickable-row {
        cursor: pointer;
    }
    
    /* 4. Action Buttons in Table Row */
    .action-buttons {
        display: inline-flex;
        gap: 0.35rem;
    }
    
    /* 5. Slide-Out Detail Side Panel */
    .side-panel {
        position: fixed;
        top: 0;
        right: -460px; /* Hide offscreen */
        width: 450px;
        height: 100vh;
        background-color: #ffffff;
        box-shadow: -5px 0 30px rgba(0, 0, 0, 0.15);
        z-index: 1060;
        transition: right 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        display: flex;
        flex-direction: column;
    }
    .side-panel.show {
        right: 0;
    }
    .panel-backdrop {
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background-color: rgba(0, 0, 0, 0.4);
        backdrop-filter: blur(2px);
        z-index: 1050;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s ease, visibility 0.3s ease;
    }
    .panel-backdrop.show {
        opacity: 1;
        visibility: visible;
    }
    
    /* Panel scroll styling */
    .side-panel-body::-webkit-scrollbar {
        width: 6px;
    }
    .side-panel-body::-webkit-scrollbar-track {
        background: #f1f1f1;
    }
    .side-panel-body::-webkit-scrollbar-thumb {
        background: #ccc;
        border-radius: 3px;
    }
    .side-panel-body::-webkit-scrollbar-thumb:hover {
        background: #999;
    }
    
    @media (max-width: 576px) {
        .side-panel {
            width: 100%;
            right: -100%;
        }
    }
    

    /* 7. Custom Tabs Styling */
    .custom-saw-tabs .nav-link {
        color: #6c757d;
        border: none;
        background: transparent;
        transition: all 0.2s ease;
    }
    .custom-saw-tabs .nav-link:hover {
        color: #212529;
        background-color: rgba(0, 0, 0, 0.04);
    }
    .custom-saw-tabs .nav-link.active {
        color: #212529 !important;
        background-color: #ffffff !important;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    }
</style>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4">
    <div>
        <h3 class="fw-bold text-dark mb-1">Hasil Perhitungan SAW</h3>
        <p class="text-muted small mb-0">Daftar pemetaan minat topik dan judul skripsi mahasiswa berdasarkan perhitungan metode SAW.</p>
    </div>
</div>

<!-- Tabs Navigation (iOS Segmented Control Style) -->
<div class="d-flex mb-4">
    <ul class="nav nav-pills custom-saw-tabs p-1 bg-light rounded-3 shadow-sm" id="sawTab" role="tablist" style="border: 1px solid rgba(0,0,0,0.06);">
        <li class="nav-item" role="presentation">
            <button class="nav-link active fw-bold py-2 px-4 rounded-3 transition-all" 
                    id="ranking-tab" 
                    data-bs-toggle="tab" 
                    data-bs-target="#ranking-pane" 
                    type="button" 
                    role="tab" 
                    aria-controls="ranking-pane" 
                    aria-selected="true"
                    style="font-size: 0.9rem;">
                <i class="bi bi-trophy-fill me-2 text-success"></i>Hasil Perankingan
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link fw-bold py-2 px-4 rounded-3 transition-all" 
                    id="normalisasi-tab" 
                    data-bs-toggle="tab" 
                    data-bs-target="#normalisasi-pane" 
                    type="button" 
                    role="tab" 
                    aria-controls="normalisasi-pane" 
                    aria-selected="false"
                    style="font-size: 0.9rem;">
                <i class="bi bi-grid-3x3-gap-fill me-2 text-primary"></i>Matriks Normalisasi
            </button>
        </li>
    </ul>
</div>

<!-- Tabs Content -->
<div class="tab-content" id="sawTabContent">
    <!-- Tab 1: Hasil Perankingan (Active by default) -->
    <div class="tab-pane fade show active" id="ranking-pane" role="tabpanel" aria-labelledby="ranking-tab" tabindex="0">
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-4">
                <!-- Re-positioned Export Button inside Header -->
                <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center gap-3 mb-3">
                    <h5 class="fw-bold mb-0 text-success"><i class="bi bi-trophy-fill me-2"></i>Hasil Perankingan</h5>
                    @if(auth()->user()->role == 'admin')
                    <div class="d-flex gap-2 flex-wrap">
                        {{-- Tombol Simpan Hasil ke Database --}}
                        <form action="{{ route('hitung.simpan') }}" method="POST" class="m-0">
                            @csrf
                            <button type="submit" class="btn btn-primary d-inline-flex align-items-center gap-2 shadow-sm rounded-3 py-2 px-3"
                                onclick="return confirm('Simpan hasil perhitungan SAW ke database? Data lama akan diganti.')">
                                <i class="bi bi-save-fill"></i>
                                <span>Simpan Hasil</span>
                            </button>
                        </form>
                        {{-- Tombol Ekspor Excel --}}
                        <a href="{{ route('hitung.excel') }}" class="btn btn-success d-inline-flex align-items-center gap-2 shadow-sm rounded-3 py-2 px-3">
                            <i class="bi bi-file-earmark-excel-fill"></i>
                            <span>Ekspor Excel</span>
                        </a>
                    </div>
                    @endif
                </div>
                
                <hr class="text-muted mb-4" style="opacity: 0.15;">
                
                <!-- Interactive Search Bar -->
                <div class="row g-3 mb-4">
                    <div class="col-md-5 col-sm-8">
                        <div class="input-group shadow-sm rounded-3 overflow-hidden">
                            <span class="input-group-text bg-white border-end-0 text-muted"><i class="bi bi-search"></i></span>
                            <input type="text" id="tableSearch" class="form-control border-start-0 py-2" placeholder="Cari nama alternatif / mahasiswa...">
                        </div>
                    </div>
                </div>
                
                <!-- Increased max-height to 750px for ample desktop height -->
                <div class="table-responsive" style="max-height: 750px; overflow-y: auto;">
                    <table class="table table-custom table-sticky-header align-middle mb-0" id="rankingTable">
                        <thead class="table-light">
                            <tr>
                                <th class="text-center text-uppercase text-secondary fw-bold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px; width: 80px;">Peringkat</th>
                                <th class="text-uppercase text-secondary fw-bold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Alternatif</th>
                                <th class="text-uppercase text-secondary fw-bold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Topik</th>
                                <th class="text-uppercase text-secondary fw-bold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Keterangan</th>
                                <th class="text-end text-uppercase text-secondary fw-bold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Nilai Akhir</th>
                                <th class="text-center text-uppercase text-secondary fw-bold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px; width: 180px;">Status</th>
                                <th class="text-center text-uppercase text-secondary fw-bold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px; width: 100px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php $rank = 1; @endphp
                            @foreach($ranks as $id => $score)
                            @php 
                                $alternatif = $alternatifs->find($id); 
                                $isWinner = $rank == 1;
                            @endphp
                            @php
                                if ($score > 0.70) {
                                    $statusLabel = 'Prioritas Utama';
                                } elseif ($score >= 0.60) {
                                    $statusLabel = 'Direkomendasikan';
                                } else {
                                    $statusLabel = 'Dipertimbangkan / Perlu Revisi Judul';
                                }
                            @endphp
                            <tr class="clickable-row {{ $isWinner ? 'table-success' : '' }}" 
                                style="{{ $isWinner ? 'background-color: rgba(25, 135, 84, 0.03);' : '' }}"
                                data-id="{{ $alternatif->id }}"
                                data-nama="{{ $alternatif->nama }}"
                                data-topik="{{ $alternatif->topik }}"
                                data-keterangan="{{ $alternatif->keterangan ?? '-' }}"
                                data-nilai-akhir="{{ number_format($score, 4) }}"
                                data-peringkat="{{ $rank }}"
                                data-status="{{ $statusLabel }}"
                                data-penilaians="{{ $alternatif->penilaians->map(function($p) use ($normalized, $alternatif) {
                                    return [
                                        'kode' => $p->kriteria->kode,
                                        'nama' => $p->kriteria->nama,
                                        'nilai' => $p->nilai,
                                        'normalisasi' => number_format($normalized[$alternatif->id][$p->kriteria_id], 4)
                                    ];
                                })->toJson() }}">
                                <td class="text-center border-light">
                                    @if($rank == 1)
                                        <span class="badge bg-warning text-dark rounded-circle shadow-sm" style="width: 30px; height: 30px; display: inline-flex; align-items: center; justify-content: center; font-size: 0.9rem;">1</span>
                                    @elseif($rank == 2)
                                        <span class="badge bg-secondary rounded-circle shadow-sm" style="width: 30px; height: 30px; display: inline-flex; align-items: center; justify-content: center; font-size: 0.9rem;">2</span>
                                    @elseif($rank == 3)
                                        <span class="badge text-white rounded-circle shadow-sm" style="background-color: #cd7f32; width: 30px; height: 30px; display: inline-flex; align-items: center; justify-content: center; font-size: 0.9rem;">3</span>
                                    @else
                                        <span class="badge bg-light text-dark border rounded-circle" style="width: 30px; height: 30px; display: inline-flex; align-items: center; justify-content: center; font-size: 0.9rem;">{{ $rank }}</span>
                                    @endif
                                </td>
                                <td class="fw-bold border-light {{ $isWinner ? 'text-success' : 'text-dark' }} search-name">
                                    {{ $alternatif->nama }}
                                    @if($isWinner)
                                        <span class="badge bg-success ms-2 rounded-pill"><i class="bi bi-star-fill text-warning me-1"></i> Rekomendasi Utama</span>
                                    @endif
                                </td>
                                <td class="border-light">
                                    <span class="badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25 rounded-pill px-3 py-2" style="font-weight: 600;">{{ $alternatif->topik }}</span>
                                </td>
                                <td style="max-width: 250px;" class="text-truncate text-muted border-light" title="{{ $alternatif->keterangan }}" data-bs-toggle="tooltip" data-bs-placement="top">
                                    {{ $alternatif->keterangan }}
                                </td>
                                <td class="text-end fw-bold font-monospace border-light {{ $isWinner ? 'text-success' : 'text-primary' }}">
                                    {{ number_format($score, 4) }}
                                </td>
                                <td class="text-center border-light">
                                    @if($score > 0.70)
                                        <span class="badge rounded-pill px-3 py-2" style="background-color: #198754; color: #fff; font-weight: 600;">
                                            <i class="bi bi-check-circle-fill me-1"></i>Prioritas Utama
                                        </span>
                                    @elseif($score >= 0.60)
                                        <span class="badge rounded-pill px-3 py-2" style="background-color: #0d6efd; color: #fff; font-weight: 600;">
                                            <i class="bi bi-hand-thumbs-up-fill me-1"></i>Direkomendasikan
                                        </span>
                                    @else
                                        <span class="badge rounded-pill px-3 py-2" style="background-color: #ffc107; color: #212529; font-weight: 600;">
                                            <i class="bi bi-exclamation-triangle-fill me-1"></i>Dipertimbangkan
                                        </span>
                                    @endif
                                </td>
                                <td class="text-center border-light">
                                    <div class="action-buttons justify-content-center">
                                        <button type="button" class="btn btn-sm btn-outline-primary d-inline-flex align-items-center gap-1 btn-view-detail" title="Lihat Detail" data-bs-toggle="tooltip">
                                            <i class="bi bi-eye"></i> <span>Detail</span>
                                        </button>
                                        @if(auth()->user()->role == 'admin')
                                        <a href="{{ route('penilaian.index') }}" class="btn btn-sm btn-outline-warning d-inline-flex align-items-center gap-1 btn-edit-nilai" title="Kelola Nilai" data-bs-toggle="tooltip">
                                            <i class="bi bi-pencil-square"></i> <span>Nilai</span>
                                        </a>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                            @php $rank++; @endphp
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Tab 2: Matriks Normalisasi -->
    <div class="tab-pane fade" id="normalisasi-pane" role="tabpanel" aria-labelledby="normalisasi-tab" tabindex="0">
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-3 text-primary"><i class="bi bi-grid-3x3-gap-fill me-2"></i>Matriks Normalisasi</h5>
                <hr class="text-muted mb-4" style="opacity: 0.15;">
                
                <!-- Increased max-height to 650px for normalization table -->
                <div class="table-responsive" style="max-height: 650px; overflow-y: auto;">
                    <table class="table table-custom table-sticky-header align-middle mb-0" id="matriksTable">
                        <thead class="table-light">
                            <tr>
                                <th class="text-uppercase text-secondary fw-bold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Alternatif</th>
                                @foreach($kriterias as $kriteria)
                                    <th class="text-end text-uppercase text-secondary fw-bold border-bottom-0" 
                                        style="font-size: 0.75rem; letter-spacing: 0.5px; cursor: help;"
                                        data-bs-toggle="tooltip" 
                                        data-bs-placement="top" 
                                        title="{{ $kriteria->nama }} ({{ ucfirst($kriteria->jenis) }}, Bobot: {{ $kriteria->bobot }})">
                                        {{ $kriteria->kode }}
                                    </th>
                                @endforeach
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($alternatifs as $alternatif)
                            <tr>
                                <td class="fw-medium text-dark border-light search-name">{{ $alternatif->nama }}</td>
                                @foreach($kriterias as $kriteria)
                                    <td class="text-end text-muted font-monospace border-light">{{ number_format($normalized[$alternatif->id][$kriteria->id], 4) }}</td>
                                @endforeach
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Side Panel Detail -->
<div id="detailSidePanel" class="side-panel">
    <div class="side-panel-header p-4 border-bottom d-flex align-items-center justify-content-between">
        <h5 class="fw-bold mb-0 text-dark"><i class="bi bi-person-badge-fill me-2 text-primary"></i>Detail Alternatif</h5>
        <button type="button" class="btn-close" onclick="closeDetailPanel()" aria-label="Close"></button>
    </div>
    <div class="side-panel-body p-4 flex-grow-1 overflow-y-auto">
        <!-- Profile Section -->
        <div class="text-center mb-4">
            <div id="panelAvatar" class="bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25 d-flex align-items-center justify-content-center rounded-circle fw-bold shadow-sm mx-auto mb-3" style="width: 70px; height: 70px; font-size: 2rem;">
                -
            </div>
            <h4 id="panelNama" class="fw-bold text-dark mb-1">Nama Mahasiswa</h4>
            <span id="panelTopik" class="badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25 rounded-pill px-3 py-2 fw-semibold">Topik Rekomendasi</span>
        </div>

        <div class="mb-4">
            <h6 class="fw-semibold text-muted text-uppercase mb-2" style="font-size: 0.75rem; letter-spacing: 0.5px;">Keterangan / Judul Skripsi</h6>
            <div class="card border-0 bg-light rounded-3 p-3">
                <p id="panelKeterangan" class="mb-0 text-dark small" style="white-space: pre-wrap; line-height: 1.6;">-</p>
            </div>
        </div>

        <div class="mb-4">
            <h6 class="fw-semibold text-muted text-uppercase mb-2" style="font-size: 0.75rem; letter-spacing: 0.5px;">Hasil Perhitungan</h6>
            <div class="row g-2">
                <div class="col-4">
                    <div class="border rounded-3 p-3 text-center bg-light">
                        <div class="small text-muted mb-1">Peringkat</div>
                        <div id="panelPeringkat" class="fs-4 fw-bold text-success">-</div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="border rounded-3 p-3 text-center bg-light">
                        <div class="small text-muted mb-1">Nilai Akhir</div>
                        <div id="panelNilaiAkhir" class="fs-4 fw-bold text-primary font-monospace">-</div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="border rounded-3 p-3 text-center bg-light">
                        <div class="small text-muted mb-1">Status</div>
                        <div id="panelStatus" class="fw-bold" style="font-size: 0.85rem;">-</div>
                    </div>
                </div>
            </div>
        </div>

        <div>
            <h6 class="fw-semibold text-muted text-uppercase mb-2" style="font-size: 0.75rem; letter-spacing: 0.5px;">Rincian Nilai Kriteria</h6>
            <div class="table-responsive border rounded-3">
                <table class="table table-sm table-striped align-middle mb-0" style="font-size: 0.85rem;">
                    <thead class="table-light">
                        <tr>
                            <th class="p-2 fw-semibold">Kriteria</th>
                            <th class="p-2 text-end fw-semibold">Nilai Asli</th>
                            <th class="p-2 text-end fw-semibold">Normalisasi</th>
                        </tr>
                    </thead>
                    <tbody id="panelKriteriaBody">
                        <!-- Dynamically filled by JS -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="side-panel-footer p-4 border-top bg-light">
        <button type="button" class="btn btn-outline-secondary w-100" onclick="closeDetailPanel()">Tutup</button>
    </div>
</div>

<!-- Backdrop Overlay -->
<div id="panelOverlay" class="panel-backdrop" onclick="closeDetailPanel()"></div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Initialize Bootstrap tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });

        // 1. Client-Side Instant Search
        const tableSearch = document.getElementById('tableSearch');
        if (tableSearch) {
            tableSearch.addEventListener('input', function() {
                const query = this.value.toLowerCase().trim();
                
                // Search in Ranking Table
                const rankingRows = document.querySelectorAll('#rankingTable tbody tr');
                rankingRows.forEach(row => {
                    const nameCell = row.querySelector('.search-name');
                    if (nameCell) {
                        const nameText = nameCell.textContent.toLowerCase();
                        if (nameText.includes(query)) {
                            row.style.setProperty('display', '', 'important');
                        } else {
                            row.style.setProperty('display', 'none', 'important');
                        }
                    }
                });
                
                // Search in Matriks Table
                const matriksRows = document.querySelectorAll('#matriksTable tbody tr');
                matriksRows.forEach(row => {
                    const nameCell = row.querySelector('.search-name');
                    if (nameCell) {
                        const nameText = nameCell.textContent.toLowerCase();
                        if (nameText.includes(query)) {
                            row.style.setProperty('display', '', 'important');
                        } else {
                            row.style.setProperty('display', 'none', 'important');
                        }
                    }
                });
            });
        }

        // 2. Side Panel Interactions
        function showDetailPanel(row) {
            const nama = row.getAttribute('data-nama');
            const topik = row.getAttribute('data-topik');
            const keterangan = row.getAttribute('data-keterangan');
            const nilaiAkhir = row.getAttribute('data-nilai-akhir');
            const peringkat = row.getAttribute('data-peringkat');
            const penilaians = JSON.parse(row.getAttribute('data-penilaians') || '[]');
            
            // Set text content
            document.getElementById('panelNama').textContent = nama;
            document.getElementById('panelTopik').textContent = topik;
            document.getElementById('panelKeterangan').textContent = keterangan;
            document.getElementById('panelNilaiAkhir').textContent = nilaiAkhir;
            document.getElementById('panelPeringkat').textContent = '#' + peringkat;
            
            // Set status with color
            const status = row.getAttribute('data-status');
            const panelStatus = document.getElementById('panelStatus');
            panelStatus.textContent = status;
            if (status.includes('Utama')) {
                panelStatus.className = 'fw-bold text-success';
                panelStatus.style.fontSize = '0.85rem';
            } else if (status.includes('Direkomendasikan')) {
                panelStatus.className = 'fw-bold text-primary';
                panelStatus.style.fontSize = '0.85rem';
            } else {
                panelStatus.className = 'fw-bold text-warning';
                panelStatus.style.fontSize = '0.85rem';
            }
            
            // Set avatar initials
            document.getElementById('panelAvatar').textContent = nama.charAt(0).toUpperCase();
            
            // Populate criteria breakdown
            const tbody = document.getElementById('panelKriteriaBody');
            tbody.innerHTML = '';
            penilaians.forEach(p => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td class="p-2 border-light">
                        <div class="fw-bold">${p.kode}</div>
                        <div class="text-muted small" style="font-size: 0.75rem;">${p.nama}</div>
                    </td>
                    <td class="p-2 text-end font-monospace border-light">${p.nilai}</td>
                    <td class="p-2 text-end font-monospace fw-semibold text-primary border-light">${p.normalisasi}</td>
                `;
                tbody.appendChild(tr);
            });
            
            // Slide in panel and show backdrop
            document.getElementById('detailSidePanel').classList.add('show');
            document.getElementById('panelOverlay').classList.add('show');
        }

        window.closeDetailPanel = function() {
            document.getElementById('detailSidePanel').classList.remove('show');
            document.getElementById('panelOverlay').classList.remove('show');
        }


        // Click handler for table rows (excludes click on links/buttons)
        document.querySelectorAll('#rankingTable tbody tr.clickable-row').forEach(row => {
            row.addEventListener('click', function(e) {
                if (e.target.closest('a') || e.target.closest('button')) {
                    return;
                }
                showDetailPanel(this);
            });
        });

        // Click handler for quick actions view button
        document.querySelectorAll('.btn-view-detail').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                const row = this.closest('tr');
                showDetailPanel(row);
            });
        });
    });
</script>
@endsection
