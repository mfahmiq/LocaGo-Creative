@extends('layouts.app')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold text-dark mb-0">Data Kriteria</h3>
    <button class="btn btn-primary rounded-pill shadow-sm px-4" data-bs-toggle="modal" data-bs-target="#createModal">
        <i class="bi bi-plus-lg me-1"></i> Tambah Kriteria
    </button>
</div>

<div class="card border-0 shadow-sm rounded-4 mb-4">
    <div class="card-body p-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="text-uppercase text-secondary fw-semibold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Kode</th>
                        <th class="text-uppercase text-secondary fw-semibold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Nama</th>
                        <th class="text-end text-uppercase text-secondary fw-semibold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Bobot</th>
                        <th class="text-center text-uppercase text-secondary fw-semibold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Jenis</th>
                        <th class="text-center text-uppercase text-secondary fw-semibold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px; width: 120px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
        @foreach($kriterias as $kriteria)
                    <tr>
                        <td class="fw-bold text-dark border-light">{{ $kriteria->kode }}</td>
                        <td class="border-light">{{ $kriteria->nama }}</td>
                        <td class="text-end font-monospace border-light">{{ number_format($kriteria->bobot, 2) }}</td>
                        <td class="text-center border-light">
                            @if(strtolower($kriteria->jenis) == 'benefit')
                                <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 rounded-pill px-3 py-2" style="font-weight: 600;">Benefit</span>
                            @else
                                <span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 rounded-pill px-3 py-2" style="font-weight: 600;">Cost</span>
                            @endif
                        </td>
                        <td class="border-light text-center">
                            <div class="d-flex justify-content-center gap-1">
                                <button class="btn btn-sm btn-outline-primary border-0 rounded-circle" data-bs-toggle="modal" data-bs-target="#editModal{{ $kriteria->id }}" title="Edit">
                                    <i class="bi bi-pencil-square" style="font-size: 1.1rem;"></i>
                                </button>
                                <form action="{{ route('kriteria.destroy', $kriteria->id) }}" method="POST" class="d-inline">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger border-0 rounded-circle" onclick="return confirm('Yakin ingin menghapus kriteria ini?')" title="Hapus">
                                        <i class="bi bi-trash" style="font-size: 1.1rem;"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>

        <!-- Edit Modal -->
        <div class="modal fade" id="editModal{{ $kriteria->id }}" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="{{ route('kriteria.update', $kriteria->id) }}" method="POST">
                        @csrf @method('PUT')
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Kriteria</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label>Kode</label>
                                <input type="text" name="kode" class="form-control" value="{{ $kriteria->kode }}" required>
                            </div>
                            <div class="mb-3">
                                <label>Nama</label>
                                <input type="text" name="nama" class="form-control" value="{{ $kriteria->nama }}" required>
                            </div>
                            <div class="mb-3">
                                <label>Bobot</label>
                                <input type="number" step="0.01" name="bobot" class="form-control" value="{{ $kriteria->bobot }}" required>
                            </div>
                            <div class="mb-3">
                                <label>Jenis</label>
                                <select name="jenis" class="form-control" required>
                                    <option value="benefit" {{ $kriteria->jenis == 'benefit' ? 'selected' : '' }}>Benefit</option>
                                    <option value="cost" {{ $kriteria->jenis == 'cost' ? 'selected' : '' }}>Cost</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Create Modal -->
<div class="modal fade" id="createModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('kriteria.store') }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Kriteria</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>Kode</label>
                        <input type="text" name="kode" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Nama</label>
                        <input type="text" name="nama" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Bobot</label>
                        <input type="number" step="0.01" name="bobot" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Jenis</label>
                        <select name="jenis" class="form-control" required>
                            <option value="benefit">Benefit</option>
                            <option value="cost">Cost</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
