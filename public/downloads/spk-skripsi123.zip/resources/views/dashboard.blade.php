@extends('layouts.app')

@section('content')

    <div class="row mb-5 mt-2">
        <div class="col-12">
            <div class="card border-0 shadow-lg overflow-hidden position-relative" style="border-radius: 1.5rem; background: linear-gradient(135deg, #0a3d91 0%, #0d6efd 50%, #0dcaf0 100%);">
                <!-- Background Pattern Overlay (Grid / Tech Theme) -->
                <div class="position-absolute top-0 start-0 w-100 h-100" style="background-image: linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px); background-size: 32px 32px; opacity: 0.2; pointer-events: none;"></div>
                
                <div class="card-body p-5 text-white position-relative" style="z-index: 10;">
                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
                        <div class="mb-4 mb-md-0 text-center text-md-start">
                            <!-- Drop shadow pada teks agar lebih menonjol -->
                            <h1 class="fw-bolder mb-2" style="text-shadow: 0 4px 10px rgba(0,0,0,0.3); letter-spacing: -0.5px; font-size: 2.25rem;">Dashboard Administrator</h1>
                            <p class="mb-0 fs-5 fw-medium text-white" style="text-shadow: 0 2px 4px rgba(0,0,0,0.2);">Selamat Datang, {{ Auth::user()->name }}! 👋</p>
                        </div>
                        
                        <!-- Glassmorphism Date Box -->
                        <div class="d-flex align-items-center gap-3 px-4 py-3 shadow-sm" style="background: rgba(255, 255, 255, 0.15); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.3); border-radius: 1.25rem; transition: all 0.3s ease;">
                            <!-- Kalender Ikon -->
                            <div class="p-2 rounded-3 shadow-inner" style="background: rgba(255, 255, 255, 0.2);">
                                <svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                            </div>
                            <div class="text-start">
                                <span class="d-block fs-4 fw-bold" style="text-shadow: 0 2px 4px rgba(0,0,0,0.1); line-height: 1.2;">{{ \Carbon\Carbon::now()->locale('id')->translatedFormat('d F Y') }}</span>
                                <span class="text-uppercase fw-semibold" style="font-size: 0.75rem; letter-spacing: 1.5px; color: rgba(255, 255, 255, 0.9);">Hari Ini</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistik Ringkas -->
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100 hover-lift" style="border-radius: 1rem; transition: transform 0.2s;">
                <div class="card-body p-4 d-flex align-items-center">
                    <div class="icon-shape bg-primary bg-opacity-10 text-primary p-3 rounded-circle me-4">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:32px;height:32px"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                    </div>
                    <div>
                        <h6 class="text-muted mb-1">Total Kriteria</h6>
                        <h2 class="fw-bold mb-0">{{ $data['kriterias']->count() }}</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100 hover-lift" style="border-radius: 1rem; transition: transform 0.2s;">
                <div class="card-body p-4 d-flex align-items-center">
                    <div class="icon-shape bg-success bg-opacity-10 text-success p-3 rounded-circle me-4">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:32px;height:32px"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                    </div>
                    <div>
                        <h6 class="text-muted mb-1">Total Alternatif</h6>
                        <h2 class="fw-bold mb-0">{{ $data['alternatifs']->count() }}</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 shadow-sm h-100 hover-lift" style="border-radius: 1rem; transition: transform 0.2s;">
                <div class="card-body p-4 d-flex align-items-center">
                    <div class="icon-shape bg-warning bg-opacity-10 text-warning p-3 rounded-circle me-4">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:32px;height:32px"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                    </div>
                    <div>
                        <h6 class="text-muted mb-1">Status Hitung</h6>
                        <h5 class="fw-bold mb-0 text-success">Siap Proses</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <h5 class="fw-bold mb-3 text-secondary">Aksi Cepat</h5>
    <div class="row g-4">
        <div class="col-md-3">
            <a href="{{ route('kriteria.index') }}" class="card text-decoration-none border-0 shadow-sm text-center p-3 h-100 hover-card" style="border-radius: 1rem;">
                <div class="card-body">
                    <div class="mb-2 text-primary">
                        <svg class="mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:40px;height:40px" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 014.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.393A9.065 9.065 0 0112 15a9.065 9.065 0 00-6.23-.693L5 14.5m14.8.8l1.402 1.402c1.232 1.232.65 3.318-1.067 3.611A48.309 48.309 0 0112 21c-2.773 0-5.491-.235-8.135-.687-1.718-.293-2.3-2.379-1.067-3.61L5 14.5" /></svg>
                    </div>
                    <h6 class="fw-bold text-dark">Kelola Kriteria</h6>
                    <small class="text-muted">Edit bobot & atribut</small>
                </div>
            </a>
        </div>
        <div class="col-md-3">
            <a href="{{ route('alternatif.index') }}" class="card text-decoration-none border-0 shadow-sm text-center p-3 h-100 hover-card" style="border-radius: 1rem;">
                <div class="card-body">
                    <div class="mb-2 text-success">
                        <svg class="mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:40px;height:40px" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z" /></svg>
                    </div>
                    <h6 class="fw-bold text-dark">Kelola Alternatif</h6>
                    <small class="text-muted">Tambah data mahasiswa</small>
                </div>
            </a>
        </div>
        <div class="col-md-3">
            <a href="{{ route('penilaian.index') }}" class="card text-decoration-none border-0 shadow-sm text-center p-3 h-100 hover-card" style="border-radius: 1rem;">
                <div class="card-body">
                    <div class="mb-2 text-warning">
                        <svg class="mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:40px;height:40px" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M11.35 3.836c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m8.9-4.414c.376.023.75.05 1.124.08 1.131.094 1.976 1.057 1.976 2.192V16.5A2.25 2.25 0 0118 18.75h-2.25m-7.5-10.5H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V18.75m-7.5-10.5h6.375c.621 0 1.125.504 1.125 1.125v9.375m-8.25-3l1.5 1.5 3-3.75" /></svg>
                    </div>
                    <h6 class="fw-bold text-dark">Input Penilaian</h6>
                    <small class="text-muted">Entri skor C2, C3, C4</small>
                </div>
            </a>
        </div>
        <div class="col-md-3">
            <a href="{{ route('hitung.index') }}" class="card text-decoration-none border-0 shadow-sm text-center p-3 h-100 hover-card" style="border-radius: 1rem;">
                <div class="card-body">
                    <div class="mb-2 text-danger">
                        <svg class="mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:40px;height:40px" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" /></svg>
                    </div>
                    <h6 class="fw-bold text-dark">Hasil Perhitungan</h6>
                    <small class="text-muted">Ranking & rekomendasi</small>
                </div>
            </a>
        </div>
    </div>

    <style>
        .hover-lift:hover { transform: translateY(-5px); }
        .hover-card:hover {
            background-color: #f8f9fa;
            border-color: #0d6efd !important;
            transform: translateY(-5px);
            transition: all 0.3s;
        }
    </style>

@endsection
