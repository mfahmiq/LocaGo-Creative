<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SPK SAW</title>
    <!-- Include Bootstrap CSS & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        body {
            margin: 0;
            padding: 0;
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
            
            /* Background from the image */
            background-color: #1459c5;
            background-image: 
                radial-gradient(rgba(255, 255, 255, 0.25) 2px, transparent 2px),
                linear-gradient(to bottom, transparent 0%, rgba(10, 25, 60, 0.8) 100%);
            background-size: 30px 30px, cover;
            background-position: center top, center center;
            background-attachment: fixed;
            
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-card {
            background: white;
            border: none;
            border-radius: 20px; 
            box-shadow: 0 20px 50px rgba(0,0,0,0.2); 
            padding: 3rem;
            width: 100%;
            max-width: 450px;
            margin: 2rem;
        }

        /* Input Customization */
        .custom-input-group {
            display: flex;
            align-items: center;
            border: 1px solid #dee2e6;
            border-radius: 10px; 
            transition: all 0.3s ease;
            background-color: #fff;
            overflow: hidden;
        }

        /* Focus State: Border Biru */
        .custom-input-group:focus-within {
            border-color: #0d6efd;
            box-shadow: 0 0 0 0.25rem rgba(13,110,253,0.15);
        }
        
        .custom-input-group.has-error {
            border-color: #dc3545;
        }
        
        .custom-input-group.has-error:focus-within {
            box-shadow: 0 0 0 0.25rem rgba(220,53,69,0.15);
        }

        .custom-input-group .input-icon {
            padding: 0.85rem 1rem;
            color: #6c757d; 
            background: transparent;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: color 0.3s;
        }

        .custom-input-group:focus-within .input-icon {
            color: #0d6efd;
        }
        
        .custom-input-group.has-error .input-icon {
            color: #dc3545;
        }

        .custom-input-group .form-control {
            border: none;
            padding: 0.85rem 0.85rem 0.85rem 0;
            box-shadow: none;
            background: transparent;
            flex: 1;
            font-size: 1rem;
            color: #495057;
        }
        
        .custom-input-group .form-control::placeholder {
            color: #adb5bd;
        }

        .password-toggle {
            cursor: pointer;
            padding: 0.85rem 1rem;
            color: #6c757d;
            background: transparent;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: color 0.2s;
        }
        
        .password-toggle:hover {
            color: #0d6efd;
        }

        /* Button Styling */
        .btn-login {
            border-radius: 10px;
            padding: 0.85rem;
            font-weight: 600;
            font-size: 1rem;
            background-color: #0d6efd;
            border: none;
            box-shadow: 0 8px 20px rgba(13, 110, 253, 0.4);
            transition: all 0.3s ease;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 25px rgba(13, 110, 253, 0.5);
            background-color: #0b5ed7;
        }
        
        .form-label {
            font-weight: 600;
            color: #495057;
            font-size: 0.9rem;
        }
        
        .login-title {
            color: #212529;
            font-weight: 700;
            font-size: 1.8rem;
            margin-bottom: 0.25rem;
        }
        
        .login-subtitle {
            color: #6c757d;
            font-size: 0.95rem;
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>

    <div class="login-card">
        <!-- Branding Logo -->
        <div class="text-center mb-4">
            <img src="{{ asset('images/logo.png') }}" alt="Logo Universitas" class="mb-3" style="height: 90px; object-fit: contain;">
            <h2 class="login-title">Login Portal</h2>
            <p class="login-subtitle">Silakan masuk ke akun Anda.</p>
        </div>

        <form action="{{ route('login') }}" method="POST">
            @csrf
            
            <!-- Email Field -->
            <div class="mb-4">
                <label class="form-label mb-2">Email Address</label>
                <div class="custom-input-group {{ $errors->has('email') ? 'has-error' : '' }}">
                    <span class="input-icon">
                        <i class="bi bi-envelope"></i>
                    </span>
                    <input type="email" name="email" value="{{ old('email') }}"
                        class="form-control"
                        placeholder="administrator" required>
                </div>
                @error('email')
                    <div class="text-danger small mt-1 fw-medium">{{ $message }}</div>
                @enderror
            </div>

            <!-- Password Field -->
            <div class="mb-4">
                <label class="form-label mb-2">Password</label>
                <div class="custom-input-group {{ $errors->has('password') ? 'has-error' : '' }}">
                    <span class="input-icon">
                        <i class="bi bi-lock"></i>
                    </span>
                    <input type="password" name="password" id="passwordField"
                        class="form-control"
                        placeholder="Masukkan password Anda" required>
                    <button type="button" class="password-toggle" id="togglePassword">
                        <i class="bi bi-eye-slash" id="toggleIcon"></i>
                    </button>
                </div>
                @error('password')
                    <div class="text-danger small mt-1 fw-medium">{{ $message }}</div>
                @enderror
            </div>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary w-100 btn-login mt-2">
                Masuk ke Akun
            </button>
        </form>
    </div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const togglePassword = document.getElementById('togglePassword');
        const passwordField = document.getElementById('passwordField');
        const toggleIcon = document.getElementById('toggleIcon');

        togglePassword.addEventListener('click', function (e) {
            // Toggle the type attribute
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
            
            // Toggle the eye / eye slash icon
            if(type === 'text') {
                toggleIcon.classList.remove('bi-eye-slash');
                toggleIcon.classList.add('bi-eye');
                toggleIcon.classList.add('text-primary');
            } else {
                toggleIcon.classList.remove('bi-eye');
                toggleIcon.classList.add('bi-eye-slash');
                toggleIcon.classList.remove('text-primary');
            }
        });
    });
</script>
</body>
</html>
