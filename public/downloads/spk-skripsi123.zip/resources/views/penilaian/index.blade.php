@extends('layouts.app')

@section('content')
<div class="card shadow-sm border-0 mb-4">
    <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="fw-bold text-primary mb-0">Input Penilaian Alternatif</h3>
            <button form="penilaianForm" type="submit" class="btn btn-primary px-4 fw-bold">
                <svg class="w-5 h-5 inline-block mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:20px;height:20px"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"></path></svg>
                Simpan Semua
            </button>
        </div>

        <div class="alert alert-light border-start border-4 border-info shadow-sm">
            <h6 class="align-items-center d-flex fw-bold text-info">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:20px;height:20px"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                Pedoman Penilaian (Rentang 0.75 - 2.00)
            </h6>
            <div class="row mt-2">
                <div class="col-md-6">
                    <strong>Ketersediaan Data (C2):</strong>
                    <p class="small text-secondary mb-0 mt-1">Isi Sesuai Referensi Jurnal</p>
                </div>
                <div class="col-md-6">
                    <strong>Minat Mahasiswa (C3), Keahlian Penelitian (C4), dan Tren Penelitian Terkini (C5):</strong>
                    <ul class="mb-0 mt-1 small text-secondary">
                        <li><span class="badge bg-danger">0.75</span> Sulit</li>
                        <li><span class="badge bg-warning text-dark">1.00</span> Lumayan Sulit</li>
                        <li><span class="badge bg-info text-dark">1.75</span> Mudah</li>
                        <li><span class="badge bg-success">2.00</span> Sangat Mudah</li>
                    </ul>
                </div>
            </div>
        </div>

        <form action="{{ route('penilaian.store') }}" method="POST" id="penilaianForm">
            @csrf
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th class="sticky-start bg-light shadow-sm" style="position: sticky; left: 0; z-index: 2;">Alternatif</th>
                            @foreach($kriterias as $kriteria)
                                <th class="text-center" style="min-width: 150px;">
                                    <span class="d-block fw-bold">{{ $kriteria->nama }}</span>
                                    <small class="text-muted badge bg-white border">{{ $kriteria->kode }}</small>
                                </th>
                            @endforeach
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($alternatifs as $alternatif)
                        <tr>
                            <td class="sticky-start bg-white shadow-sm fw-bold text-dark" style="position: sticky; left: 0;">
                                {{ $alternatif->nama }}
                                <div class="small text-muted fw-normal">{{ $alternatif->topik }}</div>
                            </td>
                            @foreach($kriterias as $kriteria)
                                @php
                                    $nilai = $alternatif->penilaians->where('kriteria_id', $kriteria->id)->first();
                                    $val = $nilai ? $nilai->nilai : 0;
                                @endphp
                                <td>
                                    <input type="number" step="0.01" min="0" 
                                        name="nilai[{{ $alternatif->id }}][{{ $kriteria->id }}]" 
                                        class="form-control text-center fw-bold border-0 bg-light focus-ring" 
                                        value="{{ $val }}" 
                                        onfocus="this.select()"
                                        style="transition: all 0.2s;">
                                </td>
                            @endforeach
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </form>
    </div>
</div>

<style>
    .focus-ring:focus {
        background: #fff !important;
        box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
        border: 1px solid #86b7fe !important;
    }
    .sticky-start {
        border-right: 1px solid #dee2e6;
    }
</style>
@endsection
