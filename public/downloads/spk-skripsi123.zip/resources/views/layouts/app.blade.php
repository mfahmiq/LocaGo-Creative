<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SPK - Simple Additive Weighting</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        /* ===== SIDEBAR & LAYOUT ===== */
        :root {
            --sidebar-width: 260px;
            --sidebar-collapsed-width: 85px;
            --sidebar-bg: #1e2a3a;
            --sidebar-active: #0d6efd;
            --sidebar-text: #c8d6e5;
            --sidebar-text-muted: #6c8aaa;
        }

        body {
            background: #f0f4f8;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Sidebar Base */
        #sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: var(--sidebar-bg);
            display: flex;
            flex-direction: column;
            z-index: 1000;
            transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            overflow-y: auto;
            overflow-x: hidden;
            box-shadow: 4px 0 10px rgba(0,0,0,0.05);
        }

        /* Collapsed State (Desktop) */
        @media (min-width: 769px) {
            body.sidebar-collapsed #sidebar {
                width: var(--sidebar-collapsed-width);
            }
            body.sidebar-collapsed #main-content {
                margin-left: var(--sidebar-collapsed-width);
            }
            body.sidebar-collapsed .brand-text,
            body.sidebar-collapsed .nav-text,
            body.sidebar-collapsed .nav-label,
            body.sidebar-collapsed .user-info-text {
                display: none;
            }
            body.sidebar-collapsed .sidebar-brand a {
                justify-content: center;
                padding-left: 0;
            }
            body.sidebar-collapsed .sidebar-nav .nav-link {
                justify-content: center;
                margin: 0.3rem 0.75rem;
                padding: 0.75rem;
            }
            body.sidebar-collapsed .sidebar-nav .nav-link svg {
                margin-right: 0;
            }
            body.sidebar-collapsed .sidebar-user {
                justify-content: center;
                padding: 1rem 0;
            }
            body.sidebar-collapsed .btn-logout span {
                display: none;
            }
            body.sidebar-collapsed .btn-logout svg {
                margin: 0;
            }
        }

        /* Brand / Logo */
        .sidebar-brand {
            padding: 1.5rem 1.25rem 1rem;
        }
        .sidebar-brand a {
            text-decoration: none;
            color: #fff;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            white-space: nowrap;
        }
        .sidebar-brand .brand-icon {
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .sidebar-brand .brand-text {
            font-weight: 800;
            font-size: 1.2rem;
            letter-spacing: 0.5px;
        }

        /* Divider */
        .sidebar-divider {
            border-top: 1px solid rgba(255,255,255,0.08);
            margin: 0 1.25rem 0.5rem 1.25rem;
        }

        /* Nav links */
        .sidebar-nav {
            flex: 1;
            padding: 0.5rem 0;
        }
        .sidebar-nav .nav-label {
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            color: var(--sidebar-text-muted);
            padding: 0.75rem 1.5rem 0.25rem;
            font-weight: 700;
            white-space: nowrap;
        }
        .sidebar-nav .nav-link {
            display: flex;
            align-items: center;
            padding: 0.7rem 1rem;
            margin: 0.3rem 1.25rem; /* Pill shape margin */
            color: var(--sidebar-text);
            font-size: 0.9rem;
            font-weight: 500;
            border-radius: 8px; /* Sudut membulat */
            transition: all 0.2s ease;
            text-decoration: none;
            white-space: nowrap;
        }
        
        .sidebar-nav .nav-link svg {
            flex-shrink: 0;
            color: var(--sidebar-text-muted); /* Ikon lebih redup */
            margin-right: 0.8rem;
            transition: color 0.2s ease;
        }

        /* Hover State */
        .sidebar-nav .nav-link:hover {
            background: rgba(255,255,255,0.06);
            color: #fff;
            transform: translateX(3px);
        }
        .sidebar-nav .nav-link:hover svg {
            color: #fff; /* Ikon putih saat hover */
        }

        /* Active State (Pill) */
        .sidebar-nav .nav-link.active {
            background: var(--sidebar-active);
            color: #fff;
            box-shadow: 0 4px 12px rgba(13,110,253,0.25); /* Efek melayang */
            font-weight: 600;
        }
        .sidebar-nav .nav-link.active svg {
            color: #fff; /* Ikon solid putih saat aktif */
        }

        /* User info bottom */
        .sidebar-user {
            padding: 1.25rem;
            border-top: 1px solid rgba(255,255,255,0.08);
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        .sidebar-user .user-profile {
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        .sidebar-user .user-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: rgba(13,110,253,0.2);
            color: var(--sidebar-active);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 15px;
            flex-shrink: 0;
            border: 2px solid rgba(13,110,253,0.4);
        }
        .sidebar-user .user-name {
            font-size: 0.9rem;
            font-weight: 600;
            color: #fff;
            line-height: 1.2;
            white-space: nowrap;
        }
        .sidebar-user .user-role {
            font-size: 0.75rem;
            color: var(--sidebar-text-muted);
            white-space: nowrap;
        }
        .btn-logout {
            background: rgba(220,53,69,0.1);
            border: 1px solid rgba(220,53,69,0.2);
            color: #ff6b6b;
            font-size: 0.8rem;
            font-weight: 500;
            padding: 0.5rem;
            border-radius: 8px;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            width: 100%;
        }
        .btn-logout:hover {
            background: rgba(220,53,69,0.25);
            color: #fff;
        }

        /* Main content */
        #main-content {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
            padding: 1.5rem 2rem;
            transition: margin-left 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            display: flex;
            flex-direction: column;
        }

        /* Top Navbar / Header */
        .top-navbar {
            background: #fff;
            border-radius: 12px;
            padding: 0.75rem 1.25rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 12px rgba(0,0,0,0.03);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .hamburger-btn {
            background: transparent;
            border: none;
            color: #495057;
            padding: 0.5rem;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }
        .hamburger-btn:hover {
            background: #f8f9fa;
            color: var(--sidebar-active);
        }

        /* Responsive: mobile toggle (Off-Canvas) */
        @media (max-width: 768px) {
            #sidebar {
                transform: translateX(-100%);
                box-shadow: none;
            }
            #sidebar.show {
                transform: translateX(0);
                box-shadow: 4px 0 20px rgba(0,0,0,0.15);
            }
            #main-content {
                margin-left: 0 !important;
                padding: 1rem;
            }
            .top-navbar {
                border-radius: 8px;
                padding: 0.75rem 1rem;
            }
        }

        /* Alert styling */
        .alert { border-radius: 10px; }
    </style>
</head>
<body>

{{-- ===== SIDEBAR ===== --}}
<div id="sidebar">

    {{-- Brand --}}
    <div class="sidebar-brand">
        <a href="{{ url('/') }}" title="Sistem Pendukung Keputusan Penentuan Minat Topik dan Judul Skripsi Mahasiswa">
            <span class="brand-icon">
                <img src="{{ asset('images/logo.png') }}" alt="Logo UPS" style="width: 36px; height: auto; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));">
            </span>
            <span class="brand-text">SPK - SAW</span>
        </a>
    </div>

    <div class="sidebar-divider"></div>

    {{-- Navigation --}}
    <nav class="sidebar-nav">
        @auth
            <div class="nav-label">Menu Utama</div>

            <a href="{{ route('dashboard') }}"
               class="nav-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M8 4a.5.5 0 0 1 .5.5V6a.5.5 0 0 1-1 0V4.5A.5.5 0 0 1 8 4M3.732 5.732a.5.5 0 0 1 .707 0l.915.914a.5.5 0 1 1-.708.708l-.914-.915a.5.5 0 0 1 0-.707M2 10a.5.5 0 0 1 .5-.5h1.586a.5.5 0 0 1 0 1H2.5A.5.5 0 0 1 2 10m9.5 0a.5.5 0 0 1 .5-.5h1.5a.5.5 0 0 1 0 1H12a.5.5 0 0 1-.5-.5m.754-4.246a.389.389 0 0 0-.527-.02L7.547 9.31a.91.91 0 1 0 1.302 1.258l3.434-4.297a.389.389 0 0 0-.029-.518z"/>
                    <path fill-rule="evenodd" d="M0 10a8 8 0 1 1 15.547 2.661c-.442 1.253-1.845 1.602-2.932 1.25C11.309 13.488 9.475 13 8 13c-1.474 0-3.31.488-4.615.911-1.087.352-2.49.003-2.932-1.25A8 8 0 0 1 0 10"/>
                </svg>
                <span class="nav-text">Dashboard</span>
            </a>

            <a href="{{ route('hitung.index') }}"
               class="nav-link {{ request()->routeIs('hitung.*') ? 'active' : '' }}">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M12 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zM4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2z"/>
                    <path d="M4 2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.5.5h-7a.5.5 0 0 1-.5-.5zm0 4a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5zm0 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5zm4-3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5zm0 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5zm3-3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v4a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5z"/>
                </svg>
                <span class="nav-text">Perhitungan SAW</span>
            </a>

            @if(auth()->user()->role == 'admin')
                <div class="nav-label mt-2">Kelola Data</div>

                <a href="{{ route('kriteria.index') }}"
                   class="nav-link {{ request()->routeIs('kriteria.*') ? 'active' : '' }}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5M2 2a1 1 0 0 0-1 1v1h14V3a1 1 0 0 0-1-1zm13 3H1v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1z"/>
                    </svg>
                    <span class="nav-text">Kriteria</span>
                </a>

                <a href="{{ route('alternatif.index') }}"
                   class="nav-link {{ request()->routeIs('alternatif.*') ? 'active' : '' }}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5"/>
                    </svg>
                    <span class="nav-text">Alternatif</span>
                </a>

                <a href="{{ route('penilaian.index') }}"
                   class="nav-link {{ request()->routeIs('penilaian.*') ? 'active' : '' }}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16">
                        <path d="M9.5 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V4.5zm0 1v2A1.5 1.5 0 0 0 11 4.5h2V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zM4.5 7a.5.5 0 0 0 0 1h7a.5.5 0 0 0 0-1zm0 2.5a.5.5 0 0 0 0 1h7a.5.5 0 0 0 0-1zm0 2.5a.5.5 0 0 0 0 1H7a.5.5 0 0 0 0-1z"/>
                    </svg>
                    <span class="nav-text">Penilaian</span>
                </a>
            @endif

        @else
            {{-- Guest: Daftar & Login --}}
            <div class="nav-label">Akun</div>
            <a href="{{ route('register') }}" class="nav-link {{ request()->routeIs('register') ? 'active' : '' }}">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6m2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0m4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4m-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.288 10 6 10s-3.516.68-4.168 1.332c-.678.678-.83 1.418-.832 1.664z"/>
                    <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5"/>
                </svg>
                <span class="nav-text">Daftar Mahasiswa</span>
            </a>
            <a href="{{ route('login') }}" class="nav-link {{ request()->routeIs('login') ? 'active' : '' }}">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0z"/>
                    <path fill-rule="evenodd" d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708z"/>
                </svg>
                <span class="nav-text">Masuk / Login</span>
            </a>
        @endauth
    </nav>



</div>
{{-- ===== END SIDEBAR ===== --}}

{{-- ===== MAIN CONTENT ===== --}}
<div id="main-content">

    {{-- Top Navbar (Header) --}}
    @if(!request()->routeIs('login') && !request()->routeIs('register'))
    <nav class="top-navbar">
        <!-- Left Side: Hamburger & Context -->
        <div class="d-flex align-items-center gap-4">
            <button class="hamburger-btn" onclick="toggleSidebar()" aria-label="Toggle Sidebar">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" width="24" height="24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                </svg>
            </button>
            <div class="d-none d-md-flex align-items-center text-muted small fw-medium" style="letter-spacing: 0.3px;">
                <i class="bi bi-house-door me-2"></i> Dashboard <span class="mx-2 text-black-50">/</span> <span class="text-primary fw-bold">{{ ucfirst(request()->segment(1) ?: 'Beranda') }}</span>
            </div>
        </div>
        
        <!-- Right Side: User Profile & Actions -->
        @auth
        <div class="d-flex align-items-center gap-4">


            <!-- Profile Dropdown -->
            <div class="dropdown">
                <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="dropdownUser" data-bs-toggle="dropdown" aria-expanded="false" style="color: inherit;">
                    <div class="d-none d-sm-block text-end me-3">
                        <div class="text-dark fw-bold lh-1 mb-1" style="font-size: 0.9rem;">{{ Auth::user()->name }}</div>
                        <div class="text-muted" style="font-size: 0.75rem; letter-spacing: 0.5px;">{{ ucfirst(Auth::user()->role) }}</div>
                    </div>
                    <!-- User Avatar (Initials) -->
                    <div class="bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25 d-flex align-items-center justify-content-center rounded-circle fw-bold shadow-sm transition-hover" style="width: 42px; height: 42px; font-size: 1.1rem;">
                        {{ strtoupper(substr(Auth::user()->name, 0, 1)) }}
                    </div>
                </a>
                
                <!-- Dropdown Menu -->
                <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 mt-3 rounded-4" aria-labelledby="dropdownUser" style="min-width: 240px; animation: fadeInUp 0.2s ease-out;">
                    <!-- Dropdown Header Info -->
                    <li class="px-4 py-3 text-center border-bottom mb-2 bg-light rounded-top-4">
                        <div class="fw-bold text-dark fs-6">{{ Auth::user()->name }}</div>
                        <div class="small text-muted">{{ Auth::user()->email }}</div>
                    </li>
                    
                    <!-- Logout -->
                    <li>
                        <form action="{{ route('logout') }}" method="POST" class="m-0">
                            @csrf
                            <button type="submit" class="dropdown-item d-flex align-items-center gap-3 py-2 px-4 text-danger fw-medium w-100 text-start hover-danger">
                                <i class="bi bi-box-arrow-right"></i> Keluar Sistem
                            </button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
        @endauth
    </nav>
    @else
    {{-- On login/register, still provide a mobile toggle if they want to access the sidebar --}}
    <button class="hamburger-btn d-md-none position-absolute" style="top: 1rem; left: 1rem; z-index: 1050; background: white; box-shadow: 0 2px 5px rgba(0,0,0,0.1);" onclick="toggleSidebar()">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" width="24" height="24">
            <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
        </svg>
    </button>
    @endif

    {{-- Flash Messages --}}
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show mb-4 border-0 shadow-sm" role="alert">
            <div class="d-flex align-items-center gap-2">
                <i class="bi bi-check-circle-fill"></i>
                <div>{{ session('success') }}</div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if($errors->any())
        <div class="alert alert-danger alert-dismissible fade show mb-4 border-0 shadow-sm" role="alert">
            <strong>⚠️ Terdapat kesalahan:</strong>
            <ul class="mb-0 mt-2">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    {{-- Page Content --}}
    @yield('content')

</div>
{{-- ===== END MAIN CONTENT ===== --}}

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function toggleSidebar() {
        if (window.innerWidth <= 768) {
            // Off-Canvas on Mobile
            document.getElementById('sidebar').classList.toggle('show');
        } else {
            // Mini Sidebar on Desktop
            document.body.classList.toggle('sidebar-collapsed');
        }
    }

    // Close sidebar on outside click (mobile only)
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
            const sidebar = document.getElementById('sidebar');
            const toggles = document.querySelectorAll('.hamburger-btn');
            
            let clickedOnToggle = false;
            toggles.forEach(btn => {
                if(btn.contains(e.target)) clickedOnToggle = true;
            });

            if (!sidebar.contains(e.target) && !clickedOnToggle) {
                sidebar.classList.remove('show');
            }
        }
    });
</script>
</body>
</html>
