@extends('layouts.app')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="fw-bold text-dark mb-0">Data Alternatif</h3>
    <div class="d-flex gap-2">
        <button class="btn btn-success rounded-pill shadow-sm px-4" data-bs-toggle="modal" data-bs-target="#importModal">
            <i class="bi bi-file-earmark-excel me-1"></i> Import CSV / Excel
        </button>
        <button class="btn btn-primary rounded-pill shadow-sm px-4" data-bs-toggle="modal" data-bs-target="#createModal">
            <i class="bi bi-plus-lg me-1"></i> Tambah Alternatif
        </button>
    </div>
</div>

<div class="card border-0 shadow-sm rounded-4 mb-4">
    <div class="card-body p-4">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="text-uppercase text-secondary fw-semibold border-bottom-0 text-center" style="font-size: 0.75rem; letter-spacing: 0.5px; width: 50px;">No.</th>
                        <th class="text-uppercase text-secondary fw-semibold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">NPM</th>
                        <th class="text-uppercase text-secondary fw-semibold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Nama</th>
                        <th class="text-uppercase text-secondary fw-semibold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Topik</th>
                        <th class="text-uppercase text-secondary fw-semibold border-bottom-0" style="font-size: 0.75rem; letter-spacing: 0.5px;">Keterangan</th>
                        <th class="text-uppercase text-secondary fw-semibold border-bottom-0 text-center" style="font-size: 0.75rem; letter-spacing: 0.5px; width: 120px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($alternatifs as $alternatif)
                    <tr>
                        <td class="text-center text-muted border-light">{{ $loop->iteration }}</td>
                        <td class="fw-bold text-dark border-light">{{ $alternatif->npm }}</td>
                        <td class="fw-bold text-dark border-light">{{ $alternatif->nama }}</td>
                        <td class="border-light">
                            <span class="badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25 rounded-pill px-3 py-2" style="font-weight: 600;">{{ $alternatif->topik }}</span>
                        </td>
                        <td style="max-width: 300px;" class="text-truncate text-muted border-light" title="{{ $alternatif->keterangan }}" data-bs-toggle="tooltip" data-bs-placement="top">
                            {{ $alternatif->keterangan }}
                        </td>
                        <td class="border-light text-center">
                            <div class="d-flex justify-content-center gap-1">
                                <button class="btn btn-sm btn-outline-primary border-0 rounded-circle" data-bs-toggle="modal" data-bs-target="#editModal{{ $alternatif->id }}" title="Edit">
                                    <i class="bi bi-pencil-square" style="font-size: 1.1rem;"></i>
                                </button>
                                <form action="{{ route('alternatif.destroy', $alternatif->id) }}" method="POST" class="d-inline">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger border-0 rounded-circle" onclick="return confirm('Yakin ingin menghapus alternatif ini?')" title="Hapus">
                                        <i class="bi bi-trash" style="font-size: 1.1rem;"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>

        <!-- Edit Modal -->
        <div class="modal fade" id="editModal{{ $alternatif->id }}" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="{{ route('alternatif.update', $alternatif->id) }}" method="POST">
                        @csrf @method('PUT')
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Alternatif</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label>NPM</label>
                                <input type="text" name="npm" class="form-control" value="{{ $alternatif->npm }}" required>
                            </div>
                            <div class="mb-3">
                                <label>Nama</label>
                                <input type="text" name="nama" class="form-control" value="{{ $alternatif->nama }}" required>
                            </div>
                            <div class="mb-3">
                                <label>Topik</label>
                                <select name="topik" class="form-control" required>
                                    <option value="">Pilih Topik</option>
                                    @foreach(['Pemrograman Web', 'Data Mining', 'Kecerdasan Buatan (AI)', 'Internet of Things (IoT)'] as $topik)
                                        <option value="{{ $topik }}" {{ $alternatif->topik == $topik ? 'selected' : '' }}>{{ $topik }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Keterangan</label>
                                <textarea name="keterangan" class="form-control">{{ $alternatif->keterangan }}</textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        @endforeach
    </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        })
    });
</script>

<!-- Create Modal -->
<div class="modal fade" id="createModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('alternatif.store') }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Tambah Alternatif</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>NPM</label>
                        <input type="text" name="npm" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Nama</label>
                        <input type="text" name="nama" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Topik</label>
                        <select name="topik" class="form-control" required>
                            <option value="">Pilih Topik</option>
                            @foreach(['Pemrograman Web', 'Data Mining', 'Kecerdasan Buatan (AI)', 'Internet of Things (IoT)'] as $topik)
                                <option value="{{ $topik }}">{{ $topik }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Keterangan</label>
                        <textarea name="keterangan" class="form-control"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Import Modal -->
<div class="modal fade" id="importModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('alternatif.import') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Import Data Alternatif & Nilai</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">File Template (CSV / Excel)</label>
                        <input type="file" name="file_csv" class="form-control" accept=".csv,.xls" required>
                        <div class="form-text">Pastikan file sesuai dengan template. Format yang didukung: .csv, .xls</div>
                    </div>
                    <div class="mb-1 text-end">
                        <a href="{{ route('alternatif.template') }}" class="btn btn-sm btn-outline-info">
                            <i class="bi bi-download"></i> Download Template Excel (.xls)
                        </a>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Import</button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection
