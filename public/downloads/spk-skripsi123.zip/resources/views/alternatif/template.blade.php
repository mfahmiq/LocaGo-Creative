<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
    <table>
        <thead>
            <tr>
                <th style="font-family: Arial, sans-serif; font-size: 10pt; font-weight: bold; background-color: #1E2A3A; color: #FFFFFF; border: 1px solid #000000; text-align: center; vertical-align: middle; width: 150px; height: 35px;">NPM</th>
                <th style="font-family: Arial, sans-serif; font-size: 10pt; font-weight: bold; background-color: #1E2A3A; color: #FFFFFF; border: 1px solid #000000; text-align: center; vertical-align: middle; width: 200px; height: 35px;">Nama</th>
                <th style="font-family: Arial, sans-serif; font-size: 10pt; font-weight: bold; background-color: #1E2A3A; color: #FFFFFF; border: 1px solid #000000; text-align: center; vertical-align: middle; width: 220px; height: 35px;">Topik</th>
                <th style="font-family: Arial, sans-serif; font-size: 10pt; font-weight: bold; background-color: #1E2A3A; color: #FFFFFF; border: 1px solid #000000; text-align: center; vertical-align: middle; width: 350px; height: 35px;">Keterangan Judul</th>
                @foreach($kriterias as $k)
                <th style="font-family: Arial, sans-serif; font-size: 10pt; font-weight: bold; background-color: #1E2A3A; color: #FFFFFF; border: 1px solid #000000; text-align: center; vertical-align: middle; width: 100px; height: 35px;">{{ $k->kode }}</th>
                @endforeach
            </tr>
        </thead>
        <tbody>
            @for($i = 0; $i < 3; $i++)
            <tr>
                <td style="font-family: Arial, sans-serif; font-size: 10pt; border: 1px solid #000000; text-align: center; vertical-align: middle; height: 30px; padding: 5px;"></td>
                <td style="font-family: Arial, sans-serif; font-size: 10pt; border: 1px solid #000000; text-align: center; vertical-align: middle; height: 30px; padding: 5px;"></td>
                <td style="font-family: Arial, sans-serif; font-size: 10pt; border: 1px solid #000000; text-align: center; vertical-align: middle; height: 30px; padding: 5px;"></td>
                <td style="font-family: Arial, sans-serif; font-size: 10pt; border: 1px solid #000000; text-align: center; vertical-align: middle; height: 30px; padding: 5px;"></td>
                @foreach($kriterias as $k)
                <td style="font-family: Arial, sans-serif; font-size: 10pt; border: 1px solid #000000; text-align: center; vertical-align: middle; height: 30px; padding: 5px;"></td>
                @endforeach
            </tr>
            @endfor
        </tbody>
    </table>
</body>
</html>
