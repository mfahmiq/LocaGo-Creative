<?php
require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

// ==========================================
// AMBIL DATA UNTUK UJI VALIDITAS SAW
// ==========================================

$kriterias = \App\Models\Kriteria::orderBy('kode')->get();
$alternatifs = \App\Models\Alternatif::with('penilaians.kriteria')->take(5)->get();

echo "============================================================\n";
echo "     DATA SAMPEL UNTUK UJI VALIDITAS ALGORITMA SAW\n";
echo "============================================================\n\n";

// 1. DATA KRITERIA
echo "=== 1. DATA KRITERIA ===\n";
echo str_pad("No", 4) . str_pad("Kode", 8) . str_pad("Nama Kriteria", 35) . str_pad("Bobot", 10) . "Jenis\n";
echo str_repeat("-", 70) . "\n";
$no = 1;
foreach ($kriterias as $k) {
    echo str_pad($no, 4) . str_pad($k->kode, 8) . str_pad($k->nama, 35) . str_pad($k->bobot, 10) . $k->jenis . "\n";
    $no++;
}
$totalBobot = $kriterias->sum('bobot');
echo str_repeat("-", 70) . "\n";
echo str_pad("", 4) . str_pad("", 8) . str_pad("TOTAL BOBOT", 35) . $totalBobot . "\n\n";

// 2. DATA ALTERNATIF
echo "=== 2. DATA ALTERNATIF (5 Sampel) ===\n";
echo str_pad("No", 4) . str_pad("Kode", 8) . str_pad("NPM", 15) . str_pad("Nama", 30) . "Topik\n";
echo str_repeat("-", 90) . "\n";
$no = 1;
foreach ($alternatifs as $a) {
    $kode = "A" . $no;
    echo str_pad($no, 4) . str_pad($kode, 8) . str_pad($a->npm ?? '-', 15) . str_pad($a->nama, 30) . ($a->topik ?? '-') . "\n";
    $no++;
}
echo "\n";

// 3. MATRIKS KEPUTUSAN (NILAI ASLI)
echo "=== 3. MATRIKS KEPUTUSAN (Nilai Asli) ===\n";
$header = str_pad("Alternatif", 20);
foreach ($kriterias as $k) {
    $header .= str_pad($k->kode . "(" . substr($k->jenis,0,1) . ")", 12, " ", STR_PAD_LEFT);
}
echo $header . "\n";
echo str_repeat("-", 20 + 12 * count($kriterias)) . "\n";

$nilaiMatrix = [];
$no = 1;
foreach ($alternatifs as $a) {
    $kode = "A" . $no;
    $row = str_pad($kode . " - " . mb_substr($a->nama, 0, 12), 20);
    foreach ($kriterias as $k) {
        $penilaian = $a->penilaians->where('kriteria_id', $k->id)->first();
        $nilai = $penilaian ? $penilaian->nilai : 0;
        $nilaiMatrix[$a->id][$k->id] = $nilai;
        $row .= str_pad($nilai, 12, " ", STR_PAD_LEFT);
    }
    echo $row . "\n";
    $no++;
}
echo "\n";

// 4. MENENTUKAN MAX & MIN
echo "=== 4. NILAI MAX DAN MIN PER KRITERIA ===\n";
$minMax = [];
foreach ($kriterias as $k) {
    $nilaiKolom = [];
    foreach ($alternatifs as $a) {
        $nilaiKolom[] = $nilaiMatrix[$a->id][$k->id];
    }
    $minMax[$k->id] = [
        'min' => min($nilaiKolom),
        'max' => max($nilaiKolom),
    ];
}

$headerMM = str_pad("", 12);
foreach ($kriterias as $k) {
    $headerMM .= str_pad($k->kode, 12, " ", STR_PAD_LEFT);
}
echo $headerMM . "\n";
echo str_repeat("-", 12 + 12 * count($kriterias)) . "\n";

$rowMax = str_pad("Max", 12);
$rowMin = str_pad("Min", 12);
foreach ($kriterias as $k) {
    $rowMax .= str_pad($minMax[$k->id]['max'], 12, " ", STR_PAD_LEFT);
    $rowMin .= str_pad($minMax[$k->id]['min'], 12, " ", STR_PAD_LEFT);
}
echo $rowMax . "\n";
echo $rowMin . "\n\n";

// 5. NORMALISASI
echo "=== 5. MATRIKS NORMALISASI ===\n";
$normalized = [];
foreach ($alternatifs as $a) {
    foreach ($kriterias as $k) {
        $nilai = $nilaiMatrix[$a->id][$k->id];
        if ($k->jenis == 'benefit') {
            $norm = $minMax[$k->id]['max'] > 0 ? $nilai / $minMax[$k->id]['max'] : 0;
        } else {
            $norm = $nilai > 0 ? $minMax[$k->id]['min'] / $nilai : 0;
        }
        $normalized[$a->id][$k->id] = $norm;
    }
}

$headerN = str_pad("Alternatif", 20);
foreach ($kriterias as $k) {
    $headerN .= str_pad($k->kode, 12, " ", STR_PAD_LEFT);
}
echo $headerN . "\n";
echo str_repeat("-", 20 + 12 * count($kriterias)) . "\n";

$no = 1;
foreach ($alternatifs as $a) {
    $kode = "A" . $no;
    $row = str_pad($kode, 20);
    foreach ($kriterias as $k) {
        $row .= str_pad(number_format($normalized[$a->id][$k->id], 4), 12, " ", STR_PAD_LEFT);
    }
    echo $row . "\n";
    $no++;
}
echo "\n";

// 6. DETAIL PERHITUNGAN NORMALISASI PER KRITERIA
echo "=== 6. DETAIL PERHITUNGAN NORMALISASI ===\n\n";
foreach ($kriterias as $k) {
    echo "--- Kriteria {$k->kode}: {$k->nama} ({$k->jenis}) ---\n";
    if ($k->jenis == 'benefit') {
        echo "Rumus: rij = Xij / max(Xij), max = {$minMax[$k->id]['max']}\n";
    } else {
        echo "Rumus: rij = min(Xij) / Xij, min = {$minMax[$k->id]['min']}\n";
    }
    echo str_pad("Alt", 6) . str_pad("Xij", 8) . str_pad("Perhitungan", 25) . "rij\n";
    echo str_repeat("-", 50) . "\n";
    $no = 1;
    foreach ($alternatifs as $a) {
        $kode = "A" . $no;
        $nilai = $nilaiMatrix[$a->id][$k->id];
        if ($k->jenis == 'benefit') {
            $perhitungan = "{$nilai} / {$minMax[$k->id]['max']}";
        } else {
            $perhitungan = "{$minMax[$k->id]['min']} / {$nilai}";
        }
        $rij = number_format($normalized[$a->id][$k->id], 4);
        echo str_pad($kode, 6) . str_pad($nilai, 8) . str_pad($perhitungan, 25) . $rij . "\n";
        $no++;
    }
    echo "\n";
}

// 7. PERHITUNGAN NILAI PREFERENSI
echo "=== 7. PERHITUNGAN NILAI PREFERENSI (Vi) ===\n\n";
$ranks = [];
$no = 1;
foreach ($alternatifs as $a) {
    $kode = "A" . $no;
    echo "--- {$kode}: {$a->nama} ---\n";
    echo "Vi = ";
    $parts = [];
    $score = 0;
    foreach ($kriterias as $k) {
        $w = $k->bobot;
        $r = $normalized[$a->id][$k->id];
        $product = $w * $r;
        $score += $product;
        $parts[] = "({$w} x " . number_format($r, 4) . ")";
    }
    echo implode(" + ", $parts) . "\n";
    
    // Show intermediate
    $partsVal = [];
    foreach ($kriterias as $k) {
        $w = $k->bobot;
        $r = $normalized[$a->id][$k->id];
        $product = $w * $r;
        $partsVal[] = number_format($product, 4);
    }
    echo "Vi = " . implode(" + ", $partsVal) . "\n";
    echo "Vi = " . number_format($score, 4) . "\n\n";
    
    $ranks[$a->id] = ['kode' => $kode, 'nama' => $a->nama, 'score' => $score];
    $no++;
}

// 8. HASIL PERANKINGAN
echo "=== 8. HASIL PERANKINGAN ===\n";
usort($ranks, function($a, $b) { return $b['score'] <=> $a['score']; });

echo str_pad("Rank", 6) . str_pad("Kode", 8) . str_pad("Nama", 30) . str_pad("Skor", 12) . "Status\n";
echo str_repeat("-", 80) . "\n";
$peringkat = 1;
foreach ($ranks as $r) {
    if ($r['score'] > 0.70) {
        $status = 'Prioritas Utama';
    } elseif ($r['score'] >= 0.60) {
        $status = 'Direkomendasikan';
    } else {
        $status = 'Dipertimbangkan / Perlu Revisi Judul';
    }
    echo str_pad($peringkat, 6) . str_pad($r['kode'], 8) . str_pad($r['nama'], 30) . str_pad(number_format($r['score'], 4), 12) . $status . "\n";
    $peringkat++;
}
echo "\n";
echo "============================================================\n";
echo "  Data di atas siap digunakan untuk Uji Validitas Skripsi\n";
echo "============================================================\n";
