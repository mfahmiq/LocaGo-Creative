# Warehouse & Inventory Management System - Sistem Penjualan Stok Opname

```
========================================================================
📦 Warehouse & Inventory Management System - Sistem Penjualan Stok Opname
Kategori     : Bisnis & Manajemen
Tech Stack   : PHP Native • PHP • MySQL
Database     : MySQL (.sql) (File: sistem_penjualan.sql)
Sumber Asli  : https://github.com/FerdiGeasil/sistem-penjualan-stok-opname (GitHub Open Source)
Stars GitHub : ⭐ 0 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/sistem-penjualan-stok-opname`
     * Untuk Laragon: `C:/laragon/www/sistem-penjualan-stok-opname`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - File SQL ini membuat database `sistem_penjualan_stok_opname` sendiri — tidak perlu membuat
     database manual. Klik tab 'Import', pilih file SQL yang disertakan pada:
     `sistem_penjualan.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. JALANKAN SEED — WAJIB (membuat akun login + data contoh):
   - Buka di browser: http://localhost/sistem-penjualan-stok-opname/seeder.php
   - Langkah ini membuat akun login di bawah + mengisi data contoh.
     TANPA langkah ini akun login TIDAK BISA dipakai: password di file .sql
     tidak didokumentasikan oleh repo aslinya.

4. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = sistem_penjualan_stok_opname

5. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/sistem-penjualan-stok-opname

6. AKUN LOGIN DEMO:
   - Repo ini tidak mendokumentasikan akun demo di README-nya.
     Cek README.md repo asli atau tabel `users` di phpMyAdmin;
     JANGAN pakai tebakan umum (admin/admin123 dsb.) — belum tentu benar.

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
