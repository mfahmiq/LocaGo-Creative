# Panduan Billing Rental PS Desktop
1. Install Python di komputer kasir Windows.
2. Jalankan perintah `python app.py`.
3. Untuk membuat file `.exe` mandiri tanpa instalasi Python:
   Jalankan `pip install pyinstaller` lalu `pyinstaller --onefile --windowed app.py`.
