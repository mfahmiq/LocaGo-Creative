# Billing Rental PS Desktop - LocaGo Creative
import tkinter as tk
from tkinter import ttk, messagebox
import datetime

class BillingPSApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🎮 Billing Rental PS & Game Cafe v2.0")
        self.root.geometry("800x500")
        
        tk.Label(root, text="SISTEM BILLING RENTAL PS & CAFE", font=("Arial", 16, "bold")).pack(pady=10)
        
        frame = tk.Frame(root)
        frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        self.consoles = [f"PS5 #{i+1:02d}" for i in range(8)]
        for i, c in enumerate(self.consoles):
            btn = tk.Button(frame, text=f"{c}\n[STANDBY]", font=("Arial", 12), width=15, height=4, bg="#10b981", fg="white",
                            command=lambda name=c: self.start_session(name))
            btn.grid(row=i//4, column=i%4, padx=10, pady=10)
            
    def start_session(self, name):
        messagebox.showinfo("Mulai Rental", f"Sesi sewa {name} telah dimulai! Tarif Rp 10.000/jam.")

if __name__ == "__main__":
    root = tk.Tk()
    app = BillingPSApp(root)
    root.mainloop()
