<?php
session_start();
if(isset($_POST['tombol'])){
    /** @var mysqli $koneksi */
    include'koneksi.php';
    $nis = $_POST['nis'];
    $nama_anggota = $_POST['nama_anggota'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $kelas = $_POST['kelas'];
    $query = "INSERT INTO anggota(nis, nama_anggota, username, password, kelas) VALUES('$nis', '$nama_anggota', '$username', '$password', '$kelas')";
    $data = mysqli_query($koneksi,$query);
    if($data){
        echo"<script>alert('Pendaftaran Berhasil'); window.location.assign('login-anggota.php');</script>";
        exit;
    }else{
        echo"<script>alert('Pendaftaran Gagal'); window.location.assign('pendaftaran-anggota.php');</script>";
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran Anggota - Aplikasi Perpustakaan Labuna SMKN 1 Wanayasa</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
</head>
<body class="page-pendaftaran-anggota d-flex align-items-center justify-content-center py-4">

    <div class="bg-overlay"></div>

    <div class="container d-flex justify-content-center">
        <div class="card card-custom p-4 p-md-4">
            
            <div class="avatar-badge">
                <i class="bi bi-person-plus-fill"></i>
            </div>

            <h4 class="text-center fw-bold text-dark mb-1" style="font-size: 1.35rem;">Pendaftaran Anggota</h4>
            <h6 class="text-center text-muted mb-4" style="font-size: 0.85rem; line-height: 1.4;">
                Aplikasi Perpustakaan Labuna<br>
                <span class="fw-semibold" style="color: #064e3b;">SMKN 1 Wanayasa</span>
            </h6>

            <form method="post" action="">

                <div class="position-relative mb-3">
                    <span class="input-group-text-custom">
                        <i class="bi bi-card-text"></i>
                    </span>
                    <input type="text" name="nis" class="form-control form-control-icon" placeholder="Masukan NIS" required>
                </div>


                <div class="position-relative mb-3">
                    <span class="input-group-text-custom">
                        <i class="bi bi-person"></i>
                    </span>
                    <input type="text" name="nama_anggota" class="form-control form-control-icon" placeholder="Masukan Nama Anggota" required>
                </div>


                <div class="position-relative mb-3">
                    <span class="input-group-text-custom">
                        <i class="bi bi-at"></i>
                    </span>
                    <input type="text" name="username" class="form-control form-control-icon" placeholder="Masukan Username" required>
                </div>

                <div class="position-relative mb-3">
                    <span class="input-group-text-custom">
                        <i class="bi bi-lock"></i>
                    </span>
                    <input type="password" name="password" class="form-control form-control-icon" placeholder="Masukan Password" required>
                </div>

                <div class="position-relative mb-4">
                    <span class="input-group-text-custom">
                        <i class="bi bi-book"></i>
                    </span>
                    <input type="text" name="kelas" class="form-control form-control-icon" placeholder="Masukan Kelas" required>
                </div>


                <button type="submit" name="tombol" class="btn btn-custom-primary w-100 text-white mb-3">Daftar</button>

                <div class="d-flex flex-column gap-1 text-center pt-2 border-top">
                    <a href="login-admin.php" class="text-decoration-none link-item d-flex align-items-center justify-content-between px-2 py-2 rounded">
                        <span><i class="bi bi-shield-lock me-2"></i>Login Sebagai Admin</span>
                        <i class="bi bi-chevron-right small"></i>
                    </a>
                    <a href="login-anggota.php" class="text-decoration-none link-item d-flex align-items-center justify-content-between px-2 py-2 rounded">
                        <span><i class="bi bi-person-badge me-2"></i>Login Sebagai Anggota</span>
                        <i class="bi bi-chevron-right small"></i>
                    </a>
                </div>
            </form>

        </div>
    </div>
</body>
</html>