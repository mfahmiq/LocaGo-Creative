<?php
session_start();
if(isset($_POST['tombol'])){
    include'koneksi.php';
    $username = $_POST['username'];
    $password = $_POST['password'];
    $query = "SELECT*FROM admin WHERE username='$username' AND password='$password'";
    $data = mysqli_query($koneksi,$query);
    if(mysqli_num_rows($data)>0){
        $data = mysqli_fetch_array($data);
        
        $_SESSION['id_admin'] = $data['id_admin'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['nama_admin'] = $data['nama_admin'];
        header("Location:admin/dashboard.php");
        exit;
    }else{
        echo"<script>alert('maaf login gagal'); window.location.assign('login-admin.php');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - Aplikasi Perpustakaan Labuna SMKN 1 Wanayasa</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

</head>
<body class="page-login-admin">

    <div class="bg-overlay"></div>

    <div class="vh-100 row justify-content-center align-content-center m-0">
        <form method="post" action="" class="col-md-4 border p-4 rounded-4 login-card" style="width: 440px;">
            <div class="icon-container">
                <i class="bi bi-shield-lock-fill"></i>
            </div>
            <h4 class="text-center fw-bold text-dark mb-1">Login Admin</h4>
            <h5 class="text-center text-muted fs-6 mb-4">Aplikasi Perpustakaan Labuna<br>SMKN 1 Wanayasa</h5>
            
            <div class="position-relative mb-3">
                <span class="input-group-text-custom"><i class="bi bi-person-fill"></i></span>
                <input type="text" name="username" class="form-control form-control-icon" placeholder="Masukan Username" required>
            </div>
            
            <div class="position-relative mb-3">
                <span class="input-group-text-custom"><i class="bi bi-lock-fill"></i></span>
                <input type="password" name="password" class="form-control form-control-icon" placeholder="Masukan Password" required>
            </div>
            
            <button type="submit" name="tombol" class="btn w-100 mb-3 btn-custom">Login</button>
            <div class="text-center">
                <a href="login-anggota.php" class="text-decoration-none fs-6" style="color: #064e3b; font-weight: 500;">Login Sebagai Anggota</a> 
            </div>
        </form>
    </div>
</body>
</html>