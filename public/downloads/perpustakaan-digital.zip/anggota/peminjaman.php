<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/** @var mysqli $koneksi */
include "../koneksi.php";
date_default_timezone_set("Asia/Jakarta");

$id = $_GET['id'];
$tgl = date('Y-m-d H:i:s');
$id_anggota = $_SESSION['id_anggota'];

$query = "INSERT INTO transaksi(id_anggota, id_buku, tgl_pinjam, status_transaksi) 
          VALUES('$id_anggota', '$id', '$tgl', 'Peminjaman')";
$data = mysqli_query($koneksi, $query);

if ($data) {
    mysqli_query($koneksi, "UPDATE buku SET stok = stok - 1 WHERE id_buku='$id'");
    
    $cek_stok = mysqli_query($koneksi, "SELECT stok FROM buku WHERE id_buku='$id'");
    $data_buku = mysqli_fetch_array($cek_stok);

    if ($data_buku['stok'] <= 0) {
        mysqli_query($koneksi, "UPDATE buku SET status='dipinjam' WHERE id_buku='$id'");
    }

    echo "<script>alert('Buku Sukses Dipinjam'); window.location.assign('dashboard-anggota.php');</script>";
} else {
    echo "<script>alert('Gagal Meminjam Buku'); window.location.assign('dashboard-anggota.php');</script>";
}
?>