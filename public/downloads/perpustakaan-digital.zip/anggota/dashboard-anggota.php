<?php
session_start();
 /** @var mysqli $koneksi */
include "../koneksi.php";

if (!isset($_SESSION['id_anggota'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard Anggota - Aplikasi Perpustakaan Sekolah Digital</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="../css/style.css">

    <style>
      
    </style>
</head>

<body class="dashboard-anggota">

<div class="member-layout">

    <aside class="member-sidebar">

        <div class="member-sidebar-brand">
            <div class="member-logo-icon">
                <i class="bi bi-book-half"></i>
            </div>

            <div class="member-logo-text">
                <span class="member-logo-title">Perpustakaan</span>
                <small>Digital School</small>
            </div>
        </div>

        <nav class="member-sidebar-menu">
            <a href="dashboard-anggota.php"
               class="member-menu-item <?= !isset($_GET['halaman']) ? 'active' : ''; ?>">
                <i class="bi bi-house-door-fill"></i>
                <span>Dashboard</span>
            </a>

            <a href="?halaman=history"
               class="member-menu-item <?= isset($_GET['halaman']) && $_GET['halaman'] == 'history' ? 'active' : ''; ?>">
                <i class="bi bi-clock-history"></i>
                <span>History Peminjaman</span>
            </a>
        </nav>

        <div class="member-sidebar-bottom">
            <a href="logout.php"
               class="member-logout"
               onclick="return confirm('Yakin ingin logout?')">
                <i class="bi bi-box-arrow-right"></i>
                <span>Logout</span>
            </a>
        </div>

    </aside>

    <main class="member-main">

        <header class="member-topbar">
            <div class="member-welcome">

                <div class="member-mobile-logo">
                    <i class="bi bi-book-half"></i>
                </div>

                <div>
                    <h4>
                        Selamat Datang,
                        <span>
                            <?= htmlspecialchars($_SESSION['nama_anggota']); ?>
                        </span>
                    </h4>

                    <p>Aplikasi Perpustakaan Sekolah Digital</p>
                </div>

            </div>
        </header>

        <div class="member-content">

        <?php

        if (isset($_GET['halaman'])) {

            $halaman = $_GET['halaman'];

            $halaman_diizinkan = [
                'history',
                'peminjaman',
                'proses_pengembalian'
            ];

            if (in_array($halaman, $halaman_diizinkan)) {

                $file = $halaman . ".php";

                if (file_exists($file)) {
                    include $file;
                } else {
                    echo "
                    <div class='alert alert-danger border-0'
                         style='border-radius:12px;'>
                        Halaman tidak ditemukan!
                    </div>";
                }

            } else {

                echo "
                <div class='alert alert-danger border-0'
                     style='border-radius:12px;'>
                    Halaman tidak ditemukan!
                </div>";
            }

        } else {
        ?>

            <div class="member-page-heading">
                <h5>Temukan Buku Favoritmu</h5>
                <p>Cari buku yang ingin kamu baca dan pinjam dari perpustakaan.</p>
            </div>

            <form action=""
                  method="get"
                  class="member-search-form"
                  id="formCari">

                <label>
                    <i class="bi bi-search"></i>
                    Cari Judul Buku
                </label>

                <div class="member-search-box">
                    <i class="bi bi-search"></i>

                    <input type="text"
                           name="cari"
                           id="inputCari"
                           placeholder="Cari buku favorit kamu..."
                           autocomplete="off"
                           value="<?= htmlspecialchars($_GET['cari'] ?? ''); ?>">
                </div>

            </form>

            <section class="member-section">

                <div class="member-section-header">
                    <div>
                        <h5>
                            <i class="bi bi-journal-check"></i>
                            Buku yang Sedang Dipinjam
                        </h5>

                        <p>Daftar buku yang masih kamu pinjam.</p>
                    </div>
                </div>

                <div class="member-table-wrapper">
                    <div class="table-responsive">

                        <table class="table align-middle mb-0 member-loan-table">

                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Judul Buku</th>
                                    <th>Tanggal Pinjam</th>
                                    <th class="text-center">Pengembalian</th>
                                </tr>
                            </thead>

                            <tbody>

                            <?php

                            $no = 1;
                            $id_anggota = $_SESSION['id_anggota'];

                            $query = "
                                SELECT *
                                FROM transaksi
                                JOIN buku
                                ON buku.id_buku = transaksi.id_buku
                                WHERE transaksi.id_anggota = '$id_anggota'
                                AND transaksi.status_transaksi = 'Peminjaman'
                                ORDER BY transaksi.id_transaksi DESC
                            ";

                            $data_peminjaman = mysqli_query($koneksi, $query);

                            if (
                                $data_peminjaman &&
                                mysqli_num_rows($data_peminjaman) > 0
                            ) {

                                foreach ($data_peminjaman as $peminjaman) {
                            ?>

                                <tr>
                                    <td class="fw-bold">
                                        <?= $no++; ?>
                                    </td>

                                    <td class="fw-semibold">
                                        <?= htmlspecialchars($peminjaman['judul_buku']); ?>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars($peminjaman['tgl_pinjam']); ?>
                                    </td>

                                    <td class="text-center">

                                        <a href="?halaman=proses_pengembalian&id=<?= $peminjaman['id_transaksi']; ?>&buku=<?= $peminjaman['id_buku']; ?>"
                                           class="member-return-btn"
                                           onclick="return confirm('Pengembalian Buku <?= addslashes($peminjaman['judul_buku']); ?>?')">

                                            <i class="bi bi-check-circle-fill"></i>
                                            Kembalikan

                                        </a>

                                    </td>
                                </tr>

                            <?php
                                }

                            } else {
                            ?>

                                <tr>
                                    <td colspan="4"
                                        class="text-center py-5 text-muted">

                                        <i class="bi bi-journal-x d-block mb-2"
                                           style="font-size:2rem;"></i>

                                        Tidak ada buku yang sedang dipinjam.

                                    </td>
                                </tr>

                            <?php
                            }
                            ?>

                            </tbody>

                        </table>

                    </div>
                </div>

            </section>

            <section class="member-section">

                <div class="member-section-header">
                    <div>
                        <h5>
                            <i class="bi bi-grid-fill"></i>
                            Katalog Buku
                        </h5>

                        <p>Pilih buku yang ingin kamu pinjam.</p>
                    </div>
                </div>

                <div class="row">

                <?php

                if (
                    isset($_GET['cari']) &&
                    trim($_GET['cari']) != ''
                ) {

                    $cari = mysqli_real_escape_string(
                        $koneksi,
                        trim($_GET['cari'])
                    );

                    $query_buku = "
                        SELECT *
                        FROM buku
                        WHERE judul_buku LIKE '%$cari%'
                        ORDER BY id_buku DESC
                    ";

                } else {

                    $query_buku = "
                        SELECT *
                        FROM buku
                        ORDER BY id_buku DESC
                    ";
                }

                $data_buku = mysqli_query($koneksi, $query_buku);

                if (
                    $data_buku &&
                    mysqli_num_rows($data_buku) > 0
                ) {

                    foreach ($data_buku as $buku) {

                        $tahun_terbit = '-';

                        if (isset($buku['tahun_terbit'])) {
                            $tahun_terbit = $buku['tahun_terbit'];
                        } elseif (isset($buku['thn_terbit'])) {
                            $tahun_terbit = $buku['thn_terbit'];
                        }

                        $status_buku = strtolower(
                            $buku['status'] ?? ''
                        );
                ?>

                    <div class="col-lg-3 col-md-4 col-sm-6 mb-4">

                        <div class="member-book-card">

                            <div>

                                <div class="member-book-icon">
                                    <i class="bi bi-book-fill"></i>
                                </div>

                                <h6>
                                    <?= htmlspecialchars($buku['judul_buku']); ?>
                                </h6>

                                <div class="member-book-info">

                                    <p>
                                        <i class="bi bi-person"></i>
                                        <?= htmlspecialchars($buku['pengarang']); ?>
                                    </p>

                                    <p>
                                        <i class="bi bi-building"></i>
                                        <?= htmlspecialchars($buku['penerbit']); ?>
                                    </p>

                                    <p>
                                        <i class="bi bi-calendar3"></i>
                                        <?= htmlspecialchars($tahun_terbit); ?>
                                    </p>

                                </div>

                                <div class="member-stock">
                                    <span>Stok</span>

                                    <strong>
                                        <?= htmlspecialchars($buku['stok']); ?>
                                    </strong>
                                </div>

                            </div>

                            <div>

                            <?php
                            if (
                                $status_buku == 'tersedia' &&
                                $buku['stok'] > 0
                            ) {
                            ?>

                                <span class="member-status-available">
                                    <i class="bi bi-check-circle-fill"></i>
                                    Tersedia
                                </span>

                                <a href="?halaman=peminjaman&id=<?= $buku['id_buku']; ?>"
                                   class="member-borrow-btn"
                                   onclick="return confirm('Peminjaman Buku <?= addslashes($buku['judul_buku']); ?>?')">

                                    <i class="bi bi-bookmark-plus-fill"></i>
                                    Pinjam Buku

                                </a>

                            <?php
                            } else {
                            ?>

                                <span class="member-status-unavailable">
                                    <i class="bi bi-x-circle-fill"></i>
                                    Tidak Tersedia
                                </span>

                                <button class="member-borrow-disabled"
                                        disabled>

                                    <i class="bi bi-lock-fill"></i>
                                    Tidak Bisa Dipinjam

                                </button>

                            <?php
                            }
                            ?>

                            </div>

                        </div>

                    </div>

                <?php
                    }

                } else {
                ?>

                    <div class="col-12">

                        <div class="member-empty-search">

                            <i class="bi bi-search"></i>

                            <h6>Buku tidak ditemukan</h6>

                            <p>Coba gunakan kata kunci lain.</p>

                        </div>

                    </div>

                <?php
                }
                ?>

                </div>

            </section>

        <?php
        }
        ?>

        </div>

    </main>

</div>

<nav class="member-bottom-nav">

    <a href="dashboard-anggota.php"
       class="member-bottom-item <?= !isset($_GET['halaman']) ? 'active' : ''; ?>">

        <i class="bi bi-house-door-fill"></i>
        <span>Dashboard</span>

    </a>

    <a href="?halaman=history"
       class="member-bottom-item <?= isset($_GET['halaman']) && $_GET['halaman'] == 'history' ? 'active' : ''; ?>">

        <i class="bi bi-clock-history"></i>
        <span>History</span>

    </a>

    <a href="logout.php"
       class="member-bottom-item member-bottom-logout"
       onclick="return confirm('Yakin ingin logout?')">

        <i class="bi bi-box-arrow-right"></i>
        <span>Logout</span>

    </a>

</nav>

<script>
const inputCari = document.getElementById('inputCari');
const formCari = document.getElementById('formCari');

if (inputCari && formCari) {

    let waktuCari;

    inputCari.addEventListener('input', function () {

        clearTimeout(waktuCari);

        waktuCari = setTimeout(function () {
            formCari.submit();
        }, 500);

    });

}
</script>

</body>
</html>

