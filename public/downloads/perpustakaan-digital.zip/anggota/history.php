<h4>Daftar History Peminjaman :</h4>
<table class="table table-bordered mt-3">
    <tr class="fw-bold">
        <td>No</td>
        <td>Judul Buku</td>
        <td>Tanggal Pinjam</td>
        <td>Tanggal Kembali</td>
    </tr>
    <?php 
    /** @var mysqli $koneksi */
include "../koneksi.php";
    $no = 1;
    $id_anggota = $_SESSION['id_anggota'];

    $query = "SELECT * FROM transaksi, buku 
              WHERE buku.id_buku=transaksi.id_buku 
              AND transaksi.id_anggota='$id_anggota' 
              AND transaksi.status_transaksi='Pengembalian' 
              ORDER BY transaksi.id_transaksi DESC";
              
    $data_history = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($data_history) > 0) {
        foreach ($data_history as $history) {
    ?>
    <tr>
        <td><?= $no++; ?></td>
        <td><?= $history['judul_buku']; ?></td>
        <td><?= $history['tgl_pinjam']; ?></td>
        <td><?= $history['tgl_kembali']; ?></td>
    </tr>
    <?php 
        }
    } else {
        echo "<tr><td colspan='4' class='text-center'>Belum ada riwayat pengembalian buku</td></tr>";
    }
    ?>
</table>