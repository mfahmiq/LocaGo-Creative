<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selamat Datang - Perpustakaan Digital Sekolah</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    
</head>
<body class="page-index">

    <div class="bg-overlay"></div>

    <div class="vh-100 d-flex justify-content-center align-items-center">
        <div class="card card-login p-5 text-center" style="width: 440px;">

            <div class="mb-4">
                <div class="mb-3" style="color: #064e3b;">
                    <i class="bi bi-book-half" style="font-size: 2.5rem;"></i>
                </div>
                <h3 class="fw-bold text-dark">Perpustakaan Digital</h3>
                <p class="text-muted small">Silakan pilih akses masuk sesuai akunmu</p>
            </div>
            
            <a href="login-anggota.php" class="btn btn-custom-blue btn-lg w-100 py-3 mb-3 d-flex align-items-center justify-content-center gap-2 text-decoration-none">
                <i class="bi bi-person-fill-gear" style="font-size: 1.2rem;"></i> 
                <span class="fw-semibold">Login sebagai Anggota</span>
            </a>
            
            <a href="login-admin.php" class="btn btn-custom-blue btn-lg w-100 py-3 d-flex align-items-center justify-content-center gap-2 text-decoration-none">
                <i class="bi bi-shield-lock-fill" style="font-size: 1.2rem;"></i> 
                <span class="fw-semibold">Login sebagai Admin</span>
            </a>
            
            <div class="mt-4 text-muted" style="font-size: 0.8rem;">
                &copy; SMK Negeri 1 Wanayasa
            </div>

        </div>
    </div>

</body>
</html>