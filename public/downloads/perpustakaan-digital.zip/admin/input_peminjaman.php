<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/** @var mysqli $koneksi */
include '../koneksi.php';
$anggota = mysqli_query($koneksi, "SELECT * FROM anggota");
$buku = mysqli_query($koneksi, "SELECT * FROM buku WHERE stok > 0");
?>

<h4 class="fw-bold mb-3 text-dark"><i class="bi bi-journal-plus me-1"></i> Tambah Peminjaman</h4>
<form method="post" action="" class="mt-3">
    <div class="mb-3">
        <label class="form-label fw-semibold">Pilih Anggota</label>
        <select name="id_anggota" class="form-select" style="border-radius: 10px; padding: 10px 15px;" required>
            <option value="">-- Pilih Anggota --</option>
            <?php foreach($anggota as $data) { ?>
                <option value="<?= $data['id_anggota']; ?>"><?= $data['nama_anggota']; ?></option>
            <?php } ?>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label fw-semibold">Pilih Buku</label>
        <select name="id_buku" class="form-select" style="border-radius: 10px; padding: 10px 15px;" required>
            <option value="">-- Pilih Buku --</option>
            <?php foreach($buku as $data) { ?>
                <option value="<?= $data['id_buku']; ?>"><?= $data['judul_buku']; ?></option>
            <?php } ?>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label fw-semibold">Tanggal & Waktu Pinjam</label>
        <input name="tgl_pinjam" type="datetime-local" class="form-control" style="border-radius: 10px; padding: 10px 15px;" required>
    </div>

    <button name="tombol" type="submit" class="btn text-white shadow-sm" style="background: #1E4D3B; border: none; border-radius: 10px; padding: 10px 20px; font-weight: 500; transition: all 0.2s;">
         SIMPAN
    </button>
</form>

<?php 
if (isset($_POST['tombol'])) {
    $id_anggota = $_POST['id_anggota'];
    $id_buku = $_POST['id_buku'];
    $tgl_pinjam = $_POST['tgl_pinjam'];
    $status_transaksi = "Peminjaman";
    
    
    $id_admin = isset($_SESSION['id_admin']) ? $_SESSION['id_admin'] : 1;

    $query = "INSERT INTO transaksi(id_anggota, id_buku, id_admin, tgl_pinjam, status_transaksi) 
              VALUES('$id_anggota', '$id_buku', '$id_admin', '$tgl_pinjam', '$status_transaksi')";
    $data = mysqli_query($koneksi, $query);

    mysqli_query($koneksi, "UPDATE buku SET stok = stok - 1 WHERE id_buku='$id_buku'");
    
    $cek_stok = mysqli_query($koneksi, "SELECT stok FROM buku WHERE id_buku='$id_buku'");
    $data_buku = mysqli_fetch_array($cek_stok);

    if ($data_buku['stok'] <= 0) {
        mysqli_query($koneksi, "UPDATE buku SET status='dipinjam' WHERE id_buku='$id_buku'");
    }

    if ($data) {
        echo "<script>alert('data peminjaman tersimpan'); window.location.assign('?halaman=peminjaman');</script>";
    } else {
        echo "<script>alert('data gagal tersimpan'); window.location.assign('?halaman=input_peminjaman');</script>";
    }
}
?>