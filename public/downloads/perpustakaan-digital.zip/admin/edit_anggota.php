        <?php
        /**@var mysqli $koneksi */
        include '../koneksi.php';
        $id = $_GET['id'];
        $query_anggota = mysqli_query($koneksi, "SELECT * FROM anggota WHERE id_anggota='$id'");
        $data_anggota = mysqli_fetch_array($query_anggota);
        ?>

        <h4>Edit Data Anggota</h4>
        <form method="post" action="" class="mt-3">
            <div class="mb-3">
                <label>NIS</label>
                <input type="text" name="nis" value="<?= $data_anggota['nis']; ?>" class="form-control" placeholder="Masukan NIS Anggota" required>
            </div>
            <div class="mb-3">
                <label>Nama Anggota</label>
                <input type="text" name="nama_anggota" value="<?= $data_anggota['nama_anggota']; ?>" class="form-control" placeholder="Masukan Nama Anggota" required>
            </div>
            <div class="mb-3">
                <label>Username</label>
                <input type="text" name="username" value="<?= $data_anggota['username']; ?>" class="form-control" placeholder="Masukan Username Anggota" required>
            </div>
            <div class="mb-3">
                <label>Password</label>
                <input type="password" name="password" value="<?= $data_anggota['password']; ?>" class="form-control" placeholder="Masukan Password Anggota" required>
            </div>
            <div class="mb-3">
                <label>Kelas</label>
                <input type="text" name="kelas" value="<?= $data_anggota['kelas']; ?>" class="form-control" placeholder="Masukan Kelas Anggota" required>
            </div>
            <button type="submit" name="tombol_update" class="btn btn-warning">UPDATE</button>
            <a href="?halaman=data_anggota" class="btn btn-secondary">Batal</a>
        </form>
        <?php
        if(isset($_POST['tombol_update'])){
            $nis = $_POST['nis'];
            $nama_anggota = $_POST['nama_anggota'];
            $username = $_POST['username'];
            $password = $_POST['password'];
            $kelas = $_POST['kelas'];

            $update_query = "UPDATE anggota SET nis='$nis', nama_anggota='$nama_anggota', username='$username', password='$password', kelas='$kelas' WHERE id_anggota='$id'";
            $update_data = mysqli_query($koneksi, $update_query);

            if($update_data){
                echo "<script>alert('Data Anggota Berhasil Diperbarui'); window.location.assign('?halaman=data_anggota');</script>";
            }else{
                echo "<script>alert('Data Anggota Gagal Diperbarui'); window.location.assign('?halaman=edit_anggota&id=$id');</script>";
            }
        }

