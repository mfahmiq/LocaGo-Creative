        <?php
        /**@var mysqli $koneksi */
        include '../koneksi.php';

        if (!isset($_GET['id']) || empty($_GET['id'])) {
            echo "<script>alert('ID Buku tidak valid!'); window.location.assign('?halaman=data_buku');</script>";
            exit;
        }

        $id = $_GET['id'];
        $query = mysqli_query($koneksi, "SELECT * FROM buku WHERE id_buku='$id'");
        $data  = mysqli_fetch_array($query);

        if (!$data) {
            echo "<script>alert('Data buku tidak ditemukan!'); window.location.assign('?halaman=data_buku');</script>";
            exit;
        }
        ?>

        <h4>Edit Data Buku</h4>

        <form method="post" action="" class="mt-3">
            <label class="form-label">Judul Buku</label>
            <input type="text" name="judul_buku" value="<?= $data['judul_buku']; ?>" class="form-control mb-2" required>
            
            <label class="form-label">Pengarang</label>
            <input type="text" name="pengarang" value="<?= $data['pengarang']; ?>" class="form-control mb-2" required>
            
            <label class="form-label">Penerbit</label>
            <input type="text" name="penerbit" value="<?= $data['penerbit']; ?>" class="form-control mb-2" required>
            
            <label class="form-label">Tahun Terbit</label>
            <input type="number" name="tahun_terbit" value="<?= $data['tahun_terbit']; ?>" class="form-control mb-2" required>
            
            <label class="form-label">Stok Buku</label>
            <input type="number" name="stok" value="<?= $data['stok']; ?>" class="form-control mb-2" min="0" required>

            <label class="form-label">Status Buku</label>
            <select name="status" class="form-control mb-3" required>
                <option value="tersedia" <?= $data['status'] == 'tersedia' ? 'selected' : ''; ?>>Tersedia</option>
                <option value="dipinjam" <?= $data['status'] == 'dipinjam' ? 'selected' : ''; ?>>Dipinjam</option>
            </select>

            <button type="submit" name="tombol_update" class="btn btn-warning">UPDATE</button>
            <a href="?halaman=data_buku" class="btn btn-secondary">Batal</a>
        </form>

        <?php
        if (isset($_POST['tombol_update'])) {
            $judul_buku   = $_POST['judul_buku'];
            $pengarang    = $_POST['pengarang'];
            $penerbit     = $_POST['penerbit'];
            $tahun_terbit = $_POST['tahun_terbit'];
            $stok         = $_POST['stok'];
            $status       = $_POST['status'];

            $update = mysqli_query($koneksi, "UPDATE buku SET 
                judul_buku='$judul_buku', 
                pengarang='$pengarang', 
                penerbit='$penerbit', 
                tahun_terbit='$tahun_terbit', 
                stok='$stok', 
                status='$status' 
                WHERE id_buku='$id'");

            if ($update) {
                echo "<script>alert('Data Berhasil Diperbarui'); window.location.assign('?halaman=data_buku');</script>";
            } else {
                echo "<script>alert('Data Gagal Diperbarui'); window.location.assign('?halaman=edit_buku&id=$id');</script>";
            }
        }
        ?>