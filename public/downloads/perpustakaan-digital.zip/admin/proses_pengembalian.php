<?php
$id = $_GET['id'];
$buku = $_GET['buku'];
date_default_timezone_set('Asia/Jakarta');
$tgl_kembali = date('Y-m-d H:i:s');
/** @var mysqli $koneksi */
    include_once "../koneksi.php";
    $data = mysqli_query($koneksi, "UPDATE transaksi SET status_transaksi='Pengembalian', tgl_kembali='$tgl_kembali' WHERE id_transaksi='$id'");
    if($data){
        mysqli_query($koneksi, "UPDATE buku SET stok = stok + 1 WHERE id_buku='$buku'");
        mysqli_query($koneksi, "UPDATE buku SET status='tersedia' WHERE id_buku='$buku'");
        echo "<script>alert('Buku Berhasil dikembalikan'); window.location.assign('?halaman=data_peminjaman');</script>";
    }
?>