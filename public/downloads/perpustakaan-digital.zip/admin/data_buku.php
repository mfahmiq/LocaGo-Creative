<link rel="stylesheet" href="../css/style.css">
<div class="card border-0 shadow-sm p-4 mb-4 book-header-card">
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div class="d-flex align-items-center gap-3">
        <div class="book-icon-box">
            <i class="bi bi-journal-bookmark-fill"></i>
        </div>

        <div>
            <h4 class="fw-bold m-0"
                style="color: #1F2937; letter-spacing: -0.5px;">
                Data Buku Perpustakaan
            </h4>

            <p class="small m-0 mt-1"
               style="color: #6B7280; font-weight: 500;">
                Kelola data dan stok buku perpustakaan dengan cepat dan mudah.
            </p>
        </div>
    </div>

    <a href="?halaman=input_buku"
       class="btn text-white shadow-sm px-4 py-2 btn-add-book">
        <i class="bi bi-plus-circle-fill me-1"></i>
        Tambah Data Buku
    </a>
</div>
</div>

<form action="" method="get" class="mb-4" id="formCariBuku">
    <?php foreach ($_GET as $key => $value): ?>
        <?php if ($key !== 'cari'): ?>
            <input type="hidden" name="<?= htmlspecialchars($key); ?>" value="<?= htmlspecialchars($value); ?>">
        <?php endif; ?>
    <?php endforeach; ?>
    
    <div class="input-group shadow-sm">
        <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
        <input type="text" 
               name="cari" 
               id="inputCariBuku" 
               class="form-control border-start-0 ps-0" 
               placeholder="Cari judul buku..." 
               autocomplete="off" 
               value="<?= htmlspecialchars($_GET['cari'] ?? ''); ?>">
    </div>
</form>

<div class="table-card">
<div class="table-responsive">
    <table class="table align-middle mb-0 table-custom table-custom-hover">
        <thead>
            <tr>
                <th class="py-3 px-3 fw-bold">
                    No
                </th>

                <th class="py-3 fw-bold">
                    Judul Buku
                </th>

                <th class="py-3 fw-bold">
                    Pengarang
                </th>

                <th class="py-3 fw-bold">
                    Penerbit
                </th>

                <th class="py-3 text-center fw-bold">
                    Tahun
                </th>

                <th class="py-3 text-center fw-bold">
                    Stok
                </th>

                <th class="py-3 text-center fw-bold">
                    Status
                </th>

                <th class="py-3 text-center fw-bold">
                    Aksi
                </th>
            </tr>
        </thead>
        <tbody>
            <?php
            /** @var mysqli $koneksi */
            include '../koneksi.php';
            $no = 1;

            if (isset($_GET['cari']) && trim($_GET['cari']) != '') {
                $cari = mysqli_real_escape_string($koneksi, trim($_GET['cari']));
                $query = "SELECT * FROM buku WHERE judul_buku LIKE '%$cari%' ORDER BY id_buku DESC";
            } else {
                $query = "SELECT * FROM buku ORDER BY id_buku DESC";
            }

            $data = mysqli_query($koneksi, $query);

            if ($data && mysqli_num_rows($data) > 0) {
                $index = 0;

        foreach ($data as $buku) {
        $bg_row = ($index % 2 == 0) ? '#FFFFFF' : '#F1F5F3';
        $index++;
        ?>
                <tr style="background-color: <?= $bg_row; ?> !important;">
                    <td class="px-3 fw-bold"
                        style="background-color: transparent !important;">
                        <?= $no++; ?>
                    </td>

                    <td class="fw-bold"
                        style="background-color: transparent !important;">
                        <?= $buku['judul_buku']; ?>
                    </td>

                    <td class="fw-semibold"
                        style="background-color: transparent !important;">
                        <?= $buku['pengarang']; ?>
                    </td>

                    <td class="fw-semibold"
                        style="background-color: transparent !important;">
                        <?= $buku['penerbit']; ?>
                    </td>

                    <td class="text-center fw-semibold"
                        style="background-color: transparent !important;">
                        <?= $buku['tahun_terbit']; ?>
                    </td>

                    <td class="text-center"
                        style="background-color: transparent !important;">
                        <span class="badge stock-badge">
                            <?= $buku['stok']; ?>
                        </span>
                    </td>

                    <td class="text-center"
                        style="background-color: transparent !important;">
                        <?php if(strtolower($buku['status']) == 'tersedia' || $buku['stok'] > 0): ?>
                            <span class="badge status-available">
                                Tersedia
                            </span>
                        <?php else: ?>
                            <span class="badge status-empty">
                                Habis
                            </span>
                        <?php endif; ?>
                    </td>

                    <td class="text-center px-3"
                        style="background-color: transparent !important;">
                        <div class="d-inline-flex gap-2">

                           
                            <a class="btn btn-sm px-2.5 py-1.5 shadow-sm btn-edit-custom"
                               href="?halaman=edit_buku&id=<?= $buku['id_buku']; ?>"
                               title="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </a>

                           
                            <a class="btn btn-sm px-2.5 py-1.5 shadow-sm btn-delete-custom"
                               onclick="return confirm('Yakin ingin menghapus data buku ini?')"
                               href="?halaman=hapus_buku&id=<?= $buku['id_buku']; ?>"
                               title="Hapus">
                                <i class="bi bi-trash-fill"></i>
                            </a>
                        </div>
                    </td>
                </tr>

            <?php
                }
            } else {
                echo "
                <tr>
                    <td colspan='8'
                        class='text-center py-5 text-muted fw-semibold fst-italic'
                        style='background-color: #FFFFFF !important;'>

                        <i class='bi bi-journal-x d-block mb-2'
                           style='font-size: 1.5rem; color: #9CA3AF;'></i>
                        Belum ada data buku yang tersimpan atau buku tidak ditemukan.
                    </td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</div>
</div>

<script>
const inputCariBuku = document.getElementById('inputCariBuku');
const formCariBuku = document.getElementById('formCariBuku');

if (inputCariBuku && formCariBuku) {
    let waktuCari;

    inputCariBuku.addEventListener('input', function () {
        clearTimeout(waktuCari);

        waktuCari = setTimeout(function () {
            formCariBuku.submit();
        }, 400);
    });

    inputCariBuku.focus();
    let panjangTeks = inputCariBuku.value.length;
    inputCariBuku.setSelectionRange(panjangTeks, panjangTeks);
}
</script>