<?php
/** @var mysqli $koneksi */
include "../koneksi.php";

$id_anggota = $_GET['id'];

$cek_pinjam = mysqli_query($koneksi, "SELECT * FROM transaksi WHERE id_anggota = '$id_anggota' AND status_transaksi = 'Peminjaman'");

if (mysqli_num_rows($cek_pinjam) > 0) {

    echo "<script>
            alert('Gagal menghapus! Anggota ini masih memiliki tanggungan buku yang belum dikembalikan.');
            window.location.assign('dashboard.php?halaman=anggota');
          </script>";
} else {

    $query_hapus = "DELETE FROM anggota WHERE id_anggota = '$id_anggota'";
    $hapus = mysqli_query($koneksi, $query_hapus);

    if ($hapus) {
        echo "<script>
                alert('Data anggota berhasil dihapus.');
                window.location.assign('dashboard.php?halaman=anggota');
              </script>";
    } else {
        echo "<script>
                alert('Gagal menghapus data anggota.');
                window.location.assign('dashboard.php?halaman=anggota');
              </script>";
    }
}
?>