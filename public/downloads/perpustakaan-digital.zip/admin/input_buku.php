<h4 class="fw-bold mb-3 text-dark"><i class="bi bi-book-half me-1"></i> Tambah Data Buku</h4>
<form method="post" action="" class="mt-3">
    <div class="mb-3">
        <label class="form-label fw-semibold">Judul Buku</label>
        <input type="text" name="judul_buku" class="form-control" placeholder="Masukan Judul Buku" style="border-radius: 10px; padding: 10px 15px;" required>
    </div>
    <div class="mb-3">
        <label class="form-label fw-semibold">Pengarang</label>
        <input type="text" name="pengarang" class="form-control" placeholder="Masukan Pengarang Buku" style="border-radius: 10px; padding: 10px 15px;" required>
    </div>
    <div class="mb-3">
        <label class="form-label fw-semibold">Penerbit</label>
        <input type="text" name="penerbit" class="form-control" placeholder="Masukan Penerbit Buku" style="border-radius: 10px; padding: 10px 15px;" required>
    </div>
    <div class="mb-3">
        <label class="form-label fw-semibold">Tahun Terbit</label>
        <input type="number" name="tahun_terbit" class="form-control" placeholder="Masukan Tahun Terbit Buku" style="border-radius: 10px; padding: 10px 15px;" required>
    </div>
    <div class="mb-3">
        <label class="form-label fw-semibold">Stok</label>
        <input type="number" name="stok" class="form-control" placeholder="Masukan Jumlah Stok Buku" style="border-radius: 10px; padding: 10px 15px;" min="1" required>
    </div>
    <button type="submit" name="tombol_simpan" class="btn text-white shadow-sm" style="background: #1E4D3B; border: none; border-radius: 10px; padding: 10px 20px; font-weight: 500; transition: all 0.2s;">
        Simpan
    </button>
</form>

<?php
if(isset($_POST['tombol_simpan'])){
    /** @var mysqli $koneksi */
    include '../koneksi.php';
    $judul_buku = $_POST['judul_buku'];
    $pengarang = $_POST['pengarang'];
    $penerbit = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $stok = $_POST['stok']; 

    $query = "INSERT INTO buku(judul_buku, pengarang, penerbit, tahun_terbit, stok, status) VALUES('$judul_buku', '$pengarang', '$penerbit', '$tahun_terbit', '$stok', 'tersedia')";
    $data = mysqli_query($koneksi, $query);
    
    if($data){
        echo "<script>alert('Data Buku Berhasil Disimpan'); window.location.assign('?halaman=data_buku');</script>";
    }else{
        echo "<script>alert('Data Buku Gagal Disimpan'); window.location.assign('?halaman=input_buku');</script>";
    }
}
?>