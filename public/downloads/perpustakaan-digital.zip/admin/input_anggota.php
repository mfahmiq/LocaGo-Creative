<h4 class="fw-bold mb-3 text-dark"><i class="bi bi-person-plus-fill me-1"></i> Tambah Data Anggota</h4>
<form method="post" action="" class="mt-3">
    <div class="mb-3">
        <label class="form-label fw-semibold">NIS</label>
        <input type="text" name="nis" class="form-control" placeholder="Masukan NIS Anggota" style="border-radius: 10px; padding: 10px 15px;" required>
    </div>
    <div class="mb-3">
        <label class="form-label fw-semibold">Nama Anggota</label>
        <input type="text" name="nama_anggota" class="form-control" placeholder="Masukan Nama Anggota" style="border-radius: 10px; padding: 10px 15px;" required>
    </div>
    <div class="mb-3">
        <label class="form-label fw-semibold">Username</label>
        <input type="text" name="username" class="form-control" placeholder="Masukan Username Anggota" style="border-radius: 10px; padding: 10px 15px;" required>
    </div>
    <div class="mb-3">
        <label class="form-label fw-semibold">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Masukan Password Anggota" style="border-radius: 10px; padding: 10px 15px;" required>
    </div>
    <div class="mb-3">
        <label class="form-label fw-semibold">Kelas</label>
        <input type="text" name="kelas" class="form-control" placeholder="Masukan Kelas Anggota" style="border-radius: 10px; padding: 10px 15px;" required>
    </div>
    <button type="submit" name="tombol" class="btn text-white shadow-sm" style="background: #1E4D3B; border: none; border-radius: 10px; padding: 10px 20px; font-weight: 500; transition: all 0.2s;">
       Simpan
    </button>
</form> 

<?php
if(isset($_POST['tombol'])){
    /** @var mysqli $koneksi */
    include '../koneksi.php';
    $nis = $_POST['nis'];
    $nama_anggota = $_POST['nama_anggota'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $kelas = $_POST['kelas'];


    $cek_nis = mysqli_query($koneksi, "SELECT * FROM anggota WHERE nis = '$nis'");
    if(mysqli_num_rows($cek_nis) > 0) {

        echo "<script>alert('Gagal! NIS $nis sudah terdaftar.'); window.location.assign('?halaman=input_anggota');</script>";
    } else {

        $query = "INSERT INTO anggota(nis, nama_anggota, username, password, kelas) VALUES('$nis', '$nama_anggota', '$username', '$password', '$kelas')";
        $data = mysqli_query($koneksi, $query);
        
        if($data){
            echo "<script>alert('Data Anggota Berhasil Disimpan'); window.location.assign('?halaman=data_anggota');</script>";
        }else{
            echo "<script>alert('Data Anggota Gagal Disimpan'); window.location.assign('?halaman=input_anggota');</script>";
        }
    }
}
?>