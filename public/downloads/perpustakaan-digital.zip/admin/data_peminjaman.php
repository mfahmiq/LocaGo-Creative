<link rel="stylesheet" href="../css/style.css">
<div class="card border-0 shadow-sm p-4 mb-4 loan-header-card">

<div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

    <div class="d-flex align-items-center gap-3">

        <div class="loan-icon-box">
            <i class="bi bi-journal-check"></i>
        </div>

        <div>

            <h4 class="fw-bold m-0"
                style="color: #1F2937; letter-spacing: -0.5px;">

                Data Peminjaman Perpustakaan

            </h4>

            <p class="small m-0 mt-1"
               style="color: #6B7280; font-weight: 500;">

                Kelola sirkulasi peminjaman buku perpustakaan.

            </p>

        </div>

    </div>


    <a href="?halaman=input_peminjaman"
       class="btn text-white shadow-sm px-4 py-2 btn-add-loan">

        <i class="bi bi-plus-circle-fill me-1"></i>

        Tambah Data Peminjaman

    </a>

</div>

</div>


<div class="card border-0 shadow-sm mb-4 loan-table-card">

<div class="loan-section-title">

    <i class="bi bi-arrow-left-right me-2"></i>

    Peminjaman Aktif

</div>


<div class="table-responsive">

    <table class="table align-middle mb-0 table-custom-hover loan-table">

        <thead>

            <tr>

                <th class="px-3 fw-bold">No</th>

                <th class="fw-bold">NIS</th>

                <th class="fw-bold">Nama Anggota</th>
                <th class="fw-bold">Buku</th>
                <th class="fw-bold">Tanggal Pinjam</th>
                <th class="text-center fw-bold">Kelola</th>

            </tr>

        </thead>


        <tbody>

            <?php
            /** @var mysqli $koneksi */

            if (!isset($koneksi)) {
                include_once "../koneksi.php";
            }

            $no = 1;

            $query = "SELECT * FROM transaksi
                     INNER JOIN buku ON buku.id_buku = transaksi.id_buku
                     INNER JOIN anggota ON anggota.id_anggota = transaksi.id_anggota
                     WHERE transaksi.status_transaksi = 'Peminjaman'
                     ORDER BY transaksi.id_transaksi DESC";

            $data = mysqli_query($koneksi, $query);


            if ($data && mysqli_num_rows($data) > 0) {

                $index = 0;

                foreach($data as $pinjam) {

                    $bg_row = ($index % 2 == 0)
                        ? '#FFFFFF'
                        : '#F1F5F3';

                    $index++;
            ?>

                <tr style="background-color: <?= $bg_row; ?> !important;">

                    <td class="px-3 fw-bold"
                        style="background-color: transparent !important;">

                        <?= $no++; ?>

                    </td>


                    <td style="background-color: transparent !important;">

                        <span class="badge nis-badge">

                            <?= htmlspecialchars($pinjam['nis']); ?>

                        </span>

                    </td>


                    <td class="fw-bold"
                        style="background-color: transparent !important;">

                        <?= htmlspecialchars($pinjam['nama_anggota']); ?>

                    </td>


                    <td class="fw-semibold"
                        style="background-color: transparent !important;">

                        <?= htmlspecialchars($pinjam['judul_buku']); ?>

                    </td>


                    <td class="text-muted"
                        style="background-color: transparent !important;">

                        <?= htmlspecialchars($pinjam['tgl_pinjam']); ?>

                    </td>


                    <td class="text-center px-3"
                        style="background-color: transparent !important;">

                        <?php
                        $pesan = "Pengembalian buku oleh " . $pinjam['nama_anggota'] . ", Buku " . $pinjam['judul_buku'];

                        $isi = "'" . addslashes($pesan) . "', " . $pinjam['id_transaksi'] . ", " . $pinjam['id_buku'];


                        $pesan_hapus = "Anda Yakin ingin menghapus data " . $pinjam['nama_anggota'] . ", Buku " . $pinjam['judul_buku'];

                        $isi_hapus = "'" . addslashes($pesan_hapus) . "', " . $pinjam['id_transaksi'] . ", " . $pinjam['id_buku'];
                        ?>


                        <div class="d-inline-flex gap-2">

                            <a onclick="pengembalian(<?= $isi; ?>)"
                               class="btn btn-sm px-3 py-1.5 shadow-sm btn-return-custom"
                               title="Pengembalian">

                                <i class="bi bi-check-circle-fill"></i>

                                Pengembalian

                            </a>


                            <a onclick="hapus(<?= $isi_hapus; ?>)"
                               class="btn btn-sm px-3 py-1.5 shadow-sm btn-delete-custom"
                               title="Hapus">

                                <i class="bi bi-trash-fill"></i>

                                Hapus

                            </a>

                        </div>

                    </td>

                </tr>


            <?php

                }

            } else {

                echo "<tr>
                    <td colspan='6'
                        class='text-center py-5 text-muted fw-semibold fst-italic'
                        style='background-color: #FFFFFF !important;'>

                        Belum ada data peminjaman.

                    </td>
                </tr>";
            }

            ?>

        </tbody>

    </table>

</div>

</div>


<div class="card border-0 shadow-sm loan-table-card">

<div class="loan-section-title">

    <i class="bi bi-journal-text me-2"></i>

    Riwayat Pengembalian Buku

</div>

<div class="table-responsive">

    <table class="table align-middle mb-0 table-custom-hover loan-table">

        <thead>

            <tr>
                <th class="px-3 fw-bold">No</th>
                <th class="fw-bold">NIS</th>
                <th class="fw-bold">Nama Anggota</th>
                <th class="fw-bold">Buku</th>
                <th class="fw-bold">Tanggal Pinjam</th>
                <th class="fw-bold">Tanggal Pengembalian</th>
                <th class="text-center fw-bold">Kelola</th>

            </tr>

        </thead>


        <tbody>

            <?php

            $no = 1;

            $query_kembali = "SELECT * FROM transaksi
                             INNER JOIN buku ON buku.id_buku = transaksi.id_buku
                             INNER JOIN anggota ON anggota.id_anggota = transaksi.id_anggota
                             WHERE transaksi.status_transaksi = 'Pengembalian'
                             ORDER BY transaksi.id_transaksi DESC";

            $data_kembali = mysqli_query($koneksi, $query_kembali);


            if ($data_kembali && mysqli_num_rows($data_kembali) > 0) {

                $index_kembali = 0;

                foreach($data_kembali as $kembali) {

                    $bg_row_k = ($index_kembali % 2 == 0)
                        ? '#FFFFFF'
                        : '#F1F5F3';

                    $index_kembali++;
            ?>

                <tr style="background-color: <?= $bg_row_k; ?> !important;">

                    <td class="px-3 fw-bold"
                        style="background-color: transparent !important;">

                        <?= $no++; ?>

                    </td>


                    <td style="background-color: transparent !important;">

                        <span class="badge nis-badge">

                            <?= htmlspecialchars($kembali['nis']); ?>

                        </span>

                    </td>


                    <td class="fw-bold"
                        style="background-color: transparent !important;">

                        <?= htmlspecialchars($kembali['nama_anggota']); ?>

                    </td>


                    <td class="fw-semibold"
                        style="background-color: transparent !important;">

                        <?= htmlspecialchars($kembali['judul_buku']); ?>

                    </td>


                    <td class="text-muted"
                        style="background-color: transparent !important;">

                        <?= htmlspecialchars($kembali['tgl_pinjam']); ?>

                    </td>


                    <td class="text-muted"
                        style="background-color: transparent !important;">

                        <?= htmlspecialchars($kembali['tgl_kembali']); ?>

                    </td>


                    <td class="text-center px-3"
                        style="background-color: transparent !important;">

                        <?php

                        $pesan_hapus2 = "Anda Yakin ingin menghapus data " . $kembali['nama_anggota'] . ", Buku " . $kembali['judul_buku'];

                        $isi_hapus2 = "'" . addslashes($pesan_hapus2) . "', " . $kembali['id_transaksi'] . ", " . $kembali['id_buku'];

                        ?>


                        <a onclick="hapus(<?= $isi_hapus2; ?>)"
                           class="btn btn-sm px-3 py-1.5 shadow-sm btn-delete-custom"
                           title="Hapus">

                            <i class="bi bi-trash-fill"></i>

                            Hapus
                        </a>
                    </td>
                </tr>

            <?php
                }
            } else {

                echo "<tr>
                    <td colspan='7'
                        class='text-center py-5 text-muted fw-semibold fst-italic'
                        style='background-color: #FFFFFF !important;'>

                        Belum ada data pengembalian.

                    </td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</div>
</div>

<script>

function pengembalian(pesan, id_transaksi, id_buku) {
    if (confirm(pesan)) {
        window.location.href =
            "?halaman=proses_pengembalian&id=" + id_transaksi +
            "&buku=" + id_buku;
    }
}

function hapus(pesan, id_transaksi, id_buku) {

    if (confirm(pesan)) {
        window.location.href =
            "?halaman=hapus&id=" +id_transaksi +
            "&buku=" +id_buku;
    }
}
</script>
