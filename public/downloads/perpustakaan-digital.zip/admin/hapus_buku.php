<?php
/**@var mysqli $koneksi */
    include '../koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $hapus = mysqli_query($koneksi, "DELETE FROM buku WHERE id_buku='$id'");

    if ($hapus) {
        echo "<script>alert('Data Berhasil Dihapus'); window.location.assign('?halaman=data_buku');</script>";
    } else {
        echo "<script>alert('Data Gagal Dihapus'); window.location.assign('?halaman=data_buku');</script>";
    }
} else {
    header("Location: ?halaman=data_buku");
}
?>