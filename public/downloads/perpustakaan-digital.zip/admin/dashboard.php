<?php
session_start();
/** @var mysqli $koneksi */
include '../koneksi.php';

if(empty($_SESSION['id_admin'])){
    header("location:../login-admin.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Halaman Admin | Aplikasi Perpustakaan Labuna SMKN 1 Wanayasa</title>

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>

    </style>

</head>

<body class="page-dashboard-admin">

<div class="sidebar">

    <div class="brand">

        <div class="brand-icon">

            <i class="bi bi-book-half"></i>

        </div>

        <div>

            <h5>Perpus Labuna</h5>

            <small>SMKN 1 Wanayasa</small>

        </div>

    </div>

    <div class="menu-title">

        Menu Utama

    </div>

    <ul class="sidebar-menu">

        <li>

            <a href="dashboard.php"
               class="<?= empty($_GET['halaman']) ? 'active' : '' ?>">

                <i class="bi bi-grid-fill"></i>

                Dashboard

            </a>
        </li>
        <li>

            <a href="?halaman=data_buku"
               class="<?= (isset($_GET['halaman']) && $_GET['halaman'] == 'data_buku') ? 'active' : '' ?>">

                <i class="bi bi-journal-bookmark-fill"></i>

                Data Buku

            </a>
        </li>
        <li>

            <a href="?halaman=data_anggota"
               class="<?= (isset($_GET['halaman']) && $_GET['halaman'] == 'data_anggota') ? 'active' : '' ?>">

                <i class="bi bi-people-fill"></i>

                Data Anggota

            </a>
        </li>

        <li>

            <a href="?halaman=data_peminjaman"
               class="<?= (isset($_GET['halaman']) && $_GET['halaman'] == 'data_peminjaman') ? 'active' : '' ?>">

                <i class="bi bi-arrow-left-right"></i>

                Peminjaman

            </a>
        </li>
    </ul>

    <div class="logout-section">

        <a href="logout.php"
           class="logout-btn"
           onclick="return confirm('Yakin ingin keluar dari aplikasi?')">

            <i class="bi bi-box-arrow-right"></i>

            Logout

        </a>
    </div>
</div>

<div class="main-content">

    <div class="topbar">

        <div class="topbar-title">

            <h4>Dashboard Admin</h4>

            <small>
                Sistem Informasi Perpustakaan Digital
            </small>

        </div>

        <div class="admin-profile">

            <div class="admin-avatar">

                <i class="bi bi-person-fill"></i>

            </div>

            <div>

                <div class="admin-name">

                    <?= $_SESSION['nama_admin']; ?>

                </div>

                <div class="admin-role">

                    Administrator

                </div>
            </div>
        </div>
    </div>

    <?php

    $halaman = isset($_GET['halaman'])
        ? $_GET['halaman']
        : "";

    if(file_exists($halaman.".php")){

        include $halaman.".php";

    }

    else {

        $count_buku =
            mysqli_num_rows(
                mysqli_query(
                    $koneksi,
                    "SELECT * FROM buku"
                )
            );

        $count_anggota =
            mysqli_num_rows(
                mysqli_query(
                    $koneksi,
                    "SELECT * FROM anggota"
                )
            );

        $count_pinjam =
            mysqli_num_rows(
                mysqli_query(
                    $koneksi,
                    "SELECT * FROM transaksi"
                )
            );

    ?>
    <div class="welcome-card">

        <h3>

            Selamat Datang,
            <?= $_SESSION['nama_admin']; ?>! 

        </h3>

        <p>

            Sistem Informasi Manajemen
            Perpustakaan Labuna SMKN 1 Wanayasa.

        </p>

    </div>

    <div class="row g-4">

        <div class="col-lg-4 col-md-6">

            <a href="?halaman=data_buku"
               class="stat-card">

                <div class="stat-top">

                    <div class="stat-icon icon-buku">

                        <i class="bi bi-book-fill"></i>

                    </div>

                    <h2 class="stat-number">

                        <?= $count_buku; ?>

                    </h2>
                </div>

                <h5 class="stat-title">

                    Total Buku

                </h5>

                <p class="stat-description">

                    Total koleksi buku
                    yang tersedia di perpustakaan.

                </p>

                <div class="stat-link">

                    Kelola Data Buku

                    <i class="bi bi-arrow-right ms-1"></i>

                </div>
            </a>
        </div>


        <div class="col-lg-4 col-md-6">

            <a href="?halaman=data_anggota"
               class="stat-card">

                <div class="stat-top">

                    <div class="stat-icon icon-anggota">
                        <i class="bi bi-people-fill"></i>
                    </div>

                    <h2 class="stat-number">
                        <?= $count_anggota; ?>
                    </h2>
                </div>

                <h5 class="stat-title">
                    Total Anggota
                </h5>

                <p class="stat-description">
                    Jumlah anggota
                    perpustakaan yang terdaftar.
                </p>
                <div class="stat-link">
                    Kelola Anggota
                    <i class="bi bi-arrow-right ms-1"></i>

                </div>
            </a>
        </div>

    

        <div class="col-lg-4 col-md-6">

            <a href="?halaman=data_peminjaman"
               class="stat-card">

                <div class="stat-top">

                    <div class="stat-icon icon-transaksi">
                        <i class="bi bi-arrow-left-right"></i>
                    </div>

                    <h2 class="stat-number">
                        <?= $count_pinjam; ?>
                    </h2>

                </div>

                <h5 class="stat-title">
                    Total Transaksi
                </h5>

                <p class="stat-description">
                    Total riwayat dan transaksi
                    peminjaman buku.
                </p>

                <div class="stat-link">
                    Proses Transaksi
                    <i class="bi bi-arrow-right ms-1"></i>

                </div>
            </a>
        </div>
    </div>

    <div class="content-card mt-4">

        <div class="d-flex align-items-center gap-3">

            <div class="stat-icon icon-buku">
                <i class="bi bi-info-circle-fill"></i>
            </div>

            <div>

                <h5 class="fw-bold mb-1">
                    Sistem Perpustakaan Digital Labuna
                </h5>

                <p class="text-muted small mb-0">

                    Sistem ini digunakan untuk membantu
                    pengelolaan data buku, anggota,
                    dan transaksi peminjaman secara 
                    efektif dan terstruktur.

                </p>
            </div>
        </div>
    </div>

    <?php } ?>

</div>
</body>
</html>