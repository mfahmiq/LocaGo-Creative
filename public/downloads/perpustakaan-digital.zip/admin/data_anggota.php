<link rel="stylesheet" href="../css/style.css">
<div class="card border-0 shadow-sm p-4 mb-4 member-header-card">
<div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
    <div class="d-flex align-items-center gap-3">
        <div class="member-icon-box">
            <i class="bi bi-people-fill"></i>
        </div>

        <div>
            <h4 class="fw-bold m-0"
                style="color: #1F2937; letter-spacing: -0.5px;">
                Data Anggota Perpustakaan
            </h4>

            <p class="small m-0 mt-1"
               style="color: #6B7280; font-weight: 500;">
                Kelola daftar siswa atau anggota perpustakaan.
            </p>
        </div>
    </div>

    <a href="?halaman=input_anggota"
       class="btn text-white shadow-sm px-4 py-2 btn-add-member">
        <i class="bi bi-plus-circle-fill me-1"></i>
        Tambah Data Anggota 
    </a>
</div>
</div>

<form action="" method="get" class="mb-4" id="formCariAnggota">
    <?php foreach ($_GET as $key => $value): ?>
        <?php if ($key !== 'cari'): ?>
            <input type="hidden" name="<?= htmlspecialchars($key); ?>" value="<?= htmlspecialchars($value); ?>">
        <?php endif; ?>
    <?php endforeach; ?>
    
    <div class="input-group shadow-sm">
        <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
        <input type="text" 
               name="cari" 
               id="inputCariAnggota" 
               class="form-control border-start-0 ps-0" 
               placeholder="Cari berdasarkan NIS..." 
               autocomplete="off" 
               value="<?= htmlspecialchars($_GET['cari'] ?? ''); ?>">
    </div>
</form>

<div class="card border-0 p-0 member-table-card">
<div class="table-responsive">
    <table class="table align-middle mb-0 table-custom-hover member-table">
        <thead>
            <tr>
                <th class="px-3 fw-bold">
                    No
                </th>

                <th class="fw-bold">
                    NIS
                </th>

                <th class="fw-bold">
                    Nama Anggota
                </th>

                <th class="fw-bold">
                    Username
                </th>

                <th class="fw-bold">
                    Password
                </th>

                <th class="fw-bold">
                    Kelas
                </th>

                <th class="text-center fw-bold">
                    Aksi
                </th>
            </tr>
        </thead>

        <tbody>
            <?php
            /** @var mysqli $koneksi */

            if (!isset($koneksi)) {
                include'../koneksi.php';
            }
            $no = 1;

            
            if (isset($_GET['cari']) && trim($_GET['cari']) != '') {
                $cari = mysqli_real_escape_string($koneksi, trim($_GET['cari']));
                $query = "SELECT * FROM anggota WHERE nis LIKE '%$cari%' ORDER BY id_anggota DESC";
            } else {
                $query = "SELECT * FROM anggota ORDER BY id_anggota DESC";
            }

            $data = mysqli_query($koneksi, $query);
            if ($data && mysqli_num_rows($data) > 0) {
                $index = 0;
                foreach ($data as $anggota) {
                    $bg_row = ($index % 2 == 0)
                        ? '#FFFFFF'
                        : '#F1F5F3';

                    $index++;
            ?>
                <tr style="background-color: <?= $bg_row; ?> !important;">

                    <td class="px-3 fw-bold"
                        style="background-color: transparent !important;">

                        <?= $no++; ?>
                    </td>

                    <td style="background-color: transparent !important;">
                        <span class="badge nis-badge">
                            <?= $anggota['nis']; ?>
                        </span>
                    </td>

                    <td class="fw-bold"
                        style="background-color: transparent !important;">
                        <?= $anggota['nama_anggota']; ?>
                    </td>

                    <td class="text-muted"
                        style="background-color: transparent !important;">
                        <?= $anggota['username']; ?>
                    </td>

                    <td class="text-muted font-monospace"
                        style="background-color: transparent !important;">
                        <?= $anggota['password']; ?>
                    </td>

                    <td style="background-color: transparent !important;">
                        <span class="badge class-badge">
                            <?= $anggota['kelas']; ?>
                        </span>
                    </td>

                    <td class="text-center px-3"
                        style="background-color: transparent !important;">
                        <div class="d-inline-flex gap-2">


                            <a class="btn btn-sm px-2.5 py-1.5 shadow-sm btn-edit-member"
                               href="?halaman=edit_anggota&id=<?= $anggota['id_anggota']; ?>"
                               title="Edit">
                                <i class="bi bi-pencil-square"></i>
                            </a>


                            <a class="btn btn-sm px-2.5 py-1.5 shadow-sm btn-delete-member"
                               onclick="return confirm('Yakin ingin menghapus data anggota ini?')"
                               href="?halaman=hapus_anggota&id=<?= $anggota['id_anggota']; ?>"
                               title="Hapus">
                                <i class="bi bi-trash-fill"></i>
                            </a>

                        </div>
                    </td>
                </tr>
            <?php
                }

            } else {
                echo "
                <tr>
                    <td colspan='7'
                        class='text-center py-5 text-muted fw-semibold fst-italic'
                        style='background-color: #FFFFFF !important;'>

                        <i class='bi bi-people d-block mb-2'
                           style='font-size: 1.5rem; color: #9CA3AF;'></i>

                        Belum ada data anggota yang tersimpan atau NIS tidak ditemukan.

                    </td>
                </tr>";
            }

            ?>

        </tbody>
    </table>
</div>
</div>


<script>
const inputCariAnggota = document.getElementById('inputCariAnggota');
const formCariAnggota = document.getElementById('formCariAnggota');

if (inputCariAnggota && formCariAnggota) {
    let waktuCariAnggota;

    inputCariAnggota.addEventListener('input', function () {
        clearTimeout(waktuCariAnggota);

        waktuCariAnggota = setTimeout(function () {
            formCariAnggota.submit();
        }, 400);
    });

    inputCariAnggota.focus();
    let panjangTeksAnggota = inputCariAnggota.value.length;
    inputCariAnggota.setSelectionRange(panjangTeksAnggota, panjangTeksAnggota);
}
</script>