<?php 
session_start();
if (isset($_POST['tombol'])) {
    include 'koneksi.php';
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM anggota WHERE username='$username' AND password='$password'";
    $data = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($data) > 0) {
        $d = mysqli_fetch_array($data);
        $_SESSION['id_anggota'] = $d['id_anggota'];
        $_SESSION['username'] = $d['username'];
        $_SESSION['nama_anggota'] = $d['nama_anggota'];

        header("Location: anggota/dashboard-anggota.php");
        exit;
    } else {
        echo "<script>alert('Login Gagal, Username / Password Salah'); window.location.assign('login-anggota.php');</script>";
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Anggota Aplikasi Perpustakaan Digital Sekolah</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="page-login-anggota d-flex justify-content-center align-items-center vh-100">

    <div class="bg-overlay"></div>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4" style="width: 440px;">
                <div class="card card-login p-4">
                    <div class="text-center mb-4">
                        <div class="rounded-circle text-white d-inline-flex justify-content-center align-items-center mb-3 shadow-sm" style="width: 65px; height: 65px; font-size: 30px; background-color: #064e3b;">
                            <i class="bi bi-person-fill"></i>
                        </div>
                        <h4 class="fw-bold mb-1 text-dark">Login Anggota</h4>
                        <p class="text-muted small mb-0">Aplikasi Perpustakaan Digital Sekolah</p>
                    </div>

                    <form method="post" action="">
                        <div class="mb-3 position-relative">
                            <span class="input-group-text-custom"><i class="bi bi-person"></i></span>
                            <input name="username" type="text" class="form-control py-2 form-control-icon" placeholder="Username" required>
                        </div>
                        <div class="mb-3 position-relative">
                            <span class="input-group-text-custom"><i class="bi bi-lock"></i></span>
                            <input name="password" type="password" class="form-control py-2 form-control-icon" placeholder="Password" required>
                        </div>
                        
                        <button type="submit" name="tombol" class="btn btn-primary-custom text-white w-100 mb-3 py-2 fw-semibold shadow-sm">Login</button>
                        
                        <div class="text-center small">
                            <a href="login-admin.php" class="text-decoration-none d-block mb-1" style="color: #064e3b; font-weight: 500;"><i class="bi bi-person-badge"></i> Login sebagai Admin Perpustakaan..?  &gt;</a>
                            <a href="pendaftaran-anggota.php" class="text-decoration-none d-block" style="color: #064e3b; font-weight: 500;"><i class="bi bi-pencil-square"></i> Pendaftaran Anggota Perpustakaan..?  &gt;</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
</html>