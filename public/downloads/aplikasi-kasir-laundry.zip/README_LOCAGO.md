# Sistem Manajemen Laundry Kiloan - Aplikasi Kasir Laundry

```
========================================================================
📦 Sistem Manajemen Laundry Kiloan - Aplikasi Kasir Laundry
Kategori     : Layanan & Jasa
Tech Stack   : PHP Native • PHP • MySQL
Database     : MySQL (.sql) (File: database/laundry.sql)
Sumber Asli  : https://github.com/ReyZ007/aplikasi-kasir-laundry (GitHub Open Source)
Stars GitHub : ⭐ 1 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/aplikasi-kasir-laundry`
     * Untuk Laragon: `C:/laragon/www/aplikasi-kasir-laundry`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database kosong `laundry` dulu di phpMyAdmin (file SQL ini
     TIDAK membuat database sendiri — tidak ada perintah CREATE DATABASE di
     dalamnya; nama database `laundry` sesuai README repo asli dan file
     `admin/include/koneksi.php`). Lalu klik tab 'Import', pilih file SQL
     yang disertakan pada: `database/laundry.sql`, pastikan database
     `laundry` yang dipilih sebagai tujuan import.
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = laundry   (sesuai admin/include/koneksi.php repo asli)

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/aplikasi-kasir-laundry
     (halaman login; sesudah login, dashboard admin ada di
     http://localhost/aplikasi-kasir-laundry/admin/index.php)

5. AKUN LOGIN DEMO (terverifikasi terhadap database .sql bawaan):
   - Admin: admin / 1  (tabel demo di README repo asli; hash bcrypt di
     database/laundry.sql terverifikasi cocok dengan password ini)
   - Petugas: Budi — password TIDAK didokumentasikan README repo asli
     ("[isi password Budi]"); jangan ditebak. Login sebagai admin untuk
     mengelola akun, atau reset password Budi langsung di tabel `akun`.

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
