# Sistem Informasi Inventaris & Gudang - Inventaris Lab20 Update

```
========================================================================
📦 Sistem Informasi Inventaris & Gudang - Inventaris Lab20 Update
Kategori     : Bisnis & Manajemen
Tech Stack   : Laravel • PHP • MySQL • Bootstrap
Database     : MySQL (.sql) (File: backup-2026-07-24.sql)
Sumber Asli  : https://github.com/vianhubgit/inventaris-lab2.0-update (GitHub Open Source)
Stars GitHub : ⭐ 0 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/inventaris-lab20-update`
     * Untuk Laragon: `C:/laragon/www/inventaris-lab20-update`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - File SQL ini membuat database `inventaris_lab20_update` sendiri — tidak perlu membuat
     database manual. Klik tab 'Import', pilih file SQL yang disertakan pada:
     `backup-2026-07-24.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = inventaris_lab20_update

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/inventaris-lab20-update

5. AKUN LOGIN DEMO (terverifikasi terhadap database .sql bawaan):
   - Admin: demoadmin / demoadmin
   - Sekretaris: sekretaris / sekretaris123
   - Catatan: README repo asli juga mendokumentasikan admin / admin123 —
     akun itu dibuat oleh seeder (php artisan migrate:fresh --seed), TETAPI
     password admin di file .sql bawaan sudah diganti pemilik repo, jadi
     admin/admin123 TIDAK bisa login setelah import .sql. Pakai demoadmin
     untuk peran Admin, atau jalankan migrate:fresh --seed (langkah 6) untuk
     instalasi baru.

6. INSTALASI BARU VIA SEEDER (ALTERNATIF — ganti langkah 2, jangan keduanya):
   - Sebagai pengganti import .sql, Anda bisa membangun database dari nol:
     php artisan migrate:fresh --seed
   - Perintah ini membuat ulang semua tabel + akun demo dari README
     (admin / admin123 dan sekretaris / sekretaris123) + data contoh.
   - JANGAN jalankan ini setelah import .sql — migrate:fresh MENGHAPUS
     semua data hasil import.
========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
