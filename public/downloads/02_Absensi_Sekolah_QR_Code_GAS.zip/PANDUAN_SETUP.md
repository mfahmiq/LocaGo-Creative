# Panduan Sistem Absensi QR Code Google Apps Script (0 Server Fee)
1. Buat Google Spreadsheet baru dengan 2 tab:
   - Tab 1: `Data_Siswa` (Kolom: NISN, Nama, Kelas, No_WA_Ortu)
   - Tab 2: `Presensi_Log` (Kolom: Timestamp, NISN, Nama, Kelas, Status)
2. Klik menu **Ekstensi > Apps Script**.
3. Copy paste file `Code.gs` dan buat file HTML `index.html`.
4. Masukkan Spreadsheet ID dan Token Fonnte WA Anda di `Code.gs`.
5. Klik **Deploy > New Deployment > Web App** (Set akses: Anyone / Siapa Saja).
6. Buka URL Web App di tablet sekolah atau laptop webcam. Siap digunakan!
