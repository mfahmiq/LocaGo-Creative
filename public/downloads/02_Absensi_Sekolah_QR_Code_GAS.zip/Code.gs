// Code.gs - Google Apps Script Engine
const SPREADSHEET_ID = "YOUR_SPREADSHEET_ID_HERE";
const WA_TOKEN = "YOUR_FONNTE_TOKEN_HERE";

function doGet() {
  return HtmlService.createTemplateFromFile('index')
    .evaluate()
    .setTitle('Presensi QR Code Sekolah')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function processAttendance(nisn) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheetSiswa = ss.getSheetByName('Data_Siswa');
  const sheetPresensi = ss.getSheetByName('Presensi_Log');
  
  const data = sheetSiswa.getDataRange().getValues();
  let student = null;
  for (let i = 1; i < data.length; i++) {
    if (data[i][0] == nisn) {
      student = { nisn: data[i][0], nama: data[i][1], kelas: data[i][2], waOrtu: data[i][3] };
      break;
    }
  }
  
  if (!student) return { status: 'error', message: 'Siswa tidak ditemukan' };
  
  const now = new Date();
  sheetPresensi.appendRow([now, student.nisn, student.nama, student.kelas, 'Hadir']);
  
  // Kirim WhatsApp ke Orang Tua
  sendWaNotification(student.waOrtu, student.nama, now);
  
  return { status: 'success', student: student, time: now.toLocaleTimeString() };
}

function sendWaNotification(target, nama, time) {
  if (!WA_TOKEN || WA_TOKEN === "YOUR_FONNTE_TOKEN_HERE") return;
  const msg = "Assalamu'alaikum Bpk/Ibu. Memberitahukan bahwa ananda " + nama + " telah hadir di sekolah pada " + time.toLocaleTimeString() + " WIB.";
  UrlFetchApp.fetch("https://api.fonnte.com/send", {
    method: "post",
    headers: { "Authorization": WA_TOKEN },
    payload: { "target": target, "message": msg }
  });
}
