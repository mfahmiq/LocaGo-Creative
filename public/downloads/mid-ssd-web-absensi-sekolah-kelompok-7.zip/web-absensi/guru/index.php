<?php
session_start();

if (!isset($_SESSION['id']) || $_SESSION['role'] != 'guru') {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

$user_id = $_SESSION['id'];

$guru = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT id,nama
FROM teachers
WHERE user_id='$user_id'
"));

if(!$guru){
    die("Data guru tidak ditemukan.");
}

$teacher_id = $guru['id'];

$sql = "
SELECT

ats.id,
ats.tanggal,

c.tingkat,
c.nama_kelas,

sub.nama_mapel,

SUM(CASE WHEN ad.status='Hadir' THEN 1 ELSE 0 END) hadir,
SUM(CASE WHEN ad.status='Sakit' THEN 1 ELSE 0 END) sakit,
SUM(CASE WHEN ad.status='Izin' THEN 1 ELSE 0 END) izin,
SUM(CASE WHEN ad.status='Alfa' THEN 1 ELSE 0 END) alfa

FROM attendance_sessions ats

JOIN schedules s
ON ats.schedule_id=s.id

JOIN classes c
ON s.class_id=c.id

JOIN subjects sub
ON s.subject_id=sub.id

JOIN attendance_details ad
ON ats.id=ad.session_id

WHERE s.teacher_id='$teacher_id'

GROUP BY ats.id

ORDER BY ats.tanggal DESC
";

$query = mysqli_query($conn,$sql);

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <h2 class="fw-bold">
            Riwayat Absensi
        </h2>

        <span class="badge bg-primary">
            <?= mysqli_num_rows($query) ?> Laporan
        </span>

    </div>

    <div class="card shadow">

        <div class="card-header bg-primary text-white">

            Riwayat Absensi Guru

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-bordered table-striped table-hover datatable">

                    <thead class="table-primary text-center">

                        <tr>

                            <th>No</th>

                            <th>Tanggal</th>

                            <th>Kelas</th>

                            <th>Mata Pelajaran</th>

                            <th>Hadir</th>

                            <th>Sakit</th>

                            <th>Izin</th>

                            <th>Alfa</th>

                            <th width="220">Aksi</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php
$no=1;

while($row=mysqli_fetch_assoc($query)){
?>

                        <tr>

                            <td class="text-center"><?= $no++ ?></td>

                            <td class="text-center">

                                <?= date('d-m-Y',strtotime($row['tanggal'])) ?>

                            </td>

                            <td>

                                <?= htmlspecialchars($row['tingkat']) ?>

                                <?= htmlspecialchars($row['nama_kelas']) ?>

                            </td>

                            <td>

                                <?= htmlspecialchars($row['nama_mapel']) ?>

                            </td>

                            <td class="text-center">

                                <span class="badge bg-success">

                                    <?= $row['hadir'] ?>

                                </span>

                            </td>

                            <td class="text-center">

                                <span class="badge bg-primary">

                                    <?= $row['sakit'] ?>

                                </span>

                            </td>

                            <td class="text-center">

                                <span class="badge bg-warning text-dark">

                                    <?= $row['izin'] ?>

                                </span>

                            </td>

                            <td class="text-center">

                                <span class="badge bg-danger">

                                    <?= $row['alfa'] ?>

                                </span>

                            </td>

                            <td class="text-center">

                                <div class="btn-group">

                                    <a href="detail.php?id=<?= $row['id'] ?>" class="btn btn-info btn-sm">

                                        <i class="bi bi-eye"></i>

                                        Detail

                                    </a>

                                    <a href="export_pdf.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm">

                                        <i class="bi bi-file-earmark-pdf"></i>

                                        PDF

                                    </a>

                                    <a href="export_excel.php?id=<?= $row['id'] ?>" class="btn btn-success btn-sm">

                                        <i class="bi bi-file-earmark-excel"></i>

                                        Excel

                                    </a>

                                </div>

                            </td>

                        </tr>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>