<?php
session_start();

if (!isset($_SESSION['id']) || $_SESSION['role'] != 'guru') {
    header("Location: ../auth/login.php");
    exit;
}

require "../config/config.php";
require "../config/koneksi.php";

/*
|--------------------------------------------------------------------------
| Ambil ID Guru
|--------------------------------------------------------------------------
*/

$user_id = $_SESSION['id'];

$qGuru = mysqli_query($conn,"
SELECT id,nama
FROM teachers
WHERE user_id='$user_id'
");

$guru = mysqli_fetch_assoc($qGuru);

if(!$guru){
    die("Data guru tidak ditemukan.");
}

$teacher_id = $guru['id'];

/*
|--------------------------------------------------------------------------
| Statistik
|--------------------------------------------------------------------------
*/

$jmlJadwal = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT COUNT(*) total
FROM schedules
WHERE teacher_id='$teacher_id'
"))['total'];

$jmlKelas = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT COUNT(DISTINCT class_id) total
FROM schedules
WHERE teacher_id='$teacher_id'
"))['total'];

$jmlAbsensi = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT COUNT(*) total
FROM attendance_sessions ats
JOIN schedules s
ON ats.schedule_id=s.id
WHERE s.teacher_id='$teacher_id'
"))['total'];

$hariIni = date('Y-m-d');

$absensiHariIni = mysqli_fetch_assoc(mysqli_query($conn,"
SELECT COUNT(*) total
FROM attendance_sessions ats
JOIN schedules s
ON ats.schedule_id=s.id
WHERE s.teacher_id='$teacher_id'
AND ats.tanggal='$hariIni'
"))['total'];

/*
|--------------------------------------------------------------------------
| Jadwal Hari Ini
|--------------------------------------------------------------------------
*/

$hari = date('l');

switch($hari){
    case "Monday": $hari="Senin"; break;
    case "Tuesday": $hari="Selasa"; break;
    case "Wednesday": $hari="Rabu"; break;
    case "Thursday": $hari="Kamis"; break;
    case "Friday": $hari="Jumat"; break;
    case "Saturday": $hari="Sabtu"; break;
    default: $hari="Minggu";
}

$jadwal = mysqli_query($conn,"
SELECT
s.*,
c.tingkat,
c.nama_kelas,
sub.nama_mapel

FROM schedules s

JOIN classes c
ON s.class_id=c.id

JOIN subjects sub
ON s.subject_id=sub.id

WHERE
s.teacher_id='$teacher_id'
AND s.hari='$hari'

ORDER BY s.jam_mulai
");

include "../templates/header.php";
include "../templates/sidebar.php";
include "../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="mb-4">
        <h2 class="fw-bold">
            Dashboard Guru
        </h2>

        <p class="text-muted">
            Selamat datang,
            <strong><?= htmlspecialchars($guru['nama']) ?></strong>
        </p>
    </div>

    <div class="row">

        <div class="col-md-3 mb-3">
            <div class="card shadow border-0 bg-primary text-white">
                <div class="card-body text-center">
                    <h6>Jadwal Mengajar</h6>
                    <h2><?= $jmlJadwal ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="card shadow border-0 bg-success text-white">
                <div class="card-body text-center">
                    <h6>Kelas Diampu</h6>
                    <h2><?= $jmlKelas ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="card shadow border-0 bg-warning">
                <div class="card-body text-center">
                    <h6>Total Absensi</h6>
                    <h2><?= $jmlAbsensi ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="card shadow border-0 bg-danger text-white">
                <div class="card-body text-center">
                    <h6>Absensi Hari Ini</h6>
                    <h2><?= $absensiHariIni ?></h2>
                </div>
            </div>
        </div>

    </div>

    <div class="card shadow">

        <div class="card-header bg-primary text-white">

            <h5 class="mb-0">
                Jadwal Mengajar Hari Ini (<?= $hari ?>)
            </h5>

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-bordered table-hover">

                    <thead class="table-primary">

                        <tr>

                            <th>No</th>

                            <th>Jam</th>

                            <th>Kelas</th>

                            <th>Mata Pelajaran</th>

                            <th>Aksi</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php
$no=1;

if(mysqli_num_rows($jadwal)>0){

while($row=mysqli_fetch_assoc($jadwal)){
?>

                        <tr>

                            <td><?= $no++ ?></td>

                            <td>
                                <?= substr($row['jam_mulai'],0,5) ?>
                                -
                                <?= substr($row['jam_selesai'],0,5) ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($row['tingkat']) ?>
                                <?= htmlspecialchars($row['nama_kelas']) ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($row['nama_mapel']) ?>
                            </td>

                            <td>

                                <a href="attendance/create.php?schedule_id=<?= $row['id'] ?>"
                                    class="btn btn-success btn-sm">

                                    <i class="bi bi-check2-square"></i>

                                    Input Absensi

                                </a>

                            </td>

                        </tr>

                        <?php
}

}else{
?>

                        <tr>

                            <td colspan="5" class="text-center text-muted">
                                Tidak ada jadwal hari ini.
                            </td>

                        </tr>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<?php include "../templates/footer.php"; ?>