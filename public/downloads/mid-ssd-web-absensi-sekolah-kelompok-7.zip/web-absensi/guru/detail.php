<?php
session_start();

if (!isset($_SESSION['id']) || $_SESSION['role'] != 'guru') {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['id'];
$session_id = (int)$_GET['id'];

/*
|--------------------------------------------------------------------------
| Ambil ID Guru
|--------------------------------------------------------------------------
*/

$qGuru = mysqli_query($conn,"
SELECT id,nama
FROM teachers
WHERE user_id='$user_id'
");

$guru = mysqli_fetch_assoc($qGuru);

if(!$guru){
    die("Data guru tidak ditemukan.");
}

$teacher_id = $guru['id'];

/*
|--------------------------------------------------------------------------
| Validasi Session Absensi Milik Guru
|--------------------------------------------------------------------------
*/

$stmt = mysqli_prepare($conn,"
SELECT

ats.id,
ats.tanggal,

s.hari,
s.jam_mulai,
s.jam_selesai,

c.tingkat,
c.nama_kelas,

sub.nama_mapel,

t.nama AS guru

FROM attendance_sessions ats

JOIN schedules s
ON ats.schedule_id=s.id

JOIN classes c
ON s.class_id=c.id

JOIN teachers t
ON s.teacher_id=t.id

JOIN subjects sub
ON s.subject_id=sub.id

WHERE ats.id=?
AND s.teacher_id=?
");

mysqli_stmt_bind_param($stmt,"ii",$session_id,$teacher_id);
mysqli_stmt_execute($stmt);

$session = mysqli_fetch_assoc(
mysqli_stmt_get_result($stmt)
);

if(!$session){
    die("Data tidak ditemukan.");
}

/*
|--------------------------------------------------------------------------
| Detail Siswa
|--------------------------------------------------------------------------
*/

$detail = mysqli_prepare($conn,"
SELECT

st.nis,
st.nama,

ad.status,
ad.keterangan

FROM attendance_details ad

JOIN students st
ON ad.student_id=st.id

WHERE ad.session_id=?

ORDER BY st.nama ASC
");

mysqli_stmt_bind_param($detail,"i",$session_id);
mysqli_stmt_execute($detail);

$data = mysqli_stmt_get_result($detail);

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header bg-primary text-white">

            <h4 class="mb-0">
                Detail Absensi
            </h4>

        </div>

        <div class="card-body">

            <div class="row mb-4">

                <div class="col-md-3">
                    <b>Tanggal</b><br>
                    <?= date('d-m-Y',strtotime($session['tanggal'])) ?>
                </div>

                <div class="col-md-3">
                    <b>Kelas</b><br>
                    <?= htmlspecialchars($session['tingkat']) ?>
                    <?= htmlspecialchars($session['nama_kelas']) ?>
                </div>

                <div class="col-md-3">
                    <b>Mata Pelajaran</b><br>
                    <?= htmlspecialchars($session['nama_mapel']) ?>
                </div>

                <div class="col-md-3">
                    <b>Guru</b><br>
                    <?= htmlspecialchars($session['guru']) ?>
                </div>

            </div>

            <div class="table-responsive">

                <table class="table table-bordered table-striped">

                    <thead class="table-primary text-center">

                        <tr>

                            <th>No</th>
                            <th>NIS</th>
                            <th>Nama</th>
                            <th>Status</th>
                            <th>Keterangan</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php

$no=1;

$hadir=0;
$sakit=0;
$izin=0;
$alfa=0;

while($row=mysqli_fetch_assoc($data)){

switch($row['status']){

case 'Hadir':
$badge='success';
$hadir++;
break;

case 'Sakit':
$badge='primary';
$sakit++;
break;

case 'Izin':
$badge='warning';
$izin++;
break;

default:
$badge='danger';
$alfa++;
break;

}

?>

                        <tr>

                            <td class="text-center"><?= $no++ ?></td>

                            <td><?= htmlspecialchars($row['nis']) ?></td>

                            <td><?= htmlspecialchars($row['nama']) ?></td>

                            <td class="text-center">

                                <span class="badge bg-<?= $badge ?>">

                                    <?= htmlspecialchars($row['status']) ?>

                                </span>

                            </td>

                            <td>

                                <?= empty($row['keterangan']) ? '-' : htmlspecialchars($row['keterangan']) ?>

                            </td>

                        </tr>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

            <hr>

            <div class="row">

                <div class="col-md-3">

                    <div class="card bg-success text-white">

                        <div class="card-body text-center">

                            <h6>Hadir</h6>

                            <h2><?= $hadir ?></h2>

                        </div>

                    </div>

                </div>

                <div class="col-md-3">

                    <div class="card bg-primary text-white">

                        <div class="card-body text-center">

                            <h6>Sakit</h6>

                            <h2><?= $sakit ?></h2>

                        </div>

                    </div>

                </div>

                <div class="col-md-3">

                    <div class="card bg-warning">

                        <div class="card-body text-center">

                            <h6>Izin</h6>

                            <h2><?= $izin ?></h2>

                        </div>

                    </div>

                </div>

                <div class="col-md-3">

                    <div class="card bg-danger text-white">

                        <div class="card-body text-center">

                            <h6>Alfa</h6>

                            <h2><?= $alfa ?></h2>

                        </div>

                    </div>

                </div>

            </div>

            <hr>

            <div class="d-flex justify-content-between">

                <a href="index.php" class="btn btn-secondary">

                    <i class="bi bi-arrow-left"></i>

                    Kembali

                </a>

                <div>

                    <a href="export_pdf.php?id=<?= $session['id'] ?>" class="btn btn-danger">

                        <i class="bi bi-file-earmark-pdf"></i>

                        Export PDF

                    </a>

                    <a href="export_excel.php?id=<?= $session['id'] ?>" class="btn btn-success">

                        <i class="bi bi-file-earmark-excel"></i>

                        Export Excel

                    </a>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>