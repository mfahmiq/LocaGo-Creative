<?php
session_start();

require_once "../config/koneksi.php";

$email = trim($_POST['email']);
$password = trim($_POST['password']);

$stmt = mysqli_prepare(
    $conn,
    "SELECT id, role_id, nama, email, password
     FROM users
     WHERE email=?"
);

mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 1) {

    $user = mysqli_fetch_assoc($result);

    if (password_verify($password, $user['password'])) {

        $_SESSION['id'] = $user['id'];
        $_SESSION['nama'] = $user['nama'];
        $_SESSION['role'] = $user['role_id'];

        // Arahkan sesuai role
        if ($user['role_id'] == 1) {
            header("Location: ../admin/dashboard.php");
        } elseif ($user['role_id'] == 2) {
            header("Location: ../guru/dashboard.php");
        } elseif ($user['role_id'] == 3) {
            header("Location: ../siswa/dashboard.php");
        }

        exit;

    } else {

        echo "<script>
            alert('Password salah');
            window.location='login.php';
        </script>";

    }

} else {

    echo "<script>
        alert('Email tidak ditemukan');
        window.location='login.php';
    </script>";

}