<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

$tanggal = $_GET['tanggal'] ?? "";
$kelas = $_GET['kelas'] ?? "";

$sql = "
SELECT
    ats.id,
    ats.tanggal,

    s.hari,
    s.jam_mulai,
    s.jam_selesai,

    c.tingkat,
    c.nama_kelas,

    sub.nama_mapel,

    t.nama AS guru,

    SUM(CASE WHEN ad.status='Hadir' THEN 1 ELSE 0 END) AS hadir,
    SUM(CASE WHEN ad.status='Sakit' THEN 1 ELSE 0 END) AS sakit,
    SUM(CASE WHEN ad.status='Izin' THEN 1 ELSE 0 END) AS izin,
    SUM(CASE WHEN ad.status='Alfa' THEN 1 ELSE 0 END) AS alfa

FROM attendance_sessions ats

JOIN schedules s
ON ats.schedule_id=s.id

JOIN classes c
ON s.class_id=c.id

JOIN teachers t
ON s.teacher_id=t.id

JOIN subjects sub
ON s.subject_id=sub.id

JOIN attendance_details ad
ON ats.id=ad.session_id

WHERE 1=1
";

if($tanggal!=""){
    $sql .= " AND ats.tanggal='".mysqli_real_escape_string($conn,$tanggal)."'";
}

if($kelas!=""){
    $sql .= " AND c.id=".(int)$kelas;
}

$sql .= "
GROUP BY ats.id

ORDER BY
ats.tanggal DESC,
c.tingkat,
c.nama_kelas
";

$query = mysqli_query($conn,$sql);

$totalLaporan = mysqli_num_rows($query);

$kelasQuery = mysqli_query($conn,"
SELECT
id,
tingkat,
nama_kelas
FROM classes
ORDER BY tingkat,nama_kelas
");

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                <i class="bi bi-file-earmark-text text-primary"></i>

                Laporan Absensi

            </h2>

            <p class="text-muted mb-0">

                Rekapitulasi absensi siswa berdasarkan kelas dan tanggal.

            </p>

        </div>

        <span class="badge bg-primary fs-6">

            Total <?= $totalLaporan ?> Laporan

        </span>

    </div>

    <div class="row mb-4">

        <div class="col-md-4">

            <div class="card shadow border-0 bg-primary text-white">

                <div class="card-body">

                    <small>Total Laporan</small>

                    <h2 class="fw-bold">

                        <?= $totalLaporan ?>

                    </h2>

                </div>

            </div>

        </div>

        <div class="col-md-4">

            <div class="card shadow border-0 bg-success text-white">

                <div class="card-body">

                    <small>Tanggal Hari Ini</small>

                    <h5 class="fw-bold">

                        <?= date('d-m-Y') ?>

                    </h5>

                </div>

            </div>

        </div>

        <div class="col-md-4">

            <div class="card shadow border-0 bg-warning">

                <div class="card-body">

                    <small>Filter</small>

                    <h5 class="fw-bold">

                        <?= ($tanggal || $kelas) ? "Aktif" : "Semua Data" ?>

                    </h5>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow mb-4">

        <div class="card-header bg-white">

            <h5 class="mb-0">

                Filter Laporan

            </h5>

        </div>

        <div class="card-body">

            <form method="GET">

                <div class="row">

                    <div class="col-md-4 mb-3">

                        <label class="form-label">

                            Tanggal

                        </label>

                        <input type="date" name="tanggal" class="form-control"
                            value="<?= htmlspecialchars($tanggal) ?>">

                    </div>

                    <div class="col-md-4 mb-3">

                        <label class="form-label">

                            Kelas

                        </label>

                        <select name="kelas" class="form-select">

                            <option value="">

                                Semua Kelas

                            </option>
                            <?php while($k = mysqli_fetch_assoc($kelasQuery)){ ?>

                            <option value="<?= $k['id'] ?>" <?= ($kelas == $k['id']) ? 'selected' : '' ?>>

                                <?= htmlspecialchars($k['tingkat']) ?>

                                <?= htmlspecialchars($k['nama_kelas']) ?>

                            </option>

                            <?php } ?>

                        </select>

                    </div>

                    <div class="col-md-4 d-flex align-items-end mb-3">

                        <button type="submit" class="btn btn-primary me-2">

                            <i class="bi bi-search"></i>

                            Filter

                        </button>

                        <a href="index.php" class="btn btn-secondary">

                            <i class="bi bi-arrow-clockwise"></i>

                            Reset

                        </a>

                    </div>

                </div>

            </form>

        </div>

    </div>

    <div class="card shadow">

        <div class="card-header bg-white">

            <h5 class="mb-0">

                Daftar Laporan Absensi

            </h5>

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-bordered table-striped table-hover datatable">

                    <thead class="table-primary text-center">

                        <tr>

                            <th>No</th>

                            <th>Tanggal</th>

                            <th>Kelas</th>

                            <th>Mata Pelajaran</th>

                            <th>Guru</th>

                            <th>Hadir</th>

                            <th>Sakit</th>

                            <th>Izin</th>

                            <th>Alfa</th>

                            <th width="220">Aksi</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php

                        $no = 1;

                        while($row = mysqli_fetch_assoc($query)){

                        ?>

                        <tr>

                            <td class="text-center">

                                <?= $no++ ?>

                            </td>

                            <td class="text-center">

                                <strong>

                                    <?= date('d-m-Y', strtotime($row['tanggal'])) ?>

                                </strong>

                                <br>

                                <small class="text-muted">

                                    <?= htmlspecialchars($row['hari']) ?>

                                </small>

                            </td>

                            <td>

                                <?= htmlspecialchars($row['tingkat']) ?>

                                <?= htmlspecialchars($row['nama_kelas']) ?>

                            </td>

                            <td>

                                <?= htmlspecialchars($row['nama_mapel']) ?>

                            </td>

                            <td>

                                <?= htmlspecialchars($row['guru']) ?>

                            </td>

                            <td class="text-center">

                                <span class="badge bg-success">

                                    <?= $row['hadir'] ?>

                                </span>

                            </td>

                            <td class="text-center">

                                <span class="badge bg-primary">

                                    <?= $row['sakit'] ?>

                                </span>

                            </td>

                            <td class="text-center">

                                <span class="badge bg-warning text-dark">

                                    <?= $row['izin'] ?>

                                </span>

                            </td>

                            <td class="text-center">

                                <span class="badge bg-danger">

                                    <?= $row['alfa'] ?>

                                </span>

                            </td>

                            <td class="text-center">

                                <div class="btn-group">

                                    <a href="detail.php?id=<?= $row['id'] ?>" class="btn btn-info btn-sm">

                                        <i class="bi bi-eye"></i>

                                        Detail

                                    </a>

                                    <a href="export_pdf.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm">

                                        <i class="bi bi-file-earmark-pdf"></i>

                                        PDF

                                    </a>

                                    <a href="export_excel.php?id=<?= $row['id'] ?>" class="btn btn-success btn-sm">

                                        <i class="bi bi-file-earmark-excel"></i>

                                        Excel

                                    </a>

                                </div>

                            </td>

                        </tr>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>z