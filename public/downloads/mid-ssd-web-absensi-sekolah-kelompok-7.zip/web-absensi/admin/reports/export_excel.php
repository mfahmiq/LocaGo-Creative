<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/koneksi.php";


if (!isset($_GET['id'])) {
    exit("ID tidak ditemukan");
}

$id = (int)$_GET['id'];


/* Ambil data sesi */

$sql = mysqli_prepare($conn,"
SELECT
ats.tanggal,
c.tingkat,
c.nama_kelas,
sub.nama_mapel,
t.nama AS guru
FROM attendance_sessions ats

JOIN schedules s
ON ats.schedule_id=s.id

JOIN classes c
ON s.class_id=c.id

JOIN subjects sub
ON s.subject_id=sub.id

JOIN teachers t
ON s.teacher_id=t.id

WHERE ats.id=?
");


mysqli_stmt_bind_param($sql,"i",$id);
mysqli_stmt_execute($sql);

$session=mysqli_fetch_assoc(
mysqli_stmt_get_result($sql)
);



/* Ambil siswa */

$detail=mysqli_prepare($conn,"
SELECT
st.nis,
st.nama,
ad.status,
ad.keterangan

FROM attendance_details ad

JOIN students st
ON ad.student_id=st.id

WHERE ad.session_id=?

ORDER BY st.nama
");


mysqli_stmt_bind_param($detail,"i",$id);
mysqli_stmt_execute($detail);

$data=mysqli_stmt_get_result($detail);



/* Download CSV */

$filename="laporan_absensi.csv";


header("Content-Type: text/csv");
header(
"Content-Disposition: attachment; filename=$filename"
);


$output=fopen("php://output","w");



fputcsv($output,[
"LAPORAN ABSENSI"
]);


fputcsv($output,[
"Tanggal",
$session['tanggal']
]);


fputcsv($output,[
"Kelas",
$session['tingkat']." ".$session['nama_kelas']
]);


fputcsv($output,[
"Mata Pelajaran",
$session['nama_mapel']
]);


fputcsv($output,[
"Guru",
$session['guru']
]);


fputcsv($output,[]);


fputcsv($output,[
"No",
"NIS",
"Nama",
"Status",
"Keterangan"
]);



$no=1;

while($row=mysqli_fetch_assoc($data)){

    fputcsv($output,[
        $no++,
        $row['nis'],
        $row['nama'],
        $row['status'],
        $row['keterangan']
    ]);

}


fclose($output);

exit;