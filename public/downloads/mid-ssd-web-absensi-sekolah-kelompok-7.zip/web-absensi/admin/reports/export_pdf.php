<?php

session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/koneksi.php";


if (!isset($_GET['id'])) {
    exit("ID tidak ditemukan");
}


$id = (int)$_GET['id'];



/* Ambil data sesi */

$sql = mysqli_prepare($conn,"
SELECT

ats.tanggal,

c.tingkat,
c.nama_kelas,

sub.nama_mapel,

t.nama AS guru,

s.hari,
s.jam_mulai,
s.jam_selesai


FROM attendance_sessions ats


JOIN schedules s
ON ats.schedule_id=s.id


JOIN classes c
ON s.class_id=c.id


JOIN subjects sub
ON s.subject_id=sub.id


JOIN teachers t
ON s.teacher_id=t.id


WHERE ats.id=?

");


mysqli_stmt_bind_param($sql,"i",$id);

mysqli_stmt_execute($sql);


$session=mysqli_fetch_assoc(
    mysqli_stmt_get_result($sql)
);



if(!$session){

    die("Data tidak ditemukan");

}



/* Ambil detail siswa */

$detail=mysqli_prepare($conn,"
SELECT

st.nis,

st.nama,

ad.status,

ad.keterangan


FROM attendance_details ad


JOIN students st

ON ad.student_id=st.id


WHERE ad.session_id=?


ORDER BY st.nama

");


mysqli_stmt_bind_param($detail,"i",$id);

mysqli_stmt_execute($detail);


$data=mysqli_stmt_get_result($detail);



?>


<!DOCTYPE html>
<html>

<head>

    <title>
        Laporan Absensi
    </title>


    <style>
    body {

        font-family: Arial;

    }


    h2 {

        text-align: center;

    }


    table {

        width: 100%;

        border-collapse: collapse;

    }


    table,
    th,
    td {

        border: 1px solid black;

    }


    th,
    td {

        padding: 8px;

    }


    .info {

        margin-bottom: 20px;

    }


    @media print {

        .btn {

            display: none;

        }

    }
    </style>


</head>


<body>


    <button class="btn" onclick="window.print()">

        Cetak / Simpan PDF

    </button>


    <h2>
        LAPORAN ABSENSI SISWA
    </h2>



    <div class="info">


        <b>Tanggal :</b>

        <?= $session['tanggal'] ?>

        <br>


        <b>Kelas :</b>

        <?= $session['tingkat']." ".$session['nama_kelas'] ?>

        <br>


        <b>Mata Pelajaran :</b>

        <?= $session['nama_mapel'] ?>

        <br>


        <b>Guru :</b>

        <?= $session['guru'] ?>

        <br>


        <b>Hari :</b>

        <?= $session['hari'] ?>

        <br>


        <b>Jam :</b>

        <?= $session['jam_mulai']." - ".$session['jam_selesai'] ?>


    </div>



    <table>


        <tr>

            <th>No</th>

            <th>NIS</th>

            <th>Nama</th>

            <th>Status</th>

            <th>Keterangan</th>

        </tr>



        <?php


$no=1;


while($row=mysqli_fetch_assoc($data)){


?>


        <tr>


            <td>
                <?= $no++ ?>
            </td>


            <td>
                <?= htmlspecialchars($row['nis']) ?>
            </td>


            <td>
                <?= htmlspecialchars($row['nama']) ?>
            </td>


            <td>
                <?= htmlspecialchars($row['status']) ?>
            </td>


            <td>
                <?= htmlspecialchars($row['keterangan']) ?>
            </td>


        </tr>


        <?php } ?>


    </table>


    <script>
    window.print();
    </script>


</body>

</html>