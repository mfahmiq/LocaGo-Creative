<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

if (!isset($_GET['id'])) {
    header("Location:index.php");
    exit;
}

$id = (int)$_GET['id'];

$sql = mysqli_prepare($conn,"
SELECT
ats.id,
ats.tanggal,

c.tingkat,
c.nama_kelas,

sub.nama_mapel,

t.nama AS guru,

s.hari,
s.jam_mulai,
s.jam_selesai

FROM attendance_sessions ats

JOIN schedules s
ON ats.schedule_id=s.id

JOIN classes c
ON s.class_id=c.id

JOIN teachers t
ON s.teacher_id=t.id

JOIN subjects sub
ON s.subject_id=sub.id

WHERE ats.id=?
");

mysqli_stmt_bind_param($sql,"i",$id);
mysqli_stmt_execute($sql);

$session=mysqli_fetch_assoc(
mysqli_stmt_get_result($sql)
);

if(!$session){
    die("Data tidak ditemukan.");
}

$detail=mysqli_prepare($conn,"
SELECT

st.nis,
st.nama,

ad.status,
ad.keterangan

FROM attendance_details ad

JOIN students st
ON ad.student_id=st.id

WHERE ad.session_id=?

ORDER BY st.nama
");

mysqli_stmt_bind_param($detail,"i",$id);
mysqli_stmt_execute($detail);

$data=mysqli_stmt_get_result($detail);

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header">

            <h4>Detail Laporan Absensi</h4>

        </div>

        <div class="card-body">

            <div class="row mb-4">

                <div class="col-md-3">

                    <b>Tanggal</b><br>

                    <?= date('d-m-Y',strtotime($session['tanggal'])) ?>

                </div>

                <div class="col-md-3">

                    <b>Kelas</b><br>

                    <?= htmlspecialchars($session['tingkat']) ?>

                    <?= htmlspecialchars($session['nama_kelas']) ?>

                </div>

                <div class="col-md-3">

                    <b>Mata Pelajaran</b><br>

                    <?= htmlspecialchars($session['nama_mapel']) ?>

                </div>

                <div class="col-md-3">

                    <b>Guru</b><br>

                    <?= htmlspecialchars($session['guru']) ?>

                </div>

            </div>

            <div class="table-responsive">

                <table class="table table-bordered table-striped table-hover">

                    <thead class="table-primary text-center">

                        <tr>

                            <th>No</th>

                            <th>NIS</th>

                            <th>Nama</th>

                            <th>Status</th>

                            <th>Keterangan</th>

                        </tr>

                    </thead>

                    <tbody>
                        <?php

$no = 1;

while($row = mysqli_fetch_assoc($data)){

switch($row['status']){

    case "Hadir":
        $badge = "success";
        break;

    case "Sakit":
        $badge = "primary";
        break;

    case "Izin":
        $badge = "warning";
        break;

    default:
        $badge = "danger";
        break;

}

?>

                        <tr>

                            <td class="text-center">

                                <?= $no++ ?>

                            </td>

                            <td>

                                <?= htmlspecialchars($row['nis']) ?>

                            </td>

                            <td>

                                <?= htmlspecialchars($row['nama']) ?>

                            </td>

                            <td class="text-center">

                                <span class="badge bg-<?= $badge ?>">

                                    <?= htmlspecialchars($row['status']) ?>

                                </span>

                            </td>

                            <td>

                                <?= empty($row['keterangan'])
            ? "-"
            : htmlspecialchars($row['keterangan']) ?>

                            </td>

                        </tr>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

            <hr>

            <div class="row">

                <div class="col-md-6">

                    <strong>Hari :</strong>

                    <?= htmlspecialchars($session['hari']) ?>

                </div>

                <div class="col-md-6 text-end">

                    <strong>Jam :</strong>

                    <?= substr($session['jam_mulai'],0,5) ?>

                    -

                    <?= substr($session['jam_selesai'],0,5) ?>

                </div>

            </div>

            <hr>

            <div class="d-flex justify-content-between">

                <a href="index.php" class="btn btn-secondary">

                    <i class="bi bi-arrow-left"></i>

                    Kembali

                </a>

                <div>

                    <a href="export_excel.php?id=<?= $id ?>" class="btn btn-success">

                        <i class="bi bi-file-earmark-excel"></i>

                        Export Excel

                    </a>

                    <a href="export_pdf.php?id=<?= $id ?>" class="btn btn-danger">
                        Export PDF
                    </a>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>