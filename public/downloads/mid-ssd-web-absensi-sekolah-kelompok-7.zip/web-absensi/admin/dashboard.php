<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../auth/login.php");
    exit;
}

require_once "../config/config.php";
require_once "../config/koneksi.php";

include "../templates/header.php";
include "../templates/sidebar.php";
include "../templates/navbar.php";

/* =========================
   STATISTIK
========================= */

$totalUser     = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM users"));
$totalSiswa    = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM students"));
$totalGuru     = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM teachers"));
$totalKelas    = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM classes"));
$totalMapel    = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM subjects"));
$totalJadwal   = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM schedules"));

?>

<div class="container-fluid">

    <h3 class="mb-4 fw-bold">
        Dashboard Administrator
    </h3>

    <div class="row g-4">

        <div class="col-lg-2 col-md-4 col-6">
            <div class="card shadow border-0 bg-primary text-white">
                <div class="card-body text-center">
                    <i class="bi bi-people-fill fs-1"></i>
                    <h6 class="mt-2">Total User</h6>
                    <h2><?= $totalUser ?></h2>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-4 col-6">
            <div class="card shadow border-0 bg-success text-white">
                <div class="card-body text-center">
                    <i class="bi bi-mortarboard-fill fs-1"></i>
                    <h6 class="mt-2">Siswa</h6>
                    <h2><?= $totalSiswa ?></h2>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-4 col-6">
            <div class="card shadow border-0 bg-warning">
                <div class="card-body text-center">
                    <i class="bi bi-person-badge-fill fs-1"></i>
                    <h6 class="mt-2">Guru</h6>
                    <h2><?= $totalGuru ?></h2>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-4 col-6">
            <div class="card shadow border-0 bg-danger text-white">
                <div class="card-body text-center">
                    <i class="bi bi-building fs-1"></i>
                    <h6 class="mt-2">Kelas</h6>
                    <h2><?= $totalKelas ?></h2>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-4 col-6">
            <div class="card shadow border-0 bg-info text-white">
                <div class="card-body text-center">
                    <i class="bi bi-book-half fs-1"></i>
                    <h6 class="mt-2">Mapel</h6>
                    <h2><?= $totalMapel ?></h2>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-4 col-6">
            <div class="card shadow border-0 bg-secondary text-white">
                <div class="card-body text-center">
                    <i class="bi bi-calendar-week-fill fs-1"></i>
                    <h6 class="mt-2">Jadwal</h6>
                    <h2><?= $totalJadwal ?></h2>
                </div>
            </div>
        </div>

    </div>

    <div class="row mt-4">

        <div class="col-lg-8">

            <div class="card shadow border-0">

                <div class="card-header bg-white">

                    <h5 class="mb-0">
                        👋 Selamat Datang Administrator
                    </h5>

                </div>

                <div class="card-body">

                    <h4 class="fw-bold">
                        Sistem Informasi Absensi Sekolah
                    </h4>

                    <p class="text-muted">
                        Halo,
                        <strong><?= htmlspecialchars($_SESSION['nama']) ?></strong>.
                    </p>

                    <p>
                        Gunakan menu di sebelah kiri untuk mengelola data
                        pengguna, siswa, guru, kelas, mata pelajaran,
                        jadwal pelajaran, serta laporan absensi.
                    </p>

                    <hr>

                    <div class="row">

                        <div class="col-md-4">
                            <h6>Tanggal</h6>
                            <strong><?= date('d F Y'); ?></strong>
                        </div>

                        <div class="col-md-4">
                            <h6>Hari</h6>
                            <strong><?= date('l'); ?></strong>
                        </div>

                        <div class="col-md-4">
                            <h6>Status</h6>
                            <span class="badge bg-success">
                                Administrator Aktif
                            </span>
                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-4">

            <div class="card shadow border-0">

                <div class="card-header bg-white">

                    <h5 class="mb-0">
                        Ringkasan Sistem
                    </h5>

                </div>

                <div class="card-body">

                    <table class="table table-borderless">

                        <tr>
                            <td>Total User</td>
                            <td class="text-end"><?= $totalUser ?></td>
                        </tr>

                        <tr>
                            <td>Total Guru</td>
                            <td class="text-end"><?= $totalGuru ?></td>
                        </tr>

                        <tr>
                            <td>Total Siswa</td>
                            <td class="text-end"><?= $totalSiswa ?></td>
                        </tr>

                        <tr>
                            <td>Total Kelas</td>
                            <td class="text-end"><?= $totalKelas ?></td>
                        </tr>

                        <tr>
                            <td>Total Mapel</td>
                            <td class="text-end"><?= $totalMapel ?></td>
                        </tr>

                        <tr>
                            <td>Total Jadwal</td>
                            <td class="text-end"><?= $totalJadwal ?></td>
                        </tr>

                    </table>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include "../templates/footer.php"; ?>