<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

if (!isset($_GET['id'])) {
    header("Location:index.php");
    exit;
}

$id = (int)$_GET['id'];

// Cek session absensi
$cek = mysqli_prepare(
    $conn,
    "SELECT id
     FROM attendance_sessions
     WHERE id=?"
);

mysqli_stmt_bind_param($cek, "i", $id);
mysqli_stmt_execute($cek);

$result = mysqli_stmt_get_result($cek);

if(mysqli_num_rows($result)==0){

    echo "<script>
    alert('Data tidak ditemukan.');
    window.location='index.php';
    </script>";

    exit;
}

// Hapus session
// attendance_details akan ikut terhapus
// karena ON DELETE CASCADE

$hapus = mysqli_prepare(
    $conn,
    "DELETE
     FROM attendance_sessions
     WHERE id=?"
);

mysqli_stmt_bind_param(
    $hapus,
    "i",
    $id
);

if(mysqli_stmt_execute($hapus)){

    header("Location:index.php?success=hapus");
    exit;

}else{

    echo "<script>
    alert('Gagal menghapus data.');
    window.location='index.php';
    </script>";

}