<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

if (empty($_GET['session'])) {
    header("Location:index.php");
    exit;
}

$session_id = (int)$_GET['session'];

$sql = mysqli_prepare($conn,"
SELECT
ats.id,
ats.tanggal,

c.tingkat,
c.nama_kelas,

sub.nama_mapel,

t.nama AS guru

FROM attendance_sessions ats

JOIN schedules s
ON ats.schedule_id=s.id

JOIN classes c
ON s.class_id=c.id

JOIN teachers t
ON s.teacher_id=t.id

JOIN subjects sub
ON s.subject_id=sub.id

WHERE ats.id=?
");

mysqli_stmt_bind_param($sql,"i",$session_id);
mysqli_stmt_execute($sql);

$session=mysqli_fetch_assoc(
mysqli_stmt_get_result($sql)
);

if(!$session){
    die("Session tidak ditemukan.");
}

if(isset($_POST['update'])){

    foreach($_POST['detail_id'] as $i=>$detail_id){

        $status=$_POST['status'][$i];
        $ket=trim($_POST['keterangan'][$i]);

        $update=mysqli_prepare($conn,"
        UPDATE attendance_details
        SET
        status=?,
        keterangan=?
        WHERE id=?
        ");

        mysqli_stmt_bind_param(
            $update,
            "ssi",
            $status,
            $ket,
            $detail_id
        );

        mysqli_stmt_execute($update);
    }

    header("Location:detail.php?id=".$session_id);
    exit;
}

$data=mysqli_query($conn,"
SELECT

ad.id,

st.nis,
st.nama,

ad.status,
ad.keterangan

FROM attendance_details ad

JOIN students st
ON ad.student_id=st.id

WHERE ad.session_id=".$session_id."

ORDER BY st.nama
");

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header">

            <h4>Edit Absensi</h4>

        </div>

        <div class="card-body">

            <form method="POST">

                <div class="row mb-4">

                    <div class="col-md-3">

                        <b>Tanggal</b><br>

                        <?= date('d-m-Y',strtotime($session['tanggal'])) ?>

                    </div>

                    <div class="col-md-3">

                        <b>Kelas</b><br>

                        <?= htmlspecialchars($session['tingkat']) ?>

                        <?= htmlspecialchars($session['nama_kelas']) ?>

                    </div>

                    <div class="col-md-3">

                        <b>Mapel</b><br>

                        <?= htmlspecialchars($session['nama_mapel']) ?>

                    </div>

                    <div class="col-md-3">

                        <b>Guru</b><br>

                        <?= htmlspecialchars($session['guru']) ?>

                    </div>

                </div>

                <div class="table-responsive">

                    <table class="table table-bordered table-striped">

                        <thead class="table-primary text-center">

                            <tr>

                                <th>No</th>

                                <th>NIS</th>

                                <th>Nama</th>

                                <th>Status</th>

                                <th>Keterangan</th>

                            </tr>

                        </thead>

                        <tbody>
                            <?php

$no = 1;
$i = 0;

while($row = mysqli_fetch_assoc($data)){

?>

                            <tr>

                                <td class="text-center">

                                    <?= $no++ ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars($row['nis']) ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars($row['nama']) ?>

                                </td>

                                <td>

                                    <input type="hidden" name="detail_id[]" value="<?= $row['id'] ?>">

                                    <div class="d-flex flex-wrap justify-content-center gap-3">

                                        <div class="form-check">

                                            <input class="form-check-input" type="radio" name="status[<?= $i ?>]"
                                                value="Hadir" <?= $row['status']=="Hadir" ? "checked" : "" ?> required>

                                            <label class="form-check-label">

                                                Hadir

                                            </label>

                                        </div>

                                        <div class="form-check">

                                            <input class="form-check-input" type="radio" name="status[<?= $i ?>]"
                                                value="Sakit" <?= $row['status']=="Sakit" ? "checked" : "" ?>>

                                            <label class="form-check-label">

                                                Sakit

                                            </label>

                                        </div>

                                        <div class="form-check">

                                            <input class="form-check-input" type="radio" name="status[<?= $i ?>]"
                                                value="Izin" <?= $row['status']=="Izin" ? "checked" : "" ?>>

                                            <label class="form-check-label">

                                                Izin

                                            </label>

                                        </div>

                                        <div class="form-check">

                                            <input class="form-check-input" type="radio" name="status[<?= $i ?>]"
                                                value="Alfa" <?= $row['status']=="Alfa" ? "checked" : "" ?>>

                                            <label class="form-check-label">

                                                Alfa

                                            </label>

                                        </div>

                                    </div>

                                </td>

                                <td>

                                    <input type="text" name="keterangan[<?= $i ?>]" class="form-control"
                                        value="<?= htmlspecialchars($row['keterangan']) ?>">

                                </td>

                            </tr>

                            <?php

$i++;

}

?>

                        </tbody>

                    </table>

                </div>

                <hr>

                <div class="d-flex justify-content-between">

                    <a href="detail.php?id=<?= $session_id ?>" class="btn btn-secondary">

                        <i class="bi bi-arrow-left"></i>

                        Kembali

                    </a>

                    <button type="submit" name="update" class="btn btn-success">

                        <i class="bi bi-save"></i>

                        Update Semua Absensi

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>