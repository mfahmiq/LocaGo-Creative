<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

/* ==========================
   AMBIL DATA JADWAL
========================== */

$jadwal = mysqli_query($conn,"
SELECT
    s.id,
    s.hari,
    s.jam_mulai,
    s.jam_selesai,
    c.tingkat,
    c.nama_kelas,
    sub.nama_mapel,
    t.nama AS guru
FROM schedules s
JOIN classes c
ON s.class_id=c.id
JOIN subjects sub
ON s.subject_id=sub.id
JOIN teachers t
ON s.teacher_id=t.id
ORDER BY
FIELD(
s.hari,
'Senin',
'Selasa',
'Rabu',
'Kamis',
'Jumat',
'Sabtu'
),
s.jam_mulai
");

$totalJadwal = mysqli_num_rows($jadwal);

/* ==========================
   PROSES
========================== */

if(isset($_POST['lanjut'])){

    $tanggal = $_POST['tanggal'];
    $schedule = (int)$_POST['schedule_id'];
    $user = $_SESSION['id'];

    $cek = mysqli_prepare(
        $conn,
        "SELECT id
        FROM attendance_sessions
        WHERE schedule_id=?
        AND tanggal=?"
    );

    mysqli_stmt_bind_param(
        $cek,
        "is",
        $schedule,
        $tanggal
    );

    mysqli_stmt_execute($cek);

    $hasil = mysqli_stmt_get_result($cek);

    if(mysqli_num_rows($hasil)>0){

        $session = mysqli_fetch_assoc($hasil);

        header("Location:input.php?id=".$session['id']);
        exit;

    }

    $insert = mysqli_prepare(
        $conn,
        "INSERT INTO attendance_sessions
        (
            schedule_id,
            tanggal,
            created_by
        )
        VALUES(?,?,?)"
    );

    mysqli_stmt_bind_param(
        $insert,
        "isi",
        $schedule,
        $tanggal,
        $user
    );

    mysqli_stmt_execute($insert);

    $session_id = mysqli_insert_id($conn);

    header("Location:input.php?id=".$session_id);
    exit;
}

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                <i class="bi bi-calendar-check text-primary"></i>

                Input Absensi

            </h2>

            <p class="text-muted">

                Pilih tanggal dan jadwal untuk memulai absensi siswa.

            </p>

        </div>

        <a href="index.php" class="btn btn-secondary">

            <i class="bi bi-arrow-left"></i>

            Kembali

        </a>

    </div>

    <div class="row mb-4">

        <div class="col-md-4">

            <div class="card shadow border-0 bg-primary text-white">

                <div class="card-body">

                    <small>Total Jadwal</small>

                    <h2 class="fw-bold">

                        <?= $totalJadwal ?>

                    </h2>

                </div>

            </div>

        </div>

        <div class="col-md-4">

            <div class="card shadow border-0 bg-success text-white">

                <div class="card-body">

                    <small>Tanggal Hari Ini</small>

                    <h5 class="fw-bold">

                        <?= date('d-m-Y') ?>

                    </h5>

                </div>

            </div>

        </div>

        <div class="col-md-4">

            <div class="card shadow border-0 bg-warning">

                <div class="card-body">

                    <small>Status</small>

                    <h5 class="fw-bold">

                        Siap Input

                    </h5>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow border-0">

        <div class="card-header bg-white">

            <h5 class="mb-0">

                Form Input Absensi

            </h5>

        </div>

        <div class="card-body">

            <form method="POST">

                <div class="row">

                    <div class="col-md-4 mb-3">

                        <label class="form-label">

                            Tanggal

                        </label>

                        <input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>" required>

                    </div>

                    <div class="col-md-8 mb-3">

                        <label class="form-label">

                            Pilih Jadwal Mengajar

                        </label>

                        <select name="schedule_id" class="form-select" required>

                            <option value="">

                                -- Pilih Jadwal --

                            </option>
                            <?php while($j = mysqli_fetch_assoc($jadwal)){ ?>

                            <option value="<?= $j['id'] ?>">

                                <?= $j['hari'] ?>

                                |

                                <?= substr($j['jam_mulai'],0,5) ?>

                                -

                                <?= substr($j['jam_selesai'],0,5) ?>

                                |

                                <?= $j['tingkat'] ?>

                                <?= $j['nama_kelas'] ?>

                                |

                                <?= $j['nama_mapel'] ?>

                                |

                                <?= $j['guru'] ?>

                            </option>

                            <?php } ?>

                        </select>

                    </div>

                </div>

                <hr>

                <div class="d-flex justify-content-between align-items-center">

                    <div>

                        <span class="badge bg-primary fs-6">

                            Total Jadwal :

                            <?= $totalJadwal ?>

                        </span>

                    </div>

                    <div>

                        <button type="submit" name="lanjut" class="btn btn-primary">

                            <i class="bi bi-arrow-right-circle"></i>

                            Lanjut Input

                        </button>

                        <a href="index.php" class="btn btn-secondary">

                            <i class="bi bi-arrow-left"></i>

                            Kembali

                        </a>

                    </div>

                </div>

            </form>

        </div>

        <div class="card-footer bg-white">

            <small class="text-muted">

                Pilih tanggal dan jadwal mengajar, kemudian klik <strong>Lanjut Input</strong> untuk membuka halaman
                absensi siswa.

            </small>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>