<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

if (empty($_GET['id'])) {
    header("Location:index.php");
    exit;
}

$session_id = (int) $_GET['id'];

$sql = mysqli_prepare($conn,"
SELECT

ats.id,
ats.tanggal,

c.tingkat,
c.nama_kelas,

sub.nama_mapel,

t.nama AS guru,

s.hari,
s.jam_mulai,
s.jam_selesai

FROM attendance_sessions ats

JOIN schedules s
ON ats.schedule_id=s.id

JOIN classes c
ON s.class_id=c.id

JOIN teachers t
ON s.teacher_id=t.id

JOIN subjects sub
ON s.subject_id=sub.id

WHERE ats.id=?
");

mysqli_stmt_bind_param($sql,"i",$session_id);
mysqli_stmt_execute($sql);

$session = mysqli_fetch_assoc(
    mysqli_stmt_get_result($sql)
);

if(!$session){
    die("Data tidak ditemukan.");
}

$detail = mysqli_prepare($conn,"
SELECT

st.nis,
st.nama,

ad.status,
ad.keterangan

FROM attendance_details ad

JOIN students st
ON ad.student_id=st.id

WHERE ad.session_id=?

ORDER BY st.nama ASC
");

mysqli_stmt_bind_param($detail,"i",$session_id);
mysqli_stmt_execute($detail);

$data = mysqli_stmt_get_result($detail);

$totalSiswa = mysqli_num_rows($data);

mysqli_data_seek($data,0);

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                <i class="bi bi-clipboard-check text-primary"></i>

                Detail Absensi

            </h2>

            <p class="text-muted mb-0">

                Informasi absensi siswa berdasarkan jadwal.

            </p>

        </div>

        <div>

            <a href="edit.php?session=<?= $session_id ?>" class="btn btn-warning">

                <i class="bi bi-pencil-square"></i>

                Edit Absensi

            </a>

            <a href="index.php" class="btn btn-secondary">

                <i class="bi bi-arrow-left"></i>

                Kembali

            </a>

        </div>

    </div>

    <div class="row mb-4">

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-primary text-white">

                <div class="card-body">

                    <small>Tanggal</small>

                    <h5 class="fw-bold">

                        <?= date('d-m-Y',strtotime($session['tanggal'])) ?>

                    </h5>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-success text-white">

                <div class="card-body">

                    <small>Kelas</small>

                    <h5 class="fw-bold">

                        <?= htmlspecialchars($session['tingkat']) ?>

                        <?= htmlspecialchars($session['nama_kelas']) ?>

                    </h5>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-warning">

                <div class="card-body">

                    <small>Mata Pelajaran</small>

                    <h6 class="fw-bold">

                        <?= htmlspecialchars($session['nama_mapel']) ?>

                    </h6>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-danger text-white">

                <div class="card-body">

                    <small>Guru</small>

                    <h6 class="fw-bold">

                        <?= htmlspecialchars($session['guru']) ?>

                    </h6>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow border-0">

        <div class="card-header bg-white">

            <div class="d-flex justify-content-between align-items-center">

                <h5 class="mb-0">

                    Daftar Kehadiran Siswa

                </h5>

                <span class="badge bg-primary">

                    Total <?= $totalSiswa ?> Siswa

                </span>

            </div>

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-hover align-middle">

                    <thead class="table-primary">

                        <tr>

                            <th class="text-center">No</th>
                            <th>NIS</th>
                            <th>Nama</th>
                            <th class="text-center">Status</th>
                            <th>Keterangan</th>

                        </tr>

                    </thead>

                    <tbody><?php

$no = 1;

while($row = mysqli_fetch_assoc($data)){

    switch($row['status']){

        case "Hadir":
            $badge = "success";
            $icon  = "bi-check-circle-fill";
            break;

        case "Sakit":
            $badge = "primary";
            $icon  = "bi-heart-pulse-fill";
            break;

        case "Izin":
            $badge = "warning";
            $icon  = "bi-envelope-check-fill";
            break;

        default:
            $badge = "danger";
            $icon  = "bi-x-circle-fill";
            break;

    }

?>

                        <tr>

                            <td class="text-center">

                                <?= $no++ ?>

                            </td>

                            <td>

                                <?= htmlspecialchars($row['nis']) ?>

                            </td>

                            <td>

                                <i class="bi bi-person-circle text-primary"></i>

                                <?= htmlspecialchars($row['nama']) ?>

                            </td>

                            <td class="text-center">

                                <span class="badge bg-<?= $badge ?> px-3 py-2">

                                    <i class="bi <?= $icon ?>"></i>

                                    <?= htmlspecialchars($row['status']) ?>

                                </span>

                            </td>

                            <td>

                                <?= empty($row['keterangan']) ? '-' : htmlspecialchars($row['keterangan']) ?>

                            </td>

                        </tr>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

        <div class="card-footer bg-white">

            <div class="row">

                <div class="col-md-6">

                    <small class="text-muted">

                        Detail absensi siswa pada sesi pembelajaran ini.

                    </small>

                </div>

                <div class="col-md-6 text-end">

                    <small class="text-muted">

                        Jumlah Siswa :

                        <strong><?= $totalSiswa ?></strong>

                    </small>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>