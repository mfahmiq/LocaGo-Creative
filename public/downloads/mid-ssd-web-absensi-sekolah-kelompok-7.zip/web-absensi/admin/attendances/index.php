<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

/* ==========================
   DATA ABSENSI
========================== */

$query = mysqli_query($conn,"
SELECT
    ats.id,
    ats.tanggal,
    ats.created_at,
    s.hari,
    s.jam_mulai,
    s.jam_selesai,
    c.tingkat,
    c.nama_kelas,
    sub.nama_mapel,
    t.nama AS guru
FROM attendance_sessions ats
JOIN schedules s
ON ats.schedule_id=s.id
JOIN classes c
ON s.class_id=c.id
JOIN teachers t
ON s.teacher_id=t.id
JOIN subjects sub
ON s.subject_id=sub.id
ORDER BY
ats.tanggal DESC,
c.tingkat,
c.nama_kelas,
s.jam_mulai
");

/* ==========================
   STATISTIK
========================== */

$totalAbsensi = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT COUNT(*) total FROM attendance_sessions")
)['total'];

$hariIni = date('Y-m-d');

$totalHariIni = mysqli_fetch_assoc(
    mysqli_query($conn,"
    SELECT COUNT(*) total
    FROM attendance_sessions
    WHERE tanggal='$hariIni'
")
)['total'];

$totalGuru = mysqli_fetch_assoc(
    mysqli_query($conn,"
    SELECT COUNT(DISTINCT schedule_id) total
    FROM attendance_sessions
")
)['total'];

$totalKelas = mysqli_fetch_assoc(
    mysqli_query($conn,"
    SELECT COUNT(DISTINCT schedules.class_id) total
    FROM attendance_sessions
    JOIN schedules
    ON attendance_sessions.schedule_id=schedules.id
")
)['total'];

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <?php if(isset($_GET['success'])){ ?>

    <div class="alert alert-success alert-dismissible fade show">

        <?php

switch($_GET['success']){

case "tambah":
echo "Absensi berhasil ditambahkan.";
break;

case "edit":
echo "Absensi berhasil diperbarui.";
break;

case "hapus":
echo "Absensi berhasil dihapus.";
break;

default:
echo "Data berhasil diproses.";

}

?>

        <button class="btn-close" data-bs-dismiss="alert"></button>

    </div>

    <?php } ?>

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                <i class="bi bi-clipboard-check text-primary"></i>

                Data Absensi

            </h2>

            <p class="text-muted mb-0">

                Kelola seluruh data absensi siswa.

            </p>

        </div>

        <a href="tambah.php" class="btn btn-primary shadow">

            <i class="bi bi-plus-circle"></i>

            Input Absensi

        </a>

    </div>

    <div class="row mb-4">

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-primary text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small>Total Absensi</small>

                            <h2 class="fw-bold"><?= $totalAbsensi ?></h2>

                        </div>

                        <i class="bi bi-clipboard-check fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-success text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small>Hari Ini</small>

                            <h2 class="fw-bold"><?= $totalHariIni ?></h2>

                        </div>

                        <i class="bi bi-calendar-check fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-warning">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small>Guru Mengajar</small>

                            <h2 class="fw-bold"><?= $totalGuru ?></h2>

                        </div>

                        <i class="bi bi-person-workspace fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-danger text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <small>Kelas</small>

                            <h2 class="fw-bold"><?= $totalKelas ?></h2>

                        </div>

                        <i class="bi bi-building fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow border-0">

        <div class="card-header bg-white">

            <div class="d-flex justify-content-between align-items-center">

                <h5 class="mb-0">

                    Daftar Absensi

                </h5>

                <span class="badge bg-primary">

                    Total <?= $totalAbsensi ?> Data

                </span>

            </div>

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-hover align-middle datatable">

                    <thead class="table-primary">

                        <tr>

                            <th class="text-center">No</th>
                            <th class="text-center">Tanggal</th>
                            <th class="text-center">Hari</th>
                            <th class="text-center">Jam</th>
                            <th>Kelas</th>
                            <th>Mata Pelajaran</th>
                            <th>Guru</th>
                            <th class="text-center">Aksi</th>

                        </tr>

                    </thead>

                    <tbody>
                        <?php

$no = 1;

while($row = mysqli_fetch_assoc($query)){

    switch($row['hari']){

        case "Senin":
            $badgeHari = "bg-primary";
            break;

        case "Selasa":
            $badgeHari = "bg-success";
            break;

        case "Rabu":
            $badgeHari = "bg-warning text-dark";
            break;

        case "Kamis":
            $badgeHari = "bg-info text-dark";
            break;

        case "Jumat":
            $badgeHari = "bg-danger";
            break;

        case "Sabtu":
            $badgeHari = "bg-secondary";
            break;

        default:
            $badgeHari = "bg-dark";

    }

?>

                        <tr>

                            <td class="text-center">

                                <?= $no++ ?>

                            </td>

                            <td class="text-center">

                                <span class="badge bg-dark">

                                    <?= date('d-m-Y', strtotime($row['tanggal'])) ?>

                                </span>

                            </td>

                            <td class="text-center">

                                <span class="badge <?= $badgeHari ?>">

                                    <?= htmlspecialchars($row['hari']) ?>

                                </span>

                            </td>

                            <td class="text-center">

                                <i class="bi bi-clock-fill text-primary"></i>

                                <?= substr($row['jam_mulai'],0,5) ?>

                                -

                                <?= substr($row['jam_selesai'],0,5) ?>

                            </td>

                            <td>

                                <span class="badge bg-primary">

                                    <?= htmlspecialchars($row['tingkat']) ?>

                                </span>

                                <?= htmlspecialchars($row['nama_kelas']) ?>

                            </td>

                            <td>

                                <i class="bi bi-book-fill text-success"></i>

                                <?= htmlspecialchars($row['nama_mapel']) ?>

                            </td>

                            <td>

                                <i class="bi bi-person-badge-fill text-primary"></i>

                                <?= htmlspecialchars($row['guru']) ?>

                            </td>

                            <td class="text-center">

                                <a href="detail.php?id=<?= $row['id'] ?>" class="btn btn-info btn-sm" title="Detail">

                                    <i class="bi bi-eye"></i>

                                </a>

                                <a href="edit.php?session=<?= $row['id'] ?>" class="btn btn-warning btn-sm"
                                    title="Edit">

                                    <i class="bi bi-pencil-square"></i>

                                </a>

                                <a href="hapus.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" title="Hapus"
                                    onclick="return confirm('Yakin ingin menghapus absensi ini?')">

                                    <i class="bi bi-trash"></i>

                                </a>

                            </td>

                        </tr>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

        <div class="card-footer bg-white">

            <div class="row">

                <div class="col-md-6">

                    <small class="text-muted">

                        Menampilkan seluruh data absensi yang telah diinput.

                    </small>

                </div>

                <div class="col-md-6 text-end">

                    <small class="text-muted">

                        Total Data Absensi :

                        <strong><?= $totalAbsensi ?></strong>

                    </small>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>