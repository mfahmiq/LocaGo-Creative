<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

if (!isset($_GET['id'])) {
    header("Location:index.php");
    exit;
}

$session_id = (int) $_GET['id'];

/* ==========================
   DATA SESSION
========================== */

$stmt = mysqli_prepare($conn,"
SELECT
ats.*,

c.id AS class_id,
c.tingkat,
c.nama_kelas,

sub.nama_mapel,

t.nama AS guru,

s.hari,
s.jam_mulai,
s.jam_selesai

FROM attendance_sessions ats

JOIN schedules s
ON ats.schedule_id=s.id

JOIN classes c
ON s.class_id=c.id

JOIN subjects sub
ON s.subject_id=sub.id

JOIN teachers t
ON s.teacher_id=t.id

WHERE ats.id=?
");

mysqli_stmt_bind_param($stmt,"i",$session_id);
mysqli_stmt_execute($stmt);

$session = mysqli_fetch_assoc(
    mysqli_stmt_get_result($stmt)
);

if(!$session){
    die("Session tidak ditemukan.");
}

/* ==========================
   SIMPAN
========================== */

if(isset($_POST['simpan'])){

    foreach($_POST['status'] as $student=>$status){

        $ket = "";

        if(isset($_POST['keterangan'][$student])){
            $ket = trim($_POST['keterangan'][$student]);
        }

        $cek = mysqli_prepare($conn,"
        SELECT id
        FROM attendance_details
        WHERE session_id=?
        AND student_id=?
        ");

        mysqli_stmt_bind_param(
            $cek,
            "ii",
            $session_id,
            $student
        );

        mysqli_stmt_execute($cek);

        if(mysqli_num_rows(mysqli_stmt_get_result($cek))>0){

            $update = mysqli_prepare($conn,"
            UPDATE attendance_details
            SET
            status=?,
            keterangan=?
            WHERE
            session_id=?
            AND student_id=?
            ");

            mysqli_stmt_bind_param(
                $update,
                "ssii",
                $status,
                $ket,
                $session_id,
                $student
            );

            mysqli_stmt_execute($update);

        }else{

            $insert = mysqli_prepare($conn,"
            INSERT INTO attendance_details
            (
                session_id,
                student_id,
                status,
                keterangan
            )
            VALUES(?,?,?,?)
            ");

            mysqli_stmt_bind_param(
                $insert,
                "iiss",
                $session_id,
                $student,
                $status,
                $ket
            );

            mysqli_stmt_execute($insert);

        }

    }

    header("Location:index.php?success=edit");
    exit;
}

/* ==========================
   DATA SISWA + ABSENSI
========================== */

$siswa = mysqli_query($conn,"
SELECT
st.*,
ad.status,
ad.keterangan

FROM students st

LEFT JOIN attendance_details ad
ON st.id=ad.student_id
AND ad.session_id=".$session_id."

WHERE st.class_id=".$session['class_id']."

ORDER BY st.nama
");

$totalSiswa = mysqli_num_rows($siswa);

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                <i class="bi bi-pencil-square text-warning"></i>

                Edit Absensi

            </h2>

            <p class="text-muted">

                Perbarui data kehadiran siswa.

            </p>

        </div>

        <a href="detail.php?id=<?= $session_id ?>" class="btn btn-secondary">

            <i class="bi bi-arrow-left"></i>

            Kembali

        </a>

    </div>

    <div class="row mb-4">

        <div class="col-md-3">

            <div class="card shadow border-0 bg-primary text-white">

                <div class="card-body">

                    <small>Tanggal</small>

                    <h5>

                        <?= date('d-m-Y',strtotime($session['tanggal'])) ?>

                    </h5>

                </div>

            </div>

        </div>

        <div class="col-md-3">

            <div class="card shadow border-0 bg-success text-white">

                <div class="card-body">

                    <small>Kelas</small>

                    <h5>

                        <?= htmlspecialchars($session['tingkat']) ?>

                        <?= htmlspecialchars($session['nama_kelas']) ?>

                    </h5>

                </div>

            </div>

        </div>

        <div class="col-md-3">

            <div class="card shadow border-0 bg-warning">

                <div class="card-body">

                    <small>Mata Pelajaran</small>

                    <h6>

                        <?= htmlspecialchars($session['nama_mapel']) ?>

                    </h6>

                </div>

            </div>

        </div>

        <div class="col-md-3">

            <div class="card shadow border-0 bg-danger text-white">

                <div class="card-body">

                    <small>Guru</small>

                    <h6>

                        <?= htmlspecialchars($session['guru']) ?>

                    </h6>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow">

        <div class="card-header bg-white">

            <h5 class="mb-0">

                Daftar Siswa

            </h5>

        </div>

        <div class="card-body">

            <form method="POST">

                <div class="table-responsive">

                    <table class="table table-hover align-middle">

                        <thead class="table-primary">

                            <tr>

                                <th>No</th>

                                <th>NIS</th>

                                <th>Nama</th>

                                <th>Status</th>

                                <th>Keterangan</th>

                            </tr>

                        </thead>

                        <tbody><?php

$no = 1;

while($row = mysqli_fetch_assoc($siswa)){

?>

                            <tr>

                                <td class="text-center">

                                    <?= $no++ ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars($row['nis']) ?>

                                </td>

                                <td>

                                    <i class="bi bi-person-circle text-primary"></i>

                                    <?= htmlspecialchars($row['nama']) ?>

                                </td>

                                <td>

                                    <div class="d-flex justify-content-center flex-wrap gap-3">

                                        <div class="form-check">

                                            <input class="form-check-input" type="radio"
                                                name="status[<?= $row['id'] ?>]" value="Hadir"
                                                <?= ($row['status']=="Hadir" || empty($row['status'])) ? "checked" : "" ?>>

                                            <label class="form-check-label">

                                                <span class="badge bg-success">

                                                    Hadir

                                                </span>

                                            </label>

                                        </div>

                                        <div class="form-check">

                                            <input class="form-check-input" type="radio"
                                                name="status[<?= $row['id'] ?>]" value="Sakit"
                                                <?= ($row['status']=="Sakit") ? "checked" : "" ?>>

                                            <label class="form-check-label">

                                                <span class="badge bg-primary">

                                                    Sakit

                                                </span>

                                            </label>

                                        </div>

                                        <div class="form-check">

                                            <input class="form-check-input" type="radio"
                                                name="status[<?= $row['id'] ?>]" value="Izin"
                                                <?= ($row['status']=="Izin") ? "checked" : "" ?>>

                                            <label class="form-check-label">

                                                <span class="badge bg-warning text-dark">

                                                    Izin

                                                </span>

                                            </label>

                                        </div>

                                        <div class="form-check">

                                            <input class="form-check-input" type="radio"
                                                name="status[<?= $row['id'] ?>]" value="Alfa"
                                                <?= ($row['status']=="Alfa") ? "checked" : "" ?>>

                                            <label class="form-check-label">

                                                <span class="badge bg-danger">

                                                    Alfa

                                                </span>

                                            </label>

                                        </div>

                                    </div>

                                </td>

                                <td>

                                    <input type="text" name="keterangan[<?= $row['id'] ?>]" class="form-control"
                                        value="<?= htmlspecialchars($row['keterangan']) ?>" placeholder="Opsional">

                                </td>

                            </tr>

                            <?php } ?>

                        </tbody>

                    </table>

                </div>

                <hr>

                <div class="d-flex justify-content-between align-items-center">

                    <div>

                        <span class="badge bg-primary fs-6">

                            Total Siswa :
                            <?= $totalSiswa ?>

                        </span>

                    </div>

                    <div>

                        <button type="submit" name="simpan" class="btn btn-success">

                            <i class="bi bi-save"></i>

                            Simpan Perubahan

                        </button>

                        <a href="detail.php?id=<?= $session_id ?>" class="btn btn-secondary">

                            <i class="bi bi-arrow-left"></i>

                            Kembali

                        </a>

                    </div>

                </div>

            </form>

        </div>

        <div class="card-footer bg-white">

            <small class="text-muted">

                Silakan ubah status kehadiran siswa kemudian klik <b>Simpan Perubahan</b> untuk memperbarui data
                absensi.

            </small>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>