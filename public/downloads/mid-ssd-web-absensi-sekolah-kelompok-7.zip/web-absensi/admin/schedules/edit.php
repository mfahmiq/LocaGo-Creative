<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Ambil data jadwal
$stmt = mysqli_prepare($conn,"
SELECT *
FROM schedules
WHERE id=?
");

mysqli_stmt_bind_param($stmt,"i",$id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$jadwal = mysqli_fetch_assoc($result);

if(!$jadwal){
    die("Data jadwal tidak ditemukan.");
}

// Dropdown
$kelas = mysqli_query($conn,"
SELECT *
FROM classes
ORDER BY tingkat,nama_kelas
");

$guru = mysqli_query($conn,"
SELECT *
FROM teachers
ORDER BY nama
");

$mapel = mysqli_query($conn,"
SELECT *
FROM subjects
ORDER BY nama_mapel
");

if(isset($_POST['update'])){

    $class_id=$_POST['class_id'];
    $subject_id=$_POST['subject_id'];
    $teacher_id=$_POST['teacher_id'];
    $hari=$_POST['hari'];
    $jam_mulai=$_POST['jam_mulai'];
    $jam_selesai=$_POST['jam_selesai'];

    if($jam_mulai >= $jam_selesai){

        echo "<script>
        alert('Jam selesai harus lebih besar dari jam mulai.');
        history.back();
        </script>";

        exit;
    }

    // Cek bentrok selain dirinya sendiri
    $cek=mysqli_prepare($conn,"
    SELECT id
    FROM schedules
    WHERE class_id=?
    AND hari=?
    AND id<>?
    AND(
        (? < jam_selesai)
        AND
        (? > jam_mulai)
    )
    ");

    mysqli_stmt_bind_param(
        $cek,
        "isiss",
        $class_id,
        $hari,
        $id,
        $jam_mulai,
        $jam_selesai
    );

    mysqli_stmt_execute($cek);

    if(mysqli_num_rows(mysqli_stmt_get_result($cek))>0){

        echo "<script>
        alert('Jadwal bentrok.');
        history.back();
        </script>";

        exit;
    }

    $update=mysqli_prepare($conn,"
    UPDATE schedules
    SET
        class_id=?,
        subject_id=?,
        teacher_id=?,
        hari=?,
        jam_mulai=?,
        jam_selesai=?
    WHERE id=?
    ");

    mysqli_stmt_bind_param(
        $update,
        "iiisssi",
        $class_id,
        $subject_id,
        $teacher_id,
        $hari,
        $jam_mulai,
        $jam_selesai,
        $id
    );

    if(mysqli_stmt_execute($update)){

        header("Location:index.php?success=edit");
        exit;

    }else{

        die(mysqli_error($conn));

    }

}

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header">

            <h4>Edit Jadwal</h4>

        </div>

        <div class="card-body">

            <form method="POST">

                <div class="row">

                    <div class="col-md-6 mb-3">

                        <label>Kelas</label>

                        <select name="class_id" class="form-select" required>

                            <?php while($k=mysqli_fetch_assoc($kelas)){ ?>

                            <option value="<?= $k['id'] ?>" <?= $k['id']==$jadwal['class_id'] ? 'selected' : '' ?>>

                                <?= $k['tingkat'] ?>

                                <?= $k['nama_kelas'] ?>

                            </option>

                            <?php } ?>

                        </select>

                    </div>

                    <div class="col-md-6 mb-3">

                        <label>Mata Pelajaran</label>

                        <select name="subject_id" class="form-select" required>

                            <?php while($m=mysqli_fetch_assoc($mapel)){ ?>

                            <option value="<?= $m['id'] ?>" <?= $m['id']==$jadwal['subject_id'] ? 'selected' : '' ?>>

                                <?= $m['nama_mapel'] ?>

                            </option>

                            <?php } ?>

                        </select>

                    </div>
                    <div class="col-md-6 mb-3">

                        <label>Guru</label>

                        <select name="teacher_id" class="form-select" required>

                            <?php while($g=mysqli_fetch_assoc($guru)){ ?>

                            <option value="<?= $g['id'] ?>" <?= $g['id']==$jadwal['teacher_id'] ? 'selected' : '' ?>>

                                <?= htmlspecialchars($g['nama']) ?>

                            </option>

                            <?php } ?>

                        </select>

                    </div>

                    <div class="col-md-6 mb-3">

                        <label>Hari</label>

                        <select name="hari" class="form-select" required>

                            <option value="Senin" <?= $jadwal['hari']=="Senin"?"selected":"" ?>>Senin</option>
                            <option value="Selasa" <?= $jadwal['hari']=="Selasa"?"selected":"" ?>>Selasa</option>
                            <option value="Rabu" <?= $jadwal['hari']=="Rabu"?"selected":"" ?>>Rabu</option>
                            <option value="Kamis" <?= $jadwal['hari']=="Kamis"?"selected":"" ?>>Kamis</option>
                            <option value="Jumat" <?= $jadwal['hari']=="Jumat"?"selected":"" ?>>Jumat</option>
                            <option value="Sabtu" <?= $jadwal['hari']=="Sabtu"?"selected":"" ?>>Sabtu</option>

                        </select>

                    </div>

                    <div class="col-md-6 mb-3">

                        <label>Jam Mulai</label>

                        <input type="time" name="jam_mulai" class="form-control" value="<?= $jadwal['jam_mulai'] ?>"
                            required>

                    </div>

                    <div class="col-md-6 mb-3">

                        <label>Jam Selesai</label>

                        <input type="time" name="jam_selesai" class="form-control" value="<?= $jadwal['jam_selesai'] ?>"
                            required>

                    </div>

                </div>

                <button type="submit" name="update" class="btn btn-success">

                    <i class="bi bi-check-circle"></i>

                    Update

                </button>

                <a href="index.php" class="btn btn-secondary">

                    <i class="bi bi-arrow-left"></i>

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>