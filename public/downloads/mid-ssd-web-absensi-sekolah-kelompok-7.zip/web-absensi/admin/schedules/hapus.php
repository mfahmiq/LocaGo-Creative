<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$id = (int) $_GET['id'];

$stmt = mysqli_prepare($conn, "DELETE FROM schedules WHERE id = ?");

mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {

    header("Location: index.php?success=hapus");
    exit;

} else {

    echo "<script>
            alert('Gagal menghapus jadwal.');
            window.location='index.php';
          </script>";
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>