<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

/* ==========================
   DATA JADWAL
========================== */

$query = mysqli_query($conn,"
SELECT
    s.*,
    c.tingkat,
    c.nama_kelas,
    sub.nama_mapel,
    t.nama AS guru
FROM schedules s
JOIN classes c
ON s.class_id=c.id
JOIN subjects sub
ON s.subject_id=sub.id
JOIN teachers t
ON s.teacher_id=t.id
ORDER BY
FIELD(
    s.hari,
    'Senin',
    'Selasa',
    'Rabu',
    'Kamis',
    'Jumat',
    'Sabtu'
),
s.jam_mulai ASC
");

/* ==========================
   STATISTIK
========================== */

$totalJadwal = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT COUNT(*) total FROM schedules")
)['total'];

$totalSenin = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT COUNT(*) total FROM schedules WHERE hari='Senin'")
)['total'];

$totalSelasa = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT COUNT(*) total FROM schedules WHERE hari='Selasa'")
)['total'];

$totalRabu = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT COUNT(*) total FROM schedules WHERE hari='Rabu'")
)['total'];

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <?php if(isset($_GET['success'])){ ?>

    <div class="alert alert-success alert-dismissible fade show">

        <?php

switch($_GET['success']){

case "tambah":
echo "Jadwal berhasil ditambahkan.";
break;

case "edit":
echo "Jadwal berhasil diperbarui.";
break;

case "hapus":
echo "Jadwal berhasil dihapus.";
break;

default:
echo "Data berhasil diproses.";

}

?>

        <button class="btn-close" data-bs-dismiss="alert"></button>

    </div>

    <?php } ?>

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                <i class="bi bi-calendar-week text-primary"></i>

                Data Jadwal

            </h2>

            <p class="text-muted mb-0">

                Kelola jadwal mengajar guru pada sistem.

            </p>

        </div>

        <a href="tambah.php" class="btn btn-primary shadow">

            <i class="bi bi-plus-circle"></i>

            Tambah Jadwal

        </a>

    </div>

    <div class="row mb-4">

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-primary text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Total Jadwal</small>

                            <h2 class="fw-bold mb-0">

                                <?= $totalJadwal ?>

                            </h2>

                        </div>

                        <i class="bi bi-calendar-week fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-success text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Senin</small>

                            <h2 class="fw-bold mb-0">

                                <?= $totalSenin ?>

                            </h2>

                        </div>

                        <i class="bi bi-calendar-check fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-warning">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Selasa</small>

                            <h2 class="fw-bold mb-0">

                                <?= $totalSelasa ?>

                            </h2>

                        </div>

                        <i class="bi bi-calendar2-week fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-danger text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Rabu</small>

                            <h2 class="fw-bold mb-0">

                                <?= $totalRabu ?>

                            </h2>

                        </div>

                        <i class="bi bi-calendar3 fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow border-0">

        <div class="card-header bg-white">

            <div class="d-flex justify-content-between align-items-center">

                <h5 class="mb-0">

                    Daftar Jadwal

                </h5>

                <span class="badge bg-primary">

                    Total <?= $totalJadwal ?> Jadwal

                </span>

            </div>

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-hover align-middle datatable">

                    <thead class="table-primary">

                        <tr>

                            <th class="text-center">No</th>
                            <th class="text-center">Hari</th>
                            <th class="text-center">Jam</th>
                            <th>Kelas</th>
                            <th>Mata Pelajaran</th>
                            <th>Guru</th>
                            <th class="text-center">Aksi</th>

                        </tr>

                    </thead>

                    <tbody>
                        <?php

$no = 1;

while($row = mysqli_fetch_assoc($query)){

    switch($row['hari']){

        case "Senin":
            $badgeHari = "bg-primary";
            break;

        case "Selasa":
            $badgeHari = "bg-success";
            break;

        case "Rabu":
            $badgeHari = "bg-warning text-dark";
            break;

        case "Kamis":
            $badgeHari = "bg-info text-dark";
            break;

        case "Jumat":
            $badgeHari = "bg-danger";
            break;

        case "Sabtu":
            $badgeHari = "bg-secondary";
            break;

        default:
            $badgeHari = "bg-dark";

    }

?>

                        <tr>

                            <td class="text-center">

                                <?= $no++ ?>

                            </td>

                            <td class="text-center">

                                <span class="badge <?= $badgeHari ?> px-3 py-2">

                                    <?= htmlspecialchars($row['hari']) ?>

                                </span>

                            </td>

                            <td class="text-center">

                                <i class="bi bi-clock-fill text-primary"></i>

                                <?= substr($row['jam_mulai'],0,5) ?>

                                -

                                <?= substr($row['jam_selesai'],0,5) ?>

                            </td>

                            <td>

                                <span class="badge bg-primary">

                                    <?= htmlspecialchars($row['tingkat']) ?>

                                </span>

                                <?= htmlspecialchars($row['nama_kelas']) ?>

                            </td>

                            <td>

                                <i class="bi bi-book-fill text-success"></i>

                                <?= htmlspecialchars($row['nama_mapel']) ?>

                            </td>

                            <td>

                                <i class="bi bi-person-badge-fill text-primary"></i>

                                <?= htmlspecialchars($row['guru']) ?>

                            </td>

                            <td class="text-center">

                                <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm" title="Edit">

                                    <i class="bi bi-pencil-square"></i>

                                </a>

                                <a href="hapus.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" title="Hapus"
                                    onclick="return confirm('Hapus jadwal ini?')">

                                    <i class="bi bi-trash"></i>

                                </a>

                            </td>

                        </tr>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

        <div class="card-footer bg-white">

            <div class="row">

                <div class="col-md-6">

                    <small class="text-muted">

                        Menampilkan seluruh jadwal mengajar yang terdaftar.

                    </small>

                </div>

                <div class="col-md-6 text-end">

                    <small class="text-muted">

                        Total Jadwal :

                        <strong><?= $totalJadwal ?></strong>

                    </small>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>