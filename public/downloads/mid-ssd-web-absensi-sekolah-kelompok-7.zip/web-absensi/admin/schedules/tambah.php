<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

// Data dropdown
$kelas = mysqli_query($conn,"
SELECT *
FROM classes
ORDER BY tingkat,nama_kelas
");

$guru = mysqli_query($conn,"
SELECT *
FROM teachers
ORDER BY nama
");

$mapel = mysqli_query($conn,"
SELECT *
FROM subjects
ORDER BY nama_mapel
");

if(isset($_POST['simpan'])){

    $class_id=$_POST['class_id'];
    $subject_id=$_POST['subject_id'];
    $teacher_id=$_POST['teacher_id'];
    $hari=$_POST['hari'];
    $jam_mulai=$_POST['jam_mulai'];
    $jam_selesai=$_POST['jam_selesai'];

    // Validasi jam
    if($jam_mulai >= $jam_selesai){

        echo "<script>
        alert('Jam selesai harus lebih besar dari jam mulai.');
        history.back();
        </script>";

        exit;
    }

    // Cek bentrok jadwal
    $cek=mysqli_prepare($conn,"
    SELECT id
    FROM schedules
    WHERE class_id=?
    AND hari=?
    AND (
        (? BETWEEN jam_mulai AND jam_selesai)
        OR
        (? BETWEEN jam_mulai AND jam_selesai)
    )
    ");

    mysqli_stmt_bind_param(
        $cek,
        "isss",
        $class_id,
        $hari,
        $jam_mulai,
        $jam_selesai
    );

    mysqli_stmt_execute($cek);

    if(mysqli_num_rows(mysqli_stmt_get_result($cek))>0){

        echo "<script>
        alert('Jadwal kelas bentrok.');
        history.back();
        </script>";

        exit;
    }

    $stmt=mysqli_prepare($conn,"
    INSERT INTO schedules
    (
        class_id,
        subject_id,
        teacher_id,
        hari,
        jam_mulai,
        jam_selesai
    )
    VALUES(?,?,?,?,?,?)
    ");

    mysqli_stmt_bind_param(
        $stmt,
        "iiisss",
        $class_id,
        $subject_id,
        $teacher_id,
        $hari,
        $jam_mulai,
        $jam_selesai
    );

    if(mysqli_stmt_execute($stmt)){

        header("Location:index.php?success=tambah");
        exit;

    }else{

        die(mysqli_error($conn));

    }

}

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header">

            <h4>Tambah Jadwal</h4>

        </div>

        <div class="card-body">

            <form method="POST">

                <div class="row">

                    <div class="col-md-6 mb-3">

                        <label>Kelas</label>

                        <select name="class_id" class="form-select" required>

                            <option value="">Pilih Kelas</option>

                            <?php while($k=mysqli_fetch_assoc($kelas)){ ?>

                            <option value="<?= $k['id'] ?>">

                                <?= $k['tingkat'] ?>

                                <?= $k['nama_kelas'] ?>

                            </option>

                            <?php } ?>

                        </select>

                    </div>

                    <div class="col-md-6 mb-3">

                        <label>Mata Pelajaran</label>

                        <select name="subject_id" class="form-select" required>

                            <option value="">Pilih Mata Pelajaran</option>

                            <?php while($m=mysqli_fetch_assoc($mapel)){ ?>

                            <option value="<?= $m['id'] ?>">

                                <?= $m['nama_mapel'] ?>

                            </option>

                            <?php } ?>

                        </select>

                    </div>

                    <div class="col-md-6 mb-3">

                        <label>Guru</label>

                        <select name="teacher_id" class="form-select" required>

                            <option value="">Pilih Guru</option>

                            <?php while($g=mysqli_fetch_assoc($guru)){ ?>

                            <option value="<?= $g['id'] ?>">

                                <?= $g['nama'] ?>

                            </option>

                            <?php } ?>

                        </select>

                    </div>

                    <div class="col-md-6 mb-3">

                        <label>Hari</label>

                        <select name="hari" class="form-select" required>

                            <option>Senin</option>
                            <option>Selasa</option>
                            <option>Rabu</option>
                            <option>Kamis</option>
                            <option>Jumat</option>
                            <option>Sabtu</option>

                        </select>

                    </div>

                    <div class="col-md-6 mb-3">

                        <label>Jam Mulai</label>

                        <input type="time" name="jam_mulai" class="form-control" required>

                    </div>

                    <div class="col-md-6 mb-3">

                        <label>Jam Selesai</label>

                        <input type="time" name="jam_selesai" class="form-control" required>

                    </div>

                    <button type="submit" name="simpan" class="btn btn-primary">

                        <i class="bi bi-save"></i>

                        Simpan

                    </button>

                    <a href="index.php" class="btn btn-secondary">

                        <i class="bi bi-arrow-left"></i>

                        Kembali

                    </a>

            </form>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>