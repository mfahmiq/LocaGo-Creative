<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

/* ==========================
   DATA GURU
========================== */

$query = mysqli_query($conn, "SELECT * FROM teachers ORDER BY id DESC");

/* ==========================
   STATISTIK
========================== */

$totalGuru = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM teachers")
)['total'];

$totalLaki = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM teachers
         WHERE jenis_kelamin='Laki-laki'"
    )
)['total'];

$totalPerempuan = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM teachers
         WHERE jenis_kelamin='Perempuan'"
    )
)['total'];

$totalUserGuru = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM users u
         INNER JOIN roles r
         ON u.role_id=r.id
         WHERE r.nama_role='Guru'"
    )
)['total'];

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <?php if(isset($_GET['success'])){ ?>

    <div class="alert alert-success alert-dismissible fade show">

        <?php

switch($_GET['success']){

    case "tambah":
        echo "Data guru berhasil ditambahkan.";
    break;

    case "edit":
        echo "Data guru berhasil diperbarui.";
    break;

    case "hapus":
        echo "Data guru berhasil dihapus.";
    break;

}

?>

        <button class="btn-close" data-bs-dismiss="alert"></button>

    </div>

    <?php } ?>

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                <i class="bi bi-person-video3 text-primary"></i>

                Data Guru

            </h2>

            <p class="text-muted mb-0">

                Kelola seluruh data guru yang terdaftar pada sistem.

            </p>

        </div>

        <a href="tambah.php" class="btn btn-primary shadow">

            <i class="bi bi-plus-circle"></i>

            Tambah Guru

        </a>

    </div>

    <div class="row mb-4">

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-primary text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Total Guru</small>

                            <h2 class="fw-bold mb-0">

                                <?= $totalGuru ?>

                            </h2>

                        </div>

                        <i class="bi bi-person-video3 fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-success text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Laki-laki</small>

                            <h2 class="fw-bold mb-0">

                                <?= $totalLaki ?>

                            </h2>

                        </div>

                        <i class="bi bi-gender-male fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-danger text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Perempuan</small>

                            <h2 class="fw-bold mb-0">

                                <?= $totalPerempuan ?>

                            </h2>

                        </div>

                        <i class="bi bi-gender-female fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-info text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>User Guru</small>

                            <h2 class="fw-bold mb-0">

                                <?= $totalUserGuru ?>

                            </h2>

                        </div>

                        <i class="bi bi-person-badge-fill fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow border-0">

        <div class="card-header bg-white">

            <div class="d-flex justify-content-between align-items-center">

                <h5 class="mb-0">

                    Daftar Guru

                </h5>

                <span class="badge bg-primary">

                    Total <?= $totalGuru ?> Guru

                </span>

            </div>

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-hover align-middle datatable">

                    <thead class="table-primary">

                        <tr>

                            <th class="text-center">No</th>
                            <th class="text-center">Foto</th>
                            <th class="text-center">NIP</th>
                            <th class="text-center">Nama</th>
                            <th class="text-center">JK</th>
                            <th class="text-center">No HP</th>
                            <th class="text-center">Email</th>
                            <th class="text-center">Aksi</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php

$no = 1;

while($guru = mysqli_fetch_assoc($query)){

    if($guru['jenis_kelamin']=="Laki-laki"){

        $badge = "bg-primary";

    }else{

        $badge = "bg-danger";

    }

?>

                        <tr>

                            <td class="text-center">

                                <?= $no++ ?>

                            </td>

                            <td class="text-center">

                                <img src="../../assets/uploads/teachers/<?= htmlspecialchars($guru['foto']) ?>"
                                    width="55" height="55" class="rounded-circle border shadow-sm"
                                    style="object-fit:cover;">

                            </td>

                            <td>

                                <?= htmlspecialchars($guru['nip']) ?>

                            </td>

                            <td>

                                <div class="fw-semibold">

                                    <?= htmlspecialchars($guru['nama']) ?>

                                </div>

                            </td>

                            <td class="text-center">

                                <span class="badge <?= $badge ?>">

                                    <?= htmlspecialchars($guru['jenis_kelamin']) ?>

                                </span>

                            </td>

                            <td>

                                <i class="bi bi-telephone-fill text-success"></i>

                                <?= htmlspecialchars($guru['no_hp']) ?>

                            </td>

                            <td>

                                <i class="bi bi-envelope-fill text-primary"></i>

                                <?= htmlspecialchars($guru['email']) ?>

                            </td>

                            <td class="text-center">

                                <a href="edit.php?id=<?= $guru['id'] ?>" class="btn btn-warning btn-sm" title="Edit">

                                    <i class="bi bi-pencil-square"></i>

                                </a>

                                <a href="hapus.php?id=<?= $guru['id'] ?>" class="btn btn-danger btn-sm" title="Hapus"
                                    onclick="return confirm('Yakin ingin menghapus guru ini?')">

                                    <i class="bi bi-trash"></i>

                                </a>

                            </td>

                        </tr>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

        <div class="card-footer bg-white">

            <div class="row">

                <div class="col-md-6">

                    <small class="text-muted">

                        Menampilkan seluruh data guru yang terdaftar.

                    </small>

                </div>

                <div class="col-md-6 text-end">

                    <small class="text-muted">

                        Total Guru :

                        <strong><?= $totalGuru ?></strong>

                    </small>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>