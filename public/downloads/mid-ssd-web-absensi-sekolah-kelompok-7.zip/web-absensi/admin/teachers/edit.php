<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = mysqli_prepare($conn, "SELECT * FROM teachers WHERE id=?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$guru = mysqli_fetch_assoc($result);

if (!$guru) {
    die("Data guru tidak ditemukan.");
}

if (isset($_POST['update'])) {

    $nip = trim($_POST['nip']);
    $nama = trim($_POST['nama']);
    $jk = $_POST['jenis_kelamin'];
    $alamat = trim($_POST['alamat']);
    $no_hp = trim($_POST['no_hp']);
    $email = trim($_POST['email']);

    // Cek NIP selain dirinya sendiri
    $cek = mysqli_prepare($conn,
        "SELECT id FROM teachers WHERE nip=? AND id<>?");
    mysqli_stmt_bind_param($cek, "si", $nip, $id);
    mysqli_stmt_execute($cek);

    if (mysqli_num_rows(mysqli_stmt_get_result($cek)) > 0) {
        echo "<script>
        alert('NIP sudah digunakan!');
        history.back();
        </script>";
        exit;
    }

    $foto = $guru['foto'];

    if (!empty($_FILES['foto']['name'])) {

        if ($foto != "default.png" && file_exists("../../assets/uploads/teachers/".$foto)) {
            unlink("../../assets/uploads/teachers/".$foto);
        }

        $foto = time()."_".$_FILES['foto']['name'];

        move_uploaded_file(
            $_FILES['foto']['tmp_name'],
            "../../assets/uploads/teachers/".$foto
        );
    }

    $update = mysqli_prepare($conn,
        "UPDATE teachers SET
        nip=?,
        nama=?,
        jenis_kelamin=?,
        alamat=?,
        no_hp=?,
        email=?,
        foto=?
        WHERE id=?");

    mysqli_stmt_bind_param(
        $update,
        "sssssssi",
        $nip,
        $nama,
        $jk,
        $alamat,
        $no_hp,
        $email,
        $foto,
        $id
    );

    if (mysqli_stmt_execute($update)) {

        header("Location:index.php?success=edit");
        exit;

    } else {

        die(mysqli_error($conn));

    }
}

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header">
            <h4>Edit Guru</h4>
        </div>

        <div class="card-body">

            <form method="POST" enctype="multipart/form-data">

                <div class="row">

                    <div class="col-md-6">

                        <label>NIP</label>

                        <input type="text" name="nip" class="form-control" value="<?= htmlspecialchars($guru['nip']) ?>"
                            required>

                    </div>

                    <div class="col-md-6">

                        <label>Nama</label>

                        <input type="text" name="nama" class="form-control"
                            value="<?= htmlspecialchars($guru['nama']) ?>" required>

                    </div>

                </div>

                <br>

                <label>Jenis Kelamin</label>

                <select name="jenis_kelamin" class="form-select">

                    <option value="Laki-laki" <?= $guru['jenis_kelamin']=="Laki-laki"?"selected":"" ?>>

                        Laki-laki

                    </option>

                    <option value="Perempuan" <?= $guru['jenis_kelamin']=="Perempuan"?"selected":"" ?>>

                        Perempuan

                    </option>

                </select>

                <br>

                <label>Alamat</label>

                <textarea name="alamat" class="form-control"><?= htmlspecialchars($guru['alamat']) ?></textarea>

                <br>

                <label>No HP</label>

                <input type="text" name="no_hp" class="form-control" value="<?= htmlspecialchars($guru['no_hp']) ?>">

                <br>

                <label>Email</label>

                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($guru['email']) ?>">

                <br>

                <label>Foto Saat Ini</label>

                <br>

                <img src="../../assets/uploads/teachers/<?= htmlspecialchars($guru['foto']) ?>" width="120"
                    class="mb-3 rounded">

                <input type="file" name="foto" class="form-control">

                <br>

                <button name="update" class="btn btn-success">

                    Update

                </button>

                <a href="index.php" class="btn btn-secondary">

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>