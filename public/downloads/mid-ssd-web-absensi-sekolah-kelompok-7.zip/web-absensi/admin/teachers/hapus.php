<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/koneksi.php";

$id = (int)$_GET['id'];

$stmt = mysqli_prepare($conn,"SELECT foto FROM teachers WHERE id=?");
mysqli_stmt_bind_param($stmt,"i",$id);
mysqli_stmt_execute($stmt);

$data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if($data){

    if($data['foto']!="default.png"){

        $file="../../assets/uploads/teachers/".$data['foto'];

        if(file_exists($file)){
            unlink($file);
        }

    }

    $hapus=mysqli_prepare($conn,"DELETE FROM teachers WHERE id=?");
    mysqli_stmt_bind_param($hapus,"i",$id);
    mysqli_stmt_execute($hapus);

}

header("Location:index.php?success=hapus");
exit;