<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

if (isset($_POST['simpan'])) {

    $nip = trim($_POST['nip']);
    $nama = trim($_POST['nama']);
    $jk = $_POST['jenis_kelamin'];
    $alamat = trim($_POST['alamat']);
    $no_hp = trim($_POST['no_hp']);
    $email = trim($_POST['email']);

    // Cek NIP
    $cek = mysqli_prepare($conn, "SELECT id FROM teachers WHERE nip=?");
    mysqli_stmt_bind_param($cek, "s", $nip);
    mysqli_stmt_execute($cek);
    $hasil = mysqli_stmt_get_result($cek);

    if (mysqli_num_rows($hasil) > 0) {
        echo "<script>
            alert('NIP sudah digunakan!');
            window.history.back();
        </script>";
        exit;
    }

    // Upload Foto
    $foto = "default.png";

    if (!empty($_FILES['foto']['name'])) {

        $namaFile = time() . "_" . basename($_FILES['foto']['name']);
        $tmp = $_FILES['foto']['tmp_name'];

        move_uploaded_file(
            $tmp,
            "../../assets/uploads/teachers/" . $namaFile
        );

        $foto = $namaFile;
    }

    $stmt = mysqli_prepare($conn,
        "INSERT INTO teachers
        (nip,nama,jenis_kelamin,alamat,no_hp,email,foto)
        VALUES (?,?,?,?,?,?,?)");

    mysqli_stmt_bind_param(
        $stmt,
        "sssssss",
        $nip,
        $nama,
        $jk,
        $alamat,
        $no_hp,
        $email,
        $foto
    );

    if (mysqli_stmt_execute($stmt)) {

        header("Location:index.php?success=tambah");
        exit;

    } else {

        echo "<script>alert('Gagal menyimpan data');</script>";

    }
}

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header">
            <h4>Tambah Guru</h4>
        </div>

        <div class="card-body">

            <form method="POST" enctype="multipart/form-data">

                <div class="mb-3">
                    <label>NIP</label>
                    <input type="text" name="nip" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Nama Guru</label>
                    <input type="text" name="nama" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Jenis Kelamin</label>

                    <select name="jenis_kelamin" class="form-select" required>

                        <option value="">-- Pilih --</option>
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>

                    </select>

                </div>

                <div class="mb-3">
                    <label>Alamat</label>

                    <textarea name="alamat" class="form-control" rows="3"></textarea>

                </div>

                <div class="mb-3">
                    <label>No HP</label>

                    <input type="text" name="no_hp" class="form-control">

                </div>

                <div class="mb-3">
                    <label>Email</label>

                    <input type="email" name="email" class="form-control">

                </div>

                <div class="mb-3">
                    <label>Foto</label>

                    <input type="file" name="foto" class="form-control" accept="image/*">

                </div>

                <button type="submit" name="simpan" class="btn btn-primary">

                    Simpan

                </button>

                <a href="index.php" class="btn btn-secondary">

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>