<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

/* ==========================
   DATA KELAS
========================== */

$query = mysqli_query($conn,"
SELECT
    c.*,
    t.nama AS wali
FROM classes c
LEFT JOIN teachers t
ON c.wali_kelas=t.id
ORDER BY c.tingkat,c.nama_kelas
");

/* ==========================
   STATISTIK
========================== */

$totalKelas = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT COUNT(*) total FROM classes")
)['total'];

$totalX = mysqli_fetch_assoc(
    mysqli_query($conn,"
    SELECT COUNT(*) total
    FROM classes
    WHERE tingkat='X'
")
)['total'];

$totalXI = mysqli_fetch_assoc(
    mysqli_query($conn,"
    SELECT COUNT(*) total
    FROM classes
    WHERE tingkat='XI'
")
)['total'];

$totalXII = mysqli_fetch_assoc(
    mysqli_query($conn,"
    SELECT COUNT(*) total
    FROM classes
    WHERE tingkat='XII'
")
)['total'];

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <?php if(isset($_GET['success'])){ ?>

    <div class="alert alert-success alert-dismissible fade show">

        <?php

switch($_GET['success']){

case "tambah":
echo "Data kelas berhasil ditambahkan.";
break;

case "edit":
echo "Data kelas berhasil diperbarui.";
break;

case "hapus":
echo "Data kelas berhasil dihapus.";
break;

default:
echo "Data berhasil diproses.";

}

?>

        <button class="btn-close" data-bs-dismiss="alert"></button>

    </div>

    <?php } ?>

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                <i class="bi bi-building text-primary"></i>

                Data Kelas

            </h2>

            <p class="text-muted mb-0">

                Kelola seluruh data kelas pada sistem.

            </p>

        </div>

        <a href="tambah.php" class="btn btn-primary shadow">

            <i class="bi bi-plus-circle"></i>

            Tambah Kelas

        </a>

    </div>

    <div class="row mb-4">

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-primary text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Total Kelas</small>

                            <h2 class="fw-bold mb-0">

                                <?= $totalKelas ?>

                            </h2>

                        </div>

                        <i class="bi bi-building fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-success text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Tingkat X</small>

                            <h2 class="fw-bold mb-0">

                                <?= $totalX ?>

                            </h2>

                        </div>

                        <i class="bi bi-mortarboard-fill fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-warning">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Tingkat XI</small>

                            <h2 class="fw-bold mb-0">

                                <?= $totalXI ?>

                            </h2>

                        </div>

                        <i class="bi bi-book-fill fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-danger text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Tingkat XII</small>

                            <h2 class="fw-bold mb-0">

                                <?= $totalXII ?>

                            </h2>

                        </div>

                        <i class="bi bi-award-fill fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow border-0">

        <div class="card-header bg-white">

            <div class="d-flex justify-content-between align-items-center">

                <h5 class="mb-0">

                    Daftar Kelas

                </h5>

                <span class="badge bg-primary">

                    Total <?= $totalKelas ?> Kelas

                </span>

            </div>

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-hover align-middle datatable">

                    <thead class="table-primary">

                        <tr>

                            <th class="text-center">No</th>
                            <th class="text-center">Kelas</th>
                            <th class="text-center">Tingkat</th>
                            <th class="text-center">Jurusan</th>
                            <th class="text-center">Wali Kelas</th>
                            <th class="text-center">Aksi</th>

                        </tr>

                    </thead>

                    <tbody>
                        <?php

$no = 1;

while ($kelas = mysqli_fetch_assoc($query)) :

    if ($kelas['tingkat'] == "X") {

        $badgeTingkat = "bg-primary";

    } elseif ($kelas['tingkat'] == "XI") {

        $badgeTingkat = "bg-success";

    } else {

        $badgeTingkat = "bg-danger";

    }

    switch (strtoupper($kelas['jurusan'])) {

        case "IPA":
            $badgeJurusan = "bg-success";
            break;

        case "IPS":
            $badgeJurusan = "bg-primary";
            break;

        case "RPL":
            $badgeJurusan = "bg-danger";
            break;

        case "TKJ":
            $badgeJurusan = "bg-warning text-dark";
            break;

        default:
            $badgeJurusan = "bg-secondary";

    }

?>

                        <tr>

                            <td class="text-center">

                                <?= $no++ ?>

                            </td>

                            <td>

                                <strong>

                                    <?= htmlspecialchars($kelas['nama_kelas']) ?>

                                </strong>

                            </td>

                            <td class="text-center">

                                <span class="badge <?= $badgeTingkat ?> px-3 py-2">

                                    <?= htmlspecialchars($kelas['tingkat']) ?>

                                </span>

                            </td>

                            <td class="text-center">

                                <span class="badge <?= $badgeJurusan ?> px-3 py-2">

                                    <?= htmlspecialchars($kelas['jurusan']) ?>

                                </span>

                            </td>

                            <td>

                                <i class="bi bi-person-badge-fill text-primary"></i>

                                <?= !empty($kelas['wali']) ? htmlspecialchars($kelas['wali']) : '-' ?>

                            </td>

                            <td class="text-center">

                                <a href="detail.php?id=<?= $kelas['id'] ?>" class="btn btn-info btn-sm" title="Detail">

                                    <i class="bi bi-eye"></i>

                                </a>

                                <a href="edit.php?id=<?= $kelas['id'] ?>" class="btn btn-warning btn-sm" title="Edit">

                                    <i class="bi bi-pencil-square"></i>

                                </a>

                                <a href="hapus.php?id=<?= $kelas['id'] ?>" class="btn btn-danger btn-sm" title="Hapus"
                                    onclick="return confirm('Yakin ingin menghapus kelas ini?')">

                                    <i class="bi bi-trash"></i>

                                </a>

                            </td>

                        </tr>

                        <?php endwhile; ?>

                    </tbody>

                </table>

            </div>

        </div>
        <div class="card-footer bg-white">

            <div class="row">

                <div class="col-md-6">

                    <small class="text-muted">

                        Menampilkan seluruh data kelas yang terdaftar.

                    </small>

                </div>

                <div class="col-md-6 text-end">

                    <small class="text-muted">

                        Total Kelas :

                        <strong><?= $totalKelas ?></strong>

                    </small>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>