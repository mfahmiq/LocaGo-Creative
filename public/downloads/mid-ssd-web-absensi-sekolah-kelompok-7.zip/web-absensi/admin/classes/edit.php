<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = mysqli_prepare($conn, "SELECT * FROM classes WHERE id=?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$kelas = mysqli_fetch_assoc($result);

if (!$kelas) {
    die("Data kelas tidak ditemukan.");
}

if (isset($_POST['update'])) {

    $nama_kelas = trim($_POST['nama_kelas']);
    $tingkat = $_POST['tingkat'];
    $jurusan = trim($_POST['jurusan']);
    $wali = !empty($_POST['wali_kelas']) ? (int)$_POST['wali_kelas'] : NULL;

    // Cek duplikat kelas
    $cek = mysqli_prepare(
        $conn,
        "SELECT id
         FROM classes
         WHERE nama_kelas=? AND tingkat=? AND id<>?"
    );

    mysqli_stmt_bind_param(
        $cek,
        "ssi",
        $nama_kelas,
        $tingkat,
        $id
    );

    mysqli_stmt_execute($cek);

    if (mysqli_num_rows(mysqli_stmt_get_result($cek)) > 0) {

        echo "<script>
            alert('Kelas sudah ada.');
            history.back();
        </script>";
        exit;
    }

    $update = mysqli_prepare(
        $conn,
        "UPDATE classes
         SET
            nama_kelas=?,
            tingkat=?,
            jurusan=?,
            wali_kelas=?
         WHERE id=?"
    );

    mysqli_stmt_bind_param(
        $update,
        "sssii",
        $nama_kelas,
        $tingkat,
        $jurusan,
        $wali,
        $id
    );

    if (mysqli_stmt_execute($update)) {

        header("Location:index.php?success=edit");
        exit;

    } else {

        die(mysqli_error($conn));

    }
}

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header">
            <h4>Edit Kelas</h4>
        </div>

        <div class="card-body">

            <form method="POST">

                <div class="row">

                    <div class="col-md-4">

                        <label class="form-label">Tingkat</label>

                        <select name="tingkat" class="form-select" required>

                            <option value="X" <?= $kelas['tingkat']=="X" ? "selected" : "" ?>>X</option>
                            <option value="XI" <?= $kelas['tingkat']=="XI" ? "selected" : "" ?>>XI</option>
                            <option value="XII" <?= $kelas['tingkat']=="XII" ? "selected" : "" ?>>XII</option>

                        </select>

                    </div>

                    <div class="col-md-4">

                        <label class="form-label">Nama Kelas</label>

                        <input type="text" name="nama_kelas" class="form-control"
                            value="<?= htmlspecialchars($kelas['nama_kelas']) ?>" required>

                    </div>

                    <div class="col-md-4">

                        <label class="form-label">Jurusan</label>

                        <input type="text" name="jurusan" class="form-control"
                            value="<?= htmlspecialchars($kelas['jurusan']) ?>" required>

                    </div>

                </div>

                <br>

                <label class="form-label">Wali Kelas</label>

                <select name="wali_kelas" class="form-select">

                    <option value="">-- Pilih Wali Kelas --</option>

                    <?php

$guru = mysqli_query($conn, "SELECT * FROM teachers ORDER BY nama ASC");

while($g = mysqli_fetch_assoc($guru)){

?>

                    <option value="<?= $g['id']; ?>" <?= ($g['id'] == $kelas['wali_kelas']) ? "selected" : ""; ?>>

                        <?= htmlspecialchars($g['nama']); ?>

                    </option>

                    <?php } ?>

                </select>

                <br>

                <button type="submit" name="update" class="btn btn-success">

                    <i class="bi bi-check-circle"></i>
                    Update

                </button>

                <a href="index.php" class="btn btn-secondary">

                    <i class="bi bi-arrow-left"></i>
                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>