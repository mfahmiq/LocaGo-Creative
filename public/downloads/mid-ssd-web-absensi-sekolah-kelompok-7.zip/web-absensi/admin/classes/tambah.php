<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

if (isset($_POST['simpan'])) {

    $nama_kelas = trim($_POST['nama_kelas']);
    $tingkat = $_POST['tingkat'];
    $jurusan = trim($_POST['jurusan']);
    $wali = !empty($_POST['wali_kelas']) ? (int)$_POST['wali_kelas'] : NULL;

    // Cek apakah kelas sudah ada
    $cek = mysqli_prepare($conn,
        "SELECT id FROM classes
        WHERE nama_kelas=? AND tingkat=?");

    mysqli_stmt_bind_param(
        $cek,
        "ss",
        $nama_kelas,
        $tingkat
    );

    mysqli_stmt_execute($cek);

    if (mysqli_num_rows(mysqli_stmt_get_result($cek)) > 0) {

        echo "<script>
        alert('Kelas sudah ada!');
        history.back();
        </script>";
        exit;

    }

    $stmt = mysqli_prepare($conn,
        "INSERT INTO classes
        (nama_kelas,tingkat,jurusan,wali_kelas)
        VALUES(?,?,?,?)");

    mysqli_stmt_bind_param(
        $stmt,
        "sssi",
        $nama_kelas,
        $tingkat,
        $jurusan,
        $wali
    );

    if (mysqli_stmt_execute($stmt)) {

        header("Location:index.php?success=tambah");
        exit;

    } else {

        die(mysqli_error($conn));

    }

}

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header">

            <h4>Tambah Kelas</h4>

        </div>

        <div class="card-body">

            <form method="POST">

                <div class="row">

                    <div class="col-md-4">

                        <label>Tingkat</label>

                        <select name="tingkat" class="form-select" required>

                            <option value="">Pilih</option>
                            <option value="X">X</option>
                            <option value="XI">XI</option>
                            <option value="XII">XII</option>

                        </select>

                    </div>

                    <div class="col-md-4">

                        <label>Nama Kelas</label>

                        <input type="text" name="nama_kelas" class="form-control" placeholder="Contoh: IPA 1" required>

                    </div>

                    <div class="col-md-4">

                        <label>Jurusan</label>

                        <input type="text" name="jurusan" class="form-control" placeholder="IPA / IPS / TKJ" required>

                    </div>

                </div>

                <br>

                <label>Wali Kelas</label>

                <select name="wali_kelas" class="form-select">

                    <option value="">Belum Ditentukan</option>

                    <?php

$guru = mysqli_query($conn,"SELECT * FROM teachers ORDER BY nama");

while($g=mysqli_fetch_assoc($guru)){

?>

                    <option value="<?= $g['id'] ?>">

                        <?= htmlspecialchars($g['nama']) ?>

                    </option>

                    <?php } ?>

                </select>

                <br>

                <button name="simpan" class="btn btn-primary">

                    Simpan

                </button>

                <a href="index.php" class="btn btn-secondary">

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>