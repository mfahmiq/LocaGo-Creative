<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$class = isset($_GET['class']) ? (int)$_GET['class'] : 0;

// Ambil data siswa
$stmt = mysqli_prepare($conn, "SELECT foto FROM students WHERE id=?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$siswa = mysqli_fetch_assoc($result);

if (!$siswa) {

    echo "<script>
    alert('Data siswa tidak ditemukan.');
    window.location='detail.php?id=$class';
    </script>";

    exit;
}

// Hapus foto jika bukan default
if (
    $siswa['foto'] != "default.png" &&
    file_exists("../../assets/uploads/students/" . $siswa['foto'])
) {
    unlink("../../assets/uploads/students/" . $siswa['foto']);
}

// Hapus data siswa
$hapus = mysqli_prepare($conn, "DELETE FROM students WHERE id=?");
mysqli_stmt_bind_param($hapus, "i", $id);

if (mysqli_stmt_execute($hapus)) {

    header("Location: detail.php?id=$class");
    exit;

} else {

    echo "<script>
    alert('Gagal menghapus siswa.');
    window.location='detail.php?id=$class';
    </script>";

}