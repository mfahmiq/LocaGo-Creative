<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

/* ==========================
   DATA KELAS
========================== */

$stmt = mysqli_prepare(
    $conn,
    "SELECT
        c.*,
        t.nama AS wali
    FROM classes c
    LEFT JOIN teachers t
        ON c.wali_kelas=t.id
    WHERE c.id=?"
);

mysqli_stmt_bind_param($stmt,"i",$id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$kelas = mysqli_fetch_assoc($result);

if(!$kelas){
    die("Data kelas tidak ditemukan.");
}

/* ==========================
   DATA SISWA
========================== */

$siswa = mysqli_prepare(
    $conn,
    "SELECT *
    FROM students
    WHERE class_id=?
    ORDER BY nama ASC"
);

mysqli_stmt_bind_param($siswa,"i",$id);
mysqli_stmt_execute($siswa);

$dataSiswa = mysqli_stmt_get_result($siswa);

$jumlahSiswa = mysqli_num_rows($dataSiswa);

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                <i class="bi bi-building text-primary"></i>

                Detail Kelas

            </h2>

            <p class="text-muted mb-0">

                Informasi kelas dan daftar siswa.

            </p>

        </div>

        <a href="index.php" class="btn btn-secondary">

            <i class="bi bi-arrow-left"></i>

            Kembali

        </a>

    </div>

    <div class="row mb-4">

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-primary text-white">

                <div class="card-body">

                    <small>Kelas</small>

                    <h3 class="fw-bold">

                        <?= htmlspecialchars($kelas['tingkat']) ?>

                        <?= htmlspecialchars($kelas['nama_kelas']) ?>

                    </h3>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-success text-white">

                <div class="card-body">

                    <small>Jurusan</small>

                    <h3 class="fw-bold">

                        <?= htmlspecialchars($kelas['jurusan']) ?>

                    </h3>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-warning">

                <div class="card-body">

                    <small>Wali Kelas</small>

                    <h5 class="fw-bold">

                        <?= !empty($kelas['wali']) ? htmlspecialchars($kelas['wali']) : "-" ?>

                    </h5>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-danger text-white">

                <div class="card-body">

                    <small>Jumlah Siswa</small>

                    <h2 class="fw-bold">

                        <?= $jumlahSiswa ?>

                    </h2>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow border-0">

        <div class="card-header bg-white">

            <div class="d-flex justify-content-between align-items-center">

                <h5 class="mb-0">

                    Daftar Siswa

                </h5>

                <a href="tambah_siswa.php?class=<?= $kelas['id'] ?>" class="btn btn-primary">

                    <i class="bi bi-plus-circle"></i>

                    Tambah Siswa

                </a>

            </div>

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-hover align-middle datatable">

                    <thead class="table-primary">

                        <tr>

                            <th class="text-center">No</th>
                            <th class="text-center">Foto</th>
                            <th class="text-center">NIS</th>
                            <th>Nama</th>
                            <th class="text-center">JK</th>
                            <th>Tanggal Lahir</th>
                            <th>Alamat</th>
                            <th>No HP</th>
                            <th>Email</th>
                            <th class="text-center">Aksi</th>

                        </tr>

                    </thead>

                    <tbody>
                    <tbody>

                        <?php

$no = 1;

while ($row = mysqli_fetch_assoc($dataSiswa)) {

    if ($row['jenis_kelamin'] == "Laki-laki") {

        $badge = "bg-primary";

    } else {

        $badge = "bg-danger";

    }

?>

                        <tr>

                            <td class="text-center">

                                <?= $no++ ?>

                            </td>

                            <td class="text-center">

                                <img src="../../assets/uploads/students/<?= htmlspecialchars($row['foto']) ?>"
                                    width="55" height="55" class="rounded-circle border shadow-sm"
                                    style="object-fit:cover;">

                            </td>

                            <td>

                                <?= htmlspecialchars($row['nis']) ?>

                            </td>

                            <td>

                                <div class="fw-semibold">

                                    <?= htmlspecialchars($row['nama']) ?>

                                </div>

                            </td>

                            <td class="text-center">

                                <span class="badge <?= $badge ?>">

                                    <?= htmlspecialchars($row['jenis_kelamin']) ?>

                                </span>

                            </td>

                            <td>

                                <?= !empty($row['tanggal_lahir']) ? date('d-m-Y', strtotime($row['tanggal_lahir'])) : '-' ?>

                            </td>

                            <td>

                                <?= htmlspecialchars($row['alamat']) ?>

                            </td>

                            <td>

                                <i class="bi bi-telephone-fill text-success"></i>

                                <?= htmlspecialchars($row['no_hp']) ?>

                            </td>

                            <td>

                                <i class="bi bi-envelope-fill text-primary"></i>

                                <?= htmlspecialchars($row['email']) ?>

                            </td>

                            <td class="text-center">

                                <a href="edit_siswa.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm"
                                    title="Edit">

                                    <i class="bi bi-pencil-square"></i>

                                </a>

                                <a href="hapus_siswa.php?id=<?= $row['id'] ?>&class=<?= $kelas['id'] ?>"
                                    class="btn btn-danger btn-sm" title="Hapus"
                                    onclick="return confirm('Yakin ingin menghapus siswa ini?')">

                                    <i class="bi bi-trash"></i>

                                </a>

                            </td>

                        </tr>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

        <div class="card-footer bg-white">

            <div class="row">

                <div class="col-md-6">

                    <small class="text-muted">

                        Menampilkan seluruh siswa pada kelas ini.

                    </small>

                </div>

                <div class="col-md-6 text-end">

                    <small class="text-muted">

                        Total Siswa :

                        <strong><?= $jumlahSiswa ?></strong>

                    </small>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>