<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

$class_id = isset($_GET['class']) ? (int)$_GET['class'] : 0;

$stmt = mysqli_prepare($conn, "SELECT * FROM classes WHERE id=?");
mysqli_stmt_bind_param($stmt, "i", $class_id);
mysqli_stmt_execute($stmt);

$kelas = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$kelas) {
    die("Kelas tidak ditemukan.");
}

if (isset($_POST['simpan'])) {

    $nis = trim($_POST['nis']);
    $nama = trim($_POST['nama']);
    $jk = $_POST['jenis_kelamin'];
    $tgl = $_POST['tanggal_lahir'];
    $alamat = trim($_POST['alamat']);
    $hp = trim($_POST['no_hp']);
    $email = trim($_POST['email']);

    $cek = mysqli_prepare($conn, "SELECT id FROM students WHERE nis=?");
    mysqli_stmt_bind_param($cek, "s", $nis);
    mysqli_stmt_execute($cek);

    if (mysqli_num_rows(mysqli_stmt_get_result($cek)) > 0) {

        echo "<script>
            alert('NIS sudah digunakan.');
            history.back();
        </script>";
        exit;
    }

    $foto = "default.png";

    if (!empty($_FILES['foto']['name'])) {

        $foto = time() . "_" . basename($_FILES['foto']['name']);

        move_uploaded_file(
            $_FILES['foto']['tmp_name'],
            "../../assets/uploads/students/" . $foto
        );
    }

    $insert = mysqli_prepare($conn,
        "INSERT INTO students
        (class_id,nis,nama,jenis_kelamin,tanggal_lahir,alamat,no_hp,email,foto)
        VALUES(?,?,?,?,?,?,?,?,?)");

    mysqli_stmt_bind_param(
        $insert,
        "issssssss",
        $class_id,
        $nis,
        $nama,
        $jk,
        $tgl,
        $alamat,
        $hp,
        $email,
        $foto
    );

    if (mysqli_stmt_execute($insert)) {

        header("Location:detail.php?id=".$class_id);
        exit;

    } else {

        die(mysqli_error($conn));

    }
}

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header">
            <h4>Tambah Siswa</h4>
        </div>

        <div class="card-body">

            <form method="POST" enctype="multipart/form-data">

                <div class="mb-3">
                    <label>Kelas</label>
                    <input type="text" class="form-control"
                        value="<?= htmlspecialchars($kelas['tingkat'].' '.$kelas['nama_kelas']) ?>" readonly>
                </div>

                <div class="mb-3">
                    <label>NIS</label>
                    <input type="text" name="nis" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Nama</label>
                    <input type="text" name="nama" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Jenis Kelamin</label>
                    <select name="jenis_kelamin" class="form-select" required>
                        <option value="">Pilih</option>
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="form-control">
                </div>

                <div class="mb-3">
                    <label>Alamat</label>
                    <textarea name="alamat" class="form-control"></textarea>
                </div>

                <div class="mb-3">
                    <label>No HP</label>
                    <input type="text" name="no_hp" class="form-control">
                </div>

                <div class="mb-3">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control">
                </div>

                <div class="mb-3">
                    <label>Foto</label>
                    <input type="file" name="foto" class="form-control" accept="image/*">
                </div>

                <button type="submit" name="simpan" class="btn btn-primary">
                    Simpan
                </button>

                <a href="detail.php?id=<?= $class_id ?>" class="btn btn-secondary">
                    Kembali
                </a>

            </form>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>