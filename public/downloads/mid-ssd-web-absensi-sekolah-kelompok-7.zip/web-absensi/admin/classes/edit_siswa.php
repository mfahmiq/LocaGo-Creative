<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = mysqli_prepare($conn,"SELECT * FROM students WHERE id=?");
mysqli_stmt_bind_param($stmt,"i",$id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$siswa = mysqli_fetch_assoc($result);

if(!$siswa){
    die("Data siswa tidak ditemukan.");
}

if(isset($_POST['update'])){

    $nis = trim($_POST['nis']);
    $nama = trim($_POST['nama']);
    $jk = $_POST['jenis_kelamin'];
    $tgl = $_POST['tanggal_lahir'];
    $alamat = trim($_POST['alamat']);
    $hp = trim($_POST['no_hp']);
    $email = trim($_POST['email']);

    $foto = $siswa['foto'];

    if(!empty($_FILES['foto']['name'])){

        if($foto!="default.png" && file_exists("../../assets/uploads/students/".$foto)){
            unlink("../../assets/uploads/students/".$foto);
        }

        $foto=time()."_".basename($_FILES['foto']['name']);

        move_uploaded_file(
            $_FILES['foto']['tmp_name'],
            "../../assets/uploads/students/".$foto
        );
    }

    $update=mysqli_prepare($conn,"
    UPDATE students SET
    nis=?,
    nama=?,
    jenis_kelamin=?,
    tanggal_lahir=?,
    alamat=?,
    no_hp=?,
    email=?,
    foto=?
    WHERE id=?
    ");

    mysqli_stmt_bind_param(
        $update,
        "ssssssssi",
        $nis,
        $nama,
        $jk,
        $tgl,
        $alamat,
        $hp,
        $email,
        $foto,
        $id
    );

    mysqli_stmt_execute($update);

    header("Location:detail.php?id=".$siswa['class_id']);
    exit;
}

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header">

            <h4>Edit Siswa</h4>

        </div>

        <div class="card-body">

            <form method="POST" enctype="multipart/form-data">

                <div class="mb-3">

                    <label>NIS</label>

                    <input type="text" name="nis" class="form-control" value="<?= htmlspecialchars($siswa['nis']) ?>"
                        required>

                </div>

                <div class="mb-3">

                    <label>Nama</label>

                    <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($siswa['nama']) ?>"
                        required>

                </div>

                <div class="mb-3">

                    <label>Jenis Kelamin</label>

                    <select name="jenis_kelamin" class="form-select">

                        <option value="Laki-laki" <?= $siswa['jenis_kelamin']=="Laki-laki"?"selected":"" ?>>

                            Laki-laki

                        </option>

                        <option value="Perempuan" <?= $siswa['jenis_kelamin']=="Perempuan"?"selected":"" ?>>

                            Perempuan

                        </option>

                    </select>

                </div>

                <div class="mb-3">

                    <label>Tanggal Lahir</label>

                    <input type="date" name="tanggal_lahir" class="form-control" value="<?= $siswa['tanggal_lahir'] ?>">

                </div>

                <div class="mb-3">

                    <label>Alamat</label>

                    <textarea name="alamat" class="form-control"><?= htmlspecialchars($siswa['alamat']) ?></textarea>

                </div>

                <div class="mb-3">

                    <label>No HP</label>

                    <input type="text" name="no_hp" class="form-control"
                        value="<?= htmlspecialchars($siswa['no_hp']) ?>">

                </div>

                <div class="mb-3">

                    <label>Email</label>

                    <input type="email" name="email" class="form-control"
                        value="<?= htmlspecialchars($siswa['email']) ?>">

                </div>

                <div class="mb-3">

                    <label>Foto</label>

                    <br>

                    <img src="../../assets/uploads/students/<?= htmlspecialchars($siswa['foto']) ?>" width="100"
                        class="mb-2">

                    <input type="file" name="foto" class="form-control">

                </div>

                <button name="update" class="btn btn-success">

                    Update

                </button>

                <a href="detail.php?id=<?= $siswa['class_id'] ?>" class="btn btn-secondary">

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>