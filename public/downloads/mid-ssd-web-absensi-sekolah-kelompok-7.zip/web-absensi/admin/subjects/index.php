<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

/* ==========================
   DATA MATA PELAJARAN
========================== */

$query = mysqli_query($conn,"
SELECT *
FROM subjects
ORDER BY nama_mapel ASC
");

/* ==========================
   STATISTIK
========================== */

$totalMapel = mysqli_fetch_assoc(
    mysqli_query($conn,"SELECT COUNT(*) total FROM subjects")
)['total'];

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <?php if(isset($_GET['success'])){ ?>

    <div class="alert alert-success alert-dismissible fade show">

        <?php

switch($_GET['success']){

case "tambah":
echo "Mata pelajaran berhasil ditambahkan.";
break;

case "edit":
echo "Mata pelajaran berhasil diperbarui.";
break;

case "hapus":
echo "Mata pelajaran berhasil dihapus.";
break;

default:
echo "Data berhasil diproses.";

}

?>

        <button class="btn-close" data-bs-dismiss="alert"></button>

    </div>

    <?php } ?>

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                <i class="bi bi-book-half text-primary"></i>

                Data Mata Pelajaran

            </h2>

            <p class="text-muted mb-0">

                Kelola seluruh mata pelajaran pada sistem absensi sekolah.

            </p>

        </div>

        <a href="tambah.php" class="btn btn-primary shadow">

            <i class="bi bi-plus-circle"></i>

            Tambah Mata Pelajaran

        </a>

    </div>

    <div class="row mb-4">

        <div class="col-lg-12">

            <div class="card shadow border-0 bg-primary text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Total Mata Pelajaran</small>

                            <h2 class="fw-bold mb-0">

                                <?= $totalMapel ?>

                            </h2>

                        </div>

                        <i class="bi bi-book-half fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow border-0">

        <div class="card-header bg-white">

            <div class="d-flex justify-content-between align-items-center">

                <h5 class="mb-0">

                    Daftar Mata Pelajaran

                </h5>

                <span class="badge bg-primary">

                    Total <?= $totalMapel ?> Mata Pelajaran

                </span>

            </div>

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-hover align-middle datatable">

                    <thead class="table-primary">

                        <tr>

                            <th class="text-center">No</th>
                            <th class="text-center">Kode</th>
                            <th>Nama Mata Pelajaran</th>
                            <th>Deskripsi</th>
                            <th class="text-center">Aksi</th>

                        </tr>

                    </thead>

                    <tbody>
                        <?php

$no = 1;

while($mapel = mysqli_fetch_assoc($query)){

?>

                        <tr>

                            <td class="text-center">

                                <?= $no++ ?>

                            </td>

                            <td class="text-center">

                                <span class="badge bg-primary px-3 py-2">

                                    <?= htmlspecialchars($mapel['kode_mapel']) ?>

                                </span>

                            </td>

                            <td>

                                <div class="fw-semibold">

                                    <?= htmlspecialchars($mapel['nama_mapel']) ?>

                                </div>

                            </td>

                            <td>

                                <?php

        if(strlen($mapel['deskripsi']) > 70){

            echo htmlspecialchars(substr($mapel['deskripsi'],0,70))."...";

        }else{

            echo htmlspecialchars($mapel['deskripsi']);

        }

        ?>

                            </td>

                            <td class="text-center">

                                <a href="edit.php?id=<?= $mapel['id'] ?>" class="btn btn-warning btn-sm" title="Edit">

                                    <i class="bi bi-pencil-square"></i>

                                </a>

                                <a href="hapus.php?id=<?= $mapel['id'] ?>" class="btn btn-danger btn-sm" title="Hapus"
                                    onclick="return confirm('Hapus mata pelajaran ini?')">

                                    <i class="bi bi-trash"></i>

                                </a>

                            </td>

                        </tr>

                        <?php } ?>

                    </tbody>

                </table>

            </div>

        </div>

        <div class="card-footer bg-white">

            <div class="row">

                <div class="col-md-6">

                    <small class="text-muted">

                        Menampilkan seluruh data mata pelajaran yang terdaftar.

                    </small>

                </div>

                <div class="col-md-6 text-end">

                    <small class="text-muted">

                        Total Mata Pelajaran :

                        <strong><?= $totalMapel ?></strong>

                    </small>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>