<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

if (isset($_POST['simpan'])) {

    $kode = strtoupper(trim($_POST['kode_mapel']));
    $nama = trim($_POST['nama_mapel']);
    $deskripsi = trim($_POST['deskripsi']);

    // Cek kode mapel
    $cek = mysqli_prepare($conn,
        "SELECT id FROM subjects WHERE kode_mapel=?");

    mysqli_stmt_bind_param($cek, "s", $kode);
    mysqli_stmt_execute($cek);

    if (mysqli_num_rows(mysqli_stmt_get_result($cek)) > 0) {

        echo "<script>
        alert('Kode mata pelajaran sudah digunakan.');
        history.back();
        </script>";

        exit;
    }

    $stmt = mysqli_prepare(
        $conn,
        "INSERT INTO subjects
        (kode_mapel,nama_mapel,deskripsi)
        VALUES(?,?,?)"
    );

    mysqli_stmt_bind_param(
        $stmt,
        "sss",
        $kode,
        $nama,
        $deskripsi
    );

    if (mysqli_stmt_execute($stmt)) {

        header("Location:index.php?success=tambah");
        exit;

    } else {

        die(mysqli_error($conn));

    }

}

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header">

            <h4>Tambah Mata Pelajaran</h4>

        </div>

        <div class="card-body">

            <form method="POST">

                <div class="mb-3">

                    <label class="form-label">

                        Kode Mata Pelajaran

                    </label>

                    <input type="text" name="kode_mapel" class="form-control" placeholder="Contoh : MTK" required>

                </div>

                <div class="mb-3">

                    <label class="form-label">

                        Nama Mata Pelajaran

                    </label>

                    <input type="text" name="nama_mapel" class="form-control" placeholder="Contoh : Matematika"
                        required>

                </div>

                <div class="mb-3">

                    <label class="form-label">

                        Deskripsi

                    </label>

                    <textarea name="deskripsi" class="form-control" rows="4"
                        placeholder="Contoh : Mata pelajaran wajib kelas X"></textarea>

                </div>

                <button type="submit" name="simpan" class="btn btn-primary">

                    <i class="bi bi-save"></i>

                    Simpan

                </button>

                <a href="index.php" class="btn btn-secondary">

                    <i class="bi bi-arrow-left"></i>

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>