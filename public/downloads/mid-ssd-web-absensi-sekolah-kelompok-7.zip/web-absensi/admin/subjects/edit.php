<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = mysqli_prepare(
    $conn,
    "SELECT * FROM subjects WHERE id=?"
);

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$mapel = mysqli_fetch_assoc($result);

if (!$mapel) {
    die("Data mata pelajaran tidak ditemukan.");
}

if (isset($_POST['update'])) {

    $kode = strtoupper(trim($_POST['kode_mapel']));
    $nama = trim($_POST['nama_mapel']);
    $deskripsi = trim($_POST['deskripsi']);

    // Cek kode selain dirinya sendiri
    $cek = mysqli_prepare(
        $conn,
        "SELECT id
        FROM subjects
        WHERE kode_mapel=? AND id<>?"
    );

    mysqli_stmt_bind_param(
        $cek,
        "si",
        $kode,
        $id
    );

    mysqli_stmt_execute($cek);

    if (mysqli_num_rows(mysqli_stmt_get_result($cek)) > 0) {

        echo "<script>
        alert('Kode mata pelajaran sudah digunakan.');
        history.back();
        </script>";

        exit;
    }

    $update = mysqli_prepare(
        $conn,
        "UPDATE subjects
        SET
            kode_mapel=?,
            nama_mapel=?,
            deskripsi=?
        WHERE id=?"
    );

    mysqli_stmt_bind_param(
        $update,
        "sssi",
        $kode,
        $nama,
        $deskripsi,
        $id
    );

    if (mysqli_stmt_execute($update)) {

        header("Location:index.php?success=edit");
        exit;

    } else {

        die(mysqli_error($conn));

    }

}

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header">

            <h4>Edit Mata Pelajaran</h4>

        </div>

        <div class="card-body">

            <form method="POST">

                <div class="mb-3">

                    <label class="form-label">

                        Kode Mata Pelajaran

                    </label>

                    <input type="text" name="kode_mapel" class="form-control"
                        value="<?= htmlspecialchars($mapel['kode_mapel']) ?>" required>

                </div>

                <div class="mb-3">

                    <label class="form-label">

                        Nama Mata Pelajaran

                    </label>

                    <input type="text" name="nama_mapel" class="form-control"
                        value="<?= htmlspecialchars($mapel['nama_mapel']) ?>" required>

                </div>

                <div class="mb-3">

                    <label class="form-label">

                        Deskripsi

                    </label>

                    <textarea name="deskripsi" class="form-control"
                        rows="4"><?= htmlspecialchars($mapel['deskripsi']) ?></textarea>

                </div>

                <button type="submit" name="update" class="btn btn-success">

                    <i class="bi bi-check-circle"></i>

                    Update

                </button>

                <a href="index.php" class="btn btn-secondary">

                    <i class="bi bi-arrow-left"></i>

                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>