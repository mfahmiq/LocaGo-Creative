<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header("Location:index.php");
    exit;
}

// Cek apakah data ada
$cek = mysqli_prepare(
    $conn,
    "SELECT id
    FROM subjects
    WHERE id=?"
);

mysqli_stmt_bind_param($cek, "i", $id);
mysqli_stmt_execute($cek);

$result = mysqli_stmt_get_result($cek);

if (mysqli_num_rows($result) == 0) {

    echo "<script>
    alert('Data mata pelajaran tidak ditemukan.');
    window.location='index.php';
    </script>";

    exit;
}

/*
Jika nanti tabel schedules sudah dibuat,
tambahkan pengecekan di sini agar
mata pelajaran yang masih dipakai jadwal
tidak bisa dihapus.
*/

$hapus = mysqli_prepare(
    $conn,
    "DELETE FROM subjects
    WHERE id=?"
);

mysqli_stmt_bind_param($hapus, "i", $id);

if (mysqli_stmt_execute($hapus)) {

    header("Location:index.php?success=hapus");
    exit;

} else {

    echo "<script>
    alert('Gagal menghapus data.');
    window.location='index.php';
    </script>";

}