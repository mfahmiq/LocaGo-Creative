<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

/* ==========================
   QUERY DATA USER
========================== */

$query = mysqli_prepare($conn, "
SELECT
    u.id,
    u.nama,
    u.email,
    r.nama_role
FROM users u
INNER JOIN roles r
    ON u.role_id = r.id
ORDER BY u.id DESC
");

mysqli_stmt_execute($query);
$result = mysqli_stmt_get_result($query);

/* ==========================
   STATISTIK
========================== */

$totalUser = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM users")
)['total'];

$totalAdmin = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
        FROM users u
        INNER JOIN roles r
        ON u.role_id = r.id
        WHERE r.nama_role='Administrator'"
    )
)['total'];

$totalGuru = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
        FROM teachers"
    )
)['total'];

$totalSiswa = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
        FROM students"
    )
)['total'];

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold mb-1">

                <i class="bi bi-people-fill text-primary"></i>

                Data User

            </h2>

            <p class="text-muted mb-0">

                Kelola seluruh akun pengguna Sistem Informasi Absensi Sekolah

            </p>

        </div>

        <a href="tambah.php" class="btn btn-primary shadow">

            <i class="bi bi-plus-circle"></i>

            Tambah User

        </a>

    </div>

    <?php if(isset($_GET['success'])): ?>

    <div class="alert alert-success alert-dismissible fade show">

        <?php

        switch($_GET['success']){

            case "tambah":
                echo "User berhasil ditambahkan.";
            break;

            case "edit":
                echo "User berhasil diperbarui.";
            break;

            case "hapus":
                echo "User berhasil dihapus.";
            break;

            default:
                echo "Data berhasil diproses.";

        }

        ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert">
        </button>

    </div>

    <?php endif; ?>

    <div class="row mb-4">

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-primary text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Total User</small>

                            <h2 class="fw-bold mb-0">
                                <?= $totalUser ?>
                            </h2>

                        </div>

                        <i class="bi bi-people-fill fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-danger text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Administrator</small>

                            <h2 class="fw-bold mb-0">
                                <?= $totalAdmin ?>
                            </h2>

                        </div>

                        <i class="bi bi-person-fill-gear fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-success text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Total Guru</small>

                            <h2 class="fw-bold mb-0">
                                <?= $totalGuru ?>
                            </h2>

                        </div>

                        <i class="bi bi-person-video3 fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

        <div class="col-lg-3 col-md-6 mb-3">

            <div class="card shadow border-0 bg-info text-white">

                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <small>Total Siswa</small>

                            <h2 class="fw-bold mb-0">
                                <?= $totalSiswa ?>
                            </h2>

                        </div>

                        <i class="bi bi-mortarboard-fill fs-1"></i>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <div class="card shadow border-0">

        <div class="card-header bg-white">

            <div class="d-flex justify-content-between align-items-center">

                <div>

                    <h5 class="mb-1">

                        <i class="bi bi-table"></i>

                        Daftar Pengguna

                    </h5>

                    <small class="text-muted">

                        Seluruh akun pengguna yang dapat mengakses sistem.

                    </small>

                </div>

                <span class="badge bg-primary fs-6">

                    Total <?= $totalUser ?> User

                </span>

            </div>

        </div>

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-hover align-middle datatable">

                    <thead class="table-primary">

                        <tr>

                            <th width="60" class="text-center">No</th>

                            <th>Pengguna</th>

                            <th>Email</th>

                            <th width="150" class="text-center">Role</th>

                            <th width="150" class="text-center">Aksi</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php

                $no = 1;

                while($row = mysqli_fetch_assoc($result)):

                    $badge = "bg-secondary";

                    if($row['nama_role']=="Administrator"){

                        $badge = "bg-danger";

                    }elseif($row['nama_role']=="Guru"){

                        $badge = "bg-success";

                    }

                    $inisial = strtoupper(substr($row['nama'],0,1));

                ?>

                        <tr>

                            <td class="text-center">

                                <?= $no++; ?>

                            </td>

                            <td>

                                <div class="d-flex align-items-center">

                                    <div class="rounded-circle bg-primary text-white fw-bold d-flex justify-content-center align-items-center"
                                        style="width:45px;height:45px;">

                                        <?= $inisial ?>

                                    </div>

                                    <div class="ms-3">

                                        <div class="fw-semibold">

                                            <?= htmlspecialchars($row['nama']) ?>

                                        </div>

                                        <small class="text-muted">

                                            ID User :
                                            <?= $row['id'] ?>

                                        </small>

                                    </div>

                                </div>

                            </td>

                            <td>

                                <i class="bi bi-envelope-fill text-secondary me-1"></i>

                                <?= htmlspecialchars($row['email']) ?>

                            </td>

                            <td class="text-center">

                                <span class="badge <?= $badge ?> px-3 py-2">

                                    <?= htmlspecialchars($row['nama_role']) ?>

                                </span>

                            </td>

                            <td class="text-center">

                                <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm" title="Edit">

                                    <i class="bi bi-pencil-square"></i>

                                </a>

                                <a href="hapus.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" title="Hapus"
                                    onclick="return confirm('Yakin ingin menghapus user ini?')">

                                    <i class="bi bi-trash"></i>

                                </a>

                            </td>

                        </tr>

                        <?php endwhile; ?>

                    </tbody>

                </table>

            </div>

        </div>

        <div class="card-footer bg-white">

            <div class="row">

                <div class="col-md-6">

                    <small class="text-muted">

                        Menampilkan seluruh akun pengguna yang terdaftar.

                    </small>

                </div>

                <div class="col-md-6 text-md-end">

                    <small class="text-muted">

                        Total Data :
                        <strong><?= $totalUser ?></strong>

                    </small>

                </div>

            </div>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>