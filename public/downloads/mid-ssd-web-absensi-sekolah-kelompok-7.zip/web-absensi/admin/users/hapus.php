<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

// Ambil ID dari URL
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Validasi ID
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

// Cegah menghapus akun sendiri
if ($id == $_SESSION['id']) {
    echo "<script>
        alert('Anda tidak dapat menghapus akun yang sedang digunakan.');
        window.location='index.php';
    </script>";
    exit;
}

// Cek apakah user ada
$cek = mysqli_prepare($conn, "SELECT id FROM users WHERE id=?");
mysqli_stmt_bind_param($cek, "i", $id);
mysqli_stmt_execute($cek);

$result = mysqli_stmt_get_result($cek);

if (mysqli_num_rows($result) == 0) {

    echo "<script>
        alert('Data user tidak ditemukan.');
        window.location='index.php';
    </script>";

    exit;
}

// Hapus user
$hapus = mysqli_prepare($conn, "DELETE FROM users WHERE id=?");
mysqli_stmt_bind_param($hapus, "i", $id);

if (mysqli_stmt_execute($hapus)) {

    header("Location: index.php?success=hapus");
    exit;

} else {

    echo "<script>
        alert('Gagal menghapus data.');
        window.location='index.php';
    </script>";

}