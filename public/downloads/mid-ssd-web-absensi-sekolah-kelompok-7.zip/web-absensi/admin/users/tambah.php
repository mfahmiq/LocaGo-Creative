<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

/* ==========================
   SIMPAN DATA
========================== */

if (isset($_POST['simpan'])) {

    $nama     = trim($_POST['nama']);
    $email    = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role     = (int)$_POST['role'];

    // Validasi
    if ($nama == "" || $email == "" || $_POST['password'] == "" || $role == 0) {
        echo "<div class='alert alert-danger'>Semua field wajib diisi.</div>";
    } else {

        // Cek email
        $cek = mysqli_prepare($conn, "SELECT id FROM users WHERE email=?");
        mysqli_stmt_bind_param($cek, "s", $email);
        mysqli_stmt_execute($cek);
        $hasil = mysqli_stmt_get_result($cek);

        if (mysqli_num_rows($hasil) > 0) {

            echo "<script>
                alert('Email sudah digunakan!');
                window.history.back();
            </script>";
            exit;

        }

        $stmt = mysqli_prepare(
            $conn,
            "INSERT INTO users
            (role_id,nama,email,password)
            VALUES (?,?,?,?)"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "isss",
            $role,
            $nama,
            $email,
            $password
        );

        if (mysqli_stmt_execute($stmt)) {

            header("Location: index.php?success=tambah");
            exit;

        } else {

            echo "<div class='alert alert-danger'>
                    Gagal menyimpan data.
                  </div>";
        }
    }
}

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="fw-bold">

                <i class="bi bi-person-plus-fill text-primary"></i>

                Tambah User

            </h2>

            <p class="text-muted mb-0">

                Tambahkan akun pengguna baru ke dalam sistem.

            </p>

        </div>

        <a href="index.php" class="btn btn-secondary">

            <i class="bi bi-arrow-left"></i>

            Kembali

        </a>

    </div>

    <div class="card shadow border-0">

        <div class="card-header bg-primary text-white">

            <h5 class="mb-0">

                Form Tambah User

            </h5>

        </div>

        <div class="card-body">

            <form method="POST">

                <div class="row">

                    <div class="col-md-6 mb-3">

                        <label class="form-label">

                            Nama Lengkap

                        </label>

                        <input type="text" name="nama" class="form-control" placeholder="Masukkan nama lengkap"
                            required>

                    </div>

                    <div class="col-md-6 mb-3">

                        <label class="form-label">

                            Email

                        </label>

                        <input type="email" name="email" class="form-control" placeholder="Masukkan email" required>

                    </div>

                </div>

                <div class="row">

                    <div class="col-md-6 mb-3">

                        <label class="form-label">

                            Password

                        </label>

                        <input type="password" name="password" class="form-control" placeholder="Masukkan password"
                            required>

                    </div>

                    <div class="col-md-6 mb-3">

                        <label class="form-label">

                            Role

                        </label>

                        <select name="role" class="form-select" required>

                            <option value="">

                                -- Pilih Role --

                            </option>

                            <?php

                            $role = mysqli_query(
                                $conn,
                                "SELECT * FROM roles ORDER BY nama_role ASC"
                            );

                            while($r = mysqli_fetch_assoc($role)){

                            ?>

                            <option value="<?= $r['id']; ?>">

                                <?= htmlspecialchars($r['nama_role']); ?>

                            </option>

                            <?php } ?>

                        </select>

                    </div>

                </div>

                <hr>

                <button type="submit" name="simpan" class="btn btn-primary">

                    <i class="bi bi-save"></i>

                    Simpan

                </button>

                <a href="index.php" class="btn btn-secondary">

                    <i class="bi bi-x-circle"></i>

                    Batal

                </a>

            </form>

        </div>

    </div>

</div>

<?php include "../../templates/footer.php"; ?>