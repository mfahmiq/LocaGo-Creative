<?php
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

require "../../config/config.php";
require "../../config/koneksi.php";

// Ambil ID dari URL
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Ambil data user
$stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

if (!$user) {
    die("Data user tidak ditemukan.");
}

// Proses update
if (isset($_POST['update'])) {

    $nama     = trim($_POST['nama']);
    $email    = trim($_POST['email']);
    $role     = (int) $_POST['role'];
    $password = trim($_POST['password']);

    // Cek apakah email sudah dipakai user lain
    $cek = mysqli_prepare($conn, "SELECT id FROM users WHERE email=? AND id<>?");
    mysqli_stmt_bind_param($cek, "si", $email, $id);
    mysqli_stmt_execute($cek);
    $cekResult = mysqli_stmt_get_result($cek);

    if (mysqli_num_rows($cekResult) > 0) {

        echo "<script>
            alert('Email sudah digunakan user lain!');
            window.history.back();
        </script>";
        exit;
    }

    if ($password != "") {

        $hash = password_hash($password, PASSWORD_DEFAULT);

        $update = mysqli_prepare($conn,
            "UPDATE users
            SET
                nama=?,
                email=?,
                password=?,
                role_id=?
            WHERE id=?");

        mysqli_stmt_bind_param(
            $update,
            "sssii",
            $nama,
            $email,
            $hash,
            $role,
            $id
        );

    } else {

        $update = mysqli_prepare($conn,
            "UPDATE users
            SET
                nama=?,
                email=?,
                role_id=?
            WHERE id=?");

        mysqli_stmt_bind_param(
            $update,
            "ssii",
            $nama,
            $email,
            $role,
            $id
        );
    }

    if (mysqli_stmt_execute($update)) {

        header("Location: index.php?success=edit");
        exit;

    } else {

        die("Gagal update: " . mysqli_error($conn));

    }

}

include "../../templates/header.php";
include "../../templates/sidebar.php";
include "../../templates/navbar.php";
?>

<div class="container-fluid">

    <div class="card shadow">

        <div class="card-header">
            <h4>Edit User</h4>
        </div>

        <div class="card-body">

            <form method="POST">

                <div class="mb-3">

                    <label class="form-label">Nama</label>

                    <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($user['nama']) ?>"
                        required>

                </div>

                <div class="mb-3">

                    <label class="form-label">Email</label>

                    <input type="email" name="email" class="form-control"
                        value="<?= htmlspecialchars($user['email']) ?>" required>

                </div>

                <div class="mb-3">

                    <label class="form-label">Password Baru</label>

                    <input type="password" name="password" class="form-control">

                    <small class="text-muted">
                        Kosongkan jika tidak ingin mengubah password.
                    </small>

                </div>

                <div class="mb-3">

                    <label class="form-label">Role</label>

                    <select name="role" class="form-select" required>

                        <?php
                        $roles = mysqli_query($conn, "SELECT * FROM roles");

                        while ($r = mysqli_fetch_assoc($roles)) {
                        ?>

                        <option value="<?= $r['id'] ?>" <?= ($r['id'] == $user['role_id']) ? 'selected' : '' ?>>

                            <?= htmlspecialchars($r['nama_role']) ?>

                        </option>

                        <?php } ?>

                    </select>

                </div>

                <button type="submit" name="update" class="btn btn-success">

                    <i class="bi bi-check-circle"></i>
                    Update

                </button>

                <a href="index.php" class="btn btn-secondary">

                    <i class="bi bi-arrow-left"></i>
                    Kembali

                </a>

            </form>

        </div>

    </div>

</div>

<?php
include "../../templates/footer.php";
?>