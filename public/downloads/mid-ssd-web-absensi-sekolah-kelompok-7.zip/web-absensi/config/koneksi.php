<?php

require_once "config.php";

$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_absensi_sekolah";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}