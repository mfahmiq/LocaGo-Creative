<?php

// Konfigurasi dasar aplikasi
define('BASE_URL', 'http://localhost/web-absensi/');

// Timezone
date_default_timezone_set('Asia/Jakarta');