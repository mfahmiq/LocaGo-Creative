<div class="content">

    <nav class="navbar bg-white shadow-sm rounded mb-4">

        <div class="container-fluid">

            <h4 class="mb-0">
                Dashboard Administrator
            </h4>

            <div>

                <i class="bi bi-person-circle"></i>

                <?= htmlspecialchars($_SESSION['nama']) ?>

            </div>

        </div>

    </nav>