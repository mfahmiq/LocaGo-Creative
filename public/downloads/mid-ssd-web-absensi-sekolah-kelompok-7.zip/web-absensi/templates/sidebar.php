<div class="sidebar">

    <h3>ABSENSI</h3>

    <a href="<?= BASE_URL ?>admin/dashboard.php">
        <i class="bi bi-speedometer2"></i>
        Dashboard
    </a>

    <a href="<?= BASE_URL ?>admin/users/index.php">
        <i class="bi bi-person-circle"></i>
        User
    </a>

    <a href="<?= BASE_URL ?>admin/teachers/index.php">
        <i class="bi bi-person-badge"></i>
        Guru
    </a>

    <a href="<?= BASE_URL ?>admin/classes/index.php">
        <i class="bi bi-building"></i>
        Kelas
    </a>

    <a href="<?= BASE_URL ?>admin/subjects/index.php">
        <i class="bi bi-book"></i>
        Mata Pelajaran
    </a>

    <a href="<?= BASE_URL ?>admin/schedules/index.php">
        <i class="bi bi-calendar-week"></i>
        Jadwal
    </a>

    <a href="<?= BASE_URL ?>admin/attendances/index.php">
        <i class="bi bi-calendar-check"></i>
        Absensi
    </a>
    <li class="nav-item">
        <a href="<?= BASE_URL ?>admin/reports/index.php" class="nav-link">
            <i class="bi bi-file-earmark-text"></i>
            <span>Laporan Absensi</span>
        </a>
    </li>
    <hr class="text-white">

    <a href="<?= BASE_URL ?>auth/logout.php">
        <i class="bi bi-box-arrow-right"></i>
        Logout
    </a>

</div>