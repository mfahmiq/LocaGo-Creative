</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script src="https://cdn.datatables.net/2.3.2/js/dataTables.js"></script>

<script src="https://cdn.datatables.net/2.3.2/js/dataTables.bootstrap5.js"></script>

<script>
$(document).ready(function() {

    $('.datatable').DataTable({

        pageLength: 10,

        language: {

            url: "https://cdn.datatables.net/plug-ins/2.3.2/i18n/id.json"

        }

    });

});
</script>

</body>

</html>