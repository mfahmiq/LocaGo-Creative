# 📚 Sistem Informasi Absensi Sekolah Berbasis Web

Sistem Informasi Absensi Sekolah Berbasis Web merupakan aplikasi yang dibangun untuk membantu proses pengelolaan absensi siswa secara digital. Sistem ini memiliki tiga jenis pengguna, yaitu **Administrator**, **Guru**, dan **Siswa**, dengan hak akses yang berbeda sesuai perannya.

Proyek ini dibuat sebagai tugas mata kuliah **Scalable System Design (SSD)**.

# ✨ Fitur Sistem

## Administrator

- Login
- Dashboard
- Kelola User
- Kelola Guru
- Kelola Siswa
- Kelola Kelas
- Kelola Mata Pelajaran
- Kelola Jadwal
- Laporan Absensi
- Detail Laporan
- Export PDF
- Export Excel

## Guru

- Login
- Dashboard Guru
- Jadwal Mengajar
- Input Absensi
- Riwayat Absensi
- Detail Absensi
- Export PDF
- Export Excel

## Siswa

- Login
- Dashboard
- Melihat Riwayat Absensi

---

# 🛠 Teknologi yang Digunakan

- PHP Native
- MySQL
- Bootstrap 5
- HTML5
- CSS3
- JavaScript
- Apache (XAMPP)
- Git
- GitHub

---

# 📁 Struktur Folder

```
web-absensi/
│
├── admin/
├── guru/
├── siswa/
├── auth/
├── assets/
├── config/
├── templates/
├── database/
│   └── web_absensi.sql
│
├── README.md
└── index.php
```

---

# 🏗 Arsitektur Sistem

```
Browser
(Admin | Guru | Siswa)
        │
        ▼
Apache Web Server
(PHP Native)
        │
        ▼
MySQL Database
```

Sistem menggunakan konsep **Three Tier Architecture**, yaitu:

- Presentation Layer
- Application Layer
- Database Layer

---

# 🗄 Database

Database terdiri dari tabel:

- users
- teachers
- students
- classes
- subjects
- schedules
- attendance_sessions
- attendance_details

Seluruh tabel saling berhubungan menggunakan **Primary Key** dan **Foreign Key**.

---

# ⚙ Cara Instalasi

1. Install XAMPP.

2. Jalankan Apache dan MySQL.

3. Clone repository

```bash
git clone https://github.com/Wannn15/MID-SSD-Web-Absensi-Sekolah-Kelompok-7.git
```

4. Pindahkan project ke folder

```
htdocs/
```

5. Buat database

```
web_absensi
```

6. Import file

```
database/web_absensi.sql
```

7. Atur koneksi database pada

```
config/koneksi.php
```

---

# ▶ Cara Menjalankan

Buka browser

```
http://localhost/web-absensi
```

---

# 🔑 Akun Demo

## Administrator

Email

```
admin@gmail.com
```

Password

```
admin123
```


> Gunakan akun demo atau data dummy. Jangan menggunakan akun asli.

---

# 📈 Penerapan Scalable System Design

Konsep Scalable System Design diterapkan melalui:

- Pembagian modul berdasarkan peran pengguna.
- Struktur folder yang modular.
- Role Based Access Control (RBAC).
- Database relasional menggunakan Foreign Key.
- Penggunaan Prepared Statement.
- Pemisahan antara Web Server dan Database Server.
- Sistem mudah dikembangkan dengan penambahan modul baru.
- Siap dikembangkan menggunakan Load Balancer apabila jumlah pengguna meningkat.

---

# 📸 Screenshot

<img width="298" height="693" alt="image" src="https://github.com/user-attachments/assets/2c307607-8a2d-437a-abbb-290b7fb384d5" />
<img width="862" height="513" alt="image" src="https://github.com/user-attachments/assets/e3d10a2a-f183-4e43-93f4-2127be6806ef" />
<img width="862" height="424" alt="image" src="https://github.com/user-attachments/assets/fca3426e-68a7-49ce-9358-ca554febaeef" />
<img width="862" height="422" alt="image" src="https://github.com/user-attachments/assets/52eaf984-6b2c-432a-8dbc-9543ce552ecb" />
<img width="862" height="423" alt="image" src="https://github.com/user-attachments/assets/1a6dab99-f53a-4635-af4b-225ae2b11ae0" />
<img width="862" height="420" alt="image" src="https://github.com/user-attachments/assets/7fd62392-4316-438d-a8f2-86a8dc688d79" />
<img width="862" height="424" alt="image" src="https://github.com/user-attachments/assets/db9cdb4a-1eb4-436b-b101-0ed50c45ff6d" />
<img width="862" height="425" alt="image" src="https://github.com/user-attachments/assets/4b7aeba3-69aa-4ab9-bff7-3d432d2b6b1e" />
<img width="862" height="422" alt="image" src="https://github.com/user-attachments/assets/14141ae6-ea57-460c-8a92-b9918851731a" />
<img width="862" height="422" alt="image" src="https://github.com/user-attachments/assets/7c2d525e-d171-4c8a-a4b5-f9fce0e111d7" />
<img width="862" height="426" alt="image" src="https://github.com/user-attachments/assets/cb709ac9-fb50-4cca-8887-f721cf8c5b61" />
<img width="508" height="214" alt="image" src="https://github.com/user-attachments/assets/7d4b4262-61d7-42f7-802c-2d2386fb0925" />

---

# 🎥 Video Presentasi

https://youtu.be/ISI_LINK_VIDEO_ANDA

---

# 💻 Repository GitHub

https://github.com/Wannn15/MID-SSD-Web-Absensi-Sekolah-Kelompok-7

---

# 📄 Lisensi

Proyek ini dibuat untuk memenuhi tugas mata kuliah **Scalable System Design**.
