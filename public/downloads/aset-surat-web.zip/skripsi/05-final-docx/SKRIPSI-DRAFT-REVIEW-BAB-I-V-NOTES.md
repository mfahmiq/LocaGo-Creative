# SKRIPSI DRAFT REVIEW BAB I-V NOTES

Tanggal dibuat: 2026-07-05

## 1. Status

`SKRIPSI-DRAFT-REVIEW-BAB-I-V.docx` adalah **DRAFT REVIEW**, bukan dokumen final. Dokumen ini digabungkan langsung dari berkas Markdown BAB I sampai BAB V yang sudah tersedia sebagai final arah atau draft revisi, tanpa mengubah substansi. Dokumen ini belum boleh dikumpulkan sebagai naskah resmi ke pembimbing atau kampus.

Dokumen dibuat secara terprogram menggunakan Python (`python-docx`) untuk mengonversi Markdown menjadi format Word (OOXML) apa adanya, termasuk seluruh tabel dan marker. Tidak ada isi yang dikarang di luar isi kelima berkas Markdown sumber; halaman sampul hanya berisi banner status dan ringkasan metadata (bukan lembar judul resmi kampus).

## 2. File Sumber

1. `skripsi/03-draft-bab/BAB-I-FINAL-ARAH.md`
2. `skripsi/03-draft-bab/BAB-II-FINAL-ARAH-REFPATCH-1.md` (kandidat BAB II terbaru, sudah memuat referensi jurnal ke-10)
3. `skripsi/03-draft-bab/BAB-III-REVISI-1.md`
4. `skripsi/03-draft-bab/BAB-IV-REVISI-1.md`
5. `skripsi/03-draft-bab/BAB-V-REVISI-1.md`

Dibaca juga sebagai referensi format: `DOCX-READINESS-CHECK-UPDATED.md`, `BAB-I-SAMPAI-V-DRAFT-REVIEW-CHECK-UPDATED.md`, `DOCX_FORMAT_SPEC.md`, dan `PEDOMAN_AUDIT.md`. File `PEDOMAN-UBSI-2026-RINGKASAN-PROYEK.md` tetap **BELUM ADA**.

## 3. Marker Yang Masih Ada

Jumlah marker asli pada berkas Markdown sumber (sebelum ditambah banner status):

- BAB I: 6 (`[PERLU DATA]` x1, `[PERLU CEK REFERENSI]` x5)
- BAB II: 1 (`[PERLU CEK APA 7]` x1)
- BAB III: 3 (`[PERLU DATA]` x3)
- BAB IV: 18 (`[PERLU DATA]` x5, `[PERLU CEK SCREENSHOT]` x5, `[PERLU DATA HASIL PENGUJIAN]` x7, `[PERLU CEK BUKTI KODE]` x1)
- BAB V: 2 (`[PERLU CEK SETELAH BAB IV FINAL]` x2)
- **Total: 30 marker**

Seluruh marker di atas dipertahankan apa adanya di dalam DOCX (tidak dihapus, tidak diubah menjadi teks lain). Verifikasi otomatis pada file DOCX hasil (menghitung kemunculan literal string setiap marker, termasuk 1 kemunculan tambahan per jenis marker pada halaman banner status di awal dokumen) menunjukkan seluruh 30 marker plus rujukan pada halaman banner tetap terlihat utuh, tanpa satu pun yang hilang.

## 4. Catatan Referensi

1. Jumlah jurnal ilmiah pada `BAB-II-FINAL-ARAH-REFPATCH-1.md` sudah **10**, memenuhi syarat minimal 10 jurnal pada pedoman UBSI (`PEDOMAN_AUDIT.md`) dengan catatan.
2. Semua referensi (termasuk jurnal ke-10 Usnaini, Yasin, & Sianipar 2021) tetap perlu dicek dan dimasukkan ke Mendeley dengan gaya APA 7.
3. Daftar pustaka final belum boleh dianggap selesai — beberapa referensi masih berstatus PERLU CEK atau BELUM LENGKAP metadatanya (lihat `REFERENSI-APA7-MENDELEY-CHECK-UPDATED.md`).
4. Dokumen DOCX ini tidak memuat halaman Daftar Pustaka tersendiri karena daftar pustaka final belum disusun; sitasi yang muncul hanya sitasi dalam teks (in-text) sebagaimana tertulis di BAB II.

## 5. Catatan Finalisasi

Data yang masih perlu dilengkapi sebelum naskah ini dapat dianggap mendekati final:

1. Profil resmi SMPI REJIS.
2. Sejarah SMPI REJIS.
3. Struktur organisasi SMPI REJIS.
4. 5 screenshot halaman tertentu (manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, cetak laporan).
5. Pengukuran waktu respons kinerja dasar (BAB IV 4.3 Testing).
6. Spesifikasi hardware pengembangan.
7. Potongan kode tambahan untuk modul aset, transaksi, surat, laporan, dan backup (BAB IV 4.2 Code Generation).
8. Pengecekan Mendeley APA 7 untuk seluruh referensi BAB II.
9. Pengecekan format akhir DOCX sesuai pedoman UBSI secara lengkap: lembar judul resmi, lembar pernyataan, daftar isi, daftar gambar, daftar tabel, daftar lampiran, watermark, dan penomoran halaman awal/bab (belum diterapkan pada draft review ini karena sebagian ketentuan tersebut masih dicatat sebagai `[BELUM DAPAT DIPASTIKAN]` pada `DOCX_FORMAT_SPEC.md`).

Catatan tambahan mengenai penerapan format pada draft review ini: ukuran kertas A4, margin (atas 3 cm, kiri 4 cm, bawah 2,5 cm, kanan 2,5 cm), font Times New Roman 12, spasi isi 2, judul BAB (tengah, kapital, tebal, 14), judul subbab/sub-subbab (tebal, 12), serta tabel dengan garis kisi sudah diterapkan. Nomor gambar/tabel eksplisit bergaya "Gambar IV.1"/"Tabel IV.1" belum ditambahkan secara seragam di luar teks yang sudah ada pada Markdown sumber, karena urutan gambar/tabel final belum dikunci (`DOCX_FORMAT_SPEC.md` bagian Caption Tabel dan Gambar). Diagram dan screenshot yang dirujuk dalam teks belum disisipkan sebagai gambar biner ke dalam DOCX ini; keduanya masih berupa rujukan path berkas sebagaimana tertulis di BAB IV.

## 6. Keputusan

DOCX draft review boleh digunakan untuk dibaca dan dikoreksi oleh user dan Maestro, tetapi **belum boleh dikumpulkan sebagai final**.
