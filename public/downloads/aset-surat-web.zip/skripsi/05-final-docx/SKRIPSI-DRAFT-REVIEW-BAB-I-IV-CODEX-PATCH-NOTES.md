# SKRIPSI DRAFT REVIEW BAB I-IV CODEX PATCH NOTES

Tanggal dibuat: 2026-07-05

## 1. Status

Dokumen `SKRIPSI-DRAFT-REVIEW-BAB-I-IV-CODEX-PATCH.md` (dan versi DOCX-nya jika berhasil dibuat) adalah **draft review**, bukan final. Dokumen ini digabungkan langsung dari 4 berkas Markdown BAB I-IV terbaru tanpa mengubah substansi, ditambah banner status dan ringkasan sumber di bagian awal.

## 2. File Sumber

1. BAB I: `skripsi/03-draft-bab/BAB-I-FINAL-ARAH-DATAPATCH-2.md`
2. BAB II: `skripsi/03-draft-bab/BAB-II-FINAL-ARAH-REFPATCH-1.md`
3. BAB III: `skripsi/03-draft-bab/BAB-III-REVISI-1-DATAPATCH-2.md`
4. BAB IV: `skripsi/03-draft-bab/BAB-IV-REVISI-1-CODEX-EVIDENCEPATCH-1.md`

BAB V sengaja tidak disertakan sesuai instruksi kerja.

## 3. Bukti Codex Yang Digunakan

Bukti yang diklaim berasal dari sesi Codex sudah dibaca dan direkonsiliasi (lihat `CODEX-EVIDENCE-RECONCILIATION.md`, `SCREENSHOT-INVENTORY-CHECK-CODEX.md`, `BLACKBOX-TESTING-RECONCILIATION-CODEX.md`). Ringkasan temuan:

1. Berkas `APPLICATION_VERIFICATION.md`, `BLACKBOX_TEST_SCENARIOS.md`, dan `BAB_IV_EVIDENCE_READINESS.md` **tidak berubah sejak 2026-07-04** berdasarkan timestamp berkas — tidak ada pembaruan baru pada 2026-07-05.
2. Folder screenshot **tidak bertambah** — tetap 22 berkas, seluruhnya bertimestamp 2026-07-04. Klaim "10 screenshot baru" tidak dapat diverifikasi.
3. Angka black-box testing "23 valid, 19 belum diverifikasi" yang disebut sebagai hasil Codex ternyata adalah checkpoint yang **sudah digantikan** di dalam berkas yang sama oleh checkpoint berikutnya (42 valid, 0 gagal, 0 belum diverifikasi, setelah pengujian CRUD terkontrol). BAB IV pada naskah ini tetap memakai checkpoint 42 valid karena itu yang tercatat sebagai hasil terbaru di berkas.
4. Karena tidak ada bukti baru yang terverifikasi, **tidak ada marker tambahan yang diselesaikan** pada rekonsiliasi kali ini dibandingkan `BAB-IV-REVISI-1-EVIDENCEPATCH-3.md`.

## 4. Marker Yang Masih Ada

Total marker logis pada naskah gabungan BAB I-IV ini: **17** (BAB I = 1, BAB II = 1, BAB III = 3, BAB IV = 12). Total proyek BAB I-V tetap **19** jika BAB V ikut dihitung, karena BAB V memiliki 2 marker `[PERLU CEK SETELAH BAB IV FINAL]` dan tidak disertakan dalam naskah gabungan ini. Rincian BAB I-IV:

- `[PERLU DATA]`: 4 (1 BAB I — observasi; 3 BAB III — profil, sejarah, struktur organisasi).
- `[PERLU CEK APA 7]`: 1 (BAB II — subbab 2.1.11 LRS).
- `[PERLU CEK SCREENSHOT]`: 5 (BAB IV 4.1.3 — manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, cetak laporan).
- `[PERLU DATA HASIL PENGUJIAN]`: 7 (BAB IV 4.3 — 6 proses pengukuran waktu respons + 1 kalimat penutup).

(Catatan BAB V dengan 2 marker `[PERLU CEK SETELAH BAB IV FINAL]` tidak dihitung karena BAB V tidak termasuk dalam naskah gabungan ini.)

## 5. Catatan Penting

1. Data sekolah (profil, sejarah, struktur organisasi SMPI REJIS, detail observasi) belum tersedia — masih ditandai marker `[PERLU DATA]` pada BAB I dan BAB III.
2. Waktu respons kinerja dasar belum tersedia — masih ditandai marker `[PERLU DATA HASIL PENGUJIAN]` pada BAB IV.
3. Mendeley APA 7 belum final untuk seluruh referensi BAB II, termasuk marker `[PERLU CEK APA 7]` pada subbab LRS.
4. DOCX final belum boleh dibuat — dokumen ini dan versi DOCX-nya (jika ada) tetap berstatus draft review.
5. User perlu mengecek manual hasil gabungan BAB I sampai BAB IV ini, terutama karena rekonsiliasi bukti Codex menemukan bahwa klaim pembaruan (screenshot baru dan hasil pengujian baru) belum terverifikasi di workspace — mohon konfirmasi apakah pekerjaan Codex tersebut sudah benar-benar tersimpan.
