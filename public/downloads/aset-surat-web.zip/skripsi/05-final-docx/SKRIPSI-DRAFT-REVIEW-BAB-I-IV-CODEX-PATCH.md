# DRAFT REVIEW BAB I-IV — BUKAN DOKUMEN FINAL

Tanggal disusun: 2026-07-05

Dokumen ini adalah naskah gabungan BAB I sampai BAB IV, disusun dari berkas Markdown terbaru yang sudah melalui beberapa tahap patch (final arah, revisi, data patch, dan evidence patch, termasuk rekonsiliasi bukti Codex). Dokumen ini **bukan naskah final** dan **masih perlu direview oleh user** sebelum dianggap siap untuk tahap berikutnya. Seluruh marker yang masih ada (`[PERLU DATA]`, `[PERLU CEK SCREENSHOT]`, `[PERLU DATA HASIL PENGUJIAN]`, `[PERLU CEK APA 7]`) sengaja dipertahankan agar terlihat jelas bagian mana yang masih membutuhkan data atau verifikasi lebih lanjut.

Berkas sumber:

1. BAB I: `BAB-I-FINAL-ARAH-DATAPATCH-2.md`
2. BAB II: `BAB-II-FINAL-ARAH-REFPATCH-1.md`
3. BAB III: `BAB-III-REVISI-1-DATAPATCH-2.md`
4. BAB IV: `BAB-IV-REVISI-1-CODEX-EVIDENCEPATCH-1.md`

BAB V tidak disertakan dalam naskah ini sesuai instruksi kerja.

---

# BAB I

# PENDAHULUAN

Status dokumen: data patch 2 dari `BAB-I-FINAL-ARAH-DATAPATCH-1.md`. Pada putaran pengisian data kedua ini (`USER-DATA-INPUT-ROUND-2.md`), seluruh field data observasi (detail, tanggal, pihak yang ditemui) masih berupa placeholder kosong, sama seperti putaran pertama. Sesuai instruksi dan hasil validasi, marker `[PERLU DATA]` pada bagian observasi **dipertahankan tanpa perubahan** karena belum ada data nyata untuk menggantikannya. Tidak ada substansi lain yang diubah pada patch ini. Kandidat BAB I terbaru, belum menjadi naskah final DOCX.

## 1.1. Latar Belakang

Pengelolaan administrasi sekolah perlu didukung oleh pencatatan yang rapi, mudah ditelusuri, dan dapat digunakan kembali saat dibutuhkan. Pada lingkungan sekolah, administrasi tidak hanya berhubungan dengan kegiatan pembelajaran, tetapi juga mencakup pengelolaan inventaris aset, pencatatan surat masuk, proses disposisi, pengarsipan surat, penyusunan surat keluar, dan pembuatan laporan. Sistem Informasi (Information System) berbasis web dapat digunakan untuk membantu penyimpanan data secara terpusat dan mendukung proses pencarian data agar lebih terstruktur (Wahyuni, Muthmainnah, Permana, & Novalima, 2025).

SMPI REJIS menjadi objek penelitian dalam penyusunan skripsi ini. Berdasarkan transkrip wawancara penelitian, wawancara dilakukan pada 27 April 2026 dengan Wakil Kepala Sekolah Bidang Kesiswaan SMPI REJIS, yaitu Gilang Ramadhan S.Kom. atau Ust. Gilang. Wawancara tersebut digunakan untuk mengetahui kondisi pengelolaan inventaris aset dan pengelolaan surat yang berjalan di sekolah.

Berdasarkan hasil wawancara, pengelolaan inventaris aset di SMPI REJIS masih dilakukan secara manual menggunakan buku. Pencatatan menggunakan Microsoft Excel pernah dicoba, tetapi tidak berlanjut. Kondisi tersebut menyebabkan data barang masuk, barang keluar, dan peminjaman aset belum terdokumentasi secara konsisten. Data aset yang seharusnya dapat ditelusuri, seperti letak barang dan riwayat peminjaman, belum tersusun dalam satu sistem yang terpusat.

Permasalahan inventaris aset juga terlihat pada pengelompokan aset. Aset belum dikelompokkan secara jelas berdasarkan kategori, lokasi, dan kondisi barang. Dalam praktiknya, aset yang dipinjam dapat tidak kembali ke tempat semula sehingga sekolah mengalami kesulitan ketika perlu mengetahui keberadaan barang. Kondisi ini menunjukkan bahwa sekolah membutuhkan sistem yang mampu mencatat data aset, lokasi aset, status penggunaan, serta transaksi peminjaman dan pengembalian aset secara lebih teratur.

Pengelolaan surat di SMPI REJIS juga masih dilakukan secara manual. Pencatatan surat masuk belum terintegrasi dalam sistem terpusat, sedangkan arsip surat masuk dan surat keluar masih tersimpan secara terpisah. Kondisi tersebut dapat menyulitkan pencarian kembali dokumen dan pemantauan status tindak lanjut surat. Pada proses disposisi, arahan dari kepala sekolah atau wakil kepala sekolah kepada staf belum didukung mekanisme pemantauan yang terstruktur sehingga status penyelesaian surat belum mudah dikontrol.

Berdasarkan kondisi tersebut, diperlukan sistem terintegrasi inventaris aset dan disposisi surat berbasis web. Sistem terintegrasi diperlukan agar pengelolaan aset, transaksi peminjaman aset, surat masuk, disposisi surat, surat keluar, laporan, dan backup dapat berada dalam satu aplikasi. Dengan adanya sistem tersebut, data administrasi sekolah dapat disimpan lebih rapi, proses pencarian data dapat dilakukan lebih mudah, dan laporan dapat disusun berdasarkan data yang tercatat pada aplikasi.

Sistem yang dirancang dalam penelitian ini menggunakan CodeIgniter 4 sebagai *framework* pengembangan aplikasi dan MySQL/MariaDB sebagai basis data. Pemilihan teknologi tersebut dibahas sebagai bagian dari implementasi aplikasi, sedangkan penelitian ini tetap berfokus pada perancangan sistem dan kesesuaian fitur dengan kebutuhan administrasi SMPI REJIS. Aplikasi dikembangkan dan diuji pada lingkungan lokal menggunakan Laragon, sehingga penelitian ini tidak menulis klaim penerapan produksi, penerapan daring, atau penggunaan resmi pada server sekolah.

Model pengembangan sistem yang digunakan adalah Agile Scrum. Scrum digunakan karena kebutuhan aplikasi dapat dibagi ke dalam beberapa kelompok pekerjaan, seperti autentikasi, dashboard, manajemen pengguna, inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup. Dalam penelitian ini, Scrum dijelaskan sebagai pendekatan iteratif untuk menyusun kebutuhan ke dalam *product backlog*, memetakan pekerjaan ke dalam *sprint*, menghasilkan modul aplikasi, dan mengevaluasi fitur melalui pengujian (Scrum Guide, 2020).

Pengujian sistem dalam penelitian ini mencakup *black-box testing*, pengujian keamanan dasar, dan pengujian kinerja dasar. *Black-box testing* digunakan untuk memeriksa kesesuaian fungsi aplikasi berdasarkan masukan dan keluaran. Pengujian keamanan dasar digunakan untuk memeriksa mekanisme autentikasi, otorisasi, validasi input, sesi pengguna, unggah file, dan akses halaman. Pengujian kinerja dasar digunakan untuk memeriksa waktu respons halaman dan proses utama pada lingkungan lokal. Detail skenario dan hasil pengujian dibahas pada BAB IV (ISTQB Glossary).

Dengan demikian, penelitian ini diarahkan untuk merancang sistem yang dapat mendukung pengelolaan administrasi aset dan surat pada SMPI REJIS secara lebih terstruktur. Sistem yang dirancang tidak dimaksudkan untuk menggantikan seluruh prosedur administrasi sekolah, tetapi menjadi alat bantu pencatatan, pengolahan data, pemantauan status, dan penyusunan laporan berdasarkan fitur yang tersedia pada aplikasi.

## 1.2. Identifikasi Masalah

Berdasarkan latar belakang tersebut, permasalahan pada penelitian ini dapat diidentifikasi sebagai berikut:

1. Proses pencatatan inventaris aset masih dilakukan secara manual sehingga pencarian data membutuhkan waktu lebih lama dan berisiko menimbulkan kesalahan pencatatan.
2. Data barang masuk, barang keluar, dan peminjaman aset belum terdokumentasi secara konsisten sehingga riwayat penggunaan aset sulit ditelusuri.
3. Pengelompokan aset berdasarkan kategori, lokasi, dan kondisi barang belum tersusun secara terstruktur.
4. Lokasi dan status aset sulit dipantau karena belum tersedia sistem yang dapat mencatat pergerakan atau peminjaman aset.
5. Pencatatan surat masuk masih dilakukan secara manual sehingga berisiko menimbulkan keterlambatan pengolahan informasi.
6. Arsip surat tersimpan secara terpisah sehingga pencarian kembali dokumen belum efisien.
7. Disposisi surat belum memiliki mekanisme pemantauan yang terstruktur sehingga tindak lanjut surat belum dapat dikontrol dengan baik.

## 1.3. Perumusan Masalah

Berdasarkan identifikasi masalah tersebut, rumusan masalah dalam penelitian ini adalah sebagai berikut:

1. Bagaimana merancang sistem terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS?
2. Bagaimana sistem dapat membantu pengelolaan inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup secara terstruktur?
3. Bagaimana penerapan Agile Scrum dalam pengembangan sistem inventaris aset dan disposisi surat berbasis web?
4. Bagaimana hasil pengujian sistem melalui *black-box testing*, pengujian keamanan dasar, dan pengujian kinerja dasar terhadap fungsi utama aplikasi?
5. Apakah sistem yang dirancang dapat mendukung kebutuhan administrasi aset dan surat pada SMPI REJIS?

## 1.4. Tujuan dan Manfaat

Tujuan dan manfaat penelitian digunakan untuk menjelaskan arah perancangan sistem serta kontribusi yang diharapkan dari hasil penelitian.

### 1.4.1. Tujuan Penelitian

Tujuan penelitian ini adalah sebagai berikut:

1. Merancang sistem terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS.
2. Membangun aplikasi yang mendukung pengelolaan pengguna, inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup.
3. Menerapkan Agile Scrum sebagai pendekatan pengembangan sistem melalui pemetaan kebutuhan, *product backlog*, *sprint mapping*, implementasi modul, dan evaluasi fitur.
4. Melakukan pengujian sistem menggunakan *black-box testing*, pengujian keamanan dasar, dan pengujian kinerja dasar.
5. Menghasilkan sistem yang dapat mendukung pengelolaan administrasi aset dan surat secara lebih terstruktur.

### 1.4.2. Manfaat Penelitian

Manfaat penelitian ini adalah sebagai berikut:

1. Bagi penulis

   Penelitian ini bermanfaat untuk menambah pemahaman dan keterampilan dalam perancangan sistem informasi berbasis web, penerapan CodeIgniter 4, pengelolaan basis data MySQL/MariaDB, penggunaan Agile Scrum, serta pengujian sistem. Penelitian ini juga menjadi salah satu bentuk penerapan ilmu yang diperoleh selama menempuh Program Studi Teknologi Informasi pada Universitas Bina Sarana Informatika.

2. Bagi SMPI REJIS

   Penelitian ini bermanfaat sebagai rancangan sistem yang dapat membantu pengelolaan inventaris aset, transaksi peminjaman aset, pencatatan surat masuk, disposisi surat, surat keluar, pengarsipan, laporan, dan backup. Sistem yang dirancang diharapkan dapat membantu sekolah dalam menyusun data administrasi secara lebih terpusat dan mudah ditelusuri.

3. Bagi pembaca atau peneliti selanjutnya

   Penelitian ini dapat menjadi referensi mengenai perancangan sistem administrasi sekolah berbasis web, khususnya yang mengintegrasikan pengelolaan inventaris aset dan disposisi surat. Penelitian ini juga dapat menjadi gambaran awal mengenai penerapan Agile Scrum pada pengembangan aplikasi administrasi sekolah.

## 1.5. Metode Penelitian

Metode penelitian pada skripsi ini mencakup teknik pengumpulan data dan model pengembangan sistem. Teknik pengumpulan data digunakan untuk memperoleh informasi mengenai kondisi berjalan dan kebutuhan sistem, sedangkan model pengembangan sistem digunakan untuk menjelaskan tahapan pembangunan aplikasi.

### 1.5.1. Teknik Pengumpulan Data

Teknik pengumpulan data yang digunakan dalam penelitian ini adalah sebagai berikut:

1. Observasi

   Observasi dilakukan untuk memahami proses administrasi yang berjalan, khususnya pengelolaan inventaris aset dan pengelolaan surat. Observasi juga diarahkan untuk memahami kebutuhan fitur aplikasi yang berhubungan dengan pencatatan aset, peminjaman aset, surat masuk, disposisi, surat keluar, laporan, dan backup. Detail pelaksanaan observasi, seperti waktu dan bentuk observasi langsung, masih perlu dilengkapi dari bukti riset. [PERLU DATA]

2. Wawancara

   Wawancara dilakukan dengan Wakil Kepala Sekolah Bidang Kesiswaan SMPI REJIS, yaitu Gilang Ramadhan S.Kom. atau Ust. Gilang, pada 27 April 2026. Wawancara digunakan untuk memperoleh informasi mengenai kondisi pengelolaan inventaris aset, pengelolaan surat, kendala yang terjadi, dan kebutuhan sistem yang diharapkan oleh pihak sekolah.

3. Studi pustaka

   Studi pustaka dilakukan dengan mempelajari buku, jurnal ilmiah, dan referensi lain yang berkaitan dengan Sistem Informasi, website, inventaris aset, surat, disposisi surat, basis data MySQL, PHP, CodeIgniter, UML, ERD, LRS, Agile Scrum, dan *black-box testing*. Referensi yang digunakan harus mengikuti pedoman penulisan, menggunakan gaya APA 7 melalui Mendeley, dan tidak berasal dari Blogspot, Wordpress, atau Wikipedia, sebagaimana telah dikumpulkan dan diverifikasi pada kajian teori BAB II (lihat `BAB-II-FINAL-ARAH-REFPATCH-1.md`).

### 1.5.2. Model Pengembangan Sistem

Model pengembangan sistem yang digunakan dalam penelitian ini adalah Agile Scrum. Scrum merupakan model pengembangan perangkat lunak yang bersifat iteratif dan bertahap. Model ini membagi kebutuhan sistem ke dalam daftar kebutuhan atau *product backlog*, kemudian memilih pekerjaan yang akan dikerjakan dalam *sprint* sesuai prioritas pengembangan (Scrum Guide, 2020).

Penerapan Scrum dalam penelitian ini disesuaikan dengan kebutuhan sistem inventaris aset dan disposisi surat berbasis web pada SMPI REJIS. Kebutuhan sistem disusun berdasarkan hasil wawancara, observasi, studi pustaka, dan audit aplikasi. Kebutuhan tersebut kemudian dipetakan ke dalam modul utama, yaitu autentikasi, dashboard, manajemen pengguna, inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup.

Pada BAB I, pembahasan Scrum ditulis secara ringkas agar tidak mendahului uraian implementasi. Detail *product backlog*, *sprint backlog*, *sprint mapping*, hasil increment, implementasi modul, dan evaluasi fitur akan dibahas pada BAB IV bersama hasil pengujian. Penelitian ini tidak menuliskan tanggal *sprint*, nama Scrum Master, Product Owner, Daily Scrum, Sprint Review, atau Sprint Retrospective sebagai fakta historis apabila bukti rinci belum tersedia.

## 1.6. Ruang Lingkup

Ruang lingkup penelitian ini dibatasi pada perancangan sistem terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS. Aplikasi dikembangkan menggunakan CodeIgniter 4 dengan basis data MySQL/MariaDB dan diuji pada lingkungan lokal menggunakan Laragon. Penelitian ini tidak membahas penerapan produksi, penerapan daring, atau penggunaan resmi pada server sekolah.

Pengguna sistem mengikuti peran yang tersedia pada aplikasi, yaitu admin, operator, dan pimpinan. Dalam konteks operasional sekolah, peran tersebut dapat dipadankan dengan admin atau operator administrasi dan pimpinan sekolah sesuai kebutuhan hak akses.

Fitur yang dibahas dalam penelitian ini mencakup:

1. Login dan autentikasi pengguna.
2. Dashboard.
3. Manajemen pengguna.
4. Inventaris aset.
5. Transaksi atau peminjaman aset.
6. Surat masuk.
7. Disposisi surat.
8. Surat keluar.
9. Laporan.
10. Backup.

Pengujian sistem mencakup *black-box testing*, pengujian keamanan dasar, dan pengujian kinerja dasar. Pengujian keamanan dasar dibatasi pada pemeriksaan autentikasi, pembatasan hak akses berdasarkan peran, akses halaman tanpa login, akses langsung ke URL tertentu sesuai peran, logout dan sesi pengguna, validasi input pada form penting, unggah file atau lampiran dummy, serta route dan menu ERD yang tidak ditampilkan sebagai fitur operasional. Pengujian kinerja dasar dibatasi pada pemeriksaan waktu respons halaman dan proses utama pada lingkungan lokal, seperti halaman login, dashboard, data aset, surat masuk, pencarian atau filter, simpan data uji, pembuatan laporan, CSV, PDF, dan backup database.

Penelitian ini tidak mencakup integrasi dengan sistem eksternal, tanda tangan digital, email otomatis, penerapan multi-sekolah, *penetration testing*, *load testing*, *stress testing*, benchmark server produksi, atau audit keamanan tingkat lanjut. ERD digunakan sebagai artefak perancangan dan dokumentasi skripsi, bukan sebagai fitur operasional aplikasi.

---

# BAB II

# LANDASAN TEORI

Status dokumen: patch referensi 1 dari `BAB-II-FINAL-ARAH.md`, ditambahkan sitasi Usnaini, Yasin, dan Sianipar (2021) pada 2.1.3 dan 2.2 untuk memenuhi kebutuhan minimal 10 jurnal. Kandidat BAB II terbaru, belum menjadi naskah final DOCX.

## 2.1. Tinjauan Pustaka

### 2.1.1. Sistem Informasi

Sistem informasi adalah seperangkat komponen yang mengelola data menjadi informasi untuk mendukung proses pengambilan keputusan dan operasional organisasi. Dalam konteks sekolah, sistem informasi membantu mencatat, menyimpan, mengolah, dan menyajikan data administrasi yang melibatkan aset, surat, dan aktivitas layanan sekolah. Sistem informasi sekolah yang baik mengintegrasikan manusia, prosedur, data, perangkat lunak, perangkat keras, dan komunikasi agar informasi dapat dihasilkan secara teratur dan dapat digunakan kembali.

Di lingkungan administrasi sekolah, sistem informasi diperlukan untuk mengurangi ketergantungan pada catatan manual, mempercepat pencarian data, serta meningkatkan konsistensi dan keterandalan informasi. Annisa, Rahayuningsih, dan Anna (2023) menunjukkan bahwa sistem informasi inventaris berbasis web dapat membantu sekolah mengelola data sarana dan prasarana yang sebelumnya tersimpan dalam buku atau spreadsheet. Pendekatan ini relevan bagi SMPI REJIS karena kebutuhan pengelolaan aset dan surat belum tersentralisasi.

Sistem informasi tidak hanya berfungsi sebagai media pencatatan, tetapi juga sebagai alat bantu dalam proses pemantauan dan pelaporan. Dengan adanya sistem informasi sekolah berbasis web, pelaku administrasi dapat memperoleh gambaran kondisi aset, riwayat peminjaman, dan status tindak lanjut surat dalam bentuk informasi yang mudah diolah.

### 2.1.2. Website

Website adalah media aplikasi yang dapat diakses melalui peramban web pada perangkat yang terhubung ke jaringan. Website memungkinkan penyajian halaman dan formulir yang dapat diisi, ditampilkan, dan diperbarui secara dinamis. Untuk sistem administrasi sekolah, website menjadi pilihan yang tepat karena dapat diakses dari berbagai perangkat tanpa perlu instalasi aplikasi khusus.

Pengembangan aplikasi berbasis website menawarkan keuntungan seperti akses data terpusat, kemudahan pembaruan, dan fleksibilitas penggunaan. Annisa, Rahayuningsih, dan Anna (2023) menjelaskan bahwa sistem inventaris berbasis web memudahkan sekolah dalam mengelola informasi secara online dan meningkatkan keterpaduan data. Mubarok dan Sutaji (2025) menambahkan bahwa aplikasi web membantu pemantauan aset dan pelaporan dengan interface yang dapat diakses oleh pengguna berwenang.

Website bagi lembaga sekolah memungkinkan pengelolaan data inventaris dan disposisi surat secara terpadu. Dengan akses melalui peramban, pengguna dapat melakukan pencatatan, pencarian, dan pelaporan dari satu platform yang sama.

### 2.1.3. Inventaris Aset

Inventaris aset adalah kegiatan pencatatan dan pengelolaan barang yang dimiliki oleh organisasi atau institusi. Di sekolah, inventaris aset mencakup sarana dan prasarana seperti meja, kursi, komputer, proyektor, dan perangkat laboratorium. Pengelolaan inventaris yang baik mencakup pencatatan kategori aset, lokasi penyimpanan, kondisi barang, status penggunaan, riwayat peminjaman, dan pembuatan laporan.

Inventaris aset tidak hanya melibatkan daftar barang, tetapi juga memerlukan data yang konsisten tentang peminjaman dan pengembalian. Annisa, Rahayuningsih, dan Anna (2023) menyatakan bahwa pencatatan yang masih menggunakan buku atau spreadsheet menyebabkan proses pencarian data lambat dan rentan kehilangan data. Pranoto dan Sediyono (2021) memperkuat bahwa sistem informasi inventaris berbasis web mampu memperbaiki manajemen barang, pemantauan lokasi, dan penyusunan laporan.

Mubarok dan Sutaji (2025) menunjukkan bahwa sistem inventaris aset kantor berbasis web penting untuk meningkatkan efektivitas pengelolaan aset, khususnya pada pencatatan peminjaman dan monitoring aset. Usnaini, Yasin, dan Sianipar (2021) membahas bahwa pengelolaan inventaris aset sekolah yang masih dilakukan secara manual dapat menimbulkan kendala dalam pencarian data, kelengkapan arsip, dan penyusunan laporan. Oleh karena itu, sistem informasi inventarisasi aset berbasis web diperlukan untuk membantu pencatatan, pengelolaan, dan penyajian laporan aset secara lebih terstruktur. Untuk SMPI REJIS, perancangan sistem inventaris aset diperlukan agar data barang dapat dilacak, status aset dipantau, dan laporan disusun secara akurat.

### 2.1.4. Surat

Surat adalah media komunikasi tertulis yang digunakan untuk menyampaikan informasi secara resmi. Surat masuk dan surat keluar merupakan bagian penting dari administrasi sekolah karena dokumen tersebut menjadi bukti kegiatan, permohonan, atau pemberitahuan. KBBI mendefinisikan surat sebagai dokumen tertulis yang disampaikan dari satu pihak kepada pihak lain dengan tujuan tertentu, sedangkan Undang-Undang Nomor 43 Tahun 2009 tentang Kearsipan menempatkan arsip sebagai rekaman kegiatan atau peristiwa dalam berbagai bentuk media yang dibuat dan diterima oleh lembaga.

Dalam administrasi sekolah, surat perlu dicatat secara terstruktur dan diarsipkan agar dapat ditemukan kembali ketika dibutuhkan. Surat masuk yang diterima oleh sekolah harus didokumentasikan dengan informasi tanggal, pengirim, nomor surat, perihal, dan penerima internal. Pencatatan surat keluar juga penting untuk melacak dokumen yang telah dikirim. Apabila pencatatan surat dilakukan secara manual, risiko kehilangan dokumen dan keterlambatan tindak lanjut menjadi lebih besar.

Arsip surat memungkinkan penyimpanan dokumen administratif secara sistematis. Dengan sistem berbasis web, arsip surat dapat tersimpan secara digital sehingga pencarian ulang dan pelaporan menjadi lebih cepat dan terstruktur.

### 2.1.5. Disposisi Surat

Disposisi surat adalah proses pemberian arahan, instruksi, atau tindak lanjut terhadap surat masuk. Proses disposisi bertujuan memastikan bahwa surat yang diterima ditangani oleh pihak yang tepat dan tindak lanjutnya dapat dimonitor. Disposisi surat melibatkan penentuan penerima disposisi, status tindak lanjut, dan tanggal penyelesaian.

Sistem disposisi surat berbasis web membantu memantau status surat masuk secara real time. Siswaya dan Setiawan (2025) menyatakan bahwa sistem pengarsipan dan disposisi surat berbasis web memperbaiki proses pengelolaan surat dan memudahkan pengambilan keputusan. Rohmawati dan Yulianingsih (2025) menekankan bahwa e-disposisi surat berbasis web meningkatkan efisiensi pengelolaan surat dan memudahkan pelacakan dokumen.

Londa, Wee, dan Radja (2022) menunjukkan bahwa monitoring disposisi surat penting agar status surat dapat diketahui oleh pihak terkait. Bagi SMPI REJIS, modul disposisi surat diperlukan untuk mencatat instruksi, memantau proses, dan memastikan bahwa surat yang masuk diselesaikan sesuai kebutuhan administrasi.

### 2.1.6. Basis Data MySQL

Basis data adalah kumpulan data yang disimpan secara terstruktur untuk memudahkan pengelolaan dan pengambilan informasi. Basis data relasional menyimpan data dalam tabel yang saling berhubungan melalui kunci primer dan kunci asing. MySQL merupakan sistem manajemen basis data relasional yang banyak digunakan untuk aplikasi web karena dukungan terhadap transaksi, integritas data, dan kemampuan query.

Dalam aplikasi inventaris aset dan disposisi surat, basis data menyimpan entitas seperti pengguna, aset, kategori, lokasi, peminjaman, surat masuk, disposisi, dan laporan. Kunci primer adalah atribut unik yang membedakan setiap baris data, sedangkan kunci asing menghubungkan tabel satu dengan tabel lain. Relasi antara entitas memungkinkan data tersimpan secara konsisten dan meminimalkan duplikasi.

MySQL Reference Manual menjelaskan konsep relasional yang menjadi dasar penyimpanan data aplikasi. Dengan perancangan basis data yang baik, proses pencarian data, pembaruan data, dan pembuatan laporan menjadi lebih efisien dan dapat didukung oleh query yang sesuai.

### 2.1.7. PHP

PHP adalah bahasa pemrograman sisi server yang umum digunakan untuk pengembangan aplikasi web. PHP memproses permintaan dari peramban, berinteraksi dengan basis data, dan menghasilkan halaman web dinamis. Bahasa ini digunakan untuk memvalidasi input, memproses logika bisnis, dan mengatur alur kerja aplikasi.

Dokumentasi resmi PHP memberikan pedoman penggunaan syntax, koneksi basis data, dan pengelolaan sesi. Dalam aplikasi yang dirancang, PHP bertanggung jawab untuk mengolah data pengguna, data aset, data surat, dan menghubungkan hasil pemrosesan tersebut dengan tampilan yang disajikan ke pengguna.

### 2.1.8. CodeIgniter

CodeIgniter 4 adalah *framework* PHP yang memfasilitasi pengembangan aplikasi web dengan pola Model-View-Controller (MVC). MVC memisahkan logika penyimpanan data (Model), tampilan antarmuka (View), dan alur kendali aplikasi (Controller). Dengan pemisahan ini, pengembangan aplikasi menjadi lebih terstruktur dan lebih mudah dikelola.

CodeIgniter 4 User Guide menjelaskan bagaimana model berinteraksi dengan basis data, controller mengatur alur proses, dan view menampilkan data kepada pengguna. Struktur ini sesuai untuk aplikasi administrasi sekolah yang memiliki modul-modul terpisah seperti inventaris aset, surat masuk, disposisi, dan laporan.

### 2.1.9. UML

Unified Modeling Language (UML) adalah bahasa pemodelan visual untuk menggambarkan sistem perangkat lunak. UML menyediakan notasi untuk menjelaskan elemen sistem, interaksi antarobjek, dan alur proses. Dalam penelitian ini, UML digunakan sebagai dasar pemodelan sistem tanpa menampilkan gambar diagram aktual di BAB II.

Diagram UML yang relevan antara lain use case diagram, activity diagram, sequence diagram, dan deployment diagram. Use case diagram menggambarkan aktor dan fungsi utama sistem. Activity diagram menggambarkan alur proses administratif seperti pencatatan aset dan disposisi surat. Sequence diagram menggambarkan interaksi sistem berdasarkan waktu. OMG UML 2.5.1 menjadi sumber resmi untuk pemodelan tersebut.

### 2.1.10. ERD

Entity Relationship Diagram (ERD) adalah alat bantu perancangan basis data yang menggambarkan entitas, atribut, dan relasi antarentitas. ERD membantu memahami struktur data sebelum basis data dibuat, termasuk komponen seperti primary key, foreign key, dan kardinalitas.

Dalam sistem inventaris aset dan disposisi surat, ERD digunakan untuk menggambarkan interaksi antara entitas pengguna, aset, kategori, lokasi, peminjaman, surat masuk, dan disposisi. Relasi antarentitas menjelaskan bagaimana data terkait dapat dihubungkan, misalnya entitas aset terhubung dengan entitas kategori dan entitas lokasi. IBM Entity-Relationship Model Documentation menjadi sumber utama konsep ERD dalam perancangan basis data.

### 2.1.11. LRS

Logical Record Structure (LRS) adalah representasi logis struktur record yang menggambarkan susunan atribut pada entitas berdasarkan relasi antarentitas di ERD. LRS menekankan bagaimana data direpresentasikan dalam bentuk record sehingga hubungan antarentitas dapat diatur secara logis.

Dalam perancangan basis data aplikasi, LRS membantu menentukan struktur record untuk setiap tabel dan memastikan bahwa atribut yang diperlukan dapat direlasikan dengan benar. Sumber IJIS Wiratama (2024) menjelaskan LRS sebagai representasi struktur record dari entitas berdasarkan relasi antarentitas pada ERD. Artikel JSAI (2024) menggambarkan penggunaan LRS dalam perancangan sistem informasi akademik.

Karena LRS saat ini didukung oleh jurnal aplikasi dan perancangan sistem, subbab ini diberi catatan bahwa sumbernya adalah penguat awal, bukan buku teori utama. [PERLU CEK APA 7]

### 2.1.12. Agile Scrum

Agile Scrum adalah model pengembangan perangkat lunak yang bersifat iteratif dan bertahap. Scrum membantu mengelola kebutuhan pengembangan melalui daftar pekerjaan yang tersusun dalam *product backlog*, memilih pekerjaan untuk setiap *sprint*, dan menghasilkan *increment* berupa modul yang dapat diuji.

Scrum Guide 2020 menjelaskan bahwa *product backlog* berisi seluruh kebutuhan sistem, *sprint backlog* memuat pekerjaan yang akan dikerjakan dalam satu sprint, dan *increment* adalah hasil kerja yang siap ditinjau. Pendekatan ini sesuai untuk pengembangan sistem inventaris aset dan disposisi surat karena fitur dapat diimplementasikan dalam beberapa tahapan dan dievaluasi secara berkala.

Model Scrum di sini digunakan sebagai landasan teori untuk menjelaskan pendekatan pengembangan, bukan sebagai catatan historis pelaksanaan peristiwa Scrum tertentu. Setiap sprint dapat mencakup pengerjaan modul login, inventaris aset, surat masuk, disposisi surat, laporan, dan backup.

### 2.1.13. Black-Box Testing

*Black-box testing* adalah teknik pengujian perangkat lunak yang berfokus pada fungsi sistem tanpa melihat struktur internal kode. Penguji memberikan input dan memeriksa output yang dihasilkan sesuai dengan yang diharapkan. Teknik ini cocok untuk menguji fitur aplikasi web karena dapat memeriksa perilaku sistem dari perspektif pengguna.

ISTQB Glossary menjelaskan bahwa black-box testing digunakan untuk memverifikasi fungsionalitas sistem berdasarkan spesifikasi. Dalam aplikasi inventaris aset dan disposisi surat, black-box testing dapat digunakan untuk menguji proses login, input data aset, peminjaman aset, pencatatan surat masuk, disposisi surat, serta pembuatan laporan. Pengujian keamanan dasar dan pengujian kinerja dasar dapat disebut sebagai pendukung, tetapi rincian lebih lanjut dibahas di BAB IV.

## 2.2. Penelitian Terkait

Beberapa penelitian terkait memperkuat dasar penelitian ini. Annisa, Rahayuningsih, dan Anna (2023) melakukan perancangan sistem informasi inventaris sarana dan prasarana sekolah berbasis web. Penelitian tersebut menyoroti permasalahan pencatatan aset yang masih dilakukan secara manual dan kebutuhan penyajian data yang terpusat agar pencarian dan pelaporan menjadi lebih efektif.

Pranoto dan Sediyono (2021) meneliti perancangan sistem informasi inventaris barang berbasis web. Penelitian mereka menunjukkan bahwa pencatatan inventaris manual menyulitkan pengelolaan data barang, pencarian informasi, dan pembuatan laporan. Sistem berbasis web yang dirancang membantu mengelola data aset, mutasi barang, dan pelaporan secara lebih terstruktur.

Mubarok dan Sutaji (2025) membahas perancangan dan implementasi sistem inventaris aset kantor berbasis web pada Dinas Kominfo Lamongan. Penelitian ini menekankan pemanfaatan sistem web untuk meningkatkan efektivitas dan efisiensi pengelolaan aset serta pemantauan peminjaman. Relevansi penelitian ini terletak pada kebutuhan SMPI REJIS untuk mencatat aset, lokasi, status, dan riwayat peminjaman secara digital.

Penelitian Usnaini, Yasin, dan Sianipar (2021) membahas perancangan sistem informasi inventarisasi aset berbasis web pada SDN Rawamangun 09. Penelitian tersebut berangkat dari permasalahan pengelolaan aset yang masih dilakukan secara manual, sehingga proses pencarian data dan penyusunan laporan belum berjalan optimal. Relevansi penelitian tersebut dengan penelitian ini terdapat pada fokus pengelolaan inventaris aset berbasis web. Perbedaannya, penelitian ini tidak hanya membahas inventaris aset, tetapi juga mengintegrasikan pengelolaan disposisi surat dalam satu aplikasi berbasis web pada SMPI REJIS.

Siswaya dan Setiawan (2025) meneliti perancangan sistem pengarsipan dan disposisi surat berbasis web dengan metode RAD. Sistem yang dikembangkan membantu pengelolaan surat masuk, pencatatan disposisi, dan proses tindak lanjut secara lebih terorganisir. Penelitian ini relevan dengan kebutuhan SMPI REJIS untuk memantau status disposisi dan menjaga alur informasi surat.

Rohmawati dan Yulianingsih (2025) meneliti sistem informasi e-disposisi surat berbasis web. Penelitian tersebut memfokuskan pada efisiensi pengelolaan surat dan kemudahan pelacakan dokumen. Hasil penelitian ini relevan bagi SMPI REJIS karena proses disposisi surat yang terstruktur mendukung pelaporan dan tindak lanjut yang lebih cepat.

Londa, Wee, dan Radja (2022) membahas implementasi sistem informasi monitoring disposisi surat masuk dan surat keluar berbasis website. Penelitian mereka menekankan pentingnya monitoring status surat agar proses disposisi tidak terhenti. Relevansi penelitian ini terlihat pada kebutuhan SMPI REJIS untuk memantau alur disposisi dan mengurangi risiko surat tertunda.

Berdasarkan penelitian terdahulu, banyak penelitian menyoroti pengelolaan inventaris aset atau disposisi surat secara terpisah. Penelitian ini berbeda karena mengintegrasikan inventaris aset dan disposisi surat ke dalam satu sistem berbasis web pada SMPI REJIS. Integrasi tersebut diharapkan dapat memperkuat proses administrasi sekolah dengan menyediakan satu platform untuk pencatatan, pemantauan, dan pelaporan.

---

# BAB III

# ANALISIS DAN PERANCANGAN APLIKASI

Status dokumen: data patch 2 dari `BAB-III-REVISI-1-DATAPATCH-1.md`. Pada putaran pengisian data kedua ini (`USER-DATA-INPUT-ROUND-2.md`), seluruh field profil resmi, sejarah singkat, dan struktur organisasi SMPI REJIS masih berupa placeholder kosong, sama seperti putaran pertama. Sesuai instruksi dan hasil validasi, ketiga marker `[PERLU DATA]` pada 3.1, 3.1.1, dan 3.1.2 **dipertahankan tanpa perubahan** karena belum ada data nyata untuk menggantikannya. Tidak ada substansi lain yang diubah pada patch ini. Kandidat BAB III terbaru, belum menjadi naskah final DOCX.

## 3.1. Tinjauan Perusahaan

SMPI REJIS menjadi objek penelitian dalam penyusunan skripsi ini. Berdasarkan transkrip wawancara penelitian yang dilakukan pada 27 April 2026 dengan Wakil Kepala Sekolah Bidang Kesiswaan SMPI REJIS, yaitu Gilang Ramadhan S.Kom. atau Ust. Gilang, SMPI REJIS merupakan lembaga pendidikan yang menyelenggarakan administrasi sekolah, termasuk pengelolaan inventaris aset dan pengelolaan surat.

Profil resmi SMPI REJIS, seperti alamat lengkap, status kelembagaan/yayasan, serta visi dan misi, belum tersedia pada workspace ini. `[PERLU DATA]`

## 3.1.1. Sejarah Perusahaan

Sejarah singkat SMPI REJIS, termasuk tahun berdiri, latar belakang pendirian, dan perkembangan institusi, perlu disusun berdasarkan dokumen resmi SMPI REJIS. Dokumen tersebut belum tersedia pada workspace ini. `[PERLU DATA]`

## 3.1.2. Struktur Organisasi

Struktur organisasi resmi SMPI REJIS, termasuk bagan organisasi dan nama pejabat pada setiap posisi, perlu dilengkapi berdasarkan dokumen resmi sekolah. Dokumen tersebut belum tersedia pada workspace ini. `[PERLU DATA]`

Berdasarkan transkrip wawancara, pihak yang berkaitan dengan pengelolaan inventaris aset dan disposisi surat secara umum mencakup pimpinan sekolah, wakil kepala sekolah, tata usaha atau operator administrasi, dan staf terkait. Uraian ini disebutkan secara umum sebagai gambaran pihak yang relevan terhadap sistem, bukan sebagai struktur organisasi resmi yang sudah diverifikasi.

## 3.2. Analisis Aplikasi

Analisis aplikasi dalam penelitian ini disusun berdasarkan kondisi pengelolaan inventaris aset dan pengelolaan surat di SMPI REJIS sebagaimana diperoleh dari hasil wawancara pada 27 April 2026 dengan Gilang Ramadhan S.Kom. (Ust. Gilang), serta hasil audit aplikasi yang tersedia (`APLIKASI_FEATURE_AUDIT.md`, `DATABASE_ERD_AUDIT.md`).

Kondisi yang menjadi dasar analisis:

1. Inventaris aset masih dicatat secara manual menggunakan buku.
2. Microsoft Excel pernah dicoba untuk pencatatan aset, tetapi tidak berlanjut.
3. Data barang masuk, barang keluar, dan peminjaman aset belum terdokumentasi secara konsisten.
4. Aset belum dikelompokkan secara jelas berdasarkan kategori, lokasi, dan kondisi.
5. Aset yang dipinjam dapat tidak kembali ke tempat semula sehingga sulit dilacak.
6. Pengelolaan surat masih dilakukan secara manual.
7. Arsip surat masuk dan surat keluar masih tersimpan secara terpisah.
8. Proses disposisi surat belum memiliki mekanisme pemantauan yang terstruktur.

### 3.2.1. Analisis Masalah

Analisis masalah diturunkan dari identifikasi masalah pada BAB I.

No | Masalah | Dampak | Solusi Yang Diusulkan
---|---|---|---
1 | Inventaris aset masih dicatat secara manual | Pencarian data membutuhkan waktu lebih lama dan berisiko menimbulkan kesalahan pencatatan | Modul inventaris aset berbasis web untuk mencatat data aset secara terpusat
2 | Riwayat barang masuk, barang keluar, dan peminjaman aset belum terdokumentasi secara konsisten | Riwayat penggunaan aset sulit ditelusuri | Modul transaksi/peminjaman aset yang mencatat status peminjaman dan pengembalian secara terstruktur
3 | Kategori, lokasi, dan kondisi aset belum tersusun secara terstruktur | Pengelompokan aset tidak konsisten dan menyulitkan pelaporan | Modul kategori dan lokasi aset yang terhubung dengan data aset melalui relasi basis data
4 | Lokasi dan status aset sulit dipantau | Sekolah kesulitan mengetahui keberadaan barang saat dibutuhkan | Pencatatan lokasi, kondisi, dan status aset pada modul inventaris aset
5 | Pencatatan surat masuk masih dilakukan secara manual | Berisiko menimbulkan keterlambatan pengolahan informasi | Modul surat masuk berbasis web dengan pencatatan nomor, tanggal, pengirim, dan status
6 | Arsip surat masuk dan surat keluar tersimpan secara terpisah | Pencarian kembali dokumen belum efisien | Modul surat masuk dan surat keluar yang tersimpan pada satu basis data terpusat
7 | Disposisi surat belum memiliki mekanisme pemantauan yang terstruktur | Tindak lanjut surat belum dapat dikontrol dengan baik | Modul disposisi surat yang mencatat tujuan, instruksi, status, dan tanggal jatuh tempo

### 3.2.2. Analisis Kebutuhan

Analisis kebutuhan dalam penelitian ini disesuaikan dengan role yang tersedia pada aplikasi, yaitu admin, operator, dan pimpinan. Role tersebut ditemukan pada `app/Helpers/auth_helper.php`, `app/Models/UserModel.php`, dan `app/Config/Routes.php` (`APLIKASI_FEATURE_AUDIT.md`). Admin TU, Kepala Sekolah, dan Staff hanya digunakan sebagai padanan operasional jika diperlukan, bukan sebagai role teknis final aplikasi.

**Kebutuhan Pengguna**

No | Pengguna | Kebutuhan | Hak Akses Utama
---|---|---|---
1 | admin | Mengelola seluruh data master, pengguna, dan seluruh modul aplikasi | Login, manajemen pengguna, inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, backup
2 | operator | Mencatat dan memperbarui data operasional aset dan surat sehari-hari | Login, inventaris aset, transaksi aset, surat masuk, surat keluar, laporan; tidak memiliki akses manajemen pengguna (terverifikasi menolak akses `/users` dengan redirect ke dashboard pada `APPLICATION_VERIFICATION.md`)
3 | pimpinan | Memantau data, status, dan laporan tanpa mengubah data operasional utama | Login, dashboard, laporan, dan pemantauan data; dibatasi dari beberapa aksi input seperti form tambah aset (terverifikasi menolak akses `/assets/create` dengan redirect ke dashboard pada `APPLICATION_VERIFICATION.md`)

**Kebutuhan Fungsional**

No | Kebutuhan | Deskripsi | Pengguna Terkait
---|---|---|---
1 | Login atau autentikasi | Pengguna dapat masuk ke sistem menggunakan username dan password sesuai role | admin, operator, pimpinan
2 | Dashboard | Sistem menampilkan ringkasan data aset, surat, disposisi, dan pengguna | admin, operator, pimpinan
3 | Manajemen pengguna | Admin dapat mengelola data pengguna sistem | admin
4 | Inventaris aset | Pengguna dapat mencatat, mengubah, mencari, dan melihat detail data aset beserta kategori dan lokasi | admin, operator (kelola); pimpinan (lihat)
5 | Transaksi atau peminjaman aset | Pengguna dapat mencatat peminjaman aset multi-item, mencetak bukti transaksi, dan mencatat pengembalian | admin, operator
6 | Surat masuk | Pengguna dapat mencatat surat masuk beserta lampiran dan ekstraksi tanggal lampiran | admin, operator
7 | Disposisi surat | Pengguna dapat membuat disposisi dari surat masuk dan memperbarui status tindak lanjut | admin, pimpinan
8 | Surat keluar | Pengguna dapat mencatat surat keluar beserta lampiran dan status pengiriman | admin, operator
9 | Laporan | Sistem menyediakan laporan aset, surat masuk, surat keluar, disposisi, dan transaksi aset yang dapat ditampilkan, diekspor CSV, dan dicetak | admin, operator, pimpinan
10 | Backup | Admin dapat mengunduh cadangan basis data dalam bentuk berkas SQL | admin

**Kebutuhan Nonfungsional**

1. Keamanan dasar pada proses login dan sesi pengguna.
2. Hak akses berbasis role (admin, operator, pimpinan).
3. Validasi input pada form-form penting.
4. Penyimpanan data terpusat pada satu basis data MySQL/MariaDB.
5. Kemudahan penggunaan melalui antarmuka web yang sederhana.
6. Ketersediaan fitur backup data secara berkala.
7. Performa dasar yang memadai pada lingkungan lokal.
8. Penggunaan melalui web browser tanpa instalasi aplikasi tambahan.
9. Sistem dibatasi pada lingkungan lokal menggunakan Laragon; belum mencakup kebutuhan nonfungsional untuk lingkungan produksi/daring.

## 3.3. Rancangan Algoritma

Rancangan algoritma berikut menjelaskan alur logika proses utama aplikasi berdasarkan alur yang ditemukan pada route, controller, dan model aplikasi (`APLIKASI_FEATURE_AUDIT.md`). Alur ditulis dalam bentuk langkah bernomor, bukan kode program.

**Algoritma Login**

1. Pengguna membuka halaman login.
2. Pengguna memasukkan username dan password, lalu mengirim form.
3. Sistem memvalidasi bahwa username dan password wajib diisi.
4. Jika validasi gagal, sistem mengembalikan pengguna ke form login beserta pesan kesalahan.
5. Jika validasi berhasil, sistem mencari pengguna aktif berdasarkan username dan memverifikasi kecocokan password.
6. Jika kredensial tidak sesuai, sistem menampilkan pesan gagal dan tetap berada di halaman login.
7. Jika kredensial sesuai, sistem membuat sesi baru dan menyimpan data pengguna (id, nama, username, role) pada sesi.
8. Sistem mengarahkan pengguna ke halaman dashboard.

**Algoritma Pengelolaan Inventaris Aset**

1. Pengguna membuka daftar aset; sistem dapat memfilter berdasarkan kata kunci, kategori, lokasi, dan kondisi.
2. Pengguna memilih tambah data aset dan mengisi kode, nama, kategori, lokasi, kondisi, jumlah, tahun perolehan, sumber dana, nilai, penanggung jawab, foto, dan catatan.
3. Sistem memvalidasi kelengkapan data dan keunikan kode aset.
4. Jika foto diunggah, sistem memeriksa jenis berkas sebelum menyimpan.
5. Jika valid, sistem menyimpan data aset ke basis data dan menampilkannya pada daftar aset.
6. Pengguna dapat membuka detail, mengubah, atau (khusus admin) menghapus data aset.

**Algoritma Transaksi atau Peminjaman Aset**

1. Pengguna membuka daftar transaksi aset.
2. Pengguna membuat transaksi baru dengan mengisi kode transaksi, tanggal pinjam, estimasi tanggal kembali, unit peminjam, nama peminjam, tujuan, serta satu atau lebih item aset beserta jumlah dan kondisi awal.
3. Sistem memvalidasi bahwa transaksi harus memiliki minimal satu item aset.
4. Jika valid, sistem menyimpan transaksi dengan status awal `dipinjam`.
5. Pengguna dapat melihat detail transaksi dan mengunduh bukti transaksi dalam bentuk PDF.
6. Saat pengembalian, pengguna mengisi tanggal kembali, kondisi setelah kembali, dan catatan.
7. Sistem memperbarui status transaksi menjadi salah satu dari `dikembalikan`, `rusak_saat_kembali`, `hilang`, atau `dibatalkan`.

**Algoritma Surat Masuk**

1. Pengguna membuka daftar surat masuk; sistem dapat memfilter berdasarkan kata kunci, status, prioritas, dan rentang tanggal.
2. Pengguna mencatat surat masuk baru dengan mengisi nomor surat, tanggal surat, tanggal diterima, pengirim, prioritas, perihal, ringkasan, dan lampiran.
3. Jika lampiran diunggah, sistem memeriksa jenis dan ukuran berkas.
4. Sistem menyimpan data surat masuk dengan status awal `menunggu_disposisi`.
5. Sistem dapat mencoba mengekstraksi tanggal dari lampiran surat menggunakan pustaka ekstraksi tanggal.
6. Pengguna dapat membuka detail surat masuk beserta status dan disposisi terkait.

**Algoritma Disposisi Surat**

1. Admin atau pimpinan membuka detail surat masuk yang berstatus `menunggu_disposisi`.
2. Pengguna mengisi tujuan/unit disposisi, instruksi, dan tanggal jatuh tempo.
3. Sistem menyimpan data disposisi dan mengubah status surat masuk menjadi `didisposisikan`.
4. Pengguna dapat membuka daftar disposisi dan memfilter berdasarkan kata kunci atau status.
5. Saat status disposisi diperbarui (misalnya menjadi `dalam_proses` atau `selesai`), sistem menyinkronkan status surat masuk terkait.

**Algoritma Laporan**

1. Pengguna membuka halaman laporan dan memilih jenis data: aset, surat masuk, surat keluar, disposisi, atau transaksi aset.
2. Pengguna dapat menerapkan filter tanggal atau status sesuai jenis laporan.
3. Sistem mengambil data dari tabel modul bisnis terkait dan menampilkan hasil laporan.
4. Pengguna dapat mengekspor laporan ke berkas CSV atau menampilkan versi cetak.

**Algoritma Backup**

1. Admin membuka halaman backup.
2. Sistem menampilkan daftar tabel basis data yang tersedia.
3. Admin memilih unduh backup.
4. Sistem membuat berkas dump SQL berisi struktur dan data tabel, lalu mengirimkannya sebagai berkas unduhan.

---

# BAB IV

# IMPLEMENTASI DAN PENGUJIAN SOFTWARE

Status dokumen: Codex evidence patch 1 dari `BAB-IV-REVISI-1-EVIDENCEPATCH-3.md`. Patch ini merekonsiliasi klaim bukti verifikasi aplikasi dari sesi Codex (`CODEX-EVIDENCE-RECONCILIATION.md`, `SCREENSHOT-INVENTORY-CHECK-CODEX.md`, `BLACKBOX-TESTING-RECONCILIATION-CODEX.md`) terhadap kondisi nyata workspace. **Temuan rekonsiliasi**: berkas `APPLICATION_VERIFICATION.md`, `BLACKBOX_TEST_SCENARIOS.md`, dan `BAB_IV_EVIDENCE_READINESS.md`, serta folder screenshot, **tidak berubah sejak 2026-07-04** (dikonfirmasi lewat timestamp berkas) — tidak ditemukan 10 screenshot baru maupun pembaruan hasil pengujian pada 2026-07-05. Angka "Valid 23, Belum diverifikasi 19" yang disebut sebagai hasil Codex ternyata adalah checkpoint yang sudah digantikan di dalam `BLACKBOX_TEST_SCENARIOS.md` sendiri oleh checkpoint berikutnya (42 valid, 0 gagal, 0 belum diverifikasi, setelah pengujian CRUD terkontrol). Karena itu, tabel 4.3 Testing pada patch ini **tetap memakai checkpoint terbaru (42 valid)**, sama seperti versi sebelumnya — bukan penurunan ke 23 valid, karena penurunan tersebut akan mengabaikan bukti pengujian CRUD terkontrol yang sudah lebih dahulu tercatat di berkas yang sama. Kelima kebutuhan screenshot BAB IV (manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, cetak laporan) tetap tidak ditemukan sehingga marker `[PERLU CEK SCREENSHOT]` tetap dipertahankan. Marker data pengujian kinerja dasar, data sekolah, dan Mendeley/APA 7 juga tetap dipertahankan karena tidak ada data baru. BAB V tidak difinalkan pada patch ini. Kandidat BAB IV terbaru, belum menjadi naskah final DOCX.

## 4.1. Desain

Desain aplikasi meliputi rancangan basis data, arsitektur perangkat lunak, dan antarmuka pengguna. Aplikasi dibangun menggunakan CodeIgniter 4 dengan pola Model-View-Controller (MVC), bahasa pemrograman PHP, dan basis data MySQL/MariaDB, dikembangkan serta diuji pada lingkungan lokal menggunakan Laragon.

Pengembangan aplikasi ini menggunakan pendekatan Agile Scrum secara hati-hati sebagai kerangka dokumentasi berbasis fitur yang benar-benar ditemukan pada aplikasi, bukan sebagai catatan historis pelaksanaan ceremony Scrum. Penerapannya dijelaskan sebagai berikut:

1. Kebutuhan fitur aplikasi dipetakan ke dalam *product backlog*, misalnya kebutuhan login dan role, manajemen pengguna, inventaris aset, transaksi/peminjaman aset, surat masuk, disposisi, surat keluar, laporan, dan backup.
2. *Product backlog* tersebut dipetakan ke dalam kelompok pengerjaan modul (*sprint mapping*) berdasarkan modul aplikasi yang saling berkaitan, misalnya fondasi akses pengguna dan dashboard, modul master inventaris aset, modul transaksi/peminjaman aset, modul administrasi surat dan disposisi, serta modul laporan dan backup.
3. Setiap kelompok modul menghasilkan *increment* berupa bagian aplikasi yang dapat diuji, sebagaimana terlihat pada route, controller, model, dan view yang sudah tersedia untuk setiap modul.
4. Hasil setiap modul diuji pada tahap *testing* (lihat 4.3) melalui black-box testing, pengujian keamanan dasar, dan pengujian kinerja dasar.

Penelitian ini tidak menuliskan tanggal sprint, nama Scrum Master, Product Owner, Daily Scrum, Sprint Review, atau Sprint Retrospective sebagai fakta historis karena bukti rinci pelaksanaan ceremony tersebut belum ditemukan pada workspace ini.

### 4.1.1. Database

Rancangan basis data aplikasi terdiri atas 9 tabel bisnis utama dan 1 tabel sistem CodeIgniter (`migrations`). Rancangan ini bersumber dari `app/Database/Migrations/`, `database/*.sql`, `app/Controllers/ErdController.php`, `DATABASE_ERD_AUDIT.md`, dan `skripsi/04-diagram-dan-gambar/LRS_DRAFT.md`.

**Entity Relationship Diagram**

Relasi antar tabel yang ditemukan:

1. Satu `asset_categories` memiliki banyak `assets`.
2. Satu `asset_locations` memiliki banyak `assets`.
3. Satu `users` dapat membuat banyak `incoming_letters`, `outgoing_letters`, `asset_transactions`, dan melakukan banyak `dispositions`.
4. Satu `incoming_letters` dapat memiliki banyak `dispositions`.
5. Satu `asset_transactions` dapat memiliki banyak `asset_transaction_items`.
6. Satu `assets` dapat muncul pada banyak `asset_transaction_items`.

Gambar IV.1 Entity Relationship Diagram (sumber: `skripsi/04-diagram-dan-gambar/diagram-output/erd-final.svg`)

**Logical Record Structure**

LRS berikut disajikan dalam bentuk tabel struktur record per tabel bisnis, mengacu pada `LRS_DRAFT.md` (Tabel IV.1 Logical Record Structure, karena LRS disajikan tabular, bukan sebagai gambar).

*users*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas unik pengguna
2 | name | VARCHAR(120) | - | Nama lengkap pengguna
3 | username | VARCHAR(80) | UQ | Username login unik
4 | password_hash | VARCHAR(255) | - | Hash password, bukan password asli
5 | role | VARCHAR(30) | - | Hak akses: admin, operator, pimpinan
6 | is_active | TINYINT(1) | - | Status aktif akun
7 | last_login_at | DATETIME | - | Waktu login terakhir
8 | created_at | DATETIME | - | Waktu data dibuat
9 | updated_at | DATETIME | - | Waktu data diperbarui

*asset_categories*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas kategori aset
2 | name | VARCHAR(120) | UQ | Nama kategori aset
3 | description | TEXT | - | Keterangan kategori
4 | created_at | DATETIME | - | Waktu data dibuat
5 | updated_at | DATETIME | - | Waktu data diperbarui

*asset_locations*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas lokasi aset
2 | name | VARCHAR(120) | UQ | Nama lokasi atau ruangan
3 | description | TEXT | - | Keterangan lokasi
4 | created_at | DATETIME | - | Waktu data dibuat
5 | updated_at | DATETIME | - | Waktu data diperbarui

*assets*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas aset
2 | code | VARCHAR(80) | UQ | Kode aset unik
3 | name | VARCHAR(160) | - | Nama aset
4 | category_id | INT UNSIGNED | FK | Relasi ke `asset_categories.id`
5 | location_id | INT UNSIGNED | FK | Relasi ke `asset_locations.id`
6 | quantity | INT(11) | - | Jumlah unit aset
7 | condition_status | VARCHAR(40) | IDX | Kondisi aset
8 | acquisition_year | INT(4) | - | Tahun perolehan
9 | funding_source | VARCHAR(120) | - | Sumber dana
10 | value | DECIMAL(14,2) | - | Nilai aset
11 | custodian | VARCHAR(120) | - | Penanggung jawab
12 | photo | VARCHAR(255) | - | Path foto aset
13 | notes | TEXT | - | Catatan aset
14 | created_at | DATETIME | - | Waktu data dibuat
15 | updated_at | DATETIME | - | Waktu data diperbarui

*asset_transactions*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas transaksi aset
2 | transaction_code | VARCHAR(80) | UQ | Kode transaksi unik
3 | borrower_unit | VARCHAR(160) | - | Unit peminjam
4 | borrower_name | VARCHAR(160) | - | Nama peminjam
5 | purpose | TEXT | - | Tujuan peminjaman
6 | loan_date | DATE | IDX | Tanggal pinjam
7 | expected_return_date | DATE | - | Target tanggal kembali
8 | actual_return_date | DATE | - | Tanggal kembali aktual
9 | status | VARCHAR(50) | IDX | Status transaksi
10 | notes | TEXT | - | Catatan transaksi
11 | created_by | INT UNSIGNED | FK | Relasi ke `users.id`
12 | created_at | DATETIME | - | Waktu data dibuat
13 | updated_at | DATETIME | - | Waktu data diperbarui

*asset_transaction_items*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas item transaksi
2 | asset_transaction_id | INT UNSIGNED | FK | Relasi ke `asset_transactions.id`
3 | asset_id | INT UNSIGNED | FK | Relasi ke `assets.id`
4 | quantity | INT(11) | - | Jumlah aset dipinjam
5 | condition_before | VARCHAR(50) | - | Kondisi sebelum dipinjam
6 | condition_after | VARCHAR(50) | - | Kondisi setelah kembali
7 | notes | TEXT | - | Catatan item
8 | created_at | DATETIME | - | Waktu data dibuat
9 | updated_at | DATETIME | - | Waktu data diperbarui

*incoming_letters*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas surat masuk
2 | letter_number | VARCHAR(120) | - | Nomor surat
3 | letter_date | DATE | - | Tanggal surat
4 | received_date | DATE | IDX | Tanggal diterima
5 | sender | VARCHAR(160) | - | Pengirim surat
6 | subject | VARCHAR(200) | - | Perihal surat
7 | priority | VARCHAR(50) | - | Prioritas surat
8 | summary | TEXT | - | Ringkasan isi surat
9 | attachment | VARCHAR(255) | - | Path lampiran
10 | status | VARCHAR(50) | IDX | Status proses surat
11 | created_by | INT UNSIGNED | FK | Relasi ke `users.id`
12 | created_at | DATETIME | - | Waktu data dibuat
13 | updated_at | DATETIME | - | Waktu data diperbarui

*dispositions*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas disposisi
2 | incoming_letter_id | INT UNSIGNED | FK | Relasi ke `incoming_letters.id`
3 | target_unit | VARCHAR(160) | - | Unit tujuan disposisi
4 | instruction | TEXT | - | Instruksi disposisi
5 | due_date | DATE | - | Batas tindak lanjut
6 | status | VARCHAR(50) | IDX | Status disposisi
7 | disposed_by | INT UNSIGNED | FK | Relasi ke `users.id`
8 | created_at | DATETIME | - | Waktu data dibuat
9 | updated_at | DATETIME | - | Waktu data diperbarui

*outgoing_letters*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas surat keluar
2 | letter_number | VARCHAR(120) | - | Nomor surat
3 | letter_date | DATE | IDX | Tanggal surat
4 | recipient | VARCHAR(160) | - | Penerima surat
5 | destination_unit | VARCHAR(160) | - | Unit tujuan
6 | subject | VARCHAR(200) | - | Perihal surat
7 | attachment | VARCHAR(255) | - | Path lampiran
8 | status | VARCHAR(50) | IDX | Status pengiriman
9 | receiver_name | VARCHAR(120) | - | Nama penerima di tujuan
10 | received_date | DATE | - | Tanggal diterima tujuan
11 | delivery_notes | TEXT | - | Catatan pengiriman
12 | created_by | INT UNSIGNED | FK | Relasi ke `users.id`
13 | created_at | DATETIME | - | Waktu data dibuat
14 | updated_at | DATETIME | - | Waktu data diperbarui

Catatan: tabel `migrations` merupakan tabel sistem CodeIgniter dan tidak dimasukkan sebagai LRS bisnis utama. Belum ditemukan tabel khusus backup atau log aktivitas; fitur backup membaca metadata seluruh tabel basis data, sedangkan laporan mengambil data dari tabel modul bisnis masing-masing.

### 4.1.2. Software Architecture

Aplikasi menggunakan arsitektur MVC CodeIgniter 4. Route didefinisikan pada `app/Config/Routes.php`, dilindungi oleh filter `auth` untuk memastikan pengguna sudah login dan filter `role` untuk membatasi akses sesuai peran (`app/Filters/AuthFilter.php`, `app/Filters/RoleFilter.php`). Controller menangani logika proses (`app/Controllers/*.php`), model menangani akses data (`app/Models/*.php`), dan view menampilkan antarmuka (`app/Views/*`). Aplikasi juga memakai pustaka pendukung `SimplePdf` untuk mencetak bukti transaksi aset dan `LetterDateExtractor` untuk membantu ekstraksi tanggal lampiran surat, serta trait `HandlesUploads` untuk penanganan unggah berkas.

Diagram pendukung yang sudah tersedia sebagai bahan rancangan arsitektur:

- Gambar IV.2 Use Case Diagram Sistem (`diagram-output/use-case-diagram.svg`)
- Gambar IV.3 Activity Diagram Login (`diagram-output/activity-login.svg`)
- Gambar IV.4 Activity Diagram Inventaris Aset (`diagram-output/activity-inventaris-aset.svg`)
- Gambar IV.5 Activity Diagram Transaksi Aset (`diagram-output/activity-transaksi-aset.svg`)
- Gambar IV.6 Activity Diagram Surat Masuk dan Disposisi (`diagram-output/activity-surat-masuk-disposisi.svg`)
- Gambar IV.7 Activity Diagram Surat Keluar (`diagram-output/activity-surat-keluar.svg`)
- Gambar IV.8 Sequence Diagram Login (`diagram-output/sequence-login.svg`)
- Gambar IV.9 Sequence Diagram Transaksi Aset (`diagram-output/sequence-transaksi-aset.svg`)
- Gambar IV.10 Sequence Diagram Disposisi Surat (`diagram-output/sequence-disposisi-surat.svg`)
- Gambar IV.11 Arsitektur MVC Sistem (`diagram-output/arsitektur-mvc.svg`)

Seluruh diagram di atas sudah tersedia sebagai file source Mermaid dan output SVG (status: ADA). `DIAGRAM_QUALITY_REVIEW.md` mencatat bahwa Use Case Diagram, ERD, Class Diagram, dan sebagian Activity Diagram yang panjang perlu perhatian layout (misalnya landscape/lampiran) saat dimasukkan ke DOCX.

Deployment Diagram (`diagram-output/deployment-diagram.svg`) tersedia sebagai gambar pendukung opsional untuk menjelaskan konteks lingkungan lokal/Laragon, bukan sebagai subbab utama; diagram ini dapat dicantumkan di bagian ini atau pada 4.4.2 Spesifikasi Hardware dan Software sesuai kebutuhan. Class Diagram (`diagram-output/class-diagram.svg`) tersedia sebagai referensi internal, tetapi tidak digunakan sebagai gambar/subbab utama sesuai batasan outline.

### 4.1.3. User Interface

Tampilan antarmuka aplikasi ditunjukkan melalui screenshot yang diambil setelah login lokal menggunakan akun demo, tanpa menampilkan credential. Data yang tampil pada sebagian screenshot merupakan data uji/dummy yang sengaja dibuat untuk keperluan verifikasi (`APPLICATION_VERIFICATION.md`).

No | Halaman | Status Screenshot | Caption/Catatan
---|---|---|---
1 | Login | ADA — `screenshots/01-login.png` | Gambar IV.12 Tampilan Halaman Login
2 | Dashboard | ADA — `screenshots/21-dashboard-final-tanpa-erd.png` (versi final tanpa menu ERD); pendukung: `screenshots/22-sidebar-final-admin.png` | Gambar IV.13 Tampilan Dashboard; Gambar IV.14 Tampilan Sidebar Admin
3 | Manajemen Pengguna | `[PERLU CEK SCREENSHOT]` — belum ada berkas screenshot khusus, meskipun `/users` terverifikasi HTTP 200 dengan role admin | -
4 | Inventaris Aset — daftar | ADA — `screenshots/03-data-aset.png` | Gambar IV.15 Tampilan Halaman Inventaris Aset
5 | Inventaris Aset — form tambah | ADA — `screenshots/04-tambah-aset.png` | Gambar IV.16 Tampilan Form Tambah Aset
6 | Inventaris Aset — form edit | ADA — `screenshots/12-edit-data-aset.png` | Gambar IV.17 Tampilan Form Edit Aset
7 | Inventaris Aset — detail | ADA — `screenshots/13-detail-data-aset.png` | Gambar IV.18 Tampilan Detail Aset
8 | Transaksi Aset — daftar | `[PERLU CEK SCREENSHOT]` — belum ada berkas screenshot khusus daftar transaksi | -
9 | Transaksi Aset — form/detail | ADA — `screenshots/14-transaksi-aset.png` (detail transaksi dummy) | Gambar IV.19 Tampilan Detail Transaksi Aset
10 | Surat Masuk — daftar | ADA — `screenshots/05-surat-masuk.png` | Gambar IV.20 Tampilan Halaman Surat Masuk
11 | Surat Masuk — form tambah | `[PERLU CEK SCREENSHOT]` — belum ada berkas screenshot khusus form tambah | -
12 | Surat Masuk — detail dan lampiran | ADA — `screenshots/15-upload-surat-masuk.png`, `screenshots/20-hasil-upload-lampiran.png` | Gambar IV.21 Tampilan Detail Surat Masuk dan Lampiran
13 | Disposisi Surat — daftar | ADA — `screenshots/06-disposisi-surat.png` | Gambar IV.22 Tampilan Halaman Disposisi
14 | Disposisi Surat — form/detail | ADA — `screenshots/16-form-disposisi.png`, `screenshots/17-detail-disposisi.png` | Gambar IV.23 Tampilan Form dan Detail Disposisi
15 | Surat Keluar — daftar | ADA — `screenshots/07-surat-keluar.png` | Gambar IV.24 Tampilan Halaman Surat Keluar
16 | Surat Keluar — form tambah | `[PERLU CEK SCREENSHOT]` — belum ada berkas screenshot khusus form tambah | -
17 | Surat Keluar — detail | ADA — `screenshots/18-surat-keluar.png` | Gambar IV.25 Tampilan Detail Surat Keluar
18 | Laporan — halaman utama | ADA — `screenshots/08-laporan.png` | Gambar IV.26 Tampilan Halaman Laporan
19 | Laporan — cetak/print | `[PERLU CEK SCREENSHOT]` — belum ada berkas screenshot khusus tampilan cetak | -
20 | Backup | ADA — `screenshots/09-backup.png` | Gambar IV.27 Tampilan Halaman Backup

Catatan: `screenshots/10-erd-database.png` tidak digunakan sebagai bukti antarmuka operasional karena menu ERD Database sudah disembunyikan dari navigasi aplikasi final; ERD tetap ditempatkan sebagai artefak rancangan basis data pada 4.1.1, bukan sebagai halaman aplikasi.

Catatan rekonsiliasi (2026-07-05): folder screenshot dicek ulang secara langsung dan tidak ditemukan berkas baru dibandingkan sebelumnya; kelima kebutuhan yang masih bermarker `[PERLU CEK SCREENSHOT]` di atas (manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, cetak laporan) tetap belum terpenuhi. Rincian lengkap ada di `SCREENSHOT-INVENTORY-CHECK-CODEX.md`.

## 4.2. Code Generation

Aplikasi dibangun menggunakan CodeIgniter 4 dengan pola MVC. Bagian ini menampilkan potongan kode inti yang sudah diverifikasi aman untuk dikutip (tidak memuat credential, password, token, API key, session, atau data sensitif).

**Autentikasi (`app/Controllers/AuthController.php`)**

```php
public function attempt()
{
    $rules = [
        'username' => 'required',
        'password' => 'required',
    ];

    if (! $this->validate($rules)) {
        return redirect()->back()->withInput()->with('error', 'Username dan password wajib diisi.');
    }

    $model = new UserModel();
    $user  = $model->verifyLogin(
        trim((string) $this->request->getPost('username')),
        (string) $this->request->getPost('password')
    );

    if (! $user) {
        return redirect()->back()->withInput()->with('error', 'Username atau password tidak sesuai.');
    }

    $this->session->regenerate(true);

    $this->session->set([
        'isLoggedIn' => true,
        'user'       => [
            'id'       => $user['id'],
            'name'     => $user['name'],
            'username' => $user['username'],
            'role'     => $user['role'],
        ],
    ]);

    return redirect()->to('/dashboard')->with('success', 'Selamat datang, ' . $user['name'] . '.');
}
```

Potongan kode di atas menunjukkan validasi input wajib, verifikasi kredensial melalui `UserModel::verifyLogin()`, regenerasi sesi setelah login berhasil, dan penyimpanan data pengguna (tanpa password) ke sesi.

**Pembatasan Akses Berdasarkan Role (`app/Filters/RoleFilter.php`)**

```php
public function before(RequestInterface $request, $arguments = null)
{
    $allowedRoles = $arguments ?? [];
    $user         = session('user') ?? [];
    $currentRole  = $user['role'] ?? null;

    if ($allowedRoles !== [] && ! in_array($currentRole, $allowedRoles, true)) {
        return redirect()->to('/dashboard')->with('error', 'Akses ditolak untuk role Anda.');
    }
}
```

Potongan kode di atas menunjukkan mekanisme pembatasan akses berbasis role: filter membaca role dari sesi pengguna dan menolak akses (redirect ke dashboard) jika role tidak termasuk daftar peran yang diizinkan pada definisi route.

**Inventaris Aset (`app/Controllers/AssetsController.php`)**

Controller ini mengelola CRUD aset melalui method `index()`, `create()`, `store()`, `show()`, `edit()`, `update()`, dan `destroy()`. Method `index()` membangun query dengan filter opsional berdasarkan kata kunci, kategori, lokasi, dan kondisi aset. Method `store()`/`update()` memvalidasi keunikan kode aset menggunakan rule `is_unique[assets.code]` (dengan pengecualian id saat update), lalu menyimpan foto melalui trait `HandlesUploads` dengan pembatasan jenis berkas (`jpg`, `jpeg`, `png`, `webp`) dan ukuran maksimum. Method privat `findOrCreateLocation()` memungkinkan operator menambahkan lokasi baru langsung dari form aset apabila lokasi yang dicari belum tersedia di data referensi. Method `destroy()` dibatasi untuk role admin melalui filter route dan turut menghapus berkas foto terkait agar folder unggahan tetap rapi.

**Transaksi/Peminjaman Aset (`app/Controllers/AssetTransactionsController.php`)**

Method `store()` mengumpulkan item aset multi-baris melalui method privat `collectItems()` (membaca input `asset_id[]`, `quantity[]`, `condition_before[]`), kemudian memvalidasi ketersediaan stok melalui `assertItemsAvailable()` yang menghitung jumlah aset tersedia dikurangi jumlah yang sedang dipinjam pada transaksi berstatus aktif. Penyimpanan header transaksi dan item dilakukan dalam satu database transaction (`$db->transStart()`/`transComplete()`) agar data tidak tersimpan sebagian jika terjadi kegagalan. Method `completeReturn()` menutup transaksi aktif dengan mencatat status akhir (`dikembalikan`, `rusak_saat_kembali`, `hilang`, atau `dibatalkan`) beserta kondisi tiap item setelah kembali. Method `pdf()` memanggil pustaka `SimplePdf` untuk menghasilkan bukti transaksi dalam bentuk berkas PDF yang dapat diunduh.

**Surat Masuk dan Disposisi (`app/Controllers/IncomingLettersController.php`, `app/Controllers/DispositionsController.php`)**

Method `store()` pada `IncomingLettersController` menyimpan surat masuk dengan status awal tetap `menunggu_disposisi` dan memanggil trait `HandlesUploads` untuk lampiran (`pdf`, `jpg`, `jpeg`, `png`, `webp`). Method `extractDate()` adalah endpoint AJAX yang memanggil pustaka `LetterDateExtractor` untuk mencoba membaca tanggal dari berkas lampiran yang baru dipilih, tanpa menyimpan data surat, sehingga operator dapat memakai hasil ekstraksi sebagai bantuan pengisian tanggal. Method `dispose()` menyimpan data disposisi baru (`target_unit`, `instruction`, `due_date`) melalui `DispositionModel` sekaligus mengubah status surat masuk menjadi `didisposisikan`. Pada `DispositionsController`, method `updateStatus()` menyinkronkan status disposisi dengan status surat masuk melalui pemetaan tetap (`pending` → `didisposisikan`, `proses` → `dalam_proses`, `selesai` → `selesai`, `diarsipkan` → `diarsipkan`).

**Surat Keluar (`app/Controllers/OutgoingLettersController.php`)**

Method `store()`/`update()` memvalidasi status surat keluar terhadap daftar tetap (`dicatat`, `siap_dikirim`, `terkirim`, `diterima_tujuan`, `diarsipkan`) melalui rule `in_list`. Method `updateDelivery()` mewajibkan pengisian `receiver_name` dan `received_date` ketika status diubah menjadi `diterima_tujuan`, sehingga bukti penerimaan surat tetap tercatat.

**Laporan (`app/Controllers/ReportsController.php`)**

Method privat `reportData()` memilih salah satu dari lima jenis laporan (`assets`, `incoming`, `outgoing`, `dispositions`, `asset-transactions`) menggunakan ekspresi `match`, masing-masing dengan filter tanggal/status melalui method privat `applyDateAndStatusFilters()`. Method `csv()` membentuk berkas CSV langsung menggunakan fungsi bawaan PHP `fputcsv()` tanpa pustaka pihak ketiga, sedangkan method `print()` menampilkan versi cetak melalui view terpisah (`reports/print`).

**Backup (`app/Controllers/BackupController.php`)**

Method `index()` menampilkan daftar tabel basis data melalui `db_connect()->listTables()`. Method `download()` membentuk dump SQL secara manual: untuk setiap tabel, sistem mengambil struktur tabel melalui kueri `SHOW CREATE TABLE`, lalu menyisipkan seluruh baris data melalui pernyataan `INSERT INTO` yang di-escape menggunakan `db_connect()->escape()`, sebelum hasil akhirnya dikirim sebagai berkas unduhan `.sql`. Method ini tidak menampilkan maupun mencatat kredensial koneksi database.

Uraian di atas disusun berdasarkan pembacaan langsung berkas controller yang bersangkutan pada 2026-07-05, tanpa mengubah kode aplikasi maupun menampilkan potongan kode yang memuat data sensitif.

## 4.3. Testing

Pengujian sistem mencakup black-box testing, pengujian keamanan dasar, dan pengujian kinerja dasar, sesuai keputusan yang sudah disepakati pada BAB I. Pengujian tidak mencakup penetration testing, load testing, stress testing, atau benchmark server produksi.

### Black-Box Testing

Tabel berikut bersumber dari `BLACKBOX_TEST_SCENARIOS.md` (pembaruan 2026-07-04 setelah pengujian CRUD terkontrol). Seluruh data uji menggunakan data dummy/uji, bukan data operasional asli sekolah, dan tidak mencantumkan credential.

Catatan rekonsiliasi (2026-07-05): `BLACKBOX_TEST_SCENARIOS.md` mencatat dua checkpoint berurutan — checkpoint awal (23 valid, 0 gagal, 19 belum diverifikasi) sebelum pengujian CRUD terkontrol, dan checkpoint terbaru (42 valid, 0 gagal, 0 belum diverifikasi) setelah pengujian CRUD terkontrol selesai. Tabel di bawah ini memakai checkpoint terbaru sesuai isi berkas saat ini. Rincian rekonsiliasi lengkap ada di `BLACKBOX-TESTING-RECONCILIATION-CODEX.md`.

No | Fitur | Skenario | Hasil Yang Diharapkan | Hasil Pengujian | Status
---|---|---|---|---|---
BB-01 | Login | Membuka halaman login | Halaman login tampil | Halaman login merespons HTTP 200 | valid
BB-02 | Login | Login dengan data valid | Pengguna masuk ke dashboard sesuai role | Login berhasil dan diarahkan ke dashboard | valid
BB-03 | Login | Login dengan data tidak valid | Sistem menolak login dan menampilkan pesan gagal | Tetap berada di halaman login | valid
BB-04 | Akses Route | Mengakses dashboard tanpa login | Sistem mengarahkan ke login | HTTP 302 redirect ke login | valid
BB-05 | Dashboard | Membuka dashboard setelah login | Ringkasan data, grafik, dan monitoring tampil | `/dashboard` merespons HTTP 200 setelah login | valid
BB-06 | Pengguna | Admin membuka daftar pengguna | Daftar pengguna tampil | `/users` merespons HTTP 200 dengan role admin | valid
BB-07 | Pengguna | Admin menambah pengguna | Data pengguna tersimpan dan tampil di daftar | Data pengguna dummy nonaktif tersimpan dan tampil di daftar | valid
BB-08 | Aset | Membuka daftar aset | Daftar aset tampil | `/assets` merespons HTTP 200 setelah login | valid
BB-09 | Aset | Menambah aset valid | Data aset tersimpan | Data aset dummy tersimpan dan muncul di daftar | valid
BB-10 | Aset | Menambah aset tanpa field wajib | Sistem menampilkan validasi gagal | Sistem kembali ke form tambah aset | valid
BB-11 | Aset | Filter daftar aset | Daftar aset terfilter sesuai input | Filter kode dummy menampilkan aset uji | valid
BB-12 | Aset | Upload foto aset valid | Foto tersimpan dan tampil pada detail | Upload PNG dummy diterima saat tambah aset | valid
BB-13 | Aset | Upload foto tidak valid | Sistem menolak upload | Sistem kembali ke form tambah aset dan tidak membuat link detail record | valid
BB-14 | Transaksi Aset | Membuka daftar transaksi aset | Daftar transaksi tampil | `/asset-transactions` merespons HTTP 200 setelah login | valid
BB-15 | Transaksi Aset | Membuat transaksi aset valid | Transaksi tersimpan dengan status awal | Transaksi aset dummy tersimpan dan detail merespons HTTP 200 | valid
BB-16 | Transaksi Aset | Membuat transaksi tanpa item aset | Sistem menampilkan validasi gagal | Sistem kembali ke form transaksi aset | valid
BB-17 | Transaksi Aset | Mencatat pengembalian aset | Transaksi berubah sesuai status pengembalian | Status transaksi berubah menjadi dikembalikan | valid
BB-18 | Transaksi Aset | Mengunduh PDF transaksi | File PDF transaksi dapat diunduh | Route PDF merespons HTTP 200 `application/pdf` | valid
BB-19 | Surat Masuk | Membuka daftar surat masuk | Daftar surat masuk tampil | `/incoming-letters` merespons HTTP 200 setelah login | valid
BB-20 | Surat Masuk | Menambah surat masuk valid | Data surat masuk tersimpan | Surat masuk dummy tersimpan dan detail merespons HTTP 200 | valid
BB-21 | Surat Masuk | Menambah surat masuk tanpa field wajib | Sistem menampilkan validasi gagal | Sistem kembali ke form surat masuk | valid
BB-22 | Surat Masuk | Upload lampiran valid | Lampiran tersimpan | Upload PDF dummy diterima saat tambah surat masuk | valid
BB-23 | Surat Masuk | Ekstraksi tanggal dari lampiran | Sistem mencoba membaca tanggal dari lampiran | Endpoint ekstraksi tanggal merespons HTTP 200 | valid
BB-24 | Disposisi | Membuat disposisi surat masuk | Disposisi tersimpan dan status surat berubah | Disposisi dummy tersimpan dari detail surat masuk | valid
BB-25 | Disposisi | Mengubah status disposisi | Status disposisi dan status surat sinkron | Status disposisi dummy berubah menjadi selesai | valid
BB-26 | Surat Keluar | Membuka daftar surat keluar | Daftar surat keluar tampil | `/outgoing-letters` merespons HTTP 200 setelah login | valid
BB-27 | Surat Keluar | Menambah surat keluar valid | Data surat keluar tersimpan | Surat keluar dummy tersimpan dan detail merespons HTTP 200 | valid
BB-28 | Surat Keluar | Update status diterima tujuan tanpa penerima/tanggal | Sistem menolak dan meminta data penerima/tanggal | Sistem kembali ke detail surat keluar tanpa data penerima lengkap | valid
BB-29 | Surat Keluar | Update status pengiriman valid | Status surat keluar diperbarui | Status surat keluar berubah menjadi diterima tujuan | valid
BB-30 | Laporan | Membuka halaman laporan | Halaman pilihan/filter laporan tampil | `/reports` merespons HTTP 200 setelah login | valid
BB-31 | Laporan | Menampilkan laporan aset | Laporan aset tampil | `/reports/assets` merespons HTTP 200 setelah login | valid
BB-32 | Laporan | Export CSV laporan | File CSV dihasilkan | `/reports/assets/csv` merespons HTTP 200 | valid
BB-33 | Laporan | Cetak laporan | Tampilan cetak laporan muncul | `/reports/assets/print` merespons HTTP 200 | valid
BB-34 | Backup | Membuka halaman backup sebagai admin | Halaman backup tampil | `/backup` merespons HTTP 200 dengan role admin | valid
BB-35 | Backup | Mengunduh backup database | File SQL backup diunduh | `POST /backup/download` merespons HTTP 200 | valid
BB-36 | Role Access | Operator mengakses halaman pengguna | Sistem menolak/redirect sesuai role | HTTP 302 redirect ke dashboard | valid
BB-37 | Role Access | Pimpinan mengakses form tambah aset | Sistem menolak/redirect sesuai role | HTTP 302 redirect ke dashboard | valid
BB-38 | ERD | Membuka halaman ERD setelah login | Halaman ERD tampil | `/erd` merespons HTTP 200 setelah login | valid
BB-39 | Aset | Membuka form tambah aset | Form tambah aset tampil | `/assets/create` merespons HTTP 200 | valid
BB-40 | Transaksi Aset | Membuka form transaksi aset | Form transaksi aset tampil | `/asset-transactions/create` merespons HTTP 200 | valid
BB-41 | Surat Masuk | Membuka form surat masuk | Form surat masuk tampil | `/incoming-letters/create` merespons HTTP 200 | valid
BB-42 | Surat Keluar | Membuka form surat keluar | Form surat keluar tampil | `/outgoing-letters/create` merespons HTTP 200 | valid

Ringkasan: total skenario 42, valid 42, gagal 0, belum diverifikasi 0 (per pembaruan `BLACKBOX_TEST_SCENARIOS.md` 2026-07-04). Pengujian delete tidak dilakukan karena aturan tahap audit melarang penghapusan data lama.

### Pengujian Keamanan Dasar

Pengujian keamanan dasar berikut diturunkan dari skenario black-box yang relevan dengan autentikasi, sesi, dan otorisasi. Pengujian ini bukan penetration testing dan tidak mengklaim sistem aman dari seluruh jenis serangan.

No | Aspek | Skenario | Hasil Yang Diharapkan | Hasil Pengujian | Status
---|---|---|---|---|---
1 | Autentikasi | Login dengan kredensial tidak valid (BB-03) | Sistem menolak login | Tetap berada di halaman login | valid
2 | Sesi dan otorisasi akses halaman | Mengakses route terproteksi tanpa sesi login (BB-04) | Sistem mengarahkan ke halaman login | HTTP 302 redirect ke login | valid
3 | Otorisasi berbasis role | Operator mengakses halaman manajemen pengguna (BB-36) | Sistem menolak dan mengarahkan sesuai role | HTTP 302 redirect ke dashboard | valid
4 | Otorisasi berbasis role | Pimpinan mengakses form tambah aset (BB-37) | Sistem menolak dan mengarahkan sesuai role | HTTP 302 redirect ke dashboard | valid
5 | Validasi input | Menyimpan data aset/surat masuk tanpa field wajib (BB-10, BB-21) | Sistem menampilkan validasi gagal dan tidak menyimpan data kosong | Sistem kembali ke form dengan data tidak tersimpan | valid
6 | Validasi unggah berkas | Mengunggah foto aset dengan format tidak valid (BB-13) | Sistem menolak berkas dan tidak membuat record | Sistem kembali ke form tambah aset tanpa membuat record detail | valid

Catatan: pengujian keamanan dasar pada tahap ini terbatas pada mekanisme yang tercakup di atas dan belum mencakup pengujian kerentanan tingkat lanjut (misalnya SQL injection, XSS, atau serangan otomatis) karena termasuk kategori pengujian keamanan tingkat lanjut yang berada di luar ruang lingkup penelitian.

### Pengujian Kinerja Dasar

No | Proses | Lingkungan Uji | Hasil Pengamatan | Catatan
---|---|---|---|---
1 | Membuka halaman login | Lokal/Laragon, server development CodeIgniter | Merespons HTTP 200 | `[PERLU DATA HASIL PENGUJIAN]` untuk waktu respons dalam satuan waktu
2 | Membuka dashboard setelah login | Lokal/Laragon | Merespons HTTP 200 | `[PERLU DATA HASIL PENGUJIAN]`
3 | Membuka daftar data aset | Lokal/Laragon | Merespons HTTP 200 | `[PERLU DATA HASIL PENGUJIAN]`
4 | Membuka daftar surat masuk | Lokal/Laragon | Merespons HTTP 200 | `[PERLU DATA HASIL PENGUJIAN]`
5 | Menghasilkan laporan dan export CSV | Lokal/Laragon | Merespons HTTP 200 | `[PERLU DATA HASIL PENGUJIAN]`
6 | Mengunduh backup database | Lokal/Laragon | Merespons HTTP 200 | `[PERLU DATA HASIL PENGUJIAN]`

Pengujian kinerja dasar pada tahap ini baru mencatat keberhasilan proses (respons HTTP 200) pada lingkungan lokal Laragon, belum mencatat waktu respons secara terukur dalam satuan waktu (milidetik/detik). Pengukuran waktu respons formal ditandai `[PERLU DATA HASIL PENGUJIAN]` dan perlu dilengkapi sebelum bagian ini disebut final. Pengujian ini tidak dimaksudkan sebagai *load testing*, *stress testing*, atau benchmark server produksi.

## 4.4. Support

Dukungan yang dibutuhkan agar aplikasi dapat dijalankan mencakup perangkat lunak dan perangkat keras pengembangan/pengujian. Karena aplikasi hanya dikembangkan dan diuji pada lingkungan lokal, batasan ini ditulis secara eksplisit.

### 4.4.1. Publikasi Software

Publikasi software pada penelitian ini dibatasi pada lingkungan lokal menggunakan Laragon. Berdasarkan konfirmasi user (`USER-DATA-INPUT-ROUND-1.md` bagian 2), aplikasi tetap dijalankan dan diuji pada lingkungan lokal menggunakan Laragon dan belum memiliki rencana penerapan pada server internal sekolah maupun layanan hosting. Aplikasi belum dipublikasikan secara daring (online), belum berjalan pada lingkungan produksi, dan belum digunakan secara resmi oleh SMPI REJIS.

Publikasi software dapat dikembangkan pada tahap lanjutan apabila pihak sekolah berencana menerapkan aplikasi pada server internal atau layanan hosting di kemudian hari, dengan penyesuaian konfigurasi lingkungan (`ENVIRONMENT`), keamanan tambahan, dan proses deployment yang belum menjadi bagian dari penelitian ini.

### 4.4.2. Spesifikasi Hardware dan Software

**Spesifikasi Software**

1. Sistem operasi: Windows 11 (berdasarkan konfirmasi user, `USER-DATA-INPUT-ROUND-3.md`).
2. Laragon versi 6 sebagai lingkungan pengembangan lokal (berdasarkan konfirmasi user).
3. PHP CLI versi `8.4.10` (terverifikasi pada `APPLICATION_VERIFICATION.md`).
4. Composer versi `2.8.9` (terverifikasi).
5. CodeIgniter framework versi `v4.7.3` (terverifikasi pada `composer.lock`).
6. MySQL/MariaDB sebagai sistem manajemen basis data (versi spesifik belum terverifikasi di workspace ini).
7. Web browser: Google Chrome, versi terbaru saat pengujian (berdasarkan konfirmasi user; nomor versi persis tidak dicatat karena tidak ada bukti spesifik).
8. Editor pengembangan: Visual Studio Code, versi terbaru saat pengujian (berdasarkan konfirmasi user; nomor versi persis tidak dicatat karena tidak ada bukti spesifik).

**Spesifikasi Hardware**

Berdasarkan konfirmasi user (`USER-DATA-INPUT-ROUND-3.md`), spesifikasi perangkat keras (laptop/PC) yang digunakan untuk pengembangan dan pengujian adalah sebagai berikut: prosesor Intel Core i5, RAM 8 GB, dan penyimpanan 256 GB SSD.

Deployment Diagram (`diagram-output/deployment-diagram.svg`) dapat digunakan sebagai gambar pendukung opsional pada bagian ini untuk menggambarkan konteks lingkungan lokal/Laragon, tanpa menjadi subbab utama.
