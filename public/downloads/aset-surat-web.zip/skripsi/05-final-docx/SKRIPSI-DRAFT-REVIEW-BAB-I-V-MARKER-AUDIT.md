# SKRIPSI DRAFT REVIEW BAB I-V MARKER AUDIT

Tanggal dibuat: 2026-07-05

## 1. Status

File ini adalah audit rinci seluruh marker pada `SKRIPSI-DRAFT-REVIEW-BAB-I-V.docx` dan berkas Markdown sumbernya (`BAB-I-FINAL-ARAH.md`, `BAB-II-FINAL-ARAH-REFPATCH-1.md`, `BAB-III-REVISI-1.md`, `BAB-IV-REVISI-1.md`, `BAB-V-REVISI-1.md`). File ini **bukan revisi final** dan tidak mengubah DOCX, tidak menghapus marker, serta tidak mengarang data apa pun. Tujuannya hanya mengelompokkan setiap marker berdasarkan apa yang dibutuhkan untuk menyelesaikannya.

Pengecekan tambahan yang dilakukan untuk audit ini (read-only, tanpa menjalankan perintah terminal): pemeriksaan folder `skripsi/04-diagram-dan-gambar/screenshots/` (22 berkas PNG/PDF, tidak bertambah sejak draft sebelumnya), folder `skripsi/02-data-aplikasi/` (4 berkas audit, tidak ada berkas spesifikasi hardware/performa baru), dan konfirmasi keberadaan 7 berkas controller aplikasi (`AssetsController.php`, `AssetTransactionsController.php`, `IncomingLettersController.php`, `DispositionsController.php`, `OutgoingLettersController.php`, `ReportsController.php`, `BackupController.php`) yang relevan untuk marker `[PERLU CEK BUKTI KODE]`.

## 2. Ringkasan Marker

BAB | Jumlah Marker | Status | Catatan
---|---|---|---
BAB I | 6 | Final arah, marker belum selesai | 1 `[PERLU DATA]` (observasi), 5 `[PERLU CEK REFERENSI]` (latar belakang dan metode penelitian)
BAB II | 1 | Final arah + patch referensi, marker belum selesai | 1 `[PERLU CEK APA 7]` (subbab 2.1.11 LRS)
BAB III | 3 | Draft revisi 1, marker belum selesai | 3 `[PERLU DATA]` (profil, sejarah, struktur organisasi SMPI REJIS)
BAB IV | 18 | Draft revisi 1, marker belum selesai | 5 `[PERLU DATA]`, 5 `[PERLU CEK SCREENSHOT]`, 7 `[PERLU DATA HASIL PENGUJIAN]`, 1 `[PERLU CEK BUKTI KODE]`
BAB V | 2 | Draft revisi 1, marker belum selesai | 2 `[PERLU CEK SETELAH BAB IV FINAL]`
**Total** | **30** | - | -

## 3. Daftar Marker Detail

No | BAB | Marker | Lokasi/Subbab | Masalah | Sumber Penyelesaian | Status Penyelesaian | Rekomendasi
---|---|---|---|---|---|---|---
1 | I | `[PERLU DATA]` | 1.5.1 Teknik Pengumpulan Data — Observasi | Detail waktu dan bentuk pelaksanaan observasi langsung belum tercatat | Wawancara/konfirmasi ulang dengan narasumber atau pihak sekolah | BUTUH DATA USER/SEKOLAH | Tanyakan ke narasumber (Gilang Ramadhan S.Kom./Ust. Gilang) atau catat detail observasi lapangan bila pernah dilakukan
2 | I | `[PERLU CEK REFERENSI]` (3 kemunculan) | 1.1 Latar Belakang — paragraf Sistem Informasi berbasis web, paragraf Agile Scrum, paragraf pengujian sistem | Konsep sudah dibahas tetapi belum disertai sitasi langsung nama-tahun | Referensi BAB II sudah tersedia di `BAB-II-FINAL-ARAH-REFPATCH-1.md` (2.1.1 Sistem Informasi, 2.1.12 Agile Scrum, 2.1.13 Black-Box Testing) | BISA DISELESAIKAN DARI FILE LOKAL | Sisipkan sitasi nama-tahun yang relevan (mis. Wahyuni et al., 2025 untuk sistem informasi) ke paragraf BAB I terkait
3 | I | `[PERLU CEK REFERENSI]` (2 kemunculan) | 1.5.1 Studi Pustaka; 1.5.2 Model Pengembangan Sistem | Sama seperti di atas, pada bagian metode penelitian | Referensi BAB II sudah tersedia (2.1.12 Agile Scrum — Scrum Guide 2020) | BISA DISELESAIKAN DARI FILE LOKAL | Sisipkan sitasi Scrum Guide 2020 dan sumber studi pustaka lain yang relevan
4 | II | `[PERLU CEK APA 7]` | 2.1.11 LRS | Sumber LRS (Wiratama 2024, JSAI 2024) masih jurnal aplikasi/penguat awal, belum dicek format APA 7/Mendeley | Mendeley, dicocokkan dengan `REFERENSI-APA7-MENDELEY-CHECK-UPDATED.md` | BUTUH MENDLEY/APA 7 | Masukkan kedua referensi ke Mendeley, verifikasi metadata volume/nomor/halaman, cek apakah ada buku teori utama LRS yang lebih kuat
5 | III | `[PERLU DATA]` | 3.1 Tinjauan Perusahaan | Profil resmi SMPI REJIS (alamat lengkap, status yayasan/kelembagaan, visi misi) belum tersedia | Dokumen resmi sekolah | BUTUH DATA USER/SEKOLAH | Minta profil resmi/company profile SMPI REJIS ke narasumber atau pihak tata usaha
6 | III | `[PERLU DATA]` | 3.1.1 Sejarah Perusahaan | Sejarah singkat, tahun berdiri, latar belakang pendirian belum tersedia | Dokumen resmi sekolah | BUTUH DATA USER/SEKOLAH | Minta dokumen sejarah singkat sekolah atau wawancara tambahan ke pihak yang berwenang
7 | III | `[PERLU DATA]` | 3.1.2 Struktur Organisasi | Bagan organisasi resmi dan nama pejabat pada setiap posisi belum tersedia | Dokumen resmi sekolah | BUTUH DATA USER/SEKOLAH | Minta bagan struktur organisasi resmi SMPI REJIS
8 | IV | `[PERLU CEK SCREENSHOT]` | 4.1.3 User Interface — Manajemen Pengguna | Belum ada berkas screenshot khusus, meskipun `/users` terverifikasi HTTP 200 dengan role admin | Ambil screenshot halaman `/users` setelah login lokal | BUTUH SCREENSHOT | Login lokal, buka `/users`, ambil screenshot tanpa menampilkan credential
9 | IV | `[PERLU CEK SCREENSHOT]` | 4.1.3 User Interface — Transaksi Aset (daftar) | Belum ada berkas screenshot khusus daftar transaksi (yang ada baru detail transaksi dummy) | Ambil screenshot halaman `/asset-transactions` | BUTUH SCREENSHOT | Login lokal, buka daftar transaksi aset, ambil screenshot
10 | IV | `[PERLU CEK SCREENSHOT]` | 4.1.3 User Interface — Surat Masuk (form tambah) | Belum ada berkas screenshot khusus form tambah surat masuk | Ambil screenshot halaman `/incoming-letters/create` | BUTUH SCREENSHOT | Login lokal, buka form tambah surat masuk, ambil screenshot
11 | IV | `[PERLU CEK SCREENSHOT]` | 4.1.3 User Interface — Surat Keluar (form tambah) | Belum ada berkas screenshot khusus form tambah surat keluar | Ambil screenshot halaman `/outgoing-letters/create` | BUTUH SCREENSHOT | Login lokal, buka form tambah surat keluar, ambil screenshot
12 | IV | `[PERLU CEK SCREENSHOT]` | 4.1.3 User Interface — Laporan (cetak/print) | Belum ada berkas screenshot khusus tampilan cetak laporan | Ambil screenshot halaman `/reports/assets/print` (atau jenis laporan lain) | BUTUH SCREENSHOT | Login lokal, buka tampilan cetak laporan, ambil screenshot
13 | IV | `[PERLU DATA HASIL PENGUJIAN]` (6 baris tabel + 1 kalimat penutup = 7 kemunculan) | 4.3 Testing — Pengujian Kinerja Dasar (login, dashboard, data aset, surat masuk, laporan/CSV, backup) | Baru tercatat keberhasilan respons (HTTP 200), belum ada pengukuran waktu respons dalam satuan waktu (ms/detik) | Pengujian ulang dengan pencatatan waktu (mis. DevTools browser, Postman, atau stopwatch manual pada lingkungan lokal) | BUTUH HASIL PENGUJIAN | Ukur waktu respons 6 proses tersebut pada lingkungan lokal/Laragon dan catat hasil aktual, bukan dikarang
14 | IV | `[PERLU DATA]` | 4.4.1 Publikasi Software | Rencana deployment ke server internal/hosting belum ada buktinya | Keputusan pihak sekolah/user mengenai rencana deployment | BUTUH DATA USER/SEKOLAH | Tanyakan ke sekolah apakah ada rencana penerapan pada server; jika tidak ada, biarkan bagian ini kosong/ditandai tidak berlaku
15 | IV | `[PERLU DATA]` | 4.4.2 Spesifikasi Hardware dan Software — versi Windows, versi browser, versi editor | Versi sistem operasi, browser, dan editor pengembangan belum dicatat spesifik | Pengecekan lingkungan lokal (butuh izin menjalankan perintah terminal seperti `ver`/`systeminfo`/pengecekan versi browser) | BUTUH SPESIFIKASI HARDWARE | Setelah mendapat izin eksplisit, cek versi OS/browser/editor yang benar-benar dipakai selama pengembangan
16 | IV | `[PERLU DATA]` | 4.4.2 Spesifikasi Hardware dan Software — spesifikasi hardware | Spesifikasi laptop/PC (prosesor, RAM, penyimpanan) belum tersedia | Data perangkat milik pengembang/user | BUTUH SPESIFIKASI HARDWARE | Minta user mencatat spesifikasi perangkat yang dipakai untuk pengembangan dan pengujian
17 | IV | `[PERLU CEK BUKTI KODE]` | 4.2 Code Generation — Modul Lain | Potongan kode untuk modul aset, transaksi, surat, laporan, backup belum dikutip langsung (baru uraian naratif) | Berkas controller sudah ada secara lokal: `AssetsController.php`, `AssetTransactionsController.php`, `IncomingLettersController.php`, `DispositionsController.php`, `OutgoingLettersController.php`, `ReportsController.php`, `BackupController.php` (dikonfirmasi ada pada audit ini) | BISA DISELESAIKAN DARI FILE LOKAL | Pilih potongan kode singkat dan aman (tanpa credential) dari tiap controller untuk dikutip pada revisi berikutnya
18 | V | `[PERLU CEK SETELAH BAB IV FINAL]` (2 kemunculan) | 5.1 Kesimpulan poin 4 dan kalimat penutup | Kesimpulan hasil pengujian bergantung pada penyelesaian marker BAB IV (screenshot, pengujian kinerja, kode) | Menunggu marker BAB IV nomor 8-17 di atas selesai, lalu kesimpulan ditinjau ulang | BUTUH REVIEW MANUAL | Tinjau ulang redaksi kesimpulan poin 4 setelah BAB IV tidak lagi memiliki marker terkait pengujian

## 4. Marker Yang Bisa Dikerjakan Sekarang

Marker berikut secara teknis bisa diselesaikan hanya dari file lokal yang sudah tersedia di workspace, tanpa perlu data baru dari user/sekolah maupun screenshot/pengujian baru. **Marker-marker ini belum diselesaikan pada audit ini — hanya didaftarkan sesuai instruksi.**

1. `[PERLU CEK REFERENSI]` pada BAB I 1.1 Latar Belakang (3 kemunculan) — referensi sudah ada di `BAB-II-FINAL-ARAH-REFPATCH-1.md`, tinggal disisipkan sebagai sitasi ke paragraf BAB I yang sesuai.
2. `[PERLU CEK REFERENSI]` pada BAB I 1.5.1 dan 1.5.2 (2 kemunculan) — sama, sumber Scrum Guide 2020 dan referensi studi pustaka lain sudah tersedia di BAB II.
3. `[PERLU CEK BUKTI KODE]` pada BAB IV 4.2 Code Generation — 7 berkas controller (aset, transaksi, surat masuk, disposisi, surat keluar, laporan, backup) sudah dikonfirmasi ada di `app/Controllers/`, tinggal dipilih potongan kode yang aman untuk dikutip.

## 5. Marker Yang Membutuhkan Data Dari User/Sekolah

1. Profil resmi SMPI REJIS (BAB III 3.1).
2. Sejarah SMPI REJIS (BAB III 3.1.1).
3. Struktur organisasi SMPI REJIS (BAB III 3.1.2).
4. Detail observasi yang belum lengkap — waktu dan bentuk pelaksanaan observasi langsung (BAB I 1.5.1).
5. Rencana deployment/publikasi software ke server, jika ada (BAB IV 4.4.1) — termasuk kategori ini karena merupakan keputusan pihak sekolah, bukan data yang bisa diambil dari file lokal.

## 6. Marker Yang Membutuhkan Screenshot

Lima screenshot yang masih kurang (BAB IV 4.1.3 User Interface):

1. Halaman manajemen pengguna (`/users`).
2. Daftar transaksi aset (`/asset-transactions`).
3. Form tambah surat masuk (`/incoming-letters/create`).
4. Form tambah surat keluar (`/outgoing-letters/create`).
5. Cetak laporan (`/reports/assets/print` atau jenis laporan lain yang relevan).

## 7. Marker Yang Membutuhkan Pengujian

Pengukuran waktu respons yang masih kurang (BAB IV 4.3 Testing — Pengujian Kinerja Dasar):

1. Pengukuran waktu respons halaman login.
2. Pengukuran waktu respons dashboard.
3. Pengukuran waktu respons daftar data aset.
4. Pengukuran waktu respons daftar surat masuk.
5. Pengukuran waktu respons pembuatan laporan dan export CSV.
6. Pengukuran waktu respons pengunduhan backup database.
7. Kemunculan ke-7 (`[PERLU DATA HASIL PENGUJIAN]`) adalah kalimat penutup subbab yang menegaskan kembali kebutuhan pengukuran di atas, bukan proses tambahan yang berbeda.

Tidak ada hasil pengujian yang dikarang pada audit ini; keenam item di atas tetap kosong sampai pengukuran nyata dilakukan.

## 8. Marker Referensi

1. Jumlah jurnal ilmiah pada BAB II sudah 10 (memenuhi syarat minimal 10 jurnal pedoman UBSI dengan catatan), berkat penambahan Usnaini, Yasin, & Sianipar (2021) pada `BAB-II-FINAL-ARAH-REFPATCH-1.md`.
2. Mendeley dan format APA 7 belum final untuk seluruh 19 referensi yang dipakai (lihat `REFERENSI-APA7-MENDELEY-CHECK-UPDATED.md`).
3. Marker `[PERLU CEK APA 7]` pada subbab 2.1.11 LRS masih ada dan belum dibereskan.
4. Semua referensi — termasuk yang berstatus LENGKAP sekalipun — tetap harus dicek manual di Mendeley dan dicocokkan gaya APA 7 sebelum daftar pustaka disebut final.

## 9. Rekomendasi Prioritas

**Prioritas 1:** Marker yang bisa diselesaikan dari file lokal — sisipkan sitasi BAB II ke BAB I (5 marker `[PERLU CEK REFERENSI]`) dan kutip potongan kode 7 controller ke BAB IV (1 marker `[PERLU CEK BUKTI KODE]`).

**Prioritas 2:** Screenshot aplikasi — ambil 5 screenshot halaman yang masih kurang (manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, cetak laporan).

**Prioritas 3:** Spesifikasi hardware dan software — lengkapi versi OS/browser/editor (butuh izin menjalankan perintah pengecekan lokal) dan spesifikasi hardware pengembangan.

**Prioritas 4:** Data institusi SMPI REJIS — profil resmi, sejarah, dan struktur organisasi (butuh dokumen resmi sekolah atau wawancara tambahan).

**Prioritas 5:** Pengujian kinerja dasar — ukur waktu respons 6 proses utama pada lingkungan lokal.

**Prioritas 6:** Mendeley APA 7 dan format akhir DOCX — masukkan seluruh referensi ke Mendeley, verifikasi APA 7, dan terapkan format akhir resmi (lembar judul, daftar isi/gambar/tabel/lampiran, watermark, penomoran halaman).

Setelah Prioritas 1 sampai 3 selesai, marker BAB V (`[PERLU CEK SETELAH BAB IV FINAL]`) dapat ditinjau ulang karena sebagian besar dasar ketergantungannya (screenshot dan bukti kode) sudah berkurang.

## 10. Keputusan

DOCX draft review versi 1 (`SKRIPSI-DRAFT-REVIEW-BAB-I-V.docx`) sudah layak untuk dibaca, tetapi revisi versi 2 sebaiknya dibuat setelah marker prioritas 1 sampai 3 dibereskan.
