# SKRIPSI Draft Finalisasi BAB I-IV Notes

Tanggal dibuat: 2026-07-05

## Status

Dokumen `SKRIPSI-DRAFT-FINALISASI-BAB-I-IV.md` dan `SKRIPSI-DRAFT-FINALISASI-BAB-I-IV.docx` sudah dibuat sebagai draft finalisasi BAB I sampai BAB IV. Dokumen ini bukan `SKRIPSI-FINAL.docx` dan bukan `SKRIPSI.docx`.

## File Sumber Yang Digunakan

1. `MEMORY.md`
2. `skripsi/05-final-docx/SKRIPSI-DRAFT-REVIEW-BAB-I-IV-CODEX-PATCH.md`
3. `skripsi/05-final-docx/SKRIPSI-DRAFT-REVIEW-BAB-I-IV-CODEX-PATCH.docx`
4. `skripsi/05-final-docx/SKRIPSI-DRAFT-REVIEW-BAB-I-IV-CODEX-PATCH-NOTES.md`
5. `skripsi/03-draft-bab/BAB-IV-REVISI-1-CODEX-EVIDENCEPATCH-1.md`
6. `skripsi/03-draft-bab/SCREENSHOT-CAPTURE-MISSING-5.md`
7. `skripsi/03-draft-bab/PERFORMANCE-BASIC-OBSERVATION.md`
8. `skripsi/03-draft-bab/BAB-IV-EVIDENCE-COMPLETION-REPORT.md`
9. `skripsi/04-diagram-dan-gambar/screenshots/`

## Istilah Internal Yang Dibersihkan Dari Isi Utama

Istilah internal yang ditargetkan untuk dibersihkan antara lain `.md`, Codex, Claude, workspace, marker, evidence patch, draft review, data patch, MEMORY.md, AGENTS.md, TOOLS.md, APPLICATION_VERIFICATION.md, BLACKBOX_TEST_SCENARIOS.md, SCREENSHOT-INVENTORY-CHECK-CODEX.md, PERFORMANCE-BASIC-OBSERVATION.md, USER-DATA-INPUT, BAB-IV-REVISI, BAB-I-FINAL-ARAH, BAB-II-FINAL-ARAH, dan BAB-III-REVISI.

Hasil scan isi utama setelah pembersihan: tidak ditemukan istilah terlarang.

## Screenshot Baru Yang Dimasukkan

1. `screenshot-manajemen-pengguna.png` - Gambar IV.15 Tampilan Halaman Manajemen Pengguna.
2. `screenshot-daftar-transaksi-aset.png` - Gambar IV.20 Tampilan Daftar Transaksi Aset.
3. `screenshot-form-tambah-surat-masuk.png` - Gambar IV.23 Tampilan Form Tambah Surat Masuk.
4. `screenshot-form-tambah-surat-keluar.png` - Gambar IV.28 Tampilan Form Tambah Surat Keluar.
5. `screenshot-cetak-laporan.png` - Gambar IV.31 Tampilan Cetak Laporan.

## Data Kinerja Dasar Yang Dimasukkan

1. Login: 2.860 ms.
2. Dashboard: 1.607 ms.
3. Data Aset: 1.273 ms.
4. Surat Masuk: 1.200 ms.
5. Laporan: 1.055 ms.
6. Backup: 1.013 ms.

## Bagian Yang Masih Perlu Dilengkapi

1. Detail observasi BAB I.
2. Profil resmi SMPI REJIS.
3. Sejarah singkat SMPI REJIS.
4. Struktur organisasi SMPI REJIS.
5. Cek final Mendeley/APA 7 pada referensi LRS.

## Catatan DOCX

1. DOCX dibuat dengan format A4, margin atas 3 cm, kiri 4 cm, bawah 2,5 cm, kanan 2,5 cm.
2. Font utama Times New Roman 12.
3. Spasi isi 2.
4. Judul BAB rata tengah, kapital, tebal, ukuran 14.
5. Subbab tebal ukuran 12.
6. Tabel diberi garis.
7. Caption gambar berada di bawah gambar.
8. Tidak dibuat daftar isi otomatis final, halaman awal final, daftar pustaka final, atau watermark final.
9. Render visual DOCX ke PNG belum dapat dilakukan karena LibreOffice/soffice tidak tersedia pada environment saat ini. QA yang dilakukan adalah pemeriksaan struktural DOCX: ukuran halaman, margin, font utama, jumlah tabel, dan jumlah gambar.
