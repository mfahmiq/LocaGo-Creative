# PERSEPSI_PROJECT_CHECKPOINT

Tanggal dibuat: 2026-07-04
Tujuan: checkpoint penyamaan persepsi sebelum drafting BAB.

## Ringkasan Pemahaman Project

Project ini terdiri dari aplikasi web CodeIgniter 4 untuk SMPI REJIS dan penyusunan dokumen akhir skripsi `SKRIPSI.docx`. Fokus sistem adalah sistem inventaris aset dan disposisi surat berbasis web yang mengelola login/autentikasi, dashboard, manajemen pengguna, inventaris aset, transaksi/peminjaman aset, surat masuk, disposisi surat, surat keluar, laporan, dan backup.

## Judul Skripsi Yang Dipahami

Judul skripsi final yang sudah dikonfirmasi user:

`Perancangan Sistem Terintegrasi Inventaris Aset dan Disposisi Surat Berbasis Web pada SMPI REJIS`

Judul tersebut harus digunakan secara konsisten pada blueprint, draft, dan dokumen skripsi. Jika pada cover diperlukan huruf kapital, format kapitalisasi disesuaikan pada tahap DOCX.

## Objek Penelitian

- Objek penelitian: SMPI REJIS.
- Konteks masalah: pencatatan inventaris aset, peminjaman/pengembalian aset, arsip surat masuk/keluar, disposisi surat, laporan, dan backup.
- Profil resmi, sejarah institusi, dan struktur organisasi resmi masih perlu dilengkapi atau dikonfirmasi.

## Program Studi dan Outline

- Program studi: Teknologi Informasi Program Sarjana.
- Outline: kode 156.
- Jenis outline: Perancangan Program / Perancangan Program Science.
- Struktur utama: BAB I sampai BAB V sesuai `OUTLINE_156_MAPPING.md`.

## Metode Pengembangan Sistem

- Metode yang digunakan: Agile Scrum.
- Dasar aman: outline membuka ruang model selain Waterfall dengan tahapan disesuaikan.
- Cara penulisan aman:
  - Scrum ditulis sebagai pendekatan pengembangan/perancangan sistem untuk memetakan kebutuhan, product backlog, sprint mapping, implementasi modul, dan pengujian.
  - Product backlog dan sprint mapping harus berbasis fitur nyata aplikasi yang sudah ditemukan, diverifikasi, dan diuji.
  - Jangan menulis seolah-olah semua ceremony Scrum historis terdokumentasi lengkap jika tidak ada bukti.
  - Jangan mengarang tanggal sprint, nama tim, Daily Scrum, Sprint Review, atau Sprint Retrospective.

## Framework Aplikasi

- Framework: CodeIgniter 4.
- Versi framework yang terdeteksi: `codeigniter4/framework v4.7.3`.
- Bahasa/platform: PHP.
- Lingkungan pengembangan dan pengujian: Laragon/local environment.
- Status deployment: aplikasi dikembangkan dan diuji pada lingkungan lokal/Laragon. Jangan menulis deployment produksi, online, atau server resmi sekolah jika tidak ada bukti deployment produksi.

## Database

- Database: MySQL/MariaDB.
- Tabel bisnis utama: `users`, `asset_categories`, `asset_locations`, `assets`, `asset_transactions`, `asset_transaction_items`, `incoming_letters`, `dispositions`, dan `outgoing_letters`.
- Tabel `migrations` adalah tabel sistem CodeIgniter.
- Belum ditemukan tabel khusus backup, log aktivitas, atau laporan.

## Target Akhir Dokumen

- Target akhir: `SKRIPSI.docx` siap diperiksa dosen pembimbing.
- `SKRIPSI.docx` belum dibuat.
- Draft BAB final belum dibuat.
- Draft harus mengikuti pedoman kampus, outline 156, audit aplikasi, database, diagram, screenshot, dan hasil pengujian.

## Sumber Acuan Utama

- `PEDOMAN_AUDIT.md`
- `OUTLINE_156_MAPPING.md`
- `APLIKASI_FEATURE_AUDIT.md`
- `DATABASE_ERD_AUDIT.md`
- `SCRUM_MAPPING_AUDIT.md`
- `BLACKBOX_TEST_SCENARIOS.md`
- `DIAGRAM_INDEX.md`
- `DIAGRAM_QUALITY_REVIEW.md`
- `LRS_DRAFT.md`
- Screenshot aplikasi di `skripsi/04-diagram-dan-gambar/screenshots/`
- Source aplikasi: route, controller, model, view, migration, SQL, library, trait, dan helper.

## Keputusan Project Yang Sudah Disepakati

1. Workspace utama: `C:\laragon\www\aset-surat-web`.
2. File koordinasi lintas sesi: `AGENTS.md`, `MEMORY.md`, dan `TOOLS.md`.
3. Folder kerja skripsi berada di `skripsi/`.
4. PDF asli, SQL asli, migration, seeder, dan source code tidak boleh diubah tanpa instruksi eksplisit.
5. `SKRIPSI.docx` belum boleh dibuat sebelum disetujui.
6. Draft BAB final belum boleh dibuat sebelum disetujui.
7. Menu `ERD Database` disembunyikan dari sidebar/menu operasional aplikasi.
8. `ErdController.php` tetap dipertahankan sebagai referensi dokumentasi skripsi.
9. Route `/erd` bersifat dev-only.
10. Judul skripsi final adalah `Perancangan Sistem Terintegrasi Inventaris Aset dan Disposisi Surat Berbasis Web pada SMPI REJIS`.
11. Objek penelitian ditulis konsisten sebagai SMPI REJIS.
12. Data dummy boleh digunakan sebagai bukti pengujian black-box dan screenshot, tetapi harus disebut sebagai data uji/dummy, bukan data asli sekolah.
13. Diagram besar seperti ERD, class diagram, use case diagram, dan activity diagram panjang boleh digunakan dengan catatan layout landscape atau lampiran bila sulit dibaca pada halaman biasa.

## Struktur BAB I Sampai BAB V Yang Dipahami

### BAB I - Pendahuluan

- `1.1 Latar Belakang Masalah`
- `1.2 Identifikasi Permasalahan`
- `1.3 Perumusan Masalah`
- `1.4 Tujuan dan Manfaat`
- `1.5 Metode Penelitian`
- `1.5.1 Teknik Pengumpulan Data`
- `1.5.2 Model Pengembangan Software`
- `1.6 Ruang Lingkup`

### BAB II - Landasan Teori

- `2.1 Tinjauan Pustaka`
- `2.2 Penelitian Terkait`

### BAB III - Analisis dan Perancangan Aplikasi

- `3.1 Tinjauan Perusahaan` atau disesuaikan menjadi tinjauan institusi/sekolah bila disetujui.
- `3.1.1 Sejarah Perusahaan`
- `3.1.2 Struktur Organisasi`
- `3.2 Analisis Aplikasi`
- `3.2.1 Analisis Masalah`
- `3.2.2 Analisis Kebutuhan`
- `3.3 Rancangan Algoritma`

### BAB IV - Implementasi dan Pengujian Software

- `4.1 Desain`
- `4.1.1 Database`
- `4.1.2 Software Architecture`
- `4.1.3 User Interface`
- `4.2 Code Generation`
- `4.3 Testing`
- `4.4 Support`
- `4.4.1 Publikasi Software`
- `4.4.2 Spesifikasi Hardware dan Software`

### BAB V - Penutup

- `5.1 Kesimpulan`
- `5.2 Saran`

## Ruang Lingkup Aplikasi Yang Benar-Benar Ada

- Login/logout.
- Dashboard.
- Manajemen pengguna.
- Inventaris aset.
- Transaksi/peminjaman dan pengembalian aset.
- Upload foto aset.
- Surat masuk.
- Upload lampiran surat masuk.
- Ekstraksi tanggal lampiran surat.
- Disposisi surat.
- Surat keluar.
- Upload lampiran surat keluar.
- Update status pengiriman surat keluar.
- Laporan show/CSV/print.
- Backup database.
- ERD sebagai artefak dokumentasi/dev-only, bukan menu operasional final.

## Bagian Yang Tidak Boleh Dikarang

- Profil resmi, sejarah, dan struktur organisasi SMPI REJIS.
- Kutipan wawancara di luar transkrip/sumber yang tersedia.
- Tanggal sprint, anggota Scrum Team, Scrum Master, Product Owner, Daily Scrum, Sprint Review, atau Retrospective sebagai fakta historis bila belum ada bukti.
- Bukti deployment produksi, online, atau penggunaan resmi di server sekolah jika belum ada bukti.
- Referensi jurnal/buku dan sitasi yang belum dikumpulkan.
- Hasil pengujian yang belum diverifikasi.
- Fitur yang tidak ditemukan dalam route, controller, model, view, database, atau hasil verifikasi.
- Data dummy sebagai data asli sekolah.
- Credential, password, token, API key, session, cookie, atau data sensitif.

## Aturan Bahasa, Singkatan, dan Pengutipan

- Gunakan bahasa Indonesia akademik, baku, jelas, dan dapat dipertanggungjawabkan.
- Gunakan Mendeley dengan style APA 7 untuk sitasi.
- Jangan membuat sitasi palsu; bagian yang membutuhkan referensi tetapi belum tersedia diberi penanda `[PERLU SITASI]`.
- Kutipan langsung harus mengikuti pedoman: kurang dari 5 baris memakai tanda kutip dan 2 spasi, sedangkan 5 baris atau lebih memakai 1 spasi, paragraf/tab dari tepi kiri, dan tanpa tanda kutip.
- Kutipan tidak langsung harus memakai parafrasa sendiri, terintegrasi dalam paragraf, tanpa tanda kutip, dan tetap mencantumkan sumber.
- Hindari singkatan tidak resmi seperti `dll`, `dst`, `ybs`, `dsb`, `yg`, dan `thd`.
- Istilah asing digunakan seperlunya; gunakan istilah Indonesia bila tersedia, dan tulis miring/garis bawah bila istilah asing belum memiliki padanan yang jelas.
- Kata ulang harus ditulis penuh, misalnya `kata-kata`, bukan `kata2`.
- Hindari gaya tidak akademik, terlalu promosi, subjektif, terlalu umum, humor, atau klaim yang tidak berbasis sumber.

## Risiko Salah Persepsi

1. Istilah `Tinjauan Perusahaan` pada outline perlu disesuaikan dengan objek sekolah/institusi tanpa melanggar outline.
2. Scrum dapat terlihat seperti cerita historis palsu jika tidak diberi batas sebagai mapping berbasis fitur.
3. ERD dapat keliru dianggap fitur operasional bila tidak dijelaskan sebagai artefak desain/database.
4. Deployment bisa keliru ditulis sebagai internet/intranet padahal bukti yang ada baru lokal/Laragon.
5. Data dummy pengujian masih ada dan harus dibedakan dari data asli.
6. Referensi BAB II belum cukup untuk penulisan final karena daftar pustaka terstruktur belum ditemukan.
7. Diagram besar bisa sulit dibaca jika dipaksakan ke halaman portrait biasa.

## Hal Yang Perlu Disetujui Sebelum Drafting

1. Apakah BAB III memakai istilah `Tinjauan Institusi/Sekolah` atau tetap mengikuti label outline `Tinjauan Perusahaan`.
2. Apakah data dummy pengujian dibiarkan sebagai bukti atau perlu cleanup terkontrol nanti.
3. Urutan gambar/tabel final yang akan dipakai di BAB III dan BAB IV.
4. Referensi jurnal/buku untuk BAB II dan sitasi APA 7.
5. Data profil resmi, sejarah, dan struktur organisasi SMPI REJIS.
