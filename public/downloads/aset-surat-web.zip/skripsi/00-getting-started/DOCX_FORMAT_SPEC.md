# DOCX_FORMAT_SPEC

Tanggal dibuat: 2026-07-04
Tujuan: spesifikasi awal format `SKRIPSI.docx` berdasarkan `PEDOMAN_AUDIT.md`.

## Ukuran Kertas

- Ukuran kertas: A4.
- Sumber: `PEDOMAN_AUDIT.md`, berdasarkan `render-pedoman/pedoman-page-01.png`.

## Margin

| Sisi | Ukuran |
| --- | --- |
| Atas | 3 cm |
| Kiri | 4 cm |
| Bawah | 2,5 cm |
| Kanan | 2,5 cm |

Sumber: `PEDOMAN_AUDIT.md`, berdasarkan `render-pedoman/pedoman-page-01.png`, `page-06.png`, `page-08.png`, dan `page-09.png`.

## Footer dan Watermark

- Penomoran halaman bagian awal diletakkan tengah bawah, 2 cm dari bawah.
- Penomoran halaman awal BAB diletakkan bawah tengah, 2 cm dari bawah.
- Penomoran halaman selain awal BAB diletakkan pojok kanan atas, 2 cm dari atas.
- Watermark diberikan pada setiap halaman kecuali lembar judul.
- Watermark menggunakan logo resmi Universitas Bina Sarana Informatika, ukuran 10 cm x 10 cm, rata tengah.
- Detail implementasi footer selain nomor halaman belum dapat dipastikan.

## Font

- Font utama: Times New Roman.
- Ukuran font isi: 12.
- Nomor dan judul BAB: ukuran 14, tebal, huruf besar, rata tengah.
- Subbab dan sub-subbab: ukuran 12, tebal, awal kata huruf besar.
- Isi tabel/gambar dapat disesuaikan; font isi tabel minimal 8 atau disesuaikan.

## Spasi Isi

- Isi tulisan skripsi menggunakan 2 spasi.
- Abstrak menggunakan 1 spasi dalam satu paragraf.
- Kutipan langsung kurang dari 5 baris menggunakan 2 spasi dan tanda kutip.
- Kutipan langsung 5 baris atau lebih menggunakan 1 spasi, paragraf lurus/tab dari tepi kiri, tanpa tanda kutip.
- Daftar pustaka menggunakan 1 spasi per pustaka dan 2 spasi antar pustaka.

## Paragraf dan Indentasi

- Penomoran poin dapat menggunakan angka dan huruf kecil sesuai hierarki.
- Kutipan panjang menggunakan tab dari tepi kiri atau paragraf lurus sesuai pedoman.
- Detail ukuran indentasi paragraf biasa belum dapat dipastikan dari render pedoman.

## Judul BAB

- Nomor BAB menggunakan angka Romawi.
- Nomor dan judul BAB ditulis di tengah.
- Judul BAB menggunakan huruf besar, Times New Roman 14, tebal.
- Jarak pasti sebelum/sesudah judul BAB belum dapat dipastikan penuh; audit visual menunjukkan jarak mengikuti contoh pedoman dan perlu dicek saat render DOCX.

## Subbab

- Subbab menggunakan angka Latin berbasis nomor BAB, contoh `3.1`, `3.2`, `3.2.1`.
- Judul subbab dan sub-subbab diawali huruf besar, Times New Roman 12, tebal.
- Detail spacing subbab belum dapat dipastikan penuh dari render pedoman.

## Tabel

- Judul tabel diletakkan di atas tengah tabel.
- Nomor tabel mengikuti BAB, contoh `Tabel IV.4`.
- Isi tabel minimal font 8 atau disesuaikan.
- Sumber tabel diletakkan di bawah tabel jika ada.

## Gambar

- Judul gambar/grafik diletakkan di bawah tengah gambar.
- Nomor gambar/grafik mengikuti BAB, contoh `Gambar II.2`.
- Sumber gambar diletakkan di bawah atau dekat gambar sesuai contoh.

## Caption Tabel dan Gambar

- Caption tabel: di atas tabel, rata tengah, format nomor mengikuti BAB.
- Caption gambar/grafik: di bawah gambar, rata tengah, format nomor mengikuti BAB.
- Nomor caption final belum dapat dikunci sebelum urutan gambar/tabel dalam draft BAB selesai.

## Abstrak

- Abstrak ditulis dalam Bahasa Indonesia dan Bahasa Inggris.
- Masing-masing abstrak berada pada halaman berbeda.
- Isi abstrak 1 spasi, satu paragraf.
- Jumlah kata 150 sampai 200 kata.
- Isi abstrak memuat latar belakang, tujuan, metode, dan hasil.

## Daftar Isi

- Struktur daftar isi sebagai bagian awal terlihat dari outline.
- Format rinci daftar isi belum dapat dipastikan dari render pedoman.

## Daftar Gambar

- Daftar gambar menjadi bagian awal sesuai outline.
- Format rinci daftar gambar belum dapat dipastikan dari render pedoman.

## Daftar Tabel

- Daftar tabel menjadi bagian awal sesuai outline.
- Format rinci daftar tabel belum dapat dipastikan dari render pedoman.

## Daftar Lampiran

- Daftar lampiran menjadi bagian awal sesuai outline.
- Lampiran berisi data pendukung seperti gambar, tabel, analisis, dan data lain yang terlalu banyak untuk dimasukkan ke BAB.
- Halaman lampiran memakai nomor halaman tengah bawah sebagai kelanjutan halaman skripsi.
- Pojok kanan atas diberi nama kelompok lampiran, contoh `Lampiran A1`, `A2`, `B1`, `B2`.
- Format rinci daftar lampiran bagian awal belum dapat dipastikan.

## Daftar Pustaka dan Sitasi

- Sitasi menggunakan Mendeley.
- Style sitasi: APA 7.
- Sumber tidak boleh dari Blogspot, Wordpress, atau Wikipedia.
- Skripsi mensitasi minimal 10 jurnal.
- Referensi jurnal minimal 5 tahun terakhir.
- Referensi buku minimal 10 tahun terakhir.
- Daftar pustaka diurutkan berdasarkan abjad.
- Gelar pengarang tidak dicantumkan.
- Semua pengarang yang dikutip wajib masuk daftar pustaka.
- Daftar pustaka tidak menggunakan nomor urut.

## Aturan Bahasa, Singkatan, dan Pengutipan

Sumber: review visual `render-pedoman/pedoman-page-10.png` sampai `render-pedoman/pedoman-page-15.png`.

### Teknik Pengutipan

- Teknik pengutipan terdiri atas kutipan langsung dan kutipan tidak langsung.
- Sumber kutipan tidak boleh berasal dari Blogspot, Wordpress, atau Wikipedia.
- Format pengutipan wajib menggunakan Mendeley dengan style APA 7.
- Nama pengarang ditulis setelah kalimat yang dikutip dengan format dalam kurung: nama pengarang, koma, dan tahun terbit.
- Laporan skripsi mensitasi minimal 10 jurnal.
- Referensi jurnal minimal 5 tahun terakhir dan referensi buku minimal 10 tahun terakhir dari periode penyusunan laporan.
- Jika sumber kutipan merujuk pada sumber lain, sumber yang ditulis adalah sumber yang digunakan pengutip, dengan menyebut pihak yang mengemukakan pendapat tersebut sesuai contoh pedoman.

### Kutipan Langsung

- Kutipan langsung harus sama dengan aslinya, baik susunan kata, ejaan, maupun tanda baca.
- Kutipan langsung kurang dari 5 baris diketik 2 spasi dan mengikuti paragraf yang diberi tanda kutip.
- Kutipan langsung 5 baris atau lebih diketik 1 spasi, paragraf lurus sesuai ketukan paragraf atau menggunakan tab dari tepi kiri, dan tanpa tanda kutip.

### Kutipan Tidak Langsung

- Kutipan tidak langsung hanya mengambil inti atau sari pendapat.
- Kutipan tidak langsung tidak menggunakan tanda kutip.
- Kutipan diintegrasikan dengan teks atau paragraf.
- Jarak antarbaris tetap 2 spasi.
- Penyajian tidak sama dengan teks asli, melainkan memakai bahasa/kalimat penulis sendiri.
- Setelah poin atau gagasan dikutip, sumber tetap ditulis dalam kurung dengan nama pengarang dan tahun terbit.

### Singkatan

- Hindari singkatan tidak resmi seperti `dll`, `dst`, `ybs`, dan `dsb`.
- Hindari singkatan tidak resmi seperti `yg` untuk `yang` dan `thd` untuk `terhadap`.
- Singkatan resmi mengikuti ketentuan bahasa Indonesia resmi. Detail semua bentuk singkatan resmi belum dapat dipastikan dari pedoman.

### Istilah Asing

- Sedapat mungkin gunakan istilah yang berlaku dalam bahasa Indonesia.
- Jika istilah Indonesia perlu dijelaskan dalam bahasa asing, istilah asing ditulis dalam kurung setelah istilah Indonesia.
- Jika bahasa asing belum memiliki terjemahan dalam bahasa Indonesia, kata tersebut ditulis miring atau diberi garis bawah.
- Hindari kesalahan penulisan istilah asing dan pastikan maknanya sesuai konteks kalimat bahasa Indonesia.

### Kata Yang Diulang

- Kata yang berulang harus ditulis penuh.
- Jangan menulis angka dua di belakang kata berulang.
- Contoh aturan: tulis `kata-kata`, bukan `kata2`; tulis `berulang-ulang`, bukan `ber-ulang2`.

### Gaya Bahasa

- Gunakan bahasa ilmiah dan baku.
- Gaya bahasa harus baik, mudah dipahami pembaca, sesuai metode ilmiah, dan dapat dipertanggungjawabkan.
- Hindari humor atau kalimat yang mengundang senyum.
- Hindari penggunaan kata yang salah, termasuk penggunaan `daripada` yang tidak sesuai makna.
- Hindari tambahan keterangan/catatan secara tersendiri yang dapat membuat pokok teks tidak sistematis.
- Hindari penggunaan garis miring `/` sebagai arti `atau`, kecuali untuk singkatan resmi seperti `PKL/Riset`.
- Untuk kata pengantar seperti `terdiri dari`, `adalah`, `sebagai berikut`, `yaitu`, `bahwa`, `diantaranya`, dan `seperti`, cukup gunakan salah satu sesuai kebutuhan dan di akhir kata langsung diberi titik dua tanpa spasi sebelumnya.
- Tanda baca seperti titik dua, kurung, tanda tanya, garis miring, kutip, dan penghubung tidak diberi spasi dari kata/kalimat yang diberi tanda tersebut, kecuali pada format formulir/isian.
- Larangan gaya penulisan untuk draft: jangan memakai gaya bahasa tidak akademik, terlalu promosi, terlalu subjektif, terlalu umum, atau tidak terkait langsung dengan objek penelitian.

## Penomoran Halaman Awal

- Bagian awal menggunakan angka Romawi huruf kecil, misalnya `i`, `ii`, `iii`, `iv`.
- Nomor halaman bagian awal diletakkan tengah bawah, 2 cm dari bawah.
- Lembar judul tidak menampilkan nomor halaman tetapi tetap dihitung.

## Penomoran Halaman BAB

- Bagian pokok menggunakan angka Latin.
- Halaman pertama BAB I adalah halaman nomor 1.
- Setiap awal BAB: nomor halaman bawah tengah, 2 cm dari bawah.
- Selain awal BAB: nomor halaman pojok kanan atas, 2 cm dari atas.
- Bagian akhir memakai angka Latin sebagai kelanjutan dari bagian pokok dan diletakkan bawah tengah, 2 cm dari bawah.

## Bagian Belum Dapat Dipastikan

- Format rinci daftar isi.
- Format rinci daftar gambar.
- Format rinci daftar tabel.
- Format rinci daftar lampiran bagian awal.
- Detail ukuran indentasi paragraf biasa.
- Detail spacing pasti sebelum/sesudah judul BAB dan subbab.
- Format lengkap halaman awal selain halaman judul.
- Ketentuan teknis implementasi watermark pada file DOCX final.
