# SKRIPSI_BLUEPRINT

Tanggal dibuat: 2026-07-04
Status: blueprint sebelum drafting BAB, bukan draft BAB final.

## 1. Judul Skripsi Final

`Perancangan Sistem Terintegrasi Inventaris Aset dan Disposisi Surat Berbasis Web pada SMPI REJIS`

Catatan: jika pada cover harus menggunakan huruf kapital, format kapitalisasi disesuaikan pada tahap DOCX.

## 2. Objek Penelitian

- Objek penelitian: SMPI REJIS.
- Fokus sistem: sistem inventaris aset dan disposisi surat berbasis web.
- Framework aplikasi: CodeIgniter 4.
- Database: MySQL/MariaDB.
- Lingkungan pengembangan dan pengujian: Laragon/local environment.
- Status deployment: dikembangkan dan diuji pada lingkungan lokal/Laragon. Jangan tulis deployment produksi, online, atau server sekolah tanpa bukti.

## 3. Ringkasan Konteks Masalah

Konteks yang sudah tersedia dari transkrip wawancara dan audit:

- Pencatatan inventaris aset masih manual dan pernah dicoba di Excel tetapi tidak berlanjut.
- Data aset yang dibutuhkan mencakup barang masuk, barang keluar, letak barang, dan peminjaman barang.
- Kendala aset mencakup barang keluar/masuk belum tercatat, peminjaman tidak selalu kembali ke tempat semula, dan pencarian/lokasi aset sulit dipantau.
- Pencatatan surat dan disposisi masih manual.
- Arsip surat masuk/keluar masih terpisah.
- Dibutuhkan pemantauan status surat, disposisi, arsip digital, dan laporan.

Bagian yang masih perlu dilengkapi:

- Profil resmi SMPI REJIS. [PERLU DATA]
- Sejarah SMPI REJIS. [PERLU DATA]
- Struktur organisasi SMPI REJIS. [PERLU DATA]
- Referensi teori untuk sistem informasi, inventaris aset, disposisi surat, CodeIgniter 4, MySQL/MariaDB, UML/diagram, black-box testing, dan Agile Scrum. [PERLU SITASI]

## 4. Struktur Halaman Awal

Struktur halaman awal berdasarkan outline 156 dan pedoman:

1. Lembar Judul Skripsi.
2. Lembar Pernyataan Keaslian Skripsi.
3. Lembar Pernyataan Persetujuan Publikasi Karya Ilmiah.
4. Lembar Persetujuan dan Pengesahan Skripsi.
5. Lembar Pedoman Penggunaan Hak Cipta.
6. Lembar Konsultasi Skripsi.
7. Lembar Persembahan.
8. Kata Pengantar.
9. Abstraksi Bahasa Indonesia.
10. Abstract Bahasa Inggris.
11. Daftar Isi.
12. Daftar Simbol. [BELUM DAPAT DIPASTIKAN format rinci]
13. Daftar Gambar.
14. Daftar Tabel.
15. Daftar Lampiran.

Catatan format:

- Kertas A4.
- Margin atas 3 cm, kiri 4 cm, bawah 2,5 cm, kanan 2,5 cm.
- Font utama Times New Roman.
- Isi naskah ukuran 12, spasi 2.
- Abstrak 150 sampai 200 kata, 1 spasi, satu paragraf.
- Format rinci daftar isi/gambar/tabel/lampiran belum dapat dipastikan dari render pedoman. [BELUM DAPAT DIPASTIKAN]

## 5. Struktur BAB I - Pendahuluan

### 1.1 Latar Belakang Masalah

Rencana isi:

- Kondisi pencatatan aset dan surat di SMPI REJIS berdasarkan transkrip wawancara.
- Masalah pencatatan manual, arsip terpisah, pemantauan status, dan kebutuhan laporan.
- Kebutuhan sistem inventaris aset dan disposisi surat berbasis web.
- Relevansi sistem terintegrasi untuk inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup.

Kebutuhan:

- Data profil singkat SMPI REJIS. [PERLU DATA]
- Sitasi teori sistem informasi/arsip/inventaris/surat. [PERLU SITASI]

### 1.2 Identifikasi Permasalahan

Rencana poin masalah:

- Pencatatan inventaris aset masih manual.
- Pencatatan peminjaman/pengembalian aset belum mudah dipantau.
- Arsip surat masuk dan surat keluar masih terpisah.
- Proses disposisi surat belum terdokumentasi dalam sistem terpadu.
- Laporan aset dan surat membutuhkan proses yang lebih terstruktur.

Sumber: transkrip wawancara, `OUTLINE_156_MAPPING.md`, dan audit aplikasi.

### 1.3 Perumusan Masalah

Rencana rumusan berbentuk pertanyaan:

- Bagaimana merancang sistem terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS?
- Bagaimana sistem mendukung pengelolaan aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup?
- Bagaimana penerapan Agile Scrum digunakan secara aman sebagai pendekatan pengembangan/perancangan sistem?

Catatan: redaksi final perlu disetujui saat drafting BAB I.

### 1.4 Tujuan dan Manfaat

Rencana tujuan:

- Merancang sistem terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS.
- Menyediakan fitur pengelolaan aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup.
- Menyusun dokumentasi pengembangan menggunakan Agile Scrum berbasis fitur nyata aplikasi.

Rencana manfaat:

- Untuk SMPI REJIS: membantu pengelolaan data aset, surat, disposisi, dan laporan.
- Untuk penulis: menerapkan ilmu perancangan dan pengembangan aplikasi web.
- Untuk pembaca/peneliti berikutnya: menjadi referensi pengembangan sistem serupa.

### 1.5 Metode Penelitian

Rencana isi:

- Menjelaskan teknik pengumpulan data dan model pengembangan software.
- Harus mengikuti outline 156.

### 1.5.1 Teknik Pengumpulan Data

Rencana isi:

- Observasi. [PERLU DATA detail pelaksanaan bila ingin spesifik]
- Wawancara, berdasarkan transkrip yang tersedia.
- Studi pustaka. [PERLU SITASI]

### 1.5.2 Model Pengembangan Software

Rencana isi:

- Model: Agile Scrum.
- Scrum ditulis sebagai pendekatan untuk memetakan kebutuhan, product backlog, sprint mapping, implementasi modul, dan pengujian.
- Jangan mengarang tanggal sprint, nama tim, Daily Scrum, Sprint Review, atau Sprint Retrospective.
- Product backlog dan sprint mapping harus berbasis fitur aplikasi yang ditemukan, diverifikasi, dan diuji.

Sumber: `SCRUM_MAPPING_AUDIT.md`, `OUTLINE_156_MAPPING.md`, hasil audit/verifikasi aplikasi.

### 1.6 Ruang Lingkup

Ruang lingkup aplikasi:

- Login/autentikasi.
- Dashboard.
- Manajemen pengguna.
- Inventaris aset.
- Transaksi/peminjaman aset.
- Surat masuk.
- Disposisi surat.
- Surat keluar.
- Laporan.
- Backup.

Catatan:

- ERD tidak ditulis sebagai fitur operasional. ERD digunakan sebagai artefak perancangan/dokumentasi.
- Data dummy pada screenshot/testing harus disebut sebagai data uji/dummy.

## 6. Struktur BAB II - Landasan Teori

### 2.1 Tinjauan Pustaka

Struktur teori yang perlu digunakan:

- `2.1.1 Sistem Informasi` [PERLU SITASI]
- `2.1.2 Website` [PERLU SITASI]
- `2.1.3 Inventaris Aset` [PERLU SITASI]
- `2.1.4 Surat` [PERLU SITASI]
- `2.1.5 Disposisi Surat` [PERLU SITASI]
- `2.1.6 Basis Data MySQL` [PERLU SITASI]
- `2.1.7 PHP` [PERLU SITASI]
- `2.1.8 CodeIgniter` [PERLU SITASI]
- `2.1.9 UML` [PERLU SITASI]
- `2.1.10 ERD` [PERLU SITASI]
- `2.1.11 LRS` [PERLU SITASI]
- `2.1.12 Agile Scrum` [PERLU SITASI]
- `2.1.13 Black-Box Testing` [PERLU SITASI]

Catatan pedoman:

- Sitasi memakai APA 7 dan Mendeley.
- Minimal 10 jurnal untuk skripsi.
- Referensi jurnal minimal 5 tahun terakhir.
- Referensi buku minimal 10 tahun terakhir.
- Hindari Blogspot, Wordpress, dan Wikipedia.
- Jangan gunakan subbab `Sistem` secara terpisah.
- Fokus teori langsung pada Sistem Informasi dan topik yang relevan dengan aplikasi.
- Jangan membuat sitasi palsu; bila referensi belum tersedia, gunakan `[PERLU SITASI]`.
- Jangan menginstal atau memakai tool humanizer/paraphrase otomatis untuk mengakali deteksi.
- Gaya penulisan BAB II harus akademik, natural, parafrasa sendiri, bukan copy-paste.

### 2.2 Penelitian Terkait

Rencana isi:

- Minimal 5 penelitian terkait dari jurnal ilmiah sesuai outline. [PERLU SITASI]
- Topik yang dicari: sistem informasi inventaris aset sekolah, sistem arsip surat, disposisi surat berbasis web, sistem administrasi sekolah, atau aplikasi sejenis.
- Setiap penelitian terkait harus diringkas berdasarkan masalah, metode, hasil, dan relevansi terhadap skripsi ini.

## 7. Struktur BAB III - Analisis dan Perancangan Aplikasi

### 3.1 Tinjauan Perusahaan / Institusi

Catatan:

- Outline menyebut `Tinjauan Perusahaan`, tetapi objek penelitian adalah SMPI REJIS.
- Redaksi yang disarankan: `Tinjauan Institusi` atau tetap mengikuti label outline dengan isi tentang SMPI REJIS. [PERLU PERSETUJUAN]

### 3.1.1 Sejarah Perusahaan / Institusi

Rencana isi:

- Sejarah SMPI REJIS. [PERLU DATA]
- Profil singkat institusi. [PERLU DATA]

### 3.1.2 Struktur Organisasi

Rencana isi:

- Struktur organisasi SMPI REJIS. [PERLU DATA]
- Peran yang relevan terhadap sistem: Admin TU, operator/staff, kepala sekolah/pimpinan. [PERLU DATA jika ingin formal]

### 3.2 Analisis Aplikasi

Rencana isi:

- Menjelaskan aplikasi sebagai sistem terintegrasi inventaris aset dan disposisi surat berbasis web.
- Menguraikan aktor: admin, operator, pimpinan.
- Menguraikan modul: login, dashboard, pengguna, aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, backup.
- Menjelaskan ERD sebagai artefak perancangan, bukan fitur operasional.

Sumber: `APLIKASI_FEATURE_AUDIT.md`, route, controller, model, view, screenshot final.

### 3.2.1 Analisis Masalah

Rencana isi:

- Masalah inventaris aset manual.
- Masalah peminjaman/pengembalian aset.
- Masalah arsip surat masuk/keluar terpisah.
- Masalah pemantauan disposisi dan laporan.

Sumber: transkrip wawancara, audit fitur, hasil verifikasi aplikasi.

### 3.2.2 Analisis Kebutuhan

Rencana isi:

- Kebutuhan fungsional per role.
- Kebutuhan nonfungsional awal: autentikasi, hak akses, penyimpanan data, backup, lingkungan lokal.
- Product backlog berbasis fitur nyata aplikasi.
- Use Case Diagram.
- Activity Diagram modul inti.

Catatan:

- Product backlog tidak boleh memasukkan ERD sebagai fitur operasional sekolah. ERD dapat dicatat sebagai artefak dokumentasi/perancangan.

### 3.3 Rancangan Algoritma

Rencana isi:

- Rancangan alur/proses bisnis aplikasi, bukan algoritma Dijkstra dari contoh outline.
- Alur login.
- Alur inventaris aset.
- Alur transaksi/peminjaman aset.
- Alur surat masuk sampai disposisi.
- Alur surat keluar.
- Alur laporan/backup bila diperlukan.

Sumber diagram:

- `activity-login.svg`
- `activity-inventaris-aset.svg`
- `activity-transaksi-aset.svg`
- `activity-surat-masuk-disposisi.svg`
- `activity-surat-keluar.svg`

## 8. Struktur BAB IV - Implementasi dan Pengujian Software

### 4.1 Desain

Rencana isi:

- Pengantar desain sistem berbasis CodeIgniter 4.
- Menghubungkan desain database, arsitektur software, user interface, dan Scrum mapping.

### 4.1.1 Database

Rencana isi:

- Tabel database utama.
- ERD final.
- LRS.
- Relasi tabel.
- Catatan bahwa tabel `migrations` adalah tabel sistem CodeIgniter.
- Tidak ditemukan tabel khusus backup/log/laporan; laporan mengambil data dari tabel modul bisnis.

Sumber:

- `DATABASE_ERD_AUDIT.md`
- `LRS_DRAFT.md`
- `erd-final.svg`
- migration dan SQL dump.

### 4.1.2 Software Architecture

Rencana isi:

- Arsitektur MVC CodeIgniter 4.
- Route, filter auth/role, controller, model, view.
- Library pendukung: `SimplePdf`, `LetterDateExtractor`.
- Trait upload: `HandlesUploads`.
- Sequence diagram login, transaksi aset, disposisi surat.
- Deployment diagram lokal/Laragon.

Catatan:

- Status deployment ditulis lokal/Laragon, bukan produksi/online.

### 4.1.3 User Interface

Rencana isi:

- Screenshot halaman login.
- Dashboard final tanpa menu ERD.
- Menu/sidebar final.
- Pengguna.
- Inventaris aset.
- Transaksi aset.
- Surat masuk.
- Disposisi.
- Surat keluar.
- Laporan.
- Backup.

Catatan:

- Screenshot dengan data dummy harus diberi keterangan data uji/dummy.
- Screenshot ERD lama tidak dipakai sebagai UI operasional final.

### 4.2 Code Generation

Rencana isi:

- Potongan kode terpilih dari route, controller, model, filter, helper, library, atau trait.
- Kandidat kode:
  - Auth/login dan role filter.
  - Aset dan upload foto.
  - Transaksi aset dan PDF.
  - Surat masuk, upload lampiran, ekstraksi tanggal.
  - Disposisi dan sinkronisasi status.
  - Backup database.

Catatan:

- Jangan menampilkan credential, password, token, session, cookie, API key, atau data sensitif.
- Pilih potongan kode yang relevan, bukan seluruh file panjang.

### 4.3 Testing

Rencana isi:

- Black-box testing.
- Skenario yang sudah diverifikasi: total 42, valid 42, gagal 0, belum diverifikasi 0.
- Modul mencakup login, dashboard, pengguna, aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, backup, role access, dan ERD sebagai route dokumentasi/dev-only.
- Data dummy ditulis sebagai data uji/dummy.

Sumber:

- `BLACKBOX_TEST_SCENARIOS.md`
- `APPLICATION_VERIFICATION.md`
- `BAB_IV_EVIDENCE_READINESS.md`

### 4.4 Support

Rencana isi:

- Lingkungan pengembangan dan pengujian: Laragon/local environment.
- PHP, Composer, CodeIgniter 4, MySQL/MariaDB, browser.
- Kebutuhan hardware/software final. [PERLU DATA]

### 4.4.1 Publikasi Software

Rencana isi:

- Aplikasi dikembangkan dan diuji pada lingkungan lokal/Laragon.
- Belum ada bukti deployment produksi/online/server sekolah.
- Jangan menulis publikasi produksi jika tidak ada bukti.

### 4.4.2 Spesifikasi Hardware dan Software

Rencana isi:

- Spesifikasi software: PHP, Composer, CodeIgniter 4, MySQL/MariaDB, Laragon, browser.
- Spesifikasi hardware pengembangan/pengujian. [PERLU DATA]

## 9. Struktur BAB V - Penutup

### 5.1 Kesimpulan

Rencana isi:

- Menyimpulkan hasil perancangan sistem berdasarkan tujuan.
- Menyimpulkan bahwa sistem mencakup inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup.
- Menyimpulkan hasil pengujian black-box berdasarkan data yang sudah diverifikasi.

Catatan: kesimpulan final baru boleh ditulis setelah BAB I-IV disetujui.

### 5.2 Saran

Rencana isi:

- Saran pengembangan deployment produksi/intranet bila nanti diperlukan.
- Saran pengembangan audit trail/log aktivitas.
- Saran pengembangan role/unit disposisi lebih rinci jika dibutuhkan.
- Saran penyempurnaan fitur berdasarkan hasil pengujian.

## 10. Daftar Tabel Yang Direncanakan

| No | Tabel | Rencana Penempatan | Status |
| --- | --- | --- | --- |
| 1 | Tabel Identifikasi Permasalahan | BAB I/BAB III | siap konsep |
| 2 | Tabel Kebutuhan Fungsional | BAB III | siap konsep |
| 3 | Tabel Hak Akses Role | BAB III | siap dari route/audit |
| 4 | Tabel Product Backlog | BAB III/BAB IV | siap dari Scrum mapping, perlu koreksi ERD sebagai artefak |
| 5 | Tabel Sprint Mapping | BAB III/BAB IV | siap sebagai mapping aman |
| 6 | Tabel Struktur Database | BAB IV | siap dari LRS/audit |
| 7 | Tabel Relasi Database | BAB IV | siap dari ERD/audit |
| 8 | Tabel LRS | BAB IV | siap draft |
| 9 | Tabel Black-box Testing | BAB IV | siap dari 42 skenario valid |
| 10 | Tabel Spesifikasi Software | BAB IV | siap sebagian |
| 11 | Tabel Spesifikasi Hardware | BAB IV | [PERLU DATA] |
| 12 | Tabel Penelitian Terkait | BAB II | [PERLU SITASI] |

## 11. Daftar Gambar Yang Direncanakan

| No | Gambar | Rencana Penempatan | Status |
| --- | --- | --- | --- |
| 1 | Use Case Diagram Sistem | BAB III | siap, perlu layout besar |
| 2 | Activity Diagram Login | BAB III | siap |
| 3 | Activity Diagram Inventaris Aset | BAB III | siap, perlu layout besar |
| 4 | Activity Diagram Transaksi Aset | BAB III | siap, perlu layout besar |
| 5 | Activity Diagram Surat Masuk dan Disposisi | BAB III | siap, perlu layout besar |
| 6 | Activity Diagram Surat Keluar | BAB III | siap, perlu layout besar |
| 7 | ERD Final | BAB IV | siap, sebaiknya landscape/lampiran |
| 8 | Arsitektur MVC CodeIgniter 4 | BAB IV | siap |
| 9 | Sequence Diagram Login | BAB IV | siap |
| 10 | Sequence Diagram Transaksi Aset | BAB IV | siap |
| 11 | Sequence Diagram Disposisi Surat | BAB IV | siap |
| 12 | Class Diagram Aplikasi | BAB IV | siap, sebaiknya landscape/lampiran |
| 13 | Deployment Diagram Lokal/Laragon | BAB IV | siap |
| 14 | Alur Agile Scrum | BAB I/BAB IV | siap dengan catatan mapping aman |
| 15 | Screenshot Login | BAB IV | siap |
| 16 | Screenshot Dashboard Final Tanpa ERD | BAB IV | siap |
| 17 | Screenshot Sidebar Final Admin | BAB IV | siap |
| 18 | Screenshot Modul Aset, Transaksi, Surat, Disposisi, Laporan, Backup | BAB IV | siap, perlu seleksi final |

## 12. Daftar Lampiran Yang Direncanakan

- Lampiran transkrip wawancara. [PERLU CEK FORMAT]
- Lampiran screenshot aplikasi tambahan.
- Lampiran diagram besar bila sulit dibaca pada halaman BAB.
- Lampiran hasil black-box testing lengkap.
- Lampiran source code terpilih jika diminta dosen.
- Lampiran bukti backup database pengujian.
- Lampiran surat riset/surat keterangan. [PERLU DATA]
- Lampiran cek plagiarisme. [PERLU DATA]
- Lampiran daftar riwayat hidup. [PERLU DATA]

## 13. Sumber Data Untuk Setiap BAB

| BAB | Sumber Data |
| --- | --- |
| BAB I | Transkrip wawancara, outline 156, audit aplikasi, konteks masalah, [PERLU SITASI] |
| BAB II | Jurnal/buku terkait sistem informasi, inventaris, disposisi, web, Scrum, CodeIgniter, MySQL/MariaDB, black-box testing [PERLU SITASI] |
| BAB III | `APLIKASI_FEATURE_AUDIT.md`, route, controller, model, view, transkrip, diagram, Scrum mapping |
| BAB IV | `DATABASE_ERD_AUDIT.md`, `LRS_DRAFT.md`, diagram SVG, screenshot, black-box testing, application verification |
| BAB V | Kesimpulan dari BAB I-IV dan hasil pengujian |

## 13.1 Aturan Bahasa, Singkatan, dan Pengutipan

Aturan yang harus dipakai saat drafting:

- Kutipan terdiri atas kutipan langsung dan tidak langsung.
- Sumber kutipan tidak boleh berasal dari Blogspot, Wordpress, atau Wikipedia.
- Sitasi wajib memakai Mendeley dengan style APA 7.
- Kutipan langsung harus sama dengan aslinya, baik susunan kata, ejaan, maupun tanda baca.
- Kutipan langsung kurang dari 5 baris diketik 2 spasi, mengikuti paragraf, dan diberi tanda kutip.
- Kutipan langsung 5 baris atau lebih diketik 1 spasi, paragraf lurus/tab dari tepi kiri, dan tanpa tanda kutip.
- Kutipan tidak langsung ditulis sebagai parafrasa sendiri, terintegrasi dalam paragraf, tidak diapit tanda kutip, dan tetap mencantumkan sumber.
- Hindari singkatan tidak resmi seperti `dll`, `dst`, `ybs`, `dsb`, `yg`, dan `thd`.
- Gunakan istilah Indonesia bila tersedia. Istilah asing dipakai seperlunya dan ditulis miring/garis bawah bila belum memiliki padanan yang jelas.
- Kata ulang harus ditulis penuh, bukan memakai angka dua.
- Gunakan bahasa ilmiah dan baku, tidak promosi, tidak subjektif, tidak terlalu umum, dan tidak memakai humor.
- Bagian yang belum jelas dari pedoman tetap diberi tanda `[BELUM DAPAT DIPASTIKAN]`.

## 14. Bagian Yang Sudah Siap Ditulis

- BAB I bagian ruang lingkup.
- BAB I bagian metode pengembangan Agile Scrum secara aman.
- BAB III analisis aplikasi berdasarkan fitur, role, route, controller, model, view.
- BAB III analisis kebutuhan awal.
- BAB III rancangan alur sistem berdasarkan diagram.
- BAB IV desain database, ERD, dan LRS.
- BAB IV arsitektur MVC.
- BAB IV user interface berdasarkan screenshot yang sudah tersedia.
- BAB IV testing berdasarkan 42 skenario valid.
- BAB IV support lingkungan lokal/Laragon.

## 15. Bagian Yang Masih Membutuhkan Data Tambahan

- Profil resmi SMPI REJIS. [PERLU DATA]
- Sejarah SMPI REJIS. [PERLU DATA]
- Struktur organisasi SMPI REJIS. [PERLU DATA]
- Spesifikasi hardware pengembangan/pengujian. [PERLU DATA]
- Status surat riset/surat keterangan riset. [PERLU DATA]
- Referensi BAB II dan sitasi APA 7. [PERLU SITASI]
- Penelitian terkait minimal 5 jurnal. [PERLU SITASI]
- Detail format daftar isi/gambar/tabel/lampiran dari pedoman. [BELUM DAPAT DIPASTIKAN]

## 16. Risiko Penulisan

1. BAB I lemah jika profil, sejarah, dan struktur organisasi SMPI REJIS belum tersedia.
2. BAB II belum bisa final tanpa referensi jurnal/buku yang valid.
3. Scrum berisiko dianggap mengarang proses jika ditulis sebagai ceremony historis tanpa bukti.
4. Deployment berisiko salah jika ditulis produksi/online padahal bukti hanya lokal/Laragon.
5. Data dummy berisiko disalahpahami jika tidak diberi label data uji/dummy.
6. Diagram besar berisiko tidak terbaca jika dipaksakan pada halaman portrait.
7. Format daftar isi/gambar/tabel/lampiran masih perlu dicek saat pembuatan DOCX.

## 17. Rekomendasi Urutan Drafting BAB

Urutan yang disarankan:

1. Lengkapi data yang diperlukan untuk BAB I: profil, sejarah, struktur organisasi, dan detail objek penelitian. [PERLU DATA]
2. Siapkan referensi untuk BAB II. [PERLU SITASI]
3. Draft BAB III lebih dulu setelah data institusi minimal tersedia, karena audit aplikasi dan diagram sudah kuat.
4. Draft BAB IV setelah pemilihan screenshot, diagram, tabel testing, dan potongan kode final.
5. Draft BAB I dapat disusun paralel setelah data profil dan referensi cukup.
6. Draft BAB II setelah referensi terkumpul dan dikelola dengan Mendeley/APA 7.
7. Draft BAB V dibuat terakhir setelah BAB I-IV stabil.

Catatan akhir: jangan lanjut drafting BAB I sebelum user menyetujui blueprint ini.
