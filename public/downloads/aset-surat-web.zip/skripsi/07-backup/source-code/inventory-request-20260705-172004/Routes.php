<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */

/*
| -------------------------------------------------------------------
| ROUTING APLIKASI SMPI REJIS
| -------------------------------------------------------------------
| File ini mendefinisikan alamat URL untuk aplikasi inventaris aset,
| surat, disposisi, laporan, backup, dan autentikasi.
|
| Alur Kerja:
| - Route publik hanya login dan proses login.
| - Route internal dilindungi filter auth.
| - Route sensitif diberi filter role sesuai kebutuhan.
|
| Tips Debugging:
| - Jika halaman 404, pastikan nama controller dan method sesuai.
| - Jika akses ditolak, periksa filter role pada group route terkait.
*/
$routes->get('/', 'AuthController::login');
$routes->get('login', 'AuthController::login');
$routes->post('login', 'AuthController::attempt');
$routes->get('logout', 'AuthController::logout');

$routes->group('', ['filter' => 'auth'], static function ($routes) {
    $routes->get('dashboard', 'DashboardController::index');

    if (ENVIRONMENT === 'development') {
        $routes->get('erd', 'ErdController::index');
    }

    $routes->group('users', ['filter' => 'role:admin'], static function ($routes) {
        $routes->get('/', 'UsersController::index');
        $routes->get('create', 'UsersController::create');
        $routes->post('/', 'UsersController::store');
        $routes->get('(:num)/edit', 'UsersController::edit/$1');
        $routes->post('(:num)', 'UsersController::update/$1');
        $routes->post('(:num)/delete', 'UsersController::destroy/$1');
    });

    $routes->group('assets', ['filter' => 'role:admin,operator,pimpinan'], static function ($routes) {
        $routes->get('/', 'AssetsController::index');
        $routes->get('create', 'AssetsController::create', ['filter' => 'role:admin,operator']);
        $routes->post('/', 'AssetsController::store', ['filter' => 'role:admin,operator']);
        $routes->get('(:num)', 'AssetsController::show/$1');
        $routes->get('(:num)/edit', 'AssetsController::edit/$1', ['filter' => 'role:admin,operator']);
        $routes->post('(:num)', 'AssetsController::update/$1', ['filter' => 'role:admin,operator']);
        $routes->post('(:num)/delete', 'AssetsController::destroy/$1', ['filter' => 'role:admin']);
    });

    $routes->group('asset-transactions', ['filter' => 'role:admin,operator,pimpinan'], static function ($routes) {
        $routes->get('/', 'AssetTransactionsController::index');
        $routes->get('create', 'AssetTransactionsController::create', ['filter' => 'role:admin,operator']);
        $routes->post('/', 'AssetTransactionsController::store', ['filter' => 'role:admin,operator']);
        $routes->get('(:num)/pdf', 'AssetTransactionsController::pdf/$1');
        $routes->get('(:num)', 'AssetTransactionsController::show/$1');
        $routes->post('(:num)/return', 'AssetTransactionsController::completeReturn/$1', ['filter' => 'role:admin,operator']);
        $routes->post('(:num)/delete', 'AssetTransactionsController::destroy/$1', ['filter' => 'role:admin']);
    });

    $routes->group('incoming-letters', ['filter' => 'role:admin,operator,pimpinan'], static function ($routes) {
        $routes->get('/', 'IncomingLettersController::index');
        $routes->get('create', 'IncomingLettersController::create', ['filter' => 'role:admin,operator']);
        $routes->post('extract-date', 'IncomingLettersController::extractDate', ['filter' => 'role:admin,operator']);
        $routes->post('/', 'IncomingLettersController::store', ['filter' => 'role:admin,operator']);
        $routes->get('(:num)', 'IncomingLettersController::show/$1');
        $routes->get('(:num)/edit', 'IncomingLettersController::edit/$1', ['filter' => 'role:admin,operator']);
        $routes->post('(:num)', 'IncomingLettersController::update/$1', ['filter' => 'role:admin,operator']);
        $routes->post('(:num)/dispose', 'IncomingLettersController::dispose/$1', ['filter' => 'role:admin,pimpinan']);
        $routes->post('(:num)/status', 'IncomingLettersController::updateStatus/$1', ['filter' => 'role:admin,operator,pimpinan']);
        $routes->post('(:num)/delete', 'IncomingLettersController::destroy/$1', ['filter' => 'role:admin']);
    });

    $routes->group('outgoing-letters', ['filter' => 'role:admin,operator,pimpinan'], static function ($routes) {
        $routes->get('/', 'OutgoingLettersController::index');
        $routes->get('create', 'OutgoingLettersController::create', ['filter' => 'role:admin,operator']);
        $routes->post('/', 'OutgoingLettersController::store', ['filter' => 'role:admin,operator']);
        $routes->get('(:num)', 'OutgoingLettersController::show/$1');
        $routes->get('(:num)/edit', 'OutgoingLettersController::edit/$1', ['filter' => 'role:admin,operator']);
        $routes->post('(:num)', 'OutgoingLettersController::update/$1', ['filter' => 'role:admin,operator']);
        $routes->post('(:num)/delivery', 'OutgoingLettersController::updateDelivery/$1', ['filter' => 'role:admin,operator']);
        $routes->post('(:num)/delete', 'OutgoingLettersController::destroy/$1', ['filter' => 'role:admin']);
    });

    $routes->group('dispositions', ['filter' => 'role:admin,operator,pimpinan'], static function ($routes) {
        $routes->get('/', 'DispositionsController::index');
        $routes->post('(:num)/status', 'DispositionsController::updateStatus/$1');
    });

    $routes->group('reports', ['filter' => 'role:admin,operator,pimpinan'], static function ($routes) {
        $routes->get('/', 'ReportsController::index');
        $routes->get('(:segment)', 'ReportsController::show/$1');
        $routes->get('(:segment)/csv', 'ReportsController::csv/$1');
        $routes->get('(:segment)/print', 'ReportsController::print/$1');
    });

    $routes->group('backup', ['filter' => 'role:admin'], static function ($routes) {
        $routes->get('/', 'BackupController::index');
        $routes->post('download', 'BackupController::download');
    });
});
