<?php
/*
| -------------------------------------------------------------------
| VIEW LOGIN
| -------------------------------------------------------------------
| Halaman ini menjadi pintu masuk aplikasi. Form login mengirim username
| dan password ke AuthController::attempt().
|
| Tips Debugging:
| - Jika login selalu gagal, cek akun di DatabaseSeeder.
| - Jika CSRF error, pastikan csrf_field() tetap ada di dalam form.
*/
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login | SMPI REJIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css" rel="stylesheet">
    <link href="<?= base_url('app-assets/css/app.css') ?>" rel="stylesheet">
</head>
<body>
<main class="auth-shell">
    <section class="auth-panel">
        <div class="d-flex align-items-center gap-3 mb-4">
            <span class="brand-mark"><i class="bi bi-building-check"></i></span>
            <div>
                <h1 class="h4 mb-0">SMPI REJIS</h1>
                <p class="text-muted mb-0">Inventaris Aset & Disposisi Surat</p>
            </div>
        </div>

        <form action="<?= site_url('login') ?>" method="post" autocomplete="off">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label class="form-label" for="username">Username</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-person"></i></span>
                    <input type="text" class="form-control" id="username" name="username" value="<?= old('username') ?>" required autofocus>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label" for="password">Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
            </div>
            <button class="btn btn-success w-100" type="submit">
                <i class="bi bi-box-arrow-in-right me-2"></i>Masuk
            </button>
        </form>

        <div class="border-top mt-4 pt-3 small text-muted">
            Akun awal: admin/admin123, operator/operator123, pimpinan/pimpinan123.
        </div>
    </section>
</main>

<script>
    window.flashMessages = {
        success: <?= json_encode(session('success')) ?>,
        error: <?= json_encode(session('error')) ?>
    };
</script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
<script src="<?= base_url('app-assets/js/app.js') ?>"></script>
</body>
</html>
