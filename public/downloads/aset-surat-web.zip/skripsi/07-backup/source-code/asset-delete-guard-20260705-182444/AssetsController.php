<?php

namespace App\Controllers;

use App\Controllers\Concerns\HandlesUploads;
use App\Models\AssetCategoryModel;
use App\Models\AssetLocationModel;
use App\Models\AssetModel;

class AssetsController extends BaseController
{
    use HandlesUploads;

    /*
    | -------------------------------------------------------------------
    | CONTROLLER INVENTARIS ASET
    | -------------------------------------------------------------------
    | Controller ini mengelola CRUD aset sekolah, pencarian, filter kategori,
    | filter lokasi, filter kondisi, dan upload foto aset.
    |
    | Alur Kerja:
    | - Operator/Admin mencatat aset dari form.
    | - Data disimpan ke tabel assets dengan relasi kategori dan lokasi.
    | - Pimpinan dapat melihat data dan laporan tanpa mengubahnya.
    |
    | Tips Debugging:
    | - Jika halaman aset kosong, jalankan migration dan seeder.
    | - Jika upload foto gagal, cek folder public/uploads/aset.
    */
    private AssetModel $assets;

    public function __construct()
    {
        $this->assets = new AssetModel();
    }

    public function index()
    {
        /*
        | -------------------------------------------------------------------
        | DAFTAR DAN FILTER ASET
        | -------------------------------------------------------------------
        | Query menggunakan join kategori/lokasi dan filter opsional dari query
        | string agar pengguna bisa mencari data dengan cepat.
        |
        | Tips Debugging:
        | - Jika filter tidak bekerja, cek name input pada form filter.
        */
        $filters = [
            'q'          => trim((string) $this->request->getGet('q')),
            'category'   => $this->request->getGet('category'),
            'location'   => $this->request->getGet('location'),
            'condition'  => $this->request->getGet('condition'),
        ];

        $query = $this->assets->withRelations();

        if ($filters['q'] !== '') {
            $query->groupStart()
                ->like('assets.code', $filters['q'])
                ->orLike('assets.name', $filters['q'])
                ->orLike('assets.custodian', $filters['q'])
                ->groupEnd();
        }

        if ($filters['category']) {
            $query->where('assets.category_id', $filters['category']);
        }

        if ($filters['location']) {
            $query->where('assets.location_id', $filters['location']);
        }

        if ($filters['condition']) {
            $query->where('assets.condition_status', $filters['condition']);
        }

        return view('assets/index', [
            'title'      => 'Inventaris Aset',
            'assets'     => $query->orderBy('assets.created_at', 'DESC')->paginate(10),
            'pager'      => $this->assets->pager,
            'filters'    => $filters,
            'categories' => (new AssetCategoryModel())->orderBy('name', 'ASC')->findAll(),
            'locations'  => (new AssetLocationModel())->orderBy('name', 'ASC')->findAll(),
            'conditions' => AssetModel::CONDITIONS,
        ]);
    }

    public function create()
    {
        return view('assets/form', $this->formData('Tambah Aset'));
    }

    public function store()
    {
        /*
        | -------------------------------------------------------------------
        | SIMPAN ASET BARU
        | -------------------------------------------------------------------
        | Data form divalidasi, file foto dipindahkan ke public/uploads/aset,
        | lalu record baru dibuat di tabel assets.
        |
        | Tips Debugging:
        | - Jika kode aset ditolak, pastikan kode belum pernah digunakan.
        | - Jika quantity bernilai 0, cek input jumlah pada form.
        */
        $rules = $this->rules();

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        try {
            $payload = $this->payload();
            $photo   = $this->storeUploadedFile('photo', 'aset', ['jpg', 'jpeg', 'png', 'webp'], 3);

            if ($photo) {
                $payload['photo'] = $photo;
            }

            $this->assets->insert($payload);

            return redirect()->to('/assets')->with('success', 'Data aset berhasil ditambahkan.');
        } catch (\RuntimeException $exception) {
            return redirect()->back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function show(int $id)
    {
        $asset = (new AssetModel())->withRelations()->find($id);

        if (! $asset) {
            return redirect()->to('/assets')->with('error', 'Data aset tidak ditemukan.');
        }

        return view('assets/show', [
            'title' => 'Detail Aset',
            'asset' => $asset,
        ]);
    }

    public function edit(int $id)
    {
        $asset = $this->assets->find($id);

        if (! $asset) {
            return redirect()->to('/assets')->with('error', 'Data aset tidak ditemukan.');
        }

        return view('assets/form', $this->formData('Edit Aset', $asset));
    }

    public function update(int $id)
    {
        /*
        | -------------------------------------------------------------------
        | UPDATE DATA ASET
        | -------------------------------------------------------------------
        | Proses update memakai validasi unik kode aset dengan pengecualian id
        | data saat ini. Jika foto baru diunggah, foto lama dihapus.
        |
        | Tips Debugging:
        | - Jika foto lama masih muncul, refresh browser atau cek path file database.
        */
        $asset = $this->assets->find($id);

        if (! $asset) {
            return redirect()->to('/assets')->with('error', 'Data aset tidak ditemukan.');
        }

        $rules = $this->rules($id);

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        try {
            $payload = $this->payload();
            $photo   = $this->storeUploadedFile('photo', 'aset', ['jpg', 'jpeg', 'png', 'webp'], 3);

            if ($photo) {
                $this->removeUploadedFile($asset['photo'] ?? null);
                $payload['photo'] = $photo;
            }

            $this->assets->update($id, $payload);

            return redirect()->to('/assets')->with('success', 'Data aset berhasil diperbarui.');
        } catch (\RuntimeException $exception) {
            return redirect()->back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function destroy(int $id)
    {
        /*
        | -------------------------------------------------------------------
        | HAPUS DATA ASET
        | -------------------------------------------------------------------
        | Hapus aset hanya dibuka untuk Admin melalui route role. Foto terkait
        | ikut dihapus agar folder upload tetap bersih.
        |
        | Tips Debugging:
        | - Jika tombol hapus tidak tampil, pastikan login sebagai admin.
        */
        $asset = $this->assets->find($id);

        if ($asset) {
            $this->removeUploadedFile($asset['photo'] ?? null);
            $this->assets->delete($id);
        }

        return redirect()->to('/assets')->with('success', 'Data aset berhasil dihapus.');
    }

    private function formData(string $title, ?array $asset = null): array
    {
        /*
        | -------------------------------------------------------------------
        | DATA FORM ASET
        | -------------------------------------------------------------------
        | Mengumpulkan data referensi kategori, lokasi, dan kondisi untuk form
        | tambah/edit agar controller tidak mengulang kode view data.
        */
        return [
            'title'      => $title,
            'asset'      => $asset,
            'categories' => (new AssetCategoryModel())->orderBy('name', 'ASC')->findAll(),
            'locations'  => (new AssetLocationModel())->orderBy('name', 'ASC')->findAll(),
            'conditions' => AssetModel::CONDITIONS,
        ];
    }

    private function rules(?int $id = null): array
    {
        /*
        | -------------------------------------------------------------------
        | RULE VALIDASI ASET
        | -------------------------------------------------------------------
        | Kode aset harus unik. Pada update, id data saat ini dikecualikan agar
        | kode lama tetap boleh dipakai.
        */
        $uniqueCode = $id ? "is_unique[assets.code,id,{$id}]" : 'is_unique[assets.code]';

        return [
            'code'              => "required|max_length[80]|{$uniqueCode}",
            'name'              => 'required|max_length[160]',
            'category_id'       => 'required|is_natural_no_zero',
            'location_id'       => 'permit_empty|is_natural_no_zero',
            'new_location_name' => 'permit_empty|max_length[120]',
            'quantity'          => 'required|is_natural_no_zero',
            'condition_status'  => 'required|in_list[baik,rusak_ringan,rusak_berat,hilang]',
            'acquisition_year'  => 'permit_empty|integer|exact_length[4]',
            'value'             => 'permit_empty|decimal',
        ];
    }

    private function payload(): array
    {
        /*
        | -------------------------------------------------------------------
        | PAYLOAD ASET
        | -------------------------------------------------------------------
        | Method ini mengambil input form dan mengubahnya menjadi struktur array
        | yang sesuai dengan allowedFields AssetModel.
        |
        | Tips Debugging:
        | - Jika data kosong, cek atribut name pada input form.
        */
        $locationId = (int) $this->request->getPost('location_id');
        $newLocationName = trim((string) $this->request->getPost('new_location_name'));

        if ($newLocationName !== '') {
            $locationId = $this->findOrCreateLocation($newLocationName);
        }

        if ($locationId < 1) {
            throw new \RuntimeException('Pilih lokasi aset atau isi lokasi baru.');
        }

        return [
            'code'              => trim((string) $this->request->getPost('code')),
            'name'              => trim((string) $this->request->getPost('name')),
            'category_id'       => (int) $this->request->getPost('category_id'),
            'location_id'       => $locationId,
            'quantity'          => (int) $this->request->getPost('quantity'),
            'condition_status'  => (string) $this->request->getPost('condition_status'),
            'acquisition_year'  => $this->request->getPost('acquisition_year') ?: null,
            'funding_source'    => trim((string) $this->request->getPost('funding_source')),
            'value'             => (float) ($this->request->getPost('value') ?: 0),
            'custodian'         => trim((string) $this->request->getPost('custodian')),
            'notes'             => trim((string) $this->request->getPost('notes')),
        ];
    }

    private function findOrCreateLocation(string $name): int
    {
        /*
        | -------------------------------------------------------------------
        | LOKASI MANUAL ASET
        | -------------------------------------------------------------------
        | Method ini membuat lokasi baru langsung dari form aset bila operator
        | mengetik lokasi yang belum tersedia di dropdown.
        |
        | Alur Kerja:
        | - Sistem mencari nama lokasi yang sama terlebih dahulu.
        | - Jika ada, id lokasi lama dipakai ulang.
        | - Jika belum ada, lokasi baru disimpan ke tabel asset_locations.
        |
        | Tips Debugging:
        | - Jika lokasi baru tidak muncul, cek allowedFields AssetLocationModel.
        | - Jika muncul duplikat, pastikan penulisan nama lokasi konsisten.
        */
        $locations = new AssetLocationModel();
        $existing = $locations->where('name', $name)->first();

        if ($existing) {
            return (int) $existing['id'];
        }

        return (int) $locations->insert(['name' => $name], true);
    }
}
