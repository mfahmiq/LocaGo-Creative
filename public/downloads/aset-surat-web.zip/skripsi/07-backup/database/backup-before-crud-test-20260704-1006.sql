-- Backup SMPI REJIS
-- Database: aset_surat_web
-- Generated: 2026-07-04 10:06:21

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `asset_categories`;
CREATE TABLE `asset_categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `asset_categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('1', 'Meubel', NULL, '2026-06-16 15:10:51', '2026-06-16 15:10:51');
INSERT INTO `asset_categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('2', 'Elektronik', NULL, '2026-06-16 15:10:51', '2026-06-16 15:10:51');
INSERT INTO `asset_categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('3', 'Buku & Dokumen', NULL, '2026-06-16 15:10:51', '2026-06-16 15:10:51');
INSERT INTO `asset_categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('4', 'Sarana Pembelajaran', NULL, '2026-06-16 15:10:51', '2026-06-16 15:10:51');
INSERT INTO `asset_categories` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('5', 'Peralatan Kantor', NULL, '2026-06-16 15:10:51', '2026-06-16 15:10:51');

DROP TABLE IF EXISTS `asset_locations`;
CREATE TABLE `asset_locations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `description` text COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `asset_locations` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('1', 'Ruang TU', NULL, '2026-06-16 15:10:51', '2026-06-16 15:10:51');
INSERT INTO `asset_locations` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('2', 'Ruang Kepala Sekolah', NULL, '2026-06-16 15:10:51', '2026-06-16 15:10:51');
INSERT INTO `asset_locations` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('3', 'Kelas VII', NULL, '2026-06-16 15:10:51', '2026-06-16 15:10:51');
INSERT INTO `asset_locations` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('4', 'Perpustakaan', NULL, '2026-06-16 15:10:51', '2026-06-16 15:10:51');
INSERT INTO `asset_locations` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES ('5', 'Laboratorium', NULL, '2026-06-16 15:10:51', '2026-06-16 15:10:51');

DROP TABLE IF EXISTS `asset_transaction_items`;
CREATE TABLE `asset_transaction_items` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `asset_transaction_id` int unsigned NOT NULL,
  `asset_id` int unsigned DEFAULT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `condition_before` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'baik',
  `condition_after` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asset_transaction_items_asset_id_foreign` (`asset_id`),
  KEY `asset_transaction_id_asset_id` (`asset_transaction_id`,`asset_id`),
  CONSTRAINT `asset_transaction_items_asset_id_foreign` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE RESTRICT ON UPDATE SET NULL,
  CONSTRAINT `asset_transaction_items_asset_transaction_id_foreign` FOREIGN KEY (`asset_transaction_id`) REFERENCES `asset_transactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `asset_transactions`;
CREATE TABLE `asset_transactions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `transaction_code` varchar(80) COLLATE utf8mb4_general_ci NOT NULL,
  `borrower_unit` varchar(160) COLLATE utf8mb4_general_ci NOT NULL,
  `borrower_name` varchar(160) COLLATE utf8mb4_general_ci NOT NULL,
  `purpose` text COLLATE utf8mb4_general_ci,
  `loan_date` date NOT NULL,
  `expected_return_date` date DEFAULT NULL,
  `actual_return_date` date DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'dipinjam',
  `notes` text COLLATE utf8mb4_general_ci,
  `created_by` int unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_code` (`transaction_code`),
  KEY `asset_transactions_created_by_foreign` (`created_by`),
  KEY `status_loan_date` (`status`,`loan_date`),
  CONSTRAINT `asset_transactions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `assets`;
CREATE TABLE `assets` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(80) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(160) COLLATE utf8mb4_general_ci NOT NULL,
  `category_id` int unsigned NOT NULL,
  `location_id` int unsigned NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `condition_status` varchar(40) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'baik',
  `acquisition_year` int DEFAULT NULL,
  `funding_source` varchar(120) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `value` decimal(14,2) NOT NULL DEFAULT '0.00',
  `custodian` varchar(120) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_general_ci,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `assets_location_id_foreign` (`location_id`),
  KEY `category_id_location_id_condition_status` (`category_id`,`location_id`,`condition_status`),
  CONSTRAINT `assets_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `asset_categories` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `assets_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `asset_locations` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `assets` (`id`, `code`, `name`, `category_id`, `location_id`, `quantity`, `condition_status`, `acquisition_year`, `funding_source`, `value`, `custodian`, `photo`, `notes`, `created_at`, `updated_at`) VALUES ('1', 'AST-2026-001', 'Meja Administrasi', '1', '1', '4', 'baik', '2026', 'BOS', '2400000.00', 'Tata Usaha', NULL, 'Inventaris ruang pelayanan administrasi.', '2026-06-16 15:10:51', '2026-06-16 15:10:51');
INSERT INTO `assets` (`id`, `code`, `name`, `category_id`, `location_id`, `quantity`, `condition_status`, `acquisition_year`, `funding_source`, `value`, `custodian`, `photo`, `notes`, `created_at`, `updated_at`) VALUES ('2', 'AST-2026-002', 'Laptop Pimpinan', '2', '2', '1', 'baik', '2026', 'Komite', '8500000.00', 'Kepala Sekolah', NULL, 'Digunakan untuk administrasi pimpinan.', '2026-06-16 15:10:51', '2026-06-16 15:10:51');

DROP TABLE IF EXISTS `dispositions`;
CREATE TABLE `dispositions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `incoming_letter_id` int unsigned NOT NULL,
  `target_unit` varchar(160) COLLATE utf8mb4_general_ci NOT NULL,
  `instruction` text COLLATE utf8mb4_general_ci NOT NULL,
  `due_date` date DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pending',
  `disposed_by` int unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dispositions_disposed_by_foreign` (`disposed_by`),
  KEY `incoming_letter_id_status` (`incoming_letter_id`,`status`),
  CONSTRAINT `dispositions_disposed_by_foreign` FOREIGN KEY (`disposed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `dispositions_incoming_letter_id_foreign` FOREIGN KEY (`incoming_letter_id`) REFERENCES `incoming_letters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `incoming_letters`;
CREATE TABLE `incoming_letters` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `letter_number` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `letter_date` date NOT NULL,
  `received_date` date NOT NULL,
  `sender` varchar(160) COLLATE utf8mb4_general_ci NOT NULL,
  `subject` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `priority` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Biasa',
  `summary` text COLLATE utf8mb4_general_ci,
  `attachment` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'menunggu_disposisi',
  `created_by` int unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `incoming_letters_created_by_foreign` (`created_by`),
  KEY `status_received_date` (`status`,`received_date`),
  CONSTRAINT `incoming_letters_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `incoming_letters` (`id`, `letter_number`, `letter_date`, `received_date`, `sender`, `subject`, `priority`, `summary`, `attachment`, `status`, `created_by`, `created_at`, `updated_at`) VALUES ('1', '421/001/DISDIK/2026', '2026-06-16', '2026-06-16', 'Dinas Pendidikan', 'Undangan Rapat Koordinasi', 'Penting', 'Undangan rapat koordinasi program sekolah.', NULL, 'menunggu_disposisi', '1', '2026-06-16 15:10:51', '2026-06-16 15:10:51');
INSERT INTO `incoming_letters` (`id`, `letter_number`, `letter_date`, `received_date`, `sender`, `subject`, `priority`, `summary`, `attachment`, `status`, `created_by`, `created_at`, `updated_at`) VALUES ('2', '16062026/SDITRejis/001', '2026-06-16', '2026-06-16', 'Mis. Endah', 'Undangan Wisuda Thafiz untuk Kepala Sekoalh ataau mananjemen Sekolah', 'Biasa', 'Undangan Wisuda Tahfiz SD IT Rejis', 'uploads/surat/1781624492_b49b60e9ac6914161f18.pdf', 'selesai', '4', '2026-06-16 22:41:32', '2026-06-16 22:45:17');

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `group` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `namespace` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `time` int NOT NULL,
  `batch` int unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('1', '2026-06-16-000001', 'App\\Database\\Migrations\\CreateSmpiRejisTables', 'default', 'App', '1781622642', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('2', '2026-06-16-000002', 'App\\Database\\Migrations\\CreateAssetTransactionTables', 'default', 'App', '1781624851', '2');

DROP TABLE IF EXISTS `outgoing_letters`;
CREATE TABLE `outgoing_letters` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `letter_number` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `letter_date` date NOT NULL,
  `recipient` varchar(160) COLLATE utf8mb4_general_ci NOT NULL,
  `destination_unit` varchar(160) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subject` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `attachment` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'dicatat',
  `receiver_name` varchar(120) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `received_date` date DEFAULT NULL,
  `delivery_notes` text COLLATE utf8mb4_general_ci,
  `created_by` int unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `outgoing_letters_created_by_foreign` (`created_by`),
  KEY `status_letter_date` (`status`,`letter_date`),
  CONSTRAINT `outgoing_letters_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `outgoing_letters` (`id`, `letter_number`, `letter_date`, `recipient`, `destination_unit`, `subject`, `attachment`, `status`, `receiver_name`, `received_date`, `delivery_notes`, `created_by`, `created_at`, `updated_at`) VALUES ('1', 'SMPI/OUT/001/2026', '2026-06-16', 'Unit SD', 'Unit SD', 'Pemberitahuan Koordinasi Kegiatan', NULL, 'siap_dikirim', NULL, NULL, NULL, '1', '2026-06-16 15:10:51', '2026-06-16 15:10:51');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(80) COLLATE utf8mb4_general_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `role` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`id`, `name`, `username`, `password_hash`, `role`, `is_active`, `last_login_at`, `created_at`, `updated_at`) VALUES ('1', 'Administrator Sistem', 'admin', '$2y$12$ZwuXz/ZLEPHscFi26AT5Uu6I.AJB5ifohGzI8zkOT9k7ooap1V9Ai', 'admin', '1', '2026-07-04 10:06:18', '2026-06-16 15:10:51', '2026-07-04 10:06:18');
INSERT INTO `users` (`id`, `name`, `username`, `password_hash`, `role`, `is_active`, `last_login_at`, `created_at`, `updated_at`) VALUES ('2', 'Staf Tata Usaha', 'operator', '$2y$12$14B4ojJp8fqvqSwC6rcmrewqfkYKo/hdUr2HGp/2GeQLluMpgFRBa', 'operator', '1', '2026-07-04 09:59:30', '2026-06-16 15:10:51', '2026-07-04 09:59:30');
INSERT INTO `users` (`id`, `name`, `username`, `password_hash`, `role`, `is_active`, `last_login_at`, `created_at`, `updated_at`) VALUES ('3', 'Kepala Sekolah', 'pimpinan', '$2y$12$cnJ03Pl76jban20KvUtG5.uK9fP34OSO4pHbP9a0I0eS55yiB.NwK', 'pimpinan', '1', '2026-07-04 09:59:31', '2026-06-16 15:10:51', '2026-07-04 09:59:31');
INSERT INTO `users` (`id`, `name`, `username`, `password_hash`, `role`, `is_active`, `last_login_at`, `created_at`, `updated_at`) VALUES ('4', 'Ustzah. Rini', 'rini@rejis.com', '$2y$12$i43gbUgjWbvAk4b2KUOlteBqiAM7.avNJIKuAsA.2KCswjKT5vyaW', 'operator', '1', '2026-06-16 15:37:54', '2026-06-16 15:37:16', '2026-06-16 15:37:54');

SET FOREIGN_KEY_CHECKS=1;
