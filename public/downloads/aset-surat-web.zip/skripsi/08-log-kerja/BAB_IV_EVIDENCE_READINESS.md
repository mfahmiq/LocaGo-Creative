# BAB_IV_EVIDENCE_READINESS

## Status

- Tanggal dibuat: 2026-07-04
- Tujuan: menilai kesiapan bukti untuk penulisan BAB IV Implementasi dan Pengujian Software.
- Catatan: file ini bukan draft BAB IV final.

## Bukti Implementasi yang Sudah Tersedia

Bukti implementasi yang sudah tersedia:

- Struktur aplikasi CodeIgniter 4.
- Dependency Composer dan CodeIgniter framework v4.7.3.
- Route utama aplikasi dari `php spark routes`.
- Controller untuk modul autentikasi, dashboard, pengguna, aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, backup, dan ERD.
- Model untuk tabel utama.
- View untuk halaman utama setiap modul.
- Migration dan SQL dump struktur database.
- Dokumentasi ERD dalam `ErdController.php` dan view ERD.
- Library pendukung PDF dan ekstraksi tanggal.
- Trait upload file.
- Helper autentikasi dan role.
- Hasil HTTP terbatas: `/` dan `/login` merespons 200; route internal redirect ke login tanpa session.

Sumber:

- `APPLICATION_VERIFICATION.md`
- `APLIKASI_FEATURE_AUDIT.md`
- `DATABASE_ERD_AUDIT.md`
- `app/Config/Routes.php`
- `app/Controllers/*.php`
- `app/Models/*.php`
- `app/Views/*`
- `app/Database/Migrations/*.php`
- `database/*.sql`

## Bukti Screenshot yang Perlu Diambil

Screenshot yang perlu diambil:

- Login.
- Dashboard.
- Menu utama.
- Pengguna.
- Daftar aset.
- Form aset.
- Detail aset.
- Daftar transaksi aset.
- Form transaksi aset.
- Pengembalian aset.
- Daftar surat masuk.
- Form surat masuk.
- Detail surat masuk.
- Disposisi surat.
- Daftar disposisi.
- Daftar surat keluar.
- Form surat keluar.
- Detail surat keluar.
- Laporan.
- Cetak laporan.
- Backup.

Sumber daftar: `SCREENSHOT_REQUIREMENTS.md`.

## Skenario Testing yang Sudah Tersedia

Skenario testing yang sudah disiapkan:

- Login.
- Redirect route internal tanpa session.
- Dashboard.
- Manajemen pengguna.
- Aset.
- Upload foto aset.
- Transaksi aset.
- Pengembalian aset.
- PDF transaksi.
- Surat masuk.
- Upload lampiran surat.
- Ekstraksi tanggal surat.
- Disposisi.
- Surat keluar.
- Laporan show/CSV/print.
- Backup database.
- Role access.
- ERD sebagai route dokumentasi dev-only/arsip, bukan pengujian UI operasional final.

Sumber: `BLACKBOX_TEST_SCENARIOS.md`.

## Skenario Testing yang Masih Kurang

Skenario yang masih perlu dilengkapi setelah aplikasi bisa login:

- Hasil aktual untuk login valid dan login gagal.
- Hasil aktual untuk semua CRUD.
- Hasil aktual validasi field wajib.
- Hasil aktual upload file valid dan tidak valid.
- Hasil aktual export PDF, CSV, print, dan backup.
- Hasil aktual pembatasan role admin/operator/pimpinan.
- Hasil aktual sinkronisasi status disposisi dan surat masuk.
- Hasil aktual status pengiriman surat keluar.

## Diagram yang Sudah Cukup

Sumber diagram yang sudah cukup sebagai bahan:

- ERD dari `ErdController.php`.
- Struktur database dari migration dan SQL.
- Mapping role dan route dari `Routes.php`.
- Struktur MVC dari controller, model, view, filter, helper, library, dan trait.

Catatan:

- Source diagram dan output SVG prioritas sudah dibuat. Pemilihan nomor caption final masih menunggu susunan BAB/DOCX.

## Diagram yang Masih Perlu Dibuat

Diagram yang masih perlu dibuat:

- Use Case Diagram.
- Activity Diagram login.
- Activity Diagram manajemen aset.
- Activity Diagram transaksi aset.
- Activity Diagram surat masuk dan disposisi.
- Activity Diagram surat keluar.
- ERD final skripsi.
- LRS.
- Arsitektur MVC.
- Sequence Diagram.
- Class Diagram.
- Deployment Diagram.
- Diagram Scrum Flow bila dibutuhkan.

Sumber daftar: `DIAGRAM_REQUIREMENTS.md`.

Pembaruan 2026-07-04:

- Source dan SVG sudah tersedia untuk diagram prioritas: Use Case, Activity Login, Activity Inventaris Aset, Activity Surat Masuk dan Disposisi, Sequence Login, Sequence Transaksi Aset, Sequence Disposisi Surat, Class Diagram, ERD Final, Deployment Diagram, dan Arsitektur MVC.
- Draft LRS sudah tersedia di `skripsi/04-diagram-dan-gambar/LRS_DRAFT.md`.
- Output diagram tersedia di `skripsi/04-diagram-dan-gambar/diagram-output/`.
- Screenshot final tanpa menu ERD sudah tersedia: `21-dashboard-final-tanpa-erd.png` dan `22-sidebar-final-admin.png`.
- Activity Diagram Transaksi Aset, Activity Diagram Surat Keluar, dan Diagram Scrum Flow sudah dibuat pada quality gate dan berhasil dirender ke SVG.
- Quality review diagram tersedia di `DIAGRAM_QUALITY_REVIEW.md`.

## Risiko Sebelum BAB IV Ditulis

Risiko utama:

- Database aktif belum terkoneksi saat verifikasi, sehingga modul setelah login belum bisa diuji.
- Screenshot halaman internal belum tersedia.
- Hasil aktual black-box testing belum tersedia untuk sebagian besar skenario.
- Status publikasi software belum dipastikan.
- Spesifikasi hardware/software final belum dipastikan.
- Bukti Scrum historis belum tersedia eksplisit.
- Diagram SVG sudah dibuat, tetapi beberapa diagram padat perlu layout besar/landscape saat masuk DOCX.

## Rekomendasi Urutan Pengerjaan BAB IV

Urutan yang direkomendasikan:

1. Aktifkan MySQL/MariaDB Laragon dan ulangi verifikasi database.
2. Login lokal menggunakan akun demo tanpa mencatat credential di dokumen.
3. Ambil screenshot halaman sesuai `SCREENSHOT_REQUIREMENTS.md`.
4. Jalankan skenario pengujian pada `BLACKBOX_TEST_SCENARIOS.md` dan isi hasil aktual.
5. Buat ERD final dan LRS dari sumber database.
6. Buat Use Case Diagram dan Activity Diagram modul inti untuk mendukung BAB III/BAB IV.
7. Buat Arsitektur MVC, Sequence Diagram, dan Deployment Diagram.
8. Setelah bukti cukup, mulai susun draft BAB IV mengikuti outline 156:
   - `4.1 Desain`
   - `4.1.1 Database`
   - `4.1.2 Software Architecture`
   - `4.1.3 User Interface`
   - `4.2 Code Generation`
   - `4.3 Testing`
   - `4.4 Support`

## Bagian yang Belum Boleh Ditulis Sebagai Fakta Final

- Pernyataan final BAB IV yang mengikat hasil testing dan screenshot ke nomor gambar/tabel.
- Publikasi software.
- Deployment internet/intranet.
- Bukti sprint Scrum historis.
- Isi database aktif di luar ringkasan non-sensitif yang sudah diverifikasi.

## Pembaruan Setelah Verifikasi Laragon Aktif

Tanggal pembaruan: 2026-07-04

Status database:

- Database aktif berhasil terkoneksi.
- `php spark migrate:status` berhasil membaca dua migration yang sudah berjalan.
- Credential database tidak dibuka dan tidak ditampilkan.

Status aplikasi:

- Server lokal berjalan pada `http://localhost:8080`.
- Login lokal menggunakan akun demo berhasil tanpa mencatat detail credential.
- Login tidak valid dengan data dummy tetap berada di halaman login.
- Modul internal utama berhasil dibuka setelah login admin:
  - Dashboard.
  - ERD.
  - Pengguna.
  - Aset.
  - Form tambah aset.
  - Transaksi aset.
  - Form transaksi aset.
  - Surat masuk.
  - Form surat masuk.
  - Disposisi.
  - Surat keluar.
  - Form surat keluar.
  - Laporan.
  - Laporan aset.
  - Cetak laporan aset.
  - Backup.

Screenshot yang sudah tersedia:

- `01-login.png`
- `02-dashboard-admin.png`
- `03-data-aset.png`
- `04-tambah-aset.png`
- `05-surat-masuk.png`
- `06-disposisi-surat.png`
- `07-surat-keluar.png`
- `08-laporan.png`
- `09-backup.png`
- `10-erd-database.png`

Status black-box testing:

- Total skenario pada `BLACKBOX_TEST_SCENARIOS.md`: 42.
- Valid: 23.
- Gagal: 0.
- Belum diverifikasi: 19.

Risiko yang tersisa:

- Pengujian CRUD yang mengubah database belum dilakukan.
- Pengujian upload foto/lampiran belum dilakukan.
- Pengujian ekstraksi tanggal lampiran belum dilakukan.
- Pengujian PDF transaksi belum dilakukan.
- Screenshot detail record tertentu belum lengkap jika dibutuhkan untuk BAB IV.

Rekomendasi berikutnya:

1. Tentukan apakah pengujian boleh membuat data dummy sementara.
2. Jika boleh, lanjutkan pengujian CRUD, upload, status disposisi, status surat keluar, dan PDF transaksi.
3. Jika tidak boleh mengubah database, gunakan screenshot dan hasil GET/akses halaman sebagai bukti implementasi awal.
4. Lanjutkan membuat diagram prioritas: Use Case, Activity, ERD final, LRS, dan Arsitektur MVC.

## Pembaruan Setelah Pengujian CRUD Terkontrol

Tanggal pembaruan: 2026-07-04

Bukti pengujian tambahan:

- Backup database sebelum CRUD tersedia di `skripsi/07-backup/database/backup-before-crud-test-20260704-1006.sql`.
- Data dummy berhasil dibuat untuk aset, transaksi aset, surat masuk, disposisi, surat keluar, dan pengguna dummy nonaktif.
- Upload foto aset dummy berhasil.
- Upload lampiran surat masuk dan surat keluar dummy berhasil.
- Validasi input kosong pada form penting berhasil diuji.
- Validasi upload format tidak valid berhasil diuji tanpa membuat record detail.
- PDF transaksi aset berhasil diunduh sebagai respons `application/pdf`.
- Pengembalian aset berhasil diuji.
- Status disposisi berhasil diubah menjadi selesai.
- Status surat keluar berhasil diubah menjadi diterima tujuan.

Status black-box testing terbaru:

- Total skenario: 42.
- Valid: 42.
- Gagal: 0.
- Belum diverifikasi: 0.

Screenshot dan bukti visual terbaru:

- Total screenshot PNG: 19.
- Bukti PDF transaksi: 1 file PDF hasil download.
- Folder: `skripsi/04-diagram-dan-gambar/screenshots/`.

Risiko yang tersisa:

- Data dummy masih berada di database agar dapat diperiksa ulang.
- Pengujian delete tidak dilakukan karena tidak boleh menghapus data lama.
- Jika database perlu kembali bersih, perlu tahap cleanup terkontrol setelah user menyetujui.
- Screenshot PDF transaksi tidak dibuat karena renderer lokal tidak dapat membaca PDF sederhana dari library aplikasi; bukti PDF dicatat dari respons HTTP dan file hasil download.

Rekomendasi menuju BAB IV:

1. Gunakan hasil black-box terbaru sebagai dasar tabel `4.3 Testing`.
2. Gunakan screenshot 01-18 dan 20 sebagai bukti `4.1.3 User Interface`.
3. Gunakan file PDF transaksi sebagai bukti fitur cetak/download transaksi, tanpa memasukkan isi PDF jika tidak perlu.
4. Lanjutkan tahap diagram prioritas: Use Case, Activity Diagram, ERD final, LRS, dan Arsitektur MVC.

## Pembaruan Change Request Menu ERD

Tanggal pembaruan: 2026-07-04

Bukti implementasi final yang diperbarui:

- Sidebar desktop dan menu mobile tidak lagi menampilkan `ERD Database`.
- Dashboard tetap merespons HTTP 200 setelah login lokal.
- Menu operasional lain tetap tampil sesuai verifikasi admin: Dashboard, Pengguna, Inventaris Aset, Transaksi Aset, Surat Masuk, Surat Keluar, Disposisi, Laporan, dan Backup.
- Route `/erd` dibuat dev-only melalui guard `ENVIRONMENT === 'development'`.
- `ErdController.php` tetap ada sebagai sumber dokumentasi ERD untuk skripsi.

Dampak ke BAB IV:

- Screenshot ERD tidak digunakan sebagai bukti user interface aplikasi final.
- ERD tetap ditulis sebagai diagram rancangan/database, bukan sebagai menu aplikasi operasional.
- Jika screenshot dashboard final akan dimasukkan ke `4.1.3 User Interface`, sebaiknya ambil ulang screenshot dashboard/sidebar setelah perubahan ini.

Risiko tersisa:

- Environment lokal masih `development`, sehingga `/erd` tetap dapat diakses setelah login pada verifikasi lokal.
- Untuk deployment operasional, environment harus diset ke non-development agar route `/erd` tidak didaftarkan.

## Pembaruan Quality Gate Sebelum Drafting

Tanggal pembaruan: 2026-07-04

- `DOCX_FORMAT_SPEC.md` tersedia sebagai acuan format awal DOCX.
- `PERSEPSI_PROJECT_CHECKPOINT.md` tersedia sebagai checkpoint sebelum drafting.
- Diagram yang paling siap masuk BAB IV: sequence login, sequence disposisi, deployment, arsitektur MVC, dan Scrum flow.
- Diagram yang perlu layout besar/landscape: ERD, class diagram, sequence transaksi, dan activity diagram panjang.
- Draft BAB IV belum dibuat dan `SKRIPSI.docx` belum dibuat.
