@echo off
set PY="C:\laragon\bin\python\python-3.10\python.exe"
set SCRIPT="C:\laragon\www\aset-surat-web\skripsi\08-log-kerja\create_babiv_docx.py"
%PY% %SCRIPT%
pause
