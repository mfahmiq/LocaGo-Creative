# WORKSPACE_AUDIT.md

Tanggal audit: 2026-07-04
Workspace: `C:\laragon\www\aset-surat-web`
Mode audit: read-only untuk file lama

## Ringkasan

Workspace berisi aplikasi web CodeIgniter 4 untuk manajemen inventaris aset dan disposisi surat pada SMPI REJIS serta folder `skripsi/` untuk dokumen akademik pendukung. Audit awal dilakukan tanpa mengubah file lama, tanpa membaca isi `.env`, dan tanpa menampilkan data sensitif.

## Struktur Workspace Utama

Folder penting yang ditemukan:

1. `.git`
2. `.refact`
3. `app`
4. `build`
5. `database`
6. `public`
7. `skripsi`
8. `tests`
9. `vendor`
10. `writable`

File root penting yang ditemukan:

1. `.env` - ada, tidak dibaca.
2. `.gitignore`
3. `composer.json`
4. `composer.lock`
5. `env`
6. `LICENSE`
7. `phpunit.dist.xml`
8. `preload.php`
9. `README.md`
10. `spark`

## Status Git Awal

Branch aktif: `main`

Commit terakhir:

```text
284041e 2026-06-29 19:01:21 +0700 Initial public release
```

Worktree sudah memiliki perubahan sebelum file panduan dibuat. Perubahan tersebut tidak disentuh dalam audit.

File yang terlihat modified/untracked saat audit awal:

```text
M app/Config/Routes.php
M app/Controllers/AssetTransactionsController.php
M app/Views/asset_transactions/index.php
M app/Views/asset_transactions/show.php
M app/Views/layouts/main.php
M public/app-assets/css/app.css
?? app/Controllers/ErdController.php
?? app/Libraries/SimplePdf.php
?? app/Views/erd/
?? skripsi/
```

## File Skripsi Yang Ditemukan

Di folder `skripsi/` ditemukan:

1. `outline.pdf`
   - Ukuran: 2.089.289 bytes.
   - Halaman: 9.
   - Metadata title: Handout Skripsi Prodi Teknologi Informasi Periode I Tahun 2024.pdf.
   - Teks tidak terbaca melalui ekstraksi biasa pada audit awal.
2. `pedoman.pdf`
   - Ukuran: 6.596.544 bytes.
   - Halaman: 18.
   - Metadata title: Pedoman Laporan Skripsi TA Universitas BSI Periode 2025 (1).pdf.
   - Teks tidak terbaca melalui ekstraksi biasa pada audit awal.
3. `Transkrip Wawancara Riset.pdf`
   - Ukuran: 79.998 bytes.
   - Halaman: 5.
   - Teks dapat diekstrak.
   - Author metadata: Maulana El Shidqi.

## Ringkasan Transkrip Wawancara

Transkrip memuat penelitian berjudul Perancangan Sistem Terintegrasi Inventaris Aset dan Disposisi Surat Berbasis Web pada SMPI REJIS.

Poin kebutuhan dan masalah awal:

1. Pencatatan inventaris aset masih manual.
2. Excel pernah dicoba tetapi tidak berlanjut.
3. Data yang perlu dicatat meliputi barang masuk, barang keluar, letak barang, dan peminjaman barang.
4. Kendala aset mencakup pencatatan barang masuk/keluar yang belum rapi dan barang pinjaman yang kadang tidak kembali ke tempat semula.
5. Proses surat dan disposisi masih manual.
6. Arsip surat masuk dan keluar masih terpisah.
7. Dibutuhkan pemantauan status surat, arsip digital, dan laporan.
8. Aktor kebutuhan mencakup Admin TU, Kepala Sekolah, dan Staff.

## Struktur Aplikasi Web

Aplikasi berbasis CodeIgniter 4.

Versi/lingkungan yang terdeteksi:

```text
PHP CLI: 8.4.10
Composer: 2.8.9
CodeIgniter framework: v4.7.3
```

Modul controller yang ditemukan:

1. `AuthController`
2. `DashboardController`
3. `UsersController`
4. `AssetsController`
5. `AssetTransactionsController`
6. `IncomingLettersController`
7. `DispositionsController`
8. `OutgoingLettersController`
9. `ReportsController`
10. `BackupController`
11. `ErdController`

Folder view utama:

1. `assets`
2. `asset_transactions`
3. `auth`
4. `backup`
5. `dashboard`
6. `dispositions`
7. `erd`
8. `incoming_letters`
9. `layouts`
10. `outgoing_letters`
11. `reports`
12. `users`

## Route Dan Hak Akses

Route publik:

1. `/`
2. `/login`
3. `POST /login`
4. `/logout`

Route internal dilindungi filter `auth`. Modul sensitif memakai filter role:

1. `users` - admin.
2. `assets` - admin, operator, pimpinan; create/update terbatas admin/operator; delete admin.
3. `asset-transactions` - admin, operator, pimpinan; create/return terbatas admin/operator; delete admin.
4. `incoming-letters` - admin, operator, pimpinan; create/update operator/admin; disposisi admin/pimpinan.
5. `outgoing-letters` - admin, operator, pimpinan; create/update operator/admin.
6. `dispositions` - admin, operator, pimpinan.
7. `reports` - admin, operator, pimpinan.
8. `backup` - admin.

## Database Dan SQL

Folder `database/` berisi:

1. `aset_surat_web_full.sql`
2. `aset_surat_web_full_utf8.sql`
3. `aset_surat_web_phpmyadmin_utf8.sql`

Ketiga file SQL berisi struktur tabel tanpa `INSERT`.

Tabel yang ditemukan:

1. `asset_categories`
2. `asset_locations`
3. `asset_transaction_items`
4. `asset_transactions`
5. `assets`
6. `dispositions`
7. `incoming_letters`
8. `migrations`
9. `outgoing_letters`
10. `users`

Relasi penting:

1. `asset_categories` ke `assets`.
2. `asset_locations` ke `assets`.
3. `users` ke `incoming_letters`.
4. `incoming_letters` ke `dispositions`.
5. `users` ke `dispositions`.
6. `users` ke `outgoing_letters`.
7. `users` ke `asset_transactions`.
8. `asset_transactions` ke `asset_transaction_items`.
9. `assets` ke `asset_transaction_items`.

## Artefak Visual

Artefak visual terpisah seperti gambar UML/LRS belum ditemukan pada audit awal.

Sumber visual/diagram yang tersedia:

1. `app/Controllers/ErdController.php` berisi Mermaid ERD dan dokumentasi tabel.
2. `app/Views/erd/index.php` menampilkan ERD dan tabel relasi.

Folder `public/uploads/surat/` berisi satu file PDF upload. File tersebut tidak dibaca karena dapat berisi dokumen operasional.

## Tests

Folder `tests/` masih berisi contoh bawaan/awal:

1. `tests/database/ExampleDatabaseTest.php`
2. `tests/session/ExampleSessionTest.php`
3. `tests/unit/HealthTest.php`

Belum ditemukan test khusus untuk fitur skripsi atau modul aplikasi.

## File Yang Belum Ditemukan

1. `SKRIPSI.docx`.
2. Draft BAB I sampai BAB V dalam `.docx`.
3. File referensi atau sitasi terstruktur.
4. File UML/LRS/use case/activity/class/sequence terpisah.
5. Template Word resmi kampus.
6. Artefak Scrum eksplisit seperti backlog, sprint planning, sprint review, atau sprint retrospective.

## Risiko Awal

1. Pedoman dan outline belum bisa dibaca sebagai teks biasa; perlu OCR/render.
2. Format kampus belum boleh disimpulkan sebelum pedoman dan outline terbaca jelas.
3. Metode BAB IV harus Agile Scrum, sedangkan bukti Scrum belum tersedia.
4. Aplikasi memiliki file runtime, session, log, debugbar, upload, dan `.env` yang harus dijaga agar tidak terbaca/terpublikasi.
5. Worktree Git sudah dirty sebelum pekerjaan dimulai, sehingga perlu hati-hati agar tidak mengganggu perubahan existing.

## Pembaruan Setelah Persetujuan Struktur

Setelah user menyetujui struktur folder, folder kerja baru dibuat di `skripsi/` sesuai struktur yang disetujui. File koordinasi lintas sesi juga dibuat sebagai file baru:

1. `AGENTS.md`
2. `MEMORY.md`
3. `TOOLS.md`
4. `skripsi/08-log-kerja/WORKSPACE_AUDIT.md`

Render awal pedoman dan outline dibuat sebagai file PNG baru:

1. `skripsi/01-pedoman-dan-outline/render-pedoman/` - 18 PNG.
2. `skripsi/01-pedoman-dan-outline/render-outline/` - 9 PNG.
3. `skripsi/01-pedoman-dan-outline/ocr-render-status.md` - catatan status render/OCR.

PDF asli tidak diubah. OCR teks otomatis belum dilakukan karena OCR engine lokal belum tersedia.

## Rekomendasi Awal

1. Gunakan `pedoman.pdf` dan `outline.pdf` sebagai sumber utama setelah OCR atau review visual dari render.
2. Gunakan transkrip wawancara sebagai dasar masalah, kebutuhan sistem, aktor, dan manfaat.
3. Gunakan route/controller/model/migration/ERD sebagai dasar BAB III dan BAB IV.
4. Buat ringkasan aturan pedoman dan outline setelah OCR cukup jelas.
5. Jangan membuat `SKRIPSI.docx` atau draft BAB sebelum pedoman dan outline dipahami.
