# INVENTORY_REQUEST_FEATURE_IMPLEMENTATION

## Status

- Tanggal implementasi: 2026-07-05.
- Modul: Pengajuan Inventaris.
- Status: berhasil diimplementasikan dan diverifikasi pada lingkungan lokal Laragon.
- Catatan keamanan: credential, password, token, session, cookie, dan API key tidak dicantumkan pada dokumen ini.

## Ringkasan Fitur

Modul Pengajuan Inventaris dibuat untuk mencatat pengajuan kebutuhan inventaris sekolah, meliputi peminjaman aset, pengadaan aset, perbaikan aset, dan penggantian aset. Admin dan operator dapat membuat pengajuan, sedangkan admin dan pimpinan dapat menyetujui atau menolak pengajuan. Setiap pengajuan dapat diunduh sebagai dokumen PDF.

Status yang didukung:

1. `diajukan`
2. `diproses`
3. `disetujui`
4. `ditolak`
5. `direalisasikan`
6. `selesai`

Status yang sudah diuji langsung: `diajukan`, `disetujui`, dan `ditolak`.

## File Yang Dibuat

Source code baru:

1. `app/Database/Migrations/2026-07-05-000001_CreateInventoryRequestTables.php`
2. `app/Models/InventoryRequestModel.php`
3. `app/Models/InventoryRequestItemModel.php`
4. `app/Controllers/InventoryRequestsController.php`
5. `app/Views/inventory_requests/index.php`
6. `app/Views/inventory_requests/create.php`
7. `app/Views/inventory_requests/edit.php`
8. `app/Views/inventory_requests/show.php`
9. `app/Views/inventory_requests/partials/form.php`

Dokumentasi baru:

1. `skripsi/08-log-kerja/INVENTORY_REQUEST_FEATURE_IMPLEMENTATION.md`
2. `skripsi/02-data-aplikasi/INVENTORY_REQUEST_DATABASE_PATCH.md`
3. `skripsi/02-data-aplikasi/INVENTORY_REQUEST_ROUTE_AUDIT.md`
4. `skripsi/03-draft-bab/SKRIPSI-IMPACT-PENGAJUAN-INVENTARIS.md`
5. `skripsi/03-draft-bab/BLACKBOX-PENGAJUAN-INVENTARIS.md`

Screenshot bukti:

1. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-daftar-pengajuan-inventaris.png`
2. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-form-pengajuan-inventaris.png`
3. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-detail-pengajuan-inventaris.png`
4. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-approval-pengajuan-inventaris.png`
5. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-pdf-pengajuan-inventaris.png`

## File Yang Diubah

1. `app/Config/Routes.php`
   - Menambahkan group route `inventory-requests`.
2. `app/Views/layouts/main.php`
   - Menambahkan menu `Pengajuan Inventaris` pada sidebar desktop dan mobile.
3. `app/Helpers/app_helper.php`
   - Menambahkan mapping badge dan label status pengajuan.

## Backup Source Code

Backup file lama yang diubah sudah dibuat sebelum perubahan source code:

- `skripsi/07-backup/source-code/inventory-request-20260705-172004/`

Isi backup:

1. `Routes.php`
2. `main.php`
3. `app_helper.php`

## Route Baru

| Method | Route | Controller/Method | Role |
| --- | --- | --- | --- |
| GET | `/inventory-requests` | `InventoryRequestsController::index` | admin, operator, pimpinan |
| GET | `/inventory-requests/create` | `InventoryRequestsController::create` | admin, operator |
| POST | `/inventory-requests` | `InventoryRequestsController::store` | admin, operator |
| GET | `/inventory-requests/{id}` | `InventoryRequestsController::show` | admin, operator, pimpinan |
| GET | `/inventory-requests/{id}/edit` | `InventoryRequestsController::edit` | admin, operator |
| POST | `/inventory-requests/{id}` | `InventoryRequestsController::update` | admin, operator |
| POST | `/inventory-requests/{id}/approve` | `InventoryRequestsController::approve` | admin, pimpinan |
| POST | `/inventory-requests/{id}/reject` | `InventoryRequestsController::reject` | admin, pimpinan |
| GET | `/inventory-requests/{id}/pdf` | `InventoryRequestsController::pdf` | admin, operator, pimpinan |

## Tabel Baru

1. `inventory_requests`
2. `inventory_request_items`

Migration sudah dijalankan dengan `php spark migrate` dan masuk batch migrasi baru pada 2026-07-05.

## Hak Akses

Admin:

- Melihat semua pengajuan.
- Membuat pengajuan.
- Mengubah pengajuan selama status masih `diajukan`.
- Menyetujui atau menolak pengajuan.
- Mengunduh PDF.

Operator:

- Membuat pengajuan.
- Melihat pengajuan miliknya sendiri.
- Mengubah pengajuan miliknya selama status masih `diajukan`.
- Mengunduh PDF pengajuan miliknya.
- Tidak dapat menyetujui atau menolak pengajuan.

Pimpinan:

- Melihat semua pengajuan.
- Menyetujui atau menolak pengajuan.
- Mengunduh PDF.
- Tidak diberi akses membuat atau mengubah pengajuan.

## Hasil Uji Manual

| Pengujian | Hasil |
| --- | --- |
| Sintaks PHP migration/model/controller/view/helper/route/layout | valid |
| Route `inventory-requests` terdaftar | valid |
| Migration tabel baru | valid |
| Login admin/operator/pimpinan | valid |
| Membuka daftar pengajuan | valid |
| Membuat pengajuan valid dengan item | valid |
| Melihat detail pengajuan | valid |
| Menyetujui pengajuan oleh pimpinan | valid |
| Menolak pengajuan tanpa catatan | validasi menahan proses |
| Menolak pengajuan dengan catatan | valid |
| Operator mencoba approve | ditolak oleh pembatasan role |
| Download PDF pengajuan | valid |
| Akses tanpa login ke daftar pengajuan | redirect ke login |

Data uji yang dibuat adalah data dummy dengan identitas seperti `Pemohon Uji Skripsi`, `Unit Uji Skripsi`, dan `Item Pengajuan Inventaris Uji Skripsi`.

## Batasan Fitur

1. Fitur hapus pengajuan tidak dibuat untuk mengurangi risiko perubahan data.
2. Integrasi otomatis ke Surat Keluar tidak dibuat karena struktur Surat Keluar existing memiliki alur dokumen tersendiri.
3. Integrasi otomatis ke Transaksi Aset tidak dibuat karena dapat mengubah alur transaksi/peminjaman aset yang sudah berjalan.
4. Status `diproses`, `direalisasikan`, dan `selesai` sudah disiapkan di model, tetapi belum dibuatkan flow perubahan status khusus.
5. Modul ini diverifikasi pada lingkungan lokal Laragon, bukan server produksi atau aplikasi online.

