from docx import Document
from pathlib import Path

src = Path(r'C:\laragon\www\aset-surat-web\skripsi\03-draft-bab\BAB-IV-REVISI-1-EVIDENCEPATCH-3.md')
out = Path(r'C:\laragon\www\aset-surat-web\skripsi\05-final-docx\BAB-IV-DRAFT-REVIEW.docx')
out.parent.mkdir(parents=True, exist_ok=True)

text = src.read_text(encoding='utf-8')
doc = Document()
doc.styles['Normal'].font.name = 'Times New Roman'
doc.styles['Normal'].font.size = 11

p = doc.add_paragraph()
r = p.add_run('Draft Bab IV - Review')
r.bold = True
r.font.size = 18
p.space_after = 0.2

doc.add_paragraph()

for line in text.splitlines():
    if line.startswith('# '):
        p = doc.add_paragraph()
        r = p.add_run(line[2:])
        r.bold = True
        r.font.size = 16
    elif line.startswith('## '):
        p = doc.add_paragraph()
        r = p.add_run(line[3:])
        r.bold = True
        r.font.size = 13
    elif line.startswith('### '):
        p = doc.add_paragraph()
        r = p.add_run(line[4:])
        r.bold = True
        r.font.size = 12
    elif line.strip():
        p = doc.add_paragraph()
        p.add_run(line)
    else:
        doc.add_paragraph()

doc.save(out)
print(out)
print(out.exists())
