# NEXT_STEPS_TO_SKRIPSI.md

Tanggal dibuat: 2026-07-04
Status: rencana kerja menuju `SKRIPSI.docx`

## Kondisi Saat Ini

Tahap audit awal workspace sudah selesai. Struktur folder kerja sudah dibuat. Render pedoman dan outline tersedia. Audit visual pedoman dan outline 156 sudah dibuat sebagai file baru.

Belum dibuat:

1. `SKRIPSI.docx`.
2. Draft BAB I sampai BAB V.
3. File ringkasan aturan final pedoman dan outline yang sudah diverifikasi penuh oleh user.
4. Daftar pustaka final.
5. Artefak Scrum final.

## File Audit Yang Sudah Tersedia

File audit dan panduan yang sudah ada:

1. `AGENTS.md`
2. `MEMORY.md`
3. `TOOLS.md`
4. `skripsi/08-log-kerja/WORKSPACE_AUDIT.md`
5. `skripsi/01-pedoman-dan-outline/ocr-render-status.md`
6. `skripsi/01-pedoman-dan-outline/PEDOMAN_AUDIT.md`
7. `skripsi/01-pedoman-dan-outline/OUTLINE_156_MAPPING.md`
8. `skripsi/08-log-kerja/NEXT_STEPS_TO_SKRIPSI.md`

## File Audit Yang Masih Perlu Dibuat

File audit lanjutan yang disarankan:

1. `skripsi/02-data-aplikasi/APLIKASI_FEATURE_AUDIT.md`
   - Fitur aplikasi, aktor, route, controller, model, view, role, dan alur utama.
2. `skripsi/02-data-aplikasi/DATABASE_ERD_AUDIT.md`
   - Tabel, kolom, relasi, ERD, dan mapping ke BAB IV `4.1.1 Database`.
3. `skripsi/02-data-aplikasi/TESTING_PLAN_AUDIT.md`
   - Rencana pengujian modul dan skenario test.
4. `skripsi/02-data-aplikasi/SCRUM_MAPPING_AUDIT.md`
   - Mapping Agile Scrum ke project, backlog, sprint, deliverable, dan bukti yang tersedia.
5. `skripsi/04-diagram-dan-gambar/DIAGRAM_REQUIREMENTS.md`
   - Daftar diagram yang dibutuhkan: use case, activity, sequence, class/deployment bila diperlukan, ERD, LRS, dan gambar antarmuka.
6. `skripsi/06-referensi/REFERENSI_AUDIT.md`
   - Referensi yang sudah ada, referensi yang kurang, dan status sitasi APA 7.

## Data Yang Masih Kurang

Data yang belum ditemukan atau perlu dikonfirmasi:

1. Template Word resmi kampus, jika ada.
2. Draft BAB lama, jika pernah dibuat.
3. Daftar pustaka atau file sitasi dari Mendeley.
4. Minimal 10 jurnal untuk skripsi atau sesuai ketentuan pedoman/outline yang akan dipakai.
5. Surat keterangan riset atau surat keabsahan data.
6. Bukti hasil pengecekan plagiarisme.
7. Daftar riwayat hidup.
8. Lembar konsultasi skripsi.
9. Data resmi profil SMPI REJIS, sejarah, dan struktur organisasi.
10. Artefak Scrum: product backlog, sprint backlog, sprint goal, sprint review, atau catatan pengembangan.
11. Screenshot aplikasi yang sudah final.
12. Status deployment/publikasi aplikasi: lokal, intranet, internet, atau belum dipublikasikan.

## Urutan Kerja Menuju SKRIPSI.docx

Urutan kerja yang disarankan:

1. Validasi hasil `PEDOMAN_AUDIT.md` dan `OUTLINE_156_MAPPING.md` bersama user.
2. Audit aplikasi secara rinci:
   - fitur
   - aktor
   - route
   - controller
   - model
   - view
   - alur proses
3. Audit database dan ERD:
   - tabel
   - kolom
   - relasi
   - ERD
   - LRS bila dibutuhkan
4. Audit kebutuhan data lapangan dari transkrip wawancara:
   - masalah
   - kebutuhan
   - aktor
   - manfaat
5. Susun mapping Agile Scrum:
   - product backlog
   - sprint planning
   - sprint backlog
   - sprint execution
   - sprint review/testing
   - sprint retrospective/evaluasi
6. Tentukan daftar diagram dan screenshot yang harus dibuat.
7. Kumpulkan referensi jurnal dan buku sesuai pedoman.
8. Buat kerangka draft BAB I sampai BAB V dalam file kerja, bukan `SKRIPSI.docx` final.
9. Review kerangka dengan user.
10. Setelah disetujui, buat draft BAB bertahap:
    - BAB I
    - BAB II
    - BAB III
    - BAB IV
    - BAB V
11. Setelah isi BAB stabil, siapkan dokumen Word sementara.
12. Verifikasi format Word berdasarkan pedoman.
13. Lengkapi daftar isi, daftar gambar, daftar tabel, daftar lampiran, sitasi, dan daftar pustaka.
14. Buat backup sebelum finalisasi.
15. Baru setelah disetujui, hasilkan `SKRIPSI.docx`.

## Prioritas Pengerjaan BAB I Sampai BAB V

Prioritas awal:

1. BAB I
   - Gunakan transkrip wawancara untuk latar belakang, identifikasi masalah, rumusan masalah, tujuan/manfaat, teknik pengumpulan data, model Scrum, dan ruang lingkup.
2. BAB III
   - Audit aplikasi dan kebutuhan sistem dulu, karena BAB III menjadi dasar BAB IV.
3. BAB IV
   - Gunakan database, arsitektur, UI, code generation, testing, support, dan Agile Scrum.
4. BAB II
   - Kerjakan setelah referensi tersedia agar teori dan penelitian terkait tidak mengarang.
5. BAB V
   - Kerjakan paling akhir setelah BAB I-IV stabil.

Catatan:

1. BAB II membutuhkan referensi yang valid, sehingga jangan disusun penuh sebelum referensi terkumpul.
2. BAB V harus mengikuti hasil pembahasan, sehingga jangan dibuat dulu.

## Kebutuhan Gambar Dan Diagram

Diagram/gambar yang kemungkinan dibutuhkan:

1. Struktur organisasi SMPI REJIS.
2. Use case diagram.
3. Activity diagram proses inventaris aset.
4. Activity diagram proses peminjaman/pengembalian aset.
5. Activity diagram surat masuk dan disposisi.
6. Activity diagram surat keluar.
7. Sequence diagram modul penting, bila diminta outline/dosen.
8. Class diagram atau struktur MVC, bila relevan.
9. ERD.
10. LRS, jika diminta kampus/dosen.
11. Deployment diagram atau spesifikasi arsitektur, jika diperlukan untuk BAB IV.
12. Screenshot halaman login.
13. Screenshot dashboard.
14. Screenshot manajemen aset.
15. Screenshot transaksi aset.
16. Screenshot surat masuk.
17. Screenshot disposisi.
18. Screenshot surat keluar.
19. Screenshot laporan.
20. Screenshot backup atau ERD jika relevan.

## Kebutuhan Screenshot Aplikasi

Screenshot yang perlu disiapkan setelah aplikasi diverifikasi:

1. Login.
2. Dashboard.
3. Daftar aset.
4. Form tambah/edit aset.
5. Detail aset.
6. Daftar transaksi aset.
7. Form transaksi aset.
8. Detail atau PDF transaksi aset.
9. Daftar surat masuk.
10. Form surat masuk.
11. Detail surat masuk dan disposisi.
12. Daftar disposisi.
13. Daftar surat keluar.
14. Form surat keluar.
15. Laporan.
16. ERD database.
17. Backup database, jika perlu.

Catatan keamanan:

1. Jangan tampilkan data sensitif.
2. Gunakan data dummy bila perlu.
3. Jangan tampilkan credential atau isi `.env`.

## Kebutuhan Referensi Dan Daftar Pustaka

Kebutuhan referensi:

1. Minimal 10 jurnal untuk skripsi berdasarkan pedoman.
2. Jurnal minimal 5 tahun terakhir.
3. Buku minimal 10 tahun terakhir.
4. Sitasi dan daftar pustaka menggunakan Mendeley dan APA 7.
5. Referensi tidak boleh berasal dari Blogspot, Wordpress, atau Wikipedia.
6. Referensi terkait aplikasi sejenis perlu masuk BAB II `2.2 Penelitian Terkait`.
7. Teori yang perlu dicari:
   - sistem informasi
   - inventaris aset
   - manajemen surat
   - disposisi surat
   - aplikasi web
   - CodeIgniter/PHP atau arsitektur MVC jika relevan
   - database/ERD
   - UML
   - Agile Scrum
   - black-box testing atau metode testing yang akan dipakai

## Risiko Utama Sebelum Membuat Final DOCX

Risiko utama:

1. Aturan pedoman belum seluruhnya terbaca melalui OCR; review visual sudah dilakukan tetapi perlu validasi user.
2. Referensi dan file sitasi belum tersedia.
3. Artefak Scrum belum tersedia dan tidak boleh dikarang.
4. Data resmi profil, sejarah, dan struktur organisasi SMPI REJIS belum lengkap.
5. Screenshot aplikasi belum dibuat dan aplikasi belum diverifikasi jalan pada sesi ini.
6. Status publikasi software belum dikonfirmasi.
7. Template Word kampus belum ditemukan.
8. BAB IV harus mengikuti outline tetapi disesuaikan dengan Agile Scrum secara eksplisit.
9. Worktree Git sudah dirty sejak awal, jadi pekerjaan dokumen harus tetap dipisahkan dari source code aplikasi.
10. Final DOCX tidak boleh dibuat sebelum audit aplikasi, referensi, diagram, dan struktur bab disetujui.

## Rekomendasi Tahap Berikutnya

Tahap berikutnya yang disarankan adalah audit aplikasi dan database untuk membuat:

1. `skripsi/02-data-aplikasi/APLIKASI_FEATURE_AUDIT.md`
2. `skripsi/02-data-aplikasi/DATABASE_ERD_AUDIT.md`
3. `skripsi/02-data-aplikasi/SCRUM_MAPPING_AUDIT.md`

Tahap ini sebaiknya dilakukan sebelum membuat draft BAB I-V atau `SKRIPSI.docx`.
