& 'C:\laragon\bin\python\python-3.10\python.exe' -c "print('ok')"
