# BAB_III_IV_READINESS

## Status

- Tanggal audit: 2026-07-04
- Tujuan: menilai kesiapan data untuk mulai menyusun BAB III dan BAB IV.
- Catatan: file ini bukan draft BAB III/BAB IV, melainkan peta kesiapan data sebelum penulisan.

## Data yang Sudah Cukup untuk BAB III

Data yang sudah cukup:

- Identitas aplikasi sebagai sistem pengelolaan aset dan surat untuk SMPI REJIS.
- Role pengguna: admin, operator, pimpinan.
- Modul utama: dashboard, pengguna, aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup. ERD tersedia sebagai artefak dokumentasi/dev-only, bukan menu operasional final.
- Route utama dan hak akses modul.
- Controller, model, dan view utama.
- Struktur database dan relasi utama.
- Alur autentikasi.
- Alur manajemen aset.
- Alur transaksi/peminjaman aset.
- Alur surat masuk.
- Alur disposisi.
- Alur surat keluar.
- Alur laporan.
- Dasar analisis kebutuhan sistem berdasarkan fitur yang ditemukan.

Sumber: `APLIKASI_FEATURE_AUDIT.md`, `DATABASE_ERD_AUDIT.md`, `app/Config/Routes.php`, `app/Controllers/*.php`, `app/Models/*.php`, `app/Views/*`.

## Data yang Sudah Cukup untuk BAB IV

Data yang sudah cukup:

- Desain database dari migration, SQL, model, dan `ErdController`.
- Software architecture berbasis CodeIgniter 4 MVC.
- User interface berdasarkan file view.
- Code generation berbasis route, controller, model, filter, helper, library, dan trait.
- Kandidat skenario black-box testing untuk fitur utama.
- Support environment dasar dari `composer.json`, `composer.lock`, README, dan konteks Laragon.
- Mapping Agile Scrum awal untuk product backlog, sprint, increment, dan testing.

Sumber: `APLIKASI_FEATURE_AUDIT.md`, `DATABASE_ERD_AUDIT.md`, `SCRUM_MAPPING_AUDIT.md`, `composer.json`, `composer.lock`, `README.md`.

## Data yang Masih Kurang

Data yang masih perlu dilengkapi:

- Profil resmi SMPI REJIS.
- Sejarah institusi.
- Struktur organisasi institusi.
- Hasil wawancara atau transkrip wawancara yang bisa dikutip untuk BAB I dan BAB III.
- Bukti kebutuhan pengguna dari pihak sekolah.
- Screenshot aplikasi dari browser sudah tersedia, tetapi perlu dipilih dan dinomori sesuai urutan BAB final.
- Hasil pengujian aktual black-box sudah tersedia untuk skenario yang diuji, tetapi perlu dirapikan sebagai tabel BAB IV.
- Bukti publikasi/deployment software.
- Spesifikasi hardware dan software final.
- Referensi jurnal/buku untuk BAB II dan sitasi Agile Scrum.
- Template atau format final Word bila tersedia dari kampus.
- Bukti historis Scrum bila ingin menulis Scrum sebagai proses nyata, bukan mapping dokumentasi.

## Diagram yang Perlu Dibuat

Diagram yang direkomendasikan:

- Use case diagram berdasarkan role admin, operator, dan pimpinan.
- Activity diagram login.
- Activity diagram manajemen aset.
- Activity diagram transaksi/peminjaman aset.
- Activity diagram surat masuk.
- Activity diagram disposisi surat.
- Activity diagram surat keluar.
- ERD final untuk naskah skripsi.
- LRS database.
- Diagram arsitektur MVC atau software architecture.
- Diagram Scrum flow/backlog-to-sprint bila diperlukan.

Pembaruan 2026-07-04:

- Source Mermaid dan output SVG sudah dibuat untuk Use Case, Activity Login, Activity Inventaris Aset, Activity Surat Masuk dan Disposisi, Sequence Login, Sequence Transaksi Aset, Sequence Disposisi Surat, Class Diagram, ERD Final, Deployment Diagram, dan Arsitektur MVC.
- Draft LRS sudah dibuat di `skripsi/04-diagram-dan-gambar/LRS_DRAFT.md`.
- Activity Diagram Transaksi Aset, Activity Diagram Surat Keluar, dan Diagram Scrum Flow sudah dibuat pada quality gate.
- `DIAGRAM_QUALITY_REVIEW.md` sudah tersedia untuk menentukan diagram yang layak dipakai langsung dan diagram yang perlu layout besar/landscape.

## Screenshot Aplikasi yang Perlu Disiapkan

Screenshot yang perlu dibuat pada tahap verifikasi aplikasi:

- Login.
- Dashboard.
- Menu utama/sidebar.
- Pengguna.
- Daftar aset.
- Form aset.
- Detail aset.
- Daftar transaksi aset.
- Form transaksi aset.
- Detail/pengembalian transaksi aset.
- Daftar surat masuk.
- Form surat masuk.
- Detail surat masuk dan disposisi.
- Daftar disposisi.
- Daftar surat keluar.
- Form surat keluar.
- Detail surat keluar.
- Laporan.
- Cetak laporan.
- Backup.
- Screenshot dashboard/sidebar final tanpa menu ERD sudah dibuat setelah change request.

## Tabel yang Perlu Dibuat

Tabel yang direkomendasikan:

- Tabel role dan hak akses.
- Tabel kebutuhan fungsional.
- Tabel kebutuhan nonfungsional.
- Tabel product backlog.
- Tabel sprint backlog.
- Tabel hasil implementasi per sprint.
- Tabel struktur database.
- Tabel relasi database.
- Tabel pengujian black-box.
- Tabel spesifikasi hardware.
- Tabel spesifikasi software.
- Tabel daftar screenshot/user interface.

## Bagian BAB III yang Bisa Mulai Ditulis

Bagian yang sudah bisa mulai ditulis setelah user menyetujui tahap drafting:

- `3.2 Analisis Aplikasi`.
- `3.2.1 Analisis Masalah`, dengan catatan perlu diperkuat dari wawancara/profil institusi.
- `3.2.2 Analisis Kebutuhan`, berdasarkan role, modul, route, dan fitur aplikasi.
- Bagian rancangan alur sistem untuk modul aset, transaksi aset, surat masuk, disposisi, surat keluar, dan laporan.
- Bagian rancangan database awal, bila ditempatkan sebagai pendukung analisis sebelum detail BAB IV.

## Bagian BAB IV yang Bisa Mulai Ditulis

Bagian yang sudah bisa mulai ditulis setelah user menyetujui tahap drafting:

- `4.1 Desain`.
- `4.1.1 Database`, berdasarkan migration, SQL, model, dan ERD.
- `4.1.2 Software Architecture`, berdasarkan CodeIgniter MVC, route, controller, model, view, filter, helper, library, dan trait.
- `4.1.3 User Interface`, setelah screenshot aplikasi tersedia.
- `4.2 Code Generation`, dengan potongan kode terpilih dari file yang sudah ditemukan.
- `4.3 Testing`, setelah skenario dan hasil pengujian aktual dibuat.
- `4.4 Support`, setelah spesifikasi hardware/software dan deployment/publikasi dikonfirmasi.

## Bagian yang Belum Boleh Ditulis Karena Data Belum Cukup

Bagian yang belum boleh ditulis sebagai fakta final:

- Sejarah resmi SMPI REJIS.
- Struktur organisasi resmi SMPI REJIS.
- Kutipan hasil wawancara.
- Pernyataan masalah yang mengatasnamakan narasumber tanpa transkrip.
- Tanggal sprint, peserta Scrum, dan aktivitas Scrum aktual tanpa bukti.
- Hasil pengujian aktual sebelum pengujian dilakukan.
- Publikasi software/deployment sebelum statusnya dikonfirmasi.
- Screenshot atau gambar final yang belum dipilih/dinomori sesuai susunan BAB.
- Daftar pustaka final sebelum referensi dikumpulkan dan divalidasi.

## Risiko Utama Sebelum Draft BAB III dan BAB IV

- BAB III dapat lemah jika profil, sejarah, struktur organisasi, dan wawancara belum tersedia.
- BAB IV dapat kurang kuat jika screenshot, diagram, dan hasil testing belum dipilih/dinomori sesuai struktur BAB final.
- Scrum berisiko dianggap mengarang proses bila bukti historis tidak tersedia.
- ERD/LRS perlu dirapikan agar sesuai format skripsi, bukan hanya mengikuti tampilan halaman aplikasi.
- Spesifikasi support dan publikasi software masih belum cukup untuk `4.4`.

## Pembaruan Quality Gate Sebelum Drafting

Tanggal pembaruan: 2026-07-04

- Spesifikasi format DOCX berdasarkan pedoman sudah dibuat di `skripsi/00-getting-started/DOCX_FORMAT_SPEC.md`.
- Checkpoint penyamaan persepsi project sudah dibuat di `skripsi/00-getting-started/PERSEPSI_PROJECT_CHECKPOINT.md`.
- Masih perlu persetujuan user untuk judul final, penyebutan objek/institusi, status deployment, dan cara menulis Scrum sebelum drafting BAB.

## Rekomendasi Tahap Berikutnya

Tahap berikutnya yang direkomendasikan adalah meminta koreksi user terhadap checkpoint persepsi, lalu menyusun `SKRIPSI_BLUEPRINT.md` sebelum drafting BAB.
