# COPILOT HANDOFF CHECKPOINT

Tanggal dibuat: 2026-07-04

## 1. Judul skripsi

Perancangan Sistem Terintegrasi Inventaris Aset dan Disposisi Surat Berbasis Web pada SMPI REJIS

## 2. Objek penelitian

SMPI REJIS sebagai institusi yang menjadi fokus penelitian.

## 3. Teknologi aplikasi

- Framework: CodeIgniter 4
- Bahasa: PHP
- Basis data: MySQL/MariaDB
- Lingkungan pengembangan: Laragon / lokal

## 4. Metode pengembangan

Agile Scrum, ditulis sebagai pendekatan iteratif untuk memetakan kebutuhan, product backlog, sprint mapping, implementasi modul, dan pengujian.

## 5. Status BAB I

- Draft `BAB-I-REVISI-1.md` telah dibuat.
- BAB I berisi latar belakang, identifikasi masalah, perumusan masalah, tujuan dan manfaat, metode penelitian, dan ruang lingkup.
- Dokumentasi revisi BAB I sudah ada di `BAB-I-REVISION-NOTES.md`.
- BAB I masih mengandung beberapa marker referensi dan cek referensi yang harus divalidasi.

## 6. Status BAB II

- Audit dan rencana revisi BAB II sudah disusun: `BAB-II-AUDIT-V2.md` dan `BAB-II-REVISION-PLAN-V2.md`.
- Struktur final BAB II telah dikonfirmasi, dengan subbab 2.1.1 sampai 2.1.13 dan 2.2 Penelitian Terkait.
- BAB II belum ditulis ulang final karena referensi belum diverifikasi.
- Perlu verifikasi sumber dan metadata jurnal/buku sebelum penulisan BAB II final.

## 7. Larangan penting

- Jangan membuat sitasi palsu.
- Jangan membuat daftar pustaka palsu.
- Jangan mengubah source code aplikasi kecuali diminta eksplisit.
- Jangan mengubah database.
- Jangan menjalankan aplikasi kecuali diminta eksplisit.
- Jangan membuat SKRIPSI.docx kecuali diminta eksplisit.
- Jangan menulis BAB II final sebelum referensi valid disetujui.
- Jangan menampilkan credential, password, token, session, cookie, atau data sensitif.
- Semua file lama hanya untuk audit, bukan sumber final otomatis.

## 8. Langkah aman berikutnya

1. Verifikasi referensi dan metadata sumber untuk setiap subbab BAB II final.
2. Kumpulkan sumber jurnal/buku valid sesuai pedoman APA 7 dan outline 156.
3. Persiapkan kerangka draft BAB II berdasarkan struktur final dan audit V2.
4. Tahan penulisan BAB II final sampai referensi terverifikasi dan disetujui.
5. Jangan buat SKRIPSI.docx sampai user meminta secara eksplisit.

## 9. Role dan fitur aplikasi final

Role pengguna aplikasi adalah:

1. admin
2. operator
3. pimpinan

Fitur final yang dibahas dalam skripsi:

1. login/autentikasi
2. dashboard
3. manajemen pengguna
4. inventaris aset
5. transaksi atau peminjaman aset
6. surat masuk
7. disposisi surat
8. surat keluar
9. laporan
10. backup

Istilah Admin TU, Kepala Sekolah, dan Staff hanya boleh digunakan sebagai padanan operasional sekolah jika diperlukan, bukan sebagai role teknis final aplikasi.

## 10. Batasan deployment

Aplikasi hanya dikembangkan dan diuji pada lingkungan lokal menggunakan Laragon. Jangan menulis bahwa aplikasi sudah deployment produksi, online, atau resmi berjalan pada server sekolah.

## 11. Keputusan pengujian

Pengujian sistem mencakup:

1. black-box testing
2. pengujian keamanan dasar
3. pengujian kinerja dasar

Pengujian keamanan dasar tidak boleh ditulis sebagai penetration testing atau audit keamanan tingkat lanjut.

Pengujian kinerja dasar tidak boleh ditulis sebagai load testing, stress testing, atau benchmark server produksi.

## 12. ERD

ERD tidak dianggap sebagai fitur operasional aplikasi. ERD hanya digunakan sebagai artefak dokumentasi dan perancangan skripsi.

## 13. Status BAB I final arah

BAB-I-REVISI-1.md disetujui sebagai final dari sisi arah, isi, dan ruang lingkup. Namun belum final mutlak untuk DOCX karena masih ada marker [PERLU DATA] dan [PERLU CEK REFERENSI] yang harus dibereskan setelah referensi BAB II valid.

Aturan:

1. Jangan membuat BAB II final.
2. Jangan membuat SKRIPSI.docx.
3. Jangan mengubah source code.
4. Jangan mengubah database.
5. Jangan membuat sitasi palsu.
6. Jangan membuat daftar pustaka palsu.
