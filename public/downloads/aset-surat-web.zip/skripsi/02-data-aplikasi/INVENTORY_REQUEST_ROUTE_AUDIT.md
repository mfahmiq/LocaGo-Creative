# INVENTORY_REQUEST_ROUTE_AUDIT

## Status

- Tanggal audit: 2026-07-05.
- File route: `app/Config/Routes.php`.
- Controller: `app/Controllers/InventoryRequestsController.php`.
- Status: route sudah terdaftar dan diverifikasi melalui `php spark routes`.

## Daftar Route Baru

| Method | Route | Controller/Method | Role | Fungsi |
| --- | --- | --- | --- | --- |
| GET | `/inventory-requests` | `index` | admin, operator, pimpinan | Menampilkan daftar pengajuan |
| GET | `/inventory-requests/create` | `create` | admin, operator | Menampilkan form tambah pengajuan |
| POST | `/inventory-requests` | `store` | admin, operator | Menyimpan pengajuan baru |
| GET | `/inventory-requests/{id}/pdf` | `pdf` | admin, operator, pimpinan | Mengunduh PDF pengajuan |
| GET | `/inventory-requests/{id}` | `show` | admin, operator, pimpinan | Menampilkan detail pengajuan |
| GET | `/inventory-requests/{id}/edit` | `edit` | admin, operator | Menampilkan form edit pengajuan |
| POST | `/inventory-requests/{id}` | `update` | admin, operator | Menyimpan perubahan pengajuan |
| POST | `/inventory-requests/{id}/approve` | `approve` | admin, pimpinan | Menyetujui pengajuan |
| POST | `/inventory-requests/{id}/reject` | `reject` | admin, pimpinan | Menolak pengajuan |

## Filter Auth Dan Role

Semua route berada di dalam group route yang sudah dilindungi filter `auth`. Group `inventory-requests` memakai filter role `admin,operator,pimpinan`, lalu route tertentu diberi filter tambahan:

1. Create/store: `admin,operator`.
2. Edit/update: `admin,operator`.
3. Approve/reject: `admin,pimpinan`.

## Pembatasan Tambahan Di Controller

Selain filter route, controller juga membatasi akses berdasarkan data:

1. Operator hanya dapat melihat pengajuan yang dibuat olehnya.
2. Operator hanya dapat mengubah pengajuan miliknya selama status masih `diajukan`.
3. Admin dapat melihat dan mengubah pengajuan selama status masih `diajukan`.
4. Pimpinan dan admin dapat memproses approval untuk status `diajukan` atau `diproses`.

## Hasil Audit Route

| Cek | Hasil |
| --- | --- |
| Route daftar tampil di `php spark routes` | valid |
| Route create/store dibatasi admin/operator | valid |
| Route approve/reject dibatasi admin/pimpinan | valid |
| Route PDF tersedia | valid |
| Operator mencoba approve | ditolak |
| Akses tanpa login | redirect ke login |

## Catatan

Tidak ada route delete untuk pengajuan inventaris. Keputusan ini dibuat agar modul baru tidak menghapus data lama atau data uji secara tidak sengaja.

