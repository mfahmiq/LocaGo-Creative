# APPLICATION_VERIFICATION

## Status Verifikasi

- Tanggal verifikasi: 2026-07-04
- Lingkup: verifikasi lokal aplikasi untuk bahan BAB III dan BAB IV.
- Mode kerja: read-only terhadap source code, database, SQL, migration, seeder, PDF, upload, dan runtime.
- Catatan keamanan: credential, password, token, session, cookie, API key, dan isi `.env` tidak ditampilkan.

## Cara Menjalankan Aplikasi di Laragon/Local Environment

Cara umum berdasarkan lokasi project dan README:

1. Buka Laragon.
2. Pastikan service web server dan database MySQL/MariaDB aktif.
3. Buka terminal di:

   ```text
   C:\laragon\www\aset-surat-web
   ```

4. Pastikan dependency Composer tersedia.
5. Jalankan aplikasi menggunakan salah satu cara berikut:
   - Melalui virtual host Laragon, jika auto virtual host aktif.
   - Melalui CodeIgniter development server:

     ```powershell
     php spark serve
     ```

6. Akses aplikasi melalui URL lokal yang tersedia.

Sumber: `README.md`, `TOOLS.md`, hasil verifikasi CLI.

## URL Lokal Aplikasi

URL yang dapat dipastikan dari verifikasi sementara:

- `http://127.0.0.1:8098/`
- `http://127.0.0.1:8098/login`

Catatan:

- URL tersebut berasal dari server sementara `php spark serve --host 127.0.0.1 --port 8098` saat audit.
- Redirect route internal mengarah ke `http://localhost:8080/login`, mengikuti konfigurasi/base URL aplikasi yang aktif.
- URL virtual host Laragon seperti domain `.test` belum dapat dipastikan dari verifikasi ini.

## Status Dependency Composer

Hasil verifikasi:

- `vendor/autoload.php` tersedia.
- Composer tersedia: versi `2.8.9`.
- PHP CLI tersedia: versi `8.4.10`.
- CodeIgniter framework terdeteksi: `codeigniter4/framework v4.7.3`.
- `composer check-platform-reqs` menunjukkan kebutuhan platform utama berstatus `success`.

Sumber verifikasi:

- `php -v`
- `composer --version`
- `composer show codeigniter4/framework --no-ansi`
- `composer check-platform-reqs --no-ansi`
- `composer.json`
- `composer.lock`

## Status Konfigurasi Database

Hasil verifikasi aman:

- File `.env` tersedia, tetapi isinya tidak dibaca dan tidak ditampilkan.
- Perintah `php spark migrate:status` mencoba koneksi database.
- Koneksi database aktif belum berhasil karena koneksi MySQL ditolak oleh mesin lokal.

Kesimpulan:

- Konfigurasi database tidak diverifikasi detail karena credential tidak boleh ditampilkan.
- Struktur database tetap sudah tersedia dari migration dan SQL dump.
- Verifikasi database aktif perlu diulang setelah service MySQL/MariaDB Laragon berjalan.

Sumber:

- Keberadaan `.env` dicek tanpa membaca isi.
- `php spark migrate:status`
- `app/Database/Migrations/*.php`
- `database/*.sql`

## Status Route Utama

Route utama berhasil dibaca melalui:

```powershell
php spark routes
```

Route yang terverifikasi tersedia:

- `/`
- `/login`
- `/logout`
- `/dashboard`
- `/erd`
- `/users`
- `/assets`
- `/asset-transactions`
- `/incoming-letters`
- `/outgoing-letters`
- `/dispositions`
- `/reports`
- `/backup`

Route internal memakai filter `auth` dan beberapa route memakai filter `role`.

Sumber: hasil `php spark routes`, `app/Config/Routes.php`.

## Status Halaman Login

Status:

- `/` merespons HTTP `200`.
- `/login` merespons HTTP `200`.
- Halaman login dapat dijangkau melalui server lokal sementara.

Catatan:

- Isi form/token tidak ditampilkan.
- Login menggunakan akun demo belum dilakukan karena koneksi database aktif belum berhasil.

Sumber: verifikasi HTTP lokal pada `http://127.0.0.1:8098/` dan `http://127.0.0.1:8098/login`.

## Status Dashboard

Status:

- Route `/dashboard` tersedia.
- Akses tanpa session merespons HTTP `302` dan diarahkan ke halaman login.
- Dashboard belum berhasil diverifikasi setelah login karena database aktif belum terkoneksi.

Sumber: `php spark routes`, verifikasi HTTP lokal, `app/Controllers/DashboardController.php`.

## Status Modul Aset

Status:

- Route `/assets`, `/assets/create`, detail, edit, update, dan delete tersedia.
- Akses `/assets` tanpa session merespons HTTP `302` ke login.
- Modul aset belum berhasil diverifikasi setelah login karena database aktif belum terkoneksi.

Sumber: `php spark routes`, `app/Controllers/AssetsController.php`, `app/Models/AssetModel.php`, `app/Views/assets/*`.

## Status Modul Transaksi/Peminjaman Aset

Status:

- Route `/asset-transactions`, create, detail, PDF, return, dan delete tersedia.
- Akses `/asset-transactions` tanpa session merespons HTTP `302` ke login.
- Modul transaksi/peminjaman aset belum berhasil diverifikasi setelah login karena database aktif belum terkoneksi.

Sumber: `php spark routes`, `app/Controllers/AssetTransactionsController.php`, `app/Models/AssetTransactionModel.php`, `app/Models/AssetTransactionItemModel.php`, `app/Views/asset_transactions/*`.

## Status Modul Surat Masuk

Status:

- Route `/incoming-letters`, create, detail, edit, update, dispose, status, delete, dan ekstraksi tanggal tersedia.
- Akses `/incoming-letters` tanpa session merespons HTTP `302` ke login.
- Modul surat masuk belum berhasil diverifikasi setelah login karena database aktif belum terkoneksi.

Sumber: `php spark routes`, `app/Controllers/IncomingLettersController.php`, `app/Models/IncomingLetterModel.php`, `app/Views/incoming_letters/*`.

## Status Modul Disposisi

Status:

- Route `/dispositions` dan update status disposisi tersedia.
- Akses `/dispositions` tanpa session merespons HTTP `302` ke login.
- Modul disposisi belum berhasil diverifikasi setelah login karena database aktif belum terkoneksi.

Sumber: `php spark routes`, `app/Controllers/DispositionsController.php`, `app/Models/DispositionModel.php`, `app/Views/dispositions/index.php`.

## Status Modul Surat Keluar

Status:

- Route `/outgoing-letters`, create, detail, edit, update, delivery, dan delete tersedia.
- Akses `/outgoing-letters` tanpa session merespons HTTP `302` ke login.
- Modul surat keluar belum berhasil diverifikasi setelah login karena database aktif belum terkoneksi.

Sumber: `php spark routes`, `app/Controllers/OutgoingLettersController.php`, `app/Models/OutgoingLetterModel.php`, `app/Views/outgoing_letters/*`.

## Status Modul Laporan

Status:

- Route `/reports`, `/reports/{type}`, `/reports/{type}/csv`, dan `/reports/{type}/print` tersedia.
- Akses `/reports` tanpa session merespons HTTP `302` ke login.
- Modul laporan belum berhasil diverifikasi setelah login karena database aktif belum terkoneksi.

Sumber: `php spark routes`, `app/Controllers/ReportsController.php`, `app/Views/reports/*`.

## Status Modul Backup

Status:

- Route `/backup` dan `POST /backup/download` tersedia.
- Modul backup dibatasi role admin.
- Akses `/backup` tanpa session merespons HTTP `302` ke login.
- Modul backup belum berhasil diverifikasi setelah login karena database aktif belum terkoneksi.

Sumber: `php spark routes`, `app/Controllers/BackupController.php`, `app/Views/backup/index.php`.

## Hasil HTTP Verifikasi Tanpa Login

| URL Path | Status HTTP | Catatan |
| --- | --- | --- |
| `/` | 200 | Halaman publik merespons |
| `/login` | 200 | Halaman login merespons |
| `/dashboard` | 302 | Redirect ke login karena belum ada session |
| `/assets` | 302 | Redirect ke login karena belum ada session |
| `/asset-transactions` | 302 | Redirect ke login karena belum ada session |
| `/incoming-letters` | 302 | Redirect ke login karena belum ada session |
| `/dispositions` | 302 | Redirect ke login karena belum ada session |
| `/outgoing-letters` | 302 | Redirect ke login karena belum ada session |
| `/reports` | 302 | Redirect ke login karena belum ada session |
| `/backup` | 302 | Redirect ke login karena belum ada session |

## Kendala Saat Verifikasi

- Database aktif belum dapat terkoneksi; koneksi MySQL ditolak oleh mesin lokal.
- Login demo tidak dilakukan karena login membutuhkan koneksi database aktif.
- Halaman setelah login belum bisa diverifikasi secara visual.
- Screenshot final belum dapat diambil secara sah dari halaman internal.
- URL virtual host Laragon belum dapat dipastikan dari verifikasi otomatis.

## Bagian yang Belum Berhasil Diverifikasi

- Login menggunakan akun demo.
- Dashboard setelah login.
- Daftar dan form aset.
- Daftar dan form transaksi aset.
- Daftar dan form surat masuk.
- Detail surat masuk dan disposisi.
- Daftar disposisi.
- Daftar dan form surat keluar.
- Laporan show/CSV/print.
- Backup database.
- ERD melalui browser setelah login.
- Isi database aktif.

## Catatan Keamanan

- Isi `.env` tidak dibuka.
- Credential database tidak ditampilkan.
- Username/password akun demo tidak ditampilkan.
- Token, session, cookie, dan CSRF tidak ditampilkan.
- File upload tidak dibuka.

## Rekomendasi Verifikasi Lanjutan

1. Jalankan Laragon dan pastikan MySQL/MariaDB aktif.
2. Ulangi `php spark migrate:status` tanpa menampilkan credential.
3. Login lokal menggunakan akun demo yang tersedia, tanpa mencatat username/password di file audit.
4. Verifikasi halaman internal satu per satu.
5. Ambil screenshot sesuai daftar pada `SCREENSHOT_REQUIREMENTS.md`.
6. Isi hasil aktual pengujian pada `BLACKBOX_TEST_SCENARIOS.md` setelah testing dilakukan.

## Pembaruan Verifikasi Setelah Laragon Aktif

Tanggal pembaruan: 2026-07-04

Status database:

- Koneksi database berhasil.
- `php spark migrate:status` berhasil membaca tabel migration.
- Migration yang terdeteksi sudah berjalan:
  - `2026-06-16-000001 CreateSmpiRejisTables`
  - `2026-06-16-000002 CreateAssetTransactionTables`
- Isi credential database tidak dibuka dan tidak ditampilkan.

Status server lokal:

- Server development CodeIgniter dijalankan sementara pada `http://localhost:8080`.
- URL ini sesuai redirect/base URL aplikasi yang aktif.

Status login:

- Halaman `/login` merespons HTTP `200`.
- Login lokal menggunakan akun demo berhasil.
- Detail username/password akun demo tidak dicatat di file ini.
- Login gagal dengan data dummy tidak valid tetap berada di halaman login.

Status modul internal setelah login admin:

| Modul/Route | Status Aktual | Catatan |
| --- | --- | --- |
| `/dashboard` | HTTP 200 | Dashboard berhasil dibuka |
| `/erd` | HTTP 200 pada lokal development | Route dokumentasi ERD; setelah change request tidak tampil sebagai menu operasional |
| `/users` | HTTP 200 | Halaman pengguna berhasil dibuka dengan role admin |
| `/assets` | HTTP 200 | Daftar aset berhasil dibuka |
| `/assets/create` | HTTP 200 | Form tambah aset berhasil dibuka |
| `/asset-transactions` | HTTP 200 | Daftar transaksi aset berhasil dibuka |
| `/asset-transactions/create` | HTTP 200 | Form transaksi aset berhasil dibuka |
| `/incoming-letters` | HTTP 200 | Daftar surat masuk berhasil dibuka |
| `/incoming-letters/create` | HTTP 200 | Form surat masuk berhasil dibuka |
| `/dispositions` | HTTP 200 | Halaman disposisi berhasil dibuka |
| `/outgoing-letters` | HTTP 200 | Daftar surat keluar berhasil dibuka |
| `/outgoing-letters/create` | HTTP 200 | Form surat keluar berhasil dibuka |
| `/reports` | HTTP 200 | Halaman laporan berhasil dibuka |
| `/reports/assets` | HTTP 200 | Laporan aset berhasil dibuka |
| `/reports/assets/csv` | HTTP 200 | Export CSV laporan aset merespons berhasil |
| `/reports/assets/print` | HTTP 200 | Tampilan cetak laporan aset berhasil dibuka |
| `/backup` | HTTP 200 | Halaman backup berhasil dibuka dengan role admin |
| `POST /backup/download` | HTTP 200 | Download backup merespons berhasil; isi file tidak ditampilkan |

Status pembatasan role:

- Role operator mengakses `/users`: HTTP `302` redirect ke dashboard.
- Role pimpinan mengakses `/assets/create`: HTTP `302` redirect ke dashboard.
- Detail akun demo tidak dicatat.

Screenshot yang berhasil dibuat:

- `skripsi/04-diagram-dan-gambar/screenshots/01-login.png`
- `skripsi/04-diagram-dan-gambar/screenshots/02-dashboard-admin.png`
- `skripsi/04-diagram-dan-gambar/screenshots/03-data-aset.png`
- `skripsi/04-diagram-dan-gambar/screenshots/04-tambah-aset.png`
- `skripsi/04-diagram-dan-gambar/screenshots/05-surat-masuk.png`
- `skripsi/04-diagram-dan-gambar/screenshots/06-disposisi-surat.png`
- `skripsi/04-diagram-dan-gambar/screenshots/07-surat-keluar.png`
- `skripsi/04-diagram-dan-gambar/screenshots/08-laporan.png`
- `skripsi/04-diagram-dan-gambar/screenshots/09-backup.png`
- `skripsi/04-diagram-dan-gambar/screenshots/10-erd-database.png`

Catatan screenshot:

- Screenshot login dibuat tanpa menampilkan petunjuk credential.
- Screenshot halaman internal dibuat setelah login admin lokal.
- Screenshot memakai data yang ada pada database lokal.

Bagian yang masih belum diverifikasi:

- CRUD tambah/update/delete yang mengubah database belum dijalankan karena aturan tahap ini melarang perubahan database/source.
- Upload file belum diuji.
- Ekstraksi tanggal lampiran belum diuji.
- PDF transaksi belum diuji karena memerlukan data transaksi spesifik.
- Detail item tertentu belum diuji bila membutuhkan ID data tertentu.

## Pembaruan Pengujian CRUD Terkontrol

Tanggal pembaruan: 2026-07-04

Backup sebelum pengujian:

- Backup database dibuat sebelum pengujian CRUD.
- Lokasi backup: `skripsi/07-backup/database/backup-before-crud-test-20260704-1006.sql`.
- Ukuran backup: 14.941 bytes.
- Backup dibuat melalui fitur backup aplikasi, sehingga credential database tidak dibuka dan tidak ditampilkan.

File dummy yang digunakan:

- `skripsi/04-diagram-dan-gambar/dummy-upload/dummy-foto-aset-uji-skripsi.png`.
- `skripsi/04-diagram-dan-gambar/dummy-upload/dummy-lampiran-uji-skripsi.pdf`.
- `skripsi/04-diagram-dan-gambar/dummy-upload/dummy-format-ditolak-uji-skripsi.txt`.

Data dummy yang dibuat:

- 2 akun pengguna dummy nonaktif untuk pengujian tambah pengguna. Detail login tidak dicantumkan.
- 3 aset dummy bertanda `AS-UJI`, termasuk satu aset diagnosis awal dan aset utama pengujian.
- 1 transaksi aset dummy untuk pengujian peminjaman, PDF, dan pengembalian.
- 1 surat masuk dummy bertanda `SM-UJI`.
- 1 disposisi dummy dari surat masuk uji.
- 1 surat keluar dummy bertanda `SK-UJI`.
- File upload dummy tersimpan melalui mekanisme upload aplikasi.

Modul/fitur yang berhasil diuji:

| Modul/Fitur | Status Aktual |
| --- | --- |
| Backup sebelum CRUD | Berhasil |
| Tambah pengguna dummy nonaktif | Berhasil |
| Tambah aset dummy | Berhasil |
| Edit aset dummy | Berhasil |
| Detail aset dummy | Berhasil |
| Filter aset dummy | Berhasil |
| Upload foto aset dummy | Berhasil |
| Validasi input kosong aset | Berhasil |
| Upload foto aset dengan format tidak valid | Ditolak, tidak membuat record detail |
| Tambah transaksi aset dummy | Berhasil |
| Validasi transaksi tanpa item | Berhasil |
| Detail transaksi aset | Berhasil |
| PDF transaksi aset | HTTP 200 `application/pdf` |
| Pengembalian aset | Berhasil |
| Tambah surat masuk dummy | Berhasil |
| Upload lampiran surat masuk dummy | Berhasil |
| Validasi input kosong surat masuk | Berhasil |
| Ekstraksi tanggal lampiran | Endpoint merespons HTTP 200 |
| Buat disposisi surat masuk | Berhasil |
| Update status disposisi menjadi selesai | Berhasil |
| Tambah surat keluar dummy | Berhasil |
| Upload lampiran surat keluar dummy | Berhasil |
| Validasi status diterima tanpa penerima/tanggal | Berhasil |
| Update status surat keluar menjadi diterima tujuan | Berhasil |

Catatan PDF transaksi:

- Route PDF transaksi berhasil merespons `application/pdf`.
- File PDF bukti download tersimpan sebagai `skripsi/04-diagram-dan-gambar/screenshots/19-cetak-pdf-transaksi.pdf`.
- Renderer PDF lokal tidak dapat membaca PDF sederhana tersebut, sehingga tidak dibuat screenshot PNG PDF agar tidak menjadi bukti visual yang keliru.

Screenshot tambahan yang berhasil dibuat:

- `11-tambah-data-aset.png`
- `12-edit-data-aset.png`
- `13-detail-data-aset.png`
- `14-transaksi-aset.png`
- `15-upload-surat-masuk.png`
- `16-form-disposisi.png`
- `17-detail-disposisi.png`
- `18-surat-keluar.png`
- `20-hasil-upload-lampiran.png`

Bagian yang sengaja tidak dilakukan:

- Delete data tidak diuji karena instruksi melarang menghapus data lama.
- Source code aplikasi tidak diubah.
- SQL asli, migration, seeder, pedoman, outline, dan `SKRIPSI.docx` tidak diubah/dibuat.

Data dummy yang perlu dibersihkan jika ingin database kembali rapi:

- Akun pengguna dummy nonaktif bertanda `Pengguna Uji Skripsi`.
- Aset dummy bertanda `AS-UJI`.
- Transaksi aset dummy terkait aset uji.
- Surat masuk dummy bertanda `SM-UJI`.
- Disposisi dummy terkait surat masuk uji.
- Surat keluar dummy bertanda `SK-UJI`.
- File upload dummy pada folder upload aplikasi.

## Pembaruan Change Request Menu ERD

Tanggal pembaruan: 2026-07-04

Perubahan source yang diverifikasi:

- Menu `ERD Database` dihapus dari sidebar desktop dan menu mobile pada `app/Views/layouts/main.php`.
- Route `/erd` di `app/Config/Routes.php` hanya didaftarkan saat `ENVIRONMENT === 'development'`.
- `app/Controllers/ErdController.php` tidak dihapus karena masih menjadi referensi dokumentasi ERD untuk skripsi.

Status verifikasi lokal:

| Item Verifikasi | Hasil |
| --- | --- |
| Sintaks `app/Views/layouts/main.php` | Valid, tidak ada error PHP |
| Sintaks `app/Config/Routes.php` | Valid, tidak ada error PHP |
| Dashboard setelah login lokal | HTTP 200 dan tampil normal |
| Menu `ERD Database` pada dashboard | Tidak tampil |
| Menu `Dashboard` | Tetap tampil |
| Menu `Pengguna` | Tetap tampil untuk admin |
| Menu `Inventaris Aset` | Tetap tampil |
| Menu `Transaksi Aset` | Tetap tampil |
| Menu `Surat Masuk` | Tetap tampil |
| Menu `Surat Keluar` | Tetap tampil |
| Menu `Disposisi` | Tetap tampil |
| Menu `Laporan` | Tetap tampil |
| Menu `Backup` | Tetap tampil untuk admin |
| Route `/erd` pada environment lokal development | Masih merespons HTTP 200 setelah login karena dev-only |

Catatan keamanan:

- Verifikasi login memakai akun demo lokal secara internal.
- Username, password, cookie, session, token, dan credential tidak dicatat dalam file ini.
- Tidak ada perubahan database.
