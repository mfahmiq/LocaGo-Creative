# SCRUM_MAPPING_AUDIT

## Status Audit

- Tanggal audit: 2026-07-04
- Lingkup: mapping Agile Scrum untuk dasar penulisan BAB III dan BAB IV.
- Basis temuan: fitur aplikasi, route, controller, model, view, database, dan outline 156.
- Catatan penting: bukti historis pelaksanaan Scrum belum ditemukan eksplisit. Mapping ini adalah usulan dokumentasi yang aman berdasarkan fitur aplikasi yang benar-benar ditemukan.

## Alasan Metode Agile Scrum Digunakan dalam Konteks Project

Agile Scrum dapat digunakan karena aplikasi memiliki beberapa modul yang dapat dikembangkan secara bertahap:

- Autentikasi dan role.
- Dashboard.
- Inventaris aset.
- Transaksi/peminjaman aset.
- Surat masuk.
- Disposisi.
- Surat keluar.
- Laporan.
- Backup dan dokumentasi ERD.

Pendekatan Scrum cocok untuk memecah kebutuhan aplikasi menjadi backlog, sprint, increment, pengujian bertahap, dan perbaikan berulang. Outline 156 juga membuka ruang adaptasi bila model pengembangan software yang digunakan bukan Waterfall.

Sumber: `skripsi/01-pedoman-dan-outline/OUTLINE_156_MAPPING.md`, `app/Config/Routes.php`, `app/Controllers/*.php`, `app/Views/*`.

## Mapping Kebutuhan Aplikasi ke Product Backlog

Product backlog yang dapat ditulis berdasarkan fitur yang ditemukan:

| ID | Backlog Item | Modul | Bukti File |
| --- | --- | --- | --- |
| PB-01 | Pengguna dapat login dan logout sesuai role | Autentikasi | `AuthController.php`, `UserModel.php`, `Routes.php` |
| PB-02 | Admin dapat mengelola data pengguna | Pengguna | `UsersController.php`, `app/Views/users/*` |
| PB-03 | Sistem menampilkan dashboard ringkasan aset, surat, disposisi, user, dan grafik | Dashboard | `DashboardController.php`, `app/Views/dashboard/index.php` |
| PB-04 | Admin/operator dapat mengelola data kategori, lokasi, dan aset | Inventaris Aset | `AssetsController.php`, `AssetModel.php`, `app/Views/assets/*` |
| PB-05 | Sistem dapat menyimpan foto aset | Inventaris Aset | `AssetsController.php`, `HandlesUploads.php`, `app/Views/assets/form.php` |
| PB-06 | Admin/operator dapat mencatat peminjaman aset dengan banyak item | Transaksi Aset | `AssetTransactionsController.php`, `AssetTransactionItemModel.php`, `app/Views/asset_transactions/form.php` |
| PB-07 | Admin/operator dapat mencatat pengembalian aset | Transaksi Aset | `AssetTransactionsController.php`, `app/Views/asset_transactions/show.php` |
| PB-08 | Sistem dapat membuat PDF transaksi aset | Transaksi Aset | `AssetTransactionsController.php`, `SimplePdf.php` |
| PB-09 | Admin/operator dapat mencatat surat masuk dan lampiran | Surat Masuk | `IncomingLettersController.php`, `IncomingLetterModel.php`, `app/Views/incoming_letters/*` |
| PB-10 | Sistem dapat membantu ekstraksi tanggal dari lampiran surat | Surat Masuk | `IncomingLettersController.php`, `LetterDateExtractor.php` |
| PB-11 | Admin/pimpinan dapat membuat disposisi surat masuk | Disposisi | `IncomingLettersController.php`, `DispositionModel.php`, `app/Views/incoming_letters/show.php` |
| PB-12 | Pengguna dapat memperbarui status disposisi | Disposisi | `DispositionsController.php`, `app/Views/dispositions/index.php` |
| PB-13 | Admin/operator dapat mencatat surat keluar dan pengiriman | Surat Keluar | `OutgoingLettersController.php`, `OutgoingLetterModel.php`, `app/Views/outgoing_letters/*` |
| PB-14 | Sistem menyediakan laporan dan cetak/CSV | Laporan | `ReportsController.php`, `app/Views/reports/*` |
| PB-15 | Admin dapat mengunduh backup database | Backup | `BackupController.php`, `app/Views/backup/index.php` |
| PB-16 | Sistem menyediakan dokumentasi ERD database | ERD | `ErdController.php`, `app/Views/erd/index.php` |

## Usulan Sprint Berdasarkan Modul Aplikasi

Usulan sprint berikut aman digunakan sebagai struktur penulisan jika disebut sebagai rencana/rekonstruksi berbasis fitur yang tersedia. Jangan menuliskannya sebagai kejadian historis lengkap bila tidak ada bukti sprint asli.

| Sprint | Sprint Goal | Backlog Item | Hasil Implementasi yang Ditemukan |
| --- | --- | --- | --- |
| Sprint 0 | Menyiapkan kebutuhan, environment, database, dan backlog awal | PB-01 sampai PB-16 sebagai backlog awal | Struktur CodeIgniter, route, model, migration, SQL dump, README |
| Sprint 1 | Membangun fondasi akses pengguna dan dashboard | PB-01, PB-02, PB-03 | Login, role filter, user CRUD, dashboard |
| Sprint 2 | Membangun modul master inventaris aset | PB-04, PB-05 | CRUD aset, kategori, lokasi, upload foto, filter aset |
| Sprint 3 | Membangun transaksi/peminjaman aset | PB-06, PB-07, PB-08 | Transaksi multi-item, pengembalian, status transaksi, PDF |
| Sprint 4 | Membangun administrasi surat masuk, disposisi, dan surat keluar | PB-09, PB-10, PB-11, PB-12, PB-13 | CRUD surat, lampiran, ekstraksi tanggal, disposisi, status pengiriman |
| Sprint 5 | Membangun laporan, backup, ERD, dan pengujian akhir | PB-14, PB-15, PB-16 | Laporan show/CSV/print, backup SQL, halaman ERD |

## Artefak Scrum yang Bisa Ditulis di Skripsi

Artefak yang dapat dibuat untuk skripsi:

- Product backlog berdasarkan fitur aplikasi.
- Sprint backlog per sprint.
- Sprint goal.
- Increment/hasil implementasi per sprint.
- Tabel pengujian per backlog item.
- Catatan sprint review berdasarkan kesesuaian fitur dengan kebutuhan.
- Catatan retrospective secara umum, bila user dapat memberikan bukti atau narasi yang valid.

Catatan: artefak seperti tanggal sprint, anggota Scrum Team, Daily Scrum, Sprint Review aktual, dan Sprint Retrospective aktual belum ditemukan dalam file aplikasi. Bagian ini belum boleh ditulis sebagai fakta historis tanpa konfirmasi atau bukti tambahan.

## Penyesuaian BAB IV Implementasi dan Pengujian Software

Outline 156 tetap dapat dipertahankan dengan penyesuaian berikut:

- `4.1 Desain`: menjelaskan desain database, arsitektur MVC CodeIgniter, dan desain user interface.
- `4.1.1 Database`: menggunakan tabel, ERD, dan LRS dari migration/SQL/ErdController.
- `4.1.2 Software Architecture`: menjelaskan route, controller, model, view, filter, helper, library, dan alur MVC.
- `4.1.3 User Interface`: menampilkan screenshot halaman login, dashboard, aset, transaksi, surat, disposisi, laporan, backup, dan ERD.
- `4.2 Code Generation`: menampilkan potongan kode terpilih dari controller, model, route, filter, upload, PDF, dan ekstraksi tanggal.
- `4.3 Testing`: menyusun black-box testing berdasarkan backlog dan role.
- `4.4 Support`: menjelaskan kebutuhan hardware/software, Laragon, PHP, Composer, MySQL/MariaDB, dan publikasi software bila tersedia.

Scrum dapat menjadi kerangka implementasi yang menjelaskan bagaimana fitur-fitur pada BAB IV dibangun bertahap melalui sprint, tanpa mengubah struktur utama outline.

## Hubungan Scrum dengan Implementasi Fitur

Hubungan yang dapat ditulis:

- Product backlog menjadi daftar kebutuhan fitur.
- Sprint backlog memecah fitur menjadi pekerjaan per modul.
- Increment terlihat sebagai modul yang sudah ada pada route, controller, model, view, dan database.
- Setiap sprint menghasilkan bagian aplikasi yang bisa diuji.
- BAB IV dapat menyajikan implementasi fitur sesuai sprint, lalu tetap mengelompokkan hasilnya menurut desain, code generation, testing, dan support.

## Hubungan Scrum dengan Pengujian Software

Pengujian software dapat dihubungkan dengan Scrum melalui:

- Acceptance criteria per backlog item.
- Black-box testing per fitur dan role.
- Test scenario per sprint.
- Sprint review sebagai evaluasi hasil increment.
- Perbaikan backlog berdasarkan hasil pengujian.

Contoh pengujian yang perlu disiapkan:

- Login berhasil/gagal.
- Pembatasan akses berdasarkan role.
- CRUD aset.
- Upload foto aset.
- Transaksi peminjaman dan pengembalian aset.
- Upload lampiran surat.
- Ekstraksi tanggal surat.
- Disposisi dan update status.
- Surat keluar dan status pengiriman.
- Laporan show/CSV/print.
- Backup database.

## Risiko Jika Bukti Scrum Tidak Tersedia Eksplisit

- Risiko mengarang riwayat sprint jika tanggal, aktor, dan aktivitas Scrum ditulis tanpa bukti.
- Risiko konflik dengan dosen jika Scrum hanya muncul di naskah tetapi tidak didukung artefak.
- Risiko BAB IV terlalu fokus pada metode dan tidak sesuai outline bila struktur `Desain`, `Code Generation`, `Testing`, dan `Support` tidak dipertahankan.
- Risiko product backlog tidak valid bila memuat fitur yang tidak benar-benar ada di aplikasi.

## Rekomendasi Cara Menulis Agile Scrum Secara Aman

- Tulis Scrum sebagai model pengembangan software yang digunakan untuk mengelompokkan kebutuhan dan implementasi fitur.
- Bedakan antara fakta aplikasi yang sudah ditemukan dan usulan dokumentasi Scrum.
- Jangan menulis tanggal sprint, nama Scrum Master, Product Owner, Daily Scrum, Sprint Review, atau Retrospective sebagai fakta jika belum ada bukti.
- Gunakan backlog yang langsung berasal dari route, controller, model, view, dan database.
- Gunakan istilah "usulan sprint", "mapping sprint", atau "rekonstruksi dokumentasi berdasarkan fitur aplikasi" bila bukti historis belum tersedia.
- Minta user menyediakan bukti tambahan jika ingin menulis Scrum sebagai proses historis penuh.
- Pertahankan struktur BAB IV sesuai outline 156.

## Sumber File Pendukung

- `skripsi/01-pedoman-dan-outline/OUTLINE_156_MAPPING.md`
- `app/Config/Routes.php`
- `app/Controllers/*.php`
- `app/Models/*.php`
- `app/Views/*`
- `app/Database/Migrations/*.php`
- `database/*.sql`
- `README.md`
