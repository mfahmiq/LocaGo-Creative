# DATABASE_ERD_AUDIT

## Status Audit

- Tanggal audit: 2026-07-04
- Lingkup: audit database, migration, SQL dump, model, dan ERD untuk dasar BAB III dan BAB IV.
- Metode: membaca file database dan kode terkait secara read-only.
- Batasan keamanan: konfigurasi credential database tidak dibuka atau ditampilkan.

## Daftar File SQL/Migration yang Ditemukan

File SQL:

- `database/aset_surat_web_full.sql`
- `database/aset_surat_web_full_utf8.sql`
- `database/aset_surat_web_phpmyadmin_utf8.sql`

File migration:

- `app/Database/Migrations/2026-06-16-000001_CreateSmpiRejisTables.php`
- `app/Database/Migrations/2026-06-16-000002_CreateAssetTransactionTables.php`

File seeder:

- `app/Database/Seeds/DatabaseSeeder.php`

Catatan: SQL dump yang ditemukan berisi struktur tabel. Data insert tidak ditemukan pada file SQL yang diaudit. Seeder tersedia, tetapi detail akun demo tidak ditampilkan.

## Daftar Tabel Database

Tabel bisnis dan pendukung yang ditemukan:

- `users`
- `asset_categories`
- `asset_locations`
- `assets`
- `asset_transactions`
- `asset_transaction_items`
- `incoming_letters`
- `dispositions`
- `outgoing_letters`
- `migrations`

Sumber: `database/*.sql`, `app/Database/Migrations/*.php`, `app/Controllers/ErdController.php`.

## Field Penting, Primary Key, dan Relasi

### users

- Field penting: `id`, `name`, `username`, `password_hash`, `role`, `is_active`, `last_login_at`, `created_at`, `updated_at`.
- Primary key: `id`.
- Unique key: `username`.
- Digunakan oleh: autentikasi, role, pencatatan pembuat data, dan pihak yang melakukan disposisi.
- Sumber: `app/Models/UserModel.php`, `database/*.sql`.

### asset_categories

- Field penting: `id`, `name`, `description`, `created_at`, `updated_at`.
- Primary key: `id`.
- Unique key: `name`.
- Digunakan oleh: klasifikasi aset.
- Sumber: `app/Models/AssetCategoryModel.php`, `database/*.sql`.

### asset_locations

- Field penting: `id`, `name`, `description`, `created_at`, `updated_at`.
- Primary key: `id`.
- Unique key: `name`.
- Digunakan oleh: lokasi aset.
- Sumber: `app/Models/AssetLocationModel.php`, `database/*.sql`.

### assets

- Field penting: `id`, `code`, `name`, `category_id`, `location_id`, `quantity`, `condition_status`, `acquisition_year`, `funding_source`, `value`, `custodian`, `photo`, `notes`, `created_at`, `updated_at`.
- Primary key: `id`.
- Unique key: `code`.
- Foreign key:
  - `category_id` ke `asset_categories.id`.
  - `location_id` ke `asset_locations.id`.
- Index yang terlihat: `category_id`, `location_id`, `condition_status`.
- Digunakan oleh: inventaris aset dan item transaksi aset.
- Sumber: `app/Models/AssetModel.php`, `database/*.sql`, `app/Controllers/ErdController.php`.

### asset_transactions

- Field penting: `id`, `transaction_code`, `borrower_unit`, `borrower_name`, `purpose`, `loan_date`, `expected_return_date`, `actual_return_date`, `status`, `notes`, `created_by`, `created_at`, `updated_at`.
- Primary key: `id`.
- Unique key: `transaction_code`.
- Foreign key:
  - `created_by` ke `users.id`.
- Index yang terlihat: `status`, `loan_date`.
- Digunakan oleh: header transaksi/peminjaman aset.
- Sumber: `app/Models/AssetTransactionModel.php`, `database/*.sql`, `app/Controllers/ErdController.php`.

### asset_transaction_items

- Field penting: `id`, `asset_transaction_id`, `asset_id`, `quantity`, `condition_before`, `condition_after`, `notes`, `created_at`, `updated_at`.
- Primary key: `id`.
- Foreign key:
  - `asset_transaction_id` ke `asset_transactions.id`.
  - `asset_id` ke `assets.id`.
- Index yang terlihat: `asset_transaction_id`, `asset_id`.
- Digunakan oleh: rincian item aset dalam transaksi.
- Sumber: `app/Models/AssetTransactionItemModel.php`, `database/*.sql`, `app/Controllers/ErdController.php`.

### incoming_letters

- Field penting: `id`, `letter_number`, `letter_date`, `received_date`, `sender`, `subject`, `priority`, `summary`, `attachment`, `status`, `created_by`, `created_at`, `updated_at`.
- Primary key: `id`.
- Foreign key:
  - `created_by` ke `users.id`.
- Index yang terlihat: `status`, `received_date`.
- Digunakan oleh: pencatatan surat masuk dan dasar disposisi.
- Sumber: `app/Models/IncomingLetterModel.php`, `database/*.sql`, `app/Controllers/ErdController.php`.

### dispositions

- Field penting: `id`, `incoming_letter_id`, `target_unit`, `instruction`, `due_date`, `status`, `disposed_by`, `created_at`, `updated_at`.
- Primary key: `id`.
- Foreign key:
  - `incoming_letter_id` ke `incoming_letters.id`.
  - `disposed_by` ke `users.id`.
- Index yang terlihat: `incoming_letter_id`, `status`.
- Digunakan oleh: disposisi surat masuk.
- Sumber: `app/Models/DispositionModel.php`, `database/*.sql`, `app/Controllers/ErdController.php`.

### outgoing_letters

- Field penting: `id`, `letter_number`, `letter_date`, `recipient`, `destination_unit`, `subject`, `attachment`, `status`, `receiver_name`, `received_date`, `delivery_notes`, `created_by`, `created_at`, `updated_at`.
- Primary key: `id`.
- Foreign key:
  - `created_by` ke `users.id`.
- Index yang terlihat: `status`, `letter_date`.
- Digunakan oleh: pencatatan surat keluar dan status pengiriman.
- Sumber: `app/Models/OutgoingLetterModel.php`, `database/*.sql`, `app/Controllers/ErdController.php`.

### migrations

- Field penting: `id`, `version`, `class`, `group`, `namespace`, `time`, `batch`.
- Primary key: `id`.
- Digunakan oleh: sistem migration CodeIgniter, bukan tabel bisnis utama.
- Sumber: `database/*.sql`, `app/Controllers/ErdController.php`.

## Relasi Antar Tabel

Relasi utama yang terlihat:

- Satu `asset_categories` memiliki banyak `assets`.
- Satu `asset_locations` memiliki banyak `assets`.
- Satu `users` dapat membuat banyak `incoming_letters`.
- Satu `users` dapat membuat banyak `outgoing_letters`.
- Satu `users` dapat membuat banyak `asset_transactions`.
- Satu `users` dapat melakukan banyak `dispositions`.
- Satu `incoming_letters` dapat memiliki banyak `dispositions`.
- Satu `asset_transactions` dapat memiliki banyak `asset_transaction_items`.
- Satu `assets` dapat muncul pada banyak `asset_transaction_items`.

Sumber: `database/*.sql`, `app/Models/*.php`, `app/Controllers/ErdController.php`.

## Mapping Tabel ke Modul Aplikasi

- Autentikasi dan role: `users`.
- Dashboard: agregasi dari `assets`, `incoming_letters`, `outgoing_letters`, `dispositions`, `users`, `asset_transactions`.
- Inventaris aset: `assets`, `asset_categories`, `asset_locations`.
- Transaksi/peminjaman aset: `asset_transactions`, `asset_transaction_items`, `assets`, `users`.
- Surat masuk: `incoming_letters`, `users`.
- Disposisi: `dispositions`, `incoming_letters`, `users`.
- Surat keluar: `outgoing_letters`, `users`.
- Laporan: tabel modul bisnis sesuai jenis laporan.
- Backup: seluruh tabel database.
- ERD: dokumentasi seluruh tabel dan relasi.

Sumber: `app/Controllers/*.php`, `app/Models/*.php`, `app/Controllers/ErdController.php`.

## Ringkasan ERD dari ErdController.php

`ErdController.php` menyediakan dokumentasi database dalam bentuk:

- Daftar tabel dan deskripsi.
- Daftar field per tabel.
- Relasi antar tabel.
- Mermaid ERD.
- Catatan desain database.

Catatan desain yang terlihat:

- Role pengguna disimpan sebagai enum/string pada tabel `users`, bukan tabel role terpisah.
- Tujuan disposisi disimpan sebagai teks `target_unit`, bukan foreign key ke tabel user/unit.
- Tabel `migrations` adalah tabel sistem CodeIgniter dan tidak menjadi relasi bisnis utama.

Sumber: `app/Controllers/ErdController.php`, `app/Views/erd/index.php`.

## Dukungan Database terhadap Modul Aplikasi

Database mendukung modul utama aplikasi sebagai berikut:

- Modul user dan autentikasi didukung oleh tabel `users`.
- Modul aset didukung oleh tabel `assets`, `asset_categories`, dan `asset_locations`.
- Modul transaksi aset didukung oleh tabel `asset_transactions` dan `asset_transaction_items`.
- Modul surat masuk didukung oleh tabel `incoming_letters`.
- Modul disposisi didukung oleh tabel `dispositions`.
- Modul surat keluar didukung oleh tabel `outgoing_letters`.
- Modul laporan didukung melalui query ke tabel modul masing-masing.
- Modul backup didukung dengan pembacaan daftar tabel dan dump SQL.

Catatan: dukungan database dinilai dari file model, controller, migration, SQL, dan ERD. Isi database aktif belum diverifikasi pada tahap ini.

## Kebutuhan LRS untuk Skripsi

LRS yang perlu disiapkan untuk skripsi:

- LRS `users`.
- LRS `asset_categories`.
- LRS `asset_locations`.
- LRS `assets`.
- LRS `asset_transactions`.
- LRS `asset_transaction_items`.
- LRS `incoming_letters`.
- LRS `dispositions`.
- LRS `outgoing_letters`.

Catatan: tabel `migrations` dapat dikecualikan dari LRS bisnis utama karena merupakan tabel sistem framework, kecuali dosen meminta seluruh tabel fisik dicantumkan.

## Risiko atau Kekurangan Database

- Tidak ditemukan data insert pada file SQL dump yang diaudit, sehingga data contoh perlu diambil dari seeder atau database aktif bila diperlukan.
- Isi database aktif belum diverifikasi karena konfigurasi credential tidak dibuka.
- `target_unit` pada disposisi berupa teks, sehingga tidak ada relasi formal ke tabel unit atau user tujuan.
- Role disimpan langsung pada `users`, bukan tabel role terpisah. Ini cukup untuk aplikasi kecil, tetapi perlu dijelaskan jika diminta normalisasi lanjutan.
- Belum ditemukan tabel audit trail/log aktivitas.
- Bukti relasi dan constraint perlu divisualisasikan ulang menjadi ERD/LRS yang rapi untuk naskah skripsi.

## Sumber File Pendukung

- `database/aset_surat_web_full.sql`
- `database/aset_surat_web_full_utf8.sql`
- `database/aset_surat_web_phpmyadmin_utf8.sql`
- `app/Database/Migrations/2026-06-16-000001_CreateSmpiRejisTables.php`
- `app/Database/Migrations/2026-06-16-000002_CreateAssetTransactionTables.php`
- `app/Database/Seeds/DatabaseSeeder.php`
- `app/Controllers/ErdController.php`
- `app/Views/erd/index.php`
- `app/Models/UserModel.php`
- `app/Models/AssetCategoryModel.php`
- `app/Models/AssetLocationModel.php`
- `app/Models/AssetModel.php`
- `app/Models/AssetTransactionModel.php`
- `app/Models/AssetTransactionItemModel.php`
- `app/Models/IncomingLetterModel.php`
- `app/Models/DispositionModel.php`
- `app/Models/OutgoingLetterModel.php`
