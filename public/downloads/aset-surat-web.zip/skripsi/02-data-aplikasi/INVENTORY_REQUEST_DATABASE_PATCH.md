# INVENTORY_REQUEST_DATABASE_PATCH

## Status

- Tanggal patch: 2026-07-05.
- Migration: `app/Database/Migrations/2026-07-05-000001_CreateInventoryRequestTables.php`.
- Status migration: sudah dijalankan pada database lokal.
- Sifat perubahan: non-destruktif, menambah tabel baru tanpa mengubah tabel lama.

## Tabel Baru: inventory_requests

| Field | Tipe | Keterangan |
| --- | --- | --- |
| `id` | unsigned int | Primary key |
| `request_number` | varchar(30) | Nomor pengajuan unik, format `PI-YYYYMMDD-XXXX` |
| `request_date` | date | Tanggal pengajuan |
| `requester_name` | varchar(150) | Nama pemohon |
| `requester_unit` | varchar(150) | Unit pemohon |
| `request_type` | enum | Jenis pengajuan |
| `priority` | enum | Prioritas pengajuan |
| `reason` | text | Alasan pengajuan |
| `needed_date` | date nullable | Tanggal dibutuhkan |
| `status` | enum | Status pengajuan |
| `approval_notes` | text nullable | Catatan persetujuan atau penolakan |
| `approved_by` | unsigned int nullable | User yang memproses approval |
| `approved_at` | datetime nullable | Waktu approval/reject |
| `created_by` | unsigned int nullable | User pembuat pengajuan |
| `created_at` | datetime nullable | Waktu dibuat |
| `updated_at` | datetime nullable | Waktu diperbarui |

Nilai `request_type`:

1. `peminjaman_aset`
2. `pengadaan_aset`
3. `perbaikan_aset`
4. `penggantian_aset`

Nilai `priority`:

1. `rendah`
2. `sedang`
3. `tinggi`
4. `mendesak`

Nilai `status`:

1. `diajukan`
2. `diproses`
3. `disetujui`
4. `ditolak`
5. `direalisasikan`
6. `selesai`

## Tabel Baru: inventory_request_items

| Field | Tipe | Keterangan |
| --- | --- | --- |
| `id` | unsigned int | Primary key |
| `inventory_request_id` | unsigned int | Relasi ke `inventory_requests.id` |
| `asset_id` | unsigned int nullable | Relasi opsional ke `assets.id` |
| `item_name` | varchar(180) | Nama barang/aset yang diajukan |
| `quantity` | int | Jumlah item |
| `unit` | varchar(50) | Satuan |
| `notes` | varchar(255) nullable | Catatan item |
| `created_at` | datetime nullable | Waktu dibuat |
| `updated_at` | datetime nullable | Waktu diperbarui |

## Relasi

1. `inventory_requests.created_by` -> `users.id`
2. `inventory_requests.approved_by` -> `users.id`
3. `inventory_request_items.inventory_request_id` -> `inventory_requests.id`
4. `inventory_request_items.asset_id` -> `assets.id`

## Dampak Ke ERD

ERD perlu ditambah dua entitas baru:

1. `inventory_requests`
2. `inventory_request_items`

Relasi ERD yang perlu ditambahkan:

1. `users` 1..n `inventory_requests` sebagai pembuat.
2. `users` 1..n `inventory_requests` sebagai penyetuju/penolak.
3. `inventory_requests` 1..n `inventory_request_items`.
4. `assets` 1..n `inventory_request_items` sebagai aset terkait opsional.

## Dampak Ke LRS

LRS perlu ditambah dua record structure:

1. `inventory_requests`
2. `inventory_request_items`

Kunci utama dan kunci relasi perlu ditulis pada bagian LRS BAB IV 4.1.1 Database.

## Catatan Dukungan Database

Database mendukung modul pengajuan karena:

1. Tabel header dan item dipisah, sehingga satu pengajuan dapat memiliki lebih dari satu item.
2. Pengajuan dapat terhubung ke aset existing jika jenis pengajuan berkaitan dengan aset tertentu.
3. Pembuat dan pemroses approval tercatat melalui relasi ke tabel `users`.
4. Status pengajuan tersimpan eksplisit dan dapat dipakai pada daftar, detail, filter, approval, dan PDF.

## Risiko Atau Kekurangan

1. Belum ada tabel histori status; perubahan status terakhir tercatat pada field status utama.
2. Belum ada flow khusus untuk status `diproses`, `direalisasikan`, dan `selesai`.
3. Belum ada integrasi otomatis ke transaksi aset atau surat keluar.
4. Data dummy uji pengajuan tersimpan pada database lokal dan dapat dibersihkan manual jika tidak lagi diperlukan.

