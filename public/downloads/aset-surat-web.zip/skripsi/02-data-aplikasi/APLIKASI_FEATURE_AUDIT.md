# APLIKASI_FEATURE_AUDIT

## Status Audit

- Tanggal audit: 2026-07-04
- Lingkup: audit fitur aplikasi untuk dasar BAB III dan BAB IV.
- Metode: membaca file aplikasi secara read-only, tanpa menjalankan perubahan pada kode, database, file upload, PDF asli, atau runtime.
- Batasan keamanan: file credential, password, token, API key, cookie, session, dan data sensitif tidak dibuka atau ditampilkan.

## Identitas Aplikasi

- Nama aplikasi yang terlihat: Aset Surat Web.
- Konteks instansi yang terlihat: SMPI REJIS.
- Fungsi utama: pengelolaan inventaris aset, transaksi/peminjaman aset, surat masuk, disposisi, surat keluar, laporan, dan backup database.
- Catatan pembaruan 2026-07-04: ERD database tidak lagi menjadi menu/fitur operasional user-facing. `ErdController.php` tetap dipertahankan sebagai artefak dokumentasi pengembangan dan referensi skripsi.
- Sumber: `README.md`, `app/Config/Routes.php`, `app/Views/layouts/main.php`.

## Framework dan Versi

- Framework: CodeIgniter 4.
- Paket framework pada lock file: `codeigniter4/framework` versi `v4.7.3`.
- Kebutuhan PHP pada `composer.json`: `^8.2`.
- Paket pengujian pengembangan yang terlihat: PHPUnit `^10.5.16`.
- Sumber: `composer.json`, `composer.lock`.

## Struktur Folder Aplikasi

Folder utama aplikasi yang terlihat:

- `app/Config`
- `app/Controllers`
- `app/Database`
- `app/Filters`
- `app/Helpers`
- `app/Language`
- `app/Libraries`
- `app/Models`
- `app/ThirdParty`
- `app/Views`
- `database`
- `public`
- `writable`

Sumber: struktur workspace, `WORKSPACE_AUDIT.md`, dan daftar folder aplikasi.

## Daftar Role Pengguna

Role pengguna yang terlihat:

- `admin`
- `operator`
- `pimpinan`

Label yang terlihat:

- `admin`: Administrator
- `operator`: Operator / TU
- `pimpinan`: Pimpinan

Catatan: akun demo/seeder tersedia berdasarkan README dan seeder, tetapi detail akun tidak ditampilkan sesuai aturan keamanan.

Sumber: `app/Helpers/auth_helper.php`, `app/Models/UserModel.php`, `app/Config/Routes.php`, `README.md`, `app/Database/Seeds/DatabaseSeeder.php`.

## Daftar Modul Utama

Modul utama yang ditemukan:

- Autentikasi dan logout.
- Dashboard.
- Manajemen pengguna.
- Inventaris aset.
- Transaksi aset/peminjaman aset.
- Surat masuk.
- Disposisi surat.
- Surat keluar.
- Laporan.
- Backup database.

Sumber: `app/Views/layouts/main.php`, `app/Config/Routes.php`, `README.md`.

## Daftar Menu dan Halaman

Menu pada layout utama:

- Dashboard.
- Pengguna.
- Inventaris Aset.
- Transaksi Aset.
- Surat Masuk.
- Surat Keluar.
- Disposisi.
- Laporan.
- Backup.

Folder view utama:

- `app/Views/auth`
- `app/Views/dashboard`
- `app/Views/erd`
- `app/Views/users`
- `app/Views/assets`
- `app/Views/asset_transactions`
- `app/Views/incoming_letters`
- `app/Views/dispositions`
- `app/Views/outgoing_letters`
- `app/Views/reports`
- `app/Views/backup`
- `app/Views/layouts`

Sumber: `app/Views/layouts/main.php`, struktur `app/Views`.

## Daftar Route Penting

Route publik:

- `GET /` ke `AuthController::login`.
- `GET login` ke `AuthController::login`.
- `POST login` ke `AuthController::attempt`.
- `GET logout` ke `AuthController::logout`.

Route dengan filter `auth`:

- `dashboard` ke `DashboardController::index`.
- `erd` ke `ErdController::index` hanya didaftarkan pada environment `development` dan tidak tampil di sidebar/menu operasional.
- `users` untuk CRUD pengguna, khusus admin.
- `assets` untuk inventaris aset.
- `asset-transactions` untuk transaksi/peminjaman aset.
- `incoming-letters` untuk surat masuk, ekstraksi tanggal, disposisi, status, dan CRUD.
- `outgoing-letters` untuk surat keluar, pengiriman, status, dan CRUD.
- `dispositions` untuk daftar dan update status disposisi.
- `reports` untuk laporan, detail, CSV, dan cetak.
- `backup` untuk daftar dan unduh backup database, khusus admin.

Sumber: `app/Config/Routes.php`.

## Daftar Controller Penting

- `AuthController`: login, verifikasi login, logout.
- `DashboardController`: ringkasan data, grafik tren, grafik kondisi aset, surat terbaru, disposisi pending.
- `UsersController`: CRUD pengguna.
- `AssetsController`: CRUD inventaris aset, upload foto aset, filter data.
- `AssetTransactionsController`: transaksi peminjaman, detail, PDF, pengembalian, hapus transaksi.
- `IncomingLettersController`: CRUD surat masuk, upload lampiran, ekstraksi tanggal, disposisi, update status.
- `DispositionsController`: daftar disposisi dan update status.
- `OutgoingLettersController`: CRUD surat keluar, update pengiriman, upload lampiran.
- `ReportsController`: laporan aset, surat masuk, surat keluar, disposisi, dan transaksi aset.
- `BackupController`: daftar tabel dan unduh backup SQL.
- `ErdController`: dokumentasi ERD dan relasi database untuk referensi pengembangan/skripsi, bukan fitur operasional user-facing.

Sumber: `app/Controllers/*.php`.

## Daftar Model Penting

- `UserModel`: tabel `users`, login, role, status aktif.
- `AssetCategoryModel`: tabel `asset_categories`.
- `AssetLocationModel`: tabel `asset_locations`.
- `AssetModel`: tabel `assets`.
- `AssetTransactionModel`: tabel `asset_transactions`.
- `AssetTransactionItemModel`: tabel `asset_transaction_items`.
- `IncomingLetterModel`: tabel `incoming_letters`.
- `DispositionModel`: tabel `dispositions`.
- `OutgoingLetterModel`: tabel `outgoing_letters`.

Sumber: `app/Models/*.php`.

## Daftar View Penting

- Login: `app/Views/auth/login.php`.
- Dashboard: `app/Views/dashboard/index.php`.
- Layout utama: `app/Views/layouts/main.php`.
- ERD: `app/Views/erd/index.php` sebagai view dokumentasi dev-only, tidak ditampilkan pada navigasi aplikasi.
- Pengguna: `app/Views/users/index.php`, `app/Views/users/form.php`.
- Aset: `app/Views/assets/index.php`, `app/Views/assets/form.php`, `app/Views/assets/show.php`.
- Transaksi aset: `app/Views/asset_transactions/index.php`, `app/Views/asset_transactions/form.php`, `app/Views/asset_transactions/show.php`.
- Surat masuk: `app/Views/incoming_letters/index.php`, `app/Views/incoming_letters/form.php`, `app/Views/incoming_letters/show.php`.
- Disposisi: `app/Views/dispositions/index.php`.
- Surat keluar: `app/Views/outgoing_letters/index.php`, `app/Views/outgoing_letters/form.php`, `app/Views/outgoing_letters/show.php`.
- Laporan: `app/Views/reports/index.php`, `app/Views/reports/show.php`, `app/Views/reports/print.php`.
- Backup: `app/Views/backup/index.php`.

Sumber: struktur `app/Views`.

## Alur Autentikasi

Alur yang terlihat:

1. Pengguna membuka halaman login.
2. Form login mengirim `username` dan `password`.
3. `AuthController::attempt` memvalidasi input.
4. `UserModel::verifyLogin` mencari user aktif berdasarkan username dan memverifikasi password hash.
5. Jika valid, session diregenerasi dan data user disimpan pada session.
6. Route internal dilindungi filter `auth`.
7. Hak akses modul dibatasi filter `role`.
8. Logout menghapus data session login.

Sumber: `app/Controllers/AuthController.php`, `app/Models/UserModel.php`, `app/Filters/AuthFilter.php`, `app/Filters/RoleFilter.php`, `app/Config/Filters.php`, `app/Config/Routes.php`.

## Alur Manajemen Aset

Alur yang terlihat:

1. Admin/operator membuka daftar aset dan dapat memfilter berdasarkan kata kunci, kategori, lokasi, dan kondisi.
2. Admin/operator dapat menambah data aset.
3. Form aset memuat kode, nama, kategori, lokasi, kondisi, jumlah, tahun perolehan, sumber dana, nilai, penanggung jawab, foto, dan catatan.
4. Foto aset dapat diunggah dengan batas jenis file gambar tertentu.
5. Admin/operator dapat mengubah aset.
6. Admin dapat menghapus aset.
7. Detail aset dapat dilihat oleh admin, operator, dan pimpinan.

Sumber: `app/Controllers/AssetsController.php`, `app/Views/assets/index.php`, `app/Views/assets/form.php`, `app/Views/assets/show.php`, `app/Models/AssetModel.php`, `app/Traits/HandlesUploads.php`, `app/Config/Routes.php`.

## Alur Transaksi/Peminjaman Aset

Alur yang terlihat:

1. Admin/operator membuat transaksi peminjaman aset.
2. Form transaksi memuat kode transaksi, tanggal pinjam, estimasi tanggal kembali, unit peminjam, nama peminjam, tujuan, daftar aset, jumlah, kondisi awal, catatan item, dan catatan transaksi.
3. Transaksi dapat memuat lebih dari satu item aset.
4. Status awal transaksi yang terlihat adalah `dipinjam`.
5. Pengguna yang berhak dapat melihat detail transaksi dan mengunduh PDF.
6. Admin/operator dapat mencatat pengembalian dengan tanggal kembali, status akhir, kondisi setelah kembali, dan catatan.
7. Status pengembalian yang terlihat mencakup `dikembalikan`, `rusak_saat_kembali`, `hilang`, dan `dibatalkan`.
8. Admin dapat menghapus transaksi.

Sumber: `app/Controllers/AssetTransactionsController.php`, `app/Views/asset_transactions/index.php`, `app/Views/asset_transactions/form.php`, `app/Views/asset_transactions/show.php`, `app/Models/AssetTransactionModel.php`, `app/Models/AssetTransactionItemModel.php`, `app/Libraries/SimplePdf.php`, `app/Config/Routes.php`.

## Alur Surat Masuk

Alur yang terlihat:

1. Admin/operator membuka daftar surat masuk dan dapat memfilter berdasarkan kata kunci, status, prioritas, dan rentang tanggal.
2. Admin/operator membuat data surat masuk.
3. Form surat masuk memuat nomor surat, tanggal surat, tanggal diterima, pengirim, prioritas, perihal, ringkasan, dan lampiran.
4. Lampiran surat masuk dapat berupa PDF atau gambar dengan batas ukuran tertentu.
5. Tersedia route ekstraksi tanggal dari lampiran.
6. Status awal surat masuk yang terlihat adalah `menunggu_disposisi`.
7. Detail surat masuk menampilkan data surat dan disposisi terkait.
8. Admin/operator dapat mengubah surat masuk.
9. Status surat masuk dapat diperbarui.
10. Admin dapat menghapus surat masuk.

Sumber: `app/Controllers/IncomingLettersController.php`, `app/Views/incoming_letters/index.php`, `app/Views/incoming_letters/form.php`, `app/Views/incoming_letters/show.php`, `app/Models/IncomingLetterModel.php`, `app/Libraries/LetterDateExtractor.php`, `app/Traits/HandlesUploads.php`, `app/Config/Routes.php`.

## Alur Disposisi Surat

Alur yang terlihat:

1. Surat masuk dapat didisposisikan oleh admin atau pimpinan.
2. Disposisi memuat tujuan/unit, instruksi, tanggal jatuh tempo, status, dan pihak yang mendisposisikan.
3. Setelah disposisi dibuat, status surat masuk berubah menjadi `didisposisikan`.
4. Daftar disposisi dapat difilter berdasarkan kata kunci dan status.
5. Status disposisi dapat diperbarui.
6. Perubahan status disposisi menyinkronkan status surat masuk, misalnya proses menjadi `dalam_proses` dan selesai menjadi `selesai`.

Sumber: `app/Controllers/IncomingLettersController.php`, `app/Controllers/DispositionsController.php`, `app/Models/DispositionModel.php`, `app/Models/IncomingLetterModel.php`, `app/Views/dispositions/index.php`, `app/Views/incoming_letters/show.php`.

## Alur Surat Keluar

Alur yang terlihat:

1. Admin/operator membuka daftar surat keluar dan dapat memfilter berdasarkan kata kunci, status, dan rentang tanggal.
2. Admin/operator membuat data surat keluar.
3. Form surat keluar memuat nomor surat, tanggal surat, penerima, unit tujuan, perihal, lampiran, status, dan catatan pengiriman.
4. Lampiran dapat diunggah.
5. Admin/operator dapat mengubah data surat keluar.
6. Status pengiriman dapat diperbarui.
7. Jika status menjadi `diterima_tujuan`, data penerima dan tanggal diterima wajib dicatat.
8. Admin dapat menghapus surat keluar.

Sumber: `app/Controllers/OutgoingLettersController.php`, `app/Views/outgoing_letters/index.php`, `app/Views/outgoing_letters/form.php`, `app/Views/outgoing_letters/show.php`, `app/Models/OutgoingLetterModel.php`, `app/Traits/HandlesUploads.php`, `app/Config/Routes.php`.

## Alur Laporan

Alur yang terlihat:

1. Modul laporan mendukung beberapa jenis data: aset, surat masuk, surat keluar, disposisi, dan transaksi aset.
2. Laporan dapat ditampilkan, diekspor CSV, dan dicetak.
3. Filter tanggal dan status tersedia untuk modul yang relevan.
4. View laporan memiliki halaman index, show, dan print.

Sumber: `app/Controllers/ReportsController.php`, `app/Views/reports/index.php`, `app/Views/reports/show.php`, `app/Views/reports/print.php`, `app/Config/Routes.php`.

## Fitur Backup

Fitur backup yang terlihat:

- Modul backup tersedia untuk admin.
- Halaman backup menampilkan tabel database.
- `BackupController::download` membuat dump SQL berisi struktur dan data tabel.

Sumber: `app/Controllers/BackupController.php`, `app/Views/backup/index.php`, `app/Config/Routes.php`.

## Fitur yang Relevan untuk BAB III

Fitur yang dapat menjadi dasar BAB III:

- Aktor dan hak akses: admin, operator, pimpinan.
- Analisis kebutuhan autentikasi dan pembatasan role.
- Analisis kebutuhan inventaris aset.
- Analisis kebutuhan transaksi/peminjaman dan pengembalian aset.
- Analisis kebutuhan surat masuk dan disposisi.
- Analisis kebutuhan surat keluar dan status pengiriman.
- Analisis kebutuhan laporan dan backup.
- Kebutuhan data berdasarkan model dan database.
- Rancangan alur sistem berdasarkan route, controller, model, dan view.

Sumber: `app/Config/Routes.php`, `app/Controllers/*.php`, `app/Models/*.php`, `app/Views/*`, `app/Helpers/auth_helper.php`.

## Fitur yang Relevan untuk BAB IV

Fitur yang dapat menjadi dasar BAB IV:

- Desain database berdasarkan migration, SQL dump, model, dan `ErdController`.
- Software architecture berbasis pola MVC CodeIgniter 4.
- User interface berdasarkan file view.
- Code generation/contoh implementasi dari controller, model, filter, helper, library, dan trait.
- Testing berbasis skenario login, CRUD aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup.
- Support berupa kebutuhan PHP, Composer, MySQL/MariaDB, dan web server Laragon.

Sumber: `composer.json`, `composer.lock`, `app/Database/Migrations/*.php`, `database/*.sql`, `app/Controllers/*.php`, `app/Models/*.php`, `app/Views/*`, `app/Config/Routes.php`, `README.md`.

## Catatan Fitur yang Belum Pasti

- Aplikasi belum diverifikasi berjalan langsung melalui browser pada tahap audit ini.
- Screenshot final untuk skripsi belum disiapkan.
- Isi database aktif belum diverifikasi karena file konfigurasi sensitif tidak dibuka.
- Detail deployment/publikasi software belum ditemukan.
- Bukti historis pelaksanaan Scrum belum ditemukan eksplisit.
- Format akhir tampilan pada browser perlu dicek pada tahap verifikasi aplikasi.

## Sumber File Pendukung

- `README.md`
- `composer.json`
- `composer.lock`
- `app/Config/Routes.php`
- `app/Config/Filters.php`
- `app/Filters/AuthFilter.php`
- `app/Filters/RoleFilter.php`
- `app/Helpers/auth_helper.php`
- `app/Controllers/AuthController.php`
- `app/Controllers/DashboardController.php`
- `app/Controllers/UsersController.php`
- `app/Controllers/AssetsController.php`
- `app/Controllers/AssetTransactionsController.php`
- `app/Controllers/IncomingLettersController.php`
- `app/Controllers/DispositionsController.php`
- `app/Controllers/OutgoingLettersController.php`
- `app/Controllers/ReportsController.php`
- `app/Controllers/BackupController.php`
- `app/Controllers/ErdController.php`
- `app/Models/*.php`
- `app/Views/*`
- `app/Libraries/SimplePdf.php`
- `app/Libraries/LetterDateExtractor.php`
- `app/Traits/HandlesUploads.php`
