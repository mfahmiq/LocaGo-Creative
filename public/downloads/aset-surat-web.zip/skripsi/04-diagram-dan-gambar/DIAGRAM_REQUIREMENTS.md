# DIAGRAM_REQUIREMENTS

## Status

- Tanggal dibuat: 2026-07-04
- Tujuan: daftar kebutuhan diagram untuk BAB III dan BAB IV.
- Status umum: source diagram prioritas sudah dibuat dalam format Mermaid dan berhasil dirender ke SVG pada 2026-07-04.

## Daftar Diagram yang Diperlukan

| Prioritas | Diagram | Modul yang Dicakup | Sumber Data | Usulan Caption | Status |
| --- | --- | --- | --- | --- | --- |
| Tinggi | Use Case Diagram | Login, aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, backup, pengguna | `Routes.php`, `auth_helper.php`, controller, audit fitur | Gambar III.1 Use Case Diagram Sistem | source dan SVG dibuat |
| Tinggi | Activity Diagram Login | Autentikasi | `AuthController.php`, `UserModel.php`, `AuthFilter.php` | Gambar III.2 Activity Diagram Login | source dan SVG dibuat |
| Tinggi | Activity Diagram Manajemen Aset | Inventaris aset | `AssetsController.php`, `AssetModel.php`, view aset | Gambar III.3 Activity Diagram Manajemen Aset | source dan SVG dibuat |
| Tinggi | Activity Diagram Transaksi Aset | Peminjaman dan pengembalian aset | `AssetTransactionsController.php`, model transaksi, view transaksi | Gambar III.4 Activity Diagram Transaksi Aset | source dan SVG dibuat |
| Tinggi | Activity Diagram Surat Masuk dan Disposisi | Surat masuk, upload lampiran, disposisi, status | `IncomingLettersController.php`, `DispositionsController.php`, model terkait | Gambar III.5 Activity Diagram Surat Masuk dan Disposisi | source dan SVG dibuat |
| Tinggi | Activity Diagram Surat Keluar | Surat keluar dan status pengiriman | `OutgoingLettersController.php`, `OutgoingLetterModel.php` | Gambar III.6 Activity Diagram Surat Keluar | source dan SVG dibuat |
| Tinggi | ERD | Seluruh tabel bisnis utama | `ErdController.php`, migration, SQL dump, model | Gambar IV.1 Entity Relationship Diagram | source dan SVG dibuat |
| Tinggi | LRS | Seluruh tabel bisnis utama | `DATABASE_ERD_AUDIT.md`, migration, SQL dump | Gambar IV.2 Logical Record Structure | draft LRS dibuat |
| Sedang | Arsitektur MVC | Route, controller, model, view, database | `Routes.php`, struktur CodeIgniter, controller, model, view | Gambar IV.3 Arsitektur MVC Aplikasi | source dan SVG dibuat |
| Sedang | Sequence Diagram Login | Proses login | `AuthController.php`, `UserModel.php`, session/filter | Gambar IV.4 Sequence Diagram Login | source dan SVG dibuat |
| Sedang | Sequence Diagram Transaksi Aset | Peminjaman/pengembalian aset | `AssetTransactionsController.php`, model transaksi | Gambar IV.5 Sequence Diagram Transaksi Aset | source dan SVG dibuat |
| Sedang | Sequence Diagram Disposisi Surat | Surat masuk ke disposisi | `IncomingLettersController.php`, `DispositionsController.php` | Gambar IV.6 Sequence Diagram Disposisi Surat | source dan SVG dibuat |
| Sedang | Class Diagram | Controller, model, library, helper inti | `app/Controllers`, `app/Models`, `app/Libraries`, `app/Traits` | Gambar IV.7 Class Diagram Aplikasi | source dan SVG dibuat |
| Sedang | Deployment Diagram | Client, web server, PHP, MySQL/MariaDB, storage upload | README, Composer, Laragon, APPLICATION_VERIFICATION | Gambar IV.8 Deployment Diagram Aplikasi | source dan SVG dibuat |
| Rendah | Diagram Scrum Flow | Product backlog, sprint backlog, increment, testing | `SCRUM_MAPPING_AUDIT.md` | Gambar IV.9 Alur Pengembangan Agile Scrum | source dan SVG dibuat |

## Use Case Diagram

Aktor yang perlu dimasukkan:

- Admin.
- Operator/TU.
- Pimpinan.

Use case utama:

- Login/logout.
- Mengelola pengguna.
- Melihat dashboard.
- Mengelola aset.
- Melihat detail aset.
- Mengelola transaksi/peminjaman aset.
- Mencatat pengembalian aset.
- Mengelola surat masuk.
- Membuat disposisi.
- Memperbarui status disposisi.
- Mengelola surat keluar.
- Memperbarui status pengiriman surat keluar.
- Melihat/mencetak laporan.
- Mengunduh backup database.

Sumber: `app/Config/Routes.php`, `app/Helpers/auth_helper.php`, `APLIKASI_FEATURE_AUDIT.md`.

Catatan pembaruan: ERD tidak dimasukkan sebagai use case operasional aplikasi final karena menu ERD sudah disembunyikan. ERD tetap digunakan sebagai diagram desain database untuk skripsi.

## Activity Diagram

Activity diagram yang direkomendasikan:

- Login.
- Manajemen aset.
- Transaksi/peminjaman aset.
- Pengembalian aset.
- Surat masuk.
- Disposisi surat.
- Surat keluar.
- Laporan.

Sumber: controller dan view masing-masing modul.

## Sequence Diagram

Sequence diagram yang direkomendasikan:

- Login: user, form login, `AuthController`, `UserModel`, session.
- Transaksi aset: user, form transaksi, `AssetTransactionsController`, `AssetTransactionModel`, `AssetTransactionItemModel`, `AssetModel`.
- Disposisi surat: user, detail surat masuk, `IncomingLettersController`, `DispositionModel`, `IncomingLetterModel`.
- Surat keluar: user, form surat keluar, `OutgoingLettersController`, `OutgoingLetterModel`.

Status pembaruan 2026-07-04: sequence login, transaksi aset, dan disposisi surat sudah dibuat sebagai source Mermaid dan SVG.

## Class Diagram

Class diagram dapat memuat:

- Controller utama.
- Model utama.
- Library `SimplePdf`.
- Library `LetterDateExtractor`.
- Trait `HandlesUploads`.
- Helper autentikasi sebagai catatan pendukung, bila tidak dimodelkan sebagai class.

Catatan: class diagram sebaiknya dibuat ringkas agar tidak terlalu padat.

## ERD

Sumber ERD sudah tersedia:

- `app/Controllers/ErdController.php`.
- `app/Views/erd/index.php`.
- `app/Database/Migrations/*.php`.
- `database/*.sql`.

Status:

- Sudah dibuat ulang sebagai source Mermaid `diagram-source/erd-final.mmd`.
- Output SVG tersedia di `diagram-output/erd-final.svg`.

## LRS

LRS perlu dibuat berdasarkan tabel:

- `users`
- `asset_categories`
- `asset_locations`
- `assets`
- `asset_transactions`
- `asset_transaction_items`
- `incoming_letters`
- `dispositions`
- `outgoing_letters`

Catatan:

- Tabel `migrations` dapat dikecualikan dari LRS bisnis utama, kecuali dosen meminta semua tabel fisik.
- Draft LRS tersedia di `LRS_DRAFT.md`.

## Deployment Diagram

Komponen yang perlu dimasukkan:

- Client/browser.
- Web server lokal atau server publik/intranet.
- PHP/CodeIgniter 4.
- MySQL/MariaDB.
- Storage upload.
- Composer dependency.

Status publikasi software belum dipastikan, sehingga deployment diagram awal sebaiknya menulis status lokal/Laragon sampai ada konfirmasi.

## Arsitektur MVC

Arsitektur yang perlu digambarkan:

- Request masuk ke route.
- Filter auth/role.
- Controller memproses request.
- Model mengakses database.
- View menampilkan UI.
- Library/trait membantu proses upload, PDF, ekstraksi tanggal.

Sumber: struktur CodeIgniter, `Routes.php`, controller, model, view, library, trait.

## Prioritas Pembuatan Diagram

Prioritas 1:

- Use Case Diagram.
- Activity Diagram modul inti.
- ERD.
- LRS.

Prioritas 2:

- Arsitektur MVC.
- Sequence Diagram login/transaksi/disposisi.
- Deployment Diagram.

Prioritas 3:

- Class Diagram.
- Diagram Scrum Flow.

## Pembaruan Quality Gate

Tanggal pembaruan: 2026-07-04

- Diagram opsional yang dibuat: `activity-transaksi-aset.mmd`, `activity-surat-keluar.mmd`, dan `scrum-flow.mmd`.
- Output SVG tambahan tersedia di `diagram-output/`.
- Quality review tersedia di `DIAGRAM_QUALITY_REVIEW.md`.
- Diagram padat seperti ERD, class diagram, dan activity diagram panjang perlu ukuran besar/landscape saat dimasukkan ke DOCX.

## Catatan Risiko

- Jangan menyalin contoh diagram Dijkstra dari outline karena tidak sesuai konteks aplikasi.
- Jangan membuat diagram berdasarkan fitur yang tidak ditemukan.
- Diagram harus mengikuti role dan route yang benar-benar ada.
- ERD/LRS harus mengikuti migration/SQL/model, bukan asumsi baru.
- Deployment diagram final perlu menunggu status publikasi software.
