# SCREENSHOT_REQUIREMENTS

## Status

- Tanggal dibuat: 2026-07-04
- Tujuan: daftar kebutuhan screenshot untuk BAB IV, khususnya subbab `4.1.3 User Interface`.
- Status pengambilan screenshot: screenshot awal dan bukti CRUD sudah tersedia; screenshot dashboard/sidebar final sebaiknya diambil ulang setelah menu ERD disembunyikan.

## Aturan Umum Screenshot

- Ambil screenshot setelah aplikasi berhasil berjalan dengan database aktif.
- Jangan menampilkan credential, password, token, session, cookie, atau data sensitif.
- Gunakan data dummy atau data demo yang aman untuk ditampilkan.
- Hindari menampilkan file upload/dokumen asli yang bersifat operasional.
- Simpan hasil screenshot di folder `skripsi/04-diagram-dan-gambar/` atau subfolder khusus yang nanti disetujui.
- Gunakan nama file konsisten, huruf kecil, dan deskriptif.

## Urutan Screenshot Sesuai Alur BAB IV

| Urutan | Nama File Disarankan | Halaman/Modul | Tujuan dalam Skripsi | Usulan Caption |
| --- | --- | --- | --- | --- |
| 1 | `gambar-iv-01-login.png` | Login | Menunjukkan halaman autentikasi pengguna | Gambar IV.1 Tampilan Halaman Login |
| 2 | `gambar-iv-02-dashboard.png` | Dashboard | Menunjukkan ringkasan data, grafik, dan monitoring awal | Gambar IV.2 Tampilan Dashboard |
| 3 | `gambar-iv-03-menu-utama.png` | Layout/menu utama | Menunjukkan navigasi modul aplikasi | Gambar IV.3 Tampilan Menu Utama Aplikasi |
| 4 | `gambar-iv-04-pengguna.png` | Manajemen pengguna | Menunjukkan fitur pengelolaan pengguna oleh admin | Gambar IV.4 Tampilan Halaman Data Pengguna |
| 5 | `gambar-iv-05-daftar-aset.png` | Daftar aset | Menunjukkan data inventaris aset | Gambar IV.5 Tampilan Halaman Inventaris Aset |
| 6 | `gambar-iv-06-form-aset.png` | Form aset | Menunjukkan input data aset | Gambar IV.6 Tampilan Form Data Aset |
| 7 | `gambar-iv-07-detail-aset.png` | Detail aset | Menunjukkan detail data aset | Gambar IV.7 Tampilan Detail Aset |
| 8 | `gambar-iv-08-transaksi-aset.png` | Daftar transaksi aset | Menunjukkan daftar transaksi/peminjaman aset | Gambar IV.8 Tampilan Halaman Transaksi Aset |
| 9 | `gambar-iv-09-form-transaksi-aset.png` | Form transaksi aset | Menunjukkan input peminjaman aset multi-item | Gambar IV.9 Tampilan Form Transaksi Aset |
| 10 | `gambar-iv-10-pengembalian-aset.png` | Detail/pengembalian aset | Menunjukkan proses pengembalian aset | Gambar IV.10 Tampilan Pengembalian Aset |
| 11 | `gambar-iv-11-surat-masuk.png` | Daftar surat masuk | Menunjukkan pencatatan surat masuk | Gambar IV.11 Tampilan Halaman Surat Masuk |
| 12 | `gambar-iv-12-form-surat-masuk.png` | Form surat masuk | Menunjukkan input surat masuk dan lampiran | Gambar IV.12 Tampilan Form Surat Masuk |
| 13 | `gambar-iv-13-detail-surat-masuk.png` | Detail surat masuk | Menunjukkan detail surat masuk | Gambar IV.13 Tampilan Detail Surat Masuk |
| 14 | `gambar-iv-14-disposisi-surat.png` | Disposisi dari detail surat | Menunjukkan proses pembuatan disposisi | Gambar IV.14 Tampilan Form Disposisi Surat |
| 15 | `gambar-iv-15-daftar-disposisi.png` | Daftar disposisi | Menunjukkan monitoring disposisi | Gambar IV.15 Tampilan Halaman Disposisi |
| 16 | `gambar-iv-16-surat-keluar.png` | Daftar surat keluar | Menunjukkan pencatatan surat keluar | Gambar IV.16 Tampilan Halaman Surat Keluar |
| 17 | `gambar-iv-17-form-surat-keluar.png` | Form surat keluar | Menunjukkan input surat keluar | Gambar IV.17 Tampilan Form Surat Keluar |
| 18 | `gambar-iv-18-detail-surat-keluar.png` | Detail surat keluar | Menunjukkan detail dan status pengiriman surat keluar | Gambar IV.18 Tampilan Detail Surat Keluar |
| 19 | `gambar-iv-19-laporan.png` | Laporan | Menunjukkan pilihan dan filter laporan | Gambar IV.19 Tampilan Halaman Laporan |
| 20 | `gambar-iv-20-cetak-laporan.png` | Cetak laporan | Menunjukkan output cetak laporan | Gambar IV.20 Tampilan Cetak Laporan |
| 21 | `gambar-iv-21-backup.png` | Backup | Menunjukkan fitur backup database admin | Gambar IV.21 Tampilan Halaman Backup Database |
| 22 | Tidak digunakan sebagai screenshot UI operasional | ERD Database | ERD tidak lagi tampil sebagai menu aplikasi; gunakan diagram ERD terpisah untuk skripsi | Tidak digunakan |

## Screenshot Wajib untuk BAB IV

Screenshot minimal yang sebaiknya ada:

- Login.
- Dashboard.
- Daftar aset.
- Form aset.
- Daftar transaksi aset.
- Form transaksi aset.
- Pengembalian aset.
- Daftar surat masuk.
- Form surat masuk.
- Detail surat masuk/disposisi.
- Daftar disposisi.
- Daftar surat keluar.
- Form surat keluar.
- Laporan.
- Backup.

## Screenshot Tambahan Jika Ruang Dokumen Cukup

- Manajemen pengguna.
- Detail aset.
- Detail transaksi aset.
- Detail surat keluar.
- Cetak laporan.
- Tampilan menu berdasarkan role berbeda.

## Modul yang Harus Diambil

- Autentikasi.
- Dashboard.
- Pengguna.
- Inventaris aset.
- Transaksi/peminjaman aset.
- Surat masuk.
- Disposisi.
- Surat keluar.
- Laporan.
- Backup.

## Catatan Screenshot yang Belum Bisa Diambil

- Screenshot final dashboard/sidebar setelah change request menu ERD belum dibuat ulang.
- Halaman publik login dan halaman internal sudah pernah diverifikasi pada environment lokal.
- Gunakan data dummy/aman agar tidak menampilkan dokumen atau data operasional sensitif.

## Sumber Data

- `APPLICATION_VERIFICATION.md`
- `APLIKASI_FEATURE_AUDIT.md`
- `app/Views/*`
- `app/Config/Routes.php`
- `app/Controllers/*.php`

## Pembaruan Screenshot Setelah Pengujian CRUD

Tanggal pembaruan: 2026-07-04

Screenshot PNG yang sudah tersedia:

| File | Isi Bukti |
| --- | --- |
| `01-login.png` | Halaman login tanpa petunjuk credential |
| `02-dashboard-admin.png` | Dashboard admin |
| `03-data-aset.png` | Daftar aset |
| `04-tambah-aset.png` | Form tambah aset |
| `05-surat-masuk.png` | Daftar surat masuk |
| `06-disposisi-surat.png` | Daftar disposisi |
| `07-surat-keluar.png` | Daftar surat keluar |
| `08-laporan.png` | Halaman laporan |
| `09-backup.png` | Halaman backup |
| `10-erd-database.png` | Arsip screenshot lama halaman ERD database; tidak dipakai sebagai screenshot UI operasional setelah change request |
| `11-tambah-data-aset.png` | Bukti aset dummy tampil di daftar/filter |
| `12-edit-data-aset.png` | Form edit aset dummy |
| `13-detail-data-aset.png` | Detail aset dummy |
| `14-transaksi-aset.png` | Detail transaksi aset dummy |
| `15-upload-surat-masuk.png` | Detail surat masuk dummy dengan lampiran |
| `16-form-disposisi.png` | Detail surat masuk/disposisi |
| `17-detail-disposisi.png` | Monitoring disposisi dummy |
| `18-surat-keluar.png` | Detail surat keluar dummy |
| `20-hasil-upload-lampiran.png` | Bukti detail surat masuk/lampiran dummy |

Bukti tambahan non-PNG:

- `19-cetak-pdf-transaksi.pdf`: file PDF hasil download transaksi aset dummy.

Catatan:

- Screenshot PDF transaksi dalam bentuk PNG tidak dibuat karena renderer PDF lokal tidak dapat membaca PDF sederhana yang dihasilkan library aplikasi.
- File `19-cetak-pdf-transaksi.pdf` tetap menjadi bukti bahwa route PDF merespons dan file dapat diunduh.

## Pembaruan Setelah Change Request Menu ERD

Tanggal pembaruan: 2026-07-04

- Screenshot ERD tidak lagi menjadi kebutuhan BAB IV bagian user interface karena menu `ERD Database` sudah disembunyikan dari navigasi aplikasi.
- ERD tetap dibutuhkan sebagai diagram skripsi, tetapi sebaiknya dibuat sebagai artefak diagram terpisah berdasarkan `ErdController.php`, migration, SQL, dan audit database.
- Screenshot menu/dashboard terbaru sebaiknya diambil ulang bila dokumen final memerlukan bukti bahwa sidebar aplikasi operasional tidak menampilkan ERD.
- File `10-erd-database.png` dipertahankan sebagai arsip bukti sebelum change request, bukan bahan utama UI final.

## Pembaruan Screenshot Final Sidebar

Tanggal pembaruan: 2026-07-04

Screenshot final setelah menu ERD disembunyikan:

- `21-dashboard-final-tanpa-erd.png`: dashboard final tanpa menu `ERD Database`.
- `22-sidebar-final-admin.png`: sidebar admin final tanpa menu `ERD Database`.

Hasil verifikasi: teks/menu `ERD Database` tidak terdeteksi pada dashboard setelah login lokal. Detail credential, cookie, token, dan session tidak dicatat.
