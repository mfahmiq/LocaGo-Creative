# DIAGRAM_INDEX

Tanggal dibuat: 2026-07-04
Tujuan: indeks sumber diagram prioritas untuk kebutuhan BAB III dan BAB IV.

## Catatan Umum

- Semua diagram dibuat sebagai source Mermaid di `skripsi/04-diagram-dan-gambar/diagram-source/`.
- Output gambar, jika berhasil dirender, disimpan di `skripsi/04-diagram-dan-gambar/diagram-output/`.
- Diagram berbasis fitur yang benar-benar ditemukan pada route, controller, model, view, migration, SQL, dan audit aplikasi.
- ERD tidak diposisikan sebagai menu operasional aplikasi final. ERD dipakai sebagai diagram rancangan/database untuk skripsi.
- Bagian deployment internet/intranet belum dapat dipastikan; deployment diagram saat ini memakai konteks lokal/Laragon.

## Daftar Diagram

| No | File Source | Tujuan Diagram | Sumber Data | Penempatan | Usulan Caption | Status Source | Status Output |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | `diagram-source/use-case-diagram.mmd` | Menjelaskan aktor dan use case utama aplikasi | `Routes.php`, `APLIKASI_FEATURE_AUDIT.md`, role helper | BAB III | Gambar III.1 Use Case Diagram Sistem | dibuat | `diagram-output/use-case-diagram.svg` |
| 2 | `diagram-source/activity-login.mmd` | Menjelaskan alur autentikasi pengguna | `AuthController.php`, `UserModel.php`, `AuthFilter.php` | BAB III | Gambar III.2 Activity Diagram Login | dibuat | `diagram-output/activity-login.svg` |
| 3 | `diagram-source/activity-inventaris-aset.mmd` | Menjelaskan alur pengelolaan inventaris aset | `AssetsController.php`, `AssetModel.php`, view aset | BAB III | Gambar III.3 Activity Diagram Inventaris Aset | dibuat | `diagram-output/activity-inventaris-aset.svg` |
| 4 | `diagram-source/activity-surat-masuk-disposisi.mmd` | Menjelaskan alur surat masuk sampai disposisi | `IncomingLettersController.php`, `DispositionsController.php`, model terkait | BAB III | Gambar III.4 Activity Diagram Surat Masuk dan Disposisi | dibuat | `diagram-output/activity-surat-masuk-disposisi.svg` |
| 5 | `diagram-source/sequence-login.mmd` | Menjelaskan interaksi login antara user, controller, model, dan session | `AuthController.php`, `UserModel.php` | BAB IV | Gambar IV.1 Sequence Diagram Login | dibuat | `diagram-output/sequence-login.svg` |
| 6 | `diagram-source/sequence-transaksi-aset.mmd` | Menjelaskan interaksi transaksi/peminjaman aset | `AssetTransactionsController.php`, model transaksi, `AssetModel.php` | BAB IV | Gambar IV.2 Sequence Diagram Transaksi Aset | dibuat | `diagram-output/sequence-transaksi-aset.svg` |
| 7 | `diagram-source/sequence-disposisi-surat.mmd` | Menjelaskan interaksi pembuatan disposisi surat | `IncomingLettersController.php`, `DispositionModel.php`, `IncomingLetterModel.php` | BAB IV | Gambar IV.3 Sequence Diagram Disposisi Surat | dibuat | `diagram-output/sequence-disposisi-surat.svg` |
| 8 | `diagram-source/class-diagram.mmd` | Menjelaskan class controller, model, library, trait, dan relasi entitas utama | `app/Controllers`, `app/Models`, `app/Libraries`, `app/Traits` | BAB IV | Gambar IV.4 Class Diagram Aplikasi | dibuat | `diagram-output/class-diagram.svg` |
| 9 | `diagram-source/erd-final.mmd` | Menjelaskan relasi tabel database final untuk skripsi | migration, SQL, `ErdController.php`, `DATABASE_ERD_AUDIT.md` | BAB IV | Gambar IV.5 Entity Relationship Diagram | dibuat | `diagram-output/erd-final.svg` |
| 10 | `diagram-source/deployment-diagram.mmd` | Menjelaskan arsitektur deployment lokal/web | README, Composer, Laragon, verifikasi aplikasi | BAB IV | Gambar IV.6 Deployment Diagram Aplikasi | dibuat | `diagram-output/deployment-diagram.svg` |
| 11 | `diagram-source/arsitektur-mvc.mmd` | Menjelaskan alur MVC CodeIgniter 4 | `Routes.php`, controller, model, view, filter, library, trait | BAB IV | Gambar IV.7 Arsitektur MVC CodeIgniter 4 | dibuat | `diagram-output/arsitektur-mvc.svg` |
| 12 | `LRS_DRAFT.md` | Menyajikan Logical Record Structure per tabel bisnis | migration, SQL, `DATABASE_ERD_AUDIT.md` | BAB IV | Tabel IV.x Logical Record Structure | dibuat | tidak perlu render |
| 13 | `diagram-source/activity-transaksi-aset.mmd` | Menjelaskan alur transaksi/peminjaman aset sampai PDF/pengembalian | `AssetTransactionsController.php`, model transaksi, view transaksi | BAB III/BAB IV | Gambar III.5 Activity Diagram Transaksi Aset | dibuat | `diagram-output/activity-transaksi-aset.svg` |
| 14 | `diagram-source/activity-surat-keluar.mmd` | Menjelaskan alur surat keluar dan status pengiriman | `OutgoingLettersController.php`, `OutgoingLetterModel.php`, view surat keluar | BAB III/BAB IV | Gambar III.6 Activity Diagram Surat Keluar | dibuat | `diagram-output/activity-surat-keluar.svg` |
| 15 | `diagram-source/scrum-flow.mmd` | Menjelaskan alur Agile Scrum sebagai mapping dokumentasi berbasis fitur | `SCRUM_MAPPING_AUDIT.md`, outline 156, hasil testing | BAB I/BAB IV | Gambar IV.8 Alur Pengembangan Agile Scrum | dibuat | `diagram-output/scrum-flow.svg` |

## Catatan Diagram

- Activity Diagram Transaksi Aset, Activity Diagram Surat Keluar, dan Diagram Scrum Flow sudah dibuat pada quality gate 2026-07-04 karena relevan untuk BAB III/BAB IV.
- Diagram publikasi internet/intranet belum dapat dipastikan karena status deployment final belum ditemukan.

## Quality Review

- `DIAGRAM_QUALITY_REVIEW.md` sudah dibuat sebagai quality gate diagram.
- Diagram yang paling siap langsung dipakai: activity login, sequence login, sequence disposisi, deployment, arsitektur MVC, dan Scrum flow.
- Diagram yang perlu perhatian layout: ERD, class diagram, use case, dan activity diagram yang panjang.

## Screenshot Final Sidebar

Screenshot final setelah change request menu ERD:

- `screenshots/21-dashboard-final-tanpa-erd.png`
- `screenshots/22-sidebar-final-admin.png`

Hasil verifikasi: teks/menu `ERD Database` tidak terdeteksi pada dashboard setelah login lokal.

## Instruksi Render Manual

Jika Mermaid CLI tersedia, render dapat dilakukan dari root project:

```powershell
npx -y @mermaid-js/mermaid-cli -i skripsi/04-diagram-dan-gambar/diagram-source/use-case-diagram.mmd -o skripsi/04-diagram-dan-gambar/diagram-output/use-case-diagram.png
```

Ulangi perintah dengan nama file source lain. Jika PNG terlalu kecil atau teks kurang jelas, gunakan output SVG:

```powershell
npx -y @mermaid-js/mermaid-cli -i skripsi/04-diagram-dan-gambar/diagram-source/erd-final.mmd -o skripsi/04-diagram-dan-gambar/diagram-output/erd-final.svg
```
