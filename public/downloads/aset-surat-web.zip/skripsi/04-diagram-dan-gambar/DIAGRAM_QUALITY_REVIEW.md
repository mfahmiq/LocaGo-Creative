# DIAGRAM_QUALITY_REVIEW

Tanggal review: 2026-07-04
Tujuan: quality gate diagram sebelum drafting BAB III dan BAB IV.

## Dasar Review

Review dilakukan terhadap file SVG di `skripsi/04-diagram-dan-gambar/diagram-output/` dan source Mermaid di `skripsi/04-diagram-dan-gambar/diagram-source/`.

Sumber kesesuaian:

- `APLIKASI_FEATURE_AUDIT.md`
- `DATABASE_ERD_AUDIT.md`
- `SCRUM_MAPPING_AUDIT.md`
- `DIAGRAM_INDEX.md`
- `LRS_DRAFT.md`
- `app/Config/Routes.php`
- `app/Controllers/*.php`
- `app/Models/*.php`
- `app/Database/Migrations/*.php`

## Ringkasan Status Diagram SVG

| No | Diagram SVG | Keterbacaan | Kepadatan | Kesesuaian Aplikasi | Penempatan | Caption | Status Review |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | `use-case-diagram.svg` | Cukup terbaca | Tinggi secara vertikal | Sesuai aktor admin, operator, pimpinan dan modul operasional | BAB III | Gambar III.1 Use Case Diagram Sistem | Layak, lebih baik dipakai ukuran besar |
| 2 | `activity-login.svg` | Terbaca | Sedang | Sesuai `AuthController`, `UserModel`, session, dan dashboard | BAB III | Gambar III.2 Activity Diagram Login | Layak dipakai langsung |
| 3 | `activity-inventaris-aset.svg` | Cukup terbaca | Tinggi | Sesuai alur aset, upload foto, validasi, role admin/operator | BAB III | Gambar III.3 Activity Diagram Inventaris Aset | Layak, perlu ukuran besar/landscape |
| 4 | `activity-surat-masuk-disposisi.svg` | Cukup terbaca | Sangat tinggi | Sesuai surat masuk, lampiran, disposisi, status surat | BAB III | Gambar III.4 Activity Diagram Surat Masuk dan Disposisi | Layak, disarankan dirapikan/split bila terlalu panjang |
| 5 | `sequence-login.svg` | Terbaca | Sedang | Sesuai proses login aplikasi | BAB IV | Gambar IV.1 Sequence Diagram Login | Layak dipakai langsung |
| 6 | `sequence-transaksi-aset.svg` | Terbaca | Sedang | Sesuai transaksi multi-item, PDF, dan pengembalian | BAB IV | Gambar IV.2 Sequence Diagram Transaksi Aset | Layak, gunakan ukuran lebar |
| 7 | `sequence-disposisi-surat.svg` | Terbaca | Sedang | Sesuai pembuatan disposisi dan update status surat masuk | BAB IV | Gambar IV.3 Sequence Diagram Disposisi Surat | Layak dipakai langsung |
| 8 | `class-diagram.svg` | Cukup terbaca | Tinggi/lebar | Sesuai controller, model, library, trait, dan relasi utama | BAB IV | Gambar IV.4 Class Diagram Aplikasi | Perlu dirapikan atau ditempatkan landscape/lampiran |
| 9 | `erd-final.svg` | Cukup terbaca | Tinggi/lebar | Sesuai tabel dan relasi dari migration, SQL, dan ERD controller | BAB IV | Gambar IV.5 Entity Relationship Diagram | Layak sebagai SVG besar; perlu cek visual sebelum DOCX final |
| 10 | `deployment-diagram.svg` | Terbaca | Ringkas | Sesuai environment lokal/Laragon; publikasi internet belum pasti | BAB IV | Gambar IV.6 Deployment Diagram Aplikasi | Layak dipakai langsung |
| 11 | `arsitektur-mvc.svg` | Terbaca | Sedang/lebar | Sesuai arsitektur CodeIgniter 4 MVC | BAB IV | Gambar IV.7 Arsitektur MVC CodeIgniter 4 | Layak dipakai langsung |
| 12 | `activity-transaksi-aset.svg` | Cukup terbaca | Tinggi | Sesuai transaksi aset, validasi item, PDF, dan pengembalian | BAB III/BAB IV | Gambar III.5 Activity Diagram Transaksi Aset | Layak, gunakan ukuran besar/landscape |
| 13 | `activity-surat-keluar.svg` | Cukup terbaca | Tinggi | Sesuai surat keluar, lampiran, dan validasi status diterima tujuan | BAB III/BAB IV | Gambar III.6 Activity Diagram Surat Keluar | Layak, gunakan ukuran besar/landscape |
| 14 | `scrum-flow.svg` | Terbaca | Lebar | Sesuai mapping Scrum sebagai dokumentasi berbasis fitur, bukan bukti historis penuh | BAB I/BAB IV | Gambar IV.8 Alur Pengembangan Agile Scrum | Layak dengan catatan narasi harus hati-hati |

## Kesesuaian Aktor, Entitas, Relasi, dan Alur

- Aktor pada Use Case Diagram sudah sesuai role aplikasi: Admin, Operator, dan Pimpinan.
- Modul operasional pada Use Case Diagram sudah mengikuti aplikasi final: login, pengguna, inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup.
- ERD tidak ditampilkan sebagai use case operasional karena menu ERD sudah disembunyikan dari aplikasi final.
- Entitas pada ERD sesuai LRS dan audit database: `users`, `asset_categories`, `asset_locations`, `assets`, `asset_transactions`, `asset_transaction_items`, `incoming_letters`, `dispositions`, dan `outgoing_letters`.
- Tabel `migrations` tidak dimasukkan ke ERD final karena merupakan tabel sistem CodeIgniter, bukan tabel bisnis utama.
- Activity dan sequence diagram sudah mengikuti controller/model yang ditemukan.
- Scrum flow layak sebagai diagram pendukung metode, tetapi tidak boleh ditulis sebagai riwayat sprint aktual tanpa bukti tambahan.

## Catatan Revisi

1. `activity-surat-masuk-disposisi.svg`, `activity-transaksi-aset.svg`, dan `activity-surat-keluar.svg` tinggi. Untuk DOCX final, gunakan ukuran besar, orientasi landscape, atau pecah menjadi dua diagram bila dosen meminta tampilan lebih ringkas.
2. `erd-final.svg` dan `class-diagram.svg` padat. Disarankan tetap memakai SVG, bukan PNG kecil, agar teks tidak pecah.
3. `scrum-flow.svg` lebar. Cocok ditempatkan sebagai gambar pendukung metode atau lampiran bila ruang BAB IV terbatas.
4. Caption masih berupa usulan. Nomor gambar final harus disesuaikan saat susunan BAB/DOCX sudah pasti.
5. Deployment diagram masih berbasis lokal/Laragon karena status publikasi internet/intranet belum dapat dipastikan.
6. Product backlog di `SCRUM_MAPPING_AUDIT.md` masih menyebut ERD sebagai PB-16. Untuk drafting, tulis ERD sebagai artefak dokumentasi/dev-only, bukan fitur operasional sekolah.

## Diagram Layak Dipakai Langsung

- `activity-login.svg`
- `sequence-login.svg`
- `sequence-disposisi-surat.svg`
- `deployment-diagram.svg`
- `arsitektur-mvc.svg`
- `scrum-flow.svg`, dengan catatan narasi Scrum tidak mengarang sejarah sprint.

## Diagram Layak Dengan Penyesuaian Layout

- `use-case-diagram.svg`
- `activity-inventaris-aset.svg`
- `activity-transaksi-aset.svg`
- `activity-surat-masuk-disposisi.svg`
- `activity-surat-keluar.svg`
- `sequence-transaksi-aset.svg`
- `class-diagram.svg`
- `erd-final.svg`

## Rekomendasi Sebelum Masuk DOCX

1. Gunakan SVG untuk diagram di DOCX bila tool dokumen mendukung; jika tidak, konversi ke PNG resolusi tinggi.
2. Gunakan orientasi landscape atau ukuran penuh halaman untuk ERD, class diagram, dan activity diagram yang panjang.
3. Pastikan nomor caption mengikuti urutan gambar final pada BAB III dan BAB IV.
4. Jangan memasukkan screenshot ERD sebagai UI aplikasi final; gunakan `erd-final.svg` sebagai desain database.

