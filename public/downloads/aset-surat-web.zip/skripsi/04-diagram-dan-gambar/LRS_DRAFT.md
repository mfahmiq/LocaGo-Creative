# LRS_DRAFT

Tanggal dibuat: 2026-07-04
Tujuan: draft Logical Record Structure untuk BAB IV bagian desain database.

## Catatan

- LRS disusun berdasarkan migration, SQL dump, `ErdController.php`, dan `DATABASE_ERD_AUDIT.md`.
- Tabel `migrations` adalah tabel sistem CodeIgniter dan tidak dimasukkan sebagai LRS bisnis utama.
- Tidak ditemukan tabel khusus backup, log aktivitas, atau laporan. Fitur backup membaca seluruh tabel database, sedangkan laporan mengambil data dari tabel modul bisnis.

## users

| No | Nama Field | Tipe Data | Key | Keterangan |
| --- | --- | --- | --- | --- |
| 1 | id | INT(11) UNSIGNED | PK | Identitas unik pengguna |
| 2 | name | VARCHAR(120) |  | Nama lengkap pengguna |
| 3 | username | VARCHAR(80) | UQ | Username login unik |
| 4 | password_hash | VARCHAR(255) |  | Hash password, bukan password asli |
| 5 | role | VARCHAR(30) |  | Hak akses: admin, operator, pimpinan |
| 6 | is_active | TINYINT(1) |  | Status aktif akun |
| 7 | last_login_at | DATETIME |  | Waktu login terakhir |
| 8 | created_at | DATETIME |  | Waktu data dibuat |
| 9 | updated_at | DATETIME |  | Waktu data diperbarui |

## asset_categories

| No | Nama Field | Tipe Data | Key | Keterangan |
| --- | --- | --- | --- | --- |
| 1 | id | INT(11) UNSIGNED | PK | Identitas kategori aset |
| 2 | name | VARCHAR(120) | UQ | Nama kategori aset |
| 3 | description | TEXT |  | Keterangan kategori |
| 4 | created_at | DATETIME |  | Waktu data dibuat |
| 5 | updated_at | DATETIME |  | Waktu data diperbarui |

## asset_locations

| No | Nama Field | Tipe Data | Key | Keterangan |
| --- | --- | --- | --- | --- |
| 1 | id | INT(11) UNSIGNED | PK | Identitas lokasi aset |
| 2 | name | VARCHAR(120) | UQ | Nama lokasi atau ruangan |
| 3 | description | TEXT |  | Keterangan lokasi |
| 4 | created_at | DATETIME |  | Waktu data dibuat |
| 5 | updated_at | DATETIME |  | Waktu data diperbarui |

## assets

| No | Nama Field | Tipe Data | Key | Keterangan |
| --- | --- | --- | --- | --- |
| 1 | id | INT(11) UNSIGNED | PK | Identitas aset |
| 2 | code | VARCHAR(80) | UQ | Kode aset unik |
| 3 | name | VARCHAR(160) |  | Nama aset |
| 4 | category_id | INT UNSIGNED | FK | Relasi ke `asset_categories.id` |
| 5 | location_id | INT UNSIGNED | FK | Relasi ke `asset_locations.id` |
| 6 | quantity | INT(11) |  | Jumlah unit aset |
| 7 | condition_status | VARCHAR(40) | IDX | Kondisi aset |
| 8 | acquisition_year | INT(4) |  | Tahun perolehan |
| 9 | funding_source | VARCHAR(120) |  | Sumber dana |
| 10 | value | DECIMAL(14,2) |  | Nilai aset |
| 11 | custodian | VARCHAR(120) |  | Penanggung jawab |
| 12 | photo | VARCHAR(255) |  | Path foto aset |
| 13 | notes | TEXT |  | Catatan aset |
| 14 | created_at | DATETIME |  | Waktu data dibuat |
| 15 | updated_at | DATETIME |  | Waktu data diperbarui |

## asset_transactions

| No | Nama Field | Tipe Data | Key | Keterangan |
| --- | --- | --- | --- | --- |
| 1 | id | INT(11) UNSIGNED | PK | Identitas transaksi aset |
| 2 | transaction_code | VARCHAR(80) | UQ | Kode transaksi unik |
| 3 | borrower_unit | VARCHAR(160) |  | Unit peminjam |
| 4 | borrower_name | VARCHAR(160) |  | Nama peminjam |
| 5 | purpose | TEXT |  | Tujuan peminjaman |
| 6 | loan_date | DATE | IDX | Tanggal pinjam |
| 7 | expected_return_date | DATE |  | Target tanggal kembali |
| 8 | actual_return_date | DATE |  | Tanggal kembali aktual |
| 9 | status | VARCHAR(50) | IDX | Status transaksi |
| 10 | notes | TEXT |  | Catatan transaksi |
| 11 | created_by | INT UNSIGNED | FK | Relasi ke `users.id` |
| 12 | created_at | DATETIME |  | Waktu data dibuat |
| 13 | updated_at | DATETIME |  | Waktu data diperbarui |

## asset_transaction_items

| No | Nama Field | Tipe Data | Key | Keterangan |
| --- | --- | --- | --- | --- |
| 1 | id | INT(11) UNSIGNED | PK | Identitas item transaksi |
| 2 | asset_transaction_id | INT UNSIGNED | FK | Relasi ke `asset_transactions.id` |
| 3 | asset_id | INT UNSIGNED | FK | Relasi ke `assets.id` |
| 4 | quantity | INT(11) |  | Jumlah aset dipinjam |
| 5 | condition_before | VARCHAR(50) |  | Kondisi sebelum dipinjam |
| 6 | condition_after | VARCHAR(50) |  | Kondisi setelah kembali |
| 7 | notes | TEXT |  | Catatan item |
| 8 | created_at | DATETIME |  | Waktu data dibuat |
| 9 | updated_at | DATETIME |  | Waktu data diperbarui |

## incoming_letters

| No | Nama Field | Tipe Data | Key | Keterangan |
| --- | --- | --- | --- | --- |
| 1 | id | INT(11) UNSIGNED | PK | Identitas surat masuk |
| 2 | letter_number | VARCHAR(120) |  | Nomor surat |
| 3 | letter_date | DATE |  | Tanggal surat |
| 4 | received_date | DATE | IDX | Tanggal diterima |
| 5 | sender | VARCHAR(160) |  | Pengirim surat |
| 6 | subject | VARCHAR(200) |  | Perihal surat |
| 7 | priority | VARCHAR(50) |  | Prioritas surat |
| 8 | summary | TEXT |  | Ringkasan isi surat |
| 9 | attachment | VARCHAR(255) |  | Path lampiran |
| 10 | status | VARCHAR(50) | IDX | Status proses surat |
| 11 | created_by | INT UNSIGNED | FK | Relasi ke `users.id` |
| 12 | created_at | DATETIME |  | Waktu data dibuat |
| 13 | updated_at | DATETIME |  | Waktu data diperbarui |

## dispositions

| No | Nama Field | Tipe Data | Key | Keterangan |
| --- | --- | --- | --- | --- |
| 1 | id | INT(11) UNSIGNED | PK | Identitas disposisi |
| 2 | incoming_letter_id | INT UNSIGNED | FK | Relasi ke `incoming_letters.id` |
| 3 | target_unit | VARCHAR(160) |  | Unit tujuan disposisi |
| 4 | instruction | TEXT |  | Instruksi disposisi |
| 5 | due_date | DATE |  | Batas tindak lanjut |
| 6 | status | VARCHAR(50) | IDX | Status disposisi |
| 7 | disposed_by | INT UNSIGNED | FK | Relasi ke `users.id` |
| 8 | created_at | DATETIME |  | Waktu data dibuat |
| 9 | updated_at | DATETIME |  | Waktu data diperbarui |

## outgoing_letters

| No | Nama Field | Tipe Data | Key | Keterangan |
| --- | --- | --- | --- | --- |
| 1 | id | INT(11) UNSIGNED | PK | Identitas surat keluar |
| 2 | letter_number | VARCHAR(120) |  | Nomor surat |
| 3 | letter_date | DATE | IDX | Tanggal surat |
| 4 | recipient | VARCHAR(160) |  | Penerima surat |
| 5 | destination_unit | VARCHAR(160) |  | Unit tujuan |
| 6 | subject | VARCHAR(200) |  | Perihal surat |
| 7 | attachment | VARCHAR(255) |  | Path lampiran |
| 8 | status | VARCHAR(50) | IDX | Status pengiriman |
| 9 | receiver_name | VARCHAR(120) |  | Nama penerima di tujuan |
| 10 | received_date | DATE |  | Tanggal diterima tujuan |
| 11 | delivery_notes | TEXT |  | Catatan pengiriman |
| 12 | created_by | INT UNSIGNED | FK | Relasi ke `users.id` |
| 13 | created_at | DATETIME |  | Waktu data dibuat |
| 14 | updated_at | DATETIME |  | Waktu data diperbarui |

## Catatan Backup, Log, dan Laporan

| Komponen | Status Tabel | Keterangan |
| --- | --- | --- |
| Backup | Tidak ada tabel khusus | Fitur backup membaca metadata/tabel database dan menghasilkan dump SQL |
| Log aktivitas | Belum ditemukan tabel khusus | Belum dapat dipastikan adanya audit trail aplikasi |
| Laporan | Tidak ada tabel khusus | Laporan mengambil data dari tabel aset, surat, disposisi, dan transaksi |

