# OCR dan Render Pedoman/Outline

Tanggal: 2026-07-04
Status: render selesai, OCR teks otomatis belum tersedia

## Sumber Asli

File asli tidak diubah:

1. `skripsi/pedoman.pdf`
2. `skripsi/outline.pdf`

## Hasil Render

Render dibuat sebagai file PNG baru:

1. `skripsi/01-pedoman-dan-outline/render-pedoman/`
   - Jumlah halaman render: 18 PNG.
   - Pola nama file: `pedoman-page-01.png` sampai `pedoman-page-18.png`.
2. `skripsi/01-pedoman-dan-outline/render-outline/`
   - Jumlah halaman render: 9 PNG.
   - Pola nama file: `outline-page-1.png` sampai `outline-page-9.png`.

Render menggunakan Poppler `pdftoppm` pada resolusi 150 DPI.

## Status OCR

Ekstraksi teks biasa dari PDF belum menghasilkan teks untuk `pedoman.pdf` dan `outline.pdf`.

OCR otomatis belum dijalankan karena OCR engine lokal belum tersedia pada audit ini:

1. `tesseract` tidak ditemukan di PATH.
2. `ocrmypdf` tidak ditemukan.
3. Paket Python OCR seperti `pytesseract`, `easyocr`, dan `paddleocr` tidak tersedia.

Paket `PIL` tersedia, tetapi hanya cukup untuk membaca/memproses gambar, bukan OCR teks.

## Review Visual Awal

Halaman render sampel berhasil dibuka dan terbaca secara visual:

1. `render-pedoman/pedoman-page-01.png`
2. `render-outline/outline-page-1.png`

Catatan visual awal:

1. Render pedoman halaman pertama yang diperiksa menampilkan bagian teknik penulisan, termasuk format pengetikan.
2. Render outline halaman pertama yang diperiksa menampilkan outline Program Studi Teknologi Informasi Program Sarjana, termasuk kode outline 156.

Catatan ini belum dianggap sebagai ringkasan aturan final. Seluruh halaman perlu direview/OCR lebih lanjut sebelum aturan format kampus dan struktur bab disimpulkan.

## Bagian Yang Perlu Dicek Manual

Karena OCR belum tersedia, seluruh halaman render perlu dicek manual atau diproses dengan OCR pada sesi berikutnya:

1. Semua 18 halaman `pedoman.pdf`.
2. Semua 9 halaman `outline.pdf`.
3. Bagian format pengetikan, halaman judul, penomoran halaman, heading, caption, daftar isi, daftar gambar, daftar tabel, daftar lampiran, sitasi, daftar pustaka, dan lampiran.
4. Bagian outline 156 yang menentukan struktur BAB I sampai BAB V.

## Rekomendasi Lanjutan

1. Gunakan render PNG untuk review manual cepat.
2. Jika tersedia, pasang atau gunakan OCR engine lokal untuk membuat teks hasil OCR.
3. Setelah OCR/review cukup jelas, buat ringkasan aturan pedoman dan outline sebagai file kerja baru.
4. Jangan menyusun draft BAB atau `SKRIPSI.docx` sebelum ringkasan aturan pedoman/outline selesai diverifikasi.
