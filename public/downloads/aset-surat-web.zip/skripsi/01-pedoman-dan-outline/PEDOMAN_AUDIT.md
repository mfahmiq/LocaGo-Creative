# PEDOMAN_AUDIT.md

Tanggal audit: 2026-07-04
Metode audit: review visual render PNG, tanpa OCR otomatis
Sumber asli: `skripsi/pedoman.pdf`
Render sumber: `skripsi/01-pedoman-dan-outline/render-pedoman/`

## Identitas Dokumen Pedoman

Dokumen yang diaudit adalah `pedoman.pdf`. Berdasarkan audit metadata sebelumnya, dokumen ini berjudul `Pedoman Laporan Skripsi TA Universitas BSI Periode 2025 (1).pdf`, berjumlah 18 halaman PDF, dan sudah dirender menjadi 18 PNG.

Catatan penting:

1. Ekstraksi teks biasa tidak menghasilkan teks.
2. OCR otomatis belum tersedia.
3. Audit ini hanya berdasarkan review visual terhadap render PNG.
4. PDF asli tidak diubah.

## Cakupan Render Yang Direview

Render yang direview:

1. `render-pedoman/pedoman-page-01.png` sampai `render-pedoman/pedoman-page-18.png`.
2. Footer dokumen pada render memperlihatkan halaman internal pedoman dari `Hal. 4` sampai `Hal. 21`.

## Aturan Ukuran Kertas

Aturan yang terlihat:

1. Skripsi/Tugas Akhir menggunakan kertas ukuran A4.

Sumber:

1. `render-pedoman/pedoman-page-01.png`

## Margin

Aturan yang terlihat:

1. Margin atas: 3 cm.
2. Margin kiri: 4 cm.
3. Margin bawah: 2,5 cm.
4. Margin kanan: 2,5 cm.

Sumber:

1. `render-pedoman/pedoman-page-01.png`
2. `render-pedoman/pedoman-page-06.png`
3. `render-pedoman/pedoman-page-08.png`
4. `render-pedoman/pedoman-page-09.png`

## Font Dan Ukuran Font

Aturan yang terlihat:

1. Jenis huruf menggunakan Times New Roman.
2. Ukuran font isi tulisan adalah 12.
3. Isi tabel dan gambar dapat disesuaikan.
4. Nomor dan judul bab ditulis di tengah, huruf besar, ukuran 14, tebal.
5. Judul subbab dan sub-subbab dimulai dengan huruf besar, ukuran 12, tebal.
6. Pada halaman judul, judul skripsi/tugas akhir diketik kapital ukuran 14.
7. Pada halaman judul, kata `SKRIPSI` atau `TUGAS AKHIR` ditulis ukuran 18.
8. Pada halaman judul, kalimat `Diajukan ...` ditulis ukuran 12.
9. Pada halaman judul, nama penulis dan NIM ditulis ukuran 14.
10. Nama program studi, fakultas, universitas, kota, dan tahun ditulis ukuran 12.

Sumber:

1. `render-pedoman/pedoman-page-01.png`
2. `render-pedoman/pedoman-page-05.png`

## Spasi

Aturan yang terlihat:

1. Isi tulisan skripsi/tugas akhir menggunakan jarak 2 spasi.
2. Isi tabel dan gambar disesuaikan.
3. Abstrak ditulis satu spasi dalam satu paragraf.
4. Kutipan langsung kurang dari 5 baris diketik dua spasi dan mengikuti paragraf yang diberi tanda kutip.
5. Kutipan langsung 5 baris atau lebih diketik satu spasi dengan paragraf lurus sesuai ketukan paragraf atau menggunakan tab dari tepi kiri dan tanpa tanda kutip.
6. Daftar pustaka diketik satu spasi untuk setiap pustaka, dengan jarak dua spasi antar pustaka.

Sumber:

1. `render-pedoman/pedoman-page-01.png`
2. `render-pedoman/pedoman-page-04.png`
3. `render-pedoman/pedoman-page-10.png`
4. `render-pedoman/pedoman-page-13.png`
5. `render-pedoman/pedoman-page-15.png`
6. `render-pedoman/pedoman-page-18.png`

## Aturan Paragraf Dan Indentasi

Aturan yang terlihat:

1. Penulisan poin dapat menggunakan angka dan huruf kecil sesuai hierarki.
2. Untuk sub-subbab yang tidak disebutkan di outline, penulisan mengikuti contoh penomoran yang ditampilkan.
3. Kutipan panjang 5 baris atau lebih menggunakan tab dari tepi kiri atau paragraf lurus sesuai ketukan paragraf.
4. Detail ukuran indentasi paragraf biasa belum dapat dipastikan dari render yang direview.

Sumber:

1. `render-pedoman/pedoman-page-05.png`
2. `render-pedoman/pedoman-page-06.png`
3. `render-pedoman/pedoman-page-10.png`
4. `render-pedoman/pedoman-page-13.png`

## Aturan Judul BAB Dan Subbab

Aturan yang terlihat:

1. Bab diberi nomor menggunakan angka Romawi.
2. Subbab diberi nomor menggunakan angka Latin mengacu pada nomor bab/subbab.
3. Contoh format subbab: `3.1`, `3.2`, `3.2.1`.
4. Nomor dan judul bab ditulis di tengah dengan huruf besar, ukuran 14, tebal.
5. Judul subbab dan sub-subbab dimulai dengan huruf besar, ukuran 12, tebal.
6. Jarak visual pada contoh menunjukkan jarak 2 spasi sebelum bab/subbab dan 4 spasi setelah judul bab, tetapi rincian ini terlihat dari diagram sehingga perlu dicek lagi saat pemformatan akhir.

Sumber:

1. `render-pedoman/pedoman-page-04.png`
2. `render-pedoman/pedoman-page-05.png`
3. `render-pedoman/pedoman-page-06.png`
4. `render-pedoman/pedoman-page-08.png`
5. `render-pedoman/pedoman-page-09.png`

## Aturan Penomoran Halaman

Aturan yang terlihat:

1. Bagian awal menggunakan angka Romawi huruf kecil, misalnya `i, ii, iii, iv`.
2. Nomor halaman bagian awal diletakkan di tengah bawah, 2 cm dari bawah.
3. Khusus lembar judul, nomor halaman tidak diketik tetapi tetap dihitung.
4. Bagian pokok menggunakan angka Latin.
5. Halaman pertama dari bab pertama adalah halaman nomor 1.
6. Nomor halaman pada setiap awal bab diletakkan di bawah tengah, 2 cm dari bawah.
7. Nomor halaman selain awal bab diletakkan di pojok kanan atas, 2 cm dari atas.
8. Bagian akhir menggunakan angka Latin sebagai kelanjutan dari bagian pokok dan diletakkan di bawah tengah, 2 cm dari bawah.

Sumber:

1. `render-pedoman/pedoman-page-08.png`
2. `render-pedoman/pedoman-page-09.png`

## Aturan Tabel

Aturan yang terlihat:

1. Judul tabel ditulis di sebelah atas tengah dari tabel.
2. Penomoran tabel mengikuti bab yang bersangkutan.
3. Contoh penomoran terlihat seperti `Tabel IV.4`, artinya tabel berada pada Bab IV.
4. Font isi tabel minimal 8 atau disesuaikan.
5. Sumber tabel diletakkan di bawah tabel jika ada.

Sumber:

1. `render-pedoman/pedoman-page-09.png`

## Aturan Gambar Dan Grafik

Aturan yang terlihat:

1. Judul gambar/grafik ditulis di bagian bawah tengah gambar.
2. Penomoran gambar/grafik mengikuti bab yang bersangkutan.
3. Contoh penomoran terlihat seperti `Gambar II.2`.
4. Sumber gambar diletakkan di bawah atau dekat gambar sesuai contoh.

Sumber:

1. `render-pedoman/pedoman-page-09.png`
2. `render-pedoman/pedoman-page-10.png`

## Aturan Daftar Isi

Belum dapat dipastikan dari render pedoman yang direview. Bagian daftar isi tidak terlihat secara langsung pada render `pedoman.pdf` yang tersedia.

Catatan:

1. Struktur daftar isi sebagai bagian awal terlihat pada dokumen outline, tetapi detail format daftar isi dari pedoman belum terlihat pada render pedoman.

Sumber:

1. Belum terlihat jelas pada `render-pedoman/`.

## Aturan Daftar Gambar

Belum dapat dipastikan dari render pedoman yang direview. Bagian daftar gambar tidak terlihat secara langsung pada render `pedoman.pdf` yang tersedia.

Sumber:

1. Belum terlihat jelas pada `render-pedoman/`.

## Aturan Daftar Tabel

Belum dapat dipastikan dari render pedoman yang direview. Bagian daftar tabel tidak terlihat secara langsung pada render `pedoman.pdf` yang tersedia.

Sumber:

1. Belum terlihat jelas pada `render-pedoman/`.

## Aturan Daftar Lampiran

Aturan yang terlihat:

1. Lampiran berisi data pendukung seperti gambar, tabel, analisis, dan lain-lain yang terlalu banyak sehingga tidak mungkin dimasukkan ke dalam bab sebelumnya.
2. Nomor halaman lampiran diletakkan di tengah bawah mengikuti isi halaman skripsi/tugas akhir.
3. Pada pojok kanan atas diberi nama lampiran sesuai kelompoknya.
4. Contoh kelompok lampiran: `Lampiran A1`, `A2`, `B1`, `B2`, dan seterusnya.

Belum dapat dipastikan:

1. Format daftar lampiran pada bagian awal belum terlihat langsung pada render pedoman.

Sumber:

1. `render-pedoman/pedoman-page-18.png`

## Aturan Abstrak

Aturan yang terlihat:

1. Abstrak ditulis dalam Bahasa Indonesia dan Bahasa Inggris.
2. Masing-masing abstrak berada pada halaman berbeda.
3. Isi teks abstrak menggunakan jarak baris satu spasi dalam satu paragraf.
4. Jumlah kata isi abstrak minimal 150 kata dan maksimal 200 kata.
5. Isi abstrak memuat:
   - Latar belakang.
   - Tujuan.
   - Metode yang digunakan.
   - Hasil.

Sumber:

1. `render-pedoman/pedoman-page-04.png`

## Aturan Daftar Pustaka Dan Sitasi

Aturan sitasi yang terlihat:

1. Sumber kutipan tidak boleh berasal dari Blogspot, Wordpress, atau Wikipedia.
2. Format pengutipan wajib menggunakan software Mendeley.
3. Style yang digunakan adalah APA 7.
4. Nama pengarang ditulis setelah kalimat yang dikutip dalam kurung, dengan format nama pengarang dan tahun terbit.
5. Laporan Skripsi mensitasi minimal 10 jurnal.
6. Referensi jurnal minimal 5 tahun terakhir.
7. Referensi buku minimal 10 tahun terakhir.
8. Referensi buku diutamakan karangan Dosen Universitas Bina Sarana Informatika yang tersedia di laman repository.
9. Kutipan tidak langsung tidak menggunakan tanda kutip, diintegrasikan dengan teks/paragraf, tidak diapit tanda kutip, dan tetap diikuti nama pengarang serta tahun.

Aturan daftar pustaka yang terlihat:

1. Nama pengarang ditulis mulai dari nama belakang/keluarga, diikuti koma, kemudian nama depan, kecuali nama Cina.
2. Semua pengarang yang dikutip wajib dimasukkan ke daftar pustaka secara lengkap.
3. Daftar pustaka diurutkan berdasarkan abjad.
4. Gelar pengarang tidak perlu dicantumkan.
5. Jika lebih dari dua pengarang, semua nama pengarang tetap ditulis; nama pengarang pertama saja yang dibalik; tidak perlu menggunakan `et al` atau `dkk`.
6. Jika nama pengarang yang sama digunakan lebih dari satu buku, nama pengarang tetap ditulis dan diurutkan berdasarkan tahun terbit.
7. Setiap pustaka diketik satu spasi, antar pustaka dua spasi.
8. Referensi pustaka dari internet harus memuat nama penulis, tahun upload tulisan, judul tulisan, nama lengkap URL/web, dan tanggal unduh.
9. Referensi pustaka bukan dari Blogspot, Wordpress, atau Wikipedia.
10. Jika buku/referensi tidak mencantumkan nama pengarang, gunakan nama instansi/bagian penerbit buku.
11. Contoh daftar pustaka menunjukkan daftar tidak menggunakan nomor urut.

Sumber:

1. `render-pedoman/pedoman-page-10.png`
2. `render-pedoman/pedoman-page-11.png`
3. `render-pedoman/pedoman-page-12.png`
4. `render-pedoman/pedoman-page-13.png`
5. `render-pedoman/pedoman-page-15.png`
6. `render-pedoman/pedoman-page-16.png`
7. `render-pedoman/pedoman-page-17.png`
8. `render-pedoman/pedoman-page-18.png`

## Struktur Halaman Awal Jika Terlihat

Struktur halaman awal tidak terlihat lengkap pada render pedoman. Namun aturan halaman judul terlihat sebagian:

1. Judul skripsi/tugas akhir di tengah, huruf kapital, ukuran 14, jarak 1,5 spasi.
2. Logo Universitas Bina Sarana Informatika menggunakan ukuran standar, contoh 5 cm x 5 cm.
3. Kata `SKRIPSI` atau `TUGAS AKHIR` ukuran 18.
4. Kalimat `Diajukan ...` ukuran 12.
5. Nama penulis dan NIM ukuran 14, jarak 1,5 spasi.
6. Nama program studi, fakultas, universitas, kota, dan tahun pembuatan ukuran 12, jarak 1,5 spasi.

Bagian awal lain seperti lembar pernyataan, persetujuan, kata pengantar, daftar isi, daftar simbol, daftar gambar, daftar tabel, dan daftar lampiran tidak terlihat rinci pada render pedoman.

Sumber:

1. `render-pedoman/pedoman-page-01.png`
2. `render-pedoman/pedoman-page-02.png`
3. `render-pedoman/pedoman-page-03.png`

## Watermark Dan Tanda Tangan Digital

Aturan yang terlihat:

1. Tanda tangan persetujuan skripsi/tugas akhir yang berhubungan dengan tanda tangan dosen pembimbing menggunakan fitur DigiSAYS.
2. Verifikasi keabsahan dokumen dilakukan dari hasil scan QR code.
3. Watermark diberikan pada setiap halaman kecuali lembar judul.
4. Watermark menggunakan logo resmi Universitas Bina Sarana Informatika.
5. Ukuran logo watermark 10 cm x 10 cm.
6. Letak watermark menggunakan layout rata tengah.

Sumber:

1. `render-pedoman/pedoman-page-03.png`
2. `render-pedoman/pedoman-page-04.png`

## Catatan Bagian Yang Belum Terbaca Jelas

Bagian berikut belum dapat dipastikan dari render pedoman:

1. Format rinci daftar isi.
2. Format rinci daftar gambar.
3. Format rinci daftar tabel.
4. Format rinci daftar lampiran pada bagian awal.
5. Format lengkap halaman awal selain halaman judul.
6. Ketentuan rinci heading pada daftar isi.
7. Ketentuan pasti indentasi paragraf biasa.
8. Apakah ada aturan khusus bahasa Inggris/Indonesia selain abstrak yang tidak tampak pada render.

## Konflik Awal

Belum ditemukan konflik langsung antar aturan pedoman dari halaman render yang direview. Potensi konflik belum dapat dipastikan karena beberapa bagian awal pedoman tidak terlihat dalam render yang tersedia.
