# OUTLINE_156_MAPPING.md

Tanggal audit: 2026-07-04
Metode audit: review visual render PNG, tanpa OCR otomatis
Sumber asli: `skripsi/outline.pdf`
Render sumber: `skripsi/01-pedoman-dan-outline/render-outline/`

## Identitas Dokumen Outline 156

Dokumen yang diaudit adalah `outline.pdf`. Berdasarkan audit metadata sebelumnya, dokumen ini berjudul `Handout Skripsi Prodi Teknologi Informasi Periode I Tahun 2024.pdf`, berjumlah 9 halaman PDF, dan sudah dirender menjadi 9 PNG.

Identitas yang terlihat pada render:

1. Dokumen: Outline Skripsi Program Studi Teknologi Informasi Program Sarjana.
2. Kode outline yang digunakan: 156.
3. Nama outline pada tabel awal: Perancangan Program Science.
4. Pada bagian kode dan ketentuan outline, kode 156 disebut sebagai `Perancangan Program`.
5. Metode pengerjaan: Individu.
6. Bukti riset: Surat Keterangan PKL/Riset atau Surat Keabsahan Data.
7. Luaran: publikasi artikel ilmiah wajib; HKI, buku, dan berita acara serah terima karya disarankan/opsional sesuai keterangan yang terlihat.

Sumber:

1. `render-outline/outline-page-1.png`

## Jenis Outline/Program Yang Digunakan

Jenis outline yang digunakan untuk project ini adalah Outline 156, Perancangan Program Science/Perancangan Program, untuk Program Studi Teknologi Informasi Program Sarjana.

Catatan:

1. Dokumen menggunakan istilah `Perancangan Program Science` pada tabel awal.
2. Bagian detail menggunakan istilah `Perancangan Program`.
3. Perbedaan istilah ini perlu dicatat, tetapi tidak mengubah kode outline 156.

Sumber:

1. `render-outline/outline-page-1.png`

## Bentuk Outline Umum

Struktur awal dan akhir yang terlihat:

1. Lembar Judul Skripsi.
2. Lembar Pernyataan Keaslian Skripsi.
3. Lembar Pernyataan Persetujuan Publikasi Karya Ilmiah.
4. Lembar Persetujuan dan Pengesahan Skripsi.
5. Lembar Pedoman Penggunaan Hak Cipta.
6. Lembar Konsultasi Skripsi.
7. Lembar Persembahan.
8. Kata Pengantar.
9. Abstraksi.
10. Daftar Isi.
11. Daftar Simbol.
12. Daftar Gambar.
13. Daftar Tabel.
14. Daftar Lampiran.
15. BAB I sampai BAB V.
16. Daftar Pustaka.
17. Daftar Riwayat Hidup.
18. Surat Keterangan Riset.
19. Bukti hasil pengecekan plagiarisme.
20. Lampiran.

Sumber:

1. `render-outline/outline-page-1.png`
2. `render-outline/outline-page-2.png`
3. `render-outline/outline-page-9.png`

## Struktur BAB I Sampai BAB V Berdasarkan Outline

### BAB I - Pendahuluan

Subbab yang terlihat:

1. `1.1 Latar Belakang Masalah`
2. `1.2 Identifikasi Permasalahan`
3. `1.3 Perumusan Masalah`
4. `1.4 Tujuan dan Manfaat`
5. `1.5 Metode Penelitian`
6. `1.5.1 Teknik Pengumpulan Data`
7. `1.5.2 Model Pengembangan Software`
8. `1.6 Ruang Lingkup`

Penjelasan ringkas:

1. Latar belakang berisi garis besar alasan pembuatan skripsi dan masalah yang membutuhkan aplikasi.
2. Identifikasi permasalahan berisi alasan dan permasalahan yang membutuhkan aplikasi.
3. Perumusan masalah berbentuk kalimat tanya.
4. Tujuan dan manfaat menjelaskan tujuan pembuatan skripsi dan manfaatnya.
5. Teknik pengumpulan data mencakup observasi, wawancara, dan studi pustaka.
6. Model pengembangan software disesuaikan dengan model yang dipilih penulis.
7. Ruang lingkup menjelaskan proses yang dibahas pada pembuatan dan pengembangan aplikasi berdasarkan latar belakang permasalahan.

Sumber:

1. `render-outline/outline-page-1.png`
2. `render-outline/outline-page-2.png`
3. `render-outline/outline-page-3.png`
4. `render-outline/outline-page-4.png`

### BAB II - Landasan Teori

Subbab yang terlihat:

1. `2.1 Tinjauan Pustaka`
2. `2.2 Penelitian Terkait`

Penjelasan ringkas:

1. BAB II berisi tinjauan pustaka yang menguraikan teori dan algoritma yang mendukung judul.
2. BAB II tidak hanya berisi definisi, tetapi juga konsep dasar, model atau algoritma yang berkaitan langsung dengan masalah.
3. Tools/software komponen yang digunakan untuk aplikasi atau penelitian juga ditulis.
4. Tinjauan pustaka berisi konsep dasar program, metode algoritma, pengujian aplikasi, dan peralatan pendukung.
5. Jika menggunakan UML, teori dan diagram UML yang dipakai harus konsisten dengan pembahasan.
6. Penelitian terkait berisi aplikasi serupa dari jurnal ilmiah dan kutipan jurnal terkait, minimal 5 kutipan jurnal terkait.

Sumber:

1. `render-outline/outline-page-4.png`

### BAB III - Analisis dan Perancangan Aplikasi

Subbab yang terlihat:

1. `3.1 Tinjauan Perusahaan` atau pada penjelasan halaman 5 tertulis `Tinjauan Institusi/Organisasi/Perusahaan`.
2. `3.1.1 Sejarah Perusahaan`
3. `3.1.2 Struktur Organisasi`
4. `3.2 Analisis Aplikasi`
5. `3.2.1 Analisis Masalah`
6. `3.2.2 Analisis Kebutuhan`
7. `3.3 Rancangan Algoritma`

Penjelasan ringkas:

1. Jika mahasiswa melakukan riset, tinjauan institusi/organisasi/perusahaan berisi sejarah dan struktur organisasi tempat riset.
2. Analisis aplikasi menjelaskan analisis umum yang dilakukan penulis sampai menemukan permasalahan dan solusi dalam desain software.
3. Analisis masalah menjelaskan proses menemukan dan mengidentifikasi permasalahan serta solusi.
4. Analisis kebutuhan merumuskan kebutuhan untuk menyelesaikan masalah.
5. Rancangan algoritma menjelaskan algoritma yang digunakan untuk menyelesaikan kasus.

Sumber:

1. `render-outline/outline-page-2.png`
2. `render-outline/outline-page-5.png`
3. `render-outline/outline-page-6.png`

### BAB IV - Implementasi dan Pengujian Software

Subbab yang terlihat:

1. `4.1 Desain`
2. `4.1.1 Database`
3. `4.1.2 Software Architecture`
4. `4.1.3 User Interface`
5. `4.2 Code Generation`
6. `4.3 Testing`
7. `4.4 Support`
8. `4.4.1 Publikasi Software`
9. `4.4.2 Spesifikasi Hardware dan Software`

Penjelasan ringkas:

1. Database berisi desain basis data sesuai aplikasi, termasuk tabel, relasi, dan tipe data.
2. Software Architecture menjelaskan pseudocode dari algoritma yang digunakan untuk menyelesaikan permasalahan dalam pembangunan aplikasi.
3. User Interface menjelaskan model antarmuka pengguna dan menampilkan desain/form yang dibuat.
4. Code Generation menampilkan hasil generate class untuk OOP atau listing program untuk pemrograman terstruktur pada form yang terkait proses bisnis utama.
5. Testing berisi pengujian unit pada program yang telah dibuat dengan metode pengujian yang dikuasai mahasiswa.
6. Support berisi tempat software dipublikasikan atau dijalankan dan spesifikasi hardware/software.
7. Publikasi software membedakan aplikasi web untuk pengguna luar perusahaan/internet dan pengguna dalam perusahaan/intranet.
8. Spesifikasi hardware dan software berisi daftar terstruktur perangkat pendukung menjalankan aplikasi.

Sumber:

1. `render-outline/outline-page-2.png`
2. `render-outline/outline-page-7.png`
3. `render-outline/outline-page-8.png`

### BAB V - Penutup

Subbab yang terlihat:

1. `5.1 Kesimpulan`
2. `5.2 Saran`

Penjelasan ringkas:

1. Kesimpulan berisi kesimpulan dari hasil penelitian yang telah dilakukan.
2. Saran berisi solusi terhadap kelemahan sistem yang dibuat dan saran untuk aspek manajerial, aspek sistem, dan aspek penelitian/pembahasan selanjutnya.

Sumber:

1. `render-outline/outline-page-2.png`
2. `render-outline/outline-page-9.png`

## Rincian Subbab Wajib

Subbab wajib berdasarkan struktur outline:

1. BAB I: 1.1 sampai 1.6, termasuk 1.5.1 dan 1.5.2.
2. BAB II: 2.1 dan 2.2.
3. BAB III: 3.1 sampai 3.3, termasuk 3.1.1, 3.1.2, 3.2.1, dan 3.2.2.
4. BAB IV: 4.1 sampai 4.4, termasuk 4.1.1, 4.1.2, 4.1.3, 4.4.1, dan 4.4.2.
5. BAB V: 5.1 dan 5.2.

Sumber:

1. `render-outline/outline-page-1.png`
2. `render-outline/outline-page-2.png`

## Bagian Yang Berkaitan Dengan Metode Pengembangan Sistem

Bagian yang berkaitan langsung:

1. `1.5.2 Model Pengembangan Software`.
2. Outline menyebut contoh model: Waterfall, Spiral, Incremental, Prototype, RAD, dan lain-lain.
3. Outline menyatakan jika model pengembangan sistem yang digunakan bukan Waterfall, isi tahapan model disesuaikan dengan model yang akan digunakan.

Implikasi untuk project ini:

1. Agile Scrum dapat digunakan pada `1.5.2` karena outline membuka ruang untuk model selain Waterfall.
2. Tahapan Scrum harus dijelaskan sebagai model pengembangan yang dipilih, bukan dicampur tanpa penjelasan dengan Waterfall/RAD.

Sumber:

1. `render-outline/outline-page-3.png`

## Bagian Yang Berkaitan Dengan BAB IV Implementasi Dan Pengujian Software

Bagian yang berkaitan langsung:

1. `4.1 Desain`
2. `4.1.1 Database`
3. `4.1.2 Software Architecture`
4. `4.1.3 User Interface`
5. `4.2 Code Generation`
6. `4.3 Testing`
7. `4.4 Support`
8. `4.4.1 Publikasi Software`
9. `4.4.2 Spesifikasi Hardware dan Software`

Data yang harus disiapkan dari aplikasi:

1. Struktur database, tabel, relasi, dan tipe data.
2. Arsitektur software atau alur aplikasi.
3. Tampilan/form utama aplikasi.
4. Potongan kode atau class yang mewakili proses bisnis utama.
5. Skenario testing.
6. Spesifikasi hardware/software untuk menjalankan aplikasi.
7. Status publikasi/deployment: lokal, intranet, internet, atau belum dipublikasikan.

Sumber:

1. `render-outline/outline-page-7.png`
2. `render-outline/outline-page-8.png`

## Penyesuaian Agar BAB IV Menggunakan Agile Scrum

Penyesuaian yang aman berdasarkan outline:

1. Pada `1.5.2 Model Pengembangan Software`, tuliskan Agile Scrum sebagai model pengembangan yang dipilih.
2. Jelaskan bahwa outline memperbolehkan model selain Waterfall dengan tahapan disesuaikan, sehingga tahapan Scrum digunakan untuk konteks project ini.
3. Dalam BAB IV, struktur subbab outline tetap dipertahankan:
   - `4.1 Desain`
   - `4.2 Code Generation`
   - `4.3 Testing`
   - `4.4 Support`
4. Isi setiap subbab BAB IV dikaitkan dengan hasil sprint/Scrum:
   - Product backlog dan sprint backlog menjadi dasar kebutuhan/desain.
   - Sprint execution menjadi dasar implementasi/code generation.
   - Sprint review/testing menjadi dasar pengujian.
   - Retrospective atau evaluasi dapat menjadi catatan perbaikan.
5. Jika artefak Scrum eksplisit belum tersedia, jangan mengarang sprint. Buat dulu audit aplikasi dan susun artefak kerja berdasarkan riwayat project yang bisa diverifikasi atau minta data dari user.

Risiko:

1. Outline BAB IV tidak menyebut Scrum secara eksplisit.
2. Penyesuaian Scrum harus dijelaskan sebagai adaptasi model pengembangan pada bagian `1.5.2`, bukan mengubah struktur BAB IV secara bebas.

Sumber:

1. `render-outline/outline-page-3.png`
2. `render-outline/outline-page-7.png`
3. `render-outline/outline-page-8.png`

## Bagian Yang Perlu Diambil Dari Aplikasi

Sumber aplikasi yang perlu digunakan:

1. `app/Config/Routes.php` untuk route dan hak akses.
2. `app/Controllers/` untuk proses bisnis.
3. `app/Models/` untuk model data.
4. `app/Views/` untuk user interface.
5. `app/Database/Migrations/` dan `database/*.sql` untuk struktur database.
6. `app/Controllers/ErdController.php` untuk ERD, relasi, dan dokumentasi tabel.
7. `README.md` untuk fitur dan setup.

Mapping ke outline:

1. BAB III `3.2 Analisis Aplikasi`: modul, masalah, solusi, kebutuhan.
2. BAB III `3.3 Rancangan Algoritma`: alur/proses bisnis aplikasi yang relevan.
3. BAB IV `4.1.1 Database`: migration, SQL, ERD.
4. BAB IV `4.1.2 Software Architecture`: struktur MVC CodeIgniter, route, controller, model, view, dan alur proses.
5. BAB IV `4.1.3 User Interface`: screenshot/desain form.
6. BAB IV `4.2 Code Generation`: kode controller/model/view terpilih.
7. BAB IV `4.3 Testing`: skenario pengujian modul.
8. BAB IV `4.4 Support`: spesifikasi Laragon/PHP/MySQL/browser/hardware.

Sumber outline:

1. `render-outline/outline-page-5.png`
2. `render-outline/outline-page-7.png`
3. `render-outline/outline-page-8.png`

## Bagian Yang Perlu Diambil Dari Transkrip Wawancara

Bagian transkrip yang perlu digunakan:

1. Kondisi pencatatan inventaris aset masih manual.
2. Excel pernah dicoba tetapi tidak berlanjut.
3. Data yang perlu dicatat: barang masuk, barang keluar, letak barang, peminjaman barang.
4. Kendala barang keluar/masuk belum tercatat dan barang pinjaman tidak selalu kembali ke tempat semula.
5. Proses surat dan disposisi masih manual.
6. Arsip surat masuk/keluar masih terpisah.
7. Kebutuhan pemantauan status surat, arsip digital, dan laporan.
8. Aktor kebutuhan: Admin TU, Kepala Sekolah, Staff.

Mapping ke outline:

1. BAB I `1.1 Latar Belakang Masalah`.
2. BAB I `1.2 Identifikasi Permasalahan`.
3. BAB I `1.3 Perumusan Masalah`.
4. BAB I `1.4 Tujuan dan Manfaat`.
5. BAB I `1.5.1 Teknik Pengumpulan Data`.
6. BAB III `3.2.1 Analisis Masalah`.
7. BAB III `3.2.2 Analisis Kebutuhan`.

Sumber outline:

1. `render-outline/outline-page-3.png`
2. `render-outline/outline-page-5.png`

## Bagian Yang Perlu Diambil Dari Database/ERD

Bagian database/ERD yang perlu digunakan:

1. Tabel users.
2. Tabel asset_categories.
3. Tabel asset_locations.
4. Tabel assets.
5. Tabel incoming_letters.
6. Tabel dispositions.
7. Tabel outgoing_letters.
8. Tabel asset_transactions.
9. Tabel asset_transaction_items.
10. Relasi antar tabel.

Mapping ke outline:

1. BAB IV `4.1.1 Database`.
2. BAB III `3.2.2 Analisis Kebutuhan`, terutama kebutuhan data.
3. BAB IV `4.1.2 Software Architecture`, jika relasi data dipakai menjelaskan alur.
4. Lampiran, jika ERD/tabel terlalu panjang untuk dimasukkan penuh di bab.

Sumber outline:

1. `render-outline/outline-page-7.png`
2. `render-outline/outline-page-8.png`

## Risiko Konflik Antara Outline Dan Kondisi Project

Risiko yang terlihat:

1. Outline mencontohkan model pengembangan umum dan menyebut Waterfall/RAD sebagai contoh, sedangkan project harus menggunakan Agile Scrum. Ini dapat diselesaikan karena outline menyatakan model selain Waterfall boleh disesuaikan.
2. BAB III dan BAB IV memberi contoh Rancangan Algoritma dan Software Architecture dengan Dijkstra. Project ini bukan aplikasi pencarian rute, sehingga contoh tersebut tidak boleh disalin. Perlu mengganti dengan alur/proses bisnis aplikasi inventaris aset dan disposisi surat.
3. Outline menyebut `Tinjauan Perusahaan`, sedangkan objek penelitian adalah sekolah/SMPI REJIS. Penyesuaian istilah dapat menjadi `Tinjauan Institusi/Organisasi/Sekolah`, karena halaman penjelasan juga memakai istilah institusi/organisasi/perusahaan.
4. Outline menyebut publikasi software, sedangkan aplikasi mungkin masih berjalan lokal/Laragon. Status publikasi harus diverifikasi sebelum ditulis.
5. Artefak Scrum seperti backlog/sprint belum ditemukan, sehingga tidak boleh dikarang.
6. Outline mewajibkan atau menekankan referensi jurnal, sedangkan file referensi/sitasi belum ditemukan.

Sumber:

1. `render-outline/outline-page-3.png`
2. `render-outline/outline-page-5.png`
3. `render-outline/outline-page-7.png`
4. `render-outline/outline-page-8.png`
5. `render-outline/outline-page-9.png`

## Catatan Bagian Yang Belum Terbaca Jelas

Bagian yang belum dapat dipastikan:

1. Format teknis layout outline selain struktur bab tidak dibahas rinci pada outline.
2. Detail persyaratan publikasi artikel ilmiah tidak dijelaskan penuh pada render yang direview.
3. Detail format bukti hasil pengecekan plagiarisme tidak terlihat.
4. Detail isi lampiran belum dirinci.
5. Detail daftar simbol belum dirinci.
6. Detail contoh lengkap untuk BAB IV hanya sebagian terlihat dan menggunakan contoh Dijkstra, sehingga tidak cocok langsung untuk project ini.

## Kesimpulan Mapping Awal

Struktur `SKRIPSI.docx` harus mempertahankan BAB I sampai BAB V sesuai outline 156. Penyesuaian utama project ini berada pada:

1. `1.5.2 Model Pengembangan Software`: gunakan Agile Scrum.
2. `3.3 Rancangan Algoritma`: gunakan alur/proses bisnis aplikasi, bukan contoh Dijkstra.
3. `4.1.2 Software Architecture`: jelaskan arsitektur CodeIgniter MVC dan alur proses penting, serta jika perlu pseudocode/alur Scrum yang relevan.
4. `4.3 Testing`: gunakan skenario pengujian modul aplikasi.
5. `4.4 Support`: tulis status deployment dan spesifikasi perangkat secara faktual.
