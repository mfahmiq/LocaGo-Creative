# BAB III

# ANALISIS DAN PERANCANGAN APLIKASI

Status dokumen: data patch 2 dari `BAB-III-REVISI-1-DATAPATCH-1.md`. Pada putaran pengisian data kedua ini (`USER-DATA-INPUT-ROUND-2.md`), seluruh field profil resmi, sejarah singkat, dan struktur organisasi SMPI REJIS masih berupa placeholder kosong, sama seperti putaran pertama. Sesuai instruksi dan hasil validasi, ketiga marker `[PERLU DATA]` pada 3.1, 3.1.1, dan 3.1.2 **dipertahankan tanpa perubahan** karena belum ada data nyata untuk menggantikannya. Tidak ada substansi lain yang diubah pada patch ini. Kandidat BAB III terbaru, belum menjadi naskah final DOCX.

## 3.1. Tinjauan Perusahaan

SMPI REJIS menjadi objek penelitian dalam penyusunan skripsi ini. Berdasarkan transkrip wawancara penelitian yang dilakukan pada 27 April 2026 dengan Wakil Kepala Sekolah Bidang Kesiswaan SMPI REJIS, yaitu Gilang Ramadhan S.Kom. atau Ust. Gilang, SMPI REJIS merupakan lembaga pendidikan yang menyelenggarakan administrasi sekolah, termasuk pengelolaan inventaris aset dan pengelolaan surat.

Profil resmi SMPI REJIS, seperti alamat lengkap, status kelembagaan/yayasan, serta visi dan misi, belum tersedia pada workspace ini. `[PERLU DATA]`

## 3.1.1. Sejarah Perusahaan

Sejarah singkat SMPI REJIS, termasuk tahun berdiri, latar belakang pendirian, dan perkembangan institusi, perlu disusun berdasarkan dokumen resmi SMPI REJIS. Dokumen tersebut belum tersedia pada workspace ini. `[PERLU DATA]`

## 3.1.2. Struktur Organisasi

Struktur organisasi resmi SMPI REJIS, termasuk bagan organisasi dan nama pejabat pada setiap posisi, perlu dilengkapi berdasarkan dokumen resmi sekolah. Dokumen tersebut belum tersedia pada workspace ini. `[PERLU DATA]`

Berdasarkan transkrip wawancara, pihak yang berkaitan dengan pengelolaan inventaris aset dan disposisi surat secara umum mencakup pimpinan sekolah, wakil kepala sekolah, tata usaha atau operator administrasi, dan staf terkait. Uraian ini disebutkan secara umum sebagai gambaran pihak yang relevan terhadap sistem, bukan sebagai struktur organisasi resmi yang sudah diverifikasi.

## 3.2. Analisis Aplikasi

Analisis aplikasi dalam penelitian ini disusun berdasarkan kondisi pengelolaan inventaris aset dan pengelolaan surat di SMPI REJIS sebagaimana diperoleh dari hasil wawancara pada 27 April 2026 dengan Gilang Ramadhan S.Kom. (Ust. Gilang), serta hasil audit aplikasi yang tersedia (`APLIKASI_FEATURE_AUDIT.md`, `DATABASE_ERD_AUDIT.md`).

Kondisi yang menjadi dasar analisis:

1. Inventaris aset masih dicatat secara manual menggunakan buku.
2. Microsoft Excel pernah dicoba untuk pencatatan aset, tetapi tidak berlanjut.
3. Data barang masuk, barang keluar, dan peminjaman aset belum terdokumentasi secara konsisten.
4. Aset belum dikelompokkan secara jelas berdasarkan kategori, lokasi, dan kondisi.
5. Aset yang dipinjam dapat tidak kembali ke tempat semula sehingga sulit dilacak.
6. Pengelolaan surat masih dilakukan secara manual.
7. Arsip surat masuk dan surat keluar masih tersimpan secara terpisah.
8. Proses disposisi surat belum memiliki mekanisme pemantauan yang terstruktur.

### 3.2.1. Analisis Masalah

Analisis masalah diturunkan dari identifikasi masalah pada BAB I.

No | Masalah | Dampak | Solusi Yang Diusulkan
---|---|---|---
1 | Inventaris aset masih dicatat secara manual | Pencarian data membutuhkan waktu lebih lama dan berisiko menimbulkan kesalahan pencatatan | Modul inventaris aset berbasis web untuk mencatat data aset secara terpusat
2 | Riwayat barang masuk, barang keluar, dan peminjaman aset belum terdokumentasi secara konsisten | Riwayat penggunaan aset sulit ditelusuri | Modul transaksi/peminjaman aset yang mencatat status peminjaman dan pengembalian secara terstruktur
3 | Kategori, lokasi, dan kondisi aset belum tersusun secara terstruktur | Pengelompokan aset tidak konsisten dan menyulitkan pelaporan | Modul kategori dan lokasi aset yang terhubung dengan data aset melalui relasi basis data
4 | Lokasi dan status aset sulit dipantau | Sekolah kesulitan mengetahui keberadaan barang saat dibutuhkan | Pencatatan lokasi, kondisi, dan status aset pada modul inventaris aset
5 | Pencatatan surat masuk masih dilakukan secara manual | Berisiko menimbulkan keterlambatan pengolahan informasi | Modul surat masuk berbasis web dengan pencatatan nomor, tanggal, pengirim, dan status
6 | Arsip surat masuk dan surat keluar tersimpan secara terpisah | Pencarian kembali dokumen belum efisien | Modul surat masuk dan surat keluar yang tersimpan pada satu basis data terpusat
7 | Disposisi surat belum memiliki mekanisme pemantauan yang terstruktur | Tindak lanjut surat belum dapat dikontrol dengan baik | Modul disposisi surat yang mencatat tujuan, instruksi, status, dan tanggal jatuh tempo

### 3.2.2. Analisis Kebutuhan

Analisis kebutuhan dalam penelitian ini disesuaikan dengan role yang tersedia pada aplikasi, yaitu admin, operator, dan pimpinan. Role tersebut ditemukan pada `app/Helpers/auth_helper.php`, `app/Models/UserModel.php`, dan `app/Config/Routes.php` (`APLIKASI_FEATURE_AUDIT.md`). Admin TU, Kepala Sekolah, dan Staff hanya digunakan sebagai padanan operasional jika diperlukan, bukan sebagai role teknis final aplikasi.

**Kebutuhan Pengguna**

No | Pengguna | Kebutuhan | Hak Akses Utama
---|---|---|---
1 | admin | Mengelola seluruh data master, pengguna, dan seluruh modul aplikasi | Login, manajemen pengguna, inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, backup
2 | operator | Mencatat dan memperbarui data operasional aset dan surat sehari-hari | Login, inventaris aset, transaksi aset, surat masuk, surat keluar, laporan; tidak memiliki akses manajemen pengguna (terverifikasi menolak akses `/users` dengan redirect ke dashboard pada `APPLICATION_VERIFICATION.md`)
3 | pimpinan | Memantau data, status, dan laporan tanpa mengubah data operasional utama | Login, dashboard, laporan, dan pemantauan data; dibatasi dari beberapa aksi input seperti form tambah aset (terverifikasi menolak akses `/assets/create` dengan redirect ke dashboard pada `APPLICATION_VERIFICATION.md`)

**Kebutuhan Fungsional**

No | Kebutuhan | Deskripsi | Pengguna Terkait
---|---|---|---
1 | Login atau autentikasi | Pengguna dapat masuk ke sistem menggunakan username dan password sesuai role | admin, operator, pimpinan
2 | Dashboard | Sistem menampilkan ringkasan data aset, surat, disposisi, dan pengguna | admin, operator, pimpinan
3 | Manajemen pengguna | Admin dapat mengelola data pengguna sistem | admin
4 | Inventaris aset | Pengguna dapat mencatat, mengubah, mencari, dan melihat detail data aset beserta kategori dan lokasi | admin, operator (kelola); pimpinan (lihat)
5 | Transaksi atau peminjaman aset | Pengguna dapat mencatat peminjaman aset multi-item, mencetak bukti transaksi, dan mencatat pengembalian | admin, operator
6 | Surat masuk | Pengguna dapat mencatat surat masuk beserta lampiran dan ekstraksi tanggal lampiran | admin, operator
7 | Disposisi surat | Pengguna dapat membuat disposisi dari surat masuk dan memperbarui status tindak lanjut | admin, pimpinan
8 | Surat keluar | Pengguna dapat mencatat surat keluar beserta lampiran dan status pengiriman | admin, operator
9 | Laporan | Sistem menyediakan laporan aset, surat masuk, surat keluar, disposisi, dan transaksi aset yang dapat ditampilkan, diekspor CSV, dan dicetak | admin, operator, pimpinan
10 | Backup | Admin dapat mengunduh cadangan basis data dalam bentuk berkas SQL | admin

**Kebutuhan Nonfungsional**

1. Keamanan dasar pada proses login dan sesi pengguna.
2. Hak akses berbasis role (admin, operator, pimpinan).
3. Validasi input pada form-form penting.
4. Penyimpanan data terpusat pada satu basis data MySQL/MariaDB.
5. Kemudahan penggunaan melalui antarmuka web yang sederhana.
6. Ketersediaan fitur backup data secara berkala.
7. Performa dasar yang memadai pada lingkungan lokal.
8. Penggunaan melalui web browser tanpa instalasi aplikasi tambahan.
9. Sistem dibatasi pada lingkungan lokal menggunakan Laragon; belum mencakup kebutuhan nonfungsional untuk lingkungan produksi/daring.

## 3.3. Rancangan Algoritma

Rancangan algoritma berikut menjelaskan alur logika proses utama aplikasi berdasarkan alur yang ditemukan pada route, controller, dan model aplikasi (`APLIKASI_FEATURE_AUDIT.md`). Alur ditulis dalam bentuk langkah bernomor, bukan kode program.

**Algoritma Login**

1. Pengguna membuka halaman login.
2. Pengguna memasukkan username dan password, lalu mengirim form.
3. Sistem memvalidasi bahwa username dan password wajib diisi.
4. Jika validasi gagal, sistem mengembalikan pengguna ke form login beserta pesan kesalahan.
5. Jika validasi berhasil, sistem mencari pengguna aktif berdasarkan username dan memverifikasi kecocokan password.
6. Jika kredensial tidak sesuai, sistem menampilkan pesan gagal dan tetap berada di halaman login.
7. Jika kredensial sesuai, sistem membuat sesi baru dan menyimpan data pengguna (id, nama, username, role) pada sesi.
8. Sistem mengarahkan pengguna ke halaman dashboard.

**Algoritma Pengelolaan Inventaris Aset**

1. Pengguna membuka daftar aset; sistem dapat memfilter berdasarkan kata kunci, kategori, lokasi, dan kondisi.
2. Pengguna memilih tambah data aset dan mengisi kode, nama, kategori, lokasi, kondisi, jumlah, tahun perolehan, sumber dana, nilai, penanggung jawab, foto, dan catatan.
3. Sistem memvalidasi kelengkapan data dan keunikan kode aset.
4. Jika foto diunggah, sistem memeriksa jenis berkas sebelum menyimpan.
5. Jika valid, sistem menyimpan data aset ke basis data dan menampilkannya pada daftar aset.
6. Pengguna dapat membuka detail, mengubah, atau (khusus admin) menghapus data aset.

**Algoritma Transaksi atau Peminjaman Aset**

1. Pengguna membuka daftar transaksi aset.
2. Pengguna membuat transaksi baru dengan mengisi kode transaksi, tanggal pinjam, estimasi tanggal kembali, unit peminjam, nama peminjam, tujuan, serta satu atau lebih item aset beserta jumlah dan kondisi awal.
3. Sistem memvalidasi bahwa transaksi harus memiliki minimal satu item aset.
4. Jika valid, sistem menyimpan transaksi dengan status awal `dipinjam`.
5. Pengguna dapat melihat detail transaksi dan mengunduh bukti transaksi dalam bentuk PDF.
6. Saat pengembalian, pengguna mengisi tanggal kembali, kondisi setelah kembali, dan catatan.
7. Sistem memperbarui status transaksi menjadi salah satu dari `dikembalikan`, `rusak_saat_kembali`, `hilang`, atau `dibatalkan`.

**Algoritma Surat Masuk**

1. Pengguna membuka daftar surat masuk; sistem dapat memfilter berdasarkan kata kunci, status, prioritas, dan rentang tanggal.
2. Pengguna mencatat surat masuk baru dengan mengisi nomor surat, tanggal surat, tanggal diterima, pengirim, prioritas, perihal, ringkasan, dan lampiran.
3. Jika lampiran diunggah, sistem memeriksa jenis dan ukuran berkas.
4. Sistem menyimpan data surat masuk dengan status awal `menunggu_disposisi`.
5. Sistem dapat mencoba mengekstraksi tanggal dari lampiran surat menggunakan pustaka ekstraksi tanggal.
6. Pengguna dapat membuka detail surat masuk beserta status dan disposisi terkait.

**Algoritma Disposisi Surat**

1. Admin atau pimpinan membuka detail surat masuk yang berstatus `menunggu_disposisi`.
2. Pengguna mengisi tujuan/unit disposisi, instruksi, dan tanggal jatuh tempo.
3. Sistem menyimpan data disposisi dan mengubah status surat masuk menjadi `didisposisikan`.
4. Pengguna dapat membuka daftar disposisi dan memfilter berdasarkan kata kunci atau status.
5. Saat status disposisi diperbarui (misalnya menjadi `dalam_proses` atau `selesai`), sistem menyinkronkan status surat masuk terkait.

**Algoritma Laporan**

1. Pengguna membuka halaman laporan dan memilih jenis data: aset, surat masuk, surat keluar, disposisi, atau transaksi aset.
2. Pengguna dapat menerapkan filter tanggal atau status sesuai jenis laporan.
3. Sistem mengambil data dari tabel modul bisnis terkait dan menampilkan hasil laporan.
4. Pengguna dapat mengekspor laporan ke berkas CSV atau menampilkan versi cetak.

**Algoritma Backup**

1. Admin membuka halaman backup.
2. Sistem menampilkan daftar tabel basis data yang tersedia.
3. Admin memilih unduh backup.
4. Sistem membuat berkas dump SQL berisi struktur dan data tabel, lalu mengirimkannya sebagai berkas unduhan.
