# SKRIPSI-IMPACT-PENGAJUAN-INVENTARIS

## Status

- Tanggal: 2026-07-05.
- Tujuan: mencatat dampak fitur Pengajuan Inventaris terhadap naskah skripsi.
- Catatan: dokumen ini belum mengubah BAB I sampai BAB V utama.

## Dampak Ke BAB I

BAB I perlu ditinjau ulang pada bagian ruang lingkup dan manfaat sistem. Fitur baru dapat disebut sebagai perluasan modul inventaris aset, yaitu pencatatan pengajuan kebutuhan inventaris sebelum tindak lanjut operasional dilakukan.

Catatan aman penulisan:

1. Jangan menulis bahwa fitur ini sudah digunakan resmi oleh sekolah.
2. Jangan menulis aplikasi sudah online atau produksi.
3. Tetap tulis bahwa aplikasi dikembangkan dan diuji pada lingkungan lokal/Laragon jika belum ada bukti deployment.

## Dampak Ke BAB III

BAB III bagian analisis kebutuhan dapat menambahkan kebutuhan fungsional:

1. Admin/operator dapat membuat pengajuan inventaris.
2. Pengajuan memiliki item barang/aset.
3. Pimpinan/admin dapat menyetujui atau menolak pengajuan.
4. Pengajuan dapat dicetak atau diunduh sebagai PDF.

BAB III bagian rancangan algoritma dapat menambahkan alur ringkas:

1. Pengguna memilih menu Pengajuan Inventaris.
2. Sistem menampilkan daftar pengajuan sesuai role.
3. Admin/operator mengisi form pengajuan.
4. Sistem memvalidasi header dan minimal satu item.
5. Sistem menyimpan pengajuan dengan status `diajukan`.
6. Pimpinan/admin memproses approval.
7. Sistem mengubah status menjadi `disetujui` atau `ditolak`.

## Dampak Ke BAB IV

BAB IV perlu diperbarui pada bagian:

1. Database: menambah tabel `inventory_requests` dan `inventory_request_items`.
2. Software Architecture: menambah controller, model, route, dan view modul Pengajuan Inventaris.
3. User Interface: menambah screenshot daftar, form, detail, approval, dan PDF pengajuan.
4. Code Generation: menambah penjelasan singkat controller/model untuk modul Pengajuan Inventaris.
5. Testing: menambah skenario black-box khusus modul Pengajuan Inventaris.

## Dampak Ke BAB V

BAB V dapat menambahkan poin kesimpulan bahwa sistem mendukung pencatatan pengajuan inventaris secara terstruktur, namun tidak boleh menyimpulkan integrasi otomatis dengan surat keluar atau transaksi aset karena belum dibuat.

## Diagram Yang Perlu Diperbarui

1. Use Case Diagram: tambah use case `Mengelola Pengajuan Inventaris`, `Menyetujui Pengajuan`, `Menolak Pengajuan`, dan `Mengunduh PDF Pengajuan`.
2. Activity Diagram: tambah alur pengajuan inventaris.
3. Sequence Diagram: tambah alur create pengajuan dan approval.
4. Class Diagram: tambah `InventoryRequestsController`, `InventoryRequestModel`, dan `InventoryRequestItemModel`.
5. ERD: tambah tabel `inventory_requests` dan `inventory_request_items`.
6. LRS: tambah struktur record dua tabel baru.

## Screenshot Yang Perlu Ditambahkan

Screenshot sudah tersedia:

1. `screenshot-daftar-pengajuan-inventaris.png`
2. `screenshot-form-pengajuan-inventaris.png`
3. `screenshot-detail-pengajuan-inventaris.png`
4. `screenshot-approval-pengajuan-inventaris.png`
5. `screenshot-pdf-pengajuan-inventaris.png`

## Skenario Black-Box Tambahan

Skenario black-box tambahan dicatat pada:

- `skripsi/03-draft-bab/BLACKBOX-PENGAJUAN-INVENTARIS.md`

## Batasan Penulisan

1. Jangan menyatakan fitur ini menggantikan Surat Masuk.
2. Jangan menyatakan pengajuan otomatis menjadi Surat Keluar.
3. Jangan menyatakan pengajuan peminjaman otomatis menjadi Transaksi Aset.
4. Integrasi surat keluar dan transaksi aset hanya boleh ditulis sebagai saran pengembangan lanjutan.

