# Review Ulang Bab IV dan Audit Bukti

Tanggal: 2026-07-09

## Ruang Lingkup

Dokumen yang ditinjau:

- [skripsi/03-draft-bab/BAB-IV-REVISI-1-EVIDENCEPATCH-3.md](skripsi/03-draft-bab/BAB-IV-REVISI-1-EVIDENCEPATCH-3.md)
- [skripsi/03-draft-bab/BAB-IV-REVISI-1.md](skripsi/03-draft-bab/BAB-IV-REVISI-1.md)
- [skripsi/03-draft-bab/PERFORMANCE-BASIC-OBSERVATION.md](skripsi/03-draft-bab/PERFORMANCE-BASIC-OBSERVATION.md)
- [skripsi/03-draft-bab/USER-DATA-INPUT-ROUND-3.md](skripsi/03-draft-bab/USER-DATA-INPUT-ROUND-3.md)
- Folder screenshot: [skripsi/04-diagram-dan-gambar/screenshots](skripsi/04-diagram-dan-gambar/screenshots)

## Kesimpulan Umum

Bab IV secara struktur sudah sesuai arah outline resmi yang disepakati, khususnya pada pembagian subbab 4.1 Desain, 4.2 Code Generation, 4.3 Testing, dan 4.4 Support. Namun, draft yang ada masih belum sepenuhnya sinkron dengan bukti yang sudah tersedia di workspace.

## Temuan Utama

### 1. Draft masih menampilkan marker yang seharusnya sudah bisa dihapus

Bukti yang ada di workspace menunjukkan bahwa beberapa marker masih tertinggal meskipun bukti sudah tersedia:

- Screenshot untuk halaman manajemen pengguna, transaksi aset, surat masuk, surat keluar, dan cetak laporan sudah ada di folder screenshot.
- File performance observasi sudah ada dan memuat angka waktu respons nyata.
- Data spesifikasi hardware dan software sudah terisi pada dokumen input user.

Karena itu, bagian-bagian yang masih menyatakan marker seperti "[PERLU CEK SCREENSHOT]" atau "[PERLU DATA HASIL PENGUJIAN]" perlu disesuaikan agar tidak bertentangan dengan bukti nyata.

### 2. Screenshot yang dibutuhkan sudah ada di workspace

Berkas screenshot yang terverifikasi ada di folder [skripsi/04-diagram-dan-gambar/screenshots](skripsi/04-diagram-dan-gambar/screenshots):

- [skripsi/04-diagram-dan-gambar/screenshots/screenshot-manajemen-pengguna.png](skripsi/04-diagram-dan-gambar/screenshots/screenshot-manajemen-pengguna.png)
- [skripsi/04-diagram-dan-gambar/screenshots/screenshot-daftar-transaksi-aset.png](skripsi/04-diagram-dan-gambar/screenshots/screenshot-daftar-transaksi-aset.png)
- [skripsi/04-diagram-dan-gambar/screenshots/screenshot-form-tambah-surat-masuk.png](skripsi/04-diagram-dan-gambar/screenshots/screenshot-form-tambah-surat-masuk.png)
- [skripsi/04-diagram-dan-gambar/screenshots/screenshot-form-tambah-surat-keluar.png](skripsi/04-diagram-dan-gambar/screenshots/screenshot-form-tambah-surat-keluar.png)
- [skripsi/04-diagram-dan-gambar/screenshots/screenshot-cetak-laporan.png](skripsi/04-diagram-dan-gambar/screenshots/screenshot-cetak-laporan.png)

Temuan ini membuat status marker screenshot pada draft menjadi tidak akurat jika dibiarkan seperti itu.

### 3. Data pengujian kinerja dasar sudah tersedia

File [skripsi/03-draft-bab/PERFORMANCE-BASIC-OBSERVATION.md](skripsi/03-draft-bab/PERFORMANCE-BASIC-OBSERVATION.md) memuat data waktu respons nyata untuk beberapa proses, yaitu:

- Login: 2.860 ms
- Dashboard: 1.607 ms
- Data Aset: 1.273 ms
- Surat Masuk: 1.200 ms
- Laporan: 1.055 ms
- Backup: 1.013 ms

Dengan demikian, bagian 4.3 Testing seharusnya sudah dapat memakai data ini, bukan menampilkan marker placeholder yang terus-menerus.

### 4. Spesifikasi perangkat sudah cukup kuat untuk dimasukkan

Data spesifikasi hardware dan software yang tercatat pada [skripsi/03-draft-bab/USER-DATA-INPUT-ROUND-3.md](skripsi/03-draft-bab/USER-DATA-INPUT-ROUND-3.md) dapat dipakai untuk memperjelas 4.4.2, antara lain:

- Intel Core i5
- RAM 8 GB
- Penyimpanan 256 GB SSD
- Windows 11
- Google Chrome
- Visual Studio Code
- Laragon 6

### 5. Isi Bab IV masih harus dijaga agar tidak overclaim

Berdasarkan bukti yang ada, yang bisa dinyatakan adalah:

- aplikasi dikembangkan dan diuji pada lingkungan lokal Laragon;
- aplikasi berjalan pada lingkungan lokal dengan bukti halaman yang dapat diakses;
- pengujian bersifat dasar dan tidak boleh diklaim sebagai load testing, stress testing, atau penetration testing.

## Rekomendasi Perbaikan

1. Perbarui tabel antarmuka pada 4.1.3 agar memakai nama file screenshot yang benar-benar ada.
2. Ganti marker pengujian kinerja dengan data dari [skripsi/03-draft-bab/PERFORMANCE-BASIC-OBSERVATION.md](skripsi/03-draft-bab/PERFORMANCE-BASIC-OBSERVATION.md).
3. Perjelas bahwa pengujian kinerja dasar adalah observasi lokal sederhana, bukan benchmark produksi.
4. Pertahankan bahasa yang hati-hati dan tidak mengklaim aplikasi sudah dipublikasikan secara online atau digunakan resmi oleh sekolah.

## Status Akhir

Status review: Bab IV sudah berada pada tahap yang cukup baik secara struktur, tetapi belum sepenuhnya sinkron dengan bukti baru yang ada di workspace. Draft ini masih memerlukan patch kecil agar marker placeholder tidak lagi bertentangan dengan fakta yang sudah tersedia.
