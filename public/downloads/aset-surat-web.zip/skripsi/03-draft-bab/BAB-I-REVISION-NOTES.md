# BAB I REVISION NOTES

Status dokumen: catatan revisi untuk `BAB-I-REVISI-1.md`.

## 1. Bagian Yang Direvisi

Revisi dilakukan pada seluruh BAB I:

1. `1.1. Latar Belakang`.
2. `1.2. Identifikasi Masalah`.
3. `1.3. Perumusan Masalah`.
4. `1.4. Tujuan dan Manfaat`.
5. `1.4.1. Tujuan Penelitian`.
6. `1.4.2. Manfaat Penelitian`.
7. `1.5. Metode Penelitian`.
8. `1.5.1. Teknik Pengumpulan Data`.
9. `1.5.2. Model Pengembangan Sistem`.
10. `1.6. Ruang Lingkup`.

## 2. Alasan Revisi

Revisi dilakukan untuk membuat BAB I lebih konkret terhadap kondisi SMPI REJIS, lebih konsisten dengan fitur aplikasi final, dan lebih sesuai dengan pedoman penulisan. Draft sebelumnya sudah benar secara arah, tetapi masih terlalu umum pada latar belakang dan belum memasukkan keputusan terbaru mengenai pengujian keamanan dasar serta pengujian kinerja dasar.

## 3. Bagian Dari Naskah Lama User Yang Diadopsi

Bagian naskah lama user yang diadopsi setelah dibandingkan dengan transkrip dan audit:

1. Wawancara pada 27 April 2026.
2. Narasumber wawancara: Wakil Kepala Sekolah Bidang Kesiswaan SMPI REJIS, Gilang Ramadhan S.Kom. atau Ust. Gilang.
3. Pencatatan inventaris aset masih manual menggunakan buku.
4. Microsoft Excel pernah dicoba, tetapi tidak berlanjut.
5. Data barang masuk, barang keluar, dan peminjaman aset belum terdokumentasi secara konsisten.
6. Aset belum dikelompokkan secara jelas berdasarkan kategori, lokasi, dan kondisi.
7. Aset yang dipinjam dapat tidak kembali ke tempat semula sehingga menyulitkan pelacakan.
8. Pengelolaan surat masih manual.
9. Surat masuk belum terintegrasi dalam sistem terpusat.
10. Arsip surat tersimpan terpisah.
11. Disposisi belum memiliki mekanisme pemantauan yang terstruktur.

## 4. Bagian Dari Naskah Lama User Yang Tidak Dipakai

Bagian yang tidak dipakai atau disesuaikan:

1. Sitasi `Annisa & Rahayuningsih (2023)` dan `Mubarok & Sutaji (2025)` tidak dipakai sebagai sitasi final karena file referensinya belum ditemukan di folder referensi.
2. Rumusan masalah lama berjumlah tujuh poin dan terlalu rinci; direvisi menjadi lima pertanyaan sesuai arahan user.
3. CodeIgniter 4 dan MySQL/MariaDB tidak dijadikan rumusan masalah utama, melainkan ditempatkan pada tujuan, metode, ruang lingkup, dan nanti BAB IV.
4. Role `Admin TU`, `Kepala Sekolah`, dan `Staff` tidak dipakai sebagai role aplikasi final. Revisi memakai `admin`, `operator`, dan `pimpinan`, dengan catatan padanan operasional sekolah.
5. Uraian Daily Scrum, Sprint Review, Sprint Retrospective, dan Increment tidak ditulis sebagai fakta historis karena bukti rinci pelaksanaan belum tersedia.
6. Klaim sistem sudah efektif, akurat, atau dapat digunakan penuh oleh sekolah dikurangi agar tidak melampaui bukti pengujian lokal.
7. Redaksi yang mengandung typo, istilah tidak baku, dan tanda baca tidak sesuai pedoman diperbaiki.

## 5. Keputusan Terkait Pengujian

Keputusan pengujian yang sudah masuk ke `BAB-I-REVISI-1.md`:

1. *Black-box testing* digunakan sebagai pengujian utama untuk memeriksa fungsi aplikasi berdasarkan input dan output.
2. Pengujian keamanan ditulis sebagai pengujian keamanan dasar, bukan *penetration testing* atau audit keamanan tingkat lanjut.
3. Pengujian keamanan dasar mencakup autentikasi, otorisasi, validasi input, sesi pengguna, unggah file, dan akses halaman.
4. Pengujian kinerja ditulis sebagai pengujian kinerja dasar, bukan *load testing*, *stress testing*, atau benchmark server produksi.
5. Pengujian kinerja dasar dibatasi pada waktu respons halaman dan proses utama pada lingkungan lokal/Laragon.
6. Detail skenario dan hasil pengujian keamanan dasar serta kinerja dasar belum ditulis sebagai hasil final di BAB I karena tempatnya berada pada BAB IV.

## 6. Jumlah Marker Pada BAB-I-REVISI-1.md

Jumlah marker perlu diverifikasi ulang setelah file dibuat:

| Marker | Jumlah |
| --- | --- |
| `[PERLU DATA]` | 1 |
| `[PERLU SITASI]` | 0 |
| `[PERLU CEK REFERENSI]` | 5 |
| `[BELUM DAPAT DIPASTIKAN]` | 0 |

## 7. Bagian BAB I Yang Sudah Kuat

Bagian yang sudah kuat dari sisi arah dan ruang lingkup:

1. Latar belakang sudah lebih spesifik pada SMPI REJIS.
2. Data wawancara utama sudah diverifikasi dari transkrip.
3. Identifikasi masalah sudah konkret dan tidak melebar.
4. Rumusan masalah sudah singkat, berbentuk pertanyaan, dan sesuai arahan user.
5. Tujuan penelitian sudah menjawab rumusan masalah.
6. Manfaat penelitian sudah mencakup penulis, SMPI REJIS, dan pembaca atau peneliti selanjutnya.
7. Ruang lingkup sudah sesuai fitur aplikasi final.
8. ERD sudah ditempatkan sebagai artefak perancangan, bukan fitur operasional.
9. Status deployment sudah dibatasi pada lingkungan lokal/Laragon.

## 8. Bagian Yang Masih Perlu Data

Bagian yang masih memerlukan data:

1. Detail pelaksanaan observasi, termasuk waktu dan bentuk observasi langsung.
2. Profil resmi SMPI REJIS untuk BAB III.
3. Sejarah SMPI REJIS untuk BAB III.
4. Struktur organisasi SMPI REJIS untuk BAB III.
5. Bukti surat riset atau surat keabsahan data bila diperlukan pada lampiran.

## 9. Bagian Yang Masih Perlu Referensi

Bagian yang masih memerlukan referensi:

1. Sistem Informasi berbasis web.
2. Inventaris aset.
3. Pengelolaan surat dan disposisi surat.
4. Agile Scrum.
5. *Black-box testing*, pengujian keamanan dasar, dan pengujian kinerja dasar.
6. Teknologi pendukung yang akan dibahas pada BAB II, seperti MySQL, PHP, CodeIgniter, UML, ERD, dan LRS.

## 10. Kelayakan Lanjut BAB II

BAB I revisi 1 sudah layak secara arah dan ruang lingkup untuk menjadi dasar menuju BAB II, dengan syarat user menyetujui redaksi dan cakupan pengujian terlebih dahulu. BAB II belum boleh dibuat sebelum ada persetujuan user.
