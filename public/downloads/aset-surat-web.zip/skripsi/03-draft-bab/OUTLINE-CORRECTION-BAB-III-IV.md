# OUTLINE CORRECTION BAB III DAN BAB IV

Tanggal dibuat: 2026-07-05

## 1. Status Koreksi

Struktur BAB III dan BAB IV dikoreksi berdasarkan outline resmi yang diberikan dan dikonfirmasi user pada 2026-07-05. Koreksi ini membatalkan struktur BAB III yang sebelumnya disusun pada `BAB-III-DRAFT-PLAN.md` (versi 2026-07-05 awal), yang memakai judul "ANALISIS DAN PERANCANGAN SISTEM" dengan subbab 3.1 sampai 3.7 termasuk Use Case Diagram, Activity Diagram, Sequence Diagram, ERD, LRS, dan Perancangan Antarmuka sebagai bagian BAB III.

## 2. Kesalahan Struktur Sebelumnya

Struktur sebelumnya terlalu mengikuti pola umum analisis dan perancangan sistem. Struktur itu menempatkan diagram dan basis data di BAB III. Setelah user mengonfirmasi outline, penempatan tersebut dikoreksi.

Secara rinci, kesalahan yang dikoreksi:

1. BAB III sebelumnya berjudul "ANALISIS DAN PERANCANGAN SISTEM" dengan 7 subbab (3.1 Tinjauan Institusi, 3.2 Analisis Sistem Berjalan, 3.3 Analisis Kebutuhan Sistem, 3.4 Perancangan Sistem Usulan, 3.5 Perancangan Basis Data, 3.6 Perancangan Antarmuka, 3.7 Rancangan Pengujian). Struktur ini tidak sesuai outline resmi.
2. Use Case Diagram, Activity Diagram, dan Sequence Diagram sebelumnya direncanakan sebagai subbab 3.4 di BAB III. Outline resmi menempatkan diagram tersebut pada 4.1.2 Software Architecture di BAB IV.
3. ERD dan LRS sebelumnya direncanakan sebagai subbab 3.5 di BAB III. Outline resmi menempatkan ERD dan LRS pada 4.1.1 Database di BAB IV.
4. Perancangan Antarmuka (halaman login, dashboard, aset, transaksi, surat masuk, disposisi, surat keluar, laporan) sebelumnya direncanakan sebagai subbab 3.6 di BAB III. Outline resmi menempatkan tampilan halaman aplikasi pada 4.1.3 User Interface di BAB IV.
5. Rancangan Pengujian sebelumnya direncanakan sebagai subbab 3.7 di BAB III. Outline resmi menempatkan black-box testing, pengujian keamanan dasar, dan pengujian kinerja dasar pada 4.3 Testing di BAB IV.

## 3. Struktur BAB III Yang Benar

```text
BAB III
ANALISIS DAN PERANCANGAN APLIKASI

3.1. Tinjauan Perusahaan
     3.1.1. Sejarah Perusahaan
     3.1.2. Struktur Organisasi

3.2. Analisis Aplikasi
     3.2.1. Analisis Masalah
     3.2.2. Analisis Kebutuhan

3.3. Rancangan Algoritma
```

## 4. Struktur BAB IV Yang Benar

```text
BAB IV
IMPLEMENTASI DAN PENGUJIAN SOFTWARE

4.1. Desain
     4.1.1. Database
     4.1.2. Software Architecture
     4.1.3. User Interface

4.2. Code Generation

4.3. Testing

4.4. Support
     4.4.1. Publikasi Software
     4.4.2. Spesifikasi Hardware dan Software
```

## 5. Penempatan Artefak

Artefak | Letak Yang Benar | Catatan
---|---|---
ERD | 4.1.1. Database | Sebelumnya salah ditempatkan sebagai subbab 3.5.1 di BAB III; dikoreksi ke BAB IV.
LRS | 4.1.1. Database | Sebelumnya salah ditempatkan sebagai subbab 3.5.2 di BAB III; dikoreksi ke BAB IV. LRS juga masih bermarker `[PERLU CEK APA 7]` pada BAB II subbab 2.1.11.
Spesifikasi tabel | 4.1.1. Database | Sebelumnya salah ditempatkan sebagai subbab 3.5.3 di BAB III; dikoreksi ke BAB IV.
Use Case Diagram | 4.1.2. Software Architecture | Sebelumnya salah ditempatkan sebagai subbab 3.4.1 di BAB III; dikoreksi ke BAB IV.
Activity Diagram | 4.1.2. Software Architecture | Sebelumnya salah ditempatkan sebagai subbab 3.4.2 di BAB III; dikoreksi ke BAB IV.
Sequence Diagram | 4.1.2. Software Architecture | Sebelumnya salah ditempatkan sebagai subbab 3.4.3 di BAB III; dikoreksi ke BAB IV.
Arsitektur MVC | 4.1.2. Software Architecture | Sebelumnya dicatat sebagai gambar pendukung opsional di luar struktur utama BAB III; kini menjadi bagian resmi 4.1.2 di BAB IV.
Deployment Diagram | 4.1.2. Software Architecture atau 4.4.2. Spesifikasi Hardware dan Software (opsional, bukan subbab utama) | Tidak menjadi subbab utama di BAB III maupun BAB IV; hanya gambar pendukung jika diperlukan.
User Interface | 4.1.3. User Interface | Sebelumnya salah ditempatkan sebagai subbab 3.6 (3.6.1-3.6.8) di BAB III; dikoreksi ke BAB IV.
Code Generation | 4.2. Code Generation | Potongan kode inti atau uraian implementasi kode; tidak diletakkan di BAB III.
Testing | 4.3. Testing | Black-box testing, pengujian keamanan dasar, dan pengujian kinerja dasar. Sebelumnya salah ditempatkan sebagai subbab 3.7 di BAB III; dikoreksi ke BAB IV.
Publikasi Software | 4.4.1. Publikasi Software | Ditulis hati-hati: dikembangkan dan diuji lokal/Laragon; jangan menulis sudah online, produksi, atau resmi digunakan sekolah.
Spesifikasi Hardware dan Software | 4.4.2. Spesifikasi Hardware dan Software | Mencakup kebutuhan PHP, Composer, CodeIgniter 4, MySQL/MariaDB, Laragon, dan spesifikasi hardware; spesifikasi hardware masih `[PERLU DATA]`.

Catatan tambahan: Class Diagram tetap tidak digunakan sebagai subbab utama di BAB III maupun BAB IV.

## 6. Dampak Terhadap Draft Selanjutnya

BAB III dan BAB IV harus mengikuti outline ini. Draft yang bertentangan dengan struktur ini harus direvisi sebelum DOCX. `BAB-III-DRAFT-PLAN.md` dan `BAB-III-DATA-NEEDED.md` sudah diperbarui mengikuti koreksi ini. `BAB-III-IV-STRUCTURE-FINAL-ARAH.md` dibuat sebagai penguncian arah final struktur BAB III dan BAB IV berdasarkan outline resmi.
