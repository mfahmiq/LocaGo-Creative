# REFERENSI BAB II FINAL CHECK

## 1. Status Umum

Referensi BAB II sudah cukup untuk masuk tahap draft awal BAB II, tetapi belum menjadi daftar pustaka final sampai dimasukkan ke Mendeley dan dicek format APA 7.

## 2. Koreksi DOI Mubarok & Sutaji (2025)

Referensi Mubarok & Sutaji (2025) sekarang menggunakan DOI dari halaman resmi jurnal BSI: `10.31294/bianglala.v13i1.12004`. Halaman resmi jurnal BSI menunjukkan DOI tersebut, sedangkan metadata Garuda menampilkan DOI berbeda: `10.31294/bi.v13i1.25238`. Untuk drafting, gunakan DOI dari halaman resmi jurnal BSI dan verifikasi ulang saat input ke Mendeley.

## 3. Status LRS

Subbab 2.1.11 LRS sekarang memiliki penguat awal dan dapat digunakan untuk draft BAB II dengan catatan. LRS dimasukkan sebagai teori pendukung perancangan basis data, dan sumbernya dipastikan berasal dari jurnal aplikasi/perancangan sistem, bukan buku teori utama. Jika nanti ditemukan buku atau sumber akademik yang lebih kuat tentang LRS, sumber tersebut dapat ditambahkan.

## 4. Status Subbab BAB II

No | Subbab | Status | Catatan
---|---|---|---
1 | 2.1.1 Sistem Informasi | SIAP DRAFT | Referensi awal tersedia.
2 | 2.1.2 Website | SIAP DRAFT | Referensi awal tersedia.
3 | 2.1.3 Inventaris Aset | SIAP DRAFT DENGAN CATATAN | Mubarok & Sutaji (2025) DOI halaman resmi jurnal BSI; verifikasi ulang saat Mendeley.
4 | 2.1.4 Surat | SIAP DRAFT | Referensi awal tersedia.
5 | 2.1.5 Disposisi Surat | SIAP DRAFT | Referensi awal tersedia.
6 | 2.1.6 Basis Data MySQL | SIAP DRAFT | Referensi awal tersedia.
7 | 2.1.7 PHP | SIAP DRAFT | Referensi awal tersedia.
8 | 2.1.8 CodeIgniter | SIAP DRAFT | Referensi awal tersedia.
9 | 2.1.9 UML | SIAP DRAFT | Referensi awal tersedia.
10 | 2.1.10 ERD | SIAP DRAFT | Referensi awal tersedia.
11 | 2.1.11 LRS | SIAP DRAFT DENGAN CATATAN | LRS didukung oleh artikel IJIS Wiratama 2024 dan JSAI 2024; sumber aplikasi/perancangan sistem.
12 | 2.1.12 Agile Scrum | SIAP DRAFT | Referensi awal tersedia.
13 | 2.1.13 Black-Box Testing | SIAP DRAFT | Referensi awal tersedia.
14 | 2.2 Penelitian Terkait | SIAP DRAFT DENGAN CATATAN | Semua penelitian terkait dikompilasi, beberapa masih memerlukan verifikasi metadata saat input Mendeley.

## 5. Referensi Yang Jangan Dipakai

JANGAN PAKAI DULU:

1. Sistem, n.d.
2. Literasi & Indonesia, n.d.
3. PENGANTAR JARINGAN KOMPUTER, n.d.
4. I, 2015
5. Tri et al., n.d.
6. Jogiyanto 1995
7. Subtari atau Sutabri 2005
8. Gordon 1995

## 6. Rekomendasi Tahap Berikutnya

Tahap berikutnya adalah membuat `BAB-II-REVISI-1.md` sebagai draft awal BAB II berdasarkan referensi yang sudah diverifikasi. Draft BAB II tetap belum disebut final sampai seluruh sitasi, daftar pustaka, dan format APA 7 diperiksa.
