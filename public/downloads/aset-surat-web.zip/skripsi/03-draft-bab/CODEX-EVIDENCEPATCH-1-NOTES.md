# CODEX EVIDENCEPATCH 1 NOTES

Tanggal dibuat: 2026-07-05

## 1. Status

Patch ini seharusnya menyelesaikan marker berdasarkan bukti verifikasi aplikasi baru dan screenshot baru yang diklaim dibuat oleh Codex. Namun, hasil rekonsiliasi menunjukkan **tidak ada bukti baru** yang benar-benar tersimpan di workspace pada 2026-07-05 — ketiga berkas verifikasi (`APPLICATION_VERIFICATION.md`, `BLACKBOX_TEST_SCENARIOS.md`, `BAB_IV_EVIDENCE_READINESS.md`) dan folder screenshot terbukti tidak berubah sejak 2026-07-04 (dikonfirmasi lewat timestamp berkas). Sesuai batasan wajib untuk tidak mengarang data, **tidak ada marker yang diselesaikan pada patch ini**.

## 2. Data Yang Digunakan

Tidak ada data baru. Rincian rekonsiliasi:

1. **Verifikasi aplikasi**: isi `APPLICATION_VERIFICATION.md` yang tersedia (tidak berubah) mengonfirmasi database terkoneksi, login demo berhasil, 17 modul/route terverifikasi HTTP 200 setelah login, dan pembatasan role bekerja. Informasi ini sudah dipakai sebagai dasar BAB IV sejak versi-versi sebelumnya.
2. **Black-box testing**: `BLACKBOX_TEST_SCENARIOS.md` mencatat dua checkpoint berurutan — 23 valid/19 belum diverifikasi (checkpoint awal) dan 42 valid/0 gagal/0 belum diverifikasi (checkpoint setelah pengujian CRUD terkontrol). Checkpoint terbaru (42 valid) tetap dipakai karena tidak digantikan oleh data yang lebih baru.
3. **Screenshot**: folder `skripsi/04-diagram-dan-gambar/screenshots/` tetap berisi 22 berkas yang sama, seluruhnya bertimestamp 2026-07-04. Klaim "10 screenshot baru" tidak dapat diverifikasi.
4. **Data yang tetap tidak tersedia**: pengujian kinerja dasar (waktu respons) dan data sekolah, keduanya di luar cakupan rekonsiliasi Codex kali ini.

## 3. Marker Yang Selesai

No | BAB | Marker Lama | Data Pendukung | Status
---|---|---|---|---
- | - | Tidak ada marker yang diselesaikan pada patch ini | Tidak ditemukan bukti baru di workspace | TIDAK ADA PERUBAHAN

## 4. Marker Yang Masih Tersisa

No | BAB | Marker | Alasan Belum Selesai | Data Yang Dibutuhkan
---|---|---|---|---
1 | I | `[PERLU DATA]` (1.5.1 Observasi) | Dinyatakan "BELUM ADA"; di luar cakupan rekonsiliasi Codex | Data observasi nyata
2 | III | `[PERLU DATA]` (3.1 — profil resmi) | Dinyatakan "BELUM ADA" | Profil resmi SMPI REJIS
3 | III | `[PERLU DATA]` (3.1.1 — sejarah) | Dinyatakan "BELUM ADA" | Sejarah singkat SMPI REJIS
4 | III | `[PERLU DATA]` (3.1.2 — struktur organisasi) | Dinyatakan "BELUM ADA" | Bagan organisasi resmi
5-9 | IV | `[PERLU CEK SCREENSHOT]` x5 (4.1.3 User Interface) | Folder screenshot tidak bertambah; klaim 10 file baru tidak terverifikasi | Screenshot nyata untuk manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, cetak laporan
10-16 | IV | `[PERLU DATA HASIL PENGUJIAN]` x7 (4.3 Pengujian Kinerja Dasar) | Data waktu respons tidak tersedia | Angka waktu respons nyata untuk 6 proses
17 | II | `[PERLU CEK APA 7]` (2.1.11 LRS) | Di luar cakupan rekonsiliasi ini | Verifikasi Mendeley/APA 7
18-19 | V | `[PERLU CEK SETELAH BAB IV FINAL]` x2 (5.1 Kesimpulan) | Bergantung pada penyelesaian marker BAB IV di atas | Penyelesaian marker BAB IV nomor 5-16

## 5. Risiko

1. Data yang belum diisi (screenshot, waktu respons, data sekolah) tetap membutuhkan konfirmasi user yang benar-benar baru.
2. Screenshot yang tidak ditemukan tidak boleh dianggap tersedia — pengecekan ulang folder pada 2026-07-05 mengonfirmasi kembali kondisi sebelumnya, tidak berubah.
3. Data pengujian kinerja yang tidak diisi tidak boleh dikarang.
4. Mendeley APA 7 belum final untuk seluruh referensi BAB II.
5. BAB V tetap perlu direview setelah BAB IV benar-benar final; tidak ada perubahan pada BAB V karena BAB IV belum selesai.
6. DOCX final belum boleh dibuat karena 19 marker masih tersisa, ditambah kebutuhan verifikasi Mendeley/APA 7 dan format akhir DOCX resmi.
7. **Risiko koordinasi**: jika Codex benar-benar sudah melakukan pekerjaan baru (verifikasi aplikasi dan 10 screenshot) tetapi hasilnya belum tersimpan ke workspace ini, perlu ada langkah sinkronisasi manual sebelum rekonsiliasi berikutnya, agar bukti yang sama tidak dicek berulang kali tanpa hasil.
