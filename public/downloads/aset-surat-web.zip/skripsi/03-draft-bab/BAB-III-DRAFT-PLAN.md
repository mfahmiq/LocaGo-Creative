# BAB III DRAFT PLAN

Tanggal dibuat: 2026-07-05
Terakhir diperbarui: 2026-07-05 (revisi koreksi outline BAB III/BAB IV)

## 0. Catatan Koreksi

Pada 2026-07-05, versi awal file ini menggunakan struktur BAB III berjudul "ANALISIS DAN PERANCANGAN SISTEM" dengan subbab 3.1 Tinjauan Institusi sampai 3.7 Rancangan Pengujian, termasuk Use Case Diagram, Activity Diagram, Sequence Diagram, ERD, LRS, dan Perancangan Antarmuka sebagai bagian BAB III. Struktur tersebut **DIBATALKAN** setelah user mengonfirmasi outline resmi. Lihat `OUTLINE-CORRECTION-BAB-III-IV.md` dan `BAB-III-IV-STRUCTURE-FINAL-ARAH.md` untuk detail koreksi lengkap.

Seluruh isi file ini sudah direvisi mengikuti struktur resmi terbaru: BAB III = **ANALISIS DAN PERANCANGAN APLIKASI** (3.1 Tinjauan Perusahaan, 3.2 Analisis Aplikasi, 3.3 Rancangan Algoritma). Diagram teknis (Use Case, Activity, Sequence), ERD, LRS, User Interface, Code Generation, dan Testing tidak lagi menjadi bagian BAB III — seluruhnya menjadi bagian BAB IV sesuai outline resmi.

## 1. Status

File ini adalah rencana penyusunan BAB III, bukan naskah BAB III final. Isi BAB III belum ditulis pada tahap ini. Rencana disusun berdasarkan `BAB-I-FINAL-ARAH.md`, `BAB-II-FINAL-ARAH.md`, `BAB-I-II-CONSISTENCY-CHECK.md`, `BAB-I-II-READY-FOR-BAB-III.md`, `OUTLINE-CORRECTION-BAB-III-IV.md`, `BAB-III-IV-STRUCTURE-FINAL-ARAH.md`, serta audit aplikasi dan database yang tersedia di `skripsi/02-data-aplikasi/` dan `skripsi/04-diagram-dan-gambar/`.

Catatan sumber: file bernama persis `APP_AUDIT.md` dan `DATABASE_AUDIT.md` BELUM ADA di `skripsi/02-data-aplikasi/`. Sebagai gantinya, folder tersebut berisi `APLIKASI_FEATURE_AUDIT.md` (setara audit fitur aplikasi) dan `DATABASE_ERD_AUDIT.md` (setara audit database/ERD), sehingga kedua file itu yang dipakai sebagai sumber pada rencana ini.

## 2. Arah BAB III

BAB III diarahkan untuk menjelaskan tinjauan perusahaan/institusi (SMPI REJIS), analisis aplikasi (masalah dan kebutuhan), dan rancangan algoritma alur logika fitur utama aplikasi terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS. BAB III tidak lagi memuat diagram teknis (Use Case, Activity, Sequence), ERD, LRS, atau Perancangan Antarmuka — seluruh artefak tersebut dipindahkan ke BAB IV sesuai outline resmi.

## 3. Struktur Resmi BAB III

```text
BAB III
ANALISIS DAN PERANCANGAN APLIKASI

3.1. Tinjauan Perusahaan
     3.1.1. Sejarah Perusahaan
     3.1.2. Struktur Organisasi

3.2. Analisis Aplikasi
     3.2.1. Analisis Masalah
     3.2.2. Analisis Kebutuhan

3.3. Rancangan Algoritma
```

Catatan:

1. Struktur ini menggantikan struktur sebelumnya (3.1 Tinjauan Institusi sampai 3.7 Rancangan Pengujian) yang **DIBATALKAN**.
2. ERD, LRS, dan spesifikasi tabel dipindahkan ke BAB IV 4.1.1 Database.
3. Use Case Diagram, Activity Diagram, Sequence Diagram, dan Arsitektur MVC dipindahkan ke BAB IV 4.1.2 Software Architecture.
4. Perancangan Antarmuka/tampilan halaman aplikasi dipindahkan ke BAB IV 4.1.3 User Interface.
5. Rancangan Pengujian (black-box testing, pengujian keamanan dasar, pengujian kinerja dasar) dipindahkan ke BAB IV 4.3 Testing.
6. Class Diagram dan Deployment Diagram tetap bukan subbab utama, baik di BAB III maupun di BAB IV. Deployment Diagram hanya boleh menjadi gambar pendukung opsional pada BAB IV 4.1.2 atau 4.4.2.
7. "Tinjauan Perusahaan" pada outline resmi diisi dengan konteks SMPI REJIS sebagai objek penelitian, bukan perusahaan komersial.

## 4. Mapping BAB I ke BAB III

No | Masalah BAB I | Bagian BAB III Yang Menjawab | Catatan
---|---|---|---
1 | Inventaris manual | 3.2.1 Analisis Masalah | Kondisi manual dijelaskan sebagai bagian analisis masalah, bukan pada subbab "prosedur sistem berjalan" terpisah seperti rencana sebelumnya yang dibatalkan.
2 | Riwayat barang masuk, barang keluar, dan peminjaman belum konsisten | 3.2.1 Analisis Masalah; 3.2.2 Analisis Kebutuhan | Detail tabel transaksi aset (implementasi database) dibahas di BAB IV 4.1.1 Database, bukan di BAB III.
3 | Kategori, lokasi, dan kondisi aset belum terstruktur | 3.2.1; 3.2.2 | Detail struktur tabel `asset_categories`/`asset_locations` dibahas di BAB IV 4.1.1 Database.
4 | Lokasi dan status aset sulit dipantau | 3.2.1; 3.2.2 | Alur proses detail (activity diagram) dibahas di BAB IV 4.1.2 Software Architecture.
5 | Surat masuk masih manual | 3.2.1; 3.2.2 | -
6 | Arsip surat tersimpan terpisah | 3.2.1; 3.2.2 | Detail tabel `incoming_letters`/`outgoing_letters` dibahas di BAB IV 4.1.1 Database.
7 | Disposisi belum termonitor | 3.2.1; 3.2.2 | Alur disposisi (activity/sequence diagram) dibahas di BAB IV 4.1.2 Software Architecture.

## 5. Mapping Fitur ke BAB III

No | Fitur Final | Subbab BAB III | Catatan
---|---|---|---
1 | Login atau autentikasi | 3.2.2 Analisis Kebutuhan (kebutuhan autentikasi per role); 3.3 Rancangan Algoritma (alur logika login) | Detail Use Case/Activity/Sequence Diagram login dipindahkan ke BAB IV 4.1.2.
2 | Dashboard | 3.2.2 Analisis Kebutuhan | Tampilan dashboard dipindahkan ke BAB IV 4.1.3 User Interface.
3 | Manajemen pengguna | 3.2.2 Analisis Kebutuhan (kebutuhan berdasarkan role admin, operator, pimpinan) | -
4 | Inventaris aset | 3.2.1; 3.2.2; 3.3 Rancangan Algoritma (alur logika pencatatan dan pencarian aset) | Struktur tabel dan diagram detail dipindahkan ke BAB IV.
5 | Transaksi atau peminjaman aset | 3.2.1; 3.2.2; 3.3 (alur logika peminjaman dan pengembalian) | -
6 | Surat masuk | 3.2.1; 3.2.2; 3.3 (alur logika pencatatan surat masuk) | -
7 | Disposisi surat | 3.2.1; 3.2.2; 3.3 (alur logika disposisi) | -
8 | Surat keluar | 3.2.1; 3.2.2; 3.3 (alur logika surat keluar) | -
9 | Laporan | 3.2.2 Analisis Kebutuhan | Tampilan/detail laporan dipindahkan ke BAB IV 4.1.3.
10 | Backup | 3.2.2 Analisis Kebutuhan (kebutuhan nonfungsional keberlanjutan data) | Detail implementasi backup dipindahkan ke BAB IV.

## 6. Diagram Dan Artefak Teknis — Dipindahkan Ke BAB IV

BAB III tidak memuat diagram teknis utama seperti ERD, LRS, Use Case Diagram, Activity Diagram, Sequence Diagram, Arsitektur MVC, atau tampilan antarmuka. Seluruh artefak tersebut sudah tersedia sebagai file lokal di `skripsi/04-diagram-dan-gambar/` dan direncanakan menjadi bagian BAB IV. Tabel penempatan lengkap dicatat pada `OUTLINE-CORRECTION-BAB-III-IV.md` bagian 5 (Penempatan Artefak). Rencana BAB IV secara rinci (termasuk status file diagram per subbab 4.1.1-4.1.3) belum dibuat sebagai file terpisah dan menjadi langkah berikutnya setelah struktur ini disetujui.

## 7. Data Yang Bisa Dipakai

Data yang sudah tersedia dari BAB I dan file audit dan dapat dipakai sebagai dasar penulisan BAB III nanti:

1. Wawancara 27 April 2026.
2. Narasumber Gilang Ramadhan S.Kom. atau Ust. Gilang.
3. Inventaris masih manual.
4. Microsoft Excel pernah dicoba tetapi tidak berlanjut.
5. Surat dan disposisi masih manual.
6. Aplikasi menggunakan CodeIgniter 4, PHP, MySQL/MariaDB, dan Laragon lokal.
7. Role final aplikasi adalah admin, operator, dan pimpinan.
8. Fitur final aplikasi sudah ditetapkan.

Data pendukung tambahan yang sudah tersedia dari audit aplikasi (`APLIKASI_FEATURE_AUDIT.md`), relevan untuk 3.2.1 Analisis Masalah dan 3.2.2 Analisis Kebutuhan:

1. Daftar route, controller, model, dan view per modul (autentikasi, dashboard, pengguna, aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, backup).
2. Alur fungsional per modul sebagaimana dicatat pada `APLIKASI_FEATURE_AUDIT.md` (misalnya alur manajemen aset, alur transaksi/peminjaman, alur surat masuk, alur disposisi, alur surat keluar, alur laporan, fitur backup) — dapat menjadi dasar 3.3 Rancangan Algoritma tanpa perlu menyertakan diagram teknis di BAB III.

Jangan mengarang profil sekolah, sejarah sekolah, struktur organisasi, atau data lain yang belum tersedia.

## 8. Risiko Draft BAB III

1. Profil resmi SMPI REJIS belum lengkap untuk 3.1.1 Sejarah Perusahaan.
2. Struktur organisasi SMPI REJIS belum tersedia untuk 3.1.2 Struktur Organisasi.
3. Bukti observasi detail belum lengkap, memengaruhi kekuatan 3.2.1 Analisis Masalah.
4. 3.3 Rancangan Algoritma harus menjelaskan alur logika fitur berdasarkan bukti nyata dari route/controller/model aplikasi (`APLIKASI_FEATURE_AUDIT.md`), bukan alur yang dikarang atau algoritma generik yang tidak dipakai aplikasi (misalnya algoritma pencarian/sorting teoritis yang tidak relevan).
5. Jangan klaim aplikasi sudah online atau produksi pada bagian mana pun di BAB III.
6. Jangan menambahkan Class Diagram atau Deployment Diagram sebagai subbab utama di BAB III maupun BAB IV.
7. Jangan memasukkan kembali Use Case Diagram, Activity Diagram, Sequence Diagram, ERD, LRS, atau Perancangan Antarmuka ke BAB III — seluruhnya sudah dipindahkan ke BAB IV per koreksi outline 2026-07-05.

## 9. Rekomendasi

BAB III boleh mulai ditulis setelah user atau Maestro menyetujui struktur resmi pada `BAB-III-IV-STRUCTURE-FINAL-ARAH.md` dan rencana pada file ini. Bagian yang belum memiliki data (sejarah perusahaan, struktur organisasi) harus diberi marker `[PERLU DATA]`, bukan dikarang. Rencana BAB IV yang lebih rinci (pemetaan artefak per subbab 4.1.1-4.4.2) disarankan dibuat sebagai langkah berikutnya sebelum BAB III maupun BAB IV ditulis penuh.
