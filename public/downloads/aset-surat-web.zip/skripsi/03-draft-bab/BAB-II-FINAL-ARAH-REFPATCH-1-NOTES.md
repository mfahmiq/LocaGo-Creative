# BAB II FINAL ARAH REFPATCH 1 NOTES

Tanggal dibuat: 2026-07-05

## 1. Status

File ini adalah patch referensi BAB II untuk memenuhi kebutuhan minimal 10 jurnal sesuai pedoman UBSI (`PEDOMAN_AUDIT.md` bagian Aturan Daftar Pustaka Dan Sitasi, poin 5: "Laporan Skripsi mensitasi minimal 10 jurnal"). Patch ini menghasilkan `BAB-II-FINAL-ARAH-REFPATCH-1.md` sebagai kandidat BAB II terbaru, berdasarkan `BAB-II-FINAL-ARAH.md` tanpa mengubah strukturnya.

## 2. Perubahan

1. Menambahkan sitasi Usnaini, Yasin, dan Sianipar (2021) pada 2.1.3 Inventaris Aset, ditambahkan setelah kalimat Mubarok dan Sutaji (2025) dan sebelum kalimat penutup subbab tentang SMPI REJIS, menjelaskan bahwa pengelolaan inventaris manual dapat menimbulkan kendala pencarian data, kelengkapan arsip, dan penyusunan laporan, sehingga sistem informasi inventarisasi aset berbasis web diperlukan.
2. Menambahkan paragraf Usnaini, Yasin, dan Sianipar (2021) pada 2.2 Penelitian Terkait, diletakkan setelah paragraf Mubarok dan Sutaji (2025) dan sebelum paragraf Siswaya dan Setiawan (2025), menjelaskan objek penelitian (SDN Rawamangun 09), permasalahan, dan relevansi/perbedaan dengan penelitian ini.
3. Tidak mengubah struktur BAB II — tetap 2.1 Tinjauan Pustaka (2.1.1 sampai 2.1.13) dan 2.2 Penelitian Terkait.
4. Tidak membuat daftar pustaka final; sitasi ditulis dalam naskah dengan format nama-tahun, bukan sebagai entri daftar pustaka APA 7 lengkap.

## 3. Marker Tersisa

Marker | Jumlah | Lokasi
---|---|---
`[PERLU CEK APA 7]` | 1 | Subbab 2.1.11 LRS — tidak dihapus, tetap sama seperti pada `BAB-II-FINAL-ARAH.md` karena sumber LRS (Wiratama 2024, JSAI 2024) masih penguat awal, bukan buku teori utama
`[PERLU DATA]` | 0 | -
`[PERLU SITASI]` | 0 | -
`[PERLU CEK REFERENSI]` | 0 | -

Total marker pada `BAB-II-FINAL-ARAH-REFPATCH-1.md`: 1, tidak berubah dari jumlah marker pada `BAB-II-FINAL-ARAH.md`.

## 4. Risiko

1. Semua referensi, termasuk Usnaini, Yasin, dan Sianipar (2021), tetap perlu dicek dan dimasukkan ke Mendeley sebelum daftar pustaka final disusun.
2. Format APA 7 pada naskah BAB II (termasuk sitasi baru ini) belum final mutlak; format sitasi dalam kurung dan urutan nama pengarang perlu diverifikasi ulang saat proses Mendeley.
3. Marker `[PERLU CEK APA 7]` pada LRS tetap perlu dibereskan; penambahan referensi Usnaini, Yasin, dan Sianipar (2021) tidak mengubah status subbab 2.1.11 karena topiknya berbeda (inventaris aset, bukan LRS).
4. Referensi Usnaini, Yasin, dan Sianipar (2021) diterima sebagai referensi yang sudah diverifikasi oleh Maestro sesuai instruksi kerja; metadata (DOI, volume, nomor, halaman) tidak diubah dan tidak ditambah pada patch ini.
