# REFERENSI BAB II WORKSPACE SCAN

## 1. Status Folder Referensi

Folder `skripsi/06-referensi/` ada, tetapi kosong. Tidak ada file referensi lokal yang ditemukan di dalam folder tersebut pada saat pemeriksaan.

## 2. Daftar File Referensi Lokal

Tidak ada file referensi lokal yang ditemukan di folder `skripsi/06-referensi/`.

No | Nama File | Lokasi | Jenis File | Dugaan Topik | Status Awal | Catatan
---|---|---|---|---|---|---

## 3. Referensi Yang Disebut Pada BAB II Lama

No | Referensi Disebut | Ada File Lokal? | Status | Catatan
---|---|---|---|---
1 | Annisa dkk. (2023) | Tidak | BELUM ADA FILE | Folder referensi kosong.
2 | Mubarok dan Sutaji (2025) | Tidak | BELUM ADA FILE | Folder referensi kosong.
3 | Siswaya dan Setiawan (2025) | Tidak | BELUM ADA FILE | Folder referensi kosong.
4 | Pranoto dan Sediyono (2021) | Tidak | BELUM ADA FILE | Folder referensi kosong.
5 | Rohmawati (2025) | Tidak | BELUM ADA FILE | Folder referensi kosong.
6 | Londa dkk. (2022) | Tidak | BELUM ADA FILE | Folder referensi kosong.
7 | Sistem, n.d. | Tidak | BELUM ADA FILE | Folder referensi kosong.
8 | Literasi & Indonesia, n.d. | Tidak | BELUM ADA FILE | Folder referensi kosong.
9 | PENGANTAR JARINGAN KOMPUTER, n.d. | Tidak | BELUM ADA FILE | Folder referensi kosong.
10 | I, 2015 | Tidak | BELUM ADA FILE | Folder referensi kosong.
11 | Tri et al., n.d. | Tidak | BELUM ADA FILE | Folder referensi kosong.
12 | Jogiyanto 1995 | Tidak | BELUM ADA FILE | Folder referensi kosong.
13 | Subtari/Sutabri 2005 | Tidak | BELUM ADA FILE | Folder referensi kosong.
14 | Gordon 1995 | Tidak | BELUM ADA FILE | Folder referensi kosong.

## 4. Catatan Penting

Referensi belum boleh dipakai sebagai sitasi final sebelum metadata sumber diverifikasi. Jangan membuat nama jurnal, DOI, URL, volume, nomor, halaman, atau daftar pustaka jika sumber belum tersedia.
