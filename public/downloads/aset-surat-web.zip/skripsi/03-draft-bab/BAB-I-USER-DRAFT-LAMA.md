# BAB I

# PENDAHULUAN

> Status: naskah BAB I lama milik user sebagai bahan pembanding/revisi, bukan versi final.

## 1.1 Latar Belakang Masalah
Pengelolaan administrasi di lingkungan sekolah mencakup berbagai aktivitas penting, di antaranya pencatatan inventaris aset dan pengelolaan surat. Kedua aktivitas tersebut memiliki peran strategis dalam menjaga ketertiban data, kelancaran operasional, serta mendukung akuntabilitas administrasi di lingkungan sekolah.
Seiring dengan berkembangnya pemanfaatan teknologi informasi di bidang pendidikan, penerapan sistem informasi berbasis web dinilai mampu meningkatkan efisiensi dan akurasi dalam pengelolaan data. Sistem berbasis web memungkinkan penyimpanan data secara terpusat, mempermudah akses informasi, serta mendukung proses pelaporan yang lebih cepat dan terstruktur. Hal ini sejalan dengan penelitian yang menyatakan bahwa sistem informasi berbasis web dapat membantu proses pengelolaan data menjadi lebih efektif, akurat, dan mudah diakses kapan saja (Annisa & Rahayuningsih, 2023).
Selain itu, penerapan sistem informasi dalam pengelolaan aset juga terbukti mampu meningkatkan efisiensi kerja serta mengurangi kesalahan pencatatan yang sering terjadi pada sistem manual. Pengelolaan aset berbasis sistem memungkinkan data tersimpan secara terintegrasi sehingga memudahkan proses monitoring, pelaporan, serta pengambilan keputusan yang lebih tepat (Mubarok & Sutaji, 2025).
Digitalisasi administrasi tidak hanya terbatas pada pengelolaan aset, tetapi juga mencakup pengelolaan surat, khususnya proses disposisi surat. Sistem disposisi surat berbasis digital memungkinkan proses distribusi informasi dilakukan secara lebih cepat serta memudahkan pemantauan status tindak lanjut surat secara real-time. Dengan adanya sistem tersebut, setiap proses administrasi surat dapat terdokumentasi dengan baik sehingga meminimalisir keterlambatan dan kehilangan informasi.
Berdasarkan hasil wawancara yang dilakukan pada tanggal 27 April 2026 dengan Wakil Kepala Sekolah Bidang Kesiswaan di SMPI REJIS, diketahui bahwa pengelolaan inventaris aset masih dilakukan secara manual menggunakan buku. Meskipun pernah dilakukan percobaan pencatatan menggunakan Microsoft Excel, namun penggunaannya tidak berlanjut. Kondisi ini menyebabkan data barang masuk, barang keluar, serta peminjaman aset belum terdokumentasi secara konsisten.
Selain itu, pencatatan aset belum dilengkapi dengan pengelompokan yang jelas berdasarkan kategori, lokasi, maupun kondisi barang. Hal ini berdampak pada kesulitan dalam proses pencarian data serta pengawasan aset. Dalam praktiknya, sering terjadi aset yang telah dipinjam tidak dikembalikan ke tempat semula, sehingga menyulitkan dalam pelacakan keberadaan barang.
Pada sisi lain, pengelolaan surat di SMPI REJIS juga masih dilakukan secara manual. Pencatatan surat masuk belum terintegrasi dalam suatu sistem yang terpusat, sehingga arsip surat tersimpan secara terpisah. Kondisi ini menyulitkan dalam proses pencarian kembali dokumen serta dalam memantau status tindak lanjut surat. Proses disposisi surat yang dilakukan oleh kepala sekolah dan wakil kepala sekolah kepada staf juga belum memiliki mekanisme monitoring yang terstruktur.
Berdasarkan permasalahan tersebut, diperlukan suatu solusi berupa sistem informasi terintegrasi yang mampu mengelola inventaris aset dan disposisi surat dalam satu platform berbasis web. Sistem ini dirancang untuk membantu proses pencatatan aset, pengelolaan peminjaman, pengarsipan surat, serta proses disposisi secara lebih terstruktur dan terdokumentasi.
Dengan adanya sistem ini, diharapkan proses administrasi di SMPI REJIS menjadi lebih efektif, data tersimpan secara terpusat, serta memudahkan dalam proses pencarian dan pembuatan laporan. Selain itu, sistem ini juga diharapkan mampu meningkatkan kontrol terhadap aset serta memastikan setiap surat dapat ditindaklanjuti secara tepat dan terpantau.
## 1.2 Identifikasi Permasalahan
Berdasarkan latar belakang masalah yang telah diuraikan, maka dapat diidentifikasi beberapa permasalahan yang terdapat di SMPI REJIS sebagai berikut:
1. Proses pencatatan inventaris aset masih dilakukan menggunakan buku sehingga pencarian data membutuhkan waktu yang lama dan berpotensi terjadi kesalahan pencatatan.
2. Data barang masuk, barang keluar, dan peminjaman aset belum terdokumentasi secara konsisten sehingga menyulitkan dalam pelacakan riwayat penggunaan aset.
3. Tidak adanya pengelompokan aset berdasarkan kategori, lokasi, dan kondisi menyebabkan kesulitan dalam pengawasan serta pengelolaan aset secara terstruktur.
4. Sulitnya mengetahui lokasi aset secara akurat karena tidak adanya sistem yang dapat memantau pergerakan aset.
5. Proses pencatatan surat masuk masih dilakukan secara manual sehingga berisiko terjadi kehilangan data dan keterlambatan pengolahan informasi.
6. Arsip surat disimpan secara terpisah sehingga menyulitkan dalam pencarian kembali dokumen.
7. Tidak adanya sistem pemantauan disposisi surat menyebabkan tindak lanjut surat tidak terkontrol dengan baik.
## 1.3 Perumusan Masalah
Berdasarkan identifikasi permasalahan yang telah diuraikan, maka rumusan masalah dalam penelitian ini adalah:
1. Bagaimana merancang sistem inventaris aset berbasis web yang dapat membantu proses pencatatan aset di SMPI REJIS agar lebih terstruktur, cepat, dan meminimalisir kesalahan pencatatan ?
2. Bagaimana merancang sistem yang mampu mendokumentasikan data barang masuk, barang keluar, dan peminjaman aset secara konsisten agar riwayat penggunaan aset dapat ditelusuri dengan mudah ?
3. Apakah sistem yang dirancang dapat membantu pengelompokan aset berdasarkan kategori, lokasi, dan kondisi barang agar pengawasan aset dapat dilakukan secara terstruktur ?
4. Mengapa sistem pemantauan pergerakan aset diperlukan agar pihak sekolah dapat mengetahui lokasi dan status aset secara lebih akurat ?
5. Bagaimana merancang sistem pencatatan surat masuk secara digital agar risiko kehilangan data dan keterlambatan pengolahan informasi dapat diminimalisir ?
6. Bagaimana merancang sistem pengarsipan surat yang terpusat agar proses pencarian kembali dokumen dapat dilakukan secara mudah dan cepat ?
7. Mengapa sistem pemantauan disposisi surat berbasis web diperlukan agar tindak lanjut setiap surat di SMPI REJIS dapat terkontrol dan terpantau dengan baik ?
## 1.4 Tujuan Dan Manfaat
### 1.4.1	Tujuan Penelitian
Maksud dari penulisan skripsi ini adalah membangun sistem informasi terintegrasi berbasis web yang mampu mengelola inventaris aset dan disposisi surat di SMPI REJIS secara digital, terpusat, dan terstruktur, sehingga dapat meningkatkan efektivitas dan efisiensi proses administrasi sekolah.
Tujuan dari penulisan skripsi ini adalah:
1. Mengidentifikasi permasalahan dalam pengelolaan inventaris aset dan disposisi surat di SMPI REJIS.
2. Menganalisis kebutuhan sistem informasi yang sesuai dengan proses administrasi sekolah.
3. Merancang sistem inventaris aset berbasis web yang mencakup pengelolaan data aset, kategori, lokasi, peminjaman, dan pengembalian aset.
4. Merancang sistem disposisi surat berbasis web yang mencakup pencatatan surat masuk, proses disposisi, dan pemantauan status tindak lanjut surat.
5. Mengintegrasikan sistem inventaris aset dan disposisi surat dalam satu platform berbasis web yang dapat diakses oleh Admin TU, Kepala Sekolah, dan Staff sesuai hak akses masing-masing.
6. Menerapkan metode Agile Scrum dalam proses pengembangan sistem agar pembangunan aplikasi dapat dilakukan secara bertahap, terarah, dan menyesuaikan kebutuhan pengguna.
7. Melakukan pengujian sistem melalui pengujian fungsional, keamanan, dan kinerja untuk memastikan sistem dapat berjalan sesuai kebutuhan pengguna.
### 1.4.2	Manfaat Penelitian
1. Manfaat bagi penulis
   a. Menambah pemahaman dan keterampilan dalam perancangan sistem informasi berbasis web.
   b. Mengembangkan kemampuan implementasi teknologi dalam menyelesaikan permasalahan nyata di lingkungan pendidikan.
   c. Sebagai salah satu syarat kelulusan program sarjana pada Program Studi Teknologi Informasi Universitas Binsa Sarana Informatika
2. Manfaat bagi Objek Penelitian
   a. Membantu sekolah dalam pengelolaan inventaris aset secara lebih terstruktur, terpusat, dan mudah dipantau.
   b. Mempermudah proses pencatatan, pengarsipn surat masuk, serta pelaksanaan disposisi surat secara digital.
   c. Mempercepat proses pencarian data asset dan surat yang dibutuhkan
   d. Meningkatkan efisiensi dan akurasi administrasi sekolah secara keseluruhan
   e. Membantu pihak sekolah dalam memantau status aset dan tindak lanjut surat secara lebih terkontrol
3. Manfaat bagi Pembaca
   a. Memberikan referensi dan gambaran mengenai perancangan sistem informasi administrasi berbasis web di lingkungan sekolah.
   b. Memberikan pemahaman mengenai penerapan sistem informasi terintegrasi dalam mendukung kegiatan administrasi sekolah.
   c. Memberikan gambaran mengenai penerapan metode Agile Scrum dalam pengembangan aplikasi berbasis web.


## 1.5 Metode Penelitian
Metode penelitian yang digunakan dalam penulisan skripsi ini bertujuan untuk memperoleh data yang akurat serta mendukung proses perancangan sistem yang sesuai dengan kebutuhan pengguna. Metode yang digunakan meliputi teknik pengumpulan data dan model pengembangan perangkat lunak.
### 1.5.1	Teknik Pengumpulan Data
1. Observasi
Observasi dilakukan secara langsung di SMPI REJIS untuk memahami proses administrasi yang sedang berjalan, khususnya pada pengelolaan inventaris aset dan pengelolaan surat. Observasi tidak langsung juga dilakukan dengan mempelajari aplikasi sejenis yang telah ada guna memperoleh gambaran fitur dan alur sistem yang relevan. Dari hasil observasi, ditemukan bahwa pencatatan inventaris aset masih menggunakan buku dan lembar manual, sementara arsip surat masuk disimpan secara terpisah tanpa sistem yang terintegrasi. Kondisi tersebut menjadi dasar utama dalam penentuan kebutuhan sistem yang akan dirancang.
2. Wawancara
Wawancara dilakukan dengan Wakil Kepala Sekolah Bidang Kesiswaan SMPI REJIS, yaitu Ustad Gilang, pada tanggal 27 April 2026. Wawancara bertujuan untuk memperoleh informasi secara langsung mengenai permasalahan yang dihadapi dalam pengelolaan inventaris aset dan surat, alur kerja yang berlaku, serta kebutuhan fitur sistem yang diharapkan oleh pihak sekolah.
3. Studi Pustaka
Studi pustaka dilakukan dengan mempelajari buku, jurnal ilmiah, dan referensi lain yang berkaitan dengan sistem informasi berbasis web, pengelolaan inventaris aset, pengelolaan surat, metode pengembangan perangkat lunak Agile, serta teknologi CodeIgniter 4 dan MySQL. Referensi yang digunakan bersumber dari jurnal nasional dan internasional yang terindeks serta memiliki Open Journal System (OJS), dengan rentang waktu penerbitan minimal lima tahun terakhir

### 1.5.2	Model Pengembangan Software
Model pengembangan perangkat lunak yang digunakan dalam penelitian ini adalah Agile Scrum. Agile Scrum dipilih karena memiliki pendekatan iteratif dan bertahap, sehingga proses pengembangan sistem dapat disesuaikan dengan kebutuhan pengguna. Metode ini memungkinkan penulis untuk membagi pekerjaan ke dalam beberapa siklus pengembangan atau sprint, sehingga setiap fitur dapat dirancang, dikembangkan, diuji, dan dievaluasi secara bertahap.
Dalam penelitian ini, penerapan Agile Scrum disesuaikan dengan kebutuhan pengembangan sistem inventaris aset dan disposisi surat berbasis web pada SMPI REJIS. Pihak sekolah berperan sebagai pengguna yang memberikan kebutuhan dan masukan terhadap sistem, sedangkan penulis berperan sebagai pengembang yang merancang dan membangun aplikasi sesuai kebutuhan tersebut.
Adapun tahapan Agile Scrum yang digunakan dalam pengembangan sistem ini adalah sebagai berikut :
1. Product Backlog
Tahap product backlog dilakukan dengan mengumpulkan seluruh kebutuhan sistem berdasarkan hasil observasi dan wawancara. Kebutuhan tersebut kemudian disusun dalam bentuk daftar fitur yang akan dikembangkan. Pada sistem ini, product backlog mencakup fitur login, pengelolaan data pengguna, pengelolaan data aset, kategori aset, lokasi aset, peminjaman aset, pengembalian aset, pencatatan surat masuk, disposisi surat, pemantauan status surat, laporan inventaris, dan laporan surat.
2. Sprint Planning
Sprint planning merupakan tahap perencanaan pekerjaan yang akan dilakukan dalam satu siklus pengembangan. Pada tahap ini, fitur-fitur yang terdapat dalam product backlog dipilih berdasarkan prioritas kebutuhan. Fitur yang dianggap paling penting akan dikerjakan terlebih dahulu agar sistem dapat memiliki fungsi utama sejak awal pengembangan. Dalam penelitian ini, sprint planning digunakan untuk menentukan urutan pengerjaan modul sistem yang mencakup modul autentikasi pengguna, modul inventaris aset, modul peminjaman dan pengembalian aset, modul surat masuk, modul disposisi surat, serta modul laporan.
3. Sprint Backlog
Sprint backlog merupakan daftar pekerjaan yang dipilih dari product backlog untuk dikerjakan dalam satu sprint. Pada tahap ini, setiap kebutuhan sistem dijabarkan menjadi tugas teknis yang lebih rinci. Tugas teknis tersebut meliputi perancangan tabel database, pembuatan tampilan antarmuka, pembuatan controller, pembuatan model, validasi input, pengaturan hak akses, serta pengujian fitur. Sprint backlog membantu proses pengembangan agar lebih terarah karena setiap fitur memiliki daftar pekerjaan yang jelas.
4. Sprint Execution
Sprint execution merupakan tahap pelaksanaan pengembangan sistem berdasarkan sprint backlog yang telah dibuat. Pada tahap ini, penulis mulai membangun sistem menggunakan bahasa pemrograman PHP dengan framework CodeIgniter 4, database MySQL, serta teknologi pendukung seperti HTML, CSS, JavaScript, SQL, dan Bootstrap. Pengembangan dilakukan secara bertahap berdasarkan modul yang telah direncanakan, mulai dari pembuatan struktur database, tampilan halaman, proses input data, proses update data, proses hapus data, pengelolaan hak akses, hingga pembuatan laporan.
5. Daily Scrum
Daily scrum merupakan kegiatan evaluasi singkat terhadap perkembangan pengerjaan sistem. Dalam penelitian ini, daily scrum diterapkan dalam bentuk pemantauan progres secara berkala terhadap pekerjaan yang telah selesai, pekerjaan yang sedang dilakukan, dan kendala yang ditemukan selama proses pengembangan. Apabila ditemukan kendala, seperti kesalahan logika program, tampilan yang belum sesuai, atau kebutuhan yang perlu disesuaikan, maka perbaikan dapat segera dilakukan sebelum masuk ke tahap berikutnya.
6. Sprint Review
Sprint review merupakan tahap peninjauan terhadap hasil pengembangan yang telah selesai dalam satu sprint. Pada tahap ini, fitur yang telah dibuat dievaluasi untuk memastikan bahwa fungsi sistem sudah sesuai dengan kebutuhan pengguna. Dalam penelitian ini, sprint review dilakukan dengan meninjau setiap modul sistem, seperti modul aset, peminjaman aset, surat masuk, disposisi surat, dan laporan.
Pada tahap ini juga dilakukan pengujian terhadap sistem. Pengujian tidak hanya dilakukan menggunakan Blackbox Testing, tetapi juga dilengkapi dengan uji keamanan dan uji kinerja. Blackbox Testing digunakan untuk menguji kesesuaian fungsi sistem berdasarkan input dan output. Uji keamanan dilakukan untuk memastikan sistem memiliki mekanisme login, pembagian hak akses, validasi input, dan pengelolaan sesi pengguna. Uji kinerja dilakukan untuk mengetahui kemampuan sistem dalam memuat halaman, menyimpan data, mencari data, dan menghasilkan laporan dalam waktu yang wajar.
7. Sprint Retrospective
Sprint retrospective merupakan tahap evaluasi terhadap proses pengerjaan yang telah dilakukan. Pada tahap ini, penulis mengevaluasi kendala yang muncul selama pengembangan, bagian yang sudah berjalan dengan baik, serta perbaikan yang perlu dilakukan pada sprint berikutnya. Apabila terdapat fitur yang belum sesuai kebutuhan, alur yang kurang tepat, atau tampilan yang kurang mudah digunakan, maka hasil evaluasi tersebut dijadikan dasar untuk perbaikan pada siklus pengembangan berikutnya.
8. Increment
Increment merupakan hasil akhir dari setiap sprint berupa fitur atau modul sistem yang telah selesai dikembangkan dan dapat diuji. Dalam penelitian ini, increment yang dihasilkan mencakup modul login, modul data aset, modul peminjaman dan pengembalian aset, modul surat masuk, modul disposisi surat, modul laporan, serta pengaturan hak akses pengguna. Setiap increment menjadi bagian dari sistem yang terus dikembangkan hingga seluruh modul utama selesai dan sistem inventaris aset serta disposisi surat dapat digunakan secara penuh di SMPI REJIS.
## 1.6 Ruang Lingkup

Agar pembahasan dalam penelitian ini lebih terarah dan terfokus, maka ruang lingkup penelitian dibatasi sebagai berikut :
1. Sistem yang dibangun merupakan aplikasi berbasis web untuk pengelolaan inventaris aset dan disposisi surat pada SMPI REJIS.
2. Sistem dikembangkan menggunakan PHP dengan framework CodeIgniter 4, database MySQL, serta teknologi pendukung berupa HTML, CSS, JavaScript, SQL, dan Bootstrap.
3. Sistem inventaris aset mencakup pengelolaan data aset, kategori aset, lokasi aset, kondisi aset, serta proses peminjaman dan pengembalian aset.
4. Sistem disposisi surat mencakup pencatatan surat masuk, pengarsipan surat, proses disposisi surat, pemantauan status tindak lanjut surat, serta laporan surat.
5. Pengguna sistem terdiri dari Admin TU, Kepala Sekolah, dan Staff yang memiliki hak akses berbeda sesuai dengan peran masing-masing.
6. Proses bisnis dalam sistem meliputi alur pengelolaan inventaris aset dan disposisi surat, dimulai dari proses input data, pengolahan data, pemantauan status, hingga menghasilkan output berupa laporan.
7. Perancangan sistem dilakukan menggunakan Unified Modelling Language (UML) yang meliputi use case diagram, activity diagram, sequence diagram, dan deployment diagram, serta perancangan basis data menggunakan Entity Relationship Diagram (ERD).
8. Model pengembangan perangkat lunak yang digunakan adalah Agile Scrum dengan tahapan product backlog, sprint planning, sprint backlog, sprint execution, daily scrum, sprint review, sprint retrospective, dan increment.
9. Pengujian sistem dilakukan melalui Blackbox Testing, uji keamanan, dan uji kinerja. Blackbox Testing digunakan untuk menguji fungsi sistem, uji keamanan digunakan untuk menguji login, hak akses, validasi input, dan sesi pengguna, sedangkan uji kinerja digunakan untuk menguji kecepatan akses halaman, proses penyimpanan data, pencarian data, dan pembuatan laporan.
10. Sistem yang dibangun tidak mencakup integrasi dengan sistem eksternal lainnya di luar lingkungan SMPI REJIS.
