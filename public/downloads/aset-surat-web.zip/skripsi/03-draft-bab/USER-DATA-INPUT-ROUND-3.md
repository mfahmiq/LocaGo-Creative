# USER DATA INPUT ROUND 3

Tanggal dibuat: 2026-07-05

## 1. Status

File ini mencatat data nyata yang diisi user pada putaran ketiga. Berbeda dari dua putaran sebelumnya, pada putaran ini **spesifikasi hardware/software benar-benar terisi dengan data nyata** (bukan placeholder). Untuk screenshot, user memberikan lokasi folder yang jelas dan menyatakan sudah menyiapkan 10 berkas, tetapi hasil pengecekan langsung (`SCREENSHOT-INVENTORY-CHECK.md`) menunjukkan kelima kebutuhan screenshot BAB IV tetap tidak ditemukan. Data pengujian kinerja dasar dan data sekolah secara eksplisit dinyatakan "BELUM ADA" oleh user, sehingga marker terkait tetap dipertahankan sesuai instruksi.

## 2. Data Hardware/Software Yang Digunakan

**Status: TERISI DATA NYATA, dapat dipakai untuk menyelesaikan marker.**

Field | Nilai Dari User | Status
---|---|---
Processor | Intel Core i5 | Terisi nyata
RAM | 8 GB | Terisi nyata
Storage | 256 GB SSD | Terisi nyata
Sistem Operasi | Windows 11 | Terisi nyata
Versi Windows | Windows 11 | Terisi nyata
Browser | Google Chrome | Terisi nyata
Versi Browser | versi terbaru saat pengujian (tanpa nomor versi spesifik, sesuai instruksi user) | Terisi nyata, dengan keterangan tidak ada bukti nomor versi persis
Code Editor | Visual Studio Code | Terisi nyata
Versi Code Editor | versi terbaru saat pengujian (tanpa nomor versi spesifik, sesuai instruksi user) | Terisi nyata, dengan keterangan tidak ada bukti nomor versi persis
Local Server | Laragon | Terisi (sudah dikonfirmasi sebelumnya, bukan marker)
Versi Laragon | 6 | Terisi nyata
PHP | Instruksi memakai versi terverifikasi workspace | Memakai PHP CLI 8.4.10 (sudah terverifikasi di `APPLICATION_VERIFICATION.md`, bukan marker)
Database | Instruksi memakai versi terverifikasi workspace | Tidak ada versi MySQL/MariaDB spesifik yang terverifikasi di workspace; tetap ditulis "MySQL/MariaDB" tanpa nomor versi (bukan marker karena BAB IV sebelumnya juga tidak mencantumkan nomor versi database)
Framework | CodeIgniter 4 | Terisi (sudah dikonfirmasi sebelumnya, bukan marker)

Dampak: keempat marker `[PERLU DATA]` pada BAB IV 4.4.2 (versi Windows, versi browser, versi editor, spesifikasi hardware) **dapat diselesaikan** menggunakan data di atas.

## 3. Lokasi Folder Screenshot

```text
C:\laragon\www\aset-surat-web\skripsi\04-diagram-dan-gambar\screenshots
```

Lokasi ini sudah dicek secara read-only. Rincian lengkap ada di `SCREENSHOT-INVENTORY-CHECK.md`.

## 4. Daftar Screenshot Yang Ditemukan

Folder berisi 22 berkas (21 PNG + 1 PDF) yang seluruhnya sudah pernah tercatat sebelumnya (bertanggal 2026-07-04). Tidak ada berkas baru yang cocok dengan 5 kebutuhan BAB IV yang masih kurang.

## 5. Daftar Screenshot Yang Tidak Ditemukan

Kelima kebutuhan screenshot BAB IV **tetap tidak ditemukan** setelah pengecekan langsung, termasuk pengecekan visual terhadap 4 berkas kandidat yang paling mendekati:

1. Halaman Manajemen Pengguna — tidak ada berkas sama sekali (tidak ada nama file mengandung "pengguna"/"user").
2. Halaman Daftar Transaksi Aset — `14-transaksi-aset.png` ternyata berisi halaman "Detail Transaksi Aset" (satu transaksi), bukan daftar/list.
3. Form Tambah Surat Masuk — `15-upload-surat-masuk.png` ternyata berisi halaman "Detail Surat Masuk" beserta panel disposisi, bukan form tambah.
4. Form Tambah Surat Keluar — `18-surat-keluar.png` ternyata berisi halaman "Detail Surat Keluar" beserta panel update pengiriman, bukan form tambah.
5. Cetak Laporan — `08-laporan.png` ternyata berisi halaman menu pilihan jenis laporan, bukan tampilan cetak/print.

Kelima marker `[PERLU CEK SCREENSHOT]` **tetap dipertahankan**.

## 6. Data Pengujian Kinerja

**BELUM ADA** (dinyatakan eksplisit oleh user). Ketujuh marker `[PERLU DATA HASIL PENGUJIAN]` (6 baris tabel + 1 kalimat penutup) **tetap dipertahankan**.

## 7. Data Sekolah

**BELUM ADA** (dinyatakan eksplisit oleh user untuk profil resmi, sejarah singkat, struktur organisasi, detail observasi, tanggal observasi, dan pihak yang ditemui). Marker `[PERLU DATA]` pada BAB I (observasi) dan ketiga marker `[PERLU DATA]` pada BAB III (profil, sejarah, struktur organisasi) **tetap dipertahankan**.

## 8. Catatan

Data kosong (pengujian kinerja dan data sekolah) tidak dikarang, sesuai pernyataan eksplisit "BELUM ADA" dari user. Screenshot yang tidak ditemukan tidak dianggap tersedia meskipun user menyatakan sudah menyiapkannya — keputusan didasarkan pada pengecekan langsung terhadap isi folder dan isi visual berkas, bukan asumsi.
