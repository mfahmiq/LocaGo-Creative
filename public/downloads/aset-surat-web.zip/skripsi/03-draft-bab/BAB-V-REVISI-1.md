# BAB V

# PENUTUP

Status dokumen: revisi 1 BAB V untuk review, belum menjadi naskah final DOCX. Bab ini bergantung pada penyelesaian marker BAB IV.

## 5.1. Kesimpulan

Berdasarkan hasil perancangan pada BAB III dan hasil desain, implementasi, serta pengujian pada BAB IV, dapat disimpulkan sebagai berikut:

1. Sistem terintegrasi inventaris aset dan disposisi surat dirancang untuk membantu kebutuhan administrasi SMPI REJIS berdasarkan permasalahan pencatatan aset, transaksi aset, surat masuk, disposisi surat, surat keluar, laporan, dan backup, sebagaimana diuraikan pada analisis masalah dan analisis kebutuhan di BAB III.

2. Perancangan aplikasi menggunakan pendekatan Agile Scrum secara hati-hati melalui pemetaan kebutuhan, *product backlog*, *sprint mapping*, pengembangan modul, dan pengujian, sebagaimana dijelaskan pada BAB IV bagian 4.1 Desain, tanpa mengklaim pelaksanaan ceremony Scrum historis yang belum memiliki bukti.

3. Aplikasi dikembangkan menggunakan CodeIgniter 4, PHP, MySQL/MariaDB, dan pola MVC sehingga struktur pengembangan aplikasi menjadi lebih terarah, sebagaimana diuraikan pada BAB IV bagian 4.1.1 Database dan 4.1.2 Software Architecture.

4. Berdasarkan draft BAB IV, pengujian dilakukan melalui *black-box testing*, pengujian keamanan dasar, dan pengujian kinerja dasar. *Black-box testing* menunjukkan 42 skenario berstatus valid pada tahap audit ini. Namun, karena masih ada marker pengukuran kinerja dasar (`[PERLU DATA HASIL PENGUJIAN]`) dan sejumlah bukti screenshot serta potongan kode yang belum lengkap (`[PERLU CEK SCREENSHOT]`, `[PERLU CEK BUKTI KODE]`), bagian ini perlu dicek ulang setelah BAB IV final. `[PERLU CEK SETELAH BAB IV FINAL]`

5. Aplikasi masih dibatasi pada lingkungan lokal menggunakan Laragon dan belum diklaim sebagai sistem produksi, online, atau resmi digunakan sekolah.

`[PERLU CEK SETELAH BAB IV FINAL]`

## 5.2. Saran

Berdasarkan hasil penelitian dan batasan yang telah dijelaskan, saran yang dapat disampaikan adalah sebagai berikut:

1. Sistem dapat dikembangkan ke server internal sekolah atau hosting jika sekolah membutuhkan penggunaan secara operasional.
2. Perlu pengujian lebih lanjut pada lingkungan produksi sebelum aplikasi digunakan secara resmi.
3. Perlu penguatan keamanan lanjutan apabila aplikasi akan digunakan secara online.
4. Fitur notifikasi dapat ditambahkan untuk mendukung pemantauan disposisi surat.
5. Integrasi email dapat dipertimbangkan untuk pengiriman informasi surat dan disposisi.
6. Tanda tangan digital dapat dikembangkan apabila proses surat-menyurat membutuhkan validasi digital.
7. Backup otomatis dapat dikembangkan agar perlindungan data lebih terjadwal.
8. Evaluasi pengguna perlu dilakukan apabila aplikasi diterapkan secara langsung di lingkungan sekolah.
9. Dokumentasi penggunaan aplikasi perlu disiapkan untuk admin, operator, dan pimpinan.
