# REFERENSI APA 7 MENDELEY CHECK UPDATED

Tanggal dibuat: 2026-07-05

## 1. Status

File ini memperbarui `REFERENSI-APA7-MENDELEY-CHECK.md`. Satu jurnal tambahan — Usnaini, Yasin, dan Sianipar (2021) — telah dimasukkan ke `BAB-II-FINAL-ARAH-REFPATCH-1.md` sehingga jumlah jurnal ilmiah yang terverifikasi menjadi 10, memenuhi syarat minimal 10 jurnal pada `PEDOMAN_AUDIT.md`. File ini tetap berstatus checkpoint referensi, bukan daftar pustaka final.

## 2. Referensi Tambahan

**Usnaini, M., Yasin, V., & Sianipar, A. Z. (2021). Perancangan sistem informasi inventarisasi aset berbasis web menggunakan metode waterfall. *Jurnal Manajemen Informatika Jayakarta*, 1(1), 36–55. https://doi.org/10.52362/jmijayakarta.v1i1.415**

No | Referensi | Jenis | Tahun | Status Metadata | Perlu Mendeley | Catatan
---|---|---|---|---|---|---
19 | Usnaini, Yasin, & Sianipar | Jurnal ilmiah (Jurnal Manajemen Informatika Jayakarta) | 2021 | LENGKAP | Ya | Vol. 1 No. 1, hlm. 36-55, DOI 10.52362/jmijayakarta.v1i1.415; disediakan dan diverifikasi oleh Maestro; dipakai untuk 2.1.3 Inventaris Aset dan 2.2 Penelitian Terkait pada `BAB-II-FINAL-ARAH-REFPATCH-1.md`

Metadata di atas tidak diubah dan tidak ditambah DOI/volume/halaman lain di luar yang diberikan.

## 3. Hitung Ulang Kebutuhan Minimal Jurnal

1. Jumlah jurnal ilmiah sebelum patch: **9**.
2. Jumlah jurnal ilmiah setelah patch: **10** — Wahyuni et al. (2025), Annisa et al. (2023), Pranoto & Sediyono (2021), Mubarok & Sutaji (2025), Siswaya & Setiawan (2025), Rohmawati & Yulianingsih (2025), Londa, Wee, & Radja (2022), Wiratama (2024), JSAI (2024), Usnaini, Yasin, & Sianipar (2021).
3. Status: **TERPENUHI DENGAN CATATAN**.
4. Catatan: jumlah jurnal sudah memenuhi syarat minimal 10, tetapi seluruh referensi (termasuk 9 referensi sebelumnya dan referensi baru ini) tetap harus dicek dan dimasukkan ke Mendeley dengan style APA 7 sebelum daftar pustaka disebut final. Sebagian referensi lama masih berstatus PERLU CEK atau BELUM LENGKAP (lihat `REFERENSI-APA7-MENDELEY-CHECK.md` bagian 3), sehingga pemenuhan jumlah minimal tidak berarti seluruh referensi sudah siap final.

## 4. Catatan Mendeley

Seluruh referensi yang dipakai pada BAB II — termasuk 9 referensi sebelumnya dan referensi Usnaini, Yasin, dan Sianipar (2021) — harus dimasukkan ke Mendeley dengan style APA 7 sebelum DOCX final. Proses ini mencakup:

1. Verifikasi ulang metadata (penulis, tahun, judul, nama jurnal, volume, nomor, halaman, DOI) untuk setiap referensi.
2. Penyesuaian format sitasi dalam naskah (nama pengarang dan tahun dalam kurung) sesuai contoh pedoman.
3. Penyusunan daftar pustaka berurutan abjad, tanpa nomor urut, dengan format nama pengarang dari nama belakang, sesuai `PEDOMAN_AUDIT.md`.
4. Verifikasi khusus untuk Mubarok & Sutaji (2025) karena ada dua versi DOI berbeda (halaman resmi jurnal BSI dan metadata Garuda).
