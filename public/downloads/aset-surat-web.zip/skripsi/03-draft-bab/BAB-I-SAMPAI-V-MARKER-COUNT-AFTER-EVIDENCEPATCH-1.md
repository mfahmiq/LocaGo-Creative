# BAB I SAMPAI V MARKER COUNT AFTER EVIDENCEPATCH 1

Tanggal dibuat: 2026-07-05

## 1. Status

File ini menghitung ulang marker setelah evidence patch 1, yang menyelesaikan marker berdasarkan data nyata yang diisi user (`USER-DATA-INPUT-ROUND-1.md`). Dari seluruh data yang diminta pada `MARKER-RESOLUTION-DATA-CHECKLIST.md`, hanya keputusan deployment (Opsi A: tetap lokal Laragon) yang benar-benar terisi dengan data nyata. Spesifikasi hardware/software, lokasi/berkas screenshot, data pengujian kinerja, dan data sekolah masih berupa placeholder kosong, sehingga marker terkait bagian-bagian tersebut **dipertahankan tanpa perubahan**. File terbaru yang dipakai untuk hitungan ini:

1. `BAB-I-FINAL-ARAH-DATAPATCH-1.md`
2. `BAB-II-FINAL-ARAH-REFPATCH-1.md` (tidak diubah pada tahap ini)
3. `BAB-III-REVISI-1-DATAPATCH-1.md`
4. `BAB-IV-REVISI-1-EVIDENCEPATCH-1.md`
5. `BAB-V-REVISI-1.md` (tidak diubah pada tahap ini)

## 2. Hitungan Marker Sebelum Patch

BAB | Jumlah
---|---
BAB I | 1
BAB II | 1
BAB III | 3
BAB IV | 17
BAB V | 2
**Total** | **24**

## 3. Hitungan Marker Setelah Patch

BAB | Jumlah Sebelum | Jumlah Sesudah | Selisih | Catatan
---|---|---|---|---
BAB I | 1 | 1 | 0 | Data observasi (waktu dan bentuk pelaksanaan) belum diisi user (masih placeholder kosong); marker `[PERLU DATA]` dipertahankan
BAB II | 1 | 1 | 0 | Tidak diubah pada tahap ini; marker `[PERLU CEK APA 7]` (LRS) tetap ada
BAB III | 3 | 3 | 0 | Profil, sejarah, dan struktur organisasi SMPI REJIS belum diisi user (masih placeholder kosong); ketiga marker `[PERLU DATA]` dipertahankan
BAB IV | 17 | **16** | -1 | Marker `[PERLU DATA]` pada 4.4.1 Publikasi Software (rencana deployment) selesai berdasarkan konfirmasi user (Opsi A: tetap lokal Laragon, tidak ada rencana server). 16 marker lain tetap ada: `[PERLU DATA]` x4 (versi Windows, versi browser, versi editor, spesifikasi hardware — semua masih placeholder kosong), `[PERLU CEK SCREENSHOT]` x5 (5 berkas yang disebut user tidak ditemukan di folder screenshot), `[PERLU DATA HASIL PENGUJIAN]` x7 (data waktu respons masih placeholder kosong)
BAB V | 2 | 2 | 0 | Tidak diubah pada tahap ini; 2 marker `[PERLU CEK SETELAH BAB IV FINAL]` tetap ada
**Total** | **24** | **23** | **-1** | Hanya 1 marker terselesaikan pada putaran ini karena hanya 1 dari 5 kategori data (deployment) yang benar-benar diisi user dengan data nyata

## 4. Marker Yang Berhasil Diselesaikan

No | BAB | Marker | Lokasi | Data Pendukung
---|---|---|---|---
1 | IV | `[PERLU DATA]` | 4.4.1 Publikasi Software | Konfirmasi user: Opsi A (tetap lokal menggunakan Laragon), dengan keterangan "Aplikasi pada penelitian ini masih dijalankan dan diuji pada lingkungan lokal menggunakan Laragon. Aplikasi belum dipublikasikan pada server internal sekolah maupun hosting." (`USER-DATA-INPUT-ROUND-1.md` bagian 2)

## 5. Marker Yang Masih Tersisa

Kategori | Jumlah | Rincian | Alasan Belum Selesai
---|---|---|---
Butuh data user/sekolah | 5 | BAB I: 1 (observasi); BAB III: 3 (profil, sejarah, struktur organisasi) | Field terkait pada input user masih berupa placeholder kosong (`[ISI ...]`), bukan data nyata
Butuh screenshot | 5 | BAB IV 4.1.3: manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, cetak laporan | User menyatakan sudah menyiapkan 5 berkas, tetapi lokasi folder juga masih placeholder dan kelima nama berkas yang disebut tidak ditemukan di lokasi contoh (`skripsi/04-diagram-dan-gambar/screenshots/`) saat dicek
Butuh hasil pengujian | 7 | BAB IV 4.3 Pengujian Kinerja Dasar: 6 proses + 1 kalimat penutup | Seluruh kolom waktu respons pada input user masih placeholder kosong (`[ISI]`/`[ISI, contoh: 1,2 detik]`), bukan angka nyata
Butuh Mendeley/APA 7 | 1 | BAB II 2.1.11 LRS | Tidak termasuk cakupan data yang diminta pada putaran ini; tetap menunggu verifikasi Mendeley terpisah
Butuh spesifikasi hardware | 4 | BAB IV 4.4.2: versi Windows, versi browser, versi editor, spesifikasi hardware (prosesor/RAM/penyimpanan) | Seluruh field terkait pada input user masih placeholder kosong (`[ISI ...]`)
Butuh review manual | 2 | BAB V 5.1 Kesimpulan poin 4 dan penutup | Masih bergantung pada penyelesaian marker BAB IV (screenshot dan pengujian kinerja) yang belum selesai
**Total** | **23** | - | -

## 6. Rekomendasi Berikutnya

Putaran berikutnya membutuhkan data nyata (bukan placeholder) untuk: spesifikasi hardware/software (processor, RAM, storage, versi Windows, browser, editor), berkas screenshot yang benar-benar tersimpan di lokasi yang dikonfirmasi, dan angka waktu respons hasil pengamatan sederhana. Data sekolah (profil, sejarah, struktur organisasi, observasi) tetap terpisah dan membutuhkan dokumen resmi atau konfirmasi langsung dari pihak sekolah.
