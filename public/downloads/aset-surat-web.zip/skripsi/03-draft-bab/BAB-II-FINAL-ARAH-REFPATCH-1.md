# BAB II

# LANDASAN TEORI

Status dokumen: patch referensi 1 dari `BAB-II-FINAL-ARAH.md`, ditambahkan sitasi Usnaini, Yasin, dan Sianipar (2021) pada 2.1.3 dan 2.2 untuk memenuhi kebutuhan minimal 10 jurnal. Kandidat BAB II terbaru, belum menjadi naskah final DOCX.

## 2.1. Tinjauan Pustaka

### 2.1.1. Sistem Informasi

Sistem informasi adalah seperangkat komponen yang mengelola data menjadi informasi untuk mendukung proses pengambilan keputusan dan operasional organisasi. Dalam konteks sekolah, sistem informasi membantu mencatat, menyimpan, mengolah, dan menyajikan data administrasi yang melibatkan aset, surat, dan aktivitas layanan sekolah. Sistem informasi sekolah yang baik mengintegrasikan manusia, prosedur, data, perangkat lunak, perangkat keras, dan komunikasi agar informasi dapat dihasilkan secara teratur dan dapat digunakan kembali.

Di lingkungan administrasi sekolah, sistem informasi diperlukan untuk mengurangi ketergantungan pada catatan manual, mempercepat pencarian data, serta meningkatkan konsistensi dan keterandalan informasi. Annisa, Rahayuningsih, dan Anna (2023) menunjukkan bahwa sistem informasi inventaris berbasis web dapat membantu sekolah mengelola data sarana dan prasarana yang sebelumnya tersimpan dalam buku atau spreadsheet. Pendekatan ini relevan bagi SMPI REJIS karena kebutuhan pengelolaan aset dan surat belum tersentralisasi.

Sistem informasi tidak hanya berfungsi sebagai media pencatatan, tetapi juga sebagai alat bantu dalam proses pemantauan dan pelaporan. Dengan adanya sistem informasi sekolah berbasis web, pelaku administrasi dapat memperoleh gambaran kondisi aset, riwayat peminjaman, dan status tindak lanjut surat dalam bentuk informasi yang mudah diolah.

### 2.1.2. Website

Website adalah media aplikasi yang dapat diakses melalui peramban web pada perangkat yang terhubung ke jaringan. Website memungkinkan penyajian halaman dan formulir yang dapat diisi, ditampilkan, dan diperbarui secara dinamis. Untuk sistem administrasi sekolah, website menjadi pilihan yang tepat karena dapat diakses dari berbagai perangkat tanpa perlu instalasi aplikasi khusus.

Pengembangan aplikasi berbasis website menawarkan keuntungan seperti akses data terpusat, kemudahan pembaruan, dan fleksibilitas penggunaan. Annisa, Rahayuningsih, dan Anna (2023) menjelaskan bahwa sistem inventaris berbasis web memudahkan sekolah dalam mengelola informasi secara online dan meningkatkan keterpaduan data. Mubarok dan Sutaji (2025) menambahkan bahwa aplikasi web membantu pemantauan aset dan pelaporan dengan interface yang dapat diakses oleh pengguna berwenang.

Website bagi lembaga sekolah memungkinkan pengelolaan data inventaris dan disposisi surat secara terpadu. Dengan akses melalui peramban, pengguna dapat melakukan pencatatan, pencarian, dan pelaporan dari satu platform yang sama.

### 2.1.3. Inventaris Aset

Inventaris aset adalah kegiatan pencatatan dan pengelolaan barang yang dimiliki oleh organisasi atau institusi. Di sekolah, inventaris aset mencakup sarana dan prasarana seperti meja, kursi, komputer, proyektor, dan perangkat laboratorium. Pengelolaan inventaris yang baik mencakup pencatatan kategori aset, lokasi penyimpanan, kondisi barang, status penggunaan, riwayat peminjaman, dan pembuatan laporan.

Inventaris aset tidak hanya melibatkan daftar barang, tetapi juga memerlukan data yang konsisten tentang peminjaman dan pengembalian. Annisa, Rahayuningsih, dan Anna (2023) menyatakan bahwa pencatatan yang masih menggunakan buku atau spreadsheet menyebabkan proses pencarian data lambat dan rentan kehilangan data. Pranoto dan Sediyono (2021) memperkuat bahwa sistem informasi inventaris berbasis web mampu memperbaiki manajemen barang, pemantauan lokasi, dan penyusunan laporan.

Mubarok dan Sutaji (2025) menunjukkan bahwa sistem inventaris aset kantor berbasis web penting untuk meningkatkan efektivitas pengelolaan aset, khususnya pada pencatatan peminjaman dan monitoring aset. Usnaini, Yasin, dan Sianipar (2021) membahas bahwa pengelolaan inventaris aset sekolah yang masih dilakukan secara manual dapat menimbulkan kendala dalam pencarian data, kelengkapan arsip, dan penyusunan laporan. Oleh karena itu, sistem informasi inventarisasi aset berbasis web diperlukan untuk membantu pencatatan, pengelolaan, dan penyajian laporan aset secara lebih terstruktur. Untuk SMPI REJIS, perancangan sistem inventaris aset diperlukan agar data barang dapat dilacak, status aset dipantau, dan laporan disusun secara akurat.

### 2.1.4. Surat

Surat adalah media komunikasi tertulis yang digunakan untuk menyampaikan informasi secara resmi. Surat masuk dan surat keluar merupakan bagian penting dari administrasi sekolah karena dokumen tersebut menjadi bukti kegiatan, permohonan, atau pemberitahuan. KBBI mendefinisikan surat sebagai dokumen tertulis yang disampaikan dari satu pihak kepada pihak lain dengan tujuan tertentu, sedangkan Undang-Undang Nomor 43 Tahun 2009 tentang Kearsipan menempatkan arsip sebagai rekaman kegiatan atau peristiwa dalam berbagai bentuk media yang dibuat dan diterima oleh lembaga.

Dalam administrasi sekolah, surat perlu dicatat secara terstruktur dan diarsipkan agar dapat ditemukan kembali ketika dibutuhkan. Surat masuk yang diterima oleh sekolah harus didokumentasikan dengan informasi tanggal, pengirim, nomor surat, perihal, dan penerima internal. Pencatatan surat keluar juga penting untuk melacak dokumen yang telah dikirim. Apabila pencatatan surat dilakukan secara manual, risiko kehilangan dokumen dan keterlambatan tindak lanjut menjadi lebih besar.

Arsip surat memungkinkan penyimpanan dokumen administratif secara sistematis. Dengan sistem berbasis web, arsip surat dapat tersimpan secara digital sehingga pencarian ulang dan pelaporan menjadi lebih cepat dan terstruktur.

### 2.1.5. Disposisi Surat

Disposisi surat adalah proses pemberian arahan, instruksi, atau tindak lanjut terhadap surat masuk. Proses disposisi bertujuan memastikan bahwa surat yang diterima ditangani oleh pihak yang tepat dan tindak lanjutnya dapat dimonitor. Disposisi surat melibatkan penentuan penerima disposisi, status tindak lanjut, dan tanggal penyelesaian.

Sistem disposisi surat berbasis web membantu memantau status surat masuk secara real time. Siswaya dan Setiawan (2025) menyatakan bahwa sistem pengarsipan dan disposisi surat berbasis web memperbaiki proses pengelolaan surat dan memudahkan pengambilan keputusan. Rohmawati dan Yulianingsih (2025) menekankan bahwa e-disposisi surat berbasis web meningkatkan efisiensi pengelolaan surat dan memudahkan pelacakan dokumen.

Londa, Wee, dan Radja (2022) menunjukkan bahwa monitoring disposisi surat penting agar status surat dapat diketahui oleh pihak terkait. Bagi SMPI REJIS, modul disposisi surat diperlukan untuk mencatat instruksi, memantau proses, dan memastikan bahwa surat yang masuk diselesaikan sesuai kebutuhan administrasi.

### 2.1.6. Basis Data MySQL

Basis data adalah kumpulan data yang disimpan secara terstruktur untuk memudahkan pengelolaan dan pengambilan informasi. Basis data relasional menyimpan data dalam tabel yang saling berhubungan melalui kunci primer dan kunci asing. MySQL merupakan sistem manajemen basis data relasional yang banyak digunakan untuk aplikasi web karena dukungan terhadap transaksi, integritas data, dan kemampuan query.

Dalam aplikasi inventaris aset dan disposisi surat, basis data menyimpan entitas seperti pengguna, aset, kategori, lokasi, peminjaman, surat masuk, disposisi, dan laporan. Kunci primer adalah atribut unik yang membedakan setiap baris data, sedangkan kunci asing menghubungkan tabel satu dengan tabel lain. Relasi antara entitas memungkinkan data tersimpan secara konsisten dan meminimalkan duplikasi.

MySQL Reference Manual menjelaskan konsep relasional yang menjadi dasar penyimpanan data aplikasi. Dengan perancangan basis data yang baik, proses pencarian data, pembaruan data, dan pembuatan laporan menjadi lebih efisien dan dapat didukung oleh query yang sesuai.

### 2.1.7. PHP

PHP adalah bahasa pemrograman sisi server yang umum digunakan untuk pengembangan aplikasi web. PHP memproses permintaan dari peramban, berinteraksi dengan basis data, dan menghasilkan halaman web dinamis. Bahasa ini digunakan untuk memvalidasi input, memproses logika bisnis, dan mengatur alur kerja aplikasi.

Dokumentasi resmi PHP memberikan pedoman penggunaan syntax, koneksi basis data, dan pengelolaan sesi. Dalam aplikasi yang dirancang, PHP bertanggung jawab untuk mengolah data pengguna, data aset, data surat, dan menghubungkan hasil pemrosesan tersebut dengan tampilan yang disajikan ke pengguna.

### 2.1.8. CodeIgniter

CodeIgniter 4 adalah *framework* PHP yang memfasilitasi pengembangan aplikasi web dengan pola Model-View-Controller (MVC). MVC memisahkan logika penyimpanan data (Model), tampilan antarmuka (View), dan alur kendali aplikasi (Controller). Dengan pemisahan ini, pengembangan aplikasi menjadi lebih terstruktur dan lebih mudah dikelola.

CodeIgniter 4 User Guide menjelaskan bagaimana model berinteraksi dengan basis data, controller mengatur alur proses, dan view menampilkan data kepada pengguna. Struktur ini sesuai untuk aplikasi administrasi sekolah yang memiliki modul-modul terpisah seperti inventaris aset, surat masuk, disposisi, dan laporan.

### 2.1.9. UML

Unified Modeling Language (UML) adalah bahasa pemodelan visual untuk menggambarkan sistem perangkat lunak. UML menyediakan notasi untuk menjelaskan elemen sistem, interaksi antarobjek, dan alur proses. Dalam penelitian ini, UML digunakan sebagai dasar pemodelan sistem tanpa menampilkan gambar diagram aktual di BAB II.

Diagram UML yang relevan antara lain use case diagram, activity diagram, sequence diagram, dan deployment diagram. Use case diagram menggambarkan aktor dan fungsi utama sistem. Activity diagram menggambarkan alur proses administratif seperti pencatatan aset dan disposisi surat. Sequence diagram menggambarkan interaksi sistem berdasarkan waktu. OMG UML 2.5.1 menjadi sumber resmi untuk pemodelan tersebut.

### 2.1.10. ERD

Entity Relationship Diagram (ERD) adalah alat bantu perancangan basis data yang menggambarkan entitas, atribut, dan relasi antarentitas. ERD membantu memahami struktur data sebelum basis data dibuat, termasuk komponen seperti primary key, foreign key, dan kardinalitas.

Dalam sistem inventaris aset dan disposisi surat, ERD digunakan untuk menggambarkan interaksi antara entitas pengguna, aset, kategori, lokasi, peminjaman, surat masuk, dan disposisi. Relasi antarentitas menjelaskan bagaimana data terkait dapat dihubungkan, misalnya entitas aset terhubung dengan entitas kategori dan entitas lokasi. IBM Entity-Relationship Model Documentation menjadi sumber utama konsep ERD dalam perancangan basis data.

### 2.1.11. LRS

Logical Record Structure (LRS) adalah representasi logis struktur record yang menggambarkan susunan atribut pada entitas berdasarkan relasi antarentitas di ERD. LRS menekankan bagaimana data direpresentasikan dalam bentuk record sehingga hubungan antarentitas dapat diatur secara logis.

Dalam perancangan basis data aplikasi, LRS membantu menentukan struktur record untuk setiap tabel dan memastikan bahwa atribut yang diperlukan dapat direlasikan dengan benar. Sumber IJIS Wiratama (2024) menjelaskan LRS sebagai representasi struktur record dari entitas berdasarkan relasi antarentitas pada ERD. Artikel JSAI (2024) menggambarkan penggunaan LRS dalam perancangan sistem informasi akademik.

Karena LRS saat ini didukung oleh jurnal aplikasi dan perancangan sistem, subbab ini diberi catatan bahwa sumbernya adalah penguat awal, bukan buku teori utama. [PERLU CEK APA 7]

### 2.1.12. Agile Scrum

Agile Scrum adalah model pengembangan perangkat lunak yang bersifat iteratif dan bertahap. Scrum membantu mengelola kebutuhan pengembangan melalui daftar pekerjaan yang tersusun dalam *product backlog*, memilih pekerjaan untuk setiap *sprint*, dan menghasilkan *increment* berupa modul yang dapat diuji.

Scrum Guide 2020 menjelaskan bahwa *product backlog* berisi seluruh kebutuhan sistem, *sprint backlog* memuat pekerjaan yang akan dikerjakan dalam satu sprint, dan *increment* adalah hasil kerja yang siap ditinjau. Pendekatan ini sesuai untuk pengembangan sistem inventaris aset dan disposisi surat karena fitur dapat diimplementasikan dalam beberapa tahapan dan dievaluasi secara berkala.

Model Scrum di sini digunakan sebagai landasan teori untuk menjelaskan pendekatan pengembangan, bukan sebagai catatan historis pelaksanaan peristiwa Scrum tertentu. Setiap sprint dapat mencakup pengerjaan modul login, inventaris aset, surat masuk, disposisi surat, laporan, dan backup.

### 2.1.13. Black-Box Testing

*Black-box testing* adalah teknik pengujian perangkat lunak yang berfokus pada fungsi sistem tanpa melihat struktur internal kode. Penguji memberikan input dan memeriksa output yang dihasilkan sesuai dengan yang diharapkan. Teknik ini cocok untuk menguji fitur aplikasi web karena dapat memeriksa perilaku sistem dari perspektif pengguna.

ISTQB Glossary menjelaskan bahwa black-box testing digunakan untuk memverifikasi fungsionalitas sistem berdasarkan spesifikasi. Dalam aplikasi inventaris aset dan disposisi surat, black-box testing dapat digunakan untuk menguji proses login, input data aset, peminjaman aset, pencatatan surat masuk, disposisi surat, serta pembuatan laporan. Pengujian keamanan dasar dan pengujian kinerja dasar dapat disebut sebagai pendukung, tetapi rincian lebih lanjut dibahas di BAB IV.

## 2.2. Penelitian Terkait

Beberapa penelitian terkait memperkuat dasar penelitian ini. Annisa, Rahayuningsih, dan Anna (2023) melakukan perancangan sistem informasi inventaris sarana dan prasarana sekolah berbasis web. Penelitian tersebut menyoroti permasalahan pencatatan aset yang masih dilakukan secara manual dan kebutuhan penyajian data yang terpusat agar pencarian dan pelaporan menjadi lebih efektif.

Pranoto dan Sediyono (2021) meneliti perancangan sistem informasi inventaris barang berbasis web. Penelitian mereka menunjukkan bahwa pencatatan inventaris manual menyulitkan pengelolaan data barang, pencarian informasi, dan pembuatan laporan. Sistem berbasis web yang dirancang membantu mengelola data aset, mutasi barang, dan pelaporan secara lebih terstruktur.

Mubarok dan Sutaji (2025) membahas perancangan dan implementasi sistem inventaris aset kantor berbasis web pada Dinas Kominfo Lamongan. Penelitian ini menekankan pemanfaatan sistem web untuk meningkatkan efektivitas dan efisiensi pengelolaan aset serta pemantauan peminjaman. Relevansi penelitian ini terletak pada kebutuhan SMPI REJIS untuk mencatat aset, lokasi, status, dan riwayat peminjaman secara digital.

Penelitian Usnaini, Yasin, dan Sianipar (2021) membahas perancangan sistem informasi inventarisasi aset berbasis web pada SDN Rawamangun 09. Penelitian tersebut berangkat dari permasalahan pengelolaan aset yang masih dilakukan secara manual, sehingga proses pencarian data dan penyusunan laporan belum berjalan optimal. Relevansi penelitian tersebut dengan penelitian ini terdapat pada fokus pengelolaan inventaris aset berbasis web. Perbedaannya, penelitian ini tidak hanya membahas inventaris aset, tetapi juga mengintegrasikan pengelolaan disposisi surat dalam satu aplikasi berbasis web pada SMPI REJIS.

Siswaya dan Setiawan (2025) meneliti perancangan sistem pengarsipan dan disposisi surat berbasis web dengan metode RAD. Sistem yang dikembangkan membantu pengelolaan surat masuk, pencatatan disposisi, dan proses tindak lanjut secara lebih terorganisir. Penelitian ini relevan dengan kebutuhan SMPI REJIS untuk memantau status disposisi dan menjaga alur informasi surat.

Rohmawati dan Yulianingsih (2025) meneliti sistem informasi e-disposisi surat berbasis web. Penelitian tersebut memfokuskan pada efisiensi pengelolaan surat dan kemudahan pelacakan dokumen. Hasil penelitian ini relevan bagi SMPI REJIS karena proses disposisi surat yang terstruktur mendukung pelaporan dan tindak lanjut yang lebih cepat.

Londa, Wee, dan Radja (2022) membahas implementasi sistem informasi monitoring disposisi surat masuk dan surat keluar berbasis website. Penelitian mereka menekankan pentingnya monitoring status surat agar proses disposisi tidak terhenti. Relevansi penelitian ini terlihat pada kebutuhan SMPI REJIS untuk memantau alur disposisi dan mengurangi risiko surat tertunda.

Berdasarkan penelitian terdahulu, banyak penelitian menyoroti pengelolaan inventaris aset atau disposisi surat secara terpisah. Penelitian ini berbeda karena mengintegrasikan inventaris aset dan disposisi surat ke dalam satu sistem berbasis web pada SMPI REJIS. Integrasi tersebut diharapkan dapat memperkuat proses administrasi sekolah dengan menyediakan satu platform untuk pencatatan, pemantauan, dan pelaporan.
