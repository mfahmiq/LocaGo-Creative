# BAB I SAMPAI BAB V DRAFT REVIEW CHECK UPDATED

Tanggal dibuat: 2026-07-05

## 1. Status Umum

File ini memperbarui `BAB-I-SAMPAI-V-DRAFT-REVIEW-CHECK.md` setelah patch referensi BAB II. BAB I sampai BAB V sudah tersedia sebagai final arah (BAB I) atau draft revisi (BAB II patch, BAB III, BAB IV, BAB V), tetapi belum final mutlak. Kandidat BAB II terbaru adalah `BAB-II-FINAL-ARAH-REFPATCH-1.md`, menggantikan rujukan `BAB-II-FINAL-ARAH.md` untuk keperluan review lanjutan (file `BAB-II-FINAL-ARAH.md` tetap tidak dihapus dan tetap berlaku sebagai versi sebelumnya).

## 2. File Yang Tersedia

BAB | File | Status | Catatan
---|---|---|---
BAB I | `BAB-I-FINAL-ARAH.md` | Final arah | Masih perlu review marker (`[PERLU DATA]`, `[PERLU CEK REFERENSI]`)
BAB II | `BAB-II-FINAL-ARAH-REFPATCH-1.md` (kandidat terbaru, berdasarkan `BAB-II-FINAL-ARAH.md`) | Final arah + patch referensi | Jumlah jurnal sudah 10 (terpenuhi dengan catatan); masih perlu APA 7 dan Mendeley
BAB III | `BAB-III-REVISI-1.md` | Draft revisi 1 | Perlu review; data institusi masih `[PERLU DATA]`
BAB IV | `BAB-IV-REVISI-1.md` | Draft revisi 1 | Perlu review; 18 marker screenshot/pengujian/kode/hardware
BAB V | `BAB-V-REVISI-1.md` | Draft revisi 1 | Perlu review setelah BAB IV final

## 3. Marker Yang Masih Ada

Marker | BAB I | BAB II (REFPATCH-1) | BAB III | BAB IV | BAB V | Catatan
---|---|---|---|---|---|---
`[PERLU DATA]` | 1 | 0 | 3 | 5 | 0 | BAB I: detail observasi. BAB III: profil, sejarah, struktur organisasi SMPI REJIS. BAB IV: rencana deployment server, versi Windows/browser/editor, spesifikasi hardware.
`[PERLU SITASI]` | 0 | 0 | 0 | 0 | 0 | Tidak ditemukan.
`[PERLU CEK REFERENSI]` | 5 | 0 | 0 | 0 | 0 | BAB I 1.1 Latar Belakang dan 1.5 Metode Penelitian.
`[PERLU CEK APA 7]` | 0 | 1 | 0 | 0 | 0 | BAB II subbab 2.1.11 LRS; tidak dihapus oleh patch referensi. Selain itu, sejumlah referensi lain masih berstatus PERLU CEK/BELUM LENGKAP pada `REFERENSI-APA7-MENDELEY-CHECK-UPDATED.md` (di luar hitungan marker inline BAB II).
`[PERLU CEK OUTLINE]` | 0 | 0 | 0 | 0 | 0 | Tidak ditemukan.
`[PERLU CEK BUKTI]` | 0 | 0 | 0 | 0 | 0 | Tidak ditemukan.
`[PERLU CEK SCREENSHOT]` | 0 | 0 | 0 | 5 | 0 | BAB IV 4.1.3 User Interface.
`[PERLU DATA HASIL PENGUJIAN]` | 0 | 0 | 0 | 7 | 0 | BAB IV 4.3 Testing bagian Pengujian Kinerja Dasar.
`[PERLU CEK BUKTI KODE]` | 0 | 0 | 0 | 1 | 0 | BAB IV 4.2 Code Generation.
`[PERLU CEK SETELAH BAB IV FINAL]` | 0 | 0 | 0 | 0 | 2 | BAB V 5.1 Kesimpulan.
`[BELUM DAPAT DIPASTIKAN]` | 0 | 0 | 0 | 0 | 0 | Tidak ditemukan.

Total marker per BAB: BAB I = 6, BAB II (REFPATCH-1) = 1 (tidak berubah dari sebelum patch), BAB III = 3, BAB IV = 18, BAB V = 2. **Total keseluruhan BAB I-V tetap 30 marker** — patch referensi menambah 1 jurnal dan 2 paragraf sitasi, tetapi tidak menambah maupun mengurangi marker inline.

## 4. Status Minimal 10 Jurnal

Minimal 10 jurnal **sudah terpenuhi dengan catatan** setelah patch referensi (lihat `REFERENSI-APA7-MENDELEY-CHECK-UPDATED.md`): 10 jurnal ilmiah tersedia (9 referensi sebelumnya ditambah Usnaini, Yasin, & Sianipar 2021). Catatan: pemenuhan jumlah ini tidak berarti seluruh referensi sudah siap final — beberapa referensi masih berstatus PERLU CEK atau BELUM LENGKAP dan seluruhnya belum dimasukkan ke Mendeley.

## 5. Konsistensi Utama

Poin 1 sampai 11 pada `BAB-I-SAMPAI-V-DRAFT-REVIEW-CHECK.md` bagian 4 tetap berlaku dan tidak berubah akibat patch referensi ini (judul, objek, role, fitur, deployment, pengujian, larangan Class/Deployment Diagram sebagai subbab utama, serta kepatuhan BAB III/BAB IV terhadap outline resmi). Patch referensi hanya menambah isi pada 2.1.3 dan 2.2 BAB II, tidak mengubah struktur bab manapun.

## 6. Kesiapan DOCX

DOCX draft BAB I sampai BAB V boleh dibuat jika user meminta untuk review. Namun **DOCX final belum boleh disebut final** karena:

1. 30 marker gabungan BAB I-V masih ada.
2. Data institusi (profil, sejarah, struktur organisasi SMPI REJIS) belum tersedia.
3. Seluruh referensi (termasuk yang baru) belum dimasukkan ke Mendeley dan dicek APA 7 secara final.
4. Bukti screenshot, hasil pengujian kinerja, spesifikasi hardware, dan potongan kode tambahan BAB IV masih perlu dilengkapi.
5. Format akhir DOCX (margin, font, penomoran, watermark, caption) sesuai `DOCX_FORMAT_SPEC.md`/`PEDOMAN_AUDIT.md` belum diterapkan.
