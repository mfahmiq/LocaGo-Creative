# REFERENSI BAB II MATRIX UPDATED

No | Subbab | Referensi Direkomendasikan | Status | Catatan Drafting
---|---|---|---|---
1 | 2.1.1 Sistem Informasi | Wahyuni, Muthmainnah, Permana, & Novalima (2025) | SIAP DRAFT | Referensi awal untuk konteks sistem informasi sekolah berbasis web.
2 | 2.1.2 Website | Wahyuni, Muthmainnah, Permana, & Novalima (2025) | SIAP DRAFT | Referensi awal untuk konsep website aplikasi web.
3 | 2.1.3 Inventaris Aset | Annisa, Rahayuningsih, & Anna (2023); Pranoto & Sediyono (2021); Mubarok & Sutaji (2025) | SIAP DRAFT DENGAN CATATAN | Pranoto & Sediyono (2021) halaman perlu cek ulang; Mubarok & Sutaji (2025) DOI halaman resmi jurnal BSI: 10.31294/bianglala.v13i1.12004. Metadata Garuda berbeda, verifikasi ulang saat input ke Mendeley.
4 | 2.1.4 Surat | KBBI; Undang-Undang Nomor 43 Tahun 2009 tentang Kearsipan | SIAP DRAFT | Gunakan KBBI untuk istilah surat dan UU Kearsipan untuk arsip dan aturan kearsipan.
5 | 2.1.5 Disposisi Surat | Siswaya & Setiawan (2025); Rohmawati & Yulianingsih (2025); Londa, Wee, & Radja (2022) | SIAP DRAFT | Tiga penelitian seputar disposisi surat dan monitoring disposisi.
6 | 2.1.6 Basis Data MySQL | MySQL Reference Manual | SIAP DRAFT | Sumber resmi MySQL untuk basis data relasional.
7 | 2.1.7 PHP | PHP Documentation | SIAP DRAFT | Sumber resmi dokumentasi PHP.
8 | 2.1.8 CodeIgniter | CodeIgniter 4 User Guide | SIAP DRAFT | Sumber resmi dokumentasi CodeIgniter 4.
9 | 2.1.9 UML | OMG UML 2.5.1 | SIAP DRAFT | Sumber resmi OMG untuk UML.
10 | 2.1.10 ERD | IBM Entity-Relationship Model Documentation | SIAP DRAFT | Sumber pendukung resmi untuk ERD.
11 | 2.1.11 LRS | Artikel IJIS Wiratama (2024); Artikel JSAI (2024) | SIAP DRAFT DENGAN CATATAN | LRS kini memiliki penguat awal dari jurnal aplikasi/perancangan sistem; tetap catat bahwa sumbernya bukan buku teori utama.
12 | 2.1.12 Agile Scrum | Scrum Guide 2020 | SIAP DRAFT | Sumber resmi Scrum.
13 | 2.1.13 Black-Box Testing | ISTQB Glossary | SIAP DRAFT | Sumber resmi ISTQB.
14 | 2.2 Penelitian Terkait | Annisa, Rahayuningsih, & Anna (2023); Pranoto & Sediyono (2021); Mubarok & Sutaji (2025); Siswaya & Setiawan (2025); Rohmawati & Yulianingsih (2025); Londa, Wee, & Radja (2022) | SIAP DRAFT DENGAN CATATAN | Pilih artikel yang paling relevan dengan inventaris aset dan disposisi surat; periksa halaman dan DOI untuk beberapa sumber.
