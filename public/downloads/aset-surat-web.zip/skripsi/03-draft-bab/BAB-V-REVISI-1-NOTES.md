# BAB V REVISI 1 NOTES

Tanggal dibuat: 2026-07-05

## 1. Status Draft

`BAB-V-REVISI-1.md` adalah draft awal BAB V. Bab ini belum final karena masih bergantung pada penyelesaian marker BAB IV, khususnya marker `[PERLU DATA HASIL PENGUJIAN]` (pengujian kinerja dasar), `[PERLU CEK SCREENSHOT]` (5 halaman), dan `[PERLU CEK BUKTI KODE]` (potongan kode modul non-autentikasi).

## 2. Keterkaitan Dengan BAB I

Kesimpulan poin 1 sampai 5 pada `BAB-V-REVISI-1.md` sudah mengarah pada jawaban atas lima rumusan masalah di `BAB-I-FINAL-ARAH.md` bagian 1.3:

1. "Bagaimana merancang sistem terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS?" — dijawab oleh kesimpulan poin 1 dan 3.
2. "Bagaimana sistem dapat membantu pengelolaan inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup secara terstruktur?" — dijawab oleh kesimpulan poin 1.
3. "Bagaimana penerapan Agile Scrum dalam pengembangan sistem inventaris aset dan disposisi surat berbasis web?" — dijawab oleh kesimpulan poin 2.
4. "Bagaimana hasil pengujian sistem melalui black-box testing, pengujian keamanan dasar, dan pengujian kinerja dasar terhadap fungsi utama aplikasi?" — dijawab oleh kesimpulan poin 4, tetapi masih bergantung pada penyelesaian marker BAB IV sehingga diberi tanda `[PERLU CEK SETELAH BAB IV FINAL]`.
5. "Apakah sistem yang dirancang dapat mendukung kebutuhan administrasi aset dan surat pada SMPI REJIS?" — dijawab secara umum oleh kesimpulan poin 1 dan 5, dengan batasan lingkungan lokal.

Kesimpulan tidak menjawab rumusan masalah dengan klaim yang melampaui bukti BAB III/BAB IV, sesuai batasan yang berlaku.

## 3. Keterkaitan Dengan BAB III Dan BAB IV

BAB V mengambil dasar dari analisis masalah dan analisis kebutuhan pada BAB III (`BAB-III-REVISI-1.md` bagian 3.2.1 dan 3.2.2), serta hasil desain, implementasi, dan pengujian pada BAB IV (`BAB-IV-REVISI-1.md` bagian 4.1, 4.2, dan 4.3). Karena BAB III masih memiliki 3 marker `[PERLU DATA]` untuk data institusi (profil, sejarah, struktur organisasi SMPI REJIS) dan BAB IV masih memiliki 18 marker, kesimpulan dan saran pada BAB V ini tetap perlu dicek ulang setelah kedua bab tersebut lebih lengkap, khususnya bagian kesimpulan poin 4 yang menyinggung hasil pengujian.

## 4. Marker Yang Masih Ada

Marker | Jumlah | Lokasi
---|---|---
`[PERLU CEK SETELAH BAB IV FINAL]` | 2 | Akhir paragraf kesimpulan poin 4 dan penutup bagian 5.1 Kesimpulan
`[PERLU DATA]` | 0 | -
`[PERLU SITASI]` | 0 | -
`[PERLU CEK REFERENSI]` | 0 | -
`[PERLU CEK APA 7]` | 0 | -
`[PERLU CEK OUTLINE]` | 0 | -
`[PERLU CEK BUKTI]` | 0 | -
`[PERLU CEK SCREENSHOT]` | 0 | -
`[PERLU DATA HASIL PENGUJIAN]` | 0 | -
`[PERLU CEK BUKTI KODE]` | 0 | -
`[BELUM DAPAT DIPASTIKAN]` | 0 | -

Total marker BAB V: 2.

## 5. Bagian Yang Perlu Review

1. Redaksi kesimpulan poin 4 perlu direview ulang setelah pengujian kinerja dasar BAB IV memiliki data pengukuran waktu respons, agar kalimat "42 skenario berstatus valid" tetap konsisten dengan hasil pengujian terbaru bila ada perubahan.
2. Saran poin 1 sampai 3 (pengembangan ke server, pengujian produksi, penguatan keamanan) perlu dipastikan tidak dibaca sebagai klaim bahwa sistem sudah siap produksi — saran ini bersifat arah pengembangan lanjutan, bukan bagian dari hasil penelitian saat ini.
3. Perlu konfirmasi user/Maestro apakah 9 poin saran sudah cukup atau perlu disesuaikan dengan kebutuhan pembimbing.
4. Perlu dipastikan kesimpulan tidak ditulis ulang menjadi seolah semua marker BAB IV sudah selesai, sesuai batasan wajib pada instruksi kerja.

## 6. Rekomendasi Berikutnya

BAB V perlu direview ulang setelah BAB IV final, terutama setelah bukti screenshot, hasil pengujian, spesifikasi hardware, dan data kinerja dasar dilengkapi.
