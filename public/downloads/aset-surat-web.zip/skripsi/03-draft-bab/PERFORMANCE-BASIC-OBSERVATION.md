# Performance Basic Observation

Tanggal: 2026-07-05  
Lingkup: pengamatan waktu respons sederhana pada lingkungan lokal Laragon.  
Mode: satu kali pengamatan navigasi lokal untuk setiap proses.  
Catatan keamanan: credential, token, session, cookie, dan data sensitif tidak dicatat.

## Batasan Pengujian

Pengujian ini hanya pengamatan sederhana pada lingkungan lokal Laragon/CodeIgniter development server. Pengujian ini bukan load testing, bukan stress testing, bukan penetration testing, dan bukan benchmark server produksi.

## Lingkungan

| Item | Nilai |
|---|---|
| URL pengamatan | `http://localhost:8080` |
| Server | CodeIgniter development server lokal |
| Database | MySQL/MariaDB lokal Laragon |
| Browser | Browser lokal melalui sesi Codex |
| Login | Menggunakan akun demo lokal tanpa mencatat credential |
| Migration/seeder | Tidak dijalankan |
| Perubahan database | Tidak ada CRUD/data bisnis yang diubah; login lokal dapat memperbarui metadata autentikasi seperti waktu login terakhir akun demo |

## Metode Pengamatan

1. Proses login diukur dari klik tombol masuk sampai dashboard tampil.
2. Proses lain diukur dari awal navigasi URL sampai halaman selesai dimuat pada status `domcontentloaded`.
3. Setiap proses diamati satu kali pada lingkungan lokal yang sama.
4. Angka waktu respons digunakan sebagai bukti observasi dasar BAB IV, bukan kesimpulan performa produksi.

## Hasil Pengamatan Waktu Respons

| No | Proses | URL/Route | Status | Waktu Respons |
|---:|---|---|---|---:|
| 1 | Login | `/login` ke `/dashboard` | Berhasil | 2.860 ms |
| 2 | Dashboard | `/dashboard` | Berhasil | 1.607 ms |
| 3 | Data Aset | `/assets` | Berhasil | 1.273 ms |
| 4 | Surat Masuk | `/incoming-letters` | Berhasil | 1.200 ms |
| 5 | Laporan | `/reports` | Berhasil | 1.055 ms |
| 6 | Backup | `/backup` | Berhasil | 1.013 ms |

## Ringkasan

Seluruh proses yang diamati berhasil diakses pada lingkungan lokal. Waktu respons berada pada kisaran 1.013 ms sampai 2.860 ms dalam satu kali pengamatan lokal. Angka ini cukup digunakan sebagai bukti pengujian kinerja dasar sederhana pada BAB IV dengan catatan keterbatasan lingkungan lokal.

## Catatan Untuk BAB IV

Kalimat yang aman digunakan:

> Pengujian kinerja dasar dilakukan melalui pengamatan sederhana terhadap waktu respons beberapa halaman utama pada lingkungan lokal Laragon. Hasil pengamatan menunjukkan seluruh halaman yang diuji dapat diakses, dengan waktu respons lokal yang tercatat pada tabel pengujian.

Kalimat yang harus dihindari:

1. Klaim load testing.
2. Klaim stress testing.
3. Klaim penetration testing.
4. Klaim benchmark server produksi.
5. Klaim sistem pasti cepat pada seluruh kondisi penggunaan.
