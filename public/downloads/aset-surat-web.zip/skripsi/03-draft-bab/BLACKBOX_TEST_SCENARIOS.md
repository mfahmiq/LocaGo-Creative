# BLACKBOX_TEST_SCENARIOS

## Status

- Tanggal dibuat: 2026-07-04
- Tujuan: rancangan skenario pengujian black-box untuk BAB IV `4.3 Testing`.
- Status umum: skenario tersedia, hasil aktual sebagian besar belum diverifikasi karena login dan database aktif belum berhasil diverifikasi.
- Catatan keamanan: credential, password, token, session, cookie, dan data sensitif tidak dicantumkan.

## Ketentuan Pengisian Hasil Aktual

- Kolom `Hasil Aktual` hanya boleh diisi setelah pengujian benar-benar dilakukan.
- Jika belum diuji, isi dengan `belum diverifikasi`.
- Gunakan data dummy yang aman.
- Jangan mencantumkan password, token, session, cookie, atau isi dokumen upload.

## Tabel Skenario Pengujian Black-Box

| No | Modul | Skenario Uji | Data Uji | Hasil yang Diharapkan | Hasil Aktual | Status | Keterangan |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BB-01 | Login | Membuka halaman login | Akses `/login` | Halaman login tampil | Halaman login merespons HTTP 200 | valid | Terverifikasi tanpa menampilkan isi token/form |
| BB-02 | Login | Login dengan data valid | Akun demo yang tersedia, nilai tidak dicantumkan | Pengguna masuk ke dashboard sesuai role | Login berhasil dan diarahkan ke dashboard | valid | Detail credential tidak dicantumkan |
| BB-03 | Login | Login dengan data tidak valid | Username/password dummy salah | Sistem menolak login dan menampilkan pesan gagal | Tetap berada di halaman login | valid | Data uji dummy, bukan credential asli |
| BB-04 | Akses Route | Mengakses dashboard tanpa login | Akses `/dashboard` tanpa session | Sistem mengarahkan ke login | HTTP 302 redirect ke login | valid | Terverifikasi via HTTP tanpa session |
| BB-05 | Dashboard | Membuka dashboard setelah login | User valid | Ringkasan data, grafik, dan monitoring tampil | `/dashboard` merespons HTTP 200 setelah login | valid | Screenshot dashboard dibuat |
| BB-06 | Pengguna | Admin membuka daftar pengguna | User role admin | Daftar pengguna tampil | `/users` merespons HTTP 200 dengan role admin | valid | Modul admin only |
| BB-07 | Pengguna | Admin menambah pengguna | Data dummy pengguna nonaktif | Data pengguna tersimpan dan tampil di daftar | Data pengguna dummy nonaktif tersimpan dan tampil di daftar | valid | Detail login dummy tidak dicantumkan |
| BB-08 | Aset | Membuka daftar aset | User role admin/operator/pimpinan | Daftar aset tampil | `/assets` merespons HTTP 200 setelah login | valid | Screenshot daftar aset dibuat |
| BB-09 | Aset | Menambah aset valid | Kode aset, nama, kategori, lokasi, jumlah, kondisi | Data aset tersimpan | Data aset dummy tersimpan dan muncul di daftar | valid | Kode dummy `AS-UJI-*` |
| BB-10 | Aset | Menambah aset tanpa field wajib | Field wajib dikosongkan | Sistem menampilkan validasi gagal | Sistem kembali ke form tambah aset | valid | Tidak menyimpan data kosong |
| BB-11 | Aset | Filter daftar aset | Kata kunci/kategori/lokasi/kondisi | Daftar aset terfilter sesuai input | Filter kode dummy menampilkan aset uji | valid | Berdasarkan pencarian `AS-UJI-*` |
| BB-12 | Aset | Upload foto aset valid | File gambar dummy sesuai batasan | Foto tersimpan dan tampil pada detail | Upload PNG dummy diterima saat tambah aset | valid | File dummy non-sensitif |
| BB-13 | Aset | Upload foto tidak valid | File bukan gambar | Sistem menolak upload | Sistem kembali ke form tambah aset dan tidak membuat link detail record | valid | File TXT dummy ditolak |
| BB-14 | Transaksi Aset | Membuka daftar transaksi aset | User role admin/operator/pimpinan | Daftar transaksi tampil | `/asset-transactions` merespons HTTP 200 setelah login | valid | Daftar transaksi berhasil dibuka |
| BB-15 | Transaksi Aset | Membuat transaksi aset valid | Unit peminjam, nama peminjam, tanggal, item aset | Transaksi tersimpan dengan status awal | Transaksi aset dummy tersimpan dan detail merespons HTTP 200 | valid | Menggunakan aset dummy |
| BB-16 | Transaksi Aset | Membuat transaksi tanpa item aset | Header transaksi tanpa item | Sistem menampilkan validasi gagal | Sistem kembali ke form transaksi aset | valid | Tidak membuat transaksi tanpa item |
| BB-17 | Transaksi Aset | Mencatat pengembalian aset | Status pengembalian dan kondisi akhir | Transaksi berubah sesuai status pengembalian | Status transaksi berubah menjadi dikembalikan | valid | Form pengembalian berhasil |
| BB-18 | Transaksi Aset | Mengunduh PDF transaksi | Transaksi yang ada | File PDF transaksi dapat diunduh | Route PDF merespons HTTP 200 `application/pdf` | valid | File PDF dummy diunduh sebagai bukti, tidak ditampilkan isinya |
| BB-19 | Surat Masuk | Membuka daftar surat masuk | User role admin/operator/pimpinan | Daftar surat masuk tampil | `/incoming-letters` merespons HTTP 200 setelah login | valid | Screenshot surat masuk dibuat |
| BB-20 | Surat Masuk | Menambah surat masuk valid | Nomor, tanggal, pengirim, prioritas, perihal | Data surat masuk tersimpan | Surat masuk dummy tersimpan dan detail merespons HTTP 200 | valid | Nomor dummy `SM-UJI-*` |
| BB-21 | Surat Masuk | Menambah surat masuk tanpa field wajib | Field wajib dikosongkan | Sistem menampilkan validasi gagal | Sistem kembali ke form surat masuk | valid | Tidak menyimpan data kosong |
| BB-22 | Surat Masuk | Upload lampiran valid | PDF/gambar dummy aman | Lampiran tersimpan | Upload PDF dummy diterima saat tambah surat masuk | valid | File dummy non-sensitif |
| BB-23 | Surat Masuk | Ekstraksi tanggal dari lampiran | Lampiran dummy dengan tanggal | Sistem mencoba membaca tanggal dari lampiran | Endpoint ekstraksi tanggal merespons HTTP 200 | valid | PDF dummy tidak memuat data sensitif |
| BB-24 | Disposisi | Membuat disposisi surat masuk | Target unit, instruksi, due date | Disposisi tersimpan dan status surat berubah | Disposisi dummy tersimpan dari detail surat masuk | valid | Role admin digunakan |
| BB-25 | Disposisi | Mengubah status disposisi | Status proses/selesai/diarsipkan | Status disposisi dan status surat sinkron | Status disposisi dummy berubah menjadi selesai | valid | Status surat masuk ikut tersinkron |
| BB-26 | Surat Keluar | Membuka daftar surat keluar | User role admin/operator/pimpinan | Daftar surat keluar tampil | `/outgoing-letters` merespons HTTP 200 setelah login | valid | Screenshot surat keluar dibuat |
| BB-27 | Surat Keluar | Menambah surat keluar valid | Nomor, tanggal, penerima, unit tujuan, perihal | Data surat keluar tersimpan | Surat keluar dummy tersimpan dan detail merespons HTTP 200 | valid | Nomor dummy `SK-UJI-*` |
| BB-28 | Surat Keluar | Update status diterima tujuan tanpa penerima/tanggal | Status diterima_tujuan tanpa data penerima | Sistem menolak dan meminta data penerima/tanggal | Sistem kembali ke detail surat keluar tanpa data penerima lengkap | valid | Validasi status diterima berjalan |
| BB-29 | Surat Keluar | Update status pengiriman valid | Status dan data penerima valid | Status surat keluar diperbarui | Status surat keluar berubah menjadi diterima tujuan | valid | Data penerima dummy digunakan |
| BB-30 | Laporan | Membuka halaman laporan | User role admin/operator/pimpinan | Halaman pilihan/filter laporan tampil | `/reports` merespons HTTP 200 setelah login | valid | Screenshot laporan dibuat |
| BB-31 | Laporan | Menampilkan laporan aset | Jenis laporan assets | Laporan aset tampil | `/reports/assets` merespons HTTP 200 setelah login | valid | Laporan aset berhasil dibuka |
| BB-32 | Laporan | Export CSV laporan | Jenis laporan valid | File CSV dihasilkan | `/reports/assets/csv` merespons HTTP 200 | valid | Isi CSV tidak ditampilkan |
| BB-33 | Laporan | Cetak laporan | Jenis laporan valid | Tampilan cetak laporan muncul | `/reports/assets/print` merespons HTTP 200 | valid | Tampilan cetak berhasil dibuka |
| BB-34 | Backup | Membuka halaman backup sebagai admin | User role admin | Halaman backup tampil | `/backup` merespons HTTP 200 dengan role admin | valid | Screenshot backup dibuat |
| BB-35 | Backup | Mengunduh backup database | User role admin | File SQL backup diunduh | `POST /backup/download` merespons HTTP 200 | valid | Isi backup tidak ditampilkan |
| BB-36 | Role Access | Operator mengakses halaman pengguna | User role operator | Sistem menolak/redirect sesuai role | HTTP 302 redirect ke dashboard | valid | Detail akun demo tidak dicantumkan |
| BB-37 | Role Access | Pimpinan mengakses form tambah aset | User role pimpinan | Sistem menolak/redirect sesuai role | HTTP 302 redirect ke dashboard | valid | Detail akun demo tidak dicantumkan |
| BB-38 | ERD | Membuka halaman ERD setelah login | User valid | Halaman ERD tampil | `/erd` merespons HTTP 200 setelah login | valid | Screenshot ERD dibuat |
| BB-39 | Aset | Membuka form tambah aset | User role admin | Form tambah aset tampil | `/assets/create` merespons HTTP 200 | valid | Tidak menyimpan data baru |
| BB-40 | Transaksi Aset | Membuka form transaksi aset | User role admin | Form transaksi aset tampil | `/asset-transactions/create` merespons HTTP 200 | valid | Tidak menyimpan data baru |
| BB-41 | Surat Masuk | Membuka form surat masuk | User role admin | Form surat masuk tampil | `/incoming-letters/create` merespons HTTP 200 | valid | Tidak menyimpan data baru |
| BB-42 | Surat Keluar | Membuka form surat keluar | User role admin | Form surat keluar tampil | `/outgoing-letters/create` merespons HTTP 200 | valid | Tidak menyimpan data baru |

## Ringkasan Status Pengujian

Pembaruan 2026-07-04 setelah pengujian CRUD terkontrol:

- Total skenario: 42.
- Valid: 42.
- Gagal: 0.
- Belum diverifikasi: 0.

Valid terverifikasi:

- Halaman login dapat diakses.
- Login valid berhasil dan masuk ke dashboard.
- Login tidak valid tetap berada di halaman login.
- Route internal mengarahkan ke login bila belum ada session.
- Dashboard, ERD, pengguna, aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup dapat dibuka setelah login.
- Form tambah aset, transaksi aset, surat masuk, dan surat keluar dapat dibuka tanpa menyimpan data.
- Laporan aset, CSV laporan aset, dan tampilan cetak laporan aset merespons berhasil.
- Backup download merespons berhasil tanpa menampilkan isi backup.
- Pembatasan role operator dan pimpinan pada route tertentu bekerja dengan redirect.
- CRUD tambah/edit/detail aset terverifikasi dengan data dummy.
- Upload foto aset dummy dan lampiran surat dummy terverifikasi.
- Validasi input kosong pada form penting terverifikasi.
- Transaksi aset, PDF transaksi, dan pengembalian aset terverifikasi.
- Surat masuk, disposisi, surat keluar, dan update status pengiriman terverifikasi.

Catatan:

- Pengujian delete tidak dilakukan karena aturan tahap ini melarang menghapus data lama.
- Data dummy sengaja dibiarkan agar dapat diperiksa ulang.

## Sumber Skenario

- `APPLICATION_VERIFICATION.md`
- `APLIKASI_FEATURE_AUDIT.md`
- `SCRUM_MAPPING_AUDIT.md`
- `app/Config/Routes.php`
- `app/Controllers/*.php`
- `app/Models/*.php`
- `app/Views/*`
