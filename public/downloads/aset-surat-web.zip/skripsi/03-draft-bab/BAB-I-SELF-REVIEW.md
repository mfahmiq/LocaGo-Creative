# BAB I SELF-REVIEW

Status dokumen: checklist review untuk `BAB-I-DRAFT-AKHIR.md` sebelum lanjut BAB II.

## Ringkasan Review

Draft BAB I sudah disusun berdasarkan judul final, outline 156, pedoman penulisan, audit aplikasi, mapping Scrum, dan batasan project. Draft belum dianggap final karena masih memerlukan pengecekan user terhadap data institusi, bukti riset, dan referensi ilmiah.

## Checklist Kesesuaian Pedoman dan Outline 156

| Aspek | Status | Catatan |
| --- | --- | --- |
| Struktur BAB I mengikuti outline 156 | Sesuai | Memuat 1.1 sampai 1.6, termasuk 1.5.1 dan 1.5.2. |
| Judul bab dan subbab | Sesuai awal | Format final DOCX tetap perlu mengikuti Times New Roman, ukuran, spasi, margin, dan penomoran halaman dari pedoman. |
| Perumusan masalah berbentuk pertanyaan | Sesuai | Lima rumusan masalah sudah ditulis dalam bentuk pertanyaan. |
| Tujuan menjawab rumusan masalah | Sesuai awal | Tujuan sudah mencakup perancangan sistem, fitur, teknologi, Scrum, dan pengujian. |
| Manfaat penelitian | Sesuai | Manfaat mencakup penulis, SMPI REJIS, dan pembaca. |
| Ruang lingkup | Sesuai | Scope mengikuti fitur aplikasi yang ditemukan dan diverifikasi. |
| Sitasi | Belum lengkap | Semua klaim teori masih diberi `[PERLU SITASI]`. |
| Data institusi | Belum lengkap | Profil, sejarah, struktur organisasi, observasi, dan wawancara formal masih diberi `[PERLU DATA]`. |

## Konsistensi Judul, Objek, Metode, dan Scope

| Elemen | Status | Catatan |
| --- | --- | --- |
| Judul skripsi | Sesuai | Menggunakan judul final: Perancangan Sistem Terintegrasi Inventaris Aset dan Disposisi Surat Berbasis Web pada SMPI REJIS. |
| Objek penelitian | Sesuai | Objek ditulis sebagai SMPI REJIS. |
| Metode pengembangan | Sesuai dengan batasan | Agile Scrum ditulis sebagai model pengembangan dan mapping fitur, bukan riwayat historis tanpa bukti. |
| Framework | Sesuai | CodeIgniter 4 disebut sebagai framework aplikasi. |
| Database | Sesuai | MySQL/MariaDB disebut sebagai basis data. |
| Lingkungan pengujian | Sesuai | Laragon/local environment disebut secara eksplisit. |
| Status deployment | Aman | Draft menyatakan tidak membahas penerapan produksi pada server daring sekolah. |

## Review Rumusan Masalah dan Tujuan

Rumusan masalah sudah mencakup:

1. Perancangan sistem terintegrasi inventaris aset dan disposisi surat.
2. Dukungan fitur inti aplikasi.
3. Penggunaan CodeIgniter 4 dan MySQL/MariaDB.
4. Penggunaan Agile Scrum secara aman.
5. Pengujian black-box.

Tujuan penelitian sudah menjawab arah rumusan masalah tersebut. Namun, setelah BAB II memiliki referensi teori, kalimat tujuan dan rumusan masalah dapat dipoles agar terminologi teknis lebih konsisten dengan sitasi.

## Review Manfaat Penelitian

Manfaat sudah mencakup:

1. Penulis.
2. SMPI REJIS.
3. Pembaca.

Catatan: manfaat untuk SMPI REJIS masih bersifat umum dan belum memakai data kuantitatif karena data resmi sekolah belum tersedia. Jangan menambahkan angka, tanggal, atau nama pihak tanpa sumber.

## Review Agile Scrum

Status: aman dengan catatan.

Draft menuliskan Agile Scrum sebagai model pengembangan yang digunakan untuk:

1. Menyusun product backlog.
2. Memetakan modul ke sprint.
3. Menghubungkan implementasi fitur dengan pengujian.

Draft tidak menulis tanggal sprint, nama Scrum Master, Product Owner, anggota tim, Daily Scrum, Sprint Review, atau Sprint Retrospective sebagai fakta historis. Bagian tersebut tetap membutuhkan data bila user ingin menjadikannya narasi proses aktual.

## Review Ruang Lingkup Aplikasi

Scope sudah sesuai dengan fitur yang ditemukan:

1. Autentikasi dan role.
2. Dashboard.
3. Manajemen pengguna.
4. Inventaris aset.
5. Transaksi atau peminjaman aset.
6. Surat masuk.
7. Disposisi surat.
8. Surat keluar.
9. Laporan.
10. Backup database.

ERD sudah diposisikan sebagai artefak dokumentasi dan perancangan, bukan fitur operasional pengguna.

## Review Bahasa, Pengutipan, Singkatan, dan Kata Ulang

| Aspek | Status | Catatan |
| --- | --- | --- |
| Bahasa akademik | Sesuai awal | Draft menghindari gaya promosi dan pembuka terlalu umum. |
| Sitasi | Belum lengkap | Penanda `[PERLU SITASI]` masih dipakai sampai referensi tersedia. |
| Singkatan tidak resmi | Sesuai | Tidak memakai singkatan seperti `dll`, `dst`, `yg`, atau `thd`. |
| Kata ulang | Sesuai | Kata ulang ditulis penuh. |
| Istilah asing | Perlu cek final | Istilah seperti sprint, product backlog, framework, dan black-box perlu dipastikan konsisten dengan BAB II dan dapat ditulis miring saat DOCX final bila diwajibkan. |
| Kutipan langsung | Tidak digunakan | Draft belum memuat kutipan langsung. |
| Kutipan tidak langsung | Belum final | Klaim teori masih diberi marker sampai referensi ilmiah dipilih. |

## Claims Yang Perlu Dicek

1. Profil resmi SMPI REJIS.
2. Sejarah singkat SMPI REJIS.
3. Struktur organisasi SMPI REJIS.
4. Tanggal dan tempat observasi.
5. Identitas atau jabatan narasumber wawancara yang boleh ditulis.
6. Bukti surat riset atau surat keabsahan data.
7. Referensi sistem informasi, website, inventaris aset, surat, disposisi, MySQL, PHP, CodeIgniter, UML, ERD, LRS, Agile Scrum, dan black-box testing.
8. Referensi minimal penelitian terkait untuk BAB II.

## Marker Dalam Draft BAB I

Perlu dihitung ulang dengan pencarian teks sebelum finalisasi. Target marker:

| Marker | Fungsi |
| --- | --- |
| `[PERLU DATA]` | Data institusi, observasi, wawancara, atau bukti proses yang belum tersedia. |
| `[PERLU SITASI]` | Klaim teori atau metodologis yang membutuhkan referensi ilmiah. |
| `[BELUM DAPAT DIPASTIKAN]` | Dipakai bila ada aturan atau fakta yang tidak bisa dipastikan dari sumber tersedia. |

## Rekomendasi Sebelum BAB II

1. User meninjau redaksi BAB I, terutama latar belakang, rumusan masalah, tujuan, dan ruang lingkup.
2. Lengkapi data SMPI REJIS yang boleh ditulis: profil singkat, sejarah, struktur organisasi, dan bukti riset.
3. Siapkan referensi BAB II sesuai struktur yang sudah dikoreksi.
4. Jangan lanjut BAB II sebelum BAB I disetujui secara arah dan scope.
5. Saat BAB II dibuat, gunakan `[PERLU SITASI]` sampai referensi benar-benar dipilih dan jangan membuat sitasi palsu.
