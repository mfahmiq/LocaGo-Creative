# BAB III REVISI 1 NOTES

Tanggal dibuat: 2026-07-05

## 1. Status Draft

`BAB-III-REVISI-1.md` adalah draft revisi 1 BAB III, disusun mengikuti struktur resmi hasil koreksi outline (ANALISIS DAN PERANCANGAN APLIKASI: 3.1 Tinjauan Perusahaan, 3.2 Analisis Aplikasi, 3.3 Rancangan Algoritma). Draft ini belum final dan masih memuat marker `[PERLU DATA]` untuk bagian yang belum memiliki bukti.

## 2. File Yang Digunakan

1. `BAB-I-FINAL-ARAH.md` — sumber identifikasi masalah, wawancara, dan konteks SMPI REJIS.
2. `BAB-II-FINAL-ARAH.md` — konteks landasan teori (tidak dikutip langsung di BAB III).
3. `OUTLINE-CORRECTION-BAB-III-IV.md` dan `BAB-III-IV-STRUCTURE-FINAL-ARAH.md` — struktur resmi BAB III.
4. `BAB-III-DRAFT-PLAN.md` dan `BAB-III-DATA-NEEDED.md` — rencana dan kebutuhan data BAB III.
5. `APLIKASI_FEATURE_AUDIT.md` — dasar analisis masalah, analisis kebutuhan, dan rancangan algoritma.
6. `DATABASE_ERD_AUDIT.md` — dasar penyebutan role dan mapping tabel (dirujuk tanpa detail struktur tabel karena struktur tabel ditempatkan di BAB IV).
7. `APPLICATION_VERIFICATION.md` — bukti pembatasan hak akses role (operator ditolak akses `/users`, pimpinan ditolak akses `/assets/create`).
8. `SKRIPSI_BLUEPRINT.md` dan `PERSEPSI_PROJECT_CHECKPOINT.md` — konteks umum project dan catatan bahwa profil/sejarah/struktur organisasi SMPI REJIS belum tersedia.

## 3. Struktur Yang Dipakai

```text
BAB III
ANALISIS DAN PERANCANGAN APLIKASI

3.1. Tinjauan Perusahaan
3.1.1. Sejarah Perusahaan
3.1.2. Struktur Organisasi
3.2. Analisis Aplikasi
3.2.1. Analisis Masalah
3.2.2. Analisis Kebutuhan
3.3. Rancangan Algoritma
```

Struktur ini sesuai `BAB-III-IV-STRUCTURE-FINAL-ARAH.md` dan tidak memuat diagram teknis (Use Case, Activity, Sequence, ERD, LRS) atau tampilan antarmuka — seluruhnya ditempatkan di BAB IV.

## 4. Marker Yang Masih Ada

Marker | Jumlah | Lokasi
---|---|---
`[PERLU DATA]` | 3 | 3.1 Tinjauan Perusahaan (profil resmi), 3.1.1 Sejarah Perusahaan, 3.1.2 Struktur Organisasi
`[PERLU CEK BUKTI]` | 0 | -
`[PERLU CEK SCREENSHOT]` | 0 | Tidak relevan untuk BAB III karena screenshot ditempatkan di BAB IV 4.1.3
`[PERLU DATA HASIL PENGUJIAN]` | 0 | Tidak relevan untuk BAB III karena hasil pengujian ditempatkan di BAB IV 4.3
`[PERLU CEK BUKTI KODE]` | 0 | Tidak relevan untuk BAB III karena kode ditempatkan di BAB IV 4.2
`[BELUM DAPAT DIPASTIKAN]` | 0 | -

Total marker BAB III: 3.

## 5. Data Yang Masih Kurang

1. Profil resmi SMPI REJIS (alamat lengkap, status yayasan/kelembagaan, visi dan misi).
2. Sejarah singkat SMPI REJIS (tahun berdiri, latar belakang pendirian, perkembangan).
3. Struktur organisasi resmi SMPI REJIS (bagan organisasi dan nama pejabat).

Ketiga data ini sudah dicatat sebelumnya pada `BAB-III-DATA-NEEDED.md` bagian 1 (Data Institusi Yang Dibutuhkan) dan belum berubah statusnya.

## 6. Bagian Yang Perlu Review

1. Redaksi 3.1.2 Struktur Organisasi yang menyebut pihak terkait secara umum (pimpinan sekolah, wakil kepala sekolah, tata usaha/operator, staf) perlu dikonfirmasi user agar tidak disalahartikan sebagai struktur organisasi resmi.
2. Tabel Analisis Masalah (3.2.1) dan Analisis Kebutuhan (3.2.2) perlu direview kesesuaiannya dengan bahasa akademik dan pedoman APA 7/istilah baku sebelum menjadi naskah final.
3. Rancangan Algoritma (3.3) ditulis sebagai langkah bernomor berdasarkan alur nyata aplikasi; perlu direview apakah dosen pembimbing meminta notasi pseudocode formal atau tetap dalam bentuk naratif bernomor.
4. Kebutuhan nonfungsional poin 9 sengaja menegaskan batasan lingkungan lokal; perlu dipertahankan agar konsisten dengan BAB I dan BAB II.

## 7. Rekomendasi Berikutnya

BAB III revisi 1 sudah dapat direview oleh user dan Maestro. Data institusi (profil, sejarah, struktur organisasi) perlu dilengkapi sebelum BAB III dapat disebut final untuk DOCX. Setelah review, langkah berikutnya adalah menyinkronkan hasil review BAB III dengan `BAB-I-SAMPAI-IV-DRAFT-REVIEW-CHECK.md`.
