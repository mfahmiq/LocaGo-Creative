# BAB I SAMPAI V MARKER COUNT AFTER LOCALPATCH

Tanggal dibuat: 2026-07-05

## 1. Status

Patch lokal sudah dilakukan untuk marker referensi BAB I dan bukti kode BAB IV, sesuai hasil `SKRIPSI-DRAFT-REVIEW-BAB-I-V-MARKER-AUDIT.md` yang menyatakan kedua kelompok marker tersebut dapat diselesaikan dari file lokal tanpa membutuhkan data sekolah, screenshot, hasil pengujian, Mendeley/APA 7, atau spesifikasi hardware baru. File terbaru yang dipakai untuk hitungan ini:

1. `BAB-I-FINAL-ARAH-REFPATCH-1.md` (kandidat BAB I terbaru)
2. `BAB-II-FINAL-ARAH-REFPATCH-1.md` (tidak diubah pada tahap ini)
3. `BAB-III-REVISI-1.md` (tidak diubah pada tahap ini)
4. `BAB-IV-REVISI-1-CODEPATCH-1.md` (kandidat BAB IV terbaru)
5. `BAB-V-REVISI-1.md` (tidak diubah pada tahap ini)

## 2. Hitungan Marker Sebelum Patch

BAB | Jumlah
---|---
BAB I | 6
BAB II | 1
BAB III | 3
BAB IV | 18
BAB V | 2
**Total** | **30**

## 3. Hitungan Marker Setelah Patch

BAB | Jumlah Sebelum | Jumlah Sesudah | Selisih | Catatan
---|---|---|---|---
BAB I | 6 | **1** | -5 | 5 marker `[PERLU CEK REFERENSI]` selesai (sitasi Wahyuni et al. 2025, Scrum Guide 2020, ISTQB Glossary disisipkan dari BAB II); marker `[PERLU DATA]` (observasi) tetap ada
BAB II | 1 | 1 | 0 | Tidak diubah pada tahap ini; marker `[PERLU CEK APA 7]` (LRS) tetap ada
BAB III | 3 | 3 | 0 | Tidak diubah pada tahap ini; 3 marker `[PERLU DATA]` (profil, sejarah, struktur organisasi) tetap ada
BAB IV | 18 | **17** | -1 | Marker `[PERLU CEK BUKTI KODE]` selesai (uraian code generation 6 modul lain ditambahkan berdasarkan pembacaan 7 controller); 17 marker lain (`[PERLU DATA]` x5, `[PERLU CEK SCREENSHOT]` x5, `[PERLU DATA HASIL PENGUJIAN]` x7) tetap ada
BAB V | 2 | 2 | 0 | Tidak diubah pada tahap ini; 2 marker `[PERLU CEK SETELAH BAB IV FINAL]` tetap ada
**Total** | **30** | **24** | **-6** | Hasil sesuai target perkiraan (BAB I turun ke 1, BAB IV turun ke 17, total 24)

Hasil hitungan sesuai dengan target perkiraan pada instruksi kerja: BAB I turun dari 6 menjadi 1, BAB IV turun dari 18 menjadi 17, dan total turun dari 30 menjadi 24. Tidak ada penyimpangan yang perlu dijelaskan.

## 4. Marker Yang Masih Tersisa

Kategori | Jumlah | Rincian
---|---|---
Butuh data user/sekolah | 5 | BAB I: 1 (detail observasi); BAB III: 3 (profil, sejarah, struktur organisasi SMPI REJIS); BAB IV: 1 (rencana deployment/publikasi software ke server)
Butuh screenshot | 5 | BAB IV 4.1.3 User Interface: manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, cetak laporan
Butuh hasil pengujian | 7 | BAB IV 4.3 Testing — Pengujian Kinerja Dasar: 6 proses (login, dashboard, data aset, surat masuk, laporan/CSV, backup) + 1 kalimat penutup subbab
Butuh Mendeley/APA 7 | 1 | BAB II 2.1.11 LRS (sumber masih jurnal penguat awal); seluruh referensi lain juga tetap perlu verifikasi Mendeley meski tidak menyumbang marker inline tambahan
Butuh spesifikasi hardware | 4 | BAB IV 4.4.2: versi Windows, versi browser, versi editor pengembangan, spesifikasi hardware (prosesor/RAM/penyimpanan)
Butuh review manual | 2 | BAB V 5.1 Kesimpulan poin 4 dan penutup, bergantung pada penyelesaian marker BAB IV di atas
**Total** | **24** | -

## 5. Rekomendasi Berikutnya

Setelah patch lokal, langkah berikutnya adalah melengkapi screenshot, spesifikasi hardware, dan hasil pengujian kinerja dasar sebelum membuat DOCX draft review versi 2. Data institusi SMPI REJIS (profil, sejarah, struktur organisasi) dan verifikasi Mendeley/APA 7 tetap menjadi kebutuhan terpisah yang membutuhkan pihak sekolah/user, bukan sesuatu yang bisa diselesaikan lebih lanjut dari file lokal yang sudah ada.
