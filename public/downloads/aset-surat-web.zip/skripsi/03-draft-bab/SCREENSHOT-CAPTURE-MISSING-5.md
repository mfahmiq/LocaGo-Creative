# Screenshot Capture Missing 5

Tanggal: 2026-07-05  
Lingkup: pelengkapan 5 screenshot yang masih kurang untuk bukti BAB IV.  
Mode kerja: verifikasi lokal melalui Laragon/CodeIgniter development server.  
Catatan keamanan: username, password, token, session, cookie, dan credential tidak dicatat di file ini.

## Sumber Kebutuhan

Berdasarkan status terakhir project, screenshot BAB IV yang masih kurang adalah:

1. Halaman Manajemen Pengguna.
2. Halaman Daftar Transaksi Aset.
3. Form Tambah Surat Masuk.
4. Form Tambah Surat Keluar.
5. Halaman Cetak/Preview Laporan.

## Lingkungan Pengambilan

| Item | Status |
|---|---|
| Server lokal | Berjalan melalui CodeIgniter development server |
| URL utama | `http://localhost:8080` |
| Login lokal | Berhasil menggunakan akun demo lokal tanpa mencatat credential |
| Database | Tidak ada CRUD/data bisnis yang diubah; login lokal dapat memperbarui metadata autentikasi seperti waktu login terakhir akun demo |
| Source code | Tidak diubah pada tahap ini |
| Migration/seeder | Tidak dijalankan |
| Form tambah | Hanya dibuka untuk screenshot, tombol simpan tidak diklik |

## Hasil Screenshot

| No | Kebutuhan Screenshot | Nama File | Status | Catatan |
|---:|---|---|---|---|
| 1 | Halaman Manajemen Pengguna | `screenshot-manajemen-pengguna.png` | Berhasil | Halaman manajemen pengguna/admin berhasil dibuka. |
| 2 | Halaman Daftar Transaksi Aset | `screenshot-daftar-transaksi-aset.png` | Berhasil | Halaman daftar transaksi aset berhasil dibuka dan diambil ulang dengan viewport desktop. |
| 3 | Form Tambah Surat Masuk | `screenshot-form-tambah-surat-masuk.png` | Berhasil | Form tambah surat masuk berhasil dibuka; tidak ada penyimpanan data. |
| 4 | Form Tambah Surat Keluar | `screenshot-form-tambah-surat-keluar.png` | Berhasil dengan catatan | Form berhasil dibuka; tampilan lokal halaman ini tertangkap menyempit di sisi kiri sesuai render aplikasi pada saat verifikasi. Tidak ada data yang disimpan. |
| 5 | Halaman Cetak/Preview Laporan | `screenshot-cetak-laporan.png` | Berhasil dengan catatan | Halaman preview/cetak laporan aset berhasil dibuka; tampil sebagai halaman gaya cetak/preview, bukan dialog print browser. |

## Lokasi File Screenshot

```text
skripsi/04-diagram-dan-gambar/screenshots/screenshot-manajemen-pengguna.png
skripsi/04-diagram-dan-gambar/screenshots/screenshot-daftar-transaksi-aset.png
skripsi/04-diagram-dan-gambar/screenshots/screenshot-form-tambah-surat-masuk.png
skripsi/04-diagram-dan-gambar/screenshots/screenshot-form-tambah-surat-keluar.png
skripsi/04-diagram-dan-gambar/screenshots/screenshot-cetak-laporan.png
```

## Verifikasi File

| File | Status File |
|---|---|
| `screenshot-manajemen-pengguna.png` | Ada |
| `screenshot-daftar-transaksi-aset.png` | Ada |
| `screenshot-form-tambah-surat-masuk.png` | Ada |
| `screenshot-form-tambah-surat-keluar.png` | Ada |
| `screenshot-cetak-laporan.png` | Ada |

## Batasan

1. Screenshot halaman manajemen pengguna berpotensi memuat data akun lokal/demo yang ada pada database lokal; detail credential tidak disalin ke laporan ini.
2. Form tambah surat masuk dan form tambah surat keluar hanya dibuka, tidak dilakukan penyimpanan.
3. Halaman cetak/preview laporan hanya dibuka, tidak membuka dialog print sistem.
4. Tidak ada perubahan source code dan tidak ada perubahan data bisnis/CRUD pada tahap ini.
5. Login lokal untuk membuka halaman internal dapat memperbarui metadata autentikasi seperti waktu login terakhir akun demo.
