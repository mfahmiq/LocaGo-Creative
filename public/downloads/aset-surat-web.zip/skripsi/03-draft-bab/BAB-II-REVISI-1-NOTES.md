# BAB II REVISI 1 NOTES

## 1. Status Draft

BAB-II-REVISI-1.md adalah draft awal BAB II, bukan final mutlak.

## 2. Referensi Yang Digunakan

- Annisa, Rahayuningsih, dan Anna (2023)
- Pranoto dan Sediyono (2021)
- Mubarok dan Sutaji (2025)
- Siswaya dan Setiawan (2025)
- Rohmawati dan Yulianingsih (2025)
- Londa, Wee, dan Radja (2022)
- KBBI
- Undang-Undang Nomor 43 Tahun 2009 tentang Kearsipan
- PHP Documentation
- CodeIgniter 4 User Guide
- MySQL Reference Manual
- OMG UML 2.5.1
- IBM Entity-Relationship Model Documentation
- Scrum Guide 2020
- ISTQB Glossary
- IJIS Wiratama (2024)
- JSAI (2024)

## 3. Marker Yang Masih Ada


## 4. Bagian Yang Sudah Kuat

- Struktur BAB II sudah mengikuti format final.
- Subbab 2.1.1 sampai 2.1.13 dan 2.2 telah disusun.
- Referensi utama yang terverifikasi sudah dimasukkan sebagai rujukan draft.
- Keterangan mengenai LRS dan Agile Scrum ditulis sesuai catatan referensi.

## 5. Bagian Yang Masih Perlu Review

- Subbab 2.1.11 LRS membutuhkan review karena sumber masih berupa penguat awal dari jurnal aplikasi/perancangan sistem.
- Subbab 2.1.3 Inventaris Aset menggunakan Mubarok dan Sutaji (2025) dengan catatan DOI resmi jurnal BSI.
- Subbab 2.2 Penelitian Terkait perlu verifikasi metadata artikel saat input ke Mendeley.
- Semua rujukan masih harus dicek ulang pada tahap APA 7 dan daftar pustaka final.

## 6. Risiko Yang Masih Ada

- Metadata referensi belum dimasukkan ke Mendeley secara resmi.
- Format APA 7 belum final.
- LRS masih memakai penguat awal dan bukan buku teori utama.
- Penelitian terkait perlu dicek ulang sebelum finalisasi dokumen.

## 7. Rekomendasi Berikutnya

Draft BAB II perlu direview oleh user dan Maestro sebelum dilanjutkan ke finalisasi sitasi atau DOCX.
