# MARKER RESOLUTION DATA CHECKLIST

Tanggal dibuat: 2026-07-05

## 1. Status

File ini adalah daftar data konkret yang harus dilengkapi oleh user/sekolah sebelum membuat patch berikutnya. File ini bukan revisi BAB, tidak mengubah `BAB-I-FINAL-ARAH-REFPATCH-1.md`, `BAB-II-FINAL-ARAH-REFPATCH-1.md`, `BAB-III-REVISI-1.md`, `BAB-IV-REVISI-1-CODEPATCH-1.md`, maupun `BAB-V-REVISI-1.md`. Tidak ada data yang dikarang pada file ini — seluruh kolom template sengaja dikosongkan untuk diisi user.

## 2. Ringkasan Marker Tersisa

Kategori | Jumlah | Status | Prioritas
---|---|---|---
Butuh data user/sekolah | 5 | Menunggu data dari user/sekolah | Prioritas 4 (data institusi) — lihat bagian 7
Butuh screenshot | 5 | Menunggu screenshot dari user | Prioritas 2 — lihat bagian 5
Butuh hasil pengujian | 7 | Menunggu pengukuran dari user | Prioritas 5 — lihat bagian 6
Butuh Mendeley/APA 7 | 1 | Menunggu verifikasi Mendeley (di luar cakupan file ini) | Prioritas 6, tidak dibahas rinci di file ini
Butuh spesifikasi hardware | 4 | Menunggu data dari user | Prioritas 3 — lihat bagian 3
Butuh review manual | 2 | Bergantung pada penyelesaian marker BAB IV di atas | Menyusul setelah Prioritas 1-5 selesai

**Total marker tersisa: 24** (tidak berubah sejak `BAB-I-SAMPAI-V-MARKER-COUNT-AFTER-LOCALPATCH.md`, karena file ini hanya menyiapkan checklist, belum melakukan patch apa pun).

## 3. Data Spesifikasi Hardware dan Software Yang Harus Diisi User

```text
Processor:
RAM:
Storage:
Sistem Operasi:
Versi Windows:
Browser:
Versi Browser:
Code Editor:
Versi Code Editor:
Local Server:
Versi Laragon:
PHP:
Database:
Framework:
Catatan:
```

Catatan pengisian:

1. Bagian `PHP`, `Database`, dan `Framework` boleh diisi ulang oleh user untuk konfirmasi, tetapi versi yang sudah terverifikasi secara lokal adalah PHP CLI `8.4.10`, Composer `2.8.9`, dan CodeIgniter framework `v4.7.3` (lihat `APPLICATION_VERIFICATION.md`); user tidak perlu mengukur ulang ketiganya kecuali ingin memastikan versi yang benar-benar dipakai saat pengerjaan skripsi berbeda dari hasil verifikasi tersebut.
2. Kolom `Processor`, `RAM`, `Storage`, `Versi Windows`, `Browser`, `Versi Browser`, `Code Editor`, dan `Versi Code Editor` belum memiliki data apa pun di workspace ini dan wajib diisi oleh user secara langsung dari perangkat yang dipakai.
3. Jangan mengisi kolom ini dengan perkiraan atau spesifikasi umum yang tidak benar-benar dipakai; kosongkan saja kolom yang belum diketahui daripada menebak.

## 4. Rencana Deployment Yang Harus Diputuskan User

A. Tetap lokal menggunakan Laragon.
B. Rencana lanjutan ke server internal sekolah.
C. Rencana lanjutan ke hosting.

Naskah BAB IV saat ini (`BAB-IV-REVISI-1-CODEPATCH-1.md` bagian 4.4.1 Publikasi Software) aman memakai opsi **A** selama belum ada bukti deployment ke server. Jika user memilih opsi B atau C, sertakan penjelasan singkat mengenai rencana tersebut (misalnya nama server internal, target waktu, atau penyedia hosting) agar dapat dituliskan sebagai rencana pengembangan lanjutan, bukan sebagai fakta yang sudah terjadi. Jika belum ada keputusan, biarkan bagian ini kosong dan opsi A tetap berlaku sebagai status default yang sudah benar berdasarkan bukti yang ada.

## 5. Screenshot Yang Harus Disiapkan User

No | Screenshot | Nama File Disarankan | Status
---|---|---|---
1 | Halaman Manajemen Pengguna | `screenshot-manajemen-pengguna.png` | Belum tersedia
2 | Halaman Daftar Transaksi Aset | `screenshot-daftar-transaksi-aset.png` | Belum tersedia
3 | Form Tambah Surat Masuk | `screenshot-form-tambah-surat-masuk.png` | Belum tersedia
4 | Form Tambah Surat Keluar | `screenshot-form-tambah-surat-keluar.png` | Belum tersedia
5 | Cetak Laporan | `screenshot-cetak-laporan.png` | Belum tersedia

Catatan pengisian:

1. Ambil screenshot setelah login lokal menggunakan akun demo, tanpa menampilkan credential, token, session, atau cookie pada gambar.
2. Simpan berkas di `skripsi/04-diagram-dan-gambar/screenshots/` dengan nama file sesuai kolom di atas, atau nama lain yang jelas jika lebih sesuai dengan urutan penomoran yang sudah ada di folder tersebut.
3. Gunakan data uji/dummy, bukan data operasional asli sekolah, konsisten dengan screenshot yang sudah ada sebelumnya.

## 6. Data Pengujian Kinerja Dasar Yang Harus Diisi User

No | Proses | Waktu Respons | Lingkungan Uji | Catatan
---|---|---|---|---
1 | Login | | |
2 | Dashboard | | |
3 | Data Aset | | |
4 | Surat Masuk | | |
5 | Laporan | | |
6 | Backup | | |

Catatan pengisian:

1. Waktu respons boleh berupa hasil pengamatan sederhana di lingkungan lokal (misalnya dicatat dari DevTools browser, Postman, atau stopwatch manual), bukan *load testing*, bukan *stress testing*, dan bukan benchmark server produksi.
2. Cukup catat waktu dalam detik/milidetik untuk satu kali percobaan wajar di lingkungan lokal/Laragon; tidak perlu pengujian berulang dengan banyak pengguna simultan.
3. Kolom "Lingkungan Uji" dapat diisi misalnya "Lokal/Laragon, server development CodeIgniter" mengikuti redaksi yang sudah dipakai di BAB IV, atau disesuaikan jika lingkungan uji sebenarnya berbeda.

## 7. Data Sekolah Yang Harus Diisi User

```text
Profil resmi SMPI REJIS:
Sejarah singkat:
Struktur organisasi:
Detail observasi:
Tanggal observasi:
Pihak yang ditemui:
Catatan:
```

Catatan pengisian: data ini dibutuhkan untuk melengkapi marker `[PERLU DATA]` pada BAB III (3.1 Tinjauan Perusahaan, 3.1.1 Sejarah Perusahaan, 3.1.2 Struktur Organisasi) dan BAB I (1.5.1 Teknik Pengumpulan Data — Observasi). Sumber yang sah untuk mengisi bagian ini adalah dokumen resmi sekolah (profil, sejarah, bagan organisasi) atau konfirmasi langsung dari narasumber (Gilang Ramadhan S.Kom./Ust. Gilang) maupun pihak sekolah lain yang berwenang.

## 8. Rekomendasi Patch Berikutnya

Patch berikutnya sebaiknya dilakukan setelah user mengisi minimal:

1. Spesifikasi hardware/software (bagian 3).
2. Keputusan rencana deployment (bagian 4).
3. Screenshot yang kurang (bagian 5).

Setelah itu baru buat `BAB-IV-REVISI-1-EVIDENCEPATCH-1.md` dan hitung ulang marker. Data sekolah (bagian 7) dan pengujian kinerja dasar (bagian 6) dapat menyusul terpisah sesuai ketersediaan user, karena keduanya memengaruhi BAB yang berbeda (BAB I/BAB III untuk data sekolah, BAB IV untuk pengujian kinerja) dan tidak harus selesai bersamaan dengan tiga item di atas.
