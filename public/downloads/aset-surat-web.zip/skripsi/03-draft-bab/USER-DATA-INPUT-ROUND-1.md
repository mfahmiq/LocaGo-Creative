# USER DATA INPUT ROUND 1

Tanggal dibuat: 2026-07-05

## 1. Status

File ini mencatat data yang benar-benar diisi user pada putaran pertama pengisian `MARKER-RESOLUTION-DATA-CHECKLIST.md`, serta memisahkan secara jujur mana yang sungguh terisi versus mana yang masih berupa placeholder kosong (`[ISI ...]`). Tidak ada data kosong yang dikarang untuk melengkapi bagian ini.

## 2. Deployment Yang Dipilih

**Status: TERISI, dapat dipakai.**

- Pilihan: **A. Tetap lokal menggunakan Laragon.**
- Keterangan dari user: "Aplikasi pada penelitian ini masih dijalankan dan diuji pada lingkungan lokal menggunakan Laragon. Aplikasi belum dipublikasikan pada server internal sekolah maupun hosting."
- Dampak: marker `[PERLU DATA]` pada BAB IV 4.4.1 Publikasi Software (mengenai rencana penerapan server) dapat diselesaikan, karena user secara eksplisit mengonfirmasi bahwa belum ada rencana deployment ke server internal maupun hosting.

## 3. Spesifikasi Hardware/Software Yang Diisi

**Status: SEBAGIAN BESAR MASIH KOSONG (placeholder), tidak dapat dipakai untuk menyelesaikan marker.**

Field | Nilai Yang Dikirim User | Status
---|---|---
Processor | `[ISI PROCESSOR]` | Kosong (placeholder)
RAM | `[ISI RAM]` | Kosong (placeholder)
Storage | `[ISI STORAGE]` | Kosong (placeholder)
Sistem Operasi | `[ISI SISTEM OPERASI]` | Kosong (placeholder)
Versi Windows | `[ISI VERSI WINDOWS]` | Kosong (placeholder)
Browser | `[ISI BROWSER]` | Kosong (placeholder)
Versi Browser | `[ISI VERSI BROWSER]` | Kosong (placeholder)
Code Editor | `[ISI CODE EDITOR]` | Kosong (placeholder)
Versi Code Editor | `[ISI VERSI CODE EDITOR]` | Kosong (placeholder)
Local Server | Laragon | Terisi, tetapi bukan marker (sudah disebut di BAB IV sebelumnya tanpa marker)
Versi Laragon | `[ISI VERSI LARAGON]` | Kosong (placeholder); bukan marker BAB IV yang ada saat ini
PHP | `[ISI VERSI PHP, ATAU GUNAKAN YANG SUDAH TERVERIFIKASI]` | Tidak diisi nilai baru; user mengizinkan memakai versi yang sudah terverifikasi (PHP CLI 8.4.10) — bukan marker, karena versi ini sudah tercantum di BAB IV sebelum patch ini tanpa marker
Database | `[ISI MYSQL/MARIADB DAN VERSINYA, ATAU GUNAKAN YANG SUDAH TERVERIFIKASI]` | Tidak diisi nilai versi baru; tidak ada versi MySQL/MariaDB yang terverifikasi secara spesifik di workspace ini — bukan marker, karena BAB IV sebelum patch ini hanya menyebut "MySQL/MariaDB" tanpa marker versi
Framework | CodeIgniter 4 | Terisi, tetapi bukan marker (sudah dikonfirmasi versi v4.7.3 di BAB IV sebelumnya tanpa marker)

Kesimpulan: keempat marker `[PERLU DATA]` pada BAB IV 4.4.2 (versi Windows, versi browser, versi editor, spesifikasi hardware) **tidak dapat diselesaikan** pada putaran ini karena seluruh field terkait masih berupa placeholder kosong.

## 4. Screenshot Yang Ditemukan Dan Tidak Ditemukan

**Status: TIDAK DITEMUKAN, tidak dapat dipakai untuk menyelesaikan marker.**

User menyatakan sudah menyiapkan 5 berkas screenshot, tetapi kolom "Lokasi folder screenshot" juga masih berupa placeholder (`[ISI LOKASI FOLDER SCREENSHOT, CONTOH: skripsi/04-diagram-dan-gambar/screenshots/]`), sehingga lokasi pastinya belum dikonfirmasi. Pengecekan dilakukan pada lokasi contoh yang disebutkan (`skripsi/04-diagram-dan-gambar/screenshots/`), dengan hasil sebagai berikut:

No | Nama File Yang Disebut User | Ditemukan Di `skripsi/04-diagram-dan-gambar/screenshots/`? | Status
---|---|---|---
1 | `screenshot-manajemen-pengguna.png` | Tidak | Belum ada, marker dipertahankan
2 | `screenshot-daftar-transaksi-aset.png` | Tidak | Belum ada, marker dipertahankan
3 | `screenshot-form-tambah-surat-masuk.png` | Tidak | Belum ada, marker dipertahankan
4 | `screenshot-form-tambah-surat-keluar.png` | Tidak | Belum ada, marker dipertahankan
5 | `screenshot-cetak-laporan.png` | Tidak | Belum ada, marker dipertahankan

Isi folder aktual pada `skripsi/04-diagram-dan-gambar/screenshots/` saat pengecekan (22 berkas): `01-login.png` sampai `22-sidebar-final-admin.png` (penomoran lama, lihat `SCREENSHOT_REQUIREMENTS.md`), tidak ada satu pun berkas dengan nama sesuai yang disebut user. Kelima marker `[PERLU CEK SCREENSHOT]` pada BAB IV **tidak diselesaikan** pada putaran ini karena berkas tidak ditemukan, sesuai instruksi "jika ada file screenshot yang tidak ditemukan, jangan dikarang."

## 5. Data Pengujian Kinerja Yang Diisi Dan Kosong

**Status: SELURUHNYA KOSONG, tidak dapat dipakai untuk menyelesaikan marker.**

No | Proses | Waktu Respons Yang Dikirim User | Status
---|---|---|---
1 | Login | `[ISI, contoh: 1,2 detik]` | Kosong (placeholder/contoh, bukan data nyata)
2 | Dashboard | `[ISI]` | Kosong (placeholder)
3 | Data Aset | `[ISI]` | Kosong (placeholder)
4 | Surat Masuk | `[ISI]` | Kosong (placeholder)
5 | Laporan | `[ISI]` | Kosong (placeholder)
6 | Backup | `[ISI]` | Kosong (placeholder)

Ketujuh marker `[PERLU DATA HASIL PENGUJIAN]` pada BAB IV (6 baris tabel + 1 kalimat penutup) **tidak dapat diselesaikan** pada putaran ini.

## 6. Data Sekolah Yang Diisi Dan Kosong

**Status: SELURUHNYA KOSONG, tidak dapat dipakai untuk menyelesaikan marker.**

Field | Nilai Yang Dikirim User | Status
---|---|---
Profil resmi SMPI REJIS | `[ISI PROFIL RESMI]` | Kosong (placeholder)
Sejarah singkat | `[ISI SEJARAH SINGKAT]` | Kosong (placeholder)
Struktur organisasi | `[ISI STRUKTUR ORGANISASI]` | Kosong (placeholder)
Detail observasi | `[ISI DETAIL OBSERVASI]` | Kosong (placeholder)
Tanggal observasi | `[ISI TANGGAL OBSERVASI]` | Kosong (placeholder)
Pihak yang ditemui | `[ISI PIHAK YANG DITEMUI]` | Kosong (placeholder)

Marker `[PERLU DATA]` pada BAB I (observasi) dan ketiga marker `[PERLU DATA]` pada BAB III (profil, sejarah, struktur organisasi) **tidak dapat diselesaikan** pada putaran ini.

## 7. Catatan

Data yang masih kosong (placeholder `[ISI ...]`) tidak boleh dikarang. Seluruh marker terkait bagian 3, 4, 5, dan 6 di atas tetap dipertahankan apa adanya pada patch berikutnya. Hanya bagian 2 (Deployment) yang benar-benar berisi data nyata dan dapat dipakai untuk menyelesaikan satu marker pada BAB IV 4.4.1 Publikasi Software.
