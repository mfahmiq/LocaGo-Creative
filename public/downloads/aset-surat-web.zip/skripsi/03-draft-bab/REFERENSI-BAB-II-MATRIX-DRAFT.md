# REFERENSI BAB II MATRIX DRAFT

Berikut adalah matrix kebutuhan referensi untuk BAB II berdasarkan struktur final yang disetujui.

No | Subbab | Konsep Yang Perlu Dijelaskan | Referensi Lokal Yang Tersedia | Referensi Online Terverifikasi | Status | Catatan
---|---|---|---|---|---|---
1 | 2.1.1 Sistem Informasi | Definisi sistem informasi, komponen, peran dalam organisasi, manfaat sistem informasi sekolah | Tidak ada file referensi lokal di `skripsi/06-referensi/` | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu referensi jurnal/buku valid.
2 | 2.1.2 Website | Konsep website aplikasi, keunggulan web untuk sistem informasi sekolah | Tidak ada file referensi lokal | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu referensi akademik tentang aplikasi web.
3 | 2.1.3 Inventaris Aset | Konsep inventaris aset, kategori aset, lokasi, peminjaman, pelaporan | Tidak ada file referensi lokal | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu referensi inventaris aset di lingkungan sekolah.
4 | 2.1.4 Surat | Teori surat masuk/keluar, administrasi surat, arsip surat | Tidak ada file referensi lokal | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu referensi administrasi surat formal.
5 | 2.1.5 Disposisi Surat | Teori disposisi surat, alur tindak lanjut, monitoring status | Tidak ada file referensi lokal | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu referensi sistem disposisi surat.
6 | 2.1.6 Basis Data MySQL | Basis data relasional, MySQL, tabel, kunci, integritas data | Tidak ada file referensi lokal | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu referensi database relasional MySQL.
7 | 2.1.7 PHP | PHP sebagai bahasa server-side, peran dalam aplikasi web | Tidak ada file referensi lokal | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu referensi PHP terbaru atau dokumentasi resmi.
8 | 2.1.8 CodeIgniter | Framework CodeIgniter 4, MVC, keunggulan penggunaan | Tidak ada file referensi lokal | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu referensi dokumentasi atau sumber akademik CodeIgniter.
9 | 2.1.9 UML | Konsep UML, jenis diagram, kegunaan pemodelan sistem | Tidak ada file referensi lokal | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu referensi UML untuk perancangan sistem.
10 | 2.1.10 ERD | Konsep ERD, entitas, atribut, relasi, kardinalitas | Tidak ada file referensi lokal | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu referensi ERD dan basis data.
11 | 2.1.11 LRS | Konsep Logical Record Structure, struktur rekaman logis | Tidak ada file referensi lokal | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu referensi LRS akademik.
12 | 2.1.12 Agile Scrum | Konsep Agile Scrum, sprint, backlog, iterasi | Tidak ada file referensi lokal | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu referensi Agile Scrum dengan konteks pengembangan aplikasi.
13 | 2.1.13 Black-Box Testing | Konsep black-box testing, tujuan, kelebihan, batasan | Tidak ada file referensi lokal | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu referensi pengujian fungsional perangkat lunak.
14 | 2.2 Penelitian Terkait | Referensi penelitian sejenis, studi kasus, gap penelitian | Tidak ada file referensi lokal | MENUNGGU REFERENSI ONLINE DARI MAESTRO | MENUNGGU REFERENSI | Perlu verifikasi penelitian terkait dengan metadata jelas.
