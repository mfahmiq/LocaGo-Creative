# BAB IV Evidence Completion Report

Tanggal: 2026-07-05  
Tujuan: melengkapi bukti BAB IV yang masih kurang, yaitu 5 screenshot dan data waktu respons sederhana.  
Status: selesai dengan catatan.

## Ringkasan Hasil

| Item | Hasil |
|---|---|
| Screenshot yang diminta | 5 |
| Screenshot berhasil dibuat | 5 |
| Screenshot gagal dibuat | 0 |
| Proses waktu respons yang diminta | 6 |
| Proses waktu respons berhasil diamati | 6 |
| Source code aplikasi | Tidak diubah pada tahap ini |
| Database | Tidak ada CRUD/data bisnis yang diubah; login lokal dapat memperbarui metadata autentikasi seperti waktu login terakhir akun demo |
| Migration | Tidak dijalankan |
| Seeder | Tidak dijalankan |
| DOCX baru | Tidak dibuat |
| BAB I-IV | Tidak ditulis ulang |

## Screenshot Berhasil Dibuat

| No | Screenshot | File |
|---:|---|---|
| 1 | Halaman Manajemen Pengguna | `skripsi/04-diagram-dan-gambar/screenshots/screenshot-manajemen-pengguna.png` |
| 2 | Halaman Daftar Transaksi Aset | `skripsi/04-diagram-dan-gambar/screenshots/screenshot-daftar-transaksi-aset.png` |
| 3 | Form Tambah Surat Masuk | `skripsi/04-diagram-dan-gambar/screenshots/screenshot-form-tambah-surat-masuk.png` |
| 4 | Form Tambah Surat Keluar | `skripsi/04-diagram-dan-gambar/screenshots/screenshot-form-tambah-surat-keluar.png` |
| 5 | Halaman Cetak/Preview Laporan | `skripsi/04-diagram-dan-gambar/screenshots/screenshot-cetak-laporan.png` |

## Screenshot Gagal

Tidak ada screenshot yang gagal dibuat.

Catatan visual:

1. Form tambah surat keluar berhasil dibuka, tetapi tampilan lokalnya tertangkap menyempit di sisi kiri sesuai kondisi render aplikasi saat verifikasi.
2. Halaman cetak/preview laporan berhasil dibuka sebagai halaman preview/cetak laporan aset.

## Data Waktu Respons Sederhana

Pengamatan dilakukan pada lingkungan lokal Laragon/CodeIgniter development server dan bukan pengujian beban, bukan pengujian tekanan, bukan pengujian penetrasi, serta bukan benchmark server produksi.

| No | Proses | Status | Waktu Respons |
|---:|---|---|---:|
| 1 | Login | Berhasil | 2.860 ms |
| 2 | Dashboard | Berhasil | 1.607 ms |
| 3 | Data Aset | Berhasil | 1.273 ms |
| 4 | Surat Masuk | Berhasil | 1.200 ms |
| 5 | Laporan | Berhasil | 1.055 ms |
| 6 | Backup | Berhasil | 1.013 ms |

## Dampak Ke Source Code Dan Database

1. Source code aplikasi tidak diubah pada tahap ini.
2. Tidak ada perubahan data bisnis/CRUD pada tahap ini.
3. Form tambah surat masuk dan form tambah surat keluar hanya dibuka untuk screenshot, tidak disimpan.
4. Fitur backup hanya dibuka untuk pengamatan halaman, tidak mengunduh backup baru pada tahap ini.
5. Migration dan seeder tidak dijalankan.
6. Login lokal untuk membuka halaman internal dapat memperbarui metadata autentikasi seperti waktu login terakhir akun demo.

Catatan git:

Workspace sudah memiliki perubahan source code dari tahap sebelumnya. Laporan ini hanya menyatakan bahwa pada tahap pelengkapan bukti BAB IV tanggal 2026-07-05, tidak dilakukan perubahan source code, tidak dilakukan CRUD data bisnis, dan tidak dijalankan migration/seeder.

## Rekomendasi Patch BAB IV Berikutnya

Patch BAB IV berikutnya dapat dibuat sebagai `BAB-IV-REVISI-1-EVIDENCEPATCH-4.md` atau nama versi lain yang disetujui user. Patch tersebut sebaiknya:

1. Mengganti 5 marker `[PERLU CEK SCREENSHOT]` dengan rujukan file screenshot yang sudah dibuat.
2. Mengisi tabel pengujian kinerja dasar menggunakan 6 data waktu respons pada laporan ini.
3. Menambahkan catatan keterbatasan bahwa pengukuran dilakukan pada lingkungan lokal Laragon.
4. Tidak menyebut load testing, stress testing, penetration testing, atau benchmark server produksi.
5. Tidak mengubah BAB I sampai BAB IV sebelum user menyetujui patch berikutnya.
