# BLACKBOX-PENGAJUAN-INVENTARIS

## Status

- Tanggal pengujian: 2026-07-05.
- Lingkup: modul Pengajuan Inventaris.
- Lingkungan: lokal Laragon.
- Catatan keamanan: credential, password, token, session, cookie, dan API key tidak dicantumkan.

## Data Uji

Data uji memakai data dummy:

1. Pemohon: `Pemohon Uji Skripsi`
2. Unit: `Unit Uji Skripsi`
3. Item: `Item Pengajuan Inventaris Uji Skripsi`
4. Jenis pengajuan yang diuji: pengadaan aset, perbaikan aset, dan peminjaman aset.

## Tabel Skenario Black-Box

| No | Modul | Skenario Uji | Data Uji | Hasil Yang Diharapkan | Hasil Aktual | Status | Keterangan |
| --- | --- | --- | --- | --- | --- | --- | --- |
| PI-01 | Pengajuan Inventaris | Membuka daftar pengajuan | User login role admin | Daftar pengajuan tampil | Halaman daftar tampil dan screenshot dibuat | valid | `screenshot-daftar-pengajuan-inventaris.png` |
| PI-02 | Pengajuan Inventaris | Membuat pengajuan valid | Header lengkap dan satu item dummy | Pengajuan tersimpan dengan status `diajukan` | Pengajuan tersimpan dan detail dapat dibuka | valid | Data dummy tersimpan di lokal |
| PI-03 | Pengajuan Inventaris | Membuat pengajuan tanpa item | Header terisi, item kosong | Sistem menolak simpan dan menampilkan validasi | Sistem kembali ke form tambah dan menampilkan validasi item | valid | Tidak membuat pengajuan kosong |
| PI-04 | Pengajuan Inventaris | Melihat detail pengajuan | Pengajuan dummy yang sudah dibuat | Detail pengajuan dan item tampil | Detail tampil dan screenshot dibuat | valid | `screenshot-detail-pengajuan-inventaris.png` |
| PI-05 | Pengajuan Inventaris | Approve pengajuan | Role pimpinan, catatan opsional | Status berubah menjadi `disetujui` | Status berubah menjadi `disetujui` | valid | Diproses melalui route approval |
| PI-06 | Pengajuan Inventaris | Reject pengajuan tanpa catatan | Role pimpinan, catatan kosong | Sistem menolak karena catatan wajib | Status tetap `diajukan` | valid | Validasi reject berjalan |
| PI-07 | Pengajuan Inventaris | Reject pengajuan dengan catatan | Role pimpinan, catatan dummy | Status berubah menjadi `ditolak` | Status berubah menjadi `ditolak` | valid | Catatan penolakan tersimpan |
| PI-08 | Pengajuan Inventaris | Download PDF | Pengajuan dummy | PDF pengajuan dihasilkan | PDF merespons dan berhasil dirender menjadi screenshot | valid | `screenshot-pdf-pengajuan-inventaris.png` |
| PI-09 | Pengajuan Inventaris | Operator mencoba approve | Role operator | Akses approval ditolak | Route approval ditolak untuk operator | valid | Tidak menampilkan credential |
| PI-10 | Pengajuan Inventaris | Akses tanpa login | Akses `/inventory-requests` tanpa session | Redirect ke login | HTTP 302 ke `/login` | valid | Diverifikasi dengan request tanpa session |

## Ringkasan Hasil

- Total skenario: 10.
- Valid: 10.
- Gagal: 0.
- Belum diverifikasi: 0.

## Catatan Risiko

Semua skenario prioritas modul Pengajuan Inventaris sudah terverifikasi pada lingkungan lokal. Data yang dibuat adalah data dummy uji dan dapat dibersihkan manual jika tidak lagi diperlukan.
