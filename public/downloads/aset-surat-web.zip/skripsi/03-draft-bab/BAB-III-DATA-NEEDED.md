# BAB III DATA NEEDED

Tanggal dibuat: 2026-07-05
Terakhir diperbarui: 2026-07-05 (catatan koreksi outline BAB III/BAB IV)

## 0. Catatan Koreksi

Struktur BAB III dikoreksi pada 2026-07-05 menjadi ANALISIS DAN PERANCANGAN APLIKASI (3.1 Tinjauan Perusahaan, 3.2 Analisis Aplikasi, 3.3 Rancangan Algoritma), sesuai `OUTLINE-CORRECTION-BAB-III-IV.md` dan `BAB-III-IV-STRUCTURE-FINAL-ARAH.md`. Data pada file ini tetap relevan karena kebutuhan data institusi (bagian 1) dan data sistem berjalan (bagian 2) dipakai untuk 3.1 dan 3.2. Bagian 3 (data aplikasi) disesuaikan: daftar diagram yang sudah tersedia kini menjadi kebutuhan data untuk BAB IV (4.1.1 Database dan 4.1.2 Software Architecture), bukan untuk BAB III, karena BAB III tidak lagi memuat diagram teknis.

## 1. Data Institusi Yang Dibutuhkan

1. Nama resmi sekolah.
2. Alamat lengkap sekolah.
3. Sejarah singkat sekolah.
4. Visi dan misi jika diperlukan.
5. Struktur organisasi sekolah.
6. Tugas bagian terkait, khususnya kepala sekolah, wakil kepala sekolah, tata usaha, operator, dan staf.
7. Profil narasumber.
8. Bukti observasi atau keterangan waktu observasi.

## 2. Data Sistem Berjalan Yang Dibutuhkan

1. Alur pencatatan inventaris aset saat ini.
2. Contoh buku inventaris jika ada.
3. Alur peminjaman aset saat ini.
4. Alur surat masuk.
5. Alur disposisi surat.
6. Alur surat keluar.
7. Contoh dokumen atau format pencatatan jika ada.

## 3. Data Aplikasi Yang Dibutuhkan

Untuk BAB III (3.2 Analisis Aplikasi dan 3.3 Rancangan Algoritma):

1. Daftar role dan hak akses final.
2. Daftar fitur final.
3. Hasil audit aplikasi jika tersedia (`APLIKASI_FEATURE_AUDIT.md`), khususnya alur fungsional per modul untuk mendasari rancangan algoritma.

Untuk BAB IV (4.1 Desain — bukan lagi kebutuhan BAB III setelah koreksi outline):

4. Daftar tabel database, ERD, dan LRS untuk 4.1.1 Database.
5. Daftar diagram yang sudah tersedia (Use Case, Activity, Sequence, Arsitektur MVC) untuk 4.1.2 Software Architecture.
6. Screenshot halaman aplikasi jika tersedia untuk 4.1.3 User Interface.

## 4. Marker Yang Wajib Dipakai Jika Data Belum Ada

Jika data belum tersedia, gunakan marker `[PERLU DATA]`. Jangan mengarang profil sekolah, struktur organisasi, tanggal observasi, nama jabatan, atau data operasional.
