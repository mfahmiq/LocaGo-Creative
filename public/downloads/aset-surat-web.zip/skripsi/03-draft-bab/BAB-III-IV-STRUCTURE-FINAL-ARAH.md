# BAB III DAN BAB IV STRUCTURE FINAL ARAH

Tanggal dibuat: 2026-07-05

## 1. BAB III

```text
BAB III
ANALISIS DAN PERANCANGAN APLIKASI

3.1. Tinjauan Perusahaan
     3.1.1. Sejarah Perusahaan
     3.1.2. Struktur Organisasi

3.2. Analisis Aplikasi
     3.2.1. Analisis Masalah
     3.2.2. Analisis Kebutuhan

3.3. Rancangan Algoritma
```

## 2. BAB IV

```text
BAB IV
IMPLEMENTASI DAN PENGUJIAN SOFTWARE

4.1. Desain
     4.1.1. Database
     4.1.2. Software Architecture
     4.1.3. User Interface

4.2. Code Generation

4.3. Testing

4.4. Support
     4.4.1. Publikasi Software
     4.4.2. Spesifikasi Hardware dan Software
```

## 3. Aturan Penulisan BAB III

1. Jangan mengarang sejarah perusahaan.
2. Jangan mengarang struktur organisasi.
3. Gunakan `[PERLU DATA]` jika data perusahaan belum tersedia.
4. Analisis masalah diambil dari BAB I.
5. Analisis kebutuhan disesuaikan dengan role admin, operator, dan pimpinan.
6. Rancangan algoritma menjelaskan alur logika fitur utama aplikasi.

## 4. Aturan Penulisan BAB IV

1. Database memuat ERD, LRS, dan spesifikasi tabel.
2. Software Architecture memuat UML atau arsitektur yang relevan.
3. User Interface memuat tampilan halaman aplikasi.
4. Code Generation memuat potongan kode atau uraian implementasi kode.
5. Testing memuat black-box testing, pengujian keamanan dasar, dan pengujian kinerja dasar.
6. Support memuat publikasi software dan spesifikasi hardware/software.
7. Jangan klaim online atau produksi.
8. Jangan menulis penetration testing, load testing, stress testing, atau benchmark server produksi.

## 5. Rekomendasi

Setelah koreksi ini, langkah berikutnya adalah membuat ulang rencana BAB III dan BAB IV sesuai outline resmi, bukan memakai struktur umum sebelumnya. Rencana BAB III yang telah disesuaikan dicatat pada `BAB-III-DRAFT-PLAN.md` (versi revisi 2026-07-05) dan kebutuhan data pada `BAB-III-DATA-NEEDED.md`. Rencana BAB IV belum dibuat sebagai file terpisah dan menjadi langkah berikutnya setelah struktur ini disetujui.
