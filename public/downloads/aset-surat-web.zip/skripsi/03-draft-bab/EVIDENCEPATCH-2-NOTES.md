# EVIDENCEPATCH 2 NOTES

Tanggal dibuat: 2026-07-05

## 1. Status

Patch ini seharusnya menyelesaikan marker berdasarkan data nyata putaran kedua dari user. Namun, hasil validasi terhadap `USER-DATA-INPUT-ROUND-2.md` menunjukkan seluruh field yang dikirim pada putaran ini masih berupa placeholder template (`[TULIS DATA NYATA]`, `[TULIS ANGKA NYATA]`, `[TULIS DATA NYATA ATAU TULIS BELUM ADA]`, `[TULIS LOKASI FOLDER SCREENSHOT YANG BENAR]`), tanpa satu pun nilai nyata baru. Sesuai bagian Validasi Sebelum Mengerjakan pada instruksi kerja, **tidak ada marker yang diselesaikan pada patch ini**. File `BAB-I-FINAL-ARAH-DATAPATCH-2.md`, `BAB-III-REVISI-1-DATAPATCH-2.md`, dan `BAB-IV-REVISI-1-EVIDENCEPATCH-2.md` dibuat sebagai checkpoint lanjutan, tetapi isinya identik secara substansi dengan versi sebelumnya (`BAB-I-FINAL-ARAH-DATAPATCH-1.md`, `BAB-III-REVISI-1-DATAPATCH-1.md`, `BAB-IV-REVISI-1-EVIDENCEPATCH-1.md`), hanya baris status dokumen yang diperbarui untuk mencatat riwayat validasi putaran kedua.

## 2. Data Yang Digunakan

Tidak ada data baru yang dapat digunakan. Rincian validasi:

1. **Spesifikasi hardware/software**: seluruh 9 field (Processor, RAM, Storage, Sistem Operasi, Versi Windows, Browser, Versi Browser, Code Editor, Versi Code Editor) masih `[TULIS DATA NYATA]`. Versi Laragon masih `[TULIS DATA NYATA ATAU TULIS BELUM ADA]`. PHP dan Database diberi instruksi memakai versi yang sudah terverifikasi, tetapi keduanya bukan marker aktif di BAB IV.
2. **Screenshot**: lokasi folder masih `[TULIS LOKASI FOLDER SCREENSHOT YANG BENAR]` (tidak diisi). Pencarian menyeluruh (`**/screenshot-*.png`) terhadap seluruh workspace untuk kelima nama berkas yang disebut user tidak menemukan satu pun berkas.
3. **Pengujian kinerja dasar**: seluruh 6 baris waktu respons masih `[TULIS ANGKA NYATA] detik`, bukan angka nyata.
4. **Data sekolah**: seluruh 6 field masih `[TULIS DATA NYATA ATAU TULIS BELUM ADA]`, tidak ada yang diisi data nyata maupun pernyataan eksplisit "BELUM ADA".

## 3. Marker Yang Selesai

No | BAB | Marker Lama | Data Pendukung | Status
---|---|---|---|---
- | - | Tidak ada marker yang diselesaikan pada patch ini | Seluruh data yang diminta masih placeholder kosong | TIDAK ADA PERUBAHAN

## 4. Marker Yang Masih Tersisa

No | BAB | Marker | Alasan Belum Selesai | Data Yang Dibutuhkan
---|---|---|---|---
1 | I | `[PERLU DATA]` (1.5.1 Observasi) | Field detail/tanggal observasi dan pihak yang ditemui masih placeholder | Data observasi nyata
2 | III | `[PERLU DATA]` (3.1 Tinjauan Perusahaan — profil resmi) | Field profil resmi masih placeholder | Profil resmi SMPI REJIS
3 | III | `[PERLU DATA]` (3.1.1 Sejarah Perusahaan) | Field sejarah singkat masih placeholder | Sejarah singkat SMPI REJIS
4 | III | `[PERLU DATA]` (3.1.2 Struktur Organisasi) | Field struktur organisasi masih placeholder | Bagan organisasi resmi
5 | IV | `[PERLU DATA]` (4.4.2 — versi Windows) | Field masih placeholder | Versi Windows nyata
6 | IV | `[PERLU DATA]` (4.4.2 — versi browser) | Field masih placeholder | Nama dan versi browser nyata
7 | IV | `[PERLU DATA]` (4.4.2 — versi editor) | Field masih placeholder | Nama dan versi editor nyata
8 | IV | `[PERLU DATA]` (4.4.2 — spesifikasi hardware) | Field masih placeholder | Processor/RAM/Storage nyata
9-13 | IV | `[PERLU CEK SCREENSHOT]` x5 (4.1.3 User Interface) | Lokasi folder masih placeholder; pencarian menyeluruh tidak menemukan berkas | Berkas screenshot nyata di lokasi yang dikonfirmasi eksplisit
14-20 | IV | `[PERLU DATA HASIL PENGUJIAN]` x7 (4.3 Pengujian Kinerja Dasar) | Seluruh kolom waktu respons masih placeholder | Angka waktu respons nyata untuk 6 proses
21 | II | `[PERLU CEK APA 7]` (2.1.11 LRS) | Di luar cakupan data yang diminta pada dua putaran ini | Verifikasi Mendeley/APA 7
22-23 | V | `[PERLU CEK SETELAH BAB IV FINAL]` x2 (5.1 Kesimpulan) | Bergantung pada penyelesaian marker BAB IV di atas | Penyelesaian marker BAB IV nomor 5-20

## 5. Risiko

1. Data yang belum diisi (spesifikasi hardware/software, lokasi/berkas screenshot, waktu respons pengujian, data sekolah) tetap membutuhkan konfirmasi user yang benar-benar nyata, bukan menyalin ulang teks placeholder/instruksi pengisian.
2. Screenshot yang tidak ditemukan tidak boleh dianggap tersedia; pencarian menyeluruh pada putaran ini mengonfirmasi kembali bahwa kelima berkas belum ada di workspace mana pun.
3. Data pengujian yang tidak diisi tidak boleh dikarang; seluruh nilai waktu respons tetap kosong sampai user memberikan angka nyata hasil pengamatan.
4. Mendeley APA 7 belum final untuk seluruh referensi BAB II, termasuk marker `[PERLU CEK APA 7]` pada LRS yang tidak tersentuh pada dua putaran evidence patch ini.
5. BAB V tetap perlu direview ulang setelah BAB IV benar-benar final (screenshot dan pengujian kinerja lengkap); belum ada perubahan pada BAB V karena BAB IV belum selesai.
6. DOCX final belum boleh dibuat karena 23 marker masih tersisa, ditambah kebutuhan verifikasi Mendeley/APA 7 dan format akhir DOCX resmi.
