# BAB I SAMPAI BAB V DRAFT REVIEW CHECK

Tanggal dibuat: 2026-07-05

## 1. Status Umum

BAB I sampai BAB V sudah tersedia sebagai final arah (BAB I dan BAB II) atau draft revisi 1 (BAB III, BAB IV, BAB V), tetapi belum final mutlak. Total 30 marker masih tersebar dari BAB I sampai BAB V yang perlu dibereskan sebelum naskah disebut final untuk DOCX.

## 2. File Yang Tersedia

BAB | File | Status | Catatan
---|---|---|---
BAB I | `BAB-I-FINAL-ARAH.md` | Final arah | Masih perlu review marker (`[PERLU DATA]`, `[PERLU CEK REFERENSI]`)
BAB II | `BAB-II-FINAL-ARAH.md` | Final arah | Masih perlu APA 7 dan Mendeley; lihat `REFERENSI-APA7-MENDELEY-CHECK.md`
BAB III | `BAB-III-REVISI-1.md` | Draft revisi 1 | Perlu review; data institusi masih `[PERLU DATA]`
BAB IV | `BAB-IV-REVISI-1.md` | Draft revisi 1 | Perlu review; 18 marker screenshot/pengujian/kode/hardware
BAB V | `BAB-V-REVISI-1.md` | Draft revisi 1 | Perlu review setelah BAB IV final

## 3. Marker Yang Masih Ada

Marker | BAB I | BAB II | BAB III | BAB IV | BAB V | Catatan
---|---|---|---|---|---|---
`[PERLU DATA]` | 1 | 0 | 3 | 5 | 0 | BAB I: detail observasi. BAB III: profil, sejarah, struktur organisasi SMPI REJIS. BAB IV: rencana deployment server, versi Windows/browser/editor, spesifikasi hardware.
`[PERLU SITASI]` | 0 | 0 | 0 | 0 | 0 | Tidak ditemukan pada BAB I-V revisi ini.
`[PERLU CEK REFERENSI]` | 5 | 0 | 0 | 0 | 0 | BAB I 1.1 Latar Belakang dan 1.5 Metode Penelitian, menunggu referensi BAB II benar-benar dipakai sebagai sitasi langsung di BAB I.
`[PERLU CEK APA 7]` | 0 | 1 | 0 | 0 | 0 | BAB II subbab 2.1.11 LRS; lihat juga catatan APA 7 tambahan di `REFERENSI-APA7-MENDELEY-CHECK.md` untuk referensi berstatus PERLU CEK/BELUM LENGKAP.
`[PERLU CEK OUTLINE]` | 0 | 0 | 0 | 0 | 0 | Tidak ditemukan pada BAB I-V revisi ini.
`[PERLU CEK BUKTI]` | 0 | 0 | 0 | 0 | 0 | Tidak ditemukan pada BAB I-V revisi ini.
`[PERLU CEK SCREENSHOT]` | 0 | 0 | 0 | 5 | 0 | BAB IV 4.1.3 User Interface — halaman manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, tampilan cetak laporan.
`[PERLU DATA HASIL PENGUJIAN]` | 0 | 0 | 0 | 7 | 0 | BAB IV 4.3 Testing bagian Pengujian Kinerja Dasar — pengukuran waktu respons formal belum tersedia.
`[PERLU CEK BUKTI KODE]` | 0 | 0 | 0 | 1 | 0 | BAB IV 4.2 Code Generation — potongan kode modul aset, transaksi, surat, laporan, dan backup belum dikutip langsung.
`[PERLU CEK SETELAH BAB IV FINAL]` | 0 | 0 | 0 | 0 | 2 | BAB V 5.1 Kesimpulan — kesimpulan hasil pengujian bergantung pada penyelesaian marker BAB IV.
`[BELUM DAPAT DIPASTIKAN]` | 0 | 0 | 0 | 0 | 0 | Tidak ditemukan pada BAB I-V revisi ini.

Total marker per BAB: BAB I = 6, BAB II = 1, BAB III = 3, BAB IV = 18, BAB V = 2. **Total keseluruhan BAB I-V = 30 marker.**

## 4. Konsistensi Utama

1. Judul tetap sama — "Perancangan Sistem Terintegrasi Inventaris Aset dan Disposisi Surat Berbasis Web pada SMPI REJIS" konsisten di BAB I sampai BAB V. **KONSISTEN**
2. Objek tetap SMPI REJIS — konsisten di seluruh bab. **KONSISTEN**
3. Role tetap admin, operator, pimpinan — konsisten pada BAB I 1.6, BAB III 3.2.2, dan BAB IV 4.1.3. **KONSISTEN**
4. Fitur tetap 10 fitur final (login, dashboard, manajemen pengguna, inventaris aset, transaksi aset, surat masuk, disposisi surat, surat keluar, laporan, backup) — konsisten pada BAB I 1.6, BAB III 3.2.2, dan BAB IV. **KONSISTEN**
5. Deployment tetap lokal Laragon — ditegaskan pada BAB I 1.1/1.6, BAB IV 4.4.1, dan BAB V 5.1/5.2. **KONSISTEN**
6. Pengujian tetap black-box, keamanan dasar, kinerja dasar — konsisten pada BAB I, BAB IV 4.3, dan BAB V 5.1. **KONSISTEN**
7. Tidak ada klaim online atau produksi — dicek pada BAB I, BAB III, BAB IV 4.4.1, dan BAB V; tidak ditemukan klaim tersebut. **KONSISTEN**
8. Tidak ada Class Diagram sebagai subbab utama — dicek pada `OUTLINE-CORRECTION-BAB-III-IV.md` dan BAB IV 4.1.2; Class Diagram hanya disebut sebagai referensi internal, bukan gambar/subbab utama. **KONSISTEN**
9. Tidak ada Deployment Diagram sebagai subbab utama — dicek pada BAB IV 4.1.2 dan 4.4.2; Deployment Diagram hanya disebut sebagai gambar pendukung opsional. **KONSISTEN**
10. BAB III mengikuti outline resmi (3.1 Tinjauan Perusahaan, 3.2 Analisis Aplikasi, 3.3 Rancangan Algoritma) sesuai `BAB-III-IV-STRUCTURE-FINAL-ARAH.md`. **KONSISTEN**
11. BAB IV mengikuti outline resmi (4.1 Desain dengan 4.1.1-4.1.3, 4.2 Code Generation, 4.3 Testing, 4.4 Support dengan 4.4.1-4.4.2) sesuai `BAB-III-IV-STRUCTURE-FINAL-ARAH.md`. **KONSISTEN**

## 5. Kesiapan DOCX

DOCX draft BAB I sampai BAB V boleh dibuat jika user meminta untuk review. Namun DOCX final belum boleh disebut final karena marker (30 marker gabungan), data institusi (profil, sejarah, struktur organisasi SMPI REJIS), APA 7, Mendeley (termasuk kekurangan 1 jurnal untuk memenuhi syarat minimal 10 jurnal — lihat `REFERENSI-APA7-MENDELEY-CHECK.md`), screenshot, bukti diagram, hasil pengujian, dan format akhir DOCX (margin, font, penomoran, watermark sesuai `DOCX_FORMAT_SPEC.md`) masih perlu dicek.
