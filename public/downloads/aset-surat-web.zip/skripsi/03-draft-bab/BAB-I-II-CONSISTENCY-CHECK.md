# BAB I DAN BAB II CONSISTENCY CHECK

Tanggal dibuat: 2026-07-05

## 1. Status File Yang Dicek

No | File | Ada atau Tidak | Status | Catatan
---|---|---|---|---
1 | BAB-I-REVISI-1.md | ADA | Naskah BAB I terbaru | Berisi 1.1 sampai 1.6, masih ada marker.
2 | BAB-I-REVISION-NOTES.md | ADA | Catatan revisi BAB I | Mencatat bagian yang diadopsi/tidak dipakai dan jumlah marker.
3 | BAB-I-FINAL-ARAH.md | ADA | Naskah BAB I final arah | Dibuat 2026-07-05 berdasarkan `BAB-I-REVISI-1.md`, setara dengan `BAB-II-FINAL-ARAH.md`. Substansi tidak diubah, hanya menghapus baris status dokumen dan metadata judul.
4 | BAB-I-FINAL-ARAH-NOTES.md | ADA | Catatan status BAB I final arah | Dibuat 2026-07-05, mencatat dasar penguncian, marker tersisa, dan rekomendasi.
5 | BAB-II-FINAL-ARAH.md | ADA | Naskah BAB II final arah | Berisi 2.1.1 sampai 2.1.13 dan 2.2 Penelitian Terkait.
6 | BAB-II-FINAL-ARAH-NOTES.md | ADA | Catatan status BAB II final arah | Mencatat status, marker tersisa, dan rekomendasi.
7 | REFERENSI-BAB-II-FINAL-CHECK.md | ADA | Status referensi BAB II | Mencatat status siap draft per subbab dan sumber yang jangan dipakai dulu.
8 | REFERENSI-BAB-II-ONLINE-VERIFIED.md | ADA | Referensi online terverifikasi awal | Mencantumkan referensi valid per subbab beserta DOI/volume/halaman.
9 | REFERENSI-BAB-II-MATRIX-UPDATED.md | ADA | Matrix referensi terbaru | Memetakan referensi per subbab dengan status siap draft.

## 2. Konsistensi Judul dan Objek

Judul:
Perancangan Sistem Terintegrasi Inventaris Aset dan Disposisi Surat Berbasis Web pada SMPI REJIS

Objek:
SMPI REJIS

`BAB-I-REVISI-1.md` mencantumkan judul yang sama persis pada baris pembuka dokumen dan menyebut SMPI REJIS sebagai objek penelitian secara konsisten di seluruh subbab. `BAB-II-FINAL-ARAH.md` tidak mencantumkan judul ulang (wajar karena BAB II berisi landasan teori), tetapi seluruh subbab yang membahas relevansi (2.1.1, 2.1.3, 2.1.5, dan 2.2) merujuk ke SMPI REJIS secara konsisten.

Hasil: **KONSISTEN**

## 3. Konsistensi Role Pengguna

Role final yang disepakati: admin, operator, pimpinan. Admin TU, Kepala Sekolah, dan Staff hanya boleh sebagai padanan operasional.

- `BAB-I-REVISI-1.md` bagian 1.6 Ruang Lingkup menulis: "Pengguna sistem mengikuti peran yang tersedia pada aplikasi, yaitu admin, operator, dan pimpinan," dan role Admin TU/Kepala Sekolah/Staff tidak muncul sebagai role teknis di BAB I.
- `BAB-II-FINAL-ARAH.md` tidak menyebut role admin/operator/pimpinan maupun Admin TU/Kepala Sekolah/Staff sama sekali karena BAB II berisi landasan teori umum, bukan pembahasan role aplikasi. Tidak ditemukan istilah role yang bertentangan.

Hasil: **KONSISTEN**

## 4. Konsistensi Fitur Aplikasi

Fitur final: login/autentikasi, dashboard, manajemen pengguna, inventaris aset, transaksi/peminjaman aset, surat masuk, disposisi surat, surat keluar, laporan, backup.

- `BAB-I-REVISI-1.md` bagian 1.6 Ruang Lingkup mencantumkan seluruh 10 fitur tersebut secara eksplisit dan berurutan.
- `BAB-II-FINAL-ARAH.md` membahas landasan teori yang selaras dengan fitur tersebut: 2.1.1 Sistem Informasi dan 2.1.2 Website (dasar aplikasi web), 2.1.3 Inventaris Aset (fitur aset), 2.1.4 Surat dan 2.1.5 Disposisi Surat (fitur surat masuk/disposisi/surat keluar), 2.1.6-2.1.10 teknologi pendukung (MySQL, PHP, CodeIgniter, UML, ERD), 2.1.11 LRS (perancangan basis data), 2.1.12 Agile Scrum (metode), 2.1.13 Black-Box Testing (pengujian). Tidak ditemukan subbab landasan teori di luar cakupan fitur final (misalnya tidak ada subbab UI/UX atau teknologi di luar tumpukan yang dipakai aplikasi).

Hasil: **KONSISTEN**

## 5. Konsistensi Metode Pengembangan

- `BAB-I-REVISI-1.md` bagian 1.5.2 menulis Scrum sebagai pendekatan iteratif untuk memetakan kebutuhan ke *product backlog*, memilih pekerjaan untuk *sprint*, dan secara eksplisit menyatakan "tidak menuliskan tanggal *sprint*, nama Scrum Master, Product Owner, Daily Scrum, Sprint Review, atau Sprint Retrospective sebagai fakta historis apabila bukti rinci belum tersedia."
- `BAB-II-FINAL-ARAH.md` subbab 2.1.12 Agile Scrum menulis Scrum sebagai model pengembangan iteratif berdasarkan Scrum Guide 2020, dan secara eksplisit menyatakan "digunakan sebagai landasan teori untuk menjelaskan pendekatan pengembangan, bukan sebagai catatan historis pelaksanaan peristiwa Scrum tertentu."
- Pengecekan kata kunci pada `BAB-II-FINAL-ARAH.md` untuk Daily Scrum, Sprint Review, Sprint Retrospective, Scrum Master, Product Owner, dan tanggal sprint tertentu: tidak ditemukan satu pun kemunculan.

Hasil: **KONSISTEN**

## 6. Konsistensi Pengujian

- `BAB-I-REVISI-1.md` bagian 1.5 dan 1.6 menulis pengujian mencakup *black-box testing*, pengujian keamanan dasar, dan pengujian kinerja dasar, dengan kalimat eksplisit "Penelitian ini tidak mencakup ... *penetration testing*, *load testing*, *stress testing*, benchmark server produksi, atau audit keamanan tingkat lanjut."
- `BAB-II-FINAL-ARAH.md` subbab 2.1.13 Black-Box Testing menulis black-box testing sebagai teknik pengujian fungsional dan menyebut pengujian keamanan dasar/kinerja dasar sebagai pendukung, dengan rincian diarahkan ke BAB IV.
- Pengecekan kata kunci pada `BAB-II-FINAL-ARAH.md` untuk penetration testing, load testing, stress testing, benchmark server produksi, dan audit keamanan tingkat lanjut: tidak ditemukan satu pun kemunculan sebagai klaim.

Hasil: **KONSISTEN**

## 7. Konsistensi Deployment

- `BAB-I-REVISI-1.md` menulis aplikasi "dikembangkan dan diuji pada lingkungan lokal menggunakan Laragon" dan menyatakan penelitian "tidak menulis klaim penerapan produksi, penerapan daring, atau penggunaan resmi pada server sekolah."
- `BAB-II-FINAL-ARAH.md` tidak membahas status deployment karena berisi landasan teori, sehingga tidak ada klaim yang bertentangan. Pengecekan kata kunci untuk "sudah online", "sudah produksi", "server sekolah", dan "digunakan penuh oleh sekolah" pada `BAB-II-FINAL-ARAH.md`: tidak ditemukan satu pun kemunculan.

Hasil: **KONSISTEN**

## 8. Konsistensi ERD

- `BAB-I-REVISI-1.md` bagian 1.6 menulis "ERD digunakan sebagai artefak perancangan dan dokumentasi skripsi, bukan sebagai fitur operasional aplikasi."
- `BAB-II-FINAL-ARAH.md` subbab 2.1.10 ERD menulis ERD sebagai "alat bantu perancangan basis data" untuk menggambarkan entitas, atribut, dan relasi, tanpa menyebutnya sebagai fitur atau menu aplikasi.

Hasil: **KONSISTEN**

## 9. Konsistensi Referensi

Pengecekan sumber terlarang pada `BAB-II-FINAL-ARAH.md` (naskah BAB II final arah yang akan menjadi dasar penulisan): "Sistem, n.d.", "Literasi & Indonesia, n.d.", "PENGANTAR JARINGAN KOMPUTER, n.d.", "I, 2015", "Tri et al., n.d.", "Jogiyanto 1995", "Subtari"/"Sutabri 2005", "Gordon 1995" — tidak ditemukan satu pun kemunculan di `BAB-II-FINAL-ARAH.md`. Sumber-sumber tersebut hanya muncul di `REFERENSI-BAB-II-FINAL-CHECK.md` dan `REFERENSI-BAB-II-ONLINE-VERIFIED.md` sebagai daftar "JANGAN PAKAI DULU", bukan sebagai sitasi yang dipakai.

Hasil: **KONSISTEN**

## 10. Marker Yang Masih Ada

Marker | Jumlah di BAB I (BAB-I-FINAL-ARAH.md) | Jumlah di BAB II (BAB-II-FINAL-ARAH.md) | Catatan
---|---|---|---
`[PERLU DATA]` | 1 | 0 | Di BAB I, pada bagian 1.5.1 Observasi terkait detail waktu dan bentuk observasi langsung.
`[PERLU SITASI]` | 0 | 0 | Tidak ditemukan di kedua file.
`[PERLU CEK REFERENSI]` | 5 | 0 | Di BAB I, tersebar pada bagian 1.1 Latar Belakang (3 kemunculan) dan 1.5.1-1.5.2 Metode Penelitian (2 kemunculan), menandai bagian yang menunggu referensi BAB II final.
`[PERLU CEK APA 7]` | 0 | 1 | Di BAB II, pada subbab 2.1.11 LRS karena sumber masih penguat awal (jurnal aplikasi), bukan buku teori utama.
`[PERLU PENGUAT]` | 0 | 0 | Tidak ditemukan di kedua file.
`[BELUM DAPAT DIPASTIKAN]` | 0 | 0 | Tidak ditemukan di kedua file.

Total marker: BAB I = 6 (dihitung dari `BAB-I-FINAL-ARAH.md`, sama jumlahnya dengan `BAB-I-REVISI-1.md` karena tidak ada marker yang dihapus atau ditambahkan saat penguncian), BAB II = 1.

## 11. Rekomendasi

1. BAB I dan BAB II sudah cukup aman untuk menjadi dasar BAB III dari sisi arah, judul, objek penelitian, role, fitur, metode pengembangan, pengujian, deployment, ERD, dan referensi yang dipakai. Tidak ditemukan pertentangan substansial antara kedua bab.
2. `BAB-I-FINAL-ARAH.md` sudah dibuat pada 2026-07-05 untuk mengunci BAB I sebagai arah final, setara dengan `BAB-II-FINAL-ARAH.md`. BAB I kini terkunci sebagai final arah, bukan final mutlak, sama seperti status BAB II.
3. Marker BAB I (`[PERLU DATA]` dan `[PERLU CEK REFERENSI]`) sebaiknya dibereskan setelah referensi BAB II final benar-benar dipakai dan setelah data observasi/profil sekolah tersedia untuk BAB III. Marker ini tidak menghalangi mulai menyusun BAB III, tetapi harus dibereskan sebelum BAB I dianggap final untuk DOCX.
4. BAB II tetap perlu dicek ulang format APA 7 dan dimasukkan ke Mendeley sebelum DOCX final, khususnya subbab 2.1.11 LRS yang masih bermarker `[PERLU CEK APA 7]` dan sumber Mubarok & Sutaji (2025) yang memiliki perbedaan metadata DOI antara halaman resmi jurnal BSI dan Garuda.
