# BAB I SAMPAI BAB IV DRAFT REVIEW CHECK

Tanggal dibuat: 2026-07-05

## 1. Status Umum

BAB I sampai BAB IV sudah tersedia sebagai draft arah atau draft revisi, tetapi belum final mutlak. BAB I dan BAB II sudah dikunci sebagai final arah (`BAB-I-FINAL-ARAH.md`, `BAB-II-FINAL-ARAH.md`). BAB III dan BAB IV baru tersedia sebagai draft revisi 1 (`BAB-III-REVISI-1.md`, `BAB-IV-REVISI-1.md`) mengikuti struktur resmi hasil koreksi outline. BAB V dan `SKRIPSI.docx` belum dibuat.

## 2. File Yang Tersedia

BAB | File | Status | Catatan
---|---|---|---
BAB I | `BAB-I-FINAL-ARAH.md` | Final arah | Masih ada marker `[PERLU DATA]` dan `[PERLU CEK REFERENSI]`
BAB II | `BAB-II-FINAL-ARAH.md` | Final arah | Masih ada marker `[PERLU CEK APA 7]` pada subbab 2.1.11 LRS
BAB III | `BAB-III-REVISI-1.md` | Draft revisi 1 | Perlu review; masih ada marker `[PERLU DATA]` untuk data institusi
BAB IV | `BAB-IV-REVISI-1.md` | Draft revisi 1 | Perlu review; masih ada marker `[PERLU DATA]`, `[PERLU CEK SCREENSHOT]`, `[PERLU DATA HASIL PENGUJIAN]`, dan `[PERLU CEK BUKTI KODE]`

## 3. Marker Yang Masih Ada

Marker | BAB I | BAB II | BAB III | BAB IV | Catatan
---|---|---|---|---|---
`[PERLU DATA]` | 1 | 0 | 3 | 5 | BAB I: detail observasi. BAB III: profil, sejarah, struktur organisasi SMPI REJIS. BAB IV: rencana deployment server, versi Windows/browser/editor, spesifikasi hardware.
`[PERLU CEK REFERENSI]` | 5 | 0 | 0 | 0 | Tersebar pada BAB I 1.1 Latar Belakang dan 1.5 Metode Penelitian, menunggu referensi BAB II benar-benar dipakai sebagai sitasi di BAB I.
`[PERLU CEK APA 7]` | 0 | 1 | 0 | 0 | BAB II subbab 2.1.11 LRS, sumber masih penguat awal (jurnal aplikasi), bukan buku teori utama.
`[PERLU CEK BUKTI]` | 0 | 0 | 0 | 0 | Tidak ditemukan pada BAB I-IV revisi ini.
`[PERLU CEK SCREENSHOT]` | 0 | 0 | 0 | 5 | BAB IV 4.1.3 User Interface — halaman manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, tampilan cetak laporan.
`[PERLU DATA HASIL PENGUJIAN]` | 0 | 0 | 0 | 7 | BAB IV 4.3 Testing bagian Pengujian Kinerja Dasar — pengukuran waktu respons formal belum tersedia.
`[PERLU CEK BUKTI KODE]` | 0 | 0 | 0 | 1 | BAB IV 4.2 Code Generation — potongan kode modul aset, transaksi, surat, laporan, dan backup belum dikutip langsung.
`[BELUM DAPAT DIPASTIKAN]` | 0 | 0 | 0 | 0 | Tidak ditemukan pada BAB I-IV revisi ini.

Total marker per BAB: BAB I = 6, BAB II = 1, BAB III = 3, BAB IV = 18. Total keseluruhan = 28.

## 4. Kesiapan DOCX

DOCX draft BAB I sampai BAB IV boleh dibuat jika user meminta untuk review. Namun DOCX final belum boleh disebut final karena marker, APA 7, data institusi, screenshot, bukti diagram, dan hasil pengujian masih perlu dicek. Secara rinci, sebelum DOCX final:

1. Marker `[PERLU DATA]` pada BAB I, BAB III, dan BAB IV perlu dilengkapi dengan data nyata atau tetap ditandai secara eksplisit jika dosen mengizinkan bagian tersebut tetap terbuka.
2. Marker `[PERLU CEK REFERENSI]` pada BAB I perlu dibereskan setelah sitasi BAB II dipakai secara langsung di BAB I.
3. Marker `[PERLU CEK APA 7]` pada BAB II perlu dicek ulang bersama Mendeley sebelum daftar pustaka final.
4. Marker `[PERLU CEK SCREENSHOT]` pada BAB IV perlu dilengkapi dengan pengambilan screenshot tambahan pada 5 halaman yang belum ada buktinya.
5. Marker `[PERLU DATA HASIL PENGUJIAN]` pada BAB IV perlu dilengkapi dengan pengukuran waktu respons formal, atau dipertahankan sebagai batasan penelitian jika pengukuran formal tidak dilakukan.
6. Marker `[PERLU CEK BUKTI KODE]` pada BAB IV perlu dilengkapi dengan potongan kode tambahan yang sudah diverifikasi aman untuk dikutip.

Sampai seluruh poin di atas selesai, BAB I sampai BAB IV berstatus draft yang boleh direview tetapi belum final mutlak.
