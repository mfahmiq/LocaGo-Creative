# BAB I

# PENDAHULUAN

Status dokumen: data patch 1 dari `BAB-I-FINAL-ARAH-REFPATCH-1.md`. Pada putaran pengisian data ini (`USER-DATA-INPUT-ROUND-1.md`), user belum mengisi data observasi (waktu dan bentuk pelaksanaan observasi langsung masih berupa placeholder kosong). Sesuai instruksi, marker `[PERLU DATA]` pada bagian observasi **dipertahankan tanpa perubahan** karena belum ada data nyata untuk menggantikannya. Tidak ada substansi lain yang diubah pada patch ini. Kandidat BAB I terbaru, belum menjadi naskah final DOCX.

## 1.1. Latar Belakang

Pengelolaan administrasi sekolah perlu didukung oleh pencatatan yang rapi, mudah ditelusuri, dan dapat digunakan kembali saat dibutuhkan. Pada lingkungan sekolah, administrasi tidak hanya berhubungan dengan kegiatan pembelajaran, tetapi juga mencakup pengelolaan inventaris aset, pencatatan surat masuk, proses disposisi, pengarsipan surat, penyusunan surat keluar, dan pembuatan laporan. Sistem Informasi (Information System) berbasis web dapat digunakan untuk membantu penyimpanan data secara terpusat dan mendukung proses pencarian data agar lebih terstruktur (Wahyuni, Muthmainnah, Permana, & Novalima, 2025).

SMPI REJIS menjadi objek penelitian dalam penyusunan skripsi ini. Berdasarkan transkrip wawancara penelitian, wawancara dilakukan pada 27 April 2026 dengan Wakil Kepala Sekolah Bidang Kesiswaan SMPI REJIS, yaitu Gilang Ramadhan S.Kom. atau Ust. Gilang. Wawancara tersebut digunakan untuk mengetahui kondisi pengelolaan inventaris aset dan pengelolaan surat yang berjalan di sekolah.

Berdasarkan hasil wawancara, pengelolaan inventaris aset di SMPI REJIS masih dilakukan secara manual menggunakan buku. Pencatatan menggunakan Microsoft Excel pernah dicoba, tetapi tidak berlanjut. Kondisi tersebut menyebabkan data barang masuk, barang keluar, dan peminjaman aset belum terdokumentasi secara konsisten. Data aset yang seharusnya dapat ditelusuri, seperti letak barang dan riwayat peminjaman, belum tersusun dalam satu sistem yang terpusat.

Permasalahan inventaris aset juga terlihat pada pengelompokan aset. Aset belum dikelompokkan secara jelas berdasarkan kategori, lokasi, dan kondisi barang. Dalam praktiknya, aset yang dipinjam dapat tidak kembali ke tempat semula sehingga sekolah mengalami kesulitan ketika perlu mengetahui keberadaan barang. Kondisi ini menunjukkan bahwa sekolah membutuhkan sistem yang mampu mencatat data aset, lokasi aset, status penggunaan, serta transaksi peminjaman dan pengembalian aset secara lebih teratur.

Pengelolaan surat di SMPI REJIS juga masih dilakukan secara manual. Pencatatan surat masuk belum terintegrasi dalam sistem terpusat, sedangkan arsip surat masuk dan surat keluar masih tersimpan secara terpisah. Kondisi tersebut dapat menyulitkan pencarian kembali dokumen dan pemantauan status tindak lanjut surat. Pada proses disposisi, arahan dari kepala sekolah atau wakil kepala sekolah kepada staf belum didukung mekanisme pemantauan yang terstruktur sehingga status penyelesaian surat belum mudah dikontrol.

Berdasarkan kondisi tersebut, diperlukan sistem terintegrasi inventaris aset dan disposisi surat berbasis web. Sistem terintegrasi diperlukan agar pengelolaan aset, transaksi peminjaman aset, surat masuk, disposisi surat, surat keluar, laporan, dan backup dapat berada dalam satu aplikasi. Dengan adanya sistem tersebut, data administrasi sekolah dapat disimpan lebih rapi, proses pencarian data dapat dilakukan lebih mudah, dan laporan dapat disusun berdasarkan data yang tercatat pada aplikasi.

Sistem yang dirancang dalam penelitian ini menggunakan CodeIgniter 4 sebagai *framework* pengembangan aplikasi dan MySQL/MariaDB sebagai basis data. Pemilihan teknologi tersebut dibahas sebagai bagian dari implementasi aplikasi, sedangkan penelitian ini tetap berfokus pada perancangan sistem dan kesesuaian fitur dengan kebutuhan administrasi SMPI REJIS. Aplikasi dikembangkan dan diuji pada lingkungan lokal menggunakan Laragon, sehingga penelitian ini tidak menulis klaim penerapan produksi, penerapan daring, atau penggunaan resmi pada server sekolah.

Model pengembangan sistem yang digunakan adalah Agile Scrum. Scrum digunakan karena kebutuhan aplikasi dapat dibagi ke dalam beberapa kelompok pekerjaan, seperti autentikasi, dashboard, manajemen pengguna, inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup. Dalam penelitian ini, Scrum dijelaskan sebagai pendekatan iteratif untuk menyusun kebutuhan ke dalam *product backlog*, memetakan pekerjaan ke dalam *sprint*, menghasilkan modul aplikasi, dan mengevaluasi fitur melalui pengujian (Scrum Guide, 2020).

Pengujian sistem dalam penelitian ini mencakup *black-box testing*, pengujian keamanan dasar, dan pengujian kinerja dasar. *Black-box testing* digunakan untuk memeriksa kesesuaian fungsi aplikasi berdasarkan masukan dan keluaran. Pengujian keamanan dasar digunakan untuk memeriksa mekanisme autentikasi, otorisasi, validasi input, sesi pengguna, unggah file, dan akses halaman. Pengujian kinerja dasar digunakan untuk memeriksa waktu respons halaman dan proses utama pada lingkungan lokal. Detail skenario dan hasil pengujian dibahas pada BAB IV (ISTQB Glossary).

Dengan demikian, penelitian ini diarahkan untuk merancang sistem yang dapat mendukung pengelolaan administrasi aset dan surat pada SMPI REJIS secara lebih terstruktur. Sistem yang dirancang tidak dimaksudkan untuk menggantikan seluruh prosedur administrasi sekolah, tetapi menjadi alat bantu pencatatan, pengolahan data, pemantauan status, dan penyusunan laporan berdasarkan fitur yang tersedia pada aplikasi.

## 1.2. Identifikasi Masalah

Berdasarkan latar belakang tersebut, permasalahan pada penelitian ini dapat diidentifikasi sebagai berikut:

1. Proses pencatatan inventaris aset masih dilakukan secara manual sehingga pencarian data membutuhkan waktu lebih lama dan berisiko menimbulkan kesalahan pencatatan.
2. Data barang masuk, barang keluar, dan peminjaman aset belum terdokumentasi secara konsisten sehingga riwayat penggunaan aset sulit ditelusuri.
3. Pengelompokan aset berdasarkan kategori, lokasi, dan kondisi barang belum tersusun secara terstruktur.
4. Lokasi dan status aset sulit dipantau karena belum tersedia sistem yang dapat mencatat pergerakan atau peminjaman aset.
5. Pencatatan surat masuk masih dilakukan secara manual sehingga berisiko menimbulkan keterlambatan pengolahan informasi.
6. Arsip surat tersimpan secara terpisah sehingga pencarian kembali dokumen belum efisien.
7. Disposisi surat belum memiliki mekanisme pemantauan yang terstruktur sehingga tindak lanjut surat belum dapat dikontrol dengan baik.

## 1.3. Perumusan Masalah

Berdasarkan identifikasi masalah tersebut, rumusan masalah dalam penelitian ini adalah sebagai berikut:

1. Bagaimana merancang sistem terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS?
2. Bagaimana sistem dapat membantu pengelolaan inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup secara terstruktur?
3. Bagaimana penerapan Agile Scrum dalam pengembangan sistem inventaris aset dan disposisi surat berbasis web?
4. Bagaimana hasil pengujian sistem melalui *black-box testing*, pengujian keamanan dasar, dan pengujian kinerja dasar terhadap fungsi utama aplikasi?
5. Apakah sistem yang dirancang dapat mendukung kebutuhan administrasi aset dan surat pada SMPI REJIS?

## 1.4. Tujuan dan Manfaat

Tujuan dan manfaat penelitian digunakan untuk menjelaskan arah perancangan sistem serta kontribusi yang diharapkan dari hasil penelitian.

### 1.4.1. Tujuan Penelitian

Tujuan penelitian ini adalah sebagai berikut:

1. Merancang sistem terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS.
2. Membangun aplikasi yang mendukung pengelolaan pengguna, inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup.
3. Menerapkan Agile Scrum sebagai pendekatan pengembangan sistem melalui pemetaan kebutuhan, *product backlog*, *sprint mapping*, implementasi modul, dan evaluasi fitur.
4. Melakukan pengujian sistem menggunakan *black-box testing*, pengujian keamanan dasar, dan pengujian kinerja dasar.
5. Menghasilkan sistem yang dapat mendukung pengelolaan administrasi aset dan surat secara lebih terstruktur.

### 1.4.2. Manfaat Penelitian

Manfaat penelitian ini adalah sebagai berikut:

1. Bagi penulis

   Penelitian ini bermanfaat untuk menambah pemahaman dan keterampilan dalam perancangan sistem informasi berbasis web, penerapan CodeIgniter 4, pengelolaan basis data MySQL/MariaDB, penggunaan Agile Scrum, serta pengujian sistem. Penelitian ini juga menjadi salah satu bentuk penerapan ilmu yang diperoleh selama menempuh Program Studi Teknologi Informasi pada Universitas Bina Sarana Informatika.

2. Bagi SMPI REJIS

   Penelitian ini bermanfaat sebagai rancangan sistem yang dapat membantu pengelolaan inventaris aset, transaksi peminjaman aset, pencatatan surat masuk, disposisi surat, surat keluar, pengarsipan, laporan, dan backup. Sistem yang dirancang diharapkan dapat membantu sekolah dalam menyusun data administrasi secara lebih terpusat dan mudah ditelusuri.

3. Bagi pembaca atau peneliti selanjutnya

   Penelitian ini dapat menjadi referensi mengenai perancangan sistem administrasi sekolah berbasis web, khususnya yang mengintegrasikan pengelolaan inventaris aset dan disposisi surat. Penelitian ini juga dapat menjadi gambaran awal mengenai penerapan Agile Scrum pada pengembangan aplikasi administrasi sekolah.

## 1.5. Metode Penelitian

Metode penelitian pada skripsi ini mencakup teknik pengumpulan data dan model pengembangan sistem. Teknik pengumpulan data digunakan untuk memperoleh informasi mengenai kondisi berjalan dan kebutuhan sistem, sedangkan model pengembangan sistem digunakan untuk menjelaskan tahapan pembangunan aplikasi.

### 1.5.1. Teknik Pengumpulan Data

Teknik pengumpulan data yang digunakan dalam penelitian ini adalah sebagai berikut:

1. Observasi

   Observasi dilakukan untuk memahami proses administrasi yang berjalan, khususnya pengelolaan inventaris aset dan pengelolaan surat. Observasi juga diarahkan untuk memahami kebutuhan fitur aplikasi yang berhubungan dengan pencatatan aset, peminjaman aset, surat masuk, disposisi, surat keluar, laporan, dan backup. Detail pelaksanaan observasi, seperti waktu dan bentuk observasi langsung, masih perlu dilengkapi dari bukti riset. [PERLU DATA]

2. Wawancara

   Wawancara dilakukan dengan Wakil Kepala Sekolah Bidang Kesiswaan SMPI REJIS, yaitu Gilang Ramadhan S.Kom. atau Ust. Gilang, pada 27 April 2026. Wawancara digunakan untuk memperoleh informasi mengenai kondisi pengelolaan inventaris aset, pengelolaan surat, kendala yang terjadi, dan kebutuhan sistem yang diharapkan oleh pihak sekolah.

3. Studi pustaka

   Studi pustaka dilakukan dengan mempelajari buku, jurnal ilmiah, dan referensi lain yang berkaitan dengan Sistem Informasi, website, inventaris aset, surat, disposisi surat, basis data MySQL, PHP, CodeIgniter, UML, ERD, LRS, Agile Scrum, dan *black-box testing*. Referensi yang digunakan harus mengikuti pedoman penulisan, menggunakan gaya APA 7 melalui Mendeley, dan tidak berasal dari Blogspot, Wordpress, atau Wikipedia, sebagaimana telah dikumpulkan dan diverifikasi pada kajian teori BAB II (lihat `BAB-II-FINAL-ARAH-REFPATCH-1.md`).

### 1.5.2. Model Pengembangan Sistem

Model pengembangan sistem yang digunakan dalam penelitian ini adalah Agile Scrum. Scrum merupakan model pengembangan perangkat lunak yang bersifat iteratif dan bertahap. Model ini membagi kebutuhan sistem ke dalam daftar kebutuhan atau *product backlog*, kemudian memilih pekerjaan yang akan dikerjakan dalam *sprint* sesuai prioritas pengembangan (Scrum Guide, 2020).

Penerapan Scrum dalam penelitian ini disesuaikan dengan kebutuhan sistem inventaris aset dan disposisi surat berbasis web pada SMPI REJIS. Kebutuhan sistem disusun berdasarkan hasil wawancara, observasi, studi pustaka, dan audit aplikasi. Kebutuhan tersebut kemudian dipetakan ke dalam modul utama, yaitu autentikasi, dashboard, manajemen pengguna, inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup.

Pada BAB I, pembahasan Scrum ditulis secara ringkas agar tidak mendahului uraian implementasi. Detail *product backlog*, *sprint backlog*, *sprint mapping*, hasil increment, implementasi modul, dan evaluasi fitur akan dibahas pada BAB IV bersama hasil pengujian. Penelitian ini tidak menuliskan tanggal *sprint*, nama Scrum Master, Product Owner, Daily Scrum, Sprint Review, atau Sprint Retrospective sebagai fakta historis apabila bukti rinci belum tersedia.

## 1.6. Ruang Lingkup

Ruang lingkup penelitian ini dibatasi pada perancangan sistem terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS. Aplikasi dikembangkan menggunakan CodeIgniter 4 dengan basis data MySQL/MariaDB dan diuji pada lingkungan lokal menggunakan Laragon. Penelitian ini tidak membahas penerapan produksi, penerapan daring, atau penggunaan resmi pada server sekolah.

Pengguna sistem mengikuti peran yang tersedia pada aplikasi, yaitu admin, operator, dan pimpinan. Dalam konteks operasional sekolah, peran tersebut dapat dipadankan dengan admin atau operator administrasi dan pimpinan sekolah sesuai kebutuhan hak akses.

Fitur yang dibahas dalam penelitian ini mencakup:

1. Login dan autentikasi pengguna.
2. Dashboard.
3. Manajemen pengguna.
4. Inventaris aset.
5. Transaksi atau peminjaman aset.
6. Surat masuk.
7. Disposisi surat.
8. Surat keluar.
9. Laporan.
10. Backup.

Pengujian sistem mencakup *black-box testing*, pengujian keamanan dasar, dan pengujian kinerja dasar. Pengujian keamanan dasar dibatasi pada pemeriksaan autentikasi, pembatasan hak akses berdasarkan peran, akses halaman tanpa login, akses langsung ke URL tertentu sesuai peran, logout dan sesi pengguna, validasi input pada form penting, unggah file atau lampiran dummy, serta route dan menu ERD yang tidak ditampilkan sebagai fitur operasional. Pengujian kinerja dasar dibatasi pada pemeriksaan waktu respons halaman dan proses utama pada lingkungan lokal, seperti halaman login, dashboard, data aset, surat masuk, pencarian atau filter, simpan data uji, pembuatan laporan, CSV, PDF, dan backup database.

Penelitian ini tidak mencakup integrasi dengan sistem eksternal, tanda tangan digital, email otomatis, penerapan multi-sekolah, *penetration testing*, *load testing*, *stress testing*, benchmark server produksi, atau audit keamanan tingkat lanjut. ERD digunakan sebagai artefak perancangan dan dokumentasi skripsi, bukan sebagai fitur operasional aplikasi.
