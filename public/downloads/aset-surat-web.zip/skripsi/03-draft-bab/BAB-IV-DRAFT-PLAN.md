# BAB IV DRAFT PLAN

Tanggal dibuat: 2026-07-05

## 1. Status

File ini adalah rencana penyusunan BAB IV berdasarkan outline resmi user, bukan naskah final. Rencana disusun mengacu pada `OUTLINE-CORRECTION-BAB-III-IV.md`, `BAB-III-IV-STRUCTURE-FINAL-ARAH.md`, dan bukti yang tersedia di `skripsi/02-data-aplikasi/` serta `skripsi/04-diagram-dan-gambar/`.

## 2. Struktur BAB IV

```text
BAB IV
IMPLEMENTASI DAN PENGUJIAN SOFTWARE

4.1. Desain
     4.1.1. Database
     4.1.2. Software Architecture
     4.1.3. User Interface

4.2. Code Generation

4.3. Testing

4.4. Support
     4.4.1. Publikasi Software
     4.4.2. Spesifikasi Hardware dan Software
```

## 3. Penempatan Artefak

No | Artefak | Letak BAB IV | Catatan
---|---|---|---
1 | ERD | 4.1.1 Database | Gambar desain database. File: `diagram-source/erd-final.mmd`, `diagram-output/erd-final.svg` — ADA.
2 | LRS | 4.1.1 Database | Gambar/tabel desain database logis. File: `skripsi/04-diagram-dan-gambar/LRS_DRAFT.md` — ADA (berbentuk tabel, bukan gambar).
3 | Spesifikasi tabel | 4.1.1 Database | Tabel struktur data 9 tabel bisnis utama, bersumber dari `DATABASE_ERD_AUDIT.md` dan `LRS_DRAFT.md` — ADA.
4 | Use Case Diagram | 4.1.2 Software Architecture | Diagram kebutuhan sistem. File: `diagram-source/use-case-diagram.mmd`, `diagram-output/use-case-diagram.svg` — ADA, perlu perhatian layout menurut `DIAGRAM_QUALITY_REVIEW.md`.
5 | Activity Diagram | 4.1.2 Software Architecture | Diagram alur proses (login, inventaris aset, transaksi aset, surat masuk-disposisi, surat keluar) — ADA seluruhnya di `diagram-source/`/`diagram-output/`.
6 | Sequence Diagram | 4.1.2 Software Architecture | Diagram interaksi sistem (login, transaksi aset, disposisi surat) — ADA seluruhnya.
7 | Arsitektur MVC | 4.1.2 Software Architecture | Arsitektur aplikasi CodeIgniter. File: `diagram-source/arsitektur-mvc.mmd`, `diagram-output/arsitektur-mvc.svg` — ADA.
8 | User Interface | 4.1.3 User Interface | Tampilan halaman aplikasi. Sebagian besar screenshot ADA di `skripsi/04-diagram-dan-gambar/screenshots/`; beberapa halaman (manajemen pengguna, form transaksi aset, form surat masuk, form surat keluar, cetak laporan) belum ada screenshot khusus — `[PERLU CEK SCREENSHOT]`.
9 | Potongan kode atau uraian kode | 4.2 Code Generation | Jangan tampilkan data sensitif. Potongan kode `AuthController.php` dan `RoleFilter.php` sudah dibaca dan aman dikutip; modul lain (aset, transaksi, surat, laporan, backup) diuraikan naratif berdasarkan `APLIKASI_FEATURE_AUDIT.md` dan diberi `[PERLU CEK BUKTI KODE]` untuk potongan kode tambahan.
10 | Black-box testing | 4.3 Testing | Pengujian fungsi. Sumber: `BLACKBOX_TEST_SCENARIOS.md` — 42 skenario, seluruhnya berstatus valid per pembaruan 2026-07-04.
11 | Pengujian keamanan dasar | 4.3 Testing | Bukan penetration testing. Diturunkan dari skenario login, akses tanpa sesi, dan pembatasan role pada `BLACKBOX_TEST_SCENARIOS.md`.
12 | Pengujian kinerja dasar | 4.3 Testing | Bukan load atau stress testing. Baru mencatat keberhasilan respons (HTTP 200), belum ada pengukuran waktu respons formal — `[PERLU DATA HASIL PENGUJIAN]`.
13 | Publikasi software | 4.4.1 Publikasi Software | Lokal Laragon, bukan online produksi.
14 | Spesifikasi hardware dan software | 4.4.2 Spesifikasi Hardware dan Software | Software terverifikasi (PHP 8.4.10, Composer 2.8.9, CodeIgniter v4.7.3); spesifikasi hardware belum tersedia — `[PERLU DATA]`.

## 4. Data Yang Dibutuhkan

1. File ERD — sudah tersedia (`diagram-output/erd-final.svg`).
2. File LRS — sudah tersedia (`LRS_DRAFT.md`).
3. Spesifikasi tabel database — sudah tersedia (`DATABASE_ERD_AUDIT.md`, `LRS_DRAFT.md`).
4. Diagram Use Case, Activity, Sequence — sudah tersedia seluruhnya di `diagram-output/`.
5. Gambar Arsitektur MVC — sudah tersedia (`diagram-output/arsitektur-mvc.svg`).
6. Screenshot halaman aplikasi — sebagian besar tersedia; halaman manajemen pengguna, form transaksi aset (create), form surat masuk (create), form surat keluar (create), dan cetak laporan (print) belum memiliki screenshot khusus — `[PERLU CEK SCREENSHOT]`.
7. Potongan kode aman atau uraian code generation — tersedia untuk autentikasi (`AuthController.php`) dan filter role (`RoleFilter.php`); modul lain masih `[PERLU CEK BUKTI KODE]` untuk kutipan langsung.
8. Hasil black-box testing — tersedia lengkap (42 skenario valid) pada `BLACKBOX_TEST_SCENARIOS.md`.
9. Hasil pengujian keamanan dasar — tersedia sebagian melalui skenario login dan role access; belum ada laporan keamanan terpisah.
10. Hasil pengujian kinerja dasar — belum tersedia pengukuran waktu respons formal — `[PERLU DATA HASIL PENGUJIAN]`.
11. Spesifikasi hardware dan software — software terverifikasi sebagian, hardware belum tersedia — `[PERLU DATA]`.
12. Status publikasi software — sudah jelas: lokal/Laragon, belum ada bukti deployment produksi.

## 5. Risiko

1. Jangan mengklaim aplikasi online.
2. Jangan mengklaim aplikasi produksi.
3. Jangan mengklaim aplikasi resmi digunakan sekolah.
4. Jangan mengklaim sistem aman dari semua serangan.
5. Jangan mengklaim sistem kuat untuk banyak pengguna.
6. Jangan menggandakan diagram di BAB III — seluruh diagram teknis hanya muncul di BAB IV sesuai koreksi outline.
7. Jangan membuat Class Diagram sebagai subbab utama.
8. Jangan membuat Deployment Diagram sebagai subbab utama; Deployment Diagram hanya boleh menjadi gambar pendukung opsional pada 4.1.2 atau 4.4.2.
