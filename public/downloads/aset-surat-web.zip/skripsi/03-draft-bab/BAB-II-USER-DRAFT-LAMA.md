<!--
Status: BAHAN MENTAH / USER DRAFT LAMA BAB II
Fungsi: arsip dan bahan audit, bukan naskah final.
Catatan: struktur, sitasi, sumber, dan istilah di dalam file ini perlu diverifikasi sebelum digunakan pada BAB II final.
-->

# BAB II

# LANDASAN TEORI

## 2.1 Tinjauan Pustaka

### 2.1.1	Konsep Dasar Sistem dan Informasi
Sistem merupakan sekumpulan komponen yang saling berhubungan dan bekerja sama untuk mencapai tujuan tertentu. Dalam konteks teknologi informasi, sistem tidak hanya dipahami sebagai kumpulan perangkat keras atau perangkat lunak, tetapi juga mencakup prosedur, pengguna, data, serta aturan yang membentuk suatu proses kerja. Suatu sistem dapat dikatakan berjalan dengan baik apabila setiap komponen di dalamnya saling mendukung dan menghasilkan keluaran sesuai dengan tujuan yang telah ditentukan.
Sistem informasi saat ini telah menjadi pndasi serta kemajuan dalam transformasi diberbagai esensi kehidupan manusia. Sistem informasi menduduki peran penting dalam pengelolaan informasi. Komunikasi, dan pengambilan keputusan berbagai bidang/sektor. Mulai dari sektor bisnis, pemerintahan, pendidikan, kesehatan, dan sektor lainnya. Pemanfaatan sistem informasi memungkinkan organisasi untuk dapat mengoptimalkan proses operasional dan memberikan pelayanan terbaik kepada pelanggan dan stackholder.(Sistem, n.d.)
Informasi dapat diartikan sebagai hasil pengolahan data dari satu atau berbagai  sumber yang diolah sedemikian rupa sehingga dapat memberikan arti, nilai dan manfaat. Data sendiri dapat didefinisikan sebagai kenyataan yang menggambarkan suatu kejadian dan kesatuan nyata. Sedangkan menurut (Jogiyanto, 1995) informasi ialah hasil pengolahan data ke dalam suatu bentuk yang lebih berguna dan lebih berarti bagi penerima informasi tersebut yang menggambarkan suatu kejadian yang nyata yang nantinya akan digunakan untuk engambilan keputusan.(Literasi & Indonesia, n.d.)
Menurut (subtari, 2005), sistem dapat diartikan sebagai kumpulan  atau himpunan dari unsur, komponen atau variabel yang terpadu dan teroganisir, saling berinteraksi dan saling ketergantungan suatu sama lain, misalnya sistem komputer yang tersdiri dari hardware dan software. Sedangkan menurut (gordon, 1995), sistem terbagi dalam beberapa subsistem-subsistem, di mana batasan dan penghubung ditelaah guna menjamin bubungan antar subsistem didefinisikan secara cepat.(Literasi & Indonesia, n.d.)
Pada lingkungan sekolah, sistem dapat ditemukan dalam berbagai aktivitas administrasi, seperti pencatatan data siswa, pengelolaan surat, pengelolaan inventaris, serta pembuatan laporan. Setiap aktivitas tersebut memiliki alur kerja, pelaksana, dokumen, serta keluaran yang berbeda-beda. Apabila proses tersebut masih dilakukan secara manual dan tidak saling terhubung, maka informasi yang dihasilkan berpotensi kurang akurat, sulit ditelusuri, dan membutuhkan waktu lebih lama ketika dibutuhkan.
Informasi merupakan hasil pengolahan data yang memiliki makna dan berguna bagi penerima dalam proses pengambilan keputusan. Data yang belum diolah belum dapat memberikan manfaat secara langsung. Misalnya, daftar barang, nomor surat, tanggal surat, atau nama peminjam aset hanya menjadi data mentah apabila tidak dikelola ke dalam sistem yang terstruktur. Setelah data tersebut diolah, dikelompokkan, dan disajikan dalam bentuk laporan, maka data tersebut berubah menjadi informasi yang dapat digunakan oleh pihak sekolah untuk mengetahui kondisi aset, riwayat peminjaman, atau status tindak lanjut surat.
Sistem informasi merupakan gabungan antara manusia, prosedur, data, perangkat lunak, perangkat keras, dan jaringan yang digunakan untuk mengumpulkan, mengolah, menyimpan, serta menyajikan informasi. Sistem informasi memiliki peran penting dalam membantu organisasi mengelola data secara lebih teratur. Dalam penelitian ini, sistem informasi digunakan untuk mendukung proses administrasi sekolah, khususnya pada pengelolaan inventaris aset dan disposisi surat. Sistem yang dirancang diharapkan mampu memperbaiki proses pencatatan manual menjadi proses digital yang lebih terstruktur.
Sistem informasi berbasis web merupakan sistem informasi yang dapat diakses melalui peramban dengan memanfaatkan jaringan internet atau intranet. Keunggulan sistem berbasis web terletak pada kemudahan akses, penyimpanan data terpusat, serta fleksibilitas penggunaan. (Annisa dkk., 2023) menunjukkan bahwa sistem inventaris sarana dan prasarana berbasis web dapat membantu sekolah mengelola data inventaris yang sebelumnya masih tersimpan dalam buku atau Microsoft Excel. Hal tersebut relevan dengan kondisi SMPI REJIS yang masih membutuhkan sistem pencatatan aset dan surat yang lebih terpusat.
Dengan demikian, konsep sistem informasi menjadi dasar utama dalam penelitian ini. Sistem yang akan dirancang tidak hanya berfungsi sebagai media pencatatan, tetapi juga sebagai alat bantu dalam proses pengelolaan, pencarian, pemantauan, dan pelaporan data administrasi sekolah.

### 2.1.2	Website, World Wide Web, Internet, dan Web Browser
Website merupakan kumpulan halaman yang saling terhubung dan dapat diakses melalui jaringan internet atau jaringan lokal. Dalam pengembangan sistem informasi, website digunakan sebagai media antarmuka antara pengguna dengan sistem. Pengguna dapat memasukkan data, melihat informasi, memperbarui data, serta mencetak laporan melalui halaman-halaman yang telah disediakan.
Dalam penelitian ini, website digunakan sebagai media utama untuk menjalankan sistem inventaris aset dan disposisi surat. Penggunaan website dipilih karena aplikasi dapat diakses melalui perangkat yang memiliki peramban, sehingga pengguna tidak perlu memasang aplikasi khusus pada perangkat masing-masing. Hal ini sesuai dengan kebutuhan SMPI REJIS yang memerlukan sistem administrasi yang dapat digunakan oleh Admin TU, Kepala Sekolah, dan Staff sesuai hak akses masing-masing.

#### A.	World Wide Web (WWW)
World Wide Web atau WWW merupakan layanan berbasis internet yang memungkinkan pengguna mengakses halaman web melalui alamat tertentu atau URL. WWW menyediakan mekanisme untuk menampilkan informasi dalam bentuk teks, gambar, tabel, formulir, dokumen, dan tautan antardokumen. Melalui WWW, pengguna dapat berpindah dari satu halaman ke halaman lain menggunakan hyperlink.
Pada sistem inventaris aset dan disposisi surat berbasis web, konsep WWW digunakan untuk menyediakan halaman-halaman sistem seperti halaman login, dashboard, data aset, peminjaman aset, surat masuk, disposisi surat, laporan inventaris, dan laporan surat. Setiap halaman tersebut saling terhubung sehingga membentuk satu aplikasi yang dapat digunakan secara terstruktur.

#### B.	Internet
Internet adalah jaringan global yang menghubungkan jutaan komputer dan jaringan di seluruh dunia, memungkinkan akses informasi dan komunikasi publik tanpa batasan geografis. Keamanan intranet cenderung lebih ketat karena berada di balik firewall dan kontrol akses internal, sedangkan internet lebih rentan terhadap berbagai ancaman cyber karena keterbukaannya. Sementara intranet fokus pada kebutuhan internal dan efisiensi operasional organisasi, internet menyediakan platform luas untuk komunikasi global, perdagangan elektronik, pendidikan, dan hiburan.(PENGANTAR JARINGAN KOMPUTER, n.d.)
Meskipun demikian, aplikasi berbasis web juga dapat berjalan pada jaringan lokal atau intranet. Apabila sistem hanya digunakan di lingkungan internal SMPI REJIS, maka aplikasi dapat dipasang pada server lokal dan diakses melalui jaringan sekolah. Dengan demikian, sistem tetap menggunakan konsep web meskipun tidak selalu harus dipublikasikan secara luas di internet.

#### C.	Web Browser
Browser atau Browser atau Penjelajah Web  sudah tidak asing lagi ditelinga kita, setiap hari kita selalu berhubungan dengan browser. Aktifitas kerja ataupun hiburan kini kebanyakan dijalankan di browser  dengan memanfaatkan  jaringan internet. Secara singkat browser  adalah alat untuk menjelajahi atau membuka konten-konten yang bertebaran di dunia maya. Pengertian Browser  adalah suatu aplikasi atau program yang dijalankan pada perangkat komputer untuk melihat konten yang ada pada media World Wide Web (WWW) dengan memanfaatkan jaringan internet. Teknologi browser  yang berkembang saat ini tidak hanya dapat menampilkan halaman yang berisi text atau tulisan saja, browser-browser populer sekarang dapat menampilkan gambar, musik, suara, video, file pdf dan data lainnya.(I, 2015)
Jenis-jenis Web Browser:
1.	Mozila firefox
Mozilla Firefox (aslinya bernama Phoenix dan kemudian untuk sesaat dikenal sebagai Mozilla Firebird) adalah peramban web lintas platform gratis yang dikembangkan oleh Yayasan Mozilla dan ratusan sukarelawan. Sebelum rilis versi 1.0-nya pada 9 November 2004, Firefox telah mendapatkan sambutan yang sangat bagus dari pihak media, termasuk dari Forbes dan Wall Street Journal. Dengan lebih dari 5  juta download dalam 12 hari pertama rilisnya dan 6 juta hingga24 November 2004, Firefox 1.0 adalah salah satu perangkat lunak gratis, sumber terbuka (open-source) yang paling banyak digunakan di antara pengguna rumahan. Dibuat oleh mozilla corporation, Mozilla firefox adalah salah satu dari web browser open source yang dibangun dengan Gecko layout engine. Web browser merupakan salah satu dari macam macam Web browser yang handal karena didukung oleh sejumlah  Add-ons yang dapat diinstall secara terpisah yang memungkinkan pengguna melakukan sesuai dengan kegunaan Add-ons tersebut. Melalui Firefox, Yayasan Mozilla betujuan untuk mengembangkan sebuah peramban web yang kecil, cepat, sederhana, dan sangat bisa dikembangkan (terpisah dari Mozilla Suite yang lebih besar). Sejak 3 April 2003, Firefox dan klien surel Thunderbird telah menjadi fokus utama pengembang Yayasan Mozilla untuk menggantikan Mozilla Suite. Firefox dapat dijalankan pada berbagai macam sistem operasi sepertiMicrosoftWindows, Linux, Mac OS X, dan FreeBSD. Versi stabil terbaru Firefox saat ini adalah 14.0.1, yang dirilis pada 15 Juni 2012 .(I, 2015)
2.	Google Chrome
Google Chrome adalah sebuah peramban web sumber terbukayang dikembangkan oleh Google dengan menggunakanmesinrenderingWeb Kit. Proyek sumber terbukanya sendiri dinamakan Chromium. Google Chrome adalah program aplikasi peramban web yang berguna untuk menjelajahi internet. Versi terbaru program ini adalah Google Chrome 18, yang dirilis pada tanggal 12 April 2012. Software Google Chrome dibuat dan dikembangkan olehGoogle Inc. Perangkat lunak komputer ini memiliki kelebihan padakecepatan dan tampilannya yang bersih. Di balik tampilannya yang minimalis dan sederhana, Google Chrome memiliki segudang fitur yang setara dengan aplikasi peramban alias web browser modern lainnya. Fitur seperti multitab, bookmark, dan fitur penambahan fungsi melalui ekstensi bisa Anda temukan. Aplikasi ini juga terintegrasi dengan beberapa layanan Google, seperti fitur terjemah halaman web secara otomatis (termasuk dalam Bahasa Indonesia) dan fitur pencarian Google. Program Google Chrome banyak diaplikasikan dan digunakan oleh berbagai kalangan pengguna internet. Google Chrome merupakan software gratis. Google Chrome dapat dijalankan di sistem operasi Windows XP, Windows Vista, Windows 7, serta tersedia untuk Mac dan Linux. Untuk menginstall versi terbaru program ini, komputer Windows Anda harus memiliki spesifikasi minimal menggunakan prosesor Intel Pentium 4, memori (RAM) 128 MB, dan harddisk dengan kapasitas kosong minimal 100 MB.(I, 2015)
Dalam sistem yang dirancang, Admin TU, Kepala Sekolah, dan Staff dapat mengakses sistem melalui web browser. Pengguna cukup membuka alamat aplikasi, melakukan login, kemudian menggunakan fitur sesuai hak aksesnya. Dengan pendekatan ini, penggunaan sistem menjadi lebih praktis karena tidak memerlukan instalasi aplikasi tambahan pada setiap perangkat.

#### D.	Arsitektur Client-Server pada Aplikasi Web
Aplikasi web umumnya menggunakan arsitektur client-server. Pada arsitektur ini, client merupakan perangkat pengguna yang mengirim permintaan melalui web browser, sedangkan server merupakan tempat aplikasi dan basis data dijalankan. Ketika pengguna melakukan login, menambahkan data aset, melakukan disposisi surat, atau mencetak laporan, permintaan tersebut dikirim dari client ke server untuk diproses. Setelah proses selesai, server mengirimkan hasilnya kembali kepada client untuk ditampilkan pada halaman web.
Arsitektur client-server sesuai digunakan pada sistem administrasi sekolah karena data dapat disimpan secara terpusat dan dikelola berdasarkan hak akses. Dengan penyimpanan terpusat, risiko duplikasi data dapat dikurangi dan proses pencarian data dapat dilakukan lebih cepat.

### 2.1.3	Inventaris Aset
Inventaris merupakan kegiatan pencatatan dan pengelolaan barang yang dimiliki oleh suatu organisasi atau instansi. Dalam lingkungan sekolah, inventaris mencakup sarana dan prasarana yang digunakan untuk menunjang kegiatan belajar mengajar maupun kegiatan administrasi. Aset sekolah dapat berupa meja, kursi, komputer, proyektor, lemari, alat praktik, perangkat jaringan, dan barang lainnya yang perlu dicatat keberadaan serta kondisinya.
Pengelolaan inventaris aset tidak hanya berkaitan dengan pencatatan nama barang. Pengelolaan tersebut juga mencakup informasi tentang kategori aset, lokasi penyimpanan, jumlah barang, kondisi aset, status penggunaan, riwayat peminjaman, dan laporan. Apabila data aset tidak dikelola dengan baik, sekolah dapat mengalami kesulitan dalam mengetahui jumlah barang, lokasi barang, kondisi barang, dan riwayat penggunaan aset.
Dalam penelitian Annisa, Rahayuningsih, dan Anna (2023), dijelaskan bahwa permasalahan inventaris di sekolah sering terjadi karena data masih dicatat menggunakan buku atau Microsoft Excel, sehingga proses pencarian data menjadi lambat dan rawan kehilangan data. Permasalahan tersebut juga ditemukan pada SMPI REJIS, yaitu pencatatan aset masih dilakukan secara manual dan belum memiliki sistem yang mengelompokkan aset berdasarkan kategori, lokasi, serta kondisi barang.
Sistem inventaris aset berbasis web dapat membantu sekolah dalam mengelola data aset secara lebih terstruktur. Melalui sistem, Admin TU dapat memasukkan data aset, mengelompokkan aset berdasarkan kategori, mencatat lokasi aset, serta mencatat peminjaman dan pengembalian aset. Kepala Sekolah dapat melihat laporan inventaris dan status aset, sedangkan Staff dapat menggunakan fitur sesuai hak akses yang diberikan.
Selain pencatatan, sistem inventaris juga dapat mendukung proses monitoring aset. Monitoring diperlukan agar aset yang dipinjam atau dipindahkan tetap dapat ditelusuri. Mubarok dan Sutaji (2025) menunjukkan bahwa sistem inventaris aset berbasis web dapat meningkatkan efektivitas dan efisiensi pengelolaan aset serta mendukung transparansi dalam pemantauan peminjaman aset. Hal ini relevan dengan kebutuhan SMPI REJIS yang mengalami kendala ketika aset yang dipinjam tidak kembali ke tempat semula.

### 2.1.4	Disposisi Surat
Pengertian surat menurut undang-undang (UU) Nomor 43 Tahun 2009 tentang kearsipan disebut bahwa arsip adalah rekaman kegiatan atau pristiwa dalam berbagai bentuk dan media sesuai dengan perkembangan teknologi informasi dan komunikasi yang dibuat dan diterima oleh lembaga negara, pemerintahan daerah, lembaga pendidikan, perusahaan, organisasi politik, organisasi kemasyarakatan, dan perseorangan dalam pelaksanaan kehidupan bermasyarakat, berbangsa dan bernegara. Sedangkan pengertian kearsipan adalah hal-hal yang berkenan dengan arsip.(Tri et al., n.d.)
Terdapat 4 (empat) karakteristik dari dokumen yang perlu diketahui sebagai berikut:
1.	Autentik, dokumen mempunyai informasi-informasi fakta yang aktual dan faktual yang berisi informasi waktu dan tempat dokumen tersebut diterima, lalu terdapat tujuan aktivitas serta bukti kebijakan dan organisasi yang menyusun dokumen tersebut.
2.	Legal, dokumen adalah suatu upaya dokumentasi yang mampu mendukung tugas maupun kegiatan serta berguna untuk bukti resmi atas pengembalian kebijakan dan pelaksanaan kegiatan.
3.	Unik, setiap dokumen terdapat kronologi yang tidak tersusun secara serentak. Saat sebuah dokumen terduplikasi, maka dokumen tersebut sudah memiliki arti yang berbeda dalam hal pelaksanaan kegiatannya.
4.	Terpercaya, sebuah dokumen dapat berguna dan dipercaya sebagai bukti yang faktual dan sebagai bahan pendukung pelaksanaan suatu kegiatan.(Tri et al., n.d.)

Surat merupakan media komunikasi tertulis yang digunakan oleh instansi untuk menyampaikan informasi secara resmi. Dalam lingkungan sekolah, surat dapat berupa surat masuk dari pihak luar, surat undangan, surat pemberitahuan, surat permohonan, maupun dokumen administratif lainnya. Surat yang diterima sekolah perlu dicatat dan diarsipkan agar dapat ditemukan kembali ketika dibutuhkan.
Surat masuk merupakan surat yang diterima oleh suatu instansi dari pihak luar. Pada proses administrasi sekolah, surat masuk biasanya diterima oleh bagian Tata Usaha, kemudian dicatat dan diteruskan kepada pimpinan untuk mendapatkan arahan. Apabila pencatatan surat masih dilakukan secara manual dan arsip disimpan secara terpisah, maka proses pencarian kembali surat dapat membutuhkan waktu lebih lama.
Kata arsip dalam bahasa Indonesia diserap dalam bahasa belanda archief yang secara etimologi berasal dari bahasa yunani archium yang artinya peti tempat untuk menyimpan sesuatu. Pengertian arsip awalnya menunjukan tempat atau ruang penyimpanan arsip, namun saat ini pengertian arsip lebih cenderung sebagai catatan atau surat yang memiliki nilai kegunaan yang perlu untuk disimpan dengan sistem kearsipan. Sedangkan dalam bahasa latin, kata arsip disebut felum (bundle) yang berarti benang atau tali. Kala itu benang atau tali digunakan untuk mengikat kumpulan lembaran tulisan atau catatan agar ringkas dan mudah dicari jika diperlukan.(Tri et al., n.d.)
Arsip surat merupakan kumpulan dokumen surat yang disimpan sebagai bukti administrasi dan referensi kegiatan organisasi. Arsip surat memiliki nilai penting karena dapat digunakan untuk menelusuri riwayat komunikasi, dasar pengambilan keputusan, serta bukti pelaksanaan kegiatan. Pengarsipan yang tidak tertata dapat menimbulkan risiko kehilangan dokumen, duplikasi data, dan keterlambatan dalam menindaklanjuti informasi.
Disposisi surat merupakan proses pemberian instruksi atau arahan dari pimpinan kepada pihak tertentu untuk menindaklanjuti isi surat. Dalam sistem administrasi sekolah, disposisi dapat dilakukan oleh Kepala Sekolah atau Wakil Kepala Sekolah kepada Staff atau bagian yang berkaitan. Proses disposisi membutuhkan pencatatan yang jelas agar status surat dapat diketahui, apakah surat baru diterima, sudah didisposisikan, sedang diproses, atau telah selesai ditindaklanjuti.
Sistem disposisi surat berbasis web dapat membantu memperbaiki proses pengelolaan surat yang sebelumnya dilakukan secara manual. Melalui sistem, surat masuk dapat dicatat secara digital, disposisi dapat dikirimkan kepada pihak yang berwenang, dan status tindak lanjut dapat dipantau. Penelitian Siswaya dan Setiawan (2025) menunjukkan bahwa sistem pengarsipan dan disposisi surat berbasis web dirancang untuk mengatasi kendala pengelolaan surat masuk dan keluar serta memudahkan proses pengambilan keputusan dalam disposisi surat.
Pada SMPI REJIS, pengelolaan surat masih dilakukan secara manual dan arsip surat tersimpan secara terpisah. Kondisi tersebut menyebabkan pencarian surat dan pemantauan status tindak lanjut surat menjadi kurang optimal. Oleh karena itu, modul disposisi surat dalam sistem yang dirancang diperlukan untuk membantu proses pencatatan surat masuk, disposisi, monitoring status, dan pelaporan surat.

### 2.1.5	Bahasa Pemrograman dan Perangkat Lunak Pendukung
Bahasa pemrograman dan perangkat lunak pendukung merupakan komponen penting dalam proses pengembangan aplikasi. Dalam penelitian ini, sistem dikembangkan sebagai aplikasi berbasis web menggunakan beberapa teknologi, yaitu HTML, CSS, JavaScript, PHP, SQL, CodeIgniter 4, Bootstrap, dan MySQL. Setiap teknologi memiliki fungsi yang berbeda dalam membangun struktur, tampilan, logika, pengolahan data, dan penyimpanan data sistem.

#### A.	HTML
HTML atau HyperText Markup Language merupakan bahasa markup yang digunakan untuk membentuk struktur halaman web. HTML digunakan untuk menyusun elemen-elemen pada halaman, seperti teks, tabel, formulir, tombol, gambar, dan tautan. Dalam sistem inventaris aset dan disposisi surat, HTML digunakan untuk membangun halaman login, dashboard, formulir input aset, formulir surat masuk, halaman disposisi, halaman laporan, dan halaman detail data

#### B.	CSS
CSS atau Cascading Style Sheets merupakan bahasa yang digunakan untuk mengatur tampilan halaman web. CSS berfungsi mengatur warna, ukuran huruf, tata letak, jarak antar elemen, serta responsivitas tampilan. Penggunaan CSS diperlukan agar tampilan sistem lebih rapi, konsisten, dan mudah digunakan oleh pengguna

#### C.	JavaScript
JavaScript merupakan bahasa pemrograman yang berjalan pada sisi client dan digunakan untuk membuat halaman web menjadi lebih interaktif. JavaScript dapat digunakan untuk validasi formulir, konfirmasi hapus data, pencarian data secara dinamis, notifikasi, serta pengolahan interaksi pengguna pada halaman web. Dalam sistem yang akan dirancang, JavaScript membantu meningkatkan kenyamanan pengguna ketika mengelola data aset maupun surat

#### D.	PHP
PHP merupakan bahasa pemrograman sisi server yang banyak digunakan dalam pengembangan aplikasi web. PHP berfungsi memproses logika sistem, menghubungkan aplikasi dengan basis data, memvalidasi data, mengelola sesi pengguna, dan menghasilkan halaman yang ditampilkan kepada pengguna. Pada penelitian ini, PHP digunakan melalui framework CodeIgniter 4 sebagai teknologi utama pada sisi backend.

#### E.	SQL
SQL atau Structured Query Language merupakan bahasa yang digunakan untuk mengelola data pada basis data relasional. SQL digunakan untuk membuat tabel, menambah data, mengubah data, menghapus data, dan menampilkan data berdasarkan kriteria tertentu. Dalam sistem ini, SQL digunakan untuk mengelola data pengguna, aset, kategori, lokasi, peminjaman, surat masuk, disposisi, dan laporan

#### F.	CodeIgniter 4
CodeIgniter 4 merupakan framework PHP yang digunakan untuk membangun aplikasi web secara lebih terstruktur. CodeIgniter 4 mendukung pola MVC atau Model-View-Controller, yaitu pemisahan antara bagian pengolahan data, tampilan, dan logika kontrol aplikasi. Dengan pola ini, pengembangan sistem menjadi lebih teratur karena setiap bagian memiliki tanggung jawab yang jelas. Model digunakan untuk mengelola data dan berhubungan dengan database, View digunakan untuk menampilkan halaman kepada pengguna, sedangkan Controller digunakan untuk mengatur alur proses aplikasi

#### G.	Bootstrap
Bootstrap merupakan framework frontend yang digunakan untuk membuat tampilan web responsif dan konsisten. Bootstrap menyediakan komponen siap pakai seperti tombol, tabel, formulir, modal, navigasi, dan grid layout. Penggunaan Bootstrap membantu sistem agar dapat digunakan dengan tampilan yang lebih mudah dipahami oleh Admin TU, Kepala Sekolah, dan Staff.

#### H.	MySQL
MySQL merupakan sistem manajemen basis data relasional yang digunakan untuk menyimpan dan mengelola data aplikasi. MySQL menyimpan data dalam bentuk tabel yang saling berhubungan. Dalam sistem inventaris aset dan disposisi surat, MySQL digunakan untuk menyimpan data pengguna, aset, kategori, lokasi, peminjaman, pengembalian, surat masuk, disposisi, dan laporan.
Berdasarkan uraian tersebut, bahasa dan teknologi utama yang digunakan dalam penelitian ini adalah PHP, JavaScript, dan SQL sebagai bahasa pemrograman atau bahasa pengolah data, sedangkan HTML dan CSS digunakan sebagai bahasa pembentuk struktur dan tampilan web. CodeIgniter 4, Bootstrap, dan MySQL digunakan sebagai perangkat pendukung dalam proses pembangunan aplikasi.


### 2.1.6	Basis Data
Basis data atau database merupakan kumpulan data yang disimpan secara terstruktur dan dapat dikelola menggunakan sistem manajemen basis data. Dalam aplikasi berbasis web, database digunakan untuk menyimpan data pengguna, data aset, data kategori, data lokasi, data peminjaman, data surat masuk, data disposisi, serta data laporan. Tanpa database, sistem akan sulit menyimpan dan mengolah data secara berkelanjutan.
MySQL merupakan salah satu sistem manajemen basis data relasional yang banyak digunakan dalam pengembangan aplikasi web. MySQL menyimpan data dalam bentuk tabel yang saling berhubungan. Setiap tabel memiliki kolom dan baris yang merepresentasikan atribut dan data. Dalam sistem inventaris aset dan disposisi surat, MySQL dapat digunakan untuk menyimpan data secara terpusat sehingga lebih mudah dicari, diperbarui, dan dilaporkan.
SQL atau Structured Query Language merupakan bahasa yang digunakan untuk mengelola data dalam database relasional. SQL dapat digunakan untuk membuat tabel, menambahkan data, mengubah data, menghapus data, dan menampilkan data berdasarkan kriteria tertentu. Dalam sistem yang akan dirancang, SQL digunakan secara tidak langsung melalui model pada CodeIgniter 4 untuk mengelola data aset dan surat.
Dalam database relasional terdapat konsep primary key dan foreign key. Primary key merupakan atribut unik yang digunakan untuk membedakan setiap baris data dalam tabel. Misalnya, setiap data aset memiliki kode aset atau ID aset yang berbeda. Sementara itu, foreign key digunakan untuk menghubungkan satu tabel dengan tabel lain. Misalnya, tabel aset dapat memiliki hubungan dengan tabel kategori dan tabel lokasi melalui ID kategori dan ID lokasi.
Entity Relationship Diagram atau ERD merupakan alat bantu perancangan basis data yang digunakan untuk menggambarkan entitas, atribut, dan relasi antarentitas. ERD membantu pengembang memahami struktur data sebelum database dibuat. Dalam sistem inventaris aset dan disposisi surat, ERD digunakan untuk menggambarkan hubungan antara tabel pengguna, aset, kategori, lokasi, peminjaman, surat masuk, disposisi, dan laporan.
Adapun komponen utama dalam ERD adalah sebagai berikut :

#### A.	Entitas
Entitas merupakan objek atau bagian penting yang datanya perlu disimpan di dalam database. Entitas dapat berupa pengguna, aset, kategori, lokasi, peminjaman, surat masuk, dan disposisi. Dalam rancangan sistem ini, setiap entitas akan direpresentasikan menjadi tabel pada database.

#### B.	Atribut
Atribut merupakan karakteristik atau informasi yang dimiliki oleh suatu entitas. Contohnya, entitas aset memiliki atribut berupa kode aset, nama aset, kategori, lokasi, kondisi, status, dan tanggal pencatatan. Atribut digunakan untuk menjelaskan data yang akan disimpan pada setiap tabel.

#### C.	Relasi
Relasi merupakan hubungan antara satu entitas dengan entitas lain. Contohnya, entitas aset memiliki relasi dengan entitas kategori dan lokasi. Entitas surat masuk memiliki relasi dengan entitas disposisi. Relasi diperlukan agar data yang tersimpan di dalam database dapat saling terhubung dan tidak berdiri sendiri.

#### D.	Kardinalitas
Kardinalitas merupakan jumlah hubungan antara satu entitas dengan entitas lain. Kardinalitas dapat berupa satu ke satu, satu ke banyak, atau banyak ke banyak. Dalam sistem ini, satu kategori dapat memiliki banyak aset, satu lokasi dapat digunakan oleh banyak aset, dan satu surat masuk dapat memiliki satu atau lebih proses disposisi sesuai kebutuhan sistem.

#### E.	Primary Key dan Foreign Key
Primary key digunakan sebagai identitas unik pada setiap data, sedangkan foreign key digunakan sebagai penghubung antar tabel. Penggunaan primary key dan foreign key membantu menjaga integritas data serta mempermudah proses pencarian dan pelaporan.

Perancangan database yang baik sangat penting karena kualitas penyimpanan data akan memengaruhi kinerja sistem. Database yang dirancang secara terstruktur dapat mempermudah proses pencarian data, mengurangi duplikasi data, menjaga konsistensi data, dan mendukung pembuatan laporan yang akurat.

### 2.1.7	Unified Modeling Language (UML)
Unified Modeling Language atau UML merupakan bahasa pemodelan visual yang digunakan untuk menggambarkan sistem perangkat lunak. UML membantu pengembang dan pengguna memahami rancangan sistem sebelum aplikasi dibangun. Dengan UML, alur sistem, kebutuhan pengguna, interaksi antarobjek, dan arsitektur sistem dapat divisualisasikan secara lebih jelas.
Dalam penelitian perancangan sistem informasi, UML digunakan untuk mendokumentasikan kebutuhan dan rancangan aplikasi. Penggunaan UML juga membantu mengurangi kesalahan dalam tahap implementasi karena alur dan fungsi sistem telah digambarkan terlebih dahulu. Diagram UML yang digunakan dalam penelitian ini meliputi use case diagram, activity diagram, sequence diagram, dan deployment diagram.

#### A.	Use Case Diagram
Use case diagram digunakan untuk menggambarkan interaksi antara aktor dengan sistem. Aktor merupakan pihak yang menggunakan sistem atau berhubungan dengan sistem. Pada sistem inventaris aset dan disposisi surat, aktor yang terlibat adalah Admin TU, Kepala Sekolah, dan Staff.
Poin-poin penting dalam use case diagram adalah sebagai berikut :
1.	Aktor menggambarkan pengguna atau pihak yang berinteraksi dengan sistem.
2.	Use case menggambarkan fungsi atau layanan yang dapat dilakukan oleh sistem.
3.	Relasi menggambarkan hubungan antara aktor dengan fungsi sistem.
4.	Diagram ini membantu menjelaskan batasan fitur yang dapat diakses oleh setiap pengguna.
5.	Dalam sistem ini, use case diagram digunakan untuk menggambarkan fitur.

#### B.	Activity Diagram
Activity diagram digunakan untuk menggambarkan alur aktivitas atau proses bisnis dalam sistem. Diagram ini membantu menjelaskan tahapan proses dari awal sampai akhir. Pada penelitian ini, activity diagram digunakan untuk menggambarkan proses login, pengelolaan aset, peminjaman aset, pengembalian aset, pencatatan surat masuk, disposisi surat, dan pembuatan laporan.
Poin-poin penting dalam activity diagram adalah sebagai berikut :
1.	Initial node menggambarkan awal proses
2.	Activity menggambarkan aktivitas atau proses yang dilakukan
3.	Decision menggambarkan kondisi pilihan dalam alur proses
4.	Flow menggambarkan arah alur dari satu aktivitas ke aktivitas lain
5.	Final node menggambarkan akhir proses
6.	Diagram ini membantu memperjelas alur kerja sistem dari sudut pandang proses bisnis



#### C.	Sequence Diagram
Sequence diagram digunakan untuk menggambarkan urutan interaksi antarobjek berdasarkan waktu. Diagram ini menunjukkan bagaimana pengguna, antarmuka, controller, model, dan database saling berkomunikasi dalam menjalankan suatu proses. Misalnya, ketika Admin TU menambahkan data aset, sistem akan menerima input dari pengguna, controller memproses data, model menyimpan data ke database, kemudian sistem menampilkan hasil proses kepada pengguna.
Poin-poin penting dalam sequence diagram adalah sebagai berikut :
1.	Actor menggambarkan pengguna yang memulai proses.
2.	Lifeline menggambarkan objek yang terlibat dalam proses.
3.	Message menggambarkan komunikasi atau perintah antarobjek.
4.	Activation bar menggambarkan waktu aktif suatu objek ketika memproses pesan.
5.	Return message menggambarkan hasil yang dikembalikan setelah proses dilakukan.
6.	Diagram ini membantu menjelaskan urutan proses sistem secara detail berdasarkan waktu.

### 2.1.8	Antarmuka Pengguna (User Interface dan User Experience)
User Interface (UI) merupakan tampilan antarmuka yang digunakan pengguna untuk berinteraksi dengan sistem. UI mencakup elemen-elemen visual seperti warna, tombol, ikon, formulir, tabel, menu navigasi, dan tata letak halaman. Desain UI yang baik dapat memudahkan pengguna memahami fungsi sistem dan menjalankan proses kerja tanpa kebingungan.
User Experience (UX) merupakan pengalaman pengguna ketika menggunakan sistem. UX tidak hanya melihat tampilan, tetapi juga memperhatikan kemudahan penggunaan, kecepatan akses, kejelasan alur, kenyamanan, dan efektivitas sistem dalam membantu pekerjaan pengguna. Sistem yang memiliki tampilan bagus tetapi sulit digunakan belum dapat dikatakan memiliki UX yang baik.
Dalam sistem inventaris aset dan disposisi surat, UI dan UX memiliki peran penting karena pengguna sistem tidak hanya berasal dari latar belakang teknis. Admin TU, Kepala Sekolah, dan Staff membutuhkan tampilan yang mudah dipahami, alur yang sederhana, serta fitur yang tidak membingungkan. Oleh karena itu, desain antarmuka perlu dibuat berdasarkan kebutuhan pengguna dan proses kerja yang terjadi di sekolah.
Beberapa aspek yang perlu diperhatikan dalam perancangan UI dan UX adalah konsistensi tampilan, kejelasan menu, keterbacaan teks, validasi input, kemudahan pencarian data, serta kejelasan pesan ketika proses berhasil atau gagal. Misalnya, tombol tambah data, ubah data, hapus data, cetak laporan, dan lihat detail harus ditempatkan secara konsisten agar pengguna mudah mengenalinya.
UI dan UX juga berhubungan dengan efektivitas sistem. Apabila pengguna dapat menyelesaikan pekerjaan dengan langkah yang lebih sedikit, waktu yang lebih singkat, dan kesalahan yang lebih kecil, maka sistem dapat dikatakan mendukung pengalaman pengguna yang baik. Oleh karena itu, perancangan antarmuka pengguna perlu dipertimbangkan secara matang dalam proses pengembangan sistem berbasis web.

### 2.1.9	Metode Pengembangan Sistem Agile Scrum
Metode pengembangan sistem merupakan pendekatan yang digunakan dalam proses pembuatan perangkat lunak. Metode ini membantu pengembang mengatur tahapan kerja, mulai dari analisis kebutuhan, perancangan, implementasi, pengujian, hingga evaluasi. Pemilihan metode pengembangan harus disesuaikan dengan karakteristik sistem dan kebutuhan pengguna.
Dalam penelitian ini, metode pengembangan yang digunakan adalah Agile Scrum. Agile Scrum merupakan pendekatan pengembangan perangkat lunak yang bersifat iteratif, bertahap, dan fleksibel. Metode ini memungkinkan proses pengembangan dilakukan dalam beberapa siklus kerja yang disebut sprint. Setiap sprint menghasilkan bagian sistem yang dapat ditinjau, diuji, dan diperbaiki berdasarkan kebutuhan pengguna.
Agile Scrum sesuai digunakan dalam pengembangan sistem inventaris aset dan disposisi surat karena kebutuhan sistem dapat mengalami penyesuaian selama proses perancangan dan implementasi. Melalui Scrum, penulis dapat mengembangkan aplikasi secara bertahap, mulai dari fitur utama seperti login dan pengelolaan aset, kemudian dilanjutkan dengan peminjaman aset, surat masuk, disposisi surat, dan laporan.
Adapun tahapan Agile Scrum yang digunakan dalam penelitian ini adalah sebagai berikut :
1.	Product Backlog
Product backlog merupakan daftar kebutuhan sistem yang disusun berdasarkan hasil observasi, wawancara, dan studi pustaka. Daftar ini berisi seluruh fitur yang akan dikembangkan. Pada sistem ini, product backlog mencakup fitur login, data pengguna, data aset, kategori aset, lokasi aset, peminjaman aset, pengembalian aset, surat masuk, disposisi surat, laporan aset, dan laporan surat.
2.	Sprint Planning
Sprint planning merupakan tahap perencanaan sprint. Pada tahap ini, kebutuhan yang terdapat dalam product backlog dipilih berdasarkan prioritas. Fitur yang dianggap paling penting akan dikerjakan lebih awal agar sistem memiliki fungsi utama yang dapat diuji terlebih dahulu.
3.	Sprint Backlog
Sprint backlog merupakan daftar pekerjaan yang dipilih untuk dikerjakan dalam satu sprint. Setiap fitur dijabarkan menjadi tugas teknis, seperti membuat tabel database, merancang tampilan, membuat model, membuat controller, membuat validasi, mengatur hak akses, dan menguji fitur.
4.	Sprint Execution
Sprint execution merupakan tahap pelaksanaan pengembangan sistem. Pada tahap ini, penulis membangun sistem sesuai sprint backlog yang telah direncanakan. Pengembangan dilakukan menggunakan PHP, CodeIgniter 4, MySQL, HTML, CSS, JavaScript, SQL, dan Bootstrap.
5.	Daily Scrum
Daily scrum merupakan kegiatan evaluasi singkat untuk memantau perkembangan pekerjaan. Dalam penelitian ini, daily scrum diterapkan sebagai pemantauan berkala terhadap pekerjaan yang telah selesai, pekerjaan yang sedang dilakukan, serta kendala yang ditemukan selama proses pengembangan.
6.	Sprint Review
Sprint review merupakan tahap peninjauan hasil sprint. Fitur yang telah selesai dikembangkan ditinjau untuk memastikan kesesuaiannya dengan kebutuhan pengguna. Apabila terdapat kekurangan, maka hasil review digunakan sebagai dasar perbaikan pada sprint berikutnya.
7.	Sprint Retrospective
Sprint retrospective merupakan tahap evaluasi terhadap proses pengerjaan. Pada tahap ini, penulis mengevaluasi kendala, efektivitas kerja, dan perbaikan yang diperlukan agar proses pengembangan berikutnya menjadi lebih baik.
8.	Increment
Increment merupakan hasil dari sprint berupa fitur atau modul sistem yang sudah selesai dikembangkan dan dapat diuji. Increment dalam penelitian ini mencakup modul login, modul aset, modul peminjaman dan pengembalian aset, modul surat masuk, modul disposisi surat, modul laporan, serta pengaturan hak akses pengguna.
Dengan menggunakan Agile Scrum, proses pengembangan sistem dapat dilakukan secara bertahap dan tetap menyesuaikan kebutuhan pengguna. Metode ini juga membantu penulis dalam mengelola pekerjaan agar setiap modul dapat dirancang, dikembangkan, diuji, dan dievaluasi secara lebih terarah.

### 2.1.10	 Pengujian Sistem
Pengujian sistem merupakan proses untuk memastikan bahwa aplikasi yang dibangun berjalan sesuai dengan kebutuhan dan fungsi yang telah dirancang. Pengujian dilakukan untuk menemukan kesalahan, memastikan fungsi berjalan dengan benar, serta mengetahui apakah sistem dapat digunakan oleh pengguna.
Dalam penelitian ini, pengujian sistem tidak hanya difokuskan pada pengujian fungsional, tetapi juga mencakup pengujian keamanan dan pengujian kinerja. Pengujian tersebut diperlukan karena sistem menyimpan data administrasi sekolah, data aset, data surat, dan data pengguna yang perlu dikelola secara aman dan dapat diakses dengan kinerja yang baik.



#### A.	Blackbox Testing
Blackbox Testing merupakan metode pengujian yang berfokus pada fungsi sistem tanpa melihat struktur kode program. Penguji memberikan input pada sistem, kemudian memeriksa apakah output yang dihasilkan sesuai dengan hasil yang diharapkan. Metode ini digunakan untuk menguji fitur utama seperti login, tambah data aset, ubah data aset, hapus data aset, input surat masuk, disposisi surat, ubah status tindak lanjut, pencarian data, dan cetak laporan.
Poin-poin pengujian Blackbox Testing dalam sistem ini adalah sebagai berikut :
1.	Menguji validasi login berdasarkan username dan password.
2.	Menguji proses tambah, ubah, hapus, dan tampil data aset.
3.	Menguji proses peminjaman dan pengembalian aset.
4.	Menguji proses input surat masuk dan unggah dokumen surat.
5.	Menguji proses disposisi surat kepada pengguna yang dituju.
6.	Menguji perubahan status tindak lanjut surat.
7.	Menguji pencarian data dan pembuatan laporan.

#### B.	Pengujian Keamanan
Pengujian keamanan dilakukan untuk memastikan sistem memiliki mekanisme perlindungan terhadap akses yang tidak berwenang. Pada sistem inventaris aset dan disposisi surat, keamanan diperlukan karena terdapat data administrasi sekolah yang tidak boleh diakses oleh sembarang pengguna. Keamanan sistem dapat diterapkan melalui login, pembagian hak akses, validasi input, dan pengelolaan sesi pengguna.
Poin-poin pengujian keamanan dalam sistem ini adalah sebagai berikut :
1.	Menguji proses autentikasi pengguna melalui halaman login.
2.	Menguji pembatasan hak akses antara Admin TU, Kepala Sekolah, dan Staff.
3.	Menguji apakah pengguna tanpa login tidak dapat mengakses halaman dashboard.
4.	Menguji apakah pengguna dengan role tertentu tidak dapat membuka fitur di luar kewenangannya.
5.	Menguji validasi input untuk mengurangi risiko kesalahan data.
6.	Menguji pengelolaan sesi pengguna ketika logout atau sesi berakhir.

#### C.	Pengujian Kinerja
Pengujian kinerja dilakukan untuk mengetahui kemampuan sistem dalam memberikan respons terhadap proses yang dilakukan pengguna. Pengujian ini bertujuan memastikan sistem dapat berjalan stabil saat digunakan untuk memuat halaman, menyimpan data, mencari data, dan menghasilkan laporan.
Poin-poin pengujian kinerja dalam sistem ini adalah sebagai berikut :
1.	Menguji kecepatan akses halaman login dan dashboard.
2.	Menguji waktu pemrosesan saat menyimpan data aset.
3.	Menguji waktu pemrosesan saat menyimpan data surat masuk.
4.	Menguji kecepatan pencarian data aset dan surat.
5.	Menguji waktu pembuatan laporan inventaris dan laporan surat.
6.	Menguji kestabilan sistem ketika beberapa data ditampilkan dalam tabel.

#### D.	User Acceptance Testing
User Acceptance Testing atau uji penerimaan pengguna merupakan pengujian yang dilakukan untuk mengetahui apakah sistem dapat diterima oleh pengguna. Pada tahap ini, pengguna mencoba sistem dan memberikan penilaian apakah fitur yang tersedia sudah sesuai dengan kebutuhan. Uji penerimaan penting dilakukan karena keberhasilan sistem tidak hanya ditentukan oleh berjalannya fungsi, tetapi juga oleh kesesuaian sistem dengan proses kerja pengguna.
Dengan adanya pengujian fungsional, keamanan, kinerja, dan penerimaan pengguna, sistem diharapkan dapat berjalan sesuai kebutuhan dan layak digunakan dalam membantu administrasi SMPI REJIS.

## 2.2 Penelitian Terkait
Penelitian terkait digunakan untuk memperkuat dasar pengembangan sistem serta memberikan gambaran mengenai penelitian-penelitian sebelumnya yang memiliki kesamaan topik. Penelitian terkait pada bagian ini difokuskan pada sistem inventaris aset, pengelolaan surat, disposisi surat, serta aplikasi berbasis web yang relevan dengan penelitian ini.
Annisa, Rahayuningsih, dan Anna (2023) melakukan penelitian mengenai perancangan sistem informasi inventaris sarana dan prasarana sekolah berbasis web. Penelitian tersebut membahas permasalahan inventaris sekolah yang masih dikelola menggunakan buku atau Microsoft Excel sehingga menyebabkan pencarian data menjadi lambat dan berisiko kehilangan data. Sistem yang dirancang bertujuan untuk membantu sekolah mengelola data sarana dan prasarana secara lebih cepat, akurat, dan terpusat. Penelitian tersebut relevan dengan penelitian ini karena sama-sama membahas pengelolaan inventaris di lingkungan sekolah berbasis web.
Pranoto dan Sediyono (2021) melakukan penelitian mengenai perancangan sistem informasi inventaris barang berbasis web. Penelitian tersebut menunjukkan bahwa pencatatan inventaris secara manual menyebabkan kesulitan dalam pengelolaan data barang, pencarian data, dan pembuatan laporan. Sistem yang dikembangkan memiliki fitur pengelolaan data barang, barang masuk, barang keluar, perhitungan fisik, mutasi aset, dan laporan. Relevansi penelitian tersebut terletak pada penggunaan sistem berbasis web untuk mengubah proses inventaris manual menjadi digital dan lebih terstruktur.
Mubarok dan Sutaji (2025) melakukan penelitian mengenai perancangan dan implementasi sistem inventaris aset kantor berbasis web pada Dinas Kominfo Lamongan. Penelitian tersebut menjelaskan bahwa pencatatan aset secara manual dapat menghambat efektivitas dan efisiensi pelaporan aset. Sistem yang diusulkan dilengkapi fitur peminjaman aset untuk mempermudah identifikasi serta monitoring aset. Penelitian ini relevan karena sistem yang dirancang pada SMPI REJIS juga membutuhkan pengelolaan aset, lokasi aset, status aset, serta riwayat peminjaman.
Siswaya dan Setiawan (2025) melakukan penelitian mengenai perancangan sistem pengarsipan dan disposisi surat berbasis web menggunakan metode RAD. Penelitian tersebut bertujuan untuk mengatasi kendala pengelolaan surat masuk dan keluar serta proses disposisi yang membutuhkan keterlibatan bagian administrasi dan pimpinan. Sistem pengarsipan dan disposisi surat berbasis web membantu proses pencatatan, penyimpanan, dan tindak lanjut surat agar lebih teratur. Penelitian ini relevan dengan modul disposisi surat pada sistem yang dirancang karena sama-sama membahas digitalisasi pengelolaan surat dan disposisi.
Rohmawati (2025) melakukan penelitian mengenai sistem informasi e-disposisi surat berbasis web. Penelitian tersebut bertujuan untuk meningkatkan efisiensi pengelolaan surat, mempermudah akses, serta mempermudah pelacakan surat. Konsep e-disposisi dalam penelitian tersebut berkaitan dengan kebutuhan SMPI REJIS yang membutuhkan sistem untuk memantau status tindak lanjut surat. Dengan adanya sistem disposisi berbasis web, proses distribusi informasi dapat dilakukan secara lebih cepat dan terdokumentasi.
Londa, Wee, dan Radja (2022) melakukan penelitian mengenai implementasi sistem informasi monitoring disposisi surat masuk dan surat keluar berbasis website. Penelitian tersebut menekankan pentingnya monitoring dalam proses pengelolaan surat agar status surat dapat diketahui oleh pihak terkait. Penelitian ini relevan dengan rancangan sistem di SMPI REJIS karena proses disposisi surat tidak hanya membutuhkan pencatatan, tetapi juga membutuhkan pemantauan status agar tindak lanjut surat tidak terhambat.
Berdasarkan beberapa penelitian tersebut, dapat disimpulkan bahwa sistem informasi berbasis web telah banyak digunakan untuk menyelesaikan permasalahan pengelolaan inventaris dan administrasi surat. Penelitian terdahulu umumnya membahas inventaris aset dan pengelolaan surat secara terpisah. Perbedaan penelitian ini terletak pada integrasi dua proses administrasi, yaitu inventaris aset dan disposisi surat, ke dalam satu sistem berbasis web. Dengan adanya integrasi tersebut, sistem yang dirancang diharapkan mampu membantu SMPI REJIS dalam mengelola aset, peminjaman, surat masuk, disposisi, monitoring status, dan laporan secara lebih terpusat.

