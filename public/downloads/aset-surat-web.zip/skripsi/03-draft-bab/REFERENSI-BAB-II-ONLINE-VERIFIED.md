# REFERENSI BAB II ONLINE VERIFIED

## 1. Status

Referensi online berikut digunakan sebagai kandidat sumber BAB II. Referensi ini belum menjadi daftar pustaka final sampai format APA 7 diperiksa ulang dan dimasukkan ke Mendeley.

## 2. Referensi Valid dan Direkomendasikan

No | Subbab BAB II | Referensi | Jenis Sumber | Status | Kegunaan | Catatan
---|---|---|---|---|---|---
1 | 2.1.1 Sistem Informasi, 2.1.2 Website | Wahyuni, Muthmainnah, Permana, & Novalima (2025) | Artikel jurnal | VALID AWAL | Pengembangan Sistem Informasi Manajemen Sekolah Berbasis Web untuk Meningkatkan Efisiensi Administrasi Pendidikan | Kandidat awal untuk sistem informasi dan website.
2 | 2.1.3 Inventaris Aset, 2.2 Penelitian Terkait | Annisa, Rahayuningsih, & Anna (2023) | Jurnal ilmiah | VALID | Perancangan Sistem Informasi Inventaris Sarana dan Prasarana Sekolah Berbasis Web | Jurnal Infotek: Jurnal Informatika dan Teknologi, Vol. 6 No. 1, hlm. 60–70, DOI 10.29408/jit.v6i1.7356.
3 | 2.1.3 Inventaris Aset, 2.2 Penelitian Terkait | Pranoto & Sediyono (2021) | Jurnal ilmiah | VALID AWAL, HALAMAN PERLU CEK | Perancangan Sistem Informasi Inventaris Barang Berbasis Web | Jurnal JuTISI Vol. 7 No. 2; halaman perlu dikonfirmasi dari PDF atau sumber jurnal.
4 | 2.1.3 Inventaris Aset, 2.2 Penelitian Terkait | Mubarok & Sutaji (2025) | Jurnal ilmiah | VALID AWAL | Perancangan dan Implementasi Sistem Inventaris Aset Kantor Berbasis Web Dinas Kominfo Lamongan | Jurnal Bianglala Informatika Vol. 13 No. 1, hlm. 27–33; DOI halaman resmi jurnal BSI: 10.31294/bianglala.v13i1.12004. Terdapat perbedaan metadata DOI antara halaman jurnal resmi dan Garuda. Untuk drafting, gunakan DOI dari halaman resmi jurnal BSI dan verifikasi ulang saat input ke Mendeley.
5 | 2.1.4 Surat, 2.1.5 Disposisi Surat, 2.2 Penelitian Terkait | Siswaya & Setiawan (2025) | Jurnal ilmiah | VALID | Perancangan Sistem Pengarsipan dan Disposisi Surat Berbasis Web dengan Menggunakan Metode RAD | Jurnal Insect: Jurnal Teknik Informatika Vol. 11 No. 1, hlm. 127–137.
6 | 2.1.5 Disposisi Surat, 2.2 Penelitian Terkait | Rohmawati & Yulianingsih (2025) | Jurnal ilmiah | VALID | Sistem Informasi E-Disposisi Surat Berbasis Web pada Kantor Camat Tungkal Jaya Kabupaten Musi Banyuasin | Jurnal Indonesia: Manajemen Informatika dan Komunikasi Vol. 6 No. 2, hlm. 985–997, DOI 10.63447/jimik.v6i2.1372.
7 | 2.1.5 Disposisi Surat, 2.2 Penelitian Terkait | Londa, Wee, & Radja (2022) | Jurnal ilmiah | VALID | Implementasi Sistem Informasi Monitoring Disposisi Surat Masuk dan Surat Keluar Berbasis Website | Jurnal MATRIK Vol. 21 No. 2, hlm. 379–388, DOI 10.30812/matrik.v21i2.1443.
8 | 2.1.4 Surat | KBBI | Sumber istilah resmi | VALID SEBAGAI SUMBER ISTILAH | Definisi surat | Sumber istilah bahasa Indonesia resmi.
9 | 2.1.4 Surat | Undang-Undang Nomor 43 Tahun 2009 tentang Kearsipan | Sumber resmi | VALID SEBAGAI SUMBER RESMI | Arsip dan kearsipan | Sumber regulasi resmi untuk arsip dan kearsipan.
10 | 2.1.7 PHP | PHP Documentation | Dokumentasi resmi | VALID SEBAGAI SUMBER RESMI | PHP sebagai bahasa scripting untuk pengembangan web | Sumber resmi dokumentasi PHP.
11 | 2.1.8 CodeIgniter | CodeIgniter 4 User Guide | Dokumentasi resmi | VALID SEBAGAI SUMBER RESMI | CodeIgniter sebagai PHP full-stack web framework | Sumber resmi dokumentasi CodeIgniter 4.
12 | 2.1.6 Basis Data MySQL | MySQL Reference Manual | Dokumentasi resmi | VALID SEBAGAI SUMBER RESMI | MySQL sebagai sistem manajemen basis data relasional | Sumber resmi dokumentasi MySQL.
13 | 2.1.9 UML | OMG UML 2.5.1 | Dokumentasi resmi | VALID SEBAGAI SUMBER RESMI | UML sebagai bahasa grafis untuk visualisasi dan dokumentasi sistem | Sumber resmi OMG untuk UML.
14 | 2.1.10 ERD | IBM Entity-Relationship Model Documentation | Dokumentasi resmi | VALID SEBAGAI SUMBER RESMI PENDUKUNG | Entity Relationship Model dan logical database design | Sumber pendukung untuk ERD.
15 | 2.1.12 Agile Scrum | Scrum Guide 2020 | Dokumentasi resmi | VALID SEBAGAI SUMBER RESMI | Scrum, product backlog, sprint backlog, increment | Sumber resmi Scrum.
16 | 2.1.13 Black-Box Testing | ISTQB Glossary | Dokumentasi resmi | VALID SEBAGAI SUMBER RESMI | Black-box test technique | Sumber resmi ISTQB.
17 | 2.1.11 LRS | Wiratama (2024) | Jurnal ilmiah | VALID AWAL, SIAP DRAFT DENGAN CATATAN | Logical Record Structure menggambarkan struktur record dari entitas berdasarkan hasil relasi antarentitas pada ERD | Artikel IJIS 2024; LRS dipakai sebagai teori pendukung perancangan basis data.
18 | 2.1.11 LRS | JSAI (2024) | Jurnal ilmiah | VALID AWAL, SIAP DRAFT DENGAN CATATAN | Penggunaan Logical Record Structure dalam perancangan sistem informasi akademik | Artikel JSAI 2024; LRS dipakai sebagai teori pendukung perancangan basis data akademik.

## 3. Referensi Lemah atau Jangan Dipakai Dulu

1. Sistem, n.d.
2. Literasi & Indonesia, n.d.
3. PENGANTAR JARINGAN KOMPUTER, n.d.
4. I, 2015
5. Tri et al., n.d.
6. Jogiyanto 1995
7. Subtari atau Sutabri 2005
8. Gordon 1995

Alasan:
metadata tidak jelas, terlalu lama, atau belum dapat diverifikasi sebagai sumber ilmiah yang layak untuk BAB II final.

## 4. Catatan Khusus LRS

Subbab LRS telah memperoleh penguat awal dari artikel IJIS Wiratama 2024 dan JSAI 2024. LRS dapat dimasukkan ke BAB II sebagai teori pendukung perancangan basis data, tetapi tetap diberi catatan bahwa sumbernya adalah jurnal aplikasi/perancangan sistem, bukan buku teori utama. Jika nanti ditemukan buku atau sumber akademik yang lebih kuat tentang LRS, sumber tersebut dapat ditambahkan.
