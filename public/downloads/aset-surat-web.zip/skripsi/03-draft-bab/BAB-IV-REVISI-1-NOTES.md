# BAB IV REVISI 1 NOTES

Tanggal dibuat: 2026-07-05

## 1. Status Draft

`BAB-IV-REVISI-1.md` adalah draft revisi 1 BAB IV, disusun mengikuti struktur resmi hasil koreksi outline (IMPLEMENTASI DAN PENGUJIAN SOFTWARE: 4.1 Desain dengan 4.1.1 Database/4.1.2 Software Architecture/4.1.3 User Interface, 4.2 Code Generation, 4.3 Testing, 4.4 Support dengan 4.4.1 Publikasi Software/4.4.2 Spesifikasi Hardware dan Software). Draft ini belum final dan masih memuat beberapa marker untuk bagian yang belum memiliki bukti lengkap.

## 2. File Yang Digunakan

1. `OUTLINE-CORRECTION-BAB-III-IV.md`, `BAB-III-IV-STRUCTURE-FINAL-ARAH.md`, `BAB-IV-DRAFT-PLAN.md` — dasar struktur dan penempatan artefak.
2. `DATABASE_ERD_AUDIT.md` dan `skripsi/04-diagram-dan-gambar/LRS_DRAFT.md` — dasar 4.1.1 Database (ERD naratif, LRS 9 tabel bisnis, relasi antar tabel).
3. `skripsi/04-diagram-dan-gambar/DIAGRAM_INDEX.md` dan `DIAGRAM_QUALITY_REVIEW.md` — dasar 4.1.2 Software Architecture (status diagram Use Case, Activity, Sequence, Arsitektur MVC, Deployment, Class).
4. `APLIKASI_FEATURE_AUDIT.md` — dasar uraian arsitektur MVC dan Code Generation naratif.
5. `app/Controllers/AuthController.php` dan `app/Filters/RoleFilter.php` — dibaca langsung pada sesi ini untuk kutipan kode 4.2 Code Generation.
6. `skripsi/04-diagram-dan-gambar/SCREENSHOT_REQUIREMENTS.md` dan `APPLICATION_VERIFICATION.md` — dasar tabel status screenshot 4.1.3 User Interface.
7. `skripsi/03-draft-bab/BLACKBOX_TEST_SCENARIOS.md` — dasar tabel black-box testing dan pengujian keamanan dasar 4.3 (42 skenario, seluruhnya valid per pembaruan 2026-07-04).
8. `skripsi/08-log-kerja/BAB_IV_EVIDENCE_READINESS.md` — dasar catatan risiko dan kesiapan bukti.
9. `SCRUM_MAPPING_AUDIT.md` — dasar narasi Agile Scrum pada 4.1 Desain (ditulis sebagai kerangka dokumentasi berbasis fitur, bukan fakta historis ceremony Scrum).

## 3. Struktur Yang Dipakai

```text
BAB IV
IMPLEMENTASI DAN PENGUJIAN SOFTWARE

4.1. Desain
4.1.1. Database
4.1.2. Software Architecture
4.1.3. User Interface
4.2. Code Generation
4.3. Testing
4.4. Support
4.4.1. Publikasi Software
4.4.2. Spesifikasi Hardware dan Software
```

Struktur ini sesuai `BAB-III-IV-STRUCTURE-FINAL-ARAH.md`. Class Diagram dan Deployment Diagram tidak dijadikan subbab utama; keduanya hanya disebut sebagai referensi/gambar pendukung opsional pada 4.1.2 dan 4.4.2.

## 4. Marker Yang Masih Ada

Marker | Jumlah | Lokasi
---|---|---
`[PERLU DATA]` | 5 | 4.4.1 Publikasi Software (rencana deployment server); 4.4.2 Spesifikasi Hardware dan Software (versi Windows, versi browser, versi editor, spesifikasi hardware — beberapa kemunculan dalam satu daftar)
`[PERLU CEK SCREENSHOT]` | 5 | 4.1.3 User Interface — halaman Manajemen Pengguna, daftar Transaksi Aset, form tambah Surat Masuk, form tambah Surat Keluar, dan tampilan cetak/print Laporan
`[PERLU DATA HASIL PENGUJIAN]` | 7 | 4.3 Testing bagian Pengujian Kinerja Dasar — kolom Catatan pada 6 baris tabel ditambah 1 kemunculan pada kalimat penutup subbab
`[PERLU CEK BUKTI KODE]` | 1 | 4.2 Code Generation — potongan kode modul aset, transaksi, surat, laporan, dan backup belum dikutip langsung
`[PERLU CEK BUKTI]` | 0 | -
`[BELUM DAPAT DIPASTIKAN]` | 0 | -

Total marker BAB IV: 18.

## 5. Bukti Diagram Yang Tersedia Atau Tidak

Tersedia (ADA), sudah berupa file source Mermaid dan output SVG di `skripsi/04-diagram-dan-gambar/`:

1. Entity Relationship Diagram (`erd-final.svg`).
2. Use Case Diagram (`use-case-diagram.svg`).
3. Activity Diagram Login, Inventaris Aset, Transaksi Aset, Surat Masuk dan Disposisi, Surat Keluar (5 file SVG).
4. Sequence Diagram Login, Transaksi Aset, Disposisi Surat (3 file SVG).
5. Arsitektur MVC Sistem (`arsitektur-mvc.svg`).
6. Deployment Diagram (`deployment-diagram.svg`) — tersedia sebagai gambar pendukung opsional.
7. LRS (`LRS_DRAFT.md`, berbentuk tabel, bukan gambar).

Tidak/belum relevan sebagai gambar utama:

1. Class Diagram (`class-diagram.svg`) — tersedia tetapi sengaja tidak dipakai sebagai gambar/subbab utama sesuai batasan outline.

Catatan kualitas: `DIAGRAM_QUALITY_REVIEW.md` mencatat Use Case Diagram, ERD, Class Diagram, dan sebagian Activity Diagram panjang memerlukan perhatian layout (landscape/lampiran) saat masuk DOCX.

## 6. Bukti Screenshot Yang Tersedia Atau Tidak

Tersedia (ADA): login, dashboard (versi final tanpa ERD + sidebar admin), daftar/form tambah/form edit/detail inventaris aset, detail transaksi aset, daftar/detail surat masuk beserta lampiran, daftar/form/detail disposisi, daftar/detail surat keluar, halaman laporan, halaman backup — total 19 berkas PNG dan 1 berkas PDF bukti transaksi (`19-cetak-pdf-transaksi.pdf`).

Belum tersedia (`[PERLU CEK SCREENSHOT]`): halaman manajemen pengguna, daftar transaksi aset (list, bukan detail), form tambah surat masuk, form tambah surat keluar, tampilan cetak/print laporan.

## 7. Bukti Pengujian Yang Tersedia Atau Tidak

Tersedia: 42 skenario black-box testing dengan status valid seluruhnya (`BLACKBOX_TEST_SCENARIOS.md`, pembaruan 2026-07-04), mencakup login, akses route, dashboard, pengguna, aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, backup, role access, dan ERD (sebagai route dokumentasi). Pengujian keamanan dasar sudah dapat diturunkan dari 6 skenario terkait autentikasi, sesi, otorisasi role, dan validasi input/upload.

Belum tersedia: pengukuran waktu respons formal untuk pengujian kinerja dasar. Bukti yang ada baru berupa konfirmasi keberhasilan respons (HTTP 200), bukan angka waktu respons dalam milidetik/detik.

## 8. Bagian Yang Perlu Review

1. Penomoran caption gambar (Gambar IV.1 sampai IV.27) pada draft ini bersifat sementara dan perlu disesuaikan kembali saat penyusunan DOCX final, terutama jika ada gambar yang dipindah ke lampiran karena ukurannya besar.
2. Tabel black-box testing yang memuat 42 baris perlu direview apakah akan ditampilkan penuh di badan BAB IV atau sebagian dipindah ke lampiran.
3. Uraian Code Generation untuk modul selain autentikasi dan role filter masih naratif; perlu dilengkapi dengan potongan kode terpilih dari `AssetsController.php`, `AssetTransactionsController.php`, `IncomingLettersController.php`, `DispositionsController.php`, `OutgoingLettersController.php`, `ReportsController.php`, dan `BackupController.php` pada revisi berikutnya.
4. Bagian Pengujian Kinerja Dasar sengaja tidak diisi angka waktu respons karena belum ada data pengukuran; perlu diputuskan apakah pengukuran waktu respons akan dilakukan pada tahap berikutnya atau bagian ini tetap bersifat kualitatif (berhasil/tidak berhasil merespons).
5. Redaksi 4.4.1 Publikasi Software dan 4.4.2 Spesifikasi Hardware dan Software perlu direview agar konsisten dengan BAB I dan BAB III terkait batasan lingkungan lokal.

## 9. Risiko Overclaim Yang Dihindari

1. Tidak menuliskan aplikasi sudah online, produksi, atau digunakan resmi oleh SMPI REJIS — 4.4.1 secara eksplisit membatasi publikasi pada lingkungan lokal/Laragon.
2. Tidak menuliskan penetration testing, load testing, stress testing, atau benchmark server produksi — 4.3 secara eksplisit menyatakan pengujian keamanan dan kinerja bersifat dasar.
3. Tidak mengklaim sistem aman dari seluruh jenis serangan — catatan pada Pengujian Keamanan Dasar menyebutkan pengujian kerentanan tingkat lanjut berada di luar ruang lingkup.
4. Tidak mengarang hasil pengujian kinerja — kolom hasil pengamatan kinerja diberi marker `[PERLU DATA HASIL PENGUJIAN]`, bukan angka yang dikarang.
5. Tidak menampilkan credential, password, token, API key, session, atau cookie pada potongan kode maupun uraian screenshot.
6. Tidak menuliskan Daily Scrum, Sprint Review, Sprint Retrospective, Scrum Master, Product Owner, atau tanggal sprint historis pada narasi Agile Scrum di 4.1 Desain.
7. Tidak menjadikan Class Diagram atau Deployment Diagram sebagai subbab utama.

## 10. Rekomendasi Berikutnya

BAB IV revisi 1 sudah dapat direview oleh user dan Maestro. Sebelum menjadi naskah final, perlu dilengkapi: screenshot 5 halaman yang masih kurang, potongan kode tambahan untuk modul non-autentikasi, dan pengukuran waktu respons untuk pengujian kinerja dasar. Setelah review, langkah berikutnya adalah menyinkronkan hasil review BAB IV dengan `BAB-I-SAMPAI-IV-DRAFT-REVIEW-CHECK.md`.
