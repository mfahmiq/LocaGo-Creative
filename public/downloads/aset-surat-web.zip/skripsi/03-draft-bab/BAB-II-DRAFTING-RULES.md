# BAB II DRAFTING RULES

## 1. Struktur Final BAB II

BAB II
LANDASAN TEORI

2.1. Tinjauan Pustaka
     2.1.1. Sistem Informasi
     2.1.2. Website
     2.1.3. Inventaris Aset
     2.1.4. Surat
     2.1.5. Disposisi Surat
     2.1.6. Basis Data MySQL
     2.1.7. PHP
     2.1.8. CodeIgniter
     2.1.9. UML
     2.1.10. ERD
     2.1.11. LRS
     2.1.12. Agile Scrum
     2.1.13. Black-Box Testing

2.2. Penelitian Terkait

## 2. Aturan Sumber

1. Jangan membuat sitasi palsu.
2. Jangan membuat daftar pustaka palsu.
3. Jangan memakai Blogspot, Wordpress, Wikipedia, atau sumber tidak ilmiah.
4. Jangan memakai sumber `n.d.` jika metadata tidak jelas.
5. Jangan memakai jurnal yang belum diverifikasi.
6. Jangan mencantumkan DOI, URL, volume, nomor, halaman, atau penerbit jika belum ada sumber.
7. Gunakan APA 7 dan Mendeley pada tahap final.

## 3. Aturan Isi

1. BAB II berisi teori dan penelitian terkait, bukan hasil implementasi aplikasi.
2. Gambar diagram aktual sistem tidak diletakkan di BAB II.
3. Detail arsitektur aplikasi, UI/UX, screenshot, backlog, sprint mapping, dan hasil pengujian diletakkan di BAB III atau BAB IV.
4. HTML, CSS, JavaScript, SQL, dan Bootstrap tidak menjadi subbab utama BAB II.
5. UI/UX tidak menjadi subbab utama BAB II.
6. UAT tidak dimasukkan kecuali ada bukti pelaksanaan.
7. Pengujian keamanan dasar dan kinerja dasar boleh disebut sebagai pengujian pendukung, tetapi detailnya di BAB IV.

## 4. Aturan Role

Role final aplikasi adalah:

1. admin
2. operator
3. pimpinan

Istilah Admin TU, Kepala Sekolah, dan Staff hanya boleh digunakan sebagai padanan operasional sekolah jika diperlukan, bukan sebagai role teknis final aplikasi.

## 5. Aturan Agile Scrum

Agile Scrum ditulis sebagai model pengembangan dan pemetaan kerja.
Jangan menulis Daily Scrum, Sprint Review, Sprint Retrospective, Scrum Master, Product Owner, atau tanggal sprint sebagai fakta historis jika tidak ada bukti.

## 6. Aturan Bahasa

1. Gunakan bahasa Indonesia ilmiah, baku, dan mudah dipahami.
2. Hindari singkatan tidak resmi.
3. Hindari garis miring untuk arti “atau”.
4. Gunakan istilah asing secara konsisten dan beri tanda miring jika diperlukan.
5. Jangan memperpanjang pembahasan hanya untuk menambah halaman.
6. Perbaiki tanda baca, ejaan, dan kata tidak baku.
