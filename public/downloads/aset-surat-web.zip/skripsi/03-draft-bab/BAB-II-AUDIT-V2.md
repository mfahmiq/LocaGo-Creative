# BAB II Audit V2

## Status Audit

Audit ini dibuat berdasarkan naskah BAB II lama asli pada `skripsi/03-draft-bab/BAB-II-USER-DRAFT-LAMA.md`, bukan berdasarkan placeholder sebelumnya. File lama berisi struktur BAB II lengkap dengan bagian Tinjauan Pustaka dan Penelitian Terkait.

Audit ini belum menyusun BAB II final. Semua keputusan di bawah digunakan sebagai dasar revisi setelah referensi diverifikasi.

## 1. Ringkasan Kualitas Umum BAB II Lama Asli

Naskah BAB II lama asli memiliki beberapa bagian yang masih dapat menjadi bahan awal, terutama pembahasan mengenai sistem informasi, website, inventaris aset, disposisi surat, PHP, CodeIgniter, MySQL, basis data, UML, Agile Scrum, dan black-box testing. Namun, naskah belum siap digunakan sebagai BAB II final karena:

1. Struktur subbab belum sesuai dengan struktur final yang sudah disetujui.
2. Pembahasan terlalu melebar ke WWW, internet, web browser, HTML, CSS, JavaScript, SQL, Bootstrap, UI/UX, dan UAT.
3. Belum ada subbab LRS, padahal LRS wajib masuk struktur BAB II final.
4. Subbab Surat dan Disposisi Surat belum dipisahkan secara jelas.
5. Role pengguna masih memakai istilah operasional sekolah seperti Admin TU, Kepala Sekolah, dan Staff tanpa penyelarasan ke role aplikasi final yaitu admin, operator, dan pimpinan.
6. Banyak sumber belum jelas, lama, atau belum memiliki metadata yang dapat diverifikasi.
7. Ada risiko paragraf bersifat salinan definisi umum dari sumber web karena gaya bahasa, sitasi `n.d.`, dan detail historis yang tidak relevan.
8. Gaya bahasa masih perlu dibuat lebih akademik, ringkas, dan konsisten.

Kesimpulan: BAB II lama asli dapat dipakai sebagai bahan mentah, tetapi perlu ditulis ulang secara besar-besaran dan harus menunggu verifikasi referensi sebelum menjadi draft final.

## 2. Perbandingan Struktur Lama Dengan Struktur Final

| Struktur BAB II Lama Asli | Struktur BAB II Final Yang Disetujui | Status |
|---|---|---|
| 2.1.1 Konsep Dasar Sistem dan Informasi | 2.1.1 Sistem Informasi | Perlu digabung dan dipangkas |
| 2.1.2 Website, WWW, Internet, dan Web Browser | 2.1.2 Website | Perlu dipangkas besar |
| 2.1.3 Inventaris Aset | 2.1.3 Inventaris Aset | Dapat dipakai dengan revisi |
| 2.1.4 Disposisi Surat | 2.1.4 Surat dan 2.1.5 Disposisi Surat | Perlu dipecah |
| 2.1.5 Bahasa Pemrograman dan Perangkat Lunak Pendukung | 2.1.6 Basis Data MySQL, 2.1.7 PHP, 2.1.8 CodeIgniter | Perlu dipecah dan sebagian dihapus |
| HTML, CSS, JavaScript, SQL, Bootstrap | Bukan subbab utama | Hapus sebagai subbab utama |
| 2.1.6 Basis Data | 2.1.6 Basis Data MySQL, 2.1.10 ERD, 2.1.11 LRS | Perlu restrukturisasi |
| 2.1.7 UML | 2.1.9 UML | Dapat dipakai dengan revisi |
| Use Case, Activity, Sequence | Bagian dari UML dan kebutuhan diagram | Dapat diringkas |
| 2.1.8 UI/UX | Tidak menjadi subbab utama BAB II | Pindahkan bila diperlukan ke BAB III |
| 2.1.9 Agile Scrum | 2.1.12 Agile Scrum | Dapat dipakai dengan revisi |
| 2.1.10 Pengujian Sistem | 2.1.13 Black-Box Testing | Perlu difokuskan |
| UAT | Tidak dipakai tanpa bukti | Hapus |
| 2.2 Penelitian Terkait | 2.2 Penelitian Terkait | Perlu verifikasi sumber |

## 3. Tabel Keputusan Per Subbab

| No | Subbab Lama | Keputusan | Alasan | Aksi Revisi |
|---:|---|---|---|---|
| 1 | 2.1.1 Konsep Dasar Sistem dan Informasi | PAKAI DENGAN REVISI | Relevan, tetapi tidak boleh menjadi subbab `Sistem` terpisah dan sumber masih perlu dicek. | Tulis ulang menjadi `2.1.1 Sistem Informasi`; hapus definisi sistem yang terlalu umum; tandai [PERLU SITASI]. |
| 2 | 2.1.2 Website, WWW, Internet, dan Web Browser | PAKAI DENGAN REVISI | Website relevan, tetapi WWW, internet, browser, dan sejarah browser terlalu melebar. | Pertahankan konsep website secara ringkas; hapus sejarah browser dan pembahasan jaringan yang tidak langsung terkait. |
| 3 | A. World Wide Web (WWW) | HAPUS | Tidak menjadi subbab final dan terlalu umum untuk judul skripsi. | Jika perlu, satukan satu kalimat dalam definisi website. |
| 4 | B. Internet | HAPUS | Terlalu luas dan tidak menjadi struktur final. | Hapus dari subbab utama; tidak perlu dibahas panjang. |
| 5 | C. Web Browser | HAPUS | Detail Mozilla Firefox dan Google Chrome tidak relevan untuk landasan teori utama. | Hapus pembahasan historis browser. |
| 6 | D. Arsitektur Client-Server pada Aplikasi Web | PINDAHKAN | Lebih cocok sebagai penjelasan arsitektur implementasi. | Pindahkan ke BAB III/BAB IV bila dibutuhkan sebagai arsitektur MVC/client-server. |
| 7 | 2.1.3 Inventaris Aset | PAKAI DENGAN REVISI | Sangat relevan dengan judul dan kebutuhan aplikasi. | Tulis ulang dengan fokus pencatatan, pengelolaan, lokasi, peminjaman, dan pelaporan aset; tandai [PERLU SITASI]. |
| 8 | 2.1.4 Disposisi Surat | PAKAI DENGAN REVISI | Relevan, tetapi masih mencampur konsep surat, arsip, kearsipan, dan disposisi. | Pecah menjadi `2.1.4 Surat` dan `2.1.5 Disposisi Surat`; pangkas bagian etimologi/arsip yang tidak perlu. |
| 9 | 2.1.5 Bahasa Pemrograman dan Perangkat Lunak Pendukung | HAPUS | Umbrella subbab tidak sesuai struktur final. | Pecah hanya ke konsep yang final: PHP, CodeIgniter, dan Basis Data MySQL. |
| 10 | A. HTML | HAPUS | HTML tidak menjadi subbab utama BAB II final. | Sebutkan singkat sebagai teknologi tampilan jika benar-benar diperlukan. |
| 11 | B. CSS | HAPUS | CSS tidak menjadi subbab utama BAB II final. | Tidak perlu dijadikan landasan teori utama. |
| 12 | C. JavaScript | HAPUS | JavaScript tidak menjadi subbab utama BAB II final. | Tidak perlu dijadikan landasan teori utama. |
| 13 | D. PHP | PAKAI DENGAN REVISI | PHP relevan sebagai bahasa utama aplikasi. | Jadikan `2.1.7 PHP`; cek ulang sumber dan versi/konteks. |
| 14 | E. SQL | HAPUS | SQL tidak menjadi subbab utama sesuai keputusan user. | Masukkan secara singkat dalam pembahasan basis data bila perlu. |
| 15 | F. CodeIgniter 4 | PAKAI DENGAN REVISI | Relevan karena aplikasi memakai CodeIgniter 4. | Jadikan `2.1.8 CodeIgniter`; jelaskan framework MVC secara ringkas. |
| 16 | G. Bootstrap | HAPUS | Bootstrap tidak menjadi subbab utama dan bukan fokus penelitian. | Sebutkan sebagai pendukung tampilan hanya bila perlu. |
| 17 | H. MySQL | PAKAI DENGAN REVISI | Relevan sebagai basis data aplikasi. | Gabungkan ke `2.1.6 Basis Data MySQL`. |
| 18 | 2.1.6 Basis Data | PAKAI DENGAN REVISI | Relevan, tetapi perlu disesuaikan menjadi Basis Data MySQL dan memisahkan ERD/LRS. | Tulis ulang `2.1.6 Basis Data MySQL`; pindahkan komponen ERD ke `2.1.10 ERD`. |
| 19 | Entitas, Atribut, Relasi, Kardinalitas, Primary Key, Foreign Key | PAKAI DENGAN REVISI | Berguna untuk ERD dan database, tetapi perlu sumber yang jelas. | Ringkas di subbab ERD atau Basis Data MySQL; tandai [PERLU SITASI]. |
| 20 | 2.1.7 UML | PAKAI DENGAN REVISI | Relevan untuk diagram perancangan. | Jadikan `2.1.9 UML`; jelaskan jenis diagram yang dipakai saja. |
| 21 | Use Case Diagram | PAKAI DENGAN REVISI | Digunakan untuk kebutuhan diagram. | Ringkas sebagai bagian UML dan kaitkan dengan aktor admin, operator, pimpinan. |
| 22 | Activity Diagram | PAKAI DENGAN REVISI | Digunakan untuk alur proses aplikasi. | Ringkas dan sesuaikan dengan modul aset, surat, disposisi. |
| 23 | Sequence Diagram | PAKAI DENGAN REVISI | Dapat mendukung alur interaksi sistem. | Gunakan hanya jika diagram final tersedia/ditetapkan. |
| 24 | 2.1.8 UI/UX | PINDAHKAN | Tidak menjadi subbab utama BAB II final. | Pindahkan ke BAB III bagian rancangan antarmuka jika diperlukan. |
| 25 | 2.1.9 Agile Scrum | PAKAI DENGAN REVISI | Sesuai metode pengembangan, tetapi klaim ceremony lengkap harus dihindari. | Jadikan `2.1.12 Agile Scrum`; tulis sebagai model dan pemetaan kerja, bukan bukti historis ceremony lengkap. |
| 26 | 2.1.10 Pengujian Sistem | PAKAI DENGAN REVISI | Relevan, tetapi struktur final fokus ke black-box testing. | Jadikan `2.1.13 Black-Box Testing`; keamanan dan kinerja hanya sebagai pengujian pendukung bila dibahas di BAB IV. |
| 27 | A. Blackbox Testing | PAKAI DENGAN REVISI | Pengujian utama yang disepakati. | Gunakan istilah `Black-Box Testing`; cek referensi. |
| 28 | B. Pengujian Keamanan | PINDAHKAN | Pengujian keamanan dasar boleh ada sebagai pendukung, bukan subbab utama BAB II. | Pindahkan ke BAB IV bagian pengujian tambahan bila ada bukti. |
| 29 | C. Pengujian Kinerja | PINDAHKAN | Pengujian kinerja dasar boleh ada sebagai pendukung, bukan subbab utama BAB II. | Pindahkan ke BAB IV bila ada data pengujian. |
| 30 | D. User Acceptance Testing | HAPUS | Tidak ada bukti pelaksanaan UAT dan user melarang menjadikannya pengujian utama tanpa bukti. | Hapus dari BAB II final. |
| 31 | 2.2 Penelitian Terkait | PAKAI DENGAN REVISI | Wajib ada, tetapi semua artikel perlu diverifikasi. | Susun ulang setelah metadata sumber, tahun, judul, jurnal/prosiding, dan relevansi jelas. |
| 32 | LRS | TAMBAHKAN | Belum ada di BAB II lama, tetapi wajib dalam struktur final. | Tambahkan `2.1.11 LRS` dengan referensi valid. |

## 4. Bagian Yang Masih Bisa Dipakai

Bagian berikut masih dapat menjadi bahan mentah, tetapi harus ditulis ulang dan diberi sitasi yang valid:

1. Pembahasan sistem informasi sebagai gabungan data, proses, dan informasi.
2. Penjelasan website sebagai media aplikasi berbasis web.
3. Pembahasan inventaris aset yang menekankan pencatatan aset, pemantauan aset, lokasi aset, dan kebutuhan administrasi.
4. Bagian disposisi surat yang menjelaskan tindak lanjut surat masuk, setelah dipisahkan dari teori surat.
5. Penjelasan PHP sebagai bahasa pemrograman server-side.
6. Penjelasan CodeIgniter 4 sebagai framework PHP berbasis MVC.
7. Penjelasan MySQL sebagai basis data relasional.
8. Bagian basis data tentang entitas, atribut, relasi, kardinalitas, primary key, dan foreign key, setelah ditempatkan ke ERD/Basis Data MySQL.
9. Penjelasan UML dan jenis diagram yang benar-benar digunakan.
10. Penjelasan Agile Scrum sebagai model pengembangan iteratif.
11. Penjelasan black-box testing sebagai metode pengujian fungsional.
12. Ringkasan penelitian terkait, setelah sumber artikel diverifikasi.

## 5. Bagian Yang Terlalu Melebar

1. Pembahasan World Wide Web, internet, dan web browser.
2. Sejarah dan karakteristik Mozilla Firefox serta Google Chrome.
3. Pembahasan jaringan komputer, firewall, dan cyber crime yang terlalu luas.
4. Pembahasan HTML, CSS, JavaScript, SQL, dan Bootstrap sebagai subbab utama.
5. Pembahasan UI/UX sebagai landasan teori utama.
6. Penjelasan lengkap ceremony Scrum seperti Daily Scrum, Sprint Review, Sprint Retrospective, dan Increment apabila tidak didukung bukti pelaksanaan.
7. Pembahasan UAT tanpa bukti kegiatan UAT.

## 6. Bagian Yang Tidak Relevan Dengan Judul

Judul final: `Perancangan Sistem Terintegrasi Inventaris Aset dan Disposisi Surat Berbasis Web pada SMPI REJIS`.

Bagian yang tidak langsung relevan:

1. Sejarah browser dan produk browser.
2. Pembahasan internet secara umum.
3. Pembahasan cyber crime secara luas.
4. HTML, CSS, JavaScript, SQL, dan Bootstrap sebagai teori utama.
5. UI/UX sebagai subbab utama.
6. UAT sebagai metode pengujian apabila tidak ada bukti pelaksanaan.

## 7. Bagian Yang Perlu Dipangkas

1. Definisi sistem yang terlalu banyak dan berulang.
2. Pembahasan WWW, internet, dan browser.
3. Sejarah browser.
4. Uraian teknologi pendukung frontend.
5. Penjelasan SQL umum.
6. Penjelasan Scrum ceremony yang tidak terbukti dilakukan.
7. Uraian pengujian keamanan dan kinerja yang terlalu luas.
8. Paragraf penelitian terkait yang terlalu umum dan belum menunjukkan gap terhadap aplikasi SMPI REJIS.

## 8. Bagian Yang Perlu Dipindahkan Ke BAB III Atau BAB IV

1. Arsitektur client-server pada aplikasi web: pindahkan ke BAB III/BAB IV bila menjelaskan arsitektur implementasi.
2. UI/UX: pindahkan ke BAB III bagian rancangan antarmuka atau BAB IV bagian implementasi tampilan.
3. Use case, activity, sequence, class diagram, ERD, dan LRS aktual: tempatkan gambar/diagram di BAB III/BAB IV sesuai outline, sedangkan BAB II cukup teori.
4. Pengujian keamanan dasar dan pengujian kinerja dasar: pindahkan ke BAB IV jika ada skenario dan hasil pengujian.
5. Bukti Scrum berupa backlog, sprint, dan hasil implementasi: letakkan di BAB IV sebagai pemetaan implementasi, bukan klaim ceremony yang tidak terdokumentasi.

## 9. Bagian Yang Wajib Ditambahkan

1. `2.1.4 Surat`.
2. `2.1.5 Disposisi Surat` sebagai subbab terpisah dari surat.
3. `2.1.6 Basis Data MySQL` dengan fokus basis data relasional dan MySQL.
4. `2.1.10 ERD`.
5. `2.1.11 LRS`.
6. Penegasan `2.1.13 Black-Box Testing`.
7. Penelitian terkait yang sudah diverifikasi dan relevan dengan inventaris aset, disposisi surat, sistem informasi sekolah, CodeIgniter/web, dan pengujian sistem.

## 10. Audit Role Pengguna

Role final aplikasi adalah:

1. `admin`
2. `operator`
3. `pimpinan`

Naskah lama masih memakai istilah:

1. Admin TU
2. Kepala Sekolah
3. Staff

Keputusan revisi:

1. Gunakan `admin`, `operator`, dan `pimpinan` sebagai role utama.
2. Istilah Admin TU, Kepala Sekolah, dan Staff boleh disebut sebagai padanan operasional sekolah jika diperlukan, tetapi harus dijelaskan dan tidak menggantikan role final.
3. Hindari menulis fitur role yang tidak ditemukan di aplikasi final.

## 11. Audit Gaya Bahasa Sesuai Pedoman

Masalah gaya bahasa yang ditemukan:

1. Ada kalimat populer/casual seperti "sudah tidak asing lagi ditelinga kita".
2. Ada gaya naratif umum seperti "setiap hari kita selalu berhubungan" yang kurang akademik.
3. Ada kalimat panjang yang perlu dipecah.
4. Ada beberapa paragraf definisi yang terasa seperti kutipan panjang tanpa pengolahan.
5. Ada klaim manfaat yang perlu dibuat lebih hati-hati, misalnya peningkatan efektivitas atau efisiensi harus dikaitkan dengan kebutuhan sistem, bukan klaim hasil tanpa data.

Aksi revisi:

1. Gunakan gaya akademik, ringkas, dan objektif.
2. Hindari sudut pandang "kita".
3. Hindari klaim hasil yang belum diuji.
4. Tulis teori sebagai dasar konsep, bukan sebagai promosi teknologi.

## 12. Audit Istilah Asing Dan Istilah Teknis

Istilah teknis yang perlu distandarkan:

1. `Blackbox` sebaiknya ditulis `Black-Box Testing`.
2. `framework` dapat digunakan, tetapi definisi dan konteksnya harus jelas.
3. `database` dapat dipadankan dengan `basis data`; gunakan salah satu secara konsisten.
4. `User Interface` dan `User Experience` tidak dipakai sebagai subbab utama.
5. `client-server`, `server-side`, dan `MVC` boleh dipakai jika dijelaskan singkat.
6. `Scrum Master`, `Product Owner`, dan `Development Team` jangan ditulis sebagai role historis proyek jika tidak ada bukti formal.

## 13. Audit Tanda Baca, Slash, Kata Ulang, Dan Singkatan Tidak Resmi

Masalah yang perlu diperbaiki:

1. Spasi sebelum titik dua, misalnya `sebagai berikut :`, perlu menjadi `sebagai berikut:`.
2. Slash seperti `bidang/sektor` sebaiknya diganti menjadi `bidang atau sektor`.
3. Kata salah ketik yang terdeteksi antara lain `pndasi`, `stackholder`, `engambilan`, `teroganisir`, `tersdiri`, `bubungan`, dan `pristiwa`.
4. Penulisan nama bahasa atau istilah perlu konsisten, misalnya `Belanda` jika merujuk bahasa/negara.
5. Ada kata yang menempel tanpa spasi seperti `terbukayang`, `menggunakanmesinrenderingWeb Kit`, dan `sepertiMicrosoftWindows`.
6. Singkatan harus ditulis lengkap saat pertama muncul, misalnya UML, ERD, LRS, PHP, dan MVC.

## 14. Audit Sitasi Dan Referensi

Referensi belum dapat dianggap aman karena folder `skripsi/06-referensi` belum menyediakan daftar pustaka/sumber yang dapat diverifikasi. Banyak sitasi berupa `n.d.` atau rujukan lama yang belum jelas metadata aslinya.

Prinsip revisi:

1. Jangan membuat sitasi palsu.
2. Jangan membuat daftar pustaka palsu.
3. Jangan memakai Blogspot, Wordpress, Wikipedia, atau sumber tidak ilmiah sebagai rujukan utama.
4. Tandai konsep dengan [PERLU SITASI] bila membutuhkan sumber.
5. Tandai rujukan dengan [PERLU CEK REFERENSI] bila sumber belum ditemukan.

## 15. Sumber Yang Belum Jelas

Sumber berikut wajib dicek sebelum dipakai:

1. `(Sistem, n.d.)` [PERLU CEK REFERENSI]
2. `(Literasi & Indonesia, n.d.)` [PERLU CEK REFERENSI]
3. `(PENGANTAR JARINGAN KOMPUTER, n.d.)` [PERLU CEK REFERENSI]
4. `(I, 2015)` [PERLU CEK REFERENSI]
5. `(Tri et al., n.d.)` [PERLU CEK REFERENSI]
6. `(Jogiyanto, 1995)` [PERLU CEK REFERENSI]
7. `(subtari, 2005)` atau kemungkinan `(Sutabri, 2005)` [PERLU CEK REFERENSI]
8. `(gordon, 1995)` [PERLU CEK REFERENSI]

Jika sumber tidak ditemukan atau tidak ilmiah, bagian terkait harus diganti dengan referensi yang valid.

## 16. Penelitian Terkait Yang Perlu Diverifikasi

Daftar penelitian terkait yang muncul dalam naskah lama dan perlu diverifikasi:

1. Annisa, Rahayuningsih, dan Anna (2023) [PERLU CEK REFERENSI]
2. Mubarok dan Sutaji (2025) [PERLU CEK REFERENSI]
3. Siswaya dan Setiawan (2025) [PERLU CEK REFERENSI]
4. Pranoto dan Sediyono (2021) [PERLU CEK REFERENSI]
5. Rohmawati (2025) [PERLU CEK REFERENSI]
6. Londa, Wee, dan Radja (2022) [PERLU CEK REFERENSI]

Yang perlu dicek untuk setiap penelitian:

1. Judul artikel.
2. Nama jurnal/prosiding.
3. Tahun terbit.
4. Penulis lengkap.
5. Objek penelitian.
6. Metode pengembangan/pengujian.
7. Relevansi dengan inventaris aset, disposisi surat, atau sistem informasi sekolah.
8. Perbedaan/gap dengan aplikasi SMPI REJIS.

## 17. Risiko Plagiarisme Atau Copy-Paste

Risiko cukup tinggi pada bagian:

1. Definisi sistem, informasi, dan sistem informasi yang memakai banyak kutipan lama.
2. Pembahasan WWW, internet, dan web browser.
3. Sejarah Mozilla Firefox dan Google Chrome.
4. Definisi HTML, CSS, JavaScript, PHP, SQL, Bootstrap, MySQL.
5. Definisi komponen ERD dan diagram UML.
6. Penjelasan pengujian keamanan, kinerja, dan UAT.

Mitigasi:

1. Tulis ulang dengan bahasa sendiri.
2. Gunakan sumber ilmiah atau dokumentasi resmi yang relevan.
3. Hindari menyalin definisi panjang.
4. Cantumkan sitasi hanya setelah sumber benar-benar ditemukan.

## 18. Risiko Klaim Berlebihan

Klaim yang perlu dikendalikan:

1. Sistem "meningkatkan efektivitas dan efisiensi" tanpa data pengukuran.
2. Sistem "mempermudah seluruh proses" tanpa batasan.
3. Agile Scrum seolah-olah dilakukan lengkap dengan semua ceremony formal.
4. Pengujian keamanan dan kinerja seolah-olah dilakukan mendalam.
5. UAT seolah-olah dilakukan, padahal belum ada bukti.
6. Sistem mencakup seluruh kebutuhan sekolah, padahal ruang lingkup aplikasi terbatas pada inventaris aset, transaksi/peminjaman aset, surat masuk, disposisi, surat keluar, laporan, dan backup.

Aksi revisi:

1. Gunakan frasa hati-hati seperti "dirancang untuk membantu".
2. Bedakan antara tujuan, rancangan, implementasi, dan hasil pengujian.
3. Jangan menulis kegiatan yang tidak memiliki bukti.

## 19. Rekomendasi Struktur BAB II Final

Struktur final yang direkomendasikan tetap mengikuti keputusan project:

```text
BAB II
LANDASAN TEORI

2.1. Tinjauan Pustaka
     2.1.1. Sistem Informasi
     2.1.2. Website
     2.1.3. Inventaris Aset
     2.1.4. Surat
     2.1.5. Disposisi Surat
     2.1.6. Basis Data MySQL
     2.1.7. PHP
     2.1.8. CodeIgniter
     2.1.9. UML
     2.1.10. ERD
     2.1.11. LRS
     2.1.12. Agile Scrum
     2.1.13. Black-Box Testing

2.2. Penelitian Terkait
```

Catatan akhir:

1. BAB II final belum boleh ditulis penuh sebelum referensi diperiksa.
2. Kerangka BAB II boleh disiapkan, tetapi isi teori final sebaiknya menunggu sumber yang valid.
3. Naskah lama dapat menjadi bahan revisi, bukan dasar final apa adanya.
