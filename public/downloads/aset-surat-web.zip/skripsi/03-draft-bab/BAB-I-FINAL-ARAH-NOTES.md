# BAB I FINAL ARAH NOTES

Tanggal dibuat: 2026-07-05

## 1. Status

BAB I sudah dikunci sebagai final dari sisi arah, struktur, dan ruang lingkup melalui `BAB-I-FINAL-ARAH.md`, tetapi belum final mutlak untuk DOCX. Penguncian ini setara dengan `BAB-II-FINAL-ARAH.md` yang sudah dikunci lebih dahulu untuk BAB II.

## 2. Dasar Penguncian

BAB I dikunci berdasarkan:

1. `BAB-I-REVISI-1.md`
2. `BAB-I-REVISION-NOTES.md`
3. `BAB-I-II-CONSISTENCY-CHECK.md`
4. `BAB-I-II-READY-FOR-BAB-III.md`

Perubahan dari `BAB-I-REVISI-1.md` ke `BAB-I-FINAL-ARAH.md` hanya bersifat kecil, yaitu menghapus baris "Status dokumen: revisi 1 BAB I untuk review, belum menjadi naskah final DOCX." dan baris "Judul skripsi: ..." yang sebelumnya berfungsi sebagai metadata kerja, lalu memulai naskah langsung dari "BAB I" dan "PENDAHULUAN". Seluruh substansi hasil wawancara, identifikasi masalah, rumusan masalah, tujuan dan manfaat, metode penelitian, dan ruang lingkup tidak diubah. Judul skripsi, objek penelitian, role final, fitur final, metode Agile Scrum, batasan deployment lokal/Laragon, dan keputusan pengujian (black-box testing, pengujian keamanan dasar, pengujian kinerja dasar) tetap sama seperti pada `BAB-I-REVISI-1.md`.

## 3. Marker Tersisa

Marker | Jumlah | Catatan
---|---|---
`[PERLU DATA]` | 1 | Pada bagian 1.5.1 Observasi, terkait detail waktu dan bentuk pelaksanaan observasi langsung yang masih perlu dilengkapi dari bukti riset.
`[PERLU SITASI]` | 0 | Tidak ditemukan.
`[PERLU CEK REFERENSI]` | 5 | Tersebar pada bagian 1.1 Latar Belakang (3 kemunculan: paragraf Sistem Informasi, paragraf Agile Scrum, paragraf pengujian) dan 1.5.1-1.5.2 Metode Penelitian (2 kemunculan: studi pustaka dan model pengembangan sistem).
`[PERLU CEK APA 7]` | 0 | Tidak ditemukan di BAB I; marker ini hanya relevan untuk BAB II subbab 2.1.11 LRS.
`[PERLU PENGUAT]` | 0 | Tidak ditemukan.
`[BELUM DAPAT DIPASTIKAN]` | 0 | Tidak ditemukan.

Total marker pada `BAB-I-FINAL-ARAH.md`: 6, sama dengan jumlah marker pada `BAB-I-REVISI-1.md` karena tidak ada marker yang dihapus atau ditambahkan pada tahap penguncian ini.

## 4. Bagian Yang Sudah Kuat

1. Latar belakang sudah spesifik pada SMPI REJIS.
2. Masalah inventaris aset dan disposisi surat sudah jelas.
3. Hasil wawancara 27 April 2026 sudah masuk.
4. Role aplikasi sudah konsisten.
5. Fitur aplikasi sudah konsisten.
6. Agile Scrum sudah ditulis hati-hati.
7. Pengujian sudah dibatasi pada black-box testing, keamanan dasar, dan kinerja dasar.
8. Deployment sudah dibatasi pada lingkungan lokal atau Laragon.
9. ERD sudah ditempatkan sebagai artefak perancangan, bukan fitur operasional.

## 5. Bagian Yang Masih Perlu Dicek

1. Detail observasi masih perlu dilengkapi jika bukti tersedia.
2. Marker `[PERLU CEK REFERENSI]` perlu dibereskan setelah sitasi BAB II dan daftar pustaka APA 7 siap.
3. Format istilah asing perlu diperiksa saat masuk DOCX.
4. Daftar pustaka dan Mendeley belum final.

## 6. Rekomendasi

BAB I sudah dapat menjadi dasar lanjut BAB III bersama BAB II, tetapi belum boleh disebut final mutlak sampai marker data, referensi, sitasi, dan format DOCX dibereskan.
