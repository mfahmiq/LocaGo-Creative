# EVIDENCEPATCH 3 NOTES

Tanggal dibuat: 2026-07-05

## 1. Status

Patch ini menyelesaikan marker berdasarkan data nyata putaran ketiga dari user (`USER-DATA-INPUT-ROUND-3.md`). Berbeda dari dua putaran sebelumnya, pada putaran ini spesifikasi hardware/software benar-benar terisi dengan data nyata, sehingga keempat marker `[PERLU DATA]` pada BAB IV 4.4.2 berhasil diselesaikan. Screenshot, pengujian kinerja dasar, dan data sekolah tetap tidak dapat diselesaikan sesuai instruksi eksplisit user dan hasil pengecekan langsung.

## 2. Data Yang Digunakan

1. **Spesifikasi hardware/software** (dapat dipakai): Processor Intel Core i5, RAM 8 GB, Storage 256 GB SSD, Sistem Operasi/Versi Windows: Windows 11, Browser: Google Chrome (versi terbaru saat pengujian, tanpa nomor versi spesifik sesuai instruksi user), Code Editor: Visual Studio Code (versi terbaru saat pengujian, tanpa nomor versi spesifik), Local Server: Laragon versi 6, PHP dan Database memakai versi yang sudah terverifikasi sebelumnya di workspace (PHP CLI 8.4.10; MySQL/MariaDB tanpa nomor versi spesifik karena belum pernah terverifikasi), Framework: CodeIgniter 4.
2. **Lokasi folder screenshot** (dicek, tetapi tidak menghasilkan penyelesaian marker): `C:\laragon\www\aset-surat-web\skripsi\04-diagram-dan-gambar\screenshots`. Folder berisi 22 berkas, seluruhnya sudah tercatat sebelumnya (bertanggal 2026-07-04), tidak ada berkas baru. Pemeriksaan visual terhadap 4 berkas kandidat yang paling mendekati kebutuhan (`14-transaksi-aset.png`, `15-upload-surat-masuk.png`, `18-surat-keluar.png`, `08-laporan.png`) menunjukkan seluruhnya adalah halaman detail/menu, bukan daftar/form-tambah/cetak yang dibutuhkan (lihat `SCREENSHOT-INVENTORY-CHECK.md`).
3. **Data yang belum tersedia**: pengujian kinerja dasar dan data sekolah, keduanya dinyatakan eksplisit "BELUM ADA" oleh user.

## 3. Marker Yang Selesai

No | BAB | Marker Lama | Data Pendukung | Status
---|---|---|---|---
1 | IV | `[PERLU DATA]` (4.4.2 — versi Windows) | Windows 11 | SELESAI
2 | IV | `[PERLU DATA]` (4.4.2 — versi browser) | Google Chrome, versi terbaru saat pengujian | SELESAI
3 | IV | `[PERLU DATA]` (4.4.2 — versi editor) | Visual Studio Code, versi terbaru saat pengujian | SELESAI
4 | IV | `[PERLU DATA]` (4.4.2 — spesifikasi hardware) | Intel Core i5, RAM 8 GB, 256 GB SSD | SELESAI

## 4. Marker Yang Masih Tersisa

No | BAB | Marker | Alasan Belum Selesai | Data Yang Dibutuhkan
---|---|---|---|---
1 | I | `[PERLU DATA]` (1.5.1 Observasi) | Dinyatakan eksplisit "BELUM ADA" oleh user | Data observasi nyata (waktu, bentuk, tanggal, pihak yang ditemui)
2 | III | `[PERLU DATA]` (3.1 — profil resmi) | Dinyatakan eksplisit "BELUM ADA" | Profil resmi SMPI REJIS
3 | III | `[PERLU DATA]` (3.1.1 — sejarah) | Dinyatakan eksplisit "BELUM ADA" | Sejarah singkat SMPI REJIS
4 | III | `[PERLU DATA]` (3.1.2 — struktur organisasi) | Dinyatakan eksplisit "BELUM ADA" | Bagan organisasi resmi
5-9 | IV | `[PERLU CEK SCREENSHOT]` x5 (4.1.3 User Interface) | Lokasi folder dikonfirmasi dan dicek langsung, tetapi kelima kebutuhan (manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, cetak laporan) tidak ditemukan, termasuk setelah pemeriksaan visual berkas kandidat terdekat | Screenshot nyata yang benar-benar menampilkan konten yang dibutuhkan (halaman daftar/list, form create, atau tampilan cetak — bukan halaman detail yang sudah ada)
10-16 | IV | `[PERLU DATA HASIL PENGUJIAN]` x7 (4.3 Pengujian Kinerja Dasar) | Dinyatakan eksplisit "BELUM ADA" | Angka waktu respons nyata untuk 6 proses
17 | II | `[PERLU CEK APA 7]` (2.1.11 LRS) | Di luar cakupan data yang diminta pada tiga putaran ini | Verifikasi Mendeley/APA 7
18-19 | V | `[PERLU CEK SETELAH BAB IV FINAL]` x2 (5.1 Kesimpulan) | Bergantung pada penyelesaian marker BAB IV nomor 5-16 | Penyelesaian marker BAB IV di atas

## 5. Risiko

1. Pengujian kinerja dasar belum tersedia; kolom waktu respons pada 6 proses tetap kosong sampai user memberikan angka nyata hasil pengamatan sederhana.
2. Data sekolah belum tersedia; profil, sejarah, struktur organisasi, dan detail observasi SMPI REJIS tetap kosong sampai ada dokumen resmi atau konfirmasi pihak sekolah.
3. Mendeley APA 7 belum final untuk seluruh referensi BAB II, termasuk marker pada subbab LRS yang belum tersentuh pada tiga putaran evidence patch ini.
4. BAB V tetap perlu direview ulang setelah BAB IV benar-benar final (screenshot dan pengujian kinerja lengkap); tidak ada perubahan pada BAB V karena BAB IV belum selesai.
5. DOCX final belum boleh dibuat karena 19 marker masih tersisa, ditambah kebutuhan verifikasi Mendeley/APA 7 dan format akhir DOCX resmi.
