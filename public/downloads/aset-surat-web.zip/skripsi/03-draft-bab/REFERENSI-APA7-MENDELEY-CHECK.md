# REFERENSI APA 7 MENDELEY CHECK

Tanggal dibuat: 2026-07-05

## 1. Status

File ini adalah checkpoint referensi, bukan daftar pustaka final. Isi disusun dari `BAB-II-FINAL-ARAH.md`, `REFERENSI-BAB-II-ONLINE-VERIFIED.md`, dan `REFERENSI-BAB-II-FINAL-CHECK.md`.

## 2. Aturan Pedoman UBSI 2026

Catatan: file `PEDOMAN-UBSI-2026-RINGKASAN-PROYEK.md` belum ditemukan di `skripsi/01-pedoman-dan-outline/`. Aturan berikut diambil dari `DOCX_FORMAT_SPEC.md` dan `PEDOMAN_AUDIT.md` yang tersedia sebagai gantinya.

1. Sitasi wajib menggunakan Mendeley dengan style APA 7.
2. Sumber tidak boleh berasal dari Blogspot, Wordpress, atau Wikipedia.
3. Skripsi wajib mensitasi minimal 10 jurnal (OJS atau jurnal/prosiding ilmiah sesuai pedoman).
4. Referensi jurnal minimal 5 tahun terakhir dari periode penyusunan laporan.
5. Referensi buku minimal 10 tahun terakhir dari periode penyusunan laporan.
6. Semua sitasi yang muncul dalam isi wajib masuk daftar pustaka, dan daftar pustaka tidak boleh memuat pustaka yang tidak dikutip.

## 3. Referensi Yang Sudah Digunakan

No | Referensi | Jenis | Tahun | Status Metadata | Perlu Mendeley | Catatan
---|---|---|---|---|---|---
1 | Wahyuni, Muthmainnah, Permana, & Novalima | Artikel jurnal | 2025 | BELUM LENGKAP | Ya | Volume, nomor, halaman, dan DOI belum tercantum pada sumber yang diverifikasi; dipakai untuk 2.1.1 Sistem Informasi dan 2.1.2 Website
2 | Annisa, Rahayuningsih, & Anna | Jurnal ilmiah (Jurnal Infotek: Jurnal Informatika dan Teknologi) | 2023 | LENGKAP | Ya | Vol. 6 No. 1, hlm. 60-70, DOI 10.29408/jit.v6i1.7356; dipakai untuk 2.1.3 Inventaris Aset dan 2.2 Penelitian Terkait
3 | Pranoto & Sediyono | Jurnal ilmiah (Jurnal JuTISI) | 2021 | PERLU CEK | Ya | Vol. 7 No. 2; halaman belum dikonfirmasi dari sumber asli; dipakai untuk 2.1.3 dan 2.2
4 | Mubarok & Sutaji | Jurnal ilmiah (Jurnal Bianglala Informatika) | 2025 | PERLU CEK | Ya | Vol. 13 No. 1, hlm. 27-33; DOI berbeda antara halaman resmi jurnal BSI (10.31294/bianglala.v13i1.12004) dan metadata Garuda (10.31294/bi.v13i1.25238); perlu verifikasi ulang sebelum input Mendeley; dipakai untuk 2.1.3 dan 2.2
5 | Siswaya & Setiawan | Jurnal ilmiah (Jurnal Insect: Jurnal Teknik Informatika) | 2025 | PERLU CEK | Ya | Vol. 11 No. 1, hlm. 127-137; DOI belum tercantum pada sumber yang diverifikasi; dipakai untuk 2.1.4, 2.1.5, dan 2.2
6 | Rohmawati & Yulianingsih | Jurnal ilmiah (Jurnal Indonesia: Manajemen Informatika dan Komunikasi) | 2025 | LENGKAP | Ya | Vol. 6 No. 2, hlm. 985-997, DOI 10.63447/jimik.v6i2.1372; dipakai untuk 2.1.5 dan 2.2
7 | Londa, Wee, & Radja | Jurnal ilmiah (Jurnal MATRIK) | 2022 | LENGKAP | Ya | Vol. 21 No. 2, hlm. 379-388, DOI 10.30812/matrik.v21i2.1443; dipakai untuk 2.1.5 dan 2.2
8 | KBBI | Sumber istilah resmi | - | LENGKAP | Ya (sebagai entri kamus, format Mendeley disesuaikan) | Dipakai untuk definisi istilah pada 2.1.4 Surat
9 | Undang-Undang Nomor 43 Tahun 2009 tentang Kearsipan | Peraturan perundang-undangan | 2009 | LENGKAP | Ya (format peraturan perundang-undangan APA 7) | Dipakai untuk konteks arsip pada 2.1.4 Surat
10 | PHP Documentation | Dokumentasi resmi | `[PERLU CEK]` | PERLU CEK | Ya | Tahun/versi dokumentasi yang dirujuk belum dicatat secara spesifik; dipakai untuk 2.1.7 PHP
11 | CodeIgniter 4 User Guide | Dokumentasi resmi | `[PERLU CEK]` | PERLU CEK | Ya | Tahun/versi dokumentasi belum dicatat spesifik; dipakai untuk 2.1.8 CodeIgniter
12 | MySQL Reference Manual | Dokumentasi resmi | `[PERLU CEK]` | PERLU CEK | Ya | Tahun/versi manual belum dicatat spesifik; dipakai untuk 2.1.6 Basis Data MySQL
13 | OMG UML 2.5.1 | Standar/dokumentasi resmi | `[PERLU CEK]` | PERLU CEK | Ya | Nomor versi (2.5.1) sudah ada, tahun rilis resmi belum dicatat; dipakai untuk 2.1.9 UML
14 | IBM Entity-Relationship Model Documentation | Dokumentasi resmi | `[PERLU CEK]` | PERLU CEK | Ya | Tahun/versi dokumentasi belum dicatat spesifik; dipakai untuk 2.1.10 ERD
15 | Scrum Guide 2020 | Dokumentasi resmi | 2020 | LENGKAP | Ya | Dipakai untuk 2.1.12 Agile Scrum
16 | ISTQB Glossary | Dokumentasi resmi | `[PERLU CEK]` | PERLU CEK | Ya | Versi/tahun glosarium yang dirujuk belum dicatat spesifik; dipakai untuk 2.1.13 Black-Box Testing
17 | Wiratama | Artikel jurnal (IJIS) | 2024 | BELUM LENGKAP | Ya | Volume, nomor, dan halaman belum tercantum pada sumber yang diverifikasi; dipakai untuk 2.1.11 LRS sebagai penguat awal
18 | JSAI | Artikel jurnal (JSAI) | 2024 | BELUM LENGKAP | Ya | Volume, nomor, dan halaman belum tercantum pada sumber yang diverifikasi; dipakai untuk 2.1.11 LRS sebagai penguat awal

## 4. Hitung Kebutuhan Minimal 10 Jurnal

1. Jumlah jurnal ilmiah/OJS: **9** — Wahyuni et al. (2025), Annisa et al. (2023), Pranoto & Sediyono (2021), Mubarok & Sutaji (2025), Siswaya & Setiawan (2025), Rohmawati & Yulianingsih (2025), Londa, Wee, & Radja (2022), Wiratama (2024), JSAI (2024).
2. Jumlah sumber resmi teknologi (dokumentasi/standar): **7** — PHP Documentation, CodeIgniter 4 User Guide, MySQL Reference Manual, OMG UML 2.5.1, IBM Entity-Relationship Model Documentation, Scrum Guide 2020, ISTQB Glossary.
3. Jumlah sumber pemerintah atau lembaga: **2** — Undang-Undang Nomor 43 Tahun 2009 tentang Kearsipan, KBBI.
4. Status pemenuhan minimal 10 jurnal: **BELUM MEMENUHI**. Jumlah jurnal ilmiah yang tersedia saat ini adalah 9, kurang 1 dari syarat minimal 10 jurnal pada pedoman.

`[PERLU TAMBAH JURNAL]` — perlu minimal 1 jurnal ilmiah tambahan yang relevan (topik yang dapat dicari: sistem informasi inventaris aset sekolah, sistem arsip/disposisi surat berbasis web, atau topik pendukung 2.1.1-2.1.13 lain yang masih dapat diperkuat), dengan sumber yang benar-benar terverifikasi (bukan hasil karangan), sebelum daftar pustaka BAB II disebut memenuhi syarat minimal.

## 5. Referensi Yang Jangan Dipakai

Sumber berikut sebelumnya sudah ditandai jangan dipakai karena metadata tidak jelas, terlalu lama, atau belum dapat diverifikasi sebagai sumber ilmiah yang layak untuk BAB II final (`REFERENSI-BAB-II-FINAL-CHECK.md`):

1. Sistem, n.d.
2. Literasi & Indonesia, n.d.
3. PENGANTAR JARINGAN KOMPUTER, n.d.
4. I, 2015
5. Tri et al., n.d.
6. Jogiyanto 1995
7. Subtari atau Sutabri 2005
8. Gordon 1995

Pengecekan pada `BAB-II-FINAL-ARAH.md` (naskah BAB II final arah yang berlaku saat ini) menunjukkan tidak ada satu pun dari 8 sumber di atas yang dipakai sebagai sitasi. Status ini konsisten dengan `BAB-I-II-CONSISTENCY-CHECK.md` bagian 9.

## 6. Rekomendasi

Referensi harus dimasukkan ke Mendeley dan dicek APA 7 sebelum DOCX final. Secara khusus:

1. Tambahkan minimal 1 jurnal ilmiah baru yang terverifikasi untuk memenuhi syarat minimal 10 jurnal.
2. Lengkapi metadata (volume, nomor, halaman, DOI, atau tahun versi dokumentasi) untuk referensi berstatus PERLU CEK dan BELUM LENGKAP pada tabel bagian 3.
3. Selesaikan verifikasi DOI ganda pada Mubarok & Sutaji (2025) sebelum input ke Mendeley.
4. Setelah seluruh referensi lengkap, masukkan ke Mendeley dengan style APA 7 dan cocokkan kembali dengan sitasi yang benar-benar dipakai di BAB II.
