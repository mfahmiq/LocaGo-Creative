# EVIDENCEPATCH 1 NOTES

Tanggal dibuat: 2026-07-05

## 1. Status

Patch ini menyelesaikan marker berdasarkan data nyata yang diisi user pada `USER-DATA-INPUT-ROUND-1.md`. Dari lima kategori data yang diminta pada `MARKER-RESOLUTION-DATA-CHECKLIST.md` (spesifikasi hardware/software, keputusan deployment, screenshot, pengujian kinerja dasar, data sekolah), hanya kategori **keputusan deployment** yang benar-benar terisi dengan data nyata. Empat kategori lainnya masih berupa placeholder kosong (`[ISI ...]`) sehingga marker terkait dipertahankan tanpa perubahan, sesuai batasan wajib untuk tidak mengarang data.

## 2. Data Yang Digunakan

1. **Deployment**: Opsi A (tetap lokal menggunakan Laragon), dengan keterangan eksplisit dari user bahwa aplikasi belum dipublikasikan pada server internal sekolah maupun hosting. Data ini nyata dan dapat dipakai.
2. **Spesifikasi hardware/software**: seluruh field (processor, RAM, storage, sistem operasi, versi Windows, browser, versi browser, code editor, versi code editor, versi Laragon) masih placeholder `[ISI ...]`. PHP dan Database diberi instruksi "gunakan yang sudah terverifikasi", tetapi keduanya bukan marker yang ada di BAB IV (PHP sudah terverifikasi 8.4.10 tanpa marker; Database hanya disebut "MySQL/MariaDB" tanpa marker versi), sehingga tidak ada marker yang berubah dari instruksi ini.
3. **Screenshot**: user menyatakan sudah menyiapkan 5 berkas, tetapi field lokasi folder juga placeholder. Pengecekan pada lokasi contoh (`skripsi/04-diagram-dan-gambar/screenshots/`) menunjukkan kelima nama berkas yang disebut user (`screenshot-manajemen-pengguna.png`, dll.) tidak ditemukan di folder tersebut maupun di lokasi lain dalam workspace.
4. **Pengujian kinerja dasar**: seluruh 6 baris waktu respons masih placeholder (`[ISI]`/`[ISI, contoh: 1,2 detik]`), bukan angka nyata.
5. **Data sekolah**: seluruh 6 field (profil, sejarah, struktur organisasi, detail observasi, tanggal observasi, pihak yang ditemui) masih placeholder kosong.

## 3. Marker Yang Selesai

No | BAB | Marker Lama | Data Pendukung | Status
---|---|---|---|---
1 | IV | `[PERLU DATA]` pada 4.4.1 Publikasi Software (rencana deployment) | Konfirmasi user: Opsi A, tetap lokal Laragon, tidak ada rencana server internal/hosting (`USER-DATA-INPUT-ROUND-1.md` bagian 2) | SELESAI

## 4. Marker Yang Masih Tersisa

No | BAB | Marker | Alasan Belum Selesai | Data Yang Dibutuhkan
---|---|---|---|---
1 | I | `[PERLU DATA]` (1.5.1 Observasi) | Data sekolah (bagian 5 data user) seluruhnya masih placeholder kosong | Waktu dan bentuk pelaksanaan observasi langsung yang nyata
2 | III | `[PERLU DATA]` (3.1 Tinjauan Perusahaan — profil resmi) | Field profil resmi masih placeholder kosong | Profil resmi SMPI REJIS (alamat, status kelembagaan/yayasan, visi misi)
3 | III | `[PERLU DATA]` (3.1.1 Sejarah Perusahaan) | Field sejarah singkat masih placeholder kosong | Sejarah singkat SMPI REJIS (tahun berdiri, latar belakang, perkembangan)
4 | III | `[PERLU DATA]` (3.1.2 Struktur Organisasi) | Field struktur organisasi masih placeholder kosong | Bagan organisasi resmi dan nama pejabat
5 | IV | `[PERLU DATA]` (4.4.2 — versi Windows) | Field "Versi Windows" masih placeholder kosong | Versi Windows yang benar-benar dipakai
6 | IV | `[PERLU DATA]` (4.4.2 — versi browser) | Field "Browser"/"Versi Browser" masih placeholder kosong | Nama dan versi browser yang dipakai mengakses aplikasi
7 | IV | `[PERLU DATA]` (4.4.2 — versi editor) | Field "Code Editor"/"Versi Code Editor" masih placeholder kosong | Nama dan versi editor pengembangan yang dipakai
8 | IV | `[PERLU DATA]` (4.4.2 — spesifikasi hardware) | Field Processor/RAM/Storage masih placeholder kosong | Spesifikasi perangkat keras (processor, RAM, storage)
9-13 | IV | `[PERLU CEK SCREENSHOT]` x5 (4.1.3 User Interface) | Kelima berkas yang disebut user tidak ditemukan di lokasi contoh folder screenshot; lokasi folder juga belum dikonfirmasi | Berkas screenshot nyata tersimpan di lokasi yang jelas, atau konfirmasi lokasi folder yang benar jika berkas disimpan di tempat lain
14-20 | IV | `[PERLU DATA HASIL PENGUJIAN]` x7 (4.3 Pengujian Kinerja Dasar) | Seluruh kolom waktu respons masih placeholder kosong | Angka waktu respons nyata hasil pengamatan sederhana (bukan load/stress testing) untuk 6 proses: login, dashboard, data aset, surat masuk, laporan, backup
21 | II | `[PERLU CEK APA 7]` (2.1.11 LRS) | Di luar cakupan data yang diminta pada putaran ini | Verifikasi Mendeley/APA 7 untuk sumber LRS
22-23 | V | `[PERLU CEK SETELAH BAB IV FINAL]` x2 (5.1 Kesimpulan) | Bergantung pada penyelesaian marker BAB IV di atas (screenshot dan pengujian kinerja belum selesai) | Penyelesaian marker BAB IV nomor 5-20, baru kemudian kesimpulan ditinjau ulang

## 5. Risiko

1. Data yang belum diisi (spesifikasi hardware/software, screenshot, pengujian kinerja, data sekolah) tetap membutuhkan konfirmasi user yang nyata sebelum dapat dipatch; tidak ada yang dikarang untuk mengisi kekosongan ini.
2. Mendeley APA 7 belum final untuk seluruh referensi BAB II, termasuk marker `[PERLU CEK APA 7]` pada subbab LRS yang tidak tersentuh pada putaran ini.
3. BAB V tetap perlu direview ulang setelah BAB IV benar-benar final (screenshot dan pengujian kinerja lengkap), karena kesimpulan pada 5.1 masih menyinggung hasil pengujian yang belum lengkap.
4. DOCX final belum boleh dibuat karena masih ada 23 marker yang belum terselesaikan, ditambah kebutuhan verifikasi Mendeley/APA 7 dan format akhir DOCX resmi.
