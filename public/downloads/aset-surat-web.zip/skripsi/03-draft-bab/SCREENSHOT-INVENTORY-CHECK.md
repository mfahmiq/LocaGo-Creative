# SCREENSHOT INVENTORY CHECK

Tanggal dibuat: 2026-07-05

## 1. Status

Folder screenshot sudah dicek secara read-only pada 2026-07-05. Pengecekan mencakup daftar nama berkas (`ls -la`) dan pembacaan visual langsung terhadap 4 berkas kandidat yang paling mendekati kebutuhan BAB IV, untuk memastikan pencocokan berdasarkan **isi halaman aktual**, bukan hanya nama berkas. Tidak ada berkas yang disisipkan ke DOCX pada tahap ini; DOCX baru belum dibuat.

## 2. Lokasi Folder

```text
C:\laragon\www\aset-surat-web\skripsi\04-diagram-dan-gambar\screenshots
```

## 3. Daftar File Ditemukan

Folder berisi **22 berkas** (21 PNG + 1 PDF), seluruhnya sudah tercatat sebelumnya pada `SCREENSHOT_REQUIREMENTS.md` dan `APPLICATION_VERIFICATION.md`. Tidak ditemukan berkas baru dengan tanggal 2026-07-05 atau nama sesuai yang disebut user (`screenshot-manajemen-pengguna.png`, dst.) — seluruh berkas bertanggal 2026-07-04.

No | Nama File | Ukuran File | Dugaan Halaman/Fitur | Status Relevansi
---|---|---|---|---
1 | `01-login.png` | 180.812 bytes | Halaman login | Sudah dipakai (Gambar IV.12)
2 | `02-dashboard-admin.png` | 98.172 bytes | Dashboard admin (versi awal, masih ada menu ERD) | Digantikan oleh `21-dashboard-final-tanpa-erd.png`
3 | `03-data-aset.png` | 57.123 bytes | Daftar inventaris aset | Sudah dipakai (Gambar IV.15)
4 | `04-tambah-aset.png` | 53.532 bytes | Form tambah aset | Sudah dipakai (Gambar IV.16)
5 | `05-surat-masuk.png` | 62.570 bytes | Daftar surat masuk | Sudah dipakai (Gambar IV.20)
6 | `06-disposisi-surat.png` | 45.428 bytes | Daftar/monitoring disposisi | Sudah dipakai (Gambar IV.22)
7 | `07-surat-keluar.png` | 51.507 bytes | Daftar surat keluar | Sudah dipakai (Gambar IV.24)
8 | `08-laporan.png` | 57.078 bytes | Halaman "Laporan & Rekap Data" (menu pilihan jenis laporan) — dikonfirmasi visual pada audit ini | Sudah dipakai (Gambar IV.26); **bukan** tampilan cetak/print
9 | `09-backup.png` | 46.100 bytes | Halaman backup | Sudah dipakai (Gambar IV.27)
10 | `10-erd-database.png` | 66.039 bytes | Halaman ERD (arsip lama) | Tidak dipakai sebagai UI operasional (ERD disembunyikan dari menu final)
11 | `11-tambah-data-aset.png` | 53.758 bytes | Bukti aset dummy di daftar/filter | Sudah dipakai sebagai bukti pendukung
12 | `12-edit-data-aset.png` | 61.916 bytes | Form edit aset | Sudah dipakai (Gambar IV.17)
13 | `13-detail-data-aset.png` | 52.529 bytes | Detail aset | Sudah dipakai (Gambar IV.18)
14 | `14-transaksi-aset.png` | 69.217 bytes | **"Detail Transaksi Aset"** (dikonfirmasi visual pada audit ini: judul halaman "Detail Transaksi Aset", menampilkan kode transaksi, status, item dipinjam) | Sudah dipakai (Gambar IV.19) sebagai bukti detail; **bukan** halaman daftar/list transaksi
15 | `15-upload-surat-masuk.png` | 81.152 bytes | **"Detail Surat Masuk"** dengan panel "Buat Disposisi" (dikonfirmasi visual pada audit ini) | Sudah dipakai (Gambar IV.21); **bukan** form tambah/create surat masuk
16 | `16-form-disposisi.png` | 81.152 bytes | Form/detail disposisi | Sudah dipakai (Gambar IV.23)
17 | `17-detail-disposisi.png` | 53.287 bytes | Monitoring disposisi | Sudah dipakai (Gambar IV.23)
18 | `18-surat-keluar.png` | 69.932 bytes | **"Detail Surat Keluar"** dengan panel "Update Pengiriman" (dikonfirmasi visual pada audit ini) | Sudah dipakai (Gambar IV.25); **bukan** form tambah/create surat keluar
19 | `19-cetak-pdf-transaksi.pdf` | 3.233 bytes | Bukti unduhan PDF transaksi aset (bukan gambar PNG) | Bukti pendukung 4.3 Testing (BB-18), bukan screenshot UI
20 | `20-hasil-upload-lampiran.png` | 81.152 bytes | Bukti detail surat masuk/lampiran dummy | Sudah dipakai sebagai bukti pendukung
21 | `21-dashboard-final-tanpa-erd.png` | 108.687 bytes | Dashboard final tanpa menu ERD | Sudah dipakai (Gambar IV.13)
22 | `22-sidebar-final-admin.png` | 16.530 bytes | Sidebar admin final | Sudah dipakai (Gambar IV.14)

## 4. Kebutuhan Screenshot BAB IV

No | Kebutuhan Screenshot | File Yang Cocok | Status
---|---|---|---
1 | Halaman Manajemen Pengguna | Tidak ada berkas dengan konten halaman ini; tidak ada nama file yang mengandung "pengguna"/"user" pada folder | TIDAK DITEMUKAN
2 | Halaman Daftar Transaksi Aset | `14-transaksi-aset.png` diperiksa visual, tetapi berisi halaman **"Detail Transaksi Aset"** (satu transaksi spesifik), bukan daftar/list seluruh transaksi | TIDAK DITEMUKAN
3 | Form Tambah Surat Masuk | `15-upload-surat-masuk.png` diperiksa visual, tetapi berisi halaman **"Detail Surat Masuk"** beserta panel buat disposisi, bukan form tambah/create surat masuk baru | TIDAK DITEMUKAN
4 | Form Tambah Surat Keluar | `18-surat-keluar.png` diperiksa visual, tetapi berisi halaman **"Detail Surat Keluar"** beserta panel update pengiriman, bukan form tambah/create surat keluar baru | TIDAK DITEMUKAN
5 | Cetak Laporan | `08-laporan.png` diperiksa visual, tetapi berisi halaman menu pilihan jenis laporan ("Laporan & Rekap Data"), bukan tampilan cetak/print | TIDAK DITEMUKAN

## 5. Catatan

Kelima kebutuhan screenshot BAB IV **tidak ditemukan** pada folder yang dicek, baik dari nama berkas yang disebut user (`screenshot-manajemen-pengguna.png`, dst., tidak ada satu pun) maupun dari pencocokan isi berkas lama yang paling mendekati (diperiksa secara visual dan ternyata seluruhnya adalah halaman detail/menu, bukan daftar/form-tambah/cetak yang dibutuhkan). Screenshot yang tidak ditemukan **tidak boleh dianggap tersedia**; marker `[PERLU CEK SCREENSHOT]` untuk kelima kebutuhan ini tetap dipertahankan pada `BAB-IV-REVISI-1-EVIDENCEPATCH-3.md`.
