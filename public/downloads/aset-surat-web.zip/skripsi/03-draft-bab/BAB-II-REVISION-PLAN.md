# BAB II REVISION PLAN

Status dokumen: rencana revisi sebelum drafting BAB II final.

Tanggal dibuat: 2026-07-04

## 1. Struktur BAB II Final

Struktur yang wajib digunakan:

```text
BAB II
LANDASAN TEORI

2.1. Tinjauan Pustaka
     2.1.1. Sistem Informasi
     2.1.2. Website
     2.1.3. Inventaris Aset
     2.1.4. Surat
     2.1.5. Disposisi Surat
     2.1.6. Basis Data MySQL
     2.1.7. PHP
     2.1.8. CodeIgniter
     2.1.9. UML
     2.1.10. ERD
     2.1.11. LRS
     2.1.12. Agile Scrum
     2.1.13. Black-Box Testing

2.2. Penelitian Terkait
```

## 2. Subbab Yang Akan Ditulis Ulang Total

Subbab berikut sebaiknya ditulis ulang total karena harus sangat sesuai dengan judul, aplikasi final, dan referensi valid:

1. `2.1.1 Sistem Informasi`.
2. `2.1.2 Website`.
3. `2.1.3 Inventaris Aset`.
4. `2.1.4 Surat`.
5. `2.1.5 Disposisi Surat`.
6. `2.1.11 LRS`.
7. `2.1.12 Agile Scrum`.
8. `2.1.13 Black-Box Testing`.
9. `2.2 Penelitian Terkait`.

Alasan: referensi final belum tersedia dan naskah BAB II lama belum dapat diaudit penuh.

## 3. Subbab Yang Bisa Diambil Dari BAB II Lama Dengan Revisi

Karena naskah BAB II lama belum tersedia, belum ada paragraf yang dapat dinyatakan aman untuk dipakai. Jika naskah lama nanti diberikan, bagian berikut berpotensi dipakai dengan revisi:

1. Definisi Sistem Informasi, jika sumbernya valid dan kalimatnya bukan salinan langsung.
2. Definisi Website, jika ringkas dan bersumber ilmiah.
3. Definisi inventaris aset, jika relevan dengan sekolah atau instansi.
4. Definisi surat dan disposisi surat, jika sumbernya dapat diverifikasi.
5. Teori UML, ERD, dan pengujian, jika sumbernya valid dan tidak usang.

Semua bagian yang diambil harus diparafrasakan, diberi sitasi valid, dan dihubungkan dengan project SMPI REJIS.

## 4. Subbab Yang Perlu Ditambah

Subbab yang wajib ditambahkan atau dipastikan ada:

1. `2.1.5 Disposisi Surat`.
2. `2.1.6 Basis Data MySQL`.
3. `2.1.8 CodeIgniter`.
4. `2.1.10 ERD`.
5. `2.1.11 LRS`.
6. `2.1.12 Agile Scrum`.
7. `2.1.13 Black-Box Testing`.
8. `2.2 Penelitian Terkait`.

Catatan:

1. Pengujian keamanan dasar dan pengujian kinerja dasar tidak dibuat sebagai subbab utama baru pada struktur final, kecuali user atau dosen meminta. Keduanya dapat dijelaskan sebagai cakupan pengujian pada BAB IV dan disebut ringkas di bagian pengujian.
2. HTML, CSS, JavaScript, SQL, dan Bootstrap cukup disebut sebagai teknologi pendukung bila diperlukan, bukan subbab utama.

## 5. Subbab Yang Perlu Dihapus

Subbab yang harus dihapus dari BAB II final bila ada di naskah lama:

1. `Sistem` sebagai subbab mandiri.
2. HTML.
3. CSS.
4. JavaScript.
5. SQL sebagai subbab mandiri.
6. Bootstrap.
7. UI/UX sebagai subbab utama.
8. User Acceptance Testing, kecuali ada bukti UAT dan user memutuskan untuk memasukkannya sebagai tambahan.
9. Waterfall/RAD sebagai metode utama.
10. Jaringan komputer umum.

## 6. Kebutuhan Referensi Per Subbab

| Subbab | Kebutuhan Referensi | Status |
| --- | --- | --- |
| 2.1.1 Sistem Informasi | Buku atau jurnal tentang sistem informasi dan pengelolaan data | [PERLU SITASI] |
| 2.1.2 Website | Referensi aplikasi web atau web-based information system | [PERLU SITASI] |
| 2.1.3 Inventaris Aset | Jurnal/buku tentang inventaris aset pada institusi/sekolah | [PERLU SITASI] |
| 2.1.4 Surat | Referensi administrasi surat atau arsip surat | [PERLU SITASI] |
| 2.1.5 Disposisi Surat | Jurnal sistem disposisi surat atau administrasi persuratan | [PERLU SITASI] |
| 2.1.6 Basis Data MySQL | Referensi MySQL atau basis data relasional | [PERLU SITASI] |
| 2.1.7 PHP | Referensi PHP sebagai bahasa pemrograman web | [PERLU SITASI] |
| 2.1.8 CodeIgniter | Dokumentasi resmi CodeIgniter atau buku/jurnal terkait CodeIgniter | [PERLU SITASI] |
| 2.1.9 UML | Referensi UML dan diagram yang dipakai | [PERLU SITASI] |
| 2.1.10 ERD | Referensi ERD dan perancangan database | [PERLU SITASI] |
| 2.1.11 LRS | Referensi LRS atau perancangan struktur record/logical record | [PERLU SITASI] |
| 2.1.12 Agile Scrum | Referensi Scrum/Agile dari buku atau jurnal valid | [PERLU SITASI] |
| 2.1.13 Black-Box Testing | Referensi pengujian black-box dan pengujian aplikasi web | [PERLU SITASI] |
| 2.2 Penelitian Terkait | Minimal 5 jurnal aplikasi sejenis | [PERLU SITASI] |

## 7. Prioritas Pencarian Referensi

Prioritas tinggi:

1. Jurnal sistem inventaris aset sekolah atau instansi.
2. Jurnal sistem pengelolaan surat masuk, surat keluar, dan disposisi surat.
3. Jurnal sistem administrasi sekolah berbasis web.
4. Referensi Agile Scrum yang dapat dipakai sebagai model pengembangan.
5. Referensi *black-box testing*, pengujian keamanan dasar, dan pengujian kinerja dasar.

Prioritas sedang:

1. Sistem Informasi.
2. Website.
3. Basis Data MySQL.
4. PHP.
5. CodeIgniter.

Prioritas pendukung:

1. UML.
2. ERD.
3. LRS.

Catatan: referensi jurnal minimal 5 tahun terakhir lebih diprioritaskan sesuai pedoman. Buku dapat dipakai bila masih dalam rentang yang diizinkan pedoman dan relevan.

## 8. Rekomendasi Kesiapan Drafting BAB II

Rekomendasi: BAB II final belum sebaiknya ditulis penuh sebelum referensi diverifikasi.

Alasan:

1. Naskah BAB II lama belum tersedia sebagai sumber pembanding lengkap.
2. Folder referensi belum berisi file referensi yang dapat diverifikasi.
3. Beberapa sumber yang disebut user masih berstatus belum jelas, misalnya `Sistem, n.d.`, `Literasi & Indonesia, n.d.`, `PENGANTAR JARINGAN KOMPUTER, n.d.`, `I, 2015`, `Tri et al., n.d.`, Jogiyanto 1995, Subtari/Sutabri 2005, dan Gordon 1995.
4. Pedoman melarang sumber tidak ilmiah dan menuntut sitasi yang jelas dengan APA 7 melalui Mendeley.

Tahap berikutnya yang disarankan:

1. User menyediakan naskah BAB II lama bila ingin audit paragraf lama secara detail.
2. Lakukan verifikasi referensi untuk setiap subbab final.
3. Susun daftar referensi valid dan penelitian terkait.
4. Baru setelah itu drafting BAB II final dapat dimulai dengan marker `[PERLU SITASI]` hanya bila masih ada sumber yang belum lengkap.
