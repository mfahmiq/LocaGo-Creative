# BAB V DRAFT PLAN

Tanggal dibuat: 2026-07-05

## 1. Status

BAB V diarahkan untuk memuat kesimpulan dan saran berdasarkan BAB I sampai BAB IV. Karena BAB IV masih memiliki 18 marker yang belum selesai (`[PERLU DATA]`, `[PERLU CEK SCREENSHOT]`, `[PERLU DATA HASIL PENGUJIAN]`, `[PERLU CEK BUKTI KODE]`), BAB V masih berstatus draft awal dan harus dicek ulang setelah BAB IV final. File ini adalah rencana penyusunan BAB V, bukan naskah final.

Catatan sumber: file `PEDOMAN-UBSI-2026-RINGKASAN-PROYEK.md` yang diminta pada instruksi belum ditemukan di `skripsi/01-pedoman-dan-outline/`. Folder tersebut berisi `PEDOMAN_AUDIT.md`, `OUTLINE_156_MAPPING.md`, dan `ocr-render-status.md`, yang dipakai sebagai gantinya untuk konteks pedoman dan outline.

## 2. Struktur BAB V

```text
BAB V
PENUTUP

5.1. Kesimpulan
5.2. Saran
```

## 3. Dasar Penyusunan Kesimpulan

Kesimpulan harus menjawab:

1. Rumusan masalah BAB I (lima pertanyaan pada `BAB-I-FINAL-ARAH.md` bagian 1.3).
2. Hasil analisis BAB III (analisis masalah dan analisis kebutuhan pada `BAB-III-REVISI-1.md`).
3. Hasil desain, implementasi, dan pengujian BAB IV (`BAB-IV-REVISI-1.md`).
4. Batasan bahwa aplikasi diuji lokal menggunakan Laragon, bukan produksi/online/resmi digunakan sekolah.

## 4. Batasan

1. Jangan mengklaim sistem sempurna.
2. Jangan mengklaim aplikasi sudah resmi digunakan sekolah.
3. Jangan mengklaim aplikasi sudah produksi.
4. Jangan mengklaim sistem aman sepenuhnya.
5. Karena BAB IV masih memiliki marker, BAB V wajib diberi catatan `[PERLU CEK SETELAH BAB IV FINAL]` pada bagian kesimpulan yang menyinggung hasil pengujian.
