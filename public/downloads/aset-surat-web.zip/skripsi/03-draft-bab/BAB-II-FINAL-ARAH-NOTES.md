# BAB II FINAL ARAH NOTES

## 1. Status

BAB II sudah final dari sisi struktur, arah, dan ruang lingkup, tetapi belum final mutlak untuk DOCX. Draft ini dikunci sebagai arah BAB II yang dapat menjadi dasar untuk BAB III dan pembaruan selanjutnya.

## 2. Marker Tersisa


## 3. Bagian Yang Sudah Kuat

- Struktur BAB II sudah sesuai dengan format final yang disepakati.
- Subbab 2.1.11 LRS sudah tersedia dan diberi catatan sumber penguat awal.
- Penelitian terkait sudah relevan dengan inventaris aset dan disposisi surat.
- Sumber lemah lama tidak dipakai dan tetap ditandai sebagai jangan pakai dulu.
- Scrum ditulis sebagai landasan teori, bukan klaim historis pelaksanaan.
- Black-box testing difokuskan sebagai teknik pengujian fungsional.

## 4. Bagian Yang Masih Perlu Dicek

- APA 7 dan Mendeley untuk seluruh referensi.
- LRS karena sumbernya masih penguat awal dan bukan buku teori utama.
- Mubarok dan Sutaji (2025) karena DOI memakai halaman resmi jurnal BSI dan metadata Garuda berbeda.
- Metadata penelitian terkait saat dimasukkan ke daftar pustaka.

## 5. Rekomendasi

BAB II sudah dapat menjadi dasar lanjut BAB III, tetapi belum boleh disebut final mutlak sampai sitasi, daftar pustaka, dan Mendeley diperiksa.
