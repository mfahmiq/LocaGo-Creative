# BAB I SAMPAI V MARKER COUNT AFTER EVIDENCEPATCH 3

Tanggal dibuat: 2026-07-05

## 1. Status

File ini menghitung ulang marker setelah evidence patch 3. Pada putaran ketiga ini, user memberikan data nyata untuk spesifikasi hardware/software (Intel Core i5, RAM 8 GB, 256 GB SSD, Windows 11, Google Chrome, Visual Studio Code, Laragon 6), sehingga keempat marker `[PERLU DATA]` pada BAB IV 4.4.2 berhasil diselesaikan. Untuk screenshot, meskipun user memberikan lokasi folder yang jelas dan menyatakan sudah menyiapkan 10 berkas, hasil pengecekan langsung (`SCREENSHOT-INVENTORY-CHECK.md`) — termasuk pemeriksaan visual terhadap 4 berkas kandidat yang paling mendekati — menunjukkan kelima kebutuhan screenshot BAB IV tetap tidak ditemukan, sehingga marker tersebut dipertahankan. Data pengujian kinerja dasar dan data sekolah dinyatakan eksplisit "BELUM ADA" oleh user, sehingga marker terkait juga dipertahankan. File terbaru yang dipakai untuk hitungan ini:

1. `BAB-I-FINAL-ARAH-DATAPATCH-2.md` (tidak diubah pada tahap ini)
2. `BAB-II-FINAL-ARAH-REFPATCH-1.md` (tidak diubah pada tahap ini)
3. `BAB-III-REVISI-1-DATAPATCH-2.md` (tidak diubah pada tahap ini)
4. `BAB-IV-REVISI-1-EVIDENCEPATCH-3.md`
5. `BAB-V-REVISI-1.md` (tidak diubah pada tahap ini)

## 2. Hitungan Marker Sebelum Patch

BAB | Jumlah
---|---
BAB I | 1
BAB II | 1
BAB III | 3
BAB IV | 16
BAB V | 2
**Total** | **23**

## 3. Hitungan Marker Setelah Patch

BAB | Jumlah Sebelum | Jumlah Sesudah | Selisih | Catatan
---|---|---|---|---
BAB I | 1 | 1 | 0 | Tidak diubah pada tahap ini; data observasi masih "BELUM ADA"
BAB II | 1 | 1 | 0 | Tidak diubah pada tahap ini; marker `[PERLU CEK APA 7]` (LRS) tetap ada
BAB III | 3 | 3 | 0 | Tidak diubah pada tahap ini; profil, sejarah, struktur organisasi masih "BELUM ADA"
BAB IV | 16 | **12** | -4 | Keempat marker `[PERLU DATA]` pada 4.4.2 Spesifikasi Hardware dan Software selesai (processor, RAM, storage, versi Windows, browser, editor, Laragon berdasarkan data nyata user). 12 marker lain tetap ada: `[PERLU CEK SCREENSHOT]` x5 (kelima kebutuhan tidak ditemukan meskipun lokasi folder dikonfirmasi dan 4 berkas kandidat diperiksa visual), `[PERLU DATA HASIL PENGUJIAN]` x7 (data waktu respons dinyatakan "BELUM ADA")
BAB V | 2 | 2 | 0 | Tidak diubah pada tahap ini; 2 marker `[PERLU CEK SETELAH BAB IV FINAL]` tetap ada (bergantung pada BAB IV yang masih memiliki marker screenshot dan pengujian kinerja)
**Total** | **23** | **19** | **-4** | 4 marker terselesaikan pada putaran ini (seluruhnya spesifikasi hardware/software)

## 4. Marker Yang Berhasil Diselesaikan

No | BAB | Marker | Lokasi | Data Pendukung
---|---|---|---|---
1 | IV | `[PERLU DATA]` | 4.4.2 — versi Windows | Windows 11 (`USER-DATA-INPUT-ROUND-3.md`)
2 | IV | `[PERLU DATA]` | 4.4.2 — versi browser | Google Chrome, versi terbaru saat pengujian (`USER-DATA-INPUT-ROUND-3.md`)
3 | IV | `[PERLU DATA]` | 4.4.2 — versi editor | Visual Studio Code, versi terbaru saat pengujian (`USER-DATA-INPUT-ROUND-3.md`)
4 | IV | `[PERLU DATA]` | 4.4.2 — spesifikasi hardware | Intel Core i5, RAM 8 GB, 256 GB SSD (`USER-DATA-INPUT-ROUND-3.md`)

## 5. Marker Yang Masih Tersisa

Kategori | Jumlah | Rincian | Alasan Belum Selesai
---|---|---|---
Butuh data user/sekolah | 5 | BAB I: 1 (observasi); BAB III: 3 (profil, sejarah, struktur organisasi) | User menyatakan eksplisit "BELUM ADA" pada putaran ini
Butuh screenshot | 5 | BAB IV 4.1.3: manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, cetak laporan | Lokasi folder sudah dikonfirmasi dan dicek langsung, tetapi kelima kebutuhan tidak ditemukan — baik dari nama berkas baru maupun dari pencocokan isi visual berkas lama yang paling mendekati (lihat `SCREENSHOT-INVENTORY-CHECK.md`)
Butuh hasil pengujian | 7 | BAB IV 4.3 Pengujian Kinerja Dasar: 6 proses + 1 kalimat penutup | User menyatakan eksplisit "BELUM ADA" pada putaran ini
Butuh Mendeley/APA 7 | 1 | BAB II 2.1.11 LRS | Di luar cakupan data yang diminta pada tiga putaran evidence patch ini
Butuh spesifikasi hardware | 0 | - | Selesai pada patch ini
Butuh review manual | 2 | BAB V 5.1 Kesimpulan poin 4 dan penutup | Masih bergantung pada penyelesaian marker BAB IV (screenshot dan pengujian kinerja) yang belum selesai
**Total** | **19** | - | -

## 6. Rekomendasi Berikutnya

Kategori spesifikasi hardware/software sudah selesai sepenuhnya. Tiga kategori masih tersisa membutuhkan data yang benar-benar baru: (1) screenshot nyata untuk 5 halaman yang benar-benar menampilkan konten yang dibutuhkan (bukan halaman detail/menu yang sudah ada), (2) angka waktu respons nyata hasil pengamatan sederhana, dan (3) data sekolah (profil, sejarah, struktur organisasi, observasi) dari dokumen resmi atau konfirmasi langsung pihak sekolah. Mendeley/APA 7 tetap menjadi pekerjaan terpisah yang belum tersentuh.
