# BAB II AUDIT

Status dokumen: audit besar BAB II lama sebelum penyusunan BAB II final.

Tanggal audit: 2026-07-04

## 1. Ringkasan Kualitas Umum BAB II Lama

Audit ini bersifat terbatas karena naskah lengkap `BAB-II-USER-DRAFT-LAMA.md` belum tersedia di workspace dan isi naskah BAB II lama tidak ikut tertempel pada attachment instruksi. File `BAB-II-USER-DRAFT-LAMA.md` dibuat sebagai placeholder sumber, bukan sebagai naskah final dan bukan sebagai isi BAB II lama.

Berdasarkan petunjuk user pada instruksi audit, BAB II lama diduga memiliki masalah besar pada struktur, relevansi teori, sitasi, dan konsistensi dengan project final. Beberapa indikasi masalah yang perlu diperiksa ulang setelah naskah lama tersedia adalah:

1. Struktur BAB II lama kemungkinan tidak mengikuti struktur final yang sudah disetujui.
2. Ada risiko subbab terlalu melebar, misalnya HTML, CSS, JavaScript, SQL, Bootstrap, UI/UX, dan User Acceptance Testing menjadi pembahasan utama.
3. Ada risiko penggunaan subbab `Sistem` secara terpisah, padahal keputusan project melarang subbab tersebut.
4. Ada risiko referensi tidak jelas, terlalu lama, tidak ilmiah, atau belum dapat diverifikasi.
5. Ada risiko gaya bahasa belum sesuai pedoman, terutama penggunaan istilah asing, tanda garis miring, singkatan tidak resmi, dan klaim berlebihan.

Kesimpulan awal: BAB II lama belum layak dijadikan BAB II final secara langsung. BAB II final harus ditulis ulang berdasarkan struktur final, referensi valid, dan batasan aplikasi final.

## 2. Perbandingan Struktur BAB II Lama Dengan Struktur Final

Struktur final yang sudah disetujui:

```text
BAB II
LANDASAN TEORI

2.1. Tinjauan Pustaka
     2.1.1. Sistem Informasi
     2.1.2. Website
     2.1.3. Inventaris Aset
     2.1.4. Surat
     2.1.5. Disposisi Surat
     2.1.6. Basis Data MySQL
     2.1.7. PHP
     2.1.8. CodeIgniter
     2.1.9. UML
     2.1.10. ERD
     2.1.11. LRS
     2.1.12. Agile Scrum
     2.1.13. Black-Box Testing

2.2. Penelitian Terkait
```

Catatan perbandingan:

1. Struktur lama belum dapat diverifikasi penuh karena isi naskah tidak tersedia.
2. Berdasarkan instruksi user, struktur lama kemungkinan memuat subbab tambahan yang tidak termasuk struktur final, seperti HTML, CSS, JavaScript, SQL, Bootstrap, UI/UX, atau User Acceptance Testing.
3. BAB II final harus fokus pada teori yang langsung mendukung judul, BAB I, BAB III, dan BAB IV.
4. `Penelitian Terkait` tetap menjadi subbab `2.2` sesuai outline 156 dan keputusan terbaru.

## 3. Tabel Keputusan Per Subbab

Tabel berikut adalah audit awal berbasis struktur final, audit aplikasi, dan petunjuk user. Keputusan detail terhadap paragraf/subbab lama perlu diperiksa ulang setelah naskah lama asli tersedia.

| No | Subbab Lama | Keputusan | Alasan | Aksi Revisi |
| --- | --- | --- | --- | --- |
| 1 | Sistem | HAPUS | User sudah memutuskan tidak ada subbab `Sistem` terpisah. Konsep sistem cukup melebur ke `Sistem Informasi`. | Hapus sebagai subbab mandiri; ambil hanya gagasan yang relevan untuk `2.1.1 Sistem Informasi`. |
| 2 | Sistem Informasi | PAKAI DENGAN REVISI | Relevan dengan judul dan BAB I, tetapi harus memakai referensi valid dan tidak terlalu umum. | Tulis ulang ringkas dengan sitasi valid. |
| 3 | Website atau Web | PAKAI DENGAN REVISI | Relevan karena aplikasi berbasis web. | Tulis sebagai teori pendukung aplikasi web, bukan sejarah web panjang. |
| 4 | Inventaris atau Inventaris Aset | PAKAI DENGAN REVISI | Relevan langsung dengan modul aset. | Fokus pada pengelolaan aset, pencatatan barang, lokasi, kondisi, dan peminjaman aset. |
| 5 | Surat | PAKAI DENGAN REVISI | Relevan langsung dengan surat masuk dan surat keluar. | Jelaskan konsep surat administrasi secara ringkas. |
| 6 | Disposisi Surat | PAKAI DENGAN REVISI | Relevan langsung dengan fokus judul. | Jelaskan tindak lanjut surat dan pemantauan disposisi. |
| 7 | Basis Data atau Database | PAKAI DENGAN REVISI | Relevan, tetapi struktur final meminta `Basis Data MySQL`. | Fokus pada basis data relasional dan MySQL. |
| 8 | SQL | HAPUS | SQL bukan subbab utama yang disetujui. | Jika perlu, sebut singkat dalam `Basis Data MySQL`. |
| 9 | PHP | PAKAI DENGAN REVISI | Relevan sebagai bahasa pemrograman aplikasi. | Jelaskan ringkas sebagai teknologi pendukung, bukan tutorial sintaks. |
| 10 | CodeIgniter | PAKAI DENGAN REVISI | Relevan karena aplikasi menggunakan CodeIgniter 4. | Tulis sebagai *framework* PHP dan hubungkan dengan MVC. |
| 11 | HTML | HAPUS | User memutuskan HTML tidak menjadi subbab utama BAB II. | Jika perlu, sebut singkat sebagai teknologi antarmuka pada BAB IV atau support. |
| 12 | CSS | HAPUS | Tidak termasuk struktur final dan berisiko melebar. | Tidak dijadikan subbab utama. |
| 13 | JavaScript | HAPUS | Tidak termasuk struktur final dan tidak menjadi fokus penelitian. | Tidak dijadikan subbab utama. |
| 14 | Bootstrap | HAPUS | Tidak termasuk struktur final; cukup sebagai teknologi pendukung bila diperlukan. | Pindahkan ke BAB IV support atau sebut singkat sebagai pendukung antarmuka. |
| 15 | UI/UX | PINDAHKAN | Tidak menjadi subbab utama BAB II final. | Pindahkan ke BAB III bagian rancangan antarmuka bila diperlukan. |
| 16 | UML | PAKAI DENGAN REVISI | Relevan dengan diagram BAB III. | Tulis teori UML dan jenis diagram yang benar-benar dipakai. |
| 17 | Use Case Diagram | PINDAHKAN | Lebih cocok menjadi penjelasan bagian UML, bukan subbab utama terpisah. | Masukkan sebagai bagian ringkas dalam `2.1.9 UML`; detail diagram di BAB III. |
| 18 | Activity Diagram | PINDAHKAN | Lebih cocok menjadi bagian UML. | Masukkan ringkas dalam `2.1.9 UML`; detail di BAB III. |
| 19 | Sequence Diagram | PINDAHKAN | Lebih cocok menjadi bagian UML. | Masukkan ringkas dalam `2.1.9 UML`; detail di BAB IV bila digunakan. |
| 20 | Class Diagram | PINDAHKAN | Lebih cocok menjadi bagian UML. | Masukkan ringkas dalam `2.1.9 UML`; detail di BAB IV bila digunakan. |
| 21 | ERD | PAKAI DENGAN REVISI | Relevan untuk desain database dan sudah menjadi artefak skripsi, bukan menu operasional. | Tulis teori ERD dan relasi data. |
| 22 | LRS | TAMBAHKAN | Wajib ditambahkan sesuai struktur final dan kebutuhan desain database. | Cari referensi valid dan tulis subbab `2.1.11 LRS`. |
| 23 | Agile atau Scrum | PAKAI DENGAN REVISI | Relevan sebagai metode pengembangan. | Tulis Agile Scrum sebagai model pengembangan dan pemetaan kerja, bukan klaim ceremony historis lengkap. |
| 24 | Waterfall atau RAD | HAPUS | Project final menggunakan Agile Scrum. | Jangan dijadikan model utama; sebut hanya jika membandingkan secara sangat singkat dan bersumber. |
| 25 | Black Box Testing | PAKAI DENGAN REVISI | Pengujian utama yang diputuskan adalah *black-box testing*. | Gunakan ejaan konsisten `Black-Box Testing` atau *black-box testing*. |
| 26 | User Acceptance Testing | HAPUS | Tidak ada bukti pelaksanaan UAT dan bukan pengujian utama. | Jangan jadikan subbab utama. |
| 27 | Pengujian Keamanan | TAMBAHKAN SECARA TERBATAS | Dosen meminta pengujian keamanan dasar, tetapi struktur final belum memuat subbab khusus. | Masukkan sebagai pembahasan pendukung dalam subbab pengujian atau BAB IV testing, bukan klaim audit keamanan lanjut. |
| 28 | Pengujian Kinerja | TAMBAHKAN SECARA TERBATAS | Dosen meminta pengujian kinerja dasar, tetapi struktur final belum memuat subbab khusus. | Masukkan sebagai pembahasan pendukung dalam subbab pengujian atau BAB IV testing, bukan *load testing*. |
| 29 | Penelitian Terkait | PAKAI DENGAN REVISI | Wajib ada sebagai `2.2 Penelitian Terkait`. | Minimal 5 penelitian terkait dari jurnal ilmiah dan harus diverifikasi. |

## 4. Bagian Yang Terlalu Melebar

Bagian yang berpotensi terlalu melebar dan perlu dipangkas:

1. Sejarah internet, web, HTML, CSS, JavaScript, atau Bootstrap.
2. Tutorial sintaks PHP, SQL, HTML, CSS, atau JavaScript.
3. Pembahasan UI/UX umum yang tidak langsung mendukung perancangan antarmuka aplikasi.
4. Pembahasan jaringan komputer umum, terutama bila memakai sumber `PENGANTAR JARINGAN KOMPUTER, n.d.`.
5. Pembahasan metode pengembangan selain Agile Scrum.
6. Uraian lengkap ceremony Scrum sebagai kejadian historis bila tidak ada bukti.
7. Pengujian UAT jika tidak ada dokumen pelaksanaan UAT.

## 5. Bagian Yang Tidak Relevan Dengan Judul

Bagian yang tidak relevan dengan judul `Perancangan Sistem Terintegrasi Inventaris Aset dan Disposisi Surat Berbasis Web pada SMPI REJIS`:

1. Teori yang tidak terkait sistem informasi, web, aset, surat, disposisi, database, PHP, CodeIgniter, UML, ERD, LRS, Scrum, atau pengujian.
2. Pembahasan jaringan komputer umum.
3. Pembahasan desain grafis atau UI/UX yang terlalu luas.
4. Pembahasan teknologi front-end sebagai subbab utama.
5. UAT sebagai pengujian utama tanpa bukti.
6. Metode Waterfall/RAD sebagai metode utama.

## 6. Bagian Yang Perlu Dipangkas

Bagian yang perlu dipangkas bila ada dalam naskah lama:

1. Definisi berlapis dari banyak penulis untuk konsep yang sama tanpa sintesis.
2. Kutipan teori terlalu panjang.
3. Daftar fitur teknologi yang tidak digunakan langsung pada skripsi.
4. Teori yang tidak dihubungkan kembali ke project SMPI REJIS.
5. Pembahasan HTML, CSS, JavaScript, SQL, dan Bootstrap sebagai subbab utama.
6. Penjelasan teknis yang seharusnya masuk BAB IV, seperti potongan kode, route, controller, dan struktur folder aplikasi.

## 7. Bagian Yang Perlu Dipindahkan Ke BAB III atau BAB IV

| Bagian | Pindah Ke | Alasan |
| --- | --- | --- |
| UI/UX atau desain antarmuka detail | BAB III atau BAB IV | BAB II cukup teori ringkas; desain aktual masuk rancangan atau user interface. |
| Use case diagram, activity diagram, sequence diagram, class diagram aktual | BAB III/BAB IV | BAB II hanya teori UML; diagram project masuk bab perancangan/implementasi. |
| ERD final dan relasi tabel project | BAB IV | BAB II cukup teori ERD; desain database aktual masuk BAB IV. |
| LRS tabel aplikasi | BAB IV | BAB II cukup teori LRS; LRS project masuk desain database. |
| Product backlog dan sprint mapping | BAB III/BAB IV | BAB II cukup teori Agile Scrum; artefak project masuk analisis/implementasi. |
| Skenario *black-box testing* | BAB IV | BAB II cukup teori pengujian. |
| Hasil pengujian keamanan dasar dan kinerja dasar | BAB IV | Hasil aktual pengujian masuk testing. |
| Potongan kode, route, controller, model, view | BAB IV | Termasuk code generation/software architecture. |

## 8. Bagian Yang Wajib Ditambahkan

Bagian yang wajib ditambahkan atau dipastikan ada:

1. `2.1.3 Inventaris Aset`.
2. `2.1.4 Surat`.
3. `2.1.5 Disposisi Surat`.
4. `2.1.6 Basis Data MySQL`.
5. `2.1.8 CodeIgniter`.
6. `2.1.10 ERD`.
7. `2.1.11 LRS`.
8. `2.1.12 Agile Scrum`.
9. `2.1.13 Black-Box Testing`.
10. `2.2 Penelitian Terkait` minimal 5 penelitian terkait.

Catatan khusus: LRS wajib ditambahkan karena sudah masuk struktur BAB II final dan mendukung BAB IV desain database.

## 9. Audit Istilah dan Role Pengguna

Istilah yang harus konsisten:

1. `aset`, bukan `asset`.
2. `inventaris aset`, bukan `inventory asset` kecuali dalam kutipan atau istilah asing yang dijelaskan.
3. `surat masuk`, `surat keluar`, dan `disposisi surat`.
4. `basis data MySQL`, bukan hanya `database` jika konteks subbab adalah teori.
5. `CodeIgniter 4`, bukan CodeIgniter umum tanpa konteks.
6. `Agile Scrum`.
7. `Black-Box Testing` untuk judul subbab atau *black-box testing* dalam kalimat.

Role pengguna final:

1. `admin`.
2. `operator`.
3. `pimpinan`.

Jika memakai istilah sekolah, tulis sebagai padanan operasional, misalnya admin atau operator administrasi dan pimpinan sekolah. Jangan mengganti role final menjadi `Admin TU`, `Kepala Sekolah`, dan `Staff` sebagai role aplikasi jika tidak dijelaskan sebagai padanan operasional.

## 10. Audit Gaya Bahasa Sesuai Pedoman

Aturan gaya bahasa yang harus diterapkan saat revisi:

1. Gunakan bahasa ilmiah, baku, objektif, dan mudah dipahami.
2. Hindari kalimat promosi, terlalu subjektif, atau terlalu umum.
3. Hindari humor atau kalimat tidak akademik.
4. Jangan memakai kutipan panjang bila tidak diperlukan.
5. Parafrasakan teori dengan bahasa sendiri dan tetap cantumkan sumber.
6. Hindari pengulangan definisi tanpa sintesis.
7. Setiap subbab teori perlu diakhiri dengan keterkaitan singkat terhadap penelitian.

## 11. Audit Penggunaan Istilah Asing

Istilah asing boleh digunakan bila merupakan istilah teknis dan belum ada padanan yang lazim. Aturan awal:

1. Gunakan istilah Indonesia bila tersedia.
2. Tulis istilah asing miring dalam Markdown, misalnya *framework*, *product backlog*, *sprint*, dan *black-box testing*.
3. Jika istilah Indonesia perlu dijelaskan dalam bahasa asing, gunakan format `Sistem Informasi (Information System)`.
4. Jangan mencampur istilah Indonesia dan Inggris secara berlebihan dalam satu kalimat.
5. Jangan memakai istilah asing untuk memberi kesan teknis bila padanan Indonesia sudah jelas.

## 12. Audit Tanda Baca, Slash, Kata Ulang, dan Singkatan Tidak Resmi

Hal yang harus diperiksa pada naskah lama:

1. Hapus garis miring untuk arti `atau`, misalnya `fitur/modul`, `validasi/pengujian`, atau `online/deployment`.
2. Gunakan `atau` atau `dan` sesuai konteks.
3. Hindari singkatan tidak resmi seperti `dll`, `dst`, `yg`, `thd`, `dsb`, dan `ybs`.
4. Tulis kata ulang penuh, misalnya `kata-kata`, bukan `kata2`.
5. Tidak boleh ada spasi sebelum tanda tanya.
6. Tanda titik dua ditulis langsung setelah frasa, misalnya `sebagai berikut:`.
7. Perbaiki typo, misalnya `pengarsipn` menjadi `pengarsipan`.

## 13. Audit Sitasi dan Referensi

Status referensi saat audit:

1. Folder `skripsi/06-referensi/` tidak berisi file referensi yang dapat diverifikasi pada tahap ini.
2. Tidak ditemukan daftar pustaka atau database sitasi final.
3. Sitasi yang hanya disebut pada naskah lama atau instruksi harus dianggap belum valid sampai file jurnal/buku atau metadata resmi tersedia.

Aturan:

1. Jangan membuat sitasi palsu.
2. Jangan mencantumkan nama penulis dan tahun tanpa sumber yang dapat diverifikasi.
3. Gunakan `[PERLU CEK REFERENSI]` untuk sumber yang disebut tetapi belum ada filenya.
4. Gunakan `[PERLU SITASI]` untuk konsep yang membutuhkan rujukan tetapi sumber belum dipilih.
5. Gunakan Mendeley dengan style APA 7 saat daftar referensi sudah tersedia.
6. Hindari Blogspot, Wordpress, Wikipedia, dan sumber tidak ilmiah.
7. Skripsi membutuhkan minimal 10 jurnal sesuai pedoman.
8. Penelitian terkait membutuhkan minimal 5 jurnal sesuai outline.

## 14. Daftar Sumber Yang Belum Jelas

Sumber berikut wajib diverifikasi sebelum dipakai:

1. `Sistem, n.d.`.
2. `Literasi & Indonesia, n.d.`.
3. `PENGANTAR JARINGAN KOMPUTER, n.d.`.
4. `I, 2015`.
5. `Tri et al., n.d.`.
6. Jogiyanto 1995.
7. Subtari/Sutabri 2005.
8. Gordon 1995.
9. Annisa & Rahayuningsih (2023), jika nanti muncul di BAB II lama.
10. Mubarok & Sutaji (2025), jika nanti muncul di BAB II lama.

Keputusan awal: jangan pakai sumber di atas sebagai sitasi final sampai identitas lengkap, file referensi, dan relevansinya diverifikasi.

## 15. Daftar Penelitian Terkait Yang Perlu Diverifikasi

Karena naskah BAB II lama belum tersedia, daftar penelitian terkait lama belum dapat diaudit satu per satu. Kebutuhan verifikasi untuk `2.2 Penelitian Terkait`:

1. Minimal 5 jurnal ilmiah terkait sistem inventaris aset sekolah.
2. Jurnal tentang sistem pengelolaan surat masuk dan surat keluar.
3. Jurnal tentang disposisi surat berbasis web.
4. Jurnal tentang sistem administrasi sekolah atau instansi pendidikan.
5. Jurnal tentang penerapan Agile Scrum atau pengujian aplikasi web bila relevan.

Setiap penelitian terkait harus diverifikasi:

1. Judul.
2. Penulis.
3. Tahun.
4. Nama jurnal/prosiding.
5. Volume, nomor, halaman, DOI atau URL resmi bila tersedia.
6. Relevansi terhadap judul skripsi.
7. Status sumber, apakah file tersedia atau perlu dicari.

## 16. Risiko Plagiarisme atau Copy-Paste

Risiko utama:

1. Definisi teori disalin langsung dari sumber tanpa parafrasa.
2. Kutipan langsung terlalu banyak dan tidak mengikuti format pedoman.
3. Sitasi lama dipakai tanpa file sumber yang jelas.
4. Teori lama dari buku atau artikel tidak terbaru dipakai sebagai dasar utama.
5. Penelitian terkait hanya diringkas dari abstrak tanpa membaca isi.
6. Naskah terlalu mirip dengan template BAB II lain.

Mitigasi:

1. Tulis ulang teori dengan parafrasa sendiri.
2. Gunakan kutipan tidak langsung sebagai bentuk utama.
3. Validasi setiap sitasi sebelum masuk naskah.
4. Hindari tool humanizer atau parafrase otomatis untuk mengakali deteksi.
5. Tambahkan sintesis yang menghubungkan teori dengan project SMPI REJIS.

## 17. Risiko Klaim Berlebihan

Klaim yang harus dihindari:

1. Sistem pasti meningkatkan efektivitas tanpa data pengukuran.
2. Aplikasi aman dari seluruh serangan.
3. Pengujian keamanan setara *penetration testing*.
4. Pengujian kinerja setara *load testing*, *stress testing*, atau benchmark produksi.
5. Semua ceremony Scrum sudah dilakukan lengkap bila tidak ada bukti.
6. Sistem sudah dipakai resmi di server sekolah.
7. UAT sudah dilakukan bila tidak ada bukti.

Redaksi yang disarankan:

1. Sistem dirancang untuk membantu pengelolaan data.
2. Pengujian keamanan dasar memeriksa autentikasi, otorisasi, validasi input, sesi, upload, dan akses halaman.
3. Pengujian kinerja dasar memeriksa waktu respons pada lingkungan lokal.
4. Scrum digunakan sebagai model pengembangan dan pemetaan kerja berdasarkan fitur aplikasi.

## 18. Rekomendasi Struktur BAB II Final

BAB II final direkomendasikan memakai struktur berikut tanpa menambah subbab utama lain:

```text
BAB II
LANDASAN TEORI

2.1. Tinjauan Pustaka
2.1.1. Sistem Informasi
2.1.2. Website
2.1.3. Inventaris Aset
2.1.4. Surat
2.1.5. Disposisi Surat
2.1.6. Basis Data MySQL
2.1.7. PHP
2.1.8. CodeIgniter
2.1.9. UML
2.1.10. ERD
2.1.11. LRS
2.1.12. Agile Scrum
2.1.13. Black-Box Testing

2.2. Penelitian Terkait
```

Catatan akhir:

1. BAB II final sebaiknya belum ditulis penuh sebelum referensi diverifikasi.
2. Jika user menyediakan naskah BAB II lama, audit detail perlu diulang untuk memutuskan paragraf mana yang bisa dipakai.
3. Draft BAB II final harus menggunakan `[PERLU SITASI]` atau `[PERLU CEK REFERENSI]` sampai referensi valid tersedia.
