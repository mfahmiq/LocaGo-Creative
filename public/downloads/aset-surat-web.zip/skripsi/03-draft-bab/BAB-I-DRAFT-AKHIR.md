# BAB I

# PENDAHULUAN

Status dokumen: draft BAB I untuk review, belum menjadi naskah final DOCX.

Judul skripsi: Perancangan Sistem Terintegrasi Inventaris Aset dan Disposisi Surat Berbasis Web pada SMPI REJIS.

## 1.1 Latar Belakang

Administrasi sekolah tidak hanya berkaitan dengan kegiatan belajar mengajar, tetapi juga mencakup pengelolaan aset, pencatatan surat, disposisi, arsip, dan penyusunan laporan. Ketertiban administrasi diperlukan agar data yang digunakan oleh pihak sekolah dapat ditemukan kembali, diperiksa, dan dipertanggungjawabkan. Dalam konteks tersebut, sistem informasi dapat membantu mengelola data operasional agar proses pencatatan, pencarian, dan pelaporan menjadi lebih terstruktur. [PERLU SITASI]

SMPI REJIS sebagai objek penelitian memiliki kebutuhan administrasi yang berkaitan dengan inventaris aset dan pengelolaan surat. Profil resmi, sejarah singkat, dan struktur organisasi SMPI REJIS masih perlu dilengkapi dari sumber institusi agar uraian mengenai objek penelitian dapat ditulis secara akurat. [PERLU DATA] Berdasarkan bahan audit project yang tersedia, kebutuhan utama sistem berfokus pada pengelolaan inventaris aset, transaksi atau peminjaman aset, surat masuk, disposisi surat, surat keluar, arsip, laporan, dan backup.

Pengelolaan inventaris aset yang belum terdokumentasi secara terpadu dapat menimbulkan kesulitan ketika sekolah perlu mengetahui data barang, lokasi barang, riwayat peminjaman, kondisi barang, dan laporan aset. Pencatatan manual atau pencatatan yang tidak berlanjut dalam satu media terpusat berisiko membuat proses pencarian data menjadi lambat dan hasil pencatatan tidak seragam. Inventaris aset yang baik perlu mendukung pencatatan barang masuk, barang keluar, lokasi, kondisi, serta transaksi peminjaman dan pengembalian. [PERLU SITASI]

Selain inventaris aset, pengelolaan surat juga menjadi bagian penting dalam administrasi sekolah. Surat masuk perlu dicatat agar identitas surat, tanggal surat, asal surat, perihal, lampiran, dan status tindak lanjut dapat ditelusuri. Surat yang membutuhkan tindak lanjut juga memerlukan disposisi agar arahan pimpinan atau pihak terkait dapat terdokumentasi. Tanpa sistem yang terintegrasi, arsip surat masuk, disposisi, dan surat keluar dapat tersebar pada beberapa media pencatatan sehingga proses pelacakan status surat menjadi kurang efisien. [PERLU SITASI]

Disposisi surat merupakan proses penting karena berhubungan dengan penugasan, arahan, atau tindak lanjut terhadap surat yang diterima. Pada sistem manual, informasi disposisi dapat bergantung pada dokumen fisik atau catatan terpisah. Kondisi tersebut dapat menyulitkan pemantauan apabila surat sudah diteruskan, sedang diproses, atau telah selesai ditindaklanjuti. Oleh karena itu, sistem yang mampu menghubungkan surat masuk dengan disposisi dan status penyelesaiannya diperlukan untuk memperjelas alur kerja administrasi. [PERLU SITASI]

Berdasarkan kebutuhan tersebut, penelitian ini merancang sistem terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS. Sistem dirancang menggunakan CodeIgniter 4 dengan basis data MySQL/MariaDB pada lingkungan pengembangan dan pengujian lokal menggunakan Laragon. Lingkup sistem tidak mencakup publikasi produksi atau penerapan pada server daring sekolah karena bukti penerapan produksi belum tersedia. Sistem yang dibahas berfokus pada modul yang benar-benar ditemukan dan diverifikasi dalam aplikasi, yaitu autentikasi, dashboard, pengguna, inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup.

Pengembangan sistem dalam penelitian ini menggunakan pendekatan Agile Scrum. Scrum digunakan untuk memetakan kebutuhan ke dalam product backlog, mengelompokkan pekerjaan berdasarkan sprint, serta menghubungkan implementasi fitur dengan pengujian perangkat lunak. Penulisan Scrum pada skripsi ini perlu dilakukan secara hati-hati karena bukti historis pelaksanaan sprint secara rinci belum tersedia. Oleh sebab itu, pembahasan Scrum diarahkan sebagai model pengembangan dan mapping implementasi berdasarkan fitur aplikasi yang benar-benar ada, bukan sebagai riwayat kegiatan yang tidak didukung bukti. [PERLU SITASI]

Dengan adanya sistem ini, proses administrasi aset dan surat diharapkan dapat disusun dalam satu aplikasi yang lebih terarah. Aplikasi tidak dimaksudkan untuk menggantikan seluruh prosedur administrasi sekolah, tetapi menjadi alat bantu pencatatan dan pengelolaan data agar informasi aset, transaksi aset, surat, disposisi, dan laporan dapat tersimpan secara lebih rapi. Penelitian ini diharapkan memberikan dasar perancangan sistem yang relevan dengan kebutuhan SMPI REJIS serta dapat menjadi referensi bagi pengembangan sistem administrasi sekolah sejenis. [PERLU SITASI]

## 1.2 Identifikasi Masalah

Berdasarkan latar belakang dan audit kebutuhan aplikasi, identifikasi masalah dalam penelitian ini adalah sebagai berikut:

1. Pencatatan inventaris aset belum terintegrasi dalam satu sistem berbasis web.
2. Data aset seperti kategori, lokasi, kondisi, dan riwayat pengelolaan barang perlu disusun agar lebih mudah dicari dan dilaporkan.
3. Proses transaksi atau peminjaman aset memerlukan pencatatan yang dapat menunjukkan peminjam, barang yang dipinjam, tanggal transaksi, dan status pengembalian.
4. Pencatatan surat masuk, lampiran, dan status tindak lanjut perlu dikelola agar arsip surat lebih mudah ditelusuri.
5. Proses disposisi surat perlu terdokumentasi agar arahan dan status penyelesaian surat dapat dipantau.
6. Pencatatan surat keluar memerlukan media yang dapat menyimpan data surat, lampiran, status pengiriman, dan arsip.
7. Laporan aset, transaksi aset, surat masuk, disposisi, surat keluar, dan backup database perlu disiapkan dalam sistem agar mendukung kebutuhan dokumentasi administrasi.

## 1.3 Perumusan Masalah

Berdasarkan identifikasi masalah tersebut, perumusan masalah dalam penelitian ini adalah sebagai berikut:

1. Bagaimana merancang sistem terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS?
2. Bagaimana sistem dapat mendukung pengelolaan inventaris aset, transaksi atau peminjaman aset, surat masuk, disposisi, surat keluar, arsip, laporan, dan backup?
3. Bagaimana penerapan CodeIgniter 4 dan MySQL/MariaDB dapat digunakan dalam perancangan aplikasi administrasi sekolah berbasis web?
4. Bagaimana pendekatan Agile Scrum dapat digunakan untuk memetakan kebutuhan, implementasi fitur, dan pengujian sistem secara aman berdasarkan fitur yang benar-benar tersedia?
5. Bagaimana pengujian black-box dapat digunakan untuk memeriksa kesesuaian fungsi utama aplikasi dengan kebutuhan pengguna? [PERLU SITASI]

## 1.4 Tujuan dan Manfaat

Tujuan dan manfaat penelitian disusun untuk menjelaskan sasaran perancangan sistem serta kontribusi yang diharapkan dari penelitian ini.

### 1.4.1 Tujuan Penelitian

Tujuan penelitian ini adalah sebagai berikut:

1. Merancang sistem terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS.
2. Menyediakan rancangan dan implementasi aplikasi yang mencakup autentikasi, dashboard, pengguna, inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup.
3. Menggunakan CodeIgniter 4 dan MySQL/MariaDB sebagai dasar pengembangan aplikasi pada lingkungan lokal Laragon.
4. Menerapkan Agile Scrum sebagai model pengembangan sistem melalui penyusunan product backlog, sprint mapping, hasil implementasi, dan pengujian fitur.
5. Menyusun pengujian black-box untuk memeriksa fungsi utama aplikasi berdasarkan modul yang tersedia.

### 1.4.2 Manfaat Penelitian

Manfaat penelitian ini adalah sebagai berikut:

1. Bagi penulis, penelitian ini menjadi sarana untuk menerapkan pengetahuan tentang perancangan sistem informasi, pengembangan aplikasi web, basis data, metode Agile Scrum, dan pengujian black-box.
2. Bagi SMPI REJIS, penelitian ini dapat menjadi rancangan sistem yang membantu pengelolaan inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup data.
3. Bagi pembaca, penelitian ini dapat menjadi referensi mengenai perancangan sistem administrasi sekolah berbasis web yang mengintegrasikan pengelolaan aset dan surat.

## 1.5 Metode Penelitian

Metode penelitian menjelaskan cara pengumpulan data dan model pengembangan sistem yang digunakan dalam penyusunan skripsi. Penelitian ini menggunakan teknik pengumpulan data berupa observasi, wawancara, dan studi pustaka. Model pengembangan sistem yang digunakan adalah Agile Scrum. Penjelasan pada bagian ini tetap dibatasi pada data dan bukti yang tersedia agar tidak menimbulkan klaim yang belum dapat dipertanggungjawabkan.

### 1.5.1 Teknik Pengumpulan Data

Teknik pengumpulan data yang digunakan dalam penelitian ini adalah sebagai berikut:

1. Observasi

   Observasi dilakukan untuk memahami kebutuhan sistem yang berkaitan dengan pengelolaan inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup. Waktu, tempat, dan pihak yang terlibat dalam observasi masih perlu dilengkapi dari data riset resmi. [PERLU DATA]

2. Wawancara

   Wawancara digunakan untuk menggali permasalahan dan kebutuhan dari pihak yang berkaitan dengan administrasi aset dan surat di SMPI REJIS. Berdasarkan bahan project yang tersedia, hasil wawancara menunjukkan kebutuhan pencatatan barang masuk, barang keluar, lokasi barang, peminjaman barang, pencatatan surat, disposisi, arsip digital, dan laporan. Identitas narasumber, jabatan, tanggal wawancara, dan bukti administrasi riset perlu dilengkapi sebelum naskah final. [PERLU DATA]

3. Studi Pustaka

   Studi pustaka dilakukan dengan membaca dan mengkaji referensi ilmiah yang berkaitan dengan sistem informasi, website, inventaris aset, surat, disposisi surat, basis data MySQL, PHP, CodeIgniter, UML, ERD, LRS, Agile Scrum, dan black-box testing. Referensi yang digunakan harus berasal dari jurnal, buku, atau sumber ilmiah yang sesuai dengan pedoman, bukan dari Blogspot, Wordpress, atau Wikipedia. [PERLU SITASI]

### 1.5.2 Model Pengembangan Sistem

Model pengembangan sistem yang digunakan dalam penelitian ini adalah Agile Scrum. Scrum merupakan pendekatan pengembangan perangkat lunak yang menekankan pembagian pekerjaan ke dalam backlog, sprint, hasil increment, dan evaluasi bertahap. Dalam penelitian ini, Scrum digunakan untuk mengelompokkan kebutuhan sistem berdasarkan modul aplikasi, yaitu autentikasi, dashboard, pengguna, inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup. [PERLU SITASI]

Tahap awal dilakukan dengan menyusun product backlog berdasarkan kebutuhan aplikasi. Backlog tersebut mencakup kebutuhan login dan hak akses, pengelolaan pengguna, dashboard, inventaris aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, dan backup. Backlog kemudian dipetakan ke dalam sprint agar pengembangan dapat dijelaskan secara bertahap sesuai modul.

Sprint 0 digunakan sebagai tahap persiapan kebutuhan, lingkungan pengembangan, database, dan backlog awal. Sprint 1 berfokus pada autentikasi, role pengguna, dan dashboard. Sprint 2 berfokus pada inventaris aset, kategori, lokasi, dan upload foto aset. Sprint 3 berfokus pada transaksi atau peminjaman aset, pengembalian, dan PDF transaksi. Sprint 4 berfokus pada surat masuk, lampiran, disposisi, status disposisi, dan surat keluar. Sprint 5 berfokus pada laporan, backup, dokumentasi perancangan, dan pengujian akhir.

Penulisan sprint tersebut digunakan sebagai mapping pengembangan berdasarkan fitur aplikasi yang tersedia. Tanggal sprint, nama anggota Scrum Team, Daily Scrum, Sprint Review, dan Sprint Retrospective belum ditulis sebagai fakta historis karena bukti rinci belum tersedia. [PERLU DATA] Dengan batasan tersebut, Scrum tetap dapat digunakan secara aman sebagai model pengembangan sistem tanpa mengarang proses yang tidak didukung data.

## 1.6 Ruang Lingkup

Ruang lingkup penelitian ini dibatasi pada perancangan sistem terintegrasi inventaris aset dan disposisi surat berbasis web pada SMPI REJIS. Aplikasi dikembangkan menggunakan CodeIgniter 4 dengan database MySQL/MariaDB dan diuji pada lingkungan lokal Laragon. Penelitian tidak membahas penerapan produksi pada server daring sekolah karena bukti deployment produksi belum tersedia.

Fitur yang dibahas dalam penelitian ini meliputi:

1. Autentikasi pengguna dan pembatasan akses berdasarkan role.
2. Dashboard untuk menampilkan ringkasan data aplikasi.
3. Manajemen pengguna.
4. Pengelolaan inventaris aset, kategori aset, lokasi aset, kondisi aset, dan upload foto aset.
5. Transaksi atau peminjaman aset, pengembalian aset, detail transaksi, dan PDF transaksi aset.
6. Pengelolaan surat masuk, lampiran surat, dan status surat.
7. Pengelolaan disposisi surat dan status penyelesaiannya.
8. Pengelolaan surat keluar, lampiran surat keluar, dan status pengiriman.
9. Laporan aset, surat masuk, disposisi, surat keluar, dan transaksi aset.
10. Backup database sebagai fitur pendukung admin.

Ruang lingkup tidak mencakup perubahan source code di luar aplikasi yang sudah diaudit, integrasi dengan sistem eksternal, tanda tangan digital, layanan email otomatis, penerapan multi-sekolah, audit keamanan tingkat lanjut, atau penyimpanan pada server produksi. ERD tidak ditulis sebagai menu operasional pengguna, tetapi digunakan sebagai artefak dokumentasi dan perancangan skripsi.
