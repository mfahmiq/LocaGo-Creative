# BAB II Revision Plan V2

## Status

Rencana revisi ini dibuat setelah file `BAB-II-USER-DRAFT-LAMA.md` diganti dengan naskah BAB II lama asli. Rencana ini belum menulis BAB II final dan belum membuat `SKRIPSI.docx`.

## 1. Struktur BAB II Final

```text
BAB II
LANDASAN TEORI

2.1. Tinjauan Pustaka
     2.1.1. Sistem Informasi
     2.1.2. Website
     2.1.3. Inventaris Aset
     2.1.4. Surat
     2.1.5. Disposisi Surat
     2.1.6. Basis Data MySQL
     2.1.7. PHP
     2.1.8. CodeIgniter
     2.1.9. UML
     2.1.10. ERD
     2.1.11. LRS
     2.1.12. Agile Scrum
     2.1.13. Black-Box Testing

2.2. Penelitian Terkait
```

## 2. Subbab Yang Akan Ditulis Ulang Total

1. `2.1.1 Sistem Informasi`
   - Dasar dari subbab lama `Konsep Dasar Sistem dan Informasi`, tetapi perlu ditulis ulang agar tidak menjadi subbab `Sistem` terpisah.
   - Butuh sumber valid: [PERLU SITASI].

2. `2.1.2 Website`
   - Ambil inti dari subbab lama, tetapi hapus detail WWW, internet, dan web browser.
   - Butuh sumber valid: [PERLU SITASI].

3. `2.1.4 Surat`
   - Perlu ditulis sebagai subbab baru yang memisahkan teori surat dari disposisi.
   - Butuh sumber valid: [PERLU SITASI].

4. `2.1.5 Disposisi Surat`
   - Ambil inti dari subbab lama, tetapi tulis ulang agar fokus pada tindak lanjut surat masuk.
   - Butuh sumber valid: [PERLU SITASI].

5. `2.1.11 LRS`
   - Belum ada di BAB II lama.
   - Wajib ditambahkan sesuai struktur final.
   - Butuh sumber valid: [PERLU SITASI].

6. `2.2 Penelitian Terkait`
   - Harus ditulis ulang setelah seluruh artikel diverifikasi.
   - Jangan memakai daftar penelitian lama sebelum metadata sumber jelas.

## 3. Subbab Yang Bisa Diambil Dari BAB II Lama Dengan Revisi

1. `2.1.3 Inventaris Aset`
   - Materi lama relevan, tetapi perlu bahasa akademik dan sitasi valid.

2. `2.1.6 Basis Data MySQL`
   - Gabungkan teori basis data dan MySQL.
   - Pindahkan rincian ERD ke subbab ERD.

3. `2.1.7 PHP`
   - Materi lama dapat dipakai sebagai dasar, tetapi perlu ringkas dan sumber valid.

4. `2.1.8 CodeIgniter`
   - Materi CodeIgniter 4 relevan karena aplikasi menggunakan CodeIgniter 4.
   - Perlu penjelasan MVC secara ringkas.

5. `2.1.9 UML`
   - Materi UML, use case, activity, dan sequence dapat dipakai dengan pemangkasan.
   - Fokus pada diagram yang benar-benar digunakan di skripsi.

6. `2.1.10 ERD`
   - Ambil dari pembahasan entitas, atribut, relasi, kardinalitas, primary key, dan foreign key.
   - Perlu dipisahkan dari subbab basis data.

7. `2.1.12 Agile Scrum`
   - Materi lama dapat dipakai setelah dibatasi sebagai model pengembangan dan pemetaan kerja.
   - Jangan mengklaim seluruh ceremony Scrum terdokumentasi lengkap.

8. `2.1.13 Black-Box Testing`
   - Materi lama black-box testing relevan.
   - Pengujian keamanan dasar dan kinerja dasar dapat disebut sebagai pengujian pendukung bila diperlukan di BAB IV, bukan menjadi subbab utama.

## 4. Subbab Yang Perlu Ditambah

1. `2.1.4 Surat`
2. `2.1.11 LRS`
3. Penajaman `2.1.6 Basis Data MySQL`
4. Penajaman `2.1.10 ERD`
5. Penelitian terkait yang sudah diverifikasi, terutama tentang:
   - Sistem informasi inventaris aset.
   - Sistem surat masuk/keluar atau disposisi surat.
   - Sistem informasi sekolah berbasis web.
   - Implementasi CodeIgniter atau PHP/MySQL bila relevan.
   - Pengujian black-box pada aplikasi web.

## 5. Subbab Yang Perlu Dihapus

1. Subbab `Sistem` sebagai topik terpisah.
2. World Wide Web sebagai subbab.
3. Internet sebagai subbab.
4. Web Browser sebagai subbab.
5. HTML sebagai subbab utama.
6. CSS sebagai subbab utama.
7. JavaScript sebagai subbab utama.
8. SQL sebagai subbab utama.
9. Bootstrap sebagai subbab utama.
10. UI/UX sebagai subbab utama BAB II.
11. User Acceptance Testing, kecuali nanti ditemukan bukti pelaksanaan UAT.

## 6. Kebutuhan Referensi Per Subbab

| Subbab Final | Kebutuhan Referensi | Status |
|---|---|---|
| 2.1.1 Sistem Informasi | Buku atau artikel ilmiah tentang sistem informasi | [PERLU SITASI] |
| 2.1.2 Website | Buku/artikel/dokumentasi akademik tentang aplikasi website | [PERLU SITASI] |
| 2.1.3 Inventaris Aset | Sumber tentang inventaris aset/barang milik lembaga/sekolah | [PERLU SITASI] |
| 2.1.4 Surat | Sumber tentang administrasi surat masuk/keluar | [PERLU SITASI] |
| 2.1.5 Disposisi Surat | Sumber tentang disposisi surat dan tindak lanjut surat masuk | [PERLU SITASI] |
| 2.1.6 Basis Data MySQL | Sumber basis data relasional dan MySQL | [PERLU SITASI] |
| 2.1.7 PHP | Dokumentasi resmi atau buku/artikel tentang PHP | [PERLU SITASI] |
| 2.1.8 CodeIgniter | Dokumentasi resmi CodeIgniter 4 atau sumber akademik | [PERLU SITASI] |
| 2.1.9 UML | Buku/artikel tentang UML dan diagram perancangan | [PERLU SITASI] |
| 2.1.10 ERD | Buku/artikel basis data tentang ERD | [PERLU SITASI] |
| 2.1.11 LRS | Sumber akademik tentang Logical Record Structure | [PERLU SITASI] |
| 2.1.12 Agile Scrum | Sumber Scrum resmi/akademik dan sumber pengembangan perangkat lunak | [PERLU SITASI] |
| 2.1.13 Black-Box Testing | Sumber pengujian perangkat lunak tentang black-box testing | [PERLU SITASI] |
| 2.2 Penelitian Terkait | Minimal beberapa artikel relevan dan terverifikasi | [PERLU CEK REFERENSI] |

## 7. Prioritas Pencarian Referensi

Prioritas 1:

1. Penelitian terkait tentang sistem informasi inventaris aset.
2. Penelitian terkait tentang sistem disposisi surat atau surat masuk/keluar.
3. Penelitian terkait tentang sistem informasi sekolah berbasis web.

Prioritas 2:

1. Sistem informasi.
2. Website.
3. Inventaris aset.
4. Surat.
5. Disposisi surat.

Prioritas 3:

1. Agile Scrum.
2. Black-Box Testing.
3. Pengujian keamanan dasar.
4. Pengujian kinerja dasar.

Prioritas 4:

1. PHP.
2. CodeIgniter 4.
3. MySQL.
4. UML.
5. ERD.
6. LRS.

## 8. Daftar Referensi Lama Yang Harus Dicek

Referensi berikut muncul di naskah lama dan belum boleh dipakai sebelum diverifikasi:

1. `(Sistem, n.d.)`
2. `(Literasi & Indonesia, n.d.)`
3. `(PENGANTAR JARINGAN KOMPUTER, n.d.)`
4. `(I, 2015)`
5. `(Tri et al., n.d.)`
6. `(Jogiyanto, 1995)`
7. `(subtari, 2005)` atau kemungkinan `(Sutabri, 2005)`
8. `(gordon, 1995)`
9. Annisa, Rahayuningsih, dan Anna (2023)
10. Mubarok dan Sutaji (2025)
11. Siswaya dan Setiawan (2025)
12. Pranoto dan Sediyono (2021)
13. Rohmawati (2025)
14. Londa, Wee, dan Radja (2022)

## 9. Rekomendasi Status Penulisan BAB II

BAB II belum disarankan untuk langsung ditulis sebagai draft final penuh karena referensi belum terverifikasi. Tahap yang aman berikutnya adalah:

1. Verifikasi sumber yang sudah disebut dalam BAB II lama.
2. Ganti sumber yang tidak ilmiah, tidak ditemukan, terlalu lama, atau tidak relevan.
3. Kumpulkan referensi valid untuk setiap subbab final.
4. Setelah referensi aman, susun `BAB-II-REVISI-1.md` atau draft BAB II awal sesuai struktur final.

Kerangka BAB II boleh mulai disiapkan, tetapi isi teori final sebaiknya menunggu referensi agar tidak menghasilkan sitasi palsu atau daftar pustaka palsu.

## 10. Catatan Batasan

1. Belum membuat BAB II final.
2. Belum membuat `SKRIPSI.docx`.
3. Belum menambah daftar pustaka.
4. Belum menyimpulkan referensi yang belum ditemukan.
5. Belum mengubah source code, database, diagram, atau screenshot.
