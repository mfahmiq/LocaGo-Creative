# BAB I DAN BAB II READY FOR BAB III

Tanggal dibuat: 2026-07-05
Terakhir diperbarui: 2026-07-05

## 1. Kesimpulan Umum

Status: **SIAP LANJUT BAB III DENGAN CATATAN**

BAB I (`BAB-I-FINAL-ARAH.md`) dan BAB II (`BAB-II-FINAL-ARAH.md`) sudah cukup konsisten dari sisi judul, objek penelitian, role pengguna, fitur aplikasi, metode pengembangan, pendekatan pengujian, batasan deployment, penempatan ERD, dan referensi yang dipakai, sebagaimana dicatat pada `BAB-I-II-CONSISTENCY-CHECK.md`. Kedua bab kini telah dikunci sebagai final arah, bukan final mutlak, dan dapat dijadikan dasar penyusunan BAB III, selama catatan marker yang masih tersisa dan kebutuhan pengecekan APA 7/Mendeley tetap diperhatikan dan diselesaikan sebelum dokumen dianggap final untuk DOCX.

Catatan status terbaru:

1. `BAB-I-FINAL-ARAH.md` sudah dibuat pada 2026-07-05.
2. `BAB-II-FINAL-ARAH.md` sudah dibuat pada tahap sebelumnya.
3. BAB III boleh mulai disusun setelah user atau Maestro menyetujui checkpoint ini.
4. `SKRIPSI.docx` belum dibuat.

## 2. Catatan Yang Masih Tersisa

1. Marker BAB I masih ada: `[PERLU DATA]` (1 kemunculan, pada detail pelaksanaan observasi) dan `[PERLU CEK REFERENSI]` (5 kemunculan, tersebar pada Latar Belakang dan Metode Penelitian).
2. Marker BAB II masih ada: `[PERLU CEK APA 7]` (1 kemunculan, pada subbab 2.1.11 LRS).
3. APA 7 dan Mendeley belum final untuk seluruh referensi BAB II, termasuk perbedaan metadata DOI Mubarok & Sutaji (2025) antara halaman resmi jurnal BSI dan Garuda.
4. Detail observasi BAB I masih perlu data karena marker `[PERLU DATA]` masih ada, yaitu waktu dan bentuk pelaksanaan observasi langsung di SMPI REJIS.
5. LRS masih perlu cek APA 7 karena marker `[PERLU CEK APA 7]` masih ada dan sumbernya berupa jurnal aplikasi/perancangan sistem, bukan buku teori utama.

## 3. Batasan Sebelum BAB III

1. Jangan mengubah judul.
2. Jangan mengubah role aplikasi.
3. Jangan menambahkan fitur final tanpa persetujuan user.
4. Jangan menambahkan klaim deployment produksi.
5. Jangan menambahkan klaim pengujian tingkat lanjut.
6. Jangan mengubah metode dari Agile Scrum.
7. Jangan membuat DOCX sebelum diminta.

## 4. Arah BAB III

BAB III nanti harus membahas:

1. Tinjauan institusi atau objek penelitian.
2. Analisis sistem berjalan.
3. Analisis kebutuhan sistem.
4. Perancangan sistem usulan.
5. Perancangan basis data.
6. Perancangan antarmuka.
7. Rancangan pengujian jika diperlukan sesuai outline.

Catatan: dokumen ini hanya mencatat arah BAB III. Isi BAB III belum ditulis dan tidak dibuat pada tahap ini.
