# BAB I FINAL ARAH REFPATCH 1 NOTES

Tanggal dibuat: 2026-07-05

## 1. Status

File ini adalah patch BAB I untuk menyelesaikan marker `[PERLU CEK REFERENSI]` yang menurut `SKRIPSI-DRAFT-REVIEW-BAB-I-V-MARKER-AUDIT.md` dapat diselesaikan dari file lokal, karena seluruh referensi pendukungnya sudah tersedia di `BAB-II-FINAL-ARAH-REFPATCH-1.md`. Patch ini menghasilkan `BAB-I-FINAL-ARAH-REFPATCH-1.md` sebagai kandidat BAB I terbaru, berdasarkan `BAB-I-FINAL-ARAH.md` tanpa mengubah substansi lain.

## 2. Perubahan

No | Lokasi Marker | Marker Lama | Referensi Pendukung | Status
---|---|---|---|---
1 | 1.1 Latar Belakang — paragraf Sistem Informasi berbasis web | `[PERLU CEK REFERENSI]` | Wahyuni, Muthmainnah, Permana, & Novalima (2025) — sudah dipakai di BAB II subbab 2.1.1 Sistem Informasi dan 2.1.2 Website | SELESAI (sitasi parentetik disisipkan)
2 | 1.1 Latar Belakang — paragraf Agile Scrum | `[PERLU CEK REFERENSI]` | Scrum Guide (2020) — sudah dipakai di BAB II subbab 2.1.12 Agile Scrum | SELESAI (sitasi parentetik disisipkan)
3 | 1.1 Latar Belakang — paragraf pengujian sistem | `[PERLU CEK REFERENSI]` | ISTQB Glossary — sudah dipakai di BAB II subbab 2.1.13 Black-Box Testing | SELESAI (sitasi disisipkan tanpa tahun, mengikuti cara BAB II mengutip sumber ini yang juga belum mencantumkan tahun/versi spesifik)
4 | 1.5.1 Teknik Pengumpulan Data — Studi Pustaka | `[PERLU CEK REFERENSI]` | Kalimat ini merupakan pernyataan metodologis (aturan sumber pustaka), bukan klaim yang butuh satu sitasi tunggal; diselesaikan dengan merujuk balik ke kajian teori BAB II yang sudah diverifikasi | SELESAI (rujukan ke BAB II ditambahkan, bukan sitasi nama-tahun tunggal)
5 | 1.5.2 Model Pengembangan Sistem | `[PERLU CEK REFERENSI]` | Scrum Guide (2020) — sama seperti nomor 2 | SELESAI (sitasi parentetik disisipkan)

## 3. Marker Tersisa

Marker | Jumlah | Lokasi
---|---|---
`[PERLU DATA]` | 1 | 1.5.1 Teknik Pengumpulan Data — Observasi (detail waktu dan bentuk pelaksanaan observasi langsung masih perlu data asli)
`[PERLU CEK REFERENSI]` | 0 | Seluruh 5 kemunculan pada badan teks sudah diselesaikan. Catatan: string `[PERLU CEK REFERENSI]` masih muncul satu kali pada baris status dokumen di awal file sebagai keterangan riwayat patch, bukan sebagai marker aktif yang belum selesai.

Total marker aktif pada `BAB-I-FINAL-ARAH-REFPATCH-1.md`: **1** (turun dari 6 sebelum patch).

## 4. Catatan

1. Tidak ada referensi baru yang dibuat pada patch ini — seluruh sitasi (Wahyuni et al. 2025, Scrum Guide 2020, ISTQB Glossary) diambil langsung dari `BAB-II-FINAL-ARAH-REFPATCH-1.md` yang sudah ada.
2. Semua sitasi tetap perlu dicek Mendeley APA 7 sebelum final, termasuk kelengkapan metadata Wahyuni et al. (2025) yang masih berstatus BELUM LENGKAP dan ISTQB Glossary yang belum memiliki tahun/versi spesifik (lihat `REFERENSI-APA7-MENDELEY-CHECK-UPDATED.md`).
3. Marker `[PERLU DATA]` pada bagian observasi tidak dihapus karena masih membutuhkan data asli dari narasumber/pihak sekolah, bukan data yang tersedia di file lokal.
