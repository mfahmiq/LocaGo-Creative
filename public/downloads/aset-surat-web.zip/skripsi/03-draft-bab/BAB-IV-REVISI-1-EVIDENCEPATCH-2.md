# BAB IV

# IMPLEMENTASI DAN PENGUJIAN SOFTWARE

Status dokumen: evidence patch 2 dari `BAB-IV-REVISI-1-EVIDENCEPATCH-1.md`. Pada putaran pengisian data kedua ini (`USER-DATA-INPUT-ROUND-2.md`), hasil validasi menunjukkan seluruh field spesifikasi hardware/software, lokasi folder screenshot, dan waktu respons pengujian kinerja masih berupa placeholder kosong (tidak ada nilai nyata baru). Pencarian menyeluruh terhadap 5 nama berkas screenshot yang disebut user juga tidak menemukan satu pun berkas di seluruh workspace. Sesuai instruksi dan hasil validasi, **tidak ada marker tambahan yang diselesaikan pada patch ini** dibandingkan `BAB-IV-REVISI-1-EVIDENCEPATCH-1.md`. Deployment tetap lokal menggunakan Laragon seperti pada patch sebelumnya. Kandidat BAB IV terbaru, belum menjadi naskah final DOCX.

## 4.1. Desain

Desain aplikasi meliputi rancangan basis data, arsitektur perangkat lunak, dan antarmuka pengguna. Aplikasi dibangun menggunakan CodeIgniter 4 dengan pola Model-View-Controller (MVC), bahasa pemrograman PHP, dan basis data MySQL/MariaDB, dikembangkan serta diuji pada lingkungan lokal menggunakan Laragon.

Pengembangan aplikasi ini menggunakan pendekatan Agile Scrum secara hati-hati sebagai kerangka dokumentasi berbasis fitur yang benar-benar ditemukan pada aplikasi, bukan sebagai catatan historis pelaksanaan ceremony Scrum. Penerapannya dijelaskan sebagai berikut:

1. Kebutuhan fitur aplikasi dipetakan ke dalam *product backlog*, misalnya kebutuhan login dan role, manajemen pengguna, inventaris aset, transaksi/peminjaman aset, surat masuk, disposisi, surat keluar, laporan, dan backup.
2. *Product backlog* tersebut dipetakan ke dalam kelompok pengerjaan modul (*sprint mapping*) berdasarkan modul aplikasi yang saling berkaitan, misalnya fondasi akses pengguna dan dashboard, modul master inventaris aset, modul transaksi/peminjaman aset, modul administrasi surat dan disposisi, serta modul laporan dan backup.
3. Setiap kelompok modul menghasilkan *increment* berupa bagian aplikasi yang dapat diuji, sebagaimana terlihat pada route, controller, model, dan view yang sudah tersedia untuk setiap modul.
4. Hasil setiap modul diuji pada tahap *testing* (lihat 4.3) melalui black-box testing, pengujian keamanan dasar, dan pengujian kinerja dasar.

Penelitian ini tidak menuliskan tanggal sprint, nama Scrum Master, Product Owner, Daily Scrum, Sprint Review, atau Sprint Retrospective sebagai fakta historis karena bukti rinci pelaksanaan ceremony tersebut belum ditemukan pada workspace ini.

### 4.1.1. Database

Rancangan basis data aplikasi terdiri atas 9 tabel bisnis utama dan 1 tabel sistem CodeIgniter (`migrations`). Rancangan ini bersumber dari `app/Database/Migrations/`, `database/*.sql`, `app/Controllers/ErdController.php`, `DATABASE_ERD_AUDIT.md`, dan `skripsi/04-diagram-dan-gambar/LRS_DRAFT.md`.

**Entity Relationship Diagram**

Relasi antar tabel yang ditemukan:

1. Satu `asset_categories` memiliki banyak `assets`.
2. Satu `asset_locations` memiliki banyak `assets`.
3. Satu `users` dapat membuat banyak `incoming_letters`, `outgoing_letters`, `asset_transactions`, dan melakukan banyak `dispositions`.
4. Satu `incoming_letters` dapat memiliki banyak `dispositions`.
5. Satu `asset_transactions` dapat memiliki banyak `asset_transaction_items`.
6. Satu `assets` dapat muncul pada banyak `asset_transaction_items`.

Gambar IV.1 Entity Relationship Diagram (sumber: `skripsi/04-diagram-dan-gambar/diagram-output/erd-final.svg`)

**Logical Record Structure**

LRS berikut disajikan dalam bentuk tabel struktur record per tabel bisnis, mengacu pada `LRS_DRAFT.md` (Tabel IV.1 Logical Record Structure, karena LRS disajikan tabular, bukan sebagai gambar).

*users*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas unik pengguna
2 | name | VARCHAR(120) | - | Nama lengkap pengguna
3 | username | VARCHAR(80) | UQ | Username login unik
4 | password_hash | VARCHAR(255) | - | Hash password, bukan password asli
5 | role | VARCHAR(30) | - | Hak akses: admin, operator, pimpinan
6 | is_active | TINYINT(1) | - | Status aktif akun
7 | last_login_at | DATETIME | - | Waktu login terakhir
8 | created_at | DATETIME | - | Waktu data dibuat
9 | updated_at | DATETIME | - | Waktu data diperbarui

*asset_categories*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas kategori aset
2 | name | VARCHAR(120) | UQ | Nama kategori aset
3 | description | TEXT | - | Keterangan kategori
4 | created_at | DATETIME | - | Waktu data dibuat
5 | updated_at | DATETIME | - | Waktu data diperbarui

*asset_locations*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas lokasi aset
2 | name | VARCHAR(120) | UQ | Nama lokasi atau ruangan
3 | description | TEXT | - | Keterangan lokasi
4 | created_at | DATETIME | - | Waktu data dibuat
5 | updated_at | DATETIME | - | Waktu data diperbarui

*assets*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas aset
2 | code | VARCHAR(80) | UQ | Kode aset unik
3 | name | VARCHAR(160) | - | Nama aset
4 | category_id | INT UNSIGNED | FK | Relasi ke `asset_categories.id`
5 | location_id | INT UNSIGNED | FK | Relasi ke `asset_locations.id`
6 | quantity | INT(11) | - | Jumlah unit aset
7 | condition_status | VARCHAR(40) | IDX | Kondisi aset
8 | acquisition_year | INT(4) | - | Tahun perolehan
9 | funding_source | VARCHAR(120) | - | Sumber dana
10 | value | DECIMAL(14,2) | - | Nilai aset
11 | custodian | VARCHAR(120) | - | Penanggung jawab
12 | photo | VARCHAR(255) | - | Path foto aset
13 | notes | TEXT | - | Catatan aset
14 | created_at | DATETIME | - | Waktu data dibuat
15 | updated_at | DATETIME | - | Waktu data diperbarui

*asset_transactions*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas transaksi aset
2 | transaction_code | VARCHAR(80) | UQ | Kode transaksi unik
3 | borrower_unit | VARCHAR(160) | - | Unit peminjam
4 | borrower_name | VARCHAR(160) | - | Nama peminjam
5 | purpose | TEXT | - | Tujuan peminjaman
6 | loan_date | DATE | IDX | Tanggal pinjam
7 | expected_return_date | DATE | - | Target tanggal kembali
8 | actual_return_date | DATE | - | Tanggal kembali aktual
9 | status | VARCHAR(50) | IDX | Status transaksi
10 | notes | TEXT | - | Catatan transaksi
11 | created_by | INT UNSIGNED | FK | Relasi ke `users.id`
12 | created_at | DATETIME | - | Waktu data dibuat
13 | updated_at | DATETIME | - | Waktu data diperbarui

*asset_transaction_items*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas item transaksi
2 | asset_transaction_id | INT UNSIGNED | FK | Relasi ke `asset_transactions.id`
3 | asset_id | INT UNSIGNED | FK | Relasi ke `assets.id`
4 | quantity | INT(11) | - | Jumlah aset dipinjam
5 | condition_before | VARCHAR(50) | - | Kondisi sebelum dipinjam
6 | condition_after | VARCHAR(50) | - | Kondisi setelah kembali
7 | notes | TEXT | - | Catatan item
8 | created_at | DATETIME | - | Waktu data dibuat
9 | updated_at | DATETIME | - | Waktu data diperbarui

*incoming_letters*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas surat masuk
2 | letter_number | VARCHAR(120) | - | Nomor surat
3 | letter_date | DATE | - | Tanggal surat
4 | received_date | DATE | IDX | Tanggal diterima
5 | sender | VARCHAR(160) | - | Pengirim surat
6 | subject | VARCHAR(200) | - | Perihal surat
7 | priority | VARCHAR(50) | - | Prioritas surat
8 | summary | TEXT | - | Ringkasan isi surat
9 | attachment | VARCHAR(255) | - | Path lampiran
10 | status | VARCHAR(50) | IDX | Status proses surat
11 | created_by | INT UNSIGNED | FK | Relasi ke `users.id`
12 | created_at | DATETIME | - | Waktu data dibuat
13 | updated_at | DATETIME | - | Waktu data diperbarui

*dispositions*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas disposisi
2 | incoming_letter_id | INT UNSIGNED | FK | Relasi ke `incoming_letters.id`
3 | target_unit | VARCHAR(160) | - | Unit tujuan disposisi
4 | instruction | TEXT | - | Instruksi disposisi
5 | due_date | DATE | - | Batas tindak lanjut
6 | status | VARCHAR(50) | IDX | Status disposisi
7 | disposed_by | INT UNSIGNED | FK | Relasi ke `users.id`
8 | created_at | DATETIME | - | Waktu data dibuat
9 | updated_at | DATETIME | - | Waktu data diperbarui

*outgoing_letters*

No | Field | Tipe Data | Key | Keterangan
---|---|---|---|---
1 | id | INT(11) UNSIGNED | PK | Identitas surat keluar
2 | letter_number | VARCHAR(120) | - | Nomor surat
3 | letter_date | DATE | IDX | Tanggal surat
4 | recipient | VARCHAR(160) | - | Penerima surat
5 | destination_unit | VARCHAR(160) | - | Unit tujuan
6 | subject | VARCHAR(200) | - | Perihal surat
7 | attachment | VARCHAR(255) | - | Path lampiran
8 | status | VARCHAR(50) | IDX | Status pengiriman
9 | receiver_name | VARCHAR(120) | - | Nama penerima di tujuan
10 | received_date | DATE | - | Tanggal diterima tujuan
11 | delivery_notes | TEXT | - | Catatan pengiriman
12 | created_by | INT UNSIGNED | FK | Relasi ke `users.id`
13 | created_at | DATETIME | - | Waktu data dibuat
14 | updated_at | DATETIME | - | Waktu data diperbarui

Catatan: tabel `migrations` merupakan tabel sistem CodeIgniter dan tidak dimasukkan sebagai LRS bisnis utama. Belum ditemukan tabel khusus backup atau log aktivitas; fitur backup membaca metadata seluruh tabel basis data, sedangkan laporan mengambil data dari tabel modul bisnis masing-masing.

### 4.1.2. Software Architecture

Aplikasi menggunakan arsitektur MVC CodeIgniter 4. Route didefinisikan pada `app/Config/Routes.php`, dilindungi oleh filter `auth` untuk memastikan pengguna sudah login dan filter `role` untuk membatasi akses sesuai peran (`app/Filters/AuthFilter.php`, `app/Filters/RoleFilter.php`). Controller menangani logika proses (`app/Controllers/*.php`), model menangani akses data (`app/Models/*.php`), dan view menampilkan antarmuka (`app/Views/*`). Aplikasi juga memakai pustaka pendukung `SimplePdf` untuk mencetak bukti transaksi aset dan `LetterDateExtractor` untuk membantu ekstraksi tanggal lampiran surat, serta trait `HandlesUploads` untuk penanganan unggah berkas.

Diagram pendukung yang sudah tersedia sebagai bahan rancangan arsitektur:

- Gambar IV.2 Use Case Diagram Sistem (`diagram-output/use-case-diagram.svg`)
- Gambar IV.3 Activity Diagram Login (`diagram-output/activity-login.svg`)
- Gambar IV.4 Activity Diagram Inventaris Aset (`diagram-output/activity-inventaris-aset.svg`)
- Gambar IV.5 Activity Diagram Transaksi Aset (`diagram-output/activity-transaksi-aset.svg`)
- Gambar IV.6 Activity Diagram Surat Masuk dan Disposisi (`diagram-output/activity-surat-masuk-disposisi.svg`)
- Gambar IV.7 Activity Diagram Surat Keluar (`diagram-output/activity-surat-keluar.svg`)
- Gambar IV.8 Sequence Diagram Login (`diagram-output/sequence-login.svg`)
- Gambar IV.9 Sequence Diagram Transaksi Aset (`diagram-output/sequence-transaksi-aset.svg`)
- Gambar IV.10 Sequence Diagram Disposisi Surat (`diagram-output/sequence-disposisi-surat.svg`)
- Gambar IV.11 Arsitektur MVC Sistem (`diagram-output/arsitektur-mvc.svg`)

Seluruh diagram di atas sudah tersedia sebagai file source Mermaid dan output SVG (status: ADA). `DIAGRAM_QUALITY_REVIEW.md` mencatat bahwa Use Case Diagram, ERD, Class Diagram, dan sebagian Activity Diagram yang panjang perlu perhatian layout (misalnya landscape/lampiran) saat dimasukkan ke DOCX.

Deployment Diagram (`diagram-output/deployment-diagram.svg`) tersedia sebagai gambar pendukung opsional untuk menjelaskan konteks lingkungan lokal/Laragon, bukan sebagai subbab utama; diagram ini dapat dicantumkan di bagian ini atau pada 4.4.2 Spesifikasi Hardware dan Software sesuai kebutuhan. Class Diagram (`diagram-output/class-diagram.svg`) tersedia sebagai referensi internal, tetapi tidak digunakan sebagai gambar/subbab utama sesuai batasan outline.

### 4.1.3. User Interface

Tampilan antarmuka aplikasi ditunjukkan melalui screenshot yang diambil setelah login lokal menggunakan akun demo, tanpa menampilkan credential. Data yang tampil pada sebagian screenshot merupakan data uji/dummy yang sengaja dibuat untuk keperluan verifikasi (`APPLICATION_VERIFICATION.md`).

No | Halaman | Status Screenshot | Caption/Catatan
---|---|---|---
1 | Login | ADA — `screenshots/01-login.png` | Gambar IV.12 Tampilan Halaman Login
2 | Dashboard | ADA — `screenshots/21-dashboard-final-tanpa-erd.png` (versi final tanpa menu ERD); pendukung: `screenshots/22-sidebar-final-admin.png` | Gambar IV.13 Tampilan Dashboard; Gambar IV.14 Tampilan Sidebar Admin
3 | Manajemen Pengguna | `[PERLU CEK SCREENSHOT]` — belum ada berkas screenshot khusus, meskipun `/users` terverifikasi HTTP 200 dengan role admin | -
4 | Inventaris Aset — daftar | ADA — `screenshots/03-data-aset.png` | Gambar IV.15 Tampilan Halaman Inventaris Aset
5 | Inventaris Aset — form tambah | ADA — `screenshots/04-tambah-aset.png` | Gambar IV.16 Tampilan Form Tambah Aset
6 | Inventaris Aset — form edit | ADA — `screenshots/12-edit-data-aset.png` | Gambar IV.17 Tampilan Form Edit Aset
7 | Inventaris Aset — detail | ADA — `screenshots/13-detail-data-aset.png` | Gambar IV.18 Tampilan Detail Aset
8 | Transaksi Aset — daftar | `[PERLU CEK SCREENSHOT]` — belum ada berkas screenshot khusus daftar transaksi | -
9 | Transaksi Aset — form/detail | ADA — `screenshots/14-transaksi-aset.png` (detail transaksi dummy) | Gambar IV.19 Tampilan Detail Transaksi Aset
10 | Surat Masuk — daftar | ADA — `screenshots/05-surat-masuk.png` | Gambar IV.20 Tampilan Halaman Surat Masuk
11 | Surat Masuk — form tambah | `[PERLU CEK SCREENSHOT]` — belum ada berkas screenshot khusus form tambah | -
12 | Surat Masuk — detail dan lampiran | ADA — `screenshots/15-upload-surat-masuk.png`, `screenshots/20-hasil-upload-lampiran.png` | Gambar IV.21 Tampilan Detail Surat Masuk dan Lampiran
13 | Disposisi Surat — daftar | ADA — `screenshots/06-disposisi-surat.png` | Gambar IV.22 Tampilan Halaman Disposisi
14 | Disposisi Surat — form/detail | ADA — `screenshots/16-form-disposisi.png`, `screenshots/17-detail-disposisi.png` | Gambar IV.23 Tampilan Form dan Detail Disposisi
15 | Surat Keluar — daftar | ADA — `screenshots/07-surat-keluar.png` | Gambar IV.24 Tampilan Halaman Surat Keluar
16 | Surat Keluar — form tambah | `[PERLU CEK SCREENSHOT]` — belum ada berkas screenshot khusus form tambah | -
17 | Surat Keluar — detail | ADA — `screenshots/18-surat-keluar.png` | Gambar IV.25 Tampilan Detail Surat Keluar
18 | Laporan — halaman utama | ADA — `screenshots/08-laporan.png` | Gambar IV.26 Tampilan Halaman Laporan
19 | Laporan — cetak/print | `[PERLU CEK SCREENSHOT]` — belum ada berkas screenshot khusus tampilan cetak | -
20 | Backup | ADA — `screenshots/09-backup.png` | Gambar IV.27 Tampilan Halaman Backup

Catatan: `screenshots/10-erd-database.png` tidak digunakan sebagai bukti antarmuka operasional karena menu ERD Database sudah disembunyikan dari navigasi aplikasi final; ERD tetap ditempatkan sebagai artefak rancangan basis data pada 4.1.1, bukan sebagai halaman aplikasi.

## 4.2. Code Generation

Aplikasi dibangun menggunakan CodeIgniter 4 dengan pola MVC. Bagian ini menampilkan potongan kode inti yang sudah diverifikasi aman untuk dikutip (tidak memuat credential, password, token, API key, session, atau data sensitif).

**Autentikasi (`app/Controllers/AuthController.php`)**

```php
public function attempt()
{
    $rules = [
        'username' => 'required',
        'password' => 'required',
    ];

    if (! $this->validate($rules)) {
        return redirect()->back()->withInput()->with('error', 'Username dan password wajib diisi.');
    }

    $model = new UserModel();
    $user  = $model->verifyLogin(
        trim((string) $this->request->getPost('username')),
        (string) $this->request->getPost('password')
    );

    if (! $user) {
        return redirect()->back()->withInput()->with('error', 'Username atau password tidak sesuai.');
    }

    $this->session->regenerate(true);

    $this->session->set([
        'isLoggedIn' => true,
        'user'       => [
            'id'       => $user['id'],
            'name'     => $user['name'],
            'username' => $user['username'],
            'role'     => $user['role'],
        ],
    ]);

    return redirect()->to('/dashboard')->with('success', 'Selamat datang, ' . $user['name'] . '.');
}
```

Potongan kode di atas menunjukkan validasi input wajib, verifikasi kredensial melalui `UserModel::verifyLogin()`, regenerasi sesi setelah login berhasil, dan penyimpanan data pengguna (tanpa password) ke sesi.

**Pembatasan Akses Berdasarkan Role (`app/Filters/RoleFilter.php`)**

```php
public function before(RequestInterface $request, $arguments = null)
{
    $allowedRoles = $arguments ?? [];
    $user         = session('user') ?? [];
    $currentRole  = $user['role'] ?? null;

    if ($allowedRoles !== [] && ! in_array($currentRole, $allowedRoles, true)) {
        return redirect()->to('/dashboard')->with('error', 'Akses ditolak untuk role Anda.');
    }
}
```

Potongan kode di atas menunjukkan mekanisme pembatasan akses berbasis role: filter membaca role dari sesi pengguna dan menolak akses (redirect ke dashboard) jika role tidak termasuk daftar peran yang diizinkan pada definisi route.

**Inventaris Aset (`app/Controllers/AssetsController.php`)**

Controller ini mengelola CRUD aset melalui method `index()`, `create()`, `store()`, `show()`, `edit()`, `update()`, dan `destroy()`. Method `index()` membangun query dengan filter opsional berdasarkan kata kunci, kategori, lokasi, dan kondisi aset. Method `store()`/`update()` memvalidasi keunikan kode aset menggunakan rule `is_unique[assets.code]` (dengan pengecualian id saat update), lalu menyimpan foto melalui trait `HandlesUploads` dengan pembatasan jenis berkas (`jpg`, `jpeg`, `png`, `webp`) dan ukuran maksimum. Method privat `findOrCreateLocation()` memungkinkan operator menambahkan lokasi baru langsung dari form aset apabila lokasi yang dicari belum tersedia di data referensi. Method `destroy()` dibatasi untuk role admin melalui filter route dan turut menghapus berkas foto terkait agar folder unggahan tetap rapi.

**Transaksi/Peminjaman Aset (`app/Controllers/AssetTransactionsController.php`)**

Method `store()` mengumpulkan item aset multi-baris melalui method privat `collectItems()` (membaca input `asset_id[]`, `quantity[]`, `condition_before[]`), kemudian memvalidasi ketersediaan stok melalui `assertItemsAvailable()` yang menghitung jumlah aset tersedia dikurangi jumlah yang sedang dipinjam pada transaksi berstatus aktif. Penyimpanan header transaksi dan item dilakukan dalam satu database transaction (`$db->transStart()`/`transComplete()`) agar data tidak tersimpan sebagian jika terjadi kegagalan. Method `completeReturn()` menutup transaksi aktif dengan mencatat status akhir (`dikembalikan`, `rusak_saat_kembali`, `hilang`, atau `dibatalkan`) beserta kondisi tiap item setelah kembali. Method `pdf()` memanggil pustaka `SimplePdf` untuk menghasilkan bukti transaksi dalam bentuk berkas PDF yang dapat diunduh.

**Surat Masuk dan Disposisi (`app/Controllers/IncomingLettersController.php`, `app/Controllers/DispositionsController.php`)**

Method `store()` pada `IncomingLettersController` menyimpan surat masuk dengan status awal tetap `menunggu_disposisi` dan memanggil trait `HandlesUploads` untuk lampiran (`pdf`, `jpg`, `jpeg`, `png`, `webp`). Method `extractDate()` adalah endpoint AJAX yang memanggil pustaka `LetterDateExtractor` untuk mencoba membaca tanggal dari berkas lampiran yang baru dipilih, tanpa menyimpan data surat, sehingga operator dapat memakai hasil ekstraksi sebagai bantuan pengisian tanggal. Method `dispose()` menyimpan data disposisi baru (`target_unit`, `instruction`, `due_date`) melalui `DispositionModel` sekaligus mengubah status surat masuk menjadi `didisposisikan`. Pada `DispositionsController`, method `updateStatus()` menyinkronkan status disposisi dengan status surat masuk melalui pemetaan tetap (`pending` → `didisposisikan`, `proses` → `dalam_proses`, `selesai` → `selesai`, `diarsipkan` → `diarsipkan`).

**Surat Keluar (`app/Controllers/OutgoingLettersController.php`)**

Method `store()`/`update()` memvalidasi status surat keluar terhadap daftar tetap (`dicatat`, `siap_dikirim`, `terkirim`, `diterima_tujuan`, `diarsipkan`) melalui rule `in_list`. Method `updateDelivery()` mewajibkan pengisian `receiver_name` dan `received_date` ketika status diubah menjadi `diterima_tujuan`, sehingga bukti penerimaan surat tetap tercatat.

**Laporan (`app/Controllers/ReportsController.php`)**

Method privat `reportData()` memilih salah satu dari lima jenis laporan (`assets`, `incoming`, `outgoing`, `dispositions`, `asset-transactions`) menggunakan ekspresi `match`, masing-masing dengan filter tanggal/status melalui method privat `applyDateAndStatusFilters()`. Method `csv()` membentuk berkas CSV langsung menggunakan fungsi bawaan PHP `fputcsv()` tanpa pustaka pihak ketiga, sedangkan method `print()` menampilkan versi cetak melalui view terpisah (`reports/print`).

**Backup (`app/Controllers/BackupController.php`)**

Method `index()` menampilkan daftar tabel basis data melalui `db_connect()->listTables()`. Method `download()` membentuk dump SQL secara manual: untuk setiap tabel, sistem mengambil struktur tabel melalui kueri `SHOW CREATE TABLE`, lalu menyisipkan seluruh baris data melalui pernyataan `INSERT INTO` yang di-escape menggunakan `db_connect()->escape()`, sebelum hasil akhirnya dikirim sebagai berkas unduhan `.sql`. Method ini tidak menampilkan maupun mencatat kredensial koneksi database.

Uraian di atas disusun berdasarkan pembacaan langsung berkas controller yang bersangkutan pada 2026-07-05, tanpa mengubah kode aplikasi maupun menampilkan potongan kode yang memuat data sensitif.

## 4.3. Testing

Pengujian sistem mencakup black-box testing, pengujian keamanan dasar, dan pengujian kinerja dasar, sesuai keputusan yang sudah disepakati pada BAB I. Pengujian tidak mencakup penetration testing, load testing, stress testing, atau benchmark server produksi.

### Black-Box Testing

Tabel berikut bersumber dari `BLACKBOX_TEST_SCENARIOS.md` (pembaruan 2026-07-04 setelah pengujian CRUD terkontrol). Seluruh data uji menggunakan data dummy/uji, bukan data operasional asli sekolah, dan tidak mencantumkan credential.

No | Fitur | Skenario | Hasil Yang Diharapkan | Hasil Pengujian | Status
---|---|---|---|---|---
BB-01 | Login | Membuka halaman login | Halaman login tampil | Halaman login merespons HTTP 200 | valid
BB-02 | Login | Login dengan data valid | Pengguna masuk ke dashboard sesuai role | Login berhasil dan diarahkan ke dashboard | valid
BB-03 | Login | Login dengan data tidak valid | Sistem menolak login dan menampilkan pesan gagal | Tetap berada di halaman login | valid
BB-04 | Akses Route | Mengakses dashboard tanpa login | Sistem mengarahkan ke login | HTTP 302 redirect ke login | valid
BB-05 | Dashboard | Membuka dashboard setelah login | Ringkasan data, grafik, dan monitoring tampil | `/dashboard` merespons HTTP 200 setelah login | valid
BB-06 | Pengguna | Admin membuka daftar pengguna | Daftar pengguna tampil | `/users` merespons HTTP 200 dengan role admin | valid
BB-07 | Pengguna | Admin menambah pengguna | Data pengguna tersimpan dan tampil di daftar | Data pengguna dummy nonaktif tersimpan dan tampil di daftar | valid
BB-08 | Aset | Membuka daftar aset | Daftar aset tampil | `/assets` merespons HTTP 200 setelah login | valid
BB-09 | Aset | Menambah aset valid | Data aset tersimpan | Data aset dummy tersimpan dan muncul di daftar | valid
BB-10 | Aset | Menambah aset tanpa field wajib | Sistem menampilkan validasi gagal | Sistem kembali ke form tambah aset | valid
BB-11 | Aset | Filter daftar aset | Daftar aset terfilter sesuai input | Filter kode dummy menampilkan aset uji | valid
BB-12 | Aset | Upload foto aset valid | Foto tersimpan dan tampil pada detail | Upload PNG dummy diterima saat tambah aset | valid
BB-13 | Aset | Upload foto tidak valid | Sistem menolak upload | Sistem kembali ke form tambah aset dan tidak membuat link detail record | valid
BB-14 | Transaksi Aset | Membuka daftar transaksi aset | Daftar transaksi tampil | `/asset-transactions` merespons HTTP 200 setelah login | valid
BB-15 | Transaksi Aset | Membuat transaksi aset valid | Transaksi tersimpan dengan status awal | Transaksi aset dummy tersimpan dan detail merespons HTTP 200 | valid
BB-16 | Transaksi Aset | Membuat transaksi tanpa item aset | Sistem menampilkan validasi gagal | Sistem kembali ke form transaksi aset | valid
BB-17 | Transaksi Aset | Mencatat pengembalian aset | Transaksi berubah sesuai status pengembalian | Status transaksi berubah menjadi dikembalikan | valid
BB-18 | Transaksi Aset | Mengunduh PDF transaksi | File PDF transaksi dapat diunduh | Route PDF merespons HTTP 200 `application/pdf` | valid
BB-19 | Surat Masuk | Membuka daftar surat masuk | Daftar surat masuk tampil | `/incoming-letters` merespons HTTP 200 setelah login | valid
BB-20 | Surat Masuk | Menambah surat masuk valid | Data surat masuk tersimpan | Surat masuk dummy tersimpan dan detail merespons HTTP 200 | valid
BB-21 | Surat Masuk | Menambah surat masuk tanpa field wajib | Sistem menampilkan validasi gagal | Sistem kembali ke form surat masuk | valid
BB-22 | Surat Masuk | Upload lampiran valid | Lampiran tersimpan | Upload PDF dummy diterima saat tambah surat masuk | valid
BB-23 | Surat Masuk | Ekstraksi tanggal dari lampiran | Sistem mencoba membaca tanggal dari lampiran | Endpoint ekstraksi tanggal merespons HTTP 200 | valid
BB-24 | Disposisi | Membuat disposisi surat masuk | Disposisi tersimpan dan status surat berubah | Disposisi dummy tersimpan dari detail surat masuk | valid
BB-25 | Disposisi | Mengubah status disposisi | Status disposisi dan status surat sinkron | Status disposisi dummy berubah menjadi selesai | valid
BB-26 | Surat Keluar | Membuka daftar surat keluar | Daftar surat keluar tampil | `/outgoing-letters` merespons HTTP 200 setelah login | valid
BB-27 | Surat Keluar | Menambah surat keluar valid | Data surat keluar tersimpan | Surat keluar dummy tersimpan dan detail merespons HTTP 200 | valid
BB-28 | Surat Keluar | Update status diterima tujuan tanpa penerima/tanggal | Sistem menolak dan meminta data penerima/tanggal | Sistem kembali ke detail surat keluar tanpa data penerima lengkap | valid
BB-29 | Surat Keluar | Update status pengiriman valid | Status surat keluar diperbarui | Status surat keluar berubah menjadi diterima tujuan | valid
BB-30 | Laporan | Membuka halaman laporan | Halaman pilihan/filter laporan tampil | `/reports` merespons HTTP 200 setelah login | valid
BB-31 | Laporan | Menampilkan laporan aset | Laporan aset tampil | `/reports/assets` merespons HTTP 200 setelah login | valid
BB-32 | Laporan | Export CSV laporan | File CSV dihasilkan | `/reports/assets/csv` merespons HTTP 200 | valid
BB-33 | Laporan | Cetak laporan | Tampilan cetak laporan muncul | `/reports/assets/print` merespons HTTP 200 | valid
BB-34 | Backup | Membuka halaman backup sebagai admin | Halaman backup tampil | `/backup` merespons HTTP 200 dengan role admin | valid
BB-35 | Backup | Mengunduh backup database | File SQL backup diunduh | `POST /backup/download` merespons HTTP 200 | valid
BB-36 | Role Access | Operator mengakses halaman pengguna | Sistem menolak/redirect sesuai role | HTTP 302 redirect ke dashboard | valid
BB-37 | Role Access | Pimpinan mengakses form tambah aset | Sistem menolak/redirect sesuai role | HTTP 302 redirect ke dashboard | valid
BB-38 | ERD | Membuka halaman ERD setelah login | Halaman ERD tampil | `/erd` merespons HTTP 200 setelah login | valid
BB-39 | Aset | Membuka form tambah aset | Form tambah aset tampil | `/assets/create` merespons HTTP 200 | valid
BB-40 | Transaksi Aset | Membuka form transaksi aset | Form transaksi aset tampil | `/asset-transactions/create` merespons HTTP 200 | valid
BB-41 | Surat Masuk | Membuka form surat masuk | Form surat masuk tampil | `/incoming-letters/create` merespons HTTP 200 | valid
BB-42 | Surat Keluar | Membuka form surat keluar | Form surat keluar tampil | `/outgoing-letters/create` merespons HTTP 200 | valid

Ringkasan: total skenario 42, valid 42, gagal 0, belum diverifikasi 0 (per pembaruan `BLACKBOX_TEST_SCENARIOS.md` 2026-07-04). Pengujian delete tidak dilakukan karena aturan tahap audit melarang penghapusan data lama.

### Pengujian Keamanan Dasar

Pengujian keamanan dasar berikut diturunkan dari skenario black-box yang relevan dengan autentikasi, sesi, dan otorisasi. Pengujian ini bukan penetration testing dan tidak mengklaim sistem aman dari seluruh jenis serangan.

No | Aspek | Skenario | Hasil Yang Diharapkan | Hasil Pengujian | Status
---|---|---|---|---|---
1 | Autentikasi | Login dengan kredensial tidak valid (BB-03) | Sistem menolak login | Tetap berada di halaman login | valid
2 | Sesi dan otorisasi akses halaman | Mengakses route terproteksi tanpa sesi login (BB-04) | Sistem mengarahkan ke halaman login | HTTP 302 redirect ke login | valid
3 | Otorisasi berbasis role | Operator mengakses halaman manajemen pengguna (BB-36) | Sistem menolak dan mengarahkan sesuai role | HTTP 302 redirect ke dashboard | valid
4 | Otorisasi berbasis role | Pimpinan mengakses form tambah aset (BB-37) | Sistem menolak dan mengarahkan sesuai role | HTTP 302 redirect ke dashboard | valid
5 | Validasi input | Menyimpan data aset/surat masuk tanpa field wajib (BB-10, BB-21) | Sistem menampilkan validasi gagal dan tidak menyimpan data kosong | Sistem kembali ke form dengan data tidak tersimpan | valid
6 | Validasi unggah berkas | Mengunggah foto aset dengan format tidak valid (BB-13) | Sistem menolak berkas dan tidak membuat record | Sistem kembali ke form tambah aset tanpa membuat record detail | valid

Catatan: pengujian keamanan dasar pada tahap ini terbatas pada mekanisme yang tercakup di atas dan belum mencakup pengujian kerentanan tingkat lanjut (misalnya SQL injection, XSS, atau serangan otomatis) karena termasuk kategori pengujian keamanan tingkat lanjut yang berada di luar ruang lingkup penelitian.

### Pengujian Kinerja Dasar

No | Proses | Lingkungan Uji | Hasil Pengamatan | Catatan
---|---|---|---|---
1 | Membuka halaman login | Lokal/Laragon, server development CodeIgniter | Merespons HTTP 200 | `[PERLU DATA HASIL PENGUJIAN]` untuk waktu respons dalam satuan waktu
2 | Membuka dashboard setelah login | Lokal/Laragon | Merespons HTTP 200 | `[PERLU DATA HASIL PENGUJIAN]`
3 | Membuka daftar data aset | Lokal/Laragon | Merespons HTTP 200 | `[PERLU DATA HASIL PENGUJIAN]`
4 | Membuka daftar surat masuk | Lokal/Laragon | Merespons HTTP 200 | `[PERLU DATA HASIL PENGUJIAN]`
5 | Menghasilkan laporan dan export CSV | Lokal/Laragon | Merespons HTTP 200 | `[PERLU DATA HASIL PENGUJIAN]`
6 | Mengunduh backup database | Lokal/Laragon | Merespons HTTP 200 | `[PERLU DATA HASIL PENGUJIAN]`

Pengujian kinerja dasar pada tahap ini baru mencatat keberhasilan proses (respons HTTP 200) pada lingkungan lokal Laragon, belum mencatat waktu respons secara terukur dalam satuan waktu (milidetik/detik). Pengukuran waktu respons formal ditandai `[PERLU DATA HASIL PENGUJIAN]` dan perlu dilengkapi sebelum bagian ini disebut final. Pengujian ini tidak dimaksudkan sebagai *load testing*, *stress testing*, atau benchmark server produksi.

## 4.4. Support

Dukungan yang dibutuhkan agar aplikasi dapat dijalankan mencakup perangkat lunak dan perangkat keras pengembangan/pengujian. Karena aplikasi hanya dikembangkan dan diuji pada lingkungan lokal, batasan ini ditulis secara eksplisit.

### 4.4.1. Publikasi Software

Publikasi software pada penelitian ini dibatasi pada lingkungan lokal menggunakan Laragon. Berdasarkan konfirmasi user (`USER-DATA-INPUT-ROUND-1.md` bagian 2), aplikasi tetap dijalankan dan diuji pada lingkungan lokal menggunakan Laragon dan belum memiliki rencana penerapan pada server internal sekolah maupun layanan hosting. Aplikasi belum dipublikasikan secara daring (online), belum berjalan pada lingkungan produksi, dan belum digunakan secara resmi oleh SMPI REJIS.

Publikasi software dapat dikembangkan pada tahap lanjutan apabila pihak sekolah berencana menerapkan aplikasi pada server internal atau layanan hosting di kemudian hari, dengan penyesuaian konfigurasi lingkungan (`ENVIRONMENT`), keamanan tambahan, dan proses deployment yang belum menjadi bagian dari penelitian ini.

### 4.4.2. Spesifikasi Hardware dan Software

**Spesifikasi Software (Terverifikasi)**

1. Sistem operasi: Windows (versi spesifik `[PERLU DATA]`).
2. Laragon sebagai lingkungan pengembangan lokal.
3. PHP CLI versi `8.4.10` (terverifikasi pada `APPLICATION_VERIFICATION.md`).
4. Composer versi `2.8.9` (terverifikasi).
5. CodeIgniter framework versi `v4.7.3` (terverifikasi pada `composer.lock`).
6. MySQL/MariaDB sebagai sistem manajemen basis data.
7. Web browser untuk mengakses aplikasi (nama dan versi browser `[PERLU DATA]`).
8. Editor pengembangan, misalnya Visual Studio Code, jika digunakan (versi `[PERLU DATA]`; penggunaan editor spesifik belum diverifikasi pada workspace ini).

**Spesifikasi Hardware**

Spesifikasi perangkat keras (laptop/PC) yang digunakan untuk pengembangan dan pengujian belum tersedia pada workspace ini, termasuk prosesor, RAM, dan penyimpanan. `[PERLU DATA]`

Deployment Diagram (`diagram-output/deployment-diagram.svg`) dapat digunakan sebagai gambar pendukung opsional pada bagian ini untuk menggambarkan konteks lingkungan lokal/Laragon, tanpa menjadi subbab utama.
