# USER DATA INPUT ROUND 2

Tanggal dibuat: 2026-07-05

## 1. Status

File ini mencatat hasil validasi data yang dikirim user pada putaran kedua pengisian (merujuk `MARKER-RESOLUTION-DATA-CHECKLIST.md` dan `USER-DATA-INPUT-ROUND-1.md`). Hasil validasi menunjukkan **seluruh field pada putaran ini masih berupa placeholder kosong** (`[TULIS DATA NYATA]`, `[TULIS ANGKA NYATA]`, `[TULIS DATA NYATA ATAU TULIS BELUM ADA]`, `[TULIS LOKASI FOLDER SCREENSHOT YANG BENAR]`), tidak ada satu pun nilai nyata baru yang diisi. Sesuai batasan wajib dan bagian Validasi Sebelum Mengerjakan pada instruksi kerja, tidak ada marker tambahan yang diselesaikan pada putaran ini. Tidak ada data yang dikarang untuk mengisi kekosongan ini.

## 2. Spesifikasi Hardware/Software Yang Diisi

**Status: TIDAK ADA YANG TERISI BARU.**

Field | Nilai Yang Dikirim User | Status
---|---|---
Processor | `[TULIS DATA NYATA]` | Kosong (placeholder)
RAM | `[TULIS DATA NYATA]` | Kosong (placeholder)
Storage | `[TULIS DATA NYATA]` | Kosong (placeholder)
Sistem Operasi | `[TULIS DATA NYATA]` | Kosong (placeholder)
Versi Windows | `[TULIS DATA NYATA]` | Kosong (placeholder)
Browser | `[TULIS DATA NYATA]` | Kosong (placeholder)
Versi Browser | `[TULIS DATA NYATA]` | Kosong (placeholder)
Code Editor | `[TULIS DATA NYATA]` | Kosong (placeholder)
Versi Code Editor | `[TULIS DATA NYATA]` | Kosong (placeholder)
Local Server | Laragon | Terisi, tetapi bukan marker (sudah tercantum di BAB IV sejak sebelumnya tanpa marker)
Versi Laragon | `[TULIS DATA NYATA ATAU TULIS BELUM ADA]` | Kosong (placeholder); bukan marker BAB IV yang ada saat ini
PHP | "gunakan versi yang sudah terverifikasi dari workspace jika tersedia" | Instruksi memakai data lama (PHP CLI 8.4.10); bukan marker karena sudah tercantum verified tanpa marker di BAB IV
Database | "gunakan versi yang sudah terverifikasi dari workspace jika tersedia" | Tidak ada versi MySQL/MariaDB spesifik yang terverifikasi di workspace ini; bukan marker karena BAB IV hanya menyebut "MySQL/MariaDB" tanpa marker versi
Framework | CodeIgniter 4 | Terisi, tetapi bukan marker (sudah terverifikasi v4.7.3 sebelumnya tanpa marker)

**Kesimpulan: keempat marker `[PERLU DATA]` pada BAB IV 4.4.2 (versi Windows, versi browser, versi editor, spesifikasi hardware) tetap tidak dapat diselesaikan pada putaran ini.**

## 3. Screenshot Yang Ditemukan

**Tidak ada.**

## 4. Screenshot Yang Tidak Ditemukan

Kolom "Lokasi folder screenshot" pada input user masih berupa placeholder (`[TULIS LOKASI FOLDER SCREENSHOT YANG BENAR]`), sehingga tidak ada lokasi baru yang dapat diperiksa. Sebagai validasi tambahan, dilakukan pencarian menyeluruh (bukan hanya folder contoh) terhadap seluruh workspace untuk kelima nama berkas yang disebut user:

No | Nama File | Hasil Pencarian Menyeluruh Di Seluruh Workspace | Status
---|---|---|---
1 | `screenshot-manajemen-pengguna.png` | Tidak ditemukan | Marker `[PERLU CEK SCREENSHOT]` dipertahankan
2 | `screenshot-daftar-transaksi-aset.png` | Tidak ditemukan | Marker `[PERLU CEK SCREENSHOT]` dipertahankan
3 | `screenshot-form-tambah-surat-masuk.png` | Tidak ditemukan | Marker `[PERLU CEK SCREENSHOT]` dipertahankan
4 | `screenshot-form-tambah-surat-keluar.png` | Tidak ditemukan | Marker `[PERLU CEK SCREENSHOT]` dipertahankan
5 | `screenshot-cetak-laporan.png` | Tidak ditemukan | Marker `[PERLU CEK SCREENSHOT]` dipertahankan

**Kesimpulan: kelima marker `[PERLU CEK SCREENSHOT]` tetap tidak dapat diselesaikan pada putaran ini.**

## 5. Data Pengujian Kinerja Yang Diisi

**Tidak ada.**

## 6. Data Pengujian Kinerja Yang Kosong

No | Proses | Waktu Respons Yang Dikirim User | Status
---|---|---|---
1 | Login | `[TULIS ANGKA NYATA] detik` | Kosong (placeholder, bukan angka nyata)
2 | Dashboard | `[TULIS ANGKA NYATA] detik` | Kosong (placeholder)
3 | Data Aset | `[TULIS ANGKA NYATA] detik` | Kosong (placeholder)
4 | Surat Masuk | `[TULIS ANGKA NYATA] detik` | Kosong (placeholder)
5 | Laporan | `[TULIS ANGKA NYATA] detik` | Kosong (placeholder)
6 | Backup | `[TULIS ANGKA NYATA] detik` | Kosong (placeholder)

**Kesimpulan: ketujuh marker `[PERLU DATA HASIL PENGUJIAN]` (6 baris tabel + 1 kalimat penutup) tetap tidak dapat diselesaikan pada putaran ini.**

## 7. Data Sekolah Yang Diisi

**Tidak ada.**

## 8. Data Sekolah Yang Masih BELUM ADA

Field | Nilai Yang Dikirim User | Status
---|---|---
Profil resmi SMPI REJIS | `[TULIS DATA NYATA ATAU TULIS BELUM ADA]` | Kosong (placeholder, bukan pernyataan "BELUM ADA" yang eksplisit maupun data nyata)
Sejarah singkat SMPI REJIS | `[TULIS DATA NYATA ATAU TULIS BELUM ADA]` | Kosong (placeholder)
Struktur organisasi SMPI REJIS | `[TULIS DATA NYATA ATAU TULIS BELUM ADA]` | Kosong (placeholder)
Detail observasi | `[TULIS DATA NYATA ATAU TULIS BELUM ADA]` | Kosong (placeholder)
Tanggal observasi | `[TULIS DATA NYATA ATAU TULIS BELUM ADA]` | Kosong (placeholder)
Pihak yang ditemui | `[TULIS DATA NYATA ATAU TULIS BELUM ADA]` | Kosong (placeholder)

**Kesimpulan: marker `[PERLU DATA]` pada BAB I (observasi) dan ketiga marker `[PERLU DATA]` pada BAB III (profil, sejarah, struktur organisasi) tetap tidak dapat diselesaikan pada putaran ini.**

## 9. Catatan

Seluruh field pada putaran kedua ini masih berupa placeholder template (`[TULIS ...]`), sama seperti pada putaran pertama, kecuali bagian deployment yang sudah diselesaikan sebelumnya pada `EVIDENCEPATCH-1`. Tidak ada data kosong yang dikarang untuk menurunkan jumlah marker. Seluruh 23 marker yang tersisa setelah `EVIDENCEPATCH-1` **tetap dipertahankan tanpa perubahan** pada putaran ini.
