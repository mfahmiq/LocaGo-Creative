# Aset Surat Web

Aplikasi web CodeIgniter 4 untuk manajemen aset sekolah, surat masuk, surat keluar, disposisi, laporan, dan backup data.

## Fitur Utama

- Dashboard ringkasan aset dan surat.
- Manajemen aset, kategori aset, lokasi aset, dan transaksi aset.
- Manajemen surat masuk, surat keluar, unggahan lampiran, dan disposisi.
- Manajemen user berbasis role: admin, operator, dan pimpinan.
- Laporan dan tampilan cetak.
- Backup database melalui aplikasi.

## Kebutuhan

- PHP 8.2 atau lebih baru.
- Composer.
- MySQL atau MariaDB.
- Ekstensi PHP umum untuk CodeIgniter 4: intl, mbstring, json, mysqlnd, curl.

## Setup Lokal

1. Install dependency:

```bash
composer install
```

2. Salin konfigurasi environment:

```bash
cp env .env
```

3. Sesuaikan nilai database di `.env`:

```ini
database.default.hostname = localhost
database.default.database = aset_surat_web
database.default.username = root
database.default.password =
database.default.DBDriver = MySQLi
```

4. Jalankan migration dan seeder:

```bash
php spark migrate
php spark db:seed DatabaseSeeder
```

5. Jalankan server pengembangan:

```bash
php spark serve
```

Default URL: `http://localhost:8080`.

## Akun Demo

- `admin` / `admin123`
- `operator` / `operator123`
- `pimpinan` / `pimpinan123`

## Catatan Repo Public

File `.env`, dependency `vendor/`, cache, log, session, dan file upload runtime tidak disimpan ke git. Dump SQL di folder `database/` disimpan sebagai referensi struktur, sedangkan data awal aplikasi tersedia melalui migration dan seeder.
