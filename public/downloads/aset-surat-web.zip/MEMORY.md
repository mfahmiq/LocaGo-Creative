# MEMORY.md

Status: aktif
Terakhir diperbarui: 2026-07-05

## Checkpoint Implementasi Pengajuan Inventaris (2026-07-05)

Modul aplikasi baru `Pengajuan Inventaris` sudah diimplementasikan pada project CodeIgniter 4 lokal.

File source baru:

1. `app/Database/Migrations/2026-07-05-000001_CreateInventoryRequestTables.php`
2. `app/Models/InventoryRequestModel.php`
3. `app/Models/InventoryRequestItemModel.php`
4. `app/Controllers/InventoryRequestsController.php`
5. `app/Views/inventory_requests/index.php`
6. `app/Views/inventory_requests/create.php`
7. `app/Views/inventory_requests/edit.php`
8. `app/Views/inventory_requests/show.php`
9. `app/Views/inventory_requests/partials/form.php`

File source lama yang diubah terbatas:

1. `app/Config/Routes.php`
2. `app/Views/layouts/main.php`
3. `app/Helpers/app_helper.php`

Backup source sebelum perubahan tersimpan di `skripsi/07-backup/source-code/inventory-request-20260705-172004/`.

Migration baru sudah dijalankan dengan `php spark migrate` dan menambah tabel `inventory_requests` serta `inventory_request_items`. Data uji dummy pengajuan inventaris dibuat untuk verifikasi lokal. Tidak ada migration lama, seeder, file SQL asli, PDF pedoman/outline, BAB I-V utama, `SKRIPSI.docx`, atau `SKRIPSI-FINAL.docx` yang dibuat/diubah pada tahap ini.

Hasil uji lokal modul Pengajuan Inventaris:

1. Login role admin, operator, dan pimpinan: valid.
2. Daftar pengajuan, form tambah, detail, approval, dan PDF: valid.
3. Create pengajuan valid: valid.
4. Validasi pengajuan tanpa item: valid.
5. Approve oleh pimpinan: valid.
6. Reject tanpa catatan: validasi menahan proses.
7. Reject dengan catatan: valid.
8. Operator mencoba approve: ditolak.
9. Akses tanpa login ke `/inventory-requests`: redirect ke login.

Dokumentasi baru:

1. `skripsi/08-log-kerja/INVENTORY_REQUEST_FEATURE_IMPLEMENTATION.md`
2. `skripsi/02-data-aplikasi/INVENTORY_REQUEST_DATABASE_PATCH.md`
3. `skripsi/02-data-aplikasi/INVENTORY_REQUEST_ROUTE_AUDIT.md`
4. `skripsi/03-draft-bab/SKRIPSI-IMPACT-PENGAJUAN-INVENTARIS.md`
5. `skripsi/03-draft-bab/BLACKBOX-PENGAJUAN-INVENTARIS.md`

Screenshot baru:

1. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-daftar-pengajuan-inventaris.png`
2. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-form-pengajuan-inventaris.png`
3. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-detail-pengajuan-inventaris.png`
4. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-approval-pengajuan-inventaris.png`
5. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-pdf-pengajuan-inventaris.png`

Catatan batasan: integrasi otomatis ke Surat Keluar dan Transaksi Aset tidak dibuat karena berisiko mengubah alur existing. Integrasi tersebut hanya direkomendasikan sebagai pengembangan lanjutan. Status `diproses`, `direalisasikan`, dan `selesai` sudah disiapkan sebagai nilai status, tetapi belum dibuatkan flow operasional khusus.

## Status Project

Tahap saat ini: Codex evidence patch 1 selesai (2026-07-05) — bukti verifikasi aplikasi dan screenshot yang diklaim dari Codex sudah direkonsiliasi secara read-only. Tidak ditemukan bukti baru bertanggal 2026-07-05 di file verifikasi atau folder screenshot; checkpoint black-box terbaru yang tertulis di workspace tetap 42 valid, 0 gagal, 0 belum diverifikasi. Total marker logis BAB I-V tetap 19. Draft review BAB I-IV dan DOCX draft review sudah tersedia, tetapi `SKRIPSI.docx`/dokumen final belum dibuat.

Claude Code mulai digunakan sebagai eksekutor lokal tambahan setelah Codex dan Copilot. Claude Code telah membuat:

1. `skripsi/08-log-kerja/CLAUDE_CODE_HANDOFF_CHECKPOINT.md` — checkpoint status workspace, judul, objek, teknologi, metode, role, fitur, status BAB I/BAB II, dan langkah aman berikutnya.
2. `skripsi/03-draft-bab/BAB-I-II-CONSISTENCY-CHECK.md` — audit konsistensi BAB I dan BAB II terhadap judul, objek, role, fitur, metode, pengujian, deployment, ERD, referensi, dan marker. Hasil: seluruh aspek KONSISTEN.
3. `skripsi/03-draft-bab/BAB-I-II-READY-FOR-BAB-III.md` — kesimpulan SIAP LANJUT BAB III DENGAN CATATAN, mencatat marker tersisa dan arah BAB III (tanpa isi BAB III).
4. `skripsi/03-draft-bab/BAB-I-FINAL-ARAH.md` — naskah BAB I dikunci sebagai final arah pada 2026-07-05, berdasarkan `BAB-I-REVISI-1.md`, setara dengan `BAB-II-FINAL-ARAH.md`. Substansi tidak diubah, hanya menghapus baris status dokumen kerja dan metadata judul.
5. `skripsi/03-draft-bab/BAB-I-FINAL-ARAH-NOTES.md` — catatan dasar penguncian, marker tersisa, dan rekomendasi untuk BAB I final arah.

Status terbaru:

1. `BAB-I-FINAL-ARAH.md` sudah dibuat.
2. `BAB-I-FINAL-ARAH-NOTES.md` sudah dibuat.
3. BAB I dikunci sebagai final arah, bukan final mutlak.
4. BAB II sudah dikunci sebagai final arah, bukan final mutlak (`BAB-II-FINAL-ARAH.md` dan `BAB-II-FINAL-ARAH-NOTES.md`).
5. BAB I dan BAB II siap menjadi dasar penyusunan BAB III dengan catatan.
6. Marker BAB I (`BAB-I-FINAL-ARAH.md`) = 6 marker (`[PERLU DATA]` x1, `[PERLU CEK REFERENSI]` x5), masih perlu dibereskan sebelum DOCX final.
7. Marker BAB II (`BAB-II-FINAL-ARAH.md`) = 1 marker (`[PERLU CEK APA 7]` x1 pada subbab 2.1.11 LRS), masih perlu cek APA 7.
8. `skripsi/03-draft-bab/BAB-III-DRAFT-PLAN.md` sudah dibuat pada tahap sebelumnya dan sudah **direvisi pada 2026-07-05** mengikuti koreksi outline (lihat poin 14-19 di bawah).
9. `skripsi/03-draft-bab/BAB-III-DATA-NEEDED.md` sudah dibuat dan sudah diperbarui pada 2026-07-05 menyesuaikan koreksi outline.
10. `SKRIPSI.docx` belum dibuat.

### Koreksi Struktur BAB III Dan BAB IV (2026-07-05)

14. Struktur BAB III dan BAB IV dikoreksi berdasarkan outline resmi dari user. Struktur BAB III versi awal (judul "ANALISIS DAN PERANCANGAN SISTEM" dengan subbab 3.1 Tinjauan Institusi sampai 3.7 Rancangan Pengujian, termasuk Use Case Diagram, Activity Diagram, Sequence Diagram, ERD, LRS, dan Perancangan Antarmuka sebagai bagian BAB III) **DIBATALKAN**.
15. BAB III yang benar: **ANALISIS DAN PERANCANGAN APLIKASI** — 3.1 Tinjauan Perusahaan (3.1.1 Sejarah Perusahaan, 3.1.2 Struktur Organisasi), 3.2 Analisis Aplikasi (3.2.1 Analisis Masalah, 3.2.2 Analisis Kebutuhan), 3.3 Rancangan Algoritma.
16. BAB IV yang benar: **IMPLEMENTASI DAN PENGUJIAN SOFTWARE** — 4.1 Desain (4.1.1 Database, 4.1.2 Software Architecture, 4.1.3 User Interface), 4.2 Code Generation, 4.3 Testing, 4.4 Support (4.4.1 Publikasi Software, 4.4.2 Spesifikasi Hardware dan Software).
17. Diagram utama (ERD, LRS, spesifikasi tabel) tidak ditempatkan sebagai subbab utama BAB III lagi — ERD, LRS, dan spesifikasi tabel dipindahkan ke BAB IV 4.1.1 Database; Use Case/Activity/Sequence Diagram dan Arsitektur MVC ke BAB IV 4.1.2 Software Architecture; tampilan antarmuka ke BAB IV 4.1.3 User Interface; code generation, testing, dan support tetap sesuai subbab resmi BAB IV.
18. `skripsi/03-draft-bab/OUTLINE-CORRECTION-BAB-III-IV.md` sudah dibuat — mencatat status koreksi, kesalahan struktur sebelumnya, struktur resmi BAB III/BAB IV, dan tabel penempatan artefak lengkap.
19. `skripsi/03-draft-bab/BAB-III-IV-STRUCTURE-FINAL-ARAH.md` sudah dibuat — penguncian arah final struktur BAB III dan BAB IV beserta aturan penulisan masing-masing bab.

### Draft Revisi 1 BAB III Dan BAB IV (2026-07-05)

20. `skripsi/03-draft-bab/BAB-IV-DRAFT-PLAN.md` sudah dibuat — rencana struktur BAB IV, tabel penempatan artefak, data yang dibutuhkan, dan risiko.
21. `skripsi/03-draft-bab/BAB-III-REVISI-1.md` sudah dibuat — draft BAB III (Tinjauan Perusahaan, Analisis Aplikasi, Rancangan Algoritma) mengikuti struktur resmi. Marker: `[PERLU DATA]` x3 (profil, sejarah, struktur organisasi SMPI REJIS belum tersedia).
22. `skripsi/03-draft-bab/BAB-III-REVISI-1-NOTES.md` sudah dibuat — catatan file sumber, marker, data kurang, dan rekomendasi BAB III.
23. `skripsi/03-draft-bab/BAB-IV-REVISI-1.md` sudah dibuat — draft BAB IV (Database dengan ERD/LRS/spesifikasi 9 tabel, Software Architecture dengan diagram Use Case/Activity/Sequence/MVC, User Interface dengan status screenshot, Code Generation dengan kutipan kode `AuthController`/`RoleFilter`, Testing dengan tabel 42 skenario black-box valid + pengujian keamanan dasar + pengujian kinerja dasar, Support). Total marker: 18 (`[PERLU DATA]` x5, `[PERLU CEK SCREENSHOT]` x5, `[PERLU DATA HASIL PENGUJIAN]` x7, `[PERLU CEK BUKTI KODE]` x1).
24. `skripsi/03-draft-bab/BAB-IV-REVISI-1-NOTES.md` sudah dibuat — catatan file sumber, bukti diagram/screenshot/pengujian, dan rekomendasi BAB IV.
25. `skripsi/03-draft-bab/BAB-I-SAMPAI-IV-DRAFT-REVIEW-CHECK.md` sudah dibuat — status gabungan BAB I-IV, tabel marker lengkap (total 28 marker: BAB I=6, BAB II=1, BAB III=3, BAB IV=18), dan syarat sebelum DOCX final.

### Draft Revisi 1 BAB V, Checkpoint Referensi, Dan Kesiapan DOCX (2026-07-05)

26. `skripsi/03-draft-bab/BAB-V-DRAFT-PLAN.md` sudah dibuat — rencana struktur BAB V (5.1 Kesimpulan, 5.2 Saran), dasar penyusunan kesimpulan, dan batasan.
27. `skripsi/03-draft-bab/BAB-V-REVISI-1.md` sudah dibuat — draft kesimpulan (5 poin, menjawab 5 rumusan masalah BAB I) dan saran (9 poin) berdasarkan BAB I, BAB III, dan BAB IV. Marker: `[PERLU CEK SETELAH BAB IV FINAL]` x2 karena BAB IV masih memiliki marker.
28. `skripsi/03-draft-bab/BAB-V-REVISI-1-NOTES.md` sudah dibuat — keterkaitan dengan BAB I/III/IV, marker, dan rekomendasi.
29. `skripsi/03-draft-bab/REFERENSI-APA7-MENDELEY-CHECK.md` sudah dibuat — tabel 18 referensi BAB II dengan status metadata; jumlah jurnal ilmiah saat ini **9**, masih kurang 1 dari syarat minimal 10 jurnal pedoman UBSI (`[PERLU TAMBAH JURNAL]`). File `PEDOMAN-UBSI-2026-RINGKASAN-PROYEK.md` BELUM ADA; dipakai `PEDOMAN_AUDIT.md`/`DOCX_FORMAT_SPEC.md` sebagai gantinya.
30. `skripsi/03-draft-bab/BAB-I-SAMPAI-V-DRAFT-REVIEW-CHECK.md` sudah dibuat — status gabungan BAB I-V, tabel marker lengkap (total **30 marker**: BAB I=6, BAB II=1, BAB III=3, BAB IV=18, BAB V=2), dan 11 poin cek konsistensi (seluruhnya KONSISTEN).
31. `skripsi/03-draft-bab/DOCX-READINESS-CHECK.md` sudah dibuat — DOCX draft untuk review boleh dibuat, DOCX final belum boleh dibuat sampai 30 marker dan kekurangan jurnal dibereskan.
32. BAB I sampai BAB V sudah tersedia sebagai final arah atau draft revisi dan boleh direview user/Maestro.
33. `SKRIPSI.docx` belum dibuat.

### Patch Referensi Jurnal Ke-10 (2026-07-05)

34. Referensi Usnaini, Yasin, & Sianipar (2021) — "Perancangan sistem informasi inventarisasi aset berbasis web menggunakan metode waterfall", Jurnal Manajemen Informatika Jayakarta, Vol. 1 No. 1, hlm. 36-55, DOI 10.52362/jmijayakarta.v1i1.415 — ditambahkan sebagai jurnal ke-10, disediakan dan diverifikasi oleh Maestro.
35. `skripsi/03-draft-bab/BAB-II-FINAL-ARAH-REFPATCH-1.md` sudah dibuat sebagai kandidat BAB II terbaru — menambahkan sitasi Usnaini, Yasin, & Sianipar (2021) pada 2.1.3 Inventaris Aset dan paragraf baru pada 2.2 Penelitian Terkait, tanpa mengubah struktur BAB II. Marker `[PERLU CEK APA 7]` pada 2.1.11 LRS tidak dihapus (tetap 1 marker, sama seperti `BAB-II-FINAL-ARAH.md`).
36. `skripsi/03-draft-bab/BAB-II-FINAL-ARAH-REFPATCH-1-NOTES.md` sudah dibuat — mencatat perubahan, marker tersisa, dan risiko patch.
37. `skripsi/03-draft-bab/REFERENSI-APA7-MENDELEY-CHECK-UPDATED.md` sudah dibuat — jumlah jurnal ilmiah naik dari 9 menjadi **10**, status **TERPENUHI DENGAN CATATAN** (seluruh referensi tetap perlu dicek Mendeley/APA 7).
38. `skripsi/03-draft-bab/BAB-I-SAMPAI-V-DRAFT-REVIEW-CHECK-UPDATED.md` sudah dibuat — merujuk `BAB-II-FINAL-ARAH-REFPATCH-1.md` sebagai kandidat BAB II terbaru; total marker BAB I-V tetap **30** (patch referensi tidak menambah/mengurangi marker inline).
39. `skripsi/03-draft-bab/DOCX-READINESS-CHECK-UPDATED.md` sudah dibuat — DOCX draft boleh dibuat untuk review; DOCX final tetap belum boleh dibuat karena 30 marker dan verifikasi Mendeley/APA 7 belum selesai.
40. Kebutuhan minimal 10 jurnal pada pedoman UBSI (`PEDOMAN_AUDIT.md`) sudah terpenuhi dengan catatan. File lama (`BAB-II-FINAL-ARAH.md`, `REFERENSI-APA7-MENDELEY-CHECK.md`, `BAB-I-SAMPAI-V-DRAFT-REVIEW-CHECK.md`, `DOCX-READINESS-CHECK.md`) tidak dihapus dan tetap tersimpan sebagai versi sebelum patch.

### DOCX Draft Review BAB I-V (2026-07-05)

41. `skripsi/05-final-docx/SKRIPSI-DRAFT-REVIEW-BAB-I-V.docx` sudah dibuat — digabungkan dari `BAB-I-FINAL-ARAH.md`, `BAB-II-FINAL-ARAH-REFPATCH-1.md`, `BAB-III-REVISI-1.md`, `BAB-IV-REVISI-1.md`, dan `BAB-V-REVISI-1.md` menggunakan Python (`python-docx`, diinstal via pip pada tahap ini), tanpa mengubah substansi. Format: A4, margin 3/4/2,5/2,5 cm, Times New Roman 12, spasi 2, judul BAB tengah-kapital-tebal-14, subbab tebal-12, tabel bergaris grid. Berisi banner "DRAFT REVIEW - BUKAN DOKUMEN FINAL" di halaman pertama. Seluruh 30 marker asli dipertahankan utuh dan terverifikasi tidak hilang.
42. `skripsi/05-final-docx/SKRIPSI-DRAFT-REVIEW-BAB-I-V-NOTES.md` sudah dibuat — mencatat status, file sumber, rincian 30 marker, catatan referensi (10 jurnal, Mendeley/APA 7 belum final), catatan finalisasi (data institusi, screenshot, pengujian kinerja, hardware, kode, format akhir DOCX resmi belum diterapkan), dan keputusan bahwa dokumen ini hanya untuk review.
43. Nama file `SKRIPSI-FINAL.docx` sengaja tidak dibuat; hanya `SKRIPSI-DRAFT-REVIEW-BAB-I-V.docx` yang dibuat pada tahap ini.

### Audit Marker DOCX Draft Review (2026-07-05)

44. `skripsi/05-final-docx/SKRIPSI-DRAFT-REVIEW-BAB-I-V-MARKER-AUDIT.md` sudah dibuat — audit rinci 30 marker BAB I-V dengan tabel per marker (lokasi, masalah, sumber penyelesaian, status, rekomendasi) dan pengelompokan kategori:
    - BISA DISELESAIKAN DARI FILE LOKAL: 6 (5 `[PERLU CEK REFERENSI]` BAB I + 1 `[PERLU CEK BUKTI KODE]` BAB IV; 7 berkas controller terkait sudah dikonfirmasi ada).
    - BUTUH DATA USER/SEKOLAH: 5 (1 observasi BAB I + 3 profil/sejarah/struktur organisasi BAB III + 1 rencana deployment BAB IV).
    - BUTUH SCREENSHOT: 5 (BAB IV — manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, cetak laporan; dikonfirmasi belum ada di folder screenshots).
    - BUTUH HASIL PENGUJIAN: 7 (BAB IV — pengukuran waktu respons kinerja dasar, 6 proses + 1 kalimat penutup).
    - BUTUH MENDLEY/APA 7: 1 (BAB II LRS) plus seluruh referensi lain tetap perlu verifikasi Mendeley.
    - BUTUH SPESIFIKASI HARDWARE: 4 (BAB IV — versi Windows/browser/editor + spesifikasi hardware; belum ada berkas spesifikasi baru ditemukan).
    - BUTUH REVIEW MANUAL: 2 (BAB V, bergantung pada penyelesaian marker BAB IV).
45. Rekomendasi prioritas: (1) marker file lokal, (2) screenshot, (3) spesifikasi hardware/software, (4) data institusi SMPI REJIS, (5) pengujian kinerja dasar, (6) Mendeley APA 7 dan format akhir DOCX.
46. Tahap berikutnya adalah menyelesaikan marker prioritas 1-3 (khususnya Prioritas 1 yang tidak butuh data eksternal) sebelum membuat DOCX draft review versi 2.

### Patch Lokal Marker Prioritas 1 (2026-07-05)

47. `skripsi/03-draft-bab/BAB-I-FINAL-ARAH-REFPATCH-1.md` sudah dibuat sebagai kandidat BAB I terbaru — 5 marker `[PERLU CEK REFERENSI]` diselesaikan dengan menyisipkan sitasi Wahyuni, Muthmainnah, Permana, & Novalima (2025), Scrum Guide (2020), dan ISTQB Glossary yang sudah ada di `BAB-II-FINAL-ARAH-REFPATCH-1.md`. Tidak ada referensi baru dibuat. Marker `[PERLU DATA]` (observasi) tetap dipertahankan. Marker BAB I turun dari 6 menjadi **1**.
48. `skripsi/03-draft-bab/BAB-I-FINAL-ARAH-REFPATCH-1-NOTES.md` sudah dibuat — tabel perubahan per marker, marker tersisa, dan catatan.
49. `skripsi/03-draft-bab/BAB-IV-REVISI-1-CODEPATCH-1.md` sudah dibuat sebagai kandidat BAB IV terbaru — marker `[PERLU CEK BUKTI KODE]` diselesaikan dengan uraian code generation naratif untuk 6 modul (Inventaris Aset, Transaksi Aset, Surat Masuk & Disposisi, Surat Keluar, Laporan, Backup) berdasarkan pembacaan langsung 7 berkas controller (`AssetsController`, `AssetTransactionsController`, `IncomingLettersController`, `DispositionsController`, `OutgoingLettersController`, `ReportsController`, `BackupController`), tanpa menempel kode panjang dan tanpa data sensitif. Marker BAB IV turun dari 18 menjadi **17**.
50. `skripsi/03-draft-bab/BAB-IV-REVISI-1-CODEPATCH-1-NOTES.md` sudah dibuat — tabel file kode yang dibaca, perubahan, marker tersisa, dan catatan keamanan.
51. `skripsi/03-draft-bab/BAB-I-SAMPAI-V-MARKER-COUNT-AFTER-LOCALPATCH.md` sudah dibuat — total marker BAB I-V turun dari **30 menjadi 24**, sesuai target perkiraan. Rincian kategori: butuh data user/sekolah 5, butuh screenshot 5, butuh hasil pengujian 7, butuh Mendeley/APA 7 1, butuh spesifikasi hardware 4, butuh review manual 2.
52. BAB II (`BAB-II-FINAL-ARAH-REFPATCH-1.md`), BAB III (`BAB-III-REVISI-1.md`), dan BAB V (`BAB-V-REVISI-1.md`) tidak diubah pada tahap ini karena marker di dalamnya membutuhkan data user/sekolah, Mendeley/APA 7, atau bergantung pada BAB IV.
53. DOCX draft review versi 2 belum dibuat.
54. DOCX final belum boleh dibuat.

### Checklist Data Untuk Patch Berikutnya (2026-07-05)

55. `skripsi/03-draft-bab/MARKER-RESOLUTION-DATA-CHECKLIST.md` sudah dibuat — berisi template kosong (bukan data karangan) untuk: spesifikasi hardware/software (processor, RAM, storage, OS, browser, editor, dsb.), keputusan rencana deployment (opsi A tetap lokal/Laragon secara default aman, B server internal, C hosting), 5 nama file screenshot yang disarankan, template tabel pengujian kinerja dasar (login, dashboard, data aset, surat masuk, laporan, backup), dan template data sekolah (profil, sejarah, struktur organisasi, detail observasi).
56. BAB I sampai BAB V tidak diubah pada tahap ini; total marker tetap 24.
57. Tahap berikutnya menunggu user mengisi data pada checklist, khususnya spesifikasi hardware/software, keputusan deployment, dan screenshot, sebelum `BAB-IV-REVISI-1-EVIDENCEPATCH-1.md` dibuat.
58. DOCX draft review versi 2 belum dibuat.
59. DOCX final belum boleh dibuat.

### Evidence Patch 1 Dari Data User Putaran 1 (2026-07-05)

60. `skripsi/03-draft-bab/USER-DATA-INPUT-ROUND-1.md` sudah dibuat — mencatat jujur bahwa hanya keputusan deployment (Opsi A: tetap lokal Laragon, dengan keterangan nyata dari user) yang terisi data nyata; spesifikasi hardware/software, lokasi/berkas screenshot, data pengujian kinerja, dan data sekolah seluruhnya masih placeholder `[ISI ...]` kosong. Pengecekan folder `skripsi/04-diagram-dan-gambar/screenshots/` mengonfirmasi kelima berkas screenshot yang disebut user (`screenshot-manajemen-pengguna.png`, dst.) tidak ditemukan.
61. `skripsi/03-draft-bab/BAB-I-FINAL-ARAH-DATAPATCH-1.md` dibuat sebagai kandidat BAB I terbaru — tidak ada perubahan substansi karena data observasi belum diisi; marker `[PERLU DATA]` dipertahankan.
62. `skripsi/03-draft-bab/BAB-III-REVISI-1-DATAPATCH-1.md` dibuat sebagai kandidat BAB III terbaru — tidak ada perubahan substansi karena profil/sejarah/struktur organisasi belum diisi; 3 marker `[PERLU DATA]` dipertahankan.
63. `skripsi/03-draft-bab/BAB-IV-REVISI-1-EVIDENCEPATCH-1.md` dibuat sebagai kandidat BAB IV terbaru — marker `[PERLU DATA]` pada 4.4.1 Publikasi Software (rencana deployment) diselesaikan berdasarkan konfirmasi user (Opsi A). Marker lain (4 `[PERLU DATA]` sisa di 4.4.2, 5 `[PERLU CEK SCREENSHOT]`, 7 `[PERLU DATA HASIL PENGUJIAN]`) dipertahankan karena data terkait masih kosong. Marker BAB IV turun dari 17 menjadi **16**.
64. `skripsi/03-draft-bab/BAB-I-SAMPAI-V-MARKER-COUNT-AFTER-EVIDENCEPATCH-1.md` sudah dibuat — total marker BAB I-V turun dari **24 menjadi 23** (hanya 1 marker terselesaikan).
65. `skripsi/03-draft-bab/EVIDENCEPATCH-1-NOTES.md` sudah dibuat — ringkasan data dipakai, tabel marker selesai (1) dan tersisa (22 baris rincian), serta risiko.
66. DOCX draft review versi 2 belum dibuat.
67. DOCX final belum boleh dibuat.

### Evidence Patch 2 Dari Data User Putaran 2 (2026-07-05)

68. `skripsi/03-draft-bab/USER-DATA-INPUT-ROUND-2.md` sudah dibuat — hasil validasi menunjukkan **seluruh field** pada putaran kedua (spesifikasi hardware/software, lokasi folder screenshot, waktu respons pengujian kinerja, data sekolah) masih berupa placeholder template (`[TULIS DATA NYATA]`, dst.), tidak ada nilai nyata baru. Pencarian menyeluruh (`**/screenshot-*.png`) di seluruh workspace mengonfirmasi ulang kelima berkas screenshot yang disebut user tidak ditemukan di mana pun.
69. `skripsi/03-draft-bab/BAB-I-FINAL-ARAH-DATAPATCH-2.md`, `skripsi/03-draft-bab/BAB-III-REVISI-1-DATAPATCH-2.md`, dan `skripsi/03-draft-bab/BAB-IV-REVISI-1-EVIDENCEPATCH-2.md` dibuat sebagai kandidat terbaru BAB I/III/IV — hanya baris status dokumen yang diperbarui (mencatat riwayat validasi putaran 2); tidak ada marker tambahan yang diselesaikan karena tidak ada data nyata baru.
70. `skripsi/03-draft-bab/BAB-I-SAMPAI-V-MARKER-COUNT-AFTER-EVIDENCEPATCH-2.md` sudah dibuat — total marker BAB I-V **tetap 23** (0 marker terselesaikan pada putaran ini).
71. `skripsi/03-draft-bab/EVIDENCEPATCH-2-NOTES.md` sudah dibuat — mencatat bahwa tidak ada marker yang selesai, tabel 23 marker tersisa, dan risiko.
72. DOCX draft review versi 2 belum dibuat.
73. DOCX final belum boleh dibuat.

### Evidence Patch 3 Dari Data User Putaran 3 (2026-07-05)

74. `skripsi/03-draft-bab/USER-DATA-INPUT-ROUND-3.md` sudah dibuat — spesifikasi hardware/software **benar-benar terisi data nyata** (Intel Core i5, RAM 8 GB, 256 GB SSD, Windows 11, Google Chrome, Visual Studio Code, Laragon 6). Lokasi folder screenshot dikonfirmasi (`skripsi/04-diagram-dan-gambar/screenshots`), tetapi pengecekan langsung tetap tidak menemukan kelima kebutuhan screenshot BAB IV. Data pengujian kinerja dan data sekolah dinyatakan eksplisit "BELUM ADA".
75. `skripsi/03-draft-bab/SCREENSHOT-INVENTORY-CHECK.md` sudah dibuat — daftar 22 berkas di folder screenshot, plus pemeriksaan **visual langsung** (bukan hanya nama berkas) terhadap 4 berkas kandidat paling mendekati (`14-transaksi-aset.png`, `15-upload-surat-masuk.png`, `18-surat-keluar.png`, `08-laporan.png`) yang mengonfirmasi seluruhnya adalah halaman detail/menu, bukan daftar/form-tambah/cetak yang dibutuhkan. Kelima kebutuhan screenshot BAB IV: TIDAK DITEMUKAN.
76. `skripsi/03-draft-bab/BAB-IV-REVISI-1-EVIDENCEPATCH-3.md` dibuat sebagai kandidat BAB IV terbaru — 4.4.2 Spesifikasi Hardware dan Software dilengkapi penuh dengan data nyata user, menyelesaikan 4 marker `[PERLU DATA]`. Marker `[PERLU CEK SCREENSHOT]` x5 dan `[PERLU DATA HASIL PENGUJIAN]` x7 tetap dipertahankan. Marker BAB IV turun dari 16 menjadi **12**.
77. `skripsi/03-draft-bab/BAB-I-SAMPAI-V-MARKER-COUNT-AFTER-EVIDENCEPATCH-3.md` sudah dibuat — total marker BAB I-V turun dari **23 menjadi 19** (4 marker terselesaikan, seluruhnya spesifikasi hardware/software).
78. `skripsi/03-draft-bab/EVIDENCEPATCH-3-NOTES.md` sudah dibuat — ringkasan data dipakai, tabel 4 marker selesai dan 19 marker tersisa, serta risiko.
79. Data pengujian kinerja dasar masih belum tersedia (dinyatakan "BELUM ADA" oleh user).
80. Data sekolah masih belum tersedia (dinyatakan "BELUM ADA" oleh user).
81. DOCX draft review versi 2 belum dibuat.
82. DOCX final belum boleh dibuat.

### Codex Evidence Patch 1 Dan Draft Review BAB I-IV (2026-07-05)

83. `skripsi/03-draft-bab/CODEX-EVIDENCE-RECONCILIATION.md` sudah tersedia — merekonsiliasi klaim bukti Codex terhadap file nyata di workspace. Temuan utama: `APPLICATION_VERIFICATION.md`, `BLACKBOX_TEST_SCENARIOS.md`, `BAB_IV_EVIDENCE_READINESS.md`, dan folder screenshot tidak bertambah/berubah pada 2026-07-05; klaim 10 screenshot baru tidak terverifikasi dari workspace ini.
84. `skripsi/03-draft-bab/SCREENSHOT-INVENTORY-CHECK-CODEX.md` sudah tersedia — folder screenshot berisi 22 berkas yang sama. Kelima kebutuhan screenshot BAB IV yang masih kurang tetap belum terpenuhi: manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, dan cetak laporan.
85. `skripsi/03-draft-bab/BLACKBOX-TESTING-RECONCILIATION-CODEX.md` sudah tersedia — angka 23 valid/19 belum diverifikasi dicatat sebagai checkpoint lama sebelum CRUD terkontrol, sedangkan checkpoint terbaru pada file workspace tetap 42 valid, 0 gagal, 0 belum diverifikasi. Tidak ada pengujian baru dijalankan pada patch ini.
86. `skripsi/03-draft-bab/BAB-IV-REVISI-1-CODEX-EVIDENCEPATCH-1.md` sudah tersedia sebagai kandidat BAB IV terbaru — memakai checkpoint black-box terbaru yang tertulis di workspace (42 valid), mempertahankan 5 marker screenshot dan 7 marker waktu respons, serta tidak mengklaim data kinerja, data sekolah, deployment produksi, load testing, stress testing, penetration testing, atau benchmark server produksi.
87. `skripsi/03-draft-bab/BAB-I-SAMPAI-V-MARKER-COUNT-AFTER-CODEX-EVIDENCEPATCH-1.md` dan `skripsi/03-draft-bab/CODEX-EVIDENCEPATCH-1-NOTES.md` sudah tersedia — tidak ada marker baru yang terselesaikan; total marker logis BAB I-V tetap 19.
88. `skripsi/05-final-docx/SKRIPSI-DRAFT-REVIEW-BAB-I-IV-CODEX-PATCH.md` dan `skripsi/05-final-docx/SKRIPSI-DRAFT-REVIEW-BAB-I-IV-CODEX-PATCH.docx` sudah tersedia sebagai draft review, bukan dokumen final. BAB V sengaja tidak disertakan.
89. `skripsi/05-final-docx/SKRIPSI-DRAFT-REVIEW-BAB-I-IV-CODEX-PATCH-NOTES.md` sudah diperbaiki pada sesi ini: marker logis naskah gabungan BAB I-IV adalah 17, sedangkan total proyek BAB I-V tetap 19 bila 2 marker BAB V ikut dihitung.
90. Langkah berikutnya tetap: lengkapi 5 screenshot yang belum ada, isi data waktu respons kinerja dasar, lengkapi data sekolah/observasi, cek Mendeley/APA 7, lalu review BAB V setelah BAB IV benar-benar lengkap.

### Evidence Completion BAB IV Screenshot Dan Kinerja Dasar (2026-07-05)

91. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-manajemen-pengguna.png` sudah dibuat sebagai bukti halaman Manajemen Pengguna.
92. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-daftar-transaksi-aset.png` sudah dibuat sebagai bukti halaman Daftar Transaksi Aset.
93. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-form-tambah-surat-masuk.png` sudah dibuat sebagai bukti Form Tambah Surat Masuk.
94. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-form-tambah-surat-keluar.png` sudah dibuat sebagai bukti Form Tambah Surat Keluar; catatan visual: tampilan lokal halaman ini tertangkap menyempit di sisi kiri sesuai render saat verifikasi.
95. `skripsi/04-diagram-dan-gambar/screenshots/screenshot-cetak-laporan.png` sudah dibuat sebagai bukti halaman Cetak/Preview Laporan.
96. `skripsi/03-draft-bab/SCREENSHOT-CAPTURE-MISSING-5.md` sudah dibuat untuk mencatat hasil pengambilan 5 screenshot.
97. `skripsi/03-draft-bab/PERFORMANCE-BASIC-OBSERVATION.md` sudah dibuat untuk mencatat pengamatan waktu respons sederhana pada lingkungan lokal Laragon: Login 2.860 ms, Dashboard 1.607 ms, Data Aset 1.273 ms, Surat Masuk 1.200 ms, Laporan 1.055 ms, Backup 1.013 ms.
98. `skripsi/03-draft-bab/BAB-IV-EVIDENCE-COMPLETION-REPORT.md` sudah dibuat sebagai laporan pelengkapan bukti BAB IV.
99. Pada tahap ini source code aplikasi tidak diubah, tidak ada CRUD/data bisnis yang diubah, migration tidak dijalankan, seeder tidak dijalankan, BAB I-IV tidak ditulis ulang, dan DOCX baru tidak dibuat. Catatan: login lokal untuk membuka halaman internal dapat memperbarui metadata autentikasi seperti waktu login terakhir akun demo.
100. Tahap berikutnya yang direkomendasikan: buat patch BAB IV berbasis bukti baru untuk menyelesaikan marker screenshot dan waktu respons, tetapi hanya setelah user menyetujui.

### Draft Finalisasi BAB I-IV (2026-07-05)

101. `skripsi/05-final-docx/SKRIPSI-DRAFT-FINALISASI-BAB-I-IV.md` sudah dibuat sebagai naskah BAB I sampai BAB IV yang lebih bersih secara akademik. Banner, status dokumen kerja, dan penyebutan file kerja internal pada isi utama sudah dibersihkan.
102. `skripsi/05-final-docx/SKRIPSI-DRAFT-FINALISASI-BAB-I-IV.docx` sudah dibuat sebagai DOCX draft finalisasi BAB I-IV. Dokumen ini bukan `SKRIPSI-FINAL.docx` dan bukan `SKRIPSI.docx`.
103. `skripsi/05-final-docx/SKRIPSI-DRAFT-FINALISASI-BAB-I-IV-NOTES.md` sudah dibuat untuk mencatat file sumber, istilah internal yang dibersihkan, screenshot yang dimasukkan, data kinerja dasar yang dimasukkan, dan bagian yang masih perlu dilengkapi.
104. `skripsi/03-draft-bab/BAB-IV-REVISI-1-EVIDENCECOMPLETION-PATCH-1.md` sudah dibuat sebagai arsip patch BAB IV setelah 5 screenshot baru dan data pengujian kinerja dasar dimasukkan.
105. Lima screenshot baru sudah ditemukan dan dimasukkan ke bagian BAB IV 4.1.3 User Interface: manajemen pengguna, daftar transaksi aset, form tambah surat masuk, form tambah surat keluar, dan cetak/preview laporan.
106. Data waktu respons sederhana sudah dimasukkan ke BAB IV 4.3 Pengujian Kinerja Dasar: Login 2.860 ms, Dashboard 1.607 ms, Data Aset 1.273 ms, Surat Masuk 1.200 ms, Laporan 1.055 ms, Backup 1.013 ms.
107. Scan isi utama dan DOCX menunjukkan istilah internal yang ditargetkan sudah bersih: `.md`, Codex, Claude, workspace, marker, evidence patch, draft review, data patch, MEMORY.md, AGENTS.md, TOOLS.md, APPLICATION_VERIFICATION.md, BLACKBOX_TEST_SCENARIOS.md, SCREENSHOT-INVENTORY-CHECK-CODEX.md, PERFORMANCE-BASIC-OBSERVATION.md, USER-DATA-INPUT, BAB-IV-REVISI, BAB-I-FINAL-ARAH, BAB-II-FINAL-ARAH, dan BAB-III-REVISI.
108. DOCX dibuat dengan format A4, margin 3 cm/4 cm/2,5 cm/2,5 cm, Times New Roman 12, spasi isi 2, judul BAB tengah kapital tebal 14, subbab tebal 12, tabel bergaris, dan 5 gambar baru. QA struktural: 380 paragraf, 16 tabel, 5 gambar.
109. Render visual DOCX ke PNG belum dapat dilakukan karena LibreOffice/soffice tidak tersedia pada environment saat ini. Pemeriksaan yang selesai adalah QA struktural DOCX dan scan teks.
110. Bagian yang masih perlu dilengkapi sebelum final penuh: detail observasi BAB I, profil resmi SMPI REJIS, sejarah singkat SMPI REJIS, struktur organisasi SMPI REJIS, dan cek final Mendeley/APA 7 pada referensi LRS.
111. Source code aplikasi tidak diubah, database tidak diubah, migration tidak dijalankan, seeder tidak dijalankan, `SKRIPSI-FINAL.docx` tidak dibuat, dan `SKRIPSI.docx` tidak dibuat.

Audit read-only awal sudah dilakukan terhadap workspace `C:\laragon\www\aset-surat-web`. File lama belum diubah. Struktur folder kerja skripsi sudah disetujui user dan dibuat sebagai folder baru di dalam `skripsi/`.

File panduan lintas sesi sudah dibuat:

1. `AGENTS.md`
2. `MEMORY.md`
3. `TOOLS.md`
4. `skripsi/08-log-kerja/WORKSPACE_AUDIT.md`

Render awal pedoman dan outline sudah dibuat sebagai file PNG baru di `skripsi/01-pedoman-dan-outline/`. OCR teks otomatis belum tersedia karena OCR engine lokal belum ditemukan.

Belum dibuat:

1. `SKRIPSI.docx`.
2. Draft BAB II sampai BAB V.
3. File final, daftar isi, daftar pustaka, atau lampiran final.

Sudah dibuat pada tahap terbaru:

1. `skripsi/03-draft-bab/BAB-I-DRAFT-AKHIR.md`.
2. `skripsi/03-draft-bab/BAB-I-SELF-REVIEW.md`.
3. `skripsi/03-draft-bab/BAB-I-REVISI-1.md`.
4. `skripsi/03-draft-bab/BAB-I-REVISION-NOTES.md`.
5. `skripsi/03-draft-bab/BAB-II-USER-DRAFT-LAMA.md`.
6. `skripsi/03-draft-bab/BAB-II-AUDIT.md`.
7. `skripsi/03-draft-bab/BAB-II-REVISION-PLAN.md`.

## Keputusan Yang Sudah Disetujui

1. Workspace utama adalah `C:\laragon\www\aset-surat-web`.
2. File koordinasi lintas sesi berada di root project:
   - `AGENTS.md`
   - `MEMORY.md`
   - `TOOLS.md`
3. Struktur folder kerja skripsi berada di `skripsi/`:
   - `00-getting-started`
   - `01-pedoman-dan-outline`
   - `02-data-aplikasi`
   - `03-draft-bab`
   - `04-diagram-dan-gambar`
   - `05-final-docx`
   - `06-referensi`
   - `07-backup`
   - `08-log-kerja`
4. Untuk tahap ini hanya boleh membuat file baru dan folder baru.
5. PDF asli, SQL asli, file aplikasi, file upload, file runtime, dan file skripsi lama tidak boleh diubah.
6. OCR/render sementara terhadap `pedoman.pdf` dan `outline.pdf` diizinkan setelah file panduan dibuat, dengan hasil disimpan sebagai file baru di `skripsi/01-pedoman-dan-outline/`.
7. Format kampus tidak boleh disimpulkan sebelum hasil OCR atau review visual cukup jelas.
8. Change request aplikasi final disetujui: menu `ERD Database` tidak boleh tampil pada sidebar/menu operasional sekolah.
9. `ErdController.php` tetap dipertahankan sebagai referensi dokumentasi ERD skripsi.
10. Route `/erd` dibuat dev-only melalui guard `ENVIRONMENT === 'development'`; untuk deployment operasional, environment harus non-development agar route tidak didaftarkan.
11. Judul skripsi final: `Perancangan Sistem Terintegrasi Inventaris Aset dan Disposisi Surat Berbasis Web pada SMPI REJIS`.
12. Objek penelitian ditulis konsisten sebagai SMPI REJIS.
13. Fokus sistem: sistem inventaris aset dan disposisi surat berbasis web.
14. Metode pengembangan: Agile Scrum, ditulis secara aman sebagai pendekatan pengembangan/perancangan untuk memetakan kebutuhan, product backlog, sprint mapping, implementasi modul, dan pengujian.
15. Jangan mengarang tanggal sprint, nama tim, Daily Scrum, Sprint Review, Sprint Retrospective, bukti deployment produksi, data sekolah yang tidak tersedia, referensi yang belum ada, atau fitur yang tidak ditemukan.
16. Framework aplikasi: CodeIgniter 4. Database: MySQL/MariaDB. Lingkungan pengembangan dan pengujian: Laragon/local environment.
17. Status deployment yang boleh ditulis: aplikasi dikembangkan dan diuji pada lingkungan lokal/Laragon. Jangan menulis deployment produksi/online/server sekolah tanpa bukti.
18. Data dummy boleh digunakan sebagai bukti pengujian/screenshot dengan label data uji/dummy, bukan data asli sekolah.
19. Diagram besar seperti ERD, class diagram, use case diagram, dan activity diagram panjang boleh ditempatkan landscape atau lampiran jika sulit dibaca.
20. Struktur BAB II yang disetujui:

- `2.1 Tinjauan Pustaka`
- `2.1.1 Sistem Informasi`
- `2.1.2 Website`
- `2.1.3 Inventaris Aset`
- `2.1.4 Surat`
- `2.1.5 Disposisi Surat`
- `2.1.6 Basis Data MySQL`
- `2.1.7 PHP`
- `2.1.8 CodeIgniter`
- `2.1.9 UML`
- `2.1.10 ERD`
- `2.1.11 LRS`
- `2.1.12 Agile Scrum`
- `2.1.13 Black-Box Testing`
- `2.2 Penelitian Terkait`

1. Jangan gunakan subbab `Sistem` secara terpisah pada BAB II.
2. Jangan membuat sitasi palsu dan jangan memakai tool humanizer/paraphrase otomatis untuk mengakali deteksi.
3. Pedoman bahasa yang harus diikuti: kutipan langsung/tidak langsung, Mendeley APA 7, bahasa ilmiah baku, hindari singkatan tidak resmi, tulis kata ulang penuh, dan gunakan istilah asing seperlunya.
4. `SKRIPSI_BLUEPRINT.md` disetujui secara umum dengan koreksi struktur BAB II sesuai poin 20.
5. `DOCX_FORMAT_SPEC.md` sudah dilengkapi aturan bahasa, singkatan, kata ulang, istilah asing, dan pengutipan berdasarkan render pedoman.
6. Draft BAB I sudah dibuat untuk direview user terlebih dahulu sebelum pekerjaan BAB II dimulai.
7. Revisi BAB I dibuat dengan menggabungkan draft Codex, naskah BAB I lama user, transkrip wawancara, pedoman penulisan, audit aplikasi, dan keputusan terbaru project.
8. Pengujian sistem diputuskan mencakup *black-box testing*, pengujian keamanan dasar, dan pengujian kinerja dasar.
9. Pengujian keamanan dasar tidak boleh ditulis sebagai *penetration testing* atau klaim sistem aman dari seluruh serangan.
10. Pengujian kinerja dasar tidak boleh ditulis sebagai *load testing*, *stress testing*, atau benchmark server produksi.
11. BAB II lama/user draft awalnya sudah diaudit secara terbatas saat naskah asli belum tersedia, sehingga `BAB-II-USER-DRAFT-LAMA.md` pernah berfungsi sebagai placeholder sumber.
12. `BAB-II-AUDIT.md` sudah dibuat untuk mencatat audit struktur, risiko subbab melebar, sitasi/referensi, gaya bahasa, dan rekomendasi struktur final.
13. `BAB-II-REVISION-PLAN.md` sudah dibuat untuk memetakan struktur BAB II final, subbab yang ditulis ulang, subbab yang dihapus, kebutuhan referensi, dan prioritas verifikasi referensi.
14. User sudah mengganti `BAB-II-USER-DRAFT-LAMA.md` dengan naskah BAB II lama asli pada 2026-07-04.
15. `BAB-II-AUDIT-V2.md` sudah dibuat berdasarkan naskah BAB II lama asli.
16. `BAB-II-REVISION-PLAN-V2.md` sudah dibuat sebagai rencana revisi BAB II berbasis naskah lama asli.
17. Tahap berikutnya sebelum drafting BAB II final adalah verifikasi referensi dan penelitian terkait.

## Status Referensi BAB II Terbaru

1. DOI Mubarok & Sutaji (2025) sudah dicek dan memakai DOI dari halaman resmi jurnal BSI: 10.31294/bianglala.v13i1.12004.
2. Subbab 2.1.11 LRS sudah memiliki penguat awal dari artikel IJIS Wiratama 2024 dan JSAI 2024.
3. Semua subbab BAB II sudah siap masuk tahap draft awal.
4. BAB II final belum ditulis.
5. Tahap berikutnya adalah membuat `BAB-II-REVISI-1.md` sebagai draft awal BAB II berdasarkan referensi yang sudah diverifikasi, bukan final mutlak.
6. `BAB-II-REVISI-1.md` dan `BAB-II-REVISI-1-NOTES.md` sudah dibuat.
7. `BAB-II-FINAL-ARAH.md` dan `BAB-II-FINAL-ARAH-NOTES.md` sudah dibuat.
8. BAB II dikunci sebagai final arah.
9. BAB II belum final mutlak untuk DOCX.
10. Tahap berikutnya adalah review BAB III atau perapihan BAB I/BAB II sesuai kebutuhan user.

## Artefak Yang Sudah Tersedia

Sumber akademik utama:

1. `skripsi/pedoman.pdf`
   - 18 halaman.
   - Metadata: Pedoman Laporan Skripsi TA Universitas BSI Periode 2025.
   - Teks belum terbaca melalui ekstraksi biasa, kemungkinan scan/gambar.
2. `skripsi/outline.pdf`
   - 9 halaman.
   - Metadata: Handout Skripsi Prodi Teknologi Informasi Periode I Tahun 2024.
   - Teks belum terbaca melalui ekstraksi biasa, kemungkinan scan/gambar.
3. `skripsi/Transkrip Wawancara Riset.pdf`
   - 5 halaman.
   - Teks dapat diekstrak.
   - Memuat konteks penelitian SMPI REJIS, kondisi manual, kendala pencatatan aset dan surat, serta kebutuhan sistem.

Sumber aplikasi utama:

1. `README.md`
   - Ringkasan fitur, kebutuhan, dan setup lokal aplikasi.
2. `app/Config/Routes.php`
   - Route aplikasi dan pembagian akses role.
3. `app/Controllers/`
   - Controller untuk autentikasi, dashboard, aset, transaksi aset, surat masuk, disposisi, surat keluar, laporan, backup, dan ERD.
4. `app/Models/`
   - Model untuk users, assets, categories, locations, incoming letters, outgoing letters, dispositions, dan asset transactions.
5. `app/Views/`
   - View aplikasi untuk semua modul utama.
6. `app/Database/Migrations/`
   - Struktur tabel aplikasi.
7. `database/*.sql`
   - SQL struktur database.
8. `app/Controllers/ErdController.php`
   - Sumber ERD Mermaid dan dokumentasi tabel/relasi untuk referensi pengembangan/skripsi, bukan menu operasional aplikasi final.

Artefak kerja baru:

1. `skripsi/01-pedoman-dan-outline/render-pedoman/`
   - 18 PNG hasil render `pedoman.pdf`.
2. `skripsi/01-pedoman-dan-outline/render-outline/`
   - 9 PNG hasil render `outline.pdf`.
3. `skripsi/01-pedoman-dan-outline/ocr-render-status.md`
   - Catatan status render dan keterbatasan OCR.
4. `skripsi/04-diagram-dan-gambar/diagram-source/`
   - Source Mermaid diagram prioritas BAB III dan BAB IV.
5. `skripsi/04-diagram-dan-gambar/diagram-output/`
   - Output SVG diagram prioritas.
6. `skripsi/04-diagram-dan-gambar/LRS_DRAFT.md`
   - Draft Logical Record Structure tabel bisnis utama.
7. `skripsi/04-diagram-dan-gambar/screenshots/21-dashboard-final-tanpa-erd.png` dan `22-sidebar-final-admin.png`
   - Screenshot final dashboard/sidebar setelah menu ERD disembunyikan.
8. `skripsi/04-diagram-dan-gambar/DIAGRAM_QUALITY_REVIEW.md`
   - Quality gate diagram sebelum drafting BAB.
9. `skripsi/00-getting-started/DOCX_FORMAT_SPEC.md`
   - Spesifikasi awal format DOCX berdasarkan pedoman.
10. `skripsi/00-getting-started/PERSEPSI_PROJECT_CHECKPOINT.md`

- Checkpoint penyamaan persepsi project sebelum drafting.

1. `skripsi/00-getting-started/SKRIPSI_BLUEPRINT.md`

- Blueprint rancangan isi skripsi BAB I sampai BAB V sebelum drafting.

1. `skripsi/03-draft-bab/BAB-I-DRAFT-AKHIR.md`

- Draft BAB I lengkap untuk direview user.

1. `skripsi/03-draft-bab/BAB-I-SELF-REVIEW.md`

- Self-review BAB I sebelum lanjut BAB II.

1. `skripsi/03-draft-bab/BAB-I-REVISI-1.md`

- Revisi penuh BAB I berdasarkan review user, draft Codex, naskah lama user, transkrip, pedoman, audit aplikasi, dan keputusan pengujian.

1. `skripsi/03-draft-bab/BAB-I-REVISION-NOTES.md`

- Catatan perubahan, bagian yang diadopsi dari naskah lama, bagian yang tidak dipakai, keputusan pengujian, dan marker revisi.

1. `skripsi/03-draft-bab/BAB-II-USER-DRAFT-LAMA.md`

- Placeholder sebelumnya sudah diganti user dengan naskah BAB II lama asli pada 2026-07-04.

1. `skripsi/03-draft-bab/BAB-II-AUDIT.md`

- Audit besar BAB II lama secara terbatas, berbasis struktur final, pedoman, outline, audit aplikasi, dan petunjuk risiko dari user.

1. `skripsi/03-draft-bab/BAB-II-REVISION-PLAN.md`

- Rencana revisi BAB II final dan kebutuhan referensi per subbab.

1. `skripsi/03-draft-bab/BAB-II-AUDIT-V2.md`

- Audit ulang BAB II berdasarkan naskah BAB II lama asli; memetakan subbab yang dipakai, direvisi, dipindahkan, dihapus, dan ditambahkan.

1. `skripsi/03-draft-bab/BAB-II-REVISION-PLAN-V2.md`

- Rencana revisi BAB II V2 berbasis naskah lama asli; menekankan verifikasi referensi sebelum drafting BAB II final.

## Ringkasan Aplikasi

Aplikasi berbasis CodeIgniter 4 dengan modul:

1. Login/logout dan role user.
2. Dashboard.
3. Manajemen user.
4. Manajemen aset, kategori aset, lokasi aset.
5. Transaksi aset/peminjaman dan pengembalian.
6. Surat masuk.
7. Disposisi surat.
8. Surat keluar.
9. Laporan dan cetak/CSV.
10. Backup database.

Catatan pembaruan aplikasi final:

1. Halaman/menu ERD database tidak lagi tampil pada navigasi operasional.
2. Route `/erd` bersifat dev-only.
3. ERD tetap menjadi artefak dokumentasi skripsi yang bersumber dari controller/view/migration/database audit.

Database memiliki 10 tabel utama/sistem:

1. `users`
2. `asset_categories`
3. `asset_locations`
4. `assets`
5. `incoming_letters`
6. `dispositions`
7. `outgoing_letters`
8. `asset_transactions`
9. `asset_transaction_items`
10. `migrations`

## Temuan Dari Transkrip Wawancara

Poin awal yang perlu dijadikan dasar analisis kebutuhan:

1. Pencatatan inventaris aset masih manual dan pernah dicoba di Excel tetapi tidak berlanjut.
2. Data aset yang dibutuhkan mencakup barang masuk, barang keluar, letak barang, dan peminjaman barang.
3. Kendala aset mencakup barang keluar/masuk belum tercatat, peminjaman tidak selalu kembali ke tempat semula, dan pencarian/lokasi aset sulit dipantau.
4. Pencatatan surat dan disposisi masih manual.
5. Arsip surat masuk/keluar belum tergabung dan masih terpisah.
6. Dibutuhkan pemantauan status surat, disposisi, arsip digital, dan laporan.
7. Aktor yang disebut dalam kebutuhan meliputi Admin TU, Kepala Sekolah, dan Staff.

## Risiko Dan Konflik Awal

1. `pedoman.pdf` dan `outline.pdf` belum terbaca teks melalui ekstraksi biasa. Render PNG sudah tersedia, tetapi OCR teks otomatis belum tersedia.
2. Format kampus, struktur bab, ketentuan margin/font/spasi/heading, dan aturan sitasi belum boleh disimpulkan sebelum pedoman/outline terbaca.
3. BAB IV wajib diarahkan ke Agile Scrum, tetapi artefak Scrum eksplisit belum ditemukan di workspace.
4. Draft skripsi `.docx` belum ditemukan.
5. Referensi/sitasi terstruktur belum ditemukan.
6. Git worktree sudah memiliki perubahan sebelum pekerjaan ini dimulai; jangan revert atau merapikan perubahan tersebut tanpa instruksi.
7. Ada `.env`, file session, log, debugbar, upload, dan kemungkinan data sensitif. Hindari membaca atau menampilkan isinya.

## File Yang Belum Ditemukan

1. `SKRIPSI.docx`.
2. Draft BAB I sampai BAB V.
3. Daftar pustaka atau database sitasi.
4. File UML/LRS/use case/activity/class/sequence dalam format gambar atau dokumen terpisah.
5. Bukti sprint/backlog/Scrum artefact eksplisit.
6. Template Word kampus, jika ada.

## Langkah Berikutnya

1. Verifikasi referensi untuk setiap subbab BAB II final dan seluruh penelitian terkait yang muncul pada BAB II lama asli.
2. Jangan menulis BAB II final sebelum user menyetujui hasil audit V2, rencana revisi V2, dan daftar referensi yang akan dipakai.
3. Jangan membuat `SKRIPSI.docx` sebelum user meminta secara eksplisit.

## Status Referensi Online BAB II

1. Tidak ada referensi lokal ditemukan pada folder `skripsi/06-referensi/`.
2. Referensi online awal dari Maestro telah dimasukkan ke `skripsi/03-draft-bab/REFERENSI-BAB-II-ONLINE-VERIFIED.md`.
3. Matrix referensi BAB II telah diperbarui di `skripsi/03-draft-bab/REFERENSI-BAB-II-MATRIX-UPDATED.md`.
4. BAB II final belum ditulis.
5. Subbab 2.1.11 LRS masih perlu penguat referensi.
6. Langkah berikutnya adalah review referensi oleh user dan Maestro sebelum mulai `BAB-II-REVISI-1.md`.

## Status Referensi BAB II

1. Copilot sudah membuat file scan referensi lokal BAB II: `skripsi/03-draft-bab/REFERENSI-BAB-II-WORKSPACE-SCAN.md`.
2. Copilot sudah membuat matrix draft kebutuhan referensi BAB II: `skripsi/03-draft-bab/REFERENSI-BAB-II-MATRIX-DRAFT.md`.
3. Copilot sudah membuat aturan drafting BAB II: `skripsi/03-draft-bab/BAB-II-DRAFTING-RULES.md`.
4. BAB II final belum ditulis.
5. Tahap berikutnya adalah menunggu referensi online terverifikasi dari Maestro.
