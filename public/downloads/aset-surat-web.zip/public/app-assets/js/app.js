/*
| -------------------------------------------------------------------
| INTERAKSI UI SMPI REJIS
| -------------------------------------------------------------------
| File ini mengatur SweetAlert2 untuk konfirmasi hapus, Toastr untuk
| notifikasi flash message, tooltip Bootstrap, dan helper kecil dashboard.
|
| Tips Debugging:
| - Jika SweetAlert tidak muncul, pastikan CDN SweetAlert2 dimuat di layout.
| - Jika Toastr error "$ is not defined", pastikan jQuery dimuat sebelum toastr.
*/
(function () {
    'use strict';

    function initTooltips() {
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }

    function initDeleteConfirmations() {
        document.querySelectorAll('.js-confirm-delete').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                event.preventDefault();

                Swal.fire({
                    title: 'Hapus data?',
                    text: form.dataset.message || 'Data yang dihapus tidak dapat dikembalikan.',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#c0392b',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Ya, hapus',
                    cancelButtonText: 'Batal'
                }).then(function (result) {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });
        });
    }

    function initToastr() {
        if (typeof toastr === 'undefined') {
            return;
        }

        toastr.options = {
            closeButton: true,
            progressBar: true,
            newestOnTop: true,
            positionClass: 'toast-top-right',
            timeOut: 3800
        };

        if (window.flashMessages) {
            if (window.flashMessages.success) {
                toastr.success(window.flashMessages.success);
            }

            if (window.flashMessages.error) {
                toastr.error(window.flashMessages.error);
            }
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        initTooltips();
        initDeleteConfirmations();
        initToastr();
    });
})();
