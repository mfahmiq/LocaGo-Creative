# AGENTS.md

Status: aktif
Tanggal dibuat: 2026-07-04
Project: Aset Surat Web dan penyusunan SKRIPSI.docx

## Brief Project

Workspace utama project ini adalah `C:\laragon\www\aset-surat-web`.

Project memiliki dua ruang kerja yang saling berkaitan:

1. Aplikasi web inventaris aset dan disposisi surat berbasis CodeIgniter 4 untuk SMPI REJIS.
2. Penyusunan dokumen akhir skripsi `SKRIPSI.docx`.

Target akhir adalah menghasilkan `SKRIPSI.docx` yang siap diperiksa dosen pembimbing, mengikuti pedoman kampus, handout/outline 156, konteks aplikasi SMPI REJIS, dan sumber data yang tersedia di workspace.

## Instruksi Wajib Setiap Sesi

Sebelum mulai bekerja pada sesi berikutnya, Codex wajib:

1. Membaca `AGENTS.md`.
2. Membaca `MEMORY.md`.
3. Membaca `TOOLS.md`.
4. Meringkas status terakhir.
5. Melanjutkan dari langkah berikutnya yang tercatat di `MEMORY.md`.
6. Tidak mengulang pekerjaan yang sudah selesai kecuali diminta.
7. Tidak mengubah file final tanpa instruksi jelas.

## Tujuan Utama

1. Menyusun `SKRIPSI.docx` berdasarkan sumber yang tersedia.
2. Menjaga struktur bab sesuai pedoman dan outline 156.
3. Menyusun BAB I sampai BAB V secara rapi.
4. Menyesuaikan BAB IV Implementasi dan Pengujian Software dengan pendekatan Agile Scrum.
5. Memastikan tabel, gambar, diagram, lampiran, sitasi, daftar pustaka, dan penomoran mengikuti pedoman.
6. Tidak mengarang data di luar sumber yang tersedia.

## Ruang Lingkup

Pekerjaan yang termasuk ruang lingkup:

1. Audit dokumen pedoman, outline, transkrip, draft, referensi, dan artefak aplikasi.
2. Ekstraksi atau OCR dokumen pedoman/outline jika diperlukan.
3. Analisis aplikasi untuk memahami fitur, modul, database, route, controller, model, view, dan alur sistem.
4. Penyusunan bahan skripsi berdasarkan bukti dari dokumen dan aplikasi.
5. Verifikasi struktur dokumen akhir, format, daftar isi, daftar gambar, daftar tabel, daftar lampiran, sitasi, dan daftar pustaka.

Pekerjaan yang tidak boleh dilakukan tanpa instruksi eksplisit:

1. Mengubah, menghapus, memindahkan, rename, overwrite, atau merapikan file lama.
2. Mengubah source code aplikasi.
3. Mengubah PDF asli, SQL asli, file upload, file runtime, atau file konfigurasi.
4. Membuat `SKRIPSI.docx` sebelum diminta.
5. Membuat draft BAB sebelum diminta.
6. Menjalankan migrasi, seeder, atau operasi database yang mengubah data tanpa izin.

## Sumber Prioritas

Urutan prioritas sumber:

1. Pedoman penulisan skripsi/TA resmi di workspace.
2. Handout/outline 156 atau outline Perancangan Program.
3. Transkrip wawancara dan sumber data lapangan.
4. Draft skripsi yang tersedia, jika nanti ditemukan.
5. Struktur aplikasi web yang ada di workspace.
6. Database, migration, seeder, SQL dump, dan ERD aplikasi.
7. Referensi ilmiah atau sitasi yang tersedia.

Jika ada konflik antara pedoman, outline, draft, dan aplikasi, laporkan konfliknya terlebih dahulu sebelum menulis atau mengubah bagian penting.

## Konvensi Folder

Folder kerja skripsi yang disetujui:

```text
skripsi/
  00-getting-started/
  01-pedoman-dan-outline/
  02-data-aplikasi/
  03-draft-bab/
  04-diagram-dan-gambar/
  05-final-docx/
  06-referensi/
  07-backup/
  08-log-kerja/
```

File koordinasi lintas sesi berada di root project:

```text
AGENTS.md
MEMORY.md
TOOLS.md
```

Gunakan nama file lowercase dan kebab-case untuk artefak kerja baru, kecuali file yang memang disepakati menggunakan nama khusus seperti `SKRIPSI.docx` atau `WORKSPACE_AUDIT.md`.

## Aturan Keamanan

1. Jangan membuka, menyalin, menyimpan, atau menampilkan credential, password, token, API key, cookie, session, atau data sensitif.
2. Jangan membaca isi `.env` kecuali user memberi instruksi eksplisit dan ada kebutuhan yang benar-benar sah.
3. Jangan menampilkan isi file session, cookie, log sensitif, upload privat, atau dump data yang dapat memuat informasi rahasia.
4. Jika perlu membahas credential demo yang tertulis di dokumentasi, rujuk lokasinya tanpa menyalin nilainya.
5. Jangan menyimpan credential dalam file panduan, catatan, draft, atau output.

## Definisi Selesai

Suatu tahap dianggap selesai jika:

1. Output dibuat di lokasi yang disetujui.
2. File lama tidak diubah tanpa izin.
3. Hasil bisa diverifikasi dengan daftar file, ringkasan isi, atau pemeriksaan format.
4. Risiko, konflik, dan pertanyaan terbuka dicatat di `MEMORY.md`.
5. Langkah berikutnya dicatat dengan jelas.

## Catatan Tentang Metode

BAB IV harus disesuaikan dengan pendekatan Agile Scrum, bukan Waterfall/RAD, kecuali pedoman meminta istilah tertentu. Jika pedoman memakai istilah berbeda, jelaskan penyesuaian secara hati-hati dan berbasis sumber.
