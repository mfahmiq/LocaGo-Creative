<?php

namespace App\Models;

use CodeIgniter\Model;

class AssetTransactionItemModel extends Model
{
    /*
    | -------------------------------------------------------------------
    | MODEL DETAIL TRANSAKSI ASET
    | -------------------------------------------------------------------
    | Model ini menyimpan daftar barang dalam transaksi peminjaman. Satu
    | transaksi dapat berisi lebih dari satu aset.
    |
    | Tips Debugging:
    | - Jika item tidak muncul di detail transaksi, cek asset_transaction_id.
    */
    protected $table            = 'asset_transaction_items';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'asset_transaction_id',
        'asset_id',
        'quantity',
        'condition_before',
        'condition_after',
        'notes',
    ];
    protected $useTimestamps = true;

    public function withAsset(): self
    {
        /*
        | -------------------------------------------------------------------
        | QUERY ITEM DENGAN DETAIL ASET
        | -------------------------------------------------------------------
        | Menambahkan kode dan nama aset agar riwayat transaksi mudah dibaca.
        */
        return $this->select('asset_transaction_items.*, assets.code AS asset_code, assets.name AS asset_name')
            ->join('assets', 'assets.id = asset_transaction_items.asset_id', 'left');
    }
}
