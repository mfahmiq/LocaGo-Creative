<?php

namespace App\Models;

use CodeIgniter\Model;

class AssetCategoryModel extends Model
{
    /*
    | -------------------------------------------------------------------
    | MODEL KATEGORI ASET
    | -------------------------------------------------------------------
    | Model referensi untuk mengelompokkan aset sekolah berdasarkan jenisnya.
    |
    | Tips Debugging:
    | - Jika dropdown kategori kosong, cek tabel asset_categories atau jalankan seeder.
    */
    protected $table            = 'asset_categories';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = ['name', 'description'];
    protected $useTimestamps    = true;
}
