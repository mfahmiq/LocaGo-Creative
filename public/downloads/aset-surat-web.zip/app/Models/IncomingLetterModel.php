<?php

namespace App\Models;

use CodeIgniter\Model;

class IncomingLetterModel extends Model
{
    /*
    | -------------------------------------------------------------------
    | MODEL SURAT MASUK
    | -------------------------------------------------------------------
    | Model ini mengelola arsip surat masuk dan status disposisinya.
    |
    | Tips Debugging:
    | - Jika status tidak berubah setelah disposisi, cek update pada controller.
    */
    protected $table            = 'incoming_letters';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'letter_number',
        'letter_date',
        'received_date',
        'sender',
        'subject',
        'priority',
        'summary',
        'attachment',
        'status',
        'created_by',
    ];
    protected $useTimestamps = true;

    public const STATUSES = [
        'menunggu_disposisi' => 'Menunggu Disposisi',
        'didisposisikan'     => 'Didisposisikan',
        'dalam_proses'       => 'Dalam Proses',
        'selesai'            => 'Selesai',
        'diarsipkan'         => 'Diarsipkan',
    ];

    public const PRIORITIES = ['Biasa', 'Penting', 'Segera', 'Rahasia'];

    public function withCreator(): self
    {
        /*
        | -------------------------------------------------------------------
        | QUERY SURAT MASUK DENGAN OPERATOR
        | -------------------------------------------------------------------
        | Menambahkan nama pengguna yang mencatat surat masuk untuk kebutuhan
        | audit sederhana dan laporan.
        |
        | Tips Debugging:
        | - Jika creator_name kosong, kemungkinan akun pembuat sudah dihapus.
        */
        return $this->select('incoming_letters.*, users.name AS creator_name')
            ->join('users', 'users.id = incoming_letters.created_by', 'left');
    }
}
