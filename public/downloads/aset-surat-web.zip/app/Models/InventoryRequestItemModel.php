<?php

namespace App\Models;

use CodeIgniter\Model;

class InventoryRequestItemModel extends Model
{
    protected $table            = 'inventory_request_items';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'inventory_request_id',
        'asset_id',
        'item_name',
        'quantity',
        'unit',
        'notes',
    ];
    protected $useTimestamps = true;

    public function withAsset(): self
    {
        return $this->select('inventory_request_items.*, assets.code AS asset_code, assets.name AS asset_name')
            ->join('assets', 'assets.id = inventory_request_items.asset_id', 'left');
    }
}
