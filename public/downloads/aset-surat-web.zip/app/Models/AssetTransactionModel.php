<?php

namespace App\Models;

use CodeIgniter\Model;

class AssetTransactionModel extends Model
{
    /*
    | -------------------------------------------------------------------
    | MODEL TRANSAKSI ASET
    | -------------------------------------------------------------------
    | Model ini mengelola header peminjaman aset, seperti unit peminjam,
    | tanggal pinjam, rencana kembali, status, dan pencatat transaksi.
    |
    | Tips Debugging:
    | - Jika status tidak tersimpan, pastikan status masuk konstanta STATUSES.
    | - Jika creator_name kosong, user pencatat mungkin sudah dihapus.
    */
    protected $table            = 'asset_transactions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'transaction_code',
        'borrower_unit',
        'borrower_name',
        'purpose',
        'loan_date',
        'expected_return_date',
        'actual_return_date',
        'status',
        'notes',
        'created_by',
    ];
    protected $useTimestamps = true;

    public const STATUSES = [
        'dipinjam'           => 'Dipinjam',
        'dikembalikan'       => 'Dikembalikan',
        'terlambat'          => 'Terlambat',
        'rusak_saat_kembali' => 'Rusak Saat Kembali',
        'hilang'             => 'Hilang',
        'dibatalkan'         => 'Dibatalkan',
    ];

    public const ACTIVE_STATUSES = ['dipinjam', 'terlambat'];

    public function withCreator(): self
    {
        /*
        | -------------------------------------------------------------------
        | QUERY TRANSAKSI DENGAN PENCATAT
        | -------------------------------------------------------------------
        | Join ini menambahkan nama operator/admin yang mencatat transaksi.
        */
        return $this->select('asset_transactions.*, users.name AS creator_name')
            ->join('users', 'users.id = asset_transactions.created_by', 'left');
    }
}
