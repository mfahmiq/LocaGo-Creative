<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    /*
    | -------------------------------------------------------------------
    | MODEL PENGGUNA
    | -------------------------------------------------------------------
    | Model ini mengelola data akun login dan menjadi pintu utama validasi
    | username/password saat autentikasi.
    |
    | Alur Kerja:
    | - Controller memanggil verifyLogin() saat pengguna mengirim form login.
    | - Password input dibandingkan dengan password_hash dari database.
    | - Jika valid, controller menyimpan profil ringkas ke session.
    |
    | Tips Debugging:
    | - Jika login selalu gagal, cek username, is_active, dan password_hash.
    | - Jika field tidak tersimpan, pastikan masuk ke allowedFields.
    */
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'name',
        'username',
        'password_hash',
        'role',
        'is_active',
        'last_login_at',
    ];
    protected $useTimestamps = true;

    public const ROLES = [
        'admin'    => 'Admin',
        'operator' => 'Operator / TU',
        'pimpinan' => 'Pimpinan',
    ];

    public function verifyLogin(string $username, string $password): ?array
    {
        /*
        | -------------------------------------------------------------------
        | VALIDASI LOGIN
        | -------------------------------------------------------------------
        | Method ini memeriksa username, status aktif, dan kecocokan password.
        | Password tidak pernah dibandingkan sebagai teks biasa.
        |
        | Tips Debugging:
        | - Gunakan password_hash() saat membuat password baru.
        | - Pastikan kolom is_active bernilai 1 untuk akun yang boleh login.
        */
        $user = $this->where('username', $username)
            ->where('is_active', 1)
            ->first();

        if (! $user || ! password_verify($password, $user['password_hash'])) {
            return null;
        }

        $this->update($user['id'], ['last_login_at' => date('Y-m-d H:i:s')]);

        return $user;
    }
}
