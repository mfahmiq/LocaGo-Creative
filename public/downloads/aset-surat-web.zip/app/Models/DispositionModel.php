<?php

namespace App\Models;

use CodeIgniter\Model;

class DispositionModel extends Model
{
    /*
    | -------------------------------------------------------------------
    | MODEL DISPOSISI
    | -------------------------------------------------------------------
    | Model ini menyimpan instruksi pimpinan atas surat masuk dan status tindak
    | lanjutnya. Tujuan disposisi disimpan sebagai unit/teks, bukan akun user.
    |
    | Tips Debugging:
    | - Jika disposisi tidak tampil di dashboard, cek status pending/proses.
    */
    protected $table            = 'dispositions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'incoming_letter_id',
        'target_unit',
        'instruction',
        'due_date',
        'status',
        'disposed_by',
    ];
    protected $useTimestamps = true;

    public const STATUSES = [
        'pending'     => 'Pending',
        'proses'      => 'Proses',
        'selesai'     => 'Selesai',
        'diarsipkan'  => 'Diarsipkan',
    ];

    public function withLetter(): self
    {
        /*
        | -------------------------------------------------------------------
        | QUERY DISPOSISI DENGAN DETAIL SURAT
        | -------------------------------------------------------------------
        | Join ini dipakai untuk tabel monitoring agar pimpinan dapat melihat
        | instruksi disposisi beserta nomor surat dan perihalnya.
        |
        | Tips Debugging:
        | - Jika nomor surat kosong, pastikan incoming_letter_id valid.
        */
        return $this->select('dispositions.*, incoming_letters.letter_number, incoming_letters.sender, incoming_letters.subject, users.name AS disposer_name')
            ->join('incoming_letters', 'incoming_letters.id = dispositions.incoming_letter_id', 'left')
            ->join('users', 'users.id = dispositions.disposed_by', 'left');
    }
}
