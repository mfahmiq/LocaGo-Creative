<?php

namespace App\Models;

use CodeIgniter\Model;

class AssetModel extends Model
{
    /*
    | -------------------------------------------------------------------
    | MODEL INVENTARIS ASET
    | -------------------------------------------------------------------
    | Model ini menyimpan data inventaris sekolah dan menyediakan query relasi
    | ke kategori serta lokasi agar tabel laporan lebih informatif.
    |
    | Alur Kerja:
    | - Controller mengirim data hasil form ke insert/update.
    | - Model hanya menerima field yang ada di allowedFields.
    | - Query withRelations() dipakai untuk menampilkan nama kategori/lokasi.
    |
    | Tips Debugging:
    | - Jika field tidak tersimpan, cek allowedFields.
    | - Jika join gagal, pastikan migration foreign key berhasil dijalankan.
    */
    protected $table            = 'assets';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'code',
        'name',
        'category_id',
        'location_id',
        'quantity',
        'condition_status',
        'acquisition_year',
        'funding_source',
        'value',
        'custodian',
        'photo',
        'notes',
    ];
    protected $useTimestamps = true;

    public const CONDITIONS = [
        'baik'         => 'Baik',
        'rusak_ringan' => 'Rusak Ringan',
        'rusak_berat'  => 'Rusak Berat',
        'hilang'       => 'Hilang',
    ];

    public function withRelations(): self
    {
        /*
        | -------------------------------------------------------------------
        | QUERY RELASI ASET
        | -------------------------------------------------------------------
        | Method ini menambahkan join kategori dan lokasi agar controller tidak
        | perlu mengulang potongan query yang sama.
        |
        | Tips Debugging:
        | - Jika category_name kosong, cek category_id pada tabel assets.
        | - Jika query dobel join, panggil method ini pada instance query baru.
        */
        return $this->select('assets.*, asset_categories.name AS category_name, asset_locations.name AS location_name')
            ->join('asset_categories', 'asset_categories.id = assets.category_id', 'left')
            ->join('asset_locations', 'asset_locations.id = assets.location_id', 'left');
    }
}
