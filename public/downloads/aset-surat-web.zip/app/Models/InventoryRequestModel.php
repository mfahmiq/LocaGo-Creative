<?php

namespace App\Models;

use CodeIgniter\Model;

class InventoryRequestModel extends Model
{
    protected $table            = 'inventory_requests';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'request_number',
        'request_date',
        'requester_name',
        'requester_unit',
        'request_type',
        'priority',
        'reason',
        'needed_date',
        'status',
        'approval_notes',
        'approved_by',
        'approved_at',
        'created_by',
    ];
    protected $useTimestamps = true;

    public const TYPES = [
        'peminjaman_aset'  => 'Peminjaman Aset',
        'pengadaan_aset'   => 'Pengadaan Aset',
        'perbaikan_aset'   => 'Perbaikan Aset',
        'penggantian_aset' => 'Penggantian Aset',
    ];

    public const PRIORITIES = [
        'rendah' => 'Rendah',
        'sedang' => 'Sedang',
        'tinggi' => 'Tinggi',
        'mendesak' => 'Mendesak',
    ];

    public const STATUSES = [
        'diajukan'      => 'Diajukan',
        'diproses'      => 'Diproses',
        'disetujui'     => 'Disetujui',
        'ditolak'       => 'Ditolak',
        'direalisasikan'=> 'Direalisasikan',
        'selesai'       => 'Selesai',
    ];

    public const MUTABLE_STATUSES = ['diajukan'];
    public const APPROVAL_STATUSES = ['diajukan', 'diproses'];

    public function withUsers(): self
    {
        return $this->select('inventory_requests.*, creator.name AS creator_name, approver.name AS approver_name')
            ->join('users creator', 'creator.id = inventory_requests.created_by', 'left')
            ->join('users approver', 'approver.id = inventory_requests.approved_by', 'left');
    }
}
