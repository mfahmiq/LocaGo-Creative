<?php

namespace App\Models;

use CodeIgniter\Model;

class OutgoingLetterModel extends Model
{
    /*
    | -------------------------------------------------------------------
    | MODEL SURAT KELUAR
    | -------------------------------------------------------------------
    | Model ini menyimpan arsip surat keluar, status pengiriman, penerima,
    | tanggal diterima, dan catatan pengiriman.
    |
    | Tips Debugging:
    | - Jika status tidak sesuai, cek konstanta STATUSES dan form delivery.
    */
    protected $table            = 'outgoing_letters';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'letter_number',
        'letter_date',
        'recipient',
        'destination_unit',
        'subject',
        'attachment',
        'status',
        'receiver_name',
        'received_date',
        'delivery_notes',
        'created_by',
    ];
    protected $useTimestamps = true;

    public const STATUSES = [
        'dicatat'         => 'Dicatat',
        'siap_dikirim'    => 'Siap Dikirim',
        'terkirim'        => 'Terkirim',
        'diterima_tujuan' => 'Diterima Tujuan',
        'diarsipkan'      => 'Diarsipkan',
    ];

    public function withCreator(): self
    {
        /*
        | -------------------------------------------------------------------
        | QUERY SURAT KELUAR DENGAN OPERATOR
        | -------------------------------------------------------------------
        | Menambahkan nama pengguna pencatat surat keluar untuk kebutuhan audit
        | dan laporan.
        |
        | Tips Debugging:
        | - Jika creator_name kosong, data created_by mungkin null.
        */
        return $this->select('outgoing_letters.*, users.name AS creator_name')
            ->join('users', 'users.id = outgoing_letters.created_by', 'left');
    }
}
