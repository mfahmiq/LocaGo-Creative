<?php

namespace App\Models;

use CodeIgniter\Model;

class AssetLocationModel extends Model
{
    /*
    | -------------------------------------------------------------------
    | MODEL LOKASI ASET
    | -------------------------------------------------------------------
    | Model referensi untuk menyimpan ruangan/unit tempat aset berada.
    |
    | Tips Debugging:
    | - Jika filter lokasi tidak muncul, cek tabel asset_locations.
    */
    protected $table            = 'asset_locations';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = ['name', 'description'];
    protected $useTimestamps    = true;
}
