<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class RoleFilter implements FilterInterface
{
    /*
    | -------------------------------------------------------------------
    | FILTER AKSES BERDASARKAN ROLE
    | -------------------------------------------------------------------
    | Filter ini membatasi fitur sesuai peran pengguna: admin, operator,
    | atau pimpinan. Cocok untuk halaman sensitif seperti manajemen user.
    |
    | Alur Kerja:
    | - Route mendefinisikan filter, contoh: role:admin,pimpinan.
    | - Filter membaca role dari session user.
    | - Jika role tidak termasuk daftar yang diizinkan, request ditolak.
    |
    | Tips Debugging:
    | - Jika akses ditolak padahal role benar, cek ejaan role pada route.
    | - Jika role kosong, pastikan AuthController menyimpan session user['role'].
    */
    public function before(RequestInterface $request, $arguments = null)
    {
        $allowedRoles = $arguments ?? [];
        $user         = session('user') ?? [];
        $currentRole  = $user['role'] ?? null;

        if ($allowedRoles !== [] && ! in_array($currentRole, $allowedRoles, true)) {
            return redirect()->to('/dashboard')->with('error', 'Akses ditolak untuk role Anda.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Tidak ada proses setelah response untuk filter role ini.
    }
}
