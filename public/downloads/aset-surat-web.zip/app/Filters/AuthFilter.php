<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class AuthFilter implements FilterInterface
{
    /*
    | -------------------------------------------------------------------
    | FILTER AUTENTIKASI
    | -------------------------------------------------------------------
    | Filter ini memastikan halaman internal hanya dapat dibuka oleh pengguna
    | yang sudah login. Semua route aplikasi utama memakai filter ini.
    |
    | Alur Kerja:
    | - Request masuk ke route yang memiliki filter "auth".
    | - Filter membaca session isLoggedIn.
    | - Jika tidak ada session login, pengguna diarahkan ke halaman login.
    |
    | Tips Debugging:
    | - Jika selalu kembali ke login, periksa session driver dan cookie browser.
    | - Jika route tetap terbuka tanpa login, pastikan alias auth aktif di Config\Filters.
    */
    public function before(RequestInterface $request, $arguments = null)
    {
        if (! session()->get('isLoggedIn')) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Tidak ada proses setelah response untuk filter autentikasi ini.
    }
}
