<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateInventoryRequestTables extends Migration
{
    public function up()
    {
        $this->createInventoryRequestsTable();
        $this->createInventoryRequestItemsTable();
    }

    public function down()
    {
        $this->forge->dropTable('inventory_request_items', true);
        $this->forge->dropTable('inventory_requests', true);
    }

    private function createInventoryRequestsTable(): void
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'request_number' => [
                'type'       => 'VARCHAR',
                'constraint' => 80,
            ],
            'request_date' => [
                'type' => 'DATE',
            ],
            'requester_name' => [
                'type'       => 'VARCHAR',
                'constraint' => 160,
            ],
            'requester_unit' => [
                'type'       => 'VARCHAR',
                'constraint' => 160,
            ],
            'request_type' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
            ],
            'priority' => [
                'type'       => 'VARCHAR',
                'constraint' => 30,
            ],
            'reason' => [
                'type' => 'TEXT',
            ],
            'needed_date' => [
                'type' => 'DATE',
                'null' => true,
            ],
            'status' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
                'default'    => 'diajukan',
            ],
            'approval_notes' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'approved_by' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'approved_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'created_by' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('request_number');
        $this->forge->addKey(['status', 'request_date']);
        $this->forge->addKey(['request_type', 'priority']);
        $this->forge->addForeignKey('created_by', 'users', 'id', 'SET NULL', 'SET NULL');
        $this->forge->addForeignKey('approved_by', 'users', 'id', 'SET NULL', 'SET NULL');
        $this->forge->createTable('inventory_requests', true);
    }

    private function createInventoryRequestItemsTable(): void
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'inventory_request_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'asset_id' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'item_name' => [
                'type'       => 'VARCHAR',
                'constraint' => 180,
            ],
            'quantity' => [
                'type'       => 'INT',
                'constraint' => 11,
                'default'    => 1,
            ],
            'unit' => [
                'type'       => 'VARCHAR',
                'constraint' => 40,
                'default'    => 'unit',
            ],
            'notes' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addKey(['inventory_request_id', 'asset_id']);
        $this->forge->addForeignKey('inventory_request_id', 'inventory_requests', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('asset_id', 'assets', 'id', 'SET NULL', 'RESTRICT');
        $this->forge->createTable('inventory_request_items', true);
    }
}
