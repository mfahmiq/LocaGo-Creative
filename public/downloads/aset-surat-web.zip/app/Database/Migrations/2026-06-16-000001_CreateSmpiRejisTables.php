<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateSmpiRejisTables extends Migration
{
    /*
    | -------------------------------------------------------------------
    | MIGRATION DATABASE SMPI REJIS
    | -------------------------------------------------------------------
    | Migration ini membuat seluruh tabel utama aplikasi: pengguna, kategori
    | aset, lokasi aset, aset, surat masuk, disposisi, dan surat keluar.
    |
    | Alur Kerja:
    | - Jalankan perintah: php spark migrate.
    | - CodeIgniter membuat tabel sesuai urutan dependensi foreign key.
    | - Jika perlu rollback, jalankan: php spark migrate:rollback.
    |
    | Tips Debugging:
    | - Jika migration gagal foreign key, pastikan engine MySQL memakai InnoDB.
    | - Jika database tidak ditemukan, buat database di phpMyAdmin lalu atur .env.
    */
    public function up()
    {
        $this->createUsersTable();
        $this->createAssetCategoriesTable();
        $this->createAssetLocationsTable();
        $this->createAssetsTable();
        $this->createIncomingLettersTable();
        $this->createDispositionsTable();
        $this->createOutgoingLettersTable();
    }

    public function down()
    {
        /*
        | -------------------------------------------------------------------
        | ROLLBACK TABEL
        | -------------------------------------------------------------------
        | Tabel dihapus dari tabel yang paling bergantung ke tabel induknya
        | agar foreign key tidak menghalangi proses rollback.
        |
        | Tips Debugging:
        | - Jika rollback gagal, pastikan tidak ada tabel tambahan yang masih
        |   memiliki foreign key ke tabel yang akan dihapus.
        */
        $this->forge->dropTable('outgoing_letters', true);
        $this->forge->dropTable('dispositions', true);
        $this->forge->dropTable('incoming_letters', true);
        $this->forge->dropTable('assets', true);
        $this->forge->dropTable('asset_locations', true);
        $this->forge->dropTable('asset_categories', true);
        $this->forge->dropTable('users', true);
    }

    private function createUsersTable(): void
    {
        /*
        | -------------------------------------------------------------------
        | TABEL USERS
        | -------------------------------------------------------------------
        | Menyimpan akun login untuk tiga aktor: admin, operator, dan pimpinan.
        | Password disimpan sebagai hash, bukan teks asli.
        |
        | Tips Debugging:
        | - Jika login gagal, cek kolom username, password_hash, dan is_active.
        */
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'name' => [
                'type'       => 'VARCHAR',
                'constraint' => 120,
            ],
            'username' => [
                'type'       => 'VARCHAR',
                'constraint' => 80,
            ],
            'password_hash' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
            ],
            'role' => [
                'type'       => 'VARCHAR',
                'constraint' => 30,
            ],
            'is_active' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 1,
            ],
            'last_login_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('username');
        $this->forge->createTable('users', true);
    }

    private function createAssetCategoriesTable(): void
    {
        /*
        | -------------------------------------------------------------------
        | TABEL KATEGORI ASET
        | -------------------------------------------------------------------
        | Mengelompokkan aset sekolah seperti Meubel, Elektronik, Buku, atau
        | Sarana Pembelajaran agar pencarian dan laporan lebih rapi.
        |
        | Tips Debugging:
        | - Jika dropdown kategori kosong, jalankan DatabaseSeeder.
        */
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'name' => [
                'type'       => 'VARCHAR',
                'constraint' => 120,
            ],
            'description' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('name');
        $this->forge->createTable('asset_categories', true);
    }

    private function createAssetLocationsTable(): void
    {
        /*
        | -------------------------------------------------------------------
        | TABEL LOKASI ASET
        | -------------------------------------------------------------------
        | Menyimpan daftar ruangan atau unit tempat aset berada, misalnya
        | Ruang TU, Kelas VII, Perpustakaan, atau Laboratorium.
        |
        | Tips Debugging:
        | - Jika laporan per lokasi tidak muncul, cek relasi location_id di tabel assets.
        */
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'name' => [
                'type'       => 'VARCHAR',
                'constraint' => 120,
            ],
            'description' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('name');
        $this->forge->createTable('asset_locations', true);
    }

    private function createAssetsTable(): void
    {
        /*
        | -------------------------------------------------------------------
        | TABEL ASET
        | -------------------------------------------------------------------
        | Tabel inti inventaris sekolah. Data dibuat cukup sederhana tetapi
        | tetap memuat informasi penting untuk audit dan laporan aset.
        |
        | Tips Debugging:
        | - Jika data aset tidak tersimpan, cek validasi controller dan allowedFields model.
        | - Jika foto tidak muncul, cek folder public/uploads/aset.
        */
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'code' => [
                'type'       => 'VARCHAR',
                'constraint' => 80,
            ],
            'name' => [
                'type'       => 'VARCHAR',
                'constraint' => 160,
            ],
            'category_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'location_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'quantity' => [
                'type'       => 'INT',
                'constraint' => 11,
                'default'    => 1,
            ],
            'condition_status' => [
                'type'       => 'VARCHAR',
                'constraint' => 40,
                'default'    => 'baik',
            ],
            'acquisition_year' => [
                'type'       => 'INT',
                'constraint' => 4,
                'null'       => true,
            ],
            'funding_source' => [
                'type'       => 'VARCHAR',
                'constraint' => 120,
                'null'       => true,
            ],
            'value' => [
                'type'       => 'DECIMAL',
                'constraint' => '14,2',
                'default'    => 0,
            ],
            'custodian' => [
                'type'       => 'VARCHAR',
                'constraint' => 120,
                'null'       => true,
            ],
            'photo' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
                'null'       => true,
            ],
            'notes' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('code');
        $this->forge->addKey(['category_id', 'location_id', 'condition_status']);
        $this->forge->addForeignKey('category_id', 'asset_categories', 'id', 'CASCADE', 'RESTRICT');
        $this->forge->addForeignKey('location_id', 'asset_locations', 'id', 'CASCADE', 'RESTRICT');
        $this->forge->createTable('assets', true);
    }

    private function createIncomingLettersTable(): void
    {
        /*
        | -------------------------------------------------------------------
        | TABEL SURAT MASUK
        | -------------------------------------------------------------------
        | Menyimpan surat yang diterima sekolah beserta file lampiran, status
        | disposisi, dan operator yang mencatatnya.
        |
        | Tips Debugging:
        | - Jika pimpinan tidak melihat surat, cek status menunggu_disposisi.
        | - Jika lampiran gagal, cek folder public/uploads/surat.
        */
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'letter_number' => [
                'type'       => 'VARCHAR',
                'constraint' => 120,
            ],
            'letter_date' => [
                'type' => 'DATE',
            ],
            'received_date' => [
                'type' => 'DATE',
            ],
            'sender' => [
                'type'       => 'VARCHAR',
                'constraint' => 160,
            ],
            'subject' => [
                'type'       => 'VARCHAR',
                'constraint' => 200,
            ],
            'priority' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
                'default'    => 'Biasa',
            ],
            'summary' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'attachment' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
                'null'       => true,
            ],
            'status' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
                'default'    => 'menunggu_disposisi',
            ],
            'created_by' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addKey(['status', 'received_date']);
        $this->forge->addForeignKey('created_by', 'users', 'id', 'SET NULL', 'SET NULL');
        $this->forge->createTable('incoming_letters', true);
    }

    private function createDispositionsTable(): void
    {
        /*
        | -------------------------------------------------------------------
        | TABEL DISPOSISI
        | -------------------------------------------------------------------
        | Menyimpan instruksi pimpinan terhadap surat masuk. Karena penerima
        | disposisi tidak memakai akun login, tujuan disimpan sebagai teks unit.
        |
        | Tips Debugging:
        | - Jika disposisi tidak muncul, cek incoming_letter_id dan relasi surat masuk.
        */
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'incoming_letter_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'target_unit' => [
                'type'       => 'VARCHAR',
                'constraint' => 160,
            ],
            'instruction' => [
                'type' => 'TEXT',
            ],
            'due_date' => [
                'type' => 'DATE',
                'null' => true,
            ],
            'status' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
                'default'    => 'pending',
            ],
            'disposed_by' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addKey(['incoming_letter_id', 'status']);
        $this->forge->addForeignKey('incoming_letter_id', 'incoming_letters', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('disposed_by', 'users', 'id', 'SET NULL', 'SET NULL');
        $this->forge->createTable('dispositions', true);
    }

    private function createOutgoingLettersTable(): void
    {
        /*
        | -------------------------------------------------------------------
        | TABEL SURAT KELUAR
        | -------------------------------------------------------------------
        | Menyimpan surat yang dibuat/dikirim sekolah. Status pengiriman
        | mengikuti alur sederhana: dicatat, siap dikirim, terkirim,
        | diterima tujuan, dan diarsipkan.
        |
        | Tips Debugging:
        | - Jika bukti penerima tidak tersimpan, cek field receiver_name dan received_date.
        */
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'letter_number' => [
                'type'       => 'VARCHAR',
                'constraint' => 120,
            ],
            'letter_date' => [
                'type' => 'DATE',
            ],
            'recipient' => [
                'type'       => 'VARCHAR',
                'constraint' => 160,
            ],
            'destination_unit' => [
                'type'       => 'VARCHAR',
                'constraint' => 160,
                'null'       => true,
            ],
            'subject' => [
                'type'       => 'VARCHAR',
                'constraint' => 200,
            ],
            'attachment' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
                'null'       => true,
            ],
            'status' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
                'default'    => 'dicatat',
            ],
            'receiver_name' => [
                'type'       => 'VARCHAR',
                'constraint' => 120,
                'null'       => true,
            ],
            'received_date' => [
                'type' => 'DATE',
                'null' => true,
            ],
            'delivery_notes' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'created_by' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addKey(['status', 'letter_date']);
        $this->forge->addForeignKey('created_by', 'users', 'id', 'SET NULL', 'SET NULL');
        $this->forge->createTable('outgoing_letters', true);
    }
}
