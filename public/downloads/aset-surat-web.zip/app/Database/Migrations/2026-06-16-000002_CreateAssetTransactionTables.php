<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateAssetTransactionTables extends Migration
{
    /*
    | -------------------------------------------------------------------
    | MIGRATION TRANSAKSI ASET
    | -------------------------------------------------------------------
    | Migration ini membuat tabel peminjaman/pengembalian aset. Satu transaksi
    | memiliki data peminjam di tabel asset_transactions dan daftar barang
    | yang dipinjam di tabel asset_transaction_items.
    |
    | Alur Kerja:
    | - Jalankan: php spark migrate.
    | - Operator dapat mencatat peminjaman beberapa aset sekaligus.
    | - Saat barang kembali, status transaksi dan kondisi kembali dicatat.
    |
    | Tips Debugging:
    | - Jika migration gagal, pastikan tabel assets dan users sudah ada.
    | - Jika rollback gagal foreign key, hapus tabel detail sebelum tabel header.
    */
    public function up()
    {
        $this->createAssetTransactionsTable();
        $this->createAssetTransactionItemsTable();
    }

    public function down()
    {
        $this->forge->dropTable('asset_transaction_items', true);
        $this->forge->dropTable('asset_transactions', true);
    }

    private function createAssetTransactionsTable(): void
    {
        /*
        | -------------------------------------------------------------------
        | TABEL HEADER TRANSAKSI ASET
        | -------------------------------------------------------------------
        | Menyimpan informasi umum peminjaman: kode transaksi, unit peminjam,
        | penanggung jawab, tanggal pinjam, target kembali, dan status.
        */
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'transaction_code' => [
                'type'       => 'VARCHAR',
                'constraint' => 80,
            ],
            'borrower_unit' => [
                'type'       => 'VARCHAR',
                'constraint' => 160,
            ],
            'borrower_name' => [
                'type'       => 'VARCHAR',
                'constraint' => 160,
            ],
            'purpose' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'loan_date' => [
                'type' => 'DATE',
            ],
            'expected_return_date' => [
                'type' => 'DATE',
                'null' => true,
            ],
            'actual_return_date' => [
                'type' => 'DATE',
                'null' => true,
            ],
            'status' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
                'default'    => 'dipinjam',
            ],
            'notes' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'created_by' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('transaction_code');
        $this->forge->addKey(['status', 'loan_date']);
        $this->forge->addForeignKey('created_by', 'users', 'id', 'SET NULL', 'SET NULL');
        $this->forge->createTable('asset_transactions', true);
    }

    private function createAssetTransactionItemsTable(): void
    {
        /*
        | -------------------------------------------------------------------
        | TABEL DETAIL ITEM TRANSAKSI ASET
        | -------------------------------------------------------------------
        | Menyimpan daftar aset yang dipinjam dalam satu transaksi. Kondisi
        | sebelum dan setelah kembali dicatat untuk jejak administrasi.
        */
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'asset_transaction_id' => [
                'type'     => 'INT',
                'unsigned' => true,
            ],
            'asset_id' => [
                'type'     => 'INT',
                'unsigned' => true,
                'null'     => true,
            ],
            'quantity' => [
                'type'       => 'INT',
                'constraint' => 11,
                'default'    => 1,
            ],
            'condition_before' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
                'default'    => 'baik',
            ],
            'condition_after' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
                'null'       => true,
            ],
            'notes' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addKey(['asset_transaction_id', 'asset_id']);
        $this->forge->addForeignKey('asset_transaction_id', 'asset_transactions', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('asset_id', 'assets', 'id', 'SET NULL', 'RESTRICT');
        $this->forge->createTable('asset_transaction_items', true);
    }
}
