<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /*
    | -------------------------------------------------------------------
    | SEEDER DATA AWAL SMPI REJIS
    | -------------------------------------------------------------------
    | Seeder ini membuat akun awal, kategori, lokasi, serta contoh data aset
    | dan surat supaya aplikasi bisa langsung diuji setelah migration.
    |
    | Alur Kerja:
    | - Jalankan: php spark db:seed DatabaseSeeder.
    | - Login dengan akun admin/operator/pimpinan yang dibuat di bawah.
    | - Data contoh dapat dihapus dari halaman aplikasi bila tidak diperlukan.
    |
    | Tips Debugging:
    | - Jika duplicate username, berarti seeder pernah dijalankan sebelumnya.
    | - Jika password tidak cocok, cek nilai password_hash() di bagian users.
    */
    public function run()
    {
        $this->seedUsers();
        $this->seedAssetReferences();
        $this->seedSampleTransactions();
    }

    private function seedUsers(): void
    {
        /*
        | -------------------------------------------------------------------
        | AKUN AWAL
        | -------------------------------------------------------------------
        | Tiga akun ini mewakili aktor utama aplikasi. Password awal dibuat
        | sama agar mudah dicoba, lalu bisa diganti dari manajemen user.
        |
        | Akun:
        | - admin / admin123
        | - operator / operator123
        | - pimpinan / pimpinan123
        */
        $users = [
            [
                'name'          => 'Administrator Sistem',
                'username'      => 'admin',
                'password_hash' => password_hash('admin123', PASSWORD_DEFAULT),
                'role'          => 'admin',
                'is_active'     => 1,
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s'),
            ],
            [
                'name'          => 'Staf Tata Usaha',
                'username'      => 'operator',
                'password_hash' => password_hash('operator123', PASSWORD_DEFAULT),
                'role'          => 'operator',
                'is_active'     => 1,
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s'),
            ],
            [
                'name'          => 'Kepala Sekolah',
                'username'      => 'pimpinan',
                'password_hash' => password_hash('pimpinan123', PASSWORD_DEFAULT),
                'role'          => 'pimpinan',
                'is_active'     => 1,
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s'),
            ],
        ];

        foreach ($users as $user) {
            if (! $this->db->table('users')->where('username', $user['username'])->countAllResults()) {
                $this->db->table('users')->insert($user);
            }
        }
    }

    private function seedAssetReferences(): void
    {
        /*
        | -------------------------------------------------------------------
        | REFERENSI ASET
        | -------------------------------------------------------------------
        | Kategori dan lokasi dibuat terpisah agar data aset lebih konsisten,
        | mudah difilter, dan siap dipakai untuk laporan per kategori/lokasi.
        */
        $categories = ['Meubel', 'Elektronik', 'Buku & Dokumen', 'Sarana Pembelajaran', 'Peralatan Kantor'];
        $locations  = ['Ruang TU', 'Ruang Kepala Sekolah', 'Kelas VII', 'Perpustakaan', 'Laboratorium'];

        foreach ($categories as $category) {
            if (! $this->db->table('asset_categories')->where('name', $category)->countAllResults()) {
                $this->db->table('asset_categories')->insert([
                    'name'       => $category,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);
            }
        }

        foreach ($locations as $location) {
            if (! $this->db->table('asset_locations')->where('name', $location)->countAllResults()) {
                $this->db->table('asset_locations')->insert([
                    'name'       => $location,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ]);
            }
        }
    }

    private function seedSampleTransactions(): void
    {
        /*
        | -------------------------------------------------------------------
        | DATA CONTOH TRANSAKSI
        | -------------------------------------------------------------------
        | Data ini membantu mengecek dashboard, grafik, dan tabel laporan tanpa
        | perlu input manual sejak awal.
        |
        | Tips Debugging:
        | - Jika contoh data tidak muncul, pastikan kategori/lokasi berhasil dibuat.
        */
        $adminId     = $this->db->table('users')->where('username', 'admin')->get()->getRow('id');
        $meubelId    = $this->db->table('asset_categories')->where('name', 'Meubel')->get()->getRow('id');
        $elektronikId = $this->db->table('asset_categories')->where('name', 'Elektronik')->get()->getRow('id');
        $tuId        = $this->db->table('asset_locations')->where('name', 'Ruang TU')->get()->getRow('id');
        $kepsekId    = $this->db->table('asset_locations')->where('name', 'Ruang Kepala Sekolah')->get()->getRow('id');

        if (! $this->db->table('assets')->where('code', 'AST-2026-001')->countAllResults()) {
            $this->db->table('assets')->insertBatch([
                [
                    'code'              => 'AST-2026-001',
                    'name'              => 'Meja Administrasi',
                    'category_id'       => $meubelId,
                    'location_id'       => $tuId,
                    'quantity'          => 4,
                    'condition_status'  => 'baik',
                    'acquisition_year'  => 2026,
                    'funding_source'    => 'BOS',
                    'value'             => 2400000,
                    'custodian'         => 'Tata Usaha',
                    'notes'             => 'Inventaris ruang pelayanan administrasi.',
                    'created_at'        => date('Y-m-d H:i:s'),
                    'updated_at'        => date('Y-m-d H:i:s'),
                ],
                [
                    'code'              => 'AST-2026-002',
                    'name'              => 'Laptop Pimpinan',
                    'category_id'       => $elektronikId,
                    'location_id'       => $kepsekId,
                    'quantity'          => 1,
                    'condition_status'  => 'baik',
                    'acquisition_year'  => 2026,
                    'funding_source'    => 'Komite',
                    'value'             => 8500000,
                    'custodian'         => 'Kepala Sekolah',
                    'notes'             => 'Digunakan untuk administrasi pimpinan.',
                    'created_at'        => date('Y-m-d H:i:s'),
                    'updated_at'        => date('Y-m-d H:i:s'),
                ],
            ]);
        }

        if (! $this->db->table('incoming_letters')->where('letter_number', '421/001/DISDIK/2026')->countAllResults()) {
            $this->db->table('incoming_letters')->insert([
                'letter_number' => '421/001/DISDIK/2026',
                'letter_date'   => date('Y-m-d'),
                'received_date' => date('Y-m-d'),
                'sender'        => 'Dinas Pendidikan',
                'subject'       => 'Undangan Rapat Koordinasi',
                'priority'      => 'Penting',
                'summary'       => 'Undangan rapat koordinasi program sekolah.',
                'status'        => 'menunggu_disposisi',
                'created_by'    => $adminId,
                'created_at'    => date('Y-m-d H:i:s'),
                'updated_at'    => date('Y-m-d H:i:s'),
            ]);
        }

        if (! $this->db->table('outgoing_letters')->where('letter_number', 'SMPI/OUT/001/2026')->countAllResults()) {
            $this->db->table('outgoing_letters')->insert([
                'letter_number'     => 'SMPI/OUT/001/2026',
                'letter_date'       => date('Y-m-d'),
                'recipient'         => 'Unit SD',
                'destination_unit'  => 'Unit SD',
                'subject'           => 'Pemberitahuan Koordinasi Kegiatan',
                'status'            => 'siap_dikirim',
                'created_by'        => $adminId,
                'created_at'        => date('Y-m-d H:i:s'),
                'updated_at'        => date('Y-m-d H:i:s'),
            ]);
        }
    }
}
