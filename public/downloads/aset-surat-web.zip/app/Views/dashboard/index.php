<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW DASHBOARD
| -------------------------------------------------------------------
| Halaman ini menampilkan ringkasan operasional aplikasi: statistik aset,
| surat, disposisi, grafik bulanan, dan pekerjaan yang perlu dipantau.
|
| Tips Debugging:
| - Jika grafik tidak tampil, cek section scripts dan data JSON dari controller.
*/
?>

<?= $this->section('content') ?>
<div class="row g-3 mb-4">
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="metric-card">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <div class="text-muted small">Total Unit Aset</div>
                    <div class="metric-value"><?= esc($totalAssets) ?></div>
                </div>
                <span class="metric-icon"><i class="bi bi-box-seam"></i></span>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="metric-card">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <div class="text-muted small">Surat Masuk</div>
                    <div class="metric-value"><?= esc($incomingLetters) ?></div>
                </div>
                <span class="metric-icon warm"><i class="bi bi-envelope-arrow-down"></i></span>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="metric-card">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <div class="text-muted small">Surat Keluar</div>
                    <div class="metric-value"><?= esc($outgoingLetters) ?></div>
                </div>
                <span class="metric-icon dark"><i class="bi bi-envelope-arrow-up"></i></span>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="metric-card">
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <div class="text-muted small">Disposisi Pending</div>
                    <div class="metric-value"><?= esc($pendingDispositions) ?></div>
                </div>
                <span class="metric-icon"><i class="bi bi-send-exclamation"></i></span>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-12 col-xl-8">
        <div class="content-panel">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="h5 mb-0">Tren Surat 6 Bulan</h2>
                <span class="badge text-bg-light border">Masuk vs Keluar</span>
            </div>
            <canvas id="letterTrendChart" height="120"></canvas>
        </div>
    </div>
    <div class="col-12 col-xl-4">
        <div class="content-panel">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="h5 mb-0">Kondisi Aset</h2>
                <span class="badge text-bg-light border"><?= esc($assetRecords) ?> record</span>
            </div>
            <canvas id="assetConditionChart" height="220"></canvas>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-12 col-xl-6">
        <div class="table-panel">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="h5 mb-0">Surat Masuk Terbaru</h2>
                <a href="<?= site_url('incoming-letters') ?>" class="btn btn-sm btn-outline-secondary">Lihat</a>
            </div>
            <div class="table-responsive">
                <table class="table table-sm align-middle">
                    <thead>
                    <tr>
                        <th>Nomor</th>
                        <th>Pengirim</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($latestIncoming as $letter): ?>
                        <tr>
                            <td><a href="<?= site_url('incoming-letters/' . $letter['id']) ?>"><?= esc($letter['letter_number']) ?></a></td>
                            <td><?= esc($letter['sender']) ?></td>
                            <td><span class="badge <?= status_badge_class($letter['status']) ?>"><?= esc(human_status($letter['status'])) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if ($latestIncoming === []): ?>
                        <tr><td colspan="3" class="text-center text-muted py-4">Belum ada surat masuk.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-12 col-xl-6">
        <div class="table-panel">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="h5 mb-0">Disposisi Perlu Dipantau</h2>
                <a href="<?= site_url('dispositions') ?>" class="btn btn-sm btn-outline-secondary">Lihat</a>
            </div>
            <div class="table-responsive">
                <table class="table table-sm align-middle">
                    <thead>
                    <tr>
                        <th>Surat</th>
                        <th>Tujuan</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($pendingDispositionRows as $row): ?>
                        <tr>
                            <td><?= esc($row['letter_number']) ?></td>
                            <td><?= esc($row['target_unit']) ?></td>
                            <td><span class="badge <?= status_badge_class($row['status']) ?>"><?= esc(human_status($row['status'])) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if ($pendingDispositionRows === []): ?>
                        <tr><td colspan="3" class="text-center text-muted py-4">Tidak ada disposisi pending.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    /*
    | -------------------------------------------------------------------
    | GRAFIK DASHBOARD
    | -------------------------------------------------------------------
    | Chart.js membaca data yang dikirim DashboardController. Warna grafik
    | dibuat berbeda agar tidak menjadi satu tema warna yang monoton.
    |
    | Tips Debugging:
    | - Jika muncul error JSON, pastikan data controller berupa array valid.
    */
    const letterTrend = <?= json_encode($letterTrend) ?>;
    const assetCondition = <?= json_encode($assetConditionChart) ?>;

    new Chart(document.getElementById('letterTrendChart'), {
        type: 'line',
        data: {
            labels: letterTrend.labels,
            datasets: [
                {
                    label: 'Surat Masuk',
                    data: letterTrend.incoming,
                    borderColor: '#0f8f83',
                    backgroundColor: 'rgba(15, 143, 131, .12)',
                    tension: .35,
                    fill: true
                },
                {
                    label: 'Surat Keluar',
                    data: letterTrend.outgoing,
                    borderColor: '#e0a21a',
                    backgroundColor: 'rgba(224, 162, 26, .14)',
                    tension: .35,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            plugins: { legend: { position: 'bottom' } },
            scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
        }
    });

    new Chart(document.getElementById('assetConditionChart'), {
        type: 'doughnut',
        data: {
            labels: assetCondition.labels,
            datasets: [{
                data: assetCondition.values,
                backgroundColor: ['#0f8f83', '#e0a21a', '#c0392b', '#34423e']
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { position: 'bottom' } }
        }
    });
</script>
<?= $this->endSection() ?>
