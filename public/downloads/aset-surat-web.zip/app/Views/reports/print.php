<?php
/*
| -------------------------------------------------------------------
| VIEW PRINT LAPORAN
| -------------------------------------------------------------------
| Halaman ini dibuat ringan untuk dicetak atau disimpan menjadi PDF melalui
| fitur print browser.
|
| Tips Debugging:
| - Jika PDF terpotong, pilih orientasi landscape di dialog print browser.
*/
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= esc($heading) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= base_url('app-assets/css/app.css') ?>" rel="stylesheet">
</head>
<body class="print-page">
<main class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-start mb-4 no-print">
        <button class="btn btn-outline-secondary" onclick="window.close()">Tutup</button>
        <button class="btn btn-success" onclick="window.print()"><i class="bi bi-printer me-2"></i>Print</button>
    </div>

    <div class="text-center mb-4">
        <h1 class="h4 mb-1">SMPI REJIS</h1>
        <h2 class="h5 mb-0"><?= esc($heading) ?></h2>
        <div class="text-muted small">Dicetak pada <?= date('d/m/Y H:i') ?></div>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-sm">
            <thead>
            <tr>
                <?php foreach ($columns as $label): ?>
                    <th><?= esc($label) ?></th>
                <?php endforeach; ?>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <?php foreach (array_keys($columns) as $key): ?>
                        <td><?= esc($row[$key] ?? '-') ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
            <?php if ($rows === []): ?>
                <tr><td colspan="<?= count($columns) ?>" class="text-center text-muted">Data laporan tidak ditemukan.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>
</body>
</html>
