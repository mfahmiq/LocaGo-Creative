<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW DETAIL LAPORAN
| -------------------------------------------------------------------
| Halaman ini menampilkan tabel laporan dan tombol export CSV/Print.
|
| Tips Debugging:
| - Jika tombol CSV tidak membawa filter, cek http_build_query($filters).
*/
$queryString = http_build_query(array_filter((array) $filters, static fn ($value) => $value !== null && $value !== ''));
$suffix = $queryString ? '?' . $queryString : '';
?>

<?= $this->section('content') ?>
<div class="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
    <div>
        <h2 class="h5 mb-1"><?= esc($heading) ?></h2>
        <div class="text-muted">Gunakan filter, lalu export sesuai kebutuhan administrasi.</div>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= site_url('reports/' . $type . '/csv') . $suffix ?>" class="btn btn-outline-success">
            <i class="bi bi-filetype-csv me-2"></i>CSV/Excel
        </a>
        <a href="<?= site_url('reports/' . $type . '/print') . $suffix ?>" target="_blank" class="btn btn-success">
            <i class="bi bi-printer me-2"></i>Print/PDF
        </a>
    </div>
</div>

<form method="get" class="content-panel mb-3">
    <div class="row g-2">
        <?php if (! in_array($type, ['assets', 'dispositions'], true)): ?>
            <div class="col-12 col-md-3">
                <input type="date" class="form-control" name="from" value="<?= esc($filters['from'] ?? '') ?>">
            </div>
            <div class="col-12 col-md-3">
                <input type="date" class="form-control" name="to" value="<?= esc($filters['to'] ?? '') ?>">
            </div>
        <?php endif; ?>

        <?php if (! empty($filterOptions['statuses'])): ?>
            <div class="col-12 col-md-3">
                <select class="form-select" name="status">
                    <option value="">Semua status</option>
                    <?php foreach ($filterOptions['statuses'] as $key => $label): ?>
                        <option value="<?= esc($key) ?>" <?= ($filters['status'] ?? '') === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        <?php endif; ?>

        <?php if (! empty($filterOptions['conditions'])): ?>
            <div class="col-12 col-md-3">
                <select class="form-select" name="condition">
                    <option value="">Semua kondisi</option>
                    <?php foreach ($filterOptions['conditions'] as $key => $label): ?>
                        <option value="<?= esc($key) ?>" <?= ($filters['condition'] ?? '') === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        <?php endif; ?>

        <div class="col-12 col-md-2 d-grid">
            <button class="btn btn-outline-success" type="submit">
                <i class="bi bi-search me-2"></i>Filter
            </button>
        </div>
    </div>
</form>

<div class="table-panel">
    <div class="table-responsive">
        <table class="table table-striped align-middle">
            <thead>
            <tr>
                <?php foreach ($columns as $label): ?>
                    <th><?= esc($label) ?></th>
                <?php endforeach; ?>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <?php foreach (array_keys($columns) as $key): ?>
                        <td><?= esc($row[$key] ?? '-') ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
            <?php if ($rows === []): ?>
                <tr><td colspan="<?= count($columns) ?>" class="empty-state">Data laporan tidak ditemukan.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>
