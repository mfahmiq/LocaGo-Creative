<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW MENU LAPORAN
| -------------------------------------------------------------------
| Halaman ini menjadi pintu masuk untuk laporan aset, surat masuk, surat
| keluar, dan disposisi.
|
| Tips Debugging:
| - Jika link laporan 404, cek ReportsController::show() dan route reports/(:segment).
*/
?>

<?= $this->section('content') ?>
<div class="row g-3">
    <?php foreach ($reports as $key => $report): ?>
        <div class="col-12 col-md-6 col-xl-3">
            <a href="<?= site_url('reports/' . $key) ?>" class="text-decoration-none text-reset">
                <div class="metric-card">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <h2 class="h5 mb-0"><?= esc($report['label']) ?></h2>
                        <span class="metric-icon"><i class="bi bi-file-earmark-bar-graph"></i></span>
                    </div>
                    <p class="text-muted mb-0"><?= esc($report['description']) ?></p>
                </div>
            </a>
        </div>
    <?php endforeach; ?>
</div>
<?= $this->endSection() ?>
