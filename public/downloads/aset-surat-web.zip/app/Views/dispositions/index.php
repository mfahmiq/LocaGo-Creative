<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW MONITORING DISPOSISI
| -------------------------------------------------------------------
| Halaman ini mengumpulkan seluruh disposisi dari surat masuk dan menyediakan
| update status tindak lanjut.
|
| Tips Debugging:
| - Jika daftar kosong, buat disposisi dari halaman detail surat masuk.
*/
?>

<?= $this->section('content') ?>
<div class="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
    <div>
        <h2 class="h5 mb-1">Monitoring Disposisi</h2>
        <div class="text-muted">Pantau instruksi pimpinan dan status tindak lanjutnya.</div>
    </div>
    <a href="<?= site_url('incoming-letters') ?>" class="btn btn-outline-success">
        <i class="bi bi-envelope-arrow-down me-2"></i>Surat Masuk
    </a>
</div>

<form method="get" class="content-panel mb-3">
    <div class="row g-2">
        <div class="col-12 col-md-8">
            <input type="search" class="form-control" name="q" value="<?= esc($filters['q']) ?>" placeholder="Cari nomor surat, perihal, tujuan, instruksi">
        </div>
        <div class="col-12 col-md-2">
            <select class="form-select" name="status">
                <option value="">Semua status</option>
                <?php foreach ($statuses as $key => $label): ?>
                    <option value="<?= esc($key) ?>" <?= $filters['status'] === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-md-2 d-grid">
            <button class="btn btn-outline-success" type="submit">
                <i class="bi bi-search me-2"></i>Filter
            </button>
        </div>
    </div>
</form>

<div class="table-panel">
    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
            <tr>
                <th>Surat</th>
                <th>Perihal</th>
                <th>Tujuan</th>
                <th>Instruksi</th>
                <th>Batas</th>
                <th>Status</th>
                <th>Update</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($dispositions as $row): ?>
                <tr>
                    <td>
                        <a href="<?= site_url('incoming-letters/' . $row['incoming_letter_id']) ?>" class="fw-semibold">
                            <?= esc($row['letter_number']) ?>
                        </a>
                    </td>
                    <td><?= esc($row['subject']) ?></td>
                    <td><?= esc($row['target_unit']) ?></td>
                    <td><?= esc($row['instruction']) ?></td>
                    <td><?= esc(date_id($row['due_date'])) ?></td>
                    <td><span class="badge <?= status_badge_class($row['status']) ?>"><?= esc(human_status($row['status'])) ?></span></td>
                    <td>
                        <form action="<?= site_url('dispositions/' . $row['id'] . '/status') ?>" method="post" class="d-flex gap-2">
                            <?= csrf_field() ?>
                            <select class="form-select form-select-sm" name="status" aria-label="Status disposisi">
                                <?php foreach ($statuses as $key => $label): ?>
                                    <option value="<?= esc($key) ?>" <?= $row['status'] === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button class="btn btn-sm btn-outline-success" type="submit" data-bs-toggle="tooltip" title="Simpan status">
                                <i class="bi bi-check-lg"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if ($dispositions === []): ?>
                <tr><td colspan="7" class="empty-state">Belum ada disposisi.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= $pager->links() ?>
</div>
<?= $this->endSection() ?>
