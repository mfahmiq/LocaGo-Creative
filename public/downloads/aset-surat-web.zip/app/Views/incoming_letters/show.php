<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW DETAIL SURAT MASUK
| -------------------------------------------------------------------
| Detail surat masuk menampilkan informasi surat, status, lampiran, form
| disposisi untuk pimpinan/admin, dan riwayat disposisi.
|
| Tips Debugging:
| - Jika form disposisi tidak tampil, pastikan login sebagai admin/pimpinan.
*/
?>

<?= $this->section('content') ?>
<div class="row g-3">
    <div class="col-12 col-xl-7">
        <div class="content-panel">
            <div class="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
                <div>
                    <h2 class="h5 mb-1"><?= esc($letter['subject']) ?></h2>
                    <div class="text-muted"><?= esc($letter['letter_number']) ?></div>
                </div>
                <div class="d-flex gap-2">
                    <a href="<?= site_url('incoming-letters') ?>" class="btn btn-outline-secondary">Kembali</a>
                    <?php if (is_role(['admin', 'operator'])): ?>
                        <a href="<?= site_url('incoming-letters/' . $letter['id'] . '/edit') ?>" class="btn btn-success">
                            <i class="bi bi-pencil me-2"></i>Edit
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <dl class="row">
                <dt class="col-sm-4">Tanggal Surat</dt>
                <dd class="col-sm-8"><?= esc(date_id($letter['letter_date'])) ?></dd>
                <dt class="col-sm-4">Tanggal Terima</dt>
                <dd class="col-sm-8"><?= esc(date_id($letter['received_date'])) ?></dd>
                <dt class="col-sm-4">Pengirim</dt>
                <dd class="col-sm-8"><?= esc($letter['sender']) ?></dd>
                <dt class="col-sm-4">Sifat</dt>
                <dd class="col-sm-8"><?= esc($letter['priority']) ?></dd>
                <dt class="col-sm-4">Status</dt>
                <dd class="col-sm-8"><span class="badge <?= status_badge_class($letter['status']) ?>"><?= esc(human_status($letter['status'])) ?></span></dd>
                <dt class="col-sm-4">Ringkasan</dt>
                <dd class="col-sm-8"><?= esc($letter['summary'] ?: '-') ?></dd>
                <dt class="col-sm-4">Lampiran</dt>
                <dd class="col-sm-8">
                    <?php if (! empty($letter['attachment'])): ?>
                        <a href="<?= base_url($letter['attachment']) ?>" target="_blank">Buka lampiran</a>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </dd>
                <dt class="col-sm-4">Dicatat Oleh</dt>
                <dd class="col-sm-8"><?= esc($letter['creator_name'] ?: '-') ?></dd>
            </dl>

            <form action="<?= site_url('incoming-letters/' . $letter['id'] . '/status') ?>" method="post" class="border-top pt-3">
                <?= csrf_field() ?>
                <label class="form-label" for="status">Ubah Status Surat</label>
                <div class="input-group">
                    <select class="form-select" id="status" name="status">
                        <?php foreach ($statuses as $key => $label): ?>
                            <option value="<?= esc($key) ?>" <?= $letter['status'] === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button class="btn btn-outline-success" type="submit">Update</button>
                </div>
            </form>
        </div>
    </div>

    <div class="col-12 col-xl-5">
        <?php if (is_role(['admin', 'pimpinan'])): ?>
            <form action="<?= site_url('incoming-letters/' . $letter['id'] . '/dispose') ?>" method="post" class="content-panel mb-3">
                <?= csrf_field() ?>
                <h2 class="h5 mb-3">Buat Disposisi</h2>
                <div class="mb-3">
                    <label class="form-label" for="target_unit">Tujuan / Unit</label>
                    <input type="text" class="form-control" id="target_unit" name="target_unit" placeholder="Contoh: Waka Kurikulum, Unit SD" required>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="due_date">Batas Tindak Lanjut</label>
                    <input type="date" class="form-control" id="due_date" name="due_date">
                </div>
                <div class="mb-3">
                    <label class="form-label" for="instruction">Instruksi</label>
                    <textarea class="form-control" id="instruction" name="instruction" rows="4" placeholder="Tulis instruksi disposisi" required></textarea>
                </div>
                <button class="btn btn-success w-100" type="submit">
                    <i class="bi bi-send-check me-2"></i>Simpan Disposisi
                </button>
            </form>
        <?php endif; ?>

        <div class="table-panel">
            <h2 class="h5 mb-3">Riwayat Disposisi</h2>
            <?php foreach ($dispositions as $disposition): ?>
                <div class="border rounded p-3 mb-2">
                    <div class="d-flex justify-content-between gap-2 mb-2">
                        <div class="fw-semibold"><?= esc($disposition['target_unit']) ?></div>
                        <span class="badge <?= status_badge_class($disposition['status']) ?>"><?= esc(human_status($disposition['status'])) ?></span>
                    </div>
                    <div class="small text-muted mb-2">Batas: <?= esc(date_id($disposition['due_date'])) ?> | Oleh: <?= esc($disposition['disposer_name'] ?: '-') ?></div>
                    <div><?= esc($disposition['instruction']) ?></div>
                </div>
            <?php endforeach; ?>
            <?php if ($dispositions === []): ?>
                <div class="empty-state">Belum ada disposisi.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
