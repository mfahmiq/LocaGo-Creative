<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW FORM SURAT MASUK
| -------------------------------------------------------------------
| Form ini dipakai Operator/Admin untuk mencatat arsip surat masuk.
| Lampiran dapat berupa PDF atau gambar.
|
| Tips Debugging:
| - Jika file tidak terkirim, pastikan enctype multipart/form-data tidak dihapus.
*/
$isEdit = $letter !== null;
?>

<?= $this->section('content') ?>
<form action="<?= $isEdit ? site_url('incoming-letters/' . $letter['id']) : site_url('incoming-letters') ?>" method="post" enctype="multipart/form-data" class="content-panel">
    <?= csrf_field() ?>
    <div class="row g-3">
        <div class="col-12 col-md-4">
            <label class="form-label" for="letter_number">Nomor Surat</label>
            <input type="text" class="form-control" id="letter_number" name="letter_number" value="<?= old('letter_number', $letter['letter_number'] ?? '') ?>" required>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="letter_date">Tanggal Surat</label>
            <input type="date" class="form-control" id="letter_date" name="letter_date" value="<?= old('letter_date', $letter['letter_date'] ?? '') ?>" required>
            <div class="form-hint">Dapat terisi otomatis setelah upload PDF teks. Tetap bisa dikoreksi manual.</div>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="received_date">Tanggal Diterima</label>
            <input type="date" class="form-control" id="received_date" name="received_date" value="<?= old('received_date', $letter['received_date'] ?? date('Y-m-d')) ?>" required>
        </div>
        <div class="col-12 col-md-8">
            <label class="form-label" for="sender">Pengirim</label>
            <input type="text" class="form-control" id="sender" name="sender" value="<?= old('sender', $letter['sender'] ?? '') ?>" required>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="priority">Sifat Surat</label>
            <select class="form-select" id="priority" name="priority" required>
                <?php foreach ($priorities as $priority): ?>
                    <option value="<?= esc($priority) ?>" <?= old('priority', $letter['priority'] ?? 'Biasa') === $priority ? 'selected' : '' ?>>
                        <?= esc($priority) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12">
            <label class="form-label" for="subject">Perihal</label>
            <input type="text" class="form-control" id="subject" name="subject" value="<?= old('subject', $letter['subject'] ?? '') ?>" required>
        </div>
        <div class="col-12">
            <label class="form-label" for="summary">Ringkasan</label>
            <textarea class="form-control" id="summary" name="summary" rows="3"><?= old('summary', $letter['summary'] ?? '') ?></textarea>
        </div>
        <div class="col-12">
            <label class="form-label" for="attachment">Lampiran Surat</label>
            <input type="file" class="form-control" id="attachment" name="attachment" accept=".pdf,.jpg,.jpeg,.png,.webp">
            <div class="form-hint">Opsional. Format PDF/JPG/PNG/WEBP. Maksimal 8 MB.</div>
            <div class="form-hint" id="ocrHint"></div>
            <?php if ($isEdit && ! empty($letter['attachment'])): ?>
                <a href="<?= base_url($letter['attachment']) ?>" target="_blank" class="d-inline-block mt-2">Lihat lampiran saat ini</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="d-flex justify-content-end gap-2 mt-4">
        <a href="<?= site_url('incoming-letters') ?>" class="btn btn-outline-secondary">Batal</a>
        <button type="submit" class="btn btn-success">
            <i class="bi bi-save me-2"></i>Simpan
        </button>
    </div>
</form>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    /*
    | -------------------------------------------------------------------
    | AUTO ISI TANGGAL SURAT DARI LAMPIRAN
    | -------------------------------------------------------------------
    | Script ini mengirim file lampiran ke endpoint AJAX untuk membaca tanggal
    | surat. Jika tanggal ditemukan, field Tanggal Surat langsung diisi.
    |
    | Tips Debugging:
    | - Jika muncul CSRF error, pastikan hidden csrf_field() ada di form.
    | - Jika tanggal tidak ketemu, cek apakah PDF berisi teks atau hanya gambar scan.
    */
    const attachmentInput = document.getElementById('attachment');
    const letterDateInput = document.getElementById('letter_date');
    const ocrHint = document.getElementById('ocrHint');
    const csrfInput = document.querySelector('input[name="<?= csrf_token() ?>"]');

    attachmentInput?.addEventListener('change', async function () {
        if (!this.files.length || !csrfInput) {
            return;
        }

        const formData = new FormData();
        formData.append('attachment', this.files[0]);
        formData.append(csrfInput.name, csrfInput.value);
        ocrHint.textContent = 'Mencoba membaca tanggal surat...';

        try {
            const response = await fetch('<?= site_url('incoming-letters/extract-date') ?>', {
                method: 'POST',
                body: formData,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });
            const result = await response.json();

            if (result.csrfName && result.csrfHash) {
                document.querySelectorAll(`input[name="${result.csrfName}"]`).forEach(function (input) {
                    input.value = result.csrfHash;
                });
            }

            if (result.success && result.date) {
                letterDateInput.value = result.date;
                ocrHint.textContent = result.message;
                if (typeof toastr !== 'undefined') {
                    toastr.success(result.message);
                }
            } else {
                ocrHint.textContent = result.message || 'Tanggal belum bisa dikenali otomatis.';
                if (typeof toastr !== 'undefined') {
                    toastr.info(ocrHint.textContent);
                }
            }
        } catch (error) {
            ocrHint.textContent = 'Gagal membaca tanggal otomatis. Silakan isi manual.';
            if (typeof toastr !== 'undefined') {
                toastr.error(ocrHint.textContent);
            }
        }
    });
</script>
<?= $this->endSection() ?>
