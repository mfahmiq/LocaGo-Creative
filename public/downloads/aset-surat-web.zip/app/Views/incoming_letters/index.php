<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW DAFTAR SURAT MASUK
| -------------------------------------------------------------------
| Halaman ini menampilkan surat masuk dengan filter pencarian, status,
| prioritas, dan tanggal terima.
|
| Tips Debugging:
| - Jika tombol detail 404, cek route incoming-letters/(:num).
*/
?>

<?= $this->section('content') ?>
<div class="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
    <div>
        <h2 class="h5 mb-1">Arsip Surat Masuk</h2>
        <div class="text-muted">Catat surat masuk dan pantau status disposisinya.</div>
    </div>
    <?php if (is_role(['admin', 'operator'])): ?>
        <a href="<?= site_url('incoming-letters/create') ?>" class="btn btn-success">
            <i class="bi bi-plus-circle me-2"></i>Tambah Surat
        </a>
    <?php endif; ?>
</div>

<form method="get" class="content-panel mb-3">
    <div class="row g-2">
        <div class="col-12 col-lg-4">
            <input type="search" class="form-control" name="q" value="<?= esc($filters['q']) ?>" placeholder="Cari nomor, pengirim, perihal">
        </div>
        <div class="col-12 col-md-4 col-lg-2">
            <select class="form-select" name="status">
                <option value="">Semua status</option>
                <?php foreach ($statuses as $key => $label): ?>
                    <option value="<?= esc($key) ?>" <?= $filters['status'] === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-md-4 col-lg-2">
            <select class="form-select" name="priority">
                <option value="">Semua sifat</option>
                <?php foreach ($priorities as $priority): ?>
                    <option value="<?= esc($priority) ?>" <?= $filters['priority'] === $priority ? 'selected' : '' ?>><?= esc($priority) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-2 col-lg-1">
            <input type="date" class="form-control" name="from" value="<?= esc($filters['from']) ?>">
        </div>
        <div class="col-6 col-md-2 col-lg-1">
            <input type="date" class="form-control" name="to" value="<?= esc($filters['to']) ?>">
        </div>
        <div class="col-12 col-lg-2 d-grid">
            <button class="btn btn-outline-success" type="submit">
                <i class="bi bi-search me-2"></i>Filter
            </button>
        </div>
    </div>
</form>

<div class="table-panel">
    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
            <tr>
                <th>Nomor</th>
                <th>Tanggal Terima</th>
                <th>Pengirim</th>
                <th>Perihal</th>
                <th>Sifat</th>
                <th>Status</th>
                <th class="text-end">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($letters as $letter): ?>
                <tr>
                    <td class="fw-semibold"><?= esc($letter['letter_number']) ?></td>
                    <td><?= esc(date_id($letter['received_date'])) ?></td>
                    <td><?= esc($letter['sender']) ?></td>
                    <td><?= esc($letter['subject']) ?></td>
                    <td><?= esc($letter['priority']) ?></td>
                    <td><span class="badge <?= status_badge_class($letter['status']) ?>"><?= esc(human_status($letter['status'])) ?></span></td>
                    <td class="text-end">
                        <a href="<?= site_url('incoming-letters/' . $letter['id']) ?>" class="btn btn-outline-success btn-icon" data-bs-toggle="tooltip" title="Detail">
                            <i class="bi bi-eye"></i>
                        </a>
                        <?php if (is_role(['admin', 'operator'])): ?>
                            <a href="<?= site_url('incoming-letters/' . $letter['id'] . '/edit') ?>" class="btn btn-outline-secondary btn-icon" data-bs-toggle="tooltip" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                        <?php endif; ?>
                        <?php if (is_role('admin')): ?>
                            <form action="<?= site_url('incoming-letters/' . $letter['id'] . '/delete') ?>" method="post" class="d-inline js-confirm-delete">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-outline-danger btn-icon" data-bs-toggle="tooltip" title="Hapus">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if ($letters === []): ?>
                <tr><td colspan="7" class="empty-state">Belum ada surat masuk.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= $pager->links() ?>
</div>
<?= $this->endSection() ?>
