<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<?= $this->include('inventory_requests/partials/form') ?>
<?= $this->endSection() ?>
