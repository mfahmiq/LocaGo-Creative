<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
    <div>
        <h2 class="h5 mb-1">Pengajuan Inventaris</h2>
        <div class="text-muted">Ajukan kebutuhan peminjaman, pengadaan, perbaikan, atau penggantian aset.</div>
    </div>
    <?php if (is_role(['admin', 'operator'])): ?>
        <a href="<?= site_url('inventory-requests/create') ?>" class="btn btn-success">
            <i class="bi bi-plus-circle me-2"></i>Tambah Pengajuan
        </a>
    <?php endif; ?>
</div>

<form method="get" class="content-panel mb-3">
    <div class="row g-2">
        <div class="col-12 col-lg-4">
            <input type="search" class="form-control" name="q" value="<?= esc($filters['q']) ?>" placeholder="Cari nomor, pemohon, unit, alasan">
        </div>
        <div class="col-12 col-lg-2">
            <select class="form-select" name="type">
                <option value="">Semua jenis</option>
                <?php foreach ($types as $key => $label): ?>
                    <option value="<?= esc($key) ?>" <?= $filters['type'] === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-lg-2">
            <select class="form-select" name="priority">
                <option value="">Semua prioritas</option>
                <?php foreach ($priorities as $key => $label): ?>
                    <option value="<?= esc($key) ?>" <?= $filters['priority'] === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-lg-2">
            <select class="form-select" name="status">
                <option value="">Semua status</option>
                <?php foreach ($statuses as $key => $label): ?>
                    <option value="<?= esc($key) ?>" <?= $filters['status'] === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-lg-2 d-grid">
            <button class="btn btn-outline-success" type="submit">
                <i class="bi bi-search me-2"></i>Filter
            </button>
        </div>
    </div>
</form>

<div class="table-panel">
    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
            <tr>
                <th>Nomor</th>
                <th>Pemohon</th>
                <th>Jenis</th>
                <th>Prioritas</th>
                <th>Dibutuhkan</th>
                <th>Status</th>
                <th class="text-end">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($requests as $row): ?>
                <tr>
                    <td class="fw-semibold"><?= esc($row['request_number']) ?></td>
                    <td>
                        <div><?= esc($row['requester_name']) ?></div>
                        <div class="small text-muted"><?= esc($row['requester_unit']) ?></div>
                    </td>
                    <td><?= esc($types[$row['request_type']] ?? human_status($row['request_type'])) ?></td>
                    <td><?= esc($priorities[$row['priority']] ?? human_status($row['priority'])) ?></td>
                    <td><?= esc(date_id($row['needed_date'])) ?></td>
                    <td><span class="badge <?= status_badge_class($row['status']) ?>"><?= esc(human_status($row['status'])) ?></span></td>
                    <td class="text-end">
                        <a href="<?= site_url('inventory-requests/' . $row['id'] . '/pdf') ?>" class="btn btn-outline-danger btn-icon" data-bs-toggle="tooltip" title="Download PDF">
                            <i class="bi bi-file-earmark-pdf"></i>
                        </a>
                        <a href="<?= site_url('inventory-requests/' . $row['id']) ?>" class="btn btn-outline-success btn-icon" data-bs-toggle="tooltip" title="Detail">
                            <i class="bi bi-eye"></i>
                        </a>
                        <?php if (in_array($row['status'], ['diajukan'], true) && (is_role('admin') || (is_role('operator') && (int) $row['created_by'] === (int) current_user('id')))): ?>
                            <a href="<?= site_url('inventory-requests/' . $row['id'] . '/edit') ?>" class="btn btn-outline-secondary btn-icon" data-bs-toggle="tooltip" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if ($requests === []): ?>
                <tr><td colspan="7" class="empty-state">Belum ada pengajuan inventaris.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= $pager->links() ?>
</div>
<?= $this->endSection() ?>
