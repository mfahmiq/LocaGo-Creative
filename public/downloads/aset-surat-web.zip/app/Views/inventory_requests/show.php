<?= $this->extend('layouts/main') ?>

<?php
$canApprove = is_role(['admin', 'pimpinan']) && in_array($request['status'], ['diajukan', 'diproses'], true);
$canEdit = in_array($request['status'], ['diajukan'], true) && (is_role('admin') || (is_role('operator') && (int) $request['created_by'] === (int) current_user('id')));
?>

<?= $this->section('content') ?>
<div class="row g-3">
    <div class="col-12 col-xl-7">
        <div class="content-panel">
            <div class="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
                <div>
                    <h2 class="h5 mb-1"><?= esc($request['request_number']) ?></h2>
                    <div class="text-muted"><?= esc($request['requester_unit']) ?></div>
                </div>
                <div class="d-flex flex-column flex-sm-row gap-2">
                    <a href="<?= site_url('inventory-requests/' . $request['id'] . '/pdf') ?>" class="btn btn-outline-danger">
                        <i class="bi bi-file-earmark-pdf me-2"></i>Download PDF
                    </a>
                    <?php if ($canEdit): ?>
                        <a href="<?= site_url('inventory-requests/' . $request['id'] . '/edit') ?>" class="btn btn-outline-secondary">
                            <i class="bi bi-pencil me-2"></i>Edit
                        </a>
                    <?php endif; ?>
                    <a href="<?= site_url('inventory-requests') ?>" class="btn btn-outline-secondary">Kembali</a>
                </div>
            </div>

            <dl class="row">
                <dt class="col-sm-4">Tanggal Pengajuan</dt>
                <dd class="col-sm-8"><?= esc(date_id($request['request_date'])) ?></dd>
                <dt class="col-sm-4">Nama Pemohon</dt>
                <dd class="col-sm-8"><?= esc($request['requester_name']) ?></dd>
                <dt class="col-sm-4">Unit Pemohon</dt>
                <dd class="col-sm-8"><?= esc($request['requester_unit']) ?></dd>
                <dt class="col-sm-4">Jenis Pengajuan</dt>
                <dd class="col-sm-8"><?= esc($types[$request['request_type']] ?? human_status($request['request_type'])) ?></dd>
                <dt class="col-sm-4">Prioritas</dt>
                <dd class="col-sm-8"><?= esc($priorities[$request['priority']] ?? human_status($request['priority'])) ?></dd>
                <dt class="col-sm-4">Tanggal Dibutuhkan</dt>
                <dd class="col-sm-8"><?= esc(date_id($request['needed_date'])) ?></dd>
                <dt class="col-sm-4">Status</dt>
                <dd class="col-sm-8"><span class="badge <?= status_badge_class($request['status']) ?>"><?= esc(human_status($request['status'])) ?></span></dd>
                <dt class="col-sm-4">Alasan</dt>
                <dd class="col-sm-8"><?= nl2br(esc($request['reason'])) ?></dd>
                <dt class="col-sm-4">Catatan Persetujuan/Penolakan</dt>
                <dd class="col-sm-8"><?= nl2br(esc($request['approval_notes'] ?: '-')) ?></dd>
                <dt class="col-sm-4">Dibuat Oleh</dt>
                <dd class="col-sm-8"><?= esc($request['creator_name'] ?: '-') ?></dd>
                <dt class="col-sm-4">Diproses Oleh</dt>
                <dd class="col-sm-8"><?= esc($request['approver_name'] ?: '-') ?></dd>
                <dt class="col-sm-4">Waktu Proses</dt>
                <dd class="col-sm-8"><?= esc($request['approved_at'] ? date('d/m/Y H:i', strtotime($request['approved_at'])) : '-') ?></dd>
            </dl>

            <h3 class="h6 mt-4">Item Pengajuan</h3>
            <div class="table-responsive">
                <table class="table table-sm align-middle">
                    <thead>
                    <tr>
                        <th>Barang/Aset</th>
                        <th>Jumlah</th>
                        <th>Satuan</th>
                        <th>Aset Terkait</th>
                        <th>Catatan</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?= esc($item['item_name']) ?></td>
                            <td><?= esc($item['quantity']) ?></td>
                            <td><?= esc($item['unit']) ?></td>
                            <td><?= esc($item['asset_id'] ? (($item['asset_code'] ?: '-') . ' - ' . ($item['asset_name'] ?: 'Aset terhapus')) : '-') ?></td>
                            <td><?= esc($item['notes'] ?: '-') ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-12 col-xl-5">
        <?php if ($canApprove): ?>
            <div class="content-panel mb-3">
                <h2 class="h5 mb-3">Approval Pengajuan</h2>
                <form action="<?= site_url('inventory-requests/' . $request['id'] . '/approve') ?>" method="post" class="mb-3">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label" for="approve_notes">Catatan Persetujuan</label>
                        <textarea class="form-control" id="approve_notes" name="approval_notes" rows="2" placeholder="Opsional"></textarea>
                    </div>
                    <button class="btn btn-success w-100" type="submit">
                        <i class="bi bi-check-circle me-2"></i>Setujui Pengajuan
                    </button>
                </form>
                <form action="<?= site_url('inventory-requests/' . $request['id'] . '/reject') ?>" method="post">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label" for="reject_notes">Catatan Penolakan</label>
                        <textarea class="form-control" id="reject_notes" name="approval_notes" rows="3" required></textarea>
                    </div>
                    <button class="btn btn-outline-danger w-100" type="submit">
                        <i class="bi bi-x-circle me-2"></i>Tolak Pengajuan
                    </button>
                </form>
            </div>
        <?php else: ?>
            <div class="content-panel">
                <h2 class="h5 mb-2">Status Pengajuan</h2>
                <p class="text-muted mb-0">Pengajuan ini tidak berada pada status yang dapat diproses atau role Anda tidak memiliki akses approval.</p>
            </div>
        <?php endif; ?>

        <?php if ($request['status'] === 'disetujui'): ?>
            <div class="content-panel mt-3">
                <h2 class="h6 mb-2">Integrasi Lanjutan</h2>
                <p class="text-muted mb-0">Pengajuan yang disetujui dapat dijadikan dasar pembuatan surat keluar atau transaksi aset pada pengembangan berikutnya.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?>
