<?php
$isEdit = ! empty($request);
$action = $isEdit ? site_url('inventory-requests/' . $request['id']) : site_url('inventory-requests');
$oldItems = old('item_name');

if (is_array($oldItems)) {
    $formItems = [];
    $oldAssetIds = (array) old('asset_id');
    $oldQuantities = (array) old('quantity');
    $oldUnits = (array) old('unit');
    $oldNotes = (array) old('item_notes');

    foreach ($oldItems as $index => $name) {
        $formItems[] = [
            'asset_id'  => $oldAssetIds[$index] ?? '',
            'item_name' => $name,
            'quantity'  => $oldQuantities[$index] ?? 1,
            'unit'      => $oldUnits[$index] ?? 'unit',
            'notes'     => $oldNotes[$index] ?? '',
        ];
    }
} else {
    $formItems = $items ?: [[
        'asset_id'  => '',
        'item_name' => '',
        'quantity'  => 1,
        'unit'      => 'unit',
        'notes'     => '',
    ]];
}
?>

<form action="<?= $action ?>" method="post" class="content-panel" id="inventoryRequestForm">
    <?= csrf_field() ?>
    <div class="row g-3">
        <div class="col-12 col-md-4">
            <label class="form-label" for="request_date">Tanggal Pengajuan</label>
            <input type="date" class="form-control" id="request_date" name="request_date" value="<?= esc(old('request_date', $request['request_date'] ?? date('Y-m-d'))) ?>" required>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="needed_date">Tanggal Dibutuhkan</label>
            <input type="date" class="form-control" id="needed_date" name="needed_date" value="<?= esc(old('needed_date', $request['needed_date'] ?? '')) ?>">
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="priority">Prioritas</label>
            <select class="form-select" id="priority" name="priority" required>
                <?php foreach ($priorities as $key => $label): ?>
                    <option value="<?= esc($key) ?>" <?= old('priority', $request['priority'] ?? 'sedang') === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-md-6">
            <label class="form-label" for="requester_name">Nama Pemohon</label>
            <input type="text" class="form-control" id="requester_name" name="requester_name" value="<?= esc(old('requester_name', $request['requester_name'] ?? current_user('name'))) ?>" required>
        </div>
        <div class="col-12 col-md-6">
            <label class="form-label" for="requester_unit">Unit Pemohon</label>
            <input type="text" class="form-control" id="requester_unit" name="requester_unit" value="<?= esc(old('requester_unit', $request['requester_unit'] ?? '')) ?>" placeholder="Contoh: Tata Usaha" required>
        </div>
        <div class="col-12 col-md-6">
            <label class="form-label" for="request_type">Jenis Pengajuan</label>
            <select class="form-select" id="request_type" name="request_type" required>
                <option value="">Pilih jenis</option>
                <?php foreach ($types as $key => $label): ?>
                    <option value="<?= esc($key) ?>" <?= old('request_type', $request['request_type'] ?? '') === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12">
            <label class="form-label" for="reason">Alasan Pengajuan</label>
            <textarea class="form-control" id="reason" name="reason" rows="3" required><?= esc(old('reason', $request['reason'] ?? '')) ?></textarea>
        </div>
    </div>

    <hr>

    <div class="d-flex justify-content-between align-items-center mb-2">
        <h2 class="h5 mb-0">Daftar Item Barang/Aset</h2>
        <button type="button" class="btn btn-outline-success btn-sm" id="addRequestItemRow">
            <i class="bi bi-plus-circle me-1"></i>Tambah Baris
        </button>
    </div>

    <div class="table-responsive">
        <table class="table align-middle" id="inventoryRequestItemsTable">
            <thead>
            <tr>
                <th style="min-width: 240px;">Aset Terkait</th>
                <th style="min-width: 220px;">Nama Barang/Aset</th>
                <th style="width: 110px;">Jumlah</th>
                <th style="width: 120px;">Satuan</th>
                <th>Catatan</th>
                <th style="width: 48px;"></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($formItems as $item): ?>
                <tr class="request-item-row">
                    <td>
                        <select class="form-select asset-select" name="asset_id[]">
                            <option value="">Tidak terkait aset lama</option>
                            <?php foreach ($assets as $asset): ?>
                                <option value="<?= esc($asset['id']) ?>" data-name="<?= esc($asset['name']) ?>" <?= (string) ($item['asset_id'] ?? '') === (string) $asset['id'] ? 'selected' : '' ?>>
                                    <?= esc($asset['code'] . ' - ' . $asset['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td><input type="text" class="form-control item-name" name="item_name[]" value="<?= esc($item['item_name'] ?? '') ?>" required></td>
                    <td><input type="number" class="form-control" name="quantity[]" value="<?= esc($item['quantity'] ?? 1) ?>" min="1" required></td>
                    <td><input type="text" class="form-control" name="unit[]" value="<?= esc($item['unit'] ?? 'unit') ?>" required></td>
                    <td><input type="text" class="form-control" name="item_notes[]" value="<?= esc($item['notes'] ?? '') ?>" placeholder="Opsional"></td>
                    <td>
                        <button type="button" class="btn btn-outline-danger btn-icon remove-request-item-row" data-bs-toggle="tooltip" title="Hapus baris">
                            <i class="bi bi-x-lg"></i>
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="d-flex justify-content-end gap-2 mt-4">
        <a href="<?= site_url('inventory-requests') ?>" class="btn btn-outline-secondary">Batal</a>
        <button type="submit" class="btn btn-success">
            <i class="bi bi-save me-2"></i>Simpan Pengajuan
        </button>
    </div>
</form>

<?= $this->section('scripts') ?>
<script>
    const requestItemsTableBody = document.querySelector('#inventoryRequestItemsTable tbody');
    const addRequestItemRowButton = document.getElementById('addRequestItemRow');

    addRequestItemRowButton?.addEventListener('click', function () {
        const firstRow = requestItemsTableBody.querySelector('.request-item-row');
        const newRow = firstRow.cloneNode(true);

        newRow.querySelectorAll('select, input').forEach(function (input) {
            if (input.tagName === 'SELECT') {
                input.selectedIndex = 0;
            } else if (input.type === 'number') {
                input.value = 1;
            } else if (input.name === 'unit[]') {
                input.value = 'unit';
            } else {
                input.value = '';
            }
        });

        requestItemsTableBody.appendChild(newRow);
    });

    requestItemsTableBody?.addEventListener('click', function (event) {
        const button = event.target.closest('.remove-request-item-row');
        if (!button) {
            return;
        }

        if (requestItemsTableBody.querySelectorAll('.request-item-row').length > 1) {
            button.closest('tr').remove();
        }
    });

    requestItemsTableBody?.addEventListener('change', function (event) {
        if (! event.target.classList.contains('asset-select')) {
            return;
        }

        const option = event.target.selectedOptions[0];
        const row = event.target.closest('tr');
        const nameInput = row.querySelector('.item-name');

        if (option?.dataset.name && nameInput && nameInput.value.trim() === '') {
            nameInput.value = option.dataset.name;
        }
    });
</script>
<?= $this->endSection() ?>
