<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW FORM ASET
| -------------------------------------------------------------------
| Form ini dipakai untuk menambah dan mengubah data inventaris aset.
| File foto bersifat opsional.
|
| Tips Debugging:
| - Jika upload gagal, pastikan form memakai enctype multipart/form-data.
*/
$isEdit = $asset !== null;
?>

<?= $this->section('content') ?>
<form action="<?= $isEdit ? site_url('assets/' . $asset['id']) : site_url('assets') ?>" method="post" enctype="multipart/form-data" class="content-panel">
    <?= csrf_field() ?>
    <div class="row g-3">
        <div class="col-12 col-md-4">
            <label class="form-label" for="code">Kode Aset</label>
            <input type="text" class="form-control" id="code" name="code" value="<?= old('code', $asset['code'] ?? '') ?>" required>
        </div>
        <div class="col-12 col-md-8">
            <label class="form-label" for="name">Nama Aset</label>
            <input type="text" class="form-control" id="name" name="name" value="<?= old('name', $asset['name'] ?? '') ?>" required>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="category_id">Kategori</label>
            <select class="form-select" id="category_id" name="category_id" required>
                <option value="">Pilih kategori</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= esc($category['id']) ?>" <?= (string) old('category_id', $asset['category_id'] ?? '') === (string) $category['id'] ? 'selected' : '' ?>>
                        <?= esc($category['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="location_id">Lokasi</label>
            <select class="form-select" id="location_id" name="location_id">
                <option value="">Pilih lokasi</option>
                <?php foreach ($locations as $location): ?>
                    <option value="<?= esc($location['id']) ?>" <?= (string) old('location_id', $asset['location_id'] ?? '') === (string) $location['id'] ? 'selected' : '' ?>>
                        <?= esc($location['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <div class="form-hint">Pilih lokasi yang sudah ada, atau isi lokasi baru di bawah.</div>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="condition_status">Kondisi</label>
            <select class="form-select" id="condition_status" name="condition_status" required>
                <?php foreach ($conditions as $key => $label): ?>
                    <option value="<?= esc($key) ?>" <?= old('condition_status', $asset['condition_status'] ?? 'baik') === $key ? 'selected' : '' ?>>
                        <?= esc($label) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="new_location_name">Lokasi Baru</label>
            <input type="text" class="form-control" id="new_location_name" name="new_location_name" value="<?= old('new_location_name') ?>" placeholder="Contoh: Unit TK, Aula, Gudang">
        </div>
        <div class="col-12 col-md-2">
            <label class="form-label" for="quantity">Jumlah</label>
            <input type="number" min="1" class="form-control" id="quantity" name="quantity" value="<?= old('quantity', $asset['quantity'] ?? 1) ?>" required>
        </div>
        <div class="col-12 col-md-2">
            <label class="form-label" for="acquisition_year">Tahun Perolehan</label>
            <input type="number" min="1900" max="2100" class="form-control" id="acquisition_year" name="acquisition_year" value="<?= old('acquisition_year', $asset['acquisition_year'] ?? '') ?>">
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="funding_source">Sumber Dana</label>
            <input type="text" class="form-control" id="funding_source" name="funding_source" value="<?= old('funding_source', $asset['funding_source'] ?? '') ?>">
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="value">Nilai / Harga Perolehan</label>
            <input type="number" step="0.01" min="0" class="form-control" id="value" name="value" value="<?= old('value', $asset['value'] ?? 0) ?>">
            <div class="form-hint">Opsional. Isi dengan harga beli atau nilai bantuan barang.</div>
        </div>
        <div class="col-12 col-md-6">
            <label class="form-label" for="custodian">Penanggung Jawab</label>
            <input type="text" class="form-control" id="custodian" name="custodian" value="<?= old('custodian', $asset['custodian'] ?? '') ?>">
        </div>
        <div class="col-12 col-md-6">
            <label class="form-label" for="photo">Foto Aset</label>
            <input type="file" class="form-control" id="photo" name="photo" accept=".jpg,.jpeg,.png,.webp">
            <div class="form-hint">Opsional. Format JPG, PNG, WEBP. Maksimal 3 MB.</div>
        </div>
        <div class="col-12">
            <label class="form-label" for="notes">Keterangan</label>
            <textarea class="form-control" id="notes" name="notes" rows="3"><?= old('notes', $asset['notes'] ?? '') ?></textarea>
        </div>
        <?php if ($isEdit && ! empty($asset['photo'])): ?>
            <div class="col-12">
                <img src="<?= base_url($asset['photo']) ?>" alt="Foto aset" class="asset-thumb">
            </div>
        <?php endif; ?>
    </div>

    <div class="d-flex justify-content-end gap-2 mt-4">
        <a href="<?= site_url('assets') ?>" class="btn btn-outline-secondary">Batal</a>
        <button type="submit" class="btn btn-success">
            <i class="bi bi-save me-2"></i>Simpan
        </button>
    </div>
</form>
<?= $this->endSection() ?>
