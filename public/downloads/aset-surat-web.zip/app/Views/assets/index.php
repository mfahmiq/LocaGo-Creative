<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW DAFTAR ASET
| -------------------------------------------------------------------
| Halaman ini menampilkan inventaris aset dengan filter pencarian, kategori,
| lokasi, dan kondisi.
|
| Tips Debugging:
| - Jika pagination tidak muncul, pastikan controller mengirim variable $pager.
*/
?>

<?= $this->section('content') ?>
<div class="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
    <div>
        <h2 class="h5 mb-1">Data Inventaris</h2>
        <div class="text-muted">Pantau aset sekolah berdasarkan lokasi, kategori, dan kondisi.</div>
    </div>
    <?php if (is_role(['admin', 'operator'])): ?>
        <a href="<?= site_url('assets/create') ?>" class="btn btn-success">
            <i class="bi bi-plus-circle me-2"></i>Tambah Aset
        </a>
    <?php endif; ?>
</div>

<form method="get" class="content-panel mb-3">
    <div class="row g-2">
        <div class="col-12 col-lg-4">
            <input type="search" class="form-control" name="q" value="<?= esc($filters['q']) ?>" placeholder="Cari kode, nama, penanggung jawab">
        </div>
        <div class="col-12 col-md-4 col-lg-2">
            <select class="form-select" name="category">
                <option value="">Semua kategori</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= esc($category['id']) ?>" <?= (string) $filters['category'] === (string) $category['id'] ? 'selected' : '' ?>>
                        <?= esc($category['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-md-4 col-lg-2">
            <select class="form-select" name="location">
                <option value="">Semua lokasi</option>
                <?php foreach ($locations as $location): ?>
                    <option value="<?= esc($location['id']) ?>" <?= (string) $filters['location'] === (string) $location['id'] ? 'selected' : '' ?>>
                        <?= esc($location['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-md-4 col-lg-2">
            <select class="form-select" name="condition">
                <option value="">Semua kondisi</option>
                <?php foreach ($conditions as $key => $label): ?>
                    <option value="<?= esc($key) ?>" <?= $filters['condition'] === $key ? 'selected' : '' ?>>
                        <?= esc($label) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-lg-2 d-grid">
            <button class="btn btn-outline-success" type="submit">
                <i class="bi bi-search me-2"></i>Filter
            </button>
        </div>
    </div>
</form>

<div class="table-panel">
    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
            <tr>
                <th>Kode</th>
                <th>Aset</th>
                <th>Kategori</th>
                <th>Lokasi</th>
                <th>Jumlah</th>
                <th>Kondisi</th>
                <th class="text-end">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($assets as $asset): ?>
                <tr>
                    <td class="fw-semibold"><?= esc($asset['code']) ?></td>
                    <td><?= esc($asset['name']) ?></td>
                    <td><?= esc($asset['category_name']) ?></td>
                    <td><?= esc($asset['location_name']) ?></td>
                    <td><?= esc($asset['quantity']) ?></td>
                    <td><span class="badge <?= status_badge_class($asset['condition_status']) ?>"><?= esc(human_status($asset['condition_status'])) ?></span></td>
                    <td class="text-end">
                        <a href="<?= site_url('assets/' . $asset['id']) ?>" class="btn btn-outline-success btn-icon" data-bs-toggle="tooltip" title="Detail">
                            <i class="bi bi-eye"></i>
                        </a>
                        <?php if (is_role(['admin', 'operator'])): ?>
                            <a href="<?= site_url('assets/' . $asset['id'] . '/edit') ?>" class="btn btn-outline-secondary btn-icon" data-bs-toggle="tooltip" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                        <?php endif; ?>
                        <?php if (is_role('admin')): ?>
                            <form action="<?= site_url('assets/' . $asset['id'] . '/delete') ?>" method="post" class="d-inline js-confirm-delete">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-outline-danger btn-icon" data-bs-toggle="tooltip" title="Hapus">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if ($assets === []): ?>
                <tr><td colspan="7" class="empty-state">Data aset belum ditemukan.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= $pager->links() ?>
</div>
<?= $this->endSection() ?>
