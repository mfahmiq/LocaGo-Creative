<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW DETAIL ASET
| -------------------------------------------------------------------
| Detail aset menampilkan informasi inventaris dalam format baca cepat,
| termasuk foto jika tersedia.
|
| Tips Debugging:
| - Jika foto tidak muncul, cek path asset['photo'] dan folder public/uploads/aset.
*/
?>

<?= $this->section('content') ?>
<div class="content-panel">
    <div class="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
        <div>
            <h2 class="h5 mb-1"><?= esc($asset['name']) ?></h2>
            <div class="text-muted"><?= esc($asset['code']) ?></div>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= site_url('assets') ?>" class="btn btn-outline-secondary">Kembali</a>
            <?php if (is_role(['admin', 'operator'])): ?>
                <a href="<?= site_url('assets/' . $asset['id'] . '/edit') ?>" class="btn btn-success">
                    <i class="bi bi-pencil me-2"></i>Edit
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-12 col-lg-4">
            <?php if (! empty($asset['photo'])): ?>
                <img src="<?= base_url($asset['photo']) ?>" alt="Foto aset" class="img-fluid rounded border">
            <?php else: ?>
                <div class="empty-state border rounded">Belum ada foto aset.</div>
            <?php endif; ?>
        </div>
        <div class="col-12 col-lg-8">
            <dl class="row mb-0">
                <dt class="col-sm-4">Kategori</dt>
                <dd class="col-sm-8"><?= esc($asset['category_name']) ?></dd>
                <dt class="col-sm-4">Lokasi</dt>
                <dd class="col-sm-8"><?= esc($asset['location_name']) ?></dd>
                <dt class="col-sm-4">Jumlah</dt>
                <dd class="col-sm-8"><?= esc($asset['quantity']) ?></dd>
                <dt class="col-sm-4">Kondisi</dt>
                <dd class="col-sm-8"><span class="badge <?= status_badge_class($asset['condition_status']) ?>"><?= esc(human_status($asset['condition_status'])) ?></span></dd>
                <dt class="col-sm-4">Tahun Perolehan</dt>
                <dd class="col-sm-8"><?= esc($asset['acquisition_year'] ?: '-') ?></dd>
                <dt class="col-sm-4">Sumber Dana</dt>
                <dd class="col-sm-8"><?= esc($asset['funding_source'] ?: '-') ?></dd>
                <dt class="col-sm-4">Nilai / Harga Perolehan</dt>
                <dd class="col-sm-8"><?= esc(rupiah($asset['value'])) ?></dd>
                <dt class="col-sm-4">Penanggung Jawab</dt>
                <dd class="col-sm-8"><?= esc($asset['custodian'] ?: '-') ?></dd>
                <dt class="col-sm-4">Keterangan</dt>
                <dd class="col-sm-8"><?= esc($asset['notes'] ?: '-') ?></dd>
            </dl>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
