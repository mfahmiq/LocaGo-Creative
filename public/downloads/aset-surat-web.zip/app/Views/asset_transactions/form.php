<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW FORM TRANSAKSI ASET
| -------------------------------------------------------------------
| Form ini mencatat peminjaman aset. Satu transaksi bisa memuat beberapa
| aset dengan jumlah masing-masing.
|
| Tips Debugging:
| - Jika baris aset tidak bertambah, cek script addAssetRow di section scripts.
| - Jika stok ditolak, cek kolom tersedia pada dropdown aset.
*/
?>

<?= $this->section('content') ?>
<form action="<?= site_url('asset-transactions') ?>" method="post" class="content-panel" id="assetTransactionForm">
    <?= csrf_field() ?>
    <div class="row g-3">
        <div class="col-12 col-md-4">
            <label class="form-label" for="transaction_code">Kode Transaksi</label>
            <input type="text" class="form-control" id="transaction_code" value="<?= esc($code) ?>" readonly>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="loan_date">Tanggal Pinjam</label>
            <input type="date" class="form-control" id="loan_date" name="loan_date" value="<?= old('loan_date', date('Y-m-d')) ?>" required>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="expected_return_date">Rencana Kembali</label>
            <input type="date" class="form-control" id="expected_return_date" name="expected_return_date" value="<?= old('expected_return_date') ?>">
        </div>
        <div class="col-12 col-md-6">
            <label class="form-label" for="borrower_unit">Unit Peminjam</label>
            <input type="text" class="form-control" id="borrower_unit" name="borrower_unit" value="<?= old('borrower_unit') ?>" placeholder="Contoh: Unit TK" required>
        </div>
        <div class="col-12 col-md-6">
            <label class="form-label" for="borrower_name">Penanggung Jawab / Penerima</label>
            <input type="text" class="form-control" id="borrower_name" name="borrower_name" value="<?= old('borrower_name') ?>" required>
        </div>
        <div class="col-12">
            <label class="form-label" for="purpose">Keperluan</label>
            <textarea class="form-control" id="purpose" name="purpose" rows="2" placeholder="Contoh: Kegiatan pentas seni Unit TK"><?= old('purpose') ?></textarea>
        </div>
    </div>

    <hr>

    <div class="d-flex justify-content-between align-items-center mb-2">
        <h2 class="h5 mb-0">Daftar Aset Dipinjam</h2>
        <button type="button" class="btn btn-outline-success btn-sm" id="addAssetRow">
            <i class="bi bi-plus-circle me-1"></i>Tambah Baris
        </button>
    </div>

    <div class="table-responsive">
        <table class="table align-middle" id="assetItemsTable">
            <thead>
            <tr>
                <th style="min-width: 280px;">Aset</th>
                <th style="width: 120px;">Jumlah</th>
                <th style="min-width: 180px;">Kondisi Awal</th>
                <th>Catatan</th>
                <th style="width: 48px;"></th>
            </tr>
            </thead>
            <tbody>
            <tr class="asset-row">
                <td>
                    <select class="form-select asset-select" name="asset_id[]" required>
                        <option value="">Pilih aset</option>
                        <?php foreach ($assets as $asset): ?>
                            <option value="<?= esc($asset['id']) ?>" data-available="<?= esc($asset['available_quantity']) ?>">
                                <?= esc($asset['code'] . ' - ' . $asset['name'] . ' | Tersedia: ' . $asset['available_quantity']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td><input type="number" class="form-control" name="quantity[]" value="1" min="1" required></td>
                <td>
                    <select class="form-select" name="condition_before[]">
                        <?php foreach ($conditions as $key => $label): ?>
                            <option value="<?= esc($key) ?>"><?= esc($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
                <td><input type="text" class="form-control" name="item_notes[]" placeholder="Opsional"></td>
                <td>
                    <button type="button" class="btn btn-outline-danger btn-icon remove-row" data-bs-toggle="tooltip" title="Hapus baris">
                        <i class="bi bi-x-lg"></i>
                    </button>
                </td>
            </tr>
            </tbody>
        </table>
    </div>

    <div class="mt-3">
        <label class="form-label" for="notes">Catatan Transaksi</label>
        <textarea class="form-control" id="notes" name="notes" rows="2"><?= old('notes') ?></textarea>
    </div>

    <div class="d-flex justify-content-end gap-2 mt-4">
        <a href="<?= site_url('asset-transactions') ?>" class="btn btn-outline-secondary">Batal</a>
        <button type="submit" class="btn btn-success">
            <i class="bi bi-save me-2"></i>Simpan Transaksi
        </button>
    </div>
</form>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    /*
    | -------------------------------------------------------------------
    | FORM MULTI ITEM TRANSAKSI ASET
    | -------------------------------------------------------------------
    | Script ini menambah/menghapus baris aset pada form peminjaman tanpa
    | reload halaman.
    |
    | Tips Debugging:
    | - Jika baris baru tidak punya option aset, pastikan row pertama tetap ada.
    */
    const tableBody = document.querySelector('#assetItemsTable tbody');
    const addButton = document.getElementById('addAssetRow');

    addButton?.addEventListener('click', function () {
        const firstRow = tableBody.querySelector('.asset-row');
        const newRow = firstRow.cloneNode(true);

        newRow.querySelectorAll('select, input').forEach(function (input) {
            if (input.tagName === 'SELECT') {
                input.selectedIndex = 0;
            } else if (input.type === 'number') {
                input.value = 1;
            } else {
                input.value = '';
            }
        });

        tableBody.appendChild(newRow);
    });

    tableBody?.addEventListener('click', function (event) {
        const button = event.target.closest('.remove-row');
        if (!button) {
            return;
        }

        if (tableBody.querySelectorAll('.asset-row').length > 1) {
            button.closest('tr').remove();
        }
    });
</script>
<?= $this->endSection() ?>
