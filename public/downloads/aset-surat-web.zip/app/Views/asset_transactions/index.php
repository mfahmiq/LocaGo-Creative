<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW DAFTAR TRANSAKSI ASET
| -------------------------------------------------------------------
| Halaman ini menampilkan riwayat peminjaman aset antar unit, termasuk
| status transaksi dan jumlah item yang dipinjam.
|
| Tips Debugging:
| - Jika item_count kosong, cek join tabel asset_transaction_items di controller.
*/
?>

<?= $this->section('content') ?>
<div class="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
    <div>
        <h2 class="h5 mb-1">Peminjaman & Pengembalian Aset</h2>
        <div class="text-muted">Catat aset yang dipinjam unit lain dan pantau pengembaliannya.</div>
    </div>
    <?php if (is_role(['admin', 'operator'])): ?>
        <a href="<?= site_url('asset-transactions/create') ?>" class="btn btn-success">
            <i class="bi bi-plus-circle me-2"></i>Tambah Transaksi
        </a>
    <?php endif; ?>
</div>

<form method="get" class="content-panel mb-3">
    <div class="row g-2">
        <div class="col-12 col-md-8">
            <input type="search" class="form-control" name="q" value="<?= esc($filters['q']) ?>" placeholder="Cari kode transaksi, unit, peminjam, keperluan">
        </div>
        <div class="col-12 col-md-2">
            <select class="form-select" name="status">
                <option value="">Semua status</option>
                <?php foreach ($statuses as $key => $label): ?>
                    <option value="<?= esc($key) ?>" <?= $filters['status'] === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-md-2 d-grid">
            <button class="btn btn-outline-success" type="submit">
                <i class="bi bi-search me-2"></i>Filter
            </button>
        </div>
    </div>
</form>

<div class="table-panel">
    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
            <tr>
                <th>Kode</th>
                <th>Unit Peminjam</th>
                <th>Penanggung Jawab</th>
                <th>Tanggal Pinjam</th>
                <th>Rencana Kembali</th>
                <th>Item</th>
                <th>Status</th>
                <th class="text-end">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($transactions as $row): ?>
                <?php
                $status = $row['status'];
                if ($status === 'dipinjam' && ! empty($row['expected_return_date']) && $row['expected_return_date'] < date('Y-m-d')) {
                    $status = 'terlambat';
                }
                ?>
                <tr>
                    <td class="fw-semibold"><?= esc($row['transaction_code']) ?></td>
                    <td><?= esc($row['borrower_unit']) ?></td>
                    <td><?= esc($row['borrower_name']) ?></td>
                    <td><?= esc(date_id($row['loan_date'])) ?></td>
                    <td><?= esc(date_id($row['expected_return_date'])) ?></td>
                    <td><?= esc($row['item_count']) ?></td>
                    <td><span class="badge <?= status_badge_class($status) ?>"><?= esc(human_status($status)) ?></span></td>
                    <td class="text-end">
                        <a href="<?= site_url('asset-transactions/' . $row['id'] . '/pdf') ?>" class="btn btn-outline-danger btn-icon" data-bs-toggle="tooltip" title="Download PDF">
                            <i class="bi bi-file-earmark-pdf"></i>
                        </a>
                        <a href="<?= site_url('asset-transactions/' . $row['id']) ?>" class="btn btn-outline-success btn-icon" data-bs-toggle="tooltip" title="Detail">
                            <i class="bi bi-eye"></i>
                        </a>
                        <?php if (is_role('admin')): ?>
                            <form action="<?= site_url('asset-transactions/' . $row['id'] . '/delete') ?>" method="post" class="d-inline js-confirm-delete">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-outline-danger btn-icon" data-bs-toggle="tooltip" title="Hapus">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if ($transactions === []): ?>
                <tr><td colspan="8" class="empty-state">Belum ada transaksi aset.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?= $pager->links() ?>
</div>
<?= $this->endSection() ?>
