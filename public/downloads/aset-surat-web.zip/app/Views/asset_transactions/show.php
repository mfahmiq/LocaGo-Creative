<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW DETAIL TRANSAKSI ASET
| -------------------------------------------------------------------
| Halaman ini menampilkan detail peminjaman aset dan form pengembalian
| jika status transaksi masih aktif.
|
| Tips Debugging:
| - Jika form pengembalian tidak tampil, status transaksi mungkin sudah selesai.
*/
$isActive = in_array($transaction['status'], ['dipinjam', 'terlambat'], true);
?>

<?= $this->section('content') ?>
<div class="row g-3">
    <div class="col-12 col-xl-7">
        <div class="content-panel">
            <div class="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
                <div>
                    <h2 class="h5 mb-1"><?= esc($transaction['transaction_code']) ?></h2>
                    <div class="text-muted"><?= esc($transaction['borrower_unit']) ?></div>
                </div>
                <div class="d-flex flex-column flex-sm-row gap-2">
                    <a href="<?= site_url('asset-transactions/' . $transaction['id'] . '/pdf') ?>" class="btn btn-outline-danger">
                        <i class="bi bi-file-earmark-pdf me-2"></i>Download PDF
                    </a>
                    <a href="<?= site_url('asset-transactions') ?>" class="btn btn-outline-secondary">Kembali</a>
                </div>
            </div>

            <dl class="row">
                <dt class="col-sm-4">Unit Peminjam</dt>
                <dd class="col-sm-8"><?= esc($transaction['borrower_unit']) ?></dd>
                <dt class="col-sm-4">Penanggung Jawab</dt>
                <dd class="col-sm-8"><?= esc($transaction['borrower_name']) ?></dd>
                <dt class="col-sm-4">Tanggal Pinjam</dt>
                <dd class="col-sm-8"><?= esc(date_id($transaction['loan_date'])) ?></dd>
                <dt class="col-sm-4">Rencana Kembali</dt>
                <dd class="col-sm-8"><?= esc(date_id($transaction['expected_return_date'])) ?></dd>
                <dt class="col-sm-4">Tanggal Kembali</dt>
                <dd class="col-sm-8"><?= esc(date_id($transaction['actual_return_date'])) ?></dd>
                <dt class="col-sm-4">Status</dt>
                <dd class="col-sm-8"><span class="badge <?= status_badge_class($transaction['status']) ?>"><?= esc(human_status($transaction['status'])) ?></span></dd>
                <dt class="col-sm-4">Keperluan</dt>
                <dd class="col-sm-8"><?= esc($transaction['purpose'] ?: '-') ?></dd>
                <dt class="col-sm-4">Catatan</dt>
                <dd class="col-sm-8"><?= esc($transaction['notes'] ?: '-') ?></dd>
                <dt class="col-sm-4">Dicatat Oleh</dt>
                <dd class="col-sm-8"><?= esc($transaction['creator_name'] ?: '-') ?></dd>
            </dl>

            <h3 class="h6 mt-4">Item Dipinjam</h3>
            <div class="table-responsive">
                <table class="table table-sm align-middle">
                    <thead>
                    <tr>
                        <th>Aset</th>
                        <th>Jumlah</th>
                        <th>Kondisi Awal</th>
                        <th>Kondisi Kembali</th>
                        <th>Catatan</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?= esc(($item['asset_code'] ?: '-') . ' - ' . ($item['asset_name'] ?: 'Aset terhapus')) ?></td>
                            <td><?= esc($item['quantity']) ?></td>
                            <td><?= esc(human_status($item['condition_before'])) ?></td>
                            <td><?= esc($item['condition_after'] ? human_status($item['condition_after']) : '-') ?></td>
                            <td><?= esc($item['notes'] ?: '-') ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-12 col-xl-5">
        <?php if ($isActive && is_role(['admin', 'operator'])): ?>
            <form action="<?= site_url('asset-transactions/' . $transaction['id'] . '/return') ?>" method="post" class="content-panel">
                <?= csrf_field() ?>
                <h2 class="h5 mb-3">Catat Pengembalian</h2>
                <div class="mb-3">
                    <label class="form-label" for="actual_return_date">Tanggal Kembali</label>
                    <input type="date" class="form-control" id="actual_return_date" name="actual_return_date" value="<?= date('Y-m-d') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label" for="status">Status Akhir</label>
                    <select class="form-select" id="status" name="status">
                        <option value="dikembalikan">Dikembalikan</option>
                        <option value="rusak_saat_kembali">Rusak Saat Kembali</option>
                        <option value="hilang">Hilang</option>
                        <option value="dibatalkan">Dibatalkan</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Kondisi Barang Saat Kembali</label>
                    <?php foreach ($items as $item): ?>
                        <div class="border rounded p-2 mb-2">
                            <div class="small fw-semibold mb-1"><?= esc($item['asset_name']) ?></div>
                            <select class="form-select form-select-sm" name="condition_after[<?= esc($item['id']) ?>]">
                                <?php foreach ($conditions as $key => $label): ?>
                                    <option value="<?= esc($key) ?>" <?= $key === $item['condition_before'] ? 'selected' : '' ?>><?= esc($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="notes">Catatan Akhir</label>
                    <textarea class="form-control" id="notes" name="notes" rows="3"><?= esc($transaction['notes'] ?: '') ?></textarea>
                </div>
                <button class="btn btn-success w-100" type="submit">
                    <i class="bi bi-check-circle me-2"></i>Simpan Pengembalian
                </button>
            </form>
        <?php else: ?>
            <div class="content-panel">
                <h2 class="h5 mb-2">Status Transaksi</h2>
                <p class="text-muted mb-0">Transaksi ini tidak lagi aktif untuk proses pengembalian.</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?>
