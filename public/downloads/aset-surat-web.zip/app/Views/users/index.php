<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW DAFTAR PENGGUNA
| -------------------------------------------------------------------
| Halaman ini menampilkan akun yang dapat mengakses aplikasi. Hanya Admin
| yang dapat membuka halaman ini melalui filter role.
|
| Tips Debugging:
| - Jika tombol hapus tidak bekerja, pastikan public/app-assets/js/app.js termuat.
*/
?>

<?= $this->section('content') ?>
<div class="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
    <div>
        <h2 class="h5 mb-1">Akun Pengguna</h2>
        <div class="text-muted">Kelola admin, operator tata usaha, dan pimpinan.</div>
    </div>
    <a href="<?= site_url('users/create') ?>" class="btn btn-success">
        <i class="bi bi-person-plus me-2"></i>Tambah Pengguna
    </a>
</div>

<div class="table-panel">
    <div class="table-responsive">
        <table class="table align-middle">
            <thead>
            <tr>
                <th>Nama</th>
                <th>Username</th>
                <th>Role</th>
                <th>Status</th>
                <th>Login Terakhir</th>
                <th class="text-end">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($users as $row): ?>
                <tr>
                    <td class="fw-semibold"><?= esc($row['name']) ?></td>
                    <td><?= esc($row['username']) ?></td>
                    <td><?= esc(role_label($row['role'])) ?></td>
                    <td>
                        <span class="badge <?= $row['is_active'] ? 'text-bg-success' : 'text-bg-secondary' ?>">
                            <?= $row['is_active'] ? 'Aktif' : 'Nonaktif' ?>
                        </span>
                    </td>
                    <td><?= esc($row['last_login_at'] ? date('d/m/Y H:i', strtotime($row['last_login_at'])) : '-') ?></td>
                    <td class="text-end">
                        <a href="<?= site_url('users/' . $row['id'] . '/edit') ?>" class="btn btn-outline-secondary btn-icon" data-bs-toggle="tooltip" title="Edit">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <?php if ((int) current_user('id') !== (int) $row['id']): ?>
                            <form action="<?= site_url('users/' . $row['id'] . '/delete') ?>" method="post" class="d-inline js-confirm-delete">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-outline-danger btn-icon" data-bs-toggle="tooltip" title="Hapus">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if ($users === []): ?>
                <tr><td colspan="6" class="empty-state">Belum ada pengguna.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>
