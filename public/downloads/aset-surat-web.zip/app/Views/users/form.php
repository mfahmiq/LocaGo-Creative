<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW FORM PENGGUNA
| -------------------------------------------------------------------
| Form ini dipakai untuk tambah dan edit akun. Password wajib saat tambah,
| tetapi opsional saat edit agar admin tidak perlu mengganti password selalu.
|
| Tips Debugging:
| - Jika data tidak masuk ke controller, cek atribut name pada input.
*/
$isEdit = $user !== null;
?>

<?= $this->section('content') ?>
<form action="<?= $isEdit ? site_url('users/' . $user['id']) : site_url('users') ?>" method="post" class="content-panel">
    <?= csrf_field() ?>
    <div class="row g-3">
        <div class="col-12 col-md-6">
            <label class="form-label" for="name">Nama Lengkap</label>
            <input type="text" class="form-control" id="name" name="name" value="<?= old('name', $user['name'] ?? '') ?>" required>
        </div>
        <div class="col-12 col-md-6">
            <label class="form-label" for="username">Username</label>
            <input type="text" class="form-control" id="username" name="username" value="<?= old('username', $user['username'] ?? '') ?>" required>
        </div>
        <div class="col-12 col-md-6">
            <label class="form-label" for="password">Password <?= $isEdit ? 'Baru' : '' ?></label>
            <input type="password" class="form-control" id="password" name="password" <?= $isEdit ? '' : 'required' ?>>
            <div class="form-hint"><?= $isEdit ? 'Kosongkan jika tidak ingin mengganti password.' : 'Minimal 6 karakter.' ?></div>
        </div>
        <div class="col-12 col-md-3">
            <label class="form-label" for="role">Role</label>
            <select class="form-select" id="role" name="role" required>
                <?php foreach ($roles as $key => $label): ?>
                    <option value="<?= esc($key) ?>" <?= old('role', $user['role'] ?? '') === $key ? 'selected' : '' ?>>
                        <?= esc($label) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-md-3">
            <label class="form-label" for="is_active">Status</label>
            <select class="form-select" id="is_active" name="is_active">
                <option value="1" <?= (string) old('is_active', $user['is_active'] ?? 1) === '1' ? 'selected' : '' ?>>Aktif</option>
                <option value="0" <?= (string) old('is_active', $user['is_active'] ?? 1) === '0' ? 'selected' : '' ?>>Nonaktif</option>
            </select>
        </div>
    </div>

    <div class="d-flex justify-content-end gap-2 mt-4">
        <a href="<?= site_url('users') ?>" class="btn btn-outline-secondary">Batal</a>
        <button type="submit" class="btn btn-success">
            <i class="bi bi-save me-2"></i>Simpan
        </button>
    </div>
</form>
<?= $this->endSection() ?>
