<?php
/*
| -------------------------------------------------------------------
| LAYOUT UTAMA APLIKASI
| -------------------------------------------------------------------
| Layout ini menjadi kerangka semua halaman setelah login. Bootstrap 5.3.8
| dipakai tanpa SB Admin, lalu dilengkapi Chart.js, SweetAlert2, dan Toastr.
|
| Alur Kerja:
| - Controller mengirim title dan data halaman.
| - View halaman mengisi section content.
| - Layout menampilkan sidebar, topbar, flash message, dan asset JS/CSS.
|
| Tips Debugging:
| - Jika section content kosong, pastikan view memanggil $this->section('content').
| - Jika asset CDN gagal, periksa koneksi internet atau ganti ke file lokal.
*/
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= esc($title ?? 'SMPI REJIS') ?> | SMPI REJIS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css" rel="stylesheet">
    <link href="<?= base_url('app-assets/css/app.css') ?>" rel="stylesheet">
    <?= $this->renderSection('styles') ?>
</head>
<body>
<div class="app-shell">
    <aside class="sidebar">
        <div class="d-flex align-items-center gap-3 mb-4">
            <span class="brand-mark logo-mark">
                <img src="<?= base_url('app-assets/img/rejis-logo.svg') ?>" alt="Logo REJIS">
            </span>
            <div>
                <div class="fw-bold">SMPI REJIS</div>
                <div class="small text-white-50">Inventaris & Surat</div>
            </div>
        </div>

        <nav class="nav flex-column">
            <a class="nav-link rejis-link <?= active_menu('dashboard') ?>" href="<?= site_url('dashboard') ?>">
                <i class="bi bi-speedometer2"></i><span>Dashboard</span>
            </a>
            <?php if (is_role('admin')): ?>
                <a class="nav-link rejis-link <?= active_menu('users') ?>" href="<?= site_url('users') ?>">
                    <i class="bi bi-people"></i><span>Pengguna</span>
                </a>
            <?php endif; ?>
            <a class="nav-link rejis-link <?= active_menu('assets') ?>" href="<?= site_url('assets') ?>">
                <i class="bi bi-box-seam"></i><span>Inventaris Aset</span>
            </a>
            <a class="nav-link rejis-link <?= active_menu('asset-transactions') ?>" href="<?= site_url('asset-transactions') ?>">
                <i class="bi bi-arrow-left-right"></i><span>Transaksi Aset</span>
            </a>
            <a class="nav-link rejis-link <?= active_menu('inventory-requests') ?>" href="<?= site_url('inventory-requests') ?>">
                <i class="bi bi-clipboard-check"></i><span>Pengajuan Inventaris</span>
            </a>
            <a class="nav-link rejis-link <?= active_menu('incoming-letters') ?>" href="<?= site_url('incoming-letters') ?>">
                <i class="bi bi-envelope-arrow-down"></i><span>Surat Masuk</span>
            </a>
            <a class="nav-link rejis-link <?= active_menu('outgoing-letters') ?>" href="<?= site_url('outgoing-letters') ?>">
                <i class="bi bi-envelope-arrow-up"></i><span>Surat Keluar</span>
            </a>
            <a class="nav-link rejis-link <?= active_menu('dispositions') ?>" href="<?= site_url('dispositions') ?>">
                <i class="bi bi-send-check"></i><span>Disposisi</span>
            </a>
            <a class="nav-link rejis-link <?= active_menu('reports') ?>" href="<?= site_url('reports') ?>">
                <i class="bi bi-file-earmark-bar-graph"></i><span>Laporan</span>
            </a>
            <?php if (is_role('admin')): ?>
                <a class="nav-link rejis-link <?= active_menu('backup') ?>" href="<?= site_url('backup') ?>">
                    <i class="bi bi-database-down"></i><span>Backup</span>
                </a>
            <?php endif; ?>
        </nav>
    </aside>

    <main class="main-area">
        <div class="topbar">
            <div class="d-flex align-items-center justify-content-between px-3 px-lg-4 py-3">
                <div class="d-flex align-items-center gap-2">
                    <button class="btn btn-outline-secondary btn-icon d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu" aria-label="Buka menu">
                        <i class="bi bi-list"></i>
                    </button>
                    <div>
                        <h1 class="h4 mb-0"><?= esc($title ?? 'Dashboard') ?></h1>
                        <div class="small text-muted"><?= esc(role_label(current_user('role'))) ?></div>
                    </div>
                </div>
                <div class="dropdown">
                    <button class="btn btn-light border d-flex align-items-center gap-2" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle"></i>
                        <span class="d-none d-sm-inline"><?= esc(current_user('name')) ?></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><span class="dropdown-item-text small text-muted"><?= esc(current_user('username')) ?></span></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= site_url('logout') ?>"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="offcanvas offcanvas-start" tabindex="-1" id="mobileMenu">
            <div class="offcanvas-header">
                <div class="d-flex align-items-center gap-2">
                    <span class="brand-mark logo-mark logo-mark-sm">
                        <img src="<?= base_url('app-assets/img/rejis-logo.svg') ?>" alt="Logo REJIS">
                    </span>
                    <h2 class="h5 offcanvas-title mb-0">SMPI REJIS</h2>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Tutup"></button>
            </div>
            <div class="offcanvas-body">
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action" href="<?= site_url('dashboard') ?>">Dashboard</a>
                    <?php if (is_role('admin')): ?>
                        <a class="list-group-item list-group-item-action" href="<?= site_url('users') ?>">Pengguna</a>
                    <?php endif; ?>
                    <a class="list-group-item list-group-item-action" href="<?= site_url('assets') ?>">Inventaris Aset</a>
                    <a class="list-group-item list-group-item-action" href="<?= site_url('asset-transactions') ?>">Transaksi Aset</a>
                    <a class="list-group-item list-group-item-action" href="<?= site_url('inventory-requests') ?>">Pengajuan Inventaris</a>
                    <a class="list-group-item list-group-item-action" href="<?= site_url('incoming-letters') ?>">Surat Masuk</a>
                    <a class="list-group-item list-group-item-action" href="<?= site_url('outgoing-letters') ?>">Surat Keluar</a>
                    <a class="list-group-item list-group-item-action" href="<?= site_url('dispositions') ?>">Disposisi</a>
                    <a class="list-group-item list-group-item-action" href="<?= site_url('reports') ?>">Laporan</a>
                    <?php if (is_role('admin')): ?>
                        <a class="list-group-item list-group-item-action" href="<?= site_url('backup') ?>">Backup</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <section class="page-content">
            <?php if (session('errors')): ?>
                <div class="alert alert-danger">
                    <div class="fw-semibold mb-1">Periksa kembali input berikut:</div>
                    <ul class="mb-0">
                        <?php foreach ((array) session('errors') as $error): ?>
                            <li><?= esc($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?= $this->renderSection('content') ?>
        </section>
    </main>
</div>

<script>
    window.flashMessages = {
        success: <?= json_encode(session('success')) ?>,
        error: <?= json_encode(session('error')) ?>
    };
</script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js"></script>
<script src="<?= base_url('app-assets/js/app.js') ?>"></script>
<?= $this->renderSection('scripts') ?>
</body>
</html>
