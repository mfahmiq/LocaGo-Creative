<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW DETAIL SURAT KELUAR
| -------------------------------------------------------------------
| Detail surat keluar menampilkan data surat dan form pembaruan status
| pengiriman sampai diterima tujuan.
|
| Tips Debugging:
| - Jika status diterima ditolak, isi nama penerima dan tanggal diterima.
*/
?>

<?= $this->section('content') ?>
<div class="row g-3">
    <div class="col-12 col-xl-7">
        <div class="content-panel">
            <div class="d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
                <div>
                    <h2 class="h5 mb-1"><?= esc($letter['subject']) ?></h2>
                    <div class="text-muted"><?= esc($letter['letter_number']) ?></div>
                </div>
                <div class="d-flex gap-2">
                    <a href="<?= site_url('outgoing-letters') ?>" class="btn btn-outline-secondary">Kembali</a>
                    <?php if (is_role(['admin', 'operator'])): ?>
                        <a href="<?= site_url('outgoing-letters/' . $letter['id'] . '/edit') ?>" class="btn btn-success">
                            <i class="bi bi-pencil me-2"></i>Edit
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <dl class="row mb-0">
                <dt class="col-sm-4">Tanggal Surat</dt>
                <dd class="col-sm-8"><?= esc(date_id($letter['letter_date'])) ?></dd>
                <dt class="col-sm-4">Tujuan</dt>
                <dd class="col-sm-8"><?= esc($letter['recipient']) ?></dd>
                <dt class="col-sm-4">Unit Tujuan</dt>
                <dd class="col-sm-8"><?= esc($letter['destination_unit'] ?: '-') ?></dd>
                <dt class="col-sm-4">Status</dt>
                <dd class="col-sm-8"><span class="badge <?= status_badge_class($letter['status']) ?>"><?= esc(human_status($letter['status'])) ?></span></dd>
                <dt class="col-sm-4">Penerima</dt>
                <dd class="col-sm-8"><?= esc($letter['receiver_name'] ?: '-') ?></dd>
                <dt class="col-sm-4">Tanggal Diterima</dt>
                <dd class="col-sm-8"><?= esc(date_id($letter['received_date'])) ?></dd>
                <dt class="col-sm-4">Catatan Pengiriman</dt>
                <dd class="col-sm-8"><?= esc($letter['delivery_notes'] ?: '-') ?></dd>
                <dt class="col-sm-4">Lampiran</dt>
                <dd class="col-sm-8">
                    <?php if (! empty($letter['attachment'])): ?>
                        <a href="<?= base_url($letter['attachment']) ?>" target="_blank">Buka lampiran</a>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </dd>
                <dt class="col-sm-4">Dicatat Oleh</dt>
                <dd class="col-sm-8"><?= esc($letter['creator_name'] ?: '-') ?></dd>
            </dl>
        </div>
    </div>

    <div class="col-12 col-xl-5">
        <?php if (is_role(['admin', 'operator'])): ?>
            <form action="<?= site_url('outgoing-letters/' . $letter['id'] . '/delivery') ?>" method="post" class="content-panel">
                <?= csrf_field() ?>
                <h2 class="h5 mb-3">Update Pengiriman</h2>
                <div class="mb-3">
                    <label class="form-label" for="status">Status Pengiriman</label>
                    <select class="form-select" id="status" name="status">
                        <?php foreach ($statuses as $key => $label): ?>
                            <option value="<?= esc($key) ?>" <?= $letter['status'] === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label" for="receiver_name">Nama Penerima</label>
                    <input type="text" class="form-control" id="receiver_name" name="receiver_name" value="<?= old('receiver_name', $letter['receiver_name'] ?? '') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label" for="received_date">Tanggal Diterima</label>
                    <input type="date" class="form-control" id="received_date" name="received_date" value="<?= old('received_date', $letter['received_date'] ?? '') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label" for="delivery_notes">Catatan Pengiriman</label>
                    <textarea class="form-control" id="delivery_notes" name="delivery_notes" rows="3"><?= old('delivery_notes', $letter['delivery_notes'] ?? '') ?></textarea>
                </div>
                <button type="submit" class="btn btn-success w-100">
                    <i class="bi bi-truck me-2"></i>Simpan Status
                </button>
            </form>
        <?php endif; ?>
    </div>
</div>
<?= $this->endSection() ?>
