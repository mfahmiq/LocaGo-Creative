<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW FORM SURAT KELUAR
| -------------------------------------------------------------------
| Form ini mencatat arsip surat keluar setelah surat siap/ditandatangani.
| Bukti penerimaan diisi terpisah dari halaman detail.
|
| Tips Debugging:
| - Jika status tidak masuk, cek select name="status".
*/
$isEdit = $letter !== null;
?>

<?= $this->section('content') ?>
<form action="<?= $isEdit ? site_url('outgoing-letters/' . $letter['id']) : site_url('outgoing-letters') ?>" method="post" enctype="multipart/form-data" class="content-panel">
    <?= csrf_field() ?>
    <div class="row g-3">
        <div class="col-12 col-md-4">
            <label class="form-label" for="letter_number">Nomor Surat</label>
            <input type="text" class="form-control" id="letter_number" name="letter_number" value="<?= old('letter_number', $letter['letter_number'] ?? '') ?>" required>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="letter_date">Tanggal Surat</label>
            <input type="date" class="form-control" id="letter_date" name="letter_date" value="<?= old('letter_date', $letter['letter_date'] ?? date('Y-m-d')) ?>" required>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label" for="status">Status Awal</label>
            <select class="form-select" id="status" name="status" required>
                <?php foreach ($statuses as $key => $label): ?>
                    <option value="<?= esc($key) ?>" <?= old('status', $letter['status'] ?? 'dicatat') === $key ? 'selected' : '' ?>><?= esc($label) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-md-6">
            <label class="form-label" for="recipient">Tujuan Surat</label>
            <input type="text" class="form-control" id="recipient" name="recipient" value="<?= old('recipient', $letter['recipient'] ?? '') ?>" required>
        </div>
        <div class="col-12 col-md-6">
            <label class="form-label" for="destination_unit">Unit Tujuan</label>
            <input type="text" class="form-control" id="destination_unit" name="destination_unit" value="<?= old('destination_unit', $letter['destination_unit'] ?? '') ?>" placeholder="Contoh: Unit SD">
        </div>
        <div class="col-12">
            <label class="form-label" for="subject">Perihal</label>
            <input type="text" class="form-control" id="subject" name="subject" value="<?= old('subject', $letter['subject'] ?? '') ?>" required>
        </div>
        <div class="col-12">
            <label class="form-label" for="attachment">Lampiran Surat</label>
            <input type="file" class="form-control" id="attachment" name="attachment" accept=".pdf,.jpg,.jpeg,.png,.webp">
            <div class="form-hint">Opsional. Format PDF/JPG/PNG/WEBP. Maksimal 8 MB.</div>
            <?php if ($isEdit && ! empty($letter['attachment'])): ?>
                <a href="<?= base_url($letter['attachment']) ?>" target="_blank" class="d-inline-block mt-2">Lihat lampiran saat ini</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="d-flex justify-content-end gap-2 mt-4">
        <a href="<?= site_url('outgoing-letters') ?>" class="btn btn-outline-secondary">Batal</a>
        <button type="submit" class="btn btn-success">
            <i class="bi bi-save me-2"></i>Simpan
        </button>
    </div>
</form>
<?= $this->endSection() ?>
