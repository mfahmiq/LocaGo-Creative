<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex flex-column flex-xl-row gap-3 justify-content-between align-items-xl-center mb-3">
    <div>
        <div class="text-muted small mb-1">Dokumentasi database aplikasi</div>
        <h2 class="h5 mb-0">Entity Relationship Diagram Aset Surat Web</h2>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <span class="badge text-bg-light border">PK: Primary Key</span>
        <span class="badge text-bg-light border">FK: Foreign Key</span>
        <span class="badge text-bg-light border">UQ: Unique</span>
        <span class="badge text-bg-light border">IDX: Index</span>
    </div>
</div>

<div class="content-panel erd-panel mb-4">
    <div class="mermaid erd-mermaid">
<?= esc($diagram) ?>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-12 col-xl-8">
        <div class="table-panel h-100">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3 class="h6 mb-0">Relasi Foreign Key</h3>
                <span class="text-muted small"><?= count($relationships) ?> relasi</span>
            </div>
            <div class="table-responsive">
                <table class="table table-sm align-middle">
                    <thead>
                    <tr>
                        <th>Induk</th>
                        <th>Anak</th>
                        <th>Kardinalitas</th>
                        <th>Foreign Key</th>
                        <th>Aturan</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($relationships as $relationship): ?>
                        <tr>
                            <td><code><?= esc($relationship['from']) ?></code></td>
                            <td><code><?= esc($relationship['to']) ?></code></td>
                            <td><span class="badge text-bg-primary"><?= esc($relationship['cardinality']) ?></span></td>
                            <td><code><?= esc($relationship['fk']) ?></code><div class="small text-muted"><?= esc($relationship['description']) ?></div></td>
                            <td class="small"><?= esc($relationship['action']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-12 col-xl-4">
        <div class="content-panel h-100">
            <h3 class="h6 mb-3">Catatan Desain</h3>
            <div class="small text-muted">
                <p class="mb-2">XML acuan memakai entitas peran terpisah. Pada aplikasi ini, role tidak dibuat sebagai tabel sendiri karena nilainya tetap dan disimpan di <code>users.role</code>.</p>
                <p class="mb-2">Penerima disposisi disimpan sebagai teks <code>target_unit</code>, bukan user login, agar unit tujuan non-akun tetap bisa dicatat.</p>
                <p class="mb-0">Tabel <code>migrations</code> adalah tabel sistem CodeIgniter dan tidak memiliki relasi bisnis.</p>
            </div>
        </div>
    </div>
</div>

<div class="erd-table-grid">
    <?php foreach ($tables as $tableName => $table): ?>
        <section class="table-panel erd-table-card">
            <div class="d-flex justify-content-between align-items-start gap-3 mb-3">
                <div>
                    <div class="small text-muted"><?= esc($table['module']) ?></div>
                    <h3 class="h6 mb-1"><code><?= esc($tableName) ?></code></h3>
                    <p class="small text-muted mb-0"><?= esc($table['note']) ?></p>
                </div>
                <span class="badge text-bg-light border"><?= count($table['columns']) ?> kolom</span>
            </div>

            <div class="table-responsive">
                <table class="table table-sm erd-column-table">
                    <thead>
                    <tr>
                        <th>Kolom</th>
                        <th>Tipe</th>
                        <th>Key</th>
                        <th>Null</th>
                        <th>Default</th>
                        <th>Keterangan</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($table['columns'] as $column): ?>
                        <tr>
                            <td><code><?= esc($column['name']) ?></code></td>
                            <td><code><?= esc($column['type']) ?></code></td>
                            <td>
                                <?php if ($column['key'] !== ''): ?>
                                    <span class="badge erd-key-badge"><?= esc($column['key']) ?></span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td><?= $column['null'] ? 'Ya' : 'Tidak' ?></td>
                            <td><?= $column['default'] !== '' ? '<code>' . esc($column['default']) . '</code>' : '<span class="text-muted">-</span>' ?></td>
                            <td class="small"><?= esc($column['description']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="small text-muted mt-2">
                <span class="fw-semibold">Index:</span>
                <?= esc(implode('; ', $table['indexes'])) ?>
            </div>
        </section>
    <?php endforeach; ?>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script type="module">
    import mermaid from 'https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs';

    mermaid.initialize({
        startOnLoad: true,
        theme: 'base',
        themeVariables: {
            primaryColor: '#ffffff',
            primaryTextColor: '#1d2525',
            primaryBorderColor: '#0f8f83',
            lineColor: '#6b7474',
            secondaryColor: '#f4f6f5',
            tertiaryColor: '#e8f3f1'
        },
        er: {
            useMaxWidth: false,
            diagramPadding: 20
        }
    });
</script>
<?= $this->endSection() ?>
