<?= $this->extend('layouts/main') ?>

<?php
/*
| -------------------------------------------------------------------
| VIEW BACKUP DATABASE
| -------------------------------------------------------------------
| Halaman ini memberi Admin tombol unduh backup SQL manual sebagai langkah
| perlindungan data inventaris dan arsip surat.
|
| Tips Debugging:
| - Jika tombol download error, cek koneksi database dan BackupController.
*/
?>

<?= $this->section('content') ?>
<div class="content-panel">
    <div class="d-flex flex-column flex-lg-row justify-content-between gap-3">
        <div>
            <h2 class="h5 mb-2">Backup Database Manual</h2>
            <p class="text-muted mb-0">
                Unduh file SQL berisi struktur dan data tabel aplikasi. Simpan file ini di lokasi aman secara berkala.
            </p>
        </div>
        <form action="<?= site_url('backup/download') ?>" method="post">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-success">
                <i class="bi bi-database-down me-2"></i>Unduh Backup SQL
            </button>
        </form>
    </div>

    <hr>

    <h3 class="h6">Tabel yang akan dibackup</h3>
    <div class="d-flex flex-wrap gap-2">
        <?php foreach ($tables as $table): ?>
            <span class="badge text-bg-light border"><?= esc($table) ?></span>
        <?php endforeach; ?>
    </div>
</div>
<?= $this->endSection() ?>
