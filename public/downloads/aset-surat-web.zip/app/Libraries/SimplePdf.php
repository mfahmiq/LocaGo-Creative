<?php

namespace App\Libraries;

class SimplePdf
{
    public const PAGE_WIDTH = 595.28;
    public const PAGE_HEIGHT = 841.89;

    private array $pages = [];

    public function addPage(): void
    {
        $this->pages[] = '';
    }

    public function text(float $x, float $y, string $text, int $size = 10, bool $bold = false, string $align = 'left'): void
    {
        $this->ensurePage();

        if ($align !== 'left') {
            $width = $this->estimateWidth($text, $size);
            if ($align === 'center') {
                $x -= $width / 2;
            } elseif ($align === 'right') {
                $x -= $width;
            }
        }

        $font = $bold ? 'F2' : 'F1';
        $this->write(sprintf(
            "BT /%s %d Tf 1 0 0 1 %s %s Tm (%s) Tj ET\n",
            $font,
            $size,
            $this->number($x),
            $this->number($y),
            $this->escape($text)
        ));
    }

    public function line(float $x1, float $y1, float $x2, float $y2): void
    {
        $this->ensurePage();
        $this->write(sprintf(
            "%s %s m %s %s l S\n",
            $this->number($x1),
            $this->number($y1),
            $this->number($x2),
            $this->number($y2)
        ));
    }

    public function rectangle(float $x, float $y, float $width, float $height): void
    {
        $this->ensurePage();
        $this->write(sprintf(
            "%s %s %s %s re S\n",
            $this->number($x),
            $this->number($y),
            $this->number($width),
            $this->number($height)
        ));
    }

    public function output(): string
    {
        $this->ensurePage();

        $objects = [
            1 => '<< /Type /Catalog /Pages 2 0 R >>',
            3 => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
            4 => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>',
        ];

        $pageIds = [];
        $nextObjectId = 5;

        foreach ($this->pages as $stream) {
            $contentId = $nextObjectId++;
            $pageId = $nextObjectId++;
            $pageIds[] = $pageId . ' 0 R';

            $objects[$contentId] = "<< /Length " . strlen($stream) . " >>\nstream\n" . $stream . "endstream";
            $objects[$pageId] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '
                . $this->number(self::PAGE_WIDTH) . ' ' . $this->number(self::PAGE_HEIGHT)
                . '] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents '
                . $contentId . ' 0 R >>';
        }

        $objects[2] = '<< /Type /Pages /Kids [' . implode(' ', $pageIds) . '] /Count ' . count($pageIds) . ' >>';
        ksort($objects);

        $pdf = "%PDF-1.4\n";
        $offsets = [];

        foreach ($objects as $id => $object) {
            $offsets[$id] = strlen($pdf);
            $pdf .= $id . " 0 obj\n" . $object . "\nendobj\n";
        }

        $xrefOffset = strlen($pdf);
        $maxObjectId = max(array_keys($objects));
        $pdf .= "xref\n0 " . ($maxObjectId + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";

        for ($id = 1; $id <= $maxObjectId; $id++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$id]);
        }

        $pdf .= "trailer\n<< /Size " . ($maxObjectId + 1) . " /Root 1 0 R >>\n";
        $pdf .= "startxref\n" . $xrefOffset . "\n%%EOF";

        return $pdf;
    }

    private function ensurePage(): void
    {
        if ($this->pages === []) {
            $this->addPage();
        }
    }

    private function write(string $operator): void
    {
        $last = count($this->pages) - 1;
        $this->pages[$last] .= $operator;
    }

    private function escape(string $text): string
    {
        $text = preg_replace('/\s+/', ' ', trim($text)) ?? '';
        $encoded = @iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text);

        if ($encoded === false) {
            $encoded = $text;
        }

        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $encoded);
    }

    private function estimateWidth(string $text, int $size): float
    {
        $encoded = @iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text);

        return strlen($encoded === false ? $text : $encoded) * $size * 0.48;
    }

    private function number(float $value): string
    {
        return rtrim(rtrim(number_format($value, 2, '.', ''), '0'), '.');
    }
}
