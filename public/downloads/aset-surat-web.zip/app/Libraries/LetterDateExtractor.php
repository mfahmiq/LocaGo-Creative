<?php

namespace App\Libraries;

class LetterDateExtractor
{
    /*
    | -------------------------------------------------------------------
    | PEMBACA TANGGAL SURAT
    | -------------------------------------------------------------------
    | Library ini mencoba membaca tanggal dari lampiran surat. PDF berbasis
    | teks dibaca memakai pdftotext. Gambar/scan dapat dibaca jika Tesseract
    | OCR sudah terpasang di server.
    |
    | Alur Kerja:
    | - Controller mengirim path file sementara dan ekstensi file.
    | - Library mengambil teks dari file.
    | - Parser mencari format tanggal Indonesia atau numerik.
    | - Hasil dikembalikan sebagai format Y-m-d untuk input type="date".
    |
    | Tips Debugging:
    | - Jika PDF tidak terbaca, pastikan file PDF bukan scan gambar murni.
    | - Jika gambar tidak terbaca, install Tesseract dan pastikan command tesseract ada di PATH.
    */
    private array $months = [
        'januari' => 1,
        'jan' => 1,
        'februari' => 2,
        'feb' => 2,
        'maret' => 3,
        'mar' => 3,
        'april' => 4,
        'apr' => 4,
        'mei' => 5,
        'juni' => 6,
        'jun' => 6,
        'juli' => 7,
        'jul' => 7,
        'agustus' => 8,
        'agt' => 8,
        'aug' => 8,
        'september' => 9,
        'sep' => 9,
        'oktober' => 10,
        'okt' => 10,
        'oct' => 10,
        'november' => 11,
        'nov' => 11,
        'desember' => 12,
        'des' => 12,
        'dec' => 12,
    ];

    public function extract(string $path, string $extension): array
    {
        $extension = strtolower($extension);
        $text = '';
        $message = 'Tanggal surat belum ditemukan.';

        if ($extension === 'pdf') {
            $text = $this->extractPdfText($path);
            $message = $text === ''
                ? 'PDF tidak berisi teks yang bisa dibaca otomatis.'
                : 'Teks PDF berhasil dibaca.';
        } elseif (in_array($extension, ['jpg', 'jpeg', 'png', 'webp'], true)) {
            if (! $this->commandExists('tesseract')) {
                return [
                    'date' => null,
                    'message' => 'OCR gambar membutuhkan Tesseract. File tetap bisa disimpan dan tanggal dapat diisi manual.',
                ];
            }

            $text = $this->extractImageText($path);
            $message = $text === ''
                ? 'OCR gambar belum menemukan teks yang jelas.'
                : 'OCR gambar berhasil membaca teks.';
        }

        $date = $this->parseDate($text);

        return [
            'date' => $date,
            'message' => $date ? 'Tanggal surat berhasil dikenali.' : $message,
        ];
    }

    private function extractPdfText(string $path): string
    {
        /*
        | -------------------------------------------------------------------
        | EKSTRAKSI TEKS PDF
        | -------------------------------------------------------------------
        | Menggunakan pdftotext karena Laragon Git biasanya menyediakannya.
        | Output diarahkan ke stdout agar tidak membuat file tambahan.
        |
        | Tips Debugging:
        | - Jika command tidak ditemukan, install Poppler atau pastikan pdftotext ada di PATH.
        */
        if (! $this->commandExists('pdftotext')) {
            return '';
        }

        $command = 'pdftotext -layout -enc UTF-8 ' . escapeshellarg($path) . ' - 2>NUL';

        return trim((string) shell_exec($command));
    }

    private function extractImageText(string $path): string
    {
        /*
        | -------------------------------------------------------------------
        | EKSTRAKSI TEKS GAMBAR
        | -------------------------------------------------------------------
        | Tesseract membaca gambar/scan dan mengembalikan teks ke stdout.
        | Bahasa Indonesia dan Inggris dicoba agar nama bulan lebih mudah dikenali.
        |
        | Tips Debugging:
        | - Jika output kosong, coba scan ulang dengan resolusi lebih tinggi.
        */
        $command = 'tesseract ' . escapeshellarg($path) . ' stdout -l ind+eng 2>NUL';

        return trim((string) shell_exec($command));
    }

    private function parseDate(string $text): ?string
    {
        /*
        | -------------------------------------------------------------------
        | PARSER TANGGAL SURAT
        | -------------------------------------------------------------------
        | Parser mencari pola umum administrasi Indonesia, misalnya:
        | - 16 Juni 2026
        | - 16/06/2026
        | - 16-06-26
        |
        | Tips Debugging:
        | - Jika format tanggal sekolah berbeda, tambahkan pola regex baru di sini.
        */
        $normalized = mb_strtolower($text);

        if (preg_match('/\b(\d{1,2})\s+(januari|jan|februari|feb|maret|mar|april|apr|mei|juni|jun|juli|jul|agustus|agt|aug|september|sep|oktober|okt|oct|november|nov|desember|des|dec)\s+(\d{4})\b/u', $normalized, $match)) {
            return $this->formatDate((int) $match[1], $this->months[$match[2]], (int) $match[3]);
        }

        if (preg_match('/\b(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})\b/u', $normalized, $match)) {
            $year = (int) $match[3];
            $year = $year < 100 ? ($year >= 70 ? 1900 + $year : 2000 + $year) : $year;

            return $this->formatDate((int) $match[1], (int) $match[2], $year);
        }

        return null;
    }

    private function formatDate(int $day, int $month, int $year): ?string
    {
        if (! checkdate($month, $day, $year)) {
            return null;
        }

        if ($year < 2000 || $year > 2100) {
            return null;
        }

        return sprintf('%04d-%02d-%02d', $year, $month, $day);
    }

    private function commandExists(string $command): bool
    {
        $checker = PHP_OS_FAMILY === 'Windows'
            ? 'where ' . escapeshellarg($command)
            : 'command -v ' . escapeshellarg($command);

        $output = [];
        $status = 1;
        exec($checker, $output, $status);

        return $status === 0;
    }
}
