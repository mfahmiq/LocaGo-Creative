<?php

if (! function_exists('current_user')) {
    /*
    | -------------------------------------------------------------------
    | HELPER DATA PENGGUNA AKTIF
    | -------------------------------------------------------------------
    | Fungsi ini membungkus data session pengguna agar view dan controller
    | dapat membaca identitas user aktif dengan format yang konsisten.
    |
    | Alur Kerja:
    | - AuthController menyimpan data user ke session saat login berhasil.
    | - current_user() mengambil data tersebut dari session.
    | - View dapat memanggil current_user('role') atau current_user('name').
    |
    | Tips Debugging:
    | - Jika hasilnya null, pastikan pengguna sudah login.
    | - Jika key tidak ditemukan, periksa isi session pada AuthController::attempt().
    */
    function current_user(?string $key = null): mixed
    {
        $user = session('user') ?? [];

        return $key === null ? $user : ($user[$key] ?? null);
    }
}

if (! function_exists('is_role')) {
    /*
    | -------------------------------------------------------------------
    | HELPER CEK ROLE
    | -------------------------------------------------------------------
    | Fungsi ini menyederhanakan pengecekan hak akses di view, misalnya
    | untuk menampilkan tombol hanya kepada Admin atau Pimpinan.
    |
    | Alur Kerja:
    | - Role aktif dibaca dari session.
    | - Role dibandingkan dengan daftar role yang diperbolehkan.
    |
    | Tips Debugging:
    | - Jika tombol tidak muncul, pastikan role session bernilai admin/operator/pimpinan.
    */
    function is_role(string|array $roles): bool
    {
        $roles = (array) $roles;

        return in_array(current_user('role'), $roles, true);
    }
}

if (! function_exists('role_label')) {
    /*
    | -------------------------------------------------------------------
    | HELPER LABEL ROLE
    | -------------------------------------------------------------------
    | Mengubah kode role dari database menjadi label yang lebih ramah untuk
    | pengguna non-teknis.
    |
    | Tips Debugging:
    | - Jika label tampil sama dengan kode, tambahkan mapping role baru di sini.
    */
    function role_label(?string $role): string
    {
        return [
            'admin'    => 'Admin',
            'operator' => 'Operator / TU',
            'pimpinan' => 'Pimpinan',
        ][$role] ?? ucfirst((string) $role);
    }
}

if (! function_exists('status_badge_class')) {
    /*
    | -------------------------------------------------------------------
    | HELPER WARNA STATUS
    | -------------------------------------------------------------------
    | Menentukan class Bootstrap untuk badge status agar tampilan aset, surat,
    | dan disposisi konsisten di seluruh halaman.
    |
    | Tips Debugging:
    | - Jika badge abu-abu, berarti status belum masuk mapping dan perlu ditambahkan.
    */
    function status_badge_class(?string $status): string
    {
        return [
            'aktif'               => 'text-bg-success',
            'nonaktif'            => 'text-bg-secondary',
            'baik'                => 'text-bg-success',
            'rusak_ringan'        => 'text-bg-warning',
            'rusak_berat'         => 'text-bg-danger',
            'hilang'              => 'text-bg-dark',
            'menunggu_disposisi'  => 'text-bg-warning',
            'didisposisikan'      => 'text-bg-info',
            'dalam_proses'        => 'text-bg-primary',
            'selesai'             => 'text-bg-success',
            'diarsipkan'          => 'text-bg-secondary',
            'dicatat'             => 'text-bg-secondary',
            'siap_dikirim'        => 'text-bg-warning',
            'terkirim'            => 'text-bg-primary',
            'diterima_tujuan'     => 'text-bg-success',
            'pending'             => 'text-bg-warning',
            'proses'              => 'text-bg-primary',
            'dipinjam'            => 'text-bg-primary',
            'dikembalikan'        => 'text-bg-success',
            'terlambat'           => 'text-bg-warning',
            'rusak_saat_kembali'  => 'text-bg-danger',
            'dibatalkan'          => 'text-bg-secondary',
            'diajukan'            => 'text-bg-warning',
            'diproses'            => 'text-bg-primary',
            'disetujui'           => 'text-bg-success',
            'ditolak'             => 'text-bg-danger',
            'direalisasikan'      => 'text-bg-info',
        ][$status] ?? 'text-bg-secondary';
    }
}

if (! function_exists('human_status')) {
    /*
    | -------------------------------------------------------------------
    | HELPER LABEL STATUS
    | -------------------------------------------------------------------
    | Mengubah kode status berbasis snake_case menjadi teks normal sehingga
    | tabel dan detail data mudah dibaca oleh staf sekolah.
    |
    | Tips Debugging:
    | - Jika label kurang tepat, tambahkan kasus khusus sebelum fallback ucwords().
    */
    function human_status(?string $status): string
    {
        return [
            'menunggu_disposisi' => 'Menunggu Disposisi',
            'didisposisikan'     => 'Didisposisikan',
            'dalam_proses'       => 'Dalam Proses',
            'selesai'            => 'Selesai',
            'diarsipkan'         => 'Diarsipkan',
            'dicatat'            => 'Dicatat',
            'siap_dikirim'       => 'Siap Dikirim',
            'terkirim'           => 'Terkirim',
            'diterima_tujuan'    => 'Diterima Tujuan',
            'baik'               => 'Baik',
            'rusak_ringan'       => 'Rusak Ringan',
            'rusak_berat'        => 'Rusak Berat',
            'hilang'             => 'Hilang',
            'pending'            => 'Pending',
            'proses'             => 'Proses',
            'dipinjam'           => 'Dipinjam',
            'dikembalikan'       => 'Dikembalikan',
            'terlambat'          => 'Terlambat',
            'rusak_saat_kembali' => 'Rusak Saat Kembali',
            'dibatalkan'         => 'Dibatalkan',
            'diajukan'           => 'Diajukan',
            'diproses'           => 'Diproses',
            'disetujui'          => 'Disetujui',
            'ditolak'            => 'Ditolak',
            'direalisasikan'     => 'Direalisasikan',
        ][$status] ?? ucwords(str_replace('_', ' ', (string) $status));
    }
}

if (! function_exists('date_id')) {
    /*
    | -------------------------------------------------------------------
    | HELPER FORMAT TANGGAL INDONESIA
    | -------------------------------------------------------------------
    | Menampilkan tanggal database Y-m-d menjadi format d/m/Y agar lebih
    | familier untuk administrasi sekolah.
    |
    | Tips Debugging:
    | - Jika tanggal kosong, pastikan field tanggal tidak null di database.
    */
    function date_id(?string $date): string
    {
        if (empty($date)) {
            return '-';
        }

        return date('d/m/Y', strtotime($date));
    }
}

if (! function_exists('rupiah')) {
    /*
    | -------------------------------------------------------------------
    | HELPER FORMAT RUPIAH
    | -------------------------------------------------------------------
    | Mengubah nilai angka aset menjadi format rupiah yang mudah dibaca.
    |
    | Tips Debugging:
    | - Jika nilai selalu Rp 0, periksa tipe data value pada tabel assets.
    */
    function rupiah(null|int|float|string $value): string
    {
        return 'Rp ' . number_format((float) $value, 0, ',', '.');
    }
}

if (! function_exists('active_menu')) {
    /*
    | -------------------------------------------------------------------
    | HELPER MENU AKTIF
    | -------------------------------------------------------------------
    | Memberi class aktif pada sidebar berdasarkan URI saat ini.
    |
    | Tips Debugging:
    | - Jika menu tidak aktif, pastikan prefix URI sama dengan parameter helper.
    */
    function active_menu(string $prefix): string
    {
        $segment = service('uri')->getSegment(1);

        return $segment === $prefix ? 'active' : '';
    }
}
