<?php

namespace App\Controllers;

class ErdController extends BaseController
{
    /*
    | -------------------------------------------------------------------
    | CONTROLLER ERD DATABASE
    | -------------------------------------------------------------------
    | Halaman ini mendokumentasikan struktur database aplikasi berdasarkan
    | migration, bukan hasil introspeksi database aktif, agar stabil untuk
    | dokumentasi dan review arsitektur.
    */
    public function index()
    {
        $tables = $this->tables();

        return view('erd/index', [
            'title'         => 'ERD Database',
            'tables'        => $tables,
            'relationships' => $this->relationships(),
            'diagram'       => $this->mermaidDiagram(),
        ]);
    }

    private function tables(): array
    {
        return [
            'users' => [
                'label' => 'Users',
                'module' => 'Autentikasi',
                'note' => 'Menyimpan akun login. Role disimpan sebagai enum string: admin, operator, pimpinan.',
                'columns' => [
                    ['name' => 'id', 'type' => 'INT(11) UNSIGNED', 'key' => 'PK', 'null' => false, 'default' => 'AUTO_INCREMENT', 'description' => 'Identitas unik user.'],
                    ['name' => 'name', 'type' => 'VARCHAR(120)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Nama lengkap pengguna.'],
                    ['name' => 'username', 'type' => 'VARCHAR(80)', 'key' => 'UQ', 'null' => false, 'default' => '', 'description' => 'Username login unik.'],
                    ['name' => 'password_hash', 'type' => 'VARCHAR(255)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Hash password, bukan password asli.'],
                    ['name' => 'role', 'type' => 'VARCHAR(30)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Hak akses: admin, operator, pimpinan.'],
                    ['name' => 'is_active', 'type' => 'TINYINT(1)', 'key' => '', 'null' => false, 'default' => '1', 'description' => 'Status akun aktif/nonaktif.'],
                    ['name' => 'last_login_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu login terakhir.'],
                    ['name' => 'created_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data dibuat.'],
                    ['name' => 'updated_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data diperbarui.'],
                ],
                'indexes' => ['PRIMARY KEY (id)', 'UNIQUE KEY username'],
            ],
            'asset_categories' => [
                'label' => 'Asset Categories',
                'module' => 'Referensi Aset',
                'note' => 'Master kategori aset untuk klasifikasi dan laporan.',
                'columns' => [
                    ['name' => 'id', 'type' => 'INT(11) UNSIGNED', 'key' => 'PK', 'null' => false, 'default' => 'AUTO_INCREMENT', 'description' => 'Identitas kategori.'],
                    ['name' => 'name', 'type' => 'VARCHAR(120)', 'key' => 'UQ', 'null' => false, 'default' => '', 'description' => 'Nama kategori aset.'],
                    ['name' => 'description', 'type' => 'TEXT', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Keterangan kategori.'],
                    ['name' => 'created_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data dibuat.'],
                    ['name' => 'updated_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data diperbarui.'],
                ],
                'indexes' => ['PRIMARY KEY (id)', 'UNIQUE KEY name'],
            ],
            'asset_locations' => [
                'label' => 'Asset Locations',
                'module' => 'Referensi Aset',
                'note' => 'Master lokasi atau ruangan tempat aset berada.',
                'columns' => [
                    ['name' => 'id', 'type' => 'INT(11) UNSIGNED', 'key' => 'PK', 'null' => false, 'default' => 'AUTO_INCREMENT', 'description' => 'Identitas lokasi.'],
                    ['name' => 'name', 'type' => 'VARCHAR(120)', 'key' => 'UQ', 'null' => false, 'default' => '', 'description' => 'Nama lokasi aset.'],
                    ['name' => 'description', 'type' => 'TEXT', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Keterangan lokasi.'],
                    ['name' => 'created_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data dibuat.'],
                    ['name' => 'updated_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data diperbarui.'],
                ],
                'indexes' => ['PRIMARY KEY (id)', 'UNIQUE KEY name'],
            ],
            'assets' => [
                'label' => 'Assets',
                'module' => 'Inventaris Aset',
                'note' => 'Tabel inti inventaris sekolah.',
                'columns' => [
                    ['name' => 'id', 'type' => 'INT(11) UNSIGNED', 'key' => 'PK', 'null' => false, 'default' => 'AUTO_INCREMENT', 'description' => 'Identitas aset.'],
                    ['name' => 'code', 'type' => 'VARCHAR(80)', 'key' => 'UQ', 'null' => false, 'default' => '', 'description' => 'Kode aset unik.'],
                    ['name' => 'name', 'type' => 'VARCHAR(160)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Nama aset.'],
                    ['name' => 'category_id', 'type' => 'INT UNSIGNED', 'key' => 'FK', 'null' => false, 'default' => '', 'description' => 'Relasi ke asset_categories.id.'],
                    ['name' => 'location_id', 'type' => 'INT UNSIGNED', 'key' => 'FK', 'null' => false, 'default' => '', 'description' => 'Relasi ke asset_locations.id.'],
                    ['name' => 'quantity', 'type' => 'INT(11)', 'key' => '', 'null' => false, 'default' => '1', 'description' => 'Jumlah unit aset.'],
                    ['name' => 'condition_status', 'type' => 'VARCHAR(40)', 'key' => 'IDX', 'null' => false, 'default' => 'baik', 'description' => 'Kondisi aset.'],
                    ['name' => 'acquisition_year', 'type' => 'INT(4)', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Tahun perolehan.'],
                    ['name' => 'funding_source', 'type' => 'VARCHAR(120)', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Sumber dana.'],
                    ['name' => 'value', 'type' => 'DECIMAL(14,2)', 'key' => '', 'null' => false, 'default' => '0', 'description' => 'Nilai aset.'],
                    ['name' => 'custodian', 'type' => 'VARCHAR(120)', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Penanggung jawab.'],
                    ['name' => 'photo', 'type' => 'VARCHAR(255)', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Path foto aset.'],
                    ['name' => 'notes', 'type' => 'TEXT', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Catatan aset.'],
                    ['name' => 'created_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data dibuat.'],
                    ['name' => 'updated_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data diperbarui.'],
                ],
                'indexes' => ['PRIMARY KEY (id)', 'UNIQUE KEY code', 'INDEX category_id, location_id, condition_status'],
            ],
            'incoming_letters' => [
                'label' => 'Incoming Letters',
                'module' => 'Surat Masuk',
                'note' => 'Arsip surat yang diterima sekolah.',
                'columns' => [
                    ['name' => 'id', 'type' => 'INT(11) UNSIGNED', 'key' => 'PK', 'null' => false, 'default' => 'AUTO_INCREMENT', 'description' => 'Identitas surat masuk.'],
                    ['name' => 'letter_number', 'type' => 'VARCHAR(120)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Nomor surat.'],
                    ['name' => 'letter_date', 'type' => 'DATE', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Tanggal surat.'],
                    ['name' => 'received_date', 'type' => 'DATE', 'key' => 'IDX', 'null' => false, 'default' => '', 'description' => 'Tanggal diterima.'],
                    ['name' => 'sender', 'type' => 'VARCHAR(160)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Pengirim surat.'],
                    ['name' => 'subject', 'type' => 'VARCHAR(200)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Perihal surat.'],
                    ['name' => 'priority', 'type' => 'VARCHAR(50)', 'key' => '', 'null' => false, 'default' => 'Biasa', 'description' => 'Prioritas surat.'],
                    ['name' => 'summary', 'type' => 'TEXT', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Ringkasan isi surat.'],
                    ['name' => 'attachment', 'type' => 'VARCHAR(255)', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Path lampiran.'],
                    ['name' => 'status', 'type' => 'VARCHAR(50)', 'key' => 'IDX', 'null' => false, 'default' => 'menunggu_disposisi', 'description' => 'Status proses surat.'],
                    ['name' => 'created_by', 'type' => 'INT UNSIGNED', 'key' => 'FK', 'null' => true, 'default' => 'NULL', 'description' => 'User pencatat.'],
                    ['name' => 'created_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data dibuat.'],
                    ['name' => 'updated_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data diperbarui.'],
                ],
                'indexes' => ['PRIMARY KEY (id)', 'INDEX status, received_date'],
            ],
            'dispositions' => [
                'label' => 'Dispositions',
                'module' => 'Disposisi',
                'note' => 'Instruksi tindak lanjut dari pimpinan untuk surat masuk.',
                'columns' => [
                    ['name' => 'id', 'type' => 'INT(11) UNSIGNED', 'key' => 'PK', 'null' => false, 'default' => 'AUTO_INCREMENT', 'description' => 'Identitas disposisi.'],
                    ['name' => 'incoming_letter_id', 'type' => 'INT UNSIGNED', 'key' => 'FK', 'null' => false, 'default' => '', 'description' => 'Relasi ke incoming_letters.id.'],
                    ['name' => 'target_unit', 'type' => 'VARCHAR(160)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Unit tujuan disposisi.'],
                    ['name' => 'instruction', 'type' => 'TEXT', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Instruksi pimpinan.'],
                    ['name' => 'due_date', 'type' => 'DATE', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Batas tindak lanjut.'],
                    ['name' => 'status', 'type' => 'VARCHAR(50)', 'key' => 'IDX', 'null' => false, 'default' => 'pending', 'description' => 'Status disposisi.'],
                    ['name' => 'disposed_by', 'type' => 'INT UNSIGNED', 'key' => 'FK', 'null' => true, 'default' => 'NULL', 'description' => 'User pemberi disposisi.'],
                    ['name' => 'created_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data dibuat.'],
                    ['name' => 'updated_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data diperbarui.'],
                ],
                'indexes' => ['PRIMARY KEY (id)', 'INDEX incoming_letter_id, status'],
            ],
            'outgoing_letters' => [
                'label' => 'Outgoing Letters',
                'module' => 'Surat Keluar',
                'note' => 'Arsip surat yang dibuat dan dikirim sekolah.',
                'columns' => [
                    ['name' => 'id', 'type' => 'INT(11) UNSIGNED', 'key' => 'PK', 'null' => false, 'default' => 'AUTO_INCREMENT', 'description' => 'Identitas surat keluar.'],
                    ['name' => 'letter_number', 'type' => 'VARCHAR(120)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Nomor surat.'],
                    ['name' => 'letter_date', 'type' => 'DATE', 'key' => 'IDX', 'null' => false, 'default' => '', 'description' => 'Tanggal surat.'],
                    ['name' => 'recipient', 'type' => 'VARCHAR(160)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Penerima surat.'],
                    ['name' => 'destination_unit', 'type' => 'VARCHAR(160)', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Unit tujuan.'],
                    ['name' => 'subject', 'type' => 'VARCHAR(200)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Perihal surat.'],
                    ['name' => 'attachment', 'type' => 'VARCHAR(255)', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Path lampiran.'],
                    ['name' => 'status', 'type' => 'VARCHAR(50)', 'key' => 'IDX', 'null' => false, 'default' => 'dicatat', 'description' => 'Status pengiriman.'],
                    ['name' => 'receiver_name', 'type' => 'VARCHAR(120)', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Nama penerima di tujuan.'],
                    ['name' => 'received_date', 'type' => 'DATE', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Tanggal diterima tujuan.'],
                    ['name' => 'delivery_notes', 'type' => 'TEXT', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Catatan pengiriman.'],
                    ['name' => 'created_by', 'type' => 'INT UNSIGNED', 'key' => 'FK', 'null' => true, 'default' => 'NULL', 'description' => 'User pencatat.'],
                    ['name' => 'created_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data dibuat.'],
                    ['name' => 'updated_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data diperbarui.'],
                ],
                'indexes' => ['PRIMARY KEY (id)', 'INDEX status, letter_date'],
            ],
            'asset_transactions' => [
                'label' => 'Asset Transactions',
                'module' => 'Transaksi Aset',
                'note' => 'Header transaksi peminjaman atau pengembalian aset.',
                'columns' => [
                    ['name' => 'id', 'type' => 'INT(11) UNSIGNED', 'key' => 'PK', 'null' => false, 'default' => 'AUTO_INCREMENT', 'description' => 'Identitas transaksi.'],
                    ['name' => 'transaction_code', 'type' => 'VARCHAR(80)', 'key' => 'UQ', 'null' => false, 'default' => '', 'description' => 'Kode transaksi unik.'],
                    ['name' => 'borrower_unit', 'type' => 'VARCHAR(160)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Unit peminjam.'],
                    ['name' => 'borrower_name', 'type' => 'VARCHAR(160)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Nama peminjam.'],
                    ['name' => 'purpose', 'type' => 'TEXT', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Tujuan peminjaman.'],
                    ['name' => 'loan_date', 'type' => 'DATE', 'key' => 'IDX', 'null' => false, 'default' => '', 'description' => 'Tanggal pinjam.'],
                    ['name' => 'expected_return_date', 'type' => 'DATE', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Target tanggal kembali.'],
                    ['name' => 'actual_return_date', 'type' => 'DATE', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Tanggal kembali aktual.'],
                    ['name' => 'status', 'type' => 'VARCHAR(50)', 'key' => 'IDX', 'null' => false, 'default' => 'dipinjam', 'description' => 'Status transaksi.'],
                    ['name' => 'notes', 'type' => 'TEXT', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Catatan transaksi.'],
                    ['name' => 'created_by', 'type' => 'INT UNSIGNED', 'key' => 'FK', 'null' => true, 'default' => 'NULL', 'description' => 'User pencatat.'],
                    ['name' => 'created_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data dibuat.'],
                    ['name' => 'updated_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data diperbarui.'],
                ],
                'indexes' => ['PRIMARY KEY (id)', 'UNIQUE KEY transaction_code', 'INDEX status, loan_date'],
            ],
            'asset_transaction_items' => [
                'label' => 'Asset Transaction Items',
                'module' => 'Transaksi Aset',
                'note' => 'Detail daftar aset dalam satu transaksi.',
                'columns' => [
                    ['name' => 'id', 'type' => 'INT(11) UNSIGNED', 'key' => 'PK', 'null' => false, 'default' => 'AUTO_INCREMENT', 'description' => 'Identitas detail transaksi.'],
                    ['name' => 'asset_transaction_id', 'type' => 'INT UNSIGNED', 'key' => 'FK', 'null' => false, 'default' => '', 'description' => 'Relasi ke asset_transactions.id.'],
                    ['name' => 'asset_id', 'type' => 'INT UNSIGNED', 'key' => 'FK', 'null' => true, 'default' => 'NULL', 'description' => 'Relasi ke assets.id.'],
                    ['name' => 'quantity', 'type' => 'INT(11)', 'key' => '', 'null' => false, 'default' => '1', 'description' => 'Jumlah aset dipinjam.'],
                    ['name' => 'condition_before', 'type' => 'VARCHAR(50)', 'key' => '', 'null' => false, 'default' => 'baik', 'description' => 'Kondisi sebelum dipinjam.'],
                    ['name' => 'condition_after', 'type' => 'VARCHAR(50)', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Kondisi setelah kembali.'],
                    ['name' => 'notes', 'type' => 'TEXT', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Catatan detail.'],
                    ['name' => 'created_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data dibuat.'],
                    ['name' => 'updated_at', 'type' => 'DATETIME', 'key' => '', 'null' => true, 'default' => 'NULL', 'description' => 'Waktu data diperbarui.'],
                ],
                'indexes' => ['PRIMARY KEY (id)', 'INDEX asset_transaction_id, asset_id'],
            ],
            'migrations' => [
                'label' => 'Migrations',
                'module' => 'Sistem',
                'note' => 'Tabel internal CodeIgniter untuk mencatat migration yang sudah berjalan.',
                'columns' => [
                    ['name' => 'id', 'type' => 'BIGINT UNSIGNED', 'key' => 'PK', 'null' => false, 'default' => 'AUTO_INCREMENT', 'description' => 'Identitas migration.'],
                    ['name' => 'version', 'type' => 'VARCHAR(255)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Versi migration.'],
                    ['name' => 'class', 'type' => 'VARCHAR(255)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Nama class migration.'],
                    ['name' => 'group', 'type' => 'VARCHAR(255)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Group koneksi migration.'],
                    ['name' => 'namespace', 'type' => 'VARCHAR(255)', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Namespace migration.'],
                    ['name' => 'time', 'type' => 'INT', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Timestamp eksekusi.'],
                    ['name' => 'batch', 'type' => 'INT UNSIGNED', 'key' => '', 'null' => false, 'default' => '', 'description' => 'Batch migration.'],
                ],
                'indexes' => ['PRIMARY KEY (id)'],
            ],
        ];
    }

    private function relationships(): array
    {
        return [
            ['from' => 'asset_categories', 'to' => 'assets', 'cardinality' => '1 : N', 'fk' => 'assets.category_id -> asset_categories.id', 'action' => 'ON UPDATE CASCADE, ON DELETE RESTRICT', 'description' => 'Satu kategori dapat dimiliki banyak aset.'],
            ['from' => 'asset_locations', 'to' => 'assets', 'cardinality' => '1 : N', 'fk' => 'assets.location_id -> asset_locations.id', 'action' => 'ON UPDATE CASCADE, ON DELETE RESTRICT', 'description' => 'Satu lokasi dapat ditempati banyak aset.'],
            ['from' => 'users', 'to' => 'incoming_letters', 'cardinality' => '1 : N', 'fk' => 'incoming_letters.created_by -> users.id', 'action' => 'ON UPDATE SET NULL, ON DELETE SET NULL', 'description' => 'Satu user dapat mencatat banyak surat masuk.'],
            ['from' => 'incoming_letters', 'to' => 'dispositions', 'cardinality' => '1 : N', 'fk' => 'dispositions.incoming_letter_id -> incoming_letters.id', 'action' => 'ON UPDATE CASCADE, ON DELETE CASCADE', 'description' => 'Satu surat masuk dapat memiliki banyak disposisi.'],
            ['from' => 'users', 'to' => 'dispositions', 'cardinality' => '1 : N', 'fk' => 'dispositions.disposed_by -> users.id', 'action' => 'ON UPDATE SET NULL, ON DELETE SET NULL', 'description' => 'Satu user pimpinan/admin dapat membuat banyak disposisi.'],
            ['from' => 'users', 'to' => 'outgoing_letters', 'cardinality' => '1 : N', 'fk' => 'outgoing_letters.created_by -> users.id', 'action' => 'ON UPDATE SET NULL, ON DELETE SET NULL', 'description' => 'Satu user dapat mencatat banyak surat keluar.'],
            ['from' => 'users', 'to' => 'asset_transactions', 'cardinality' => '1 : N', 'fk' => 'asset_transactions.created_by -> users.id', 'action' => 'ON UPDATE SET NULL, ON DELETE SET NULL', 'description' => 'Satu user dapat mencatat banyak transaksi aset.'],
            ['from' => 'asset_transactions', 'to' => 'asset_transaction_items', 'cardinality' => '1 : N', 'fk' => 'asset_transaction_items.asset_transaction_id -> asset_transactions.id', 'action' => 'ON UPDATE CASCADE, ON DELETE CASCADE', 'description' => 'Satu transaksi memiliki banyak item aset.'],
            ['from' => 'assets', 'to' => 'asset_transaction_items', 'cardinality' => '1 : N', 'fk' => 'asset_transaction_items.asset_id -> assets.id', 'action' => 'ON UPDATE RESTRICT, ON DELETE SET NULL', 'description' => 'Satu aset dapat muncul di banyak detail transaksi.'],
        ];
    }

    private function mermaidDiagram(): string
    {
        return <<<'MERMAID'
erDiagram
    USERS {
        int id PK
        varchar name
        varchar username UK
        varchar password_hash
        varchar role
        tinyint is_active
        datetime last_login_at
        datetime created_at
        datetime updated_at
    }
    ASSET_CATEGORIES {
        int id PK
        varchar name UK
        text description
        datetime created_at
        datetime updated_at
    }
    ASSET_LOCATIONS {
        int id PK
        varchar name UK
        text description
        datetime created_at
        datetime updated_at
    }
    ASSETS {
        int id PK
        varchar code UK
        varchar name
        int category_id FK
        int location_id FK
        int quantity
        varchar condition_status
        int acquisition_year
        varchar funding_source
        decimal value
        varchar custodian
        varchar photo
        text notes
        datetime created_at
        datetime updated_at
    }
    INCOMING_LETTERS {
        int id PK
        varchar letter_number
        date letter_date
        date received_date
        varchar sender
        varchar subject
        varchar priority
        text summary
        varchar attachment
        varchar status
        int created_by FK
        datetime created_at
        datetime updated_at
    }
    DISPOSITIONS {
        int id PK
        int incoming_letter_id FK
        varchar target_unit
        text instruction
        date due_date
        varchar status
        int disposed_by FK
        datetime created_at
        datetime updated_at
    }
    OUTGOING_LETTERS {
        int id PK
        varchar letter_number
        date letter_date
        varchar recipient
        varchar destination_unit
        varchar subject
        varchar attachment
        varchar status
        varchar receiver_name
        date received_date
        text delivery_notes
        int created_by FK
        datetime created_at
        datetime updated_at
    }
    ASSET_TRANSACTIONS {
        int id PK
        varchar transaction_code UK
        varchar borrower_unit
        varchar borrower_name
        text purpose
        date loan_date
        date expected_return_date
        date actual_return_date
        varchar status
        text notes
        int created_by FK
        datetime created_at
        datetime updated_at
    }
    ASSET_TRANSACTION_ITEMS {
        int id PK
        int asset_transaction_id FK
        int asset_id FK
        int quantity
        varchar condition_before
        varchar condition_after
        text notes
        datetime created_at
        datetime updated_at
    }

    ASSET_CATEGORIES ||--o{ ASSETS : mengelompokkan
    ASSET_LOCATIONS ||--o{ ASSETS : menempatkan
    USERS ||--o{ INCOMING_LETTERS : mencatat
    INCOMING_LETTERS ||--o{ DISPOSITIONS : memiliki
    USERS ||--o{ DISPOSITIONS : mendisposisikan
    USERS ||--o{ OUTGOING_LETTERS : mencatat
    USERS ||--o{ ASSET_TRANSACTIONS : mencatat
    ASSET_TRANSACTIONS ||--o{ ASSET_TRANSACTION_ITEMS : memiliki
    ASSETS ||--o{ ASSET_TRANSACTION_ITEMS : dipinjam
MERMAID;
    }
}
