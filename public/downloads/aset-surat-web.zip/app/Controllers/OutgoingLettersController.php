<?php

namespace App\Controllers;

use App\Controllers\Concerns\HandlesUploads;
use App\Models\OutgoingLetterModel;

class OutgoingLettersController extends BaseController
{
    use HandlesUploads;

    /*
    | -------------------------------------------------------------------
    | CONTROLLER SURAT KELUAR
    | -------------------------------------------------------------------
    | Controller ini mengelola pencatatan surat keluar, upload lampiran, dan
    | status pengiriman sampai surat diterima oleh unit/tujuan.
    |
    | Alur Kerja:
    | - Operator/Admin mencatat surat keluar setelah siap/ditandatangani.
    | - Status pengiriman diperbarui dari siap dikirim sampai diterima tujuan.
    | - Nama penerima dan tanggal diterima dicatat sebagai bukti administrasi.
    |
    | Tips Debugging:
    | - Jika status pengiriman tidak berubah, cek method updateDelivery().
    */
    private OutgoingLetterModel $letters;

    public function __construct()
    {
        $this->letters = new OutgoingLetterModel();
    }

    public function index()
    {
        $filters = [
            'q'      => trim((string) $this->request->getGet('q')),
            'status' => $this->request->getGet('status'),
            'from'   => $this->request->getGet('from'),
            'to'     => $this->request->getGet('to'),
        ];

        $query = $this->letters->withCreator();

        if ($filters['q'] !== '') {
            $query->groupStart()
                ->like('outgoing_letters.letter_number', $filters['q'])
                ->orLike('outgoing_letters.recipient', $filters['q'])
                ->orLike('outgoing_letters.subject', $filters['q'])
                ->orLike('outgoing_letters.destination_unit', $filters['q'])
                ->groupEnd();
        }

        if ($filters['status']) {
            $query->where('outgoing_letters.status', $filters['status']);
        }

        if ($filters['from']) {
            $query->where('outgoing_letters.letter_date >=', $filters['from']);
        }

        if ($filters['to']) {
            $query->where('outgoing_letters.letter_date <=', $filters['to']);
        }

        return view('outgoing_letters/index', [
            'title'    => 'Surat Keluar',
            'letters'  => $query->orderBy('outgoing_letters.letter_date', 'DESC')->paginate(10),
            'pager'    => $this->letters->pager,
            'filters'  => $filters,
            'statuses' => OutgoingLetterModel::STATUSES,
        ]);
    }

    public function create()
    {
        return view('outgoing_letters/form', $this->formData('Tambah Surat Keluar'));
    }

    public function store()
    {
        /*
        | -------------------------------------------------------------------
        | SIMPAN SURAT KELUAR
        | -------------------------------------------------------------------
        | Status awal dapat dipilih operator, default-nya "dicatat". Lampiran
        | opsional untuk menyimpan scan/dokumen surat.
        |
        | Tips Debugging:
        | - Jika lampiran tidak tersimpan, cek enctype form multipart/form-data.
        */
        if (! $this->validate($this->rules())) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        try {
            $payload               = $this->payload();
            $payload['created_by'] = current_user('id');
            $attachment            = $this->storeUploadedFile('attachment', 'surat', ['pdf', 'jpg', 'jpeg', 'png', 'webp'], 8);

            if ($attachment) {
                $payload['attachment'] = $attachment;
            }

            $this->letters->insert($payload);

            return redirect()->to('/outgoing-letters')->with('success', 'Surat keluar berhasil dicatat.');
        } catch (\RuntimeException $exception) {
            return redirect()->back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function show(int $id)
    {
        $letter = (new OutgoingLetterModel())->withCreator()->find($id);

        if (! $letter) {
            return redirect()->to('/outgoing-letters')->with('error', 'Surat keluar tidak ditemukan.');
        }

        return view('outgoing_letters/show', [
            'title'    => 'Detail Surat Keluar',
            'letter'   => $letter,
            'statuses' => OutgoingLetterModel::STATUSES,
        ]);
    }

    public function edit(int $id)
    {
        $letter = $this->letters->find($id);

        if (! $letter) {
            return redirect()->to('/outgoing-letters')->with('error', 'Surat keluar tidak ditemukan.');
        }

        return view('outgoing_letters/form', $this->formData('Edit Surat Keluar', $letter));
    }

    public function update(int $id)
    {
        $letter = $this->letters->find($id);

        if (! $letter) {
            return redirect()->to('/outgoing-letters')->with('error', 'Surat keluar tidak ditemukan.');
        }

        if (! $this->validate($this->rules())) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        try {
            $payload    = $this->payload();
            $attachment = $this->storeUploadedFile('attachment', 'surat', ['pdf', 'jpg', 'jpeg', 'png', 'webp'], 8);

            if ($attachment) {
                $this->removeUploadedFile($letter['attachment'] ?? null);
                $payload['attachment'] = $attachment;
            }

            $this->letters->update($id, $payload);

            return redirect()->to("/outgoing-letters/{$id}")->with('success', 'Surat keluar berhasil diperbarui.');
        } catch (\RuntimeException $exception) {
            return redirect()->back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function updateDelivery(int $id)
    {
        /*
        | -------------------------------------------------------------------
        | UPDATE STATUS PENGIRIMAN
        | -------------------------------------------------------------------
        | Form ini dipakai saat surat sudah dikirim atau sudah diterima tujuan.
        | Jika status "diterima_tujuan", nama penerima dan tanggal diterima wajib.
        |
        | Tips Debugging:
        | - Jika status diterima gagal, pastikan receiver_name dan received_date diisi.
        */
        $status = (string) $this->request->getPost('status');

        if (! array_key_exists($status, OutgoingLetterModel::STATUSES)) {
            return redirect()->back()->with('error', 'Status pengiriman tidak valid.');
        }

        if ($status === 'diterima_tujuan') {
            $rules = [
                'receiver_name' => 'required|max_length[120]',
                'received_date' => 'required|valid_date',
            ];

            if (! $this->validate($rules)) {
                return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
            }
        }

        $this->letters->update($id, [
            'status'         => $status,
            'receiver_name'  => trim((string) $this->request->getPost('receiver_name')) ?: null,
            'received_date'  => $this->request->getPost('received_date') ?: null,
            'delivery_notes' => trim((string) $this->request->getPost('delivery_notes')),
        ]);

        return redirect()->back()->with('success', 'Status pengiriman surat berhasil diperbarui.');
    }

    public function destroy(int $id)
    {
        $letter = $this->letters->find($id);

        if ($letter) {
            $this->removeUploadedFile($letter['attachment'] ?? null);
            $this->letters->delete($id);
        }

        return redirect()->to('/outgoing-letters')->with('success', 'Surat keluar berhasil dihapus.');
    }

    private function formData(string $title, ?array $letter = null): array
    {
        return [
            'title'    => $title,
            'letter'   => $letter,
            'statuses' => OutgoingLetterModel::STATUSES,
        ];
    }

    private function rules(): array
    {
        return [
            'letter_number' => 'required|max_length[120]',
            'letter_date'   => 'required|valid_date',
            'recipient'     => 'required|max_length[160]',
            'subject'       => 'required|max_length[200]',
            'status'        => 'required|in_list[dicatat,siap_dikirim,terkirim,diterima_tujuan,diarsipkan]',
        ];
    }

    private function payload(): array
    {
        return [
            'letter_number'    => trim((string) $this->request->getPost('letter_number')),
            'letter_date'      => (string) $this->request->getPost('letter_date'),
            'recipient'        => trim((string) $this->request->getPost('recipient')),
            'destination_unit' => trim((string) $this->request->getPost('destination_unit')),
            'subject'          => trim((string) $this->request->getPost('subject')),
            'status'           => (string) $this->request->getPost('status'),
        ];
    }
}
