<?php

namespace App\Controllers;

use App\Libraries\SimplePdf;
use App\Models\AssetModel;
use App\Models\InventoryRequestItemModel;
use App\Models\InventoryRequestModel;

class InventoryRequestsController extends BaseController
{
    private InventoryRequestModel $requests;

    public function __construct()
    {
        $this->requests = new InventoryRequestModel();
    }

    public function index()
    {
        $filters = [
            'q'       => trim((string) $this->request->getGet('q')),
            'status'  => $this->request->getGet('status'),
            'type'    => $this->request->getGet('type'),
            'priority'=> $this->request->getGet('priority'),
        ];

        $query = $this->requests->withUsers();

        if (current_user('role') === 'operator') {
            $query->where('inventory_requests.created_by', current_user('id'));
        }

        if ($filters['q'] !== '') {
            $query->groupStart()
                ->like('inventory_requests.request_number', $filters['q'])
                ->orLike('inventory_requests.requester_name', $filters['q'])
                ->orLike('inventory_requests.requester_unit', $filters['q'])
                ->orLike('inventory_requests.reason', $filters['q'])
                ->groupEnd();
        }

        if ($filters['status']) {
            $query->where('inventory_requests.status', $filters['status']);
        }

        if ($filters['type']) {
            $query->where('inventory_requests.request_type', $filters['type']);
        }

        if ($filters['priority']) {
            $query->where('inventory_requests.priority', $filters['priority']);
        }

        return view('inventory_requests/index', [
            'title'     => 'Pengajuan Inventaris',
            'requests'  => $query->orderBy('inventory_requests.created_at', 'DESC')->paginate(10),
            'pager'     => $this->requests->pager,
            'filters'   => $filters,
            'types'     => InventoryRequestModel::TYPES,
            'priorities'=> InventoryRequestModel::PRIORITIES,
            'statuses'  => InventoryRequestModel::STATUSES,
        ]);
    }

    public function create()
    {
        return view('inventory_requests/create', $this->formData('Tambah Pengajuan Inventaris'));
    }

    public function store()
    {
        if (! $this->validate($this->rules())) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        try {
            $items = $this->collectItems();
            $db = db_connect();
            $db->transStart();

            $requestId = $this->requests->insert([
                'request_number' => $this->nextRequestNumber(),
                'request_date'   => (string) $this->request->getPost('request_date'),
                'requester_name' => trim((string) $this->request->getPost('requester_name')),
                'requester_unit' => trim((string) $this->request->getPost('requester_unit')),
                'request_type'   => (string) $this->request->getPost('request_type'),
                'priority'       => (string) $this->request->getPost('priority'),
                'reason'         => trim((string) $this->request->getPost('reason')),
                'needed_date'    => $this->request->getPost('needed_date') ?: null,
                'status'         => 'diajukan',
                'created_by'     => current_user('id'),
            ], true);

            foreach ($items as &$item) {
                $item['inventory_request_id'] = $requestId;
            }

            (new InventoryRequestItemModel())->insertBatch($items);
            $db->transComplete();

            if (! $db->transStatus()) {
                throw new \RuntimeException('Pengajuan inventaris gagal disimpan.');
            }

            return redirect()->to('/inventory-requests/' . $requestId)->with('success', 'Pengajuan inventaris berhasil dibuat.');
        } catch (\RuntimeException $exception) {
            return redirect()->back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function show(int $id)
    {
        $detail = $this->requestDetail($id);

        if (! $detail || ! $this->canView($detail['request'])) {
            return redirect()->to('/inventory-requests')->with('error', 'Pengajuan inventaris tidak ditemukan atau tidak dapat diakses.');
        }

        return view('inventory_requests/show', [
            'title'     => 'Detail Pengajuan Inventaris',
            'request'   => $detail['request'],
            'items'     => $detail['items'],
            'types'     => InventoryRequestModel::TYPES,
            'priorities'=> InventoryRequestModel::PRIORITIES,
            'statuses'  => InventoryRequestModel::STATUSES,
        ]);
    }

    public function edit(int $id)
    {
        $detail = $this->requestDetail($id);

        if (! $detail || ! $this->canMutate($detail['request'])) {
            return redirect()->to('/inventory-requests')->with('error', 'Pengajuan ini tidak dapat diubah.');
        }

        return view('inventory_requests/edit', $this->formData('Edit Pengajuan Inventaris', $detail['request'], $detail['items']));
    }

    public function update(int $id)
    {
        $detail = $this->requestDetail($id);

        if (! $detail || ! $this->canMutate($detail['request'])) {
            return redirect()->to('/inventory-requests')->with('error', 'Pengajuan ini tidak dapat diubah.');
        }

        if (! $this->validate($this->rules())) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        try {
            $items = $this->collectItems();
            $db = db_connect();
            $db->transStart();

            $this->requests->update($id, [
                'request_date'   => (string) $this->request->getPost('request_date'),
                'requester_name' => trim((string) $this->request->getPost('requester_name')),
                'requester_unit' => trim((string) $this->request->getPost('requester_unit')),
                'request_type'   => (string) $this->request->getPost('request_type'),
                'priority'       => (string) $this->request->getPost('priority'),
                'reason'         => trim((string) $this->request->getPost('reason')),
                'needed_date'    => $this->request->getPost('needed_date') ?: null,
            ]);

            $itemModel = new InventoryRequestItemModel();
            $itemModel->where('inventory_request_id', $id)->delete();

            foreach ($items as &$item) {
                $item['inventory_request_id'] = $id;
            }

            $itemModel->insertBatch($items);
            $db->transComplete();

            if (! $db->transStatus()) {
                throw new \RuntimeException('Pengajuan inventaris gagal diperbarui.');
            }

            return redirect()->to('/inventory-requests/' . $id)->with('success', 'Pengajuan inventaris berhasil diperbarui.');
        } catch (\RuntimeException $exception) {
            return redirect()->back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function approve(int $id)
    {
        $request = $this->requests->find($id);

        if (! $request || ! $this->canApprove($request)) {
            return redirect()->to('/inventory-requests')->with('error', 'Pengajuan ini tidak dapat disetujui.');
        }

        $this->requests->update($id, [
            'status'         => 'disetujui',
            'approval_notes' => trim((string) $this->request->getPost('approval_notes')),
            'approved_by'    => current_user('id'),
            'approved_at'    => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to('/inventory-requests/' . $id)->with('success', 'Pengajuan inventaris berhasil disetujui.');
    }

    public function reject(int $id)
    {
        $request = $this->requests->find($id);

        if (! $request || ! $this->canApprove($request)) {
            return redirect()->to('/inventory-requests')->with('error', 'Pengajuan ini tidak dapat ditolak.');
        }

        if (! $this->validate(['approval_notes' => 'required|max_length[1000]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->requests->update($id, [
            'status'         => 'ditolak',
            'approval_notes' => trim((string) $this->request->getPost('approval_notes')),
            'approved_by'    => current_user('id'),
            'approved_at'    => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to('/inventory-requests/' . $id)->with('success', 'Pengajuan inventaris berhasil ditolak.');
    }

    public function pdf(int $id)
    {
        $detail = $this->requestDetail($id);

        if (! $detail || ! $this->canView($detail['request'])) {
            return redirect()->to('/inventory-requests')->with('error', 'Pengajuan inventaris tidak ditemukan atau tidak dapat diakses.');
        }

        $filename = $this->pdfFilename($detail['request']['request_number'] ?? ('pengajuan-inventaris-' . $id));

        return $this->response
            ->setHeader('Content-Type', 'application/pdf')
            ->setHeader('Content-Disposition', 'attachment; filename="' . $filename . '"')
            ->setBody($this->buildRequestPdf($detail['request'], $detail['items']));
    }

    private function requestDetail(int $id): ?array
    {
        $request = $this->requests->withUsers()->find($id);

        if (! $request) {
            return null;
        }

        return [
            'request' => $request,
            'items'   => (new InventoryRequestItemModel())->withAsset()
                ->where('inventory_request_items.inventory_request_id', $id)
                ->findAll(),
        ];
    }

    private function formData(string $title, ?array $request = null, array $items = []): array
    {
        return [
            'title'     => $title,
            'request'   => $request,
            'items'     => $items,
            'assets'    => (new AssetModel())->orderBy('name', 'ASC')->findAll(),
            'types'     => InventoryRequestModel::TYPES,
            'priorities'=> InventoryRequestModel::PRIORITIES,
        ];
    }

    private function rules(): array
    {
        return [
            'request_date'   => 'required|valid_date',
            'requester_name' => 'required|max_length[160]',
            'requester_unit' => 'required|max_length[160]',
            'request_type'   => 'required|in_list[peminjaman_aset,pengadaan_aset,perbaikan_aset,penggantian_aset]',
            'priority'       => 'required|in_list[rendah,sedang,tinggi,mendesak]',
            'reason'         => 'required',
            'needed_date'    => 'permit_empty|valid_date',
        ];
    }

    private function collectItems(): array
    {
        $assetIds = (array) $this->request->getPost('asset_id');
        $names = (array) $this->request->getPost('item_name');
        $quantities = (array) $this->request->getPost('quantity');
        $units = (array) $this->request->getPost('unit');
        $notes = (array) $this->request->getPost('item_notes');
        $items = [];
        $assets = $this->assetMap();

        foreach ($names as $index => $name) {
            $assetId = (int) ($assetIds[$index] ?? 0);
            $quantity = (int) ($quantities[$index] ?? 0);
            $itemName = trim((string) $name);

            if ($itemName === '' && $assetId > 0 && isset($assets[$assetId])) {
                $itemName = $assets[$assetId]['name'];
            }

            if ($itemName === '' && $quantity < 1 && $assetId < 1) {
                continue;
            }

            if ($itemName === '') {
                throw new \RuntimeException('Nama barang/aset wajib diisi pada setiap item.');
            }

            if ($quantity < 1) {
                throw new \RuntimeException('Jumlah item wajib berupa angka lebih dari 0.');
            }

            $items[] = [
                'asset_id'   => $assetId > 0 ? $assetId : null,
                'item_name'  => $itemName,
                'quantity'   => $quantity,
                'unit'       => trim((string) ($units[$index] ?? 'unit')) ?: 'unit',
                'notes'      => trim((string) ($notes[$index] ?? '')),
            ];
        }

        if ($items === []) {
            throw new \RuntimeException('Minimal satu item barang/aset wajib diisi.');
        }

        return $items;
    }

    private function assetMap(): array
    {
        $assets = (new AssetModel())->findAll();
        $map = [];

        foreach ($assets as $asset) {
            $map[(int) $asset['id']] = $asset;
        }

        return $map;
    }

    private function canView(array $request): bool
    {
        if (is_role(['admin', 'pimpinan'])) {
            return true;
        }

        return current_user('role') === 'operator' && (int) $request['created_by'] === (int) current_user('id');
    }

    private function canMutate(array $request): bool
    {
        if (! in_array($request['status'], InventoryRequestModel::MUTABLE_STATUSES, true)) {
            return false;
        }

        if (is_role('admin')) {
            return true;
        }

        return current_user('role') === 'operator' && (int) $request['created_by'] === (int) current_user('id');
    }

    private function canApprove(array $request): bool
    {
        return is_role(['admin', 'pimpinan'])
            && in_array($request['status'], InventoryRequestModel::APPROVAL_STATUSES, true);
    }

    private function nextRequestNumber(): string
    {
        $prefix = 'PI-' . date('Ymd') . '-';
        $count = (new InventoryRequestModel())
            ->like('request_number', $prefix, 'after')
            ->countAllResults();

        return $prefix . str_pad((string) ($count + 1), 4, '0', STR_PAD_LEFT);
    }

    private function buildRequestPdf(array $request, array $items): string
    {
        $pdf = new SimplePdf();
        $pdf->addPage();

        $margin = 48.0;
        $right = SimplePdf::PAGE_WIDTH - $margin;
        $y = 792.0;

        $pdf->text($margin, $y, 'DOKUMEN PENGAJUAN INVENTARIS', 16, true);
        $pdf->text($right, $y + 2, 'Dicetak: ' . date('d/m/Y H:i'), 9, false, 'right');
        $y -= 18;
        $pdf->text($margin, $y, 'SMP Islam Rejis', 11, true);
        $y -= 12;
        $pdf->line($margin, $y, $right, $y);
        $y -= 26;

        $details = [
            'Nomor Pengajuan'   => $request['request_number'] ?? '-',
            'Tanggal Pengajuan' => date_id($request['request_date'] ?? null),
            'Nama Pemohon'      => $request['requester_name'] ?? '-',
            'Unit Pemohon'      => $request['requester_unit'] ?? '-',
            'Jenis Pengajuan'   => InventoryRequestModel::TYPES[$request['request_type']] ?? human_status($request['request_type'] ?? ''),
            'Prioritas'         => InventoryRequestModel::PRIORITIES[$request['priority']] ?? human_status($request['priority'] ?? ''),
            'Tanggal Dibutuhkan'=> date_id($request['needed_date'] ?? null),
            'Status'            => human_status($request['status'] ?? '-'),
            'Penyetuju'         => $request['approver_name'] ?: '-',
            'Tanggal Persetujuan'=> $request['approved_at'] ? date('d/m/Y H:i', strtotime($request['approved_at'])) : '-',
        ];

        foreach ($details as $label => $value) {
            $pdf->text($margin, $y, $label, 10, true);
            $pdf->text($margin + 135, $y, ': ' . $value, 10);
            $y -= 17;
        }

        $y -= 8;
        $pdf->text($margin, $y, 'Alasan Pengajuan', 11, true);
        $y -= 15;

        foreach ($this->wrapPdfText($request['reason'] ?: '-', 90) as $line) {
            $pdf->text($margin, $y, $line, 10);
            $y -= 13;
        }

        $y -= 10;
        $pdf->text($margin, $y, 'Daftar Item', 12, true);
        $y -= 18;

        $columns = [
            ['label' => 'No', 'x' => $margin, 'w' => 28],
            ['label' => 'Barang/Aset', 'x' => $margin + 28, 'w' => 228],
            ['label' => 'Jumlah', 'x' => $margin + 256, 'w' => 50],
            ['label' => 'Satuan', 'x' => $margin + 306, 'w' => 64],
            ['label' => 'Catatan', 'x' => $margin + 370, 'w' => 129],
        ];

        $drawHeader = function () use ($pdf, $columns, &$y): void {
            foreach ($columns as $column) {
                $pdf->rectangle($column['x'], $y - 15, $column['w'], 19);
                $pdf->text($column['x'] + 4, $y - 8, $column['label'], 9, true);
            }

            $y -= 19;
        };

        $drawHeader();

        foreach ($items as $index => $item) {
            if ($y < 120) {
                $pdf->addPage();
                $y = 792.0;
                $pdf->text($margin, $y, 'DOKUMEN PENGAJUAN INVENTARIS', 13, true);
                $pdf->text($right, $y, 'Lanjutan', 9, false, 'right');
                $y -= 24;
                $drawHeader();
            }

            $itemLabel = $item['item_name'];
            if (! empty($item['asset_code'])) {
                $itemLabel = $item['asset_code'] . ' - ' . $itemLabel;
            }

            $nameLines = $this->wrapPdfText($itemLabel, 38);
            $noteLines = $this->wrapPdfText($item['notes'] ?: '-', 22);
            $rowHeight = max(25, 13 * max(count($nameLines), count($noteLines), 1));

            foreach ($columns as $column) {
                $pdf->rectangle($column['x'], $y - $rowHeight + 4, $column['w'], $rowHeight);
            }

            $pdf->text($columns[0]['x'] + 4, $y - 9, (string) ($index + 1), 9);

            foreach ($nameLines as $lineIndex => $line) {
                $pdf->text($columns[1]['x'] + 4, $y - 9 - ($lineIndex * 12), $line, 9);
            }

            $pdf->text($columns[2]['x'] + 4, $y - 9, (string) $item['quantity'], 9);
            $pdf->text($columns[3]['x'] + 4, $y - 9, $item['unit'] ?: 'unit', 9);

            foreach ($noteLines as $lineIndex => $line) {
                $pdf->text($columns[4]['x'] + 4, $y - 9 - ($lineIndex * 12), $line, 9);
            }

            $y -= $rowHeight;
        }

        $y -= 20;
        if ($y < 160) {
            $pdf->addPage();
            $y = 792.0;
        }

        $pdf->text($margin, $y, 'Catatan Persetujuan/Penolakan', 10, true);
        $y -= 14;
        foreach ($this->wrapPdfText($request['approval_notes'] ?: '-', 92) as $line) {
            $pdf->text($margin, $y, $line, 10);
            $y -= 13;
        }

        $y -= 28;
        $pdf->text($margin + 50, $y, 'Pemohon', 10, true, 'center');
        $pdf->text($right - 78, $y, 'Pimpinan/Penyetuju', 10, true, 'center');
        $y -= 62;
        $pdf->line($margin, $y, $margin + 140, $y);
        $pdf->line($right - 160, $y, $right - 10, $y);
        $pdf->text($margin + 70, $y - 13, $request['requester_name'] ?: '-', 9, false, 'center');
        $pdf->text($right - 85, $y - 13, $request['approver_name'] ?: '-', 9, false, 'center');

        return $pdf->output();
    }

    private function wrapPdfText(string $text, int $maxLength): array
    {
        $text = trim(preg_replace('/\s+/', ' ', $text) ?? '');

        if ($text === '') {
            return ['-'];
        }

        return explode("\n", wordwrap($text, $maxLength, "\n", true));
    }

    private function pdfFilename(string $number): string
    {
        $number = trim($number) === '' ? 'pengajuan-inventaris' : $number;
        $number = preg_replace('/[^A-Za-z0-9_-]+/', '-', $number) ?: 'pengajuan-inventaris';

        return strtolower(trim($number, '-')) . '.pdf';
    }
}
