<?php

namespace App\Controllers;

use App\Models\AssetModel;
use App\Models\DispositionModel;
use App\Models\IncomingLetterModel;
use App\Models\OutgoingLetterModel;
use App\Models\UserModel;

class DashboardController extends BaseController
{
    /*
    | -------------------------------------------------------------------
    | CONTROLLER DASHBOARD
    | -------------------------------------------------------------------
    | Dashboard menyajikan ringkasan aset, surat masuk, surat keluar,
    | disposisi pending, grafik bulanan, dan notifikasi kerja.
    |
    | Alur Kerja:
    | - Data statistik dihitung dari model utama.
    | - Grafik dikirim sebagai array JSON ke view.
    | - View menampilkan chart menggunakan Chart.js.
    |
    | Tips Debugging:
    | - Jika grafik kosong, pastikan data tanggal surat sudah terisi.
    | - Jika dashboard error setelah migration, jalankan seeder data awal.
    */
    public function index()
    {
        $assetModel       = new AssetModel();
        $incomingModel    = new IncomingLetterModel();
        $outgoingModel    = new OutgoingLetterModel();
        $dispositionModel = new DispositionModel();
        $userModel        = new UserModel();

        $data = [
            'title'                => 'Dashboard',
            'totalAssets'          => $assetModel->selectSum('quantity')->first()['quantity'] ?? 0,
            'assetRecords'         => $assetModel->countAllResults(),
            'incomingLetters'      => $incomingModel->countAllResults(),
            'outgoingLetters'      => $outgoingModel->countAllResults(),
            'pendingDispositions'  => $dispositionModel->whereIn('status', ['pending', 'proses'])->countAllResults(),
            'totalUsers'           => $userModel->countAllResults(),
            'letterTrend'          => $this->monthlyLetterTrend(),
            'assetConditionChart'  => $this->assetConditionChart(),
            'latestIncoming'       => (new IncomingLetterModel())->withCreator()->orderBy('incoming_letters.created_at', 'DESC')->findAll(5),
            'latestOutgoing'       => (new OutgoingLetterModel())->withCreator()->orderBy('outgoing_letters.created_at', 'DESC')->findAll(5),
            'pendingDispositionRows' => (new DispositionModel())->withLetter()
                ->whereIn('dispositions.status', ['pending', 'proses'])
                ->orderBy('dispositions.created_at', 'DESC')
                ->findAll(5),
        ];

        return view('dashboard/index', $data);
    }

    private function monthlyLetterTrend(): array
    {
        /*
        | -------------------------------------------------------------------
        | DATA GRAFIK SURAT BULANAN
        | -------------------------------------------------------------------
        | Method ini menghitung jumlah surat masuk dan keluar selama enam bulan
        | terakhir untuk ditampilkan sebagai line chart.
        |
        | Tips Debugging:
        | - Jika angka tidak berubah, cek field received_date dan letter_date.
        */
        $labels   = [];
        $incoming = [];
        $outgoing = [];

        for ($i = 5; $i >= 0; $i--) {
            $start = date('Y-m-01', strtotime("-{$i} months"));
            $end   = date('Y-m-t', strtotime($start));

            $labels[]   = date('M Y', strtotime($start));
            $incoming[] = (new IncomingLetterModel())
                ->where('received_date >=', $start)
                ->where('received_date <=', $end)
                ->countAllResults();
            $outgoing[] = (new OutgoingLetterModel())
                ->where('letter_date >=', $start)
                ->where('letter_date <=', $end)
                ->countAllResults();
        }

        return compact('labels', 'incoming', 'outgoing');
    }

    private function assetConditionChart(): array
    {
        /*
        | -------------------------------------------------------------------
        | DATA GRAFIK KONDISI ASET
        | -------------------------------------------------------------------
        | Method ini menghitung total record aset per kondisi. Data dikirim
        | ke Chart.js sebagai doughnut chart.
        |
        | Tips Debugging:
        | - Jika kondisi tidak tampil, pastikan condition_status sesuai konstanta AssetModel.
        */
        $labels = [];
        $values = [];

        foreach (AssetModel::CONDITIONS as $key => $label) {
            $labels[] = $label;
            $values[] = (new AssetModel())->where('condition_status', $key)->countAllResults();
        }

        return compact('labels', 'values');
    }
}
