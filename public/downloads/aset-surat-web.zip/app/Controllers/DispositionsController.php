<?php

namespace App\Controllers;

use App\Models\DispositionModel;
use App\Models\IncomingLetterModel;

class DispositionsController extends BaseController
{
    /*
    | -------------------------------------------------------------------
    | CONTROLLER MONITORING DISPOSISI
    | -------------------------------------------------------------------
    | Controller ini menampilkan seluruh disposisi dan memperbarui status
    | tindak lanjutnya tanpa perlu akun tambahan untuk guru/staf penerima.
    |
    | Alur Kerja:
    | - Pimpinan membuat disposisi dari detail surat masuk.
    | - Operator/Admin/Pimpinan memantau daftar disposisi.
    | - Status diperbarui menjadi pending, proses, selesai, atau diarsipkan.
    |
    | Tips Debugging:
    | - Jika data kosong, buat disposisi dari detail surat masuk terlebih dahulu.
    */
    private DispositionModel $dispositions;

    public function __construct()
    {
        $this->dispositions = new DispositionModel();
    }

    public function index()
    {
        $filters = [
            'q'      => trim((string) $this->request->getGet('q')),
            'status' => $this->request->getGet('status'),
        ];

        $query = $this->dispositions->withLetter();

        if ($filters['q'] !== '') {
            $query->groupStart()
                ->like('incoming_letters.letter_number', $filters['q'])
                ->orLike('incoming_letters.subject', $filters['q'])
                ->orLike('dispositions.target_unit', $filters['q'])
                ->orLike('dispositions.instruction', $filters['q'])
                ->groupEnd();
        }

        if ($filters['status']) {
            $query->where('dispositions.status', $filters['status']);
        }

        return view('dispositions/index', [
            'title'        => 'Monitoring Disposisi',
            'dispositions' => $query->orderBy('dispositions.created_at', 'DESC')->paginate(10),
            'pager'        => $this->dispositions->pager,
            'filters'      => $filters,
            'statuses'     => DispositionModel::STATUSES,
        ]);
    }

    public function updateStatus(int $id)
    {
        /*
        | -------------------------------------------------------------------
        | UPDATE STATUS DISPOSISI
        | -------------------------------------------------------------------
        | Saat status disposisi berubah, status surat masuk ikut diselaraskan
        | agar dashboard menampilkan kondisi dokumen paling baru.
        |
        | Tips Debugging:
        | - Jika status surat tidak ikut berubah, cek incoming_letter_id pada disposisi.
        */
        $disposition = $this->dispositions->find($id);

        if (! $disposition) {
            return redirect()->back()->with('error', 'Disposisi tidak ditemukan.');
        }

        $status = (string) $this->request->getPost('status');

        if (! array_key_exists($status, DispositionModel::STATUSES)) {
            return redirect()->back()->with('error', 'Status disposisi tidak valid.');
        }

        $this->dispositions->update($id, ['status' => $status]);

        $letterStatus = [
            'pending'    => 'didisposisikan',
            'proses'     => 'dalam_proses',
            'selesai'    => 'selesai',
            'diarsipkan' => 'diarsipkan',
        ][$status];

        (new IncomingLetterModel())->update($disposition['incoming_letter_id'], ['status' => $letterStatus]);

        return redirect()->back()->with('success', 'Status disposisi berhasil diperbarui.');
    }
}
