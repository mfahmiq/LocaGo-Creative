<?php

namespace App\Controllers;

use App\Libraries\SimplePdf;
use App\Models\AssetModel;
use App\Models\AssetTransactionItemModel;
use App\Models\AssetTransactionModel;

class AssetTransactionsController extends BaseController
{
    /*
    | -------------------------------------------------------------------
    | CONTROLLER TRANSAKSI ASET
    | -------------------------------------------------------------------
    | Controller ini menangani peminjaman dan pengembalian aset. Satu transaksi
    | dapat berisi beberapa barang, misalnya Sound System dan Mixer untuk Unit TK.
    |
    | Alur Kerja:
    | - Operator/Admin membuat transaksi peminjaman.
    | - Sistem mengecek jumlah tersedia berdasarkan transaksi aktif.
    | - Saat barang kembali, operator mencatat tanggal kembali dan kondisi akhir.
    |
    | Tips Debugging:
    | - Jika stok dianggap kurang, cek transaksi lama yang statusnya masih Dipinjam.
    | - Jika item tidak tersimpan, cek input asset_id[] dan quantity[] di view form.
    */
    private AssetTransactionModel $transactions;

    public function __construct()
    {
        $this->transactions = new AssetTransactionModel();
    }

    public function index()
    {
        $filters = [
            'q'      => trim((string) $this->request->getGet('q')),
            'status' => $this->request->getGet('status'),
        ];

        $query = $this->transactions
            ->select('asset_transactions.*, users.name AS creator_name, COUNT(asset_transaction_items.id) AS item_count')
            ->join('users', 'users.id = asset_transactions.created_by', 'left')
            ->join('asset_transaction_items', 'asset_transaction_items.asset_transaction_id = asset_transactions.id', 'left')
            ->groupBy('asset_transactions.id');

        if ($filters['q'] !== '') {
            $query->groupStart()
                ->like('asset_transactions.transaction_code', $filters['q'])
                ->orLike('asset_transactions.borrower_unit', $filters['q'])
                ->orLike('asset_transactions.borrower_name', $filters['q'])
                ->orLike('asset_transactions.purpose', $filters['q'])
                ->groupEnd();
        }

        if ($filters['status']) {
            $query->where('asset_transactions.status', $filters['status']);
        }

        return view('asset_transactions/index', [
            'title'        => 'Transaksi Aset',
            'transactions' => $query->orderBy('asset_transactions.created_at', 'DESC')->paginate(10),
            'pager'        => $this->transactions->pager,
            'filters'      => $filters,
            'statuses'     => AssetTransactionModel::STATUSES,
        ]);
    }

    public function create()
    {
        return view('asset_transactions/form', [
            'title'       => 'Tambah Transaksi Aset',
            'transaction' => null,
            'assets'      => $this->assetOptions(),
            'conditions'  => AssetModel::CONDITIONS,
            'code'        => $this->nextTransactionCode(),
        ]);
    }

    public function store()
    {
        /*
        | -------------------------------------------------------------------
        | SIMPAN PEMINJAMAN ASET
        | -------------------------------------------------------------------
        | Header transaksi dan item aset disimpan dalam database transaction
        | agar data tidak setengah tersimpan jika terjadi error.
        |
        | Tips Debugging:
        | - Jika muncul stok tidak cukup, buka menu Transaksi Aset dan selesaikan
        |   transaksi lama yang masih berstatus Dipinjam/Terlambat.
        */
        $rules = [
            'borrower_unit'        => 'required|max_length[160]',
            'borrower_name'        => 'required|max_length[160]',
            'loan_date'            => 'required|valid_date',
            'expected_return_date' => 'permit_empty|valid_date',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        try {
            $items = $this->collectItems();
            $this->assertItemsAvailable($items);

            $db = db_connect();
            $db->transStart();

            $transactionId = $this->transactions->insert([
                'transaction_code'     => $this->nextTransactionCode(),
                'borrower_unit'        => trim((string) $this->request->getPost('borrower_unit')),
                'borrower_name'        => trim((string) $this->request->getPost('borrower_name')),
                'purpose'              => trim((string) $this->request->getPost('purpose')),
                'loan_date'            => (string) $this->request->getPost('loan_date'),
                'expected_return_date' => $this->request->getPost('expected_return_date') ?: null,
                'status'               => 'dipinjam',
                'notes'                => trim((string) $this->request->getPost('notes')),
                'created_by'           => current_user('id'),
            ], true);

            foreach ($items as &$item) {
                $item['asset_transaction_id'] = $transactionId;
            }

            (new AssetTransactionItemModel())->insertBatch($items);
            $db->transComplete();

            if (! $db->transStatus()) {
                throw new \RuntimeException('Transaksi database gagal disimpan.');
            }

            return redirect()->to('/asset-transactions/' . $transactionId)->with('success', 'Transaksi peminjaman aset berhasil dibuat.');
        } catch (\RuntimeException $exception) {
            return redirect()->back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function show(int $id)
    {
        $detail = $this->transactionDetail($id);

        if (! $detail) {
            return redirect()->to('/asset-transactions')->with('error', 'Transaksi aset tidak ditemukan.');
        }

        return view('asset_transactions/show', [
            'title'       => 'Detail Transaksi Aset',
            'transaction' => $detail['transaction'],
            'items'       => $detail['items'],
            'statuses'    => AssetTransactionModel::STATUSES,
            'conditions'  => AssetModel::CONDITIONS,
        ]);
    }

    public function pdf(int $id)
    {
        $detail = $this->transactionDetail($id);

        if (! $detail) {
            return redirect()->to('/asset-transactions')->with('error', 'Transaksi aset tidak ditemukan.');
        }

        $transaction = $detail['transaction'];
        $filename = $this->pdfFilename($transaction['transaction_code'] ?? ('transaksi-aset-' . $id));

        return $this->response
            ->setHeader('Content-Type', 'application/pdf')
            ->setHeader('Content-Disposition', 'attachment; filename="' . $filename . '"')
            ->setBody($this->buildTransactionPdf($transaction, $detail['items']));
    }

    public function completeReturn(int $id)
    {
        /*
        | -------------------------------------------------------------------
        | PROSES PENGEMBALIAN ASET
        | -------------------------------------------------------------------
        | Method ini menutup transaksi aktif dengan status akhir dan kondisi
        | barang saat kembali.
        |
        | Tips Debugging:
        | - Jika tombol pengembalian tidak tampil, pastikan transaksi masih aktif.
        | - Jika kondisi item tidak berubah, cek name condition_after[item_id].
        */
        $transaction = $this->transactions->find($id);

        if (! $transaction) {
            return redirect()->to('/asset-transactions')->with('error', 'Transaksi aset tidak ditemukan.');
        }

        if (! in_array($transaction['status'], AssetTransactionModel::ACTIVE_STATUSES, true)) {
            return redirect()->back()->with('error', 'Transaksi ini sudah tidak aktif.');
        }

        $status = (string) $this->request->getPost('status');
        $allowedReturnStatuses = ['dikembalikan', 'rusak_saat_kembali', 'hilang', 'dibatalkan'];

        if (! in_array($status, $allowedReturnStatuses, true)) {
            return redirect()->back()->with('error', 'Status pengembalian tidak valid.');
        }

        if ($status !== 'dibatalkan' && ! $this->request->getPost('actual_return_date')) {
            return redirect()->back()->withInput()->with('error', 'Tanggal kembali wajib diisi.');
        }

        $itemModel = new AssetTransactionItemModel();
        $conditionAfter = (array) $this->request->getPost('condition_after');
        $items = $itemModel->where('asset_transaction_id', $id)->findAll();

        foreach ($items as $item) {
            $itemId = (int) $item['id'];
            $itemModel->update($itemId, [
                'condition_after' => $conditionAfter[$itemId] ?? $item['condition_before'],
            ]);
        }

        $this->transactions->update($id, [
            'status'             => $status,
            'actual_return_date' => $this->request->getPost('actual_return_date') ?: null,
            'notes'              => trim((string) $this->request->getPost('notes')),
        ]);

        return redirect()->to('/asset-transactions/' . $id)->with('success', 'Pengembalian aset berhasil dicatat.');
    }

    public function destroy(int $id)
    {
        /*
        | -------------------------------------------------------------------
        | HAPUS TRANSAKSI ASET
        | -------------------------------------------------------------------
        | Hapus transaksi hanya untuk Admin. Detail item otomatis ikut terhapus
        | karena foreign key cascade.
        |
        | Tips Debugging:
        | - Jika tombol hapus tidak tampil, pastikan login sebagai admin.
        */
        $this->transactions->delete($id);

        return redirect()->to('/asset-transactions')->with('success', 'Transaksi aset berhasil dihapus.');
    }

    private function transactionDetail(int $id): ?array
    {
        $transaction = $this->transactions->withCreator()->find($id);

        if (! $transaction) {
            return null;
        }

        return [
            'transaction' => $transaction,
            'items'       => (new AssetTransactionItemModel())->withAsset()
                ->where('asset_transaction_items.asset_transaction_id', $id)
                ->findAll(),
        ];
    }

    private function buildTransactionPdf(array $transaction, array $items): string
    {
        /*
        | -------------------------------------------------------------------
        | PDF PENGAJUAN / PEMINJAMAN ASET
        | -------------------------------------------------------------------
        | Dokumen dibuat dengan generator ringan agar fitur download tetap
        | berjalan tanpa dependensi Composer tambahan di server lokal.
        */
        $pdf = new SimplePdf();
        $pdf->addPage();

        $margin = 48.0;
        $right = SimplePdf::PAGE_WIDTH - $margin;
        $y = 792.0;

        $pdf->text($margin, $y, 'FORM PENGAJUAN / PEMINJAMAN ASET', 16, true);
        $pdf->text($right, $y + 2, 'Dicetak: ' . date('d/m/Y H:i'), 9, false, 'right');
        $y -= 18;
        $pdf->text($margin, $y, 'SMP Islam Rejis', 11, true);
        $y -= 12;
        $pdf->line($margin, $y, $right, $y);
        $y -= 26;

        $status = $this->effectiveTransactionStatus($transaction);
        $details = [
            'Kode Transaksi'      => $transaction['transaction_code'] ?? '-',
            'Unit Peminjam'       => $transaction['borrower_unit'] ?? '-',
            'Penanggung Jawab'    => $transaction['borrower_name'] ?? '-',
            'Tanggal Pinjam'      => date_id($transaction['loan_date'] ?? null),
            'Rencana Kembali'     => date_id($transaction['expected_return_date'] ?? null),
            'Tanggal Kembali'     => date_id($transaction['actual_return_date'] ?? null),
            'Status'              => human_status($status),
            'Dicatat Oleh'        => $transaction['creator_name'] ?: '-',
        ];

        foreach ($details as $label => $value) {
            $pdf->text($margin, $y, $label, 10, true);
            $pdf->text($margin + 130, $y, ': ' . $value, 10);
            $y -= 17;
        }

        $y -= 8;
        $pdf->text($margin, $y, 'Daftar Aset', 12, true);
        $y -= 18;

        $columns = [
            ['label' => 'No', 'x' => $margin, 'w' => 28],
            ['label' => 'Kode', 'x' => $margin + 28, 'w' => 72],
            ['label' => 'Nama Aset', 'x' => $margin + 100, 'w' => 176],
            ['label' => 'Jml', 'x' => $margin + 276, 'w' => 36],
            ['label' => 'Kondisi Awal', 'x' => $margin + 312, 'w' => 88],
            ['label' => 'Kondisi Kembali', 'x' => $margin + 400, 'w' => 99],
        ];

        $drawTableHeader = function () use ($pdf, $columns, &$y): void {
            foreach ($columns as $column) {
                $pdf->rectangle($column['x'], $y - 15, $column['w'], 19);
                $pdf->text($column['x'] + 4, $y - 8, $column['label'], 9, true);
            }

            $y -= 19;
        };

        $drawNewPage = function () use ($pdf, $margin, $right, $drawTableHeader, &$y): void {
            $pdf->addPage();
            $y = 792.0;
            $pdf->text($margin, $y, 'FORM PENGAJUAN / PEMINJAMAN ASET', 13, true);
            $pdf->text($right, $y, 'Lanjutan', 9, false, 'right');
            $y -= 24;
            $drawTableHeader();
        };

        $drawTableHeader();

        foreach ($items as $index => $item) {
            if ($y < 110) {
                $drawNewPage();
            }

            $nameLines = $this->wrapPdfText($item['asset_name'] ?: 'Aset terhapus', 32);

            if (! empty($item['notes'])) {
                $nameLines = array_merge($nameLines, $this->wrapPdfText('Catatan: ' . $item['notes'], 32));
            }

            $rowHeight = max(25, 13 * max(count($nameLines), 1));

            foreach ($columns as $column) {
                $pdf->rectangle($column['x'], $y - $rowHeight + 4, $column['w'], $rowHeight);
            }

            $pdf->text($columns[0]['x'] + 4, $y - 9, (string) ($index + 1), 9);
            $pdf->text($columns[1]['x'] + 4, $y - 9, $item['asset_code'] ?: '-', 9);

            foreach ($nameLines as $lineIndex => $line) {
                $pdf->text($columns[2]['x'] + 4, $y - 9 - ($lineIndex * 12), $line, 9);
            }

            $pdf->text($columns[3]['x'] + 4, $y - 9, (string) $item['quantity'], 9);
            $pdf->text($columns[4]['x'] + 4, $y - 9, human_status($item['condition_before']), 9);
            $pdf->text(
                $columns[5]['x'] + 4,
                $y - 9,
                $item['condition_after'] ? human_status($item['condition_after']) : '-',
                9
            );

            $y -= $rowHeight;
        }

        $y -= 20;
        if ($y < 160) {
            $pdf->addPage();
            $y = 792.0;
        }

        $pdf->text($margin, $y, 'Keperluan', 10, true);
        $y -= 14;
        foreach ($this->wrapPdfText($transaction['purpose'] ?: '-', 92) as $line) {
            $pdf->text($margin, $y, $line, 10);
            $y -= 13;
        }

        $y -= 8;
        $pdf->text($margin, $y, 'Catatan', 10, true);
        $y -= 14;
        foreach ($this->wrapPdfText($transaction['notes'] ?: '-', 92) as $line) {
            $pdf->text($margin, $y, $line, 10);
            $y -= 13;
        }

        $y -= 30;
        if ($y < 120) {
            $pdf->addPage();
            $y = 792.0;
        }

        $pdf->text($margin + 35, $y, 'Pemohon', 10, true, 'center');
        $pdf->text($right - 70, $y, 'Mengetahui', 10, true, 'center');
        $y -= 62;
        $pdf->line($margin, $y, $margin + 125, $y);
        $pdf->line($right - 140, $y, $right - 15, $y);
        $pdf->text($margin + 62, $y - 13, $transaction['borrower_name'] ?: '-', 9, false, 'center');

        return $pdf->output();
    }

    private function effectiveTransactionStatus(array $transaction): string
    {
        if (
            ($transaction['status'] ?? '') === 'dipinjam'
            && ! empty($transaction['expected_return_date'])
            && $transaction['expected_return_date'] < date('Y-m-d')
        ) {
            return 'terlambat';
        }

        return $transaction['status'] ?? '-';
    }

    private function wrapPdfText(string $text, int $maxLength): array
    {
        $text = trim(preg_replace('/\s+/', ' ', $text) ?? '');

        if ($text === '') {
            return ['-'];
        }

        $lines = [];

        foreach (explode("\n", wordwrap($text, $maxLength, "\n", true)) as $line) {
            $lines[] = $line;
        }

        return $lines;
    }

    private function pdfFilename(string $code): string
    {
        $code = trim($code) === '' ? 'transaksi-aset' : $code;
        $code = preg_replace('/[^A-Za-z0-9_-]+/', '-', $code) ?: 'transaksi-aset';

        return strtolower(trim($code, '-')) . '.pdf';
    }

    private function collectItems(): array
    {
        /*
        | -------------------------------------------------------------------
        | KUMPULKAN ITEM TRANSAKSI
        | -------------------------------------------------------------------
        | Method ini membaca array asset_id[], quantity[], condition_before[],
        | dan item_notes[] dari form multi-baris.
        |
        | Tips Debugging:
        | - Jika item kosong, pastikan minimal satu baris aset dipilih.
        */
        $assetIds = (array) $this->request->getPost('asset_id');
        $quantities = (array) $this->request->getPost('quantity');
        $conditions = (array) $this->request->getPost('condition_before');
        $notes = (array) $this->request->getPost('item_notes');
        $items = [];

        foreach ($assetIds as $index => $assetId) {
            $assetId = (int) $assetId;
            $quantity = (int) ($quantities[$index] ?? 0);

            if ($assetId < 1 && $quantity < 1) {
                continue;
            }

            if ($assetId < 1 || $quantity < 1) {
                throw new \RuntimeException('Setiap baris aset wajib memilih aset dan jumlah minimal 1.');
            }

            $items[] = [
                'asset_id' => $assetId,
                'quantity' => $quantity,
                'condition_before' => $conditions[$index] ?? 'baik',
                'notes' => trim((string) ($notes[$index] ?? '')),
            ];
        }

        if ($items === []) {
            throw new \RuntimeException('Minimal satu aset harus dipilih dalam transaksi.');
        }

        return $items;
    }

    private function assertItemsAvailable(array $items): void
    {
        /*
        | -------------------------------------------------------------------
        | VALIDASI STOK TERSEDIA
        | -------------------------------------------------------------------
        | Jumlah tersedia dihitung dari total aset dikurangi aset yang sedang
        | dipinjam pada transaksi aktif.
        |
        | Tips Debugging:
        | - Jika stok tidak sesuai, cek status transaksi lama di menu Transaksi Aset.
        */
        $available = $this->availableQuantities();
        $requested = [];

        foreach ($items as $item) {
            $assetId = (int) $item['asset_id'];
            $requested[$assetId] = ($requested[$assetId] ?? 0) + (int) $item['quantity'];
        }

        foreach ($requested as $assetId => $quantity) {
            if ($quantity > ($available[$assetId] ?? 0)) {
                $asset = (new AssetModel())->find($assetId);
                $name = $asset['name'] ?? 'Aset';
                throw new \RuntimeException("Stok tersedia untuk {$name} tidak cukup.");
            }
        }
    }

    private function assetOptions(): array
    {
        $assets = (new AssetModel())->withRelations()->orderBy('assets.name', 'ASC')->findAll();
        $available = $this->availableQuantities();

        foreach ($assets as &$asset) {
            $asset['available_quantity'] = $available[(int) $asset['id']] ?? 0;
        }

        return $assets;
    }

    private function availableQuantities(): array
    {
        /*
        | -------------------------------------------------------------------
        | HITUNG JUMLAH ASET TERSEDIA
        | -------------------------------------------------------------------
        | Sistem tidak mengubah total inventaris saat barang dipinjam, tetapi
        | menghitung ketersediaan dari transaksi aktif.
        */
        $assets = (new AssetModel())->findAll();
        $available = [];

        foreach ($assets as $asset) {
            $available[(int) $asset['id']] = (int) $asset['quantity'];
        }

        $borrowedRows = db_connect()->table('asset_transaction_items')
            ->select('asset_transaction_items.asset_id, SUM(asset_transaction_items.quantity) AS borrowed')
            ->join('asset_transactions', 'asset_transactions.id = asset_transaction_items.asset_transaction_id')
            ->whereIn('asset_transactions.status', AssetTransactionModel::ACTIVE_STATUSES)
            ->groupBy('asset_transaction_items.asset_id')
            ->get()
            ->getResultArray();

        foreach ($borrowedRows as $row) {
            $assetId = (int) $row['asset_id'];
            $available[$assetId] = max(0, ($available[$assetId] ?? 0) - (int) $row['borrowed']);
        }

        return $available;
    }

    private function nextTransactionCode(): string
    {
        /*
        | -------------------------------------------------------------------
        | NOMOR TRANSAKSI OTOMATIS
        | -------------------------------------------------------------------
        | Kode transaksi dibuat harian agar mudah dilacak, contoh:
        | TRX-20260616-001.
        */
        $prefix = 'TRX-' . date('Ymd') . '-';
        $count = (new AssetTransactionModel())
            ->like('transaction_code', $prefix, 'after')
            ->countAllResults();

        return $prefix . str_pad((string) ($count + 1), 3, '0', STR_PAD_LEFT);
    }
}
