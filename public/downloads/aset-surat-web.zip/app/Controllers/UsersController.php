<?php

namespace App\Controllers;

use App\Models\UserModel;

class UsersController extends BaseController
{
    /*
    | -------------------------------------------------------------------
    | CONTROLLER MANAJEMEN PENGGUNA
    | -------------------------------------------------------------------
    | Controller ini khusus Admin untuk menambah, mengubah, menonaktifkan,
    | dan menghapus akun pengguna aplikasi.
    |
    | Tips Debugging:
    | - Jika halaman 403/akses ditolak, pastikan login sebagai role admin.
    | - Jika password baru tidak berlaku, pastikan field password tidak kosong saat update.
    */
    private UserModel $users;

    public function __construct()
    {
        $this->users = new UserModel();
    }

    public function index()
    {
        /*
        | -------------------------------------------------------------------
        | DAFTAR PENGGUNA
        | -------------------------------------------------------------------
        | Menampilkan seluruh akun dalam sistem untuk dipantau Admin.
        */
        return view('users/index', [
            'title' => 'Manajemen Pengguna',
            'users' => $this->users->orderBy('name', 'ASC')->findAll(),
        ]);
    }

    public function create()
    {
        return view('users/form', [
            'title' => 'Tambah Pengguna',
            'user'  => null,
            'roles' => UserModel::ROLES,
        ]);
    }

    public function store()
    {
        /*
        | -------------------------------------------------------------------
        | SIMPAN PENGGUNA BARU
        | -------------------------------------------------------------------
        | Username dibuat unik dan password langsung di-hash sebelum disimpan
        | agar tidak ada password asli di database.
        |
        | Tips Debugging:
        | - Jika validasi username gagal, cek apakah username sudah digunakan.
        */
        $rules = [
            'name'     => 'required|min_length[3]|max_length[120]',
            'username' => 'required|min_length[3]|max_length[80]|is_unique[users.username]',
            'password' => 'required|min_length[6]',
            'role'     => 'required|in_list[admin,operator,pimpinan]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->users->insert([
            'name'          => trim((string) $this->request->getPost('name')),
            'username'      => trim((string) $this->request->getPost('username')),
            'password_hash' => password_hash((string) $this->request->getPost('password'), PASSWORD_DEFAULT),
            'role'          => (string) $this->request->getPost('role'),
            'is_active'     => (int) $this->request->getPost('is_active'),
        ]);

        return redirect()->to('/users')->with('success', 'Pengguna baru berhasil ditambahkan.');
    }

    public function edit(int $id)
    {
        $user = $this->users->find($id);

        if (! $user) {
            return redirect()->to('/users')->with('error', 'Data pengguna tidak ditemukan.');
        }

        return view('users/form', [
            'title' => 'Edit Pengguna',
            'user'  => $user,
            'roles' => UserModel::ROLES,
        ]);
    }

    public function update(int $id)
    {
        /*
        | -------------------------------------------------------------------
        | UPDATE PENGGUNA
        | -------------------------------------------------------------------
        | Password bersifat opsional saat edit. Jika admin mengisi password baru,
        | sistem mengganti hash lama dengan hash baru.
        |
        | Tips Debugging:
        | - Jika username dianggap duplikat, cek rule is_unique dengan id pengecualian.
        */
        $user = $this->users->find($id);

        if (! $user) {
            return redirect()->to('/users')->with('error', 'Data pengguna tidak ditemukan.');
        }

        $rules = [
            'name'     => 'required|min_length[3]|max_length[120]',
            'username' => "required|min_length[3]|max_length[80]|is_unique[users.username,id,{$id}]",
            'role'     => 'required|in_list[admin,operator,pimpinan]',
        ];

        if ($this->request->getPost('password')) {
            $rules['password'] = 'min_length[6]';
        }

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $payload = [
            'name'      => trim((string) $this->request->getPost('name')),
            'username'  => trim((string) $this->request->getPost('username')),
            'role'      => (string) $this->request->getPost('role'),
            'is_active' => (int) $this->request->getPost('is_active'),
        ];

        if ($this->request->getPost('password')) {
            $payload['password_hash'] = password_hash((string) $this->request->getPost('password'), PASSWORD_DEFAULT);
        }

        $this->users->update($id, $payload);

        return redirect()->to('/users')->with('success', 'Data pengguna berhasil diperbarui.');
    }

    public function destroy(int $id)
    {
        /*
        | -------------------------------------------------------------------
        | HAPUS PENGGUNA
        | -------------------------------------------------------------------
        | Admin tidak boleh menghapus akun yang sedang dipakai sendiri untuk
        | mencegah kehilangan akses saat masih login.
        |
        | Tips Debugging:
        | - Jika hapus ditolak, cek apakah id sama dengan session user aktif.
        */
        if ((int) current_user('id') === $id) {
            return redirect()->to('/users')->with('error', 'Akun yang sedang digunakan tidak boleh dihapus.');
        }

        $this->users->delete($id);

        return redirect()->to('/users')->with('success', 'Pengguna berhasil dihapus.');
    }
}
