<?php

namespace App\Controllers\Concerns;

use CodeIgniter\HTTP\Files\UploadedFile;

trait HandlesUploads
{
    /*
    | -------------------------------------------------------------------
    | TRAIT UPLOAD FILE
    | -------------------------------------------------------------------
    | Trait ini memusatkan logika upload untuk foto aset dan lampiran surat
    | agar aturan ukuran, ekstensi, dan lokasi penyimpanan konsisten.
    |
    | Alur Kerja:
    | - Controller memanggil storeUploadedFile().
    | - File dicek valid, ukuran maksimal, dan ekstensi.
    | - File dipindahkan ke public/uploads/{folder}.
    |
    | Tips Debugging:
    | - Jika file tidak tersimpan, cek permission folder public/uploads.
    | - Jika format ditolak, pastikan ekstensi ada di daftar allowedExtensions.
    */
    protected function storeUploadedFile(string $field, string $folder, array $allowedExtensions, int $maxSizeMb = 5): ?string
    {
        $file = $this->request->getFile($field);

        if (! $file instanceof UploadedFile || $file->getError() === UPLOAD_ERR_NO_FILE) {
            return null;
        }

        if (! $file->isValid()) {
            throw new \RuntimeException('File gagal diunggah. Silakan coba kembali.');
        }

        if ($file->getSize() > ($maxSizeMb * 1024 * 1024)) {
            throw new \RuntimeException("Ukuran file maksimal {$maxSizeMb} MB.");
        }

        $extension = strtolower($file->getClientExtension());
        if (! in_array($extension, $allowedExtensions, true)) {
            throw new \RuntimeException('Format file tidak diizinkan.');
        }

        $targetPath = FCPATH . 'uploads' . DIRECTORY_SEPARATOR . $folder;
        if (! is_dir($targetPath)) {
            mkdir($targetPath, 0775, true);
        }

        $fileName = $file->getRandomName();
        $file->move($targetPath, $fileName);

        return 'uploads/' . $folder . '/' . $fileName;
    }

    protected function removeUploadedFile(?string $path): void
    {
        /*
        | -------------------------------------------------------------------
        | HAPUS FILE LAMA
        | -------------------------------------------------------------------
        | Method ini dipakai saat data dihapus atau file diganti agar folder
        | upload tidak penuh dengan lampiran yang sudah tidak dipakai.
        |
        | Tips Debugging:
        | - Jika file tidak terhapus, cek apakah path tersimpan relatif dari public/.
        */
        if (! $path) {
            return;
        }

        $fullPath = FCPATH . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $path);
        if (is_file($fullPath)) {
            unlink($fullPath);
        }
    }
}
