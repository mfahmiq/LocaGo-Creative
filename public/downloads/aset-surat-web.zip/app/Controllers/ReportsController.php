<?php

namespace App\Controllers;

use App\Models\AssetModel;
use App\Models\AssetTransactionModel;
use App\Models\DispositionModel;
use App\Models\IncomingLetterModel;
use App\Models\OutgoingLetterModel;

class ReportsController extends BaseController
{
    /*
    | -------------------------------------------------------------------
    | CONTROLLER LAPORAN
    | -------------------------------------------------------------------
    | Controller ini menyediakan laporan aset, surat masuk, surat keluar, dan
    | disposisi. Export Excel dibuat sebagai CSV yang kompatibel dengan Excel,
    | sedangkan export PDF dilakukan melalui halaman print browser.
    |
    | Alur Kerja:
    | - Pengguna memilih jenis laporan.
    | - Sistem menampilkan tabel dengan filter.
    | - Tombol CSV mengunduh file, tombol Print dapat disimpan sebagai PDF.
    |
    | Tips Debugging:
    | - Jika CSV kosong, cek filter tanggal/status yang sedang aktif.
    | - Jika print berantakan, cek view app/Views/reports/print.php.
    */
    public function index()
    {
        return view('reports/index', [
            'title' => 'Laporan & Rekap Data',
            'reports' => $this->reportMenu(),
        ]);
    }

    public function show(string $type)
    {
        $report = $this->reportData($type);

        if (! $report) {
            return redirect()->to('/reports')->with('error', 'Jenis laporan tidak ditemukan.');
        }

        return view('reports/show', $report + [
            'title'   => $report['heading'],
            'type'    => $type,
            'filters' => $this->request->getGet(),
        ]);
    }

    public function csv(string $type)
    {
        /*
        | -------------------------------------------------------------------
        | EXPORT CSV
        | -------------------------------------------------------------------
        | CSV dipakai sebagai export Excel ringan tanpa dependency tambahan.
        | Excel, LibreOffice, dan Google Sheets dapat membuka file ini.
        |
        | Tips Debugging:
        | - Jika karakter Indonesia rusak, pastikan aplikasi spreadsheet membaca UTF-8.
        */
        $report = $this->reportData($type);

        if (! $report) {
            return redirect()->to('/reports')->with('error', 'Jenis laporan tidak ditemukan.');
        }

        $handle = fopen('php://temp', 'r+');
        fputcsv($handle, array_values($report['columns']));

        foreach ($report['rows'] as $row) {
            $line = [];

            foreach (array_keys($report['columns']) as $key) {
                $line[] = $row[$key] ?? '';
            }

            fputcsv($handle, $line);
        }

        rewind($handle);
        $csv = stream_get_contents($handle);
        fclose($handle);

        $filename = $type . '-' . date('Ymd-His') . '.csv';

        return $this->response
            ->setHeader('Content-Type', 'text/csv; charset=UTF-8')
            ->setHeader('Content-Disposition', 'attachment; filename="' . $filename . '"')
            ->setBody("\xEF\xBB\xBF" . $csv);
    }

    public function print(string $type)
    {
        $report = $this->reportData($type);

        if (! $report) {
            return redirect()->to('/reports')->with('error', 'Jenis laporan tidak ditemukan.');
        }

        return view('reports/print', $report + [
            'title' => $report['heading'],
            'type'  => $type,
        ]);
    }

    private function reportMenu(): array
    {
        return [
            'assets'       => ['label' => 'Inventaris Aset', 'description' => 'Rekap aset per kategori, lokasi, kondisi, dan nilai.'],
            'incoming'     => ['label' => 'Surat Masuk', 'description' => 'Rekap surat masuk berdasarkan tanggal, pengirim, prioritas, dan status.'],
            'outgoing'     => ['label' => 'Surat Keluar', 'description' => 'Rekap surat keluar beserta status pengiriman dan penerima.'],
            'dispositions' => ['label' => 'Disposisi', 'description' => 'Monitoring instruksi disposisi dan status tindak lanjut.'],
            'asset-transactions' => ['label' => 'Transaksi Aset', 'description' => 'Rekap peminjaman dan pengembalian aset antar unit.'],
        ];
    }

    private function reportData(string $type): ?array
    {
        return match ($type) {
            'assets'       => $this->assetReport(),
            'incoming'     => $this->incomingReport(),
            'outgoing'     => $this->outgoingReport(),
            'dispositions' => $this->dispositionReport(),
            'asset-transactions' => $this->assetTransactionReport(),
            default        => null,
        };
    }

    private function assetReport(): array
    {
        /*
        | -------------------------------------------------------------------
        | LAPORAN ASET
        | -------------------------------------------------------------------
        | Mengambil seluruh aset dengan nama kategori/lokasi dan mendukung
        | filter kondisi melalui query string.
        */
        $query = (new AssetModel())->withRelations();

        if ($condition = $this->request->getGet('condition')) {
            $query->where('assets.condition_status', $condition);
        }

        $rows = $query->orderBy('assets.name', 'ASC')->findAll();

        foreach ($rows as &$row) {
            $row['condition_status'] = human_status($row['condition_status']);
            $row['value']            = rupiah($row['value']);
        }

        return [
            'heading' => 'Laporan Inventaris Aset',
            'rows'    => $rows,
            'columns' => [
                'code'             => 'Kode',
                'name'             => 'Nama Aset',
                'category_name'    => 'Kategori',
                'location_name'    => 'Lokasi',
                'quantity'         => 'Jumlah',
                'condition_status' => 'Kondisi',
                'acquisition_year' => 'Tahun',
                'value'            => 'Nilai/Harga',
                'custodian'        => 'Penanggung Jawab',
            ],
            'filterOptions' => [
                'conditions' => AssetModel::CONDITIONS,
            ],
        ];
    }

    private function incomingReport(): array
    {
        $query = (new IncomingLetterModel())->withCreator();
        $this->applyDateAndStatusFilters($query, 'incoming_letters.received_date', 'incoming_letters.status');

        $rows = $query->orderBy('incoming_letters.received_date', 'DESC')->findAll();

        foreach ($rows as &$row) {
            $row['received_date'] = date_id($row['received_date']);
            $row['letter_date']   = date_id($row['letter_date']);
            $row['status']        = human_status($row['status']);
        }

        return [
            'heading' => 'Laporan Surat Masuk',
            'rows'    => $rows,
            'columns' => [
                'letter_number' => 'Nomor Surat',
                'letter_date'   => 'Tanggal Surat',
                'received_date' => 'Tanggal Terima',
                'sender'        => 'Pengirim',
                'subject'       => 'Perihal',
                'priority'      => 'Sifat',
                'status'        => 'Status',
                'creator_name'  => 'Dicatat Oleh',
            ],
            'filterOptions' => [
                'statuses' => IncomingLetterModel::STATUSES,
            ],
        ];
    }

    private function outgoingReport(): array
    {
        $query = (new OutgoingLetterModel())->withCreator();
        $this->applyDateAndStatusFilters($query, 'outgoing_letters.letter_date', 'outgoing_letters.status');

        $rows = $query->orderBy('outgoing_letters.letter_date', 'DESC')->findAll();

        foreach ($rows as &$row) {
            $row['letter_date']   = date_id($row['letter_date']);
            $row['received_date'] = date_id($row['received_date']);
            $row['status']        = human_status($row['status']);
        }

        return [
            'heading' => 'Laporan Surat Keluar',
            'rows'    => $rows,
            'columns' => [
                'letter_number'    => 'Nomor Surat',
                'letter_date'      => 'Tanggal Surat',
                'recipient'        => 'Tujuan',
                'destination_unit' => 'Unit Tujuan',
                'subject'          => 'Perihal',
                'status'           => 'Status',
                'receiver_name'    => 'Penerima',
                'received_date'    => 'Tanggal Diterima',
                'creator_name'     => 'Dicatat Oleh',
            ],
            'filterOptions' => [
                'statuses' => OutgoingLetterModel::STATUSES,
            ],
        ];
    }

    private function dispositionReport(): array
    {
        $query = (new DispositionModel())->withLetter();

        if ($status = $this->request->getGet('status')) {
            $query->where('dispositions.status', $status);
        }

        $rows = $query->orderBy('dispositions.created_at', 'DESC')->findAll();

        foreach ($rows as &$row) {
            $row['due_date']   = date_id($row['due_date']);
            $row['status']     = human_status($row['status']);
            $row['created_at'] = date_id($row['created_at']);
        }

        return [
            'heading' => 'Laporan Disposisi Surat',
            'rows'    => $rows,
            'columns' => [
                'letter_number' => 'Nomor Surat',
                'subject'       => 'Perihal',
                'target_unit'   => 'Tujuan Disposisi',
                'instruction'   => 'Instruksi',
                'due_date'      => 'Batas Tindak Lanjut',
                'status'        => 'Status',
                'disposer_name' => 'Pemberi Disposisi',
                'created_at'    => 'Tanggal Disposisi',
            ],
            'filterOptions' => [
                'statuses' => DispositionModel::STATUSES,
            ],
        ];
    }

    private function assetTransactionReport(): array
    {
        /*
        | -------------------------------------------------------------------
        | LAPORAN TRANSAKSI ASET
        | -------------------------------------------------------------------
        | Mengambil riwayat peminjaman aset antar unit beserta status akhir.
        |
        | Tips Debugging:
        | - Jika laporan kosong, pastikan modul Transaksi Aset sudah memiliki data.
        */
        $query = (new AssetTransactionModel())->withCreator();

        if ($from = $this->request->getGet('from')) {
            $query->where('asset_transactions.loan_date >=', $from);
        }

        if ($to = $this->request->getGet('to')) {
            $query->where('asset_transactions.loan_date <=', $to);
        }

        if ($status = $this->request->getGet('status')) {
            $query->where('asset_transactions.status', $status);
        }

        $rows = $query->orderBy('asset_transactions.loan_date', 'DESC')->findAll();

        foreach ($rows as &$row) {
            $row['loan_date']            = date_id($row['loan_date']);
            $row['expected_return_date'] = date_id($row['expected_return_date']);
            $row['actual_return_date']   = date_id($row['actual_return_date']);
            $row['status']               = human_status($row['status']);
        }

        return [
            'heading' => 'Laporan Transaksi Aset',
            'rows'    => $rows,
            'columns' => [
                'transaction_code'     => 'Kode Transaksi',
                'borrower_unit'        => 'Unit Peminjam',
                'borrower_name'        => 'Penanggung Jawab',
                'loan_date'            => 'Tanggal Pinjam',
                'expected_return_date' => 'Rencana Kembali',
                'actual_return_date'   => 'Tanggal Kembali',
                'status'               => 'Status',
                'purpose'              => 'Keperluan',
                'creator_name'         => 'Dicatat Oleh',
            ],
            'filterOptions' => [
                'statuses' => AssetTransactionModel::STATUSES,
            ],
        ];
    }

    private function applyDateAndStatusFilters(object $query, string $dateColumn, string $statusColumn): void
    {
        /*
        | -------------------------------------------------------------------
        | FILTER TANGGAL DAN STATUS LAPORAN
        | -------------------------------------------------------------------
        | Method ini dipakai ulang oleh laporan surat masuk dan surat keluar
        | agar perilaku filter konsisten.
        |
        | Tips Debugging:
        | - Jika laporan kosong, hapus filter lalu cek kembali datanya.
        */
        if ($from = $this->request->getGet('from')) {
            $query->where($dateColumn . ' >=', $from);
        }

        if ($to = $this->request->getGet('to')) {
            $query->where($dateColumn . ' <=', $to);
        }

        if ($status = $this->request->getGet('status')) {
            $query->where($statusColumn, $status);
        }
    }
}
