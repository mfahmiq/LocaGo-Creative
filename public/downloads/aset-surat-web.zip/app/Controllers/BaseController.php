<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

/**
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 *
 * Extend this class in any new controllers:
 * ```
 *     class Home extends BaseController
 * ```
 *
 * For security, be sure to declare any new methods as protected or private.
 */
abstract class BaseController extends Controller
{
    /**
     * Be sure to declare properties for any property fetch you initialized.
     * The creation of dynamic property is deprecated in PHP 8.2.
     */

    protected $helpers = ['form', 'url', 'app'];

    protected $session;

    /**
     * @return void
     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        // Caution: Do not edit this line.
        parent::initController($request, $response, $logger);

        /*
        | -------------------------------------------------------------------
        | SESSION GLOBAL CONTROLLER
        | -------------------------------------------------------------------
        | Semua controller turunan membutuhkan session untuk membaca status
        | login, role pengguna, flash message, dan notifikasi singkat.
        |
        | Alur Kerja:
        | - CodeIgniter memanggil initController() pada setiap request.
        | - Service session dimuat satu kali di BaseController.
        | - Controller lain cukup memakai $this->session tanpa memanggil service ulang.
        |
        | Tips Debugging:
        | - Jika data login hilang setelah redirect, periksa konfigurasi app/Config/Session.php.
        | - Jika helper tidak terbaca di view, pastikan nama helper ada di property $helpers.
        */
        $this->session = service('session');
    }
}
