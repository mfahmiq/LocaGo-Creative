<?php

namespace App\Controllers;

use App\Models\UserModel;

class AuthController extends BaseController
{
    /*
    | -------------------------------------------------------------------
    | CONTROLLER AUTENTIKASI
    | -------------------------------------------------------------------
    | Controller ini menangani halaman login, proses validasi username dan
    | password, penyimpanan session, serta logout.
    |
    | Alur Kerja:
    | - Pengguna membuka /login.
    | - Form dikirim ke AuthController::attempt().
    | - Jika kredensial valid, session dibuat dan pengguna masuk dashboard.
    |
    | Tips Debugging:
    | - Jika view login tidak tampil, pastikan file ada di app/Views/auth/login.php.
    | - Jika login gagal, jalankan seeder dan cek akun awal di database.
    */
    public function login()
    {
        if ($this->session->get('isLoggedIn')) {
            return redirect()->to('/dashboard');
        }

        return view('auth/login');
    }

    public function attempt()
    {
        /*
        | -------------------------------------------------------------------
        | PROSES LOGIN
        | -------------------------------------------------------------------
        | Validasi dibuat ringkas: username dan password wajib diisi, lalu
        | dicek melalui UserModel::verifyLogin().
        |
        | Tips Debugging:
        | - Jika validasi gagal, pastikan name input form adalah username/password.
        */
        $rules = [
            'username' => 'required',
            'password' => 'required',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Username dan password wajib diisi.');
        }

        $model = new UserModel();
        $user  = $model->verifyLogin(
            trim((string) $this->request->getPost('username')),
            (string) $this->request->getPost('password')
        );

        if (! $user) {
            return redirect()->back()->withInput()->with('error', 'Username atau password tidak sesuai.');
        }

        $this->session->regenerate(true);

        $this->session->set([
            'isLoggedIn' => true,
            'user'       => [
                'id'       => $user['id'],
                'name'     => $user['name'],
                'username' => $user['username'],
                'role'     => $user['role'],
            ],
        ]);

        return redirect()->to('/dashboard')->with('success', 'Selamat datang, ' . $user['name'] . '.');
    }

    public function logout()
    {
        /*
        | -------------------------------------------------------------------
        | LOGOUT
        | -------------------------------------------------------------------
        | Session dihancurkan agar akun tidak dapat dipakai lagi melalui tab
        | browser yang sama setelah pengguna keluar.
        |
        | Tips Debugging:
        | - Jika masih bisa membuka dashboard setelah logout, bersihkan cache browser.
        */
        $this->session->remove(['isLoggedIn', 'user']);

        return redirect()->to('/login')->with('success', 'Anda berhasil logout.');
    }
}
