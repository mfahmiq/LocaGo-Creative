<?php

namespace App\Controllers;

use App\Controllers\Concerns\HandlesUploads;
use App\Libraries\LetterDateExtractor;
use App\Models\DispositionModel;
use App\Models\IncomingLetterModel;

class IncomingLettersController extends BaseController
{
    use HandlesUploads;

    /*
    | -------------------------------------------------------------------
    | CONTROLLER SURAT MASUK
    | -------------------------------------------------------------------
    | Controller ini menangani pencatatan surat masuk, upload lampiran,
    | monitoring status, dan pembuatan disposisi oleh pimpinan.
    |
    | Alur Kerja:
    | - Operator/Admin input surat masuk.
    | - Status awal otomatis "menunggu_disposisi".
    | - Pimpinan/Admin membuat disposisi ke unit tujuan.
    | - Status surat dapat dipantau sampai selesai/diarsipkan.
    |
    | Tips Debugging:
    | - Jika disposisi tidak tampil, cek tabel dispositions.
    | - Jika file lampiran tidak bisa dibuka, cek folder public/uploads/surat.
    */
    private IncomingLetterModel $letters;

    public function __construct()
    {
        $this->letters = new IncomingLetterModel();
    }

    public function index()
    {
        /*
        | -------------------------------------------------------------------
        | DAFTAR DAN FILTER SURAT MASUK
        | -------------------------------------------------------------------
        | Filter mendukung pencarian nomor/perihal/pengirim, status, prioritas,
        | dan rentang tanggal terima.
        |
        | Tips Debugging:
        | - Jika filter tanggal tidak bekerja, pastikan format input adalah YYYY-MM-DD.
        */
        $filters = [
            'q'        => trim((string) $this->request->getGet('q')),
            'status'   => $this->request->getGet('status'),
            'priority' => $this->request->getGet('priority'),
            'from'     => $this->request->getGet('from'),
            'to'       => $this->request->getGet('to'),
        ];

        $query = $this->letters->withCreator();

        if ($filters['q'] !== '') {
            $query->groupStart()
                ->like('incoming_letters.letter_number', $filters['q'])
                ->orLike('incoming_letters.sender', $filters['q'])
                ->orLike('incoming_letters.subject', $filters['q'])
                ->groupEnd();
        }

        if ($filters['status']) {
            $query->where('incoming_letters.status', $filters['status']);
        }

        if ($filters['priority']) {
            $query->where('incoming_letters.priority', $filters['priority']);
        }

        if ($filters['from']) {
            $query->where('incoming_letters.received_date >=', $filters['from']);
        }

        if ($filters['to']) {
            $query->where('incoming_letters.received_date <=', $filters['to']);
        }

        return view('incoming_letters/index', [
            'title'      => 'Surat Masuk',
            'letters'    => $query->orderBy('incoming_letters.received_date', 'DESC')->paginate(10),
            'pager'      => $this->letters->pager,
            'filters'    => $filters,
            'statuses'   => IncomingLetterModel::STATUSES,
            'priorities' => IncomingLetterModel::PRIORITIES,
        ]);
    }

    public function create()
    {
        return view('incoming_letters/form', $this->formData('Tambah Surat Masuk'));
    }

    public function extractDate()
    {
        /*
        | -------------------------------------------------------------------
        | AJAX EKSTRAKSI TANGGAL SURAT
        | -------------------------------------------------------------------
        | Endpoint ini dipanggil dari form surat masuk ketika operator memilih
        | file lampiran. Sistem mencoba membaca tanggal lalu mengirim hasil
        | ke browser tanpa menyimpan data surat.
        |
        | Tips Debugging:
        | - Jika response 403, pastikan token CSRF ikut dikirim oleh JavaScript.
        | - Jika tanggal kosong, cek apakah file PDF berupa teks atau scan gambar.
        */
        $file = $this->request->getFile('attachment');

        if (! $file || ! $file->isValid()) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'File belum valid untuk dibaca.',
                'csrfName' => csrf_token(),
                'csrfHash' => csrf_hash(),
            ]);
        }

        $result = (new LetterDateExtractor())->extract($file->getTempName(), $file->getClientExtension());

        return $this->response->setJSON([
            'success' => $result['date'] !== null,
            'date' => $result['date'],
            'message' => $result['message'],
            'csrfName' => csrf_token(),
            'csrfHash' => csrf_hash(),
        ]);
    }

    public function store()
    {
        /*
        | -------------------------------------------------------------------
        | SIMPAN SURAT MASUK
        | -------------------------------------------------------------------
        | Surat yang baru dicatat otomatis masuk status menunggu disposisi agar
        | muncul di dashboard pimpinan.
        |
        | Tips Debugging:
        | - Jika status awal salah, cek payload() pada controller ini.
        */
        $detectedDate = $this->postedOrDetectedLetterDate();

        if (! $this->validate($this->rules())) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        if ($detectedDate === '') {
            return redirect()->back()->withInput()->with('error', 'Tanggal surat wajib diisi atau dikenali dari lampiran.');
        }

        try {
            $payload              = $this->payload($detectedDate);
            $payload['status']    = 'menunggu_disposisi';
            $payload['created_by'] = current_user('id');
            $attachment           = $this->storeUploadedFile('attachment', 'surat', ['pdf', 'jpg', 'jpeg', 'png', 'webp'], 8);

            if ($attachment) {
                $payload['attachment'] = $attachment;
            }

            $this->letters->insert($payload);

            return redirect()->to('/incoming-letters')->with('success', 'Surat masuk berhasil dicatat.');
        } catch (\RuntimeException $exception) {
            return redirect()->back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function show(int $id)
    {
        $letter = (new IncomingLetterModel())->withCreator()->find($id);

        if (! $letter) {
            return redirect()->to('/incoming-letters')->with('error', 'Surat masuk tidak ditemukan.');
        }

        return view('incoming_letters/show', [
            'title'        => 'Detail Surat Masuk',
            'letter'       => $letter,
            'statuses'     => IncomingLetterModel::STATUSES,
            'dispositions' => (new DispositionModel())->withLetter()
                ->where('dispositions.incoming_letter_id', $id)
                ->orderBy('dispositions.created_at', 'DESC')
                ->findAll(),
        ]);
    }

    public function edit(int $id)
    {
        $letter = $this->letters->find($id);

        if (! $letter) {
            return redirect()->to('/incoming-letters')->with('error', 'Surat masuk tidak ditemukan.');
        }

        return view('incoming_letters/form', $this->formData('Edit Surat Masuk', $letter));
    }

    public function update(int $id)
    {
        /*
        | -------------------------------------------------------------------
        | UPDATE SURAT MASUK
        | -------------------------------------------------------------------
        | Lampiran bersifat opsional. Jika lampiran baru diunggah, file lama
        | dihapus dari folder public/uploads/surat.
        |
        | Tips Debugging:
        | - Jika file baru tidak berubah, cek enctype form multipart/form-data.
        */
        $letter = $this->letters->find($id);

        if (! $letter) {
            return redirect()->to('/incoming-letters')->with('error', 'Surat masuk tidak ditemukan.');
        }

        $detectedDate = $this->postedOrDetectedLetterDate();

        if (! $this->validate($this->rules())) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        if ($detectedDate === '') {
            return redirect()->back()->withInput()->with('error', 'Tanggal surat wajib diisi atau dikenali dari lampiran.');
        }

        try {
            $payload    = $this->payload($detectedDate);
            $attachment = $this->storeUploadedFile('attachment', 'surat', ['pdf', 'jpg', 'jpeg', 'png', 'webp'], 8);

            if ($attachment) {
                $this->removeUploadedFile($letter['attachment'] ?? null);
                $payload['attachment'] = $attachment;
            }

            $this->letters->update($id, $payload);

            return redirect()->to("/incoming-letters/{$id}")->with('success', 'Surat masuk berhasil diperbarui.');
        } catch (\RuntimeException $exception) {
            return redirect()->back()->withInput()->with('error', $exception->getMessage());
        }
    }

    public function dispose(int $id)
    {
        /*
        | -------------------------------------------------------------------
        | BUAT DISPOSISI SURAT
        | -------------------------------------------------------------------
        | Disposisi berisi unit tujuan, instruksi, batas tindak lanjut, dan
        | pengguna pimpinan/admin yang membuat instruksi.
        |
        | Tips Debugging:
        | - Jika form disposisi gagal, cek name target_unit dan instruction.
        */
        $letter = $this->letters->find($id);

        if (! $letter) {
            return redirect()->to('/incoming-letters')->with('error', 'Surat masuk tidak ditemukan.');
        }

        $rules = [
            'target_unit' => 'required|max_length[160]',
            'instruction' => 'required|min_length[5]',
            'due_date'    => 'permit_empty|valid_date',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        (new DispositionModel())->insert([
            'incoming_letter_id' => $id,
            'target_unit'        => trim((string) $this->request->getPost('target_unit')),
            'instruction'        => trim((string) $this->request->getPost('instruction')),
            'due_date'           => $this->request->getPost('due_date') ?: null,
            'status'             => 'pending',
            'disposed_by'        => current_user('id'),
        ]);

        $this->letters->update($id, ['status' => 'didisposisikan']);

        return redirect()->to("/incoming-letters/{$id}")->with('success', 'Disposisi berhasil dibuat.');
    }

    public function updateStatus(int $id)
    {
        /*
        | -------------------------------------------------------------------
        | UPDATE STATUS SURAT MASUK
        | -------------------------------------------------------------------
        | Status surat dapat diubah untuk mencerminkan tindak lanjut dokumen.
        |
        | Tips Debugging:
        | - Jika status ditolak, pastikan value select ada di IncomingLetterModel::STATUSES.
        */
        $status = (string) $this->request->getPost('status');

        if (! array_key_exists($status, IncomingLetterModel::STATUSES)) {
            return redirect()->back()->with('error', 'Status surat tidak valid.');
        }

        $this->letters->update($id, ['status' => $status]);

        return redirect()->back()->with('success', 'Status surat masuk berhasil diperbarui.');
    }

    public function destroy(int $id)
    {
        $letter = $this->letters->find($id);

        if ($letter) {
            $this->removeUploadedFile($letter['attachment'] ?? null);
            $this->letters->delete($id);
        }

        return redirect()->to('/incoming-letters')->with('success', 'Surat masuk berhasil dihapus.');
    }

    private function formData(string $title, ?array $letter = null): array
    {
        return [
            'title'      => $title,
            'letter'     => $letter,
            'priorities' => IncomingLetterModel::PRIORITIES,
            'statuses'   => IncomingLetterModel::STATUSES,
        ];
    }

    private function rules(): array
    {
        return [
            'letter_number' => 'required|max_length[120]',
            'letter_date'   => 'permit_empty|valid_date',
            'received_date' => 'required|valid_date',
            'sender'        => 'required|max_length[160]',
            'subject'       => 'required|max_length[200]',
            'priority'      => 'required|max_length[50]',
        ];
    }

    private function payload(?string $letterDate = null): array
    {
        /*
        | -------------------------------------------------------------------
        | PAYLOAD SURAT MASUK
        | -------------------------------------------------------------------
        | Mengubah input form menjadi struktur data yang sesuai dengan
        | IncomingLetterModel.
        |
        | Tips Debugging:
        | - Jika data tidak masuk, cek atribut name pada form surat masuk.
        */
        return [
            'letter_number' => trim((string) $this->request->getPost('letter_number')),
            'letter_date'   => $letterDate ?: (string) $this->request->getPost('letter_date'),
            'received_date' => (string) $this->request->getPost('received_date'),
            'sender'        => trim((string) $this->request->getPost('sender')),
            'subject'       => trim((string) $this->request->getPost('subject')),
            'priority'      => (string) $this->request->getPost('priority'),
            'summary'       => trim((string) $this->request->getPost('summary')),
        ];
    }

    private function postedOrDetectedLetterDate(): string
    {
        /*
        | -------------------------------------------------------------------
        | TANGGAL SURAT OTOMATIS
        | -------------------------------------------------------------------
        | Method ini menjaga alur server-side: jika field tanggal kosong tetapi
        | operator sudah upload lampiran, sistem mencoba membaca tanggal dari
        | file sebelum data disimpan.
        |
        | Tips Debugging:
        | - Jika tanggal tidak terisi otomatis, lihat pesan AJAX pada form.
        | - Jika file gambar, pastikan Tesseract sudah terpasang.
        */
        $postedDate = trim((string) $this->request->getPost('letter_date'));

        if ($postedDate !== '') {
            return $postedDate;
        }

        $file = $this->request->getFile('attachment');

        if (! $file || ! $file->isValid()) {
            return '';
        }

        $result = (new LetterDateExtractor())->extract($file->getTempName(), $file->getClientExtension());

        return $result['date'] ?? '';
    }
}
