<?php

namespace App\Controllers;

class BackupController extends BaseController
{
    /*
    | -------------------------------------------------------------------
    | CONTROLLER BACKUP DATABASE
    | -------------------------------------------------------------------
    | Controller ini menyediakan backup database manual dalam bentuk file SQL
    | yang dapat diunduh oleh Admin sebagai langkah awal KNF Reliability.
    |
    | Alur Kerja:
    | - Admin membuka halaman backup.
    | - Admin menekan tombol unduh backup.
    | - Sistem membaca struktur dan isi tabel lalu membentuk file .sql.
    |
    | Tips Debugging:
    | - Jika backup gagal, pastikan koneksi database MySQL aktif.
    | - Jika file terlalu besar, lakukan backup langsung via phpMyAdmin.
    */
    public function index()
    {
        return view('backup/index', [
            'title' => 'Backup Database',
            'tables' => db_connect()->listTables(),
        ]);
    }

    public function download()
    {
        /*
        | -------------------------------------------------------------------
        | UNDUH BACKUP SQL
        | -------------------------------------------------------------------
        | Dump sederhana ini cocok untuk database kecil-menengah sekolah. Untuk
        | database sangat besar, backup server/phpMyAdmin tetap disarankan.
        */
        $db       = db_connect();
        $database = $db->database;
        $sql      = "-- Backup SMPI REJIS\n";
        $sql     .= "-- Database: {$database}\n";
        $sql     .= "-- Generated: " . date('Y-m-d H:i:s') . "\n\n";
        $sql     .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

        foreach ($db->listTables() as $table) {
            $safeTable = str_replace('`', '``', $table);
            $createRow = $db->query("SHOW CREATE TABLE `{$safeTable}`")->getRowArray();
            $createSql = $createRow['Create Table'] ?? array_values($createRow)[1] ?? '';

            $sql .= "DROP TABLE IF EXISTS `{$safeTable}`;\n";
            $sql .= $createSql . ";\n\n";

            $rows = $db->table($table)->get()->getResultArray();

            foreach ($rows as $row) {
                $columns = array_map(static fn ($column) => '`' . str_replace('`', '``', $column) . '`', array_keys($row));
                $values  = array_map(static fn ($value) => $value === null ? 'NULL' : db_connect()->escape($value), array_values($row));

                $sql .= 'INSERT INTO `' . $safeTable . '` (' . implode(', ', $columns) . ') VALUES (' . implode(', ', $values) . ");\n";
            }

            $sql .= "\n";
        }

        $sql .= "SET FOREIGN_KEY_CHECKS=1;\n";
        $filename = 'backup-smpi-rejis-' . date('Ymd-His') . '.sql';

        return $this->response->download($filename, $sql);
    }
}
