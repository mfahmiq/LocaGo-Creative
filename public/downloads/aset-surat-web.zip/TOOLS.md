# TOOLS.md

Status: aktif
Tanggal dibuat: 2026-07-04

## Prinsip Penggunaan Tools

Gunakan tools untuk membantu audit, verifikasi, ekstraksi, dan pembuatan artefak baru. Jangan gunakan tools untuk mengubah file lama kecuali user memberi instruksi eksplisit.

Aturan utama:

1. Utamakan operasi read-only saat audit.
2. Jangan membaca atau menampilkan credential, password, token, API key, cookie, session, atau data sensitif.
3. Jangan membaca isi `.env` tanpa izin eksplisit.
4. Jangan mengubah PDF asli, SQL asli, file upload, file runtime, atau source code aplikasi tanpa instruksi.
5. Simpan artefak kerja baru di folder yang disetujui.
6. Sebelum memperbarui file penting, buat backup dengan nama jelas, kecuali user melarang.

## Lingkungan Project

Workspace utama:

```text
C:\laragon\www\aset-surat-web
```

Jenis aplikasi:

```text
CodeIgniter 4 / PHP / MySQL atau MariaDB
```

Versi yang terdeteksi saat audit awal:

```text
PHP CLI: 8.4.10
Composer: 2.8.9
CodeIgniter framework: v4.7.3
```

## Laragon

Project berada di folder Laragon:

```text
C:\laragon\www\aset-surat-web
```

Untuk verifikasi manual melalui Laragon:

1. Pastikan Laragon aktif.
2. Pastikan service web server dan database berjalan.
3. Pastikan konfigurasi environment lokal sudah benar, tetapi jangan tampilkan isi `.env`.
4. Akses aplikasi melalui URL lokal yang berlaku di mesin user, misalnya host Laragon atau `php spark serve`.

## Verifikasi Aplikasi

Perintah read-only atau aman yang boleh digunakan untuk orientasi:

```powershell
php -v
composer --version
php spark --version
php spark routes
```

Perintah yang dapat menjalankan aplikasi lokal:

```powershell
php spark serve
```

Catatan:

1. Jangan menjalankan server jika user hanya meminta audit dokumen.
2. Jangan mengubah source code aplikasi saat hanya diminta audit.
3. Jangan menampilkan credential login dari dokumentasi atau seeder di output.
4. Jika aplikasi perlu diverifikasi di browser, catat URL, modul yang dicek, dan hasilnya.

## Verifikasi Database

Sumber struktur database yang tersedia:

```text
app/Database/Migrations/
database/*.sql
app/Controllers/ErdController.php
```

Perintah yang relatif aman untuk orientasi:

```powershell
php spark migrate:status
```

Perintah yang harus dihindari tanpa izin eksplisit karena dapat mengubah database:

```powershell
php spark migrate
php spark migrate:rollback
php spark db:seed DatabaseSeeder
mysql < file.sql
```

Jika perlu mengecek database aktif:

1. Jangan menampilkan password atau isi `.env`.
2. Gunakan kredensial yang sudah tersedia di lingkungan lokal hanya jika user mengizinkan.
3. Laporkan hanya struktur, jumlah tabel, status koneksi, atau ringkasan non-sensitif.

## Verifikasi Dokumen Skripsi

Untuk PDF:

1. Gunakan metadata, ekstraksi teks, render halaman, dan OCR jika diperlukan.
2. Jangan mengubah PDF asli.
3. Simpan hasil OCR/render sebagai file baru di folder kerja yang disetujui.
4. Jika OCR tidak akurat, beri catatan halaman/bagian yang perlu dicek manual.

Untuk DOCX:

1. Jangan membuat `SKRIPSI.docx` sebelum diminta.
2. Jika nanti membuat atau mengubah DOCX, gunakan workflow render/preview untuk mengecek layout.
3. Pastikan margin, font, spasi, heading, caption, penomoran halaman, daftar isi, daftar gambar, daftar tabel, daftar lampiran, sitasi, dan daftar pustaka mengikuti pedoman.
4. Jangan mengarang ketentuan kampus; ambil dari pedoman/outline.

## OCR Dan Render

Tools yang dapat digunakan:

```powershell
pdftotext
pdftoppm
pdfinfo
```

Jika OCR engine seperti Tesseract tidak tersedia:

1. Tetap lakukan render halaman ke PNG untuk review visual.
2. Catat bahwa OCR teks belum bisa dilakukan otomatis.
3. Jangan menyimpulkan aturan format dari gambar yang belum direview cukup jelas.

Lokasi output OCR/render pedoman dan outline:

```text
skripsi/01-pedoman-dan-outline/
```

## Git

Gunakan Git hanya untuk melihat status atau riwayat kecuali user meminta commit/push.

Perintah orientasi yang boleh digunakan:

```powershell
git status --short
git branch --show-current
git log -1 --pretty=format:"%h %ad %s" --date=iso
```

Jangan menjalankan:

```powershell
git reset --hard
git checkout --
git clean
```

kecuali user meminta secara eksplisit dan risikonya sudah jelas.

## Batasan Keamanan

Jangan menampilkan atau menyimpan:

1. Isi `.env`.
2. Password atau hash password.
3. Token, API key, cookie, session.
4. Isi file runtime/session/debugbar/log yang dapat memuat data sensitif.
5. Isi upload privat tanpa izin eksplisit.

Jika menemukan data sensitif, cukup catat jenis file/lokasinya secara umum dan nyatakan bahwa isinya tidak dibuka atau tidak ditampilkan.
