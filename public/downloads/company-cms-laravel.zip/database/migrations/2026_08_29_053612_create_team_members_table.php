<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('team_members', function (Blueprint $table) {
            $table->id();

            $table->string('name');

            $table->string('slug')->unique();

            $table->string('designation')->nullable();

            $table->string('department')->nullable();

            $table->string('email')->nullable();

            $table->string('phone')->nullable();

            $table->text('bio')->nullable();

            $table->string('profile_image')->nullable();

            $table->string('linkedin_url')->nullable();

            $table->string('twitter_url')->nullable();

            $table->string('facebook_url')->nullable();

            $table->integer('display_order')->default(0);

            $table->boolean('status')->default(true);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('team_members');
    }
};