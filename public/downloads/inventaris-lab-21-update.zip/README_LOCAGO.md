# Sistem Informasi Inventaris & Gudang - Inventaris Lab 21 Update

```
========================================================================
📦 Sistem Informasi Inventaris & Gudang - Inventaris Lab 21 Update
Kategori     : Bisnis & Manajemen
Tech Stack   : Laravel • PHP • MySQL • Bootstrap
Database     : MySQL (.sql) (File: backup-2026-07-24.sql)
Sumber Asli  : https://github.com/vianhubgit/Inventaris-lab-2.1-update (GitHub Open Source)
Stars GitHub : ⭐ 0 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/inventaris-lab-21-update`
     * Untuk Laragon: `C:/laragon/www/inventaris-lab-21-update`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database kosong `inventaris_lab` dulu di phpMyAdmin (file SQL ini
     TIDAK membuat database sendiri — tidak ada perintah CREATE DATABASE di
     dalamnya). Lalu klik tab 'Import', pilih file SQL yang disertakan pada:
     `backup-2026-07-24.sql`, pastikan database `inventaris_lab` yang dipilih
     sebagai tujuan import.
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = inventaris_lab   (sesuai .env.example repo asli)

4. JALANKAN APLIKASI:
   - Cara yang disarankan README repo asli (Laravel): dari folder proyek,
     jalankan `php artisan serve`, lalu buka http://127.0.0.1:8000
     (sebelumnya: `composer install`, salin `.env.example` menjadi `.env`,
     `php artisan key:generate`, `npm install && npm run build`).
   - Alternatif XAMPP/Laragon: arahkan document root web server ke folder
     `public` di dalam proyek, lalu buka http://localhost/inventaris-lab-21-update
     (akses langsung ke folder proyek tanpa `public` TIDAK akan jalan
     karena ini aplikasi Laravel).

5. AKUN LOGIN DEMO (terverifikasi terhadap database .sql bawaan):
   - Admin: Demoadmin / demoadmin  (login live terverifikasi oleh runner)
   - Sekretaris: Demosekretaris / demosekretaris
   - Sekretaris: sekretaris / sekretaris123
   - Catatan: README repo asli juga mendokumentasikan admin / admin123 —
     akun itu dibuat oleh seeder (php artisan migrate:fresh --seed), TETAPI
     password admin di file .sql bawaan sudah diganti pemilik repo, jadi
     admin/admin123 TIDAK bisa login setelah import .sql. Pakai Demoadmin
     untuk peran Admin, atau jalankan migrate:fresh --seed (langkah 6) untuk
     instalasi baru.

6. INSTALASI BARU VIA SEEDER (ALTERNATIF — ganti langkah 2, jangan keduanya):
   - Sebagai pengganti import .sql, Anda bisa membangun database dari nol:
     php artisan migrate --seed
     (atau `php artisan migrate:fresh --seed` untuk reset & isi ulang data demo)
   - Perintah ini membuat ulang semua tabel + akun demo dari README
     (admin / admin123 dan sekretaris / sekretaris123) + data contoh.
   - JANGAN jalankan ini setelah import .sql — migrate:fresh MENGHAPUS
     semua data hasil import.
========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
