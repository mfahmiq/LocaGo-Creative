<?php
session_start();
include '../config/db.php';

// Cek login admin
// if (!isset($_SESSION['admin_logged_in'])) {
//     header("Location: login.php");
//     exit();
// }

$message = '';
$product = null;
$product_id = $_GET['id'] ?? null;

if (!$product_id) {
    header("Location: products.php");
    exit();
}

// Ambil data produk yang akan diedit
$sql = "SELECT * FROM products WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $product = $result->fetch_assoc();
} else {
    header("Location: products.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $image_filename = $product['image']; // Tetap gunakan gambar lama secara default

    // Proses upload gambar baru jika ada
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = '../assets/images/';
        $file_tmp_name = $_FILES['image']['tmp_name'];
        $new_image_filename = uniqid() . '-' . basename($_FILES['image']['name']);
        if (move_uploaded_file($file_tmp_name, $upload_dir . $new_image_filename)) {
            // Hapus gambar lama jika ada
            if ($image_filename && file_exists($upload_dir . $image_filename)) {
                unlink($upload_dir . $image_filename);
            }
            $image_filename = $new_image_filename;
        } else {
            $message = "Gagal mengunggah gambar baru.";
        }
    }

    if (!$message) {
        $sql = "UPDATE products SET name = ?, description = ?, price = ?, image = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssdsi", $name, $description, $price, $image_filename, $product_id);
        if ($stmt->execute()) {
            header("Location: products.php");
            exit();
        } else {
            $message = "Error: " . $stmt->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="d-flex" id="wrapper">
    <div class="bg-dark text-white p-3" id="sidebar-wrapper" style="width: 250px; min-height: 100vh;">
        <div class="sidebar-heading text-center py-4 fs-4 fw-bold text-uppercase border-bottom">Keyboard Admin</div>
        <div class="list-group list-group-flush my-3">
            <a href="dashboard.php" class="list-group-item list-group-item-action bg-transparent text-white">Dashboard</a>
            <a href="products.php" class="list-group-item list-group-item-action bg-transparent text-white active">Produk</a>
            <a href="orders.php" class="list-group-item list-group-item-action bg-transparent text-white">Pesanan</a>
            <a href="rekap-produk.php" class="list-group-item list-group-item-action bg-transparent text-white">Rekap Produk</a>
            <!-- <a href="logout.php" class="list-group-item list-group-item-action bg-transparent text-danger">Logout</a> -->
        </div>
    </div>
    
    <div id="page-content-wrapper" style="width: 100%;">
        <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
            <div class="container-fluid">
                <h2 class="mb-0">Edit Produk</h2>
            </div>
        </nav>

        <div class="container-fluid py-4">
            <?php if ($message): ?>
                <div class="alert alert-danger"><?php echo $message; ?></div>
            <?php endif; ?>
            <form action="edit-product.php?id=<?php echo $product['id']; ?>" method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="name" class="form-label">Nama Produk</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Deskripsi</label>
                    <textarea class="form-control" id="description" name="description" rows="5"><?php echo htmlspecialchars($product['description']); ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Harga</label>
                    <input type="number" class="form-control" id="price" name="price" value="<?php echo htmlspecialchars($product['price']); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">Gambar Produk</label>
                    <?php if ($product['image']): ?>
                        <div class="mb-2">
                            <img src="../assets/images/<?php echo htmlspecialchars($product['image']); ?>" alt="Gambar saat ini" style="width: 150px;">
                            <p class="mt-1"><small class="text-muted">Gambar saat ini.</small></p>
                        </div>
                    <?php endif; ?>
                    <input type="file" class="form-control" id="image" name="image">
                    <small class="form-text text-muted">Kosongkan jika tidak ingin mengubah gambar.</small>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="products.php" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>