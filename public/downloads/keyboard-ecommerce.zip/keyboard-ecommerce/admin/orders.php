<?php
session_start();
include '../config/db.php';
// Cek login admin
// if (!isset($_SESSION['admin_logged_in'])) {
//     header("Location: login.php");
//     exit();
// }

$sql = "SELECT * FROM orders ORDER BY created_at DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pesanan - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        #wrapper {
            display: flex;
        }
        #sidebar-wrapper {
            width: 250px;
            min-height: 100vh;
            margin-left: -250px;
            transition: all 0.3s ease-in-out;
        }
        #page-content-wrapper {
            width: 100%;
        }

        /* Styling responsif untuk layar kecil */
        @media (min-width: 769px) {
            #sidebar-wrapper {
                margin-left: 0;
            }
        }
        #wrapper.toggled #sidebar-wrapper {
            margin-left: 0;
        }
    </style>
</head>
<body>

<div class="d-flex" id="wrapper">
    <div class="bg-dark text-white p-3" id="sidebar-wrapper">
        <div class="sidebar-heading text-center py-4 fs-4 fw-bold text-uppercase border-bottom">Keyboard Admin</div>
        <div class="list-group list-group-flush my-3">
            <a href="dashboard.php" class="list-group-item list-group-item-action bg-transparent text-white">
                <i class="bi bi-speedometer2 me-2"></i>Dashboard
            </a>
            <a href="products.php" class="list-group-item list-group-item-action bg-transparent text-white">
                <i class="bi bi-box me-2"></i>Produk
            </a>
            <a href="orders.php" class="list-group-item list-group-item-action bg-transparent text-white active">
                <i class="bi bi-receipt me-2"></i>Pesanan
            </a>
            <a href="rekap-produk.php" class="list-group-item list-group-item-action bg-transparent text-white">
                <i class="bi bi-graph-up me-2"></i>Rekap Produk
            </a>
            </div>
    </div>
    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
            <div class="container-fluid">
                <button class="btn btn-outline-dark me-2 d-inline d-md-none" id="sidebar-toggle">
                    <i class="bi bi-list"></i>
                </button>
                <h2 class="mb-0">Daftar Pesanan</h2>
            </div>
        </nav>

        <div class="container-fluid py-4">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="card mb-3">
                        <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                            <span>Pesanan #<?php echo $row['id']; ?> | Tanggal: <?php echo date('d M Y H:i', strtotime($row['created_at'])); ?></span>
                            <a href="delete-order.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus pesanan ini? Aksi ini tidak dapat dibatalkan.');">Hapus</a>
                        </div>
                        <div class="card-body">
                            <h5>Informasi Pelanggan</h5>
                            <p><strong>Nama:</strong> <?php echo htmlspecialchars($row['name']); ?><br>
                            <strong>Telepon:</strong> <?php echo htmlspecialchars($row['phone']); ?><br>
                            <strong>Alamat:</strong> <?php echo htmlspecialchars($row['address']); ?><br>
                            <strong>Metode Pembayaran:</strong> <?php echo htmlspecialchars($row['payment_method']); ?></p>
                            
                            <?php if ($row['bukti_transfer']): ?>
                                <p><strong>Bukti Transfer:</strong> <a href="../assets/images/bukti_transfer/<?php echo htmlspecialchars($row['bukti_transfer']); ?>" target="_blank">Lihat Bukti</a></p>
                            <?php endif; ?>

                            <h5 class="mt-4">Item Pesanan</h5>
                            <ul class="list-group">
                                <?php
                                $sql_items = "SELECT oi.quantity, oi.price, p.name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?";
                                $stmt_items = $conn->prepare($sql_items);
                                $stmt_items->bind_param("i", $row['id']);
                                $stmt_items->execute();
                                $result_items = $stmt_items->get_result();
                                $total_order_price = 0;
                                while ($item = $result_items->fetch_assoc()):
                                    $subtotal = $item['quantity'] * $item['price'];
                                    $total_order_price += $subtotal;
                                ?>
                                    <li class="list-group-item d-flex justify-content-between">
                                        <span><?php echo htmlspecialchars($item['name']); ?> (x<?php echo $item['quantity']; ?>)</span>
                                        <span>Rp <?php echo number_format($subtotal, 0, ',', '.'); ?></span>
                                    </li>
                                <?php endwhile; ?>
                                <li class="list-group-item d-flex justify-content-between bg-light fw-bold">
                                    <span>Total:</span>
                                    <span>Rp <?php echo number_format($total_order_price, 0, ',', '.'); ?></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="alert alert-info text-center">Belum ada pesanan yang masuk.</div>
            <?php endif; ?>
        </div>
    </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('sidebar-toggle').addEventListener('click', function() {
        document.getElementById('wrapper').classList.toggle('toggled');
    });
</script>
</body>
</html>