<?php
session_start();
include '../config/db.php';

// Cek login admin
// if (!isset($_SESSION['admin_logged_in'])) {
//     header("Location: login.php");
//     exit();
// }

$order_id = $_GET['id'] ?? null;

if (!$order_id) {
    header("Location: orders.php");
    exit();
}

// 1. Ambil nama file bukti transfer terlebih dahulu
$sql_transfer = "SELECT bukti_transfer FROM orders WHERE id = ?";
$stmt_transfer = $conn->prepare($sql_transfer);
$stmt_transfer->bind_param("i", $order_id);
$stmt_transfer->execute();
$result_transfer = $stmt_transfer->get_result();
$row_transfer = $result_transfer->fetch_assoc();
$bukti_transfer_filename = $row_transfer['bukti_transfer'] ?? null;
$stmt_transfer->close();

// 2. Hapus item pesanan terkait dari tabel order_items
$sql_items = "DELETE FROM order_items WHERE order_id = ?";
$stmt_items = $conn->prepare($sql_items);
$stmt_items->bind_param("i", $order_id);

if ($stmt_items->execute()) {
    $stmt_items->close();

    // 3. Hapus pesanan utama dari tabel orders
    $sql_order = "DELETE FROM orders WHERE id = ?";
    $stmt_order = $conn->prepare($sql_order);
    $stmt_order->bind_param("i", $order_id);

    if ($stmt_order->execute()) {
        $stmt_order->close();
        
        // 4. Hapus file bukti transfer dari server jika ada
        if ($bukti_transfer_filename && file_exists('../assets/images/bukti_transfer/' . $bukti_transfer_filename)) {
            unlink('../assets/images/bukti_transfer/' . $bukti_transfer_filename);
        }

        // Redirect kembali ke halaman daftar pesanan
        header("Location: orders.php");
        exit();
    } else {
        echo "Error: Gagal menghapus pesanan utama. " . $stmt_order->error;
    }
} else {
    echo "Error: Gagal menghapus item pesanan terkait. " . $stmt_items->error;
}
?>