<?php
session_start();
include '../config/db.php';


$product_id = $_GET['id'] ?? null;

if ($product_id) {
    $sql_image = "SELECT image FROM products WHERE id = ?";
    $stmt_image = $conn->prepare($sql_image);
    $stmt_image->bind_param("i", $product_id);
    $stmt_image->execute();
    $result_image = $stmt_image->get_result();
    $row_image = $result_image->fetch_assoc();
    $image_filename = $row_image['image'] ?? null;

    // Hapus produk dari database
    $sql = "DELETE FROM products WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $product_id);
    
    if ($stmt->execute()) {
        // Hapus file gambar dari server
        if ($image_filename && file_exists('../assets/images/' . $image_filename)) {
            unlink('../assets/images/' . $image_filename);
        }
        header("Location: products.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
} else {
    header("Location: products.php");
    exit();
}
?>