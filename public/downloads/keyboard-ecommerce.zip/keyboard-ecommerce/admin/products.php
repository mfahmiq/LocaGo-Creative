<?php
session_start();
include '../config/db.php';
// Cek login admin
// if (!isset($_SESSION['admin_logged_in'])) {
//     header("Location: login.php");
//     exit();
// }

$sql = "SELECT * FROM products ORDER BY id DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Produk - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        #wrapper {
            display: flex;
        }
        #sidebar-wrapper {
            width: 250px;
            min-height: 100vh;
            margin-left: -250px;
            transition: all 0.3s ease-in-out;
        }
        #page-content-wrapper {
            width: 100%;
        }

        /* Styling responsif untuk layar kecil */
        @media (min-width: 769px) {
            #sidebar-wrapper {
                margin-left: 0;
            }
        }
        #wrapper.toggled #sidebar-wrapper {
            margin-left: 0;
        }
    </style>
</head>
<body>

<div class="d-flex" id="wrapper">
    <div class="bg-dark text-white p-3" id="sidebar-wrapper">
        <div class="sidebar-heading text-center py-4 fs-4 fw-bold text-uppercase border-bottom">Keyboard Admin</div>
        <div class="list-group list-group-flush my-3">
            <a href="dashboard.php" class="list-group-item list-group-item-action bg-transparent text-white">
                <i class="bi bi-speedometer2 me-2"></i>Dashboard
            </a>
            <a href="products.php" class="list-group-item list-group-item-action bg-transparent text-white active">
                <i class="bi bi-box me-2"></i>Produk
            </a>
            <a href="orders.php" class="list-group-item list-group-item-action bg-transparent text-white">
                <i class="bi bi-receipt me-2"></i>Pesanan
            </a>
            <a href="rekap-produk.php" class="list-group-item list-group-item-action bg-transparent text-white">
                <i class="bi bi-graph-up me-2"></i>Rekap Produk
            </a>
            </div>
    </div>
    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
            <div class="container-fluid">
                <button class="btn btn-outline-dark me-2 d-inline d-md-none" id="sidebar-toggle">
                    <i class="bi bi-list"></i>
                </button>
                <h2 class="mb-0">Daftar Produk</h2>
                <a href="add-product.php" class="btn btn-primary">Tambah Produk Baru</a>
            </div>
        </nav>

        <div class="container-fluid py-4">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th class="text-nowrap">ID</th>
                            <th class="text-nowrap">Gambar</th>
                            <th class="text-nowrap">Nama</th>
                            <th class="text-nowrap">Harga</th>
                            <th class="text-nowrap">Deskripsi</th>
                            <th class="text-nowrap">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><img src="../assets/images/<?php echo htmlspecialchars($row['image']); ?>" alt="" style="width: 100px;"></td>
                                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td>Rp <?php echo number_format($row['price'], 0, ',', '.'); ?></td>
                                    <td><?php echo htmlspecialchars(substr($row['description'], 0, 50)); ?>...</td>
                                    <td>
                                        <div class="d-flex gap-2 flex-nowrap">
                                            <a href="edit-product.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                                            <a href="delete-product.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus produk ini?');">Hapus</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center">Belum ada produk.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('sidebar-toggle').addEventListener('click', function() {
        document.getElementById('wrapper').classList.toggle('toggled');
    });
</script>
</body>
</html>