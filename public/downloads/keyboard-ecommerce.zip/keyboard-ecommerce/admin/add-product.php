<?php
session_start();
include '../config/db.php';
// Cek login admin
// if (!isset($_SESSION['admin_logged_in'])) {
//     header("Location: login.php");
//     exit();
// }

$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    // Proses upload gambar
    $image_filename = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = '../assets/images/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        $file_tmp_name = $_FILES['image']['tmp_name'];
        $image_filename = uniqid() . '-' . basename($_FILES['image']['name']);
        if (!move_uploaded_file($file_tmp_name, $upload_dir . $image_filename)) {
            $message = "Gagal mengunggah gambar.";
        }
    }

    if (!$message) {
        $sql = "INSERT INTO products (name, description, price, image) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssds", $name, $description, $price, $image_filename);
        if ($stmt->execute()) {
            header("Location: products.php");
            exit();
        } else {
            $message = "Error: " . $stmt->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        #wrapper {
            display: flex;
        }
        #sidebar-wrapper {
            width: 250px;
            min-height: 100vh;
            margin-left: -250px;
            transition: all 0.3s ease-in-out;
        }
        #page-content-wrapper {
            width: 100%;
        }

        /* Styling responsif untuk layar kecil */
        @media (min-width: 769px) {
            #sidebar-wrapper {
                margin-left: 0;
            }
        }
        #wrapper.toggled #sidebar-wrapper {
            margin-left: 0;
        }
    </style>
</head>
<body>

<div class="d-flex" id="wrapper">
    <div class="bg-dark text-white p-3" id="sidebar-wrapper">
        <div class="sidebar-heading text-center py-4 fs-4 fw-bold text-uppercase border-bottom">Keyboard Admin</div>
        <div class="list-group list-group-flush my-3">
            <a href="dashboard.php" class="list-group-item list-group-item-action bg-transparent text-white">
                <i class="bi bi-speedometer2 me-2"></i>Dashboard
            </a>
            <a href="products.php" class="list-group-item list-group-item-action bg-transparent text-white active">
                <i class="bi bi-box me-2"></i>Produk
            </a>
            <a href="orders.php" class="list-group-item list-group-item-action bg-transparent text-white">
                <i class="bi bi-receipt me-2"></i>Pesanan
            </a>
            <a href="rekap-produk.php" class="list-group-item list-group-item-action bg-transparent text-white">
                <i class="bi bi-graph-up me-2"></i>Rekap Produk
            </a>
            </div>
    </div>
    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
            <div class="container-fluid">
                <button class="btn btn-outline-dark me-2 d-inline d-md-none" id="sidebar-toggle">
                    <i class="bi bi-list"></i>
                </button>
                <h2 class="mb-0">Tambah Produk</h2>
            </div>
        </nav>

        <div class="container-fluid py-4">
            <?php if ($message): ?>
                <div class="alert alert-danger"><?php echo $message; ?></div>
            <?php endif; ?>
            <form action="add-product.php" method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="name" class="form-label">Nama Produk</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Deskripsi</label>
                    <textarea class="form-control" id="description" name="description" rows="5"></textarea>
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Harga</label>
                    <input type="number" class="form-control" id="price" name="price" required>
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">Gambar Produk</label>
                    <input type="file" class="form-control" id="image" name="image" required>
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="products.php" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('sidebar-toggle').addEventListener('click', function() {
        document.getElementById('wrapper').classList.toggle('toggled');
    });
</script>
</body>
</html>