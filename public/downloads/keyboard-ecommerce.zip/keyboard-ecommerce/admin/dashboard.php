<?php
session_start();
include '../config/db.php';
// Cek jika admin belum login
// if (!isset($_SESSION['admin_logged_in'])) {
//     header("Location: login.php");
//     exit();
// }

$total_products = $conn->query("SELECT COUNT(*) AS total FROM products")->fetch_assoc()['total'];
$total_orders = $conn->query("SELECT COUNT(*) AS total FROM orders")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        #wrapper {
            display: flex;
        }
        #sidebar-wrapper {
            width: 250px;
            min-height: 100vh;
            margin-left: -250px;
            transition: all 0.3s ease-in-out;
        }
        #page-content-wrapper {
            width: 100%;
        }

        /* Styling responsif untuk layar kecil */
        @media (min-width: 769px) {
            #sidebar-wrapper {
                margin-left: 0;
            }
        }
        #wrapper.toggled #sidebar-wrapper {
            margin-left: 0;
        }
    </style>
</head>
<body>

<div class="d-flex" id="wrapper">
    <div class="bg-dark text-white p-3" id="sidebar-wrapper">
        <div class="sidebar-heading text-center py-4 fs-4 fw-bold text-uppercase border-bottom">Keyboard Admin</div>
        <div class="list-group list-group-flush my-3">
            <a href="dashboard.php" class="list-group-item list-group-item-action bg-transparent text-white active">
                <i class="bi bi-speedometer2 me-2"></i>Dashboard
            </a>
            <a href="products.php" class="list-group-item list-group-item-action bg-transparent text-white">
                <i class="bi bi-box me-2"></i>Produk
            </a>
            <a href="orders.php" class="list-group-item list-group-item-action bg-transparent text-white">
                <i class="bi bi-receipt me-2"></i>Pesanan
            </a>
            <a href="rekap-produk.php" class="list-group-item list-group-item-action bg-transparent text-white">
                <i class="bi bi-graph-up me-2"></i>Rekap Produk
            </a>
            </div>
    </div>
    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
            <div class="container-fluid">
                <button class="btn btn-outline-dark me-2 d-inline d-md-none" id="sidebar-toggle">
                    <i class="bi bi-list"></i>
                </button>
                <h2 class="mb-0">Dashboard</h2>
            </div>
        </nav>

        <div class="container-fluid py-4">
            <div class="row g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="card bg-primary text-white h-100">
                        <div class="card-body">
                            <div class="fs-5 fw-bold">Total Produk</div>
                            <div class="display-4 fw-bold"><?php echo $total_products; ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card bg-success text-white h-100">
                        <div class="card-body">
                            <div class="fs-5 fw-bold">Total Pesanan</div>
                            <div class="display-4 fw-bold"><?php echo $total_orders; ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('sidebar-toggle').addEventListener('click', function() {
        document.getElementById('wrapper').classList.toggle('toggled');
    });
</script>
</body>
</html>