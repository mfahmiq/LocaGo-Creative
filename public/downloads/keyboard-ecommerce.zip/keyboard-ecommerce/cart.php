<?php
session_start();
include 'config/db.php';
include 'includes/header.php';
include 'includes/navbar.php';

$cart = $_SESSION['cart'] ?? [];
$total_price = 0;
?>

<div class="container mt-5">
    <h1 class="mb-4">Keranjang Belanja</h1>
    <?php if (empty($cart)): ?>
        <div class="alert alert-info" role="alert">
            Keranjang belanja Anda masih kosong.
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-bordered align-middle">
                <thead>
                    <tr>
                        <th class="text-nowrap">Produk</th>
                        <th class="text-nowrap">Harga</th>
                        <th class="text-center text-nowrap">Jumlah</th>
                        <th class="text-nowrap">Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cart as $item): ?>
                        <tr>
                            <td>
                                <img src="assets/images/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" style="width: 50px;" class="me-2 d-none d-md-inline-block">
                                <?php echo htmlspecialchars($item['name']); ?>
                            </td>
                            <td>Rp <?php echo number_format($item['price'], 0, ',', '.'); ?></td>
                            <td class="text-center"><?php echo $item['quantity']; ?></td>
                            <td>Rp <?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?></td>
                        
                        </tr>
                        <?php $total_price += $item['price'] * $item['quantity']; ?>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="3" class="text-end">Total Harga:</th>
                        <th colspan="2">Rp <?php echo number_format($total_price, 0, ',', '.'); ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
        <div class="d-flex justify-content-end mt-4">
            <a href="index.php" class="btn btn-secondary btn-lg">Lanjut Belanja</a>
            <a href="checkout.php" class="btn btn-success btn-lg ms-2">Lanjut ke Checkout</a>
        </div>
    <?php endif; ?>
</div>

<?php
include 'includes/footer.php';
?>