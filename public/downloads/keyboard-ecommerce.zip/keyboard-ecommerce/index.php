<?php
session_start();
include 'config/db.php';
include 'includes/header.php';
include 'includes/navbar.php';

// Ambil data produk dari database
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>

<div id="carouselExampleIndicators" class="carousel slide mt-5 pt-3" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="3" aria-label="Slide 4"></button>
        <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="4" aria-label="Slide 5"></button>
    </div>
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="assets/images/header/1.jpeg" class="d-block w-100" alt="Banner 1">
        </div>
        <div class="carousel-item">
            <img src="assets/images/header/2.jpeg" class="d-block w-100" alt="Banner 2">
        </div>
        <div class="carousel-item">
            <img src="assets/images/header/3.jpeg" class="d-block w-100" alt="Banner 3">
        </div>
        <div class="carousel-item">
            <img src="assets/images/header/4.jpeg" class="d-block w-100" alt="Banner 4">
        </div>
        <div class="carousel-item">
            <img src="assets/images/header/5.jpeg" class="d-block w-100" alt="Banner 5">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
<div class="container my-5 pt-3">
    <h1 class="text-center mb-4">Produk Unggulan</h1>
    <div class="row">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <img src="assets/images/<?php echo htmlspecialchars($row['image']); ?>" class="card-img-top fixed-image" alt="<?php echo htmlspecialchars($row['name']); ?>">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?php echo htmlspecialchars($row['name']); ?></h5>
                            <p class="card-text text-muted"><?php echo htmlspecialchars(substr($row['description'], 0, 100)); ?>...</p>
                            <h4 class="mt-auto">Rp <?php echo number_format($row['price'], 0, ',', '.'); ?></h4>
                            
                            <form action="controllers/cartController.php" method="POST" class="d-flex justify-content-between align-items-center mt-2" data-id="<?php echo $row['id']; ?>">
                                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                <div class="input-group">
                                    <button type="button" class="btn btn-outline-secondary btn-minus">-</button>
                                    <input type="number" name="quantity" class="form-control text-center" value="0" min="0" readonly>
                                    <button type="button" class="btn btn-outline-secondary btn-plus">+</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <p class="text-center">Belum ada produk yang tersedia.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<div id="cart-summary-floating" class="fixed-bottom bg-white shadow-lg p-3 d-flex justify-content-between align-items-center d-none">
    <div>
        <h5 class="mb-0">Total Harga: <span id="cart-total-price">Rp 0</span></h5>
    </div>
    <a href="checkout.php" class="btn btn-success btn-lg">Lanjut ke Checkout</a>
</div>

<?php
include 'includes/footer.php';
$conn->close();
?>