<?php
$host     = 'localhost';
$username = 'root';      
$password = '';           
$database = 'ecomm_keyboard';

$conn = new mysqli($host, $username, $password, $database);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}
?>
