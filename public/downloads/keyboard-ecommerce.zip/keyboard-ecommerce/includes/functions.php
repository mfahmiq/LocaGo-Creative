function getAllProducts($conn) {
  $sql = "SELECT * FROM produk ORDER BY id DESC";
  $result = mysqli_query($conn, $sql);
  $data = [];
  while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
  }
  return $data;
}
