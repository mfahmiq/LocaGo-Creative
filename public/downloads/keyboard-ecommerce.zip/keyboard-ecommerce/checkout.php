<?php
session_start();
include 'config/db.php';
include 'includes/header.php';
include 'includes/navbar.php';

$cart = $_SESSION['cart'] ?? [];

if (empty($cart)) {
    header("Location: cart.php");
    exit();
}

$total_price = 0;
foreach ($cart as $item) {
    $total_price += $item['price'] * $item['quantity'];
}
?>

<div class="container my-5">
    <h1 class="mb-4">Checkout</h1>
    <div class="row">
        <div class="col-md-5 mt-4 mt-md-0">
            <h4>Ringkasan Pesanan</h4>
            <hr>
            <ul class="list-group mb-3">
                <?php foreach ($cart as $item): ?>
                    <li class="list-group-item d-flex justify-content-between lh-sm">
                        <div>
                            <h6 class="my-0"><?php echo htmlspecialchars($item['name']); ?></h6>
                            <small class="text-muted">Jumlah: <?php echo $item['quantity']; ?></small>
                        </div>
                        <span class="text-muted">Rp <?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?></span>
                    </li>
                <?php endforeach; ?>
                <li class="list-group-item d-flex justify-content-between bg-light">
                    <span class="text-success">Total (IDR)</span>
                    <strong>Rp <?php echo number_format($total_price, 0, ',', '.'); ?></strong>
                </li>
            </ul>
        </div>
        <div class="col-md-7">
            <h4>Informasi Pengiriman</h4>
            <hr>
            <form id="checkoutForm" action="controllers/orderController.php" method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="name" class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label">Nomor Telepon</label>
                    <input type="tel" class="form-control" id="phone" name="phone" required>
                </div>
                <div class="mb-3">
                    <label for="address" class="form-label">Alamat Lengkap</label>
                    <textarea class="form-control" id="address" name="address" rows="3" required></textarea>
                </div>
                <div class="mb-3">
                    <label for="payment_method" class="form-label">Metode Pembayaran</label>
                    <select class="form-select" id="payment_method" name="payment_method" required>
                        <option value="">Pilih Metode Pembayaran</option>
                        <option value="Transfer Bank">Transfer Bank</option>
                        <option value="COD">Cash on Delivery (COD)</option>
                    </select>
                </div>
                
                <div id="buktiTransferField" class="mb-3" style="display: none;">
                    <label for="bukti_transfer" class="form-label">Upload Bukti Transfer</label>
                    <input type="file" class="form-control" id="bukti_transfer" name="bukti_transfer">
                    <small class="form-text text-muted">Silakan unggah bukti transfer Anda untuk verifikasi pesanan.</small>
                </div>

                <input type="hidden" name="action" value="place_order">

                <div class="d-grid gap-2">
    <button type="button" class="btn btn-success btn-lg mt-3" id="completeOrderBtn">Selesaikan Pesanan</button>
</div>

<div class="offcanvas offcanvas-bottom rounded-top" tabindex="-1" id="confirmOffcanvas" aria-labelledby="confirmOffcanvasLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="confirmOffcanvasLabel">Konfirmasi Pesanan</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body small">
    <p>Apakah Anda yakin ingin menyelesaikan pesanan ini? Pastikan semua data sudah benar.</p>
    <div class="alert alert-info text-center" role="alert">
        Total yang harus dibayar adalah <strong>Rp <?php echo number_format($total_price, 0, ',', '.'); ?></strong>.
    </div>
  </div>
  <div class="offcanvas-footer p-3 border-top">
    <div class="d-flex justify-content-between">
      <button type="button" class="btn btn-secondary w-50 me-2" data-bs-dismiss="offcanvas">Kembali</button>
      <button type="submit" form="checkoutForm" class="btn btn-success w-50">Ya, Selesaikan Pesanan</button>
    </div>
  </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // ... (Logika untuk payment method yang sudah ada) ...
        const paymentMethod = document.getElementById('payment_method');
        const buktiTransferField = document.getElementById('buktiTransferField');
        const buktiTransferInput = document.getElementById('bukti_transfer');

        paymentMethod.addEventListener('change', function() {
            if (this.value === 'Transfer Bank') {
                buktiTransferField.style.display = 'block';
                buktiTransferInput.setAttribute('required', 'required');
            } else {
                buktiTransferField.style.display = 'none';
                buktiTransferInput.removeAttribute('required');
            }
        });


        // Logika baru untuk validasi form sebelum membuka offcanvas
        const completeOrderBtn = document.getElementById('completeOrderBtn');
        const checkoutForm = document.getElementById('checkoutForm');
        const confirmOffcanvas = new bootstrap.Offcanvas(document.getElementById('confirmOffcanvas'));

        completeOrderBtn.addEventListener('click', function() {
            if (checkoutForm.checkValidity()) {
                // Jika form valid, buka offcanvas
                confirmOffcanvas.show();
            } else {
                // Jika tidak valid, pemicu validasi bawaan HTML5
                checkoutForm.reportValidity();
            }
        });
    });
</script>

<?php
include 'includes/footer.php';
?>