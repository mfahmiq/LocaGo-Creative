<?php
session_start();
include '../config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST['action'] == 'place_order') {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $payment_method = $_POST['payment_method'];
    $cart = $_SESSION['cart'] ?? [];

    if (empty($cart)) {
        header("Location: ../cart.php");
        exit();
    }

    // Masukkan data pesanan ke tabel 'orders'
    $sql = "INSERT INTO orders (name, phone, address, payment_method) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $name, $phone, $address, $payment_method);

    if ($stmt->execute()) {
        $order_id = $stmt->insert_id;

        // Masukkan item pesanan ke tabel 'order_items'
        $sql_item = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
        $stmt_item = $conn->prepare($sql_item);

        foreach ($cart as $item) {
            $product_id = $item['id'];
            $quantity = $item['quantity'];
            $price = $item['price'];
            $stmt_item->bind_param("iiii", $order_id, $product_id, $quantity, $price);
            $stmt_item->execute();
        }

        // Kosongkan keranjang setelah pesanan berhasil
        unset($_SESSION['cart']);

        // Redirect ke halaman konfirmasi
        header("Location: ../thank-you.php?order_id=$order_id");
        exit();
    } else {
        // Jika ada error
        echo "Error: " . $stmt->error;
        // Redirect ke halaman error atau kembali ke checkout
    }
}
?>