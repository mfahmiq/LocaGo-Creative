<?php
session_start();

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// ... kode sebelumnya ...

// Tambahkan logika untuk menangani AJAX
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['action']) && $_GET['action'] == 'get_cart') {
    // Mengembalikan data keranjang dalam format JSON
    header('Content-Type: application/json');
    echo json_encode($_SESSION['cart']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'update_quantity') {
    $id = $_POST['id'] ?? null;
    $quantity = intval($_POST['quantity'] ?? 0);
    
    include '../config/db.php';
    
    $response = ['status' => 'error', 'message' => 'Invalid request'];

    if ($id) {
        $sql = "SELECT * FROM products WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $product = $result->fetch_assoc();

        if ($product) {
            if ($quantity > 0) {
                $product['quantity'] = $quantity;
                $_SESSION['cart'][$id] = $product;
            } else {
                unset($_SESSION['cart'][$id]);
            }
            $response = ['status' => 'success', 'cart' => $_SESSION['cart']];
        } else {
            $response['message'] = 'Product not found';
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Tambahkan juga penanganan untuk action 'add'
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    // ... logika yang sudah ada untuk menambahkan ke keranjang ...
    // Note: Logika ini mungkin tidak lagi digunakan karena kita memakai 'update_quantity' dengan AJAX
    // Anda bisa menghapusnya jika sudah tidak dipakai atau menyesuaikannya.
}

// ... redirect ke halaman lain jika tidak ada aksi yang valid ...
?>