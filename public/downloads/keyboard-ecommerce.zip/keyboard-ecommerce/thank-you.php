<?php
session_start();
include 'config/db.php';
include 'includes/header.php';
include 'includes/navbar.php';

$order_id = $_GET['order_id'] ?? null;

if (!$order_id) {
    header("Location: index.php");
    exit();
}
?>

<div class="container my-5 text-center">
    <div class="alert alert-success" role="alert">
        <h4 class="alert-heading">Terima kasih atas pesanan Anda!</h4>
        <p>Pesanan Anda dengan nomor **#<?php echo htmlspecialchars($order_id); ?>** telah berhasil kami terima. Kami akan segera memprosesnya.</p>
        <hr>
        <p class="mb-0">Informasi lebih lanjut akan kami kirimkan melalui email atau nomor telepon Anda.</p>
    </div>
    <a href="index.php" class="btn btn-primary mt-4">Kembali ke Beranda</a>
</div>

<?php
include 'includes/footer.php';
?>