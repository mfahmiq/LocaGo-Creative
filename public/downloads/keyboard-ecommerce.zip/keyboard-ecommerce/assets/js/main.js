document.addEventListener('DOMContentLoaded', function() {
    const cards = document.querySelectorAll('.card');
    const floatingCart = document.getElementById('cart-summary-floating');
    const cartTotalPrice = document.getElementById('cart-total-price');
    let cart = {};

    // Fungsi untuk memperbarui tampilan keranjang
    function updateCartUI() {
        let total = 0;
        let totalItems = 0;
        for (const id in cart) {
            total += cart[id].price * cart[id].quantity;
            totalItems += cart[id].quantity;
        }

        cartTotalPrice.textContent = `Rp ${total.toLocaleString('id-ID')}`;
        
        if (totalItems > 0) {
            floatingCart.classList.remove('d-none');
            document.body.classList.add('body-with-cart-open');
        } else {
            floatingCart.classList.add('d-none');
            document.body.classList.remove('body-with-cart-open');
        }
    }
    
    // Inisialisasi keranjang saat halaman dimuat
    // Menggunakan AJAX untuk mengambil data keranjang dari server
    fetch('controllers/cartController.php?action=get_cart')
    .then(response => response.json())
    .then(data => {
        cart = data;
        updateCartUI();
        
        cards.forEach(card => {
            const form = card.querySelector('form');
            const id = form.dataset.id;
            const quantityInput = form.querySelector('input[name="quantity"]');
            
            if (cart[id]) {
                quantityInput.value = cart[id].quantity;
            }
        });
    });

    cards.forEach(card => {
        const btnMinus = card.querySelector('.btn-minus');
        const btnPlus = card.querySelector('.btn-plus');
        const quantityInput = card.querySelector('input[name="quantity"]');
        const form = card.querySelector('form');
        const id = form.dataset.id;

        btnPlus.addEventListener('click', function() {
            let currentValue = parseInt(quantityInput.value);
            quantityInput.value = currentValue + 1;
            updateCartItem(id, quantityInput.value);
        });

        btnMinus.addEventListener('click', function() {
            let currentValue = parseInt(quantityInput.value);
            if (currentValue > 0) {
                quantityInput.value = currentValue - 1;
                updateCartItem(id, quantityInput.value);
            }
        });
    });
    
    // Fungsi untuk mengirim update ke server via AJAX
     // Fungsi untuk mengirim update ke server via AJAX
    function updateCartItem(id, quantity) {
        const formData = new FormData();
        formData.append('id', id);
        formData.append('quantity', quantity);
        formData.append('action', 'update_quantity');

        fetch('controllers/cartController.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                cart = data.cart;
                updateCartUI(); // Panggil fungsi ini setelah berhasil
            } else {
                alert('Gagal memperbarui keranjang.');
            }
        });
    }
});