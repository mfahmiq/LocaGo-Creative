<?php
session_start();

// Database Connection
$conn = new mysqli('localhost', 'root', 'Prarthana@37', 'hospital_db');
if ($conn->connect_error) {
    die("Database Connection Failed!");
}

$message = "";

// Secret registration code (set by developer, known only to hospital management)
$secret_code = "Hospital@27673@Available:):)";  

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = trim($_POST['password'] ?? '');
    $confirm = trim($_POST['confirm_password'] ?? '');
    $code = trim($_POST['reg_code'] ?? '');

    if ($user === '' || $pass === '' || $confirm === '' || $code === '') {
        $message = "⚠ Please fill all fields.";
    } elseif ($pass !== $confirm) {
        $message = "❌ Passwords do not match.";
    } elseif ($code !== $secret_code) {
        $message = "❌ Invalid registration code. Only hospital management can register.";
    } else {
        // Check if username already exists
        $stmt = $conn->prepare("SELECT id FROM admins WHERE username = ? LIMIT 1");
        $stmt->bind_param("s", $user);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $message = "⚠ Username already exists.";
        } else {
            // Insert new admin (plain text password for now)
            $stmt = $conn->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $user, $pass);
            if ($stmt->execute()) {
                $message = "✅ Admin registered successfully! You can now log in.";
            } else {
                $message = "❌ Registration failed.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Registration - Heart Beat Hospital</title>
    <style>
        body {
            margin: 0; padding: 0;
            font-family: Arial, Helvetica, sans-serif;
            background-image: url('https://www.medishinehealth.com/v1/key-images/Best-Cardiology-Heart-Hospital.png');
            background-size: cover; background-repeat: no-repeat; background-attachment: fixed;
        }
        body::before {
            content: ""; position: fixed; top:0; left:0;
            width:100%; height:100%;
            background: rgba(0, 40, 85, 0.6);
            backdrop-filter: blur(3px);
            z-index:-1;
        }
        .register-box {
            width: 400px; background: rgba(255,255,255,0.15);
            backdrop-filter: blur(7px); padding: 35px;
            border-radius: 20px; margin: 100px auto;
            box-shadow: 0 0 25px rgba(0,0,0,0.5);
            border: 1px solid rgba(255,255,255,0.3);
            text-align: center; color: white;
        }
        .register-box h2 { font-size: 32px; margin-bottom: 10px; color: #daf6ff; text-shadow: 0 0 5px black; }
        .register-box input { width: 90%; padding: 12px; margin: 12px 0; border-radius: 10px; border: none; font-size: 17px; background: rgba(255,255,255,0.7); }
        .register-box button { width: 95%; padding: 12px; margin-top: 10px; border-radius: 10px; border: none; background: #0abde3; color: black; font-size: 20px; font-weight: bold; cursor: pointer; transition: 0.3s; }
        .register-box button:hover { background: #74b9ff; box-shadow: 0 0 15px #74b9ff; }
        .error-box { background: rgba(255,0,0,0.3); padding: 10px; border-radius: 8px; margin-bottom: 10px; border: 1px solid red; font-size: 16px; }
        .success-box { background: rgba(0,255,0,0.3); padding: 10px; border-radius: 8px; margin-bottom: 10px; border: 1px solid green; font-size: 16px; }
        .footer { text-align:center; margin-top: 40px; color: white; font-size: 14px; }
    </style>
</head>
<body>
    <div class="register-box">
        <h2>Admin Registration</h2>
        <?php if ($message): ?>
            <div class="<?php echo strpos($message,'✅')!==false ? 'success-box' : 'error-box'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Enter Username" required />
            <input type="password" name="password" placeholder="Enter Password" required />
            <input type="password" name="confirm_password" placeholder="Confirm Password" required />
            <input type="text" name="reg_code" placeholder="Enter Registration Code" required />
            <button type="submit">Register</button>
        </form>
    </div>
    <div class="footer">
        © 2025 Heart Beat Hospital — Admin Portal
    </div>
</body>
</html>
