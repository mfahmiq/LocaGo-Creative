<?php
$conn = new mysqli('localhost','root','Prarthana@37','hospital_db');

if($conn->connect_error){
    die("Database Connection Failed");
}

$doctors = $conn->query("SELECT id,name,department FROM doctors");
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<title>Book Appointment - Heart Beat Hospital</title>


<style>

*{
    box-sizing:border-box;
}


body{

    margin:0;
    padding:0;

    font-family:Arial, Helvetica, sans-serif;

    background-image:url('https://www.medishinehealth.com/v1/key-images/Best-Cardiology-Heart-Hospital.png');

    background-size:cover;

    background-repeat:no-repeat;

    background-attachment:fixed;

}



/* Overlay */

body::before{

    content:"";

    position:fixed;

    top:0;
    left:0;

    width:100%;
    height:100%;

    background:rgba(0,40,85,0.65);

    backdrop-filter:blur(3px);

    z-index:-1;

}



/* Appointment Box */

.container{

    width:500px;

    margin:70px auto;

    padding:35px;


    background:rgba(255,255,255,0.15);

    backdrop-filter:blur(8px);


    border-radius:20px;


    border:1px solid rgba(255,255,255,0.3);


    box-shadow:0 0 30px rgba(0,0,0,0.5);


    color:white;

}



/* Heading */

.container h2{

    text-align:center;

    font-size:34px;

    color:#daf6ff;

    margin-bottom:10px;

    text-shadow:0 0 8px black;

}


.hospital-name{

    text-align:center;

    color:#00cec9;

    font-size:20px;

    margin-bottom:25px;

}



/* Form */

.form-row{

    margin-bottom:20px;

}



label{

    display:block;

    font-size:17px;

    font-weight:bold;

    margin-bottom:8px;

}



input,
select{


    width:100%;


    padding:13px;


    border:none;


    border-radius:12px;


    font-size:16px;


    background:rgba(255,255,255,0.75);


}



input:focus,
select:focus{

    outline:none;

    box-shadow:0 0 10px #00cec9;

}



/* Button */

input[type="submit"]{


    margin-top:10px;


    background:#0abde3;


    color:black;


    font-size:20px;


    font-weight:bold;


    cursor:pointer;


    transition:0.3s;


}



input[type="submit"]:hover{


    background:#74b9ff;


    box-shadow:0 0 20px #74b9ff;


}



/* Back link */

.back{


    text-align:center;

    margin-top:20px;

}



.back a{

    color:#daf6ff;

    text-decoration:none;

    font-size:16px;

}


.back a:hover{

    color:#00cec9;

}



.footer{

    text-align:center;

    color:white;

    font-size:14px;

}


</style>


</head>


<body>


<div class="container">


<div class="hospital-name">
❤️ Heart Beat Hospital
</div>


<h2>
Book Appointment
</h2>



<form action="save_appointment.php" method="post">


<div class="form-row">

<label>
Patient Name
</label>

<input type="text"
name="patient_name"
placeholder="Enter patient name"
required>

</div>




<div class="form-row">

<label>
Choose Doctor
</label>


<select name="doctor_id" required>


<option value="">
-- Select Doctor --
</option>


<?php

while($d=$doctors->fetch_assoc()){

echo "<option value='".$d['id']."'>
".$d['name']." (".$d['department'].")
</option>";

}

?>


</select>


</div>





<div class="form-row">

<label>
Appointment Date
</label>


<input type="date"
name="appointment_date"
required>


</div>






<div class="form-row">

<label>
Appointment Time
</label>


<input type="time"
name="appointment_time"
required>


</div>





<input type="submit" value="🩺 Book Appointment">


</form>



<div class="back">

<a href="index.php">
⬅ Back to Home
</a>

</div>


</div>



<div class="footer">

© 2025 Heart Beat Hospital — Patient Portal

</div>



</body>

</html>