<?php
// save_doctor.php
session_start();

// Optional: check admin is logged in
// if (!isset($_SESSION['admins'])) { header('Location: admin_login.php'); exit; }

// DB config - adjust if needed
$dbHost = "localhost";
$dbUser = "root";
$dbPass = "Prarthana@37";          // your MySQL password if any
$dbName = "hospital_db";

$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
if ($conn->connect_error) {
    die("DB_ERROR: " . $conn->connect_error);
}

// Helper to clean input
function clean($v) {
    return trim(htmlspecialchars($v, ENT_QUOTES));
}

// Collect and validate fields
$name       = clean($_POST['name'] ?? '');
$experience = clean($_POST['experience'] ?? '');
$department = clean($_POST['department'] ?? '');
$education  = clean($_POST['education'] ?? '');
$phone      = clean($_POST['phone'] ?? '');
$regno      = clean($_POST['regno'] ?? '');

$errors = [];

// basic validations
if ($name === '') $errors[] = "Doctor name is required.";
if ($department === '') $errors[] = "Department is required.";
if ($phone !== '' && !preg_match('/^[0-9+\-\s]{7,20}$/', $phone)) $errors[] = "Invalid phone number.";

// FILE upload handling
if (!isset($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
    $errors[] = "Please upload a photo.";
} else {
    $f = $_FILES['photo'];
    $maxSize = 2 * 1024 * 1024; // 2 MB
    if ($f['size'] > $maxSize) $errors[] = "Photo must be <= 2MB.";

    // check mime type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $f['tmp_name']);
    finfo_close($finfo);
    $allowed = ['image/jpeg','image/png','image/webp'];
    if (!in_array($mime, $allowed)) $errors[] = "Only JPG, PNG or WEBP images allowed.";
}

// If validation failed: show errors and stop
if (!empty($errors)) {
    echo "<h3>Errors:</h3><ul>";
    foreach ($errors as $e) echo "<li>" . htmlspecialchars($e) . "</li>";
    echo "</ul><p><a href='add_doctor.php'>Go Back</a></p>";
    exit;
}

// Prepare unique filename
$ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
$unique = time() . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
$destFolder = __DIR__ . '/uploads/';
if (!is_dir($destFolder)) mkdir($destFolder, 0755, true);
$destPath = $destFolder . $unique;

// Move uploaded file
if (!move_uploaded_file($_FILES['photo']['tmp_name'], $destPath)) {
    die("Failed to move uploaded file.");
}

// Insert into DB with prepared statement
$stmt = $conn->prepare("INSERT INTO doctors (name, experience, department, education, phone, regno, photo) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssss", $name, $experience, $department, $education, $phone, $regno, $unique);

if ($stmt->execute()) {
    // success: redirect to list
    header("Location: doctors_list.php?added=1");
    exit;
} else {
    echo "DB Error: " . $stmt->error;
}
