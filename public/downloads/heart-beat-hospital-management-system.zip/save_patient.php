<?php

session_start();

if(!isset($_SESSION['admins'])){
    header("Location: admin_login.php");
    exit();
}

$conn=new mysqli("localhost","root","Prarthana@37","hospital_db");

if($conn->connect_error){
    die("Connection Failed");
}

$name=trim($_POST['name']);
$age=(int)$_POST['age'];
$gender=$_POST['gender'];
$disease=trim($_POST['disease']);
$doctor_id=(int)$_POST['doctor_id'];
$admit_date=$_POST['admit_date'];

$stmt=$conn->prepare("INSERT INTO patients(name,age,gender,disease,doctor_id,admit_date)
VALUES(?,?,?,?,?,?)");

$stmt->bind_param(
"sissis",
$name,
$age,
$gender,
$disease,
$doctor_id,
$admit_date
);

if($stmt->execute()){
?>
<script>
alert("Patient Added Successfully");
window.location="dashboard.php";
</script>
<?php
}
else{
echo "Error : ".$stmt->error;
}

$stmt->close();
$conn->close();

?>