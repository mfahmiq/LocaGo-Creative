<?php
// add_doctor.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Doctor</title>

    <!-- BOOTSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f5f9ff;
            font-family: 'Segoe UI', sans-serif;
        }

        .form-container {
            max-width: 650px;
            margin: 40px auto;
            background: white;
            padding: 35px;
            border-radius: 18px;
            box-shadow: 0 4px 25px rgba(0,0,0,0.1);
        }

        .heading-title {
            text-align: center;
            font-weight: 700;
            margin-bottom: 25px;
            color: #2a4d69;
        }

        .btn-submit {
            width: 100%;
            background: #2a4d69;
            color: white;
            font-weight: 600;
            padding: 10px;
            border-radius: 8px;
        }

        .btn-submit:hover {
            background: #163853;
        }
    </style>
</head>

<body>

<div class="form-container">
    <h2 class="heading-title">Add New Doctor</h2>

    <form action="save_doctor.php" method="POST" enctype="multipart/form-data">

        <div class="mb-3">
            <label class="form-label">Doctor Name</label>
            <input type="text" class="form-control" name="name" required placeholder="Enter doctor name">
        </div>

        <div class="mb-3">
            <label class="form-label">Experience (in years)</label>
            <input type="number" class="form-control" name="experience" required placeholder="E.g., 5">
        </div>

        <div class="mb-3">
            <label class="form-label">Department</label>
            <select class="form-select" name="department" required>
                <option value="">-- Select Department --</option>
                <option>Cardiology</option>
                <option>Neurology</option>
                <option>Orthopedics</option>
                <option>Pediatrics</option>
                <option>Dermatology</option>
                <option>General Medicine</option>
                <option>ENT</option>
                <option>Gynecology</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Education / Qualification</label>
            <input type="text" class="form-control" name="education" required placeholder="E.g., MBBS, MD">
        </div>

        <div class="mb-3">
            <label class="form-label">Phone Number</label>
            <input type="text" class="form-control" name="phone" required placeholder="Enter phone number">
        </div>

        <div class="mb-3">
            <label class="form-label">Registration Number</label>
            <input type="text" class="form-control" name="regno" required placeholder="Doctor registration number">
        </div>

        <div class="mb-3">
            <label class="form-label">Doctor Photo</label>
            <input type="file" class="form-control" name="photo" accept="image/*" required>
        </div>

        <button type="submit" class="btn btn-submit">Add Doctor</button>
    </form>
</div>

</body>
</html>
