# 🏥 Heart Beat – Hospital Management System

A web-based Hospital Management System developed using PHP and MySQL to simplify hospital administration and patient information management.

![PHP](https://img.shields.io/badge/PHP-Backend-777BB4?logo=php&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-Database-4479A1?logo=mysql&logoColor=white)
![HTML5](https://img.shields.io/badge/HTML5-Frontend-E34F26?logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-Styling-1572B6?logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-Frontend-F7DF1E?logo=javascript&logoColor=black)

## 📌 About the Project

**Heart Beat – Hospital Management System** is a web application designed to organize basic hospital administrative activities and patient information.

The application provides an administrative dashboard and patient management functionality through a centralized interface connected to a MySQL database.

The project was developed as a practical implementation of web development and database management concepts.

## ✨ Implemented Features

### 1. Admin Dashboard
- Centralized administrative interface.
- Organized navigation to available management features.
- Access to hospital administration operations.

### 2. Patient Management
- Add and manage patient information.
- Store patient details in a MySQL database.
- View and manage patient records.

## 🛠️ Technologies Used

| Technology | Purpose |
|---|---|
| PHP | Backend development |
| MySQL | Database management |
| HTML5 | Web page structure |
| CSS3 | Styling and layout |
| JavaScript | Client-side functionality |
| XAMPP / Laragon | Local development environment |

## 📂 Project Structure

```text
hospital_management/
│
├── assests/
│   └── images/
│       └── logo.png
│
├── uploads/
│
├── admin_login.php
├── admin_register.php
├── dashboard.php
│
├── add_patient.php
├── save_patient.php
├── view_patients.php
│
├── add_doctor.php
├── save_doctor.php
├── doctors_list.php
│
├── book_appointment.php
├── save_appointment.php
├── view_appointments.php
│
├── billing.php
├── report_update.php
│
├── database.sql
├── index.php
├── style.css
└── README.md
```

*Note: This is an overview of selected project files. Refer to the repository for the complete source code.*

## ⚙️ Installation and Setup

### Prerequisites

- XAMPP or Laragon
- PHP
- MySQL
- Web browser

### Step 1: Clone the Repository

```bash
git clone https://github.com/PrarthanaKumar37/Heart_Beat-Hospital-Management-System.git
```

### Step 2: Move the Project

Place the downloaded project folder inside:

- XAMPP: `htdocs/`
- Laragon: `www/`

### Step 3: Start the Local Server

Start Apache and MySQL through XAMPP or Laragon.

### Step 4: Set Up the Database

1. Open phpMyAdmin.
2. Create the database using the name expected by the project's database configuration.
3. Import the `database.sql` file.
4. Verify that the database tables are created successfully.

### Step 5: Configure Database Connection

Open the PHP file containing the database connection settings.

Update the following according to your local MySQL configuration:

- Database host
- Database username
- Database password
- Database name

Do not commit private database credentials.

### Step 6: Run the Application

Open your browser and navigate to:

```text
http://localhost/hospital_management/
```

## 📸 Screenshots

Application screenshots will be added here.

| Admin Dashboard | Patient Management |
|---|---|
| Add actual dashboard screenshot | Add actual patient management screenshot |

## 🎯 Project Objectives

- Digitize basic hospital administrative activities.
- Organize patient information in a centralized database.
- Reduce manual record management.
- Apply PHP and MySQL concepts in a practical web application.

## 🚀 Future Enhancements

- Enhanced role-based authentication.
- Doctor management improvements.
- Appointment scheduling enhancements.
- Billing and payment management.
- Medical records management.
- Reports and analytics.

## 📌 Project Details

| Category | Details |
|---|---|
| Project Name | Heart Beat – Hospital Management System |
| Project Type | Web Application |
| Project Status | Completed |
| Backend | PHP |
| Database | MySQL |
| Frontend | HTML, CSS, JavaScript |
| Environment | XAMPP / Laragon |

## 👩‍💻 Developer
Prarthana B and Aruna

Information Science and Engineering Student

GitHub: [@PrarthanaKumar37](https://github.com/PrarthanaKumar37)

---

⭐ If you find this project useful, feel free to explore the repository!
