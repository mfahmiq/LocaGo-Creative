<?php
session_start();
if (!isset($_SESSION['admin'])) { header('Location: login.html'); exit; }
$conn = new mysqli('localhost','root','','hospital_db');
$res = $conn->query('SELECT p.*, d.name as doctor_name FROM patients p LEFT JOIN doctors d ON p.doctor_id=d.id');
?><!DOCTYPE html><html><head><meta charset="utf-8"><title>Patients</title><link rel="stylesheet" href="style.css"></head><body>
<div class="container"><h2>Patients</h2>
<table><tr><th>ID</th><th>Name</th><th>Age</th><th>Gender</th><th>Disease</th><th>Doctor</th><th>Admit</th><th>Discharge</th><th>Report Date</th><th>Report Time</th></tr>
<?php while($r=$res->fetch_assoc()){
 echo "<tr><td>{$r['id']}</td><td>{$r['name']}</td><td>{$r['age']}</td><td>{$r['gender']}</td><td>{$r['disease']}</td><td>{$r['doctor_name']}</td><td>{$r['admit_date']}</td><td>{$r['discharge_date']}</td><td>{$r['report_date']}</td><td>{$r['report_time']}</td></tr>";
} ?>
</table><p style="margin-top:12px"><a href="dashboard.php">Back to Dashboard</a></p></div></body></html>