<?php
session_start();

// Database Connection
$conn = new mysqli('localhost', 'root', '', 'dashboard');
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Read input safely
$user = trim($_POST['username'] ?? '');
$pass = trim($_POST['password'] ?? '');

// Check empty
if ($user === '' || $pass === '') {
    echo "Missing credentials";
    exit;
}

// Prepare query
$stmt = $conn->prepare("SELECT id, password FROM admin WHERE username = ? LIMIT 1");
$stmt->bind_param("s", $user);
$stmt->execute();
$stmt->store_result();

// Bind results
$stmt->bind_result($id, $dbpass);

// Check login
if ($stmt->num_rows === 1) {
    $stmt->fetch();

    // Simple plain-text check (as you used)
    if ($pass === $dbpass) {
        $_SESSION['admin'] = $id;

        // Redirect to dashboard
        header("Location: dashboard.php<?php
session_start();

// Database Connection
$conn = new mysqli('localhost', 'root', 'PRARTHANA', 'dashboard');
if ($conn->connect_error) {
    die("Database Connection Failed!");
}

// Process login only when form is submitted
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = trim($_POST['password'] ?? '');

    if ($user === '' || $pass === '') {
        $message = "⚠ Please enter both username and password.";
    } else {
        $stmt = $conn->prepare("SELECT id, password FROM admin WHERE username = ? LIMIT 1");
        $stmt->bind_param("s", $user);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($id, $dbpass);

        if ($stmt->num_rows === 1) {
            $stmt->fetch();
            if ($pass === $dbpass) {
                $_SESSION['admin'] = $id;
                header("Location: dashboard.html");
                exit;
            }
        }

        $message = "❌ Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login - Heart Beat Hospital</title>

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
            background-image: url('https://www.medishinehealth.com/v1/key-images/Best-Cardiology-Heart-Hospital.png');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        /* Blue overlay */
        body::before {
            content: "";
            position: fixed;
            top:0; left:0;
            width:100%; height:100%;
            background: rgba(0, 40, 85, 0.6);
            backdrop-filter: blur(3px);
            z-index:-1;
        }

        .login-box {
            width: 380px;
            background: rgba(255,255,255,0.15);
            backdrop-filter: blur(7px);
            padding: 35px;
            border-radius: 20px;
            margin: 130px auto;
            box-shadow: 0 0 25px rgba(0,0,0,0.5);
            border: 1px solid rgba(255,255,255,0.3);
            text-align: center;
            color: white;
        }

        .login-box h2 {
            font-size: 32px;
            margin-bottom: 10px;
            color: #daf6ff;
            text-shadow: 0 0 5px black;
        }

        .login-box input {
            width: 90%;
            padding: 12px;
            margin: 12px 0;
            border-radius: 10px;
            border: none;
            outline: none;
            font-size: 17px;
            background: rgba(255,255,255,0.7);
        }

        .login-box button {
            width: 95%;
            padding: 12px;
            margin-top: 10px;
            border-radius: 10px;
            border: none;
            background: #0abde3;
            color: black;
            font-size: 20px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        .login-box button:hover {
            background: #74b9ff;
            box-shadow: 0 0 15px #74b9ff;
        }

        .error-box {
            background: rgba(255,0,0,0.3);
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 10px;
            border: 1px solid red;
            font-size: 16px;
        }

        .footer {
            text-align:center;
            margin-top: 40px;
            color: white;
            font-size: 14px;
        }
    </style>
</head>

<body>

    <div class="login-box">

        <h2>Admin Login</h2>

        <?php if ($message): ?>
            <div class="error-box"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="text" name="username" placeholder="Enter Username" required />
            <input type="password" name="password" placeholder="Enter Password" required />
            <button type="submit">Login</button>
        </form>

    </div>

    <div class="footer">
        © 2025 Heart Beat Hospital — Admin Portal
    </div>

</body>
</html>
");
        exit;
    }
}

echo "Invalid login";
exit;
?>>
