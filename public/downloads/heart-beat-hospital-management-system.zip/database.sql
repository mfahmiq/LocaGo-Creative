-- Create database and tables for Hospital Management System
CREATE DATABASE IF NOT EXISTS hospital_db;
USE hospital_db;

CREATE TABLE IF NOT EXISTS admin (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS doctors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  department VARCHAR(100),
  experience INT,
  contact VARCHAR(15)
);

CREATE TABLE IF NOT EXISTS patients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  age INT,
  gender VARCHAR(10),
  disease VARCHAR(100),
  doctor_id INT,
  admit_date DATE,
  discharge_date DATE,
  report_date DATE,
  report_time TIME
);

CREATE TABLE IF NOT EXISTS appointments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_name VARCHAR(100),
  doctor_id INT,
  appointment_date DATE,
  appointment_time TIME,
  status VARCHAR(20) DEFAULT 'Pending'
);

CREATE TABLE IF NOT EXISTS billing (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT,
  doctor_fee FLOAT DEFAULT 0,
  room_charge FLOAT DEFAULT 0,
  test_charge FLOAT DEFAULT 0,
  total_amount FLOAT DEFAULT 0
);

-- Insert a default admin (username: admin, password: admin123)
-- Note: password stored in plain text for simplicity — change for real use.
INSERT IGNORE INTO admin (username, password) VALUES ('admin','admin123');
