<?php
$conn = new mysqli('localhost','root','','hospital_db');
$res = $conn->query('SELECT * FROM doctors');
?><!DOCTYPE html><html><head><meta charset="utf-8"><title>Doctors</title><link rel="stylesheet" href="style.css"></head><body>
<div class="container"><h2>Available Doctors</h2>
<table><tr><th>ID</th><th>Name</th><th>Department</th><th>Experience</th><th>Contact</th></tr>
<?php while($r=$res->fetch_assoc()){ echo "<tr><td>{$r['id']}</td><td>{$r['name']}</td><td>{$r['department']}</td><td>{$r['experience']}</td><td>{$r['contact']}</td></tr>";} ?>
</table><p style="margin-top:12px"><a href="index.html">Back to Home</a></p></div></body></html>