<?php
$conn = new mysqli('localhost','root','','hospital_db');
$res = $conn->query('SELECT id,name,disease,report_date,report_time FROM patients WHERE report_date IS NOT NULL ORDER BY report_date DESC');
?><!DOCTYPE html><html><head><meta charset="utf-8"><title>Reports</title><link rel="stylesheet" href="style.css"></head><body>
<div class="container"><h2>Reports</h2>
<?php if ($res->num_rows==0) { echo '<p>No reports available yet.</p>'; } else { ?>
<table><tr><th>Patient ID</th><th>Name</th><th>Disease</th><th>Report Date</th><th>Report Time</th></tr>
<?php while($r=$res->fetch_assoc()){ echo "<tr><td>{$r['id']}</td><td>{$r['name']}</td><td>{$r['disease']}</td><td>{$r['report_date']}</td><td>{$r['report_time']}</td></tr>"; } ?>
</table>
<?php } ?>
<p style="margin-top:12px"><a href="index.html">Back to Home</a></p></div></body></html>