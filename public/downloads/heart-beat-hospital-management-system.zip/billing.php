<?php
session_start();

if (!isset($_SESSION['admins'])) {
    header("Location: admin_login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "Prarthana@37", "hospital_db");

if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

$patient = null;
$message = "";

// Fetch Patient
if (isset($_POST['fetch'])) {

    $patient_id = intval($_POST['patient_id']);

    $stmt = $conn->prepare("
        SELECT p.*, d.name AS doctor_name
        FROM patients p
        JOIN doctors d ON p.doctor_id = d.id
        WHERE p.id = ?
    ");

    $stmt->bind_param("i", $patient_id);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $patient = $result->fetch_assoc();
    } else {
        $message = "Patient ID not found.";
    }
}

// Save Bill
if (isset($_POST['save_bill'])) {

    $patient_id = intval($_POST['patient_id']);

    $doctor_fee = floatval($_POST['doctor_fee']);
    $room_charge = floatval($_POST['room_charge']);
    $test_charge = floatval($_POST['test_charge']);

    $total = $doctor_fee + $room_charge + $test_charge;

    $stmt = $conn->prepare("
        INSERT INTO billing
        (patient_id, doctor_fee, room_charge, test_charge, total_amount)
        VALUES (?,?,?,?,?)
    ");

    $stmt->bind_param(
        "idddd",
        $patient_id,
        $doctor_fee,
        $room_charge,
        $test_charge,
        $total
    );

    if ($stmt->execute()) {
        echo "<script>
        alert('Bill Generated Successfully!');
        window.location='dashboard.php';
        </script>";
        exit();
    } else {
        $message = "Error while saving bill.";
    }
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Generate Bill</title>

<style>

body{
margin:0;
font-family:Arial;
background:url('https://www.medishinehealth.com/v1/key-images/Best-Cardiology-Heart-Hospital.png');
background-size:cover;
background-attachment:fixed;
}

body::before{
content:'';
position:fixed;
top:0;
left:0;
width:100%;
height:100%;
background:rgba(0,40,85,.6);
backdrop-filter:blur(3px);
z-index:-1;
}

.box{
width:550px;
margin:40px auto;
background:rgba(255,255,255,.15);
backdrop-filter:blur(8px);
padding:30px;
border-radius:20px;
color:white;
box-shadow:0 0 20px rgba(0,0,0,.5);
}

h2{
text-align:center;
color:#daf6ff;
}

label{
display:block;
margin-top:12px;
font-weight:bold;
}

input{
width:100%;
padding:10px;
margin-top:5px;
border:none;
border-radius:8px;
font-size:16px;
box-sizing:border-box;
}

button{
width:100%;
padding:12px;
margin-top:20px;
background:#0abde3;
border:none;
border-radius:10px;
font-size:18px;
font-weight:bold;
cursor:pointer;
}

button:hover{
background:#74b9ff;
}

.details{
margin-top:20px;
padding:15px;
background:rgba(255,255,255,.2);
border-radius:10px;
}

.back{
display:block;
margin-top:20px;
text-align:center;
color:white;
text-decoration:none;
font-weight:bold;
}

.error{
text-align:center;
color:yellow;
font-weight:bold;
margin-top:10px;
}

</style>

</head>

<body>

<div class="box">

<h2>Generate Patient Bill</h2>

<?php
if($message!=""){
echo "<div class='error'>$message</div>";
}
?>

<form method="post">

<label>Patient ID</label>

<input
type="number"
name="patient_id"
required
value="<?php if(isset($_POST['patient_id'])) echo $_POST['patient_id']; ?>"
>

<button type="submit" name="fetch">
Fetch Patient Details
</button>

</form>

<?php if($patient){ ?>

<div class="details">

<h3>Patient Details</h3>

<p><b>Name:</b> <?= htmlspecialchars($patient['name']) ?></p>

<p><b>Age:</b> <?= $patient['age'] ?></p>

<p><b>Gender:</b> <?= htmlspecialchars($patient['gender']) ?></p>

<p><b>Disease:</b> <?= htmlspecialchars($patient['disease']) ?></p>

<p><b>Doctor:</b> <?= htmlspecialchars($patient['doctor_name']) ?></p>

<p><b>Admit Date:</b> <?= $patient['admit_date'] ?></p>

</div>

<form method="post">

<input
type="hidden"
name="patient_id"
value="<?= $patient['id'] ?>"
>

<label>Doctor Fee (₹)</label>

<input
type="number"
step="0.01"
name="doctor_fee"
required
>

<label>Room Charge (₹)</label>

<input
type="number"
step="0.01"
name="room_charge"
required
>

<label>Test Charge (₹)</label>

<input
type="number"
step="0.01"
name="test_charge"
required
>

<button type="submit" name="save_bill">
Generate Bill
</button>

</form>

<?php } ?>

<a class="back" href="dashboard.php">
⬅ Back to Dashboard
</a>

</div>

</body>
</html>