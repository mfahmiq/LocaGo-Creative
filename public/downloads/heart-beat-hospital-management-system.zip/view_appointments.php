<?php
session_start();

if (!isset($_SESSION['admins'])) { 
    header('Location: admin_login.php'); 
    exit; 
}

$conn = new mysqli('localhost','root','Prarthana@37','hospital_db');

if($conn->connect_error){
    die("Database Connection Failed");
}

$res = $conn->query("
SELECT a.*, d.name AS doctor_name 
FROM appointments a 
LEFT JOIN doctors d 
ON a.doctor_id=d.id 
ORDER BY appointment_date DESC
");

?>


<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<title>Appointments - Heart Beat Hospital</title>


<style>


*{
    box-sizing:border-box;
}


body{

    margin:0;

    font-family:Arial, Helvetica, sans-serif;

    background-image:url('https://www.medishinehealth.com/v1/key-images/Best-Cardiology-Heart-Hospital.png');

    background-size:cover;

    background-repeat:no-repeat;

    background-attachment:fixed;

}



/* Overlay */

body::before{

    content:"";

    position:fixed;

    top:0;
    left:0;

    width:100%;
    height:100%;

    background:rgba(0,40,85,0.7);

    backdrop-filter:blur(3px);

    z-index:-1;

}



/* Main box */

.container{


    width:90%;

    margin:50px auto;


    padding:35px;


    background:rgba(255,255,255,0.15);


    backdrop-filter:blur(8px);


    border-radius:20px;


    border:1px solid rgba(255,255,255,0.3);


    box-shadow:0 0 30px rgba(0,0,0,0.5);


    color:white;


}




/* Heading */


h2{


    text-align:center;


    font-size:36px;


    color:#daf6ff;


    text-shadow:0 0 8px black;


    margin-bottom:30px;


}



.hospital-title{

    text-align:center;

    color:#00cec9;

    font-size:22px;

    margin-bottom:10px;

}




/* Table */


.table-box{

    overflow-x:auto;

}


table{


    width:100%;


    border-collapse:collapse;


    background:rgba(255,255,255,0.12);


    border-radius:15px;


    overflow:hidden;


}




th{


    background:#0abde3;


    color:black;


    padding:15px;


    font-size:17px;


}




td{


    padding:14px;


    text-align:center;


    border-bottom:1px solid rgba(255,255,255,0.2);


    font-size:16px;


}





tr:hover{


    background:rgba(255,255,255,0.2);


    transition:0.3s;


}







/* Back button */


.back{


    text-align:center;


    margin-top:25px;


}



.back a{


    text-decoration:none;


    color:#daf6ff;


    font-size:18px;


    font-weight:bold;


}



.back a:hover{

    color:#00cec9;

}




.footer{


    text-align:center;


    color:white;


    margin-top:20px;


    font-size:14px;


}



</style>


</head>



<body>



<div class="container">


<div class="hospital-title">
❤️ Heart Beat Hospital
</div>


<h2>
📅 Patient Appointments
</h2>



<div class="table-box">


<table>


<tr>

<th>ID</th>

<th>Patient Name</th>

<th>Doctor</th>

<th>Date</th>

<th>Time</th>


</tr>



<?php 

while($r=$res->fetch_assoc()){


echo "

<tr>

<td>".$r['id']."</td>

<td>".$r['patient_name']."</td>

<td>Dr. ".$r['doctor_name']."</td>

<td>".$r['appointment_date']."</td>

<td>".$r['appointment_time']."</td>




</tr>

";


}


?>



</table>


</div>




<div class="back">

<a href="dashboard.php">
⬅ Back to Dashboard
</a>

</div>



</div>




<div class="footer">

© 2025 Heart Beat Hospital — Admin Portal

</div>



</body>


</html>