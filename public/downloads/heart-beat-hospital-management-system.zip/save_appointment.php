<?php

$conn = new mysqli('localhost','root','Prarthana@37','hospital_db');

if($conn->connect_error){
    die("Database Connection Failed");
}


$patient = trim($_POST['patient_name'] ?? '');
$doctor_id = intval($_POST['doctor_id'] ?? 0);
$date = $_POST['appointment_date'] ?? '';
$time = $_POST['appointment_time'] ?? '';


$message = "";
$success = false;



if($patient && $doctor_id && $date){

    $stmt = $conn->prepare(
        "INSERT INTO appointments 
        (patient_name, doctor_id, appointment_date, appointment_time) 
        VALUES (?,?,?,?)"
    );



    $stmt->bind_param(
        "siss",
        $patient,
        $doctor_id,
        $date,
        $time
       
    );


    if($stmt->execute()){

        $message = "Appointment request submitted successfully!";
        $success = true;

    }
    else{

        $message = "Something went wrong. Please try again.";

    }


}
else{

    $message = "Please fill all required details.";

}



?>


<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<title>Appointment Status - Heart Beat Hospital</title>


<style>


*{
box-sizing:border-box;
}



body{

margin:0;

font-family:Arial, Helvetica, sans-serif;

background-image:url('https://www.medishinehealth.com/v1/key-images/Best-Cardiology-Heart-Hospital.png');

background-size:cover;

background-attachment:fixed;

}



/* Overlay */

body::before{

content:"";

position:fixed;

top:0;
left:0;

width:100%;
height:100%;

background:rgba(0,40,85,0.7);

backdrop-filter:blur(3px);

z-index:-1;

}




.box{


width:450px;


margin:120px auto;


padding:35px;


text-align:center;


background:rgba(255,255,255,0.15);


backdrop-filter:blur(8px);


border-radius:20px;


border:1px solid rgba(255,255,255,0.3);


box-shadow:0 0 30px rgba(0,0,0,0.5);


color:white;


}



.logo{

font-size:22px;

color:#00cec9;

margin-bottom:20px;

}




h2{

font-size:30px;

color:#daf6ff;

text-shadow:0 0 8px black;

}




.message{


padding:15px;


margin:25px 0;


border-radius:12px;


font-size:18px;


background:

<?php echo $success ? "#00cec9" : "#ff7675"; ?>;


color:black;


font-weight:bold;


}




.btn{


display:inline-block;


margin-top:20px;


padding:12px 25px;


background:#0abde3;


color:black;


text-decoration:none;


border-radius:10px;


font-weight:bold;


font-size:17px;


transition:0.3s;


}



.btn:hover{


background:#74b9ff;


box-shadow:0 0 15px #74b9ff;


}




.footer{


text-align:center;

color:white;

font-size:14px;


}



</style>


</head>



<body>



<div class="box">


<div class="logo">
❤️ Heart Beat Hospital
</div>



<h2>
🩺 Appointment Status
</h2>




<div class="message">

<?php echo $message; ?>

</div>



<a class="btn" href="index.php">
⬅ Back to Home
</a>



</div>




<div class="footer">

© 2025 Heart Beat Hospital — Patient Portal

</div>



</body>

</html>