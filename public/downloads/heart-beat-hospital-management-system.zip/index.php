<?php
$conn = new mysqli("localhost", "root", "Prarthana@37", "hospital_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$doctors = $conn->query("SELECT * FROM doctors ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Heart Beat Hospital</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

html{
    scroll-behavior:smooth;
}

body{
    background:#f5f9ff;
    color:#333;
}


/* NAVBAR */

header{

    position:fixed;
    top:0;
    width:100%;
    background:white;
    display:flex;
    align-items:center;
    padding:15px 8%;
    z-index:1000;
    box-shadow:0 4px 15px rgba(0,0,0,0.1);
}


header img{

    width:65px;
    height:65px;
    border-radius:50%;
}


header h1{

    margin-left:20px;
    color:#c1121f;
    font-size:32px;
}


nav{

    margin-left:auto;
}


nav a{

    text-decoration:none;
    color:#333;
    margin:0 15px;
    font-weight:600;
}


nav a:hover{

    color:#c1121f;
}


/* HERO */


.hero{

    height:100vh;
    background:
    linear-gradient(rgba(0,0,0,.55),rgba(0,0,0,.55)),
    url('https://www.medishinehealth.com/v1/key-images/Best-Cardiology-Heart-Hospital.png');

    background-size:cover;
    background-position:center;

    display:flex;
    align-items:center;
    justify-content:center;
    text-align:center;
    color:white;
}


.hero h2{

    font-size:55px;
}


.hero p{

    font-size:22px;
    margin:20px;
}


.btn{

    background:#c1121f;
    color:white;
    padding:14px 30px;
    border-radius:30px;
    text-decoration:none;
    font-weight:bold;
}


/* COMMON SECTION */

section{

    padding:80px 10%;
}


.title{

    text-align:center;
    font-size:38px;
    color:#c1121f;
    margin-bottom:40px;
}


/* ABOUT */


.about p{

    text-align:center;
    line-height:1.8;
    font-size:18px;
}


.cards{

    display:flex;
    justify-content:center;
    gap:30px;
    margin-top:40px;
    flex-wrap:wrap;
}


.card{

    width:300px;
    padding:30px;
    background:white;
    border-radius:15px;
    box-shadow:0 5px 20px rgba(0,0,0,.1);
    text-align:center;
}


.card h3{

    color:#c1121f;
    margin-bottom:15px;
}



/* SERVICES */


.services{

    background:#eef6ff;
}


.service-box{

    display:flex;
    justify-content:center;
    gap:25px;
    flex-wrap:wrap;
}


.service{

    background:white;
    width:250px;
    padding:25px;
    border-radius:15px;
    text-align:center;
    box-shadow:0 5px 15px #ddd;
}


.service h3{

    color:#c1121f;
}


/* DOCTORS */


.doctor-container{

    display:flex;
    justify-content:center;
    flex-wrap:wrap;
    gap:30px;
}


.doctor-card{

    width:260px;
    background:white;
    border-radius:15px;
    overflow:hidden;
    box-shadow:0 8px 20px rgba(0,0,0,.15);
    text-align:center;
    transition:.3s;
}


.doctor-card:hover{

    transform:translateY(-10px);
}


.doctor-card img{

    width:100%;
    height:260px;
    object-fit:cover;
}


.doctor-card h3{

    margin:15px;
    color:#c1121f;
}


.doctor-card p{

    margin-bottom:20px;
}


/* CONTACT */

.emergency{

    background:#c1121f;
    color:white;
    text-align:center;
}


.emergency h2{

    font-size:35px;
}



/* FOOTER */


footer{

    background:#111;
    color:white;
    padding:25px;
    text-align:center;
}



/* MOBILE */


@media(max-width:900px){

header{

    flex-direction:column;

}

nav{

    margin-top:15px;

}


.hero h2{

    font-size:35px;

}

}

</style>

</head>


<body>


<header>


<h1>Heart Beat Hospital</h1>


<nav>

<a href="#about">About</a>
<a href="#services">Services</a>
<a href="#doctors">Doctors</a>
<a href="book_appointment.php">Appointment</a>
<a href="admin_login.php">Admin</a>

</nav>

</header>



<!-- HERO -->

<section class="hero">

<div>

<h2>Your Health, Our Priority</h2>

<p>
Advanced healthcare with compassion and technology
</p>

<a class="btn" href="book_appointment.php">
Book Appointment
</a>

</div>

</section>

<!-- HISTORY SECTION -->

<section id="history">

<h2 class="title">
Our History
</h2>

<p style="text-align:center; font-size:18px; line-height:1.8;">

Heart Beat Hospital was established in 2012 with a vision to provide
high-quality and affordable healthcare services to the community.
Starting as a small cardiac care center with a dedicated team of
doctors and nurses, the hospital gradually expanded its services to
become a leading multispeciality healthcare institution.

Over the years, Heart Beat Hospital has continuously adopted advanced
medical technologies, expanded its departments, and built a team of
experienced healthcare professionals. In 2016, the hospital introduced
modern diagnostic facilities and emergency care services to provide
faster and more effective treatment.

In 2020, Heart Beat Hospital launched specialized departments including
cardiology, neurology, orthopedics, and general medicine, allowing
patients to receive complete healthcare solutions under one roof.

Today, Heart Beat Hospital proudly serves thousands of patients every
year with a commitment to medical excellence, innovation, and
compassionate patient care. Our journey continues with the goal of
creating a healthier society through advanced treatment and preventive
healthcare programs.

</p>

</section>

<!-- ABOUT -->


<section id="about">

<h2 class="title">
About Us
</h2>


<p>

Heart Beat Hospital is a modern multispeciality healthcare center
providing reliable and affordable medical services. Our experienced
doctors and healthcare professionals deliver patient-centered care
using advanced medical technology.

</p>


<div class="cards">


<div class="card">

<h3>Our Vision</h3>

<p>
To become a trusted healthcare destination known for excellence,
innovation and compassionate treatment.
</p>

</div>



<div class="card">

<h3>Our Mission</h3>

<p>
Providing quality healthcare, advanced treatments and promoting
healthy lifestyles.
</p>

</div>



<div class="card">

<h3>Why Choose Us</h3>

<p>
24/7 Emergency Care<br>
Expert Doctors<br>
Modern Facilities
</p>

</div>


</div>

</section>





<!-- SERVICES -->


<section id="services" class="services">

<h2 class="title">
Our Services
</h2>


<div class="service-box">


<div class="service">
<h3>Emergency Care</h3>
<p>24/7 emergency medical support.</p>
</div>


<div class="service">
<h3>Cardiology</h3>
<p>Advanced heart treatments.</p>
</div>


<div class="service">
<h3>Diagnostics</h3>
<p>Modern laboratory facilities.</p>
</div>


<div class="service">
<h3>Pharmacy</h3>
<p>Complete medicine support.</p>
</div>


</div>

</section>





<!-- DOCTORS -->


<section id="doctors">


<h2 class="title">
Our Doctors
</h2>


<div class="doctor-container">


<?php if($doctors->num_rows==0){ ?>


<h3>No Doctors Available</h3>


<?php } else { ?>


<?php while($doc=$doctors->fetch_assoc()){ ?>


<div class="doctor-card">


<img src="uploads/<?php echo $doc['photo']; ?>">


<h3>
<?php echo $doc['name']; ?>
</h3>


<p>
<?php echo $doc['department']; ?>
</p>


</div>


<?php } ?>


<?php } ?>


</div>


</section>




<section class="emergency">

<h2>
Emergency Contact: +91 98765 43210
</h2>

<p>
Available 24 hours for critical medical assistance
</p>

</section>



<footer>

© 2026 Heart Beat Hospital | All Rights Reserved

</footer>


</body>
</html>