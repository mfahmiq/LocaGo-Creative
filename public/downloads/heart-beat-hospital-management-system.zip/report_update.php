<?php
session_start();
if (!isset($_SESSION['admin'])) { header('Location: login.html'); exit; }
$conn = new mysqli('localhost','root','','hospital_db');
$pid = intval($_POST['patient_id'] ?? 0);
$rdate = $conn->real_escape_string($_POST['report_date'] ?? '');
$rtime = $conn->real_escape_string($_POST['report_time'] ?? '');
if ($pid) {
  $stmt = $conn->prepare('UPDATE patients SET report_date=?, report_time=? WHERE id=?');
  $stmt->bind_param('ssi',$rdate,$rtime,$pid);
  $stmt->execute();
  echo 'Report updated. <a href="dashboard.php">Back</a>';
} else echo 'Missing patient id';
?>