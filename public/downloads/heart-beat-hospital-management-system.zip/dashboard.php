<?php
session_start();
if(!isset($_SESSION['admins'])) {
    header("Location: admin_login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body{
    margin:0;
    padding:0;
    font-family:Arial, Helvetica, sans-serif;
    background-image:url('https://www.medishinehealth.com/v1/key-images/Best-Cardiology-Heart-Hospital.png');
    background-size:cover;
    background-repeat:no-repeat;
    background-attachment:fixed;
}

body::before{
    content:"";
    position:fixed;
    top:0;
    left:0;
    width:100%;
    height:100%;
    background:rgba(0,40,85,0.6);
    backdrop-filter:blur(3px);
    z-index:-1;
}

.container{
    width:420px;
    margin:70px auto;
    background:rgba(255,255,255,0.15);
    backdrop-filter:blur(8px);
    border-radius:20px;
    padding:35px;
    text-align:center;
    box-shadow:0 0 25px rgba(0,0,0,0.5);
    border:1px solid rgba(255,255,255,0.3);
}

.container h2{
    color:#daf6ff;
    font-size:32px;
    margin-bottom:25px;
    text-shadow:0 0 5px black;
}

.btn{
    display:block;
    width:90%;
    margin:12px auto;
    padding:13px;
    border:none;
    border-radius:10px;
    background:#0abde3;
    color:black;
    text-decoration:none;
    font-size:18px;
    font-weight:bold;
    transition:.3s;
}

.btn:hover{
    background:#74b9ff;
    box-shadow:0 0 15px #74b9ff;
}

.logout{
    background:#ff4d4d;
}

.logout:hover{
    background:#ff7675;
    box-shadow:0 0 15px #ff7675;
}
    </style>
</head>
<body>

<div class="overlay">
    <div class="container">

        <h2>Admin Dashboard</h2>

        <a class="btn" href="add_doctor.php">➕ Add Doctor</a>
        <a class="btn" href="add_patient.php">➕ Add Patient</a>
        <a class="btn" href="billing.php">🧾 Generate Bill</a>
        <a class="btn" href="view_appointments.php">📅 View Appointments</a>
        <a class="btn" href="change_password.php">🔑 Change Username / Password</a>
        <a class="btn" href="admin_register.php">Register New Admin</a>
        <a class="btn logout" href="logout.php">Logout</a>

    </div>
</div>

</body>
</html>
