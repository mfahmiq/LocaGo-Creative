<?php
// add_doctor.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Doctor - Heart Beat Hospital</title>

<style>

*{
    box-sizing:border-box;
}

body{
    margin:0;
    padding:0;
    font-family:Arial, Helvetica, sans-serif;

    background-image:url('https://www.medishinehealth.com/v1/key-images/Best-Cardiology-Heart-Hospital.png');
    background-size:cover;
    background-repeat:no-repeat;
    background-attachment:fixed;
}


/* Dark blue overlay */
body::before{
    content:"";
    position:fixed;
    top:0;
    left:0;
    width:100%;
    height:100%;

    background:rgba(0,40,85,0.65);
    backdrop-filter:blur(3px);

    z-index:-1;
}


/* Main Glass Box */

.form-container{

    width:650px;

    margin:60px auto;

    background:rgba(255,255,255,0.15);

    backdrop-filter:blur(8px);

    padding:35px;

    border-radius:20px;

    border:1px solid rgba(255,255,255,0.3);

    box-shadow:0 0 30px rgba(0,0,0,0.5);

    color:white;

}


/* Heading */

.heading-title{

    text-align:center;

    font-size:35px;

    margin-bottom:25px;

    color:#daf6ff;

    text-shadow:0 0 8px black;

}


/* Labels */

label{

    font-size:17px;

    font-weight:bold;

    color:white;

}



/* Inputs */

.form-control,
.form-select{

    width:100%;

    padding:13px;

    margin-top:8px;

    margin-bottom:18px;

    border-radius:12px;

    border:none;

    font-size:16px;

    background:rgba(255,255,255,0.75);

}



.form-control:focus,
.form-select:focus{

    outline:none;

    box-shadow:0 0 10px #00cec9;

}



/* Button */

.btn-submit{

    width:100%;

    padding:13px;

    border:none;

    border-radius:12px;

    background:#0abde3;

    color:black;

    font-size:20px;

    font-weight:bold;

    cursor:pointer;

    transition:0.3s;

}



.btn-submit:hover{

    background:#74b9ff;

    box-shadow:0 0 20px #74b9ff;

}



/* Footer */

.footer{

    text-align:center;

    color:white;

    margin-top:30px;

    font-size:14px;

}



.logo-title{

    text-align:center;

    color:#00cec9;

    font-size:20px;

    margin-bottom:5px;

}


</style>

</head>


<body>


<div class="form-container">


<div class="logo-title">
❤️ Heart Beat Hospital
</div>


<h2 class="heading-title">
Add New Doctor
</h2>


<form action="save_doctor.php" method="POST" enctype="multipart/form-data">


<label>Doctor Name</label>

<input type="text" 
class="form-control" 
name="name"
placeholder="Enter doctor name"
required>



<label>Experience (in years)</label>

<input type="number"
class="form-control"
name="experience"
placeholder="Example: 5"
required>



<label>Department</label>

<select class="form-select" name="department" required>

<option value="">-- Select Department --</option>

<option>Cardiology</option>
<option>Neurology</option>
<option>Orthopedics</option>
<option>Pediatrics</option>
<option>Dermatology</option>
<option>General Medicine</option>
<option>ENT</option>
<option>Gynecology</option>

</select>



<label>Education / Qualification</label>

<input type="text"
class="form-control"
name="education"
placeholder="Example: MBBS, MD"
required>




<label>Phone Number</label>

<input type="text"
class="form-control"
name="phone"
placeholder="Enter phone number"
required>




<label>Registration Number</label>

<input type="text"
class="form-control"
name="regno"
placeholder="Doctor registration number"
required>




<label>Doctor Photo</label>

<input type="file"
class="form-control"
name="photo"
accept="image/*"
required>



<button class="btn-submit">
➕ Add Doctor
</button>


</form>

</div>



<div class="footer">

© 2025 Heart Beat Hospital — Admin Portal

</div>



</body>
</html>
