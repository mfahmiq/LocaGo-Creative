<?php
// Connect to database
$conn = new mysqli("localhost", "root", "Prarthana@37", "hospital_db");
if ($conn->connect_error) die("Database connection failed: " . $conn->connect_error);

// Fetch all doctors
$res = $conn->query("SELECT * FROM doctors ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Our Doctors - Heart Beat Hospital</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        background: linear-gradient(180deg,#e9f3ff,#f7fbff);
        font-family: Arial, sans-serif;
    }
    .wrap {
        max-width: 1200px;
        margin: 40px auto;
        padding: 20px;
    }
    .card-doctor {
        border: none;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 6px 20px rgba(0,0,0,0.08);
        transition: transform 0.2s;
    }
    .card-doctor:hover {
        transform: translateY(-5px);
    }
    .doc-photo {
        height: 230px;
        object-fit: cover;
        width: 100%;
    }
    .dept {
        font-weight: 600;
        color: #0b66a3;
    }
    .small-muted {
        color: #666;
        font-size: 0.95rem;
    }
    .top-bar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }
</style>
</head>
<body>

<div class="wrap container">

    <div class="top-bar">
        <h2>Our Doctors</h2>
        <a href="add_doctor.php" class="btn btn-primary">+ Add New Doctor</a>
    </div>

    <div class="row g-4">
        <?php if ($res && $res->num_rows > 0): ?>
            <?php while($d = $res->fetch_assoc()): ?>
                <div class="col-sm-6 col-md-4">
                    <div class="card card-doctor">
                        <img class="doc-photo" src="<?php echo 'uploads/' . htmlspecialchars($d['photo']); ?>" alt="Doctor Photo">
                        <div class="card-body">
                            <h5 class="card-title mb-1"><?php echo htmlspecialchars($d['name']); ?></h5>
                            <div class="dept mb-1"><?php echo htmlspecialchars($d['department']); ?></div>
                            <p class="small-muted mb-2"><?php echo htmlspecialchars($d['education']); ?></p>
                            <p class="mb-1"><strong>Experience:</strong> <?php echo htmlspecialchars($d['experience']); ?> years</p>
                            <p class="mb-1"><strong>Reg No:</strong> <?php echo htmlspecialchars($d['regno']); ?></p>
                            <p class="mb-0"><strong>Phone:</strong> <?php echo htmlspecialchars($d['phone']); ?></p>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-info">No doctors found. <a href="add_doctor.php">Add a doctor</a></div>
            </div>
        <?php endif; ?>
    </div>

</div>

</body>
</html>
