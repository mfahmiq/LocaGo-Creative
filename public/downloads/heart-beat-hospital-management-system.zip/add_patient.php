<?php
session_start();

if (!isset($_SESSION['admins'])) {
    header("Location: admin_login.php");
    exit();
}

$conn = new mysqli("localhost","root","Prarthana@37","hospital_db");

if ($conn->connect_error) {
    die("Connection Failed!");
}

$doctors = $conn->query("SELECT id,name FROM doctors ORDER BY name");
?>

<!DOCTYPE html>
<html>
<head>
<title>Add Patient</title>

<style>

body{
    margin:0;
    font-family:Arial;
    background:url("https://www.medishinehealth.com/v1/key-images/Best-Cardiology-Heart-Hospital.png");
    background-size:cover;
    background-attachment:fixed;
}

body::before{
    content:"";
    position:fixed;
    inset:0;
    background:rgba(0,40,85,.6);
    backdrop-filter:blur(3px);
    z-index:-1;
}

.box{
    width:500px;
    margin:40px auto;
    background:rgba(255,255,255,.15);
    backdrop-filter:blur(8px);
    border-radius:20px;
    padding:30px;
    color:white;
    box-shadow:0 0 20px rgba(0,0,0,.5);
}

h2{
    text-align:center;
    color:#daf6ff;
}

input,select{
    width:100%;
    padding:12px;
    margin:10px 0;
    border:none;
    border-radius:10px;
    font-size:16px;
}

button{
    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    background:#0abde3;
    font-size:18px;
    font-weight:bold;
    cursor:pointer;
}

button:hover{
    background:#74b9ff;
}

.back{
    display:block;
    text-align:center;
    margin-top:15px;
    color:white;
    text-decoration:none;
}

</style>

</head>

<body>

<div class="box">

<h2>Add Patient</h2>

<form action="save_patient.php" method="post">

<label>Patient Name</label>
<input type="text" name="name" required>

<label>Age</label>
<input type="number" name="age" min="1" required>

<label>Gender</label>

<select name="gender" required>
<option value="">Select Gender</option>
<option value="Male">Male</option>
<option value="Female">Female</option>
<option value="Other">Other</option>
</select>

<label>Disease</label>
<input type="text" name="disease" required>

<label>Doctor</label>

<select name="doctor_id" required>

<option value="">Select Doctor</option>

<?php
while($row=$doctors->fetch_assoc()){
?>
<option value="<?= $row['id'] ?>">
<?= htmlspecialchars($row['name']) ?>
</option>
<?php
}
?>

</select>

<label>Admit Date</label>

<input type="date" name="admit_date" required>

<button type="submit">
Add Patient
</button>

</form>

<a href="dashboard.php" class="back">
⬅ Back to Dashboard
</a>

</div>

</body>
</html>