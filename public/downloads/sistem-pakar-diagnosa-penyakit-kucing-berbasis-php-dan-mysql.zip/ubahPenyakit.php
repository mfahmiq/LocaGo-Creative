<?php
include "function.php";
if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 1) {
        header("location: test.php");
    }
} else {
    header("location:index.php");
}

$id_penyakit = $_GET["id_penyakit"];

$queryPenyakit = mysqli_query($koneksi, "SELECT * FROM penyakit WHERE id_penyakit = '$id_penyakit'");
$penyakit = mysqli_fetch_assoc($queryPenyakit);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="styles.css">
    <link
        rel="stylesheet"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
        crossorigin="anonymous"/>
    <link
        href="https://fonts.googleapis.com/css?family=Poppins:300,400,700&display=swap"
        rel="stylesheet"/>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Poppins', sans-serif;
    display: flex;
    background-color: #f8f9fc;
}

/* Sidebar */
.kiri {
    width: 250px;
    height: 100vh;
    background-color: #2c3e50;
    color: #ecf0f1;
    position: fixed;
    padding: 20px 10px;
    box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
}

.kiri h2 {
    text-align: center;
    margin-bottom: 30px;
}

.kiri .sidebar-heading {
    margin: 20px 0 10px;
    font-size: 0.9rem;
    text-transform: uppercase;
    font-weight: bold;
    color: #bdc3c7;
}

.kiri .isi a {
    text-decoration: none;
    color: #ecf0f1;
    display: block;
    padding: 10px 15px;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.kiri .isi a:hover {
    background-color: #34495e;
}

/* Konten Utama */
.kanan {
    margin-left: 270px;
    padding: 20px;
    width: calc(100% - 270px);
    background-color: #f8f9fc;
}
</style>

</head>

<body>
    <div class="kiri">
        <section class="logo">
           <h2>PakarKu.</h2>
        </section>
        <div class="sidebar-heading">
            <h5 class="font-weight-bold text-white text-uppercase teks">Data Pasien</h5>
        </div>
        <section class="isi">
            <a class="nav-link" href="indexAdmin.php">
            <span>Data Pasien</span></a>
        </section>
        
        <div class="sidebar-heading">
            <h5 class="font-weight-bold text-white text-uppercase teks">informasi</h5> 
        </div>
        <section class="isi">
            <a class="nav-link" href="indexPenyakit.php">
            <span>Data Penyakit</span>
            </a>
        </section>
        <section class="isi">
            <a class="nav-link" href="indexGejala.php">
            <span>Data Gejala</span>
            </a>
        </section>
        <section class="isi">
            <a class="nav-link" href="indexSolusi.php">
            <span>Solusi</span>
            </a>
        </section>
        <div class="sidebar-heading">
            <h5 class="font-weight-bold text-white text-uppercase teks">Akun</h5> 
        </div>
        
        <section class="isi">
            <a class="nav-link" href="index.php">
            <span>Logout</span>
            </a>
        </section>
    </div>

    <div class="kanan">
        <div class="container-fluid">
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Ubah Data Penyakit</h1>
            </div>

            <div class="row">
                <form action="function.php?act=ubahPenyakit&id_penyakit=<?= htmlspecialchars($penyakit['id_penyakit']); ?>" method="POST">
                    <div class="form-group">
                        <label for="namaPenyakit">Nama Penyakit</label>
                        <input type="text" class="form-control" id="namaPenyakit" name="namaPenyakit" 
                               value="<?= htmlspecialchars($penyakit['nama_penyakit']); ?>" required>
                        
                        <label for="deskripsi">Deskripsi</label>
                        <textarea class="form-control" id="deskripsi" name="deskripsi" 
                                  required><?= htmlspecialchars($penyakit['deskripsi']); ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Ubah</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>