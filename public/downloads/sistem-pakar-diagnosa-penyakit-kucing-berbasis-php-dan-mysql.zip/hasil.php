<?php
// hasil.php
include 'function.php';

// Check if the reset flag is set
if (isset($_GET['reset']) && $_GET['reset'] == 1) {
    // Reset session variables
    unset($_SESSION['persentase']);
    unset($_SESSION['id_gejala']);
    foreach (['P01', 'P02', 'P03', 'P04', 'P05', 'P06', 'P07', 'P08', 'P09'] as $penyakit) {
        unset($_SESSION[$penyakit]);
    }
    // Redirect to test.php
    header("Location: test.php");
    exit;
}

if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 0) {
        header("location: indexAdmin.php");
        exit;
    } else if ($_SESSION['role'] == 2) {
        header("location: indexPakar.php");
        exit;
    }
} else {
    header("location:index.php");
    exit;
}

$gejala = mysqli_query($koneksi, "SELECT * FROM gejala");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
    rel="stylesheet"
    href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
    crossorigin="anonymous"/>
    <link
    href="https://fonts.googleapis.com/css?family=Poppins:300,400,700&display=swap"
    rel="stylesheet"/>
    <link rel="stylesheet" href="custom.css" />
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
        }
        .navbar {
            background-color: #ffffff;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }
        .list-group-item {
            border-radius: 10px;
            margin-bottom: 10px;
            transition: transform 0.2s;
        }
        .list-group-item:hover {
            transform: scale(1.03);
            background-color: #f1f1f1;
        }
        .btn {
            border-radius: 20px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }
        .hasil {
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        h3, h4 {
            color: #343a40;
        }
        .badge {
            font-size: 16px;
        }
    </style>
    <title>Cek Ginjal Yuk!</title>
</head>
<body>
    <nav class="navbar py-2 navbar-expand-lg navbar-light">
    <div class="container-fluid">
    <h1>PakarKu.</h1>
            <button
            class="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
            >
            <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li>
                    <a class="btn btn-success px-4 py-2 ml-2" href="hasil.php?reset=1" role="button">Cek Ulang</a>
                    </li>
                    <li>
                    <a class="btn btn-primary px-4 py-2 ml-2" href="index.php" role="button">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="hasil mt-4">
        <div class="container">
            <div class="row">
                <div class="col align-self-center">
                    <h3 class="mb-4">Penyakit yang Anda Alami:</h3>
                    <?php
                    if (isset($_SESSION)) {
                        $penyakit = [
                            'P01' => 'Ringworm',
                            'P02' => 'Scabies',
                            'P03' => 'Panleukopenia',
                            'P04' => 'Cacingan',
                            'P05' => 'ISPA',
                            'P06' => 'Diare',
                            'P07' => 'Infeksi Mata',
                            'P08' => 'Feline Calicivirus (FCV)',
                            'P09' => 'Rabies',
                        ];

                        $data_ada = false;
                        $penyakit_tertinggi = '';
                        $persentase_tertinggi = 0;

                        echo '<ul class="list-group mb-4">';
                        foreach ($penyakit as $kode => $nama_penyakit) {
                            $persentase = isset($_SESSION[$kode]) ? $_SESSION[$kode] : 0;
                            $persentase_bulat = round($persentase);

                            if ($persentase_bulat > 0) {
                                $data_ada = true;
                                echo "<li class='list-group-item d-flex justify-content-between align-items-center'>
                                        {$nama_penyakit}
                                        <span class='badge badge-primary badge-pill'>{$persentase_bulat}%</span>
                                      </li>";
                            }

                            if ($persentase_bulat > $persentase_tertinggi) {
                                $persentase_tertinggi = $persentase_bulat;
                                $penyakit_tertinggi = $nama_penyakit;
                            }
                        }
                        echo '</ul>';

                        if (!$data_ada) {
                            echo "<p class='text-danger'>Tidak ada data diagnosa yang ditemukan. Silakan ulangi proses diagnosa.</p>";
                        } else {
                            echo "<h4>Penyakit dengan Persentase Tertinggi: <strong>{$penyakit_tertinggi} = {$persentase_tertinggi}%</strong></h4>";
                        }
                    } else {
                        echo "<p class='text-danger'>Sesi tidak ditemukan. Pastikan proses diagnosa dilakukan terlebih dahulu.</p>";
                    }
                    ?>

                    <h3 class="mb-4">Solusi untuk penyakit anda adalah : </h3>
                    <form action="" method="post" enctype="multipart/form-data" role="form">
                        <?php
                        function maximum($P01, $P02, $P03, $P04, $P05, $P06, $P07, $P08, $P09)
                        {
                            $max = $P01;
                            $kode = 'P01';
                            if ($P02 > $max) { $max = $P02; $kode = 'P02'; }
                            if ($P03 > $max) { $max = $P03; $kode = 'P03'; }
                            if ($P04 > $max) { $max = $P04; $kode = 'P04'; }
                            if ($P05 > $max) { $max = $P05; $kode = 'P05'; }
                            if ($P06 > $max) { $max = $P06; $kode = 'P06'; }
                            if ($P07 > $max) { $max = $P07; $kode = 'P07'; }
                            if ($P08 > $max) { $max = $P08; $kode = 'P08'; }
                            if ($P09 > $max) { $max = $P09; $kode = 'P09'; }
                            return $kode;
                        }

                        $id_penyakit = maximum(
                            isset($_SESSION['P01']) ? $_SESSION['P01'] : 0,
                            isset($_SESSION['P02']) ? $_SESSION['P02'] : 0,
                            isset($_SESSION['P03']) ? $_SESSION['P03'] : 0,
                            isset($_SESSION['P04']) ? $_SESSION['P04'] : 0,
                            isset($_SESSION['P05']) ? $_SESSION['P05'] : 0,
                            isset($_SESSION['P06']) ? $_SESSION['P06'] : 0,
                            isset($_SESSION['P07']) ? $_SESSION['P07'] : 0,
                            isset($_SESSION['P08']) ? $_SESSION['P08'] : 0,
                            isset($_SESSION['P09']) ? $_SESSION['P09'] : 0
                        );

                        $query = "SELECT * FROM solusi WHERE id_penyakit = '$id_penyakit'";
                        $data = mysqli_query($koneksi, $query);
                        if ($data) {
                            while ($row = mysqli_fetch_array($data)) {
                                echo '<p>' . $row['solusi'] . '</p>';
                            }
                        } else {
                            echo '<p class="text-danger">Tidak ada solusi yang ditemukan untuk penyakit ini.</p>';
                        }
                        ?>
                    </form>
                </div>
                <div class="col d-none d-sm-block">
                    <img width="500" src="gambar/kucing1.png" alt="hero" />
                </div>
            </div>
        </div>
    </section>
</body>
<script
    src="https://code.jquery.com/jquery-3.4.1.js"
    integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
    crossorigin="anonymous"
></script>
<script
    src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
    crossorigin="anonymous"
></script>
<script
    src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
    crossorigin="anonymous"
></script>
<script
    src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
    crossorigin="anonymous"
></script>
</html>