<?php 
include 'function.php';
if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 0) {
        header("location: indexAdmin.php");
    } else if ($_SESSION['role'] == 1) {
        header("location: test.php");
    } else if ($_SESSION['role'] == 2) {
        header("location: indexPakar.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Cek Kucingmu Yuk! - Registrasi</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #4A90E2;
            --secondary-color: #F5F7FA;
            --text-color: #2D3748;
            --error-color: #E53E3E;
            --success-color: #48BB78;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            padding: 2rem 0;
        }

        .container {
            max-width: 480px;
        }

        .card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            background: white;
            padding: 2rem;
        }

        .card-title {
            color: var(--text-color);
            font-weight: 600;
            margin-bottom: 2rem;
            font-size: 1.75rem;
        }

        .form-control {
            border-radius: 8px;
            padding: 0.75rem 1rem;
            border: 2px solid var(--secondary-color);
            transition: all 0.3s ease;
            margin-bottom: 1rem;
        }

        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(74, 144, 226, 0.1);
        }

        .papan {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--text-color);
            font-weight: 500;
            font-size: 0.875rem;
        }

        .registerbtn {
            background-color: var(--primary-color);
            border: none;
            border-radius: 8px;
            padding: 0.75rem 2rem;
            font-weight: 600;
            margin-top: 1rem;
            width: 100%;
            transition: all 0.3s ease;
        }

        .registerbtn:hover {
            background-color: #357ABD;
            transform: translateY(-1px);
        }

        .signin {
            margin-top: 1.5rem;
            text-align: center;
            color: var(--text-color);
        }

        .signin a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
        }

        .signin a:hover {
            text-decoration: underline;
        }

        .valid-feedback {
            color: var(--success-color);
        }

        .invalid-feedback {
            color: var(--error-color);
        }

        .form-row {
            margin-bottom: 1rem;
        }

        @media (max-width: 576px) {
            .container {
                padding: 0 1rem;
            }
            
            .card {
                padding: 1.5rem;
            }
            
            .card-title {
                font-size: 1.5rem;
            }
        }

        .was-validated .form-control:valid {
            border-color: var(--success-color);
            background-image: none;
        }

        .was-validated .form-control:invalid {
            border-color: var(--error-color);
            background-image: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1 class="card-title text-center">Halaman Registrasi</h1>
            <form id="registrationForm" method="POST" action="function.php?act=register" class="needs-validation" novalidate>
                <div class="form-row">
                    <div class="col">
                        <label class="papan" for="nama">Nama Pasien</label>
                        <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukkan nama lengkap" required>
                        <div class="valid-feedback">Bagus!</div>
                        <div class="invalid-feedback">Nama tidak boleh kosong</div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col">
                        <label class="papan" for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="nama@email.com" required>
                        <div class="valid-feedback">Bagus!</div>
                        <div class="invalid-feedback">Email tidak valid</div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col">
                        <label class="papan" for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" minlength="8" placeholder="Minimal 8 karakter" required>
                        <div class="valid-feedback">Bagus!</div>
                        <div class="invalid-feedback">Password min. 8 karakter</div>
                    </div>
                </div>
                <button type="submit" name="submitButton" id="submitButton" class="registerbtn btn btn-primary">Daftar Sekarang</button>
                <div class="signin">
                    <p>Sudah punya akun? <a href="index.php">Masuk di sini</a></p>
                </div>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script>
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
    </script>
</body>
</html>

