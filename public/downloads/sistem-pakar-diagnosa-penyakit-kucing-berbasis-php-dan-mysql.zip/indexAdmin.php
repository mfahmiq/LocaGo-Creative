<?php


include "function.php";
if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 1) {
        header("location: test.php");
    }
} else {
    header("location:index.php");
}

$queryPasien = mysqli_query($koneksi, "SELECT * FROM pengguna WHERE role = '1'");

$jumlahPasien = mysqli_query($koneksi, "SELECT COUNT('id_pengguna') as jml_pasien FROM pengguna WHERE role='1'");
$pasien = mysqli_fetch_assoc($jumlahPasien);

$jumlahPenyakit = mysqli_query($koneksi, "SELECT COUNT('id_penyakit') as jml_penyakit FROM penyakit");
$penyakit = mysqli_fetch_assoc($jumlahPenyakit);

$jumlahGejala = mysqli_query($koneksi, "SELECT COUNT('id_gejala') as jml_gejala FROM gejala");
$gejala = mysqli_fetch_assoc($jumlahGejala);

$jumlahSolusi = mysqli_query($koneksi, "SELECT COUNT('id_solusi') as jml_solusi FROM solusi");
$solusi = mysqli_fetch_assoc($jumlahSolusi);


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="styles.css">
    <link
        rel="stylesheet"
        href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
        crossorigin="anonymous"/>
    <link
        href="https://fonts.googleapis.com/css?family=Poppins:300,400,700&display=swap"
        rel="stylesheet"/>
    
<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Poppins', sans-serif;
    display: flex; /* Atur layout dengan flexbox */
    background-color: #f8f9fc;
}

/* Sidebar */
.kiri {
    width: 250px; /* Lebar sidebar */
    height: 100vh;
    background-color: #2c3e50;
    color: #ecf0f1;
    position: fixed; /* Sidebar tetap di sisi kiri */
    padding: 20px 10px;
    box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
}

.kiri h2 {
    text-align: center;
    margin-bottom: 30px;
}

.kiri .sidebar-heading {
    margin: 20px 0 10px;
    font-size: 0.9rem;
    text-transform: uppercase;
    font-weight: bold;
    color: #bdc3c7;
}

.kiri .isi a {
    text-decoration: none;
    color: #ecf0f1;
    display: block;
    padding: 10px 15px;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.kiri .isi a:hover {
    background-color: #34495e;
}

/* Konten Utama */
.kanan {
    margin-left: 270px; /* Beri jarak dengan lebar sidebar */
    padding: 20px;
    width: calc(100% - 270px); /* Sesuaikan lebar konten utama */
    background-color: #f8f9fc;
}

.card {
    background: #ffffff;
    border: 1px solid #e3e6f0;
    border-radius: 10px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    padding: 20px;
    text-align: center;
    margin-bottom: 20px;
}

.card h6 {
    font-size: 1.2rem;
    color: #4e73df;
    margin-bottom: 10px;
}

.card p {
    font-size: 1.5rem;
    color: #1cc88a;
    font-weight: bold;
}

.table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    background: #ffffff;
    border: 1px solid #e3e6f0;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.table th, .table td {
    padding: 12px 15px;
    text-align: left;
}

.table th {
    background-color: #4e73df;
    color: #ffffff;
}

.table tr:nth-child(even) {
    background-color: #f9f9f9;
}

.table tr:hover {
    background-color: #f1f1f1;
}

.badge {
    padding: 5px 10px;
    border-radius: 5px;
    color: #ffffff;
    text-decoration: none;
    cursor: pointer;
}

.badge-primary {
    background-color: #4e73df;
}

.badge-danger {
    background-color: #e74a3b;
}

.badge-primary:hover {
    background-color: #375a7f;
}

.badge-danger:hover {
    background-color: #c0392b;
}
</style>


</head>

<body >
    <div class="kiri">
        <section class="logo">
           <h2>PakarKu.</h2>
        </section>
        <div class="sidebar-heading">
            <h5 class="font-weight-bold text-white text-uppercase teks">Data Pasien</h5>
        </div>
        <section class="isi">
            <a class="nav-link" href="indexAdmin.php">
            <span>Data Pasien</span></a>
        </section>
        
        <div class="sidebar-heading">
            <h5 class="font-weight-bold text-white text-uppercase teks">informasi</h5> 
        </div>
        <section class="isi">
            <a class="nav-link" href="indexPenyakit.php">
            <span>Data Penyakit</span>
            </a>
        </section>
        <section class="isi">
            <a class="nav-link" href="indexGejala.php">
            <span>Data Gejala</span>
            </a>
        </section>
        <section class="isi">
            <a class="nav-link" href="indexSolusi.php">
            <span>Solusi</span>
            </a>
        </section>
        <div class="sidebar-heading">
            <h5 class="font-weight-bold text-white text-uppercase teks">Akun</h5> 
        </div>
        
        <section class="isi">
            <a class="nav-link" href="index.php">
            <span>Logout</span>
            </a>
        </section>
    </div>

    <div class="kanan">
    <div class="container-fluid">

<!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    </div>

<!-- Content Row -->
<div class="row">


<div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
            <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Data Pasien</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $pasien['jml_pasien']; ?></div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-success shadow h-100 py-2">
        <div class="card-body">
            <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Data Penyakit</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $penyakit['jml_penyakit']; ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-info shadow h-100 py-2">
        <div class="card-body">
            <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Data Gejala</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $gejala['jml_gejala']; ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-warning shadow h-100 py-2">
        <div class="card-body">
            <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Data Solusi</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $solusi['jml_solusi']; ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- DataTales Example -->
<div class="card shadow  ml-3 mb-12">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Tabel Data Pasien</h6>
        <a href="tambahPasien.php" class="btn btn-primary mt-3">Tambah Pasien</a>
    </div>
    <div class="card-body">
        <form method="post" encytpe="multipart/form-data">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <?php if($_SESSION['role'] == 1) {
                        echo'<th>Aksi</th>';
                        }?>
                        <th>Aksi</th>
                        <th>Nama</th>
                        <th>Email</th>                      
                        <th>Username</th>
                    </tr>
                </thead>
            <tbody>
                <?php while ($data = mysqli_fetch_assoc($queryPasien)) { ?>
                <tr>
                    <td>
                    <a class="badge badge-pill badge-primary" href="ubahPasien.php?id_pengguna=<?php echo $data["id_pengguna"]; ?>">edit</a> |
                    <a href="function.php?act=hapusPasien&id_pengguna=<?= $data["id_pengguna"]; ?>" onclick="return confirm('Yakin ingin menghapus data?');" class="badge badge-pill badge-danger">hapus</a>
                    </td>
                    <td><?= $data['nama']; ?></td>
                    <td><?= $data['email']; ?></td>
                    
                    <td><?= $data['nama']; ?></td>
                </tr>
                <?php } ?>
            </tbody>
            </table>
        </form>
    </div>
</div>

</body>

</html>