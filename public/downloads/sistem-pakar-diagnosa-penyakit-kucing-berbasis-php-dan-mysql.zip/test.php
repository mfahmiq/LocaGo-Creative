<?php
include 'function.php';

// Cek dan arahkan berdasarkan peran pengguna
if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 0) {
        header("location: indexAdmin.php");
        exit;
    } else if ($_SESSION['role'] == 2) {
        header("location: indexPakar.php");
        exit;
    }
}

// Inisialisasi sesi jika pertama kali atau setelah reset
if (!isset($_SESSION['persentase']) || !isset($_SESSION['id_gejala'])) {
    $_SESSION['persentase'] = [];
    $_SESSION['id_gejala'] = 'G01'; // Mulai dari gejala pertama
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $persentase = $_SESSION['persentase'];

    // Simpan ID gejala saat ini
    $current_gejala = intval(substr($_SESSION['id_gejala'], 1));

    // Jika jawaban "Ya", tambahkan ID ke persentase
    if (isset($_POST['ya'])) {
        $persentase[] = $_SESSION['id_gejala'];
    }

    $_SESSION['persentase'] = $persentase;

    // Hitung ID gejala berikutnya
    $next_gejala = $current_gejala + 1;
    $_SESSION['id_gejala'] = sprintf('G%02d', $next_gejala);

    // Jika melebihi G18, arahkan ke hasil
    if ($next_gejala > 18) {
        // Ambil data penyakit dan gejala dari database
        $query_penyakit = "SELECT * FROM penyakit";
        $result_penyakit = mysqli_query($koneksi, $query_penyakit);
    
        $penyakit_scores = [];
    
        while ($penyakit = mysqli_fetch_assoc($result_penyakit)) {
            $id_penyakit = $penyakit['id_penyakit'];
    
            // Ambil gejala terkait penyakit
            $query_gejala = "SELECT id_gejala FROM aturan WHERE id_penyakit = '$id_penyakit'";
            $result_gejala = mysqli_query($koneksi, $query_gejala);
            $gejala_terkait = [];
            while ($row = mysqli_fetch_assoc($result_gejala)) {
                $gejala_terkait[] = $row['id_gejala'];
            }
    
            // Hitung skor
            $nilai = 0;
            foreach ($_SESSION['persentase'] as $value) {
                if (in_array($value, $gejala_terkait)) {
                    $nilai += 1;
                }
            }
            
            // Hindari pembagian dengan nol
            $total_gejala = count($gejala_terkait);
            if ($total_gejala > 0) {
                $penyakit_scores[$id_penyakit] = ($nilai / $total_gejala) * 100;
            } else {
                $penyakit_scores[$id_penyakit] = 0;
            }
        }
    
        // Simpan skor ke dalam sesi
        foreach ($penyakit_scores as $id_penyakit => $score) {
            $_SESSION[$id_penyakit] = $score;
        }
    
        // Simpan hasil ke sesi
        $_SESSION['hasil_diagnosa'] = $penyakit_scores;
        header('Location: hasil.php');
        exit;
    }
}

// Ambil nama gejala berdasarkan ID gejala saat ini
$id_gejala = $_SESSION['id_gejala'];
$nama_gejala = "Data gejala tidak tersedia.";

$data = mysqli_query($koneksi, "SELECT nama_gejala FROM gejala WHERE id_gejala = '$id_gejala'");
if ($data && $row = mysqli_fetch_assoc($data)) {
    $nama_gejala = $row['nama_gejala'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="custom.css">
    <title>Cek Kucingmu Yuk!</title>
</head>
<body>
    <nav class="navbar py-2 navbar-expand-lg navbar-light">
    <div class="container-fluid">
    <h1>PakarKu.</h1>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li>
                        <a class="btn px-4 btn-primary ml-2" href="logout.php" role="button">Log Out</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <section class="test mt-5">
        <div class="container">
            <div class="row">
                <div class="col align-self-center">
                    <h2 class="mb-4">Pertanyaan :</h2>
                    <form action="" method="post">
                        <p class="mb-4">Apakah kucing anda mengalami <?= htmlspecialchars($nama_gejala); ?> ?</p>
                        <input type="submit" class="btn btn-primary mr-2 px-4 py-2" name="ya" value="Ya">
                        <input type="submit" class="btn btn-danger px-3 py-2" name="tidak" value="Tidak">
                    </form>
                </div>
                <div class="col d-none d-sm-block">
                    <img width="500" src="gambar/kucing1.png" alt="hero">
                </div>
            </div>
        </div>
    </section>
</body>
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</html>