<?php
// 1. Pindahkan session_start() ke paling atas sebelum melakukan operasi apapun
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$koneksi = mysqli_connect('localhost', 'root', '', 'kucing');

if (mysqli_connect_errno()) {
    echo "Koneksi Database Gagal : " . mysqli_connect_error();
}

if (isset($_GET["act"])) {
    $act = $_GET["act"];
    if ($act == "register") {
        register();
    } else if ($act == "login") {
        login();
    } else if ($act == "tambahGejala") {
        tambahGejala();
    } else if ($act == "tambahPenyakit") {
        tambahPenyakit();
    } else if ($act == "tambahAturan") {
        tambahAturan();
    } else if ($act == "hapusGejala") {
        $id_gejala = $_GET["id_gejala"];
        hapusGejala($id_gejala);
    } else if ($act == "hapusPenyakit") {
        $id_penyakit = $_GET["id_penyakit"];
        hapusPenyakit($id_penyakit);
    } else if ($act == "hapusAturan") {
        $id_aturan = $_GET["id_aturan"];
        hapusAturan($id_aturan);
    } else if ($act == "ubahGejala") {
        $id_gejala = $_GET["id_gejala"];
        ubahGejala($id_gejala);
    } else if ($act == "ubahPenyakit") {
        $id_penyakit = $_GET["id_penyakit"];
        ubahPenyakit($id_penyakit);
    } else if ($act == "diagnosa") {
        diagnosa();
    } else if ($act == "ulang") {
        ulang();
    }
}

function ulang() {
    session_unset();
    session_destroy();
    header("location: index.php");
    exit; // Tambahkan exit setelah redirect
}

function register() {
    global $koneksi;
    $nama = htmlspecialchars($_POST['nama']);
    $email = htmlspecialchars($_POST['email']);
    $password = password_hash(htmlspecialchars($_POST['password']), PASSWORD_DEFAULT);

    // Tambahkan pengecekan email duplikat
    $check_email = mysqli_query($koneksi, "SELECT * FROM pengguna WHERE email = '$email'");
    if(mysqli_num_rows($check_email) > 0) {
        echo "<script>alert('Email sudah terdaftar!');document.location.href = 'index.php';</script>";
        return;
    }

    $query = "INSERT INTO pengguna (nama, email, password) VALUES ('$nama', '$email', '$password')";
    $exe = mysqli_query($koneksi, $query);

    if (!$exe) {
        die('Query Error : ' . mysqli_error($koneksi));
    } else {
        echo "<script>alert('Berhasil Registrasi! Silahkan Login');document.location.href = 'index.php';</script>";
    }
}

function registerPakar()
{
    global $koneksi;
    
    try {
        $nama = htmlspecialchars($_POST['nama']);
        $email = htmlspecialchars($_POST['email']);
        $password = password_hash(htmlspecialchars($_POST['password']), PASSWORD_DEFAULT);
        $role = 2; // role untuk pakar
        
        // Cek apakah email sudah terdaftar
        $check_email = mysqli_query($koneksi, "SELECT email FROM pengguna WHERE email = '$email'");
        if(mysqli_num_rows($check_email) > 0) {
            throw new Exception("Email sudah terdaftar!");
        }
        
        // Gunakan prepared statement untuk keamanan
        $query = "INSERT INTO pengguna (role, nama, email, password) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($koneksi, $query);
        mysqli_stmt_bind_param($stmt, "isss", $role, $nama, $email, $password);
        $exe = mysqli_stmt_execute($stmt);
        
        if ($exe) {
            echo "<script>
                    alert('Berhasil Registrasi Pakar! Segera beritahu pakar untuk Login');
                    document.location.href = 'indexPakar.php';
                  </script>";
        } else {
            throw new Exception(mysqli_error($koneksi));
        }
    } catch (Exception $e) {
        echo "<script>
                alert('Gagal registrasi: " . $e->getMessage() . "');
                document.location.href = 'register_pakar.php';
              </script>";
    }
}

function login() {
    global $koneksi;

    $email = htmlspecialchars($_POST['email']);
    $input_pass = htmlspecialchars($_POST['password']);

    // Ambil data pengguna berdasarkan email
    $query = mysqli_query($koneksi, "SELECT * FROM pengguna WHERE email = '$email'");
    $data = mysqli_fetch_assoc($query);

    // Jika data ditemukan
    if ($data) {
        $password = $data['password'];
        $role = $data['role'];

        // Verifikasi password
        if (password_verify($input_pass, $password)) {
            if ($role == "1") {
                $_SESSION['role'] = 1;
                echo "<script>
                document.location.href = 'test.php';
                </script>";
            } elseif ($role == "0") {
                $_SESSION['role'] = 0;
                echo "<script>
                document.location.href = 'indexAdmin.php';
                </script>";
            } elseif ($role == "2") {
                $_SESSION['role'] = 2;
                echo "<script>
                document.location.href = 'indexAdmin.php';
                </script>";
            }
        } else {
            echo "<script>
                alert('Password salah!');
                document.location.href = 'index.php';
                </script>";
        }
    } else {
        echo "<script>
            alert('Email tidak ditemukan!');
            document.location.href = 'index.php';
            </script>";
    }
}



function tambahGejala() {
    global $koneksi;

    // Ambil data dari form
    $id_gejala = htmlspecialchars($_POST['idGejala']);
    $nama_gejala = htmlspecialchars($_POST['namaGejala']);

    // Pengecekan apakah ID Gejala sudah ada
    $queryCheck = "SELECT * FROM gejala WHERE id_gejala = '$id_gejala'";
    $resultCheck = mysqli_query($koneksi, $queryCheck);

    if (mysqli_num_rows($resultCheck) > 0) {
        // Jika ID sudah ada, tampilkan pesan error
        echo "<script>alert('Maaf, ID Gejala sudah digunakan.');history.go(-1);</script>";
        exit; // Menghentikan proses lebih lanjut
    }

    // Query untuk menambahkan data baru ke tabel gejala
    $query = "INSERT INTO gejala (id_gejala, nama_gejala) VALUES ('$id_gejala', '$nama_gejala')";

    // Eksekusi query
    $exe = mysqli_query($koneksi, $query);

    if (!$exe) {
        die('Error: ' . mysqli_error($koneksi));
    } else {
        echo "<script>alert('Gejala berhasil ditambahkan');document.location.href = 'indexGejala.php';</script>";
    }
}



function ubahGejala($id_gejala) {
    global $koneksi;
    
    // Validasi input
    if (!isset($_POST['nama_gejala'])) {
        echo "<script>alert('Nama gejala tidak boleh kosong');history.go(-1);</script>";
        return;
    }
    
    $nama_gejala = mysqli_real_escape_string($koneksi, htmlspecialchars($_POST['nama_gejala']));

    $query = "UPDATE gejala SET nama_gejala = '$nama_gejala' WHERE id_gejala = '$id_gejala'";
              
    $exe = mysqli_query($koneksi, $query);

    if (!$exe) {
        die('Error: ' . mysqli_error($koneksi));
    } else {
        echo "<script>alert('Gejala berhasil diubah');document.location.href = 'indexGejala.php';</script>";
    }
}

function hapusGejala($id_gejala) {
    global $koneksi;
    $query = "DELETE FROM gejala WHERE id_gejala = '$id_gejala'";
    $exe = mysqli_query($koneksi, $query);

    if ($exe) {
        echo "<script>alert('Gejala berhasil dihapus');document.location.href = 'indexGejala.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus gejala');document.location.href = 'indexGejala.php';</script>";
    }
}

function tambahPenyakit() {
    global $koneksi;
    
    try {
        // Validasi input
        if (empty($_POST['namaPenyakit']) || empty($_POST['deskripsi'])) {
            throw new Exception("Nama penyakit dan deskripsi harus diisi!");
        }

        $nama_penyakit = mysqli_real_escape_string($koneksi, $_POST['namaPenyakit']);
        $deskripsi = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);
        
        // Generate ID Penyakit baru (P01, P02, dst)
        $query_id = "SELECT MAX(CAST(SUBSTRING(id_penyakit, 2) AS SIGNED)) as max_id FROM penyakit";
        $result = mysqli_query($koneksi, $query_id);
        $row = mysqli_fetch_assoc($result);
        $next_id = $row['max_id'] + 1;
        $id_penyakit = 'P' . str_pad($next_id, 2, '0', STR_PAD_LEFT);
        
        // Cek apakah penyakit sudah ada
        $stmt_check = mysqli_prepare($koneksi, "SELECT nama_penyakit FROM penyakit WHERE nama_penyakit = ?");
        mysqli_stmt_bind_param($stmt_check, "s", $nama_penyakit);
        mysqli_stmt_execute($stmt_check);
        mysqli_stmt_store_result($stmt_check);
        
        if(mysqli_stmt_num_rows($stmt_check) > 0) {
            throw new Exception("Penyakit sudah ada dalam database!");
        }
        
        // Insert penyakit baru
        $query = "INSERT INTO penyakit (id_penyakit, nama_penyakit, deskripsi) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($koneksi, $query);
        mysqli_stmt_bind_param($stmt, "sss", $id_penyakit, $nama_penyakit, $deskripsi);
        $exe = mysqli_stmt_execute($stmt);
        
        if ($exe) {
            echo "<script>
                    alert('Penyakit berhasil ditambahkan');
                    window.location.href = 'indexPenyakit.php';
                  </script>";
        } else {
            throw new Exception(mysqli_error($koneksi));
        }
        
        // Close statements
        mysqli_stmt_close($stmt_check);
        mysqli_stmt_close($stmt);
        
    } catch (Exception $e) {
        echo "<script>
                alert('Gagal menambah penyakit: " . htmlspecialchars($e->getMessage()) . "');
                window.location.href = 'indexPenyakit.php';
              </script>";
    }
}

function ubahPenyakit($id_penyakit) {
    global $koneksi;
    
    try {
        // Validasi id_penyakit
        if (empty($id_penyakit)) {
            throw new Exception("ID Penyakit tidak boleh kosong");
        }
        
        // Ambil data dari form
        $nama_penyakit = mysqli_real_escape_string($koneksi, $_POST['namaPenyakit']);
        $deskripsi = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);
        
        // Persiapkan query dengan WHERE clause yang spesifik
        $query = "UPDATE penyakit SET nama_penyakit = ?, deskripsi = ? WHERE id_penyakit = ?";
        
        // Prepare statement
        $stmt = mysqli_prepare($koneksi, $query);
        if (!$stmt) {
            throw new Exception(mysqli_error($koneksi));
        }
        
        // Bind parameter (ssi = string, string, string)
        mysqli_stmt_bind_param($stmt, "sss", $nama_penyakit, $deskripsi, $id_penyakit);
        
        // Execute statement
        $exe = mysqli_stmt_execute($stmt);
        
        if ($exe) {
            echo "<script>
                    alert('Data penyakit berhasil diubah');
                    window.location.href = 'indexPenyakit.php';
                  </script>";
        } else {
            throw new Exception("Gagal mengubah data penyakit");
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
        
    } catch (Exception $e) {
        echo "<script>
                alert('Error: " . htmlspecialchars($e->getMessage()) . "');
                window.location.href = 'indexPenyakit.php';
              </script>";
    }
}

function hapusPenyakit($id_penyakit) {
    global $koneksi;
    
    try {
        // Validasi id_penyakit
        if (empty($id_penyakit)) {
            throw new Exception("ID Penyakit tidak boleh kosong");
        }

        // Mulai transaction untuk memastikan integritas data
        mysqli_begin_transaction($koneksi);

        // Hapus data di tabel aturan terlebih dahulu karena memiliki foreign key
        $query_aturan = "DELETE FROM aturan WHERE id_penyakit = ?";
        $stmt_aturan = mysqli_prepare($koneksi, $query_aturan);
        mysqli_stmt_bind_param($stmt_aturan, "s", $id_penyakit);
        mysqli_stmt_execute($stmt_aturan);

        // Hapus data di tabel solusi
        $query_solusi = "DELETE FROM solusi WHERE id_penyakit = ?";
        $stmt_solusi = mysqli_prepare($koneksi, $query_solusi);
        mysqli_stmt_bind_param($stmt_solusi, "s", $id_penyakit);
        mysqli_stmt_execute($stmt_solusi);

        // Hapus data di tabel penyakit
        $query_penyakit = "DELETE FROM penyakit WHERE id_penyakit = ?";
        $stmt_penyakit = mysqli_prepare($koneksi, $query_penyakit);
        mysqli_stmt_bind_param($stmt_penyakit, "s", $id_penyakit); // Ubah "i" menjadi "s" karena id_penyakit adalah VARCHAR
        $exe = mysqli_stmt_execute($stmt_penyakit);
        
        if ($exe) {
            mysqli_commit($koneksi);
            echo "<script>
                    alert('Penyakit berhasil dihapus');
                    window.location.href = 'indexPenyakit.php';
                  </script>";
        } else {
            throw new Exception(mysqli_error($koneksi));
        }

        // Close semua statement
        mysqli_stmt_close($stmt_aturan);
        mysqli_stmt_close($stmt_solusi);
        mysqli_stmt_close($stmt_penyakit);

    } catch (Exception $e) {
        mysqli_rollback($koneksi);
        echo "<script>
                alert('Gagal menghapus penyakit: " . htmlspecialchars($e->getMessage()) . "');
                window.location.href = 'indexPenyakit.php';
              </script>";
    }
}

function tambahAturan() {
    global $koneksi;
    $id_aturan = htmlspecialchars($_POST['id_aturan']);
    $id_penyakit = htmlspecialchars($_POST['id_penyakit']);
    $id_gejala = htmlspecialchars($_POST['id_gejala']);

    $query = "INSERT INTO aturan (id_aturan, id_penyakit, id_gejala) VALUES ('$id_aturan', '$id_penyakit', '$id_gejala')";
    $exe = mysqli_query($koneksi, $query);

    if (!$exe) {
        die('Error: ' . mysqli_error($koneksi));
    } else {
        echo "<script>alert('Aturan berhasil ditambahkan');document.location.href = 'indexAturan.php';</script>";
    }
}

function hapusAturan($id_aturan) {
    global $koneksi;
    $query = "DELETE FROM aturan WHERE id_aturan = '$id_aturan'";
    $exe = mysqli_query($koneksi, $query);

    if ($exe) {
        echo "<script>alert('Aturan berhasil dihapus');document.location.href = 'indexAturan.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus aturan');document.location.href = 'indexAturan.php';</script>";
    }
}


function ubahPasien($id_pengguna)
{
    global $koneksi;

    $nama = htmlspecialchars($_POST['nama']);
    $email = htmlspecialchars($_POST['email']);

    $queryUser = "UPDATE pengguna SET nama = '$nama', email = '$email' WHERE id_pengguna = '$id_pengguna'";
    $exe = mysqli_query($koneksi, $queryUser);
    
    if (!$exe) {
        echo "<script>
                alert('Gagal mengubah data: " . mysqli_error($koneksi) . "');
                document.location.href = 'indexAdmin.php';
              </script>";
        return;
    }

    echo "<script>
            alert('Data Pasien berhasil diubah!');
            document.location.href = 'indexAdmin.php';
          </script>";
}

function ubahPakar($id_pengguna)
{
    global $koneksi;

    $nama = htmlspecialchars($_POST['nama']);
    $email = htmlspecialchars($_POST['email']);

    try {
        $query = "UPDATE pengguna SET nama = ?, email = ? WHERE id_pengguna = ?";
        $stmt = mysqli_prepare($koneksi, $query);
        mysqli_stmt_bind_param($stmt, "ssi", $nama, $email, $id_pengguna);
        $exe = mysqli_stmt_execute($stmt);
        
        if ($exe) {
            echo "<script>
                    alert('Data Pakar berhasil diubah!');
                    document.location.href = 'indexPakar.php';
                  </script>";
        } else {
            throw new Exception(mysqli_error($koneksi));
        }
    } catch (Exception $e) {
        echo "<script>
                alert('Gagal mengubah data: " . $e->getMessage() . "');
                document.location.href = 'indexPakar.php';
              </script>";
    }
}

function tambahPasien() {
    global $koneksi;

    $nama = htmlspecialchars($_POST['nama']);
    $email = htmlspecialchars($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = '1'; // 1 untuk role pasien

    // Cek apakah email sudah ada
    $cek_email = mysqli_query($koneksi, "SELECT * FROM pengguna WHERE email = '$email'");
    if(mysqli_num_rows($cek_email) > 0) {
        echo "<script>
                alert('Email sudah digunakan!');
                document.location.href = 'tambahPasien.php';
              </script>";
        return;
    }

    // Query untuk menambah pasien
    $query = "INSERT INTO pengguna (nama, email, password, role) 
              VALUES ('$nama', '$email', '$password', '$role')";
    
    $exe = mysqli_query($koneksi, $query);

    if($exe) {
        echo "<script>
                alert('Data Pasien berhasil ditambahkan!');
                document.location.href = 'indexAdmin.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menambahkan data: " . mysqli_error($koneksi) . "');
                document.location.href = 'tambahPasien.php';
              </script>";
    }
}

function hapusPasien($id_pengguna)
{
    global $koneksi;
    mysqli_query($koneksi, "DELETE FROM pengguna WHERE id_pengguna = $id_pengguna");
    $result = mysqli_affected_rows($koneksi);
    
    if ($result > 0) {
        echo "<script>
                alert('Akun Pasien berhasil dihapus!');
                document.location.href = 'indexAdmin.php';
              </script>";
    } else {
        echo "<script>
                alert('Akun Pasien gagal dihapus!');
                document.location.href = 'indexAdmin.php';
              </script>";
    }
}

function tambahSolusi()
{
    global $koneksi;
    
    // Validate inputs
    if(empty($_POST['namaSolusi']) || empty($_POST['id_penyakit'])) {
        echo "<script>
            alert('Semua field harus diisi!');
            history.back();</script>";
        return;
    }
    
    $solusi = mysqli_real_escape_string($koneksi, htmlspecialchars($_POST['namaSolusi']));
    $id_penyakit = mysqli_real_escape_string($koneksi, htmlspecialchars($_POST['id_penyakit']));
    
    // Verify penyakit exists
    $check = mysqli_query($koneksi, "SELECT id_penyakit FROM penyakit WHERE id_penyakit = '$id_penyakit'");
    if(mysqli_num_rows($check) == 0) {
        echo "<script>
            alert('Penyakit tidak ditemukan!');
            history.back();</script>";
        return;
    }
    
    // Insert solusi
    $querySolusi = "INSERT INTO solusi (id_penyakit, solusi) VALUES (?, ?)";
    $stmt = mysqli_prepare($koneksi, $querySolusi);
    mysqli_stmt_bind_param($stmt, "ss", $id_penyakit, $solusi);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "<script>
            alert('Solusi berhasil ditambahkan');
            document.location.href = 'indexSolusi.php';</script>";
    } else {
        echo "<script>
            alert('Error: " . mysqli_error($koneksi) . "');
            history.back();</script>";
    }
    mysqli_stmt_close($stmt);
}

function ubahSolusi($id_solusi)
{
    global $koneksi;
    
    // Validate inputs
    if(empty($_POST['namaSolusi']) || empty($_POST['id_penyakit']) || empty($id_solusi)) {
        echo "<script>
            alert('Semua field harus diisi!');
            history.back();</script>";
        return;
    }
    
    $solusi = mysqli_real_escape_string($koneksi, htmlspecialchars($_POST['namaSolusi']));
    $id_penyakit = mysqli_real_escape_string($koneksi, htmlspecialchars($_POST['id_penyakit']));
    $id_solusi = mysqli_real_escape_string($koneksi, htmlspecialchars($id_solusi));
    
    // Verify solusi exists
    $check = mysqli_query($koneksi, "SELECT id_solusi FROM solusi WHERE id_solusi = '$id_solusi'");
    if(mysqli_num_rows($check) == 0) {
        echo "<script>
            alert('Solusi tidak ditemukan!');
            history.back();</script>";
        return;
    }
    
    // Update solusi
    $querySolusi = "UPDATE solusi SET solusi = ?, id_penyakit = ? WHERE id_solusi = ?";
    $stmt = mysqli_prepare($koneksi, $querySolusi);
    mysqli_stmt_bind_param($stmt, "sss", $solusi, $id_penyakit, $id_solusi);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "<script>
            alert('Data Solusi berhasil diubah!');
            document.location.href = 'indexSolusi.php';</script>";
    } else {
        echo "<script>
            alert('Error: " . mysqli_error($koneksi) . "');
            history.back();</script>";
    }
    mysqli_stmt_close($stmt);
}

function hapusSolusi($id_solusi)
{
    global $koneksi;
    
    if(empty($id_solusi)) {
        echo "<script>
            alert('ID Solusi tidak valid!');
            document.location.href = 'indexSolusi.php';</script>";
        return;
    }
    
    $id_solusi = mysqli_real_escape_string($koneksi, htmlspecialchars($id_solusi));
    
    // Verify solusi exists
    $check = mysqli_query($koneksi, "SELECT id_solusi FROM solusi WHERE id_solusi = '$id_solusi'");
    if(mysqli_num_rows($check) == 0) {
        echo "<script>
            alert('Solusi tidak ditemukan!');
            document.location.href = 'indexSolusi.php';</script>";
        return;
    }
    
    // Delete solusi
    $query = "DELETE FROM solusi WHERE id_solusi = ?";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "s", $id_solusi);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "<script>
            alert('Solusi berhasil dihapus!');
            document.location.href = 'indexSolusi.php';</script>";
    } else {
        echo "<script>
            alert('Error: " . mysqli_error($koneksi) . "');
            document.location.href = 'indexSolusi.php';</script>";
    }
    mysqli_stmt_close($stmt);
}


// Menangani routing berdasarkan parameter 'act'
if (isset($_GET['act'])) {
    switch ($_GET['act']) {
        case 'ubahPasien':
            if (isset($_GET['id_pengguna'])) {
                ubahPasien($_GET['id_pengguna']);
            }
        break;
        case 'tambahPasien':
            tambahPasien();
        break;
        case 'hapusPasien':
                if (isset($_GET['id_pengguna'])) {
                    hapusPasien($_GET['id_pengguna']);
                }
        break;

        case 'ubahPakar':
            if (isset($_GET['id_pengguna'])) {
                ubahPakar($_GET['id_pengguna']);
            }
        break;
        case 'registerPakar':
            registerPakar();
            break;
            case 'tambahPenyakit':
                tambahPenyakit();
                break;
            case 'ubahPenyakit':
                if (isset($_GET['id_penyakit'])) {
                    ubahPenyakit($_GET['id_penyakit']);
                }
                break;
            case 'hapusPenyakit':
                if (isset($_GET['id_penyakit'])) {
                    hapusPenyakit($_GET['id_penyakit']);
                }
                break;
            
                case 'tambahGejala':
                    tambahGejala();
                    break;
                case 'ubahGejala':
                    if (isset($_GET['id_gejala'])) { // Mengganti 'id_penyakit' menjadi 'id_gejala'
                        ubahGejala($_GET['id_gejala']); // Mengganti 'ubahPenyakit' menjadi 'ubahGejala'
                    }
                    break;
                case 'hapusGejala':
                    if (isset($_GET['id_gejala'])) { // Mengganti 'id_penyakit' menjadi 'id_gejala'
                        hapusGejala($_GET['id_gejala']); // Mengganti 'hapusPenyakit' menjadi 'hapusGejala'
                    }
                    break;
        // Tambahkan case lain untuk aksi lainnya jika ada
    }
}



function diagnosa() {
    global $koneksi;

    $gejala_input = $_POST['gejala'];
    $query = "SELECT id_penyakit FROM aturan WHERE id_gejala IN ('" . implode("','", $gejala_input) . "') GROUP BY id_penyakit";
    $result = mysqli_query($koneksi, $query);

    $penyakit = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $penyakit[] = $row['id_penyakit'];
    }

    if (count($penyakit) > 0) {
        $_SESSION['diagnosa'] = $penyakit;
        echo "<script>alert('Diagnosa selesai. Hasil telah disimpan.');document.location.href = 'hasilDiagnosa.php';</script>";
    } else {
        echo "<script>alert('Tidak ditemukan penyakit sesuai gejala.');document.location.href = 'indexDiagnosa.php';</script>";
    }
}

function gejala($id_penyakit) {
    global $koneksi;

    // Query untuk mendapatkan id_gejala berdasarkan id_penyakit
    $query = "
        SELECT aturan.id_gejala AS id_gejala 
        FROM aturan 
        INNER JOIN gejala ON aturan.id_gejala = gejala.id_gejala 
        INNER JOIN penyakit ON aturan.id_penyakit = penyakit.id_penyakit 
        WHERE aturan.id_penyakit = '$id_penyakit' 
        LIMIT 1
    ";

    $data = mysqli_query($koneksi, $query);

    // Jika query gagal atau tidak ada hasil, kembalikan null
    if (!$data || mysqli_num_rows($data) === 0) {
        return null; // Tidak ada gejala terkait penyakit ini
    }

    // Ambil data hasil query
    $row = mysqli_fetch_assoc($data);

    return $row['id_gejala'] ?? null; // Kembalikan id_gejala atau null jika tidak ada
}



?>
