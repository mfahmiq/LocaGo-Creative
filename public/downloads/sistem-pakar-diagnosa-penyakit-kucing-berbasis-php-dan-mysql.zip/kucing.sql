-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2025 at 04:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kucing`
--

-- --------------------------------------------------------

--
-- Table structure for table `aturan`
--

CREATE TABLE `aturan` (
  `id_aturan` varchar(50) NOT NULL,
  `id_penyakit` varchar(50) DEFAULT NULL,
  `id_gejala` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gejala`
--

CREATE TABLE `gejala` (
  `id_gejala` varchar(20) NOT NULL,
  `nama_gejala` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gejala`
--

INSERT INTO `gejala` (`id_gejala`, `nama_gejala`) VALUES
('G01', 'Berat badan turun'),
('G02', 'tampak cacing pada kotoran kucing'),
('G03', 'Bulu kusam dan rontok'),
('G04', 'Muncul lingkaran merah pada kulit'),
('G05', 'Sering menggaruk area yang terinfeksi'),
('G06', 'Demam tinggi'),
('G07', 'Sering buang air'),
('G08', 'Tidak nafsu makan'),
('G09', 'Mata merah dan berair'),
('G10', 'Gelisah'),
('G11', 'Lemas dan lesu'),
('G12', 'Sering muntah'),
('G13', 'Bersin dan hidung berair'),
('G14', 'Kelopak mata bengkak'),
('G15', 'Bernafas dengan mulut terbuka'),
('G16', 'Muncul kerak atau koreng'),
('G17', 'Agresif'),
('G18', 'Air liur berlebih');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nama`, `email`, `password`, `role`) VALUES
(1, 'Dimasklaten', 'dimas@gmail.com', '$2y$10$dTtx7/w8x03FTOPfwcOTT.P.mg6zLhN0CUN7ksWsKdvcSTF0D757C', '1'),
(2, 'Ana Herlina', 'ana112@gmail.com', '123456789', '1'),
(3, 'Doni', 'don.doe@example.com', 'password123', '1'),
(5, 'pran', 'pran@gmail.com', '$2y$10$odP1HnTP6P8KSNFMvTfj/Oqz8HimUT9MzmODRBvQRtohj4004.36u', '1'),
(7, 'admin12', 'admin@gmail.com', '$2y$10$rXDOrD5vcELqEXhmnnGVi.KNCj/7PUTgyKN7/80.2RgKRBLnxUwaO', '2'),
(8, 'Sigit', 'sigit@gmail.com', '$2y$10$kuWWHW/QJN4daTkhyRVZSeqqc9p9AkKRFCSAX1TXatPUW/fSrtDDy', '2');

-- --------------------------------------------------------

--
-- Table structure for table `penyakit`
--

CREATE TABLE `penyakit` (
  `id_penyakit` varchar(50) NOT NULL,
  `nama_penyakit` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penyakit`
--

INSERT INTO `penyakit` (`id_penyakit`, `nama_penyakit`, `deskripsi`) VALUES
('P01', 'Ringworm', 'Infeksi jamur pada kulit yang disebabkan oleh dermatofit/jamur.'),
('P02', 'Scabies', 'Penyakit yang disebabkan oleh infeksi tungau Sarcoptes scabei dan Notoedres cati. '),
('P03', 'Panleukopenia', 'Panleukopenia adalah penyakit virus yang sangat menular yang dapat menyerang kucing dari segala usia.'),
('P04', 'Cacingan', 'Cacingan adalah kondisi di mana cacing parasit hidup di dalam tubuh hewan.'),
('P05', 'ISPA', 'ISPA (Infeksi Saluran Pernapasan Atas) adalah sekelompok penyakit yang menyerang sistem pernapasan bagian atas, termasuk hidung, tenggorokan, dan sinus.'),
('P06', 'Diare', 'Diare adalah kondisi yang ditandai dengan tinja yang encer atau berair.'),
('P07', 'Infeksi Mata', 'Infeksi Mata adalah infeksi yang terjadi pada mata.'),
('P08', 'Feline Calicivirus (FCV)', 'Feline calicivirus (FCV) adalah penyakit virus yang sangat menular yang dapat menyebabkan berbagai gejala pada kucing, termasuk luka di mulut, masalah pernapasan, dan demam.'),
('P09', 'Rabies', 'Rabies adalah penyakit virus yang mematikan yang memengaruhi sistem saraf pusat mamalia.');

-- --------------------------------------------------------

--
-- Table structure for table `solusi`
--

CREATE TABLE `solusi` (
  `id_solusi` int(11) NOT NULL,
  `id_penyakit` varchar(50) NOT NULL,
  `solusi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `solusi`
--

INSERT INTO `solusi` (`id_solusi`, `id_penyakit`, `solusi`) VALUES
(1, 'P01', 'Menjaga kebersihan lingkungan kucing dan area tempat tidur.'),
(2, 'P01', 'Gunakan obat antijamur seperti shampo atau salep sesuai rekomendasi dokter.'),
(3, 'P01', 'Isolasi kucing yang terinfeksi untuk mencegah penyebaran.'),
(4, 'P01', 'Berikan nutrisi yang cukup untuk memperkuat sistem kekebalan tubuh.'),
(5, 'P02', 'Gunakan obat antitungau sesuai resep dokter hewan.'),
(6, 'P02', 'Bersihkan tempat tidur dan kandang secara rutin.'),
(7, 'P02', 'Hindari kontak dengan kucing lain selama masa perawatan.'),
(8, 'P03', 'Lakukan vaksinasi rutin untuk mencegah panleukopenia.'),
(9, 'P03', 'Berikan cairan tambahan untuk mengatasi dehidrasi.'),
(10, 'P03', 'Konsultasikan dengan dokter untuk perawatan antivirus.'),
(11, 'P04', 'Berikan obat cacing sesuai anjuran dokter hewan.'),
(12, 'P04', 'Pastikan kucing tidak mengonsumsi makanan mentah.'),
(13, 'P04', 'Bersihkan area sekitar kucing secara rutin.'),
(14, 'P05', 'Berikan obat sesuai resep dokter hewan untuk mengatasi infeksi pernapasan.'),
(15, 'P05', 'Jaga suhu lingkungan tetap hangat dan nyaman.'),
(16, 'P05', 'Hindari paparan debu atau bahan iritan lainnya.'),
(17, 'P06', 'Berikan makanan rendah serat untuk mengurangi beban pencernaan.'),
(18, 'P06', 'Berikan cairan tambahan untuk mencegah dehidrasi.'),
(19, 'P06', 'Konsultasikan dengan dokter hewan jika diare berlangsung lebih dari 2 hari.'),
(20, 'P07', 'Berikan obat antivirus yang direkomendasikan oleh dokter hewan.'),
(21, 'P07', 'Jaga kebersihan area makan dan tidur kucing.'),
(22, 'P07', 'Pastikan kucing mendapatkan asupan nutrisi yang baik.'),
(23, 'P08', 'Lakukan vaksinasi rutin untuk mencegah infeksi.'),
(24, 'P08', 'Isolasi kucing yang terinfeksi untuk mencegah penularan.'),
(25, 'P08', 'Berikan perawatan suportif seperti makanan bergizi.'),
(26, 'P09', 'Konsultasikan dengan dokter hewan untuk terapi imunomodulator.'),
(27, 'P09', 'Jaga kebersihan kandang dan area sekitar kucing.'),
(28, 'P09', 'Pastikan kucing mendapatkan cukup cairan dan istirahat.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aturan`
--
ALTER TABLE `aturan`
  ADD PRIMARY KEY (`id_aturan`),
  ADD KEY `id_penyakit` (`id_penyakit`),
  ADD KEY `id_gejala` (`id_gejala`);

--
-- Indexes for table `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`id_gejala`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indexes for table `penyakit`
--
ALTER TABLE `penyakit`
  ADD PRIMARY KEY (`id_penyakit`);

--
-- Indexes for table `solusi`
--
ALTER TABLE `solusi`
  ADD PRIMARY KEY (`id_solusi`),
  ADD KEY `id_penyakit` (`id_penyakit`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `solusi`
--
ALTER TABLE `solusi`
  MODIFY `id_solusi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `aturan`
--
ALTER TABLE `aturan`
  ADD CONSTRAINT `aturan_ibfk_1` FOREIGN KEY (`id_penyakit`) REFERENCES `penyakit` (`id_penyakit`) ON DELETE CASCADE,
  ADD CONSTRAINT `aturan_ibfk_2` FOREIGN KEY (`id_gejala`) REFERENCES `gejala` (`id_gejala`) ON DELETE CASCADE;

--
-- Constraints for table `solusi`
--
ALTER TABLE `solusi`
  ADD CONSTRAINT `solusi_ibfk_1` FOREIGN KEY (`id_penyakit`) REFERENCES `penyakit` (`id_penyakit`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
