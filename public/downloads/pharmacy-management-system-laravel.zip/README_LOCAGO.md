# Pharmacy Store Management System - Pharmacy Management System Laravel

```
========================================================================
📦 Pharmacy Store Management System - Pharmacy Management System Laravel
Kategori     : Kesehatan & Medis
Tech Stack   : Laravel • PHP • MySQL • Bootstrap
Database     : MySQL (.sql) (File: vendor/laravel/sail/database/pgsql/create-testing-database.sql)
Sumber Asli  : https://github.com/MartinKalema/Pharmacy-Management-System-Laravel (GitHub Open Source)
Stars GitHub : ⭐ 2 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/pharmacy-management-system-laravel`
     * Untuk Laragon: `C:/laragon/www/pharmacy-management-system-laravel`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `pharmacy_management_system_laravel`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `vendor/laravel/sail/database/pgsql/create-testing-database.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = pharmacy_management_system_laravel

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/pharmacy-management-system-laravel

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
