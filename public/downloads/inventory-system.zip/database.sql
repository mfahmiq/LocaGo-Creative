-- =======================================================
-- LocaGo Rebranded Edition: Aplikasi Inventory System Modern & Full Database
-- Database Type: MySQL (.sql)
-- Export Time: 2026-11-12 07:05:01
-- =======================================================

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `app_settings`;
DROP TABLE IF EXISTS `activity_logs`;
DROP TABLE IF EXISTS `transactions`;
DROP TABLE IF EXISTS `master_items`;
DROP TABLE IF EXISTS `users`;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('admin','operator','kasir','pimpinan') DEFAULT 'admin',
  `status` ENUM('active','suspended') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` (`name`, `email`, `password`, `role`, `status`) VALUES
('Administrator LocaGo', 'admin@locago.my.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active'),
('Operator Utama', 'operator@locago.my.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'operator', 'active');

CREATE TABLE `app_settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `setting_key` VARCHAR(50) UNIQUE NOT NULL,
  `setting_value` TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `app_settings` (`setting_key`, `setting_value`) VALUES
('app_name', 'Aplikasi Inventory System Modern & Full Database'),
('company_name', 'LocaGo Creative Enterprise'),
('theme_accent', '#10b981'),
('currency_symbol', 'Rp '),
('whatsapp_gateway_url', 'https://api.fonnte.com/send');

CREATE TABLE `master_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `code` VARCHAR(50) UNIQUE NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `stock_or_capacity` INT DEFAULT 0,
  `unit_price` DECIMAL(12,2) DEFAULT 0.00,
  `status` VARCHAR(30) DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `master_items` (`code`, `name`, `category`, `stock_or_capacity`, `unit_price`, `status`) VALUES
('ITEM-001', 'Layanan / Produk Utama A', 'Operasional', 150, 45000.00, 'active'),
('ITEM-002', 'Layanan / Produk Utama B', 'Operasional', 75, 125000.00, 'active'),
('ITEM-003', 'Paket Bundle Unggulan VIP', 'Paket Hemat', 30, 250000.00, 'active'),
('ITEM-004', 'Suplemen & Perlengkapan Pendukung', 'Aksesoris', 200, 15000.00, 'active');

CREATE TABLE `transactions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `invoice_no` VARCHAR(60) UNIQUE NOT NULL,
  `user_id` INT NOT NULL,
  `customer_name` VARCHAR(100) NOT NULL,
  `customer_phone` VARCHAR(30) NOT NULL,
  `total_amount` DECIMAL(12,2) NOT NULL,
  `payment_method` VARCHAR(40) DEFAULT 'QRIS Dinamis',
  `payment_status` ENUM('paid','pending','cancelled') DEFAULT 'paid',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `transactions` (`invoice_no`, `user_id`, `customer_name`, `customer_phone`, `total_amount`, `payment_method`, `payment_status`) VALUES
('INV-20261110-001', 1, 'Budi Santoso', '081234567890', 215000.00, 'QRIS Dinamis', 'paid'),
('INV-20261110-002', 1, 'Siti Nurhaliza', '085711223344', 375000.00, 'Transfer Bank', 'paid'),
('INV-20261110-003', 2, 'Rian Kusuma', '081399887766', 90000.00, 'Tunai', 'paid');
