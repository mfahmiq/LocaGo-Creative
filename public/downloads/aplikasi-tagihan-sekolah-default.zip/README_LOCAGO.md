# Sistem Informasi Manajemen Sekolah - Aplikasi Tagihan Sekolah Default

```
========================================================================
📦 Sistem Informasi Manajemen Sekolah - Aplikasi Tagihan Sekolah Default
Kategori     : Pendidikan & Akademik
Tech Stack   : CodeIgniter • PHP • MySQL • Bootstrap
Database     : MySQL (.sql) (File: application/aplikasi_sipasti_almahbaro.sql)
Sumber Asli  : https://github.com/penyimak527/aplikasi-tagihan-sekolah-default (GitHub Open Source)
Stars GitHub : ⭐ 0 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/aplikasi-tagihan-sekolah-default`
     * Untuk Laragon: `C:/laragon/www/aplikasi-tagihan-sekolah-default`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - File SQL ini membuat database `aplikasi_tagihan_sekolah_default` sendiri — tidak perlu membuat
     database manual. Klik tab 'Import', pilih file SQL yang disertakan pada:
     `application/aplikasi_sipasti_almahbaro.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = aplikasi_tagihan_sekolah_default

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/aplikasi-tagihan-sekolah-default

5. AKUN LOGIN DEMO:
   - Repo ini tidak mendokumentasikan akun demo di README-nya.
     Cek README.md repo asli atau tabel `users` di phpMyAdmin;
     JANGAN pakai tebakan umum (admin/admin123 dsb.) — belum tentu benar.

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
