<?php

use App\Models\User;

test('confirm password screen can be rendered', function () {
    $user = User::factory()->create();
    $response = $this->actingAs($user)->get('/confirm-password');
    $response->assertStatus(200);
});

test('password can be confirmed via post', function () {
    $user = User::factory()->create();
    $this->actingAs($user);

    $response = $this->post('/confirm-password', ['password' => 'password']);
    $response->assertRedirect();
});

test('password is not confirmed with invalid password', function () {
    $user = User::factory()->create();
    $this->actingAs($user);

    $response = $this->post('/confirm-password', ['password' => 'wrong-password']);
    $response->assertSessionHasErrors();
});
