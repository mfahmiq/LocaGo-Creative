function cetakStruk() {
    window.print();
}