<?php
$page_title = "Riwayat Peminjaman";
$current_page = "riwayat";
require_once '../includes/auth_check.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$anggota_id = $_SESSION['user_id'];

$riwayat = query("SELECT p.*, b.title, b.isbn, b.pengarang FROM tbl_pinjam p
    LEFT JOIN tbl_buku b ON p.buku_id = b.buku_id
    WHERE p.anggota_id='$anggota_id'
    ORDER BY p.id_pinjam DESC");
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <h4 class="page-title mt-3"><i class="fas fa-history me-2"></i>Riwayat Peminjaman</h4>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>ID Pinjam</th>
                            <th>Buku</th>
                            <th>Tgl Pinjam</th>
                            <th>Lama</th>
                            <th>Harus Kembali</th>
                            <th>Tgl Kembali</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($riwayat)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><span class="badge bg-primary"><?= $row['pinjam_id'] ?></span></td>
                            <td>
                                <strong><?= $row['title'] ?></strong>
                            </td>
                            <td><?= date('d-m-Y', strtotime($row['tgl_pinjam'])) ?></td>
                            <td><?= $row['lama_pinjam'] ?> hari</td>
                            <td><?= date('d-m-Y', strtotime($row['tgl_balik'])) ?></td>
                            <td>
                                <?php if ($row['tgl_kembali']): ?>
                                    <?= date('d-m-Y', strtotime($row['tgl_kembali'])) ?>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($row['status'] == 'Pinjam'): ?>
                                    <span class="badge bg-warning">Dipinjam</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Dikembalikan</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<?php require_once '../includes/footer.php'; ?>
