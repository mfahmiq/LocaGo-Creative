<?php
$page_title = "Dashboard Anggota";
$current_page = "dashboard";
require_once '../includes/auth_check.php';

$anggota_id = $_SESSION['user_id'];
$search = isset($_GET['search']) ? escape($_GET['search']) : '';

// Proses pinjam buku
if (isset($_POST['pinjam'])) {
    $buku_id = escape($_POST['buku_id']);
    $lama_pinjam = escape($_POST['lama_pinjam']);
    $tgl_pinjam = date('Y-m-d');
    $tgl_balik = date('Y-m-d', strtotime($tgl_pinjam . " +$lama_pinjam days"));

    $stok = mysqli_fetch_assoc(query("SELECT jml FROM tbl_buku WHERE buku_id='$buku_id'"));
    if ($stok && $stok['jml'] > 0) {
        $last = mysqli_fetch_assoc(query("SELECT MAX(CAST(SUBSTRING(pinjam_id, 3) AS UNSIGNED)) as last_num FROM tbl_pinjam"));
        $next_num = ($last['last_num'] ?? 0) + 1;
        $pinjam_id = 'PJ' . str_pad($next_num, 3, '0', STR_PAD_LEFT);

        query("INSERT INTO tbl_pinjam (pinjam_id, anggota_id, buku_id, status, tgl_pinjam, lama_pinjam, tgl_balik) VALUES ('$pinjam_id','$anggota_id','$buku_id','Pinjam','$tgl_pinjam','$lama_pinjam','$tgl_balik')");
        query("UPDATE tbl_buku SET jml = jml - 1 WHERE buku_id='$buku_id'");
        set_alert('success', 'Peminjaman berhasil! ID: ' . $pinjam_id);
    } else {
        set_alert('danger', 'Stok buku habis!');
    }
    redirect('index.php');
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';

// Info anggota
$anggota = mysqli_fetch_assoc(query("SELECT * FROM anggota WHERE ID_ANGGOTA='$anggota_id'"));

// Total pinjam aktif
$pinjam_aktif = mysqli_fetch_assoc(query("SELECT COUNT(*) as jml FROM tbl_pinjam WHERE anggota_id='$anggota_id' AND status='Pinjam'"))['jml'];

// Total denda
$total_denda = mysqli_fetch_assoc(query("SELECT COALESCE(SUM(d.denda),0) as total FROM tbl_denda d JOIN tbl_pinjam p ON d.pinjam_id = p.pinjam_id WHERE p.anggota_id='$anggota_id'"))['total'];

// Peminjaman terakhir
$pinjam_terakhir = query("SELECT p.*, b.title FROM tbl_pinjam p
    LEFT JOIN tbl_buku b ON p.buku_id = b.buku_id
    WHERE p.anggota_id='$anggota_id'
    ORDER BY p.id_pinjam DESC LIMIT 5");

// Buku tersedia dengan filter search
$where_search = "";
if ($search) {
    $where_search = "AND (b.title LIKE '%$search%' OR b.pengarang LIKE '%$search%' OR k.nama_kategori LIKE '%$search%')";
}

$buku_tersedia = query("SELECT b.*, k.nama_kategori, r.nama_rak FROM tbl_buku b
    LEFT JOIN tbl_kategori k ON b.id_kategori = k.id_kategori
    LEFT JOIN tbl_rak r ON b.id_rak = r.id_rak
    WHERE b.jml > 0 $where_search
    ORDER BY b.title ASC");
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <h4 class="page-title mt-3"><i class="fas fa-home me-2"></i>Selamat Datang, <?= $anggota['NAMA_ANGGOTA'] ?>!</h4>

    <?php $alert = get_alert(); if ($alert): ?>
        <div class="alert alert-<?= $alert['type'] ?> alert-dismissible fade show">
            <?= $alert['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Stat Cards -->
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="card card-stat shadow-sm">
                <div class="card-body d-flex align-items-center">
                    <div class="icon bg-primary-gradient me-3">
                        <i class="fas fa-hand-holding"></i>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0">Sedang Dipinjam</h6>
                        <h3 class="mb-0"><?= $pinjam_aktif ?></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card card-stat shadow-sm">
                <div class="card-body d-flex align-items-center">
                    <div class="icon bg-warning-gradient me-3">
                        <i class="fas fa-money-bill"></i>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0">Total Denda</h6>
                        <h3 class="mb-0">Rp <?= number_format($total_denda, 0, ',', '.') ?></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card card-stat shadow-sm">
                <div class="card-body d-flex align-items-center">
                    <div class="icon bg-success-gradient me-3">
                        <i class="fas fa-id-card"></i>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0">ID Anggota</h6>
                        <h3 class="mb-0"><?= $anggota_id ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Riwayat Pinjam -->
        <div class="col-lg-5 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h6 class="mb-0"><i class="fas fa-history me-2"></i>Riwayat Pinjam Terakhir</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Buku</th>
                                    <th>Tgl Pinjam</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (mysqli_num_rows($pinjam_terakhir) > 0): ?>
                                <?php while ($row = mysqli_fetch_assoc($pinjam_terakhir)): ?>
                                <tr>
                                    <td><?= substr($row['title'], 0, 25) ?></td>
                                    <td><?= date('d-m-Y', strtotime($row['tgl_pinjam'])) ?></td>
                                    <td>
                                        <?= $row['status'] == 'Pinjam' ? '<span class="badge bg-warning">Dipinjam</span>' : '<span class="badge bg-success">Dikembalikan</span>' ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                                <?php else: ?>
                                <tr><td colspan="3" class="text-center">Belum ada riwayat</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Buku Tersedia untuk Dipinjam -->
        <div class="col-lg-7 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-success text-white">
                    <h6 class="mb-0"><i class="fas fa-book me-2"></i>Buku Tersedia</h6>
                </div>
                <div class="card-body">
                    <!-- Form Search -->
                    <form method="GET" class="mb-3">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Cari buku (judul, pengarang, kategori)..." value="<?= htmlspecialchars($search) ?>">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-search me-1"></i>Cari
                            </button>
                            <?php if ($search): ?>
                            <a href="index.php" class="btn btn-secondary">
                                <i class="fas fa-times me-1"></i>Reset
                            </a>
                            <?php endif; ?>
                        </div>
                    </form>

                    <?php if ($search): ?>
                    <div class="mb-3">
                        <small class="text-muted">Hasil pencarian untuk: <strong>"<?= htmlspecialchars($search) ?>"</strong> (<?= mysqli_num_rows($buku_tersedia) ?> buku ditemukan)</small>
                    </div>
                    <?php endif; ?>

                    <?php if (mysqli_num_rows($buku_tersedia) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover table-sm">
                            <thead>
                                <tr>
                                    <th>Judul</th>
                                    <th>Kategori</th>
                                    <th>Stok</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = mysqli_fetch_assoc($buku_tersedia)): ?>
                                <tr>
                                    <td>
                                        <strong><?= $row['title'] ?></strong>
                                        <br><small class="text-muted"><?= $row['pengarang'] ?></small>
                                    </td>
                                    <td><span class="badge bg-info"><?= $row['nama_kategori'] ?></span></td>
                                    <td><span class="badge bg-success"><?= $row['jml'] ?></span></td>
                                    <td>
                                        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#pinjamModal" onclick="setPinjam('<?= $row['buku_id'] ?>', '<?= addslashes($row['title']) ?>')">
                                            <i class="fas fa-hand-holding me-1"></i>Pinjam
                                        </button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-book-open fa-3x mb-3"></i>
                        <p><?= $search ? 'Buku tidak ditemukan' : 'Belum ada buku tersedia' ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Modal Pinjam Buku -->
<div class="modal fade" id="pinjamModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Pinjam Buku</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="buku_id" id="pinjam_buku_id">
                    <div class="mb-3">
                        <label class="form-label">Buku</label>
                        <input type="text" id="pinjam_buku_nama" class="form-control" disabled>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Lama Pinjam (hari)</label>
                        <select name="lama_pinjam" class="form-select" required>
                            <option value="3">3 Hari</option>
                            <option value="7" selected>7 Hari</option>
                            <option value="14">14 Hari</option>
                            <option value="30">30 Hari</option>
                        </select>
                    </div>
                    <div class="alert alert-info mb-0">
                        <i class="fas fa-info-circle me-1"></i>Tanggal pinjam: <strong><?= date('d-m-Y') ?></strong><br>
                        Denda keterlambatan: Rp 4.000/hari
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="pinjam" class="btn btn-primary">
                        <i class="fas fa-check me-1"></i>Konfirmasi Pinjam
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function setPinjam(id, nama) {
    document.getElementById('pinjam_buku_id').value = id;
    document.getElementById('pinjam_buku_nama').value = nama;
}
</script>

<?php require_once '../includes/footer.php'; ?>
