<?php
$page_title = "Profil Saya";
$current_page = "profil";
require_once '../includes/auth_check.php';

$anggota_id = $_SESSION['user_id'];

if (isset($_POST['update'])) {
    $nama = escape($_POST['nama']);
    $tempat_lahir = escape($_POST['tempat_lahir']);
    $tgl_lahir = escape($_POST['tgl_lahir']);
    $jenkel = escape($_POST['jenkel']);
    $alamat = escape($_POST['alamat']);
    $telepon = escape($_POST['telepon']);
    $email = escape($_POST['email']);

    // Update tbl_login
    query("UPDATE tbl_login SET nama='$nama', tempat_lahir='$tempat_lahir', tgl_lahir='$tgl_lahir', jenkel='$jenkel', alamat='$alamat', telepon='$telepon', email='$email' WHERE user_id='$anggota_id'");

    // Update anggota
    query("UPDATE anggota SET NAMA_ANGGOTA='$nama', TANGGAL_LAHIR='$tgl_lahir', ALAMAT='$alamat', JK='$jenkel', NO_HP='$telepon' WHERE ID_ANGGOTA='$anggota_id'");

    $_SESSION['nama'] = $nama;
    set_alert('success', 'Profil berhasil diupdate!');
    redirect('profil.php');
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$user = mysqli_fetch_assoc(query("SELECT * FROM tbl_login WHERE user_id='$anggota_id'"));
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <h4 class="page-title mt-3"><i class="fas fa-user me-2"></i>Profil Saya</h4>

    <?php $alert = get_alert(); if ($alert): ?>
        <div class="alert alert-<?= $alert['type'] ?> alert-dismissible fade show">
            <?= $alert['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-4 mb-4">
            <div class="card shadow-sm text-center">
                <div class="card-body">
                    <?php if ($user['foto']): ?>
                        <img src="../assets/img/<?= $user['foto'] ?>" class="rounded-circle mb-3" width="120" height="120" style="object-fit:cover;">
                    <?php else: ?>
                        <div class="bg-primary rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:120px;height:120px;">
                            <i class="fas fa-user text-white" style="font-size:50px;"></i>
                        </div>
                    <?php endif; ?>
                    <h5><?= $user['nama'] ?></h5>
                    <p class="text-muted mb-1"><?= $user['level'] ?></p>
                    <span class="badge bg-primary"><?= $anggota_id ?></span>
                </div>
            </div>
        </div>
        <div class="col-lg-8 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h6 class="mb-0">Edit Profil</h6>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Nama Lengkap</label>
                                <input type="text" name="nama" value="<?= $user['nama'] ?>" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Username</label>
                                <input type="text" value="<?= $user['user'] ?>" class="form-control" disabled>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tempat Lahir</label>
                                <input type="text" name="tempat_lahir" value="<?= $user['tempat_lahir'] ?>" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tgl Lahir</label>
                                <input type="date" name="tgl_lahir" value="<?= $user['tgl_lahir'] ?>" class="form-control" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Jenis Kelamin</label>
                                <select name="jenkel" class="form-select" required>
                                    <option value="Laki-Laki" <?= $user['jenkel'] == 'Laki-Laki' ? 'selected' : '' ?>>Laki-Laki</option>
                                    <option value="Perempuan" <?= $user['jenkel'] == 'Perempuan' ? 'selected' : '' ?>>Perempuan</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">No Telepon</label>
                                <input type="text" name="telepon" value="<?= $user['telepon'] ?>" class="form-control" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Alamat</label>
                            <textarea name="alamat" class="form-control" rows="2" required><?= $user['alamat'] ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" value="<?= $user['email'] ?>" class="form-control" required>
                        </div>
                        <button type="submit" name="update" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Simpan Perubahan
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<?php require_once '../includes/footer.php'; ?>
