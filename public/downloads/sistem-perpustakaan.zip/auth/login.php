<?php
session_start();
require_once '../config/koneksi.php';

if (isset($_SESSION['login'])) {
    if ($_SESSION['level'] == 'Petugas') {
        redirect('../admin/index.php');
    } else {
        redirect('../anggota/index.php');
    }
}

$error = '';
if (isset($_SESSION['alert'])) {
    $alert = get_alert();
    $error = $alert['message'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Perpustakaan</title>
    <script>
        (function() {
            var theme = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', theme);
        })();
    </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s;
        }
        [data-theme="dark"] body {
            background: linear-gradient(135deg, #0d1117 0%, #161b22 100%);
        }
        .login-card {
            background: var(--login-bg, #fff);
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            overflow: hidden;
            width: 420px;
            --login-bg: #fff;
            --login-text: #212529;
            --login-input-bg: #fff;
            --login-border: #dee2e6;
            --login-muted: #6c757d;
        }
        [data-theme="dark"] .login-card {
            --login-bg: #22262e;
            --login-text: #e1e3e8;
            --login-input-bg: #2a2e37;
            --login-border: #343a40;
            --login-muted: #8a8f98;
        }
        .login-header {
            background: #2a5298;
            color: #fff;
            padding: 30px;
            text-align: center;
        }
        [data-theme="dark"] .login-header {
            background: #1c2d4a;
        }
        .login-header i {
            font-size: 50px;
            margin-bottom: 10px;
        }
        .login-body {
            padding: 30px;
            background-color: var(--login-bg);
            color: var(--login-text);
        }
        .login-body .form-label {
            color: var(--login-text);
        }
        .login-body .form-control {
            background-color: var(--login-input-bg);
            border-color: var(--login-border);
            color: var(--login-text);
        }
        .login-body .form-control:focus {
            border-color: #2a5298;
            box-shadow: 0 0 0 0.2rem rgba(42, 82, 152, 0.25);
            background-color: var(--login-input-bg);
            color: var(--login-text);
        }
        .login-body .input-group-text {
            background-color: var(--login-input-bg);
            border-color: var(--login-border);
            color: var(--login-muted);
        }
        .btn-login {
            background: #2a5298;
            border: none;
            padding: 10px;
            font-size: 16px;
        }
        .btn-login:hover {
            background: #1e3c72;
        }
        .theme-toggle-login {
            position: fixed;
            top: 15px;
            right: 15px;
            background: rgba(255,255,255,0.15);
            border: 2px solid rgba(255,255,255,0.3);
            color: #fff;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 18px;
            z-index: 1000;
        }
        .theme-toggle-login:hover {
            background: rgba(255,255,255,0.25);
            transform: rotate(30deg);
        }
    </style>
</head>
<body>
    <button class="theme-toggle-login" id="themeToggle" title="Ganti Theme">
        <i class="fas fa-moon" id="themeIcon"></i>
    </button>

    <div class="login-card">
        <div class="login-header">
            <i class="fas fa-book-open"></i>
            <h3>Sistem Perpustakaan</h3>
            <p class="mb-0">Silakan login ke akun Anda</p>
        </div>
        <div class="login-body">
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i><?= $error ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="POST" action="proses_login.php">
                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" name="user" class="form-control" placeholder="Masukkan username" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" name="pass" class="form-control" placeholder="Masukkan password" required>
                    </div>
                </div>
                <button type="submit" name="login" class="btn btn-login btn-primary w-100 text-white">
                    <i class="fas fa-sign-in-alt me-2"></i>Login
                </button>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    (function() {
        var toggle = document.getElementById('themeToggle');
        var icon = document.getElementById('themeIcon');
        var html = document.documentElement;

        function setIcon(theme) {
            icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }

        setIcon(localStorage.getItem('theme') || 'light');

        toggle.addEventListener('click', function() {
            var current = html.getAttribute('data-theme');
            var next = current === 'dark' ? 'light' : 'dark';
            html.setAttribute('data-theme', next);
            localStorage.setItem('theme', next);
            setIcon(next);
        });
    })();
    </script>
</body>
</html>
