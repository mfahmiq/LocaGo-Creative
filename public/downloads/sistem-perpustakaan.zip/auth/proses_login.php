<?php
session_start();
require_once '../config/koneksi.php';

if (isset($_POST['login'])) {
    $user = escape($_POST['user']);
    $pass = $_POST['pass'];

    $sql = "SELECT * FROM tbl_login WHERE user = '$user'";
    $result = query($sql);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($pass, $row['pass'])) {
            $_SESSION['login'] = true;
            $_SESSION['id_login'] = $row['id_login'];
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['user'] = $row['user'];
            $_SESSION['level'] = $row['level'];
            $_SESSION['nama'] = $row['nama'];

            if ($row['level'] == 'Petugas') {
                redirect('../admin/index.php');
            } else {
                redirect('../anggota/index.php');
            }
        } else {
            set_alert('danger', 'Password salah!');
            redirect('login.php');
        }
    } else {
        set_alert('danger', 'Username tidak ditemukan!');
        redirect('login.php');
    }
}
?>
