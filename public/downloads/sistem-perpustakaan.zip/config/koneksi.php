<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "perpustakaan";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");

function query($sql) {
    global $conn;
    return mysqli_query($conn, $sql);
}

function escape($data) {
    global $conn;
    return mysqli_real_escape_string($conn, $data);
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function set_alert($type, $message) {
    $_SESSION['alert'] = ['type' => $type, 'message' => $message];
}

function get_alert() {
    if (isset($_SESSION['alert'])) {
        $alert = $_SESSION['alert'];
        unset($_SESSION['alert']);
        return $alert;
    }
    return null;
}
?>
