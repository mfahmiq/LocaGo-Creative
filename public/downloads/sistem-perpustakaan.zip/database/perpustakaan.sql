-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2026 at 10:29 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `anggota`
--

CREATE TABLE `anggota` (
  `ID_ANGGOTA` varchar(7) NOT NULL,
  `NAMA_ANGGOTA` varchar(50) NOT NULL,
  `TANGGAL_LAHIR` date NOT NULL,
  `ALAMAT` varchar(100) NOT NULL,
  `JK` varchar(10) NOT NULL,
  `NO_HP` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `anggota`
--

INSERT INTO `anggota` (`ID_ANGGOTA`, `NAMA_ANGGOTA`, `TANGGAL_LAHIR`, `ALAMAT`, `JK`, `NO_HP`) VALUES
('AG001', 'Ahmad Rizky', '1998-05-12', 'Jl. Merdeka No. 12', 'Laki-Laki', '081234567001'),
('AG002', 'Siti Rahma', '2000-08-25', 'Jl. Mawar No. 45', 'Perempuan', '081234567002'),
('AG003', 'Budi Santoso', '1995-12-01', 'Jl. Anggrek No. 8', 'Laki-Laki', '081234567003'),
('AG004', 'Dewi Putri', '1999-03-15', 'Jl. Melati No. 22', 'Perempuan', '081234567004'),
('AG005', 'Fajar Nugroho', '1997-07-20', 'Jl. Kenanga No. 10', 'Laki-Laki', '081234567005'),
('AG006', 'Gita Sari', '2001-11-05', 'Jl. Cempaka No. 33', 'Perempuan', '081234567006'),
('AG007', 'Hendra Wijaya', '1996-02-28', 'Jl. Dahlia No. 7', 'Laki-Laki', '081234567007'),
('AG008', 'Indah Permata', '1998-09-10', 'Jl. Tulip No. 15', 'Perempuan', '081234567008'),
('AG009', 'Joko Prasetyo', '1994-06-18', 'Jl. Seruni No. 5', 'Laki-Laki', '081234567009'),
('AG010', 'Kartika Sari', '2000-01-22', 'Jl. Kamboja No. 20', 'Perempuan', '081234567010'),
('AG011', 'Lukman Hakim', '1997-04-08', 'Jl. Melur No. 12', 'Laki-Laki', '081234567011'),
('AG012', 'Maya Anisa', '1999-12-30', 'Jl. Lily No. 8', 'Perempuan', '081234567012');

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `ID_PETUGAS` varchar(10) NOT NULL,
  `NAMA_PETUGAS` varchar(50) NOT NULL,
  `JK_PETUGAS` varchar(10) NOT NULL,
  `JABATAN` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`ID_PETUGAS`, `NAMA_PETUGAS`, `JK_PETUGAS`, `JABATAN`) VALUES
('PTG01', 'Dewi Lestari', 'Perempuan', 'Kepala Perpustakaan'),
('PTG02', 'Rian Hidayat', 'Laki-Laki', 'Staf Sirkulasi'),
('PTG03', 'Andi Pratama', 'Laki-Laki', 'Staf Administrasi'),
('PTG04', 'Rina Wati', 'Perempuan', 'Staf Sirkulasi'),
('PTG05', 'Dimas Aditya', 'Laki-Laki', 'Staf Administrasi'),
('PTG06', 'Salsa Billa', 'Perempuan', 'Staf Sirkulasi'),
('PTG07', 'Yoga Pratama', 'Laki-Laki', 'Staf Administrasi'),
('PTG08', 'Putri Rahayu', 'Perempuan', 'Staf Sirkulasi'),
('PTG09', 'Arif Rahman', 'Laki-Laki', 'Staf Administrasi'),
('PTG10', 'Nisa Aulia', 'Perempuan', 'Staf Sirkulasi'),
('PTG11', 'Bayu Firmansyah', 'Laki-Laki', 'Staf Administrasi'),
('PTG12', 'Citra Dewi', 'Perempuan', 'Staf Sirkulasi');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_biaya_denda`
--

CREATE TABLE `tbl_biaya_denda` (
  `id_biaya_denda` int(11) NOT NULL,
  `harga_denda` int(11) NOT NULL,
  `stat` varchar(20) NOT NULL,
  `tgl_tetap` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_biaya_denda`
--

INSERT INTO `tbl_biaya_denda` (`id_biaya_denda`, `harga_denda`, `stat`, `tgl_tetap`) VALUES
(1, 4000, 'Aktif', '2024-01-01'),
(2, 5000, 'Non-Aktif', '2023-01-01'),
(3, 3000, 'Non-Aktif', '2022-06-01'),
(4, 2500, 'Non-Aktif', '2021-01-01'),
(5, 6000, 'Non-Aktif', '2020-12-01'),
(6, 3500, 'Non-Aktif', '2019-05-01'),
(7, 4500, 'Non-Aktif', '2018-03-01'),
(8, 5500, 'Non-Aktif', '2017-08-01'),
(9, 7000, 'Non-Aktif', '2016-01-01'),
(10, 2000, 'Non-Aktif', '2015-06-01'),
(11, 8000, 'Non-Aktif', '2014-12-01'),
(12, 1500, 'Non-Aktif', '2013-03-01');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_buku`
--

CREATE TABLE `tbl_buku` (
  `id_buku` int(11) NOT NULL,
  `buku_id` varchar(10) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `id_rak` int(11) NOT NULL,
  `sampul` varchar(255) DEFAULT NULL,
  `isbn` varchar(20) DEFAULT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `penerbit` varchar(100) NOT NULL,
  `pengarang` varchar(100) NOT NULL,
  `thn_buku` year(4) NOT NULL,
  `isi` text DEFAULT NULL,
  `stok_awal` int(11) NOT NULL DEFAULT 0,
  `jml` int(11) NOT NULL DEFAULT 0,
  `tgl_masuk` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_buku`
--

INSERT INTO `tbl_buku` (`id_buku`, `buku_id`, `id_kategori`, `id_rak`, `sampul`, `isbn`, `lampiran`, `title`, `penerbit`, `pengarang`, `thn_buku`, `isi`, `stok_awal`, `jml`, `tgl_masuk`) VALUES
(1, 'BK001', 2, 1, 'buku_1786004838.jpg', '978-602-0001-01', NULL, 'BELAJAR PHP DAN MYSQL UNTUK PEMULA', 'INFORMATIKA BANDUNG', 'ABDUL KADIR', '2020', 'Buku panduan belajar PHP dan MySQL.', 10, 10, '2020-01-15 08:00:00'),
(2, 'BK002', 2, 1, 'buku_1786004768.jpg', '978-602-0001-02', NULL, 'MASTERING JAVA PROGRAMMING', 'ELEX MEDIA', 'JAMES GOSLING', '2019', 'Buku lengkap pemrograman Java.', 8, 8, '2019-06-20 09:30:00'),
(3, 'BK003', 3, 2, 'buku_1786004742.jpg', '978-602-0001-03', NULL, 'DATABASE DESIGN FUNDAMENTALS', 'ANDI OFFSET', 'MICHAEL HERNANDEZ', '2021', 'Konsep dasar desain database.', 12, 12, '2021-03-10 10:00:00'),
(4, 'BK004', 4, 3, 'buku_1786004729.jpg', '978-602-0001-04', NULL, 'JARINGAN KOMPUTER LANJUT', 'GRAMEDIA', 'TANENBAUM ANDREW', '2018', 'Buku jaringan komputer tingkat lanjut.', 6, 6, '2018-09-05 11:00:00'),
(5, 'BK005', 5, 4, 'buku_1786004712.jpg', '978-602-0001-05', NULL, 'DESAIN UI/UX DENGAN FIGMA', 'INFORMATIKA', 'ADITYA CHANDRA', '2022', 'Panduan desain antarmuka modern.', 15, 15, '2022-02-14 08:30:00'),
(6, 'BK006', 6, 5, 'buku_1786004695.jpg', '978-602-0001-06', NULL, 'MATEMATIKA DASAR KULIAH', 'ERLANGGA', 'PURWO ATMOJO', '2017', 'Buku matematika untuk mahasiswa.', 20, 20, '2017-07-20 13:00:00'),
(7, 'BK007', 7, 6, 'buku_1786004680.jpg', '978-602-0001-07', NULL, 'FISIKA DASAR DAN TERAPAN', 'GRAFINDO', 'HALLIDAY RESNICK', '2019', 'Buku fisika dasar lengkap.', 10, 10, '2019-11-25 14:00:00'),
(8, 'BK008', 2, 1, 'buku_1786004659.jpg', '978-602-0001-08', NULL, 'CARA MUDAH BELAJAR PEMROGRAMAN C++', 'INFORMATIKA BANDUNG', 'BUDI RAHARJO', '2012', 'Buku C++ untuk pemula.', 25, 25, '2019-11-23 11:49:57'),
(9, 'BK009', 1, 2, 'buku_1786004645.jpg', '978-602-0001-09', NULL, 'METODOLOGI PENELITIAN SISTEM INFORMASI', 'ANDI OFFSET', 'SUGIYONO', '2018', 'Buku panduan riset.', 12, 12, '2021-02-10 08:30:00'),
(10, 'BK010', 3, 3, 'buku_1786004630.jpg', '978-602-0001-10', NULL, 'MASTERING MYSQL DAN MARIADB', 'INFORMATIKA', 'ENTERPRISER', '2020', 'Buku panduan MySQL.', 20, 20, '2022-05-14 10:11:00'),
(11, 'BK011', 8, 7, 'buku_1786004613.jpg', '978-602-0001-11', NULL, 'EKONOMI MAKRO INDONESIA', 'GRAMEDIA', 'MANKIW N GREGORY', '2021', 'Buku ekonomi makro.', 8, 8, '2021-08-12 09:00:00'),
(12, 'BK012', 9, 8, 'buku_1786004602.jpg', '978-602-0001-12', NULL, 'SEJARAH KEMERDEKAAN INDONESIA', 'BALAI PUSTAKA', 'AHMAD FATAH', '2015', 'Sejarah kemerdekaan.', 10, 10, '2015-08-17 08:00:00'),
(13, 'BK013', 10, 9, 'buku_1786004589.jpg', '978-602-0001-13', NULL, 'LASKAR PELANGI', 'GRAMEDIA', 'ANDREA HIRATA', '2005', 'Novel bestseller.', 30, 30, '2018-03-20 10:00:00'),
(14, 'BK014', 10, 9, 'buku_1786004580.jpg', '978-602-0001-14', NULL, 'BURU BURU BELAH JERUK', 'GRAMEDIA', 'MAHFUD ICHWAN', '2020', 'Kumpulan cerpen.', 15, 15, '2020-06-15 11:00:00'),
(15, 'BK015', 11, 10, 'buku_1786004571.jpg', '978-602-0001-15', NULL, 'FIQIH ISLAM LENGKAP', 'AL-HUDA', 'SAYYID SABIQ', '2018', 'Buku fiqih.', 20, 20, '2018-12-01 08:00:00'),
(16, 'BK016', 12, 11, 'buku_1786004554.jpg', '978-602-0001-16', NULL, 'ANATOMI TUBUH MANUSIA', 'EGC', 'GUYTON ARTHUR', '2016', 'Buku anatomi.', 5, 5, '2016-04-10 09:00:00'),
(17, 'BK017', 2, 1, 'buku_1786004541.jpg', '978-602-0001-17', NULL, 'PYTHON FOR DATA SCIENCE', 'O REILLY', 'WES MCKINNEY', '2022', 'Panduan Python.', 10, 10, '2022-01-20 10:30:00'),
(18, 'BK018', 2, 1, 'buku_1786004524.jpg', '978-602-0001-18', NULL, 'JAVASCRIPT MODERN ES6', 'ELEX MEDIA', 'KEVIN SYAHRUL', '2021', 'Pemrograman JS.', 12, 12, '2021-09-05 14:00:00'),
(19, 'BK019', 4, 3, 'buku_1786003769.jpg', '978-602-0001-19', NULL, 'CISCO NETWORKING CCNA', 'GRAMEDIA', 'WENDELL ODOM', '2020', 'Persiapan CCNA.', 7, 7, '2020-11-10 08:00:00'),
(20, 'BK020', 5, 4, 'buku_1786003688.jpg', '978-602-0001-20', NULL, 'ADOBE PHOTOSHOP MASTERCLASS', 'INFORMATIKA', 'RUDI HARTONO', '2021', 'Panduan Photoshop.', 10, 10, '2021-05-25 09:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_denda`
--

CREATE TABLE `tbl_denda` (
  `id_denda` int(11) NOT NULL,
  `pinjam_id` varchar(20) NOT NULL,
  `denda` int(11) NOT NULL DEFAULT 0,
  `lama_waktu` int(11) NOT NULL DEFAULT 0,
  `tgl_denda` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_denda`
--

INSERT INTO `tbl_denda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES
(1, 'PJ001', 0, 0, '2024-01-07'),
(2, 'PJ002', 0, 0, '2024-01-10'),
(3, 'PJ003', 0, 0, '2024-01-24'),
(4, 'PJ004', 0, 0, '2024-01-20'),
(5, 'PJ005', 0, 0, '2024-02-01'),
(6, 'PJ006', 0, 0, '2024-02-07'),
(7, 'PJ007', 0, 0, '2024-02-15'),
(8, 'PJ008', 0, 0, '2024-02-28'),
(9, 'PJ009', 0, 0, '2024-02-25'),
(10, 'PJ010', 0, 0, '2024-03-14'),
(11, 'PJ011', 0, 0, '2024-03-15'),
(12, 'PJ012', 0, 0, '2024-03-25'),
(13, 'PJ013', 0, 0, '2024-03-20'),
(14, 'PJ014', 0, 0, '2024-03-30'),
(15, 'PJ015', 0, 0, '2024-03-25');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kategori`
--

CREATE TABLE `tbl_kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_kategori`
--

INSERT INTO `tbl_kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Umum'),
(2, 'Pemrograman'),
(3, 'Database'),
(4, 'Networking'),
(5, 'Desain Grafis'),
(6, 'Matematika'),
(7, 'Fisika'),
(8, 'Ekonomi'),
(9, 'Sejarah'),
(10, 'Novel'),
(11, 'Agama'),
(12, 'Kesehatan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE `tbl_login` (
  `id_login` int(11) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `user` varchar(50) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `level` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenkel` varchar(10) NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `tgl_bergabung` date NOT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id_login`, `user_id`, `user`, `pass`, `level`, `nama`, `tempat_lahir`, `tgl_lahir`, `jenkel`, `alamat`, `telepon`, `email`, `tgl_bergabung`, `foto`) VALUES
(1, 'AG001', 'ahmad', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anggota', 'Ahmad Rizky', 'Jakarta', '1998-05-12', 'Laki-Laki', 'Jl. Merdeka No. 12', '081234567001', 'ahmad@gmail.com', '2019-11-20', NULL),
(2, 'AG002', 'siti', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anggota', 'Siti Rahma', 'Bandung', '2000-08-25', 'Perempuan', 'Jl. Mawar No. 45', '081234567002', 'siti@gmail.com', '2019-11-21', NULL),
(3, 'AG003', 'budi', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anggota', 'Budi Santoso', 'Jakarta', '1995-12-01', 'Laki-Laki', 'Jl. Anggrek No. 8', '081234567003', 'budi@gmail.com', '2021-01-15', NULL),
(4, 'AG004', 'dewi', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anggota', 'Dewi Putri', 'Surabaya', '1999-03-15', 'Perempuan', 'Jl. Melati No. 22', '081234567004', 'dewi@gmail.com', '2020-02-10', NULL),
(5, 'AG005', 'fajar', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anggota', 'Fajar Nugroho', 'Yogyakarta', '1997-07-20', 'Laki-Laki', 'Jl. Kenanga No. 10', '081234567005', 'fajar@gmail.com', '2020-03-05', NULL),
(6, 'AG006', 'gita', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anggota', 'Gita Sari', 'Semarang', '2001-11-05', 'Perempuan', 'Jl. Cempaka No. 33', '081234567006', 'gita@gmail.com', '2020-04-12', NULL),
(7, 'AG007', 'hendra', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anggota', 'Hendra Wijaya', 'Malang', '1996-02-28', 'Laki-Laki', 'Jl. Dahlia No. 7', '081234567007', 'hendra@gmail.com', '2020-05-20', NULL),
(8, 'AG008', 'indah', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anggota', 'Indah Permata', 'Bandung', '1998-09-10', 'Perempuan', 'Jl. Tulip No. 15', '081234567008', 'indah@gmail.com', '2020-06-15', NULL),
(9, 'AG009', 'joko', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anggota', 'Joko Prasetyo', 'Solo', '1994-06-18', 'Laki-Laki', 'Jl. Seruni No. 5', '081234567009', 'joko@gmail.com', '2020-07-10', NULL),
(10, 'AG010', 'kartika', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anggota', 'Kartika Sari', 'Palembang', '2000-01-22', 'Perempuan', 'Jl. Kamboja No. 20', '081234567010', 'kartika@gmail.com', '2020-08-05', NULL),
(11, 'AG011', 'lukman', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anggota', 'Lukman Hakim', 'Medan', '1997-04-08', 'Laki-Laki', 'Jl. Melur No. 12', '081234567011', 'lukman@gmail.com', '2020-09-01', NULL),
(12, 'AG012', 'maya', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Anggota', 'Maya Anisa', 'Makassar', '1999-12-30', 'Perempuan', 'Jl. Lily No. 8', '081234567012', 'maya@gmail.com', '2020-10-10', NULL),
(13, 'PTG01', 'dewi_p', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Petugas', 'Dewi Lestari', 'Surabaya', '1990-03-15', 'Perempuan', 'Jl. Slamet No. 10', '081234567890', 'dewi@perpustakaan.com', '2019-01-01', NULL),
(14, 'PTG02', 'rian', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Petugas', 'Rian Hidayat', 'Semarang', '1992-07-20', 'Laki-Laki', 'Jl. Pandan No. 5', '085678901234', 'rian@perpustakaan.com', '2019-06-01', NULL),
(15, 'PTG03', 'andi', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Petugas', 'Andi Pratama', 'Yogyakarta', '1994-11-10', 'Laki-Laki', 'Jl. Malioboro No. 20', '087890123456', 'andi@perpustakaan.com', '2020-03-01', NULL),
(16, 'PTG04', 'rina', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Petugas', 'Rina Wati', 'Solo', '1993-05-25', 'Perempuan', 'Jl. Adisucipto No. 15', '081234567891', 'rina@perpustakaan.com', '2020-04-15', NULL),
(17, 'PTG05', 'dimas', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Petugas', 'Dimas Aditya', 'Bandung', '1995-08-12', 'Laki-Laki', 'Jl. Asia Afrika No. 25', '085678901235', 'dimas@perpustakaan.com', '2020-05-20', NULL),
(18, 'PTG06', 'salsa', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Petugas', 'Salsa Billa', 'Jakarta', '1998-02-14', 'Perempuan', 'Jl. Sudirman No. 30', '081234567892', 'salsa@perpustakaan.com', '2020-06-10', NULL),
(19, 'PTG07', 'yoga', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Petugas', 'Yoga Pratama', 'Yogyakarta', '1996-10-08', 'Laki-Laki', 'Jl. Prawirotaman No. 12', '085678901236', 'yoga@perpustakaan.com', '2020-07-15', NULL),
(20, 'PTG08', 'putri', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Petugas', 'Putri Rahayu', 'Surabaya', '1997-06-20', 'Perempuan', 'Jl. Pemuda No. 45', '081234567893', 'putri@perpustakaan.com', '2020-08-01', NULL),
(21, 'PTG09', 'arif', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Petugas', 'Arif Rahman', 'Malang', '1994-09-05', 'Laki-Laki', 'Jl. Basuki Rachmat No. 18', '085678901237', 'arif@perpustakaan.com', '2020-09-10', NULL),
(22, 'PTG10', 'nisa', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Petugas', 'Nisa Aulia', 'Bandung', '1999-01-30', 'Perempuan', 'Jl. Buah Batu No. 22', '081234567894', 'nisa@perpustakaan.com', '2020-10-05', NULL),
(23, 'PTG11', 'bayu', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Petugas', 'Bayu Firmansyah', 'Semarang', '1995-03-18', 'Laki-Laki', 'Jl. Pandanaran No. 35', '085678901238', 'bayu@perpustakaan.com', '2020-11-01', NULL),
(24, 'PTG12', 'citra', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Petugas', 'Citra Dewi', 'Yogyakarta', '1998-11-12', 'Perempuan', 'Jl. Malioboro No. 50', '081234567895', 'citra@perpustakaan.com', '2020-12-01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pinjam`
--

CREATE TABLE `tbl_pinjam` (
  `id_pinjam` int(11) NOT NULL,
  `pinjam_id` varchar(20) NOT NULL,
  `anggota_id` varchar(7) NOT NULL,
  `buku_id` varchar(10) NOT NULL,
  `status` varchar(30) NOT NULL,
  `tgl_pinjam` date NOT NULL,
  `lama_pinjam` int(11) NOT NULL,
  `tgl_balik` date NOT NULL,
  `tgl_kembali` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_pinjam`
--

INSERT INTO `tbl_pinjam` (`id_pinjam`, `pinjam_id`, `anggota_id`, `buku_id`, `status`, `tgl_pinjam`, `lama_pinjam`, `tgl_balik`, `tgl_kembali`) VALUES
(1, 'PJ001', 'AG001', 'BK001', 'Di Kembalikan', '2024-01-01', 7, '2024-01-08', '2024-01-07'),
(2, 'PJ002', 'AG002', 'BK002', 'Di Kembalikan', '2024-01-05', 7, '2024-01-12', '2024-01-10'),
(3, 'PJ003', 'AG003', 'BK003', 'Di Kembalikan', '2024-01-10', 14, '2024-01-24', '2024-01-24'),
(4, 'PJ004', 'AG004', 'BK004', 'Di Kembalikan', '2024-01-15', 7, '2024-01-22', '2024-01-20'),
(5, 'PJ005', 'AG005', 'BK005', 'Di Kembalikan', '2024-01-20', 14, '2024-02-03', '2024-02-01'),
(6, 'PJ006', 'AG006', 'BK006', 'Di Kembalikan', '2024-02-01', 7, '2024-02-08', '2024-02-07'),
(7, 'PJ007', 'AG007', 'BK007', 'Di Kembalikan', '2024-02-10', 7, '2024-02-17', '2024-02-15'),
(8, 'PJ008', 'AG008', 'BK008', 'Di Kembalikan', '2024-02-15', 14, '2024-03-01', '2024-02-28'),
(9, 'PJ009', 'AG009', 'BK009', 'Di Kembalikan', '2024-02-20', 7, '2024-02-27', '2024-02-25'),
(10, 'PJ010', 'AG010', 'BK010', 'Di Kembalikan', '2024-03-01', 14, '2024-03-15', '2024-03-14'),
(11, 'PJ011', 'AG001', 'BK011', 'Di Kembalikan', '2024-03-10', 7, '2024-03-17', '2024-03-15'),
(12, 'PJ012', 'AG002', 'BK012', 'Di Kembalikan', '2024-03-12', 14, '2024-03-26', '2024-03-25'),
(13, 'PJ013', 'AG003', 'BK013', 'Di Kembalikan', '2024-03-15', 7, '2024-03-22', '2024-03-20'),
(14, 'PJ014', 'AG004', 'BK014', 'Di Kembalikan', '2024-03-18', 14, '2024-04-01', '2024-03-30'),
(15, 'PJ015', 'AG005', 'BK015', 'Di Kembalikan', '2024-03-20', 7, '2024-03-27', '2024-03-25'),
(16, 'PJ016', 'AG006', 'BK016', 'Di Kembalikan', '2024-03-22', 7, '2024-03-29', '2024-03-28'),
(17, 'PJ017', 'AG007', 'BK017', 'Di Kembalikan', '2024-03-25', 14, '2024-04-08', '2024-04-06'),
(18, 'PJ018', 'AG008', 'BK018', 'Di Kembalikan', '2024-03-28', 7, '2024-04-04', '2024-04-03'),
(19, 'PJ019', 'AG009', 'BK019', 'Di Kembalikan', '2024-04-01', 14, '2024-04-15', '2024-04-14'),
(20, 'PJ020', 'AG010', 'BK020', 'Di Kembalikan', '2024-04-05', 7, '2024-04-12', '2024-04-11'),
(21, 'PJ021', 'AG001', 'BK001', 'Di Kembalikan', '2026-08-06', 7, '2026-08-13', '2026-08-10'),
(22, 'PJ022', 'AG002', 'BK020', 'Di Kembalikan', '2026-08-06', 7, '2026-08-13', '2026-08-06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rak`
--

CREATE TABLE `tbl_rak` (
  `id_rak` int(11) NOT NULL,
  `nama_rak` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_rak`
--

INSERT INTO `tbl_rak` (`id_rak`, `nama_rak`) VALUES
(1, 'Rak Buku 1'),
(2, 'Rak Buku 2'),
(3, 'Rak Buku 3'),
(4, 'Rak Buku 4'),
(5, 'Rak Buku 5'),
(6, 'Rak Buku 6'),
(7, 'Rak Buku 7'),
(8, 'Rak Buku 8'),
(9, 'Rak Buku 9'),
(10, 'Rak Buku 10'),
(11, 'Rak Buku 11'),
(12, 'Rak Buku 12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`ID_ANGGOTA`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`ID_PETUGAS`);

--
-- Indexes for table `tbl_biaya_denda`
--
ALTER TABLE `tbl_biaya_denda`
  ADD PRIMARY KEY (`id_biaya_denda`);

--
-- Indexes for table `tbl_buku`
--
ALTER TABLE `tbl_buku`
  ADD PRIMARY KEY (`id_buku`),
  ADD UNIQUE KEY `unique_buku_id` (`buku_id`),
  ADD UNIQUE KEY `unique_isbn` (`isbn`),
  ADD KEY `FK_buku_kategori` (`id_kategori`),
  ADD KEY `FK_buku_rak` (`id_rak`);

--
-- Indexes for table `tbl_denda`
--
ALTER TABLE `tbl_denda`
  ADD PRIMARY KEY (`id_denda`),
  ADD KEY `FK_denda_pinjam` (`pinjam_id`);

--
-- Indexes for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`id_login`),
  ADD UNIQUE KEY `unique_user` (`user`);

--
-- Indexes for table `tbl_pinjam`
--
ALTER TABLE `tbl_pinjam`
  ADD PRIMARY KEY (`id_pinjam`),
  ADD UNIQUE KEY `unique_pinjam_id` (`pinjam_id`),
  ADD KEY `FK_pinjam_anggota` (`anggota_id`),
  ADD KEY `FK_pinjam_buku` (`buku_id`);

--
-- Indexes for table `tbl_rak`
--
ALTER TABLE `tbl_rak`
  ADD PRIMARY KEY (`id_rak`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_biaya_denda`
--
ALTER TABLE `tbl_biaya_denda`
  MODIFY `id_biaya_denda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_buku`
--
ALTER TABLE `tbl_buku`
  MODIFY `id_buku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_denda`
--
ALTER TABLE `tbl_denda`
  MODIFY `id_denda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `id_login` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_pinjam`
--
ALTER TABLE `tbl_pinjam`
  MODIFY `id_pinjam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_rak`
--
ALTER TABLE `tbl_rak`
  MODIFY `id_rak` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_buku`
--
ALTER TABLE `tbl_buku`
  ADD CONSTRAINT `FK_buku_kategori` FOREIGN KEY (`id_kategori`) REFERENCES `tbl_kategori` (`id_kategori`),
  ADD CONSTRAINT `FK_buku_rak` FOREIGN KEY (`id_rak`) REFERENCES `tbl_rak` (`id_rak`);

--
-- Constraints for table `tbl_denda`
--
ALTER TABLE `tbl_denda`
  ADD CONSTRAINT `FK_denda_pinjam` FOREIGN KEY (`pinjam_id`) REFERENCES `tbl_pinjam` (`pinjam_id`);

--
-- Constraints for table `tbl_pinjam`
--
ALTER TABLE `tbl_pinjam`
  ADD CONSTRAINT `FK_pinjam_anggota` FOREIGN KEY (`anggota_id`) REFERENCES `anggota` (`ID_ANGGOTA`),
  ADD CONSTRAINT `FK_pinjam_buku` FOREIGN KEY (`buku_id`) REFERENCES `tbl_buku` (`buku_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
