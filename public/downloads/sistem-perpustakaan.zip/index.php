<?php
session_start();
require_once 'config/koneksi.php';

if (isset($_SESSION['login'])) {
    if ($_SESSION['level'] == 'Petugas') {
        redirect('admin/index.php');
    } else {
        redirect('anggota/index.php');
    }
} else {
    redirect('auth/login.php');
}
?>
