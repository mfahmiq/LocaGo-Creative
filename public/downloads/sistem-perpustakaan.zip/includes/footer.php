    </div><!-- end row -->
</div><!-- end container -->

<footer class="text-center py-3 mt-4 border-top">
    <p class="mb-0">&copy; <?= date('Y') ?> Sistem Perpustakaan</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
