<?php
session_start();
require_once '../config/koneksi.php';

if (!isset($_SESSION['login'])) {
    redirect('../auth/login.php');
}

$level = $_SESSION['level'];
$nama = $_SESSION['nama'];
?>
