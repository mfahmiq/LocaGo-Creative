<nav class="col-md-3 col-lg-2 d-md-block sidebar collapse" style="min-height: calc(100vh - 56px);">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">
            <?php if ($level == 'Petugas'): ?>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'dashboard' ? 'active' : '' ?>" href="index.php">
                    <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'anggota' ? 'active' : '' ?>" href="anggota.php">
                    <i class="fas fa-users me-2"></i>Anggota
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'petugas' ? 'active' : '' ?>" href="petugas.php">
                    <i class="fas fa-user-tie me-2"></i>Petugas
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'buku' ? 'active' : '' ?>" href="buku.php">
                    <i class="fas fa-book me-2"></i>Buku
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'kategori' ? 'active' : '' ?>" href="kategori.php">
                    <i class="fas fa-tags me-2"></i>Kategori
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'rak' ? 'active' : '' ?>" href="rak.php">
                    <i class="fas fa-layer-group me-2"></i>Rak
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'pinjam' ? 'active' : '' ?>" href="pinjam.php">
                    <i class="fas fa-hand-holding me-2"></i>Peminjaman
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'pengembalian' ? 'active' : '' ?>" href="pengembalian.php">
                    <i class="fas fa-undo me-2"></i>Pengembalian
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'denda' ? 'active' : '' ?>" href="denda.php">
                    <i class="fas fa-money-bill me-2"></i>Denda
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'biaya_denda' ? 'active' : '' ?>" href="biaya_denda.php">
                    <i class="fas fa-cog me-2"></i>Biaya Denda
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'laporan' ? 'active' : '' ?>" href="laporan.php">
                    <i class="fas fa-chart-bar me-2"></i>Laporan
                </a>
            </li>
            <?php else: ?>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'dashboard' ? 'active' : '' ?>" href="index.php">
                    <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'riwayat' ? 'active' : '' ?>" href="riwayat.php">
                    <i class="fas fa-history me-2"></i>Riwayat Pinjam
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= ($current_page ?? '') == 'profil' ? 'active' : '' ?>" href="profil.php">
                    <i class="fas fa-user me-2"></i>Profil
                </a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
