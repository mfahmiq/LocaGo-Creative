<?php
$page_title = "Biaya Denda";
$current_page = "biaya_denda";
require_once '../includes/auth_check.php';

if (isset($_GET['hapus'])) {
    $id = escape($_GET['hapus']);
    query("DELETE FROM tbl_biaya_denda WHERE id_biaya_denda = '$id'");
    set_alert('success', 'Biaya denda berhasil dihapus!');
    redirect('biaya_denda.php');
}

if (isset($_POST['simpan'])) {
    $harga = escape($_POST['harga_denda']);
    $stat = escape($_POST['stat']);
    $tgl = escape($_POST['tgl_tetap']);
    $edit_id = escape($_POST['edit_id'] ?? '');

    if ($stat == 'Aktif') {
        query("UPDATE tbl_biaya_denda SET stat='Non-Aktif' WHERE stat='Aktif'");
    }

    if ($edit_id) {
        query("UPDATE tbl_biaya_denda SET harga_denda='$harga', stat='$stat', tgl_tetap='$tgl' WHERE id_biaya_denda='$edit_id'");
        set_alert('success', 'Biaya denda berhasil diupdate!');
    } else {
        query("INSERT INTO tbl_biaya_denda (harga_denda, stat, tgl_tetap) VALUES ('$harga','$stat','$tgl')");
        set_alert('success', 'Biaya denda berhasil ditambahkan!');
    }
    redirect('biaya_denda.php');
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$biaya = query("SELECT * FROM tbl_biaya_denda ORDER BY id_biaya_denda DESC");
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between align-items-center mt-3">
        <h4 class="page-title"><i class="fas fa-cog me-2"></i>Pengaturan Biaya Denda</h4>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#formModal" onclick="resetForm()">
            <i class="fas fa-plus me-1"></i>Tambah
        </button>
    </div>

    <?php $alert = get_alert(); if ($alert): ?>
        <div class="alert alert-<?= $alert['type'] ?> alert-dismissible fade show">
            <?= $alert['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>ID</th>
                            <th>Harga Denda/Hari</th>
                            <th>Status</th>
                            <th>Tgl Ditetapkan</th>
                            <th width="150">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($biaya)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $row['id_biaya_denda'] ?></td>
                            <td>Rp <?= number_format($row['harga_denda'], 0, ',', '.') ?></td>
                            <td>
                                <?php if ($row['stat'] == 'Aktif'): ?>
                                    <span class="badge bg-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Non-Aktif</span>
                                <?php endif; ?>
                            </td>
                            <td><?= date('d-m-Y', strtotime($row['tgl_tetap'])) ?></td>
                            <td>
                                <button class="btn btn-warning btn-sm btn-action" onclick='editDenda(<?= json_encode($row) ?>)'>
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="biaya_denda.php?hapus=<?= $row['id_biaya_denda'] ?>" class="btn btn-danger btn-sm btn-action" onclick="return confirm('Yakin hapus?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="formModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">Tambah Biaya Denda</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="mb-3">
                        <label class="form-label">Harga Denda per Hari (Rp)</label>
                        <input type="number" name="harga_denda" id="harga_denda" class="form-control" min="0" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="stat" id="stat" class="form-select" required>
                            <option value="Aktif">Aktif</option>
                            <option value="Non-Aktif">Non-Aktif</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Tgl Ditetapkan</label>
                        <input type="date" name="tgl_tetap" id="tgl_tetap" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function resetForm() {
    document.getElementById('modalTitle').textContent = 'Tambah Biaya Denda';
    document.getElementById('edit_id').value = '';
    document.getElementById('harga_denda').value = '';
    document.getElementById('stat').value = 'Aktif';
    document.getElementById('tgl_tetap').value = new Date().toISOString().split('T')[0];
}

function editDenda(data) {
    document.getElementById('modalTitle').textContent = 'Edit Biaya Denda';
    document.getElementById('edit_id').value = data.id_biaya_denda;
    document.getElementById('harga_denda').value = data.harga_denda;
    document.getElementById('stat').value = data.stat;
    document.getElementById('tgl_tetap').value = data.tgl_tetap;
    var modal = new bootstrap.Modal(document.getElementById('formModal'));
    modal.show();
}
</script>

<?php require_once '../includes/footer.php'; ?>
