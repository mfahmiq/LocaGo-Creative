<?php
$page_title = "Rak Buku";
$current_page = "rak";
require_once '../includes/auth_check.php';

if (isset($_GET['hapus'])) {
    $id = escape($_GET['hapus']);
    query("DELETE FROM tbl_rak WHERE id_rak = '$id'");
    set_alert('success', 'Rak berhasil dihapus!');
    redirect('rak.php');
}

if (isset($_POST['simpan'])) {
    $nama = escape($_POST['nama_rak']);
    $edit_id = escape($_POST['edit_id'] ?? '');

    if ($edit_id) {
        query("UPDATE tbl_rak SET nama_rak='$nama' WHERE id_rak='$edit_id'");
        set_alert('success', 'Rak berhasil diupdate!');
    } else {
        query("INSERT INTO tbl_rak (nama_rak) VALUES ('$nama')");
        set_alert('success', 'Rak berhasil ditambahkan!');
    }
    redirect('rak.php');
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$rak = query("SELECT * FROM tbl_rak ORDER BY id_rak ASC");
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between align-items-center mt-3">
        <h4 class="page-title"><i class="fas fa-layer-group me-2"></i>Rak Buku</h4>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#formModal" onclick="resetForm()">
            <i class="fas fa-plus me-1"></i>Tambah
        </button>
    </div>

    <?php $alert = get_alert(); if ($alert): ?>
        <div class="alert alert-<?= $alert['type'] ?> alert-dismissible fade show">
            <?= $alert['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>ID Rak</th>
                            <th>Nama Rak</th>
                            <th width="150">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($rak)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $row['id_rak'] ?></td>
                            <td><?= $row['nama_rak'] ?></td>
                            <td>
                                <button class="btn btn-warning btn-sm btn-action" onclick='editRak(<?= json_encode($row) ?>)'>
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="rak.php?hapus=<?= $row['id_rak'] ?>" class="btn btn-danger btn-sm btn-action" onclick="return confirm('Yakin hapus?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="formModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">Tambah Rak</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="mb-3">
                        <label class="form-label">Nama Rak</label>
                        <input type="text" name="nama_rak" id="nama_rak" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function resetForm() {
    document.getElementById('modalTitle').textContent = 'Tambah Rak';
    document.getElementById('edit_id').value = '';
    document.getElementById('nama_rak').value = '';
}

function editRak(data) {
    document.getElementById('modalTitle').textContent = 'Edit Rak';
    document.getElementById('edit_id').value = data.id_rak;
    document.getElementById('nama_rak').value = data.nama_rak;
    var modal = new bootstrap.Modal(document.getElementById('formModal'));
    modal.show();
}
</script>

<?php require_once '../includes/footer.php'; ?>
