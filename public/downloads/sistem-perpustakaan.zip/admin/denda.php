<?php
$page_title = "Data Denda";
$current_page = "denda";
require_once '../includes/auth_check.php';

if (isset($_GET['hapus'])) {
    $id = escape($_GET['hapus']);
    query("DELETE FROM tbl_denda WHERE id_denda = '$id'");
    set_alert('success', 'Data denda berhasil dihapus!');
    redirect('denda.php');
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$denda = query("SELECT d.*, p.pinjam_id, a.NAMA_ANGGOTA, b.title FROM tbl_denda d
    LEFT JOIN tbl_pinjam p ON d.pinjam_id = p.pinjam_id
    LEFT JOIN anggota a ON p.anggota_id = a.ID_ANGGOTA
    LEFT JOIN tbl_buku b ON p.buku_id = b.buku_id
    ORDER BY d.tgl_denda DESC");
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between align-items-center mt-3">
        <h4 class="page-title"><i class="fas fa-money-bill me-2"></i>Data Denda</h4>
    </div>

    <?php $alert = get_alert(); if ($alert): ?>
        <div class="alert alert-<?= $alert['type'] ?> alert-dismissible fade show">
            <?= $alert['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>ID Denda</th>
                            <th>ID Pinjam</th>
                            <th>Anggota</th>
                            <th>Buku</th>
                            <th>Lama Terlambat</th>
                            <th>Jumlah Denda</th>
                            <th>Tgl Denda</th>
                            <th width="80">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($denda)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $row['id_denda'] ?></td>
                            <td><?= $row['pinjam_id'] ?></td>
                            <td><?= $row['NAMA_ANGGOTA'] ?? '-' ?></td>
                            <td><?= $row['title'] ?? '-' ?></td>
                            <td><?= $row['lama_waktu'] ?> hari</td>
                            <td class="text-danger fw-bold">Rp <?= number_format($row['denda'], 0, ',', '.') ?></td>
                            <td><?= date('d-m-Y', strtotime($row['tgl_denda'])) ?></td>
                            <td>
                                <a href="denda.php?hapus=<?= $row['id_denda'] ?>" class="btn btn-danger btn-sm btn-action" onclick="return confirm('Yakin hapus?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<?php require_once '../includes/footer.php'; ?>
