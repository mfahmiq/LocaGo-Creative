<?php
$page_title = "Laporan";
$current_page = "laporan";
require_once '../includes/auth_check.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$tgl_awal = isset($_GET['tgl_awal']) ? escape($_GET['tgl_awal']) : date('Y-m-01');
$tgl_akhir = isset($_GET['tgl_akhir']) ? escape($_GET['tgl_akhir']) : date('Y-m-t');
$tipe = isset($_GET['tipe']) ? escape($_GET['tipe']) : 'pinjam';

if ($tipe == 'pinjam') {
    $laporan = query("SELECT p.*, a.NAMA_ANGGOTA, a.NO_HP, b.title, b.isbn FROM tbl_pinjam p
        LEFT JOIN anggota a ON p.anggota_id = a.ID_ANGGOTA
        LEFT JOIN tbl_buku b ON p.buku_id = b.buku_id
        WHERE p.tgl_pinjam BETWEEN '$tgl_awal' AND '$tgl_akhir'
        ORDER BY p.tgl_pinjam DESC");
} else {
    $laporan = query("SELECT d.*, p.pinjam_id, a.NAMA_ANGGOTA, b.title FROM tbl_denda d
        LEFT JOIN tbl_pinjam p ON d.pinjam_id = p.pinjam_id
        LEFT JOIN anggota a ON p.anggota_id = a.ID_ANGGOTA
        LEFT JOIN tbl_buku b ON p.buku_id = b.buku_id
        WHERE d.tgl_denda BETWEEN '$tgl_awal' AND '$tgl_akhir'
        ORDER BY d.tgl_denda DESC");
}
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between align-items-center mt-3">
        <h4 class="page-title"><i class="fas fa-chart-bar me-2"></i>Laporan</h4>
        <button onclick="window.print()" class="btn btn-success btn-sm">
            <i class="fas fa-print me-1"></i>Cetak
        </button>
    </div>

    <!-- Filter -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Tipe Laporan</label>
                    <select name="tipe" class="form-select">
                        <option value="pinjam" <?= $tipe == 'pinjam' ? 'selected' : '' ?>>Peminjaman</option>
                        <option value="denda" <?= $tipe == 'denda' ? 'selected' : '' ?>>Denda</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Tgl Awal</label>
                    <input type="date" name="tgl_awal" value="<?= $tgl_awal ?>" class="form-control">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Tgl Akhir</label>
                    <input type="date" name="tgl_akhir" value="<?= $tgl_akhir ?>" class="form-control">
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter me-1"></i>Filter
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Hasil -->
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white d-print-none">
            <h6 class="mb-0">
                Laporan <?= $tipe == 'pinjam' ? 'Peminjaman' : 'Denda' ?>
                | <?= date('d-m-Y', strtotime($tgl_awal)) ?> s/d <?= date('d-m-Y', strtotime($tgl_akhir)) ?>
            </h6>
        </div>
        <div class="card-body">
            <?php if ($tipe == 'pinjam'): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>ID Pinjam</th>
                            <th>Anggota</th>
                            <th>No HP</th>
                            <th>Buku</th>
                            <th>Tgl Pinjam</th>
                            <th>Tgl Kembali</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($laporan)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $row['pinjam_id'] ?></td>
                            <td><?= $row['NAMA_ANGGOTA'] ?></td>
                            <td><?= $row['NO_HP'] ?></td>
                            <td><?= $row['title'] ?></td>
                            <td><?= date('d-m-Y', strtotime($row['tgl_pinjam'])) ?></td>
                            <td><?= $row['tgl_kembali'] ? date('d-m-Y', strtotime($row['tgl_kembali'])) : '-' ?></td>
                            <td>
                                <?= $row['status'] == 'Pinjam' ? '<span class="badge bg-warning">Dipinjam</span>' : '<span class="badge bg-success">Dikembalikan</span>' ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>ID Denda</th>
                            <th>ID Pinjam</th>
                            <th>Anggota</th>
                            <th>Buku</th>
                            <th>Lama Terlambat</th>
                            <th>Jumlah Denda</th>
                            <th>Tgl Denda</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($laporan)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $row['id_denda'] ?></td>
                            <td><?= $row['pinjam_id'] ?></td>
                            <td><?= $row['NAMA_ANGGOTA'] ?? '-' ?></td>
                            <td><?= $row['title'] ?? '-' ?></td>
                            <td><?= $row['lama_waktu'] ?> hari</td>
                            <td>Rp <?= number_format($row['denda'], 0, ',', '.') ?></td>
                            <td><?= date('d-m-Y', strtotime($row['tgl_denda'])) ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
</main>

<style>
@media print {
    .sidebar, nav, .btn, .d-print-none, footer { display: none !important; }
    main { margin-left: 0 !important; }
}
</style>

<?php require_once '../includes/footer.php'; ?>
