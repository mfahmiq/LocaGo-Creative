<?php
$page_title = "Dashboard Admin";
$current_page = "dashboard";
require_once '../includes/auth_check.php';
require_once '../includes/header.php';
require_once '../includes/sidebar.php';

// Hitung statistik
$total_buku = mysqli_fetch_assoc(query("SELECT COUNT(*) as jml FROM tbl_buku"))['jml'];
$total_anggota = mysqli_fetch_assoc(query("SELECT COUNT(*) as jml FROM anggota"))['jml'];
$total_petugas = mysqli_fetch_assoc(query("SELECT COUNT(*) as jml FROM petugas"))['jml'];
$pinjam_aktif = mysqli_fetch_assoc(query("SELECT COUNT(*) as jml FROM tbl_pinjam WHERE status='Pinjam'"))['jml'];
$total_denda = mysqli_fetch_assoc(query("SELECT COALESCE(SUM(denda),0) as total FROM tbl_denda"))['total'];

// Data peminjaman terakhir
$pinjam_terakhir = query("SELECT p.*, a.NAMA_ANGGOTA, b.title FROM tbl_pinjam p
    LEFT JOIN anggota a ON p.anggota_id = a.ID_ANGGOTA
    LEFT JOIN tbl_buku b ON p.buku_id = b.buku_id
    ORDER BY p.id_pinjam DESC LIMIT 5");

// Data buku terbaru
$buku_terbaru = query("SELECT b.*, k.nama_kategori FROM tbl_buku b
    LEFT JOIN tbl_kategori k ON b.id_kategori = k.id_kategori
    ORDER BY b.tgl_masuk DESC LIMIT 5");
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <h4 class="page-title mt-3"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</h4>

    <?php $alert = get_alert(); if ($alert): ?>
        <div class="alert alert-<?= $alert['type'] ?> alert-dismissible fade show">
            <?= $alert['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Stat Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card card-stat shadow-sm">
                <div class="card-body d-flex align-items-center">
                    <div class="icon bg-primary-gradient me-3">
                        <i class="fas fa-book"></i>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0">Total Buku</h6>
                        <h3 class="mb-0"><?= $total_buku ?></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card card-stat shadow-sm">
                <div class="card-body d-flex align-items-center">
                    <div class="icon bg-success-gradient me-3">
                        <i class="fas fa-users"></i>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0">Total Anggota</h6>
                        <h3 class="mb-0"><?= $total_anggota ?></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card card-stat shadow-sm">
                <div class="card-body d-flex align-items-center">
                    <div class="icon bg-warning-gradient me-3">
                        <i class="fas fa-hand-holding"></i>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0">Dipinjam</h6>
                        <h3 class="mb-0"><?= $pinjam_aktif ?></h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card card-stat shadow-sm">
                <div class="card-body d-flex align-items-center">
                    <div class="icon bg-info-gradient me-3">
                        <i class="fas fa-money-bill"></i>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0">Total Denda</h6>
                        <h3 class="mb-0">Rp <?= number_format($total_denda, 0, ',', '.') ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Peminjaman Terakhir -->
        <div class="col-lg-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h6 class="mb-0"><i class="fas fa-history me-2"></i>Peminjaman Terakhir</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Anggota</th>
                                    <th>Buku</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = mysqli_fetch_assoc($pinjam_terakhir)): ?>
                                <tr>
                                    <td><?= $row['NAMA_ANGGOTA'] ?></td>
                                    <td><?= substr($row['title'], 0, 25) ?>...</td>
                                    <td>
                                        <?php if ($row['status'] == 'Pinjam'): ?>
                                            <span class="badge bg-warning">Dipinjam</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">Dikembalikan</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Buku Terbaru -->
        <div class="col-lg-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-success text-white">
                    <h6 class="mb-0"><i class="fas fa-book me-2"></i>Buku Terbaru</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Judul</th>
                                    <th>Kategori</th>
                                    <th>Stok</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = mysqli_fetch_assoc($buku_terbaru)): ?>
                                <tr>
                                    <td><?= substr($row['title'], 0, 25) ?>...</td>
                                    <td><span class="badge bg-info"><?= $row['nama_kategori'] ?></span></td>
                                    <td><?= $row['jml'] ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php require_once '../includes/footer.php'; ?>
