<?php
$page_title = "Data Petugas";
$current_page = "petugas";
require_once '../includes/auth_check.php';

if (isset($_GET['hapus'])) {
    $id = escape($_GET['hapus']);
    
    // Cek apakah petugas masih memiliki akun login
    $cek_login = mysqli_fetch_assoc(query("SELECT COUNT(*) as jml FROM tbl_login WHERE user_id='$id'"));
    
    if ($cek_login['jml'] > 0) {
        set_alert('danger', 'Petugas tidak bisa dihapus karena masih memiliki akun login!');
    } else {
        query("DELETE FROM petugas WHERE ID_PETUGAS = '$id'");
        set_alert('success', 'Data petugas berhasil dihapus!');
    }
    redirect('petugas.php');
}

if (isset($_POST['simpan'])) {
    $nama = escape($_POST['nama']);
    $jk = escape($_POST['jk']);
    $jabatan = escape($_POST['jabatan']);
    $edit_id = escape($_POST['edit_id'] ?? '');

    if ($edit_id) {
        query("UPDATE petugas SET NAMA_PETUGAS='$nama', JK_PETUGAS='$jk', JABATAN='$jabatan' WHERE ID_PETUGAS='$edit_id'");
        set_alert('success', 'Data petugas berhasil diupdate!');
    } else {
        // Auto generate ID petugas berurutan
        $last = mysqli_fetch_assoc(query("SELECT MAX(CAST(SUBSTRING(ID_PETUGAS, 4) AS UNSIGNED)) as last_num FROM petugas"));
        $next_num = ($last['last_num'] ?? 0) + 1;
        $id_petugas = 'PTG' . str_pad($next_num, 2, '0', STR_PAD_LEFT);
        
        query("INSERT INTO petugas VALUES ('$id_petugas','$nama','$jk','$jabatan')");
        set_alert('success', 'Data petugas berhasil ditambahkan! ID: ' . $id_petugas);
    }
    redirect('petugas.php');
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$petugas = query("SELECT * FROM petugas ORDER BY ID_PETUGAS ASC");
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between align-items-center mt-3">
        <h4 class="page-title"><i class="fas fa-user-tie me-2"></i>Data Petugas</h4>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#formModal" onclick="resetForm()">
            <i class="fas fa-plus me-1"></i>Tambah
        </button>
    </div>

    <?php $alert = get_alert(); if ($alert): ?>
        <div class="alert alert-<?= $alert['type'] ?> alert-dismissible fade show">
            <?= $alert['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>ID Petugas</th>
                            <th>Nama</th>
                            <th>Jenis Kelamin</th>
                            <th>Jabatan</th>
                            <th width="150">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($petugas)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $row['ID_PETUGAS'] ?></td>
                            <td><?= $row['NAMA_PETUGAS'] ?></td>
                            <td><?= $row['JK_PETUGAS'] ?></td>
                            <td><?= $row['JABATAN'] ?></td>
                            <td>
                                <button class="btn btn-warning btn-sm btn-action" onclick='editPetugas(<?= json_encode($row) ?>)'>
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="petugas.php?hapus=<?= $row['ID_PETUGAS'] ?>" class="btn btn-danger btn-sm btn-action" onclick="return confirm('Yakin hapus?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="formModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">Tambah Petugas</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="alert alert-info mb-3">
                        <i class="fas fa-info-circle me-1"></i>ID Petugas akan dibuat otomatis oleh sistem.
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nama Petugas</label>
                        <input type="text" name="nama" id="nama" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Jenis Kelamin</label>
                        <select name="jk" id="jk" class="form-select" required>
                            <option value="Laki-Laki">Laki-Laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Jabatan</label>
                        <input type="text" name="jabatan" id="jabatan" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function resetForm() {
    document.getElementById('modalTitle').textContent = 'Tambah Petugas';
    document.getElementById('edit_id').value = '';
    document.getElementById('nama').value = '';
    document.getElementById('jk').value = 'Laki-Laki';
    document.getElementById('jabatan').value = '';
}

function editPetugas(data) {
    document.getElementById('modalTitle').textContent = 'Edit Petugas';
    document.getElementById('edit_id').value = data.ID_PETUGAS;
    document.getElementById('nama').value = data.NAMA_PETUGAS;
    document.getElementById('jk').value = data.JK_PETUGAS;
    document.getElementById('jabatan').value = data.JABATAN;
    var modal = new bootstrap.Modal(document.getElementById('formModal'));
    modal.show();
}
</script>

<?php require_once '../includes/footer.php'; ?>
