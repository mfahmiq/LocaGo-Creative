<?php
$page_title = "Data Buku";
$current_page = "buku";
require_once '../includes/auth_check.php';

// Proses hapus
if (isset($_GET['hapus'])) {
    $id = escape($_GET['hapus']);
    
    // Cek apakah buku masih dalam peminjaman aktif
    $cek_pinjam = mysqli_fetch_assoc(query("SELECT COUNT(*) as jml FROM tbl_pinjam WHERE buku_id=(SELECT buku_id FROM tbl_buku WHERE id_buku='$id') AND status='Pinjam'"));
    
    if ($cek_pinjam['jml'] > 0) {
        set_alert('danger', 'Buku tidak bisa dihapus karena masih dalam peminjaman!');
    } else {
        $buku = mysqli_fetch_assoc(query("SELECT sampul FROM tbl_buku WHERE id_buku='$id'"));
        if ($buku && $buku['sampul'] && file_exists('../assets/img/buku/' . $buku['sampul'])) {
            unlink('../assets/img/buku/' . $buku['sampul']);
        }
        // Hapus data denda terkait
        $buku_data = mysqli_fetch_assoc(query("SELECT buku_id FROM tbl_buku WHERE id_buku='$id'"));
        if ($buku_data) {
            query("DELETE FROM tbl_denda WHERE pinjam_id IN (SELECT pinjam_id FROM tbl_pinjam WHERE buku_id='{$buku_data['buku_id']}')");
            query("DELETE FROM tbl_pinjam WHERE buku_id='{$buku_data['buku_id']}'");
        }
        query("DELETE FROM tbl_buku WHERE id_buku = '$id'");
        set_alert('success', 'Buku berhasil dihapus!');
    }
    redirect('buku.php');
}

// Proses tambah/edit
if (isset($_POST['simpan'])) {
    $id_kategori = escape($_POST['id_kategori']);
    $id_rak = escape($_POST['id_rak']);
    $isbn = escape($_POST['isbn']);
    $title = escape($_POST['title']);
    $penerbit = escape($_POST['penerbit']);
    $pengarang = escape($_POST['pengarang']);
    $thn_buku = escape($_POST['thn_buku']);
    $isi = escape($_POST['isi']);
    $stok_awal = escape($_POST['stok_awal']);
    $edit_id = escape($_POST['edit_id'] ?? '');

    $sampul = '';
    if (isset($_FILES['sampul']) && $_FILES['sampul']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];
        $ext = strtolower(pathinfo($_FILES['sampul']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, $allowed)) {
            $sampul = 'buku_' . time() . '.' . $ext;
            move_uploaded_file($_FILES['sampul']['tmp_name'], '../assets/img/buku/' . $sampul);
        }
    }

    if ($edit_id) {
        $old = mysqli_fetch_assoc(query("SELECT sampul, stok_awal, jml FROM tbl_buku WHERE id_buku='$edit_id'"));
        if ($sampul && $old['sampul'] && file_exists('../assets/img/buku/' . $old['sampul'])) {
            unlink('../assets/img/buku/' . $old['sampul']);
        }
        // Hitung selisih stok awal untuk update jml
        $diff = $stok_awal - $old['stok_awal'];
        $new_jml = $old['jml'] + $diff;
        if ($new_jml < 0) $new_jml = 0;

        if ($sampul) {
            query("UPDATE tbl_buku SET id_kategori='$id_kategori', id_rak='$id_rak', sampul='$sampul', isbn='$isbn', title='$title', penerbit='$penerbit', pengarang='$pengarang', thn_buku='$thn_buku', isi='$isi', stok_awal='$stok_awal', jml='$new_jml' WHERE id_buku='$edit_id'");
        } else {
            query("UPDATE tbl_buku SET id_kategori='$id_kategori', id_rak='$id_rak', isbn='$isbn', title='$title', penerbit='$penerbit', pengarang='$pengarang', thn_buku='$thn_buku', isi='$isi', stok_awal='$stok_awal', jml='$new_jml' WHERE id_buku='$edit_id'");
        }
        set_alert('success', 'Buku berhasil diupdate!');
    } else {
        $last = mysqli_fetch_assoc(query("SELECT MAX(CAST(SUBSTRING(buku_id, 3) AS UNSIGNED)) as last_num FROM tbl_buku"));
        $next_num = ($last['last_num'] ?? 0) + 1;
        $buku_id = 'BK' . str_pad($next_num, 3, '0', STR_PAD_LEFT);
        
        query("INSERT INTO tbl_buku (buku_id, id_kategori, id_rak, sampul, isbn, title, penerbit, pengarang, thn_buku, isi, stok_awal, jml) VALUES ('$buku_id','$id_kategori','$id_rak','$sampul','$isbn','$title','$penerbit','$pengarang','$thn_buku','$isi','$stok_awal','$stok_awal')");
        set_alert('success', 'Buku berhasil ditambahkan! ID: ' . $buku_id);
    }
    redirect('buku.php');
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$buku = query("SELECT b.*, k.nama_kategori, r.nama_rak FROM tbl_buku b
    LEFT JOIN tbl_kategori k ON b.id_kategori = k.id_kategori
    LEFT JOIN tbl_rak r ON b.id_rak = r.id_rak
    ORDER BY b.id_buku DESC");
$kategori = query("SELECT * FROM tbl_kategori ORDER BY nama_kategori");
$rak = query("SELECT * FROM tbl_rak ORDER BY nama_rak");
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between align-items-center mt-3">
        <h4 class="page-title"><i class="fas fa-book me-2"></i>Data Buku</h4>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#formModal" onclick="resetForm()">
            <i class="fas fa-plus me-1"></i>Tambah
        </button>
    </div>

    <?php $alert = get_alert(); if ($alert): ?>
        <div class="alert alert-<?= $alert['type'] ?> alert-dismissible fade show">
            <?= $alert['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>Sampul</th>
                            <th>ID Buku</th>
                            <th>Judul</th>
                            <th>Pengarang</th>
                            <th>Kategori</th>
                            <th>Stok Awal</th>
                            <th>Tersedia</th>
                            <th width="150">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($buku)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td>
                                <?php if ($row['sampul']): ?>
                                    <img src="../assets/img/buku/<?= $row['sampul'] ?>" width="50" height="70" style="object-fit:cover;" class="rounded">
                                <?php else: ?>
                                    <span class="badge bg-secondary">No Image</span>
                                <?php endif; ?>
                            </td>
                            <td><?= $row['buku_id'] ?></td>
                            <td><?= $row['title'] ?></td>
                            <td><?= $row['pengarang'] ?></td>
                            <td><span class="badge bg-info"><?= $row['nama_kategori'] ?></span></td>
                            <td><?= $row['stok_awal'] ?></td>
                            <td>
                                <?php if ($row['jml'] > 0): ?>
                                    <span class="badge bg-success"><?= $row['jml'] ?></span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Habis</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-warning btn-sm btn-action" onclick='editBuku(<?= json_encode($row) ?>)'>
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="buku.php?hapus=<?= $row['id_buku'] ?>" class="btn btn-danger btn-sm btn-action" onclick="return confirm('Yakin hapus?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="formModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">Tambah Buku</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="alert alert-info mb-3">
                        <i class="fas fa-info-circle me-1"></i>ID Buku akan dibuat otomatis oleh sistem.
                    </div>
                    <div class="mb-3">
                        <label class="form-label">ISBN</label>
                        <input type="text" name="isbn" id="isbn" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Judul Buku</label>
                        <input type="text" name="title" id="title" class="form-control" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Pengarang</label>
                            <input type="text" name="pengarang" id="pengarang" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Penerbit</label>
                            <input type="text" name="penerbit" id="penerbit" class="form-control" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Tahun</label>
                            <input type="number" name="thn_buku" id="thn_buku" class="form-control" min="1900" max="2099" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Kategori</label>
                            <select name="id_kategori" id="id_kategori" class="form-select" required>
                                <?php while ($kat = mysqli_fetch_assoc($kategori)): ?>
                                <option value="<?= $kat['id_kategori'] ?>"><?= $kat['nama_kategori'] ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">Rak</label>
                            <select name="id_rak" id="id_rak" class="form-select" required>
                                <?php while ($r = mysqli_fetch_assoc($rak)): ?>
                                <option value="<?= $r['id_rak'] ?>"><?= $r['nama_rak'] ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Stok Awal</label>
                            <input type="number" name="stok_awal" id="stok_awal" class="form-control" min="0" required>
                            <small class="text-muted">Jumlah total buku yang tersedia</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Sampul Buku</label>
                            <input type="file" name="sampul" id="sampul" class="form-control" accept="image/*">
                            <small class="text-muted">Format: JPG, PNG, WEBP (Max 2MB)</small>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="isi" id="isi" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function resetForm() {
    document.getElementById('modalTitle').textContent = 'Tambah Buku';
    document.getElementById('edit_id').value = '';
    document.getElementById('isbn').value = '';
    document.getElementById('title').value = '';
    document.getElementById('pengarang').value = '';
    document.getElementById('penerbit').value = '';
    document.getElementById('thn_buku').value = '';
    document.getElementById('stok_awal').value = '';
    document.getElementById('isi').value = '';
    document.getElementById('sampul').value = '';
}

function editBuku(data) {
    document.getElementById('modalTitle').textContent = 'Edit Buku';
    document.getElementById('edit_id').value = data.id_buku;
    document.getElementById('isbn').value = data.isbn || '';
    document.getElementById('title').value = data.title;
    document.getElementById('pengarang').value = data.pengarang;
    document.getElementById('penerbit').value = data.penerbit;
    document.getElementById('thn_buku').value = data.thn_buku;
    document.getElementById('id_kategori').value = data.id_kategori;
    document.getElementById('id_rak').value = data.id_rak;
    document.getElementById('stok_awal').value = data.stok_awal;
    document.getElementById('isi').value = data.isi || '';
    var modal = new bootstrap.Modal(document.getElementById('formModal'));
    modal.show();
}
</script>

<?php require_once '../includes/footer.php'; ?>
