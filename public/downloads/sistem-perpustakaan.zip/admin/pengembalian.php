<?php
$page_title = "Pengembalian Buku";
$current_page = "pengembalian";
require_once '../includes/auth_check.php';

// Proses pengembalian
if (isset($_POST['kembalikan'])) {
    $id_pinjam = escape($_POST['id_pinjam']);
    $tgl_kembali = date('Y-m-d');

    // Ambil data pinjam
    $pinjam = mysqli_fetch_assoc(query("SELECT * FROM tbl_pinjam WHERE id_pinjam='$id_pinjam' AND status='Pinjam'"));

    if ($pinjam) {
        $tgl_balik = $pinjam['tgl_balik'];
        $lama_pinjam = $pinjam['lama_pinjam'];

        // Hitung denda jika terlambat
        $selisih = (strtotime($tgl_kembali) - strtotime($tgl_balik)) / (60 * 60 * 24);

        // Ambil biaya denda aktif
        $denda_aktif = mysqli_fetch_assoc(query("SELECT harga_denda FROM tbl_biaya_denda WHERE stat='Aktif' LIMIT 1"));
        $harga_denda = $denda_aktif ? $denda_aktif['harga_denda'] : 5000;

        if ($selisih > 0) {
            $total_denda = $selisih * $harga_denda;
            $lama_waktu = (int)$selisih;

            // Generate ID denda
            $last_denda = mysqli_fetch_assoc(query("SELECT MAX(id_denda) as max_id FROM tbl_denda"));
            $new_denda_id = ($last_denda['max_id'] ?? 0) + 1;

            query("INSERT INTO tbl_denda (id_denda, pinjam_id, denda, lama_waktu, tgl_denda) VALUES ('$new_denda_id', '$pinjam[pinjam_id]', '$total_denda', '$lama_waktu', '$tgl_kembali')");
        }

        // Update status pinjam
        query("UPDATE tbl_pinjam SET status='Di Kembalikan', tgl_kembali='$tgl_kembali' WHERE id_pinjam='$id_pinjam'");

        // Tambah stok buku
        query("UPDATE tbl_buku SET jml = jml + 1 WHERE buku_id='$pinjam[buku_id]'");

        if ($selisih > 0) {
            set_alert('warning', "Buku dikembalikan dengan denda Rp " . number_format($total_denda, 0, ',', '.') . " ($lama_waktu hari terlambat)");
        } else {
            set_alert('success', 'Buku berhasil dikembalikan tanpa denda!');
        }
    }
    redirect('pengembalian.php');
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$pinjam = query("SELECT p.*, a.NAMA_ANGGOTA, b.title FROM tbl_pinjam p
    LEFT JOIN anggota a ON p.anggota_id = a.ID_ANGGOTA
    LEFT JOIN tbl_buku b ON p.buku_id = b.buku_id
    WHERE p.status = 'Pinjam'
    ORDER BY p.tgl_balik ASC");
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between align-items-center mt-3">
        <h4 class="page-title"><i class="fas fa-undo me-2"></i>Pengembalian Buku</h4>
    </div>

    <?php $alert = get_alert(); if ($alert): ?>
        <div class="alert alert-<?= $alert['type'] ?> alert-dismissible fade show">
            <?= $alert['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>ID Pinjam</th>
                            <th>Anggota</th>
                            <th>Buku</th>
                            <th>Tgl Pinjam</th>
                            <th>Tgl Harus Kembali</th>
                            <th>Hari Ini</th>
                            <th>Terlambat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($pinjam)):
                            $hari_ini = date('Y-m-d');
                            $selisih = (strtotime($hari_ini) - strtotime($row['tgl_balik'])) / (60*60*24);
                            $terlambat = $selisih > 0 ? (int)$selisih : 0;
                        ?>
                        <tr class="<?= $terlambat > 0 ? 'table-danger' : '' ?>">
                            <td><?= $no++ ?></td>
                            <td><?= $row['pinjam_id'] ?></td>
                            <td><?= $row['NAMA_ANGGOTA'] ?></td>
                            <td><?= $row['title'] ?></td>
                            <td><?= date('d-m-Y', strtotime($row['tgl_pinjam'])) ?></td>
                            <td><?= date('d-m-Y', strtotime($row['tgl_balik'])) ?></td>
                            <td><?= date('d-m-Y') ?></td>
                            <td>
                                <?php if ($terlambat > 0): ?>
                                    <span class="badge bg-danger"><?= $terlambat ?> hari</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Tepat waktu</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Konfirmasi pengembalian?')">
                                    <input type="hidden" name="id_pinjam" value="<?= $row['id_pinjam'] ?>">
                                    <button type="submit" name="kembalikan" class="btn btn-success btn-sm">
                                        <i class="fas fa-check me-1"></i>Kembalikan
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<?php require_once '../includes/footer.php'; ?>
