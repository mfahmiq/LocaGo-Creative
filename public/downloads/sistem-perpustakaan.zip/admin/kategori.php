<?php
$page_title = "Kategori Buku";
$current_page = "kategori";
require_once '../includes/auth_check.php';

if (isset($_GET['hapus'])) {
    $id = escape($_GET['hapus']);
    query("DELETE FROM tbl_kategori WHERE id_kategori = '$id'");
    set_alert('success', 'Kategori berhasil dihapus!');
    redirect('kategori.php');
}

if (isset($_POST['simpan'])) {
    $nama = escape($_POST['nama_kategori']);
    $edit_id = escape($_POST['edit_id'] ?? '');

    if ($edit_id) {
        query("UPDATE tbl_kategori SET nama_kategori='$nama' WHERE id_kategori='$edit_id'");
        set_alert('success', 'Kategori berhasil diupdate!');
    } else {
        query("INSERT INTO tbl_kategori (nama_kategori) VALUES ('$nama')");
        set_alert('success', 'Kategori berhasil ditambahkan!');
    }
    redirect('kategori.php');
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$kategori = query("SELECT * FROM tbl_kategori ORDER BY id_kategori ASC");
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between align-items-center mt-3">
        <h4 class="page-title"><i class="fas fa-tags me-2"></i>Kategori Buku</h4>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#formModal" onclick="resetForm()">
            <i class="fas fa-plus me-1"></i>Tambah
        </button>
    </div>

    <?php $alert = get_alert(); if ($alert): ?>
        <div class="alert alert-<?= $alert['type'] ?> alert-dismissible fade show">
            <?= $alert['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>ID Kategori</th>
                            <th>Nama Kategori</th>
                            <th width="150">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($kategori)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $row['id_kategori'] ?></td>
                            <td><?= $row['nama_kategori'] ?></td>
                            <td>
                                <button class="btn btn-warning btn-sm btn-action" onclick='editKategori(<?= json_encode($row) ?>)'>
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="kategori.php?hapus=<?= $row['id_kategori'] ?>" class="btn btn-danger btn-sm btn-action" onclick="return confirm('Yakin hapus?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="formModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">Tambah Kategori</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="mb-3">
                        <label class="form-label">Nama Kategori</label>
                        <input type="text" name="nama_kategori" id="nama_kategori" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function resetForm() {
    document.getElementById('modalTitle').textContent = 'Tambah Kategori';
    document.getElementById('edit_id').value = '';
    document.getElementById('nama_kategori').value = '';
}

function editKategori(data) {
    document.getElementById('modalTitle').textContent = 'Edit Kategori';
    document.getElementById('edit_id').value = data.id_kategori;
    document.getElementById('nama_kategori').value = data.nama_kategori;
    var modal = new bootstrap.Modal(document.getElementById('formModal'));
    modal.show();
}
</script>

<?php require_once '../includes/footer.php'; ?>
