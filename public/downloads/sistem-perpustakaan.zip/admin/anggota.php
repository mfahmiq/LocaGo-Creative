<?php
$page_title = "Data Anggota";
$current_page = "anggota";
require_once '../includes/auth_check.php';

// Proses hapus
if (isset($_GET['hapus'])) {
    $id = escape($_GET['hapus']);
    
    // Cek apakah anggota masih memiliki peminjaman aktif
    $cek_pinjam = mysqli_fetch_assoc(query("SELECT COUNT(*) as jml FROM tbl_pinjam WHERE anggota_id='$id' AND status='Pinjam'"));
    
    if ($cek_pinjam['jml'] > 0) {
        set_alert('danger', 'Anggota tidak bisa dihapus karena masih memiliki peminjaman aktif!');
    } else {
        // Hapus data terkait
        query("DELETE FROM tbl_denda WHERE pinjam_id IN (SELECT pinjam_id FROM tbl_pinjam WHERE anggota_id='$id')");
        query("DELETE FROM tbl_pinjam WHERE anggota_id='$id'");
        query("DELETE FROM tbl_login WHERE user_id='$id'");
        query("DELETE FROM anggota WHERE ID_ANGGOTA = '$id'");
        set_alert('success', 'Data anggota berhasil dihapus!');
    }
    redirect('anggota.php');
}

// Proses tambah/edit
if (isset($_POST['simpan'])) {
    $nama = escape($_POST['nama']);
    $tgl_lahir = escape($_POST['tgl_lahir']);
    $alamat = escape($_POST['alamat']);
    $jk = escape($_POST['jk']);
    $no_hp = escape($_POST['no_hp']);
    $edit_id = escape($_POST['edit_id'] ?? '');

    if ($edit_id) {
        query("UPDATE anggota SET NAMA_ANGGOTA='$nama', TANGGAL_LAHIR='$tgl_lahir', ALAMAT='$alamat', JK='$jk', NO_HP='$no_hp' WHERE ID_ANGGOTA='$edit_id'");
        set_alert('success', 'Data anggota berhasil diupdate!');
    } else {
        // Auto generate ID anggota berurutan
        $last = mysqli_fetch_assoc(query("SELECT MAX(CAST(SUBSTRING(ID_ANGGOTA, 3) AS UNSIGNED)) as last_num FROM anggota"));
        $next_num = ($last['last_num'] ?? 0) + 1;
        $id_anggota = 'AG' . str_pad($next_num, 3, '0', STR_PAD_LEFT);
        
        query("INSERT INTO anggota VALUES ('$id_anggota','$nama','$tgl_lahir','$alamat','$jk','$no_hp')");
        set_alert('success', 'Data anggota berhasil ditambahkan! ID: ' . $id_anggota);
    }
    redirect('anggota.php');
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$anggota = query("SELECT * FROM anggota ORDER BY ID_ANGGOTA ASC");
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between align-items-center mt-3">
        <h4 class="page-title"><i class="fas fa-users me-2"></i>Data Anggota</h4>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#formModal" onclick="resetForm()">
            <i class="fas fa-plus me-1"></i>Tambah
        </button>
    </div>

    <?php $alert = get_alert(); if ($alert): ?>
        <div class="alert alert-<?= $alert['type'] ?> alert-dismissible fade show">
            <?= $alert['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>ID Anggota</th>
                            <th>Nama</th>
                            <th>Tgl Lahir</th>
                            <th>Alamat</th>
                            <th>Jenis Kelamin</th>
                            <th>No HP</th>
                            <th width="150">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($anggota)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $row['ID_ANGGOTA'] ?></td>
                            <td><?= $row['NAMA_ANGGOTA'] ?></td>
                            <td><?= date('d-m-Y', strtotime($row['TANGGAL_LAHIR'])) ?></td>
                            <td><?= $row['ALAMAT'] ?></td>
                            <td><?= $row['JK'] ?></td>
                            <td><?= $row['NO_HP'] ?></td>
                            <td>
                                <button class="btn btn-warning btn-sm btn-action" onclick='editAnggota(<?= json_encode($row) ?>)'>
                                    <i class="fas fa-edit"></i>
                                </button>
                                <a href="anggota.php?hapus=<?= $row['ID_ANGGOTA'] ?>" class="btn btn-danger btn-sm btn-action" onclick="return confirm('Yakin hapus?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<!-- Modal Form -->
<div class="modal fade" id="formModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="modalTitle">Tambah Anggota</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="alert alert-info mb-3">
                        <i class="fas fa-info-circle me-1"></i>ID Anggota akan dibuat otomatis oleh sistem.
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nama Anggota</label>
                        <input type="text" name="nama" id="nama" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Tanggal Lahir</label>
                        <input type="date" name="tgl_lahir" id="tgl_lahir" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Alamat</label>
                        <input type="text" name="alamat" id="alamat" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Jenis Kelamin</label>
                        <select name="jk" id="jk" class="form-select" required>
                            <option value="Laki-Laki">Laki-Laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">No HP</label>
                        <input type="text" name="no_hp" id="no_hp" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function resetForm() {
    document.getElementById('modalTitle').textContent = 'Tambah Anggota';
    document.getElementById('edit_id').value = '';
    document.getElementById('nama').value = '';
    document.getElementById('tgl_lahir').value = '';
    document.getElementById('alamat').value = '';
    document.getElementById('jk').value = 'Laki-Laki';
    document.getElementById('no_hp').value = '';
}

function editAnggota(data) {
    document.getElementById('modalTitle').textContent = 'Edit Anggota';
    document.getElementById('edit_id').value = data.ID_ANGGOTA;
    document.getElementById('nama').value = data.NAMA_ANGGOTA;
    document.getElementById('tgl_lahir').value = data.TANGGAL_LAHIR;
    document.getElementById('alamat').value = data.ALAMAT;
    document.getElementById('jk').value = data.JK;
    document.getElementById('no_hp').value = data.NO_HP;
    var modal = new bootstrap.Modal(document.getElementById('formModal'));
    modal.show();
}
</script>

<?php require_once '../includes/footer.php'; ?>
