<?php
$page_title = "Peminjaman Buku";
$current_page = "pinjam";
require_once '../includes/auth_check.php';

// Proses tambah pinjam
if (isset($_POST['simpan'])) {
    $anggota_id = escape($_POST['anggota_id']);
    $buku_id = escape($_POST['buku_id']);
    $lama_pinjam = escape($_POST['lama_pinjam']);
    $tgl_pinjam = escape($_POST['tgl_pinjam']);
    $tgl_balik = date('Y-m-d', strtotime($tgl_pinjam . " +$lama_pinjam days"));

    $stok = mysqli_fetch_assoc(query("SELECT jml FROM tbl_buku WHERE buku_id='$buku_id'"));
    if ($stok['jml'] > 0) {
        // Auto generate pinjam_id berurutan
        $last = mysqli_fetch_assoc(query("SELECT MAX(CAST(SUBSTRING(pinjam_id, 3) AS UNSIGNED)) as last_num FROM tbl_pinjam"));
        $next_num = ($last['last_num'] ?? 0) + 1;
        $pinjam_id = 'PJ' . str_pad($next_num, 3, '0', STR_PAD_LEFT);

        query("INSERT INTO tbl_pinjam (pinjam_id, anggota_id, buku_id, status, tgl_pinjam, lama_pinjam, tgl_balik) VALUES ('$pinjam_id','$anggota_id','$buku_id','Pinjam','$tgl_pinjam','$lama_pinjam','$tgl_balik')");
        query("UPDATE tbl_buku SET jml = jml - 1 WHERE buku_id='$buku_id'");
        set_alert('success', 'Peminjaman berhasil! ID: ' . $pinjam_id);
    } else {
        set_alert('danger', 'Stok buku habis!');
    }
    redirect('pinjam.php');
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';

$pinjam = query("SELECT p.*, a.NAMA_ANGGOTA, b.title FROM tbl_pinjam p
    LEFT JOIN anggota a ON p.anggota_id = a.ID_ANGGOTA
    LEFT JOIN tbl_buku b ON p.buku_id = b.buku_id
    ORDER BY p.id_pinjam DESC");
$anggota = query("SELECT * FROM anggota ORDER BY NAMA_ANGGOTA");
$buku = query("SELECT * FROM tbl_buku WHERE jml > 0 ORDER BY title");
?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div class="d-flex justify-content-between align-items-center mt-3">
        <h4 class="page-title"><i class="fas fa-hand-holding me-2"></i>Peminjaman Buku</h4>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#formModal" onclick="resetForm()">
            <i class="fas fa-plus me-1"></i>Tambah Pinjam
        </button>
    </div>

    <?php $alert = get_alert(); if ($alert): ?>
        <div class="alert alert-<?= $alert['type'] ?> alert-dismissible fade show">
            <?= $alert['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th width="50">No</th>
                            <th>ID Pinjam</th>
                            <th>Anggota</th>
                            <th>Buku</th>
                            <th>Tgl Pinjam</th>
                            <th>Lama</th>
                            <th>Tgl Kembali</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; while ($row = mysqli_fetch_assoc($pinjam)): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $row['pinjam_id'] ?></td>
                            <td><?= $row['NAMA_ANGGOTA'] ?></td>
                            <td><?= $row['title'] ?></td>
                            <td><?= date('d-m-Y', strtotime($row['tgl_pinjam'])) ?></td>
                            <td><?= $row['lama_pinjam'] ?> hari</td>
                            <td><?= date('d-m-Y', strtotime($row['tgl_balik'])) ?></td>
                            <td>
                                <?php if ($row['status'] == 'Pinjam'): ?>
                                    <span class="badge bg-warning">Dipinjam</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Dikembalikan</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="formModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Tambah Pinjam</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info mb-3">
                        <i class="fas fa-info-circle me-1"></i>ID Pinjam akan dibuat otomatis oleh sistem.
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Anggota</label>
                        <select name="anggota_id" class="form-select" required>
                            <option value="">-- Pilih Anggota --</option>
                            <?php while ($a = mysqli_fetch_assoc($anggota)): ?>
                            <option value="<?= $a['ID_ANGGOTA'] ?>"><?= $a['ID_ANGGOTA'] ?> - <?= $a['NAMA_ANGGOTA'] ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Buku</label>
                        <select name="buku_id" class="form-select" required>
                            <option value="">-- Pilih Buku --</option>
                            <?php while ($b = mysqli_fetch_assoc($buku)): ?>
                            <option value="<?= $b['buku_id'] ?>"><?= $b['buku_id'] ?> - <?= $b['title'] ?> (Stok: <?= $b['jml'] ?>)</option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Tgl Pinjam</label>
                            <input type="date" name="tgl_pinjam" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Lama Pinjam (hari)</label>
                            <select name="lama_pinjam" class="form-select" required>
                                <option value="3">3 Hari</option>
                                <option value="7" selected>7 Hari</option>
                                <option value="14">14 Hari</option>
                                <option value="30">30 Hari</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function resetForm() {
    document.getElementById('formModal').querySelector('form').reset();
}
</script>

<?php require_once '../includes/footer.php'; ?>
