# Sistem Manajemen Perpustakaan

Sistem informasi manajemen perpustakaan berbasis web yang dibangun menggunakan PHP, MySQL, dan Bootstrap 5.

## Tech Stack

- **Backend**: PHP 8.x
- **Database**: MySQL/MariaDB
- **Frontend**: Bootstrap 5
- **Server**: Apache (XAMPP)

---

## Fitur

### Admin / Petugas
- Dashboard dengan statistik (total buku, anggota, pinjam aktif, denda)
- Manajemen Data Anggota (CRUD + auto-generated ID)
- Manajemen Data Petugas (CRUD + auto-generated ID)
- Manajemen Data Buku (CRUD + upload sampul + stok awal)
- Manajemen Kategori Buku
- Manajemen Rak Buku
- Peminjaman Buku (auto cek stok)
- Pengembalian Buku (auto hitung denda jika terlambat)
- Pengaturan Biaya Denda
- Laporan Peminjaman & Denda (dengan filter tanggal + cetak)
- Profil Admin

### Anggota
- Dashboard (status pinjam, buku tersedia, total denda)
- **Pinjam Buku** - Pilih buku dan tentukan lama pinjam
- Riwayat Peminjaman Pribadi
- Edit Profil

### Umum
- **Dark & Light Theme** - Toggle tema gelap/terang dengan tombol di navbar (preferensi tersimpan di localStorage)
- Responsive Design
- Auto-generated ID untuk semua data

---

## Persiapan

### 1. Instalasi XAMPP

Pastikan XAMPP sudah terinstall dan Apache + MySQL berjalan.

- Buka **XAMPP Control Panel**
- Start **Apache** dan **MySQL**

### 2. Import Database

1. Buka browser, akses `http://localhost/phpmyadmin`
2. Klik tab **Databases** / **New**
3. Buat database baru dengan nama `perpustakaan`
4. Klik tab **Import**
5. Pilih file `perpustakaan.sql` dari folder project ini
6. Klik **Go** / **Import**

### 3. Jalankan Website

1. Copy folder `perpustakaan` ke `C:/xampp/htdocs/`
2. Buka browser, akses: `http://localhost/perpustakaan/`
3. Login dengan akun yang tersedia

> Password sudah di-hash langsung di SQL. Semua akun menggunakan password: **password**

---

## Akun Login

### Anggota
| Username | Password | Level | Nama |
|----------|----------|-------|------|
| ahmad | password | Anggota | Ahmad Rizky |
| siti | password | Anggota | Siti Rahma |
| budi | password | Anggota | Budi Santoso |
| dewi_p | password | Anggota | Dewi Putri |
| fajar | password | Anggota | Fajar Nugroho |
| gita | password | Anggota | Gita Sari |

### Petugas
| Username | Password | Level | Nama |
|----------|----------|-------|------|
| dewi | password | Petugas | Dewi Lestari |
| rian | password | Petugas | Rian Hidayat |
| andi | password | Petugas | Andi Pratama |
| rina | password | Petugas | Rina Wati |
| dimas | password | Petugas | Dimas Aditya |
| salsa | password | Petugas | Salsa Billa |

---

## Cara Menggunakan

### Login sebagai Anggota
1. Buka `http://localhost/perpustakaan/`
2. Login dengan akun anggota (contoh: `ahmad` / `password`)
3. Di dashboard, akan terlihat daftar buku yang tersedia
4. Klik tombol **Pinjam** pada buku yang ingin dipinjam
5. Pilih lama pinjam (3/7/14/30 hari)
6. Klik **Konfirmasi Pinjam**
7. Stok buku akan berkurang otomatis
8. Lihat riwayat peminjaman di menu **Riwayat Pinjam**

### Login sebagai Petugas
1. Login dengan akun petugas (contoh: `dewi` / `password`)
2. Kelola data anggota, petugas, buku, kategori, rak
3. Proses pengembalian buku (otomatis hitung denda jika terlambat)
4. Lihat laporan peminjaman dan denda

### Ganti Theme
1. Klik ikon bulan/matahari di navbar (kanan atas)
2. Preferensi tema akan tersimpan otomatis

---

## Struktur Folder

```
perpustakaan/
├── config/
│   └── koneksi.php          # Koneksi ke database
├── auth/
│   ├── login.php            # Halaman login
│   ├── proses_login.php     # Proses autentikasi
│   └── logout.php           # Proses logout
├── admin/
│   ├── index.php            # Dashboard admin
│   ├── anggota.php          # CRUD Anggota
│   ├── petugas.php          # CRUD Petugas
│   ├── buku.php             # CRUD Buku (+ stok awal)
│   ├── kategori.php         # CRUD Kategori
│   ├── rak.php              # CRUD Rak
│   ├── pinjam.php           # Peminjaman Buku
│   ├── pengembalian.php     # Pengembalian + Denda
│   ├── denda.php            # Data Denda
│   ├── biaya_denda.php      # Pengaturan Tarif Denda
│   ├── laporan.php          # Laporan + Cetak
│   └── profil.php           # Profil Admin
├── anggota/
│   ├── index.php            # Dashboard + Pinjam Buku
│   ├── riwayat.php          # Riwayat Peminjaman
│   └── profil.php           # Profil Anggota
├── includes/
│   ├── header.php           # Header & Navbar + Theme Toggle
│   ├── footer.php           # Footer
│   ├── sidebar.php          # Sidebar
│   └── auth_check.php       # Middleware Cek Login
├── assets/
│   ├── css/style.css        # Custom CSS (Light/Dark Theme)
│   └── img/buku/            # Folder Sampul Buku
├── index.php                # Halaman Utama (redirect)
└── perpustakaan.sql         # File Database
```

---

## Database

### Tabel yang Digunakan

| Tabel | Deskripsi |
|-------|-----------|
| `anggota` | Data anggota perpustakaan |
| `petugas` | Data petugas / librarian |
| `tbl_kategori` | Kategori buku |
| `tbl_rak` | Rak buku |
| `tbl_buku` | Data buku (+ kolom stok_awal) |
| `tbl_biaya_denda` | Pengaturan tarif denda |
| `tbl_pinjam` | Data peminjaman |
| `tbl_denda` | Data denda keterlambatan |
| `tbl_login` | Akun pengguna (login) |

### Fitur Stok Awal

Tabel `tbl_buku` memiliki kolom:
- `stok_awal`: Jumlah total buku saat pertama kali dimasukkan
- `jml`: Jumlah buku yang tersedia saat ini (akan berkurang saat dipinjam)

Contoh: Buku dengan stok_awal = 25, jika sudah dipinjam 2 buku, maka jml = 23.

### Auto-Generated ID

Semua ID dibuat otomatis berurutan oleh sistem:
- Anggota: `AG001`, `AG002`, `AG003`, ...
- Petugas: `PTG01`, `PTG02`, ...
- Buku: `BK001`, `BK002`, ...
- Pinjam: `PJ001`, `PJ002`, ...

---

## Alur Sistem

```
Anggota Login → Lihat Buku Tersedia → Pinjam Buku
                                          ↓
                                    Stok berkurang
                                          ↓
Admin/Ketika Kembali → Proses Pengembalian
                           ↓
                    Cek Tanggal Kembali
                           ↓
                    Hitung Denda (jika terlambat)
                           ↓
                    Stok bertambah
```

---

## Catatan

- Denda otomatis dihitung saat pengembalian buku berdasarkan keterlambatan
- Tarif denda dapat diatur melalui menu **Biaya Denda** (hanya boleh 1 yang Aktif)
- Stok buku otomatis berkurang saat dipinjam dan bertambah saat dikembalikan
- Laporan dapat dicetak dengan klik tombol **Cetak**
- Setiap anggota memiliki akun login sendiri untuk meminjam buku
- Dark/Light theme tersedia, preferensi tersimpan di localStorage

---

## Author

**MOH. REZA ALFI ALI**

- Email: mohrezaalfiali123@gmail.com
- GitHub: [mrezaalfiali](https://github.com/mrezaalfiali)
- Instagram: [@mrezaaaxx](https://instagram.com/mrezaaaxx)
- LinkedIn: [Moh Reza Alfiali](https://linkedin.com/in/mohrezaalfiali)

---

## License

This project is for educational purposes.
