# Cek Padi Yuk! — Sistem Pakar Diagnosis Penyakit Padi

Aplikasi web **sistem pakar** berbasis **PHP native + MySQL** untuk membantu petani dan pengguna umum mengenali penyakit pada tanaman padi. Pengguna menjawab serangkaian pertanyaan gejala (**Ya / Tidak**), lalu sistem menghitung **persentase kecocokan** gejala terhadap tiap penyakit dan menampilkan hasil beserta solusinya.

**Pembuat:** Steven Andrian Pranata Wicaksono

---

## Daftar Isi

1. [Fitur](#fitur)
2. [Peran Pengguna](#peran-pengguna)
3. [Cara Kerja Diagnosis](#cara-kerja-diagnosis)
4. [Teknologi](#teknologi)
5. [Struktur Folder](#struktur-folder)
6. [Kebutuhan Sistem](#kebutuhan-sistem)
7. [Instalasi](#instalasi)
8. [Cara Menggunakan Aplikasi](#cara-menggunakan-aplikasi)
9. [Struktur Database](#struktur-database)
10. [Catatan Penting tentang Data](#catatan-penting-tentang-data)
11. [Pemecahan Masalah](#pemecahan-masalah)
12. [Catatan Pengembangan](#catatan-pengembangan)

---

## Fitur

- **Registrasi dan login** dengan password ter-hash (`password_hash`).
- **Tes gejala interaktif:** satu pertanyaan per halaman, dijawab *Ya* atau *Tidak*.
- **Hasil diagnosis** berupa persentase kecocokan untuk 7 penyakit padi: Bercak Daun Coklat, Bias, Pelepah Daun, Fusarium, Kresek Hawar Daun, Kerdil, dan Tungro.
- **Solusi penanganan** untuk penyakit dengan persentase tertinggi.
- **Cek ulang** untuk mengulang tes dari awal.
- **Panel admin/pakar** untuk mengelola data gejala, penyakit, solusi, pasien, dan pakar.

## Peran Pengguna

| Peran | Nilai `role` | Hak akses |
| --- | --- | --- |
| **Pasien** (pengguna umum) | `1` | Registrasi sendiri, melakukan tes gejala, melihat hasil |
| **Admin** | `0` | Dashboard admin: kelola pasien, pakar, penyakit, gejala, solusi |
| **Pakar** | `2` | Masuk ke panel pengelolaan; didaftarkan oleh admin lewat `register_pakar.php` |

## Cara Kerja Diagnosis

1. Pengguna login, lalu sistem menampilkan pertanyaan gejala satu per satu ("Apakah ... ?").
2. Setiap jawaban **Ya** dicatat ke sesi; jawaban **Tidak** dilewati.
3. Setelah semua gejala ditanyakan (ID gejala 1 sampai 31), sistem menghitung untuk tiap penyakit:

```
persentase = (jumlah gejala penyakit yang dijawab "Ya") / (jumlah seluruh gejala penyakit tsb) × 100%
```

4. Hasil semua penyakit ditampilkan, dan solusi diambil untuk penyakit dengan persentase tertinggi.

**Aturan gejala per penyakit** (ID gejala, ditetapkan langsung di `test.php`):

| Penyakit | ID gejala |
| --- | --- |
| Bercak Daun Coklat | 1, 2, 3, 4, 5, 6 |
| Bias | 7, 8, 9, 10 |
| Pelepah Daun | 1, 11, 12, 13 |
| Fusarium | 7, 14, 15, 16, 17 |
| Kresek Hawar Daun | 15, 18, 19, 20, 21, 22 |
| Kerdil | 23, 24, 25, 26, 27, 28, 29 |
| Tungro | 16, 21, 22, 23, 29, 30, 31 |

## Teknologi

- PHP (ekstensi `mysqli`), session PHP
- MySQL / MariaDB
- HTML, CSS, **Bootstrap 4.4.1** (CDN), **Google Fonts – Poppins** (CDN)

## Struktur Folder

```
cekpadi/
├── index.php            # Halaman depan + modal login
├── register.php         # Registrasi pasien
├── register_pakar.php   # Registrasi pakar (oleh admin)
├── test.php             # Tes gejala (tanya jawab Ya/Tidak)
├── hasil.php            # Hasil diagnosis dan solusi
├── function.php         # Koneksi database + semua fungsi (login, CRUD, dll.)
├── logout.php
│
├── indexAdmin.php       # Dashboard admin (daftar pasien)
├── indexPakar.php       # Daftar pakar
├── indexPenyakit.php    # Daftar penyakit
├── indexGejala.php      # Daftar gejala
├── indexSolusi.php      # Daftar solusi
├── tambah*.php          # Form tambah (Gejala, Penyakit, Solusi)
├── ubah*.php            # Form ubah (Gejala, Penyakit, Solusi, Pasien, Pakar)
│
├── styles.css, custom.css
├── gambar/              # Logo dan gambar ilustrasi
└── db_penyakitginjal.sql   # Dump database
```

---

## Kebutuhan Sistem

- **XAMPP** atau **Laragon** (sudah termasuk PHP, Apache, MySQL, phpMyAdmin), atau PHP 7.4+ dengan ekstensi `mysqli` dan MySQL/MariaDB.
- Koneksi internet, agar Bootstrap dan font dari CDN termuat.

## Instalasi

### 1. Ambil project
```bash
git clone https://github.com/USERNAME/NAMA-REPO.git
```

### 2. Taruh di folder web server
| Aplikasi | Lokasi |
| --- | --- |
| XAMPP | `C:\xampp\htdocs\cekpadi` |
| Laragon | `C:\laragon\www\cekpadi` |

### 3. Jalankan Apache dan MySQL
Lewat XAMPP Control Panel (**Start** pada Apache dan MySQL) atau Laragon (**Start All**).

### 4. Buat dan impor database
Nama database harus **`db_penyakitginjal`** (sesuai `function.php`).

1. Buka `http://localhost/phpmyadmin`.
2. Klik **New**, buat database `db_penyakitginjal` (collation `utf8mb4_general_ci`).
3. Pilih database tersebut, buka tab **Import**, pilih `db_penyakitginjal.sql`, klik **Go**.

Alternatif lewat terminal:
```bash
mysql -u root -e "CREATE DATABASE db_penyakitginjal CHARACTER SET utf8mb4;"
mysql -u root db_penyakitginjal < db_penyakitginjal.sql
```

### 5. Cek koneksi
Di `function.php` baris pertama:
```php
$koneksi = mysqli_connect('localhost', 'root', '', 'db_penyakitginjal');
```
Sesuaikan username dan password MySQL Anda bila berbeda.

### 6. Buka aplikasi
```
http://localhost/cekpadi/
```

---

## Cara Menggunakan Aplikasi

### Sebagai pasien (pengguna umum)
1. Buka halaman depan, klik **Mulai!** atau **Register**.
2. Isi form: **nama, email, password (minimal 8 karakter), alamat, tanggal lahir**, lalu klik **Register**.
3. Setelah muncul pesan berhasil, klik **Log In**, lalu masuk dengan **nama** dan **password** (login memakai kolom *nama*, bukan email).
4. Anda masuk ke halaman tes. Jawab tiap pertanyaan dengan **Ya** atau **Tidak** sampai selesai.
5. Halaman hasil menampilkan persentase tiap penyakit dan solusinya.
6. Klik **Cek Ulang** untuk mengulang tes, atau **Log Out** untuk keluar.

### Sebagai admin
1. Login dengan akun berperan admin (role `0`). Anda masuk ke **Dashboard Admin**.
2. Menu di sidebar:
   - **Dashboard** — daftar dan jumlah pasien, tombol edit/hapus.
   - **Penyakit** — tambah, ubah, hapus penyakit.
   - **Gejala** — tambah, ubah, hapus gejala.
   - **Solusi** — tambah, ubah, hapus solusi tiap penyakit.
   - **Log Out**
3. Pakar baru didaftarkan lewat `register_pakar.php`.

> **Akun admin:** database contoh sudah memuat satu akun admin, tetapi password-nya tersimpan sebagai hash sehingga tidak diketahui dari file. Jika lupa, ubah password lewat phpMyAdmin: buat hash baru dengan PHP (`echo password_hash('passwordBaru', PASSWORD_DEFAULT);`) lalu tempel ke kolom `password` pada tabel `user`.

---

## Struktur Database

**Database:** `db_penyakitginjal`

| Tabel | Kolom utama | Fungsi |
| --- | --- | --- |
| `user` | `id_user`, `role`, `nama`, `email`, `alamat`, `tgl_lahir`, `password` | Akun pasien (1), admin (0), pakar (2) |
| `gejala` | `id_gejala`, `gejala` | Daftar pertanyaan gejala |
| `penyakit` | `id_penyakit`, `penyakit` | Daftar penyakit |
| `relasi` | `id_relasi`, `id_gejala`, `id_penyakit` | Hubungan gejala dengan penyakit |
| `solusi` | `id_solusi`, `id_penyakit`, `solusi` | Solusi tiap penyakit |

---

## Catatan Penting tentang Data

File `db_penyakitginjal.sql` yang disertakan **masih berisi data penyakit ginjal** (6 penyakit ginjal, 27 gejala ginjal, dan solusi ginjal). Data itu sisa dari proyek sistem pakar sebelumnya, sedangkan tampilan dan aturan perhitungan di kode sudah untuk **penyakit padi**. Akibatnya:

- Login, registrasi, dan panel admin **berfungsi normal**.
- Pada tes gejala, pertanyaan yang muncul masih gejala ginjal, bukan gejala padi.
- Kode memproses **31 gejala**, sedangkan data contoh hanya memiliki **27**, sehingga pertanyaan nomor 28–31 tampil kosong.

**Agar diagnosis padi berjalan benar**, isi data berikut lewat panel admin atau SQL:
1. **7 penyakit padi** pada tabel `penyakit`.
2. **31 gejala padi** pada tabel `gejala`, dengan nomor ID yang sesuai [tabel aturan](#cara-kerja-diagnosis) di atas.
3. **Solusi** tiap penyakit pada tabel `solusi`.

## Pemecahan Masalah

| Masalah | Solusi |
| --- | --- |
| `Koneksi Database Gagal` | MySQL belum jalan, atau username/password di `function.php` salah |
| `Unknown database 'db_penyakitginjal'` | Database belum dibuat; ulangi langkah 4 |
| Halaman kosong / kode PHP tampil mentah | Buka lewat `http://localhost/...`, bukan `file:///...` |
| Login tidak berpindah halaman | Login memakai **nama**, bukan email; pastikan password benar |
| Pertanyaan tes menampilkan "Apakah ?" | Gejala dengan ID tersebut belum ada di tabel `gejala` |
| Tampilan berantakan | Tidak ada internet (Bootstrap CDN tidak termuat) |
| Tes tidak mulai dari awal | Klik **Cek Ulang**, atau logout lalu login kembali |

## Catatan Pengembangan

Proyek ini dibuat untuk pembelajaran. Perbaikan yang disarankan:

- **Prepared statement** untuk semua query; saat ini sebagian besar query menyisipkan input langsung (rentan SQL injection).
- **Hapus data lewat POST**, bukan tautan GET (`function.php?act=hapus...`).
- **Pindahkan penanda jawaban dan aturan penyakit ke database** (tabel `relasi`), bukan di-hardcode di `test.php`.
- Cek hak akses (role) di setiap halaman admin.
- Tambahkan pesan jelas saat password salah di login.

## Lisensi

Dibuat untuk keperluan tugas kuliah.
