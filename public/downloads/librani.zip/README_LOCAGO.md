# Sistem Informasi Perpustakaan - Librani

```
========================================================================
📦 Sistem Informasi Perpustakaan - Librani
Kategori     : Pendidikan & Akademik
Tech Stack   : PHP Native • PHP • MySQL
Database     : MySQL (.sql) (File: database/librani.sql)
Sumber Asli  : https://github.com/davsantoso/librani (GitHub Open Source)
Stars GitHub : ⭐ 0 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/librani`
     * Untuk Laragon: `C:/laragon/www/librani`
   - CATATAN: paket ini SUDAH MELENGKAPI folder `assets/vendor/` (Bootstrap 5.3.3,
     Bootstrap Icons 1.11.3, DataTables 2.1.8, Chart.js 4.4.1, jQuery 3.7.1,
     SweetAlert2, SheetJS, JsBarcode, qrcodejs, html5-qrcode — diunduh dari jsDelivr
     sesuai dokumen desain repo). Repo asli TIDAK menyertakan folder ini, jadi
     tanpa vendor/ tampilan aplikasi rusak (tidak ada styling Bootstrap).
     Jangan hapus folder `assets/vendor/`.

2. KONFIGURASI KONEKSI DATABASE:
   - Salin file `config/config.example.php` menjadi `config/config.php`,
     lalu sesuaikan isinya:
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = librani
     * BASE_URL = URL aplikasi Anda, contoh: http://localhost/librani
       (PENTING: semua link & aset dibuat dari BASE_URL — bila salah,
       halaman tampil tanpa styling dan login gagal redirect.)

3. BUAT DATABASE + IMPORT DATA (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru bernama `librani` (file SQL TIDAK membuat database
     sendiri — harus dibuat manual dulu).
   - Pilih database `librani`, klik tab 'Import', pilih file:
     `database/librani.sql`, lalu klik 'Go' / 'Kirim'.
   - Import ini membuat 14 tabel + seluruh data contoh (50 judul buku,
     120 eksemplar, 22 anggota, transaksi & denda) + SEMUA akun demo di bawah.
     TIDAK PERLU menjalankan seed.php — akun login sudah jadi dari import ini.

4. (OPSIONAL) COMPOSER — HANYA UNTUK EKSPOR PDF:
   - Jalankan `composer install` di folder proyek bila butuh tombol ekspor PDF
     (Dompdf). Tanpa ini aplikasi tetap jalan normal; tombol PDF disembunyikan.

5. JALANKAN SEED.PHP — JANGAN DIJALANKAN (SAAT INI RUSAK):
   - `database/seed.php` saat ini GAGAL di tengah jalan (fatal error:
     "Tanggal kembali tidak boleh sebelum tanggal pinjam") karena bug di
     `includes/helpers.php` fungsi `tambah_hari()`: untuk tanggal mundur
     (mis. -20 hari) ia membangun `"+-20 day"` yang dibaca PHP sebagai
     +20 hari (maju), sehingga skenario demo (pinjam H-20, kembali H-10)
     ditolak validasi. Perbaikan untuk penulis repo: hapus tanda `+`
     di `tambah_hari()` (pakai `"$ymd $hari day"`).
   - Karena import SQL langkah 3 sudah berisi semua data, seed.php
     TIDAK DIBUTUHKAN. Jangan menjalankannya sampai repo memperbaikinya.

6. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/librani

7. AKUN LOGIN DEMO (TERVERIFIKASI — tercantum di README repo bagian
   "Akun demo" dan di header database/librani.sql; password sudah
   dicocokkan dengan hash bcrypt di database):
   - Administrator : admin / admin123
   - Petugas       : petugas1 / petugas123
   - Anggota       : anggota1 / anggota123

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
