<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SIGMA RENTAL - Rental Mobil & Sepeda Motor Terpercaya</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body class="bg-slate-950 text-white font-sans antialiased">

    <!-- Header Navigation -->
    <header class="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <div class="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center font-black text-slate-950 text-xl shadow-lg">
                    <span class="material-icons">directions_car</span>
                </div>
                <div>
                    <span class="font-extrabold text-xl tracking-wider text-white">SIGMA</span>
                    <span class="text-xs text-emerald-400 block font-semibold">RENTAL MANAGEMENT</span>
                </div>
            </div>

            <div class="flex items-center space-x-4">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-sm shadow transition">
                        Buka Dashboard &rarr;
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="text-sm font-semibold text-slate-300 hover:text-white px-3 py-2">Masuk / Login</a>
                    <a href="<?php echo e(route('register')); ?>" class="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-sm shadow transition">
                        Daftar Akun Baru
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="relative py-24 px-6 max-w-7xl mx-auto flex flex-col items-center text-center">
        <span class="px-4 py-1.5 rounded-full text-xs font-extrabold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase tracking-widest mb-6">
            Penyewaan Armada Mobil & Sepeda Motor #1
        </span>
        <h1 class="text-4xl sm:text-6xl font-black tracking-tight max-w-4xl leading-tight">
            Sistem Management Rental Modern, Cepat & Terintegrasi
        </h1>
        <p class="mt-6 text-slate-400 max-w-2xl text-base sm:text-lg">
            Sewa mobil MPV, SUV, sedan, hingga sepeda motor matic & sport dengan verifikasi identitas cepat, perhitungan denda otomatis, dan invoice otomatis.
        </p>
        <div class="mt-8 flex flex-wrap gap-4 justify-center">
            <a href="<?php echo e(route('login')); ?>" class="px-8 py-4 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-2xl text-base shadow-xl transition">
                Mulai Sewa Kendaraan
            </a>
            <a href="<?php echo e(route('calendar')); ?>" class="px-8 py-4 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-2xl text-base border border-slate-700 transition">
                Cek Ketersediaan Armada
            </a>
        </div>
    </section>

    <!-- Fleet Feature Grid -->
    <section class="py-16 bg-slate-900 border-t border-slate-800 px-6">
        <div class="max-w-7xl mx-auto">
            <h2 class="text-2xl font-black text-center mb-12">Armada Populer Siap Pakai</h2>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <?php $__currentLoopData = App\Models\Kendaraan::take(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden p-6 flex flex-col justify-between">
                        <div>
                            <span class="text-xs font-bold text-emerald-400 uppercase tracking-wider"><?php echo e($item->kategori->nama ?? 'Armada'); ?></span>
                            <h3 class="text-xl font-bold mt-1 text-white"><?php echo e($item->merk); ?> <?php echo e($item->tipe); ?></h3>
                            <p class="text-xs text-slate-400 mt-2"><?php echo e($item->deskripsi ?? 'Mobil/Motor kondisi super aman & wangi.'); ?></p>
                        </div>
                        <div class="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
                            <div>
                                <span class="text-[10px] text-slate-500 uppercase">Tarif Daily</span>
                                <div class="text-lg font-black text-emerald-400">Rp <?php echo e(number_format($item->harga_sewa_per_hari, 0, ',', '.')); ?>/hari</div>
                            </div>
                            <a href="<?php echo e(route('login')); ?>" class="px-3 py-1.5 bg-emerald-500 text-slate-950 font-bold text-xs rounded-lg hover:bg-emerald-400 transition">
                                Sewa
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <footer class="py-8 text-center text-xs text-slate-600 border-t border-slate-900">
        &copy; <?php echo e(date('Y')); ?> SIGMA RENTAL MANAGEMENT SYSTEM. Built with Laravel 11, Blade, PHP 8.2 & Tailwind CSS.
    </footer>
</body>
</html>
<?php /**PATH C:\Users\ibnus\Downloads\sigma-rental\resources\views/welcome.blade.php ENDPATH**/ ?>