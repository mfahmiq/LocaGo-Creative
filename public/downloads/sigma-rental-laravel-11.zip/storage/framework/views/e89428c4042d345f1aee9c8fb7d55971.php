<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-black text-slate-900"><?php echo e(auth()->user()?->hasRole('Customer') ? 'Status Pengembalian & Denda Saya' : 'Pengembalian Armada & Perhitungan Denda'); ?></h1>
            <p class="text-xs text-slate-500"><?php echo e(auth()->user()?->hasRole('Customer') ? 'Riwayat pengembalian kendaraan dan rincian denda (jika ada).' : 'Proses pengembalian kendaraan dan hitung otomatis denda keterlambatan (10%/hari).'); ?></p>
        </div>
    </div>

    <?php if(auth()->user()?->hasRole('Admin') || auth()->user()?->hasRole('Petugas')): ?>
    <!-- Process Return Form -->
    <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm" x-data="{
        selectedBooking: '',
        tglRencana: '',
        tglAktual: '<?php echo e(date('Y-m-d')); ?>',
        hargaPerHari: 0,
        biayaKerusakan: 0,
        get keterlambatan() {
            if(!this.tglRencana || !this.tglAktual) return 0;
            let dR = new Date(this.tglRencana);
            let dA = new Date(this.tglAktual);
            let diff = Math.ceil((dA - dR) / (1000 * 60 * 60 * 24));
            return diff > 0 ? diff : 0;
        },
        get dendaKeterlambatan() {
            return this.keterlambatan * (this.hargaPerHari * 0.10);
        },
        get dendaTotal() {
            return this.dendaKeterlambatan + (parseFloat(this.biayaKerusakan) || 0);
        },
        onSelectBooking(e) {
            let opt = e.target.options[e.target.selectedIndex];
            this.tglRencana = opt.getAttribute('data-rencana') || '';
            this.hargaPerHari = parseFloat(opt.getAttribute('data-harga') || 0);
        }
    }">
        <h3 class="text-sm font-bold text-slate-800 mb-4 flex items-center">
            <span class="material-icons text-emerald-600 mr-2">assignment_return</span>
            Proses Pengembalian Kendaraan Sehabis Sewa
        </h3>

        <form method="POST" action="<?php echo e(route('pengembalian.store')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Pilih Transaksi Booking Berjalan *</label>
                    <select name="booking_id" required @change="onSelectBooking($event)" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                        <option value="">-- Pilih Booking --</option>
                        <?php $__currentLoopData = $activeBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($b->id); ?>" data-rencana="<?php echo e($b->tgl_kembali_rencana->format('Y-m-d')); ?>" data-harga="<?php echo e($b->kendaraan->harga_sewa_per_hari ?? 0); ?>">
                                <?php echo e($b->kode_booking); ?> - <?php echo e($b->user->name ?? ''); ?> (<?php echo e($b->kendaraan->merk ?? ''); ?> <?php echo e($b->kendaraan->tipe ?? ''); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Tanggal Pengembalian Aktual *</label>
                    <input type="date" name="tgl_pengembalian_aktual" x-model="tglAktual" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Kondisi Kendaraan *</label>
                    <select name="kondisi_kendaraan" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                        <option value="Baik">Baik & Bersih (Tanpa Kerusakan)</option>
                        <option value="Baret Ringan">Baret Ringan</option>
                        <option value="Rusak Sedang">Rusak Sedang</option>
                        <option value="Rusak Parah">Rusak Parah</option>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Biaya Kerusakan (Jika Ada Rp)</label>
                    <input type="number" name="biaya_kerusakan" x-model="biayaKerusakan" placeholder="0" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
            </div>

            <!-- Auto Fine Preview Box -->
            <div class="p-4 bg-amber-50/90 rounded-xl border border-amber-200 text-xs space-y-2">
                <div class="flex justify-between font-medium text-slate-700">
                    <span>Estimasi Keterlambatan:</span>
                    <span class="font-bold text-slate-900" x-text="keterlambatan + ' Hari'"></span>
                </div>
                <div class="flex justify-between font-medium text-slate-700">
                    <span>Denda Keterlambatan (10%/hari):</span>
                    <span class="font-bold text-amber-800" x-text="'Rp ' + Number(dendaKeterlambatan).toLocaleString('id-ID')"></span>
                </div>
                <div x-show="biayaKerusakan > 0" class="flex justify-between font-medium text-slate-700">
                    <span>Biaya Kerusakan:</span>
                    <span class="font-bold text-rose-700" x-text="'Rp ' + Number(biayaKerusakan || 0).toLocaleString('id-ID')"></span>
                </div>
                <div class="border-t border-amber-200 pt-2 flex justify-between font-bold text-sm text-amber-900">
                    <span>Total Denda & Biaya Tambahan:</span>
                    <span class="text-base text-rose-600 font-black" x-text="'Rp ' + Number(dendaTotal).toLocaleString('id-ID')"></span>
                </div>
            </div>

            <div class="flex justify-end">
                <button type="submit" class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition">
                    Proses Pengembalian Armada
                </button>
            </div>
        </form>
    </div>
    <?php endif; ?>

    <!-- Returns History & Fine Payment Status -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="p-4 border-b border-slate-100 font-bold text-slate-800 text-sm">
            Riwayat Pengembalian & Status Denda
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
                <thead class="bg-slate-50 text-slate-500 font-semibold uppercase border-b border-slate-200">
                    <tr>
                        <th class="p-4">Kode Booking</th>
                        <th class="p-4">Customer</th>
                        <th class="p-4">Kendaraan</th>
                        <th class="p-4">Tgl Pengembalian</th>
                        <th class="p-4">Terlambat</th>
                        <th class="p-4">Kondisi</th>
                        <th class="p-4">Total Denda</th>
                        <th class="p-4 text-center">Aksi Denda</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 font-medium">
                    <?php $__empty_1 = true; $__currentLoopData = $pengembalianList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50 transition">
                            <td class="p-4 font-bold text-slate-900"><?php echo e($item->booking->kode_booking ?? 'N/A'); ?></td>
                            <td class="p-4 text-slate-700"><?php echo e($item->booking->user->name ?? ''); ?></td>
                            <td class="p-4 text-emerald-700 font-semibold"><?php echo e($item->booking->kendaraan->merk ?? ''); ?> <?php echo e($item->booking->kendaraan->tipe ?? ''); ?></td>
                            <td class="p-4 text-slate-500"><?php echo e($item->tgl_pengembalian_aktual->format('d M Y')); ?></td>
                            <td class="p-4 font-bold <?php echo e($item->keterlambatan_hari > 0 ? 'text-rose-600' : 'text-slate-600'); ?>">
                                <?php echo e($item->keterlambatan_hari); ?> Hari
                            </td>
                            <td class="p-4 text-slate-700"><?php echo e($item->kondisi_kendaraan); ?></td>
                            <td class="p-4 font-black text-slate-900">
                                <?php if($item->denda): ?>
                                    Rp <?php echo e(number_format($item->denda->total_denda, 0, ',', '.')); ?>

                                <?php else: ?>
                                    Rp 0
                                <?php endif; ?>
                            </td>
                            <td class="p-4 text-center">
                                <?php if($item->denda && $item->denda->status_pembayaran == 'Belum Lunas'): ?>
                                    <form method="POST" action="<?php echo e(route('denda.bayar', $item->denda->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-bold shadow">
                                            Konfirmasi Lunas
                                        </button>
                                    </form>
                                <?php elseif($item->denda && $item->denda->status_pembayaran == 'Lunas'): ?>
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">Lunas</span>
                                <?php else: ?>
                                    <span class="text-[10px] text-slate-400">Tidak ada denda</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="p-8 text-center text-slate-400">Belum ada riwayat pengembalian kendaraan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ibnus\Downloads\sigma-rental\resources\views/pengembalian/index.blade.php ENDPATH**/ ?>