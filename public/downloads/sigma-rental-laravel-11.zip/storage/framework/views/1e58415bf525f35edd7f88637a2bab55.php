<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Invoice <?php echo e($pembayaran->booking->kode_booking ?? ''); ?></title>
    <style>
        body { font-family: sans-serif; font-size: 12px; color: #333; margin: 20px; }
        .header { border-bottom: 2px solid #16a34a; padding-bottom: 10px; margin-bottom: 20px; }
        .brand { font-size: 20px; font-weight: bold; color: #16a34a; }
        .subtitle { font-size: 10px; color: #666; }
        .table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .table th, .table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .table th { background-color: #f8fafc; font-weight: bold; }
        .total { font-size: 14px; font-weight: bold; color: #16a34a; }
    </style>
</head>
<body>
    <div class="header">
        <div class="brand">SIGMA RENTAL</div>
        <div class="subtitle">Sistem Rental Mobil & Sepeda Motor Terpercaya</div>
    </div>

    <h3>INVOICE PEMBAYARAN</h3>
    <p><strong>Kode Booking:</strong> <?php echo e($pembayaran->booking->kode_booking ?? ''); ?></p>
    <p><strong>Nama Penyewa:</strong> <?php echo e($pembayaran->booking->user->name ?? ''); ?></p>
    <p><strong>Tanggal Transaksi:</strong> <?php echo e($pembayaran->tgl_pembayaran ? $pembayaran->tgl_pembayaran->format('d M Y H:i') : ''); ?></p>

    <table class="table">
        <thead>
            <tr>
                <th>Kendaraan</th>
                <th>Tanggal Sewa</th>
                <th>Durasi</th>
                <th>Tarif / Hari</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($pembayaran->booking->kendaraan->merk ?? ''); ?> <?php echo e($pembayaran->booking->kendaraan->tipe ?? ''); ?> (<?php echo e($pembayaran->booking->kendaraan->plat_nomor ?? ''); ?>)</td>
                <td><?php echo e($pembayaran->booking->tgl_sewa->format('d/m/Y')); ?> - <?php echo e($pembayaran->booking->tgl_kembali_rencana->format('d/m/Y')); ?></td>
                <td><?php echo e($pembayaran->booking->durasi_hari); ?> Hari</td>
                <td>Rp <?php echo e(number_format($pembayaran->booking->harga_per_hari, 0, ',', '.')); ?></td>
                <td>Rp <?php echo e(number_format($pembayaran->booking->subtotal, 0, ',', '.')); ?></td>
            </tr>
        </tbody>
    </table>

    <div style="margin-top: 20px; text-align: right;">
        <p class="total">Total Bayar: Rp <?php echo e(number_format($pembayaran->jumlah_bayar, 0, ',', '.')); ?></p>
        <p style="color: green; font-weight: bold;">[ STATUS: <?php echo e(strtoupper($pembayaran->status)); ?> ]</p>
    </div>
</body>
</html>
<?php /**PATH C:\Users\ibnus\Downloads\sigma-rental\resources\views/pembayaran/invoice.blade.php ENDPATH**/ ?>