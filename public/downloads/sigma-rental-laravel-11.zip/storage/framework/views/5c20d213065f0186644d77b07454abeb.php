<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-black text-slate-900">Katalog Armada Kendaraan</h1>
            <p class="text-xs text-slate-500">Daftar pilihan mobil dan sepeda motor berkualitas siap sewa.</p>
        </div>
        <?php if(auth()->user()?->hasRole('Admin') || auth()->user()?->hasRole('Petugas')): ?>
        <a href="<?php echo e(route('kendaraan.create')); ?>" class="inline-flex items-center px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow transition">
            <span class="material-icons text-sm mr-2">add</span> Tambah Kendaraan Baru
        </a>
        <?php endif; ?>
    </div>

    <!-- Filters & Search -->
    <form method="GET" action="<?php echo e(route('kendaraan.index')); ?>" class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-col sm:flex-row gap-3">
        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari merk, tipe, atau plat nomor..." class="flex-1 text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
        
        <select name="kategori_id" class="text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
            <option value="">Semua Kategori</option>
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($kat->id); ?>" <?php echo e(request('kategori_id') == $kat->id ? 'selected' : ''); ?>><?php echo e($kat->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <select name="status" class="text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
            <option value="">Semua Status</option>
            <option value="Tersedia" <?php echo e(request('status') == 'Tersedia' ? 'selected' : ''); ?>>Tersedia</option>
            <option value="Booking" <?php echo e(request('status') == 'Booking' ? 'selected' : ''); ?>>Booking</option>
            <option value="Disewa" <?php echo e(request('status') == 'Disewa' ? 'selected' : ''); ?>>Disewa</option>
            <option value="Servis" <?php echo e(request('status') == 'Servis' ? 'selected' : ''); ?>>Servis</option>
        </select>

        <button type="submit" class="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-xl transition">Filter</button>
    </form>

    <!-- Vehicles Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $kendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col justify-between hover:shadow-md transition">
                <div>
                    <!-- Vehicle Image / Placeholder -->
                    <div class="h-44 bg-slate-100 relative flex items-center justify-center overflow-hidden">
                        <?php if($item->foto): ?>
                            <img src="<?php echo e(asset('storage/' . $item->foto)); ?>" alt="<?php echo e($item->merk); ?>" class="w-full h-full object-cover">
                        <?php else: ?>
                            <div class="text-slate-400 flex flex-col items-center">
                                <span class="material-icons text-4xl">directions_car</span>
                                <span class="text-[10px] mt-1">Foto Belum Diunggah</span>
                            </div>
                        <?php endif; ?>
                        
                        <span class="absolute top-3 right-3 px-3 py-1 rounded-full text-[10px] font-bold shadow-sm 
                            <?php echo e($item->status == 'Tersedia' ? 'bg-emerald-500 text-white' : ''); ?>

                            <?php echo e($item->status == 'Booking' ? 'bg-blue-500 text-white' : ''); ?>

                            <?php echo e($item->status == 'Disewa' ? 'bg-amber-500 text-white' : ''); ?>

                            <?php echo e($item->status == 'Servis' ? 'bg-rose-500 text-white' : ''); ?>">
                            <?php echo e($item->status); ?>

                        </span>

                        <span class="absolute bottom-3 left-3 bg-slate-900/80 backdrop-blur-sm text-white text-[10px] font-bold px-2.5 py-1 rounded-lg">
                            <?php echo e($item->plat_nomor); ?>

                        </span>
                    </div>

                    <div class="p-5">
                        <div class="text-xs font-bold text-emerald-600 uppercase"><?php echo e($item->kategori->nama ?? 'Umum'); ?></div>
                        <h3 class="text-base font-black text-slate-900 mt-1"><?php echo e($item->merk); ?> <?php echo e($item->tipe); ?></h3>
                        <p class="text-xs text-slate-500">Tahun Rilis: <?php echo e($item->tahun); ?></p>

                        <p class="text-xs text-slate-600 mt-3 line-clamp-2"><?php echo e($item->deskripsi ?? 'Kendaraan operasional siap sewa dengan kondisi prima.'); ?></p>

                        <div class="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
                            <div>
                                <span class="text-[10px] text-slate-400 font-semibold uppercase">Tarif Sewa</span>
                                <div class="text-lg font-black text-slate-900">
                                    Rp <?php echo e(number_format($item->harga_sewa_per_hari, 0, ',', '.')); ?> <span class="text-xs font-normal text-slate-500">/hari</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Card Actions -->
                <div class="px-5 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                    <a href="<?php echo e(route('booking.create', ['kendaraan_id' => $item->id])); ?>" class="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center">
                        <span class="material-icons text-sm mr-1">book_online</span> Sewa Sekarang
                    </a>
                    
                    <?php if(auth()->user()?->hasRole('Admin') || auth()->user()?->hasRole('Petugas')): ?>
                    <div class="flex items-center space-x-2">
                        <a href="<?php echo e(route('kendaraan.edit', $item->id)); ?>" class="p-1.5 text-slate-600 hover:text-blue-600 rounded-lg hover:bg-white transition" title="Edit">
                            <span class="material-icons text-sm">edit</span>
                        </a>
                        <form method="POST" action="<?php echo e(route('kendaraan.destroy', $item->id)); ?>" onsubmit="return confirm('Apakah Anda yakin ingin menghapus kendaraan ini?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="p-1.5 text-slate-600 hover:text-rose-600 rounded-lg hover:bg-white transition" title="Hapus">
                                <span class="material-icons text-sm">delete</span>
                            </button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full bg-white p-12 text-center rounded-2xl border border-slate-200">
                <span class="material-icons text-5xl text-slate-300">search_off</span>
                <p class="mt-2 text-slate-500 text-sm">Kendaraan tidak ditemukan.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        <?php echo e($kendaraan->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ibnus\Downloads\sigma-rental\resources\views/kendaraan/index.blade.php ENDPATH**/ ?>