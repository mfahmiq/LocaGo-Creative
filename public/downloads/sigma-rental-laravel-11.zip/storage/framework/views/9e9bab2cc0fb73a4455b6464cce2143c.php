<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-black text-slate-900"><?php echo e(auth()->user()?->hasRole('Customer') ? 'Riwayat Pembayaran Saya' : 'Modul Pembayaran & Bukti Transfer'); ?></h1>
            <p class="text-xs text-slate-500"><?php echo e(auth()->user()?->hasRole('Customer') ? 'Unggah dan cek status verifikasi pembayaran sewa Anda.' : 'Unggah bukti transfer pembayaran sewa dan verifikasi dari petugas.'); ?></p>
        </div>
    </div>

    <!-- Upload Pembayaran Form (for Customers or Staff) -->
    <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm" x-data="{
        openUpload: true,
        jumlahBayar: '',
        selectedKode: '',
        selectedArmada: '',
        selectedPelanggan: '',
        onSelectBooking(e) {
            let opt = e.target.options[e.target.selectedIndex];
            if (opt && opt.value) {
                this.jumlahBayar = opt.getAttribute('data-total') || '';
                this.selectedKode = opt.getAttribute('data-kode') || '';
                this.selectedArmada = opt.getAttribute('data-armada') || '';
                this.selectedPelanggan = opt.getAttribute('data-user') || '';
            } else {
                this.jumlahBayar = '';
                this.selectedKode = '';
                this.selectedArmada = '';
                this.selectedPelanggan = '';
            }
        }
    }">
        <div class="flex items-center justify-between cursor-pointer" @click="openUpload = !openUpload">
            <h3 class="text-sm font-bold text-slate-800 flex items-center">
                <span class="material-icons text-emerald-600 mr-2">upload_file</span>
                Form Unggah Bukti Pembayaran
            </h3>
            <span class="material-icons text-slate-400" x-text="openUpload ? 'expand_less' : 'expand_more'"></span>
        </div>

        <form method="POST" action="<?php echo e(route('pembayaran.store')); ?>" enctype="multipart/form-data" class="mt-4 space-y-4" x-show="openUpload" x-transition>
            <?php echo csrf_field(); ?>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Pilih Booking (Belum Lunas) *</label>
                    <select name="booking_id" required @change="onSelectBooking($event)" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                        <?php
                            $bookingQuery = App\Models\Booking::whereDoesntHave('pembayaran', function($q) {
                                $q->where('status', 'Verified');
                            })->with(['kendaraan', 'user'])->latest();

                            if (auth()->user()?->hasRole('Customer')) {
                                $bookingQuery->where('user_id', auth()->id());
                            }

                            $bookingOptions = $bookingQuery->get();
                        ?>
                        <?php if($bookingOptions->isEmpty()): ?>
                            <option value="">-- Semua Booking Sudah Terbayar (Lunas) --</option>
                        <?php else: ?>
                            <option value="">-- Pilih Kode Booking Belum Lunas --</option>
                            <?php $__currentLoopData = $bookingOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($b->id); ?>"
                                        data-total="<?php echo e($b->total_bayar); ?>"
                                        data-kode="<?php echo e($b->kode_booking); ?>"
                                        data-user="<?php echo e($b->user->name ?? 'Pelanggan'); ?>"
                                        data-armada="<?php echo e($b->kendaraan->merk ?? ''); ?> <?php echo e($b->kendaraan->tipe ?? ''); ?> (<?php echo e($b->kendaraan->plat_nomor ?? '-'); ?>)">
                                    <?php echo e($b->kode_booking); ?> - Rp <?php echo e(number_format($b->total_bayar, 0, ',', '.')); ?> (<?php echo e($b->kendaraan->merk ?? ''); ?> <?php echo e($b->kendaraan->tipe ?? ''); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Metode Pembayaran *</label>
                    <select name="metode_pembayaran" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                        <option value="Transfer Bank BCA">Transfer Bank BCA (456-789-0123 a/n SIGMA RENTAL)</option>
                        <option value="Transfer Bank Mandiri">Transfer Bank Mandiri (123-000-4567 a/n SIGMA RENTAL)</option>
                        <option value="QRIS Standard">QRIS All Payment</option>
                        <option value="Cash / Tunai">Cash / Tunai di Kasir</option>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Jumlah Bayar (Rp) - Otomatis Terisi *</label>
                    <div class="relative">
                        <input type="number" name="jumlah_bayar" x-model="jumlahBayar" placeholder="Pilih kode booking di atas..." required class="w-full text-xs border border-emerald-300 bg-emerald-50/50 rounded-xl px-3 py-2.5 font-bold text-emerald-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                        <span class="absolute right-3 top-2.5 text-[10px] text-emerald-600 font-semibold uppercase">Auto-filled</span>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Foto Bukti Transfer *</label>
                    <input type="file" name="bukti_pembayaran" accept="image/*" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
            </div>

            <!-- Auto Relational Summary Card -->
            <div x-show="selectedKode" x-transition class="p-4 bg-emerald-50/80 rounded-xl border border-emerald-200 text-xs grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                    <span class="text-slate-500 font-medium block">Kode Booking:</span>
                    <span class="font-bold text-slate-900" x-text="selectedKode"></span>
                </div>
                <div>
                    <span class="text-slate-500 font-medium block">Pelanggan & Armada:</span>
                    <span class="font-bold text-slate-900" x-text="selectedPelanggan + ' • ' + selectedArmada"></span>
                </div>
                <div>
                    <span class="text-slate-500 font-medium block">Total Tagihan Booking:</span>
                    <span class="font-black text-emerald-700 text-sm" x-text="'Rp ' + Number(jumlahBayar || 0).toLocaleString('id-ID')"></span>
                </div>
            </div>

            <div class="flex justify-end">
                <button type="submit" class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition flex items-center">
                    <span class="material-icons text-sm mr-1.5">send</span> Kirim Bukti Pembayaran
                </button>
            </div>
        </form>
    </div>

    <!-- Payments Table -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
                <thead class="bg-slate-50 text-slate-500 font-semibold uppercase border-b border-slate-200">
                    <tr>
                        <th class="p-4">Booking</th>
                        <th class="p-4">Metode</th>
                        <th class="p-4">Jumlah Bayar</th>
                        <th class="p-4">Tanggal Pembayaran</th>
                        <th class="p-4">Status Verifikasi</th>
                        <th class="p-4 text-center">Invoice & Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 font-medium">
                    <?php $__empty_1 = true; $__currentLoopData = $pembayaranList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50 transition">
                            <td class="p-4">
                                <div class="font-bold text-slate-900"><?php echo e($p->booking->kode_booking ?? 'N/A'); ?></div>
                                <div class="text-[10px] text-slate-500"><?php echo e($p->booking->user->name ?? ''); ?></div>
                            </td>
                            <td class="p-4 text-slate-700"><?php echo e($p->metode_pembayaran); ?></td>
                            <td class="p-4 font-black text-slate-900">Rp <?php echo e(number_format($p->jumlah_bayar, 0, ',', '.')); ?></td>
                            <td class="p-4 text-slate-500"><?php echo e($p->tgl_pembayaran->format('d M Y H:i')); ?></td>
                            <td class="p-4">
                                <?php if($p->status == 'Verified'): ?>
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 inline-flex items-center">
                                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-600 mr-1.5"></span>
                                        Terbayar (Pemasukan)
                                    </span>
                                <?php elseif($p->status == 'Pending'): ?>
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 inline-flex items-center">
                                        <span class="w-1.5 h-1.5 rounded-full bg-amber-500 mr-1.5"></span>
                                        Pending (Belum Masuk)
                                    </span>
                                <?php else: ?>
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 inline-flex items-center">
                                        <span class="w-1.5 h-1.5 rounded-full bg-rose-500 mr-1.5"></span>
                                        Ditolak
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="p-4 text-center space-x-2">
                                <a href="<?php echo e(route('pembayaran.invoice', $p->id)); ?>" class="inline-flex items-center px-2.5 py-1 bg-slate-800 text-white rounded-lg text-[10px] font-bold hover:bg-slate-900 shadow">
                                    <span class="material-icons text-xs mr-1">picture_as_pdf</span> Invoice
                                </a>

                                <?php if(auth()->user()?->hasRole('Admin') || auth()->user()?->hasRole('Petugas')): ?>
                                    <form method="POST" action="<?php echo e(route('pembayaran.verifikasi', $p->id)); ?>" class="inline-block">
                                        <?php echo csrf_field(); ?>
                                        <select name="status" onchange="this.form.submit()" class="text-[10px] font-bold border border-slate-300 rounded-lg p-1 bg-white focus:outline-none shadow-sm cursor-pointer">
                                            <option value="Pending" <?php echo e($p->status == 'Pending' ? 'selected' : ''); ?>>⏳ Pending</option>
                                            <option value="Verified" <?php echo e($p->status == 'Verified' ? 'selected' : ''); ?>>✅ Terbayar (Masuk Pemasukan)</option>
                                            <option value="Rejected" <?php echo e($p->status == 'Rejected' ? 'selected' : ''); ?>>❌ Ditolak</option>
                                        </select>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="p-8 text-center text-slate-400">Belum ada data pembayaran.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ibnus\Downloads\sigma-rental\resources\views/pembayaran/index.blade.php ENDPATH**/ ?>