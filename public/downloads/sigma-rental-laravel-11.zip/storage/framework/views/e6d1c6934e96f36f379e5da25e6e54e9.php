<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laporan <?php echo e(ucfirst($jenisLaporan)); ?> - SIGMA RENTAL</title>
    <style>
        body { font-family: sans-serif; font-size: 11px; color: #333; }
        .header { text-align: center; border-bottom: 2px solid #16a34a; padding-bottom: 10px; margin-bottom: 20px; }
        .title { font-size: 18px; font-weight: bold; color: #16a34a; }
        .subtitle { font-size: 11px; color: #555; }
        .table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .table th, .table td { border: 1px solid #ccc; padding: 6px 8px; text-align: left; }
        .table th { background-color: #f1f5f9; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">SIGMA RENTAL MANAGEMENT SYSTEM</div>
        <div class="subtitle">Laporan <?php echo e(ucfirst($jenisLaporan)); ?> Periode <?php echo e($bulan); ?>/<?php echo e($tahun); ?></div>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Booking</th>
                <th>Customer</th>
                <th>Kendaraan</th>
                <th>Tanggal Sewa</th>
                <th>Durasi</th>
                <th>Total Bayar</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($row->kode_booking); ?></td>
                    <td><?php echo e($row->user->name ?? 'N/A'); ?></td>
                    <td><?php echo e($row->kendaraan->merk ?? ''); ?> <?php echo e($row->kendaraan->tipe ?? ''); ?></td>
                    <td><?php echo e($row->tgl_sewa->format('d/m/Y')); ?> - <?php echo e($row->tgl_kembali_rencana->format('d/m/Y')); ?></td>
                    <td><?php echo e($row->durasi_hari); ?> Hari</td>
                    <td>Rp <?php echo e(number_format($row->total_bayar, 0, ',', '.')); ?></td>
                    <td><?php echo e($row->status); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\ibnus\Downloads\sigma-rental\resources\views/laporan/pdf.blade.php ENDPATH**/ ?>