<!-- Upgraded Responsive Role-Based Sidebar Component -->
<?php
    $user = auth()->user();
    $roleName = $user?->role?->name ?? 'customer';
    $roleDisplayName = $user?->role?->display_name ?? 'Customer';
    
    $isAdmin = $user?->hasRole('Admin') || strtolower($roleName) === 'admin';
    $isPetugas = $user?->hasRole('Petugas') || strtolower($roleName) === 'petugas';
    $isOwner = $user?->hasRole('Owner') || strtolower($roleName) === 'owner';
    $isCustomer = $user?->hasRole('Customer') || strtolower($roleName) === 'customer';
?>

<aside class="fixed inset-y-0 left-0 z-50 flex flex-col w-72 bg-slate-950 text-white border-r border-slate-800/80 transform transition-all duration-300 ease-in-out lg:static lg:translate-x-0 shadow-2xl"
       :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'">
    
    <!-- Brand Header -->
    <div class="flex items-center justify-between h-20 px-6 bg-slate-950 border-b border-slate-800/80 relative">
        <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center space-x-3 group">
            <div class="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-emerald-400 flex items-center justify-center font-black text-slate-950 shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform duration-200">
                <span class="material-icons text-xl text-slate-950">directions_car</span>
            </div>
            <div>
                <div class="flex items-center space-x-1.5">
                    <span class="font-black text-lg tracking-wider text-white">SIGMA</span>
                    <span class="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">PRO</span>
                </div>
                <div class="flex items-center space-x-1 mt-0.5">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span class="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Rental System</span>
                </div>
            </div>
        </a>
        <button @click="sidebarOpen = false" class="lg:hidden text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-900 transition-colors">
            <span class="material-icons">close</span>
        </button>
    </div>

    <!-- User Role Banner Card -->
    <div class="px-5 py-3 bg-slate-900/60 border-b border-slate-800/50 flex items-center justify-between">
        <div class="flex items-center space-x-2">
            <div class="w-2 h-2 rounded-full 
                <?php echo e($isAdmin ? 'bg-purple-400' : ''); ?>

                <?php echo e($isPetugas ? 'bg-blue-400' : ''); ?>

                <?php echo e($isOwner ? 'bg-amber-400' : ''); ?>

                <?php echo e($isCustomer ? 'bg-emerald-400' : ''); ?>"></div>
            <span class="text-[11px] font-bold text-slate-300">Akses Role:</span>
        </div>
        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wide
            <?php echo e($isAdmin ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : ''); ?>

            <?php echo e($isPetugas ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' : ''); ?>

            <?php echo e($isOwner ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : ''); ?>

            <?php echo e($isCustomer ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : ''); ?>">
            <?php echo e($roleDisplayName); ?>

        </span>
    </div>

    <!-- Navigation Menu -->
    <nav class="flex-1 px-4 py-5 space-y-6 overflow-y-auto custom-scrollbar">
        
        <!-- SECTION 1: MENU UTAMA (All Roles) -->
        <div>
            <div class="px-3 text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2">
                <?php echo e($isCustomer ? 'Menu Utama Pelanggan' : 'Menu Utama'); ?>

            </div>
            <div class="space-y-1">
                <!-- Dashboard -->
                <a href="<?php echo e(route('dashboard')); ?>" 
                   @click="if(window.innerWidth < 1024) sidebarOpen = false"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold text-xs transition-all duration-200 relative group
                   <?php echo e(request()->routeIs('dashboard') ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-lg shadow-emerald-600/25' : 'text-slate-400 hover:text-white hover:bg-slate-900/90'); ?>">
                    <div class="flex items-center space-x-3">
                        <span class="material-icons text-lg transition-transform group-hover:scale-110 <?php echo e(request()->routeIs('dashboard') ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'); ?>">dashboard</span>
                        <span>Dashboard</span>
                    </div>
                    <?php if(request()->routeIs('dashboard')): ?>
                        <span class="w-1.5 h-1.5 rounded-full bg-white"></span>
                    <?php endif; ?>
                </a>

                <!-- Jadwal Armada (Calendar) -->
                <a href="<?php echo e(route('calendar')); ?>" 
                   @click="if(window.innerWidth < 1024) sidebarOpen = false"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold text-xs transition-all duration-200 relative group
                   <?php echo e(request()->routeIs('calendar') ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-lg shadow-emerald-600/25' : 'text-slate-400 hover:text-white hover:bg-slate-900/90'); ?>">
                    <div class="flex items-center space-x-3">
                        <span class="material-icons text-lg transition-transform group-hover:scale-110 <?php echo e(request()->routeIs('calendar') ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'); ?>">calendar_month</span>
                        <span>Jadwal Armada</span>
                    </div>
                    <?php if(request()->routeIs('calendar')): ?>
                        <span class="w-1.5 h-1.5 rounded-full bg-white"></span>
                    <?php endif; ?>
                </a>

                <!-- Katalog / Kelola Kendaraan -->
                <a href="<?php echo e(route('kendaraan.index')); ?>" 
                   @click="if(window.innerWidth < 1024) sidebarOpen = false"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold text-xs transition-all duration-200 relative group
                   <?php echo e(request()->routeIs('kendaraan.*') ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-lg shadow-emerald-600/25' : 'text-slate-400 hover:text-white hover:bg-slate-900/90'); ?>">
                    <div class="flex items-center space-x-3">
                        <span class="material-icons text-lg transition-transform group-hover:scale-110 <?php echo e(request()->routeIs('kendaraan.*') ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'); ?>">directions_car</span>
                        <span><?php echo e(($isAdmin || $isPetugas) ? 'Kelola Armada' : 'Katalog Kendaraan'); ?></span>
                    </div>
                    <?php if(request()->routeIs('kendaraan.*')): ?>
                        <span class="w-1.5 h-1.5 rounded-full bg-white"></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>

        <!-- SECTION 2: OPERASIONAL (Admin & Petugas) -->
        <?php if($isAdmin || $isPetugas): ?>
        <div>
            <div class="px-3 text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2">
                Operasional Rental
            </div>
            <div class="space-y-1">
                <!-- Sewa / Booking -->
                <a href="<?php echo e(route('booking.index')); ?>" 
                   @click="if(window.innerWidth < 1024) sidebarOpen = false"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold text-xs transition-all duration-200 relative group
                   <?php echo e(request()->routeIs('booking.*') ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-lg shadow-emerald-600/25' : 'text-slate-400 hover:text-white hover:bg-slate-900/90'); ?>">
                    <div class="flex items-center space-x-3">
                        <span class="material-icons text-lg transition-transform group-hover:scale-110 <?php echo e(request()->routeIs('booking.*') ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'); ?>">book_online</span>
                        <span>Sewa / Booking</span>
                    </div>
                    <?php if(request()->routeIs('booking.*')): ?>
                        <span class="w-1.5 h-1.5 rounded-full bg-white"></span>
                    <?php endif; ?>
                </a>

                <!-- Verifikasi Pembayaran -->
                <a href="<?php echo e(route('pembayaran.index')); ?>" 
                   @click="if(window.innerWidth < 1024) sidebarOpen = false"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold text-xs transition-all duration-200 relative group
                   <?php echo e(request()->routeIs('pembayaran.*') ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-lg shadow-emerald-600/25' : 'text-slate-400 hover:text-white hover:bg-slate-900/90'); ?>">
                    <div class="flex items-center space-x-3">
                        <span class="material-icons text-lg transition-transform group-hover:scale-110 <?php echo e(request()->routeIs('pembayaran.*') ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'); ?>">payments</span>
                        <span>Pembayaran</span>
                    </div>
                    <?php if(request()->routeIs('pembayaran.*')): ?>
                        <span class="w-1.5 h-1.5 rounded-full bg-white"></span>
                    <?php endif; ?>
                </a>

                <!-- Pengembalian & Denda -->
                <a href="<?php echo e(route('pengembalian.index')); ?>" 
                   @click="if(window.innerWidth < 1024) sidebarOpen = false"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold text-xs transition-all duration-200 relative group
                   <?php echo e(request()->routeIs('pengembalian.*') ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-lg shadow-emerald-600/25' : 'text-slate-400 hover:text-white hover:bg-slate-900/90'); ?>">
                    <div class="flex items-center space-x-3">
                        <span class="material-icons text-lg transition-transform group-hover:scale-110 <?php echo e(request()->routeIs('pengembalian.*') ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'); ?>">assignment_return</span>
                        <span>Pengembalian & Denda</span>
                    </div>
                    <?php if(request()->routeIs('pengembalian.*')): ?>
                        <span class="w-1.5 h-1.5 rounded-full bg-white"></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- SECTION 2 (ALTERNATIVE): TRANSAKSI SAYA (Customer) -->
        <?php if($isCustomer): ?>
        <div>
            <div class="px-3 text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2">
                Transaksi Saya
            </div>
            <div class="space-y-1">
                <!-- Booking Saya -->
                <a href="<?php echo e(route('booking.index')); ?>" 
                   @click="if(window.innerWidth < 1024) sidebarOpen = false"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold text-xs transition-all duration-200 relative group
                   <?php echo e(request()->routeIs('booking.*') ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-lg shadow-emerald-600/25' : 'text-slate-400 hover:text-white hover:bg-slate-900/90'); ?>">
                    <div class="flex items-center space-x-3">
                        <span class="material-icons text-lg transition-transform group-hover:scale-110 <?php echo e(request()->routeIs('booking.*') ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'); ?>">receipt_long</span>
                        <span>Booking Saya</span>
                    </div>
                    <?php if(request()->routeIs('booking.*')): ?>
                        <span class="w-1.5 h-1.5 rounded-full bg-white"></span>
                    <?php endif; ?>
                </a>

                <!-- Riwayat Pembayaran -->
                <a href="<?php echo e(route('pembayaran.index')); ?>" 
                   @click="if(window.innerWidth < 1024) sidebarOpen = false"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold text-xs transition-all duration-200 relative group
                   <?php echo e(request()->routeIs('pembayaran.*') ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-lg shadow-emerald-600/25' : 'text-slate-400 hover:text-white hover:bg-slate-900/90'); ?>">
                    <div class="flex items-center space-x-3">
                        <span class="material-icons text-lg transition-transform group-hover:scale-110 <?php echo e(request()->routeIs('pembayaran.*') ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'); ?>">account_balance_wallet</span>
                        <span>Riwayat Pembayaran</span>
                    </div>
                    <?php if(request()->routeIs('pembayaran.*')): ?>
                        <span class="w-1.5 h-1.5 rounded-full bg-white"></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- SECTION 3: LAPORAN & ANALYTICS (Admin & Owner) -->
        <?php if($isAdmin || $isOwner): ?>
        <div>
            <div class="px-3 text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2">
                Laporan & Analisis
            </div>
            <div class="space-y-1">
                <a href="<?php echo e(route('laporan.index')); ?>" 
                   @click="if(window.innerWidth < 1024) sidebarOpen = false"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold text-xs transition-all duration-200 relative group
                   <?php echo e(request()->routeIs('laporan.*') ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-lg shadow-emerald-600/25' : 'text-slate-400 hover:text-white hover:bg-slate-900/90'); ?>">
                    <div class="flex items-center space-x-3">
                        <span class="material-icons text-lg transition-transform group-hover:scale-110 <?php echo e(request()->routeIs('laporan.*') ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'); ?>">analytics</span>
                        <span>Laporan Keuangan</span>
                    </div>
                    <?php if(request()->routeIs('laporan.*')): ?>
                        <span class="w-1.5 h-1.5 rounded-full bg-white"></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- SECTION 4: SYSTEM ADMIN (Admin Only) -->
        <?php if($isAdmin): ?>
        <div>
            <div class="px-3 text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2">
                Administrator System
            </div>
            <div class="space-y-1">
                <a href="<?php echo e(route('admin.users.index')); ?>" 
                   @click="if(window.innerWidth < 1024) sidebarOpen = false"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold text-xs transition-all duration-200 relative group
                   <?php echo e(request()->routeIs('admin.users.*') ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-lg shadow-emerald-600/25' : 'text-slate-400 hover:text-white hover:bg-slate-900/90'); ?>">
                    <div class="flex items-center space-x-3">
                        <span class="material-icons text-lg transition-transform group-hover:scale-110 <?php echo e(request()->routeIs('admin.users.*') ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'); ?>">manage_accounts</span>
                        <span>Pengguna & Verifikasi</span>
                    </div>
                    <?php if(request()->routeIs('admin.users.*')): ?>
                        <span class="w-1.5 h-1.5 rounded-full bg-white"></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
        <?php endif; ?>

        <!-- SECTION 5: AKUN SAYA (All Roles) -->
        <div>
            <div class="px-3 text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2">
                Pengaturan Akun
            </div>
            <div class="space-y-1">
                <a href="<?php echo e(route('profile.index')); ?>" 
                   @click="if(window.innerWidth < 1024) sidebarOpen = false"
                   class="flex items-center justify-between px-3.5 py-2.5 rounded-2xl font-bold text-xs transition-all duration-200 relative group
                   <?php echo e(request()->routeIs('profile.*') ? 'bg-gradient-to-r from-emerald-600 to-emerald-500 text-white shadow-lg shadow-emerald-600/25' : 'text-slate-400 hover:text-white hover:bg-slate-900/90'); ?>">
                    <div class="flex items-center space-x-3">
                        <span class="material-icons text-lg transition-transform group-hover:scale-110 <?php echo e(request()->routeIs('profile.*') ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'); ?>">account_circle</span>
                        <span>Profil & Dokumen</span>
                    </div>
                    <?php if(request()->routeIs('profile.*')): ?>
                        <span class="w-1.5 h-1.5 rounded-full bg-white"></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>

    </nav>

    <!-- Sidebar Footer Profile Card -->
    <div class="p-4 border-t border-slate-800/80 bg-slate-950/80 backdrop-blur-sm">
        <div class="flex items-center justify-between bg-slate-900/90 p-3 rounded-2xl border border-slate-800/80">
            <a href="<?php echo e(route('profile.index')); ?>" class="flex items-center space-x-3 min-w-0 flex-1 hover:opacity-80 transition-opacity">
                <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 text-white font-black flex items-center justify-center text-sm shadow-inner flex-shrink-0 border border-white/10">
                    <?php echo e(strtoupper(substr($user->name ?? 'U', 0, 1))); ?>

                </div>
                <div class="truncate">
                    <div class="text-xs font-bold text-white truncate leading-snug"><?php echo e($user?->name ?? 'Guest User'); ?></div>
                    <div class="text-[10px] text-emerald-400 font-semibold truncate"><?php echo e($roleDisplayName); ?></div>
                </div>
            </a>
            <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline-block ml-1">
                <?php echo csrf_field(); ?>
                <button type="submit" class="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors" title="Keluar / Logout">
                    <span class="material-icons text-lg">logout</span>
                </button>
            </form>
        </div>
    </div>
</aside>
<?php /**PATH C:\Users\ibnus\Downloads\sigma-rental\resources\views/components/sidebar.blade.php ENDPATH**/ ?>