<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-black text-slate-900">Form Booking / Sewa Kendaraan</h1>
            <p class="text-xs text-slate-500">Pilih armada dan tanggal sewa. Sistem akan menghitung total biaya otomatis.</p>
        </div>
        <a href="<?php echo e(route('booking.index')); ?>" class="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-xl transition">
            &larr; Kembali
        </a>
    </div>

    <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm" x-data="{
        hargaPerHari: <?php echo e($selectedKendaraan->harga_sewa_per_hari ?? 0); ?>,
        tglSewa: '<?php echo e(date('Y-m-d')); ?>',
        tglKembali: '<?php echo e(date('Y-m-d', strtotime('+1 day'))); ?>',
        get durasiHari() {
            if(!this.tglSewa || !this.tglKembali) return 1;
            let d1 = new Date(this.tglSewa);
            let d2 = new Date(this.tglKembali);
            let diff = (d2 - d1) / (1000 * 60 * 60 * 24);
            return diff > 0 ? Math.ceil(diff) : 1;
        },
        get totalBayar() {
            return this.durasiHari * this.hargaPerHari;
        },
        updatePrice(e) {
            let selected = e.target.options[e.target.selectedIndex];
            this.hargaPerHari = parseFloat(selected.getAttribute('data-price') || 0);
        }
    }">
        <form method="POST" action="<?php echo e(route('booking.store')); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>

            <div>
                <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Pilih Kendaraan *</label>
                <select name="kendaraan_id" required @change="updatePrice($event)" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                    <option value="">-- Pilih Kendaraan Tersedia --</option>
                    <?php $__currentLoopData = $kendaraanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id); ?>" data-price="<?php echo e($k->harga_sewa_per_hari); ?>" <?php echo e(($selectedKendaraan && $selectedKendaraan->id == $k->id) ? 'selected' : ''); ?>>
                            <?php echo e($k->merk); ?> <?php echo e($k->tipe); ?> (<?php echo e($k->plat_nomor); ?>) - Rp <?php echo e(number_format($k->harga_sewa_per_hari, 0, ',', '.')); ?>/hari
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Tanggal Mulai Sewa *</label>
                    <input type="date" name="tgl_sewa" x-model="tglSewa" required min="<?php echo e(date('Y-m-d')); ?>" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Tanggal Rencana Kembali *</label>
                    <input type="date" name="tgl_kembali_rencana" x-model="tglKembali" required min="<?php echo e(date('Y-m-d')); ?>" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
            </div>

            <!-- Calculation Summary Box -->
            <div class="p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-xs space-y-2">
                <div class="flex justify-between font-medium text-slate-700">
                    <span>Durasi Penyewaan:</span>
                    <span class="font-bold text-slate-900" x-text="durasiHari + ' Hari'"></span>
                </div>
                <div class="flex justify-between font-medium text-slate-700">
                    <span>Tarif per Hari:</span>
                    <span class="font-bold text-slate-900" x-text="'Rp ' + Number(hargaPerHari).toLocaleString('id-ID')"></span>
                </div>
                <div class="border-t border-emerald-200 pt-2 flex justify-between font-bold text-sm text-emerald-900">
                    <span>Total Estimasi Bayar:</span>
                    <span class="text-base text-emerald-700" x-text="'Rp ' + Number(totalBayar).toLocaleString('id-ID')"></span>
                </div>
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Catatan Khusus (Opsional)</label>
                <textarea name="catatan" rows="2" placeholder="Tujuan perjalanan, permintaan helm/sopir, dll." class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none"></textarea>
            </div>

            <div class="pt-4 flex justify-end">
                <button type="submit" class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition">
                    Konfirmasi & Buat Booking
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ibnus\Downloads\sigma-rental\resources\views/booking/create.blade.php ENDPATH**/ ?>