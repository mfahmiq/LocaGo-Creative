<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto space-y-6">
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-black text-slate-900">Tambah Kendaraan Baru</h1>
            <p class="text-xs text-slate-500">Tambahkan mobil atau sepeda motor ke dalam sistem armada.</p>
        </div>
        <a href="<?php echo e(route('kendaraan.index')); ?>" class="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-xl transition">
            &larr; Kembali
        </a>
    </div>

    <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <form method="POST" action="<?php echo e(route('kendaraan.store')); ?>" enctype="multipart/form-data" class="space-y-4">
            <?php echo csrf_field(); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Kategori Kendaraan *</label>
                    <select name="kategori_id" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                        <option value="">Pilih Kategori</option>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kat->id); ?>" <?php echo e(old('kategori_id') == $kat->id ? 'selected' : ''); ?>><?php echo e($kat->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Status Kesiapan *</label>
                    <select name="status" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                        <option value="Tersedia" <?php echo e(old('status') == 'Tersedia' ? 'selected' : ''); ?>>Tersedia</option>
                        <option value="Booking" <?php echo e(old('status') == 'Booking' ? 'selected' : ''); ?>>Booking</option>
                        <option value="Disewa" <?php echo e(old('status') == 'Disewa' ? 'selected' : ''); ?>>Disewa</option>
                        <option value="Servis" <?php echo e(old('status') == 'Servis' ? 'selected' : ''); ?>>Servis</option>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Merk *</label>
                    <input type="text" name="merk" value="<?php echo e(old('merk')); ?>" placeholder="Contoh: Toyota, Honda, Yamaha" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Tipe / Model *</label>
                    <input type="text" name="tipe" value="<?php echo e(old('tipe')); ?>" placeholder="Contoh: Avanza Veloz 1.5 CVT" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Tahun Kendaraan *</label>
                    <input type="number" name="tahun" value="<?php echo e(old('tahun', date('Y'))); ?>" min="2000" max="<?php echo e(date('Y')+1); ?>" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Plat Nomor *</label>
                    <input type="text" name="plat_nomor" value="<?php echo e(old('plat_nomor')); ?>" placeholder="B 1234 XYZ" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>

                <div class="md:col-span-2">
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Harga Sewa Per Hari (Rp) *</label>
                    <input type="number" name="harga_sewa_per_hari" value="<?php echo e(old('harga_sewa_per_hari')); ?>" placeholder="350000" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>

                <div class="md:col-span-2">
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Foto Kendaraan</label>
                    <input type="file" name="foto" accept="image/*" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>

                <div class="md:col-span-2">
                    <label class="block text-xs font-bold text-slate-700 uppercase mb-1">Deskripsi / Spesifikasi</label>
                    <textarea name="deskripsi" rows="3" placeholder="Fasilitas AC, Sunroof, kondisi mesin, dll." class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none"><?php echo e(old('deskripsi')); ?></textarea>
                </div>
            </div>

            <div class="pt-4 flex justify-end">
                <button type="submit" class="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition">
                    Simpan Kendaraan
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ibnus\Downloads\sigma-rental\resources\views/kendaraan/create.blade.php ENDPATH**/ ?>