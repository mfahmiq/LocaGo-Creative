<?php $__env->startSection('content'); ?>
<div class="space-y-6">

    <!-- Header Banner -->
    <div class="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 rounded-2xl p-6 text-white shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
            <div class="flex items-center space-x-3 mb-1">
                <h1 class="text-2xl font-bold tracking-tight">Selamat Datang di SIGMA RENTAL</h1>
                <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shadow-sm">
                    <span class="w-2 h-2 rounded-full bg-emerald-400 mr-1.5 animate-ping"></span> Real-Time Live Data
                </span>
            </div>
            <p class="text-slate-300 text-sm">Sistem Manajemen Operasional & Penjualan Rental Mobil dan Sepeda Motor.</p>
        </div>
        <div class="flex items-center space-x-3">
            <a href="<?php echo e(route('booking.create')); ?>" class="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl text-sm shadow transition">
                + Sewa Kendaraan Baru
            </a>
        </div>
    </div>

    <!-- Stats Cards Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        
        <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <p class="text-xs font-semibold text-slate-500 uppercase"><?php echo e($isCustomer ? 'Total Booking Saya' : 'Total Armada'); ?></p>
                <p id="stat-total-kendaraan" class="text-2xl font-black text-slate-900 mt-1"><?php echo e($stats['total_kendaraan']); ?></p>
            </div>
            <div class="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                <span class="material-icons">directions_car</span>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <p class="text-xs font-semibold text-slate-500 uppercase"><?php echo e($isCustomer ? 'Sewa Aktif' : 'Tersedia'); ?></p>
                <p id="stat-kendaraan-tersedia" class="text-2xl font-black text-emerald-600 mt-1"><?php echo e($stats['kendaraan_tersedia']); ?></p>
            </div>
            <div class="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <span class="material-icons">check_circle</span>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <p class="text-xs font-semibold text-slate-500 uppercase"><?php echo e($isCustomer ? 'Booking Pending' : 'Disewa'); ?></p>
                <p id="stat-kendaraan-disewa" class="text-2xl font-black text-amber-600 mt-1"><?php echo e($stats['kendaraan_disewa']); ?></p>
            </div>
            <div class="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                <span class="material-icons">key</span>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <p class="text-xs font-semibold text-slate-500 uppercase">Booking Hari Ini</p>
                <p id="stat-booking-hari-ini" class="text-2xl font-black text-indigo-600 mt-1"><?php echo e($stats['booking_hari_ini']); ?></p>
            </div>
            <div class="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <span class="material-icons">event</span>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <p class="text-xs font-semibold text-slate-500 uppercase"><?php echo e($isCustomer ? 'Total Bayar Saya' : 'Pendapatan Bulan Ini'); ?></p>
                <p id="stat-pendapatan-bulan-ini" class="text-lg font-black text-emerald-700 mt-1">Rp <?php echo e(number_format($stats['pendapatan_bulan_ini'], 0, ',', '.')); ?></p>
            </div>
            <div class="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <span class="material-icons">payments</span>
            </div>
        </div>

        <div class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
            <div>
                <p class="text-xs font-semibold text-slate-500 uppercase"><?php echo e($isCustomer ? 'Total Denda Saya' : 'Denda Bulan Ini'); ?></p>
                <p id="stat-denda-bulan-ini" class="text-lg font-black text-rose-600 mt-1">Rp <?php echo e(number_format($stats['denda_bulan_ini'], 0, ',', '.')); ?></p>
            </div>
            <div class="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
                <span class="material-icons">gavel</span>
            </div>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <!-- Chart 1: Revenue Trends -->
        <div class="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-base font-bold text-slate-800 flex items-center">
                    <span class="material-icons text-emerald-600 mr-2">show_chart</span>
                    Grafik Pendapatan (Database Sync)
                </h3>
                <span id="last-update-time" class="text-xs text-slate-400 font-medium">Auto-sync active</span>
            </div>
            <div class="h-64">
                <canvas id="chartRevenue"></canvas>
            </div>
        </div>

        <!-- Chart 2: Armada Status Breakdown -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 class="text-base font-bold text-slate-800 mb-4 flex items-center">
                <span class="material-icons text-indigo-600 mr-2">pie_chart</span>
                Status Armada Kendaraan
            </h3>
            <div class="h-64 flex items-center justify-center">
                <canvas id="chartStatusArmada"></canvas>
            </div>
        </div>
    </div>

    <!-- Recent Bookings Table -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="p-6 border-b border-slate-100 flex items-center justify-between">
            <h3 class="text-base font-bold text-slate-800 flex items-center">
                <span class="material-icons text-emerald-600 mr-2">list_alt</span>
                Transaksi Booking Terbaru
            </h3>
            <a href="<?php echo e(route('booking.index')); ?>" class="text-xs font-bold text-emerald-600 hover:text-emerald-700">Lihat Semua &rarr;</a>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
                <thead class="bg-slate-50 text-slate-500 font-semibold uppercase border-b border-slate-200">
                    <tr>
                        <th class="p-4">Kode Booking</th>
                        <th class="p-4">Customer</th>
                        <th class="p-4">Kendaraan</th>
                        <th class="p-4">Tanggal Sewa</th>
                        <th class="p-4">Total Bayar</th>
                        <th class="p-4">Status</th>
                    </tr>
                </thead>
                <tbody id="booking-latest-tbody" class="divide-y divide-slate-100 font-medium">
                    <?php $__empty_1 = true; $__currentLoopData = $bookingTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50 transition">
                            <td class="p-4 font-bold text-slate-900"><?php echo e($item->kode_booking); ?></td>
                            <td class="p-4 text-slate-700"><?php echo e($item->user->name ?? 'N/A'); ?></td>
                            <td class="p-4 text-slate-700"><?php echo e($item->kendaraan->merk ?? ''); ?> <?php echo e($item->kendaraan->tipe ?? ''); ?></td>
                            <td class="p-4 text-slate-500"><?php echo e($item->tgl_sewa ? $item->tgl_sewa->format('d M Y') : '-'); ?> - <?php echo e($item->tgl_kembali_rencana ? $item->tgl_kembali_rencana->format('d M Y') : '-'); ?></td>
                            <td class="p-4 font-bold text-slate-900">Rp <?php echo e(number_format($item->total_bayar, 0, ',', '.')); ?></td>
                            <td class="p-4">
                                <?php if($item->status == 'Pending'): ?>
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">Pending</span>
                                <?php elseif($item->status == 'Disetujui'): ?>
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">Disetujui</span>
                                <?php elseif($item->status == 'Berjalan'): ?>
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">Berjalan</span>
                                <?php elseif($item->status == 'Selesai'): ?>
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">Selesai</span>
                                <?php else: ?>
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800"><?php echo e($item->status); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="p-6 text-center text-slate-400">Belum ada transaksi booking.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Revenue Chart Initialization with DB Data
        const ctxRev = document.getElementById('chartRevenue').getContext('2d');
        const revenueChart = new Chart(ctxRev, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($chartRevenue['labels'], 15, 512) ?>,
                datasets: [{
                    label: 'Pendapatan Real (Rp)',
                    data: <?php echo json_encode($chartRevenue['data'], 15, 512) ?>,
                    borderColor: '#16a34a',
                    backgroundColor: 'rgba(22, 163, 74, 0.1)',
                    fill: true,
                    tension: 0.3,
                    borderWidth: 3,
                    pointRadius: 4,
                    pointBackgroundColor: '#16a34a'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'Rp ' + value.toLocaleString('id-ID');
                            }
                        }
                    }
                }
            }
        });

        // Armada Status Pie Chart
        const ctxPie = document.getElementById('chartStatusArmada').getContext('2d');
        const pieChart = new Chart(ctxPie, {
            type: 'doughnut',
            data: {
                labels: ['Tersedia', 'Booking', 'Disewa', 'Servis'],
                datasets: [{
                    data: [
                        <?php echo e($statusArmada['Tersedia']); ?>,
                        <?php echo e($statusArmada['Booking']); ?>,
                        <?php echo e($statusArmada['Disewa']); ?>,
                        <?php echo e($statusArmada['Servis']); ?>

                    ],
                    backgroundColor: ['#22c55e', '#3b82f6', '#f59e0b', '#ef4444']
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });

        // Function to render status badge
        function renderStatusBadge(status) {
            if (status === 'Pending') {
                return '<span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">Pending</span>';
            } else if (status === 'Disetujui') {
                return '<span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">Disetujui</span>';
            } else if (status === 'Berjalan') {
                return '<span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">Berjalan</span>';
            } else if (status === 'Selesai') {
                return '<span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">Selesai</span>';
            } else {
                return `<span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">${status}</span>`;
            }
        }

        // Real-Time Sync Polling Function
        async function fetchDashboardData() {
            try {
                const response = await fetch('<?php echo e(route("dashboard.data")); ?>', {
                    headers: { 'Accept': 'application/json' }
                });
                if (!response.ok) return;

                const data = await response.json();
                if (data.success) {
                    // Update Stat Counters
                    document.getElementById('stat-total-kendaraan').textContent = data.stats.total_kendaraan;
                    document.getElementById('stat-kendaraan-tersedia').textContent = data.stats.kendaraan_tersedia;
                    document.getElementById('stat-kendaraan-disewa').textContent = data.stats.kendaraan_disewa;
                    document.getElementById('stat-booking-hari-ini').textContent = data.stats.booking_hari_ini;
                    document.getElementById('stat-pendapatan-bulan-ini').textContent = data.stats.pendapatan_bulan_ini_formatted;
                    document.getElementById('stat-denda-bulan-ini').textContent = data.stats.denda_bulan_ini_formatted;

                    // Update Charts
                    revenueChart.data.labels = data.chartRevenue.labels;
                    revenueChart.data.datasets[0].data = data.chartRevenue.data;
                    revenueChart.update('none');

                    pieChart.data.datasets[0].data = [
                        data.statusArmada.Tersedia,
                        data.statusArmada.Booking,
                        data.statusArmada.Disewa,
                        data.statusArmada.Servis
                    ];
                    pieChart.update('none');

                    // Update Table
                    const tbody = document.getElementById('booking-latest-tbody');
                    if (data.bookingTerbaru.length === 0) {
                        tbody.innerHTML = '<tr><td colspan="6" class="p-6 text-center text-slate-400">Belum ada transaksi booking.</td></tr>';
                    } else {
                        tbody.innerHTML = data.bookingTerbaru.map(item => `
                            <tr class="hover:bg-slate-50 transition">
                                <td class="p-4 font-bold text-slate-900">${item.kode_booking}</td>
                                <td class="p-4 text-slate-700">${item.customer_name}</td>
                                <td class="p-4 text-slate-700">${item.kendaraan_name}</td>
                                <td class="p-4 text-slate-500">${item.tgl_sewa_formatted} - ${item.tgl_kembali_formatted}</td>
                                <td class="p-4 font-bold text-slate-900">${item.total_bayar_formatted}</td>
                                <td class="p-4">${renderStatusBadge(item.status)}</td>
                            </tr>
                        `).join('');
                    }

                    document.getElementById('last-update-time').textContent = 'Terakhir diperbarui: ' + data.updated_at;
                }
            } catch (err) {
                console.warn('Real-time sync error:', err);
            }
        }

        // Poll every 7 seconds for real-time updates
        setInterval(fetchDashboardData, 7000);
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ibnus\Downloads\sigma-rental\resources\views/dashboard/index.blade.php ENDPATH**/ ?>