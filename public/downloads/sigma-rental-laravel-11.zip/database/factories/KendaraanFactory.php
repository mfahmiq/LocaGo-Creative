<?php

namespace Database\Factories;

use App\Models\KategoriKendaraan;
use Illuminate\Database\Eloquent\Factories\Factory;

class KendaraanFactory extends Factory
{
    public function definition(): array
    {
        return [
            'kategori_id' => KategoriKendaraan::inRandomOrder()->first()?->id ?? 1,
            'merk' => fake()->randomElement(['Toyota', 'Honda', 'Suzuki', 'Yamaha', 'Mitsubishi']),
            'tipe' => fake()->word() . ' ' . fake()->randomElement(['CVT', 'AT', 'MT', 'ABS']),
            'tahun' => fake()->numberBetween(2020, 2024),
            'plat_nomor' => 'B ' . fake()->numberBetween(1000, 9999) . ' ' . fake()->lexify('???'),
            'harga_sewa_per_hari' => fake()->randomElement([150000, 250000, 350000, 500000, 750000]),
            'status' => fake()->randomElement(['Tersedia', 'Booking', 'Disewa', 'Servis']),
            'deskripsi' => fake()->sentence(10),
        ];
    }
}
