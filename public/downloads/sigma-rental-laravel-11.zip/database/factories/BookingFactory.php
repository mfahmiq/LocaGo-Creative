<?php

namespace Database\Factories;

use App\Models\User;
use App\Models\Kendaraan;
use Illuminate\Database\Eloquent\Factories\Factory;

class BookingFactory extends Factory
{
    public function definition(): array
    {
        $sewa = fake()->dateTimeBetween('now', '+1 week');
        $kembali = (clone $sewa)->modify('+3 days');
        $durasi = 3;
        $harga = 350000;
        $total = $durasi * $harga;

        return [
            'kode_booking' => 'RNT-' . date('Ymd') . '-' . fake()->unique()->numberBetween(1000, 9999),
            'user_id' => User::factory(),
            'kendaraan_id' => Kendaraan::factory(),
            'tgl_sewa' => $sewa->format('Y-m-d'),
            'tgl_kembali_rencana' => $kembali->format('Y-m-d'),
            'durasi_hari' => $durasi,
            'harga_per_hari' => $harga,
            'subtotal' => $total,
            'biaya_tambahan' => 0,
            'total_bayar' => $total,
            'status' => fake()->randomElement(['Pending', 'Disetujui', 'Berjalan', 'Selesai']),
            'catatan' => fake()->sentence(),
        ];
    }
}
