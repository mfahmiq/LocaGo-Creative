<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pembayaran', function (Blueprint $table) {
            $table->id();
            $table->foreignId('booking_id')->constrained('booking')->cascadeOnDelete();
            $table->string('metode_pembayaran'); // Transfer Bank, QRIS, Cash
            $table->decimal('jumlah_bayar', 12, 2);
            $table->string('bukti_pembayaran')->nullable();
            $table->dateTime('tgl_pembayaran');
            $table->enum('status', ['Pending', 'Verified', 'Rejected'])->default('Pending');
            $table->text('catatan')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pembayaran');
    }
};
