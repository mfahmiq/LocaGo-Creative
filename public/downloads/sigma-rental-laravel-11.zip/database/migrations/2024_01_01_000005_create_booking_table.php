<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('booking', function (Blueprint $table) {
            $table->id();
            $table->string('kode_booking')->unique(); // RNT-YYYYMMDD-0001
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('kendaraan_id')->constrained('kendaraan')->cascadeOnDelete();
            $table->date('tgl_sewa');
            $table->date('tgl_kembali_rencana');
            $table->integer('durasi_hari');
            $table->decimal('harga_per_hari', 12, 2);
            $table->decimal('subtotal', 12, 2);
            $table->decimal('biaya_tambahan', 12, 2)->default(0);
            $table->decimal('total_bayar', 12, 2);
            $table->enum('status', ['Pending', 'Disetujui', 'Ditolak', 'Berjalan', 'Selesai', 'Terlambat'])->default('Pending');
            $table->text('catatan')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('booking');
    }
};
