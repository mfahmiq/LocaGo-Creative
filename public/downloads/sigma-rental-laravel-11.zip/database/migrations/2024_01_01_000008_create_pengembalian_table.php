<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pengembalian', function (Blueprint $table) {
            $table->id();
            $table->foreignId('booking_id')->constrained('booking')->cascadeOnDelete();
            $table->date('tgl_pengembalian_aktual');
            $table->integer('keterlambatan_hari')->default(0);
            $table->enum('kondisi_kendaraan', ['Baik', 'Baret Ringan', 'Rusak Sedang', 'Rusak Parah'])->default('Baik');
            $table->decimal('biaya_kerusakan', 12, 2)->default(0);
            $table->text('catatan_kondisi')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pengembalian');
    }
};
