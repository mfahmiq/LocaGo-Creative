<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('kendaraan', function (Blueprint $table) {
            $table->id();
            $table->foreignId('kategori_id')->constrained('kategori_kendaraan')->cascadeOnDelete();
            $table->string('merk'); // Toyota, Honda, Yamaha
            $table->string('tipe'); // Avanza, NMAX, Civic
            $table->integer('tahun');
            $table->string('plat_nomor')->unique();
            $table->decimal('harga_sewa_per_hari', 12, 2);
            $table->enum('status', ['Tersedia', 'Booking', 'Disewa', 'Servis'])->default('Tersedia');
            $table->string('foto')->nullable();
            $table->text('deskripsi')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('kendaraan');
    }
};
