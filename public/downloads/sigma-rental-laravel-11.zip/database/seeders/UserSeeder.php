<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Role;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $adminRole = Role::where('name', 'Admin')->first();
        $petugasRole = Role::where('name', 'Petugas')->first();
        $customerRole = Role::where('name', 'Customer')->first();
        $ownerRole = Role::where('name', 'Owner')->first();

        User::firstOrCreate(
            ['email' => 'admin@sigmarental.com'],
            [
                'role_id' => $adminRole->id,
                'name' => 'Administrator SIGMA',
                'password' => Hash::make('password'),
                'phone' => '081234567890',
                'address' => 'Jl. Sigma Raya No. 1, Jakarta Central',
                'status' => 'active',
            ]
        );

        User::firstOrCreate(
            ['email' => 'petugas@sigmarental.com'],
            [
                'role_id' => $petugasRole->id,
                'name' => 'Budi Petugas Armada',
                'password' => Hash::make('password'),
                'phone' => '081298765432',
                'address' => 'Jl. Operasional No. 45, Jakarta',
                'status' => 'active',
            ]
        );

        User::firstOrCreate(
            ['email' => 'owner@sigmarental.com'],
            [
                'role_id' => $ownerRole->id,
                'name' => 'Haji Mansur Owner',
                'password' => Hash::make('password'),
                'phone' => '081377889900',
                'address' => 'Kawasan Industri Park No. 8',
                'status' => 'active',
            ]
        );

        User::firstOrCreate(
            ['email' => 'customer@sigmarental.com'],
            [
                'role_id' => $customerRole->id,
                'name' => 'Andi Wijaya Customer',
                'password' => Hash::make('password'),
                'phone' => '085711223344',
                'address' => 'Jl. Mawar Indah Blok B3, South Jakarta',
                'status' => 'active',
            ]
        );
    }
}
