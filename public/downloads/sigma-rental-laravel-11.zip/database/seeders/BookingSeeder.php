<?php

namespace Database\Seeders;

use App\Models\Booking;
use App\Models\User;
use App\Models\Kendaraan;
use App\Models\Pembayaran;
use Illuminate\Database\Seeder;
use Carbon\Carbon;

class BookingSeeder extends Seeder
{
    public function run(): void
    {
        $customer = User::where('email', 'customer@sigmarental.com')->first();
        $kendaraan = Kendaraan::where('plat_nomor', 'B 9999 SUV')->first();

        if ($customer && $kendaraan) {
            $tglSewa = Carbon::now()->subDays(2);
            $tglKembali = Carbon::now()->addDays(2);
            $durasi = 4;
            $total = $durasi * $kendaraan->harga_sewa_per_hari;

            $booking = Booking::firstOrCreate(
                ['kode_booking' => 'RNT-20260801-0001'],
                [
                    'user_id' => $customer->id,
                    'kendaraan_id' => $kendaraan->id,
                    'tgl_sewa' => $tglSewa,
                    'tgl_kembali_rencana' => $tglKembali,
                    'durasi_hari' => $durasi,
                    'harga_per_hari' => $kendaraan->harga_sewa_per_hari,
                    'subtotal' => $total,
                    'biaya_tambahan' => 0,
                    'total_bayar' => $total,
                    'status' => 'Disetujui',
                    'catatan' => 'Sewa untuk acara luar kota keluarga.',
                ]
            );

            Pembayaran::firstOrCreate(
                ['booking_id' => $booking->id],
                [
                    'metode_pembayaran' => 'Transfer Bank BCA',
                    'jumlah_bayar' => $total,
                    'bukti_pembayaran' => 'pembayaran/sample_receipt.jpg',
                    'tgl_pembayaran' => now()->subDays(2),
                    'status' => 'Verified',
                    'catatan' => 'Lunas via Bank Transfer',
                ]
            );
        }
    }
}
