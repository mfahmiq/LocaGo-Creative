<?php

namespace Database\Seeders;

use App\Models\Kendaraan;
use App\Models\KategoriKendaraan;
use Illuminate\Database\Seeder;

class KendaraanSeeder extends Seeder
{
    public function run(): void
    {
        $mpv = KategoriKendaraan::where('nama', 'Mobil MPV')->first();
        $suv = KategoriKendaraan::where('nama', 'Mobil SUV')->first();
        $sedan = KategoriKendaraan::where('nama', 'Mobil Sedan & City Car')->first();
        $motorMatic = KategoriKendaraan::where('nama', 'Motor Matic')->first();
        $motorSport = KategoriKendaraan::where('nama', 'Motor Sport & Big Bike')->first();

        $vehicles = [
            [
                'kategori_id' => $mpv->id,
                'merk' => 'Toyota',
                'tipe' => 'Avanza Veloz 1.5 CVT',
                'tahun' => 2023,
                'plat_nomor' => 'B 1234 SIG',
                'harga_sewa_per_hari' => 350000,
                'status' => 'Tersedia',
                'deskripsi' => 'Kapasitas 7 penumpang, AC Double Blower, Keyless Entry, kondisi mulus bersih.',
            ],
            [
                'kategori_id' => $mpv->id,
                'merk' => 'Mitsubishi',
                'tipe' => 'Xpander Ultimate AT',
                'tahun' => 2024,
                'plat_nomor' => 'B 5678 SGM',
                'harga_sewa_per_hari' => 400000,
                'status' => 'Tersedia',
                'deskripsi' => 'MPV premium dengan kenyamanan suspensi tinggi, Cruise Control, Android Auto.',
            ],
            [
                'kategori_id' => $suv->id,
                'merk' => 'Honda',
                'tipe' => 'CR-V Turbo Prestige',
                'tahun' => 2023,
                'plat_nomor' => 'B 9999 SUV',
                'harga_sewa_per_hari' => 650000,
                'status' => 'Disewa',
                'deskripsi' => 'SUV mewah mesin 1.5 Turbo, Panoramic Sunroof, Honda Sensing keselamatan aktif.',
            ],
            [
                'kategori_id' => $motorMatic->id,
                'merk' => 'Yamaha',
                'tipe' => 'NMAX 155 Connected',
                'tahun' => 2023,
                'plat_nomor' => 'B 4321 MAX',
                'harga_sewa_per_hari' => 120000,
                'status' => 'Tersedia',
                'deskripsi' => 'Motor matic bongsor nyaman untuk perjalanan jarak jauh, bagasi luas.',
            ],
            [
                'kategori_id' => $motorMatic->id,
                'merk' => 'Honda',
                'tipe' => 'PCX 160 ABS',
                'tahun' => 2024,
                'plat_nomor' => 'B 8765 PCX',
                'harga_sewa_per_hari' => 130000,
                'status' => 'Tersedia',
                'deskripsi' => 'Skuter premium elegan, Smart Key System, rem ABS.',
            ],
            [
                'kategori_id' => $motorSport->id,
                'merk' => 'Kawasaki',
                'tipe' => 'Ninja ZX-25R 4 Silinder',
                'tahun' => 2023,
                'plat_nomor' => 'B 2500 NZX',
                'harga_sewa_per_hari' => 350000,
                'status' => 'Servis',
                'deskripsi' => 'Motor sport 250cc 4 silinder suara melengking tajam, Quickshifter.',
            ],
        ];

        foreach ($vehicles as $item) {
            Kendaraan::firstOrCreate(['plat_nomor' => $item['plat_nomor']], $item);
        }
    }
}
