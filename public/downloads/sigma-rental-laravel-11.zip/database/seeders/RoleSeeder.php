<?php

namespace Database\Seeders;

use App\Models\Role;
use Illuminate\Database\Seeder;

class RoleSeeder extends Seeder
{
    public function run(): void
    {
        $roles = [
            ['name' => 'Admin', 'display_name' => 'Administrator System'],
            ['name' => 'Petugas', 'display_name' => 'Petugas Operasional'],
            ['name' => 'Customer', 'display_name' => 'Pelanggan / penyewa'],
            ['name' => 'Owner', 'display_name' => 'Pemilik Armada / Fleet Owner'],
        ];

        foreach ($roles as $role) {
            Role::firstOrCreate(['name' => $role['name']], $role);
        }
    }
}
