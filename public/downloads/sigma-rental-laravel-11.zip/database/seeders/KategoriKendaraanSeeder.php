<?php

namespace Database\Seeders;

use App\Models\KategoriKendaraan;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class KategoriKendaraanSeeder extends Seeder
{
    public function run(): void
    {
        $kategori = [
            ['nama' => 'Mobil MPV', 'deskripsi' => 'Multi Purpose Vehicle serbaguna untuk keluarga'],
            ['nama' => 'Mobil SUV', 'deskripsi' => 'Sport Utility Vehicle tangguh segala medan'],
            ['nama' => 'Mobil Sedan & City Car', 'deskripsi' => 'City car lincah & sedan mewah irit bahan bakar'],
            ['nama' => 'Motor Matic', 'deskripsi' => 'Sepeda motor otomatis praktis & efisien'],
            ['nama' => 'Motor Sport & Big Bike', 'deskripsi' => 'Sepeda motor sport dengan performa tinggi'],
        ];

        foreach ($kategori as $item) {
            KategoriKendaraan::firstOrCreate(
                ['nama' => $item['nama']],
                [
                    'slug' => Str::slug($item['nama']),
                    'deskripsi' => $item['deskripsi'],
                ]
            );
        }
    }
}
