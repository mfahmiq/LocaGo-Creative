# Sistem Informasi Rental Kendaraan - Sigma Rental Laravel 11

```
========================================================================
📦 Sistem Informasi Rental Kendaraan - Sigma Rental Laravel 11
Kategori     : Layanan & Jasa
Tech Stack   : Laravel • PHP • MySQL • Bootstrap
Database     : MySQL (.sql) (File: vendor/laravel/sail/database/pgsql/create-testing-database.sql)
Sumber Asli  : https://github.com/ibnusab/sigma-rental-laravel-11 (GitHub Open Source)
Stars GitHub : ⭐ 9 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/sigma-rental-laravel-11`
     * Untuk Laragon: `C:/laragon/www/sigma-rental-laravel-11`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `sigma_rental_laravel_11`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `vendor/laravel/sail/database/pgsql/create-testing-database.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = sigma_rental_laravel_11

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/sigma-rental-laravel-11

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
