# SIGMA RENTAL — Web-Based Car & Motorcycle Rental Management System (Laravel 11)

SIGMA RENTAL is a complete, production-ready Web-Based Rental Management System for Cars and Motorcycles built with **Laravel 11**, **PHP 8.2+**, **Blade**, **Eloquent ORM**, **MySQL**, **DomPDF**, **Maatwebsite Excel**, and **Tailwind CSS**.

---

## 🚀 Key Features

- **Multi-Role System**: Admin, Petugas (Staff), Customer (Penyewa), Owner (Fleet Owner).
- **Armada / Vehicle Management**:
  - CRUD Vehicles (Cars MPV/SUV/Sedan & Motorcycles Matic/Sport).
  - Vehicle Status Tracking (`Tersedia`, `Booking`, `Disewa`, `Servis`).
  - Category management & image upload using Laravel Storage.
- **Smart Booking Engine**:
  - Overlap & date collision prevention.
  - Automatic booking code generator (`RNT-YYYYMMDD-0001`).
  - Automatic rental duration and subtotal calculator.
  - FullCalendar interactive monthly availability calendar.
- **Customer Document Verification**:
  - Upload KTP and SIM images.
  - Admin/Staff verification workflow (`Pending`, `Verified`, `Rejected`).
- **Payment & Invoice System**:
  - Proof of payment upload (Transfer BCA, Mandiri, QRIS, Cash).
  - Staff verification workflow (`Pending`, `Verified`, `Rejected`).
  - PDF Invoice generator powered by **DomPDF**.
- **Automated Late Return & Fine Calculation**:
  - Input actual return date.
  - Automatic fine calculation: **10% of daily rental price** for every late day plus damage fees.
  - Automatic vehicle status restoration to `Tersedia`.
  - Fine status confirmation workflow (`Belum Lunas` / `Lunas`).
- **Reports & Analytics**:
  - Transaction report, revenue report, vehicle report, late return report.
  - PDF export & Excel spreadsheet support.
  - Interactive Chart.js charts for 6-month revenue trends and fleet status distribution.

---

## 📁 Laravel 11 Project Structure

```text
sigma-rental/
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── Controller.php
│   │   │   ├── DashboardController.php
│   │   │   ├── KendaraanController.php
│   │   │   ├── BookingController.php
│   │   │   ├── PembayaranController.php
│   │   │   ├── PengembalianController.php
│   │   │   ├── LaporanController.php
│   │   │   ├── UserController.php
│   │   │   └── ProfileController.php
│   │   ├── Middleware/
│   │   │   ├── AdminMiddleware.php
│   │   │   ├── PetugasMiddleware.php
│   │   │   ├── OwnerMiddleware.php
│   │   │   └── CustomerMiddleware.php
│   │   └── Requests/
│   │       ├── KendaraanRequest.php
│   │       ├── BookingRequest.php
│   │       ├── PembayaranRequest.php
│   │       └── PengembalianRequest.php
│   ├── Models/
│   │   ├── User.php
│   │   ├── Role.php
│   │   ├── KategoriKendaraan.php
│   │   ├── Kendaraan.php
│   │   ├── Booking.php
│   │   ├── BookingDetail.php
│   │   ├── Pembayaran.php
│   │   ├── Pengembalian.php
│   │   ├── Denda.php
│   │   ├── DokumenCustomer.php
│   │   ├── PerawatanKendaraan.php
│   │   ├── Notifikasi.php
│   │   ├── ActivityLog.php
│   │   └── Setting.php
│   └── Providers/
│       └── AppServiceProvider.php
├── bootstrap/
│   ├── app.php
│   └── providers.php
├── config/
│   ├── app.php
│   ├── auth.php
│   ├── database.php
│   ├── filesystems.php
│   ├── logging.php
│   └── session.php
├── database/
│   ├── factories/
│   │   ├── UserFactory.php
│   │   ├── KendaraanFactory.php
│   │   └── BookingFactory.php
│   ├── migrations/
│   │   ├── 0001_01_01_000000_create_roles_table.php
│   │   ├── 0001_01_01_000001_create_users_table.php
│   │   ├── 2024_01_01_000002_create_kategori_kendaraan_table.php
│   │   ├── 2024_01_01_000003_create_kendaraan_table.php
│   │   ├── 2024_01_01_000004_create_dokumen_customer_table.php
│   │   ├── 2024_01_01_000005_create_booking_table.php
│   │   ├── 2024_01_01_000006_create_booking_detail_table.php
│   │   ├── 2024_01_01_000007_create_pembayaran_table.php
│   │   ├── 2024_01_01_000008_create_pengembalian_table.php
│   │   ├── 2024_01_01_000009_create_denda_table.php
│   │   ├── 2024_01_01_000010_create_perawatan_kendaraan_table.php
│   │   ├── 2024_01_01_000011_create_notifikasi_table.php
│   │   ├── 2024_01_01_000012_create_activity_logs_table.php
│   │   └── 2024_01_01_000013_create_settings_table.php
│   └── seeders/
│       ├── DatabaseSeeder.php
│       ├── RoleSeeder.php
│       ├── UserSeeder.php
│       ├── KategoriKendaraanSeeder.php
│       ├── KendaraanSeeder.php
│       └── BookingSeeder.php
├── resources/
│   └── views/
│       ├── auth/
│       │   ├── login.blade.php
│       │   ├── register.blade.php
│       │   ├── forgot-password.blade.php
│       │   └── reset-password.blade.php
│       ├── components/
│       │   ├── sidebar.blade.php
│       │   └── topbar.blade.php
│       ├── dashboard/
│       │   └── index.blade.php
│       ├── kendaraan/
│       │   ├── index.blade.php
│       │   ├── create.blade.php
│       │   └── edit.blade.php
│       ├── booking/
│       │   ├── index.blade.php
│       │   └── create.blade.php
│       ├── pembayaran/
│       │   ├── index.blade.php
│       │   └── invoice.blade.php
│       ├── pengembalian/
│       │   └── index.blade.php
│       ├── laporan/
│       │   ├── index.blade.php
│       │   └── pdf.blade.php
│       ├── users/
│       │   └── index.blade.php
│       ├── profile/
│       │   └── index.blade.php
│       ├── calendar.blade.php
│       ├── layouts/
│       │   └── app.blade.php
│       └── welcome.blade.php
├── routes/
│   ├── web.php
│   ├── auth.php
│   └── console.php
├── artisan
├── composer.json
├── package.json
├── vite.config.js
└── tailwind.config.js
```

---

## ⚙️ Installation & Setup Guide

### 1. Requirements
- **PHP**: 8.2 or higher
- **Composer**: 2.x
- **Node.js**: 18.x or 20.x
- **Database**: MySQL 8.0+ / MariaDB 10.4+

### 2. Step-by-Step Commands

```bash
# Clone or open repository in VS Code
cd sigma-rental

# Install PHP dependencies
composer install

# Environment Configuration
cp .env.example .env

# Generate Application Key
php artisan key:generate

# Configure MySQL Database in .env
# DB_DATABASE=sigma_rental
# DB_USERNAME=root
# DB_PASSWORD=yourpassword

# Run Database Migrations and Seeders
php artisan migrate --seed

# Create Storage Link for Document/Image Uploads
php artisan storage:link

# Install Frontend Build Assets
npm install
npm run build

# Start Local Laravel Development Server
php artisan serve
```

Access application at: `http://127.0.0.1:8000`

---

## 🔐 Default Demo Login Accounts

| Role | Email | Password | Access Level |
|---|---|---|---|
| **Admin** | `admin@sigmarental.com` | `password` | Full system control, user verification, management |
| **Petugas (Staff)** | `petugas@sigmarental.com` | `password` | Vehicle CRUD, booking approval, returns & fines |
| **Owner** | `owner@sigmarental.com` | `password` | Executive dashboard, revenue & vehicle reports |
| **Customer** | `customer@sigmarental.com` | `password` | Browse fleet, create bookings, upload payments & KTP |

---

## 🛠️ Tech Stack
- **Framework**: Laravel 11 (PHP 8.2+)
- **Templating**: Laravel Blade Engine
- **Styling**: Tailwind CSS
- **Database & ORM**: MySQL & Eloquent ORM
- **Exporting Tools**: DomPDF (`barryvdh/laravel-dompdf`), Maatwebsite Excel (`maatwebsite/excel`)
- **Interactive UI Components**: FullCalendar JS, Chart.js, Alpine.js
