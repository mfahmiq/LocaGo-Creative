<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\KendaraanController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\PembayaranController;
use App\Http\Controllers\PengembalianController;
use App\Http\Controllers\LaporanController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ProfileController;

/*
|--------------------------------------------------------------------------
| Web Routes - SIGMA RENTAL (Laravel 11)
|--------------------------------------------------------------------------
*/

Route::get('/', function () {
    return view('welcome');
})->name('home');

// Calendar view for vehicle availability
Route::get('/calendar', function () {
    return view('calendar');
})->name('calendar');

// Authenticated Routes
Route::middleware(['auth'])->group(function () {
    
    // Dashboard (All roles)
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard/data', [DashboardController::class, 'data'])->name('dashboard.data');

    // Profile & Document upload
    Route::get('/profile', [ProfileController::class, 'index'])->name('profile.index');
    Route::post('/profile', [ProfileController::class, 'updateProfile'])->name('profile.update');
    Route::post('/profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password');
    Route::post('/profile/dokumen', [ProfileController::class, 'uploadDokumen'])->name('profile.dokumen');

    // Customer Routes
    Route::middleware(['customer'])->prefix('customer')->name('customer.')->group(function () {
        Route::get('/booking/my', [BookingController::class, 'index'])->name('booking.my');
    });

    // Booking Management
    Route::resource('booking', BookingController::class)->only(['index', 'create', 'store', 'show']);
    Route::post('/booking/{booking}/status', [BookingController::class, 'updateStatus'])->name('booking.update-status');

    // Pembayaran Management
    Route::get('/pembayaran', [PembayaranController::class, 'index'])->name('pembayaran.index');
    Route::post('/pembayaran', [PembayaranController::class, 'store'])->name('pembayaran.store');
    Route::post('/pembayaran/{pembayaran}/verifikasi', [PembayaranController::class, 'verifikasi'])->name('pembayaran.verifikasi');
    Route::get('/pembayaran/{pembayaran}/invoice', [PembayaranController::class, 'downloadInvoice'])->name('pembayaran.invoice');

    // Vehicle Catalog (All authenticated users can view list)
    Route::get('/kendaraan', [KendaraanController::class, 'index'])->name('kendaraan.index');

    // Admin & Petugas Shared Routes
    Route::middleware(['petugas'])->group(function () {
        Route::resource('kendaraan', KendaraanController::class)->except(['index']);
        
        // Pengembalian & Denda
        Route::get('/pengembalian', [PengembalianController::class, 'index'])->name('pengembalian.index');
        Route::post('/pengembalian', [PengembalianController::class, 'store'])->name('pengembalian.store');
        Route::post('/denda/{denda}/bayar', [PengembalianController::class, 'bayarDenda'])->name('denda.bayar');
    });

    // Owner & Admin Shared Routes (Laporan & Analytics)
    Route::middleware(['owner'])->group(function () {
        Route::get('/laporan', [LaporanController::class, 'index'])->name('laporan.index');
        Route::get('/laporan/export-pdf', [LaporanController::class, 'exportPdf'])->name('laporan.export-pdf');
    });

    // Admin Exclusive Routes
    Route::middleware(['admin'])->prefix('admin')->name('admin.')->group(function () {
        Route::get('/users', [UserController::class, 'index'])->name('users.index');
        Route::post('/users/verifikasi-dokumen/{dokumen}', [UserController::class, 'verifikasiDokumen'])->name('users.verifikasi-dokumen');
    });
});

require __DIR__.'/auth.php';
