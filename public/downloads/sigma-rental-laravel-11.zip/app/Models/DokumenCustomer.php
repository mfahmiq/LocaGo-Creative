<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DokumenCustomer extends Model
{
    use HasFactory;

    protected $table = 'dokumen_customer';

    protected $fillable = [
        'user_id',
        'no_ktp',
        'file_ktp',
        'no_sim',
        'file_sim',
        'status_verifikasi',
        'catatan_verifikasi',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
