<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Kendaraan extends Model
{
    use HasFactory;

    protected $table = 'kendaraan';

    protected $fillable = [
        'kategori_id',
        'merk',
        'tipe',
        'tahun',
        'plat_nomor',
        'harga_sewa_per_hari',
        'status',
        'foto',
        'deskripsi',
    ];

    public function kategori(): BelongsTo
    {
        return $this->belongsTo(KategoriKendaraan::class, 'kategori_id');
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class, 'kendaraan_id');
    }

    public function perawatan(): HasMany
    {
        return $this->hasMany(PerawatanKendaraan::class, 'kendaraan_id');
    }
}
