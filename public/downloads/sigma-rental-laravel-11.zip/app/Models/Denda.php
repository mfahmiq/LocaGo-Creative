<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOneThrough;

class Denda extends Model
{
    use HasFactory;

    protected $table = 'denda';

    protected $fillable = [
        'pengembalian_id',
        'jumlah_hari_terlambat',
        'tarif_denda_per_hari',
        'total_denda',
        'status_pembayaran',
    ];

    public function pengembalian(): BelongsTo
    {
        return $this->belongsTo(Pengembalian::class, 'pengembalian_id');
    }

    public function booking(): HasOneThrough
    {
        return $this->hasOneThrough(Booking::class, Pengembalian::class, 'id', 'id', 'pengembalian_id', 'booking_id');
    }
}
