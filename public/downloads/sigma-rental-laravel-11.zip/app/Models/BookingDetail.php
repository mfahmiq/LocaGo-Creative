<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class BookingDetail extends Model
{
    use HasFactory;

    protected $table = 'booking_detail';

    protected $fillable = ['booking_id', 'item_name', 'price', 'qty'];

    public function booking(): BelongsTo
    {
        return $this->belongsTo(Booking::class);
    }
}
