<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class KategoriKendaraan extends Model
{
    use HasFactory;

    protected $table = 'kategori_kendaraan';

    protected $fillable = ['nama', 'slug', 'deskripsi'];

    public function kendaraan(): HasMany
    {
        return $this->hasMany(Kendaraan::class, 'kategori_id');
    }
}
