<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Pengembalian extends Model
{
    use HasFactory;

    protected $table = 'pengembalian';

    protected $fillable = [
        'booking_id',
        'tgl_pengembalian_aktual',
        'keterlambatan_hari',
        'kondisi_kendaraan',
        'biaya_kerusakan',
        'catatan_kondisi',
    ];

    protected $casts = [
        'tgl_pengembalian_aktual' => 'date',
    ];

    public function booking(): BelongsTo
    {
        return $this->belongsTo(Booking::class);
    }

    public function denda(): HasOne
    {
        return $this->hasOne(Denda::class, 'pengembalian_id');
    }
}
