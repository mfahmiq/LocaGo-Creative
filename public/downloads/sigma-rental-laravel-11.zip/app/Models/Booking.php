<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOneThrough;

class Booking extends Model
{
    use HasFactory;

    protected $table = 'booking';

    protected $fillable = [
        'kode_booking',
        'user_id',
        'kendaraan_id',
        'tgl_sewa',
        'tgl_kembali_rencana',
        'durasi_hari',
        'harga_per_hari',
        'subtotal',
        'biaya_tambahan',
        'total_bayar',
        'status',
        'catatan',
    ];

    protected $casts = [
        'tgl_sewa' => 'date',
        'tgl_kembali_rencana' => 'date',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function kendaraan(): BelongsTo
    {
        return $this->belongsTo(Kendaraan::class, 'kendaraan_id');
    }

    public function details(): HasMany
    {
        return $this->hasMany(BookingDetail::class, 'booking_id');
    }

    public function pembayaran(): HasOne
    {
        return $this->hasOne(Pembayaran::class, 'booking_id');
    }

    public function pengembalian(): HasOne
    {
        return $this->hasOne(Pengembalian::class, 'booking_id');
    }

    public function denda(): HasOneThrough
    {
        return $this->hasOneThrough(Denda::class, Pengembalian::class, 'booking_id', 'pengembalian_id');
    }
}
