<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PerawatanKendaraan extends Model
{
    use HasFactory;

    protected $table = 'perawatan_kendaraan';

    protected $fillable = [
        'kendaraan_id',
        'tgl_servis',
        'jenis_perawatan',
        'biaya',
        'bengkel',
        'catatan',
    ];

    public function kendaraan(): BelongsTo
    {
        return $this->belongsTo(Kendaraan::class, 'kendaraan_id');
    }
}
