<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PengembalianRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->check() && (auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Petugas'));
    }

    public function rules(): array
    {
        return [
            'booking_id' => 'required|exists:booking,id',
            'tgl_pengembalian_aktual' => 'required|date',
            'kondisi_kendaraan' => 'required|in:Baik,Baret Ringan,Rusak Sedang,Rusak Parah',
            'biaya_kerusakan' => 'nullable|numeric|min:0',
            'catatan_kondisi' => 'nullable|string',
        ];
    }
}
