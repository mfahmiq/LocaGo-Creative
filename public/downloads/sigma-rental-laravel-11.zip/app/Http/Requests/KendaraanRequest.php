<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class KendaraanRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->check() && (auth()->user()->hasRole('Admin') || auth()->user()->hasRole('Petugas'));
    }

    public function rules(): array
    {
        $id = $this->kendaraan ? $this->kendaraan->id : null;

        return [
            'kategori_id' => 'required|exists:kategori_kendaraan,id',
            'merk' => 'required|string|max:100',
            'tipe' => 'required|string|max:100',
            'tahun' => 'required|integer|min:2000|max:'.(date('Y') + 1),
            'plat_nomor' => 'required|string|max:20|unique:kendaraan,plat_nomor,'.$id,
            'harga_sewa_per_hari' => 'required|numeric|min:0',
            'status' => 'required|in:Tersedia,Booking,Disewa,Servis',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
            'deskripsi' => 'nullable|string',
        ];
    }
}
