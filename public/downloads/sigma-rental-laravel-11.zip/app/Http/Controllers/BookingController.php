<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\Kendaraan;
use App\Http\Requests\BookingRequest;
use Illuminate\Http\Request;
use Carbon\Carbon;

class BookingController extends Controller
{
    public function index(Request $request)
    {
        $query = Booking::with(['user', 'kendaraan', 'pembayaran']);

        if (auth()->user()->hasRole('Customer')) {
            $query->where('user_id', auth()->id());
        }

        if ($request->has('status') && $request->status != '') {
            $query->where('status', $request->status);
        }

        $bookings = $query->latest()->paginate(10);

        return view('booking.index', compact('bookings'));
    }

    public function create(Request $request)
    {
        $kendaraan_id = $request->query('kendaraan_id');
        $selectedKendaraan = $kendaraan_id ? Kendaraan::find($kendaraan_id) : null;
        $kendaraanList = Kendaraan::where('status', 'Tersedia')->get();

        return view('booking.create', compact('selectedKendaraan', 'kendaraanList'));
    }

    public function store(BookingRequest $request)
    {
        $data = $request->validated();
        $kendaraan = Kendaraan::findOrFail($data['kendaraan_id']);

        $tglSewa = Carbon::parse($data['tgl_sewa']);
        $tglKembali = Carbon::parse($data['tgl_kembali_rencana']);

        // Check availability / overlap
        $overlap = Booking::where('kendaraan_id', $kendaraan->id)
            ->whereIn('status', ['Pending', 'Disetujui', 'Berjalan'])
            ->where(function ($q) use ($tglSewa, $tglKembali) {
                $q->whereBetween('tgl_sewa', [$tglSewa, $tglKembali])
                  ->orWhereBetween('tgl_kembali_rencana', [$tglSewa, $tglKembali])
                  ->orWhere(function ($sub) use ($tglSewa, $tglKembali) {
                      $sub->where('tgl_sewa', '<=', $tglSewa)
                          ->where('tgl_kembali_rencana', '>=', $tglKembali);
                  });
            })->exists();

        if ($overlap) {
            return back()->withInput()->with('error', 'Kendaraan tidak tersedia pada tanggal yang dipilih karena ada jadwal booking bentrok.');
        }

        $durasiHari = max(1, $tglSewa->diffInDays($tglKembali));
        $hargaPerHari = $kendaraan->harga_sewa_per_hari;
        $subtotal = $durasiHari * $hargaPerHari;
        $totalBayar = $subtotal;

        // Generate booking code RNT-YYYYMMDD-0001
        $todayPrefix = 'RNT-' . date('Ymd') . '-';
        $latestCount = Booking::where('kode_booking', 'like', $todayPrefix . '%')->count();
        $kodeBooking = $todayPrefix . str_pad($latestCount + 1, 4, '0', STR_PAD_LEFT);

        $booking = Booking::create([
            'kode_booking' => $kodeBooking,
            'user_id' => auth()->id(),
            'kendaraan_id' => $kendaraan->id,
            'tgl_sewa' => $data['tgl_sewa'],
            'tgl_kembali_rencana' => $data['tgl_kembali_rencana'],
            'durasi_hari' => $durasiHari,
            'harga_per_hari' => $hargaPerHari,
            'subtotal' => $subtotal,
            'biaya_tambahan' => 0,
            'total_bayar' => $totalBayar,
            'status' => 'Pending',
            'catatan' => $data['catatan'] ?? null,
        ]);

        // Update status kendaraan to Booking
        $kendaraan->update(['status' => 'Booking']);

        return redirect()->route('booking.index')->with('success', "Booking berhasil dibuat dengan kode {$kodeBooking}. Silakan lakukan pembayaran.");
    }

    public function updateStatus(Request $request, Booking $booking)
    {
        $request->validate([
            'status' => 'required|in:Pending,Disetujui,Ditolak,Berjalan,Selesai,Terlambat',
        ]);

        $booking->update(['status' => $request->status]);

        if ($request->status === 'Berjalan') {
            $booking->kendaraan->update(['status' => 'Disewa']);
        } elseif (in_array($request->status, ['Selesai', 'Ditolak'])) {
            $booking->kendaraan->update(['status' => 'Tersedia']);
        }

        return redirect()->back()->with('success', 'Status booking berhasil diubah.');
    }
}
