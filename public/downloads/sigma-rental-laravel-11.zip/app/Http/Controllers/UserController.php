<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\DokumenCustomer;
use App\Models\Role;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $users = User::with(['role', 'dokumenCustomer'])->latest()->paginate(10);
        $roles = Role::all();

        return view('users.index', compact('users', 'roles'));
    }

    public function verifikasiDokumen(Request $request, DokumenCustomer $dokumen)
    {
        $request->validate([
            'status_verifikasi' => 'required|in:Verified,Rejected',
            'catatan_verifikasi' => 'nullable|string',
        ]);

        $dokumen->update([
            'status_verifikasi' => $request->status_verifikasi,
            'catatan_verifikasi' => $request->catatan_verifikasi,
        ]);

        return back()->with('success', "Dokumen customer berhasil di-{$request->status_verifikasi}.");
    }
}
