<?php

namespace App\Http\Controllers;

use App\Models\Pengembalian;
use App\Models\Booking;
use App\Models\Denda;
use App\Http\Requests\PengembalianRequest;
use Illuminate\Http\Request;
use Carbon\Carbon;

class PengembalianController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        $pengembalianQuery = Pengembalian::with(['booking.user', 'booking.kendaraan', 'denda']);
        $activeBookingsQuery = Booking::whereIn('status', ['Disetujui', 'Berjalan', 'Terlambat'])
            ->with(['user', 'kendaraan']);

        if ($user->hasRole('Customer')) {
            $pengembalianQuery->whereHas('booking', function ($q) use ($user) {
                $q->where('user_id', $user->id);
            });
            $activeBookingsQuery->where('user_id', $user->id);
        }

        $pengembalianList = $pengembalianQuery->latest()->paginate(10);
        $activeBookings = $activeBookingsQuery->get();

        return view('pengembalian.index', compact('pengembalianList', 'activeBookings'));
    }

    public function store(PengembalianRequest $request)
    {
        $data = $request->validated();
        $booking = Booking::with('kendaraan')->findOrFail($data['booking_id']);

        $tglKembaliRencana = Carbon::parse($booking->tgl_kembali_rencana);
        $tglPengembalianAktual = Carbon::parse($data['tgl_pengembalian_aktual']);

        // Calculate late days
        $keterlambatanHari = 0;
        if ($tglPengembalianAktual->gt($tglKembaliRencana)) {
            $keterlambatanHari = $tglKembaliRencana->diffInDays($tglPengembalianAktual);
        }

        $pengembalian = Pengembalian::create([
            'booking_id' => $booking->id,
            'tgl_pengembalian_aktual' => $data['tgl_pengembalian_aktual'],
            'keterlambatan_hari' => $keterlambatanHari,
            'kondisi_kendaraan' => $data['kondisi_kendaraan'],
            'biaya_kerusakan' => $data['biaya_kerusakan'] ?? 0,
            'catatan_kondisi' => $data['catatan_kondisi'] ?? null,
        ]);

        // Calculate automatic fine: 10% of daily rental price * late days
        if ($keterlambatanHari > 0) {
            $hargaSewaPerHari = $booking->kendaraan->harga_sewa_per_hari;
            $tarifDendaPerHari = $hargaSewaPerHari * 0.10;
            $totalDenda = ($tarifDendaPerHari * $keterlambatanHari) + ($data['biaya_kerusakan'] ?? 0);

            Denda::create([
                'pengembalian_id' => $pengembalian->id,
                'jumlah_hari_terlambat' => $keterlambatanHari,
                'tarif_denda_per_hari' => $tarifDendaPerHari,
                'total_denda' => $totalDenda,
                'status_pembayaran' => 'Belum Lunas',
            ]);

            $booking->update(['status' => 'Terlambat']);
        } else {
            $booking->update(['status' => 'Selesai']);
        }

        // Automatically set vehicle status back to Tersedia
        $booking->kendaraan->update(['status' => 'Tersedia']);

        return redirect()->route('pengembalian.index')->with('success', 'Pengembalian kendaraan berhasil diproses dan armada kembali Tersedia.');
    }

    public function bayarDenda(Denda $denda)
    {
        $denda->update(['status_pembayaran' => 'Lunas']);
        $denda->pengembalian->booking->update(['status' => 'Selesai']);

        return back()->with('success', 'Pembayaran denda berhasil dikonfirmasi LUNAS.');
    }
}
