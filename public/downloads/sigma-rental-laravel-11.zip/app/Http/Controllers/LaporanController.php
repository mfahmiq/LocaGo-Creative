<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\Kendaraan;
use App\Models\Pembayaran;
use App\Models\Pengembalian;
use App\Models\User;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;
use Maatwebsite\Excel\Facades\Excel;

class LaporanController extends Controller
{
    public function index(Request $request)
    {
        $jenisLaporan = $request->query('jenis', 'transaksi');
        $bulan = $request->query('bulan', date('m'));
        $tahun = $request->query('tahun', date('Y'));

        $queryBooking = Booking::with(['user', 'kendaraan', 'pembayaran'])
            ->whereMonth('created_at', $bulan)
            ->whereYear('created_at', $tahun);

        if ($request->has('kendaraan_id') && $request->kendaraan_id != '') {
            $queryBooking->where('kendaraan_id', $request->kendaraan_id);
        }

        if ($request->has('customer_id') && $request->customer_id != '') {
            $queryBooking->where('user_id', $request->customer_id);
        }

        $reportData = $queryBooking->latest()->get();
        $kendaraanList = Kendaraan::all();
        $customerList = User::whereHas('role', fn($q) => $q->where('name', 'Customer'))->get();

        $totalPendapatan = Pembayaran::where('status', 'Verified')
            ->whereMonth('tgl_pembayaran', $bulan)
            ->whereYear('tgl_pembayaran', $tahun)
            ->sum('jumlah_bayar');

        return view('laporan.index', compact('reportData', 'jenisLaporan', 'bulan', 'tahun', 'kendaraanList', 'customerList', 'totalPendapatan'));
    }

    public function exportPdf(Request $request)
    {
        $jenisLaporan = $request->query('jenis', 'transaksi');
        $bulan = $request->query('bulan', date('m'));
        $tahun = $request->query('tahun', date('Y'));

        $reportData = Booking::with(['user', 'kendaraan', 'pembayaran'])
            ->whereMonth('created_at', $bulan)
            ->whereYear('created_at', $tahun)
            ->get();

        $pdf = Pdf::loadView('laporan.pdf', compact('reportData', 'jenisLaporan', 'bulan', 'tahun'));
        return $pdf->download("Laporan-{$jenisLaporan}-{$bulan}-{$tahun}.pdf");
    }
}
