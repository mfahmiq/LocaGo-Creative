<?php

namespace App\Http\Controllers;

use App\Models\DokumenCustomer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class ProfileController extends Controller
{
    public function index()
    {
        $user = auth()->user()->load('dokumenCustomer');
        return view('profile.index', compact('user'));
    }

    public function updateProfile(Request $request)
    {
        $user = auth()->user();

        $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string',
        ]);

        $user->update([
            'name' => $request->name,
            'phone' => $request->phone,
            'address' => $request->address,
        ]);

        return back()->with('success', 'Profil berhasil diperbarui.');
    }

    public function updatePassword(Request $request)
    {
        $request->validate([
            'current_password' => 'required',
            'password' => 'required|min:8|confirmed',
        ]);

        $user = auth()->user();

        if (!Hash::check($request->current_password, $user->password)) {
            return back()->withErrors(['current_password' => 'Password saat ini salah.']);
        }

        $user->update(['password' => Hash::make($request->password)]);

        return back()->with('success', 'Password berhasil diperbarui.');
    }

    public function uploadDokumen(Request $request)
    {
        $request->validate([
            'no_ktp' => 'required|string|max:50',
            'file_ktp' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'no_sim' => 'required|string|max:50',
            'file_sim' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $user = auth()->user();
        $dokumen = DokumenCustomer::firstOrNew(['user_id' => $user->id]);

        $dokumen->no_ktp = $request->no_ktp;
        $dokumen->no_sim = $request->no_sim;

        if ($request->hasFile('file_ktp')) {
            if ($dokumen->file_ktp) {
                Storage::disk('public')->delete($dokumen->file_ktp);
            }
            $dokumen->file_ktp = $request->file('file_ktp')->store('dokumen/ktp', 'public');
        }

        if ($request->hasFile('file_sim')) {
            if ($dokumen->file_sim) {
                Storage::disk('public')->delete($dokumen->file_sim);
            }
            $dokumen->file_sim = $request->file('file_sim')->store('dokumen/sim', 'public');
        }

        $dokumen->status_verifikasi = 'Pending';
        $dokumen->save();

        return back()->with('success', 'Dokumen KTP/SIM berhasil diunggah. Menunggu verifikasi admin.');
    }
}
