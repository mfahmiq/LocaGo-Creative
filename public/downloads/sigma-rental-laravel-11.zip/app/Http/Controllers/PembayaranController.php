<?php

namespace App\Http\Controllers;

use App\Models\Pembayaran;
use App\Models\Booking;
use App\Http\Requests\PembayaranRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Barryvdh\DomPDF\Facade\Pdf;

class PembayaranController extends Controller
{
    public function index()
    {
        $query = Pembayaran::with(['booking.user', 'booking.kendaraan']);

        if (auth()->user()->hasRole('Customer')) {
            $query->whereHas('booking', function ($q) {
                $q->where('user_id', auth()->id());
            });
        }

        $pembayaranList = $query->latest()->paginate(10);

        return view('pembayaran.index', compact('pembayaranList'));
    }

    public function store(PembayaranRequest $request)
    {
        $data = $request->validated();

        if ($request->hasFile('bukti_pembayaran')) {
            $data['bukti_pembayaran'] = $request->file('bukti_pembayaran')->store('pembayaran', 'public');
        }

        $data['tgl_pembayaran'] = now();
        $data['status'] = 'Pending';

        $pembayaran = Pembayaran::updateOrCreate(
            ['booking_id' => $data['booking_id']],
            $data
        );

        return redirect()->route('pembayaran.index')->with('success', 'Bukti pembayaran berhasil diunggah. Menunggu verifikasi petugas.');
    }

    public function verifikasi(Request $request, Pembayaran $pembayaran)
    {
        $request->validate([
            'status' => 'required|in:Verified,Rejected,Pending',
            'catatan' => 'nullable|string',
        ]);

        $pembayaran->update([
            'status' => $request->status,
            'catatan' => $request->catatan,
        ]);

        if ($request->status === 'Verified') {
            if ($pembayaran->booking && $pembayaran->booking->status === 'Pending') {
                $pembayaran->booking->update(['status' => 'Disetujui']);
            }
            return back()->with('success', "Status pembayaran berhasil diubah menjadi Terbayar (Verified). Uang pembayaran masuk ke total pemasukan.");
        } elseif ($request->status === 'Rejected') {
            return back()->with('success', "Status pembayaran diubah menjadi Ditolak (Rejected).");
        } else {
            return back()->with('success', "Status pembayaran diubah menjadi Pending.");
        }
    }

    public function downloadInvoice(Pembayaran $pembayaran)
    {
        $pembayaran->load(['booking.user', 'booking.kendaraan']);

        $pdf = Pdf::loadView('pembayaran.invoice', compact('pembayaran'));
        return $pdf->download("Invoice-{$pembayaran->booking->kode_booking}.pdf");
    }
}
