<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\Kendaraan;
use App\Models\Pembayaran;
use App\Models\Denda;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class DashboardController extends Controller
{
    private function getDashboardPayload()
    {
        $user = Auth::user();
        $isCustomer = $user && $user->hasRole('Customer');

        if ($isCustomer) {
            $myBookingsQuery = Booking::where('user_id', $user->id);

            $stats = [
                'total_kendaraan' => $myBookingsQuery->count(), // Total bookings customer made
                'kendaraan_tersedia' => $myBookingsQuery->clone()->whereIn('status', ['Disetujui', 'Berjalan'])->count(), // Active sewa
                'kendaraan_disewa' => $myBookingsQuery->clone()->where('status', 'Pending')->count(), // Pending approval/payment
                'booking_hari_ini' => $myBookingsQuery->clone()->whereDate('created_at', Carbon::today())->count(),
                'pendapatan_bulan_ini' => (float) Pembayaran::whereHas('booking', function ($q) use ($user) {
                        $q->where('user_id', $user->id);
                    })->where('status', 'Verified')->sum('jumlah_bayar'),
                'denda_bulan_ini' => (float) Denda::whereHas('pengembalian.booking', function ($q) use ($user) {
                        $q->where('user_id', $user->id);
                    })->sum('total_denda'),
            ];
        } else {
            $stats = [
                'total_kendaraan' => Kendaraan::count(),
                'kendaraan_tersedia' => Kendaraan::where('status', 'Tersedia')->count(),
                'kendaraan_disewa' => Kendaraan::where('status', 'Disewa')->count(),
                'booking_hari_ini' => Booking::whereDate('created_at', Carbon::today())->count(),
                'pendapatan_bulan_ini' => (float) Pembayaran::where('status', 'Verified')
                    ->whereMonth('tgl_pembayaran', Carbon::now()->month)
                    ->whereYear('tgl_pembayaran', Carbon::now()->year)
                    ->sum('jumlah_bayar'),
                'denda_bulan_ini' => (float) Denda::whereMonth('created_at', Carbon::now()->month)
                    ->whereYear('created_at', Carbon::now()->year)
                    ->sum('total_denda'),
            ];
        }

        // Status Breakdown for fleet
        $statusArmada = [
            'Tersedia' => Kendaraan::where('status', 'Tersedia')->count(),
            'Booking' => Kendaraan::where('status', 'Booking')->count(),
            'Disewa' => Kendaraan::where('status', 'Disewa')->count(),
            'Servis' => Kendaraan::where('status', 'Servis')->count(),
        ];

        // 6 Months Revenue from DB
        $indonesianMonths = [
            1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
            5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
            9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
        ];

        $chartRevenueLabels = [];
        $chartRevenueValues = [];

        for ($i = 5; $i >= 0; $i--) {
            $targetDate = Carbon::now()->subMonths($i);
            $m = (int) $targetDate->format('n');
            $y = (int) $targetDate->format('Y');

            $label = $indonesianMonths[$m];
            if ($y !== (int) Carbon::now()->format('Y')) {
                $label .= ' ' . $y;
            }
            $chartRevenueLabels[] = $label;

            $revQuery = Pembayaran::where('status', 'Verified')
                ->whereMonth('tgl_pembayaran', $m)
                ->whereYear('tgl_pembayaran', $y);

            if ($isCustomer) {
                $revQuery->whereHas('booking', function ($q) use ($user) {
                    $q->where('user_id', $user->id);
                });
            }

            $chartRevenueValues[] = (float) $revQuery->sum('jumlah_bayar');
        }

        $bookingQuery = Booking::with(['user', 'kendaraan']);
        if ($isCustomer) {
            $bookingQuery->where('user_id', $user->id);
        }

        $bookingTerbaru = $bookingQuery->latest()->take(5)->get();

        return [
            'stats' => $stats,
            'statusArmada' => $statusArmada,
            'chartRevenue' => [
                'labels' => $chartRevenueLabels,
                'data' => $chartRevenueValues,
            ],
            'bookingTerbaru' => $bookingTerbaru,
            'user' => $user,
            'isCustomer' => $isCustomer,
        ];
    }

    public function index()
    {
        $payload = $this->getDashboardPayload();
        return view('dashboard.index', $payload);
    }

    public function data()
    {
        $payload = $this->getDashboardPayload();

        $formattedBookings = $payload['bookingTerbaru']->map(function ($item) {
            return [
                'kode_booking' => $item->kode_booking,
                'customer_name' => $item->user->name ?? 'N/A',
                'kendaraan_name' => trim(($item->kendaraan->merk ?? '') . ' ' . ($item->kendaraan->tipe ?? '')),
                'tgl_sewa_formatted' => $item->tgl_sewa ? $item->tgl_sewa->format('d M Y') : '-',
                'tgl_kembali_formatted' => $item->tgl_kembali_rencana ? $item->tgl_kembali_rencana->format('d M Y') : '-',
                'total_bayar_formatted' => 'Rp ' . number_format($item->total_bayar, 0, ',', '.'),
                'status' => $item->status,
            ];
        });

        return response()->json([
            'success' => true,
            'stats' => [
                'total_kendaraan' => $payload['stats']['total_kendaraan'],
                'kendaraan_tersedia' => $payload['stats']['kendaraan_tersedia'],
                'kendaraan_disewa' => $payload['stats']['kendaraan_disewa'],
                'booking_hari_ini' => $payload['stats']['booking_hari_ini'],
                'pendapatan_bulan_ini_formatted' => 'Rp ' . number_format($payload['stats']['pendapatan_bulan_ini'], 0, ',', '.'),
                'denda_bulan_ini_formatted' => 'Rp ' . number_format($payload['stats']['denda_bulan_ini'], 0, ',', '.'),
            ],
            'statusArmada' => $payload['statusArmada'],
            'chartRevenue' => $payload['chartRevenue'],
            'bookingTerbaru' => $formattedBookings,
            'updated_at' => now()->format('H:i:s'),
        ]);
    }
}
