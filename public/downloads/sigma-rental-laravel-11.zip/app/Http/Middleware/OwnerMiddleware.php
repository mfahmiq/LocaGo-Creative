<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class OwnerMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (auth()->check() && (auth()->user()->hasRole('Owner') || auth()->user()->hasRole('Admin'))) {
            return $next($request);
        }

        abort(403, 'Akses khusus Owner.');
    }
}
