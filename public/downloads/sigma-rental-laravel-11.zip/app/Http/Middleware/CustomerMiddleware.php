<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CustomerMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (auth()->check() && (auth()->user()->hasRole('Customer') || auth()->user()->hasRole('Admin'))) {
            return $next($request);
        }

        abort(403, 'Akses khusus Customer.');
    }
}
