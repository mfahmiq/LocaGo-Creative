<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (auth()->check() && (auth()->user()->hasRole('Admin') || auth()->user()->hasRole('admin'))) {
            return $next($request);
        }

        abort(403, 'Akses khusus Administrator.');
    }
}
