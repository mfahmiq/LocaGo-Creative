@extends('layouts.app')

@section('content')
<div class="space-y-6">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-black text-slate-900">{{ auth()->user()?->hasRole('Customer') ? 'Daftar Booking Saya' : 'Daftar Transaksi Booking / Sewa' }}</h1>
            <p class="text-xs text-slate-500">{{ auth()->user()?->hasRole('Customer') ? 'Riwayat dan status penyewaan kendaraan Anda.' : 'Kelola reservasi sewa kendaraan dan status pesanan.' }}</p>
        </div>
        <a href="{{ route('booking.create') }}" class="inline-flex items-center px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow transition">
            <span class="material-icons text-sm mr-2">add_circle</span> Form Booking Baru
        </a>
    </div>

    <!-- Filter by Status -->
    <form method="GET" action="{{ route('booking.index') }}" class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
        <label class="text-xs font-bold text-slate-700">Filter Status:</label>
        <select name="status" onchange="this.form.submit()" class="text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
            <option value="">Semua Status</option>
            <option value="Pending" {{ request('status') == 'Pending' ? 'selected' : '' }}>Pending</option>
            <option value="Disetujui" {{ request('status') == 'Disetujui' ? 'selected' : '' }}>Disetujui</option>
            <option value="Ditolak" {{ request('status') == 'Ditolak' ? 'selected' : '' }}>Ditolak</option>
            <option value="Berjalan" {{ request('status') == 'Berjalan' ? 'selected' : '' }}>Berjalan</option>
            <option value="Selesai" {{ request('status') == 'Selesai' ? 'selected' : '' }}>Selesai</option>
            <option value="Terlambat" {{ request('status') == 'Terlambat' ? 'selected' : '' }}>Terlambat</option>
        </select>
    </form>

    <!-- Booking Table -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
                <thead class="bg-slate-50 text-slate-500 font-semibold uppercase border-b border-slate-200">
                    <tr>
                        <th class="p-4">Kode Booking</th>
                        <th class="p-4">Customer</th>
                        <th class="p-4">Kendaraan</th>
                        <th class="p-4">Tgl Sewa - Kembali</th>
                        <th class="p-4">Durasi</th>
                        <th class="p-4">Total Bayar</th>
                        <th class="p-4">Status</th>
                        <th class="p-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 font-medium">
                    @forelse($bookings as $item)
                        <tr class="hover:bg-slate-50 transition">
                            <td class="p-4 font-bold text-slate-900">{{ $item->kode_booking }}</td>
                            <td class="p-4">
                                <div class="font-bold text-slate-800">{{ $item->user->name ?? 'User' }}</div>
                                <div class="text-[10px] text-slate-400">{{ $item->user->phone ?? '' }}</div>
                            </td>
                            <td class="p-4">
                                <div class="font-bold text-emerald-700">{{ $item->kendaraan->merk ?? '' }} {{ $item->kendaraan->tipe ?? '' }}</div>
                                <div class="text-[10px] text-slate-400">{{ $item->kendaraan->plat_nomor ?? '' }}</div>
                            </td>
                            <td class="p-4 text-slate-600">
                                {{ $item->tgl_sewa->format('d/m/Y') }} - {{ $item->tgl_kembali_rencana->format('d/m/Y') }}
                            </td>
                            <td class="p-4 font-bold text-slate-700">{{ $item->durasi_hari }} Hari</td>
                            <td class="p-4 font-black text-slate-900">Rp {{ number_format($item->total_bayar, 0, ',', '.') }}</td>
                            <td class="p-4">
                                @if($item->status == 'Pending')
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">Pending</span>
                                @elseif($item->status == 'Disetujui')
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">Disetujui</span>
                                @elseif($item->status == 'Berjalan')
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">Berjalan</span>
                                @elseif($item->status == 'Selesai')
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">Selesai</span>
                                @else
                                    <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">{{ $item->status }}</span>
                                @endif
                            </td>
                            <td class="p-4 text-center">
                                @if(auth()->user()?->hasRole('Admin') || auth()->user()?->hasRole('Petugas'))
                                    <form method="POST" action="{{ route('booking.update-status', $item->id) }}" class="inline-flex items-center space-x-1">
                                        @csrf
                                        <select name="status" onchange="this.form.submit()" class="text-[10px] border border-slate-300 rounded-lg p-1 bg-white focus:outline-none">
                                            <option value="">-- Ubah Status --</option>
                                            <option value="Disetujui">Disetujui</option>
                                            <option value="Berjalan">Berjalan (Disewa)</option>
                                            <option value="Selesai">Selesai</option>
                                            <option value="Ditolak">Ditolak</option>
                                        </select>
                                    </form>
                                @else
                                    <span class="text-[10px] text-slate-400">View Only</span>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="p-8 text-center text-slate-400">Belum ada transaksi sewa kendaraan.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <div class="mt-4">
        {{ $bookings->links() }}
    </div>
</div>
@endsection
