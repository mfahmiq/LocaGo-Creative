@extends('layouts.app')

@section('content')
<div class="space-y-6">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl font-black text-slate-900">Laporan Keuangan & Transaksi</h1>
            <p class="text-xs text-slate-500">Filter laporan transaksi, pendapatan, kendaraan, dan cetak PDF / Excel.</p>
        </div>
        <div class="flex items-center space-x-2">
            <a href="{{ route('laporan.export-pdf', request()->query()) }}" class="inline-flex items-center px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow transition">
                <span class="material-icons text-sm mr-2">picture_as_pdf</span> Export PDF
            </a>
        </div>
    </div>

    <!-- Filters Form -->
    <form method="GET" action="{{ route('laporan.index') }}" class="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        <div>
            <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Jenis Laporan</label>
            <select name="jenis" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                <option value="transaksi" {{ request('jenis') == 'transaksi' ? 'selected' : '' }}>Laporan Transaksi</option>
                <option value="pendapatan" {{ request('jenis') == 'pendapatan' ? 'selected' : '' }}>Laporan Pendapatan</option>
                <option value="kendaraan" {{ request('jenis') == 'kendaraan' ? 'selected' : '' }}>Laporan Kendaraan</option>
            </select>
        </div>

        <div>
            <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Bulan</label>
            <select name="bulan" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                @for($m=1; $m<=12; $m++)
                    <option value="{{ sprintf('%02d', $m) }}" {{ $bulan == sprintf('%02d', $m) ? 'selected' : '' }}>
                        {{ date('F', mktime(0, 0, 0, $m, 1)) }}
                    </option>
                @endfor
            </select>
        </div>

        <div>
            <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Tahun</label>
            <select name="tahun" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                @for($y=date('Y'); $y>=2022; $y--)
                    <option value="{{ $y }}" {{ $tahun == $y ? 'selected' : '' }}>{{ $y }}</option>
                @endfor
            </select>
        </div>

        <div>
            <label class="block text-[10px] font-bold text-slate-500 uppercase mb-1">Kendaraan</label>
            <select name="kendaraan_id" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                <option value="">Semua Kendaraan</option>
                @foreach($kendaraanList as $k)
                    <option value="{{ $k->id }}" {{ request('kendaraan_id') == $k->id ? 'selected' : '' }}>{{ $k->merk }} {{ $k->tipe }}</option>
                @endforeach
            </select>
        </div>

        <div class="flex items-end">
            <button type="submit" class="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition">
                Tampilkan Laporan
            </button>
        </div>
    </form>

    <!-- Summary Box -->
    <div class="bg-emerald-900 text-white p-6 rounded-2xl shadow-md flex items-center justify-between">
        <div>
            <p class="text-xs uppercase font-semibold text-emerald-300 tracking-wider">Total Pendapatan Terverifikasi Per Periode</p>
            <h2 class="text-3xl font-black mt-1">Rp {{ number_format($totalPendapatan, 0, ',', '.') }}</h2>
        </div>
        <div class="w-12 h-12 rounded-2xl bg-emerald-800 flex items-center justify-center text-emerald-300">
            <span class="material-icons text-2xl">monetization_on</span>
        </div>
    </div>

    <!-- Report Table -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
                <thead class="bg-slate-50 text-slate-500 font-semibold uppercase border-b border-slate-200">
                    <tr>
                        <th class="p-4">Kode Booking</th>
                        <th class="p-4">Customer</th>
                        <th class="p-4">Kendaraan</th>
                        <th class="p-4">Tanggal Sewa</th>
                        <th class="p-4">Durasi</th>
                        <th class="p-4">Total Bayar</th>
                        <th class="p-4">Status Transaksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 font-medium">
                    @forelse($reportData as $row)
                        <tr class="hover:bg-slate-50 transition">
                            <td class="p-4 font-bold text-slate-900">{{ $row->kode_booking }}</td>
                            <td class="p-4 text-slate-700">{{ $row->user->name ?? 'N/A' }}</td>
                            <td class="p-4 text-emerald-700 font-bold">{{ $row->kendaraan->merk ?? '' }} {{ $row->kendaraan->tipe ?? '' }}</td>
                            <td class="p-4 text-slate-500">{{ $row->tgl_sewa->format('d/m/Y') }} - {{ $row->tgl_kembali_rencana->format('d/m/Y') }}</td>
                            <td class="p-4 font-bold text-slate-800">{{ $row->durasi_hari }} Hari</td>
                            <td class="p-4 font-black text-slate-900">Rp {{ number_format($row->total_bayar, 0, ',', '.') }}</td>
                            <td class="p-4 font-bold text-emerald-600">{{ $row->status }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="p-8 text-center text-slate-400">Tidak ada data laporan untuk periode ini.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
