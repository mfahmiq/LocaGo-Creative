@extends('layouts.app')

@php
    $allBookingsData = App\Models\Booking::with(['kendaraan', 'user', 'pembayaran'])->get()->map(function($b) {
        return [
            'id' => $b->id,
            'kode_booking' => $b->kode_booking,
            'kendaraan_id' => $b->kendaraan_id,
            'user_name' => $b->user->name ?? 'Customer',
            'kendaraan_nama' => ($b->kendaraan->merk ?? 'Armada') . ' ' . ($b->kendaraan->tipe ?? ''),
            'plat_nomor' => $b->kendaraan->plat_nomor ?? '-',
            'tgl_sewa' => $b->tgl_sewa->format('Y-m-d'),
            'tgl_kembali' => $b->tgl_kembali_rencana->format('Y-m-d'),
            'total_bayar' => $b->total_bayar,
            'status' => $b->status,
            'pembayaran_id' => $b->pembayaran?->id ?? null,
        ];
    });

    $vehicleListData = App\Models\Kendaraan::select('id', 'merk', 'tipe', 'plat_nomor')->get()->map(function($v) {
        return [
            'id' => $v->id,
            'nama' => $v->merk . ' ' . $v->tipe . ' (' . $v->plat_nomor . ')'
        ];
    });
@endphp

@section('content')
<div class="space-y-6" x-data="calendarApp()">
    <!-- Header Page -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm">
        <div class="flex items-center space-x-4">
            <div class="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 flex items-center justify-center">
                <span class="material-icons text-2xl">calendar_month</span>
            </div>
            <div>
                <h1 class="text-xl font-black text-slate-900 tracking-wide">Jadwal Availability & Kalender Sewa</h1>
                <p class="text-xs text-slate-500 mt-0.5">Pantau ketersediaan armada mobil dan motor dengan tampilan kalender bulat interaktif.</p>
            </div>
        </div>
        <div class="flex items-center space-x-3">
            <a href="{{ route('booking.create') }}" class="inline-flex items-center px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-600/20 transition-all">
                <span class="material-icons text-sm mr-1.5">add</span> Buat Booking Baru
            </a>
        </div>
    </div>

    <!-- Main Grid Layout: Circular Calendar & Vehicle Filter / Summary -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left Side: Circular Aesthetic Calendar Box -->
        <div class="lg:col-span-8 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
            
            <!-- Calendar Header & Navigation -->
            <div class="flex items-center justify-between pb-6 border-b border-slate-100">
                <div class="flex items-center space-x-3">
                    <button @click="prevMonth()" class="p-2 rounded-2xl border border-slate-200 hover:bg-slate-100 text-slate-700 transition">
                        <span class="material-icons text-base">chevron_left</span>
                    </button>
                    <button @click="nextMonth()" class="p-2 rounded-2xl border border-slate-200 hover:bg-slate-100 text-slate-700 transition">
                        <span class="material-icons text-base">chevron_right</span>
                    </button>
                    <button @click="goToToday()" class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-extrabold rounded-xl transition">
                        Hari Ini
                    </button>
                </div>

                <div class="text-center">
                    <h2 class="text-lg sm:text-xl font-black text-slate-900 uppercase tracking-wider" x-text="monthYearTitle"></h2>
                </div>

                <!-- Filter Armada Dropdown -->
                <div class="w-36 sm:w-48">
                    <select x-model="selectedVehicleFilter" class="w-full text-xs font-semibold border border-slate-200 rounded-xl px-2.5 py-2 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500">
                        <option value="ALL">-- Semua Armada --</option>
                        <template x-for="v in vehicleList" :key="v.id">
                            <option :value="v.id" x-text="v.nama"></option>
                        </template>
                    </select>
                </div>
            </div>

            <!-- Legend Status Indicators -->
            <div class="flex flex-wrap items-center justify-center gap-4 py-4 text-[11px] font-bold text-slate-600 bg-slate-50/70 rounded-2xl my-4 border border-slate-100">
                <div class="flex items-center space-x-1.5">
                    <span class="w-3 h-3 rounded-full bg-emerald-500 border border-emerald-600"></span>
                    <span>Sewa Berjalan (Aktif)</span>
                </div>
                <div class="flex items-center space-x-1.5">
                    <span class="w-3 h-3 rounded-full bg-blue-500 border border-blue-600"></span>
                    <span>Disetujui / Disewa</span>
                </div>
                <div class="flex items-center space-x-1.5">
                    <span class="w-3 h-3 rounded-full bg-amber-400 border border-amber-500"></span>
                    <span>Menunggu Pembayaran</span>
                </div>
                <div class="flex items-center space-x-1.5">
                    <span class="w-3 h-3 rounded-full bg-slate-900 border border-slate-950"></span>
                    <span>Tanggal Dipilih</span>
                </div>
            </div>

            <!-- Weekday Headers (S M T W T F S) -->
            <div class="grid grid-cols-7 gap-1 sm:gap-2 text-center py-2 border-b border-slate-100 mb-4">
                <template x-for="day in ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu']">
                    <div class="text-xs font-black uppercase text-slate-400 tracking-wider" x-text="day.substring(0, 3)"></div>
                </template>
            </div>

            <!-- Circular Days Grid -->
            <div class="grid grid-cols-7 gap-y-3 sm:gap-y-4 gap-x-1 sm:gap-x-2 justify-items-center min-h-[320px]">
                <template x-for="(cell, index) in calendarCells" :key="index">
                    <div class="w-full flex justify-center items-center">
                        <template x-if="cell.type === 'empty'">
                            <div class="w-9 h-9 sm:w-11 sm:h-11 rounded-full flex items-center justify-center text-xs text-slate-300 font-semibold select-none">
                                <span x-text="cell.day"></span>
                            </div>
                        </template>

                        <template x-if="cell.type === 'day'">
                            <button @click="selectDate(cell.dateStr)" 
                                    class="relative w-9 h-9 sm:w-11 sm:h-11 rounded-full flex flex-col items-center justify-center font-bold text-xs sm:text-sm transition-all duration-200 select-none group"
                                    :class="{
                                        'bg-slate-950 text-white shadow-lg ring-4 ring-slate-900/20 scale-110 z-20': cell.dateStr === selectedDateStr,
                                        'bg-emerald-100/90 text-emerald-950 hover:bg-emerald-200 border border-emerald-300': cell.dateStr !== selectedDateStr && cell.hasActiveBooking,
                                        'bg-blue-100/90 text-blue-950 hover:bg-blue-200 border border-blue-300': cell.dateStr !== selectedDateStr && cell.hasApprovedBooking && !cell.hasActiveBooking,
                                        'bg-amber-100/90 text-amber-950 hover:bg-amber-200 border border-amber-300': cell.dateStr !== selectedDateStr && cell.hasPendingBooking && !cell.hasActiveBooking && !cell.hasApprovedBooking,
                                        'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200/80': cell.dateStr !== selectedDateStr && !cell.hasBooking,
                                        'ring-2 ring-emerald-500 font-black': cell.isToday && cell.dateStr !== selectedDateStr
                                    }">
                                <span x-text="cell.day"></span>

                                <!-- Status Dots / Indicators -->
                                <template x-if="cell.hasBooking && cell.dateStr !== selectedDateStr">
                                    <span class="absolute -bottom-0.5 w-1.5 h-1.5 rounded-full"
                                          :class="{
                                              'bg-emerald-600': cell.hasActiveBooking,
                                              'bg-blue-600': cell.hasApprovedBooking && !cell.hasActiveBooking,
                                              'bg-amber-500': cell.hasPendingBooking && !cell.hasActiveBooking && !cell.hasApprovedBooking
                                          }"></span>
                                </template>
                            </button>
                        </template>
                    </div>
                </template>
            </div>

            <!-- Footer Quick Info -->
            <div class="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-medium">
                <span>Klik pada tanggal bulat untuk melihat detail armada dan jadwal sewa.</span>
                <span class="font-bold text-slate-800" x-text="'Total Booking Bulan Ini: ' + currentMonthBookingsCount"></span>
            </div>

        </div>

        <!-- Right Side: Selected Date Detail Section & Schedule Card -->
        <div class="lg:col-span-4 space-y-6">
            
            <!-- Selected Date Header Card -->
            <div class="bg-slate-900 text-white p-6 rounded-3xl shadow-xl border border-slate-800 relative overflow-hidden">
                <div class="absolute -right-6 -bottom-6 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl"></div>
                
                <div class="flex items-center justify-between mb-4">
                    <span class="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        Detail Tanggal
                    </span>
                    <span class="text-xs font-semibold text-slate-400" x-text="formattedSelectedDate"></span>
                </div>

                <div class="text-2xl font-black tracking-wide text-white mb-1" x-text="selectedDateDayName"></div>
                <div class="text-xs text-slate-400" x-text="selectedDateFullText"></div>

                <!-- Status Banner on selected date -->
                <div class="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between text-xs">
                    <span class="text-slate-400">Total Booking Active:</span>
                    <span class="font-bold text-emerald-400 text-sm" x-text="selectedDateBookings.length + ' Booking'"></span>
                </div>
            </div>

            <!-- Booking List on Selected Date -->
            <div class="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4 min-h-[300px]">
                <h3 class="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center">
                    <span class="material-icons text-emerald-600 text-base mr-1.5">event_note</span>
                    Jadwal & Reservasi Armada
                </h3>

                <!-- If NO Bookings on selected date -->
                <template x-if="selectedDateBookings.length === 0">
                    <div class="text-center py-10 px-4 border-2 border-dashed border-slate-200 rounded-2xl bg-slate-50/50">
                        <div class="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-3">
                            <span class="material-icons text-2xl">check_circle</span>
                        </div>
                        <h4 class="text-sm font-bold text-slate-800">Semua Armada Tersedia</h4>
                        <p class="text-xs text-slate-500 mt-1 mb-4">Tidak ada jadwal sewa pada tanggal ini. Siap dipesan pelanggan!</p>
                        <a :href="'{{ route('booking.create') }}?tgl=' + selectedDateStr" class="inline-flex items-center px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition">
                            <span class="material-icons text-xs mr-1">add_circle</span> Buat Booking Tanggal Ini
                        </a>
                    </div>
                </template>

                <!-- List of Bookings on selected date -->
                <template x-for="b in selectedDateBookings" :key="b.id">
                    <div class="p-4 rounded-2xl border border-slate-200 bg-slate-50/60 hover:bg-white hover:border-emerald-300 transition-all duration-200 shadow-sm space-y-3">
                        
                        <div class="flex items-center justify-between">
                            <span class="font-black text-xs text-slate-900 tracking-wider" x-text="b.kode_booking"></span>
                            <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wide"
                                  :class="{
                                      'bg-emerald-100 text-emerald-800 border border-emerald-300': b.status === 'Berjalan',
                                      'bg-blue-100 text-blue-800 border border-blue-300': b.status === 'Disetujui',
                                      'bg-amber-100 text-amber-800 border border-amber-300': b.status === 'Pending',
                                      'bg-slate-200 text-slate-800': b.status === 'Selesai'
                                  }" x-text="b.status"></span>
                        </div>

                        <div class="text-xs space-y-1">
                            <div class="flex items-center justify-between">
                                <span class="text-slate-500">Armada:</span>
                                <span class="font-bold text-slate-800" x-text="b.kendaraan_nama + ' (' + b.plat_nomor + ')'"></span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span class="text-slate-500">Penyewa:</span>
                                <span class="font-semibold text-slate-800" x-text="b.user_name"></span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span class="text-slate-500">Periode Sewa:</span>
                                <span class="font-medium text-slate-700" x-text="b.tgl_sewa + ' s/d ' + b.tgl_kembali"></span>
                            </div>
                            <div class="flex items-center justify-between pt-1 border-t border-slate-200/80 font-bold">
                                <span class="text-slate-600">Total Tagihan:</span>
                                <span class="text-emerald-700 font-black text-xs" x-text="'Rp ' + Number(b.total_bayar).toLocaleString('id-ID')"></span>
                            </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="pt-2 flex items-center justify-end space-x-2 border-t border-slate-200/60">
                            <a :href="'/pembayaran/' + b.pembayaran_id + '/invoice'" x-show="b.pembayaran_id" class="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-white text-[10px] font-bold rounded-lg transition inline-flex items-center">
                                <span class="material-icons text-xs mr-1">picture_as_pdf</span> Invoice
                            </a>
                            <a href="{{ route('booking.index') }}" class="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-[10px] font-bold rounded-lg border border-emerald-200 transition">
                                Kelola Booking
                            </a>
                        </div>
                    </div>
                </template>

            </div>

        </div>

    </div>
</div>

@push('scripts')
<script>
function calendarApp() {
    return {
        currentYear: new Date().getFullYear(),
        currentMonth: new Date().getMonth(), // 0-indexed
        selectedDateStr: new Date().toISOString().split('T')[0],
        selectedVehicleFilter: 'ALL',
        
        allBookings: @json($allBookingsData),
        vehicleList: @json($vehicleListData),

        get filteredBookings() {
            if (this.selectedVehicleFilter === 'ALL') {
                return this.allBookings;
            }
            return this.allBookings.filter(b => b.kendaraan_id == this.selectedVehicleFilter);
        },

        get monthYearTitle() {
            const date = new Date(this.currentYear, this.currentMonth, 1);
            return date.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' });
        },

        get currentMonthBookingsCount() {
            const startMonthStr = `${this.currentYear}-${String(this.currentMonth + 1).padStart(2, '0')}-01`;
            const endMonthStr = `${this.currentYear}-${String(this.currentMonth + 1).padStart(2, '0')}-31`;
            
            return this.filteredBookings.filter(b => {
                return b.tgl_sewa <= endMonthStr && b.tgl_kembali >= startMonthStr;
            }).length;
        },

        get calendarCells() {
            const cells = [];
            const firstDayIndex = new Date(this.currentYear, this.currentMonth, 1).getDay();
            const daysInMonth = new Date(this.currentYear, this.currentMonth + 1, 0).getDate();
            const todayStr = new Date().toISOString().split('T')[0];

            // Empty cells before 1st day
            for (let i = 0; i < firstDayIndex; i++) {
                cells.push({ type: 'empty', day: '' });
            }

            // Actual days of current month
            for (let d = 1; d <= daysInMonth; d++) {
                const dayStr = String(d).padStart(2, '0');
                const monthStr = String(this.currentMonth + 1).padStart(2, '0');
                const dateStr = `${this.currentYear}-${monthStr}-${dayStr}`;

                const bookingsOnDate = this.filteredBookings.filter(b => {
                    return dateStr >= b.tgl_sewa && dateStr <= b.tgl_kembali;
                });

                const hasBooking = bookingsOnDate.length > 0;
                const hasActiveBooking = bookingsOnDate.some(b => b.status === 'Berjalan');
                const hasApprovedBooking = bookingsOnDate.some(b => b.status === 'Disetujui');
                const hasPendingBooking = bookingsOnDate.some(b => b.status === 'Pending');

                cells.push({
                    type: 'day',
                    day: d,
                    dateStr: dateStr,
                    isToday: dateStr === todayStr,
                    hasBooking: hasBooking,
                    hasActiveBooking: hasActiveBooking,
                    hasApprovedBooking: hasApprovedBooking,
                    hasPendingBooking: hasPendingBooking,
                });
            }

            return cells;
        },

        get selectedDateBookings() {
            return this.filteredBookings.filter(b => {
                return this.selectedDateStr >= b.tgl_sewa && this.selectedDateStr <= b.tgl_kembali;
            });
        },

        get formattedSelectedDate() {
            if (!this.selectedDateStr) return '';
            const d = new Date(this.selectedDateStr);
            return d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
        },

        get selectedDateDayName() {
            if (!this.selectedDateStr) return '';
            const d = new Date(this.selectedDateStr);
            return d.toLocaleDateString('id-ID', { weekday: 'long' });
        },

        get selectedDateFullText() {
            if (!this.selectedDateStr) return '';
            const d = new Date(this.selectedDateStr);
            return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
        },

        selectDate(dateStr) {
            this.selectedDateStr = dateStr;
        },

        prevMonth() {
            if (this.currentMonth === 0) {
                this.currentMonth = 11;
                this.currentYear--;
            } else {
                this.currentMonth--;
            }
        },

        nextMonth() {
            if (this.currentMonth === 11) {
                this.currentMonth = 0;
                this.currentYear++;
            } else {
                this.currentMonth++;
            }
        },

        goToToday() {
            const today = new Date();
            this.currentYear = today.getFullYear();
            this.currentMonth = today.getMonth();
            this.selectedDateStr = today.toISOString().split('T')[0];
        }
    }
}
</script>
@endpush
@endsection
