<!-- Topbar Component -->
<header class="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-6 z-10 shadow-sm">
    <div class="flex items-center space-x-3">
        <button @click="sidebarOpen = true" class="lg:hidden p-2 rounded-2xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors focus:outline-none">
            <span class="material-icons">menu</span>
        </button>
        <div class="hidden sm:flex items-center text-xs text-slate-500 font-medium space-x-2">
            <span>SIGMA RENTAL</span>
            <span>/</span>
            <span class="text-slate-800 font-semibold uppercase">{{ request()->segment(1) ?? 'Dashboard' }}</span>
        </div>
    </div>

    <!-- Right Topbar Controls -->
    <div class="flex items-center space-x-4">
        
        <!-- Role Badge -->
        <span class="hidden sm:inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-2"></span>
            Role: {{ auth()->user()?->role?->display_name ?? 'Customer' }}
        </span>

        <!-- Quick Booking Button -->
        <a href="{{ route('booking.create') }}" class="inline-flex items-center px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow transition-colors">
            <span class="material-icons text-sm mr-1.5">add_circle</span>
            Booking Baru
        </a>

        <!-- User Dropdown Menu -->
        <div class="relative" x-data="{ open: false }">
            <button @click="open = !open" class="flex items-center space-x-2 p-1.5 rounded-xl hover:bg-slate-100 focus:outline-none transition-colors">
                <div class="w-8 h-8 rounded-full bg-slate-800 text-white font-bold flex items-center justify-center text-xs">
                    {{ strtoupper(substr(auth()->user()->name ?? 'U', 0, 1)) }}
                </div>
                <span class="hidden md:inline text-xs font-semibold text-slate-700 max-w-[120px] truncate">{{ auth()->user()->name ?? 'User' }}</span>
                <span class="material-icons text-sm text-slate-400">expand_more</span>
            </button>

            <!-- Dropdown Items -->
            <div x-show="open" 
                 @click.away="open = false" 
                 x-transition:enter="transition ease-out duration-100"
                 x-transition:enter-start="transform opacity-0 scale-95"
                 x-transition:enter-end="transform opacity-100 scale-100"
                 class="absolute right-0 mt-2 w-56 rounded-xl bg-white border border-slate-200 shadow-xl py-2 z-50">
                <div class="px-4 py-2 border-b border-slate-100">
                    <p class="text-xs font-semibold text-slate-800">{{ auth()->user()->name ?? 'User' }}</p>
                    <p class="text-[11px] text-slate-500 truncate">{{ auth()->user()->email ?? '' }}</p>
                </div>
                <a href="{{ route('profile.index') }}" class="flex items-center px-4 py-2 text-xs text-slate-700 hover:bg-slate-50">
                    <span class="material-icons text-sm mr-2 text-slate-400">account_circle</span>
                    Profil & Dokumen
                </a>
                <a href="{{ route('calendar') }}" class="flex items-center px-4 py-2 text-xs text-slate-700 hover:bg-slate-50">
                    <span class="material-icons text-sm mr-2 text-slate-400">calendar_month</span>
                    Jadwal Sewa
                </a>
                <div class="border-t border-slate-100 my-1"></div>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="w-full text-left flex items-center px-4 py-2 text-xs text-rose-600 hover:bg-rose-50 font-medium">
                        <span class="material-icons text-sm mr-2 text-rose-500">logout</span>
                        Keluar / Logout
                    </button>
                </form>
            </div>
        </div>
    </div>
</header>
