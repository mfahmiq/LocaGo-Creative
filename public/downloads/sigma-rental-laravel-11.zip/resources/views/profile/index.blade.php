@extends('layouts.app')

@section('content')
<div class="max-w-4xl mx-auto space-y-6">
    <div>
        <h1 class="text-2xl font-black text-slate-900">Profil Saya & Dokumen Identitas</h1>
        <p class="text-xs text-slate-500">Kelola informasi pribadi, ubah password, dan ungga dokumen KTP/SIM untuk keperluan sewa.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        <!-- Profile Info Form -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <h3 class="text-sm font-bold text-slate-800 flex items-center border-b border-slate-100 pb-3">
                <span class="material-icons text-emerald-600 mr-2">person</span> Informasi Pengguna
            </h3>
            <form method="POST" action="{{ route('profile.update') }}" class="space-y-3">
                @csrf
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Nama Lengkap</label>
                    <input type="text" name="name" value="{{ old('name', $user->name) }}" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Email</label>
                    <input type="email" value="{{ $user->email }}" disabled class="w-full text-xs border border-slate-200 bg-slate-100 text-slate-500 rounded-xl px-3 py-2 cursor-not-allowed">
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">No. WhatsApp / HP</label>
                    <input type="text" name="phone" value="{{ old('phone', $user->phone) }}" placeholder="081234567890" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Alamat Domisili</label>
                    <textarea name="address" rows="2" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">{{ old('address', $user->address) }}</textarea>
                </div>
                <button type="submit" class="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition">
                    Simpan Perubahan Profil
                </button>
            </form>
        </div>

        <!-- Upload KTP / SIM Document Form -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <h3 class="text-sm font-bold text-slate-800 flex items-center border-b border-slate-100 pb-3">
                <span class="material-icons text-indigo-600 mr-2">badge</span> Unggah Dokumen KTP & SIM
            </h3>
            
            @if($user->dokumenCustomer)
                <div class="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                    <p>Status Verifikasi: 
                        <span class="font-bold text-emerald-600 uppercase">{{ $user->dokumenCustomer->status_verifikasi }}</span>
                    </p>
                    <p class="text-[10px] text-slate-500 mt-1">No KTP: {{ $user->dokumenCustomer->no_ktp }} | No SIM: {{ $user->dokumenCustomer->no_sim }}</p>
                </div>
            @endif

            <form method="POST" action="{{ route('profile.dokumen') }}" enctype="multipart/form-data" class="space-y-3">
                @csrf
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Nomor KTP (NIK) *</label>
                    <input type="text" name="no_ktp" value="{{ old('no_ktp', $user->dokumenCustomer->no_ktp ?? '') }}" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Foto KTP</label>
                    <input type="file" name="file_ktp" accept="image/*" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-1.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Nomor SIM *</label>
                    <input type="text" name="no_sim" value="{{ old('no_sim', $user->dokumenCustomer->no_sim ?? '') }}" required class="w-full text-xs border border-slate-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Foto SIM</label>
                    <input type="file" name="file_sim" accept="image/*" class="w-full text-xs border border-slate-300 rounded-xl px-3 py-1.5 focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
                <button type="submit" class="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition">
                    Unggah / Perbarui Dokumen
                </button>
            </form>
        </div>
    </div>
</div>
@endsection
