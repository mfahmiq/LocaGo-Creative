@extends('layouts.app')

@section('content')
<div class="space-y-6">
    <div>
        <h1 class="text-2xl font-black text-slate-900">Manajemen Pengguna & Verifikasi KTP/SIM</h1>
        <p class="text-xs text-slate-500">Kelola daftar akun pengguna dan verifikasi dokumen identitas customer.</p>
    </div>

    <!-- Users Table -->
    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
                <thead class="bg-slate-50 text-slate-500 font-semibold uppercase border-b border-slate-200">
                    <tr>
                        <th class="p-4">Pengguna</th>
                        <th class="p-4">Email</th>
                        <th class="p-4">Role</th>
                        <th class="p-4">Status Dokumen (KTP/SIM)</th>
                        <th class="p-4 text-center">Aksi Verifikasi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 font-medium">
                    @forelse($users as $u)
                        <tr class="hover:bg-slate-50 transition">
                            <td class="p-4">
                                <div class="font-bold text-slate-900">{{ $u->name }}</div>
                                <div class="text-[10px] text-slate-500">{{ $u->phone ?? 'No HP belum diisi' }}</div>
                            </td>
                            <td class="p-4 text-slate-600">{{ $u->email }}</td>
                            <td class="p-4">
                                <span class="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-100 text-slate-800">
                                    {{ $u->role->display_name ?? 'User' }}
                                </span>
                            </td>
                            <td class="p-4">
                                @if($u->dokumenCustomer)
                                    <div class="space-y-1">
                                        <div class="text-[10px] text-slate-700">KTP: <strong>{{ $u->dokumenCustomer->no_ktp }}</strong> | SIM: <strong>{{ $u->dokumenCustomer->no_sim }}</strong></div>
                                        <div>
                                            @if($u->dokumenCustomer->status_verifikasi == 'Verified')
                                                <span class="px-2 py-0.5 rounded text-[9px] font-bold bg-emerald-100 text-emerald-800">Verified</span>
                                            @elseif($u->dokumenCustomer->status_verifikasi == 'Pending')
                                                <span class="px-2 py-0.5 rounded text-[9px] font-bold bg-amber-100 text-amber-800">Pending Verification</span>
                                            @else
                                                <span class="px-2 py-0.5 rounded text-[9px] font-bold bg-rose-100 text-rose-800">Rejected</span>
                                            @endif
                                        </div>
                                    </div>
                                @else
                                    <span class="text-[10px] text-slate-400">Dokumen Belum Diunggah</span>
                                @endif
                            </td>
                            <td class="p-4 text-center">
                                @if($u->dokumenCustomer && $u->dokumenCustomer->status_verifikasi == 'Pending')
                                    <form method="POST" action="{{ route('admin.users.verifikasi-dokumen', $u->dokumenCustomer->id) }}" class="inline-flex space-x-1">
                                        @csrf
                                        <input type="hidden" name="status_verifikasi" value="Verified">
                                        <button type="submit" class="px-2.5 py-1 bg-emerald-600 text-white rounded-lg text-[10px] font-bold hover:bg-emerald-700 shadow">
                                            Verifikasi KTP/SIM
                                        </button>
                                    </form>
                                @else
                                    <span class="text-[10px] text-slate-400">-</span>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="p-8 text-center text-slate-400">Belum ada pengguna terdaftar.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
