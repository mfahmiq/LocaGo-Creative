<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - SIGMA RENTAL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body class="bg-slate-950 text-white font-sans flex items-center justify-center min-h-screen p-4">

    <div class="w-full max-w-md bg-slate-900 rounded-3xl border border-slate-800 p-8 shadow-2xl">
        <div class="text-center mb-8">
            <div class="w-12 h-12 rounded-2xl bg-emerald-500 mx-auto flex items-center justify-center font-black text-slate-950 text-2xl mb-3 shadow-lg">
                <span class="material-icons">directions_car</span>
            </div>
            <h1 class="text-2xl font-black">SIGMA RENTAL</h1>
            <p class="text-xs text-slate-400 mt-1">Masuk ke akun Anda untuk menyewa atau mengelola armada.</p>
        </div>

        <!-- Quick Demo Account Switcher -->
        <div class="mb-6 p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-[11px] space-y-1">
            <span class="font-bold text-emerald-400">Akun Demo Default (Password: password):</span>
            <div class="grid grid-cols-2 gap-1 text-slate-300">
                <div>Admin: <code>admin@sigmarental.com</code></div>
                <div>Petugas: <code>petugas@sigmarental.com</code></div>
                <div>Owner: <code>owner@sigmarental.com</code></div>
                <div>Customer: <code>customer@sigmarental.com</code></div>
            </div>
        </div>

        @if ($errors->any())
            <div class="mb-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-400 text-xs">
                <ul class="list-disc list-inside space-y-1">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('login') }}" class="space-y-4">
            @csrf

            <div>
                <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Email *</label>
                <input type="email" name="email" value="{{ old('email', 'admin@sigmarental.com') }}" required class="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none">
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Password *</label>
                <input type="password" name="password" value="password" required class="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none">
            </div>

            <div class="flex items-center justify-between text-xs">
                <label class="flex items-center text-slate-400">
                    <input type="checkbox" name="remember" class="rounded bg-slate-950 border-slate-800 text-emerald-500 focus:ring-0">
                    <span class="ml-2">Ingat Saya</span>
                </label>
                <a href="{{ route('password.request') }}" class="text-emerald-400 hover:underline">Lupa Password?</a>
            </div>

            <button type="submit" class="w-full py-3 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-xl text-sm shadow-lg transition">
                Masuk Sekarang &rarr;
            </button>
        </form>

        <p class="text-center text-xs text-slate-500 mt-6">
            Belum punya akun? <a href="{{ route('register') }}" class="text-emerald-400 font-bold hover:underline">Daftar Akun Baru</a>
        </p>
    </div>
</body>
</html>
