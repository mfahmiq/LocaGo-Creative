<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Daftar Akun - SIGMA RENTAL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body class="bg-slate-950 text-white font-sans flex items-center justify-center min-h-screen p-4 py-10">

    <div class="w-full max-w-lg bg-slate-900 rounded-3xl border border-slate-800 p-8 shadow-2xl">
        <div class="text-center mb-6">
            <div class="inline-flex items-center justify-center w-12 h-12 bg-emerald-500/10 text-emerald-400 rounded-2xl mb-3 border border-emerald-500/20">
                <span class="material-icons text-2xl">person_add</span>
            </div>
            <h1 class="text-2xl font-black text-white tracking-wide">DAFTAR AKUN CUSTOMER</h1>
            <p class="text-xs text-slate-400 mt-1">Buat akun penyewa baru untuk menikmati reservasi armada SIGMA Rental.</p>
        </div>

        @if ($errors->any())
            <div class="mb-6 p-4 bg-rose-500/10 border border-rose-500/30 rounded-2xl text-rose-400 text-xs space-y-1">
                <div class="font-bold flex items-center">
                    <span class="material-icons text-sm mr-1.5">error</span> Terdapat kesalahan input:
                </div>
                <ul class="list-disc list-inside space-y-0.5 text-[11px] text-rose-300">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('register') }}" class="space-y-4">
            @csrf

            <div>
                <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Nama Lengkap *</label>
                <input type="text" name="name" value="{{ old('name') }}" placeholder="Masukkan nama lengkap" required class="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none">
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Email *</label>
                <input type="email" name="email" value="{{ old('email') }}" placeholder="nama@email.com" required class="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none">
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-bold text-slate-300 uppercase mb-1">No. WhatsApp / HP</label>
                    <input type="text" name="phone" value="{{ old('phone') }}" placeholder="081234567890" class="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Alamat Singkat</label>
                    <input type="text" name="address" value="{{ old('address') }}" placeholder="Kota / Alamat domisili" class="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none">
                </div>
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Password (Minimal 8 Karakter) *</label>
                <input type="password" name="password" placeholder="••••••••" required class="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none">
            </div>

            <div>
                <label class="block text-xs font-bold text-slate-300 uppercase mb-1">Konfirmasi Password *</label>
                <input type="password" name="password_confirmation" placeholder="••••••••" required class="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white focus:ring-2 focus:ring-emerald-500 focus:outline-none">
            </div>

            <button type="submit" class="w-full py-3.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-xl text-sm shadow-lg shadow-emerald-500/10 transition flex items-center justify-center">
                <span class="material-icons text-lg mr-2">how_to_reg</span> Daftar Akun Customer Baru
            </button>
        </form>

        <p class="text-center text-xs text-slate-500 mt-6">
            Sudah punya akun? <a href="{{ route('login') }}" class="text-emerald-400 font-bold hover:underline">Masuk Login</a>
        </p>
    </div>
</body>
</html>
