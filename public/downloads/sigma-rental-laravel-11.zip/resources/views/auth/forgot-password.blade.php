<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Lupa Password - SIGMA RENTAL</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-950 text-white font-sans flex items-center justify-center min-h-screen p-4">
    <div class="w-full max-w-md bg-slate-900 rounded-3xl border border-slate-800 p-8 shadow-2xl space-y-4">
        <h1 class="text-xl font-bold">Lupa Password</h1>
        <p class="text-xs text-slate-400">Masukkan email Anda. Kami akan mengirimkan tautan reset password.</p>
        <form method="POST" action="#" class="space-y-4">
            @csrf
            <div>
                <label class="block text-xs font-bold text-slate-300 mb-1">Email</label>
                <input type="email" name="email" required class="w-full text-xs bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white">
            </div>
            <button type="submit" class="w-full py-3 bg-emerald-500 text-slate-950 font-bold text-xs rounded-xl">Kirim Link Reset</button>
        </form>
        <div class="text-center">
            <a href="{{ route('login') }}" class="text-xs text-emerald-400 hover:underline">&larr; Kembali ke Login</a>
        </div>
    </div>
</body>
</html>
