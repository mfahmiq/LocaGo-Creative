<?php 
header('location:public')
?>