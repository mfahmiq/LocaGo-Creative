<?php

namespace App\Http\Requests\Patient;

use App\Enums\BloodType;
use App\Enums\Citizenship;
use App\Enums\EducationLevel;
use App\Enums\Gender;
use App\Enums\MaritalStatus;
use App\Enums\Religion;
use App\Http\Requests\Concerns\NormalizesWilayahCodes;
use App\Http\Requests\Concerns\ResolvesActorTenant;
use App\Models\Patient;
use App\Rules\WilayahCode;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StorePatientRequest extends FormRequest
{
    use NormalizesWilayahCodes;
    use ResolvesActorTenant;

    public function authorize(): bool
    {
        return $this->user()?->can('create', Patient::class) ?? false;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        $tenantId = $this->actorTenantId();

        return [
            'name' => ['required', 'string', 'max:255'],
            'nik' => [
                'nullable',
                'digits:16',
                Rule::unique('patients', 'nik')->where(fn ($query) => $query->where('tenant_id', $tenantId)),
            ],
            'dob' => ['nullable', 'date', 'before:today'],
            'gender' => ['nullable', Rule::enum(Gender::class)],
            'blood_type' => ['nullable', Rule::enum(BloodType::class)],
            'birth_place' => ['nullable', 'string', 'max:100'],
            'marital_status' => ['nullable', Rule::enum(MaritalStatus::class)],
            'citizenship' => ['nullable', Rule::enum(Citizenship::class)],
            'family_card_number' => ['nullable', 'digits:16'],
            'education' => ['nullable', Rule::enum(EducationLevel::class)],
            'religion' => ['nullable', Rule::enum(Religion::class)],
            'occupation' => ['nullable', 'string', 'max:100'],
            'phone' => ['nullable', 'string', 'max:30'],
            'marketing_consent' => ['sometimes', 'boolean'],
            'address' => ['nullable', 'string', 'max:1000'],
            'address_city' => ['nullable', 'string', 'max:100'],
            'address_postal_code' => ['nullable', 'string', 'max:10'],
            'province_code' => ['nullable', 'string', 'max:10', new WilayahCode('province')],
            'city_code' => ['nullable', 'string', 'max:10', new WilayahCode('city', 'province_code')],
            'district_code' => ['nullable', 'string', 'max:10', new WilayahCode('district', 'city_code')],
            'village_code' => ['nullable', 'string', 'max:20', new WilayahCode('village', 'district_code')],
            'rt' => ['nullable', 'string', 'max:5'],
            'rw' => ['nullable', 'string', 'max:5'],
            'default_payer_id' => [
                'nullable',
                'integer',
                Rule::exists('payers', 'id')->where(fn ($query) => $query->where('tenant_id', $tenantId)),
            ],
            'branch_id' => [
                Rule::requiredIf(fn () => ! $this->user()?->branch_id),
                'nullable',
                'integer',
                Rule::exists('branches', 'id')->where(fn ($query) => $query->where('tenant_id', $tenantId)),
            ],
            'bpjs_number' => ['nullable', 'string', 'max:20'],
        ];
    }

    protected function prepareForValidation(): void
    {
        $nullable = [
            'nik', 'default_payer_id', 'blood_type', 'birth_place', 'marital_status', 'family_card_number',
            'education', 'religion', 'occupation',
            'address', 'address_city', 'address_postal_code',
            'province_code', 'city_code', 'district_code', 'village_code', 'rt', 'rw',
        ];

        $merge = [
            'branch_id' => $this->input('branch_id') ?: $this->user()?->branch_id,
            'marketing_consent' => $this->boolean('marketing_consent'),
            'citizenship' => $this->input('citizenship') ?: Citizenship::Wni->value,
        ];

        foreach ($nullable as $field) {
            $merge[$field] = $this->filled($field) ? $this->input($field) : null;
        }

        $this->merge($this->normalizeWilayahInto($merge));
    }
}
