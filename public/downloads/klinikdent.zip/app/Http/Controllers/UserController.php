<?php

namespace App\Http\Controllers;

use App\Enums\RoleName;
use App\Enums\UserStatus;
use App\Http\Requests\User\ResetPasswordRequest;
use App\Http\Requests\User\StoreUserRequest;
use App\Http\Requests\User\UpdateUserRequest;
use App\Models\Branch;
use App\Models\Tenant;
use App\Models\User;
use App\Support\Impersonation;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Collection;
use Illuminate\View\View;
use Spatie\Permission\Models\Role;
use Yajra\DataTables\Facades\DataTables;

class UserController extends Controller
{
    public function index(): View
    {
        $this->authorize('viewAny', User::class);

        $columns = [
            ['data' => 'DT_RowIndex', 'name' => 'DT_RowIndex', 'title' => 'No', 'orderable' => false, 'searchable' => false, 'className' => 'text-center', 'width' => '60px'],
            ['data' => 'name', 'name' => 'name', 'title' => 'Name'],
            ['data' => 'email', 'name' => 'email', 'title' => 'Email'],
            ['data' => 'role', 'name' => 'roles.name', 'title' => 'Role', 'orderable' => false],
            ['data' => 'status', 'name' => 'status', 'title' => 'Status', 'className' => 'text-center'],
            ['data' => 'created_at', 'name' => 'created_at', 'title' => 'Created At'],
            ['data' => 'action', 'name' => 'action', 'title' => 'Action', 'orderable' => false, 'searchable' => false, 'className' => 'text-center', 'width' => '120px'],
        ];

        if (auth()->user()?->isPlatformAdmin()) {
            array_splice($columns, 3, 0, [
                ['data' => 'tenant', 'name' => 'tenant.name', 'title' => 'Klinik'],
                ['data' => 'branch', 'name' => 'branch.name', 'title' => 'Cabang'],
            ]);
        }

        return view('users.index', compact('columns'));
    }

    public function data(): JsonResponse
    {
        $this->authorize('viewAny', User::class);

        $query = User::query()->with(['roles', 'tenant', 'branch', 'branches']);

        return DataTables::eloquent($query)
            ->addIndexColumn()
            ->addColumn('role', function (User $user) {
                return $user->roles
                    ->pluck('name')
                    ->map(function (string $name) {
                        $label = RoleName::tryFrom($name)?->label() ?? $name;

                        return '<span class="badge badge-soft-primary">'.e($label).'</span>';
                    })
                    ->implode(' ');
            })
            ->addColumn('tenant', fn (User $user) => e($user->tenant?->name ?: '-'))
            ->addColumn('branch', function (User $user) {
                $names = $user->branches->pluck('name');
                if ($names->isEmpty() && $user->branch) {
                    $names = collect([$user->branch->name]);
                }

                return e($names->implode(', ') ?: '-');
            })
            ->editColumn('status', function (User $user) {
                return '<span class="'.$user->status->badgeClass().'">'.e($user->status->label()).'</span>';
            })
            ->editColumn('created_at', fn (User $user) => $user->created_at?->format('d M Y H:i'))
            ->addColumn('action', fn (User $user) => view('users.partials.actions', compact('user'))->render())
            ->filterColumn('role', function ($query, $keyword) {
                $query->whereHas('roles', function ($roleQuery) use ($keyword) {
                    $roleQuery->where('name', 'like', "%{$keyword}%");
                });
            })
            ->rawColumns(['role', 'status', 'action'])
            ->toJson();
    }

    public function create(): View
    {
        $this->authorize('create', User::class);

        return view('users.create', $this->formData());
    }

    public function store(StoreUserRequest $request): RedirectResponse
    {
        $data = $request->validated();
        $branchIds = array_values(array_unique(array_map('intval', $data['branch_ids'] ?? [])));

        $user = User::query()->create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => $data['password'],
            'status' => $data['status'],
            'tenant_id' => $request->resolvedTenantId(),
            'branch_id' => $branchIds[0] ?? null,
        ]);

        $user->syncRoles($data['roles']);
        $user->syncAssignedBranches($branchIds);

        activity_audit('created', $user, [], 'Created user '.$user->name, 'users', [
            'roles' => $data['roles'],
            'branch_ids' => $branchIds,
        ]);

        return redirect()
            ->route('users.index')
            ->with('success', 'User created successfully.');
    }

    public function show(User $user): View
    {
        $this->authorize('view', $user);

        $user->load('roles', 'permissions', 'tenant', 'branch', 'branches');

        return view('users.show', compact('user'));
    }

    public function edit(User $user): View
    {
        $this->authorize('update', $user);

        $user->load('roles', 'branches');

        return view('users.edit', $this->formData($user));
    }

    public function update(UpdateUserRequest $request, User $user): RedirectResponse
    {
        $data = $request->validated();
        $before = activity_snapshot($user);
        $branchIds = array_values(array_unique(array_map('intval', $data['branch_ids'] ?? [])));

        $payload = [
            'name' => $data['name'],
            'email' => $data['email'],
            'status' => $data['status'],
            'tenant_id' => $request->resolvedTenantId(),
            'branch_id' => $branchIds[0] ?? null,
        ];

        if (! empty($data['password'])) {
            $payload['password'] = $data['password'];
        }

        $user->update($payload);
        $user->syncRoles($data['roles']);
        $user->syncAssignedBranches($branchIds);

        activity_audit('updated', $user->fresh(), $before, 'Updated user '.$user->name, 'users', [
            'roles' => $data['roles'],
            'password_changed' => ! empty($data['password']),
            'branch_ids' => $branchIds,
        ]);

        return redirect()
            ->route('users.index')
            ->with('success', 'User updated successfully.');
    }

    public function destroy(User $user): RedirectResponse
    {
        $this->authorize('delete', $user);

        if ($user->id === auth()->id()) {
            return back()->with('error', 'You cannot delete your own account.');
        }

        $before = activity_snapshot($user);

        activity_audit('deleted', $user, $before, 'Deleted user '.$user->name, 'users', [
            'name' => $user->name,
            'email' => $user->email,
        ]);

        $user->delete();

        return redirect()
            ->route('users.index')
            ->with('success', 'User deleted successfully.');
    }

    public function toggleStatus(User $user): RedirectResponse
    {
        $this->authorize('toggleStatus', $user);

        if ($user->id === auth()->id()) {
            return back()->with('error', 'You cannot change your own status.');
        }

        $user->update([
            'status' => $user->status === UserStatus::Active
                ? UserStatus::Inactive
                : UserStatus::Active,
        ]);

        activity_log('status_changed', $user, [
            'status' => $user->status->value,
        ], 'Changed status of '.$user->name.' to '.$user->status->label(), 'users');

        return back()->with('success', 'User status updated successfully.');
    }

    public function resetPassword(ResetPasswordRequest $request, User $user): RedirectResponse
    {
        $user->update([
            'password' => $request->validated('password'),
        ]);

        activity_log('password_reset', $user, [], 'Reset password for '.$user->name, 'users');

        return back()->with('success', 'Password reset successfully.');
    }

    public function impersonate(User $user): RedirectResponse
    {
        $this->authorize('impersonate', $user);

        if ($user->id === auth()->id()) {
            return back()->with('error', 'You cannot impersonate your own account.');
        }

        if (Impersonation::active()) {
            return back()->with('error', 'Leave the current impersonation first.');
        }

        if ($user->isSuperAdmin()) {
            return back()->with('error', 'You cannot impersonate a Super Admin.');
        }

        if (! $user->isActive()) {
            return back()->with('error', 'You cannot impersonate an inactive user.');
        }

        $actor = auth()->user();

        activity_log('impersonated', $user, [
            'actor' => $actor->email,
            'target' => $user->email,
        ], $actor->name.' started impersonating '.$user->name, 'users');

        Impersonation::start($actor, $user);

        return redirect()
            ->route('dashboard')
            ->with('success', 'You are now impersonating '.$user->name.'.');
    }

    public function leaveImpersonate(): RedirectResponse
    {
        if (! Impersonation::active()) {
            return redirect()->route('dashboard');
        }

        $target = auth()->user();
        $impersonator = Impersonation::stop();

        if (! $impersonator) {
            return redirect()
                ->route('login')
                ->with('error', 'Original account was not found. Please sign in again.');
        }

        activity_log(
            'impersonation_stopped',
            $target,
            [
                'actor' => $impersonator->email,
                'target' => $target?->email,
            ],
            $impersonator->name.' stopped impersonating '.$target?->name,
            'users',
            $impersonator
        );

        return redirect()
            ->route('users.index')
            ->with('success', 'Returned to '.$impersonator->name.'.');
    }

    /**
     * @return array<string, mixed>
     */
    protected function formData(?User $user = null): array
    {
        $isPlatform = (bool) auth()->user()?->isPlatformAdmin();

        return [
            'user' => $user,
            'roles' => $this->assignableRoles(),
            'statuses' => UserStatus::cases(),
            'tenants' => $isPlatform ? Tenant::query()->orderBy('name')->get() : collect(),
            'branches' => Branch::query()
                ->with('tenant')
                ->orderBy('name')
                ->get(),
        ];
    }

    /**
     * @return Collection<int, Role>
     */
    protected function assignableRoles()
    {
        $roles = Role::query()->orderBy('name')->get();

        if (! auth()->user()?->isPlatformAdmin()) {
            return $roles->reject(fn (Role $role) => $role->name === RoleName::SuperAdminSaas->value);
        }

        return $roles;
    }
}
