<?php

namespace App\Support\Access;

use App\Enums\MenuScope;
use App\Enums\MenuType;
use App\Enums\RoleName;

final class MenuCatalog
{
    /**
     * @return array<string, list<array<string, mixed>>>
     */
    public static function trees(): array
    {
        return [
            RoleName::SuperAdminSaas->value => self::superAdminSaas(),
            RoleName::Owner->value => self::owner(),
            RoleName::Manager->value => self::manager(),
            RoleName::Registration->value => self::registration(),
            RoleName::ClinicOps->value => self::clinicOps(),
            RoleName::Dentist->value => self::dentist(),
            RoleName::DentalAssistant->value => self::dentalAssistant(),
            RoleName::Nurse->value => self::nurse(),
            RoleName::Pharmacy->value => self::pharmacy(),
            RoleName::Cashier->value => self::cashier(),
            RoleName::Finance->value => self::finance(),
            RoleName::Auditor->value => self::auditor(),
        ];
    }

    public static function scopeFor(string $role): MenuScope
    {
        return $role === RoleName::SuperAdminSaas->value
            ? MenuScope::Saas
            : MenuScope::Tenant;
    }

    /**
     * Unique placeholder routes derived from the menu trees.
     *
     * @return list<array{name: string, uri: string, permission: string, scope: string}>
     */
    public static function placeholderRoutes(): array
    {
        $skip = [
            'dashboard',
            'users.index',
            'roles.index',
            'roles.show',
            'menus.index',
            'settings.index',
            'settings.clinic',
            'logs.index',
            'medical-letters.index',
            'subscription.index',
            'subscription.invoices',
            'addons.index',
            'saas.addons.index',
            'saas.addon-subscriptions.index',
            'integrations.index',
            'integrations.satusehat',
            'integrations.bpjs',
            'whatsapp.dashboard',
            'whatsapp.balance',
            'whatsapp.reminders',
            'whatsapp.promotions.index',
            'whatsapp.templates.index',
            'whatsapp.logs.index',
            'whatsapp.settings',
            'saas.tenants.index',
            'saas.tenants.create',
            'saas.tenants.show',
            'saas.tenants.status',
            'saas.users.activity',
            'saas.packages.index',
            'saas.subscriptions.index',
            'saas.invoices.index',
            'saas.system.integrations',
            'saas.system.audit',
            'saas.payment-gateway.index',
            'cms.dashboard',
            'cms.posts.index',
            'cms.posts.create',
            'cms.categories.index',
            'cms.tags.index',
            'cms.authors.index',
            'cms.media.index',
            'cms.plans.index',
            'cms.keywords.index',
            'cms.seo-settings.edit',
            'cms.redirects.index',
            'branches.index',
            'branches.create',
            'management.clinic',
            'management.services.index',
            'management.procedures.index',
            'management.tariffs.index',
            'management.medicines.index',
            'management.payers.index',
            'management.rooms.index',
            'pharmacy.medicines.index',
            'pharmacy.index',
            'pharmacy.prescriptions.processing',
            'pharmacy.prescriptions.completed',
            'pharmacy.prescriptions.history',
            'pharmacy.stock.index',
            'pharmacy.stock.batches',
            'pharmacy.stock.expired',
            'pharmacy.stock.adjustments',
            'pharmacy.stock.card',
            'pharmacy.stock.opname',
            'pharmacy.stock.returns',
            'pharmacy.lab.index',
            'archive.index',
            'pharmacy.purchases.suppliers',
            'pharmacy.purchases.orders',
            'pharmacy.purchases.receipts',
            'pharmacy.reports',
            'pharmacy.reports.stock',
            'pharmacy.reports.outgoing',
            'pharmacy.reports.incoming',
            'pharmacy.reports.expired',
            'pharmacy.transactions',
            'reports.pharmacy',
            'billing.index',
            'billing.invoices',
            'billing.invoices.today',
            'billing.payments',
            'billing.receivables',
            'billing.history',
            'cashier.shifts.open',
            'cashier.shifts.transactions',
            'cashier.shifts.close',
            'cashier.reports',
            'finance.index',
            'finance.revenue.daily',
            'finance.revenue.monthly',
            'finance.revenue.doctors',
            'finance.expenses',
            'finance.expenses.categories',
            'finance.expenses.suppliers',
            'finance.sharing-fees.rules.index',
            'finance.sharing-fees.settlements.index',
            'finance.sharing-fees.reports.doctors',
            'finance.doctor-fee-waivers.settings.index',
            'finance.doctor-fee-waivers.logs.index',
            'finance.receivables',
            'finance.payables',
            'finance.cash-bank',
            'finance.reports.expenses',
            'finance.reports.cashflow',
            'finance.reports.receivables',
            'finance.reports.profit-loss',
            'finance.reports.revenue',
            'reports.index',
            'reports.visits',
            'reports.revenue',
            'reports.procedures',
            'reports.patients',
            'reports.personal',
            'reports.operational',
            'reports.medical',
            'reports.finance',
            'doctors.index',
            'doctors.schedule',
            'doctors.schedule.today',
            'doctors.schedule.mine',
            'registration.payers.general',
            'registration.payers.bpjs',
            'registration.payers.insurance',
            'registration.payers.corporate',
            'registration.payers.membership',
            'registration.index',
            'registration.new',
            'registration.patients',
            'registration.visits',
            'registration.visits.today',
            'registration.history',
            'patients.history',
            'queue.index',
            'queue.today',
            'queue.mine',
            'queue.waiting',
            'queue.called',
            'queue.monitor',
            'queue.loket',
            'medical-record.index',
            'odontogram.index',
            'diagnosis.index',
            'procedures.index',
            'prescriptions.index',
            'referrals.index',
            'examinations.index',
            'examinations.initial',
            'examinations.anamnesis',
            'examinations.vitals',
            'examinations.notes',
            'pharmacy.prescriptions.incoming',
        ];

        $routes = [];

        foreach (self::trees() as $role => $items) {
            self::collectRoutes($items, $routes, $skip, self::scopeFor($role)->value);
        }

        return array_values($routes);
    }

    /**
     * @param  list<array<string, mixed>>  $items
     * @return list<string>
     */
    public static function titles(array $items): array
    {
        $titles = [];

        foreach ($items as $item) {
            $titles[] = $item['title'];

            foreach (self::titles($item['children'] ?? []) as $childTitle) {
                $titles[] = $childTitle;
            }
        }

        return $titles;
    }

    /**
     * @return list<array<string, mixed>>
     */
    protected static function superAdminSaas(): array
    {
        return [
            self::item('saas.dashboard', 'Dashboard SaaS', 'bx bx-home-circle', 'dashboard', 'dashboard.view', 'Ringkasan platform SaaS klinik gigi.'),
            self::item('saas.tenants', 'Tenant / Klinik', 'bx bx-buildings', null, 'tenant.view', 'Manajemen tenant klinik.', [
                self::item('saas.tenants.index', 'Semua Klinik', 'bx bx-list-ul', 'saas.tenants.index', 'tenant.view', 'Daftar seluruh klinik pada platform.'),
                self::item('saas.tenants.create', 'Klinik Baru', 'bx bx-plus', 'saas.tenants.create', 'tenant.create', 'Pendaftaran tenant klinik baru.'),
                self::item('saas.tenants.show', 'Detail Klinik', 'bx bx-info-circle', 'saas.tenants.index', 'tenant.view', 'Informasi detail tenant klinik.'),
                self::item('saas.tenants.status', 'Status Klinik', 'bx bx-toggle-left', 'saas.tenants.index', 'tenant.manage', 'Status aktif dan langganan klinik.'),
            ]),
            self::item('saas.users', 'Users', 'bx bx-user', null, 'users.view', 'Manajemen pengguna platform.', [
                self::item('saas.users.index', 'Semua User', 'bx bx-group', 'users.index', 'users.view', 'Daftar pengguna platform.'),
                self::item('saas.users.activity', 'Aktivitas User', 'bx bx-history', 'saas.users.activity', 'saas.activity.view', 'Aktivitas pengguna platform.'),
            ]),
            self::item('saas.subscription', 'Subscription / Paket', 'bx bx-package', null, 'subscription.view', 'Paket dan langganan SaaS.', [
                self::item('saas.packages', 'Paket', 'bx bx-box', 'saas.packages.index', 'package.view', 'Master paket langganan.'),
                self::item('saas.subscriptions', 'Langganan', 'bx bx-calendar', 'saas.subscriptions.index', 'subscription.view', 'Langganan tenant.'),
                self::item('saas.invoices', 'Invoice', 'bx bx-receipt', 'saas.invoices.index', 'invoice.view', 'Invoice langganan platform.'),
            ]),
            self::item('saas.addons', 'Add-ons', 'bx bx-puzzle', null, 'addon.manage', 'Katalog dan aktivasi Add-on.', [
                self::item('saas.addons.catalog', 'Katalog', 'bx bx-list-ul', 'saas.addons.index', 'addon.manage', 'Master Add-on.'),
                self::item('saas.addons.subscriptions', 'Aktivasi Tenant', 'bx bx-check-shield', 'saas.addon-subscriptions.index', 'addon.manage', 'Status Add-on per klinik.'),
            ]),
            self::item('saas.system', 'System', 'bx bx-server', null, 'system.view', 'Konfigurasi sistem platform.', [
                self::item('saas.system.master', 'Master Global', 'bx bx-data', 'menus.index', 'menus.view', 'Master data dan navigasi global.'),
                self::item('saas.system.integrations', 'Integrasi', 'bx bx-plug', 'saas.system.integrations', 'saas.integration.view', 'Integrasi tingkat platform.'),
                self::item('saas.system.logs', 'System Logs', 'bx bx-file', 'logs.index', 'logs.view', 'Log sistem aplikasi.'),
                self::item('saas.system.audit', 'Audit Logs', 'bx bx-shield-quarter', 'saas.system.audit', 'saas.audit.view', 'Audit log platform.'),
            ]),
            self::item('saas.support', 'Support', 'bx bx-headphone', null, 'support.view', 'Dukungan platform.', [
                self::item('saas.support.tickets', 'Ticket', 'bx bx-comment-detail', 'saas.support.tickets', 'ticket.view', 'Tiket bantuan tenant.'),
                self::item('saas.support.activity', 'Activity', 'bx bx-pulse', 'saas.support.activity', 'support.view', 'Aktivitas dukungan.'),
            ]),
            self::item('saas.settings', 'Settings', 'bx bx-cog', null, 'platform.setting.view', 'Pengaturan platform.', [
                self::item('saas.settings.platform', 'Platform Settings', 'bx bx-slider-alt', 'settings.index', 'settings.update', 'Pengaturan global platform SaaS.'),
                self::item('saas.settings.payment-gateway', 'Payment Gateway', 'bx bx-money', 'saas.payment-gateway.index', 'payment_gateway.view', 'Konfigurasi Midtrans untuk pembayaran paket.'),
            ]),
            self::item('saas.cms', 'SEO & Content', 'bx bx-news', null, 'cms.view', 'Manajemen blog dan SEO platform.', [
                self::item('saas.cms.dashboard', 'Dashboard SEO', 'bx bx-bar-chart', 'cms.dashboard', 'cms.view', 'Ringkasan konten dan konversi blog.'),
                self::item('saas.cms.posts', 'Semua Artikel', 'bx bx-file', 'cms.posts.index', 'cms.view', 'Daftar artikel blog.'),
                self::item('saas.cms.posts.create', 'Tambah Artikel', 'bx bx-plus', 'cms.posts.create', 'cms.manage', 'Buat artikel baru.'),
                self::item('saas.cms.categories', 'Kategori', 'bx bx-folder', 'cms.categories.index', 'cms.view', 'Kategori artikel.'),
                self::item('saas.cms.tags', 'Tag', 'bx bx-purchase-tag', 'cms.tags.index', 'cms.view', 'Tag artikel.'),
                self::item('saas.cms.authors', 'Penulis', 'bx bx-user-voice', 'cms.authors.index', 'cms.view', 'Manajemen penulis.'),
                self::item('saas.cms.media', 'Media Library', 'bx bx-image', 'cms.media.index', 'cms.view', 'Pustaka media publik.'),
                self::item('saas.cms.plans', 'Content Planning', 'bx bx-calendar-edit', 'cms.plans.index', 'cms.view', 'Kalender editorial.'),
                self::item('saas.cms.keywords', 'Keyword Strategy', 'bx bx-key', 'cms.keywords.index', 'cms.view', 'Cluster keyword dan pillar.'),
                self::item('saas.cms.seo', 'SEO Settings', 'bx bx-globe', 'cms.seo-settings.edit', 'seo.manage', 'Metadata dan verifikasi global.'),
                self::item('saas.cms.redirects', 'Redirect Manager', 'bx bx-git-compare', 'cms.redirects.index', 'seo.manage', 'Redirect 301/302.'),
            ]),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    protected static function owner(): array
    {
        return [
            self::item('owner.dashboard', 'Dashboard', 'bx bx-home-circle', 'dashboard', 'dashboard.view', 'Ringkasan klinik.'),
            self::heading('owner.group.operational', 'Operasional', [
                self::item('owner.registration', 'Pendaftaran', 'bx bx-user-plus', 'registration.index', 'registration.view', 'Manajemen pendaftaran pasien.'),
                self::item('owner.examination', 'Pemeriksaan', 'bx bx-search-alt', 'examinations.initial', 'examination.view', 'Pemeriksaan pasien.'),
                self::item('owner.medical-record', 'Rekam Medis', 'bx bx-folder-open', 'medical-record.index', 'medical_record.view', 'Rekam medis pasien.'),
                self::item('owner.medical-letters', 'Surat Keterangan', 'bx bx-envelope', 'medical-letters.index', 'medical_record.view', 'Surat keterangan medis pasien.'),
                self::item('owner.pharmacy', 'Farmasi', 'bx bx-package', 'pharmacy.index', 'pharmacy.view', 'Manajemen farmasi klinik.'),
                self::item('owner.billing', 'Billing & Kasir', 'bx bx-credit-card', 'billing.index', 'billing.view', 'Tagihan dan kasir klinik.'),
            ]),
            self::heading('owner.group.medical-staff', 'Tenaga Medis', [
                self::item('owner.doctors', 'Dokter & Tenaga Medis', 'bx bx-user', 'doctors.index', 'doctor.view', 'Dokter dan tenaga medis klinik.'),
            ]),
            self::heading('owner.group.finance', 'Keuangan', [
                self::item('owner.finance', 'Dashboard Keuangan', 'bx bx-wallet', 'finance.index', 'finance.view', 'Keuangan klinik.'),
                self::item('owner.finance.sharing-fees', 'Sharing Fee', 'bx bx-share-alt', null, 'sharing_fee.view', 'Bagi hasil jasa dokter.', [
                    self::item('owner.finance.sharing-fees.rules', 'Aturan Fee', 'bx bx-slider-alt', 'finance.sharing-fees.rules.index', 'sharing_fee.view', 'Konfigurasi aturan sharing fee.'),
                    self::item('owner.finance.sharing-fees.settlements', 'Settlement', 'bx bx-list-check', 'finance.sharing-fees.settlements.index', 'sharing_fee.view', 'Settlement sharing fee.'),
                    self::item('owner.finance.sharing-fees.reports', 'Laporan Fee', 'bx bx-bar-chart', 'finance.sharing-fees.reports.doctors', 'sharing_fee.view', 'Laporan sharing fee per dokter.'),
                ]),
                self::item('owner.finance.doctor-fee-waivers', 'Pembebasan Jasa Dokter', 'bx bx-gift', null, 'finance.view', 'Kebijakan dan histori pembebasan jasa dokter.', [
                    self::item('owner.finance.doctor-fee-waivers.settings', 'Kebijakan Dokter', 'bx bx-slider-alt', 'finance.doctor-fee-waivers.settings.index', 'procedure.manage_doctor_fee_waiver_policy', 'Dokter yang boleh membebaskan jasa.'),
                    self::item('owner.finance.doctor-fee-waivers.logs', 'Histori Pembebasan', 'bx bx-history', 'finance.doctor-fee-waivers.logs.index', 'finance.view', 'Riwayat pembebasan dan diskon tindakan.'),
                ]),
                self::item('owner.reports', 'Laporan', 'bx bx-bar-chart-alt-2', 'reports.index', 'report.view', 'Laporan klinik.'),
            ]),
            self::heading('owner.group.master', 'Master Data', [
                self::item('owner.master.clinic', 'Klinik', 'bx bx-building-house', 'management.clinic', 'clinic.view', 'Ringkasan master data klinik.'),
                self::item('owner.master.services', 'Layanan', 'bx bx-list-check', 'management.services.index', 'service.view', 'Master layanan klinik.'),
                self::item('owner.master.procedures', 'Tindakan', 'bx bx-first-aid', 'management.procedures.index', 'procedure.view', 'Master tindakan.'),
                self::item('owner.master.tariffs', 'Tarif', 'bx bx-purchase-tag', 'management.tariffs.index', 'tariff.view', 'Master tarif layanan.'),
                self::item('owner.master.medicines', 'Obat', 'bx bx-plus-medical', 'management.medicines.index', 'medicine.view', 'Master obat.'),
                self::item('owner.master.payers', 'Penjamin', 'bx bx-id-card', 'management.payers.index', 'payer.view', 'Master penjamin.'),
                self::item('owner.master.rooms', 'Ruangan', 'bx bx-home', 'management.rooms.index', 'room.view', 'Ruangan pelayanan per cabang.'),
            ]),
            self::heading('owner.group.management', 'Manajemen Klinik', [
                self::item('owner.branches', 'Cabang', 'bx bx-git-branch', 'branches.index', 'branch.view', 'Cabang klinik.'),
                self::item('owner.users', 'Users & Roles', 'bx bx-group', null, 'users.view', 'Pengguna dan peran klinik.', [
                    self::item('owner.users.index', 'Users', 'bx bx-user', 'users.index', 'users.view', 'Pengguna tenant klinik.'),
                    self::item('owner.roles.index', 'Roles', 'bx bx-shield-quarter', 'roles.index', 'roles.view', 'Peran dan permission klinik.'),
                ]),
                self::item('owner.settings', 'Pengaturan Klinik', 'bx bx-cog', 'settings.clinic', 'setting.view', 'Pengaturan operasional klinik.'),
            ]),
            self::heading('owner.group.subscription', 'Langganan', [
                self::item('owner.subscription', 'Paket Langganan', 'bx bx-package', 'subscription.index', 'plan.view', 'Paket langganan klinik yang sedang digunakan.'),
                self::item('owner.subscription.invoices', 'Tagihan Paket', 'bx bx-receipt', 'subscription.invoices', 'plan.view', 'Tagihan dan pembayaran paket langganan.'),
            ]),
            self::heading('owner.group.addons', 'Add-ons', [
                self::item('owner.addons', 'Marketplace', 'bx bx-store', 'addons.index', 'addon.view', 'Aktifkan Add-on klinik.'),
            ]),
            self::heading('owner.group.integrations', 'Integrasi', [
                self::item('owner.satusehat', 'SATUSEHAT', 'bx bx-cloud', 'integrations.satusehat', 'satusehat.view', 'Modul SATUSEHAT klinik ini.'),
                self::item('owner.bpjs', 'BPJS VClaim', 'bx bx-id-card', 'integrations.bpjs', 'bpjs.view', 'Modul BPJS VClaim klinik ini.'),
            ]),
            self::heading('owner.group.whatsapp', 'WhatsApp Otomatis', [
                self::item('owner.whatsapp.dashboard', 'Dashboard', 'bx bxl-whatsapp', 'whatsapp.dashboard', 'whatsapp.view', 'Ringkasan pengiriman WhatsApp otomatis.'),
                self::item('owner.whatsapp.balance', 'Saldo', 'bx bx-wallet', 'whatsapp.balance', 'whatsapp.view', 'Saldo WhatsCRM dan isi ulang via payment gateway.'),
                self::item('owner.whatsapp.reminders', 'Pengingat Jadwal', 'bx bx-time-five', 'whatsapp.reminders', 'whatsapp.automation.view', 'Otomasi pengingat kunjungan pasien.'),
                self::item('owner.whatsapp.promotions', 'Promosi', 'bx bx-calendar-event', 'whatsapp.promotions.index', 'whatsapp.promotions.view', 'Promo WhatsApp untuk pasien yang menyetujui.'),
                self::item('owner.whatsapp.templates', 'Template Pesan', 'bx bx-message', 'whatsapp.templates.index', 'whatsapp.templates.view', 'Konfigurasi template WhatsApp klinik.'),
                self::item('owner.whatsapp.logs', 'Riwayat Pesan', 'bx bx-history', 'whatsapp.logs.index', 'whatsapp.logs.view', 'Log pengiriman WhatsApp.'),
                self::item('owner.whatsapp.settings', 'Pengaturan WhatsApp', 'bx bx-cog', 'whatsapp.settings', 'whatsapp.settings.manage', 'Kredensial WhatsCRM per klinik.'),
            ]),
            self::heading('owner.group.system', 'Sistem', [
                self::item('owner.audit', 'Audit Log', 'bx bx-shield', 'logs.index', 'logs.view', 'Audit log klinik.'),
                self::item('owner.archive', 'Arsip Praktik', 'bx bx-download', 'archive.index', 'logs.view', 'Unduh arsip data praktik.'),
            ]),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    protected static function manager(): array
    {
        return [
            self::item('manager.dashboard', 'Dashboard', 'bx bx-home-circle', 'dashboard', 'dashboard.view', 'Ringkasan operasional klinik.'),
            self::item('manager.examination', 'Pemeriksaan', 'bx bx-search-alt', 'examinations.initial', 'examination.view', 'Pemeriksaan pasien.'),
            self::item('manager.registration', 'Pendaftaran', 'bx bx-user-plus', null, 'registration.view', 'Operasional pendaftaran.', [
                self::item('manager.registration.patients', 'Pasien', 'bx bx-user', 'registration.patients', 'patient.view', 'Manajemen data pasien klinik.'),
            ]),
            self::item('manager.doctors', 'Dokter & Jadwal', 'bx bx-user', null, 'doctor.view', 'Dokter dan jadwal praktik.', [
                self::item('manager.doctors.index', 'Dokter', 'bx bx-user-circle', 'doctors.index', 'doctor.view', 'Daftar dokter klinik.'),
                self::item('manager.doctors.schedule', 'Jadwal Dokter', 'bx bx-calendar', 'doctors.schedule', 'schedule.view', 'Jadwal praktik dokter.'),
                self::item('manager.doctors.rooms', 'Ruangan', 'bx bx-home', 'management.rooms.index', 'room.view', 'Ruangan pelayanan.'),
            ]),
            self::item('manager.pharmacy', 'Farmasi', 'bx bx-package', null, 'pharmacy.view', 'Operasional farmasi.', [
                self::item('manager.pharmacy.stock', 'Stok', 'bx bx-package', 'pharmacy.stock.index', 'stock.view', 'Stok obat klinik.'),
                self::item('manager.pharmacy.medicines', 'Obat', 'bx bx-plus-medical', 'pharmacy.medicines.index', 'medicine.view', 'Master obat klinik.'),
                self::item('manager.pharmacy.transactions', 'Transaksi', 'bx bx-transfer', 'pharmacy.transactions', 'pharmacy.view', 'Transaksi farmasi.'),
            ]),
            self::item('manager.billing', 'Billing', 'bx bx-credit-card', null, 'billing.view', 'Tagihan dan pembayaran.', [
                self::item('manager.billing.invoices', 'Tagihan', 'bx bx-receipt', 'billing.invoices', 'billing.view', 'Tagihan pasien.'),
                self::item('manager.billing.payments', 'Pembayaran', 'bx bx-money', 'billing.payments', 'payment.view', 'Pembayaran pasien.'),
                self::item('manager.billing.receivables', 'Piutang', 'bx bx-wallet', 'billing.receivables', 'receivable.view', 'Piutang pasien.'),
            ]),
            self::item('manager.finance', 'Keuangan', 'bx bx-wallet', null, 'finance.view', 'Keuangan klinik.', [
                self::item('manager.finance.dashboard', 'Dashboard Keuangan', 'bx bx-home-circle', 'finance.index', 'finance.view', 'Ringkasan keuangan klinik.'),
                self::item('manager.finance.sharing-fees', 'Sharing Fee', 'bx bx-share-alt', null, 'sharing_fee.view', 'Bagi hasil jasa dokter.', [
                    self::item('manager.finance.sharing-fees.rules', 'Aturan Fee', 'bx bx-slider-alt', 'finance.sharing-fees.rules.index', 'sharing_fee.view', 'Konfigurasi aturan sharing fee.'),
                    self::item('manager.finance.sharing-fees.settlements', 'Settlement', 'bx bx-list-check', 'finance.sharing-fees.settlements.index', 'sharing_fee.view', 'Settlement sharing fee.'),
                    self::item('manager.finance.sharing-fees.reports', 'Laporan Fee', 'bx bx-bar-chart', 'finance.sharing-fees.reports.doctors', 'sharing_fee.view', 'Laporan sharing fee per dokter.'),
                ]),
                self::item('manager.finance.doctor-fee-waivers', 'Pembebasan Jasa Dokter', 'bx bx-gift', null, 'finance.view', 'Kebijakan dan histori pembebasan jasa dokter.', [
                    self::item('manager.finance.doctor-fee-waivers.settings', 'Kebijakan Dokter', 'bx bx-slider-alt', 'finance.doctor-fee-waivers.settings.index', 'procedure.manage_doctor_fee_waiver_policy', 'Dokter yang boleh membebaskan jasa.'),
                    self::item('manager.finance.doctor-fee-waivers.logs', 'Histori Pembebasan', 'bx bx-history', 'finance.doctor-fee-waivers.logs.index', 'finance.view', 'Riwayat pembebasan dan diskon tindakan.'),
                ]),
            ]),
            self::item('manager.reports', 'Laporan', 'bx bx-bar-chart-alt-2', null, 'report.view', 'Laporan operasional klinik.', [
                self::item('manager.reports.visits', 'Kunjungan', 'bx bx-calendar-check', 'reports.visits', 'report.view', 'Laporan kunjungan.'),
                self::item('manager.reports.revenue', 'Pendapatan', 'bx bx-dollar', 'reports.revenue', 'report.view', 'Laporan pendapatan.'),
                self::item('manager.reports.procedures', 'Tindakan', 'bx bx-first-aid', 'reports.procedures', 'report.view', 'Laporan tindakan.'),
                self::item('manager.reports.patients', 'Pasien', 'bx bx-user', 'reports.patients', 'report.view', 'Laporan pasien.'),
                self::item('manager.reports.pharmacy', 'Farmasi', 'bx bx-package', 'pharmacy.reports', 'report.view', 'Laporan farmasi.'),
            ]),
            self::item('manager.branches', 'Cabang', 'bx bx-git-branch', 'branches.index', 'branch.view', 'Cabang klinik.'),
            self::item('manager.master', 'Master Data', 'bx bx-data', null, 'clinic.view', 'Master data klinik.', [
                self::item('manager.master.clinic', 'Klinik', 'bx bx-building-house', 'management.clinic', 'clinic.view', 'Data klinik / poli.'),
                self::item('manager.master.services', 'Layanan', 'bx bx-list-check', 'management.services.index', 'service.view', 'Master layanan klinik.'),
                self::item('manager.master.procedures', 'Tindakan', 'bx bx-first-aid', 'management.procedures.index', 'procedure.view', 'Master tindakan.'),
                self::item('manager.master.tariffs', 'Tarif', 'bx bx-purchase-tag', 'management.tariffs.index', 'tariff.view', 'Master tarif layanan.'),
                self::item('manager.master.medicines', 'Obat', 'bx bx-plus-medical', 'management.medicines.index', 'medicine.view', 'Master obat.'),
                self::item('manager.master.payers', 'Penjamin', 'bx bx-id-card', 'management.payers.index', 'payer.view', 'Master penjamin.'),
            ]),
            self::item('manager.users', 'Users & Roles', 'bx bx-group', null, 'users.view', 'Pengguna dan peran klinik.', [
                self::item('manager.users.index', 'Users', 'bx bx-user', 'users.index', 'users.view', 'Pengguna klinik.'),
                self::item('manager.roles.index', 'Roles', 'bx bx-shield-quarter', 'roles.index', 'roles.view', 'Peran klinik.'),
            ]),
            self::item('manager.satusehat', 'SATUSEHAT', 'bx bx-cloud', 'integrations.satusehat', 'satusehat.view', 'Modul SATUSEHAT klinik ini.'),
            self::item('manager.bpjs', 'BPJS VClaim', 'bx bx-id-card', 'integrations.bpjs', 'bpjs.view', 'Modul BPJS VClaim klinik ini.'),
            self::item('manager.audit', 'Audit Log', 'bx bx-shield', 'logs.index', 'logs.view', 'Audit log klinik.'),
            self::item('manager.settings', 'Pengaturan Klinik', 'bx bx-cog', 'settings.clinic', 'setting.view', 'Pengaturan operasional klinik.'),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    protected static function registration(): array
    {
        return [
            self::item('registration.dashboard', 'Dashboard Pendaftaran', 'bx bx-home-circle', 'dashboard', 'dashboard.view', 'Ringkasan kerja pendaftaran.'),
            self::item('registration.examination', 'Pemeriksaan', 'bx bx-search-alt', 'examinations.initial', 'examination.view', 'Pemeriksaan pasien.'),
            self::item('registration.group', 'Pendaftaran', 'bx bx-user-plus', null, 'registration.view', 'Proses pendaftaran pasien.', [
                self::item('registration.new', 'Pendaftaran Baru', 'bx bx-plus', 'registration.new', 'registration.create', 'Form pendaftaran pasien baru.'),
                self::item('registration.patients', 'Pasien', 'bx bx-user', 'registration.patients', 'patient.view', 'Manajemen data pasien klinik.'),
            ]),
            self::item('registration.schedule', 'Jadwal Dokter', 'bx bx-calendar', null, 'schedule.view', 'Jadwal dokter hari ini.', [
                self::item('registration.schedule.today', 'Jadwal Hari Ini', 'bx bx-calendar-event', 'doctors.schedule.today', 'schedule.view', 'Jadwal praktik dokter hari ini.'),
            ]),
            self::item('registration.payers', 'Penjamin', 'bx bx-id-card', null, 'payer.view', 'Penjamin pembiayaan pasien.', [
                self::item('registration.payers.general', 'Umum', 'bx bx-user', 'registration.payers.general', 'payer.view', 'Penjamin umum.'),
                self::item('registration.payers.bpjs', 'BPJS', 'bx bx-card', 'registration.payers.bpjs', 'payer.view', 'Penjamin BPJS.'),
                self::item('registration.payers.insurance', 'Asuransi', 'bx bx-shield-plus', 'registration.payers.insurance', 'payer.view', 'Penjamin asuransi.'),
                self::item('registration.payers.corporate', 'Corporate', 'bx bx-buildings', 'registration.payers.corporate', 'payer.view', 'Penjamin perusahaan.'),
                self::item('registration.payers.membership', 'Membership', 'bx bx-star', 'registration.payers.membership', 'payer.view', 'Penjamin membership.'),
            ]),
            self::item('registration.bpjs.vclaim', 'Cek BPJS', 'bx bx-check-shield', 'integrations.bpjs', 'bpjs.view', 'Cek kepesertaan BPJS klinik ini.'),
        ];
    }

    /**
     * Sidebar alur kerja untuk Admin Operasional Klinik (pendaftaran–antrean–farmasi–kasir).
     *
     * @return list<array<string, mixed>>
     */
    protected static function clinicOps(): array
    {
        return [
            self::heading('ops.group.dashboard', 'Dashboard Operasional', [
                self::item('ops.dashboard', 'Dashboard Operasional', 'bx bx-home-circle', 'dashboard', 'dashboard.view', 'Pusat tindak lanjut operasional hari ini.'),
            ]),
            self::heading('ops.group.registration', 'Pasien & Pendaftaran', [
                self::item('ops.registration.new', 'Pendaftaran Baru', 'bx bx-plus', 'registration.new', 'registration.create', 'Daftarkan kunjungan pasien.'),
                self::item('ops.registration.patients', 'Pasien', 'bx bx-user', 'registration.patients', 'patient.view', 'Data pasien klinik.'),
                self::item('ops.examination', 'Pemeriksaan', 'bx bx-search-alt', 'examinations.initial', 'examination.view', 'Worklist pemeriksaan pasien.'),
            ]),
            self::heading('ops.group.pharmacy', 'Farmasi & Resep', [
                self::item('ops.pharmacy.dashboard', 'Dashboard Farmasi', 'bx bx-package', 'pharmacy.index', 'pharmacy.view', 'Ringkasan farmasi.'),
                self::item('ops.pharmacy.incoming', 'Resep Masuk', 'bx bx-log-in-circle', 'pharmacy.prescriptions.incoming', 'prescription.view', 'Resep menunggu proses.'),
                self::item('ops.pharmacy.processing', 'Diproses', 'bx bx-loader', 'pharmacy.prescriptions.processing', 'prescription.update', 'Resep sedang diproses.'),
                self::item('ops.pharmacy.completed', 'Selesai', 'bx bx-check-circle', 'pharmacy.prescriptions.completed', 'prescription.view', 'Resep sudah diserahkan.'),
                self::item('ops.pharmacy.stock', 'Stok Obat', 'bx bx-package', 'pharmacy.stock.index', 'stock.view', 'Stok obat cabang.'),
            ]),
            self::heading('ops.group.billing', 'Kasir & Pembayaran', [
                self::item('ops.billing.dashboard', 'Dashboard Kasir', 'bx bx-credit-card', 'billing.index', 'billing.view', 'Ringkasan tagihan dan kasir.'),
                self::item('ops.billing.invoices.today', 'Tagihan Hari Ini', 'bx bx-receipt', 'billing.invoices.today', 'billing.view', 'Tagihan pasien hari ini.'),
                self::item('ops.billing.payments', 'Pembayaran', 'bx bx-money', 'billing.payments', 'payment.view', 'Penerimaan pembayaran.'),
                self::item('ops.billing.receivables', 'Piutang', 'bx bx-wallet', 'billing.receivables', 'receivable.view', 'Piutang pasien.'),
                self::item('ops.cashier.shifts', 'Shift Kasir', 'bx bx-time-five', 'cashier.shifts.open', 'cash_shift.view', 'Buka atau tutup shift kasir.'),
            ]),
            self::heading('ops.group.reports', 'Laporan Operasional', [
                self::item('ops.reports.index', 'Laporan Klinik', 'bx bx-bar-chart-alt-2', 'reports.index', 'report.view', 'Laporan operasional klinik.'),
                self::item('ops.pharmacy.reports', 'Laporan Farmasi', 'bx bx-package', 'pharmacy.reports', 'report.view', 'Laporan stok dan obat.'),
                self::item('ops.cashier.reports', 'Laporan Kasir', 'bx bx-file', 'cashier.reports', 'report.view', 'Laporan transaksi kasir.'),
            ]),
            self::heading('ops.group.other', 'Lainnya', [
                self::item('ops.schedule.today', 'Jadwal Dokter', 'bx bx-calendar', 'doctors.schedule.today', 'schedule.view', 'Jadwal praktik hari ini.'),
                self::item('ops.payers', 'Penjamin', 'bx bx-id-card', 'management.payers.index', 'payer.view', 'Master penjamin.'),
                self::item('ops.bpjs', 'Cek BPJS', 'bx bx-check-shield', 'integrations.bpjs', 'bpjs.view', 'Cek kepesertaan BPJS.'),
            ]),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    protected static function dentist(): array
    {
        return [
            self::heading('dentist.group.dashboard', 'Dashboard', [
                self::item('dentist.dashboard', 'Dashboard Dokter', 'bx bx-home-circle', 'dashboard', 'dashboard.view', 'Ringkasan pelayanan dokter.'),
            ]),
            self::heading('dentist.group.operational', 'Operasional', [
                self::item('dentist.care.examination', 'Pemeriksaan', 'bx bx-search-alt', 'examinations.initial', 'examination.view', 'Pemeriksaan pasien.'),
            ]),
            self::heading('dentist.group.care', 'Pelayanan', [
                self::item('dentist.medical-letters', 'Surat Keterangan', 'bx bx-envelope', 'medical-letters.index', 'medical_record.view', 'Surat keterangan medis pasien.'),
                self::item('dentist.history', 'Riwayat Pasien', 'bx bx-history', 'patients.history', 'patient_history.view', 'Riwayat kunjungan dan rekam medis pasien.'),
            ]),
            self::heading('dentist.group.other', 'Lainnya', [
                self::item('dentist.schedule', 'Jadwal Saya', 'bx bx-calendar', 'doctors.schedule.mine', 'schedule.view', 'Jadwal praktik dokter yang login.'),
                self::item('dentist.reports', 'Laporan Pribadi', 'bx bx-bar-chart-alt-2', 'reports.personal', 'report.view', 'Laporan kinerja dokter.'),
                self::item('dentist.satusehat', 'SATUSEHAT', 'bx bx-cloud', 'integrations.satusehat', 'satusehat.view', 'Kirim kunjungan ke SATUSEHAT klinik ini.'),
            ]),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    protected static function dentalAssistant(): array
    {
        return [
            self::item('assistant.dashboard', 'Dashboard', 'bx bx-home-circle', 'dashboard', 'dashboard.view', 'Ringkasan kerja asisten dokter.'),
            self::item('assistant.care.initial', 'Pemeriksaan', 'bx bx-search-alt', 'examinations.initial', 'examination.view', 'Pemeriksaan pasien.'),
            self::item('assistant.history', 'Riwayat Pasien', 'bx bx-history', 'patients.history', 'patient_history.view', 'Riwayat pasien.'),
            self::item('assistant.schedule', 'Jadwal', 'bx bx-calendar', 'doctors.schedule.today', 'schedule.view', 'Jadwal pelayanan hari ini.'),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    protected static function nurse(): array
    {
        return [
            self::item('nurse.dashboard', 'Dashboard', 'bx bx-home-circle', 'dashboard', 'dashboard.view', 'Ringkasan kerja perawat.'),
            self::item('nurse.care.initial', 'Pemeriksaan', 'bx bx-search-alt', 'examinations.initial', 'examination.view', 'Pemeriksaan pasien.'),
            self::item('nurse.history', 'Riwayat Pasien', 'bx bx-history', 'patients.history', 'patient_history.view', 'Riwayat pasien.'),
            self::item('nurse.schedule', 'Jadwal', 'bx bx-calendar', 'doctors.schedule.today', 'schedule.view', 'Jadwal pelayanan.'),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    protected static function pharmacy(): array
    {
        return [
            self::item('pharmacy.dashboard', 'Dashboard Farmasi', 'bx bx-home-circle', 'dashboard', 'dashboard.view', 'Ringkasan kerja farmasi.'),
            self::item('pharmacy.examination', 'Pemeriksaan', 'bx bx-search-alt', 'examinations.initial', 'examination.view', 'Pemeriksaan pasien.'),
            self::item('pharmacy.prescriptions', 'Resep', 'bx bx-receipt', null, 'prescription.view', 'Pengelolaan resep masuk.', [
                self::item('pharmacy.prescriptions.incoming', 'Resep Masuk', 'bx bx-log-in-circle', 'pharmacy.prescriptions.incoming', 'prescription.view', 'Resep yang baru masuk.'),
                self::item('pharmacy.prescriptions.processing', 'Diproses', 'bx bx-loader', 'pharmacy.prescriptions.processing', 'prescription.update', 'Resep yang sedang diproses.'),
                self::item('pharmacy.prescriptions.completed', 'Selesai', 'bx bx-check-circle', 'pharmacy.prescriptions.completed', 'prescription.view', 'Resep yang sudah selesai.'),
                self::item('pharmacy.prescriptions.history', 'Riwayat', 'bx bx-history', 'pharmacy.prescriptions.history', 'prescription.view', 'Riwayat resep farmasi.'),
            ]),
            self::item('pharmacy.medicines', 'Obat', 'bx bx-plus-medical', null, 'medicine.view', 'Master dan stok obat.', [
                self::item('pharmacy.medicines.index', 'Daftar Obat', 'bx bx-list-ul', 'pharmacy.medicines.index', 'medicine.view', 'Daftar obat klinik.'),
                self::item('pharmacy.medicines.stock', 'Stok', 'bx bx-package', 'pharmacy.stock.index', 'stock.view', 'Stok obat.'),
                self::item('pharmacy.medicines.batches', 'Batch', 'bx bx-layer', 'pharmacy.stock.batches', 'stock.view', 'Batch obat.'),
                self::item('pharmacy.medicines.expired', 'Expired', 'bx bx-error', 'pharmacy.stock.expired', 'stock.view', 'Obat kedaluwarsa.'),
                self::item('pharmacy.medicines.adjustments', 'Penyesuaian Stok', 'bx bx-slider-alt', 'pharmacy.stock.adjustments', 'stock.manage', 'Penyesuaian stok obat.'),
                self::item('pharmacy.medicines.card', 'Kartu Stok', 'bx bx-spreadsheet', 'pharmacy.stock.card', 'stock.view', 'Kartu stok per obat.'),
                self::item('pharmacy.medicines.opname', 'Opname', 'bx bx-clipboard', 'pharmacy.stock.opname', 'stock.manage', 'Stock opname.'),
                self::item('pharmacy.medicines.returns', 'Retur', 'bx bx-undo', 'pharmacy.stock.returns', 'stock.manage', 'Retur obat.'),
                self::item('pharmacy.lab', 'Lab Gigi', 'bx bx-cube', 'pharmacy.lab.index', 'pharmacy.view', 'Pesanan laboratorium gigi.'),
            ]),
            self::item('pharmacy.purchases', 'Pembelian', 'bx bx-cart', null, 'purchase.view', 'Pembelian obat.', [
                self::item('pharmacy.purchases.suppliers', 'Supplier', 'bx bx-store', 'pharmacy.purchases.suppliers', 'supplier.view', 'Supplier farmasi.'),
                self::item('pharmacy.purchases.orders', 'Purchase Order', 'bx bx-file', 'pharmacy.purchases.orders', 'purchase.view', 'Purchase order obat.'),
                self::item('pharmacy.purchases.receipts', 'Penerimaan', 'bx bx-package', 'pharmacy.purchases.receipts', 'purchase.manage', 'Penerimaan barang farmasi.'),
            ]),
            self::item('pharmacy.reports', 'Laporan', 'bx bx-bar-chart-alt-2', 'pharmacy.reports', 'report.view', 'Laporan farmasi.', [
                self::item('pharmacy.reports.overview', 'Ringkasan', 'bx bx-home-circle', 'pharmacy.reports', 'report.view', 'Ringkasan laporan farmasi.'),
                self::item('pharmacy.reports.stock', 'Stok', 'bx bx-package', 'pharmacy.reports.stock', 'report.view', 'Laporan stok obat.'),
                self::item('pharmacy.reports.outgoing', 'Obat Keluar', 'bx bx-log-out-circle', 'pharmacy.reports.outgoing', 'report.view', 'Laporan obat keluar.'),
                self::item('pharmacy.reports.incoming', 'Obat Masuk', 'bx bx-log-in-circle', 'pharmacy.reports.incoming', 'report.view', 'Laporan obat masuk.'),
                self::item('pharmacy.reports.expired', 'Expired', 'bx bx-error-circle', 'pharmacy.reports.expired', 'report.view', 'Laporan obat kedaluwarsa.'),
                self::item('pharmacy.reports.transactions', 'Transaksi', 'bx bx-transfer', 'pharmacy.transactions', 'pharmacy.view', 'Semua mutasi stok.'),
            ]),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    protected static function cashier(): array
    {
        return [
            self::item('cashier.dashboard', 'Dashboard Kasir', 'bx bx-home-circle', 'dashboard', 'dashboard.view', 'Ringkasan kerja kasir.'),
            self::item('cashier.examination', 'Pemeriksaan', 'bx bx-search-alt', 'examinations.initial', 'examination.view', 'Pemeriksaan pasien.'),
            self::item('cashier.transactions', 'Transaksi', 'bx bx-credit-card', null, 'billing.view', 'Transaksi pembayaran pasien.', [
                self::item('cashier.invoices.today', 'Tagihan Hari Ini', 'bx bx-receipt', 'billing.invoices.today', 'billing.view', 'Tagihan pasien hari ini.'),
                self::item('cashier.payments', 'Pembayaran', 'bx bx-money', 'billing.payments', 'payment.view', 'Penerimaan pembayaran.'),
                self::item('cashier.receivables', 'Piutang', 'bx bx-wallet', 'billing.receivables', 'receivable.view', 'Piutang pasien.'),
                self::item('cashier.history', 'Riwayat Transaksi', 'bx bx-history', 'billing.history', 'billing.view', 'Riwayat transaksi kasir.'),
            ]),
            self::item('cashier.patients', 'Pasien', 'bx bx-user', 'registration.patients', 'patient.view', 'Pencarian data pasien untuk kasir.'),
            self::item('cashier.shifts', 'Shift Kasir', 'bx bx-time-five', null, 'cash_shift.view', 'Pengelolaan shift kasir.', [
                self::item('cashier.shifts.open', 'Buka Shift', 'bx bx-log-in-circle', 'cashier.shifts.open', 'cash_shift.manage', 'Pembukaan shift kasir.'),
                self::item('cashier.shifts.transactions', 'Transaksi Shift', 'bx bx-list-ul', 'cashier.shifts.transactions', 'cash_shift.view', 'Transaksi pada shift berjalan.'),
                self::item('cashier.shifts.close', 'Tutup Shift', 'bx bx-log-out-circle', 'cashier.shifts.close', 'cash_shift.manage', 'Penutupan shift kasir.'),
            ]),
            self::item('cashier.reports', 'Laporan', 'bx bx-bar-chart-alt-2', null, 'report.view', 'Laporan kasir.', [
                self::item('cashier.reports.index', 'Laporan Kasir', 'bx bx-file', 'cashier.reports', 'report.view', 'Laporan transaksi kasir.'),
            ]),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    protected static function finance(): array
    {
        return [
            self::item('finance.dashboard', 'Dashboard Keuangan', 'bx bx-home-circle', 'dashboard', 'dashboard.view', 'Ringkasan keuangan klinik.'),
            self::item('finance.examination', 'Pemeriksaan', 'bx bx-search-alt', 'examinations.initial', 'examination.view', 'Pemeriksaan pasien.'),
            self::item('finance.revenue', 'Pendapatan', 'bx bx-dollar', null, 'revenue.view', 'Pendapatan klinik.', [
                self::item('finance.revenue.daily', 'Pendapatan Harian', 'bx bx-calendar', 'finance.revenue.daily', 'revenue.view', 'Pendapatan harian klinik.'),
                self::item('finance.revenue.monthly', 'Pendapatan Bulanan', 'bx bx-calendar-alt', 'finance.revenue.monthly', 'revenue.view', 'Pendapatan bulanan klinik.'),
                self::item('finance.revenue.doctors', 'Pendapatan per Dokter', 'bx bx-user', 'finance.revenue.doctors', 'revenue.view', 'Pendapatan berdasarkan dokter.'),
            ]),
            self::item('finance.expenses', 'Pengeluaran', 'bx bx-minus-circle', null, 'expense.view', 'Pengeluaran klinik.', [
                self::item('finance.expenses.index', 'Pengeluaran', 'bx bx-receipt', 'finance.expenses', 'expense.view', 'Daftar pengeluaran.'),
                self::item('finance.expenses.categories', 'Kategori', 'bx bx-category', 'finance.expenses.categories', 'expense.view', 'Kategori pengeluaran.'),
                self::item('finance.expenses.suppliers', 'Supplier', 'bx bx-store', 'finance.expenses.suppliers', 'supplier.view', 'Supplier pengeluaran.'),
            ]),
            self::item('finance.sharing-fees', 'Sharing Fee', 'bx bx-share-alt', null, 'sharing_fee.view', 'Bagi hasil jasa dokter.', [
                self::item('finance.sharing-fees.rules', 'Aturan Fee', 'bx bx-slider-alt', 'finance.sharing-fees.rules.index', 'sharing_fee.view', 'Konfigurasi aturan sharing fee.'),
                self::item('finance.sharing-fees.settlements', 'Settlement', 'bx bx-list-check', 'finance.sharing-fees.settlements.index', 'sharing_fee.view', 'Settlement sharing fee.'),
                self::item('finance.sharing-fees.reports', 'Laporan Fee', 'bx bx-bar-chart', 'finance.sharing-fees.reports.doctors', 'sharing_fee.view', 'Laporan sharing fee per dokter.'),
            ]),
            self::item('finance.doctor-fee-waivers', 'Pembebasan Jasa Dokter', 'bx bx-gift', null, 'finance.view', 'Kebijakan dan histori pembebasan jasa dokter.', [
                self::item('finance.doctor-fee-waivers.settings', 'Kebijakan Dokter', 'bx bx-slider-alt', 'finance.doctor-fee-waivers.settings.index', 'procedure.manage_doctor_fee_waiver_policy', 'Dokter yang boleh membebaskan jasa.'),
                self::item('finance.doctor-fee-waivers.logs', 'Histori Pembebasan', 'bx bx-history', 'finance.doctor-fee-waivers.logs.index', 'finance.view', 'Riwayat pembebasan dan diskon tindakan.'),
            ]),
            self::item('finance.receivables', 'Piutang', 'bx bx-wallet', 'finance.receivables', 'receivable.view', 'Piutang klinik.'),
            self::item('finance.payables', 'Hutang', 'bx bx-credit-card', 'finance.payables', 'payable.view', 'Hutang klinik.'),
            self::item('finance.cash-bank', 'Kas & Bank', 'bx bx-bank', 'finance.cash-bank', 'cash_bank.view', 'Kas dan rekening bank klinik.'),
            self::item('finance.reports', 'Laporan', 'bx bx-bar-chart-alt-2', null, 'report.view', 'Laporan keuangan.', [
                self::item('finance.reports.revenue', 'Pendapatan', 'bx bx-dollar', 'finance.reports.revenue', 'report.view', 'Laporan pendapatan.'),
                self::item('finance.reports.expenses', 'Pengeluaran', 'bx bx-minus-circle', 'finance.reports.expenses', 'report.view', 'Laporan pengeluaran.'),
                self::item('finance.reports.cashflow', 'Arus Kas', 'bx bx-transfer', 'finance.reports.cashflow', 'report.view', 'Laporan arus kas.'),
                self::item('finance.reports.receivables', 'Piutang', 'bx bx-wallet', 'finance.reports.receivables', 'report.view', 'Laporan piutang.'),
                self::item('finance.reports.profit-loss', 'Laba Rugi', 'bx bx-line-chart', 'finance.reports.profit-loss', 'report.view', 'Laporan laba rugi.'),
            ]),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    protected static function auditor(): array
    {
        return [
            self::item('auditor.dashboard', 'Dashboard', 'bx bx-home-circle', 'dashboard', 'dashboard.view', 'Ringkasan tampilan auditor.'),
            self::item('auditor.examination', 'Pemeriksaan', 'bx bx-search-alt', 'examinations.initial', 'examination.view', 'Pemeriksaan pasien.'),
            self::item('auditor.registration', 'Pendaftaran', 'bx bx-user-plus', null, 'registration.view', 'Riwayat pendaftaran.', [
                self::item('auditor.registration.history', 'Riwayat', 'bx bx-history', 'registration.history', 'registration.view', 'Riwayat pendaftaran pasien.'),
            ]),
            self::item('auditor.patients', 'Pasien', 'bx bx-user', null, 'patient.view', 'Data pasien.', [
                self::item('auditor.patients.index', 'Daftar Pasien', 'bx bx-list-ul', 'registration.patients', 'patient.view', 'Daftar pasien klinik.'),
            ]),
            self::item('auditor.medical-record', 'Rekam Medis', 'bx bx-folder-open', null, 'medical_record.view', 'Rekam medis.', [
                self::item('auditor.medical-record.history', 'Riwayat', 'bx bx-history', 'medical-record.index', 'medical_record.view', 'Riwayat rekam medis.'),
                self::item('auditor.medical-letters', 'Surat Keterangan', 'bx bx-envelope', 'medical-letters.index', 'medical_record.view', 'Daftar surat keterangan medis.'),
            ]),
            self::item('auditor.finance', 'Keuangan', 'bx bx-wallet', null, 'finance.view', 'Informasi keuangan.', [
                self::item('auditor.finance.revenue', 'Pendapatan', 'bx bx-dollar', 'finance.revenue.daily', 'revenue.view', 'Pendapatan klinik.'),
                self::item('auditor.finance.expenses', 'Pengeluaran', 'bx bx-minus-circle', 'finance.expenses', 'expense.view', 'Pengeluaran klinik.'),
                self::item('auditor.finance.sharing-fees', 'Sharing Fee', 'bx bx-share-alt', 'finance.sharing-fees.reports.doctors', 'sharing_fee.view', 'Laporan sharing fee dokter.'),
                self::item('auditor.finance.doctor-fee-waivers', 'Histori Pembebasan', 'bx bx-gift', 'finance.doctor-fee-waivers.logs.index', 'finance.view', 'Riwayat pembebasan jasa dokter.'),
            ]),
            self::item('auditor.reports', 'Laporan', 'bx bx-bar-chart-alt-2', null, 'report.view', 'Laporan klinik.', [
                self::item('auditor.reports.operational', 'Operasional', 'bx bx-cog', 'reports.operational', 'report.view', 'Laporan operasional.'),
                self::item('auditor.reports.medical', 'Medis', 'bx bx-plus-medical', 'reports.medical', 'report.view', 'Laporan medis.'),
                self::item('auditor.reports.finance', 'Keuangan', 'bx bx-wallet', 'reports.finance', 'report.view', 'Laporan keuangan.'),
            ]),
            self::item('auditor.audit', 'Audit Log', 'bx bx-shield', 'logs.index', 'logs.view', 'Audit log sistem.'),
        ];
    }

    /**
     * @param  list<array<string, mixed>>  $children
     * @return array<string, mixed>
     */
    protected static function heading(string $name, string $title, array $children): array
    {
        return [
            'name' => $name,
            'title' => $title,
            'icon' => null,
            'route' => null,
            'permission' => '',
            'type' => MenuType::Heading->value,
            'description' => '',
            'children' => $children,
        ];
    }

    /**
     * @param  list<array<string, mixed>>  $children
     * @return array<string, mixed>
     */
    protected static function item(
        string $name,
        string $title,
        string $icon,
        ?string $route,
        string $permission,
        string $description = '',
        array $children = [],
    ): array {
        return [
            'name' => $name,
            'title' => $title,
            'icon' => $icon,
            'route' => $route,
            'permission' => $permission,
            'description' => $description !== '' ? $description : 'Modul ini akan dikembangkan pada tahap berikutnya.',
            'children' => $children,
        ];
    }

    /**
     * @param  list<array<string, mixed>>  $items
     * @param  array<string, array{name: string, uri: string, permission: string, scope: string}>  $routes
     * @param  list<string>  $skip
     */
    protected static function collectRoutes(array $items, array &$routes, array $skip, string $scope): void
    {
        foreach ($items as $item) {
            $route = $item['route'] ?? null;

            if (is_string($route) && $route !== '' && ! in_array($route, $skip, true) && ! isset($routes[$route])) {
                $routes[$route] = [
                    'name' => $route,
                    'uri' => self::uriFromRoute($route),
                    'permission' => $item['permission'],
                    'scope' => $scope,
                ];
            }

            self::collectRoutes($item['children'] ?? [], $routes, $skip, $scope);
        }
    }

    public static function uriFromRoute(string $route): string
    {
        $parts = explode('.', $route);
        $last = $parts[array_key_last($parts)];

        if ($last === 'index') {
            array_pop($parts);
        } elseif ($last === 'create') {
            array_pop($parts);

            return '/'.implode('/', $parts).'/create';
        } elseif ($last === 'show') {
            array_pop($parts);

            return '/'.implode('/', $parts).'/detail';
        }

        return '/'.implode('/', $parts);
    }
}
