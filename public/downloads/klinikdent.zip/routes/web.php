<?php

use App\Enums\PayerType;
use App\Http\Controllers\ActivityLogController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Billing\BillingDashboardController;
use App\Http\Controllers\Billing\CashShiftController;
use App\Http\Controllers\Billing\InvoiceController;
use App\Http\Controllers\Billing\PaymentController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\Clinical\CareController;
use App\Http\Controllers\Clinical\MedicalLetterController;
use App\Http\Controllers\Clinical\ClinicalIndexController;
use App\Http\Controllers\Clinical\DentalLabController;
use App\Http\Controllers\Clinical\PatientHistoryController;
use App\Http\Controllers\Clinical\PharmacyPrescriptionController;
use App\Http\Controllers\Clinical\PrescriptionTemplateController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DoctorController;
use App\Http\Controllers\DoctorScheduleController;
use App\Http\Controllers\Finance\CashBankController;
use App\Http\Controllers\Finance\ExpenseCategoryController;
use App\Http\Controllers\Finance\ExpenseController;
use App\Http\Controllers\Finance\FinanceDashboardController;
use App\Http\Controllers\Finance\FinanceReportController;
use App\Http\Controllers\Finance\PayableController;
use App\Http\Controllers\Finance\ReceivableController;
use App\Http\Controllers\Finance\RevenueController;
use App\Http\Controllers\Finance\DoctorFeeWaiverLogController;
use App\Http\Controllers\Finance\DoctorFeeWaiverSettingController;
use App\Http\Controllers\Finance\SharingFeeReportController;
use App\Http\Controllers\Finance\SharingFeeRuleController;
use App\Http\Controllers\Finance\SharingFeeSettlementController;
use App\Http\Controllers\Integration\IntegrationController;
use App\Http\Controllers\Management\ClinicController;
use App\Http\Controllers\Management\MedicineController;
use App\Http\Controllers\Management\PayerController;
use App\Http\Controllers\Management\ProcedureController;
use App\Http\Controllers\Management\RoomController;
use App\Http\Controllers\Management\ServiceController;
use App\Http\Controllers\Management\TariffController;
use App\Http\Controllers\Cms\ContentPlanController;
use App\Http\Controllers\Cms\DashboardController as CmsDashboardController;
use App\Http\Controllers\Cms\KeywordController;
use App\Http\Controllers\Cms\MediaController as CmsMediaController;
use App\Http\Controllers\Cms\PostController as CmsPostController;
use App\Http\Controllers\Cms\RedirectController as CmsRedirectController;
use App\Http\Controllers\Cms\SeoSettingsController;
use App\Http\Controllers\Cms\TaxonomyController;
use App\Http\Controllers\Marketing\BlogController;
use App\Http\Controllers\Marketing\DemoRequestController;
use App\Http\Controllers\Marketing\LandingController;
use App\Http\Controllers\Marketing\StarterKitController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\MidtransNotificationController;
use App\Http\Controllers\Onboarding\OnboardingController;
use App\Http\Controllers\Owner\AddonMarketplaceController;
use App\Http\Controllers\Owner\PlanController;
use App\Http\Controllers\Owner\PracticeArchiveController;
use App\Http\Controllers\Saas\AddonController as SaasAddonController;
use App\Http\Controllers\Saas\AddonSubscriptionController as SaasAddonSubscriptionController;
use App\Http\Controllers\Pharmacy\PharmacyDashboardController;
use App\Http\Controllers\Pharmacy\PharmacyReportController;
use App\Http\Controllers\Pharmacy\PurchaseOrderController;
use App\Http\Controllers\Pharmacy\StockController;
use App\Http\Controllers\Pharmacy\SupplierController;
use App\Http\Controllers\Portal\DocumentCheckController;
use App\Http\Controllers\Portal\PatientPortalController;
use App\Http\Controllers\Registration\PatientController;
use App\Http\Controllers\Registration\WilayahController;
use App\Http\Controllers\Registration\PublicBookingController;
use App\Http\Controllers\Registration\QueueController;
use App\Http\Controllers\Registration\QueueMonitorController;
use App\Http\Controllers\Registration\VisitController;
use App\Http\Controllers\Reports\ReportController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\Saas\InvoiceController as SaasInvoiceController;
use App\Http\Controllers\Saas\PackageController;
use App\Http\Controllers\Saas\PaymentGatewayController;
use App\Http\Controllers\Saas\PlatformOpsController;
use App\Http\Controllers\Saas\SubscriptionController;
use App\Http\Controllers\Saas\TenantController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\Settings\ClinicSettingController;
use App\Http\Controllers\Settings\ThemeSettingController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\WhatsApp\BalanceController as WhatsAppBalanceController;
use App\Http\Controllers\WhatsApp\DashboardController as WhatsAppDashboardController;
use App\Http\Controllers\WhatsApp\LogController as WhatsAppLogController;
use App\Http\Controllers\WhatsApp\PromotionController as WhatsAppPromotionController;
use App\Http\Controllers\WhatsApp\ReminderController as WhatsAppReminderController;
use App\Http\Controllers\WhatsApp\SettingController as WhatsAppSettingController;
use App\Http\Controllers\WhatsApp\TemplateController as WhatsAppTemplateController;
use Illuminate\Support\Facades\Route;

Route::get('/', [LandingController::class, 'index'])->name('home');
Route::get('/dokter-gigi-baru', [LandingController::class, 'dokterBaru'])->name('marketing.dokter-baru');
Route::get('/klinik-gigi', [LandingController::class, 'klinik'])->name('marketing.klinik');
Route::get('/multi-cabang', [LandingController::class, 'multiCabang'])->name('marketing.multi-cabang');
Route::get('/odontogram-digital', [LandingController::class, 'odontogram'])->name('marketing.odontogram');
Route::get('/rekam-medis-gigi', [LandingController::class, 'rekamMedis'])->name('marketing.rekam-medis');
Route::get('/tentang-klinikdent', [LandingController::class, 'tentang'])->name('marketing.tentang');
Route::get('/privacy', [LandingController::class, 'privacy'])->name('privacy');
Route::get('/terms', [LandingController::class, 'terms'])->name('terms');
Route::get('/sitemap.xml', [LandingController::class, 'sitemap'])->name('sitemap');
Route::get('/robots.txt', [LandingController::class, 'robots'])->name('robots');
Route::get('/llms.txt', [LandingController::class, 'llmsTxt'])->name('llms');
Route::get('/blog', [BlogController::class, 'index'])->name('blog.index');
Route::get('/blog/cari', [BlogController::class, 'search'])->middleware('throttle:30,1')->name('blog.search');
Route::get('/blog/rss.xml', [BlogController::class, 'rss'])->name('blog.rss');
Route::get('/blog/kategori/{slug}', [BlogController::class, 'category'])->name('blog.category');
Route::get('/blog/tag/{slug}', [BlogController::class, 'tag'])->name('blog.tag');
Route::get('/blog/penulis/{slug}', [BlogController::class, 'author'])->name('blog.author');
Route::get('/blog/{slug}', [BlogController::class, 'show'])->name('blog.show');
Route::post('/blog/track-cta', [BlogController::class, 'trackCta'])->middleware('throttle:60,1')->name('blog.track-cta');
Route::post('/demo', [DemoRequestController::class, 'store'])
    ->middleware('throttle:5,1')
    ->name('demo.store');
Route::post('/starter-kit', [StarterKitController::class, 'store'])
    ->middleware('throttle:5,1')
    ->name('starter-kit.store');
Route::get('/starter-kit/unduh', [StarterKitController::class, 'download'])
    ->middleware('throttle:10,1')
    ->name('starter-kit.download');

Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'create'])->name('login');
    Route::post('/login', [LoginController::class, 'store'])
        ->middleware('throttle:login')
        ->name('login.store');
    Route::get('/register', [RegisterController::class, 'create'])->name('register');
    Route::post('/register', [RegisterController::class, 'store'])
        ->middleware('throttle:register')
        ->name('register.store');
});

Route::post('/logout', [LoginController::class, 'destroy'])
    ->middleware('auth')
    ->name('logout');

Route::post('/midtrans/notification', [MidtransNotificationController::class, 'store'])
    ->name('midtrans.notification');

Route::get('/antrean/{token}', [QueueMonitorController::class, 'public'])->name('queue.monitor.public');
Route::get('/antrean/{token}/data', [QueueMonitorController::class, 'feed'])->name('queue.monitor.feed');

Route::get('/janji/{slug}', [PublicBookingController::class, 'show'])->name('booking.public');
Route::get('/janji/{slug}/sesi', [PublicBookingController::class, 'sessions'])->name('booking.public.sessions');
Route::get('/janji/{slug}/from-nik', [PublicBookingController::class, 'fromNik'])->middleware('throttle:30,1')->name('booking.public.from-nik');
Route::get('/janji/{slug}/wilayah/cities', [PublicBookingController::class, 'cities'])->middleware('throttle:60,1')->name('booking.public.wilayah.cities');
Route::get('/janji/{slug}/wilayah/districts', [PublicBookingController::class, 'districts'])->middleware('throttle:60,1')->name('booking.public.wilayah.districts');
Route::get('/janji/{slug}/wilayah/villages', [PublicBookingController::class, 'villages'])->middleware('throttle:60,1')->name('booking.public.wilayah.villages');
Route::post('/janji/{slug}', [PublicBookingController::class, 'store'])->middleware('throttle:10,1')->name('booking.public.store');

Route::get('/cek/{code}', [DocumentCheckController::class, 'show'])->name('documents.check');

Route::get('/pasien/{slug}', [PatientPortalController::class, 'show'])->name('portal.patient');
Route::post('/pasien/{slug}', [PatientPortalController::class, 'login'])->middleware('throttle:10,1')->name('portal.patient.login');
Route::post('/pasien/{slug}/keluar', [PatientPortalController::class, 'logout'])->name('portal.patient.logout');
Route::get('/pasien/{slug}/resume', [PatientPortalController::class, 'resume'])->name('portal.patient.resume');

Route::middleware(['auth', 'onboarding.owner'])->group(function () {
    Route::middleware(['tenant.scope', 'tenant.active'])->prefix('onboarding')->name('onboarding.')->group(function () {
        Route::get('/', [OnboardingController::class, 'show'])->name('show');
        Route::post('/step/{step}', [OnboardingController::class, 'step'])->name('step');
        Route::post('/skip/{step}', [OnboardingController::class, 'skip'])->name('skip');
        Route::post('/back', [OnboardingController::class, 'back'])->name('back');
        Route::post('/complete', [OnboardingController::class, 'complete'])->name('complete');
        Route::get('/selesai', [OnboardingController::class, 'done'])->name('done');
    });

    Route::middleware(['route.permission'])->group(function () {
        Route::get('/dashboard', [DashboardController::class, 'index'])
            ->middleware('permission:dashboard.view')
            ->name('dashboard');

        Route::get('/settings/theme', [ThemeSettingController::class, 'index'])->name('settings.theme');
        Route::put('/settings/theme', [ThemeSettingController::class, 'update'])->name('settings.theme.update');

        Route::middleware(['tenant.scope', 'tenant.active'])->group(function () {
            Route::get('/users/data', [UserController::class, 'data'])
                ->middleware('permission:users.view')
                ->name('users.data');
            Route::post('/users/{user}/toggle-status', [UserController::class, 'toggleStatus'])
                ->middleware('permission:users.edit')
                ->name('users.toggle-status');
            Route::post('/users/{user}/reset-password', [UserController::class, 'resetPassword'])
                ->middleware('permission:users.edit')
                ->name('users.reset-password');
            Route::post('/users/{user}/impersonate', [UserController::class, 'impersonate'])
                ->middleware('permission:users.impersonate')
                ->name('users.impersonate');
            Route::resource('users', UserController::class);

            Route::get('/branches/data', [BranchController::class, 'data'])
                ->middleware('permission:branch.view')
                ->name('branches.data');
            Route::post('/branches/{branch}/satusehat', [BranchController::class, 'syncSatuSehat'])
                ->middleware('permission:branch.manage')
                ->name('branches.satusehat');
            Route::resource('branches', BranchController::class);

            Route::prefix('management')->name('management.')->group(function () {
                Route::get('clinic', [ClinicController::class, 'index'])
                    ->middleware('permission:clinic.view')
                    ->name('clinic');

                Route::get('services/data', [ServiceController::class, 'data'])
                    ->middleware('permission:service.view')
                    ->name('services.data');
                Route::resource('services', ServiceController::class);

                Route::get('procedures/data', [ProcedureController::class, 'data'])
                    ->middleware('permission:procedure.view')
                    ->name('procedures.data');
                Route::resource('procedures', ProcedureController::class);

                Route::get('tariffs/data', [TariffController::class, 'data'])
                    ->middleware('permission:tariff.view')
                    ->name('tariffs.data');
                Route::resource('tariffs', TariffController::class);

                Route::get('medicines/data', [MedicineController::class, 'data'])
                    ->middleware('permission:medicine.view')
                    ->name('medicines.data');
                Route::get('medicines/import/template', [MedicineController::class, 'importTemplate'])
                    ->middleware('permission:medicine.manage')
                    ->name('medicines.import.template');
                Route::post('medicines/import/parse', [MedicineController::class, 'importParse'])
                    ->middleware('permission:medicine.manage')
                    ->name('medicines.import.parse');
                Route::post('medicines/import/row', [MedicineController::class, 'importRow'])
                    ->middleware('permission:medicine.manage')
                    ->name('medicines.import.row');
                Route::resource('medicines', MedicineController::class);

                Route::get('payers/data', [PayerController::class, 'data'])
                    ->middleware('permission:payer.view')
                    ->name('payers.data');
                Route::resource('payers', PayerController::class);

                Route::get('rooms/data', [RoomController::class, 'data'])
                    ->middleware('permission:room.view')
                    ->name('rooms.data');
                Route::post('rooms/{room}/satusehat', [RoomController::class, 'fetchIhs'])
                    ->middleware('permission:room.manage')
                    ->name('rooms.satusehat');
                Route::resource('rooms', RoomController::class);
            });

            Route::get('/doctors/{doctor}/edit', [DoctorController::class, 'edit'])->name('doctors.edit');
            Route::match(['put', 'patch'], '/doctors/{doctor}', [DoctorController::class, 'update'])->name('doctors.update');
            Route::post('/doctors/{doctor}/satusehat', [DoctorController::class, 'fetchIhs'])->name('doctors.satusehat');
            Route::get('/doctors/schedule/today', [DoctorScheduleController::class, 'today'])
                ->middleware('permission:schedule.view')
                ->name('doctors.schedule.today');
            Route::get('/doctors/schedule/mine', [DoctorScheduleController::class, 'mine'])
                ->middleware('permission:schedule.view')
                ->name('doctors.schedule.mine');
            Route::get('/doctors/schedule/create', [DoctorScheduleController::class, 'create'])
                ->middleware('permission:schedule.manage')
                ->name('doctors.schedule.create');
            Route::get('/doctors/schedule', [DoctorScheduleController::class, 'index'])
                ->middleware('permission:schedule.view')
                ->name('doctors.schedule');
            Route::post('/doctors/schedules', [DoctorScheduleController::class, 'store'])
                ->middleware('permission:schedule.manage')
                ->name('doctors.schedule.store');
            Route::post('/doctors/{doctor}/schedules', [DoctorScheduleController::class, 'store'])
                ->middleware('permission:schedule.manage')
                ->name('doctors.schedules.store');
            Route::get('/doctors/schedules/{doctorSchedule}/edit', [DoctorScheduleController::class, 'edit'])
                ->middleware('permission:schedule.manage')
                ->name('doctors.schedules.edit');
            Route::put('/doctors/schedules/{doctorSchedule}', [DoctorScheduleController::class, 'update'])
                ->middleware('permission:schedule.manage')
                ->name('doctors.schedules.update');
            Route::delete('/doctors/schedules/{doctorSchedule}', [DoctorScheduleController::class, 'destroy'])
                ->middleware('permission:schedule.manage')
                ->name('doctors.schedules.destroy');
            Route::resource('doctors', DoctorController::class)->except(['show', 'edit', 'update']);

            Route::get('/pharmacy/medicines', [MedicineController::class, 'index'])
                ->middleware('permission:medicine.view')
                ->name('pharmacy.medicines.index');

            foreach (PayerType::cases() as $payerType) {
                Route::get('/registration/payers/'.$payerType->routeKey(), [PayerController::class, 'index'])
                    ->middleware('permission:payer.view')
                    ->defaults('payerType', $payerType->routeKey())
                    ->name('registration.payers.'.$payerType->routeKey());
            }

            Route::get('/registration', [VisitController::class, 'hub'])->name('registration.index');
            Route::get('/registration/new', [VisitController::class, 'create'])->name('registration.new');
            Route::get('/registration/availability', [VisitController::class, 'availability'])->name('registration.availability');
            Route::post('/registration/patient-ihs', [VisitController::class, 'lookupPatientIhs'])->name('registration.patient-ihs');
            Route::post('/registration/visits', [VisitController::class, 'store'])->name('registration.visits.store');
            Route::get('/registration/visits/data', [VisitController::class, 'data'])->name('registration.visits.data');
            Route::get('/registration/visits/today', [VisitController::class, 'index'])->name('registration.visits.today');
            Route::get('/registration/visits', [VisitController::class, 'index'])->name('registration.visits');
            Route::get('/registration/history', [VisitController::class, 'index'])->name('registration.history');
            Route::get('/patients/history', [PatientHistoryController::class, 'index'])->name('patients.history');
            Route::get('/patients/{patient}/history', [PatientHistoryController::class, 'show'])->name('patients.history.show');
            Route::get('/patients/{patient}/history/visits/{visit}', [PatientHistoryController::class, 'visit'])->name('patients.history.visit');
            Route::get('/patients/{patient}/history/prescriptions/{prescription}/print', [PatientHistoryController::class, 'printPrescription'])->name('patients.history.prescription.print');
            Route::post('/patients/{patient}/history/resume', [PatientHistoryController::class, 'storeResume'])->name('patients.history.resume.store');
            Route::get('/patients/{patient}/history/resume/{document}/pdf', [PatientHistoryController::class, 'resumePdf'])->name('patients.history.resume.pdf');
            Route::get('/registration/visits/{visit}', [VisitController::class, 'show'])->name('registration.visits.show');
            Route::post('/registration/visits/{visit}/cancel', [VisitController::class, 'cancel'])->name('registration.visits.cancel');

            Route::get('/registration/patients/data', [PatientController::class, 'data'])->name('registration.patients.data');
            Route::get('/registration/patients/search', [PatientController::class, 'search'])->name('registration.patients.search');
            Route::get('/registration/wilayah/cities', [WilayahController::class, 'cities'])->name('registration.wilayah.cities');
            Route::get('/registration/wilayah/districts', [WilayahController::class, 'districts'])->name('registration.wilayah.districts');
            Route::get('/registration/wilayah/villages', [WilayahController::class, 'villages'])->name('registration.wilayah.villages');
            Route::get('/registration/wilayah/from-nik', [WilayahController::class, 'fromNik'])->name('registration.wilayah.from-nik');
            Route::get('/registration/patients/create', [PatientController::class, 'create'])->name('registration.patients.create');
            Route::get('/registration/patients', [PatientController::class, 'index'])->name('registration.patients');
            Route::post('/registration/patients', [PatientController::class, 'store'])->name('registration.patients.store');
            Route::get('/registration/patients/{patient}/edit', [PatientController::class, 'edit'])->name('registration.patients.edit');
            Route::get('/registration/patients/{patient}', [PatientController::class, 'show'])->name('registration.patients.show');
            Route::put('/registration/patients/{patient}', [PatientController::class, 'update'])->name('registration.patients.update');
            Route::post('/registration/patients/{patient}/satusehat', [PatientController::class, 'fetchIhs'])->name('registration.patients.satusehat');
            Route::delete('/registration/patients/{patient}', [PatientController::class, 'destroy'])->name('registration.patients.destroy');

            Route::get('/queue/data', [QueueController::class, 'data'])->name('queue.data');
            Route::get('/queue', [QueueController::class, 'index'])->name('queue.index');
            Route::get('/queue/today', [QueueController::class, 'index'])->name('queue.today');
            Route::get('/queue/mine', [QueueController::class, 'index'])->name('queue.mine');
            Route::get('/queue/waiting', [QueueController::class, 'index'])->name('queue.waiting');
            Route::get('/queue/called', [QueueController::class, 'index'])->name('queue.called');
            Route::get('/queue/loket', [QueueController::class, 'loket'])->name('queue.loket');
            Route::get('/queue/monitor', [QueueMonitorController::class, 'show'])->name('queue.monitor');
            Route::post('/queue/{queue}/call', [QueueController::class, 'call'])->name('queue.call');
            Route::post('/queue/{queue}/complete', [QueueController::class, 'complete'])->name('queue.complete');
            Route::post('/queue/{queue}/skip', [QueueController::class, 'skip'])->name('queue.skip');

            Route::get('/medical-record', [ClinicalIndexController::class, 'index'])->name('medical-record.index');
            Route::get('/odontogram', [ClinicalIndexController::class, 'index'])->name('odontogram.index');
            Route::get('/diagnosis', [ClinicalIndexController::class, 'index'])->name('diagnosis.index');
            Route::get('/procedures', [ClinicalIndexController::class, 'index'])->name('procedures.index');
            Route::get('/prescriptions', [ClinicalIndexController::class, 'index'])->name('prescriptions.index');
            Route::get('/referrals', [ClinicalIndexController::class, 'index'])->name('referrals.index');
            Route::get('/examinations', [ClinicalIndexController::class, 'index'])->name('examinations.index');
            Route::get('/examinations/initial', [ClinicalIndexController::class, 'index'])->name('examinations.initial');
            Route::get('/examinations/anamnesis', [ClinicalIndexController::class, 'index'])->name('examinations.anamnesis');
            Route::get('/examinations/vitals', [ClinicalIndexController::class, 'index'])->name('examinations.vitals');
            Route::get('/examinations/notes', [ClinicalIndexController::class, 'index'])->name('examinations.notes');

            Route::get('/visits/{visit}/care', [CareController::class, 'show'])->name('care.show');
            Route::get('/visits/{visit}/care/diagnoses/search', [CareController::class, 'searchDiagnoses'])->name('care.diagnosis.search');
            Route::get('/visits/{visit}/care/procedures/icd9/search', [CareController::class, 'searchIcd9'])->name('care.procedure.icd9.search');
            Route::get('/visits/{visit}/care/procedures/tariff', [CareController::class, 'quoteProcedureTariff'])->name('care.procedure.tariff');
            Route::middleware('record.mutable')->group(function () {
                Route::put('/visits/{visit}/care/record', [CareController::class, 'updateRecord'])->name('care.record.update');
                Route::put('/visits/{visit}/care/examination', [CareController::class, 'updateExamination'])->name('care.examination.update');
                Route::put('/visits/{visit}/care/vitals', [CareController::class, 'updateVitals'])->name('care.vitals.update');
                Route::put('/visits/{visit}/care/anamnesis', [CareController::class, 'updateAnamnesis'])->name('care.anamnesis.update');
                Route::put('/visits/{visit}/care/follow-up', [CareController::class, 'updateFollowUp'])->name('care.follow-up.update');
                Route::put('/visits/{visit}/care/notes', [CareController::class, 'updateNotes'])->name('care.notes.update');
                Route::put('/visits/{visit}/care/tooth', [CareController::class, 'updateTooth'])->name('care.tooth.update');
                Route::delete('/visits/{visit}/care/tooth/{toothNumber}', [CareController::class, 'destroyTooth'])
                    ->where('toothNumber', '[0-9]{2}')
                    ->name('care.tooth.destroy');
                Route::put('/visits/{visit}/care/dental-exam', [CareController::class, 'updateDentalExam'])->name('care.dental-exam.update');
                Route::put('/visits/{visit}/care/systemic', [CareController::class, 'updateSystemicHistory'])->name('care.systemic.update');
                Route::post('/visits/{visit}/care/diagnoses', [CareController::class, 'storeDiagnosis'])->name('care.diagnosis.store');
                Route::put('/visits/{visit}/care/diagnoses/{diagnosis}', [CareController::class, 'updateDiagnosis'])->name('care.diagnosis.update');
                Route::delete('/visits/{visit}/care/diagnoses/{diagnosis}', [CareController::class, 'destroyDiagnosis'])->name('care.diagnosis.destroy');
                Route::post('/visits/{visit}/care/procedures', [CareController::class, 'storeProcedure'])->name('care.procedure.store');
                Route::put('/visits/{visit}/care/procedures/{procedure_record}', [CareController::class, 'updateProcedure'])->name('care.procedure.update');
                Route::delete('/visits/{visit}/care/procedures/{procedure_record}', [CareController::class, 'destroyProcedure'])->name('care.procedure.destroy');
                Route::post('/visits/{visit}/care/procedures/{procedure_record}/waiver/approve', [CareController::class, 'approveProcedureWaiver'])->name('care.procedure.waiver.approve');
                Route::post('/visits/{visit}/care/prescription-items', [CareController::class, 'storePrescriptionItem'])->name('care.prescription-item.store');
                Route::put('/visits/{visit}/care/prescription-items/{prescriptionItem}', [CareController::class, 'updatePrescriptionItem'])->name('care.prescription-item.update');
                Route::delete('/visits/{visit}/care/prescription-items/{prescriptionItem}', [CareController::class, 'destroyPrescriptionItem'])->name('care.prescription-item.destroy');
                Route::put('/visits/{visit}/care/prescriptions/{prescription}/meta', [CareController::class, 'updatePrescriptionMeta'])->name('care.prescription.meta');
                Route::post('/visits/{visit}/care/prescriptions/{prescription}/send', [CareController::class, 'sendPrescription'])->name('care.prescription.send');
                Route::post('/visits/{visit}/care/prescription-templates', [PrescriptionTemplateController::class, 'store'])->name('care.prescription-templates.store');
                Route::put('/visits/{visit}/care/prescription-templates/{prescriptionTemplate}', [PrescriptionTemplateController::class, 'update'])->name('care.prescription-templates.update');
                Route::delete('/visits/{visit}/care/prescription-templates/{prescriptionTemplate}', [PrescriptionTemplateController::class, 'destroy'])->name('care.prescription-templates.destroy');
                Route::post('/visits/{visit}/care/prescription-templates/{prescriptionTemplate}/apply', [PrescriptionTemplateController::class, 'apply'])->name('care.prescription-templates.apply');
                Route::post('/visits/{visit}/care/prescriptions/{prescription}/template', [PrescriptionTemplateController::class, 'storeFromPrescription'])->name('care.prescription-templates.from-prescription');
                Route::post('/visits/{visit}/care/referrals', [CareController::class, 'storeReferral'])->name('care.referral.store');
                Route::put('/visits/{visit}/care/referrals/{referral}', [CareController::class, 'updateReferral'])->name('care.referral.update');
                Route::delete('/visits/{visit}/care/referrals/{referral}', [CareController::class, 'destroyReferral'])->name('care.referral.destroy');
                Route::post('/visits/{visit}/care/lab', [DentalLabController::class, 'store'])->name('care.lab.store');
                Route::put('/visits/{visit}/care/lab/{order}', [DentalLabController::class, 'updateOrder'])->name('care.lab.update');
                Route::delete('/visits/{visit}/care/lab/{order}', [DentalLabController::class, 'destroy'])->name('care.lab.destroy');
            });
            Route::post('/visits/{visit}/care/finalize', [CareController::class, 'finalizeRecord'])->name('care.record.finalize');
            Route::post('/visits/{visit}/care/assessment/complete', [CareController::class, 'completeAssessment'])->name('care.assessment.complete');
            Route::post('/visits/{visit}/care/amendments', [CareController::class, 'storeAmendment'])->name('care.record.amend');
            Route::post('/visits/{visit}/care/sick-letter', [CareController::class, 'storeSickLetter'])->name('care.sick-letter.store');
            Route::get('/visits/{visit}/medical-letters/create', [MedicalLetterController::class, 'create'])->name('care.letters.create');
            Route::post('/visits/{visit}/medical-letters/preview', [MedicalLetterController::class, 'preview'])->name('care.letters.preview');
            Route::post('/visits/{visit}/medical-letters/frame', [MedicalLetterController::class, 'frame'])->name('care.letters.frame');
            Route::post('/visits/{visit}/medical-letters', [MedicalLetterController::class, 'store'])->name('care.letters.store');
            Route::get('/medical-letters', [MedicalLetterController::class, 'index'])->name('medical-letters.index');
            Route::get('/medical-letters/data', [MedicalLetterController::class, 'data'])->name('medical-letters.data');
            Route::get('/medical-letters/{letter}', [MedicalLetterController::class, 'show'])->name('medical-letters.show');
            Route::get('/medical-letters/{letter}/pdf', [MedicalLetterController::class, 'pdf'])->name('medical-letters.pdf');
            Route::post('/medical-letters/{letter}/cancel', [MedicalLetterController::class, 'cancel'])->name('medical-letters.cancel');
            Route::get('/medical-letters/{letter}/revise', [MedicalLetterController::class, 'revise'])->name('medical-letters.revise');
            Route::post('/medical-letters/{letter}/revise', [MedicalLetterController::class, 'reviseStore'])->name('medical-letters.revise.store');
            Route::get('/visits/{visit}/care/resume/pdf', [CareController::class, 'printResume'])->name('care.resume.pdf');
            Route::get('/visits/{visit}/care/documents/{document}/pdf', [CareController::class, 'printDocument'])->name('care.documents.pdf');
            Route::post('/visits/{visit}/care/documents/{document}/cancel', [CareController::class, 'cancelDocument'])->name('care.documents.cancel');
            Route::get('/visits/{visit}/care/referrals/{referral}/pdf', [CareController::class, 'printReferral'])->name('care.referral.pdf');
            Route::get('/visits/{visit}/care/prescriptions/pdf', [CareController::class, 'printPrescriptions'])->name('care.prescriptions.pdf');
            Route::get('/visits/{visit}/care/prescriptions/{prescription}/pdf', [CareController::class, 'printPrescription'])->name('care.prescription.pdf');
            Route::get('/visits/{visit}/care/instructions/pdf', [CareController::class, 'printInstructions'])->name('care.instructions.pdf');
            Route::get('/visits/{visit}/care/discharge/pdf', [CareController::class, 'printDischarge'])->name('care.discharge.pdf');
            Route::post('/visits/{visit}/care/complete', [CareController::class, 'complete'])->name('care.complete');

            Route::get('/pharmacy', [PharmacyDashboardController::class, 'index'])->name('pharmacy.index');
            Route::get('/pharmacy/prescriptions/incoming', [PharmacyPrescriptionController::class, 'incoming'])->name('pharmacy.prescriptions.incoming');
            Route::get('/pharmacy/prescriptions/processing', [PharmacyPrescriptionController::class, 'processing'])->name('pharmacy.prescriptions.processing');
            Route::get('/pharmacy/prescriptions/completed', [PharmacyPrescriptionController::class, 'completed'])->name('pharmacy.prescriptions.completed');
            Route::get('/pharmacy/prescriptions/history', [PharmacyPrescriptionController::class, 'history'])->name('pharmacy.prescriptions.history');
            Route::get('/pharmacy/prescriptions/{prescription}/labels', [PharmacyPrescriptionController::class, 'printLabels'])->name('pharmacy.prescriptions.labels');
            Route::get('/pharmacy/prescriptions/{prescription}/items/{item}/label', [PharmacyPrescriptionController::class, 'printItemLabel'])->name('pharmacy.prescriptions.item-label');
            Route::get('/pharmacy/prescriptions/{prescription}', [PharmacyPrescriptionController::class, 'show'])->name('pharmacy.prescriptions.show');
            Route::post('/pharmacy/prescriptions/{prescription}/fulfill', [PharmacyPrescriptionController::class, 'fulfill'])->name('pharmacy.prescriptions.fulfill');

            Route::get('/pharmacy/stock', [StockController::class, 'index'])->name('pharmacy.stock.index');
            Route::get('/pharmacy/stock/batches', [StockController::class, 'batches'])->name('pharmacy.stock.batches');
            Route::get('/pharmacy/stock/expired', [StockController::class, 'expired'])->name('pharmacy.stock.expired');
            Route::get('/pharmacy/stock/adjustments', [StockController::class, 'adjustments'])->name('pharmacy.stock.adjustments');
            Route::post('/pharmacy/stock/adjustments', [StockController::class, 'storeAdjustment'])->name('pharmacy.stock.adjustments.store');
            Route::get('/pharmacy/stock/card', [StockController::class, 'card'])->name('pharmacy.stock.card');
            Route::get('/pharmacy/stock/card/{medicine}', [StockController::class, 'cardShow'])->name('pharmacy.stock.card.show');
            Route::get('/pharmacy/stock/opname', [StockController::class, 'opname'])->name('pharmacy.stock.opname');
            Route::post('/pharmacy/stock/opname', [StockController::class, 'storeOpname'])->name('pharmacy.stock.opname.store');
            Route::get('/pharmacy/stock/returns', [StockController::class, 'returns'])->name('pharmacy.stock.returns');
            Route::post('/pharmacy/stock/returns', [StockController::class, 'storeReturn'])->name('pharmacy.stock.returns.store');
            Route::get('/pharmacy/lab', [DentalLabController::class, 'index'])->name('pharmacy.lab.index');
            Route::put('/pharmacy/lab/{order}', [DentalLabController::class, 'update'])->name('pharmacy.lab.update');

            Route::get('/pharmacy/purchases/suppliers', [SupplierController::class, 'index'])->name('pharmacy.purchases.suppliers');
            Route::get('/pharmacy/purchases/suppliers/create', [SupplierController::class, 'create'])->name('pharmacy.suppliers.create');
            Route::post('/pharmacy/purchases/suppliers', [SupplierController::class, 'store'])->name('pharmacy.suppliers.store');
            Route::get('/pharmacy/purchases/suppliers/{supplier}/edit', [SupplierController::class, 'edit'])->name('pharmacy.suppliers.edit');
            Route::put('/pharmacy/purchases/suppliers/{supplier}', [SupplierController::class, 'update'])->name('pharmacy.suppliers.update');
            Route::delete('/pharmacy/purchases/suppliers/{supplier}', [SupplierController::class, 'destroy'])->name('pharmacy.suppliers.destroy');

            Route::get('/pharmacy/purchases/orders', [PurchaseOrderController::class, 'index'])->name('pharmacy.purchases.orders');
            Route::get('/pharmacy/purchases/orders/create', [PurchaseOrderController::class, 'create'])->name('pharmacy.orders.create');
            Route::post('/pharmacy/purchases/orders', [PurchaseOrderController::class, 'store'])->name('pharmacy.orders.store');
            Route::get('/pharmacy/purchases/orders/{purchaseOrder}', [PurchaseOrderController::class, 'show'])->name('pharmacy.orders.show');
            Route::post('/pharmacy/purchases/orders/{purchaseOrder}/submit', [PurchaseOrderController::class, 'submit'])->name('pharmacy.orders.submit');
            Route::get('/pharmacy/purchases/orders/{purchaseOrder}/receive', [PurchaseOrderController::class, 'receiveForm'])->name('pharmacy.orders.receive');
            Route::post('/pharmacy/purchases/orders/{purchaseOrder}/receive', [PurchaseOrderController::class, 'receive'])->name('pharmacy.orders.receive.store');
            Route::get('/pharmacy/purchases/receipts', [PurchaseOrderController::class, 'receipts'])->name('pharmacy.purchases.receipts');

            Route::get('/pharmacy/transactions', [PharmacyReportController::class, 'transactions'])->name('pharmacy.transactions');
            Route::get('/pharmacy/reports', [PharmacyReportController::class, 'landing'])->name('pharmacy.reports');
            Route::get('/pharmacy/reports/stock', [PharmacyReportController::class, 'stock'])->name('pharmacy.reports.stock');
            Route::get('/pharmacy/reports/outgoing', [PharmacyReportController::class, 'outgoing'])->name('pharmacy.reports.outgoing');
            Route::get('/pharmacy/reports/incoming', [PharmacyReportController::class, 'incoming'])->name('pharmacy.reports.incoming');
            Route::get('/pharmacy/reports/expired', [PharmacyReportController::class, 'expired'])->name('pharmacy.reports.expired');
            Route::get('/reports/pharmacy', [PharmacyReportController::class, 'landing'])->name('reports.pharmacy');

            Route::get('/reports', [ReportController::class, 'index'])->name('reports.index');
            Route::get('/reports/visits', [ReportController::class, 'visits'])->name('reports.visits');
            Route::get('/reports/revenue', [ReportController::class, 'revenue'])->name('reports.revenue');
            Route::get('/reports/procedures', [ReportController::class, 'procedures'])->name('reports.procedures');
            Route::get('/reports/patients', [ReportController::class, 'patients'])->name('reports.patients');
            Route::get('/reports/personal', [ReportController::class, 'personal'])->name('reports.personal');
            Route::get('/reports/operational', [ReportController::class, 'operational'])->name('reports.operational');
            Route::get('/reports/medical', [ReportController::class, 'medical'])->name('reports.medical');
            Route::get('/reports/finance', [ReportController::class, 'finance'])->name('reports.finance');

            Route::get('/billing', [BillingDashboardController::class, 'index'])->name('billing.index');
            Route::get('/billing/invoices', [InvoiceController::class, 'index'])->name('billing.invoices');
            Route::get('/billing/invoices/today', [InvoiceController::class, 'today'])->name('billing.invoices.today');
            Route::get('/billing/invoices/search', [InvoiceController::class, 'search'])->name('billing.invoices.search');
            Route::get('/billing/invoices/today-patients', [InvoiceController::class, 'todayPatients'])->name('billing.invoices.today-patients');
            Route::get('/billing/history', [InvoiceController::class, 'history'])->name('billing.history');
            Route::post('/billing/invoices/generate', [InvoiceController::class, 'generate'])->name('billing.invoices.generate');
            Route::get('/billing/invoices/{invoice}/print', [InvoiceController::class, 'print'])->name('billing.invoices.print');
            Route::get('/billing/invoices/{invoice}/receipt', [InvoiceController::class, 'receipt'])->name('billing.invoices.receipt');
            Route::get('/billing/invoices/{invoice}', [InvoiceController::class, 'show'])->name('billing.invoices.show');
            Route::post('/billing/invoices/{invoice}/confirm', [InvoiceController::class, 'confirm'])->name('billing.invoices.confirm');
            Route::post('/billing/invoices/{invoice}/medicines/{prescriptionItem}/decline', [InvoiceController::class, 'declineMedicine'])->name('billing.invoices.medicines.decline');
            Route::post('/billing/invoices/{invoice}/pay', [InvoiceController::class, 'pay'])->name('billing.invoices.pay');
            Route::post('/billing/invoices/{invoice}/refund', [InvoiceController::class, 'refund'])->name('billing.invoices.refund');
            Route::post('/billing/invoices/{invoice}/void', [InvoiceController::class, 'void'])->name('billing.invoices.void');
            Route::get('/billing/payments', [PaymentController::class, 'index'])->name('billing.payments');
            Route::post('/billing/payments', [PaymentController::class, 'store'])->name('billing.payments.store');
            Route::get('/billing/receivables', [PaymentController::class, 'receivables'])->name('billing.receivables');

            Route::get('/cashier/shifts/open', [CashShiftController::class, 'openForm'])->name('cashier.shifts.open');
            Route::post('/cashier/shifts/open', [CashShiftController::class, 'open'])->name('cashier.shifts.open.store');
            Route::get('/cashier/shifts/transactions', [CashShiftController::class, 'transactions'])->name('cashier.shifts.transactions');
            Route::get('/cashier/shifts/close', [CashShiftController::class, 'closeForm'])->name('cashier.shifts.close');
            Route::post('/cashier/shifts/close', [CashShiftController::class, 'close'])->name('cashier.shifts.close.store');
            Route::get('/cashier/reports', [CashShiftController::class, 'reports'])->name('cashier.reports');

            Route::get('/finance', [FinanceDashboardController::class, 'index'])->name('finance.index');
            Route::get('/finance/revenue/daily', [RevenueController::class, 'daily'])->name('finance.revenue.daily');
            Route::get('/finance/revenue/monthly', [RevenueController::class, 'monthly'])->name('finance.revenue.monthly');
            Route::get('/finance/revenue/doctors', [RevenueController::class, 'doctors'])->name('finance.revenue.doctors');
            Route::get('/finance/expenses', [ExpenseController::class, 'index'])->name('finance.expenses');
            Route::post('/finance/expenses', [ExpenseController::class, 'store'])->name('finance.expenses.store');
            Route::get('/finance/expenses/categories', [ExpenseCategoryController::class, 'index'])->name('finance.expenses.categories');
            Route::post('/finance/expenses/categories', [ExpenseCategoryController::class, 'store'])->name('finance.expenses.categories.store');
            Route::put('/finance/expenses/categories/{expenseCategory}', [ExpenseCategoryController::class, 'update'])->name('finance.expenses.categories.update');
            Route::delete('/finance/expenses/categories/{expenseCategory}', [ExpenseCategoryController::class, 'destroy'])->name('finance.expenses.categories.destroy');
            Route::get('/finance/expenses/suppliers', [ExpenseController::class, 'suppliers'])->name('finance.expenses.suppliers');
            Route::get('/finance/sharing-fees/rules', [SharingFeeRuleController::class, 'index'])->name('finance.sharing-fees.rules.index');
            Route::get('/finance/sharing-fees/rules/create', [SharingFeeRuleController::class, 'create'])->name('finance.sharing-fees.rules.create');
            Route::post('/finance/sharing-fees/rules/preview', [SharingFeeRuleController::class, 'preview'])->name('finance.sharing-fees.rules.preview');
            Route::post('/finance/sharing-fees/rules', [SharingFeeRuleController::class, 'store'])->name('finance.sharing-fees.rules.store');
            Route::get('/finance/sharing-fees/rules/{sharingFeeRule}/edit', [SharingFeeRuleController::class, 'edit'])->name('finance.sharing-fees.rules.edit');
            Route::put('/finance/sharing-fees/rules/{sharingFeeRule}', [SharingFeeRuleController::class, 'update'])->name('finance.sharing-fees.rules.update');
            Route::delete('/finance/sharing-fees/rules/{sharingFeeRule}', [SharingFeeRuleController::class, 'destroy'])->name('finance.sharing-fees.rules.destroy');
            Route::get('/finance/sharing-fees/settlements', [SharingFeeSettlementController::class, 'index'])->name('finance.sharing-fees.settlements.index');
            Route::post('/finance/sharing-fees/settlements', [SharingFeeSettlementController::class, 'store'])->name('finance.sharing-fees.settlements.store');
            Route::get('/finance/sharing-fees/settlements/{sharingFeeSettlement}', [SharingFeeSettlementController::class, 'show'])->name('finance.sharing-fees.settlements.show');
            Route::post('/finance/sharing-fees/settlements/{sharingFeeSettlement}/approve', [SharingFeeSettlementController::class, 'approve'])->name('finance.sharing-fees.settlements.approve');
            Route::post('/finance/sharing-fees/settlements/{sharingFeeSettlement}/pay', [SharingFeeSettlementController::class, 'pay'])->name('finance.sharing-fees.settlements.pay');
            Route::post('/finance/sharing-fees/settlements/{sharingFeeSettlement}/adjust', [SharingFeeSettlementController::class, 'adjust'])->name('finance.sharing-fees.settlements.adjust');
            Route::get('/finance/sharing-fees/reports/doctors', [SharingFeeReportController::class, 'doctors'])->name('finance.sharing-fees.reports.doctors');
            Route::get('/finance/doctor-fee-waivers/settings', [DoctorFeeWaiverSettingController::class, 'index'])->name('finance.doctor-fee-waivers.settings.index');
            Route::get('/finance/doctor-fee-waivers/settings/create', [DoctorFeeWaiverSettingController::class, 'create'])->name('finance.doctor-fee-waivers.settings.create');
            Route::post('/finance/doctor-fee-waivers/settings', [DoctorFeeWaiverSettingController::class, 'store'])->name('finance.doctor-fee-waivers.settings.store');
            Route::get('/finance/doctor-fee-waivers/settings/{doctorFeeWaiverSetting}/edit', [DoctorFeeWaiverSettingController::class, 'edit'])->name('finance.doctor-fee-waivers.settings.edit');
            Route::put('/finance/doctor-fee-waivers/settings/{doctorFeeWaiverSetting}', [DoctorFeeWaiverSettingController::class, 'update'])->name('finance.doctor-fee-waivers.settings.update');
            Route::delete('/finance/doctor-fee-waivers/settings/{doctorFeeWaiverSetting}', [DoctorFeeWaiverSettingController::class, 'destroy'])->name('finance.doctor-fee-waivers.settings.destroy');
            Route::get('/finance/doctor-fee-waivers/logs', [DoctorFeeWaiverLogController::class, 'index'])->name('finance.doctor-fee-waivers.logs.index');
            Route::post('/finance/doctor-fee-waivers/logs/{doctorFeeWaiverLog}/approve', [DoctorFeeWaiverLogController::class, 'approve'])->name('finance.doctor-fee-waivers.logs.approve');
            Route::get('/finance/receivables', [ReceivableController::class, 'index'])->name('finance.receivables');
            Route::get('/finance/payables', [PayableController::class, 'index'])->name('finance.payables');
            Route::post('/finance/payables/{purchaseOrder}/pay', [PayableController::class, 'pay'])->name('finance.payables.pay');
            Route::get('/finance/cash-bank', [CashBankController::class, 'index'])->name('finance.cash-bank');
            Route::get('/finance/reports/revenue', [FinanceReportController::class, 'revenue'])->name('finance.reports.revenue');
            Route::get('/finance/reports/expenses', [FinanceReportController::class, 'expenses'])->name('finance.reports.expenses');
            Route::get('/finance/reports/cashflow', [FinanceReportController::class, 'cashflow'])->name('finance.reports.cashflow');
            Route::get('/finance/reports/receivables', [FinanceReportController::class, 'receivables'])->name('finance.reports.receivables');
            Route::get('/finance/reports/profit-loss', [FinanceReportController::class, 'profitLoss'])->name('finance.reports.profit-loss');

            Route::get('/settings/clinic', [ClinicSettingController::class, 'index'])
                ->middleware('permission:setting.view')
                ->name('settings.clinic');
            Route::put('/settings/clinic', [ClinicSettingController::class, 'update'])
                ->middleware('permission:setting.manage')
                ->name('settings.clinic.update');
            Route::get('/archive', [PracticeArchiveController::class, 'index'])->name('archive.index');
            Route::post('/archive', [PracticeArchiveController::class, 'store'])->name('archive.store');
            Route::get('/archive/{archive}', [PracticeArchiveController::class, 'download'])->name('archive.download');

            Route::get('/subscription', [PlanController::class, 'index'])
                ->middleware('permission:plan.view')
                ->name('subscription.index');
            Route::post('/subscription/packages/{saasPackage}', [PlanController::class, 'subscribe'])
                ->middleware('permission:plan.subscribe')
                ->name('subscription.subscribe');
            Route::get('/subscription/invoices', [PlanController::class, 'invoices'])
                ->middleware('permission:plan.view')
                ->name('subscription.invoices');
            Route::post('/subscription/invoices/{saasInvoice}/pay', [PlanController::class, 'pay'])
                ->middleware('permission:plan.pay')
                ->name('subscription.invoices.pay');
            Route::get('/subscription/invoices/{saasInvoice}/checkout', [PlanController::class, 'checkout'])
                ->middleware('permission:plan.pay')
                ->name('subscription.invoices.checkout');
            Route::get('/subscription/invoices/midtrans/finish', [PlanController::class, 'finish'])
                ->middleware('permission:plan.view')
                ->name('subscription.invoices.finish');

            Route::get('/addons', [AddonMarketplaceController::class, 'index'])
                ->middleware('permission:addon.view')
                ->name('addons.index');
            Route::get('/addons/invoices/midtrans/finish', [AddonMarketplaceController::class, 'finish'])
                ->middleware('permission:addon.view')
                ->name('addons.invoices.finish');
            Route::get('/addons/invoices/{saasAddonInvoice}/checkout', [AddonMarketplaceController::class, 'checkout'])
                ->middleware('permission:addon.view')
                ->name('addons.checkout');
            Route::get('/addons/{saasAddon:code}', [AddonMarketplaceController::class, 'show'])
                ->middleware('permission:addon.view')
                ->name('addons.show');
            Route::post('/addons/{saasAddon:code}/activate', [AddonMarketplaceController::class, 'activate'])
                ->middleware('permission:addon.view')
                ->name('addons.activate');
            Route::post('/addons/{saasAddon:code}/pay', [AddonMarketplaceController::class, 'pay'])
                ->middleware('permission:addon.view')
                ->name('addons.pay');

            Route::get('/integrations', [IntegrationController::class, 'index'])
                ->name('integrations.index');
            Route::get('/integrations/satusehat', [IntegrationController::class, 'satusehat'])
                ->middleware('permission:satusehat.view')
                ->name('integrations.satusehat');
            Route::get('/integrations/satusehat/logs', [IntegrationController::class, 'satusehatLogs'])
                ->middleware('permission:satusehat.view')
                ->name('integrations.satusehat.logs');
            Route::get('/integrations/satusehat/logs/{log}', [IntegrationController::class, 'satusehatLogShow'])
                ->middleware('permission:satusehat.view')
                ->name('integrations.satusehat.logs.show');
            Route::get('/integrations/satusehat/visits/{visit}/logs', [IntegrationController::class, 'satusehatVisitLogs'])
                ->middleware('permission:satusehat.view')
                ->name('integrations.satusehat.visits.logs');
            Route::put('/integrations/satusehat', [IntegrationController::class, 'updateSatuSehat'])
                ->middleware('permission:integration.manage')
                ->name('integrations.satusehat.update');
            Route::post('/integrations/satusehat/test', [IntegrationController::class, 'testSatuSehat'])
                ->middleware('permission:integration.manage')
                ->name('integrations.satusehat.test');
            Route::put('/integrations/satusehat/location', [IntegrationController::class, 'updateSatuSehatLocation'])
                ->middleware('permission:integration.manage')
                ->name('integrations.satusehat.location');
            Route::post('/integrations/satusehat', [IntegrationController::class, 'sendSatuSehat'])
                ->middleware('permission:satusehat.view')
                ->name('integrations.satusehat.send');
            Route::post('/visits/{visit}/satusehat', [IntegrationController::class, 'sendSatuSehat'])
                ->middleware('permission:satusehat.view')
                ->name('care.satusehat.send');
            Route::get('/integrations/bpjs', [IntegrationController::class, 'bpjs'])
                ->middleware('permission:bpjs.view')
                ->name('integrations.bpjs');
            Route::put('/integrations/bpjs', [IntegrationController::class, 'updateBpjs'])
                ->middleware('permission:integration.manage')
                ->name('integrations.bpjs.update');
            Route::post('/integrations/bpjs', [IntegrationController::class, 'checkBpjs'])
                ->middleware('permission:bpjs.view')
                ->name('integrations.bpjs.check');
            Route::post('/registration/patients/{patient}/bpjs', [IntegrationController::class, 'checkBpjs'])
                ->middleware('permission:bpjs.view')
                ->name('registration.patients.bpjs');
            Route::post('/integrations/claims', [IntegrationController::class, 'storeClaim'])
                ->middleware('permission:integration.manage')
                ->name('integrations.claims.store');
            Route::get('/integrations/claims/{insuranceClaim}/download', [IntegrationController::class, 'downloadClaim'])
                ->middleware('permission:integration.view')
                ->name('integrations.claims.download');

            Route::prefix('whatsapp')->name('whatsapp.')->middleware('addon:whatsapp')->group(function () {
                Route::get('/', [WhatsAppDashboardController::class, 'index'])
                    ->middleware('permission:whatsapp.view')
                    ->name('dashboard');
                Route::get('/saldo', [WhatsAppBalanceController::class, 'index'])
                    ->middleware('permission:whatsapp.view')
                    ->name('balance');
                Route::post('/saldo', [WhatsAppBalanceController::class, 'store'])
                    ->middleware('permission:whatsapp.settings.manage')
                    ->name('balance.topup');
                Route::post('/saldo/cek', [WhatsAppBalanceController::class, 'check'])
                    ->middleware('permission:whatsapp.view')
                    ->name('balance.check');
                Route::get('/pengingat', [WhatsAppReminderController::class, 'index'])
                    ->middleware('permission:whatsapp.automation.view')
                    ->name('reminders');
                Route::put('/pengingat', [WhatsAppReminderController::class, 'update'])
                    ->middleware('permission:whatsapp.automation.manage')
                    ->name('reminders.update');
                Route::post('/pengingat/preset', [WhatsAppReminderController::class, 'activatePreset'])
                    ->middleware('permission:whatsapp.automation.manage')
                    ->name('reminders.preset');
                Route::get('/promosi', [WhatsAppPromotionController::class, 'index'])
                    ->middleware('permission:whatsapp.promotions.view')
                    ->name('promotions.index');
                Route::get('/promosi/baru', [WhatsAppPromotionController::class, 'create'])
                    ->middleware('permission:whatsapp.promotions.manage')
                    ->name('promotions.create');
                Route::post('/promosi', [WhatsAppPromotionController::class, 'store'])
                    ->middleware('permission:whatsapp.promotions.manage')
                    ->name('promotions.store');
                Route::get('/promosi/{whatsappPromotion}/edit', [WhatsAppPromotionController::class, 'edit'])
                    ->middleware('permission:whatsapp.promotions.manage')
                    ->name('promotions.edit');
                Route::put('/promosi/{whatsappPromotion}', [WhatsAppPromotionController::class, 'update'])
                    ->middleware('permission:whatsapp.promotions.manage')
                    ->name('promotions.update');
                Route::post('/promosi/{whatsappPromotion}/kirim', [WhatsAppPromotionController::class, 'send'])
                    ->middleware('permission:whatsapp.promotions.manage')
                    ->name('promotions.send');
                Route::get('/template', [WhatsAppTemplateController::class, 'index'])
                    ->middleware('permission:whatsapp.templates.view')
                    ->name('templates.index');
                Route::get('/template/remote', [WhatsAppTemplateController::class, 'remoteIndex'])
                    ->middleware('permission:whatsapp.templates.view')
                    ->name('templates.remote.index');
                Route::get('/template/remote/{name}', [WhatsAppTemplateController::class, 'remoteShow'])
                    ->middleware('permission:whatsapp.templates.view')
                    ->name('templates.remote.show');
                Route::get('/template/{whatsappTemplate}/edit', [WhatsAppTemplateController::class, 'edit'])
                    ->middleware('permission:whatsapp.templates.view')
                    ->name('templates.edit');
                Route::put('/template/{whatsappTemplate}', [WhatsAppTemplateController::class, 'update'])
                    ->middleware('permission:whatsapp.templates.manage')
                    ->name('templates.update');
                Route::post('/template/{whatsappTemplate}/sync', [WhatsAppTemplateController::class, 'sync'])
                    ->middleware('permission:whatsapp.templates.manage')
                    ->name('templates.sync');
                Route::post('/template/{whatsappTemplate}/status', [WhatsAppTemplateController::class, 'refreshStatus'])
                    ->middleware('permission:whatsapp.templates.manage')
                    ->name('templates.status');
                Route::get('/template/{whatsappTemplate}/ajukan', [WhatsAppTemplateController::class, 'create'])
                    ->middleware('permission:whatsapp.templates.manage')
                    ->name('templates.create');
                Route::post('/template/{whatsappTemplate}/ajukan', [WhatsAppTemplateController::class, 'store'])
                    ->middleware('permission:whatsapp.templates.manage')
                    ->name('templates.store');
                Route::post('/template/{whatsappTemplate}/tes', [WhatsAppTemplateController::class, 'testSend'])
                    ->middleware('permission:whatsapp.templates.manage')
                    ->name('templates.test');
                Route::get('/riwayat', [WhatsAppLogController::class, 'index'])
                    ->middleware('permission:whatsapp.logs.view')
                    ->name('logs.index');
                Route::get('/riwayat/{whatsappLog}', [WhatsAppLogController::class, 'show'])
                    ->middleware('permission:whatsapp.logs.view')
                    ->name('logs.show');
                Route::get('/pengaturan', [WhatsAppSettingController::class, 'index'])
                    ->middleware('permission:whatsapp.view')
                    ->name('settings');
                Route::put('/pengaturan', [WhatsAppSettingController::class, 'update'])
                    ->middleware('permission:whatsapp.settings.manage')
                    ->name('settings.update');
            });
        });

        Route::post('/impersonate/leave', [UserController::class, 'leaveImpersonate'])
            ->name('impersonate.leave');

        Route::get('/roles/data', [RoleController::class, 'data'])
            ->middleware('permission:roles.view')
            ->name('roles.data');
        Route::resource('roles', RoleController::class);

        Route::get('/menus/data', [MenuController::class, 'data'])
            ->middleware('permission:menus.view')
            ->name('menus.data');
        Route::post('/menus/{menu}/toggle-status', [MenuController::class, 'toggleStatus'])
            ->middleware('permission:menus.edit')
            ->name('menus.toggle-status');
        Route::resource('menus', MenuController::class)->except(['show']);

        Route::middleware('permission:settings.update')->group(function () {
            Route::get('/settings', [SettingController::class, 'index'])->name('settings.index');
            Route::put('/settings', [SettingController::class, 'update'])->name('settings.update');
            Route::post('/settings/test-email', [SettingController::class, 'testEmail'])->name('settings.test-email');
        });

        Route::get('/logs/data', [ActivityLogController::class, 'data'])
            ->middleware('permission:logs.view')
            ->name('logs.data');
        Route::post('/logs/clear', [ActivityLogController::class, 'destroyAll'])
            ->middleware('permission:logs.delete')
            ->name('logs.clear');
        Route::get('/logs', [ActivityLogController::class, 'index'])
            ->middleware('permission:logs.view')
            ->name('logs.index');
        Route::get('/logs/{activityLog}', [ActivityLogController::class, 'show'])
            ->middleware('permission:logs.view')
            ->name('logs.show');
        Route::delete('/logs/{activityLog}', [ActivityLogController::class, 'destroy'])
            ->middleware('permission:logs.delete')
            ->name('logs.destroy');

        Route::middleware('permission:saas.access')->prefix('saas')->name('saas.')->group(function () {
            Route::get('tenants/data', [TenantController::class, 'data'])
                ->middleware('permission:tenant.view')
                ->name('tenants.data');
            Route::post('tenants/{tenant}/status', [TenantController::class, 'toggleStatus'])
                ->middleware('permission:tenant.manage')
                ->name('tenants.status');
            Route::resource('tenants', TenantController::class);

            Route::get('packages', [PackageController::class, 'index'])->middleware('permission:package.view')->name('packages.index');
            Route::post('packages', [PackageController::class, 'store'])->middleware('permission:package.manage')->name('packages.store');
            Route::put('packages/{saasPackage}', [PackageController::class, 'update'])->middleware('permission:package.manage')->name('packages.update');
            Route::post('packages/{saasPackage}/status', [PackageController::class, 'toggleStatus'])->middleware('permission:package.manage')->name('packages.status');
            Route::delete('packages/{saasPackage}', [PackageController::class, 'destroy'])->middleware('permission:package.manage')->name('packages.destroy');

            Route::get('subscriptions', [SubscriptionController::class, 'index'])->middleware('permission:subscription.view')->name('subscriptions.index');
            Route::post('subscriptions', [SubscriptionController::class, 'store'])->middleware('permission:subscription.manage')->name('subscriptions.store');

            Route::get('invoices', [SaasInvoiceController::class, 'index'])->middleware('permission:invoice.view')->name('invoices.index');
            Route::post('invoices/{saasInvoice}/pay', [SaasInvoiceController::class, 'pay'])->middleware('permission:subscription.manage')->name('invoices.pay');

            Route::get('system/integrations', [PlatformOpsController::class, 'integrations'])->middleware('permission:saas.integration.view')->name('system.integrations');
            Route::get('system/audit', [PlatformOpsController::class, 'audit'])->middleware('permission:saas.audit.view')->name('system.audit');
            Route::get('users/activity/data', [PlatformOpsController::class, 'userActivityData'])->middleware('permission:saas.activity.view')->name('users.activity.data');
            Route::get('users/activity', [PlatformOpsController::class, 'userActivity'])->middleware('permission:saas.activity.view')->name('users.activity');

            Route::get('payment-gateway', [PaymentGatewayController::class, 'index'])->middleware('permission:payment_gateway.view')->name('payment-gateway.index');
            Route::put('payment-gateway', [PaymentGatewayController::class, 'update'])->middleware('permission:payment_gateway.manage')->name('payment-gateway.update');

            Route::get('addons', [SaasAddonController::class, 'index'])->middleware('permission:addon.manage')->name('addons.index');
            Route::post('addons', [SaasAddonController::class, 'store'])->middleware('permission:addon.manage')->name('addons.store');
            Route::put('addons/{saasAddon}', [SaasAddonController::class, 'update'])->middleware('permission:addon.manage')->name('addons.update');
            Route::post('addons/{saasAddon}/status', [SaasAddonController::class, 'toggleStatus'])->middleware('permission:addon.manage')->name('addons.status');

            Route::get('addon-subscriptions', [SaasAddonSubscriptionController::class, 'index'])->middleware('permission:addon.manage')->name('addon-subscriptions.index');
            Route::post('addon-subscriptions/ensure', [SaasAddonSubscriptionController::class, 'ensure'])->middleware('permission:addon.manage')->name('addon-subscriptions.ensure');
            Route::post('addon-subscriptions/{saasAddonSubscription}/activate', [SaasAddonSubscriptionController::class, 'activate'])->middleware('permission:addon.manage')->name('addon-subscriptions.activate');
            Route::post('addon-subscriptions/{saasAddonSubscription}/suspend', [SaasAddonSubscriptionController::class, 'suspend'])->middleware('permission:addon.manage')->name('addon-subscriptions.suspend');
            Route::post('addon-subscriptions/{saasAddonSubscription}/revoke', [SaasAddonSubscriptionController::class, 'revoke'])->middleware('permission:addon.manage')->name('addon-subscriptions.revoke');
            Route::put('addon-subscriptions/{saasAddonSubscription}/extend', [SaasAddonSubscriptionController::class, 'extend'])->middleware('permission:addon.manage')->name('addon-subscriptions.extend');
        });

        Route::middleware('permission:cms.view')->prefix('cms')->name('cms.')->group(function () {
            Route::get('/', [CmsDashboardController::class, 'index'])->name('dashboard');
            Route::get('posts', [CmsPostController::class, 'index'])->name('posts.index');
            Route::get('posts/data', [CmsPostController::class, 'data'])->name('posts.data');
            Route::post('posts/bulk-status', [CmsPostController::class, 'bulkStatus'])->middleware('permission:cms.manage')->name('posts.bulk-status');
            Route::get('posts/create', [CmsPostController::class, 'create'])->middleware('permission:cms.manage')->name('posts.create');
            Route::post('posts', [CmsPostController::class, 'store'])->middleware('permission:cms.manage')->name('posts.store');
            Route::get('posts/{post}/edit', [CmsPostController::class, 'edit'])->name('posts.edit');
            Route::get('posts/{post}/preview', [CmsPostController::class, 'preview'])->name('posts.preview');
            Route::put('posts/{post}', [CmsPostController::class, 'update'])->middleware('permission:cms.manage')->name('posts.update');
            Route::delete('posts/{post}', [CmsPostController::class, 'destroy'])->middleware('permission:cms.manage')->name('posts.destroy');
            Route::post('posts/{post}/duplicate', [CmsPostController::class, 'duplicate'])->middleware('permission:cms.manage')->name('posts.duplicate');
            Route::post('posts/{post}/revisions/{revision}/restore', [CmsPostController::class, 'restoreRevision'])->middleware('permission:cms.manage')->name('posts.revisions.restore');

            Route::get('categories', [TaxonomyController::class, 'categories'])->name('categories.index');
            Route::post('categories', [TaxonomyController::class, 'storeCategory'])->middleware('permission:cms.manage')->name('categories.store');
            Route::get('tags', [TaxonomyController::class, 'tags'])->name('tags.index');
            Route::post('tags', [TaxonomyController::class, 'storeTag'])->middleware('permission:cms.manage')->name('tags.store');
            Route::get('authors', [TaxonomyController::class, 'authors'])->name('authors.index');
            Route::post('authors', [TaxonomyController::class, 'storeAuthor'])->middleware('permission:cms.manage')->name('authors.store');

            Route::get('media', [CmsMediaController::class, 'index'])->name('media.index');
            Route::post('media', [CmsMediaController::class, 'store'])->middleware('permission:cms.manage')->name('media.store');
            Route::delete('media/{medium}', [CmsMediaController::class, 'destroy'])->middleware('permission:cms.manage')->name('media.destroy');

            Route::get('plans', [ContentPlanController::class, 'index'])->name('plans.index');
            Route::post('plans', [ContentPlanController::class, 'store'])->middleware('permission:cms.manage')->name('plans.store');
            Route::get('keywords', [KeywordController::class, 'index'])->name('keywords.index');
            Route::post('keywords', [KeywordController::class, 'store'])->middleware('permission:cms.manage')->name('keywords.store');

            Route::get('seo-settings', [SeoSettingsController::class, 'edit'])->middleware('permission:seo.manage')->name('seo-settings.edit');
            Route::put('seo-settings', [SeoSettingsController::class, 'update'])->middleware('permission:seo.manage')->name('seo-settings.update');
            Route::get('redirects', [CmsRedirectController::class, 'index'])->middleware('permission:seo.manage')->name('redirects.index');
            Route::post('redirects', [CmsRedirectController::class, 'store'])->middleware('permission:seo.manage')->name('redirects.store');
            Route::delete('redirects/{redirect}', [CmsRedirectController::class, 'destroy'])->middleware('permission:seo.manage')->name('redirects.destroy');
        });

        require __DIR__.'/modules.php';
    });
});
