# Aplikasi Manajemen Apotek & Obat - Klinikdent

```
========================================================================
📦 Aplikasi Manajemen Apotek & Obat - Klinikdent
Kategori     : Kesehatan & Medis
Tech Stack   : Laravel • PHP • MySQL • Bootstrap
Database     : MySQL (.sql) (File: database/db_klinikdent (1).sql)
Sumber Asli  : https://github.com/novaariyanto/KlinikDent (GitHub Open Source)
Stars GitHub : ⭐ 0 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/klinikdent`
     * Untuk Laragon: `C:/laragon/www/klinikdent`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - File SQL ini membuat database `klinikdent` sendiri — tidak perlu membuat
     database manual. Klik tab 'Import', pilih file SQL yang disertakan pada:
     `database/db_klinikdent (1).sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = klinikdent

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/klinikdent

5. AKUN LOGIN DEMO:
   - Repo ini tidak mendokumentasikan akun demo di README-nya.
     Cek README.md repo asli atau tabel `users` di phpMyAdmin;
     JANGAN pakai tebakan umum (admin/admin123 dsb.) — belum tentu benar.

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
