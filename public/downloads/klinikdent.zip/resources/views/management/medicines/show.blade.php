@extends('layouts.app')

@section('title', $medicine->name)

@section('content')
    <x-page-header title="{{ $medicine->name }}" :breadcrumb="['Obat' => route('management.medicines.index'), $medicine->name => null]" />
    <x-alert />
    <div class="row">
        <div class="col-lg-8">
            <x-card title="Detail Obat">
                <x-table>
                    <tbody>
                        <tr><th width="180">Nama</th><td>{{ $medicine->name }}</td></tr>
                        <tr>
                            <th>Kode KFA</th>
                            <td>
                                @if (filled($medicine->kfa_code))
                                    {{ $medicine->kfa_code }}
                                @else
                                    <span class="text-muted">Belum diisi</span>
                                    <span class="badge bg-soft-warning text-warning font-size-11 ms-1">Wajib untuk kirim resep ke SATUSEHAT</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Kekuatan zat aktif</th>
                            <td>
                                @if ($medicine->strengthLabel())
                                    {{ $medicine->strengthLabel() }}
                                @else
                                    <span class="text-muted">Belum diisi</span>
                                    <span class="text-muted small d-block">Dipakai otomatis saat racikan d.t.d (SD).</span>
                                @endif
                            </td>
                        </tr>
                        <tr><th>Satuan kemasan</th><td>{{ $medicine->unitLabel() }}</td></tr>
                        <tr><th>Kategori</th><td>{{ $medicine->categoryLabel() }}</td></tr>
                        <tr><th>Harga Dasar</th><td>Rp {{ number_format((float) $medicine->base_price, 0, ',', '.') }}</td></tr>
                        <tr><th>Margin</th><td>{{ \App\Models\Medicine::MARGIN_TYPES[$medicine->margin_type] ?? $medicine->margin_type }} ({{ $medicine->marginLabel() }})</td></tr>
                        <tr><th>Harga Jual</th><td>Rp {{ number_format((float) $medicine->sell_price, 0, ',', '.') }}</td></tr>
                        <tr>
                            <th>Status</th>
                            <td>
                                <span class="{{ $medicine->is_active ? 'badge bg-success' : 'badge bg-danger' }}">
                                    {{ $medicine->is_active ? 'Aktif' : 'Nonaktif' }}
                                </span>
                            </td>
                        </tr>
                    </tbody>
                </x-table>
                <div class="mt-3 d-flex flex-wrap gap-2">
                    @can('update', $medicine)
                        <x-button href="{{ route('management.medicines.edit', $medicine) }}" icon="bx bx-edit">Edit</x-button>
                    @endcan
                    <x-button href="{{ route('management.medicines.index') }}" variant="secondary">Back</x-button>
                </div>
            </x-card>
        </div>
    </div>
@endsection
