# Sistem Informasi Klinik & Rekam Medis - Simrs Medicca

```
========================================================================
📦 Sistem Informasi Klinik & Rekam Medis - Simrs Medicca
Kategori     : Kesehatan & Medis
Tech Stack   : PHP Native • PHP • MySQL • Bootstrap • AdminLTE
Database     : MySQL (.sql) (File: tpp/tpp.sql)
Sumber Asli  : https://github.com/bitechnoo/SIMRS-MEDICCA (GitHub Open Source)
Stars GitHub : ⭐ 9 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/simrs-medicca`
     * Untuk Laragon: `C:/laragon/www/simrs-medicca`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `simrs_medicca`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `tpp/tpp.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = simrs_medicca

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/simrs-medicca

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
