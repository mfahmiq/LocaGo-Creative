// Global user functions
