<?php
include '../config/database.php';

$bulan = $_GET['bulan'];
$tahun = $_GET['tahun'];

$nama_bulan = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
$bulan_text = $nama_bulan[(int)$bulan];

$kelas_query = mysqli_query($conn, 
    "SELECT DISTINCT s.kelas FROM kunjungan k JOIN siswa s ON k.siswa_id = s.id 
     WHERE MONTH(k.tanggal) = '$bulan' AND YEAR(k.tanggal) = '$tahun' ORDER BY s.kelas"
);

header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="Laporan_UKS_Semua_Kelas_'.$bulan_text.'_'.$tahun.'.xls"');
header('Cache-Control: max-age=0');

echo '<!DOCTYPE html>';
echo '<html><head><meta charset="UTF-8">';
echo '<style>';
echo 'body { font-family: Arial, sans-serif; margin: 20px; }';
echo '.main-title { font-size: 16px; font-weight: bold; text-align: center; color: #1a237e; margin-bottom: 5px; }';
echo '.main-subtitle { font-size: 12px; text-align: center; color: #666; margin-bottom: 20px; }';
echo '.class-title { font-size: 13px; font-weight: bold; background: #1a237e; color: white; padding: 8px 15px; margin: 20px 0 5px 0; }';
echo 'table.data { width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 10px; }';
echo 'table.data th { background: #1a237e; color: white; padding: 8px 5px; border: 1px solid #1a237e; text-align: center; }';
echo 'table.data td { padding: 6px 5px; border: 1px solid #999; }';
echo 'table.data tr:nth-child(even) { background: #f5f5f5; }';
echo '.center { text-align: center; }';
echo '.red { color: #c62828; font-weight: bold; }';
echo '.footer { font-size: 10px; margin-top: 30px; text-align: center; color: #999; }';
echo '.page-break { page-break-before: always; }';
echo '</style></head><body>';

echo '<div class="main-title">📊 LAPORAN KUNJUNGAN UKS - SEMUA KELAS</div>';
echo '<div class="main-subtitle">Periode: ' . $bulan_text . ' ' . $tahun . '</div>';

$first = true;
while($kr = mysqli_fetch_assoc($kelas_query)) {
    $kelas = $kr['kelas'];
    
    if(!$first) echo '<div class="page-break"></div>';
    $first = false;
    
    $query = "SELECT s.nisn, s.nama, s.kelas, s.jenis_kelamin, COUNT(*) as jumlah,
              GROUP_CONCAT(DISTINCT k.diagnosa SEPARATOR ', ') as penyakit
              FROM kunjungan k JOIN siswa s ON k.siswa_id = s.id 
              WHERE s.kelas = '$kelas' AND MONTH(k.tanggal) = '$bulan' AND YEAR(k.tanggal) = '$tahun'
              GROUP BY k.siswa_id ORDER BY jumlah DESC";
    $result = mysqli_query($conn, $query);
    $total = mysqli_num_rows($result);
    
    echo '<div class="class-title">📋 KELAS ' . $kelas . ' | ' . $total . ' siswa</div>';
    
    echo '<table class="data">';
    echo '<thead><tr><th width="5%">No</th><th width="15%">NISN</th><th width="38%">Nama Siswa</th><th width="7%">JK</th><th width="12%">Kunjungan</th><th width="23%">Diagnosa</th></tr></thead><tbody>';
    
    $no = 1;
    if($total > 0) {
        while($d = mysqli_fetch_assoc($result)) {
            echo '<tr>';
            echo '<td class="center">'.$no++.'</td>';
            echo '<td class="center">'.$d['nisn'].'</td>';
            echo '<td>'.$d['nama'].'</td>';
            echo '<td class="center">'.($d['jenis_kelamin']=='L'?'L':'P').'</td>';
            echo '<td class="center" style="'.($d['jumlah']>2?'color:#c62828;font-weight:bold':'').'">'.$d['jumlah'].' kali</td>';
            echo '<td>'.($d['penyakit']?:'-').'</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="6" class="center" style="padding:15px;color:#999;">Tidak ada data</td></tr>';
    }
    echo '</tbody></table>';
}

echo '<div class="footer">Dicetak: ' . date('d/m/Y H:i') . ' | UKS SDN 5 Kota Serang</div>';
echo '</body></html>';
exit;
?>