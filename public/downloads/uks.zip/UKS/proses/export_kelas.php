<?php
include '../config/database.php';

$bulan = $_GET['bulan'];
$tahun = $_GET['tahun'];
$kelas = $_GET['kelas'];

$nama_bulan = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
$bulan_text = $nama_bulan[(int)$bulan];

// Total kunjungan
$total_kelas = mysqli_fetch_assoc(mysqli_query($conn, 
    "SELECT COUNT(*) as total FROM kunjungan k JOIN siswa s ON k.siswa_id = s.id 
     WHERE s.kelas = '$kelas' AND MONTH(k.tanggal) = '$bulan' AND YEAR(k.tanggal) = '$tahun'"
))['total'];

// Data siswa
$query = "SELECT s.nisn, s.nama, s.kelas, s.jenis_kelamin, COUNT(*) as jumlah,
          GROUP_CONCAT(DISTINCT k.diagnosa SEPARATOR ', ') as penyakit
          FROM kunjungan k JOIN siswa s ON k.siswa_id = s.id 
          WHERE s.kelas = '$kelas' AND MONTH(k.tanggal) = '$bulan' AND YEAR(k.tanggal) = '$tahun'
          GROUP BY k.siswa_id ORDER BY jumlah DESC";

$result = mysqli_query($conn, $query);
$total_siswa = mysqli_num_rows($result);

// Hitung JK
$jl = 0; $jp = 0;
$all_data = [];
while($d = mysqli_fetch_assoc($result)) {
    $all_data[] = $d;
    if($d['jenis_kelamin'] == 'L') $jl++; else $jp++;
}

header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="Laporan_UKS_Kelas_'.$kelas.'_'.$bulan_text.'_'.$tahun.'.xls"');
header('Cache-Control: max-age=0');

echo '<!DOCTYPE html>';
echo '<html><head><meta charset="UTF-8">';
echo '<style>';
echo 'body { font-family: Arial, sans-serif; margin: 20px; }';
echo '.title { font-size: 16px; font-weight: bold; text-align: center; color: #1a237e; margin-bottom: 5px; }';
echo '.subtitle { font-size: 12px; text-align: center; color: #666; margin-bottom: 15px; }';
echo '.info { font-size: 11px; margin-bottom: 15px; }';
echo '.info td { padding: 3px 10px; }';
echo 'table.data { width: 100%; border-collapse: collapse; font-size: 11px; }';
echo 'table.data th { background: #1a237e; color: white; padding: 8px 5px; border: 1px solid #1a237e; text-align: center; }';
echo 'table.data td { padding: 6px 5px; border: 1px solid #999; }';
echo 'table.data tr:nth-child(even) { background: #f5f5f5; }';
echo '.center { text-align: center; }';
echo '.red { color: #c62828; font-weight: bold; }';
echo '.summary { background: #e8eaf6; padding: 10px; margin-bottom: 15px; font-size: 11px; border-radius: 5px; }';
echo '.summary b { color: #1a237e; }';
echo '.footer { font-size: 10px; margin-top: 20px; text-align: right; }';
echo '</style>';
echo '</head><body>';

// JUDUL
echo '<div class="title">📊 LAPORAN KUNJUNGAN UKS</div>';
echo '<div class="subtitle">Kelas ' . $kelas . ' | Periode: ' . $bulan_text . ' ' . $tahun . '</div>';

// RINGKASAN
echo '<div class="summary">';
echo '<b>📋 Ringkasan:</b> Total Siswa: <b>' . $total_siswa . '</b> | Total Kunjungan: <b>' . $total_kelas . '</b> | Laki-laki: <b>' . $jl . '</b> | Perempuan: <b>' . $jp . '</b>';
echo '</div>';

// TABEL
echo '<table class="data">';
echo '<thead><tr><th width="5%">No</th><th width="15%">NISN</th><th width="35%">Nama Siswa</th><th width="8%">JK</th><th width="12%">Kunjungan</th><th width="25%">Diagnosa</th></tr></thead>';
echo '<tbody>';

$no = 1;
if(count($all_data) > 0) {
    foreach($all_data as $data) {
        $highlight = $data['jumlah'] > 2 ? 'class="red"' : '';
        echo '<tr>';
        echo '<td class="center">' . $no++ . '</td>';
        echo '<td class="center">' . $data['nisn'] . '</td>';
        echo '<td>' . $data['nama'] . '</td>';
        echo '<td class="center">' . ($data['jenis_kelamin'] == 'L' ? 'L' : 'P') . '</td>';
        echo '<td class="center" ' . $highlight . '>' . $data['jumlah'] . ' kali</td>';
        echo '<td>' . ($data['penyakit'] ?: '-') . '</td>';
        echo '</tr>';
    }
} else {
    echo '<tr><td colspan="6" class="center" style="padding:20px;color:#999;">Tidak ada data kunjungan</td></tr>';
}

echo '</tbody></table>';

// FOOTER
echo '<div class="footer">Dicetak: ' . date('d/m/Y H:i') . ' | UKS SDN 5 Kota Serang</div>';

echo '</body></html>';
exit;
?>