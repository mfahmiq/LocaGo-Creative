<?php
session_start();

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if ($username === 'admin' && $password === 'admin123') {

    $_SESSION['user_id'] = 1;
    $_SESSION['username'] = 'admin';
    $_SESSION['nama_lengkap'] = 'Administrator';
    $_SESSION['role'] = 'Admin';

    echo json_encode([
        'status' => 'success'
    ]);

} else {

    echo json_encode([
        'status' => 'error',
        'message' => 'Username atau Password salah!'
    ]);

}