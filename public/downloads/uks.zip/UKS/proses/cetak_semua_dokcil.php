<?php
include '../config/database.php';

$kelas = $_GET['kelas'];
$where = $kelas != 'semua' ? "AND kelas = '$kelas'" : "";

$query = "SELECT * FROM siswa WHERE dokcil = 'Ya' $where ORDER BY kelas, nama";
$result = mysqli_query($conn, $query);

$today = date('d') . ' ' . date('F') . ' ' . date('Y');
?>
<!DOCTYPE html>
<html>
<head>
    <title>SK Dokcil - Semua</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Times New Roman', serif; padding: 30px; font-size: 13px; }
        .page-break { page-break-after: always; }
        .kop { text-align: center; margin-bottom: 15px; }
        .kop h3 { font-size: 14px; font-weight: bold; text-transform: uppercase; }
        .kop p { font-size: 10px; }
        .garis-tebal { border-top: 2px solid #000; margin: 8px 0; }
        .garis-tipis { border-top: 1px solid #000; }
        .judul { text-align: center; font-size: 14px; font-weight: bold; margin: 15px 0; text-transform: uppercase; text-decoration: underline; }
        .no-sk { text-align: center; font-size: 11px; margin-bottom: 15px; }
        .isi { text-align: justify; margin: 15px 0; font-size: 12px; }
        .identitas table { width: 100%; }
        .identitas td { padding: 2px 5px; font-size: 12px; }
        .identitas td.label { width: 120px; }
        .ttd { margin-top: 30px; display: flex; justify-content: space-between; font-size: 12px; }
        .ttd .kiri { width: 45%; }
        .ttd .kanan { width: 45%; text-align: right; }
        .ttd .nama-ttd { font-weight: bold; margin-top: 50px; text-decoration: underline; }
        @media print { body { padding: 20px; } }
    </style>
</head>
<body>
    <?php 
    $first = true;
    while($d = mysqli_fetch_assoc($result)): 
        if(!$first) echo '<div class="page-break"></div>';
        $first = false;
    ?>
    <div class="kop">
        <h3>PEMERINTAH KOTA SERANG - DINAS PENDIDIKAN</h3>
        <h3>SD NEGERI 5 KOTA SERANG</h3>
        <p>Jl. KH. Abdul Hadi No. 5, Serang, Banten</p>
    </div>
    <div class="garis-tebal"></div><div class="garis-tipis"></div>
    <div class="judul">SURAT KEPUTUSAN DOKTER CILIK</div>
    <div class="no-sk">Nomor: 421.2/____/SDN5-UKS/<?= date('Y') ?></div>
    
    <div class="isi">
        <p>Yang bertanda tangan di bawah ini, Kepala SD Negeri 5 Kota Serang, menetapkan:</p>
        <div class="identitas">
            <table>
                <tr><td class="label">Nama</td><td>: <strong><?= $d['nama'] ?></strong></td></tr>
                <tr><td class="label">NISN</td><td>: <?= $d['nisn'] ?></td></tr>
                <tr><td class="label">Kelas</td><td>: <?= $d['kelas'] ?></td></tr>
                <tr><td class="label">JK</td><td>: <?= $d['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan' ?></td></tr>
            </table>
        </div>
        <p>Sebagai <strong>DOKTER CILIK (DOKCIL)</strong> pada UKS SD Negeri 5 Kota Serang.</p>
    </div>
    
    <div class="ttd">
        <div class="kiri">
            <p>Petugas UKS,</p>
            <p class="nama-ttd"><?= $_SESSION['nama_lengkap'] ?></p>
        </div>
        <div class="kanan">
            <p>Serang, <?= $today ?></p>
            <p>Kepala Sekolah,</p>
            <p class="nama-ttd">.........................</p>
        </div>
    </div>
    <?php endwhile; ?>
    
    <script>window.onload = function() { window.print(); }</script>
</body>
</html>