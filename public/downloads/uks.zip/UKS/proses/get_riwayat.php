<?php
include '../config/database.php';

$siswa_id = (int)$_GET['siswa_id'];

// AMBIL DATA SISWA
$siswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM siswa WHERE id = $siswa_id"));

if(!$siswa) {
    echo '<div class="alert alert-danger">Data siswa tidak ditemukan!</div>';
    exit();
}

// TOTAL KUNJUNGAN
$total = mysqli_fetch_assoc(mysqli_query($conn, 
    "SELECT COUNT(*) as total FROM kunjungan WHERE siswa_id = $siswa_id"
))['total'];

// RIWAYAT PENYAKIT
$penyakit = mysqli_query($conn, 
    "SELECT * FROM riwayat_penyakit WHERE siswa_id = $siswa_id ORDER BY tahun DESC"
);

// KUNJUNGAN (MAX 20)
$kunjungan = mysqli_query($conn, 
    "SELECT k.*, u.nama_lengkap as petugas,
            GROUP_CONCAT(CONCAT(o.nama_obat, ' (', ko.jumlah, ')') SEPARATOR ', ') as obat_list
     FROM kunjungan k 
     LEFT JOIN users u ON k.petugas_id = u.id 
     LEFT JOIN kunjungan_obat ko ON k.id = ko.kunjungan_id
     LEFT JOIN obat o ON ko.obat_id = o.id
     WHERE k.siswa_id = $siswa_id 
     GROUP BY k.id
     ORDER BY k.tanggal DESC, k.created_at DESC 
     LIMIT 20"
);

// KUNJUNGAN BERULANG
$minggu = mysqli_query($conn, 
    "SELECT WEEK(tanggal) as minggu, YEAR(tanggal) as tahun, COUNT(*) as jumlah,
            GROUP_CONCAT(DATE_FORMAT(tanggal, '%d/%m/%Y') SEPARATOR ', ') as tgl_kunjungan
     FROM kunjungan 
     WHERE siswa_id = $siswa_id 
     GROUP BY YEAR(tanggal), WEEK(tanggal) 
     HAVING jumlah > 1 
     ORDER BY tahun DESC, minggu DESC 
     LIMIT 10"
);
?>

<style>
    .riwayat-card {
        background: white;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    }
    .riwayat-header {
        background: linear-gradient(135deg, #667eea, #764ba2);
        padding: 30px;
        text-align: center;
        color: white;
    }
    .riwayat-avatar {
        font-size: 70px;
        margin-bottom: 10px;
    }
    .riwayat-nama {
        font-size: 1.5rem;
        font-weight: 700;
        margin: 0;
    }
    .riwayat-info {
        color: rgba(255,255,255,0.8);
        margin: 5px 0 0;
        font-size: 0.9rem;
    }
    .riwayat-body {
        padding: 25px;
    }
    .stat-mini {
        background: #f0f4ff;
        padding: 15px;
        border-radius: 12px;
        text-align: center;
    }
    .stat-mini .value {
        font-size: 1.8rem;
        font-weight: 700;
        color: #667eea;
    }
    .stat-mini .label {
        font-size: 0.8rem;
        color: #666;
    }
    .alert-warning-custom {
        background: #FFF3CD;
        border: 1px solid #FFC107;
        border-radius: 10px;
        padding: 12px;
        margin-bottom: 20px;
        font-size: 0.9rem;
    }
    .table-riwayat {
        width: 100%;
        font-size: 0.85rem;
        border-collapse: collapse;
    }
    .table-riwayat th {
        background: #f0f0f0;
        padding: 10px;
        border: 1px solid #ddd;
        text-align: left;
        font-weight: 700;
        color: #333;
    }
    .table-riwayat td {
        padding: 10px;
        border: 1px solid #ddd;
        vertical-align: top;
    }
    .table-riwayat tr:hover td {
        background: #f8f9ff;
    }
    .section-title {
        color: #667eea;
        font-weight: 700;
        margin: 25px 0 15px;
        padding-bottom: 8px;
        border-bottom: 2px solid #667eea;
        display: inline-block;
    }
    .badge-diagnosa {
        background: #FFF3CD;
        color: #856404;
        padding: 3px 10px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 600;
    }
    .table-scroll {
        max-height: 400px;
        overflow-y: auto;
    }
    .table-scroll thead th {
        position: sticky;
        top: 0;
        z-index: 1;
    }
</style>

<div class="riwayat-card">
    <!-- HEADER -->
    <div class="riwayat-header">
        <div class="riwayat-avatar"><?= $siswa['jenis_kelamin'] == 'L' ? '👦' : '👧' ?></div>
        <h4 class="riwayat-nama"><?= htmlspecialchars($siswa['nama']) ?></h4>
        <p class="riwayat-info">Kelas <?= $siswa['kelas'] ?> | NISN: <?= $siswa['nisn'] ?></p>
        <?php if($siswa['dokcil'] == 'Ya'): ?>
        <span style="background:#FFD700;color:#333;padding:3px 12px;border-radius:20px;font-size:0.8rem;font-weight:600;display:inline-block;margin-top:8px;">🩺 Dokter Cilik</span>
        <?php endif; ?>
    </div>
    
    <!-- BODY -->
    <div class="riwayat-body">
        <!-- STATS -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:15px;margin-bottom:25px;">
            <div class="stat-mini">
                <div class="value"><?= $total ?></div>
                <div class="label">Total Kunjungan UKS</div>
            </div>
            <div class="stat-mini">
                <div class="value"><?= mysqli_num_rows($penyakit) ?></div>
                <div class="label">Riwayat Penyakit</div>
            </div>
        </div>
        
        <!-- PERINGATAN -->
        <?php if(mysqli_num_rows($minggu) > 0): ?>
        <div class="alert-warning-custom">
            <strong>⚠️ Perhatian!</strong> Siswa ini pernah berkunjung lebih dari 1 kali dalam seminggu:
            <?php while($m = mysqli_fetch_assoc($minggu)): ?>
            <div style="margin-top:5px;font-size:0.85rem;">
                • Minggu ke-<?= $m['minggu'] ?> Tahun <?= $m['tahun'] ?>: <strong><?= $m['jumlah'] ?> kali</strong> (<?= $m['tgl_kunjungan'] ?>)
            </div>
            <?php endwhile; ?>
        </div>
        <?php endif; ?>
        
        <!-- RIWAYAT PENYAKIT -->
        <h5 class="section-title">🏥 Riwayat Penyakit</h5>
        <?php if(mysqli_num_rows($penyakit) > 0): ?>
        <table class="table-riwayat">
            <thead>
                <tr><th width="5%">No</th><th width="35%">Penyakit</th><th width="15%">Tahun</th><th>Keterangan</th></tr>
            </thead>
            <tbody>
                <?php $no=1; while($p = mysqli_fetch_assoc($penyakit)): ?>
                <tr>
                    <td style="text-align:center;"><?= $no++ ?></td>
                    <td><strong><?= htmlspecialchars($p['nama_penyakit']) ?></strong></td>
                    <td style="text-align:center;"><?= $p['tahun'] ?></td>
                    <td><?= htmlspecialchars($p['keterangan'] ?: '-') ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p style="color:#999;text-align:center;padding:20px;">Tidak ada riwayat penyakit</p>
        <?php endif; ?>
        
        <!-- RIWAYAT KUNJUNGAN -->
        <h5 class="section-title">📅 Riwayat Kunjungan UKS</h5>
        <?php if(mysqli_num_rows($kunjungan) > 0): ?>
        <div class="table-scroll">
            <table class="table-riwayat">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th width="12%">Tanggal</th>
                        <th width="18%">Keluhan</th>
                        <th width="15%">Diagnosa</th>
                        <th width="15%">Penanganan</th>
                        <th width="20%">Obat</th>
                        <th width="15%">Petugas</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no=1; while($k = mysqli_fetch_assoc($kunjungan)): ?>
                    <tr>
                        <td style="text-align:center;"><?= $no++ ?></td>
                        <td style="white-space:nowrap;">
                            <strong><?= date('d/m/Y', strtotime($k['tanggal'])) ?></strong>
                            <br><small style="color:#999;"><?= date('H:i', strtotime($k['created_at'])) ?></small>
                        </td>
                        <td><?= htmlspecialchars($k['keluhan'] ?: '-') ?></td>
                        <td>
                            <?php if($k['diagnosa']): ?>
                            <span class="badge-diagnosa"><?= htmlspecialchars($k['diagnosa']) ?></span>
                            <?php else: ?>-<?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($k['penanganan'] ?: '-') ?></td>
                        <td style="font-size:0.8rem;"><?= $k['obat_list'] ?: '-' ?></td>
                        <td><?= htmlspecialchars($k['petugas'] ?: '-') ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <p style="color:#999;text-align:center;padding:20px;">Belum pernah berkunjung ke UKS</p>
        <?php endif; ?>
    </div>
</div>