<?php
include '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    
    if ($action == 'add') {
        $siswa_id = mysqli_real_escape_string($conn, $_POST['siswa_id']);
        $petugas_id = mysqli_real_escape_string($conn, $_POST['petugas_id']);
        $keluhan = mysqli_real_escape_string($conn, $_POST['keluhan']);
        $diagnosa = mysqli_real_escape_string($conn, $_POST['diagnosa']);
        $penanganan = mysqli_real_escape_string($conn, $_POST['penanganan']);
        
        $query = "INSERT INTO kunjungan (siswa_id, petugas_id, tanggal, keluhan, diagnosa, penanganan) 
                  VALUES ('$siswa_id', '$petugas_id', CURDATE(), '$keluhan', '$diagnosa', '$penanganan')";
        
        if (mysqli_query($conn, $query)) {
            $kunjungan_id = mysqli_insert_id($conn);
            
            if (isset($_POST['obat_id']) && is_array($_POST['obat_id'])) {
                foreach ($_POST['obat_id'] as $key => $obat_id) {
                    if (!empty($obat_id)) {
                        $jumlah = (int)$_POST['jumlah_obat'][$key];
                        mysqli_query($conn, "INSERT INTO kunjungan_obat (kunjungan_id, obat_id, jumlah) VALUES ('$kunjungan_id', '$obat_id', '$jumlah')");
                        mysqli_query($conn, "UPDATE obat SET stok = stok - $jumlah WHERE id = '$obat_id'");
                    }
                }
            }
            
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
        }
    }
    
    if ($action == 'delete') {
        $id = (int)$_POST['id'];
        
        // Kembalikan stok obat
        $obat_query = mysqli_query($conn, "SELECT obat_id, jumlah FROM kunjungan_obat WHERE kunjungan_id = '$id'");
        while ($obat = mysqli_fetch_assoc($obat_query)) {
            mysqli_query($conn, "UPDATE obat SET stok = stok + {$obat['jumlah']} WHERE id = '{$obat['obat_id']}'");
        }
        
        mysqli_query($conn, "DELETE FROM kunjungan WHERE id = '$id'");
        echo json_encode(['status' => 'success']);
    }
}
?>