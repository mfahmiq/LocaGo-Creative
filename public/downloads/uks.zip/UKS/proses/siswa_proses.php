<?php
include '../config/database.php';

// ============================================
// GET REQUEST - Ambil data atau detail
// ============================================
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $action = isset($_GET['action']) ? $_GET['action'] : '';
    
    // Ambil data siswa untuk edit
    if ($action == 'get_data') {
        $id = mysqli_real_escape_string($conn, $_GET['id']);
        $query = "SELECT * FROM siswa WHERE id = '$id'";
        $result = mysqli_query($conn, $query);
        
        if (mysqli_num_rows($result) > 0) {
            $data = mysqli_fetch_assoc($result);
            echo json_encode($data);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Data tidak ditemukan']);
        }
        exit();
    }
    
    // Tampilkan detail siswa
    if ($action == 'detail') {
        $id = mysqli_real_escape_string($conn, $_GET['id']);
        $query = "SELECT * FROM siswa WHERE id = '$id'";
        $result = mysqli_query($conn, $query);
        
        if (mysqli_num_rows($result) == 0) {
            echo '<div class="alert alert-danger">Data siswa tidak ditemukan!</div>';
            exit();
        }
        
        $siswa = mysqli_fetch_assoc($result);
        
        // Hitung total kunjungan
        $total_kunjungan = mysqli_fetch_assoc(mysqli_query($conn, 
            "SELECT COUNT(*) as total FROM kunjungan WHERE siswa_id = '$id'"
        ))['total'];
        
        // Ambil riwayat penyakit
        $riwayat = mysqli_query($conn, 
            "SELECT * FROM riwayat_penyakit WHERE siswa_id = '$id' ORDER BY tahun DESC"
        );
        
        // Ambil kunjungan terakhir
        $kunjungan_terakhir = mysqli_query($conn, 
            "SELECT k.*, u.nama_lengkap as petugas 
             FROM kunjungan k 
             LEFT JOIN users u ON k.petugas_id = u.id 
             WHERE k.siswa_id = '$id' 
             ORDER BY k.tanggal DESC, k.created_at DESC 
             LIMIT 5"
        );
        ?>
        
        <div class="row">
            <div class="col-md-4 text-center mb-3">
                <div class="bg-light rounded p-3">
                    <div style="font-size: 80px;">
                        <?= $siswa['jenis_kelamin'] == 'L' ? '👦' : '👧' ?>
                    </div>
                    <h4 class="mt-2"><?= htmlspecialchars($siswa['nama']) ?></h4>
                    <?php if ($siswa['dokcil'] == 'Ya'): ?>
                        <span class="badge" style="background: #F6E9D2; color: #C9963C; padding: 5px 12px; border-radius: 20px;">🩺 Dokter Cilik</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-8">
                <table class="table table-bordered">
                    <tr><th width="35%">NISN</th><td><?= htmlspecialchars($siswa['nisn']) ?></td></tr>
                    <tr><th>Nama Lengkap</th><td><?= htmlspecialchars($siswa['nama']) ?></td></tr>
                    <tr><th>Jenis Kelamin</th><td><?= $siswa['jenis_kelamin'] == 'L' ? 'Laki-laki' : 'Perempuan' ?></td></tr>
                    <tr><th>Kelas</th><td><?= htmlspecialchars($siswa['kelas']) ?></td></tr>
                    <tr><th>Alamat</th><td><?= htmlspecialchars($siswa['alamat'] ?: '-') ?></td></tr>
                    <tr><th>No. Telepon Ortu</th><td><?= htmlspecialchars($siswa['no_telp'] ?: '-') ?></td></tr>
                    <tr><th>Total Kunjungan UKS</th><td><span class="badge bg-info"><?= $total_kunjungan ?> kali</span></td></tr>
                </table>
            </div>
        </div>
        
        <hr>
        <h6>🏥 Riwayat Penyakit</h6>
        <?php if (mysqli_num_rows($riwayat) > 0): ?>
        <table class="table table-sm table-bordered">
            <thead>
                <tr><th>No</th><th>Penyakit</th><th>Tahun</th><th>Keterangan</th></tr>
            </thead>
            <tbody>
                <?php $no = 1; while($r = mysqli_fetch_assoc($riwayat)): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($r['nama_penyakit']) ?></td>
                    <td><?= htmlspecialchars($r['tahun']) ?></td>
                    <td><?= htmlspecialchars($r['keterangan'] ?: '-') ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p class="text-muted">Tidak ada riwayat penyakit</p>
        <?php endif; ?>
        
        <h6 class="mt-3">📅 5 Kunjungan Terakhir</h6>
        <?php if (mysqli_num_rows($kunjungan_terakhir) > 0): ?>
        <table class="table table-sm table-bordered">
            <thead>
                <tr><th>Tanggal</th><th>Keluhan</th><th>Diagnosa</th><th>Penanganan</th><th>Petugas</th></tr>
            </thead>
            <tbody>
                <?php while($k = mysqli_fetch_assoc($kunjungan_terakhir)): ?>
                <tr>
                    <td><?= date('d/m/Y', strtotime($k['tanggal'])) ?></td>
                    <td><?= htmlspecialchars($k['keluhan']) ?></td>
                    <td><?= htmlspecialchars($k['diagnosa'] ?: '-') ?></td>
                    <td><?= htmlspecialchars($k['penanganan'] ?: '-') ?></td>
                    <td><?= htmlspecialchars($k['petugas'] ?: '-') ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p class="text-muted">Belum pernah berkunjung ke UKS</p>
        <?php endif; ?>
        
        <?php
        exit();
    }
}

// ============================================
// POST REQUEST - Tambah, Edit, Hapus
// ============================================
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    
    // TAMBAH SISWA
    if ($action == 'tambah') {
        $nisn = mysqli_real_escape_string($conn, $_POST['nisn']);
        $nama = mysqli_real_escape_string($conn, $_POST['nama']);
        $jk = mysqli_real_escape_string($conn, $_POST['jenis_kelamin']);
        $kelas = mysqli_real_escape_string($conn, $_POST['kelas']);
        $alamat = mysqli_real_escape_string($conn, isset($_POST['alamat']) ? $_POST['alamat'] : '');
        $no_telp = mysqli_real_escape_string($conn, isset($_POST['no_telp']) ? $_POST['no_telp'] : '');
        $dokcil = isset($_POST['dokcil']) ? mysqli_real_escape_string($conn, $_POST['dokcil']) : 'Tidak';
        
        // Validasi input wajib
        if (empty($nisn) || empty($nama) || empty($jk) || empty($kelas)) {
            echo json_encode(['status' => 'error', 'message' => 'Semua field wajib (NISN, Nama, Jenis Kelamin, Kelas) harus diisi!']);
            exit();
        }
        
        // Cek NISN duplikat
        $cek = mysqli_query($conn, "SELECT id FROM siswa WHERE nisn = '$nisn'");
        if (mysqli_num_rows($cek) > 0) {
            echo json_encode(['status' => 'error', 'message' => 'NISN sudah terdaftar! Gunakan NISN lain.']);
            exit();
        }
        
        // Insert data
        $query = "INSERT INTO siswa (nisn, nama, jenis_kelamin, kelas, alamat, no_telp, dokcil) 
                  VALUES ('$nisn', '$nama', '$jk', '$kelas', '$alamat', '$no_telp', '$dokcil')";
        
        if (mysqli_query($conn, $query)) {
            echo json_encode(['status' => 'success', 'message' => 'Data siswa berhasil ditambahkan!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal menambahkan data: ' . mysqli_error($conn)]);
        }
        exit();
    }
    
    // EDIT SISWA
    if ($action == 'edit') {
        $id = mysqli_real_escape_string($conn, $_POST['id']);
        $nisn = mysqli_real_escape_string($conn, $_POST['nisn']);
        $nama = mysqli_real_escape_string($conn, $_POST['nama']);
        $jk = mysqli_real_escape_string($conn, $_POST['jenis_kelamin']);
        $kelas = mysqli_real_escape_string($conn, $_POST['kelas']);
        $alamat = mysqli_real_escape_string($conn, isset($_POST['alamat']) ? $_POST['alamat'] : '');
        $no_telp = mysqli_real_escape_string($conn, isset($_POST['no_telp']) ? $_POST['no_telp'] : '');
        $dokcil = isset($_POST['dokcil']) ? mysqli_real_escape_string($conn, $_POST['dokcil']) : 'Tidak';
        
        // Validasi
        if (empty($nisn) || empty($nama) || empty($jk) || empty($kelas)) {
            echo json_encode(['status' => 'error', 'message' => 'Semua field wajib harus diisi!']);
            exit();
        }
        
        // Cek NISN duplikat (kecuali dirinya sendiri)
        $cek = mysqli_query($conn, "SELECT id FROM siswa WHERE nisn = '$nisn' AND id != '$id'");
        if (mysqli_num_rows($cek) > 0) {
            echo json_encode(['status' => 'error', 'message' => 'NISN sudah digunakan siswa lain!']);
            exit();
        }
        
        // Update data
        $query = "UPDATE siswa SET 
                  nisn = '$nisn',
                  nama = '$nama',
                  jenis_kelamin = '$jk',
                  kelas = '$kelas',
                  alamat = '$alamat',
                  no_telp = '$no_telp',
                  dokcil = '$dokcil'
                  WHERE id = '$id'";
        
        if (mysqli_query($conn, $query)) {
            echo json_encode(['status' => 'success', 'message' => 'Data siswa berhasil diupdate!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal mengupdate data: ' . mysqli_error($conn)]);
        }
        exit();
    }
    
    // HAPUS SISWA
    if ($action == 'hapus') {
        $id = mysqli_real_escape_string($conn, $_POST['id']);
        
        // Hapus data terkait dulu
        mysqli_query($conn, "DELETE FROM kunjungan_obat WHERE kunjungan_id IN (SELECT id FROM kunjungan WHERE siswa_id = '$id')");
        mysqli_query($conn, "DELETE FROM kunjungan WHERE siswa_id = '$id'");
        mysqli_query($conn, "DELETE FROM riwayat_penyakit WHERE siswa_id = '$id'");
        
        // Hapus siswa
        $query = "DELETE FROM siswa WHERE id = '$id'";
        
        if (mysqli_query($conn, $query)) {
            echo json_encode(['status' => 'success', 'message' => 'Data siswa berhasil dihapus!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal menghapus data: ' . mysqli_error($conn)]);
        }
        exit();
    }
}

// Jika tidak ada action yang cocok
echo json_encode(['status' => 'error', 'message' => 'Action tidak valid!']);
?>