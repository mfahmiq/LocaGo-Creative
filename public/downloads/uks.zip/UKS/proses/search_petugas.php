<?php
include '../config/database.php';

$keyword = mysqli_real_escape_string($conn, $_GET['keyword']);

$query = "SELECT id, nama_lengkap, role FROM users 
          WHERE (role = 'petugas' OR role = 'admin') 
          AND nama_lengkap LIKE '%$keyword%' 
          LIMIT 8";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<a href="javascript:void(0)" class="list-group-item list-group-item-action suggestion-item-petugas" 
              data-id="'.$row['id'].'" data-nama="'.htmlspecialchars($row['nama_lengkap']).'">
              <div class="d-flex align-items-center">
                  <i class="bi bi-person-circle me-2" style="font-size: 1.2rem; color: #667eea;"></i>
                  <div>
                      <strong>'.htmlspecialchars($row['nama_lengkap']).'</strong>
                      <br><small class="text-muted">'.ucfirst($row['role']).'</small>
                  </div>
              </div>
              </a>';
    }
} else {
    echo '<div class="list-group-item text-muted text-center" style="border: none; padding: 15px;">Petugas tidak ditemukan</div>';
}
?>