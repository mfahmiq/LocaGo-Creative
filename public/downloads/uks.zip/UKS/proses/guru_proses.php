<?php
include '../config/database.php';

// GET - Ambil data untuk edit
if($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['action']) && $_GET['action'] == 'get') {
    $id = (int)$_GET['id'];
    $result = mysqli_query($conn, "SELECT * FROM guru WHERE id = $id");
    echo json_encode(mysqli_fetch_assoc($result));
    exit;
}

// POST
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    
    // TAMBAH
    if($action == 'tambah') {
        $nama = mysqli_real_escape_string($conn, trim($_POST['nama']));
        $no_wa = mysqli_real_escape_string($conn, trim($_POST['no_wa']));
        $kelas = mysqli_real_escape_string($conn, $_POST['kelas']);
        $jabatan = mysqli_real_escape_string($conn, $_POST['jabatan'] ?: 'Wali Kelas');
        
        if(empty($nama) || empty($no_wa) || empty($kelas)) {
            echo json_encode(['status' => 'error', 'message' => 'Nama, No WA, dan Kelas wajib diisi!']);
            exit;
        }
        
        $no_wa = preg_replace('/[^0-9]/', '', $no_wa);
        
        $query = "INSERT INTO guru (nama, no_wa, kelas, jabatan) VALUES ('$nama', '$no_wa', '$kelas', '$jabatan')";
        
        if(mysqli_query($conn, $query)) {
            echo json_encode(['status' => 'success', 'message' => 'Guru berhasil ditambahkan!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
        }
        exit;
    }
    
    // EDIT
    if($action == 'edit') {
        $id = (int)$_POST['id'];
        $nama = mysqli_real_escape_string($conn, trim($_POST['nama']));
        $no_wa = mysqli_real_escape_string($conn, trim($_POST['no_wa']));
        $kelas = mysqli_real_escape_string($conn, $_POST['kelas']);
        $jabatan = mysqli_real_escape_string($conn, $_POST['jabatan'] ?: 'Wali Kelas');
        
        if(empty($nama) || empty($no_wa) || empty($kelas)) {
            echo json_encode(['status' => 'error', 'message' => 'Semua field wajib diisi!']);
            exit;
        }
        
        $no_wa = preg_replace('/[^0-9]/', '', $no_wa);
        
        $query = "UPDATE guru SET nama='$nama', no_wa='$no_wa', kelas='$kelas', jabatan='$jabatan' WHERE id=$id";
        
        if(mysqli_query($conn, $query)) {
            echo json_encode(['status' => 'success', 'message' => 'Data guru berhasil diupdate!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
        }
        exit;
    }
    
    // HAPUS
    if($action == 'hapus') {
        $id = (int)$_POST['id'];
        
        if(mysqli_query($conn, "DELETE FROM guru WHERE id = $id")) {
            echo json_encode(['status' => 'success', 'message' => 'Guru berhasil dihapus!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
        }
        exit;
    }
}

echo json_encode(['status' => 'error', 'message' => 'Action tidak valid!']);
?>