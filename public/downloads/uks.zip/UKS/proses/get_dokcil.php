<?php
include '../config/database.php';

$id = (int)$_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM siswa WHERE id = $id");
$data = mysqli_fetch_assoc($result);
echo json_encode($data);
?>