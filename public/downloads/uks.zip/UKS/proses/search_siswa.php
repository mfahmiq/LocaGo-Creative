<?php
include '../config/database.php';

$keyword = mysqli_real_escape_string($conn, $_GET['keyword']);

$query = "SELECT id, nisn, nama, kelas, jenis_kelamin FROM siswa 
          WHERE nama LIKE '%$keyword%' OR nisn LIKE '%$keyword%' 
          ORDER BY nama LIMIT 10";
$result = mysqli_query($conn, $query);

if (isset($_GET['action']) && $_GET['action'] == 'get_first') {
    // Untuk tombol cari
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        echo json_encode(['status' => 'success', 'siswa_id' => $row['id']]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Siswa tidak ditemukan']);
    }
} else {
    // Untuk suggestions dropdown
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $icon = $row['jenis_kelamin'] == 'L' ? '👦' : '👧';
            echo '<a href="javascript:void(0)" class="list-group-item list-group-item-action suggestion-item" 
                  data-id="'.$row['id'].'">
                  <div class="d-flex align-items-center">
                      <span style="font-size: 1.5rem; margin-right: 10px;">'.$icon.'</span>
                      <div>
                          <strong>'.htmlspecialchars($row['nama']).'</strong>
                          <br><small class="text-muted">Kelas '.$row['kelas'].' | NISN: '.$row['nisn'].'</small>
                      </div>
                  </div>
                  </a>';
        }
    } else {
        echo '<div class="list-group-item text-muted text-center">Siswa tidak ditemukan</div>';
    }
}
?>