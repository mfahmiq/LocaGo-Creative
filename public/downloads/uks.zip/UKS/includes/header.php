<?php
include_once __DIR__ . '/../config/database.php';
checkLogin();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UKS System - Unit Kesehatan Sekolah SDN 5</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.bootstrap5.min.css" rel="stylesheet">
    
    <!-- SweetAlert2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #4e73df;
            --success-color: #1cc88a;
            --info-color: #36b9cc;
            --warning-color: #f6c23e;
            --danger-color: #e74a3b;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fc;
        }
        
        .sidebar {
            background: linear-gradient(180deg, #4e73df 0%, #224abe 100%);
            min-height: 100vh;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,.8);
            padding: 1rem 1.5rem;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: #fff;
            background: rgba(255,255,255,.1);
            border-radius: 0.35rem;
            margin: 0 0.5rem;
        }
        
        .sidebar .nav-link i {
            margin-right: 0.5rem;
            font-size: 1.2rem;
        }
        
        .card-stats {
            border-left: 0.25rem solid;
            border-radius: 0.35rem;
            transition: transform 0.3s;
        }
        
        .card-stats:hover {
            transform: translateY(-5px);
        }
        
        .card-stats.primary { border-left-color: var(--primary-color); }
        .card-stats.success { border-left-color: var(--success-color); }
        .card-stats.info { border-left-color: var(--info-color); }
        .card-stats.warning { border-left-color: var(--warning-color); }
        
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
        }
        
        .table-stok-warning {
            background-color: #fff3cd !important;
            color: #856404 !important;
            font-weight: bold;
        }
    </style>
</head>
<body>