<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav class="col-md-2 d-none d-md-block sidebar p-0">
            <!-- Logo -->
            <div class="text-center" style="padding: 20px 15px 10px;">
                <img src="../assets/img/logo_sdn5.png" alt="Logo SDN 5" style="width: 100px; height: 100px; border-radius: 5px; margin-bottom: 8px; object-fit: cover; display: block; margin-left: auto; margin-right: auto;" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                <div style="display: none; font-size: 70px; line-height: 100px;">🏥</div>
                <h5 class="text-white mb-0" style="font-size: 15px; font-weight: 700;">UKS System</h5>
                <small class="text-white-50" style="font-size: 10px; display: block; line-height: 1.2;">Unit Kesehatan Sekolah</small>
            </div>
            
            <!-- User Info -->
            <div class="text-center" style="padding: 5px 15px 15px;">
                <div class="text-white-50 small">
                    <i class="bi bi-person-circle"></i>
                    <?= $_SESSION['nama_lengkap'] ?>
                </div>
            </div>
            
            <!-- Menu -->
            <ul class="nav flex-column" style="margin-top: 0;">
                <!-- Dashboard -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>" 
                       href="dashboard.php">
                        <i class="bi bi-speedometer2"></i> Dashboard
                    </a>
                </li>
                
                <!-- Kunjungan UKS -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'kunjungan.php' ? 'active' : '' ?>" 
                       href="kunjungan.php">
                        <i class="bi bi-clipboard2-pulse"></i> Kunjungan UKS
                    </a>
                </li>
                
                <!-- Data Guru -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'guru.php' ? 'active' : '' ?>" 
                       href="guru.php">
                        <i class="bi bi-whatsapp"></i> Data Guru
                    </a>
                </li>
                
                <!-- Data Siswa -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'siswa.php' ? 'active' : '' ?>" 
                       href="siswa.php">
                        <i class="bi bi-people"></i> Data Siswa
                    </a>
                </li>
                
                <!-- Data Obat -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'obat.php' ? 'active' : '' ?>" 
                       href="obat.php">
                        <i class="bi bi-capsule"></i> Data Obat
                    </a>
                </li>
                
                <!-- Riwayat Kesehatan -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'riwayat_siswa.php' ? 'active' : '' ?>" 
                       href="riwayat_siswa.php">
                        <i class="bi bi-search"></i> Riwayat Kesehatan
                    </a>
                </li>
                
                <!-- Kartu Dokcil -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'kartu_dokcil.php' ? 'active' : '' ?>" 
                       href="kartu_dokcil.php">
                        <i class="bi bi-credit-card"></i> Kartu Dokcil
                    </a>
                </li>
                
                <!-- Laporan -->
                <li class="nav-item">
                    <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'laporan.php' ? 'active' : '' ?>" 
                       href="laporan.php">
                        <i class="bi bi-file-earmark-bar-graph"></i> Laporan
                    </a>
                </li>
                
                <!-- Logout -->
                <li class="nav-item mt-4">
                    <a class="nav-link" href="#" onclick="confirmLogout()" style="background: #dc3545; color: white !important; border-radius: 10px; margin: 0 10px; text-align: center; font-weight: 600;">
                        <i class="bi bi-box-arrow-right"></i> Logout
                    </a>
                </li>
            </ul>
        </nav>
        
        <!-- Main Content -->
        <main class="col-md-10 ms-sm-auto px-4">