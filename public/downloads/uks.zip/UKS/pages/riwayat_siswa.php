<?php
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<style>
    /* Background dengan efek blur dan gradient */
    .content-wrapper {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        padding: 20px;
        position: relative;
    }
    
    .content-wrapper::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="15" fill="rgba(255,255,255,0.05)"/><circle cx="80" cy="80" r="20" fill="rgba(255,255,255,0.05)"/><circle cx="50" cy="50" r="25" fill="rgba(255,255,255,0.03)"/></svg>');
        background-size: 200px 200px;
        pointer-events: none;
    }
    
    .main-content {
        backdrop-filter: blur(10px);
        background: rgba(255, 255, 255, 0.92);
        border-radius: 25px;
        padding: 25px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        border: 1px solid rgba(255,255,255,0.3);
        position: relative;
        z-index: 1;
        animation: fadeInUp 0.8s ease-out;
    }
    
    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .glass-header {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(20px);
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 25px;
        border: 1px solid rgba(255,255,255,0.2);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        position: relative;
        overflow: hidden;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .glass-header::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
        animation: shimmer 3s infinite;
    }
    
    @keyframes shimmer {
        0% { transform: translate(-30%, -30%) rotate(0deg); }
        100% { transform: translate(30%, 30%) rotate(180deg); }
    }
    
    .glass-header h1 {
        color: #4facfe !important;
        text-shadow: 0 2px 20px rgba(79, 172, 254, 0.3);
        position: relative;
        z-index: 1;
        font-weight: 700;
    }
    
    .card-container {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        padding: 20px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.5);
    }
    
    .search-wrapper { position: relative; }
    
    .search-input {
        border-radius: 50px !important;
        border: 2px solid rgba(0,0,0,0.06) !important;
        padding: 15px 25px !important;
        font-size: 1rem !important;
        background: rgba(255,255,255,0.8) !important;
        backdrop-filter: blur(5px) !important;
        transition: all 0.3s ease !important;
        height: 60px !important;
        padding-left: 55px !important;
    }
    
    .search-input:focus {
        border-color: #667eea !important;
        box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.15) !important;
        transform: translateY(-2px);
        background: white !important;
    }
    
    .search-icon-wrapper {
        position: absolute;
        left: 20px;
        top: 50%;
        transform: translateY(-50%);
        color: #667eea;
        font-size: 1.2rem;
        z-index: 10;
        background: rgba(102, 126, 234, 0.1);
        padding: 8px 12px;
        border-radius: 50px;
        pointer-events: none;
    }
    
    .search-suggestions {
        position: absolute;
        top: 70px;
        left: 0;
        right: 0;
        z-index: 1000;
        background: white;
        border-radius: 15px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        max-height: 350px;
        overflow-y: auto;
        display: none;
        border: 2px solid rgba(102, 126, 234, 0.15);
    }
    
    .search-suggestions .suggestion-item {
        padding: 12px 20px;
        cursor: pointer;
        transition: all 0.2s ease;
        border-bottom: 1px solid rgba(0,0,0,0.05);
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    
    .search-suggestions .suggestion-item:hover {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }
    
    .btn-search {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border: none;
        color: white;
        padding: 15px 40px;
        border-radius: 50px;
        font-weight: 600;
        letter-spacing: 0.5px;
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.4);
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        height: 60px;
        width: 100%;
        font-size: 1rem;
        cursor: pointer;
    }
    
    .btn-search:hover {
        transform: translateY(-3px) scale(1.02);
        box-shadow: 0 12px 35px rgba(102, 126, 234, 0.5);
        color: white;
        background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
    }
    
    .btn-print {
        background: #1D6F42;
        border: none;
        color: white;
        padding: 12px 25px;
        border-radius: 50px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        position: relative;
        z-index: 1;
    }
    
    .btn-print:hover {
        background: #145A32;
        transform: translateY(-2px);
    }
    
    .empty-state {
        padding: 60px 20px;
        text-align: center;
    }
    
    .empty-state i {
        font-size: 4rem;
        color: #ccc;
    }
    
    .empty-state h5 {
        margin-top: 20px;
        color: #666;
    }

    /* Print Styles */
    @media print {
        body { background: white !important; }
        .sidebar, .navbar, .btn, .glass-header, .card-container, .no-print, 
        .content-wrapper::before, .particles, .search-wrapper, .btn-search, .btn-print { 
            display: none !important; 
        }
        .content-wrapper { background: white !important; padding: 0 !important; }
        .main-content { box-shadow: none !important; border: none !important; padding: 10px !important; background: white !important; }
        #hasilPencarian { width: 100% !important; }
        .print-area { display: block !important; }
    }
</style>

<!-- Floating Particles -->
<div class="particles" id="particles"></div>

<div class="content-wrapper">
    <div class="container-fluid main-content">
        <!-- Header -->
        <div class="glass-header">
            <h1 class="h2 mb-0">
                <i class="bi bi-clipboard2-heart me-2"></i> Riwayat Kesehatan Siswa
            </h1>
            <button class="btn-print no-print" onclick="printRiwayat()" id="btnPrint" style="display: none;">
                <i class="bi bi-printer me-2"></i> Cetak Riwayat
            </button>
        </div>

        <!-- Search Bar -->
        <div class="card-container mb-4 no-print">
            <div class="card-body p-4">
                <div class="row g-3 align-items-center">
                    <div class="col-md-8">
                        <div class="search-wrapper">
                            <span class="search-icon-wrapper"><i class="bi bi-search"></i></span>
                            <input type="text" class="form-control search-input" id="searchInput" 
                                   placeholder="Cari berdasarkan Nama Siswa atau NISN..." autocomplete="off">
                            <div id="searchSuggestions" class="search-suggestions"></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <button type="button" class="btn-search" onclick="cariRiwayat()">
                            <i class="bi bi-search me-2"></i> Cari Riwayat
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Hasil Pencarian -->
        <div id="hasilPencarian">
            <div class="card-container">
                <div class="empty-state">
                    <i class="bi bi-search"></i>
                    <h5>Cari siswa untuk melihat riwayat kesehatan</h5>
                    <p>Ketik nama atau NISN siswa di kolom pencarian</p>
                </div>
            </div>
        </div>
    </div>
</div>

</main>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
var currentSiswaData = null; // Simpan data siswa yang sedang ditampilkan

$(document).ready(function() {
    // Create floating particles
    function createParticles() {
        const container = document.getElementById('particles');
        for (let i = 0; i < 20; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.width = (Math.random() * 4 + 2) + 'px';
            particle.style.height = particle.style.width;
            particle.style.animationDuration = (Math.random() * 20 + 10) + 's';
            particle.style.animationDelay = (Math.random() * 10) + 's';
            container.appendChild(particle);
        }
    }
    createParticles();

    // Live search suggestions
    var searchTimeout;
    $('#searchInput').on('keyup', function() {
        clearTimeout(searchTimeout);
        var keyword = $(this).val().trim();
        
        if (keyword.length >= 2) {
            searchTimeout = setTimeout(function() {
                $.ajax({
                    url: '../proses/search_siswa.php',
                    type: 'GET',
                    data: { keyword: keyword },
                    success: function(response) {
                        $('#searchSuggestions').html(response).slideDown(200);
                    }
                });
            }, 300);
        } else {
            $('#searchSuggestions').slideUp(200);
        }
    });
    
    // Enter key
    $('#searchInput').on('keypress', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            cariRiwayat();
        }
    });
    
    // Hide suggestions when clicking outside
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.search-wrapper').length) {
            $('#searchSuggestions').slideUp(200);
        }
    });
    
    // Select suggestion
    $(document).on('click', '.suggestion-item', function() {
        var id = $(this).data('id');
        var text = $(this).text().trim();
        $('#searchInput').val(text);
        $('#searchSuggestions').slideUp(200);
        tampilkanRiwayat(id);
    });
});

function cariRiwayat() {
    var keyword = $('#searchInput').val().trim();
    if (keyword.length < 2) {
        Swal.fire({ icon: 'warning', title: 'Perhatian', text: 'Masukkan minimal 2 karakter', timer: 1500, showConfirmButton: false });
        return;
    }
    
    $('#hasilPencarian').html(`
        <div class="card-container">
            <div class="text-center py-5">
                <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;"></div>
                <p class="mt-3 text-muted">Mencari data siswa...</p>
            </div>
        </div>
    `);
    
    $.ajax({
        url: '../proses/search_siswa.php',
        type: 'GET',
        data: { keyword: keyword, action: 'get_first' },
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                tampilkanRiwayat(response.siswa_id);
            } else {
                $('#hasilPencarian').html(`
                    <div class="card-container">
                        <div class="text-center py-5">
                            <div style="font-size: 4rem;">🔍</div>
                            <h5>Siswa Tidak Ditemukan</h5>
                            <p class="text-muted">Coba dengan kata kunci lain</p>
                        </div>
                    </div>
                `);
                $('#btnPrint').hide();
            }
        },
        error: function() {
            $('#hasilPencarian').html('<div class="card-container"><div class="text-center py-5 text-danger"><h5>Gagal Mencari Data</h5></div></div>');
        }
    });
}

function tampilkanRiwayat(siswa_id) {
    $('#hasilPencarian').html(`
        <div class="card-container">
            <div class="text-center py-5">
                <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;"></div>
                <p class="mt-3 text-muted">Memuat riwayat kesehatan...</p>
            </div>
        </div>
    `);
    
    $.ajax({
        url: '../proses/get_riwayat.php',
        type: 'GET',
        data: { siswa_id: siswa_id },
        success: function(response) {
            $('#hasilPencarian').html(response);
            // Tampilkan tombol print
            $('#btnPrint').show();
        },
        error: function() {
            $('#hasilPencarian').html('<div class="card-container"><div class="text-center py-5 text-danger"><h5>Gagal Memuat Data</h5></div></div>');
            $('#btnPrint').hide();
        }
    });
}

// Fungsi Print Riwayat
function printRiwayat() {
    var printContent = document.getElementById('hasilPencarian').innerHTML;
    
    // Ambil data siswa dari tampilan
    var namaSiswa = document.querySelector('#hasilPencarian .riwayat-nama')?.textContent || '-';
    var infoSiswa = document.querySelector('#hasilPencarian .riwayat-info')?.textContent || '-';
    
    var printWindow = window.open('', '_blank', 'width=900,height=700');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Cetak Riwayat Kesehatan - ${namaSiswa}</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { 
                    font-family: Arial, sans-serif; 
                    padding: 15px 20px; 
                    color: #000;
                    font-size: 12px;
                }
                .print-header { 
                    text-align: center; 
                    margin-bottom: 15px; 
                    border-bottom: 2px solid #000; 
                    padding-bottom: 10px; 
                }
                .print-header h3 { 
                    font-size: 16px; 
                    font-weight: bold; 
                    margin-bottom: 3px;
                    text-transform: uppercase;
                }
                .print-header .info { 
                    font-size: 11px; 
                    color: #333; 
                }
                .print-header .info span { 
                    margin: 0 10px; 
                }
                .section-title {
                    font-size: 13px;
                    font-weight: bold;
                    margin: 15px 0 8px;
                    padding-bottom: 3px;
                    border-bottom: 1px solid #000;
                    text-transform: uppercase;
                }
                table { 
                    width: 100%; 
                    border-collapse: collapse; 
                    margin-bottom: 10px;
                }
                table th { 
                    background: #eee; 
                    padding: 6px 8px; 
                    border: 1px solid #000; 
                    font-size: 11px;
                    text-align: left;
                }
                table td { 
                    padding: 5px 8px; 
                    border: 1px solid #000; 
                    font-size: 11px;
                    vertical-align: top;
                }
                table td.center { text-align: center; }
                .stat-row {
                    display: flex;
                    gap: 15px;
                    margin-bottom: 10px;
                }
                .stat-item {
                    border: 1px solid #000;
                    padding: 6px 12px;
                    text-align: center;
                }
                .stat-item .value {
                    font-size: 16px;
                    font-weight: bold;
                }
                .stat-item .label {
                    font-size: 10px;
                    color: #555;
                }
                .warning-box {
                    border: 1px solid #000;
                    padding: 8px 12px;
                    margin-bottom: 10px;
                    font-size: 11px;
                    background: #f9f9f9;
                }
                .print-footer { 
                    margin-top: 20px; 
                    text-align: right; 
                    font-size: 10px; 
                    border-top: 1px solid #000; 
                    padding-top: 8px; 
                }
                .print-footer .ttd {
                    margin-top: 40px;
                    text-align: right;
                }
                .print-footer .ttd .nama {
                    font-weight: bold;
                    margin-top: 30px;
                }
                @media print {
                    body { padding: 10px; }
                    .no-print { display: none !important; }
                }
                .no-print { 
                    text-align: center; 
                    margin-top: 20px; 
                    padding-top: 15px;
                    border-top: 1px dashed #ccc;
                }
                .btn-print {
                    padding: 8px 25px;
                    background: #1D6F42;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    font-size: 13px;
                    cursor: pointer;
                    font-weight: bold;
                    margin: 0 5px;
                }
                .btn-close {
                    padding: 8px 25px;
                    background: #666;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    font-size: 13px;
                    cursor: pointer;
                    font-weight: bold;
                    margin: 0 5px;
                }
            </style>
        </head>
        <body>
            <div class="print-header">
                <h3>LAPORAN RIWAYAT KESEHATAN SISWA</h3>
                <div class="info">
                    <strong>Nama:</strong> ${namaSiswa} 
                    <span>|</span> 
                    <strong>${infoSiswa}</strong>
                </div>
                <div class="info" style="margin-top: 3px;">
                    Tanggal Cetak: ${new Date().toLocaleDateString('id-ID', {day:'numeric', month:'long', year:'numeric'})}
                    <span>|</span>
                    UKS SDN 5 Kota Serang
                </div>
            </div>
            
            <div id="printArea">
                ${printContent}
            </div>
            
            <div class="print-footer">
                <p>Dicetak oleh: <?= $_SESSION['nama_lengkap'] ?></p>
                <div class="ttd">
                    <p>Petugas UKS</p>
                    <p class="nama"><?= $_SESSION['nama_lengkap'] ?></p>
                </div>
            </div>
            
            <div class="no-print">
                <button class="btn-print" onclick="window.print()">🖨️ Cetak</button>
                <button class="btn-close" onclick="window.close()">❌ Tutup</button>
            </div>
        </body>
        </html>
    `);
    printWindow.document.close();
    
    // Hapus elemen yang gak perlu di tampilan print
    printWindow.onload = function() {
        // Hapus gambar boneka/avatar
        var avatar = printWindow.document.querySelector('.riwayat-avatar');
        if(avatar) avatar.remove();
        
        // Hapus badge dokcil
        var badges = printWindow.document.querySelectorAll('.badge, .badge-diagnosa');
        badges.forEach(function(b) {
            b.style.border = '1px solid #000';
            b.style.background = 'none';
            b.style.color = '#000';
            b.style.padding = '1px 6px';
        });
        
        // Hapus background color dari header
        var headers = printWindow.document.querySelectorAll('.riwayat-header');
        headers.forEach(function(h) {
            h.style.background = 'white';
            h.style.color = '#000';
            h.style.padding = '0';
            h.style.marginBottom = '10px';
        });
        
        // Hapus shadow dan border radius
        var cards = printWindow.document.querySelectorAll('.riwayat-card, .stat-mini');
        cards.forEach(function(c) {
            c.style.boxShadow = 'none';
            c.style.borderRadius = '0';
            c.style.background = 'white';
        });
        
        // Sederhanakan stat mini
        var statMinis = printWindow.document.querySelectorAll('.stat-mini');
        statMinis.forEach(function(s) {
            s.style.border = '1px solid #000';
            s.style.padding = '8px';
        });
        
        // Hilangkan scroll
        var scrolls = printWindow.document.querySelectorAll('.table-scroll');
        scrolls.forEach(function(s) {
            s.style.maxHeight = 'none';
            s.style.overflow = 'visible';
        });
        
        // Sederhanakan section title
        var titles = printWindow.document.querySelectorAll('.section-title');
        titles.forEach(function(t) {
            t.style.border = 'none';
            t.style.borderBottom = '1px solid #000';
            t.style.color = '#000';
            t.style.padding = '0 0 3px 0';
            t.style.margin = '15px 0 8px';
        });
    };
}
</script>

</body>
</html>