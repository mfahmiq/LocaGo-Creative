<?php
include '../includes/header.php';
include '../includes/sidebar.php';

// Ambil daftar siswa yang jadi Dokcil
$dokcil_list = mysqli_query($conn, "SELECT * FROM siswa WHERE dokcil = 'Ya' ORDER BY kelas, nama");
$total_dokcil = mysqli_num_rows($dokcil_list);
$total_l = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM siswa WHERE dokcil='Ya' AND jenis_kelamin='L'"))['total'];
$total_p = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM siswa WHERE dokcil='Ya' AND jenis_kelamin='P'"))['total'];

// Simpan data untuk slider
$dokcil_data = [];
mysqli_data_seek($dokcil_list, 0);
while($d = mysqli_fetch_assoc($dokcil_list)) {
    $dokcil_data[] = $d;
}
?>

<style>
    .content-wrapper {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        padding: 20px;
        position: relative;
    }
    
    .content-wrapper::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="15" fill="rgba(255,255,255,0.05)"/><circle cx="80" cy="80" r="20" fill="rgba(255,255,255,0.05)"/></svg>');
        pointer-events: none;
    }
    
    .main-content {
        backdrop-filter: blur(10px);
        background: rgba(255, 255, 255, 0.92);
        border-radius: 25px;
        padding: 25px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        border: 1px solid rgba(255,255,255,0.3);
        position: relative;
        z-index: 1;
    }
    
    .glass-header {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(20px);
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 25px;
        border: 1px solid rgba(255,255,255,0.2);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .glass-header h1 {
        color: #4facfe !important;
        text-shadow: 0 2px 20px rgba(79, 172, 254, 0.3);
        font-weight: 700;
    }
    
    .btn-cetak-semua {
        background: #075E54;
        color: white;
        border: none;
        padding: 12px 30px;
        border-radius: 50px;
        font-weight: 700;
        cursor: pointer;
        animation: pulse 2s infinite;
        transition: all 0.3s;
    }
    
    @keyframes pulse {
        0% { box-shadow: 0 0 0 0 rgba(7, 94, 84, 0.5); }
        70% { box-shadow: 0 0 0 15px rgba(7, 94, 84, 0); }
        100% { box-shadow: 0 0 0 0 rgba(7, 94, 84, 0); }
    }
    
    .btn-cetak-semua:hover {
        transform: scale(1.05);
    }
    
    /* Card Info */
    .info-card {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        border-radius: 20px;
        padding: 25px 15px;
        border: 1px solid rgba(255,255,255,0.2);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        transition: all 0.3s;
        text-align: center;
        color: white;
    }
    
    .info-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 40px rgba(0,0,0,0.2);
    }
    
    .info-card .card-icon { font-size: 2.5rem; display: block; margin-bottom: 8px; }
    .info-card h5 { font-size: 0.85rem; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; margin: 0; opacity: 0.9; }
    .info-card h2 { font-size: 2.5rem; font-weight: 700; margin: 10px 0 5px; }
    .info-card small { font-size: 0.75rem; opacity: 0.8; }
    
    /* Filter */
    .filter-bar {
        background: white;
        border-radius: 15px;
        padding: 15px 20px;
        margin-bottom: 20px;
        border: 1px solid rgba(0,0,0,0.05);
    }
    
    /* Card Container */
    .card-container {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 20px;
        padding: 20px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.5);
        margin-bottom: 25px;
    }
    
    .card-container .card-header {
        background: transparent;
        border-bottom: 2px solid rgba(0,0,0,0.05);
        padding: 15px 20px;
    }
    
    /* ============================================ */
    /* SLIDER / CAROUSEL STYLES */
    /* ============================================ */
    .slider-section {
        margin-bottom: 30px;
    }
    
    .slider-section h4 {
        color: #667eea;
        font-weight: 700;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .slider-container {
        position: relative;
        overflow: hidden;
        padding: 10px 0;
    }
    
    .slider-wrapper {
        display: flex;
        gap: 20px;
        transition: transform 0.5s ease;
        padding: 5px;
    }
    
    .slider-card {
        min-width: 250px;
        max-width: 250px;
        background: white;
        border-radius: 20px;
        padding: 25px 20px;
        text-align: center;
        box-shadow: 0 8px 25px rgba(0,0,0,0.08);
        border: 1px solid rgba(0,0,0,0.05);
        transition: all 0.3s;
        cursor: pointer;
        flex-shrink: 0;
    }
    
    .slider-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        border-color: #667eea;
    }
    
    .slider-card .avatar {
        width: 70px;
        height: 70px;
        border-radius: 50%;
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2rem;
        margin: 0 auto 15px;
    }
    
    .slider-card .nama {
        font-weight: 700;
        font-size: 1rem;
        color: #333;
        margin-bottom: 5px;
    }
    
    .slider-card .kelas {
        display: inline-block;
        background: #E8EAF6;
        color: #1A237E;
        padding: 4px 15px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
        margin-bottom: 10px;
    }
    
    .slider-card .nisn {
        font-size: 0.75rem;
        color: #999;
        margin-top: 5px;
    }
    
    .slider-card .btn-cetak-kartu {
        background: #1D6F42;
        color: white;
        border: none;
        padding: 8px 20px;
        border-radius: 50px;
        font-weight: 600;
        cursor: pointer;
        font-size: 0.8rem;
        margin-top: 10px;
        transition: all 0.3s;
        width: 100%;
    }
    
    .slider-card .btn-cetak-kartu:hover {
        background: #145A32;
    }
    
    /* Slider Buttons */
    .slider-btn {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        width: 45px;
        height: 45px;
        border-radius: 50%;
        background: white;
        border: 2px solid #667eea;
        color: #667eea;
        font-size: 1.2rem;
        cursor: pointer;
        z-index: 10;
        transition: all 0.3s;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    .slider-btn:hover {
        background: #667eea;
        color: white;
    }
    
    .slider-btn.prev { left: -10px; }
    .slider-btn.next { right: -10px; }
    
    .slider-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
    }
    
    /* Tabel */
    .table-dokcil thead {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }
    
    .table-dokcil thead th {
        border: none;
        padding: 12px 15px;
        font-weight: 600;
    }
    
    .table-dokcil tbody td {
        padding: 12px 15px;
        vertical-align: middle;
    }
    
    .table-dokcil tbody tr:hover {
        background: rgba(102, 126, 234, 0.05);
    }
    
    .btn-cetak {
        background: #1D6F42;
        color: white;
        border: none;
        padding: 8px 20px;
        border-radius: 50px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        font-size: 0.85rem;
    }
    
    .btn-cetak:hover {
        background: #145A32;
        transform: translateY(-2px);
    }
    
    /* Divider */
    .section-divider {
        border: none;
        border-top: 2px dashed rgba(102, 126, 234, 0.3);
        margin: 30px 0;
        position: relative;
    }
    
    .section-divider::after {
        content: '🩺';
        position: absolute;
        top: -12px;
        left: 50%;
        transform: translateX(-50%);
        background: white;
        padding: 0 15px;
        font-size: 1.2rem;
    }
    
    @media (max-width: 768px) {
        .main-content { padding: 15px; }
        .glass-header { flex-direction: column; gap: 15px; }
        .slider-card { min-width: 200px; max-width: 200px; }
        .slider-btn { width: 35px; height: 35px; font-size: 1rem; }
    }
    
    @media print {
        body { background: white !important; }
        .sidebar, .navbar, .no-print, .content-wrapper { background: white !important; }
        .main-content { box-shadow: none !important; border: none !important; padding: 0 !important; }
    }
</style>

<div class="content-wrapper">
    <div class="container-fluid main-content">
        
        <!-- Header -->
        <div class="glass-header no-print">
            <h1 class="h2 mb-0">
                <i class="bi bi-credit-card me-2"></i> Kartu Dokter Cilik (Dokcil)
            </h1>
            <button class="btn-cetak-semua" onclick="cetakSemua()">
                <i class="bi bi-printer me-2"></i> Cetak Semua SK
            </button>
        </div>
        
        <!-- Card Info -->
        <div class="row mb-4 g-3 justify-content-center no-print">
            <div class="col-md-4">
                <div class="info-card">
                    <span class="card-icon">🩺</span>
                    <h5>Total Dokter Cilik</h5>
                    <h2><?= $total_dokcil ?></h2>
                    <small>Terdaftar aktif</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="info-card">
                    <span class="card-icon">👦</span>
                    <h5>Dokcil Laki-laki</h5>
                    <h2><?= $total_l ?></h2>
                    <small>Siswa laki-laki</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="info-card">
                    <span class="card-icon">👧</span>
                    <h5>Dokcil Perempuan</h5>
                    <h2><?= $total_p ?></h2>
                    <small>Siswa perempuan</small>
                </div>
            </div>
        </div>
        
        <!-- ============================================ -->
        <!-- SLIDER DOKCIL -->
        <!-- ============================================ -->
        <?php if(count($dokcil_data) > 0): ?>
        <div class="slider-section no-print">
            <h4><i class="bi bi-people-fill"></i> Dokter Cilik Terdaftar</h4>
            <div class="slider-container">
                <button class="slider-btn prev" onclick="slideCards(-1)" id="btnPrev">◀</button>
                <div class="slider-wrapper" id="sliderWrapper">
                    <?php foreach($dokcil_data as $d): ?>
                    <div class="slider-card">
                        <div class="avatar"><?= $d['jenis_kelamin'] == 'L' ? '👦' : '👧' ?></div>
                        <div class="nama"><?= $d['nama'] ?></div>
                        <div class="kelas">Kelas <?= $d['kelas'] ?></div>
                        <div class="nisn">NISN: <?= $d['nisn'] ?></div>
                        <button class="btn-cetak-kartu" onclick="cetakSK(<?= $d['id'] ?>)">
                            <i class="bi bi-printer me-1"></i> Cetak SK
                        </button>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button class="slider-btn next" onclick="slideCards(1)" id="btnNext">▶</button>
            </div>
        </div>
        
        <!-- Divider -->
        <hr class="section-divider no-print">
        <?php endif; ?>
        
        <!-- ============================================ -->
        <!-- FILTER & TABEL -->
        <!-- ============================================ -->
        <div class="filter-bar no-print">
            <div class="row g-3 align-items-center">
                <div class="col-md-4">
                    <label class="form-label fw-bold mb-0">Filter Kelas:</label>
                    <select class="form-select" id="filterKelas" onchange="filterTable()">
                        <option value="">📋 Semua Kelas</option>
                        <?php 
                        $kelas_list = ['1A','1B','2A','2B','2C','3A','3B','4A','4B','4C','5A','5B','6A','6B'];
                        foreach($kelas_list as $kls): 
                        ?>
                        <option value="<?= $kls ?>">Kelas <?= $kls ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold mb-0">Filter JK:</label>
                    <select class="form-select" id="filterJK" onchange="filterTable()">
                        <option value="">👫 Semua</option>
                        <option value="L">👦 Laki-laki</option>
                        <option value="P">👧 Perempuan</option>
                    </select>
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button class="btn btn-outline-secondary w-100" onclick="resetFilter()">
                        <i class="bi bi-arrow-counterclockwise me-2"></i> Reset Filter
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Tabel -->
        <div class="card-container">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap">
                <h5 class="mb-0">
                    <i class="bi bi-table me-2"></i> Daftar Dokter Cilik
                </h5>
                <span class="badge bg-primary bg-opacity-10 text-primary">
                    <i class="bi bi-people me-1"></i> <?= $total_dokcil ?> Siswa
                </span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover table-dokcil" id="tabelDokcil">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th width="15%">NISN</th>
                                <th width="30%">Nama Siswa</th>
                                <th width="10%">Kelas</th>
                                <th width="8%">JK</th>
                                <th width="15%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            foreach($dokcil_data as $d): 
                            ?>
                            <tr data-kelas="<?= $d['kelas'] ?>" data-jk="<?= $d['jenis_kelamin'] ?>">
                                <td class="text-center"><?= $no++ ?></td>
                                <td><code><?= $d['nisn'] ?></code></td>
                                <td><strong><?= $d['nama'] ?></strong></td>
                                <td><span class="badge bg-info"><?= $d['kelas'] ?></span></td>
                                <td><?= $d['jenis_kelamin'] == 'L' ? '👦 L' : '👧 P' ?></td>
                                <td class="no-print">
                                    <button class="btn-cetak btn-sm" onclick="cetakSK(<?= $d['id'] ?>)">
                                        <i class="bi bi-printer me-1"></i> Cetak SK
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if($no == 1): ?>
                            <tr><td colspan="6" class="text-center text-muted py-4">Belum ada siswa yang terdaftar sebagai Dokter Cilik</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
    </div>
</div>

</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
// ============================================
// SLIDER
// ============================================
var currentSlide = 0;

function slideCards(direction) {
    var wrapper = document.getElementById('sliderWrapper');
    var cards = wrapper.querySelectorAll('.slider-card');
    var cardWidth = cards[0].offsetWidth + 20; // width + gap
    var visibleCards = Math.floor(wrapper.parentElement.offsetWidth / cardWidth);
    var maxSlide = Math.max(0, cards.length - visibleCards);
    
    currentSlide += direction;
    
    if(currentSlide < 0) currentSlide = 0;
    if(currentSlide > maxSlide) currentSlide = maxSlide;
    
    wrapper.style.transform = 'translateX(-' + (currentSlide * cardWidth) + 'px)';
    
    // Update button states
    document.getElementById('btnPrev').disabled = currentSlide === 0;
    document.getElementById('btnNext').disabled = currentSlide >= maxSlide;
}

// Init slider
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('btnPrev').disabled = true;
});

// ============================================
// FILTER
// ============================================
function filterTable() {
    var kelas = document.getElementById('filterKelas').value;
    var jk = document.getElementById('filterJK').value;
    var rows = document.querySelectorAll('#tabelDokcil tbody tr');
    
    rows.forEach(function(row) {
        var rowKelas = row.getAttribute('data-kelas');
        var rowJK = row.getAttribute('data-jk');
        var show = true;
        if(kelas !== '' && rowKelas !== kelas) show = false;
        if(jk !== '' && rowJK !== jk) show = false;
        row.style.display = show ? '' : 'none';
    });
}

function resetFilter() {
    document.getElementById('filterKelas').value = '';
    document.getElementById('filterJK').value = '';
    filterTable();
}

// ============================================
// CETAK SK
// ============================================
function cetakSK(id) {
    fetch('../proses/get_dokcil.php?id=' + id)
        .then(r => r.json())
        .then(data => {
            var win = window.open('', '_blank', 'width=800,height=600');
            win.document.write(generateSK(data));
            win.document.close();
            setTimeout(() => win.print(), 1000);
        });
}

function cetakSemua() {
    Swal.fire({
        title: 'Cetak Semua SK Dokcil',
        text: 'Pilih kelas yang ingin dicetak:',
        input: 'select',
        inputOptions: {
            'semua': '📋 Semua Kelas',
            '1A': 'Kelas 1A', '1B': 'Kelas 1B',
            '2A': 'Kelas 2A', '2B': 'Kelas 2B', '2C': 'Kelas 2C',
            '3A': 'Kelas 3A', '3B': 'Kelas 3B',
            '4A': 'Kelas 4A', '4B': 'Kelas 4B', '4C': 'Kelas 4C',
            '5A': 'Kelas 5A', '5B': 'Kelas 5B',
            '6A': 'Kelas 6A', '6B': 'Kelas 6B'
        },
        showCancelButton: true,
        confirmButtonText: 'Cetak',
        confirmButtonColor: '#1D6F42',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if(result.isConfirmed) {
            window.open('../proses/cetak_semua_dokcil.php?kelas=' + result.value, '_blank');
        }
    });
}

function generateSK(data) {
    var today = new Date();
    var bulan = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    var tgl = today.getDate() + ' ' + bulan[today.getMonth()] + ' ' + today.getFullYear();
    
    return `<!DOCTYPE html><html><head><title>SK Dokcil - ${data.nama}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Times New Roman',serif;padding:40px 50px;color:#000;font-size:14px;line-height:1.6}
.kop{text-align:center;margin-bottom:20px}
.kop .logo{font-size:50px;margin-bottom:5px}
.kop h3{font-size:16px;font-weight:bold;margin:3px 0;text-transform:uppercase}
.kop h4{font-size:14px;font-weight:bold;margin:3px 0}
.kop p{font-size:11px;margin:2px 0}
.garis-tebal{border-top:3px solid #000;margin:10px 0}
.garis-tipis{border-top:1px solid #000;margin:5px 0}
.judul{text-align:center;font-size:16px;font-weight:bold;margin:25px 0;text-transform:uppercase;text-decoration:underline}
.no-sk{text-align:center;font-size:13px;margin-bottom:25px}
.isi{text-align:justify;margin:20px 0}
.isi .identitas{margin:15px 0 15px 30px}
.isi .identitas table{width:100%}
.isi .identitas td{padding:3px 5px;font-size:13px}
.isi .identitas td.label{width:130px}
.ttd{margin-top:40px;display:flex;justify-content:space-between}
.ttd .kiri{width:45%}
.ttd .kanan{width:45%;text-align:right}
.ttd .nama-ttd{font-weight:bold;margin-top:60px;text-decoration:underline}
.ttd .nip{font-size:12px;margin-top:3px}
.stempel{position:absolute;margin-top:30px;margin-left:-60px;width:100px;height:100px;border:3px solid #c00;border-radius:50%;display:flex;align-items:center;justify-content:center;text-align:center;font-size:10px;color:#c00;font-weight:bold;transform:rotate(-15deg);opacity:.8}
@media print{body{padding:30px}}
</style></head><body>
<div class="kop"><div class="logo">🏥</div><h3>PEMERINTAH KOTA SERANG</h3><h3>DINAS PENDIDIKAN</h3><h4>SD NEGERI 5 KOTA SERANG</h4><p>Jl. KH. Abdul Hadi No. 5, Serang, Banten 42111</p><p>Telp. (0254) 200123 | Email: sdn5kotaserang@gmail.com</p></div>
<div class="garis-tebal"></div><div class="garis-tipis"></div>
<div class="judul">SURAT KEPUTUSAN</div>
<div class="no-sk">Nomor: 421.2/____/SDN5-UKS/${today.getFullYear()}</div>
<div class="judul" style="font-size:14px;text-decoration:none;">TENTANG</div>
<div style="text-align:center;font-weight:bold;font-size:14px;margin:10px 0;">PENGANGKATAN DOKTER CILIK (DOKCIL)<br>UNIT KESEHATAN SEKOLAH (UKS)</div>
<div class="isi">
<p style="margin-left:20px;"><strong>Menimbang :</strong><br>a. Bahwa dalam rangka meningkatkan pelayanan kesehatan di lingkungan sekolah, perlu dibentuk Dokter Cilik (Dokcil);<br>b. Bahwa siswa tersebut di bawah ini dianggap cakap dan memenuhi syarat sebagai Dokter Cilik.</p>
<p style="text-align:center;margin:20px 0;font-weight:bold;">MEMUTUSKAN</p>
<p>Menetapkan siswa tersebut sebagai <strong>DOKTER CILIK (DOKCIL)</strong> pada UKS SD Negeri 5 Kota Serang:</p>
<div class="identitas"><table><tr><td class="label">Nama Lengkap</td><td>: <strong>${data.nama}</strong></td></tr><tr><td class="label">NISN</td><td>: ${data.nisn}</td></tr><tr><td class="label">Kelas</td><td>: ${data.kelas}</td></tr><tr><td class="label">Jenis Kelamin</td><td>: ${data.jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'}</td></tr></table></div>
<p>Surat Keputusan ini berlaku sejak tanggal ditetapkan.</p>
</div>
<div class="ttd"><div class="kiri"><p>Petugas UKS,</p><div style="position:relative;"><div class="stempel"><span>UKS<br>SDN 5<br>KOTA SERANG</span></div></div><p class="nama-ttd"><?= $_SESSION['nama_lengkap'] ?></p><p class="nip">NIP. ..............................</p></div><div class="kanan"><p>Serang, ${tgl}</p><p>Kepala Sekolah,</p><p class="nama-ttd" style="margin-top:100px;">..................................</p><p class="nip">NIP. ..............................</p></div></div>
<script>window.onload=function(){window.print()}<\/script></body></html>`;
}
</script>
</body></html>