<?php
include '../includes/header.php';
include '../includes/sidebar.php';

$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('m');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

// Total kunjungan
$total_kunjungan = mysqli_fetch_assoc(mysqli_query($conn, 
    "SELECT COUNT(*) as total FROM kunjungan k JOIN siswa s ON k.siswa_id = s.id 
     WHERE MONTH(k.tanggal) = '$bulan' AND YEAR(k.tanggal) = '$tahun'"
))['total'];

// Penyakit terbanyak
$penyakit_terbanyak = mysqli_query($conn, 
    "SELECT k.diagnosa, COUNT(*) as jumlah FROM kunjungan k JOIN siswa s ON k.siswa_id = s.id 
     WHERE MONTH(k.tanggal) = '$bulan' AND YEAR(k.tanggal) = '$tahun' AND k.diagnosa != ''
     GROUP BY k.diagnosa ORDER BY jumlah DESC LIMIT 10"
);

// Obat terbanyak
$obat_terbanyak = mysqli_query($conn, 
    "SELECT o.nama_obat, SUM(ko.jumlah) as total FROM kunjungan_obat ko 
     JOIN obat o ON ko.obat_id = o.id JOIN kunjungan k ON ko.kunjungan_id = k.id 
     JOIN siswa s ON k.siswa_id = s.id 
     WHERE MONTH(k.tanggal) = '$bulan' AND YEAR(k.tanggal) = '$tahun'
     GROUP BY o.nama_obat ORDER BY total DESC LIMIT 10"
);

// JK
$jk_l = mysqli_fetch_assoc(mysqli_query($conn, 
    "SELECT COUNT(DISTINCT k.siswa_id) as total FROM kunjungan k JOIN siswa s ON k.siswa_id = s.id 
     WHERE s.jenis_kelamin = 'L' AND MONTH(k.tanggal) = '$bulan' AND YEAR(k.tanggal) = '$tahun'"
))['total'];

$jk_p = mysqli_fetch_assoc(mysqli_query($conn, 
    "SELECT COUNT(DISTINCT k.siswa_id) as total FROM kunjungan k JOIN siswa s ON k.siswa_id = s.id 
     WHERE s.jenis_kelamin = 'P' AND MONTH(k.tanggal) = '$bulan' AND YEAR(k.tanggal) = '$tahun'"
))['total'];

// Siswa terbanyak
$siswa_terbanyak = mysqli_query($conn, 
    "SELECT s.id, s.nama, s.kelas, COUNT(*) as jumlah,
            GROUP_CONCAT(DISTINCT k.diagnosa SEPARATOR ', ') as penyakit
     FROM kunjungan k JOIN siswa s ON k.siswa_id = s.id 
     WHERE MONTH(k.tanggal) = '$bulan' AND YEAR(k.tanggal) = '$tahun'
     GROUP BY k.siswa_id ORDER BY jumlah DESC"
);

// Kunjungan harian
$kunjungan_harian = mysqli_query($conn, 
    "SELECT DATE(k.tanggal) as tgl, COUNT(*) as jumlah FROM kunjungan k 
     JOIN siswa s ON k.siswa_id = s.id 
     WHERE MONTH(k.tanggal) = '$bulan' AND YEAR(k.tanggal) = '$tahun'
     GROUP BY DATE(k.tanggal) ORDER BY tgl"
);

$chart_labels = [];
$chart_data = [];
while($row = mysqli_fetch_assoc($kunjungan_harian)) {
    $chart_labels[] = date('d/m', strtotime($row['tgl']));
    $chart_data[] = $row['jumlah'];
}

// Guru
$guru_list = mysqli_query($conn, "SELECT * FROM guru ORDER BY kelas");
$guru_by_kelas = [];
while($g = mysqli_fetch_assoc($guru_list)) {
    $guru_by_kelas[$g['kelas']] = $g;
}

$nama_bulan = ['', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
$bulan_text = $nama_bulan[(int)$bulan];
$total_obat = mysqli_num_rows($obat_terbanyak);

// Ambil penyakit terbanyak untuk dikirim via WA
$penyakit_arr = [];
mysqli_data_seek($penyakit_terbanyak, 0);
$no_p = 1;
while($p = mysqli_fetch_assoc($penyakit_terbanyak)) {
    if($no_p <= 5) {
        $penyakit_arr[] = $p;
    }
    $no_p++;
}
?>

<style>
    .content-wrapper { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; padding: 20px; }
    .main-content { background: rgba(255,255,255,0.95); border-radius: 25px; padding: 30px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
    .page-title { color: #667eea; font-weight: 700; font-size: 1.8rem; }
    .stat-card { background: white; border-radius: 20px; padding: 20px; text-align: center; border: 1px solid rgba(0,0,0,0.05); transition: all 0.3s; margin-bottom: 20px; }
    .stat-card:hover { transform: translateY(-5px); box-shadow: 0 15px 40px rgba(0,0,0,0.1); }
    .stat-icon { width: 60px; height: 60px; border-radius: 15px; display: flex; align-items: center; justify-content: center; font-size: 2rem; margin: 0 auto 15px; }
    .stat-value { font-size: 2.5rem; font-weight: 700; color: #333; }
    .stat-label { font-size: 0.85rem; color: #666; font-weight: 600; }
    .chart-container { background: white; border-radius: 20px; padding: 25px; margin-bottom: 20px; border: 1px solid rgba(0,0,0,0.05); }
    .chart-container h5 { color: #667eea; font-weight: 700; }
    .filter-bar { background: white; border-radius: 15px; padding: 20px; margin-bottom: 25px; border: 1px solid rgba(0,0,0,0.05); }
    .table-laporan thead { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
    .table-laporan thead th { border: none; padding: 12px 15px; font-weight: 600; }
    .table-laporan tbody td { padding: 12px 15px; vertical-align: middle; }
    .btn-excel { background: #1D6F42; color: white; border: none; padding: 12px 20px; border-radius: 50px; font-weight: 600; cursor: pointer; transition: all 0.3s; font-size: 0.9rem; }
    .btn-excel:hover { background: #145A32; transform: translateY(-2px); }
    .btn-wa { background: linear-gradient(135deg, #075E54, #128C7E); color: white; border: none; padding: 12px 20px; border-radius: 50px; font-weight: 700; cursor: pointer; font-size: 0.9rem; }
    .btn-wa:hover { transform: scale(1.05); }
    .btn-action-bar { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 15px; }
    @media (max-width: 768px) { .main-content { padding: 15px; } .stat-value { font-size: 1.8rem; } .btn-action-bar { flex-direction: column; } }
</style>

<div class="content-wrapper">
    <div class="container-fluid main-content">
        
        <h2 class="page-title mb-4"><i class="bi bi-file-earmark-bar-graph"></i> Laporan UKS - <?= $bulan_text ?> <?= $tahun ?></h2>
        
        <!-- FILTER -->
        <div class="filter-bar">
            <form class="row g-3" method="GET">
                <div class="col-md-6">
                    <label class="form-label fw-bold">Bulan</label>
                    <select class="form-select" name="bulan">
                        <?php for($i=1; $i<=12; $i++): ?>
                        <option value="<?= $i ?>" <?= $i==$bulan?'selected':'' ?>><?= $nama_bulan[$i] ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold">Tahun</label>
                    <input type="number" class="form-control" name="tahun" value="<?= $tahun ?>">
                </div>
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary w-100"><i class="bi bi-filter"></i> Tampilkan</button>
                </div>
            </form>
            <div class="btn-action-bar">
                <button class="btn-excel" onclick="exportKelas()"><i class="bi bi-download me-2"></i>Export per Kelas</button>
                <button class="btn-excel" onclick="exportSemuaKelas()" style="background:#0D4A2A;"><i class="bi bi-download me-2"></i>Export Semua</button>
                <button class="btn-wa" onclick="kirimLaporan()"><i class="bi bi-whatsapp me-2"></i>Kirim ke Guru</button>
            </div>
        </div>
        
        <!-- STATS -->
        <div class="row">
            <div class="col-md-3"><div class="stat-card"><div class="stat-icon bg-primary bg-opacity-10 text-primary">📋</div><div class="stat-value"><?= $total_kunjungan ?></div><div class="stat-label">Total Kunjungan</div></div></div>
            <div class="col-md-3"><div class="stat-card"><div class="stat-icon bg-success bg-opacity-10 text-success">👦</div><div class="stat-value"><?= $jk_l ?></div><div class="stat-label">Laki-laki</div></div></div>
            <div class="col-md-3"><div class="stat-card"><div class="stat-icon bg-danger bg-opacity-10 text-danger">👧</div><div class="stat-value"><?= $jk_p ?></div><div class="stat-label">Perempuan</div></div></div>
            <div class="col-md-3"><div class="stat-card"><div class="stat-icon bg-warning bg-opacity-10 text-warning">💊</div><div class="stat-value"><?= $total_obat ?></div><div class="stat-label">Jenis Obat</div></div></div>
        </div>
        
        <!-- GRAFIK -->
        <div class="chart-container"><h5><i class="bi bi-graph-up"></i> Grafik Kunjungan Harian</h5><canvas id="kunjunganChart" height="100"></canvas></div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="chart-container">
                    <h5><i class="bi bi-virus"></i> 10 Penyakit Terbanyak</h5>
                    <table class="table table-hover table-laporan">
                        <thead><tr><th>No</th><th>Diagnosa</th><th>Jumlah</th></tr></thead>
                        <tbody>
                            <?php $no=1; mysqli_data_seek($penyakit_terbanyak,0); while($r=mysqli_fetch_assoc($penyakit_terbanyak)): ?>
                            <tr><td><?=$no++?></td><td><?=$r['diagnosa']?></td><td><span class="badge bg-primary"><?=$r['jumlah']?> kasus</span></td></tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-md-6">
                <div class="chart-container">
                    <h5><i class="bi bi-capsule"></i> Obat Terbanyak</h5>
                    <table class="table table-hover table-laporan">
                        <thead><tr><th>No</th><th>Nama Obat</th><th>Total</th></tr></thead>
                        <tbody>
                            <?php $no=1; mysqli_data_seek($obat_terbanyak,0); while($r=mysqli_fetch_assoc($obat_terbanyak)): ?>
                            <tr><td><?=$no++?></td><td><?=$r['nama_obat']?></td><td><span class="badge bg-success"><?=$r['total']?> pcs</span></td></tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- TABEL SISWA -->
        <div class="chart-container">
            <h5><i class="bi bi-people"></i> Data Kunjungan Siswa</h5>
            <table class="table table-hover table-laporan">
                <thead><tr><th>No</th><th>Nama Siswa</th><th>Kelas</th><th>Kunjungan</th><th>Diagnosa</th></tr></thead>
                <tbody>
                    <?php $no=1; mysqli_data_seek($siswa_terbanyak,0); while($r=mysqli_fetch_assoc($siswa_terbanyak)): ?>
                    <tr>
                        <td><?=$no++?></td>
                        <td><strong><?=$r['nama']?></strong></td>
                        <td><?=$r['kelas']?></td>
                        <td><span class="badge <?=$r['jumlah']>2?'bg-danger':($r['jumlah']>1?'bg-warning':'bg-info')?>"><?=$r['jumlah']?> kali</span></td>
                        <td><small><?=$r['penyakit']?:'-'?></small></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        
    </div>
</div>

</main></div></div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
var guruData = <?= json_encode($guru_by_kelas) ?>;
var bulanText = '<?= $bulan_text ?>';
var tahun = '<?= $tahun ?>';
var bulan = '<?= $bulan ?>';

// Grafik
new Chart(document.getElementById('kunjunganChart'), {
    type: 'line',
    data: {
        labels: [<?= "'".implode("','",$chart_labels)."'" ?>],
        datasets: [{ label: 'Kunjungan', data: [<?= implode(',',$chart_data) ?>], borderColor: '#667eea', backgroundColor: 'rgba(102,126,234,0.1)', fill: true, tension: 0.4 }]
    },
    options: { responsive: true, scales: { y: { beginAtZero: true } } }
});

// Export per kelas
function exportKelas() {
    var opt = '';
    ['1A','1B','2A','2B','2C','3A','3B','4A','4B','4C','5A','5B','6A','6B'].forEach(function(k){ opt += '<option value="'+k+'">Kelas '+k+'</option>'; });
    Swal.fire({
        title: 'Export Excel per Kelas',
        html: '<select class="form-select" id="pilKelas" style="font-size:1rem;padding:12px;"><option value="">-- Pilih Kelas --</option>'+opt+'</select>',
        showCancelButton: true, confirmButtonText: 'Download', confirmButtonColor: '#1D6F42',
        preConfirm: () => { var k = document.getElementById('pilKelas').value; if(!k) { Swal.showValidationMessage('Pilih kelas!'); } return k; }
    }).then((r) => { if(r.isConfirmed) window.open('../proses/export_kelas.php?bulan='+bulan+'&tahun='+tahun+'&kelas='+r.value, '_blank'); });
}

// Export semua
function exportSemuaKelas() { window.open('../proses/export_all_kelas.php?bulan='+bulan+'&tahun='+tahun, '_blank'); }

// Kirim WA ke Guru
function kirimLaporan() {
    var opt = '';
    for(var k in guruData) {
        opt += '<option value="'+k+'">Kelas '+k+' - '+guruData[k].nama+' ('+guruData[k].no_wa+')</option>';
    }
    
    if(opt === '') {
        Swal.fire({ icon:'warning', title:'Belum Ada Guru', text:'Silakan tambah data guru dulu di halaman Data Guru!' });
        return;
    }
    
    Swal.fire({
        title: '📤 Kirim Laporan ke Guru',
        html: `
            <div class="text-start">
                <div class="mb-3 p-3 rounded" style="background:#e3f2fd;">
                    <h6 class="fw-bold text-primary">👩‍🏫 Pilih Guru Penerima</h6>
                    <select class="form-select" id="pilGuru"><option value="">-- Pilih --</option>${opt}</select>
                </div>
            </div>`,
        showCancelButton: true,
        confirmButtonText: '<i class="bi bi-whatsapp"></i> Kirim WhatsApp',
        confirmButtonColor: '#25D366',
        cancelButtonText: 'Batal',
        preConfirm: () => {
            var k = document.getElementById('pilGuru').value;
            if(!k) { Swal.showValidationMessage('Pilih guru dulu!'); return false; }
            return { nomor: guruData[k].no_wa, nama: guruData[k].nama, kelas: k };
        }
    }).then((r) => {
        if(r.isConfirmed) {
            var pesan = `*📊 LAPORAN KUNJUNGAN UKS*\n`;
            pesan += `━━━━━━━━━━━━━━━━━━━━\n\n`;
            pesan += `📅 *Periode:* ${bulanText} ${tahun}\n`;
            pesan += `🏫 *Kelas:* ${r.value.kelas}\n`;
            pesan += `👩‍🏫 *Kepada Yth:* ${r.value.nama}\n\n`;
            pesan += `━━━━━━━━━━━━━━━━━━━━\n\n`;
            pesan += `📋 *RINGKASAN LAPORAN:*\n\n`;
            pesan += `✅ Total Kunjungan : *<?= $total_kunjungan ?>* siswa\n`;
            pesan += `👦 Laki-laki       : *<?= $jk_l ?>* siswa\n`;
            pesan += `👧 Perempuan       : *<?= $jk_p ?>* siswa\n`;
            pesan += `💊 Jenis Obat      : *<?= $total_obat ?>* jenis\n\n`;
            
            <?php if(!empty($penyakit_arr)): ?>
            pesan += `🦠 *Penyakit Terbanyak:*\n`;
            <?php foreach($penyakit_arr as $i => $p): ?>
            pesan += `   <?= $i+1 ?>. <?= $p['diagnosa'] ?> - <?= $p['jumlah'] ?> kasus\n`;
            <?php endforeach; ?>
            pesan += `\n`;
            <?php endif; ?>
            
            pesan += `🙏 Terima kasih atas perhatiannya.\n`;
            pesan += `_🏥 UKS SDN 5 Kota Serang_`;
            
            window.open('https://wa.me/' + r.value.nomor + '?text=' + encodeURIComponent(pesan), '_blank');
            
            Swal.fire({
                icon: 'success',
                title: '✅ Berhasil!',
                text: 'WhatsApp terbuka untuk ' + r.value.nama,
                timer: 2000,
                showConfirmButton: false
            });
        }
    });
}
</script>
</body></html>