<?php
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<style>
    /* Background dengan efek blur dan gradient */
    .content-wrapper {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        padding: 20px;
        position: relative;
    }
    
    .content-wrapper::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="15" fill="rgba(255,255,255,0.05)"/><circle cx="80" cy="80" r="20" fill="rgba(255,255,255,0.05)"/><circle cx="50" cy="50" r="25" fill="rgba(255,255,255,0.03)"/></svg>');
        background-size: 200px 200px;
        pointer-events: none;
    }
    
    .main-content {
        backdrop-filter: blur(10px);
        background: rgba(255, 255, 255, 0.92);
        border-radius: 25px;
        padding: 25px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        border: 1px solid rgba(255,255,255,0.3);
        position: relative;
        z-index: 1;
        animation: fadeInUp 0.8s ease-out;
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    /* Header dengan efek glassmorphism */
    .glass-header {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(20px);
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 25px;
        border: 1px solid rgba(255,255,255,0.2);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        position: relative;
        overflow: hidden;
    }
    
    .glass-header::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
        animation: shimmer 3s infinite;
    }
    
    @keyframes shimmer {
        0% { transform: translate(-30%, -30%) rotate(0deg); }
        100% { transform: translate(30%, 30%) rotate(180deg); }
    }
    
    .glass-header h1 {
        color: #4facfe !important;
        text-shadow: 0 2px 20px rgba(79, 172, 254, 0.3);
        position: relative;
        z-index: 1;
        font-weight: 700;
    }
    
    .glass-header h1 i {
        color: #4facfe;
        text-shadow: 0 2px 20px rgba(79, 172, 254, 0.4);
    }
    
    /* Tombol Tambah - Elegant Gradient */
    .btn-elegant {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        border: none;
        color: white;
        padding: 12px 30px;
        border-radius: 50px;
        font-weight: 600;
        letter-spacing: 0.5px;
        box-shadow: 0 8px 25px rgba(245, 87, 108, 0.4);
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        position: relative;
        z-index: 1;
        overflow: hidden;
    }
    
    .btn-elegant::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        transition: all 0.5s ease;
        z-index: -1;
    }
    
    .btn-elegant:hover {
        transform: translateY(-3px) scale(1.02);
        box-shadow: 0 12px 35px rgba(245, 87, 108, 0.5);
        color: white;
    }
    
    .btn-elegant:hover::before {
        left: 0;
    }
    
    .btn-elegant i {
        margin-right: 10px;
    }
    
    /* Alert Stok Rendah dengan efek glass */
    .alert-glass {
        background: rgba(255, 193, 7, 0.15);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 193, 7, 0.3);
        border-radius: 15px;
        color: #856404;
        padding: 20px;
        margin-bottom: 25px;
        box-shadow: 0 8px 32px rgba(255, 193, 7, 0.1);
    }
    
    .alert-glass strong {
        color: #856404;
    }
    
    .alert-glass ul {
        margin-top: 10px;
        list-style: none;
        padding-left: 0;
    }
    
    .alert-glass ul li {
        padding: 5px 10px;
        background: rgba(255, 255, 255, 0.3);
        border-radius: 8px;
        margin-bottom: 5px;
        display: inline-block;
        margin-right: 10px;
    }
    
    /* Card Container */
    .card-container {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        padding: 20px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.5);
    }
    
    .card-container .card-header {
        background: transparent;
        border-bottom: 2px solid rgba(0,0,0,0.05);
        padding: 15px 20px;
    }
    
    .card-container .card-header h5 {
        color: #333;
        font-weight: 600;
    }
    
    .card-container .card-header h5 i {
        color: #4facfe;
    }
    
    /* Tabel dengan efek modern */
    #tabelObat {
        border-radius: 15px;
        overflow: hidden;
    }
    
    #tabelObat thead {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }
    
    #tabelObat thead th {
        border: none;
        padding: 15px;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.85rem;
        letter-spacing: 0.5px;
    }
    
    #tabelObat tbody tr {
        transition: all 0.3s ease;
        border-bottom: 1px solid rgba(0,0,0,0.05);
    }
    
    #tabelObat tbody tr:hover {
        background: rgba(102, 126, 234, 0.05);
        transform: scale(1.01);
        box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    }
    
    #tabelObat tbody td {
        padding: 12px 15px;
        vertical-align: middle;
    }
    
    /* Status stok dengan efek */
    .badge-stok {
        padding: 6px 15px;
        border-radius: 50px;
        font-weight: 500;
    }
    
    .badge-stok-habis {
        background: linear-gradient(135deg, #f5576c 0%, #f093fb 100%);
        color: white;
        animation: pulse-danger 1.5s ease-in-out infinite;
    }
    
    .badge-stok-rendah {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        color: white;
        animation: pulse-warning 2s ease-in-out infinite;
    }
    
    .badge-stok-tersedia {
        background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        color: white;
    }
    
    @keyframes pulse-danger {
        0%, 100% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.7; transform: scale(0.95); }
    }
    
    @keyframes pulse-warning {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.7; }
    }
    
    /* Row status dengan efek */
    .table-row-habis {
        background: rgba(245, 87, 108, 0.05) !important;
        border-left: 4px solid #f5576c;
    }
    
    .table-row-rendah {
        background: rgba(255, 193, 7, 0.05) !important;
        border-left: 4px solid #ffc107;
    }
    
    #tabelObat tbody tr.table-row-habis:hover {
        background: rgba(245, 87, 108, 0.1) !important;
    }
    
    #tabelObat tbody tr.table-row-rendah:hover {
        background: rgba(255, 193, 7, 0.1) !important;
    }
    
    /* Modal dengan efek glassmorphism */
    .modal-content {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(20px);
        border-radius: 25px;
        border: 1px solid rgba(255,255,255,0.3);
        box-shadow: 0 25px 80px rgba(0,0,0,0.3);
    }
    
    .modal-header {
        border-radius: 25px 25px 0 0;
        border: none;
        padding: 20px 30px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        color: white;
    }
    
    .modal-header h5 {
        color: white;
    }
    
    .modal-header h5 i {
        color: white;
    }
    
    .modal-body {
        padding: 30px;
    }
    
    .modal-footer {
        border: none;
        padding: 20px 30px;
        border-radius: 0 0 25px 25px;
    }
    
    /* Input dengan efek */
    .form-control, .form-select {
        border-radius: 15px;
        border: 2px solid rgba(0,0,0,0.06);
        padding: 12px 18px;
        transition: all 0.3s ease;
        background: rgba(255,255,255,0.8);
        backdrop-filter: blur(5px);
    }
    
    .form-control:focus, .form-select:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.15);
        transform: translateY(-2px);
    }
    
    .form-label {
        font-weight: 600;
        color: #333;
        margin-bottom: 8px;
        font-size: 0.9rem;
    }
    
    .form-label i {
        color: #4facfe;
        margin-right: 5px;
    }
    
    /* Tombol aksi di tabel */
    .btn-action {
        transition: all 0.3s ease;
        border-radius: 50px;
        padding: 6px 12px;
        margin: 0 3px;
        border: none;
    }
    
    .btn-action:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    .btn-action i {
        font-size: 0.9rem;
    }
    
    /* Floating particles */
    .particles {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 0;
        overflow: hidden;
    }
    
    .particle {
        position: absolute;
        width: 4px;
        height: 4px;
        background: rgba(255,255,255,0.3);
        border-radius: 50%;
        animation: float linear infinite;
    }
    
    @keyframes float {
        0% {
            transform: translateY(100vh) rotate(0deg);
            opacity: 0;
        }
        10% {
            opacity: 1;
        }
        90% {
            opacity: 1;
        }
        100% {
            transform: translateY(-100vh) rotate(720deg);
            opacity: 0;
        }
    }
    
    /* Card Info - Semua Biru dengan efek klik */
    .info-card {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(20px);
        border-radius: 20px;
        padding: 20px;
        border: 1px solid rgba(255,255,255,0.2);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        cursor: pointer;
        position: relative;
        overflow: hidden;
        color: white;
        text-shadow: 0 2px 10px rgba(0,0,0,0.1);
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    }
    
    .info-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(135deg, rgba(255,255,255,0.2) 0%, transparent 100%);
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    
    .info-card:hover {
        transform: translateY(-10px) scale(1.02);
        box-shadow: 0 15px 40px rgba(0,0,0,0.2);
    }
    
    .info-card:hover::before {
        opacity: 1;
    }
    
    .info-card .card-icon {
        font-size: 2.5rem;
        margin-bottom: 10px;
        display: block;
        opacity: 0.9;
    }
    
    .info-card h5 {
        font-weight: 300;
        opacity: 0.9;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    .info-card h2 {
        font-weight: 700;
        font-size: 2.5rem;
        margin: 10px 0 0;
        text-shadow: 0 2px 20px rgba(0,0,0,0.2);
    }
    
    .info-card small {
        opacity: 0.7;
        font-size: 0.75rem;
    }
    
    /* Card Stok Rendah - Warna Orange */
    .card-rendah {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%) !important;
    }
    
    /* Card Stok Habis - Warna Merah */
    .card-habis {
        background: linear-gradient(135deg, #f5576c 0%, #f093fb 100%) !important;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .content-wrapper {
            padding: 10px;
        }
        
        .main-content {
            padding: 15px;
            border-radius: 15px;
        }
        
        .glass-header {
            flex-direction: column;
            gap: 15px;
        }
        
        .btn-elegant {
            width: 100%;
        }
        
        .modal-dialog {
            margin: 10px;
        }
        
        .info-card h2 {
            font-size: 1.8rem;
        }
    }
    
    /* Scrollbar custom */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: rgba(0,0,0,0.05);
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
    }
</style>

<!-- Floating Particles -->
<div class="particles" id="particles"></div>

<div class="content-wrapper">
    <div class="container-fluid main-content">
        <!-- Header dengan efek glassmorphism -->
        <div class="glass-header d-flex justify-content-between align-items-center">
            <h1 class="h2 mb-0">
                <i class="bi bi-capsule me-2"></i> Manajemen Obat
            </h1>
            <button class="btn-elegant" data-bs-toggle="modal" data-bs-target="#modalObat">
                <i class="bi bi-plus-circle"></i> Tambah Obat
            </button>
        </div>

        <!-- Alert Stok Rendah dengan efek glass -->
        <?php
        $stok_rendah = mysqli_query($conn, "SELECT * FROM obat WHERE stok <= stok_minimum AND stok > 0");
        if (mysqli_num_rows($stok_rendah) > 0):
        ?>
        <div class="alert-glass alert-dismissible fade show" role="alert">
            <div class="d-flex align-items-start">
                <div class="me-3" style="font-size: 2rem;">⚠️</div>
                <div>
                    <strong>Peringatan!</strong> Beberapa obat memiliki stok rendah:
                    <ul>
                        <?php while($obat = mysqli_fetch_assoc($stok_rendah)): ?>
                        <li>💊 <?= $obat['nama_obat'] ?> - Stok: <?= $obat['stok'] ?> <?= $obat['satuan'] ?></li>
                        <?php endwhile; ?>
                    </ul>
                </div>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Card Info Statistik Obat - Semua Bisa Diklik -->
        <div class="row mb-4 g-3">
            <div class="col-md-3">
                <div class="info-card" onclick="filterSemua()">
                    <span class="card-icon">💊</span>
                    <h5>Total Obat <i class="bi bi-search" style="font-size: 0.8rem; opacity: 0.7;"></i></h5>
                    <h2><?= mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM obat"))['total'] ?></h2>
                    <small>Klik untuk lihat semua</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="info-card" onclick="filterTersedia()">
                    <span class="card-icon">✅</span>
                    <h5>Stok Tersedia <i class="bi bi-search" style="font-size: 0.8rem; opacity: 0.7;"></i></h5>
                    <h2><?= mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM obat WHERE stok > stok_minimum"))['total'] ?></h2>
                    <small>Klik untuk lihat data</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="info-card card-rendah" onclick="filterStokRendah()">
                    <span class="card-icon">⚠️</span>
                    <h5>Stok Rendah <i class="bi bi-search" style="font-size: 0.8rem; opacity: 0.7;"></i></h5>
                    <h2><?= mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM obat WHERE stok <= stok_minimum AND stok > 0"))['total'] ?></h2>
                    <small>Klik untuk lihat data</small>
                </div>
            </div>
            <div class="col-md-3">
                <div class="info-card card-habis" onclick="filterStokHabis()">
                    <span class="card-icon">🚫</span>
                    <h5>Stok Habis <i class="bi bi-search" style="font-size: 0.8rem; opacity: 0.7;"></i></h5>
                    <h2><?= mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM obat WHERE stok = 0"))['total'] ?></h2>
                    <small>Klik untuk lihat data</small>
                </div>
            </div>
        </div>

        <!-- Tabel Obat -->
        <div class="card-container">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap">
                <h5 class="mb-0">
                    <i class="bi bi-table me-2"></i> Daftar Seluruh Obat
                </h5>
                <div>
                    <span class="badge bg-primary bg-opacity-10 text-primary me-2">
                        <i class="bi bi-clock me-1"></i> Update: <?= date('H:i') ?>
                    </span>
                    <button class="btn btn-sm btn-outline-secondary" onclick="resetFilter()" title="Reset Filter">
                        <i class="bi bi-arrow-counterclockwise"></i>
                    </button>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover" id="tabelObat">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th width="12%">Kode Obat</th>
                                <th width="20%">Nama Obat</th>
                                <th width="12%">Jenis</th>
                                <th width="10%">Stok</th>
                                <th width="8%">Satuan</th>
                                <th width="10%">Stok Min</th>
                                <th width="10%">Status</th>
                                <th width="13%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM obat ORDER BY nama_obat";
                            $result = mysqli_query($conn, $query);
                            $no = 1;
                            while($row = mysqli_fetch_assoc($result)):
                                $row_class = $row['stok'] == 0 ? 'table-row-habis' : 
                                            ($row['stok'] <= $row['stok_minimum'] ? 'table-row-rendah' : '');
                            ?>
                            <tr class="<?= $row_class ?>">
                                <td class="text-center fw-bold"><?= $no++ ?></td>
                                <td><code><?= $row['kode_obat'] ?></code></td>
                                <td><strong><?= $row['nama_obat'] ?></strong></td>
                                <td><?= $row['jenis_obat'] ?></td>
                                <td class="text-center fw-bold"><?= $row['stok'] ?></td>
                                <td><?= $row['satuan'] ?></td>
                                <td><?= $row['stok_minimum'] ?></td>
                                <td>
                                    <?php if ($row['stok'] == 0): ?>
                                        <span class="badge badge-stok badge-stok-habis">
                                            <i class="bi bi-x-circle me-1"></i>Habis
                                        </span>
                                    <?php elseif ($row['stok'] <= $row['stok_minimum']): ?>
                                        <span class="badge badge-stok badge-stok-rendah">
                                            <i class="bi bi-exclamation-triangle me-1"></i>Stok Rendah
                                        </span>
                                    <?php else: ?>
                                        <span class="badge badge-stok badge-stok-tersedia">
                                            <i class="bi bi-check-circle me-1"></i>Tersedia
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-warning btn-action" onclick="editObat(<?= $row['id'] ?>)" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-success btn-action" onclick="tambahStok(<?= $row['id'] ?>)" title="Tambah Stok">
                                            <i class="bi bi-plus-circle"></i>
                                        </button>
                                        <button class="btn btn-danger btn-action" onclick="hapusObat(<?= $row['id'] ?>)" title="Hapus">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Obat -->
<div class="modal fade" id="modalObat" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="bi bi-plus-circle me-2"></i> Tambah Obat Baru
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="formObat">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-hash"></i> Kode Obat <span class="text-danger">*</span>
                        </label>
                        <input type="text" class="form-control" name="kode_obat" required 
                               placeholder="Contoh: OB-001">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-capsule"></i> Nama Obat <span class="text-danger">*</span>
                        </label>
                        <input type="text" class="form-control" name="nama_obat" required 
                               placeholder="Masukkan nama obat">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-tag"></i> Jenis Obat
                        </label>
                        <input type="text" class="form-control" name="jenis_obat" 
                               placeholder="Contoh: Antipiretik, Antibiotik, dll">
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-box"></i> Stok <span class="text-danger">*</span>
                            </label>
                            <input type="number" class="form-control" name="stok" required 
                                   placeholder="Jumlah stok" min="0">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-rulers"></i> Satuan <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" name="satuan" value="Tablet"
                                   placeholder="Contoh: Tablet, Botol, Strip">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-flag"></i> Stok Minimum
                        </label>
                        <input type="number" class="form-control" name="stok_minimum" value="10"
                               placeholder="Peringatan jika stok di bawah ini">
                        <small class="text-muted">Jika stok di bawah angka ini, akan muncul peringatan</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle me-1"></i> Batal
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-1"></i> Simpan Obat
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Obat -->
<div class="modal fade" id="modalEditObat" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title">
                    <i class="bi bi-pencil-square me-2"></i> Edit Obat
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="formEditObat">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-hash"></i> Kode Obat <span class="text-danger">*</span>
                        </label>
                        <input type="text" class="form-control" name="kode_obat" id="edit_kode_obat" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-capsule"></i> Nama Obat <span class="text-danger">*</span>
                        </label>
                        <input type="text" class="form-control" name="nama_obat" id="edit_nama_obat" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-tag"></i> Jenis Obat
                        </label>
                        <input type="text" class="form-control" name="jenis_obat" id="edit_jenis_obat">
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-box"></i> Stok <span class="text-danger">*</span>
                            </label>
                            <input type="number" class="form-control" name="stok" id="edit_stok" required min="0">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-rulers"></i> Satuan <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" name="satuan" id="edit_satuan">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">
                            <i class="bi bi-flag"></i> Stok Minimum
                        </label>
                        <input type="number" class="form-control" name="stok_minimum" id="edit_stok_minimum">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle me-1"></i> Batal
                    </button>
                    <button type="submit" class="btn btn-warning text-white">
                        <i class="bi bi-arrow-repeat me-1"></i> Update Obat
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

</main>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    // Create floating particles
    function createParticles() {
        const container = document.getElementById('particles');
        for (let i = 0; i < 30; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.width = (Math.random() * 4 + 2) + 'px';
            particle.style.height = particle.style.width;
            particle.style.animationDuration = (Math.random() * 20 + 10) + 's';
            particle.style.animationDelay = (Math.random() * 10) + 's';
            container.appendChild(particle);
        }
    }
    createParticles();
    
    // DataTable
    var table = $('#tabelObat').DataTable({
        responsive: true,
        language: {
            url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/id.json'
        },
        ordering: true,
        columnDefs: [
            { orderable: false, targets: [0, 8] }
        ]
    });
    
    // Submit Form Tambah Obat
    $('#formObat').submit(function(e) {
        e.preventDefault();
        
        $.ajax({
            url: '../proses/obat_proses.php',
            type: 'POST',
            data: $(this).serialize() + '&action=add',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: 'Obat berhasil ditambahkan',
                        showConfirmButton: false,
                        timer: 1500,
                        background: 'rgba(255,255,255,0.95)',
                        backdrop: 'rgba(0,0,0,0.5)'
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal!',
                        text: response.message,
                        background: 'rgba(255,255,255,0.95)',
                        backdrop: 'rgba(0,0,0,0.5)'
                    });
                }
            }
        });
    });
    
    // Submit Form Edit Obat
    $('#formEditObat').submit(function(e) {
        e.preventDefault();
        
        $.ajax({
            url: '../proses/obat_proses.php',
            type: 'POST',
            data: $(this).serialize() + '&action=edit',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: 'Obat berhasil diupdate',
                        showConfirmButton: false,
                        timer: 1500,
                        background: 'rgba(255,255,255,0.95)',
                        backdrop: 'rgba(0,0,0,0.5)'
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal!',
                        text: response.message,
                        background: 'rgba(255,255,255,0.95)',
                        backdrop: 'rgba(0,0,0,0.5)'
                    });
                }
            }
        });
    });
});

// Fungsi Filter Semua Obat
function filterSemua() {
    var table = $('#tabelObat').DataTable();
    table.column(7).search('').draw();
    
    Swal.fire({
        icon: 'info',
        title: 'Menampilkan Semua Obat',
        text: 'Semua data obat ditampilkan',
        timer: 1500,
        showConfirmButton: false,
        background: 'rgba(255,255,255,0.95)',
        backdrop: 'rgba(0,0,0,0.5)'
    });
}

// Fungsi Filter Stok Tersedia
function filterTersedia() {
    var table = $('#tabelObat').DataTable();
    table.column(7).search('Tersedia').draw();
    
    Swal.fire({
        icon: 'success',
        title: 'Menampilkan Stok Tersedia',
        text: 'Data obat dengan stok tersedia telah difilter',
        timer: 1500,
        showConfirmButton: false,
        background: 'rgba(255,255,255,0.95)',
        backdrop: 'rgba(0,0,0,0.5)'
    });
}

// Fungsi Filter Stok Rendah
function filterStokRendah() {
    var table = $('#tabelObat').DataTable();
    table.column(7).search('Stok Rendah').draw();
    
    Swal.fire({
        icon: 'warning',
        title: 'Menampilkan Stok Rendah',
        text: 'Data obat dengan stok rendah telah difilter',
        timer: 1500,
        showConfirmButton: false,
        background: 'rgba(255,255,255,0.95)',
        backdrop: 'rgba(0,0,0,0.5)'
    });
}

// Fungsi Filter Stok Habis
function filterStokHabis() {
    var table = $('#tabelObat').DataTable();
    table.column(7).search('Habis').draw();
    
    Swal.fire({
        icon: 'error',
        title: 'Menampilkan Stok Habis',
        text: 'Data obat dengan stok habis telah difilter',
        timer: 1500,
        showConfirmButton: false,
        background: 'rgba(255,255,255,0.95)',
        backdrop: 'rgba(0,0,0,0.5)'
    });
}

// Reset Filter
function resetFilter() {
    var table = $('#tabelObat').DataTable();
    table.column(7).search('').draw();
    
    Swal.fire({
        icon: 'info',
        title: 'Filter Direset',
        text: 'Menampilkan semua data obat',
        timer: 1500,
        showConfirmButton: false,
        background: 'rgba(255,255,255,0.95)',
        backdrop: 'rgba(0,0,0,0.5)'
    });
}

// Fungsi Edit Obat
function editObat(id) {
    $.ajax({
        url: '../proses/obat_proses.php',
        type: 'GET',
        data: { action: 'get_data', id: id },
        dataType: 'json',
        success: function(data) {
            $('#edit_id').val(data.id);
            $('#edit_kode_obat').val(data.kode_obat);
            $('#edit_nama_obat').val(data.nama_obat);
            $('#edit_jenis_obat').val(data.jenis_obat);
            $('#edit_stok').val(data.stok);
            $('#edit_satuan').val(data.satuan);
            $('#edit_stok_minimum').val(data.stok_minimum);
            
            $('#modalEditObat').modal('show');
        }
    });
}

// Fungsi Tambah Stok
function tambahStok(id) {
    Swal.fire({
        title: 'Tambah Stok Obat',
        html: `
            <div style="text-align: left;">
                <label class="form-label">Masukkan jumlah stok tambahan</label>
                <input type="number" id="jumlah_stok" class="form-control" 
                       placeholder="Jumlah..." min="1" step="1" value="1">
            </div>
        `,
        showCancelButton: true,
        confirmButtonColor: '#667eea',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Tambah',
        cancelButtonText: 'Batal',
        background: 'rgba(255,255,255,0.95)',
        backdrop: 'rgba(0,0,0,0.5)',
        preConfirm: () => {
            const value = document.getElementById('jumlah_stok').value;
            if (!value || value < 1) {
                Swal.showValidationMessage('Jumlah minimal 1');
                return false;
            }
            return value;
        }
    }).then((result) => {
        if (result.isConfirmed && result.value) {
            $.ajax({
                url: '../proses/obat_proses.php',
                type: 'POST',
                data: { 
                    action: 'tambah_stok', 
                    id: id, 
                    jumlah: result.value 
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil!',
                            text: 'Stok obat berhasil ditambahkan',
                            showConfirmButton: false,
                            timer: 1500,
                            background: 'rgba(255,255,255,0.95)',
                            backdrop: 'rgba(0,0,0,0.5)'
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal!',
                            text: response.message,
                            background: 'rgba(255,255,255,0.95)',
                            backdrop: 'rgba(0,0,0,0.5)'
                        });
                    }
                }
            });
        }
    });
}

// Fungsi Hapus Obat
function hapusObat(id) {
    Swal.fire({
        title: 'Konfirmasi Hapus',
        text: 'Apakah Anda yakin ingin menghapus obat ini?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal',
        background: 'rgba(255,255,255,0.95)',
        backdrop: 'rgba(0,0,0,0.5)'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../proses/obat_proses.php',
                type: 'POST',
                data: { action: 'delete', id: id },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil!',
                            text: 'Obat berhasil dihapus',
                            showConfirmButton: false,
                            timer: 1500,
                            background: 'rgba(255,255,255,0.95)',
                            backdrop: 'rgba(0,0,0,0.5)'
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal!',
                            text: response.message,
                            background: 'rgba(255,255,255,0.95)',
                            backdrop: 'rgba(0,0,0,0.5)'
                        });
                    }
                }
            });
        }
    });
}
</script>

</body>
</html>