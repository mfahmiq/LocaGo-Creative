<?php
include '../includes/header.php';
include '../includes/sidebar.php';

// Ambil data untuk dropdown obat
$obat_list = mysqli_query($conn, "SELECT * FROM obat WHERE stok > 0 ORDER BY nama_obat");
?>

<style>
    /* Background dengan efek blur dan gradient */
    .content-wrapper {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        padding: 20px;
        position: relative;
    }
    
    .content-wrapper::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="15" fill="rgba(255,255,255,0.05)"/><circle cx="80" cy="80" r="20" fill="rgba(255,255,255,0.05)"/><circle cx="50" cy="50" r="25" fill="rgba(255,255,255,0.03)"/></svg>');
        background-size: 200px 200px;
        pointer-events: none;
    }
    
    .main-content {
        backdrop-filter: blur(10px);
        background: rgba(255, 255, 255, 0.92);
        border-radius: 25px;
        padding: 25px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        border: 1px solid rgba(255,255,255,0.3);
        position: relative;
        z-index: 1;
        animation: fadeInUp 0.8s ease-out;
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .glass-header {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(20px);
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 25px;
        border: 1px solid rgba(255,255,255,0.2);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        position: relative;
        overflow: hidden;
    }
    
    .glass-header::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
        animation: shimmer 3s infinite;
    }
    
    @keyframes shimmer {
        0% { transform: translate(-30%, -30%) rotate(0deg); }
        100% { transform: translate(30%, 30%) rotate(180deg); }
    }
    
    .glass-header h1 {
        color: #4facfe !important;
        text-shadow: 0 2px 20px rgba(79, 172, 254, 0.3);
        position: relative;
        z-index: 1;
        font-weight: 700;
    }
    
    .btn-elegant {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        border: none;
        color: white;
        padding: 12px 30px;
        border-radius: 50px;
        font-weight: 600;
        letter-spacing: 0.5px;
        box-shadow: 0 8px 25px rgba(245, 87, 108, 0.4);
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        position: relative;
        z-index: 1;
        overflow: hidden;
    }
    
    .btn-elegant::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        transition: all 0.5s ease;
        z-index: -1;
    }
    
    .btn-elegant:hover {
        transform: translateY(-3px) scale(1.02);
        box-shadow: 0 12px 35px rgba(245, 87, 108, 0.5);
        color: white;
    }
    
    .btn-elegant:hover::before {
        left: 0;
    }
    
    .card-container {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        padding: 20px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.5);
    }
    
    .card-container .card-header {
        background: transparent;
        border-bottom: 2px solid rgba(0,0,0,0.05);
        padding: 15px 20px;
    }
    
    .card-container .card-header h5 {
        color: #333;
        font-weight: 600;
    }
    
    #tabelKunjungan {
        border-radius: 15px;
        overflow: hidden;
    }
    
    #tabelKunjungan thead {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }
    
    #tabelKunjungan thead th {
        border: none;
        padding: 15px;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.85rem;
        letter-spacing: 0.5px;
    }
    
    #tabelKunjungan tbody tr {
        transition: all 0.3s ease;
        border-bottom: 1px solid rgba(0,0,0,0.05);
    }
    
    #tabelKunjungan tbody tr:hover {
        background: rgba(102, 126, 234, 0.05);
        transform: scale(1.01);
        box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    }
    
    #tabelKunjungan tbody td {
        padding: 12px 15px;
        vertical-align: middle;
    }
    
    /* Search Suggestion Styles */
    .search-wrapper {
        position: relative;
    }
    
    .search-suggestions {
        position: absolute;
        z-index: 9999;
        width: 100%;
        max-height: 250px;
        overflow-y: auto;
        background: white;
        border: 1px solid rgba(0,0,0,0.1);
        border-radius: 10px;
        margin-top: 5px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }
    
    .search-suggestions .list-group-item {
        border: none;
        border-bottom: 1px solid rgba(0,0,0,0.05);
        padding: 12px 15px;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .search-suggestions .list-group-item:hover {
        background: rgba(102, 126, 234, 0.05);
        transform: translateX(5px);
    }
    
    .search-suggestions .list-group-item:last-child {
        border-bottom: none;
    }
    
    /* Modal Styles */
    .modal-content {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(20px);
        border-radius: 25px;
        border: 1px solid rgba(255,255,255,0.3);
        box-shadow: 0 25px 80px rgba(0,0,0,0.3);
    }
    
    .modal-header {
        border-radius: 25px 25px 0 0;
        border: none;
        padding: 20px 30px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        color: white;
    }
    
    .modal-body {
        padding: 30px;
    }
    
    .modal-footer {
        border: none;
        padding: 20px 30px;
        border-radius: 0 0 25px 25px;
    }
    
    .form-control, .form-select {
        border-radius: 15px;
        border: 2px solid rgba(0,0,0,0.06);
        padding: 12px 18px;
        transition: all 0.3s ease;
        background: rgba(255,255,255,0.8);
    }
    
    .form-control:focus, .form-select:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.15);
        outline: none;
    }
    
    .form-label {
        font-weight: 600;
        color: #333;
        margin-bottom: 8px;
        font-size: 0.9rem;
    }
    
    .btn-action {
        transition: all 0.3s ease;
        border-radius: 50px;
        padding: 6px 12px;
        margin: 0 3px;
        border: none;
    }
    
    .btn-action:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    .card-obat {
        background: rgba(102, 126, 234, 0.05);
        border: 2px dashed rgba(102, 126, 234, 0.3);
        border-radius: 15px;
    }
    
    .card-obat .card-header {
        background: rgba(102, 126, 234, 0.1);
        border-radius: 15px 15px 0 0;
    }
    
    .badge-status {
        padding: 8px 15px;
        font-size: 0.85rem;
    }
    
    ::-webkit-scrollbar {
        width: 6px;
    }
    
    ::-webkit-scrollbar-track {
        background: rgba(0,0,0,0.05);
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 10px;
    }
    
    @media (max-width: 768px) {
        .content-wrapper {
            padding: 10px;
        }
        .main-content {
            padding: 15px;
            border-radius: 15px;
        }
        .glass-header {
            flex-direction: column;
            gap: 15px;
        }
        .btn-elegant {
            width: 100%;
        }
    }
</style>

<div class="content-wrapper">
    <div class="container-fluid main-content">
        <!-- Header -->
        <div class="glass-header d-flex justify-content-between align-items-center">
            <h1 class="h2 mb-0">
                <i class="bi bi-clipboard2-plus me-2"></i> Form Kunjungan UKS
            </h1>
            <button class="btn-elegant" data-bs-toggle="modal" data-bs-target="#modalKunjungan">
                <i class="bi bi-plus-circle"></i> Catat Kunjungan Baru
            </button>
        </div>

        <!-- Tabel Kunjungan -->
        <div class="card-container">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap">
                <h5 class="mb-0">
                    <i class="bi bi-calendar3 me-2"></i> Kunjungan Hari Ini (<?= tgl_indo(date('Y-m-d')) ?>)
                </h5>
                <span class="badge bg-primary bg-opacity-10 text-primary badge-status">
                    <i class="bi bi-clock me-1"></i> Real-time
                </span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover" id="tabelKunjungan">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th width="12%">Nama Siswa</th>
                                <th width="8%">Kelas</th>
                                <th width="12%">Keluhan</th>
                                <th width="10%">Diagnosa</th>
                                <th width="10%">Penanganan</th>
                                <th width="15%">Obat Diberikan</th>
                                <th width="10%">Petugas</th>
                                <th width="8%">Jam</th>
                                <th width="10%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT k.*, s.nama, s.kelas, u.nama_lengkap as petugas 
                                     FROM kunjungan k 
                                     JOIN siswa s ON k.siswa_id = s.id 
                                     LEFT JOIN users u ON k.petugas_id = u.id 
                                     WHERE k.tanggal = CURDATE() 
                                     ORDER BY k.created_at DESC";
                            $result = mysqli_query($conn, $query);
                            $no = 1;
                            while($row = mysqli_fetch_assoc($result)):
                            ?>
                            <tr>
                                <td class="text-center fw-bold"><?= $no++ ?></td>
                                <td><strong><?= $row['nama'] ?></strong></td>
                                <td><span class="badge bg-primary bg-opacity-10 text-primary"><?= $row['kelas'] ?></span></td>
                                <td><?= $row['keluhan'] ?></td>
                                <td><span class="badge bg-info bg-opacity-10 text-info"><?= $row['diagnosa'] ?></span></td>
                                <td><?= $row['penanganan'] ?></td>
                                <td>
                                    <?php
                                    $obat_query = mysqli_query($conn, 
                                        "SELECT o.nama_obat, ko.jumlah 
                                         FROM kunjungan_obat ko 
                                         JOIN obat o ON ko.obat_id = o.id 
                                         WHERE ko.kunjungan_id = " . $row['id']
                                    );
                                    while($obat = mysqli_fetch_assoc($obat_query)) {
                                        echo '<span class="badge bg-success bg-opacity-10 text-success me-1">💊 '.$obat['nama_obat'].' ('.$obat['jumlah'].')</span><br>';
                                    }
                                    ?>
                                </td>
                                <td><span class="badge bg-secondary bg-opacity-10 text-secondary"><i class="bi bi-person me-1"></i><?= $row['petugas'] ?></span></td>
                                <td><span class="badge bg-warning bg-opacity-10 text-warning"><i class="bi bi-clock me-1"></i><?= date('H:i', strtotime($row['created_at'])) ?></span></td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-info btn-action" onclick="editKunjungan(<?= $row['id'] ?>)" title="Edit"><i class="bi bi-pencil"></i></button>
                                        <button class="btn btn-danger btn-action" onclick="hapusKunjungan(<?= $row['id'] ?>)" title="Hapus"><i class="bi bi-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Kunjungan -->
<div class="modal fade" id="modalKunjungan" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i> Catat Kunjungan Baru</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="formKunjungan">
                <div class="modal-body">
                    <div class="row">
                        <!-- Cari Siswa -->
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="bi bi-person"></i> Cari Siswa <span class="text-danger">*</span></label>
                            <div class="search-wrapper">
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                                    <input type="text" class="form-control" id="searchSiswa" placeholder="Ketik nama atau NISN siswa..." autocomplete="off">
                                </div>
                                <div class="search-suggestions" id="suggestionsSiswa" style="display: none;"></div>
                            </div>
                            <input type="hidden" name="siswa_id" id="selectedSiswaId">
                            <div id="selectedSiswaInfo" style="display: none; margin-top: 8px;">
                                <span class="badge bg-success"><i class="bi bi-check-circle"></i> <span id="siswaName"></span></span>
                                <button type="button" class="btn btn-sm btn-outline-danger ms-2" onclick="clearSiswa()"><i class="bi bi-x"></i></button>
                            </div>
                        </div>

                        <!-- Cari Petugas -->
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="bi bi-person-badge"></i> Cari Petugas <span class="text-danger">*</span></label>
                            <div class="search-wrapper">
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                                    <input type="text" class="form-control" id="searchPetugas" placeholder="Ketik nama petugas..." autocomplete="off" value="<?= $_SESSION['nama_lengkap'] ?>">
                                </div>
                                <div class="search-suggestions" id="suggestionsPetugas" style="display: none;"></div>
                            </div>
                            <input type="hidden" name="petugas_id" id="selectedPetugasId" value="<?= $_SESSION['user_id'] ?>">
                            <div id="selectedPetugasInfo" style="margin-top: 8px;">
                                <span class="badge bg-info"><i class="bi bi-check-circle"></i> <span id="petugasName"><?= $_SESSION['nama_lengkap'] ?></span></span>
                                <button type="button" class="btn btn-sm btn-outline-danger ms-2" onclick="clearPetugas()"><i class="bi bi-x"></i></button>
                            </div>
                        </div>

                        <div class="col-md-12 mb-3">
                            <label class="form-label"><i class="bi bi-chat"></i> Keluhan <span class="text-danger">*</span></label>
                            <textarea class="form-control" name="keluhan" rows="2" required placeholder="Masukkan keluhan siswa..."></textarea>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="bi bi-stethoscope"></i> Diagnosa Ringan</label>
                            <input type="text" class="form-control" name="diagnosa" list="diagnosaList" placeholder="Ketik atau pilih diagnosa">
                            <datalist id="diagnosaList">
                                <option value="Demam"><option value="Pusing/Sakit Kepala"><option value="Sakit Perut"><option value="Luka Ringan"><option value="Mual"><option value="Batuk"><option value="Pilek"><option value="Alergi"><option value="Sariawan"><option value="Lainnya">
                            </datalist>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label"><i class="bi bi-heart-pulse"></i> Penanganan</label>
                            <input type="text" class="form-control" name="penanganan" list="penangananList" placeholder="Ketik atau pilih penanganan">
                            <datalist id="penangananList">
                                <option value="Istirahat"><option value="Pemberian Obat"><option value="Kompres"><option value="Perban/Plaster"><option value="Rujuk ke Puskesmas"><option value="Observasi">
                            </datalist>
                        </div>
                    </div>
                    
                    <!-- Obat -->
                    <div class="card card-obat mb-3">
                        <div class="card-header bg-light">
                            <h6 class="mb-0"><i class="bi bi-capsule me-2"></i>Obat yang Diberikan</h6>
                        </div>
                        <div class="card-body">
                            <div id="obatContainer">
                                <div class="row obat-item mb-2 align-items-end">
                                    <div class="col-md-7">
                                        <select class="form-select" name="obat_id[]">
                                            <option value="">-- Pilih Obat --</option>
                                            <?php 
                                            mysqli_data_seek($obat_list, 0);
                                            while($obat = mysqli_fetch_assoc($obat_list)): 
                                            ?>
                                            <option value="<?= $obat['id'] ?>"><?= $obat['nama_obat'] ?> (Stok: <?= $obat['stok'] ?>)</option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <input type="number" class="form-control" name="jumlah_obat[]" placeholder="Jumlah" min="1" value="1">
                                    </div>
                                    <div class="col-md-2">
                                        <button type="button" class="btn btn-danger remove-obat w-100"><i class="bi bi-x"></i></button>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-success btn-sm" id="tambahObat"><i class="bi bi-plus"></i> Tambah Obat</button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="bi bi-x-circle me-1"></i> Batal</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Kunjungan</button>
                </div>
            </form>
        </div>
    </div>
</div>

</main>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    // DataTable
    $('#tabelKunjungan').DataTable({
        responsive: true,
        language: { url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/id.json' },
        columnDefs: [{ orderable: false, targets: [0, 9] }]
    });

    // ========== SEARCH SISWA ==========
    var searchTimeout;
    $('#searchSiswa').on('keyup', function() {
        clearTimeout(searchTimeout);
        var keyword = $(this).val();
        
        if (keyword.length >= 2) {
            searchTimeout = setTimeout(function() {
                $.ajax({
                    url: '../proses/search_siswa.php',
                    type: 'GET',
                    data: { keyword: keyword },
                    success: function(response) {
                        $('#suggestionsSiswa').html(response).slideDown(200);
                    }
                });
            }, 300);
        } else {
            $('#suggestionsSiswa').slideUp(200);
        }
    });

    // ========== SEARCH PETUGAS ==========
    $('#searchPetugas').on('keyup', function() {
        clearTimeout(searchTimeout);
        var keyword = $(this).val();
        
        if (keyword.length >= 2) {
            searchTimeout = setTimeout(function() {
                $.ajax({
                    url: '../proses/search_petugas.php',
                    type: 'GET',
                    data: { keyword: keyword },
                    success: function(response) {
                        $('#suggestionsPetugas').html(response).slideDown(200);
                    }
                });
            }, 300);
        } else {
            $('#suggestionsPetugas').slideUp(200);
        }
    });

    // Pilih Siswa
    $(document).on('click', '.suggestion-item-siswa', function() {
        $('#selectedSiswaId').val($(this).data('id'));
        $('#searchSiswa').val($(this).data('nama') + ' - ' + $(this).data('kelas'));
        $('#siswaName').text($(this).data('nama') + ' - Kelas ' + $(this).data('kelas') + ' (NISN: ' + $(this).data('nisn') + ')');
        $('#selectedSiswaInfo').slideDown(200);
        $('#suggestionsSiswa').slideUp(200);
    });

    // Pilih Petugas
    $(document).on('click', '.suggestion-item-petugas', function() {
        $('#selectedPetugasId').val($(this).data('id'));
        $('#searchPetugas').val($(this).data('nama'));
        $('#petugasName').text($(this).data('nama'));
        $('#selectedPetugasInfo').slideDown(200);
        $('#suggestionsPetugas').slideUp(200);
    });

    // Hide suggestions on click outside
    $(document).on('click', function(e) {
        if (!$(e.target).closest('#searchSiswa').length && !$(e.target).closest('#suggestionsSiswa').length) {
            $('#suggestionsSiswa').slideUp(200);
        }
        if (!$(e.target).closest('#searchPetugas').length && !$(e.target).closest('#suggestionsPetugas').length) {
            $('#suggestionsPetugas').slideUp(200);
        }
    });

    // Tambah Obat
    $('#tambahObat').click(function() {
        var newObat = $('.obat-item').first().clone();
        newObat.find('select').val('');
        newObat.find('input').val('1');
        $('#obatContainer').append(newObat);
    });

    // Hapus Obat
    $(document).on('click', '.remove-obat', function() {
        if ($('.obat-item').length > 1) {
            $(this).closest('.obat-item').remove();
        }
    });

    // Submit Form
    $('#formKunjungan').submit(function(e) {
        e.preventDefault();
        
        if (!$('#selectedSiswaId').val()) {
            Swal.fire({ icon: 'warning', title: 'Perhatian', text: 'Silakan cari dan pilih siswa!' });
            return;
        }
        if (!$('#selectedPetugasId').val()) {
            Swal.fire({ icon: 'warning', title: 'Perhatian', text: 'Silakan cari dan pilih petugas!' });
            return;
        }
        
        $.ajax({
            url: '../proses/kunjungan_proses.php',
            type: 'POST',
            data: $(this).serialize() + '&action=add',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    Swal.fire({ icon: 'success', title: 'Berhasil!', text: 'Kunjungan berhasil dicatat', timer: 1500, showConfirmButton: false })
                        .then(() => location.reload());
                } else {
                    Swal.fire({ icon: 'error', title: 'Gagal!', text: response.message });
                }
            }
        });
    });
});

function clearSiswa() {
    $('#selectedSiswaId').val('');
    $('#searchSiswa').val('');
    $('#selectedSiswaInfo').slideUp(200);
}

function clearPetugas() {
    $('#selectedPetugasId').val('');
    $('#searchPetugas').val('');
    $('#selectedPetugasInfo').slideUp(200);
}

function hapusKunjungan(id) {
    Swal.fire({
        title: 'Konfirmasi Hapus',
        text: 'Hapus data kunjungan ini?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../proses/kunjungan_proses.php',
                type: 'POST',
                data: { action: 'delete', id: id },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        Swal.fire({ icon: 'success', title: 'Berhasil!', timer: 1500, showConfirmButton: false })
                            .then(() => location.reload());
                    }
                }
            });
        }
    });
}

function editKunjungan(id) {
    Swal.fire({ icon: 'info', title: 'Info', text: 'Fitur edit sedang dikembangkan' });
}
</script>
</body>
</html>