<?php
include '../includes/header.php';
include '../includes/sidebar.php';

// Query data guru
$total_guru_all = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM guru"))['total'];
$total_wali = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM guru WHERE jabatan='Wali Kelas'"))['total'];
$total_mapel = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM guru WHERE jabatan='Guru Mapel'"))['total'];
$total_wa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM guru WHERE no_wa IS NOT NULL AND no_wa != ''"))['total'];
?>

<style>
    .content-wrapper {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        padding: 20px;
        position: relative;
    }
    
    .content-wrapper::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="15" fill="rgba(255,255,255,0.05)"/><circle cx="80" cy="80" r="20" fill="rgba(255,255,255,0.05)"/></svg>');
        pointer-events: none;
    }
    
    .main-content {
        backdrop-filter: blur(10px);
        background: rgba(255, 255, 255, 0.92);
        border-radius: 25px;
        padding: 25px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        border: 1px solid rgba(255,255,255,0.3);
        position: relative;
        z-index: 1;
    }
    
    .glass-header {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(20px);
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 25px;
        border: 1px solid rgba(255,255,255,0.2);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        position: relative;
        overflow: hidden;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .glass-header h1 {
        color: #4facfe !important;
        text-shadow: 0 2px 20px rgba(79, 172, 254, 0.3);
        position: relative;
        z-index: 1;
        font-weight: 700;
    }
    
    .btn-elegant {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        border: none;
        color: white;
        padding: 12px 30px;
        border-radius: 50px;
        font-weight: 600;
        cursor: pointer;
        box-shadow: 0 8px 25px rgba(245, 87, 108, 0.4);
        transition: all 0.3s;
        position: relative;
        z-index: 1;
    }
    
    .btn-elegant:hover {
        transform: translateY(-3px);
        box-shadow: 0 12px 35px rgba(245, 87, 108, 0.5);
    }
    
    /* Card Info */
    .info-card {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        border-radius: 20px;
        padding: 25px 15px;
        border: 1px solid rgba(255,255,255,0.2);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        transition: all 0.3s;
        cursor: pointer;
        text-align: center;
        color: white;
    }
    
    .info-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 40px rgba(0,0,0,0.2);
    }
    
    .info-card .card-icon {
        font-size: 2.5rem;
        display: block;
        margin-bottom: 8px;
    }
    
    .info-card h5 {
        font-size: 0.85rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin: 0;
        opacity: 0.9;
    }
    
    .info-card h2 {
        font-size: 2.5rem;
        font-weight: 700;
        margin: 10px 0 5px;
    }
    
    .info-card small {
        font-size: 0.75rem;
        opacity: 0.8;
    }
    
    /* Card Container */
    .card-container {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 20px;
        padding: 20px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.5);
    }
    
    .card-container .card-header {
        background: transparent;
        border-bottom: 2px solid rgba(0,0,0,0.05);
        padding: 15px 20px;
    }
    
    #tabelGuru thead {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }
    
    #tabelGuru thead th {
        border: none;
        padding: 15px;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.85rem;
    }
    
    #tabelGuru tbody tr:hover {
        background: rgba(102, 126, 234, 0.05);
    }
    
    #tabelGuru tbody td {
        padding: 12px 15px;
        vertical-align: middle;
    }
    
    .badge-kelas {
        background: rgba(102, 126, 234, 0.1);
        color: #667eea;
        padding: 4px 12px;
        border-radius: 50px;
        font-size: 0.8rem;
        font-weight: 600;
    }
    
    .btn-action {
        transition: all 0.3s;
        border-radius: 50px;
        padding: 6px 12px;
        margin: 0 3px;
        border: none;
    }
    
    .btn-action:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    .btn-wa {
        background: #25D366;
        color: white;
    }
    
    .btn-wa:hover {
        background: #128C7E;
        color: white;
    }
    
    /* Modal */
    .modal-content {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(20px);
        border-radius: 25px;
        border: 1px solid rgba(255,255,255,0.3);
        box-shadow: 0 25px 80px rgba(0,0,0,0.3);
    }
    
    .modal-header {
        border-radius: 25px 25px 0 0;
        border: none;
        padding: 20px 30px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
        color: white;
    }
    
    .modal-header.bg-warning {
        background: linear-gradient(135deg, #f59e0b, #d97706) !important;
    }
    
    .modal-body {
        padding: 30px;
    }
    
    .modal-footer {
        border: none;
        padding: 20px 30px;
        border-radius: 0 0 25px 25px;
    }
    
    .form-control, .form-select {
        border-radius: 15px;
        border: 2px solid rgba(0,0,0,0.06);
        padding: 12px 18px;
        transition: all 0.3s;
        background: rgba(255,255,255,0.8);
    }
    
    .form-control:focus, .form-select:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.15);
        outline: none;
    }
    
    .form-label {
        font-weight: 600;
        color: #333;
        margin-bottom: 8px;
        font-size: 0.9rem;
    }
    
    @media (max-width: 768px) {
        .content-wrapper { padding: 10px; }
        .main-content { padding: 15px; border-radius: 15px; }
        .glass-header { flex-direction: column; gap: 15px; }
        .btn-elegant { width: 100%; }
        .info-card h2 { font-size: 1.8rem; }
    }
</style>

<div class="content-wrapper">
    <div class="container-fluid main-content">
        
        <!-- Header -->
        <div class="glass-header">
            <h1 class="h2 mb-0">
                <i class="bi bi-person-badge me-2"></i> Data Guru
            </h1>
            <button class="btn-elegant" data-bs-toggle="modal" data-bs-target="#modalTambahGuru">
                <i class="bi bi-plus-circle me-2"></i> Tambah Guru
            </button>
        </div>

        <!-- Card Info - CENTER -->
        <div class="row mb-4 g-3 justify-content-center">
            <div class="col-md-3 col-sm-6">
                <div class="info-card" onclick="filterSemua()">
                    <span class="card-icon">👨‍🏫</span>
                    <h5>Total Guru</h5>
                    <h2><?= $total_guru_all ?></h2>
                    <small>Klik untuk lihat semua</small>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="info-card" onclick="filterWali()">
                    <span class="card-icon">👩‍🏫</span>
                    <h5>Wali Kelas</h5>
                    <h2><?= $total_wali ?></h2>
                    <small>Klik untuk lihat data</small>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="info-card" onclick="filterMapel()">
                    <span class="card-icon">📚</span>
                    <h5>Guru Mapel</h5>
                    <h2><?= $total_mapel ?></h2>
                    <small>Klik untuk lihat data</small>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="info-card">
                    <span class="card-icon">📱</span>
                    <h5>Nomor WA</h5>
                    <h2><?= $total_wa ?></h2>
                    <small>Nomor terdaftar</small>
                </div>
            </div>
        </div>
        
        <!-- Tabel Data Guru -->
        <div class="card-container">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap">
                <h5 class="mb-0">
                    <i class="bi bi-table me-2"></i> Daftar Seluruh Guru
                </h5>
                <div>
                    <span class="badge bg-primary bg-opacity-10 text-primary me-2">
                        <i class="bi bi-clock me-1"></i> Update: <?= date('H:i') ?>
                    </span>
                    <button class="btn btn-sm btn-outline-secondary" onclick="resetFilter()" title="Reset Filter">
                        <i class="bi bi-arrow-counterclockwise"></i> Reset
                    </button>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover" id="tabelGuru">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th width="22%">Nama Guru</th>
                                <th width="18%">No. WhatsApp</th>
                                <th width="15%">Kelas/Mapel</th>
                                <th width="15%">Jabatan</th>
                                <th width="10%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $guru_query = mysqli_query($conn, "SELECT * FROM guru ORDER BY kelas, nama");
                            $no = 1;
                            while($g = mysqli_fetch_assoc($guru_query)):
                            ?>
                            <tr>
                                <td class="text-center fw-bold"><?= $no++ ?></td>
                                <td><strong><?= $g['nama'] ?></strong></td>
                                <td><code><?= $g['no_wa'] ?></code></td>
                                <td><span class="badge-kelas"><?= $g['kelas'] ?></span></td>
                                <td>
                                    <?php 
                                    $badge_color = 'info';
                                    if ($g['jabatan'] == 'Kepala Sekolah') $badge_color = 'danger';
                                    elseif ($g['jabatan'] == 'Wali Kelas') $badge_color = 'success';
                                    elseif ($g['jabatan'] == 'Guru Mapel') $badge_color = 'warning';
                                    ?>
                                    <span class="badge bg-<?= $badge_color ?> bg-opacity-10 text-<?= $badge_color ?>">
                                        <?= $g['jabatan'] ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-success btn-action btn-wa" onclick="chatWA('<?= $g['no_wa'] ?>')" title="Chat WA">
                                            <i class="bi bi-whatsapp"></i>
                                        </button>
                                        <button class="btn btn-warning btn-action" onclick="editGuru(<?= $g['id'] ?>)" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-danger btn-action" onclick="hapusGuru(<?= $g['id'] ?>)" title="Hapus">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Guru -->
<div class="modal fade" id="modalTambahGuru" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i> Tambah Guru Baru</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="formTambahGuru">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nama Guru <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="nama" placeholder="Masukkan nama lengkap guru" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nomor WhatsApp <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="no_wa" placeholder="Contoh: 6281234567890" required>
                        <small class="text-muted">Masukkan nomor dengan awalan 62 (tanpa 0)</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Kelas/Mapel <span class="text-danger">*</span></label>
                        <select class="form-select" name="kelas" required>
                            <option value="">-- Pilih Kelas atau Mapel --</option>
                            <optgroup label="📚 Kelas">
                                <option value="1A">Kelas 1A</option><option value="1B">Kelas 1B</option>
                                <option value="2A">Kelas 2A</option><option value="2B">Kelas 2B</option>
                                <option value="2C">Kelas 2C</option><option value="3A">Kelas 3A</option>
                                <option value="3B">Kelas 3B</option><option value="4A">Kelas 4A</option>
                                <option value="4B">Kelas 4B</option><option value="4C">Kelas 4C</option>
                                <option value="5A">Kelas 5A</option><option value="5B">Kelas 5B</option>
                                <option value="6A">Kelas 6A</option><option value="6B">Kelas 6B</option>
                            </optgroup>
                            <optgroup label="🎯 Mapel Tambahan">
                                <option value="TIK">TIK</option>
                                <option value="Olahraga">Olahraga</option>
                                <option value="Pencak Silat">Pencak Silat</option>
                                <option value="Bahasa Inggris">Bahasa Inggris</option>
                            </optgroup>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Jabatan</label>
                        <select class="form-select" name="jabatan">
                            <option value="Wali Kelas">Wali Kelas</option>
                            <option value="Guru Mapel">Guru Mapel</option>
                            <option value="Kepala Sekolah">Kepala Sekolah</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Guru</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Guru -->
<div class="modal fade" id="modalEditGuru" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i> Edit Data Guru</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="formEditGuru">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Nama Guru <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="nama" id="edit_nama" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nomor WhatsApp <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="no_wa" id="edit_no_wa" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Kelas/Mapel <span class="text-danger">*</span></label>
                        <select class="form-select" name="kelas" id="edit_kelas" required>
                            <optgroup label="Kelas">
                                <option value="1A">1A</option><option value="1B">1B</option>
                                <option value="2A">2A</option><option value="2B">2B</option>
                                <option value="2C">2C</option><option value="3A">3A</option>
                                <option value="3B">3B</option><option value="4A">4A</option>
                                <option value="4B">4B</option><option value="4C">4C</option>
                                <option value="5A">5A</option><option value="5B">5B</option>
                                <option value="6A">6A</option><option value="6B">6B</option>
                            </optgroup>
                            <optgroup label="Mapel">
                                <option value="TIK">TIK</option>
                                <option value="Olahraga">Olahraga</option>
                                <option value="Pencak Silat">Pencak Silat</option>
                                <option value="Bahasa Inggris">Bahasa Inggris</option>
                            </optgroup>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Jabatan</label>
                        <select class="form-select" name="jabatan" id="edit_jabatan">
                            <option value="Wali Kelas">Wali Kelas</option>
                            <option value="Guru Mapel">Guru Mapel</option>
                            <option value="Kepala Sekolah">Kepala Sekolah</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-warning text-white"><i class="bi bi-arrow-repeat me-1"></i> Update Guru</button>
                </div>
            </form>
        </div>
    </div>
</div>

</main>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    // DataTable
    var table = $('#tabelGuru').DataTable({
        responsive: true,
        language: { url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/id.json' },
        columnDefs: [{ orderable: false, targets: [0, 5] }]
    });
    
    // Submit Form Tambah
    $('#formTambahGuru').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: '../proses/guru_proses.php',
            type: 'POST',
            data: $(this).serialize() + '&action=tambah',
            dataType: 'json',
            success: function(response) {
                if(response.status === 'success') {
                    Swal.fire({ icon:'success', title:'Berhasil!', text:'Guru berhasil ditambahkan', timer:1500, showConfirmButton:false }).then(() => location.reload());
                } else {
                    Swal.fire({ icon:'error', title:'Gagal!', text:response.message });
                }
            }
        });
    });
    
    // Submit Form Edit
    $('#formEditGuru').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: '../proses/guru_proses.php',
            type: 'POST',
            data: $(this).serialize() + '&action=edit',
            dataType: 'json',
            success: function(response) {
                if(response.status === 'success') {
                    Swal.fire({ icon:'success', title:'Berhasil!', text:'Data guru berhasil diupdate', timer:1500, showConfirmButton:false }).then(() => location.reload());
                } else {
                    Swal.fire({ icon:'error', title:'Gagal!', text:response.message });
                }
            }
        });
    });
});

// Filter functions
function filterSemua() {
    $('#tabelGuru').DataTable().search('').columns().search('').draw();
}
function filterWali() {
    $('#tabelGuru').DataTable().column(4).search('Wali Kelas').draw();
}
function filterMapel() {
    $('#tabelGuru').DataTable().column(4).search('Guru Mapel').draw();
}
function resetFilter() {
    $('#tabelGuru').DataTable().search('').columns().search('').draw();
}

// Edit Guru
function editGuru(id) {
    $.ajax({
        url: '../proses/guru_proses.php',
        type: 'GET',
        data: { action: 'get_data', id: id },
        dataType: 'json',
        success: function(data) {
            $('#edit_id').val(data.id);
            $('#edit_nama').val(data.nama);
            $('#edit_no_wa').val(data.no_wa);
            $('#edit_kelas').val(data.kelas);
            $('#edit_jabatan').val(data.jabatan);
            $('#modalEditGuru').modal('show');
        }
    });
}

// Hapus Guru
function hapusGuru(id) {
    Swal.fire({
        title: 'Konfirmasi Hapus',
        text: 'Apakah Anda yakin ingin menghapus data guru ini?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if(result.isConfirmed) {
            $.ajax({
                url: '../proses/guru_proses.php',
                type: 'POST',
                data: { action: 'hapus', id: id },
                dataType: 'json',
                success: function(response) {
                    if(response.status === 'success') {
                        Swal.fire({ icon:'success', title:'Berhasil!', timer:1500, showConfirmButton:false }).then(() => location.reload());
                    }
                }
            });
        }
    });
}

// Chat WA
function chatWA(no) {
    if(no) {
        window.open('https://wa.me/' + no, '_blank');
    } else {
        Swal.fire({ icon:'warning', title:'Info', text:'Nomor WhatsApp tidak tersedia', timer:1500, showConfirmButton:false });
    }
}
</script>
</body></html>