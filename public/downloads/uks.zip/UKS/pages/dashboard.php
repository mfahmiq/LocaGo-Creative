<?php
include '../includes/header.php';
include '../includes/sidebar.php';

// Query statistik
$total_siswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM siswa"))['total'];

$kunjungan_hari_ini = mysqli_fetch_assoc(mysqli_query($conn, 
    "SELECT COUNT(*) as total FROM kunjungan WHERE tanggal = CURDATE()"
))['total'];

$obat_hampir_habis = mysqli_fetch_assoc(mysqli_query($conn, 
    "SELECT COUNT(*) as total FROM obat WHERE stok <= stok_minimum AND stok > 0"
))['total'];

$penyakit_terbanyak = mysqli_query($conn, 
    "SELECT diagnosa, COUNT(*) as jumlah 
     FROM kunjungan 
     WHERE diagnosa IS NOT NULL AND diagnosa != ''
     GROUP BY diagnosa 
     ORDER BY jumlah DESC 
     LIMIT 5"
);

// Grafik data
$grafik_penyakit = mysqli_query($conn, 
    "SELECT diagnosa, COUNT(*) as jumlah 
     FROM kunjungan 
     WHERE MONTH(tanggal) = MONTH(CURDATE()) 
     AND YEAR(tanggal) = YEAR(CURDATE())
     AND diagnosa IS NOT NULL
     GROUP BY diagnosa 
     ORDER BY jumlah DESC 
     LIMIT 10"
);

$grafik_kunjungan = mysqli_query($conn, 
    "SELECT DATE(tanggal) as tgl, COUNT(*) as jumlah 
     FROM kunjungan 
     WHERE tanggal >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
     GROUP BY DATE(tanggal) 
     ORDER BY tgl"
);
?>

<style>
    /* ========================================
       DASHBOARD STYLE - SELARAS
    ======================================== */
    
    .content-wrapper {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        padding: 20px;
        position: relative;
    }
    
    .content-wrapper::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="15" fill="rgba(255,255,255,0.05)"/><circle cx="80" cy="80" r="20" fill="rgba(255,255,255,0.05)"/><circle cx="50" cy="50" r="25" fill="rgba(255,255,255,0.03)"/></svg>');
        background-size: 200px 200px;
        pointer-events: none;
    }
    
    .main-content {
        backdrop-filter: blur(10px);
        background: rgba(255, 255, 255, 0.92);
        border-radius: 25px;
        padding: 25px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        border: 1px solid rgba(255,255,255,0.3);
        position: relative;
        z-index: 1;
        animation: fadeInUp 0.8s ease-out;
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    /* Header Glass */
    .glass-header {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(20px);
        border-radius: 15px;
        padding: 20px 25px;
        margin-bottom: 25px;
        border: 1px solid rgba(255,255,255,0.2);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        position: relative;
        overflow: hidden;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 15px;
    }
    
    .glass-header::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
        animation: shimmer 3s infinite;
    }
    
    @keyframes shimmer {
        0% { transform: translate(-30%, -30%) rotate(0deg); }
        100% { transform: translate(30%, 30%) rotate(180deg); }
    }
    
    .glass-header h1 {
        color: #4facfe !important;
        text-shadow: 0 2px 20px rgba(79, 172, 254, 0.3);
        position: relative;
        z-index: 1;
        font-weight: 700;
        margin: 0;
    }
    
    .glass-header h1 i {
        color: #4facfe;
        text-shadow: 0 2px 20px rgba(79, 172, 254, 0.4);
    }
    
    .glass-header .date-badge {
        background: rgba(255,255,255,0.2);
        backdrop-filter: blur(10px);
        padding: 8px 20px;
        border-radius: 50px;
        color: white;
        font-size: 0.9rem;
        border: 1px solid rgba(255,255,255,0.2);
        position: relative;
        z-index: 1;
    }
    
    /* Card Stats - Modern */
    .stats-card {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(20px);
        border-radius: 20px;
        padding: 20px 25px;
        border: 1px solid rgba(255,255,255,0.2);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        cursor: pointer;
        position: relative;
        overflow: hidden;
        color: white;
        text-shadow: 0 2px 10px rgba(0,0,0,0.1);
        height: 100%;
    }
    
    .stats-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(135deg, rgba(255,255,255,0.2) 0%, transparent 100%);
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    
    .stats-card:hover {
        transform: translateY(-10px) scale(1.02);
        box-shadow: 0 15px 40px rgba(0,0,0,0.2);
    }
    
    .stats-card:hover::before {
        opacity: 1;
    }
    
    .stats-card .card-icon {
        font-size: 2.8rem;
        opacity: 0.9;
        line-height: 1;
    }
    
    .stats-card .card-label {
        font-weight: 300;
        opacity: 0.9;
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 5px;
    }
    
    .stats-card .card-value {
        font-weight: 700;
        font-size: 2.5rem;
        margin: 5px 0 0;
        text-shadow: 0 2px 20px rgba(0,0,0,0.2);
        line-height: 1.2;
    }
    
    .stats-card .card-sub {
        font-size: 0.7rem;
        opacity: 0.7;
        margin-top: 5px;
    }
    
    /* Card Colors */
    .card-blue { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
    .card-green { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); }
    .card-orange { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
    .card-purple { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
    
    /* Card Container */
    .card-container {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.5);
        overflow: hidden;
        height: 100%;
    }
    
    .card-container .card-header-custom {
        background: transparent;
        border-bottom: 2px solid rgba(0,0,0,0.05);
        padding: 15px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .card-container .card-header-custom h5 {
        color: #333;
        font-weight: 600;
        margin: 0;
    }
    
    .card-container .card-header-custom h5 i {
        color: #4facfe;
        margin-right: 8px;
    }
    
    .card-container .card-body-custom {
        padding: 20px;
    }
    
    /* List Group */
    .list-group-item-custom {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 16px;
        border-bottom: 1px solid rgba(0,0,0,0.05);
        transition: all 0.3s ease;
        background: transparent;
    }
    
    .list-group-item-custom:last-child {
        border-bottom: none;
    }
    
    .list-group-item-custom:hover {
        background: rgba(102, 126, 234, 0.05);
        transform: translateX(5px);
    }
    
    .list-group-item-custom .rank {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 28px;
        height: 28px;
        border-radius: 50%;
        background: rgba(102, 126, 234, 0.1);
        color: #667eea;
        font-weight: 700;
        font-size: 0.8rem;
        margin-right: 12px;
        flex-shrink: 0;
    }
    
    .list-group-item-custom .rank-1 { background: #FFD700; color: #fff; }
    .list-group-item-custom .rank-2 { background: #C0C0C0; color: #fff; }
    .list-group-item-custom .rank-3 { background: #CD7F32; color: #fff; }
    
    .list-group-item-custom .item-label {
        flex: 1;
        font-weight: 500;
        color: #333;
    }
    
    .list-group-item-custom .item-badge {
        background: rgba(102, 126, 234, 0.1);
        color: #667eea;
        padding: 4px 14px;
        border-radius: 50px;
        font-size: 0.8rem;
        font-weight: 600;
    }
    
    /* Chart Container */
    .chart-container {
        position: relative;
        height: 280px;
    }
    
    /* Floating particles */
    .particles {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 0;
        overflow: hidden;
    }
    
    .particle {
        position: absolute;
        width: 4px;
        height: 4px;
        background: rgba(255,255,255,0.3);
        border-radius: 50%;
        animation: float linear infinite;
    }
    
    @keyframes float {
        0% {
            transform: translateY(100vh) rotate(0deg);
            opacity: 0;
        }
        10% {
            opacity: 1;
        }
        90% {
            opacity: 1;
        }
        100% {
            transform: translateY(-100vh) rotate(720deg);
            opacity: 0;
        }
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .content-wrapper {
            padding: 10px;
        }
        
        .main-content {
            padding: 15px;
            border-radius: 15px;
        }
        
        .glass-header {
            flex-direction: column;
            text-align: center;
        }
        
        .stats-card .card-value {
            font-size: 2rem;
        }
        
        .chart-container {
            height: 200px;
        }
    }
    
    /* Scrollbar */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: rgba(0,0,0,0.05);
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
    }
</style>

<!-- Floating Particles -->
<div class="particles" id="particles"></div>

<div class="content-wrapper">
    <div class="container-fluid main-content">
        
        <!-- Header -->
        <div class="glass-header">
            <h1>
                <i class="bi bi-speedometer2 me-2"></i> Dashboard UKS
            </h1>
            <div class="date-badge">
                <i class="bi bi-calendar3 me-2"></i> <?= tgl_indo(date('Y-m-d')) ?>
            </div>
        </div>

        <!-- Card Stats -->
        <div class="row g-4 mb-4">
            <div class="col-xl-3 col-md-6">
                <div class="stats-card card-blue">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="card-label">Total Siswa</div>
                            <div class="card-value"><?= $total_siswa ?></div>
                            <div class="card-sub"><i class="bi bi-people me-1"></i> Terdaftar</div>
                        </div>
                        <div class="card-icon">👨‍🎓</div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="stats-card card-green">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="card-label">Kunjungan Hari Ini</div>
                            <div class="card-value"><?= $kunjungan_hari_ini ?></div>
                            <div class="card-sub"><i class="bi bi-clock me-1"></i> <?= date('H:i') ?></div>
                        </div>
                        <div class="card-icon">🏥</div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="stats-card card-orange">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="card-label">Obat Hampir Habis</div>
                            <div class="card-value"><?= $obat_hampir_habis ?></div>
                            <div class="card-sub"><i class="bi bi-exclamation-triangle me-1"></i> Segera diisi</div>
                        </div>
                        <div class="card-icon">💊</div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6">
                <div class="stats-card card-purple">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="card-label">Dokter Cilik</div>
                            <div class="card-value">
                                <?= mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM siswa WHERE dokcil='Ya'"))['total'] ?>
                            </div>
                            <div class="card-sub"><i class="bi bi-heart-pulse me-1"></i> Aktif</div>
                        </div>
                        <div class="card-icon">🩺</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Row 2: Penyakit Terbanyak & Grafik -->
        <div class="row g-4 mb-4">
            <!-- Penyakit Terbanyak -->
            <div class="col-lg-4">
                <div class="card-container">
                    <div class="card-header-custom">
                        <h5><i class="bi bi-trophy"></i> Penyakit Terbanyak</h5>
                        <span class="badge bg-primary bg-opacity-10 text-primary">Bulan Ini</span>
                    </div>
                    <div class="card-body-custom">
                        <?php 
                        $no = 1;
                        while($row = mysqli_fetch_assoc($penyakit_terbanyak)): 
                        ?>
                        <div class="list-group-item-custom">
                            <div class="d-flex align-items-center">
                                <span class="rank rank-<?= $no <= 3 ? $no : '' ?>"><?= $no ?></span>
                                <span class="item-label"><?= $row['diagnosa'] ?></span>
                            </div>
                            <span class="item-badge"><?= $row['jumlah'] ?>x</span>
                        </div>
                        <?php 
                        $no++;
                        endwhile; 
                        ?>
                    </div>
                </div>
            </div>
            
            <!-- Grafik Penyakit -->
            <div class="col-lg-8">
                <div class="card-container">
                    <div class="card-header-custom">
                        <h5><i class="bi bi-bar-chart"></i> Grafik Penyakit Bulan Ini</h5>
                        <span class="badge bg-primary bg-opacity-10 text-primary">
                            <?= date('F Y') ?>
                        </span>
                    </div>
                    <div class="card-body-custom">
                        <div class="chart-container">
                            <canvas id="penyakitChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Row 3: Grafik Kunjungan -->
        <div class="row g-4">
            <div class="col-12">
                <div class="card-container">
                    <div class="card-header-custom">
                        <h5><i class="bi bi-graph-up"></i> Grafik Kunjungan 7 Hari Terakhir</h5>
                        <span class="badge bg-primary bg-opacity-10 text-primary">
                            <i class="bi bi-calendar me-1"></i> 7 Hari
                        </span>
                    </div>
                    <div class="card-body-custom">
                        <div class="chart-container" style="height: 200px;">
                            <canvas id="kunjunganChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

</main>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    // Create floating particles
    function createParticles() {
        const container = document.getElementById('particles');
        for (let i = 0; i < 30; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.width = (Math.random() * 4 + 2) + 'px';
            particle.style.height = particle.style.width;
            particle.style.animationDuration = (Math.random() * 20 + 10) + 's';
            particle.style.animationDelay = (Math.random() * 10) + 's';
            container.appendChild(particle);
        }
    }
    createParticles();

    // Grafik Penyakit
    const penyakitLabels = [
        <?php 
        mysqli_data_seek($grafik_penyakit, 0);
        while($row = mysqli_fetch_assoc($grafik_penyakit)) {
            echo "'" . addslashes($row['diagnosa']) . "',";
        }
        ?>
    ];

    const penyakitData = [
        <?php 
        mysqli_data_seek($grafik_penyakit, 0);
        while($row = mysqli_fetch_assoc($grafik_penyakit)) {
            echo $row['jumlah'] . ",";
        }
        ?>
    ];

    const colors = [
        '#4facfe', '#43e97b', '#f093fb', '#f5576c', '#667eea',
        '#f6c23e', '#36b9cc', '#6f42c1', '#fd7e14', '#20c997'
    ];

    const ctxPenyakit = document.getElementById('penyakitChart').getContext('2d');
    new Chart(ctxPenyakit, {
        type: 'bar',
        data: {
            labels: penyakitLabels,
            datasets: [{
                label: 'Jumlah Kasus',
                data: penyakitData,
                backgroundColor: colors.slice(0, penyakitLabels.length),
                borderColor: '#fff',
                borderWidth: 2,
                borderRadius: 8,
                barThickness: 35
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { 
                        stepSize: 1,
                        font: { size: 11 }
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.05)'
                    }
                },
                x: {
                    grid: { display: false },
                    ticks: {
                        font: { size: 10 },
                        maxRotation: 45,
                        minRotation: 30
                    }
                }
            }
        }
    });

    // Grafik Kunjungan
    const kunjunganLabels = [
        <?php 
        mysqli_data_seek($grafik_kunjungan, 0);
        while($row = mysqli_fetch_assoc($grafik_kunjungan)) {
            echo "'" . date('d/m', strtotime($row['tgl'])) . "',";
        }
        ?>
    ];

    const kunjunganData = [
        <?php 
        mysqli_data_seek($grafik_kunjungan, 0);
        while($row = mysqli_fetch_assoc($grafik_kunjungan)) {
            echo $row['jumlah'] . ",";
        }
        ?>
    ];

    const ctxKunjungan = document.getElementById('kunjunganChart').getContext('2d');
    new Chart(ctxKunjungan, {
        type: 'line',
        data: {
            labels: kunjunganLabels,
            datasets: [{
                label: 'Jumlah Kunjungan',
                data: kunjunganData,
                borderColor: '#4facfe',
                backgroundColor: 'rgba(79,172,254,0.1)',
                fill: true,
                tension: 0.4,
                pointRadius: 6,
                pointBackgroundColor: '#4facfe',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointHoverRadius: 8,
                pointHoverBackgroundColor: '#667eea'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    display: true,
                    labels: {
                        usePointStyle: true,
                        pointStyle: 'circle',
                        font: { size: 11 }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { 
                        stepSize: 1,
                        font: { size: 11 }
                    },
                    grid: {
                        color: 'rgba(0,0,0,0.05)'
                    }
                },
                x: {
                    grid: { display: false },
                    ticks: {
                        font: { size: 11 }
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            }
        }
    });
});
</script>
</body>
</html>