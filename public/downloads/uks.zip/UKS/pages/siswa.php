<?php
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<style>
    /* Background dengan efek blur dan gradient */
    .content-wrapper {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        padding: 20px;
        position: relative;
    }
    
    .content-wrapper::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="15" fill="rgba(255,255,255,0.05)"/><circle cx="80" cy="80" r="20" fill="rgba(255,255,255,0.05)"/><circle cx="50" cy="50" r="25" fill="rgba(255,255,255,0.03)"/></svg>');
        background-size: 200px 200px;
        pointer-events: none;
    }
    
    .main-content {
        backdrop-filter: blur(10px);
        background: rgba(255, 255, 255, 0.92);
        border-radius: 25px;
        padding: 25px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        border: 1px solid rgba(255,255,255,0.3);
        position: relative;
        z-index: 1;
    }
    
    /* Header dengan efek glassmorphism */
    .glass-header {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(20px);
        border-radius: 15px;
        padding: 20px;
        margin-bottom: 25px;
        border: 1px solid rgba(255,255,255,0.2);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        position: relative;
        overflow: hidden;
    }
    
    .glass-header::before {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
        animation: shimmer 3s infinite;
    }
    
    @keyframes shimmer {
        0% { transform: translate(-30%, -30%) rotate(0deg); }
        100% { transform: translate(30%, 30%) rotate(180deg); }
    }
    
    /* Judul Data Siswa - Warna Biru */
    .glass-header h1 {
        color: #4facfe !important;
        text-shadow: 0 2px 20px rgba(79, 172, 254, 0.3);
        position: relative;
        z-index: 1;
        font-weight: 700;
    }
    
    .glass-header h1 i {
        color: #4facfe;
        text-shadow: 0 2px 20px rgba(79, 172, 254, 0.4);
    }
    
    /* Tombol Tambah Siswa - Elegant Gradient */
    .btn-elegant {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        border: none;
        color: white;
        padding: 12px 30px;
        border-radius: 50px;
        font-weight: 600;
        letter-spacing: 0.5px;
        box-shadow: 0 8px 25px rgba(245, 87, 108, 0.4);
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        position: relative;
        z-index: 1;
        overflow: hidden;
    }
    
    .btn-elegant::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        transition: all 0.5s ease;
        z-index: -1;
    }
    
    .btn-elegant:hover {
        transform: translateY(-3px) scale(1.02);
        box-shadow: 0 12px 35px rgba(245, 87, 108, 0.5);
        color: white;
    }
    
    .btn-elegant:hover::before {
        left: 0;
    }
    
    .btn-elegant i {
        margin-right: 10px;
    }
    
    /* Card Info dengan warna baru */
    .info-card {
        background: rgba(255, 255, 255, 0.15);
        backdrop-filter: blur(20px);
        border-radius: 20px;
        padding: 20px;
        border: 1px solid rgba(255,255,255,0.2);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        cursor: pointer;
        position: relative;
        overflow: hidden;
        color: white;
        text-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    
    .info-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: linear-gradient(135deg, rgba(255,255,255,0.2) 0%, transparent 100%);
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    
    .info-card:hover {
        transform: translateY(-10px) scale(1.02);
        box-shadow: 0 15px 40px rgba(0,0,0,0.2);
    }
    
    .info-card:hover::before {
        opacity: 1;
    }
    
    .info-card .card-icon {
        font-size: 2.5rem;
        margin-bottom: 10px;
        display: block;
        opacity: 0.9;
    }
    
    .info-card h5 {
        font-weight: 300;
        opacity: 0.9;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    .info-card h2 {
        font-weight: 700;
        font-size: 2.5rem;
        margin: 10px 0 0;
        text-shadow: 0 2px 20px rgba(0,0,0,0.2);
    }
    
    /* Card Gradient - Total Siswa (Ungu) */
    .card-total { 
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
    }
    
    /* Card Gradient - Laki-laki (Biru) */
    .card-laki { 
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); 
    }
    
    /* Card Gradient - Perempuan (Pink) */
    .card-perempuan { 
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); 
    }
    
    /* Card Gradient - Dokter Cilik (Hijau) */
    .card-dokcil { 
        background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); 
    }
    
    /* Tabel dengan efek modern */
    .table-container {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border-radius: 20px;
        padding: 20px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.5);
    }
    
    .table-container .card-header {
        background: transparent;
        border-bottom: 2px solid rgba(0,0,0,0.05);
        padding: 15px 20px;
    }
    
    .table-container .form-select {
        border-radius: 50px;
        border: 2px solid rgba(0,0,0,0.08);
        padding: 8px 20px;
        transition: all 0.3s ease;
        background: rgba(255,255,255,0.8);
        backdrop-filter: blur(10px);
    }
    
    .table-container .form-select:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2);
    }
    
    #tabelSiswa {
        border-radius: 15px;
        overflow: hidden;
    }
    
    #tabelSiswa thead {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }
    
    #tabelSiswa thead th {
        border: none;
        padding: 15px;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.85rem;
        letter-spacing: 0.5px;
    }
    
    #tabelSiswa tbody tr {
        transition: all 0.3s ease;
        border-bottom: 1px solid rgba(0,0,0,0.05);
    }
    
    #tabelSiswa tbody tr:hover {
        background: rgba(102, 126, 234, 0.05);
        transform: scale(1.01);
        box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    }
    
    #tabelSiswa tbody td {
        padding: 12px 15px;
        vertical-align: middle;
    }
    
    /* Badge dengan efek glow */
    .badge-glow {
        animation: glow 2s ease-in-out infinite;
    }
    
    @keyframes glow {
        0%, 100% { box-shadow: 0 0 5px rgba(255, 193, 7, 0.5); }
        50% { box-shadow: 0 0 20px rgba(255, 193, 7, 0.8); }
    }
    
    /* Tombol aksi dengan efek */
    .btn-action {
        transition: all 0.3s ease;
        border-radius: 50px;
        padding: 6px 12px;
        margin: 0 3px;
        border: none;
    }
    
    .btn-action:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }
    
    .btn-action i {
        font-size: 0.9rem;
    }
    
    /* Modal dengan efek glassmorphism */
    .modal-content {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(20px);
        border-radius: 25px;
        border: 1px solid rgba(255,255,255,0.3);
        box-shadow: 0 25px 80px rgba(0,0,0,0.3);
    }
    
    .modal-header {
        border-radius: 25px 25px 0 0;
        border: none;
        padding: 20px 30px;
    }
    
    .modal-header.bg-primary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    }
    
    .modal-header.bg-warning {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%) !important;
    }
    
    .modal-header.bg-info {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%) !important;
    }
    
    .modal-body {
        padding: 30px;
    }
    
    .modal-footer {
        border: none;
        padding: 20px 30px;
        border-radius: 0 0 25px 25px;
    }
    
    /* Input dengan efek */
    .form-control, .form-select {
        border-radius: 15px;
        border: 2px solid rgba(0,0,0,0.06);
        padding: 12px 18px;
        transition: all 0.3s ease;
        background: rgba(255,255,255,0.8);
        backdrop-filter: blur(5px);
    }
    
    .form-control:focus, .form-select:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.15);
        transform: translateY(-2px);
    }
    
    .form-label {
        font-weight: 600;
        color: #333;
        margin-bottom: 8px;
        font-size: 0.9rem;
    }
    
    /* Animasi loading */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .main-content {
        animation: fadeInUp 0.8s ease-out;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .content-wrapper {
            padding: 10px;
        }
        
        .main-content {
            padding: 15px;
            border-radius: 15px;
        }
        
        .info-card h2 {
            font-size: 1.8rem;
        }
        
        .glass-header {
            flex-direction: column;
            gap: 15px;
        }
        
        .btn-elegant {
            width: 100%;
        }
    }
    
    /* Scrollbar custom */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: rgba(0,0,0,0.05);
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
    }
    
    /* Floating particles */
    .particles {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 0;
        overflow: hidden;
    }
    
    .particle {
        position: absolute;
        width: 4px;
        height: 4px;
        background: rgba(255,255,255,0.3);
        border-radius: 50%;
        animation: float linear infinite;
    }
    
    @keyframes float {
        0% {
            transform: translateY(100vh) rotate(0deg);
            opacity: 0;
        }
        10% {
            opacity: 1;
        }
        90% {
            opacity: 1;
        }
        100% {
            transform: translateY(-100vh) rotate(720deg);
            opacity: 0;
        }
    }
    
    /* Icon gender di card */
    .gender-icon {
        font-size: 3rem;
        display: block;
        margin-bottom: 5px;
    }
</style>

<!-- Floating Particles -->
<div class="particles" id="particles"></div>

<div class="content-wrapper">
    <div class="container-fluid main-content">
        <!-- Header dengan efek glassmorphism -->
        <div class="glass-header d-flex justify-content-between align-items-center">
            <h1 class="h2 mb-0">
                <i class="bi bi-mortarboard-fill me-2"></i> Data Siswa
            </h1>
            <button class="btn-elegant" data-bs-toggle="modal" data-bs-target="#modalTambahSiswa">
                <i class="bi bi-plus-circle"></i> Tambah Siswa
            </button>
        </div>

        <!-- Card Info dengan warna baru -->
        <div class="row mb-4 g-3">
            <div class="col-md-3">
                <div class="info-card card-total">
                    <span class="card-icon">👨‍🎓</span>
                    <h5>Total Siswa</h5>
                    <h2><?= mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM siswa"))['total'] ?></h2>
                </div>
            </div>
            <div class="col-md-3">
                <div class="info-card card-laki">
                    <span class="card-icon">👦</span>
                    <h5>Laki-laki</h5>
                    <h2><?= mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM siswa WHERE jenis_kelamin='L'"))['total'] ?></h2>
                </div>
            </div>
            <div class="col-md-3">
                <div class="info-card card-perempuan">
                    <span class="card-icon">👧</span>
                    <h5>Perempuan</h5>
                    <h2><?= mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM siswa WHERE jenis_kelamin='P'"))['total'] ?></h2>
                </div>
            </div>
            <div class="col-md-3">
                <div class="info-card card-dokcil">
                    <span class="card-icon">🩺</span>
                    <h5>Dokter Cilik</h5>
                    <h2><?= mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM siswa WHERE dokcil='Ya'"))['total'] ?></h2>
                </div>
            </div>
        </div>

        <!-- Tabel Data Siswa dengan efek modern -->
        <div class="table-container">
            <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap">
                <h5 class="mb-0">
                    <i class="bi bi-table me-2"></i> Daftar Seluruh Siswa
                </h5>
                <div class="d-flex gap-2 flex-wrap">
                    <select class="form-select form-select-sm" id="filterKelas" style="width: auto;">
                        <option value="">Semua Kelas</option>
                        <option value="1A">Kelas 1A</option>
                        <option value="1B">Kelas 1B</option>
                        <option value="2A">Kelas 2A</option>
                        <option value="2B">Kelas 2B</option>
                        <option value="2C">Kelas 2C</option>
                        <option value="3A">Kelas 3A</option>
                        <option value="3B">Kelas 3B</option>
                        <option value="4A">Kelas 4A</option>
                        <option value="4B">Kelas 4B</option>
                        <option value="4C">Kelas 4C</option>
                        <option value="5A">Kelas 5A</option>
                        <option value="5B">Kelas 5B</option>
                        <option value="6A">Kelas 6A</option>
                        <option value="6B">Kelas 6B</option>
                    </select>
                    <select class="form-select form-select-sm" id="filterJK" style="width: auto;">
                        <option value="">Semua Jenis kelamin</option>
                        <option value="L">Laki-laki</option>
                        <option value="P">Perempuan</option>
                    </select>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover" id="tabelSiswa">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th width="12%">NISN</th>
                                <th width="25%">Nama</th>
                                <th width="5%">L/P</th>
                                <th width="10%">Kelas</th>
                                <th width="15%">No. Telp</th>
                                <th width="8%">Dokcil</th>
                                <th width="11%">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM siswa ORDER BY kelas, nama";
                            $result = mysqli_query($conn, $query);
                            $no = 1;
                            while ($row = mysqli_fetch_assoc($result)):
                            ?>
                            <tr>
                                <td class="text-center fw-bold"><?= $no++ ?></td>
                                <td><code><?= $row['nisn'] ?></code></td>
                                <td>
                                    <strong><?= $row['nama'] ?></strong>
                                    <?php if ($row['dokcil'] == 'Ya'): ?>
                                        <span class="badge bg-warning text-dark badge-glow ms-2">
                                            <i class="bi bi-heart-pulse me-1"></i>Dokcil
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?= $row['jenis_kelamin'] == 'L' ? '👦' : '👧' ?>
                                </td>
                                <td><span class="badge bg-primary bg-opacity-10 text-primary"><?= $row['kelas'] ?></span></td>
                                <td><?= $row['no_telp'] ?: '<span class="text-muted">-</span>' ?></td>
                                <td class="text-center">
                                    <?php if ($row['dokcil'] == 'Ya'): ?>
                                        <span class="badge bg-success badge-glow">
                                            <i class="bi bi-check-circle me-1"></i>Ya
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Tidak</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-info btn-action" onclick="detailSiswa(<?= $row['id'] ?>)" title="Detail">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        <button class="btn btn-warning btn-action" onclick="editSiswa(<?= $row['id'] ?>)" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-danger btn-action" onclick="hapusSiswa(<?= $row['id'] ?>)" title="Hapus">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tambah Siswa -->
<div class="modal fade" id="modalTambahSiswa" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">
                    <i class="bi bi-plus-circle me-2"></i> Tambah Siswa Baru
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form id="formTambahSiswa">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-hash me-1"></i>NISN <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" name="nisn" required 
                                   placeholder="Masukkan NISN" maxlength="10">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-person me-1"></i>Nama Lengkap <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" name="nama" required 
                                   placeholder="Masukkan nama lengkap">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">
                                <i class="bi bi-gender-ambiguous me-1"></i>Jenis Kelamin <span class="text-danger">*</span>
                            </label>
                            <select class="form-select" name="jenis_kelamin" required>
                                <option value="">-- Pilih --</option>
                                <option value="L">Laki-laki</option>
                                <option value="P">Perempuan</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">
                                <i class="bi bi-building me-1"></i>Kelas <span class="text-danger">*</span>
                            </label>
                            <select class="form-select" name="kelas" required>
                                <option value="">-- Pilih Kelas --</option>
                                <option value="1A">1A</option>
                                <option value="1B">1B</option>
                                <option value="2A">2A</option>
                                <option value="2B">2B</option>
                                <option value="2C">2C</option>
                                <option value="3A">3A</option>
                                <option value="3B">3B</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">
                                <i class="bi bi-telephone me-1"></i>No. Telepon
                            </label>
                            <input type="text" class="form-control" name="no_telp" placeholder="08xxxxxx">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-house me-1"></i>Alamat
                            </label>
                            <textarea class="form-control" name="alamat" rows="2" placeholder="Masukkan alamat"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-heart-pulse me-1"></i>Dokter Cilik
                            </label>
                            <select class="form-select" name="dokcil">
                                <option value="Tidak">Tidak</option>
                                <option value="Ya">Ya</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle me-1"></i>Batal
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-save me-1"></i> Simpan Data
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Siswa -->
<div class="modal fade" id="modalEditSiswa" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title">
                    <i class="bi bi-pencil-square me-2"></i> Edit Data Siswa
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="formEditSiswa">
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-hash me-1"></i>NISN <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" name="nisn" id="edit_nisn" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-person me-1"></i>Nama Lengkap <span class="text-danger">*</span>
                            </label>
                            <input type="text" class="form-control" name="nama" id="edit_nama" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">
                                <i class="bi bi-gender-ambiguous me-1"></i>Jenis Kelamin <span class="text-danger">*</span>
                            </label>
                            <select class="form-select" name="jenis_kelamin" id="edit_jk" required>
                                <option value="L">Laki-laki</option>
                                <option value="P">Perempuan</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">
                                <i class="bi bi-building me-1"></i>Kelas <span class="text-danger">*</span>
                            </label>
                            <select class="form-select" name="kelas" id="edit_kelas" required>
                                <option value="1A">1A</option>
                                <option value="1B">1B</option>
                                <option value="2A">2A</option>
                                <option value="2B">2B</option>
                                <option value="2C">2C</option>
                                <option value="3A">3A</option>
                                <option value="3B">3B</option>
                                <option value="3B">4A</option>
                                <option value="3B">4B</option>
                                <option value="3B">4C</option>
                                <option value="3B">5A</option>
                                <option value="3B">5B</option>
                                <option value="3B">6A</option>
                                <option value="3B">6B</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label">
                                <i class="bi bi-telephone me-1"></i>No. Telepon
                            </label>
                            <input type="text" class="form-control" name="no_telp" id="edit_telp">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-house me-1"></i>Alamat
                            </label>
                            <textarea class="form-control" name="alamat" id="edit_alamat" rows="2"></textarea>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">
                                <i class="bi bi-heart-pulse me-1"></i>Dokter Cilik
                            </label>
                            <select class="form-select" name="dokcil" id="edit_dokcil">
                                <option value="Tidak">Tidak</option>
                                <option value="Ya">Ya</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="bi bi-x-circle me-1"></i>Batal
                    </button>
                    <button type="submit" class="btn btn-warning text-white">
                        <i class="bi bi-arrow-repeat me-1"></i> Update Data
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Detail Siswa -->
<div class="modal fade" id="modalDetailSiswa" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title">
                    <i class="bi bi-eye me-2"></i> Detail Siswa
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="detailSiswaContent">
                <!-- Load dengan AJAX -->
            </div>
        </div>
    </div>
</div>

</main>
</div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    // Create floating particles
    function createParticles() {
        const container = document.getElementById('particles');
        for (let i = 0; i < 30; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.width = (Math.random() * 4 + 2) + 'px';
            particle.style.height = particle.style.width;
            particle.style.animationDuration = (Math.random() * 20 + 10) + 's';
            particle.style.animationDelay = (Math.random() * 10) + 's';
            container.appendChild(particle);
        }
    }
    createParticles();
    
    // DataTable
    var table = $('#tabelSiswa').DataTable({
        responsive: true,
        pageLength: 25,
        language: {
            url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/id.json'
        },
        dom: '<"top"f>rt<"bottom"lip><"clear">',
        ordering: true,
        columnDefs: [
            { orderable: false, targets: [0, 7] }
        ]
    });
    
    // Filter Kelas
    $('#filterKelas').on('change', function() {
        table.column(4).search(this.value).draw();
    });
    
    // Filter Jenis Kelamin
    $('#filterJK').on('change', function() {
        table.column(3).search(this.value).draw();
    });
    
    // Submit Form Tambah
    $('#formTambahSiswa').on('submit', function(e) {
        e.preventDefault();
        
        $.ajax({
            url: '../proses/siswa_proses.php',
            type: 'POST',
            data: $(this).serialize() + '&action=tambah',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: 'Data siswa berhasil ditambahkan',
                        showConfirmButton: false,
                        timer: 1500,
                        background: 'rgba(255,255,255,0.95)',
                        backdrop: 'rgba(0,0,0,0.5)'
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal!',
                        text: response.message,
                        background: 'rgba(255,255,255,0.95)',
                        backdrop: 'rgba(0,0,0,0.5)'
                    });
                }
            }
        });
    });
    
    // Submit Form Edit
    $('#formEditSiswa').on('submit', function(e) {
        e.preventDefault();
        
        $.ajax({
            url: '../proses/siswa_proses.php',
            type: 'POST',
            data: $(this).serialize() + '&action=edit',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: 'Data siswa berhasil diupdate',
                        showConfirmButton: false,
                        timer: 1500,
                        background: 'rgba(255,255,255,0.95)',
                        backdrop: 'rgba(0,0,0,0.5)'
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal!',
                        text: response.message,
                        background: 'rgba(255,255,255,0.95)',
                        backdrop: 'rgba(0,0,0,0.5)'
                    });
                }
            }
        });
    });
});

// Fungsi Edit Siswa
function editSiswa(id) {
    $.ajax({
        url: '../proses/siswa_proses.php',
        type: 'GET',
        data: { action: 'get_data', id: id },
        dataType: 'json',
        success: function(data) {
            $('#edit_id').val(data.id);
            $('#edit_nisn').val(data.nisn);
            $('#edit_nama').val(data.nama);
            $('#edit_jk').val(data.jenis_kelamin);
            $('#edit_kelas').val(data.kelas);
            $('#edit_alamat').val(data.alamat);
            $('#edit_telp').val(data.no_telp);
            $('#edit_dokcil').val(data.dokcil);
            
            $('#modalEditSiswa').modal('show');
        }
    });
}

// Fungsi Hapus Siswa
function hapusSiswa(id) {
    Swal.fire({
        title: 'Konfirmasi Hapus',
        text: 'Apakah Anda yakin ingin menghapus data siswa ini?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal',
        background: 'rgba(255,255,255,0.95)',
        backdrop: 'rgba(0,0,0,0.5)'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../proses/siswa_proses.php',
                type: 'POST',
                data: { action: 'hapus', id: id },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil!',
                            text: 'Data siswa berhasil dihapus',
                            showConfirmButton: false,
                            timer: 1500,
                            background: 'rgba(255,255,255,0.95)',
                            backdrop: 'rgba(0,0,0,0.5)'
                        }).then(() => {
                            location.reload();
                        });
                    }
                }
            });
        }
    });
}

// Fungsi Detail Siswa
function detailSiswa(id) {
    $.ajax({
        url: '../proses/siswa_proses.php',
        type: 'GET',
        data: { action: 'detail', id: id },
        success: function(response) {
            $('#detailSiswaContent').html(response);
            $('#modalDetailSiswa').modal('show');
        }
    });
}
</script>

</body>
</html>