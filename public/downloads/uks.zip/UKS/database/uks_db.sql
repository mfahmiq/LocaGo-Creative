-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Jul 2026
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uks_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `guru`
--

CREATE TABLE `guru` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `no_wa` varchar(20) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `jabatan` varchar(50) DEFAULT 'Wali Kelas'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `guru`
--

INSERT INTO `guru` (`id`, `nama`, `no_wa`, `kelas`, `jabatan`) VALUES
(1, 'Bu Guru A', '62812xxxxxxx1', '1A', 'Wali Kelas'),
(2, 'Bu Guru B', '62812xxxxxxx2', '1B', 'Wali Kelas'),
(3, 'Pak Guru C', '62812xxxxxxx3', 'Olahraga', 'Guru Mapel');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kunjungan`
--

CREATE TABLE `kunjungan` (
  `id` int(11) NOT NULL,
  `siswa_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `keluhan` text DEFAULT NULL,
  `diagnosa` text DEFAULT NULL,
  `penanganan` text DEFAULT NULL,
  `petugas_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kunjungan`
--

INSERT INTO `kunjungan` (`id`, `siswa_id`, `tanggal`, `keluhan`, `diagnosa`, `penanganan`, `petugas_id`, `created_at`) VALUES
(1, 3, '2026-07-20', 'Sakit kepala', 'Pusing/Sakit Kepala', 'Istirahat', 1, '2026-07-20 08:00:00'),
(2, 5, '2026-07-20', 'Demam', 'Demam', 'Pemberian Obat', 1, '2026-07-20 09:00:00'),
(3, 8, '2026-07-21', 'Jatuh saat istirahat', 'Luka Ringan', 'Perban/Plaster', 1, '2026-07-21 10:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kunjungan_obat`
--

CREATE TABLE `kunjungan_obat` (
  `id` int(11) NOT NULL,
  `kunjungan_id` int(11) NOT NULL,
  `obat_id` int(11) NOT NULL,
  `jumlah` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kunjungan_obat`
--

INSERT INTO `kunjungan_obat` (`id`, `kunjungan_id`, `obat_id`, `jumlah`) VALUES
(1, 2, 1, 1),
(2, 3, 5, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `obat`
--

CREATE TABLE `obat` (
  `id` int(11) NOT NULL,
  `kode_obat` varchar(20) NOT NULL,
  `nama_obat` varchar(100) NOT NULL,
  `jenis_obat` varchar(50) DEFAULT NULL,
  `stok` int(11) DEFAULT 0,
  `satuan` varchar(20) DEFAULT 'Tablet',
  `stok_minimum` int(11) DEFAULT 10,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `obat`
--

INSERT INTO `obat` (`id`, `kode_obat`, `nama_obat`, `jenis_obat`, `stok`, `satuan`, `stok_minimum`, `created_at`) VALUES
(1, 'OBT001', 'Paracetamol 500mg', 'Tablet', 100, 'Tablet', 20, '2026-07-18 10:09:35'),
(2, 'OBT002', 'Amoxicillin 500mg', 'Kapsul', 50, 'Kapsul', 10, '2026-07-18 10:09:35'),
(3, 'OBT003', 'Antasida', 'Tablet', 80, 'Tablet', 15, '2026-07-18 10:09:35'),
(4, 'OBT004', 'Oralit', 'Serbuk', 45, 'Sachet', 10, '2026-07-18 10:09:35'),
(5, 'OBT005', 'Betadine', 'Cairan', 30, 'Botol', 5, '2026-07-18 10:09:35'),
(6, 'OBT006', 'Paracetamol Sirup', 'Sirup', 25, 'Botol', 5, '2026-07-18 10:09:35'),
(7, 'OBT007', 'CTM', 'Tablet', 90, 'Tablet', 20, '2026-07-18 10:09:35'),
(8, 'OBT008', 'Vitamin C', 'Tablet', 120, 'Tablet', 25, '2026-07-18 10:09:35'),
(9, 'OBT009', 'Antimo', 'Tablet', 60, 'Tablet', 10, '2026-07-18 10:09:35'),
(10, 'OBT010', 'Minyak Kayu Putih', 'Cairan', 35, 'Botol', 5, '2026-07-18 10:09:35'),
(11, 'OBT011', 'Plaster Luka', 'Alat', 75, 'Pcs', 15, '2026-07-18 10:09:35'),
(12, 'OBT012', 'Kapas', 'Alat', 40, 'Roll', 10, '2026-07-18 10:09:35'),
(13, 'OBT013', 'Perban', 'Alat', 50, 'Roll', 10, '2026-07-18 10:09:35'),
(14, 'OBT014', 'Alkohol 70%', 'Cairan', 20, 'Botol', 3, '2026-07-18 10:09:35'),
(15, 'OBT015', 'OBH Combi', 'Sirup', 15, 'Botol', 3, '2026-07-18 10:09:35'),
(16, 'OBT016', 'Diapet', 'Kapsul', 55, 'Kapsul', 10, '2026-07-18 10:09:35'),
(17, 'OBT017', 'Bodrex', 'Tablet', 70, 'Tablet', 15, '2026-07-18 10:09:35'),
(18, 'OBT018', 'Tolak Angin', 'Sachet', 85, 'Sachet', 20, '2026-07-18 10:09:35'),
(19, 'OBT019', 'Antangin', 'Sachet', 65, 'Sachet', 15, '2026-07-18 10:09:35'),
(20, 'OBT020', 'Promag', 'Tablet', 95, 'Tablet', 20, '2026-07-18 10:09:35');

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayat_penyakit`
--

CREATE TABLE `riwayat_penyakit` (
  `id` int(11) NOT NULL,
  `siswa_id` int(11) NOT NULL,
  `nama_penyakit` varchar(100) NOT NULL,
  `tahun` varchar(10) DEFAULT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `riwayat_penyakit`
--

INSERT INTO `riwayat_penyakit` (`id`, `siswa_id`, `nama_penyakit`, `tahun`, `keterangan`) VALUES
(1, 3, 'Asma', '2025', 'Asma ringan'),
(2, 5, 'Alergi', '2025', 'Alergi debu');

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id` int(11) NOT NULL,
  `nisn` varchar(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `alamat` text DEFAULT NULL,
  `no_telp` varchar(15) DEFAULT NULL,
  `dokcil` enum('Ya','Tidak') DEFAULT 'Tidak',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `siswa` (DATA DUMMY)
--

INSERT INTO `siswa` (`id`, `nisn`, `nama`, `kelas`, `jenis_kelamin`, `alamat`, `no_telp`, `dokcil`, `created_at`) VALUES
(1, '0000000001', 'Siswa Satu', '1A', 'L', NULL, NULL, 'Tidak', '2026-07-18 10:09:35'),
(2, '0000000002', 'Siswa Dua', '1A', 'L', NULL, NULL, 'Tidak', '2026-07-18 10:09:35'),
(3, '0000000003', 'Siswa Tiga', '1A', 'L', NULL, NULL, 'Ya', '2026-07-18 10:09:35'),
(4, '0000000004', 'Siswa Empat', '1A', 'L', NULL, NULL, 'Tidak', '2026-07-18 10:09:35'),
(5, '0000000005', 'Siswa Lima', '1A', 'P', NULL, NULL, 'Tidak', '2026-07-18 10:09:35'),
(6, '0000000006', 'Siswa Enam', '1A', 'P', NULL, NULL, 'Ya', '2026-07-18 10:09:35'),
(7, '0000000007', 'Siswa Tujuh', '1A', 'P', NULL, NULL, 'Tidak', '2026-07-18 10:09:35'),
(8, '0000000008', 'Siswa Delapan', '1A', 'P', NULL, NULL, 'Tidak', '2026-07-18 10:09:35'),
(9, '0000000009', 'Siswa Sembilan', '1A', 'P', NULL, NULL, 'Ya', '2026-07-18 10:09:35'),
(10, '0000000010', 'Siswa Sepuluh', '1A', 'L', NULL, NULL, 'Tidak', '2026-07-18 10:09:35'),
(11, '0000000011', 'Siswa 1B Satu', '1B', 'L', NULL, NULL, 'Tidak', '2026-07-18 10:09:35'),
(12, '0000000012', 'Siswa 1B Dua', '1B', 'L', NULL, NULL, 'Tidak', '2026-07-18 10:09:35'),
(13, '0000000013', 'Siswa 1B Tiga', '1B', 'P', NULL, NULL, 'Ya', '2026-07-18 10:09:35'),
(14, '0000000014', 'Siswa 2A Satu', '2A', 'L', NULL, NULL, 'Tidak', '2026-07-18 10:09:35'),
(15, '0000000015', 'Siswa 2A Dua', '2A', 'P', NULL, NULL, 'Ya', '2026-07-18 10:09:35'),
(16, '0000000016', 'Siswa 3A Satu', '3A', 'L', NULL, NULL, 'Tidak', '2026-07-18 10:09:35'),
(17, '0000000017', 'Siswa 3A Dua', '3A', 'P', NULL, NULL, 'Ya', '2026-07-18 10:09:35'),
(18, '0000000018', 'Siswa 4A Satu', '4A', 'L', NULL, NULL, 'Tidak', '2026-07-18 10:09:35'),
(19, '0000000019', 'Siswa 5A Satu', '5A', 'P', NULL, NULL, 'Ya', '2026-07-18 10:09:35'),
(20, '0000000020', 'Siswa 6A Satu', '6A', 'L', NULL, NULL, 'Tidak', '2026-07-18 10:09:35');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `role` enum('admin','petugas') DEFAULT 'petugas',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `nama_lengkap`, `role`, `created_at`) VALUES
(1, 'Staff1', '$2y$10$vNh1BqNDIqsLq5HPuWz5Keo1fGUY3V.1AMXHnjLYXknXVFjpKrqLi', 'Staff UKS', 'admin', '2026-07-18 10:09:35'),
(2, 'petugas1', '$2y$10$vNh1BqNDIqsLq5HPuWz5Keo1fGUY3V.1AMXHnjLYXknXVFjpKrqLi', 'Petugas Satu', 'petugas', '2026-07-18 10:09:35'),
(3, 'petugas2', '$2y$10$vNh1BqNDIqsLq5HPuWz5Keo1fGUY3V.1AMXHnjLYXknXVFjpKrqLi', 'Petugas Dua', 'petugas', '2026-07-18 10:09:35');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kunjungan`
--
ALTER TABLE `kunjungan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `petugas_id` (`petugas_id`),
  ADD KEY `idx_tanggal` (`tanggal`),
  ADD KEY `idx_siswa` (`siswa_id`);

--
-- Indeks untuk tabel `kunjungan_obat`
--
ALTER TABLE `kunjungan_obat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kunjungan_id` (`kunjungan_id`),
  ADD KEY `obat_id` (`obat_id`);

--
-- Indeks untuk tabel `obat`
--
ALTER TABLE `obat`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_obat` (`kode_obat`);

--
-- Indeks untuk tabel `riwayat_penyakit`
--
ALTER TABLE `riwayat_penyakit`
  ADD PRIMARY KEY (`id`),
  ADD KEY `siswa_id` (`siswa_id`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nisn` (`nisn`),
  ADD KEY `idx_kelas` (`kelas`),
  ADD KEY `idx_nama` (`nama`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `guru`
--
ALTER TABLE `guru`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `kunjungan`
--
ALTER TABLE `kunjungan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `kunjungan_obat`
--
ALTER TABLE `kunjungan_obat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `obat`
--
ALTER TABLE `obat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `riwayat_penyakit`
--
ALTER TABLE `riwayat_penyakit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `kunjungan`
--
ALTER TABLE `kunjungan`
  ADD CONSTRAINT `kunjungan_ibfk_1` FOREIGN KEY (`siswa_id`) REFERENCES `siswa` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `kunjungan_ibfk_2` FOREIGN KEY (`petugas_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Ketidakleluasaan untuk tabel `kunjungan_obat`
--
ALTER TABLE `kunjungan_obat`
  ADD CONSTRAINT `kunjungan_obat_ibfk_1` FOREIGN KEY (`kunjungan_id`) REFERENCES `kunjungan` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `kunjungan_obat_ibfk_2` FOREIGN KEY (`obat_id`) REFERENCES `obat` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `riwayat_penyakit`
--
ALTER TABLE `riwayat_penyakit`
  ADD CONSTRAINT `riwayat_penyakit_ibfk_1` FOREIGN KEY (`siswa_id`) REFERENCES `siswa` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;