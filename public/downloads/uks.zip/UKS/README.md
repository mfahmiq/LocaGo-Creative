# 🏥 UKS Management System

A web-based School Health Unit (UKS) Management System developed using **PHP Native**, **MySQL**, **Bootstrap**, and **JavaScript**. This application helps schools manage UKS administration digitally, making health data recording faster, more organized, and easier to access.

> **Note:** This repository contains **dummy data only**. No real student or school data is included.

---

## ✨ Features

### 📊 Dashboard
- UKS statistics overview
- Quick access to all modules

### 👨‍🎓 Student Management
- Add, edit, delete student data
- Search student records
- View student details

### 🩺 Health Examination
- Record student health check results
- Store examination history
- Print examination reports

### 💊 Medicine Management
- Manage medicine inventory
- Track available medicines
- Update stock information

### 👨‍⚕️ Dokter Kecil (Dokcil)
- Manage Dokcil member data
- Print Dokcil membership cards
- View Dokcil information

### 📑 Reports
- Generate printable reports
- Export health data
- Administration reports

### 🔐 Authentication
- Secure login system
- Session management

---

## 🛠️ Built With

- PHP Native
- MySQL / MariaDB
- Bootstrap 5
- HTML5
- CSS3
- JavaScript
- XAMPP

---

## 📸 Screenshots

> Add screenshots here.

## 📸 Screenshots

### Dashboard
![Dashboard](assets/img/dashboard.png)

### Data Siswa
![Data Siswa](assets/img/data%20siswa.png)

### Kunjungan
![Kunjungan](assets/img/kunjungan.png)

### Data Guru
![Data Guru](assets/img/data%20guru.png)

### Manajemen Obat
![Manajemen Obat](assets/img/manajemen%20obat.png)

### Riwayat
![Riwayat](assets/img/riwayat.png)

### Dokter Kecil
![Dokcil](assets/img/dokcil.png)

### Laporan
![Laporan](assets/img/laporan.png)

## 📂 Project Structure

```
UKS/
│
├── assets/
├── config/
├── database/
├── pages/
├── proses/
├── templates/
├── uploads/
├── index.php
└── README.md
```

---

## 🚀 Installation

### 1. Clone Repository

```bash
git clone https://github.com/USERNAME/REPOSITORY.git
```

### 2. Move Project

Copy the project into:

```
xampp/htdocs/
```

### 3. Create Database

Create a new database in phpMyAdmin.

Example:

```
db_uks
```

### 4. Import Database

Import the SQL file located inside:

```
database/
```

### 5. Configure Database

Edit:

```
config/database.php
```

Example:

```php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_uks";
```

### 6. Run Application

Open:

```
http://localhost/UKS
```

---

## 📌 Project Purpose

This project was developed to digitize School Health Unit (UKS) administration, including:

- Student health records
- Medical examinations
- Medicine inventory
- Dokter Kecil (Dokcil) management
- Administrative reports

---

## 🔒 Disclaimer

This project is intended for educational and portfolio purposes.

All personal data included in this repository has been replaced with **dummy data**.

---

## 👨‍💻 Author

**Irgi Kusuma**

- 💼 IT Support
- 👨‍🏫 ICT Teacher
- 💻 Web Developer

GitHub:
https://github.com/YOUR_USERNAME

---

## ⭐ Support

If you like this project, don't forget to give it a ⭐ on GitHub.
