<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: pages/dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Dokter Cilik | UKS SDN 5 Kota Serang</title>
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;600;700;800&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --sky: #eaf5fc;
            --sky-deep: #d7ecf8;
            --blue: #2f8fd6;
            --blue-deep: #1c5f8f;
            --navy: #133b57;
            --gold: #ffc247;
            --mint: #3ec6a0;
            --coral: #ff7a6b;
            --white: #ffffff;
            --radius: 22px;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: 'Nunito', sans-serif;
            background:
                radial-gradient(circle at 12% 15%, #ffffff 0%, transparent 35%),
                radial-gradient(circle at 88% 82%, #ffffff 0%, transparent 30%),
                linear-gradient(160deg, var(--sky) 0%, var(--sky-deep) 55%, #cfe8f6 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 32px 16px;
            position: relative;
            overflow-x: hidden;
        }

        /* Ambient decorative shapes */
        .decor {
            position: absolute;
            border-radius: 50%;
            opacity: 0.5;
            pointer-events: none;
        }
        .decor.d1 { width: 220px; height: 220px; background: var(--gold); opacity: .18; top: -60px; left: -60px; }
        .decor.d2 { width: 260px; height: 260px; background: var(--mint); opacity: .16; bottom: -80px; right: -80px; }
        .decor.d3 { width: 140px; height: 140px; background: var(--coral); opacity: .12; bottom: 10%; left: 4%; }

        .heartbeat-line {
            position: absolute;
            top: 8%;
            left: 0;
            width: 100%;
            opacity: 0.25;
            pointer-events: none;
        }

        .wrap {
            position: relative;
            width: 100%;
            max-width: 960px;
            display: grid;
            grid-template-columns: 1.05fr 1fr;
            background: var(--white);
            border-radius: 28px;
            box-shadow: 0 30px 70px -20px rgba(19, 59, 87, 0.35);
            overflow: hidden;
            min-height: 560px;
        }

        /* Left panel - brand / school identity */
        .panel {
            background: linear-gradient(150deg, var(--blue) 0%, var(--blue-deep) 75%);
            color: var(--white);
            padding: 44px 40px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            position: relative;
            overflow: hidden;
        }
        .panel::before {
            content: "";
            position: absolute;
            width: 420px;
            height: 420px;
            border-radius: 50%;
            background: rgba(255,255,255,0.06);
            top: -140px;
            right: -140px;
        }
        .panel::after {
            content: "";
            position: absolute;
            width: 260px;
            height: 260px;
            border-radius: 50%;
            background: rgba(255,255,255,0.05);
            bottom: -100px;
            left: -80px;
        }

        .badge-logo {
            width: 118px;
            height: 118px;
            background: var(--white);
            border-radius: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 12px 28px -8px rgba(0,0,0,0.35);
            padding: 12px;
            position: relative;
            z-index: 1;
        }
        .badge-logo img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        .panel h1 {
            font-family: 'Baloo 2', sans-serif;
            font-size: 30px;
            margin: 22px 0 6px;
            position: relative;
            z-index: 1;
        }
        .panel .school-name {
            font-family: 'Baloo 2', sans-serif;
            font-weight: 700;
            font-size: 15px;
            letter-spacing: 0.4px;
            opacity: 0.9;
            position: relative;
            z-index: 1;
        }
        .panel p.tagline {
            font-size: 14.5px;
            line-height: 1.6;
            opacity: 0.88;
            max-width: 320px;
            margin-top: 14px;
            position: relative;
            z-index: 1;
        }

        .feature-list {
            display: flex;
            flex-direction: column;
            gap: 14px;
            position: relative;
            z-index: 1;
        }
        .feature-item {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 13.5px;
            font-weight: 700;
        }
        .feature-icon {
            width: 34px;
            height: 34px;
            border-radius: 10px;
            background: rgba(255,255,255,0.16);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        .feature-icon svg { width: 18px; height: 18px; }

        /* Right panel - form */
        .form-panel {
            padding: 48px 44px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .form-header {
            text-align: left;
            margin-bottom: 28px;
        }
        .form-header .eyebrow {
            font-size: 12.5px;
            font-weight: 800;
            letter-spacing: 1.2px;
            color: var(--mint);
            text-transform: uppercase;
        }
        .form-header h2 {
            font-family: 'Baloo 2', sans-serif;
            font-size: 26px;
            color: var(--navy);
            margin: 6px 0 4px;
        }
        .form-header p {
            font-size: 14px;
            color: #5c7a8c;
            margin: 0;
        }

        .field {
            margin-bottom: 18px;
        }
        .field label {
            display: block;
            font-size: 13px;
            font-weight: 700;
            color: var(--navy);
            margin-bottom: 6px;
        }
        .input-shell {
            display: flex;
            align-items: center;
            gap: 10px;
            border: 2px solid #e2eef5;
            background: #f7fbfd;
            border-radius: 14px;
            padding: 12px 14px;
            transition: border-color .18s ease, box-shadow .18s ease;
        }
        .input-shell:focus-within {
            border-color: var(--blue);
            box-shadow: 0 0 0 4px rgba(47,143,214,0.14);
            background: var(--white);
        }
        .input-shell svg {
            width: 18px;
            height: 18px;
            color: #8fadbd;
            flex-shrink: 0;
        }
        .input-shell input {
            border: none;
            outline: none;
            background: transparent;
            width: 100%;
            font-family: 'Nunito', sans-serif;
            font-size: 14.5px;
            color: var(--navy);
        }
        .input-shell input::placeholder { color: #a9c0cc; }
        .toggle-eye {
            cursor: pointer;
            color: #a9c0cc;
        }
        .toggle-eye:hover { color: var(--blue); }

        .remember-row {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 22px;
            font-size: 13.5px;
            color: #5c7a8c;
            font-weight: 700;
        }
        .remember-row input {
            width: 17px;
            height: 17px;
            accent-color: var(--blue);
            cursor: pointer;
        }

        .btn-login {
            width: 100%;
            border: none;
            border-radius: 14px;
            padding: 14px;
            background: linear-gradient(135deg, var(--blue) 0%, var(--blue-deep) 100%);
            color: #fff;
            font-family: 'Baloo 2', sans-serif;
            font-weight: 700;
            font-size: 16px;
            letter-spacing: 0.3px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            box-shadow: 0 12px 24px -8px rgba(47,143,214,0.55);
            transition: transform .15s ease, box-shadow .15s ease;
        }
        .btn-login:hover {
            transform: translateY(-1px);
            box-shadow: 0 16px 30px -8px rgba(47,143,214,0.6);
        }
        .btn-login:active { transform: translateY(0); }
        .btn-login svg { width: 18px; height: 18px; }

        .form-footer {
            text-align: center;
            margin-top: 22px;
            font-size: 13px;
            color: #93aebc;
        }

        @media (max-width: 820px) {
            .wrap { grid-template-columns: 1fr; }
            .panel { padding: 36px 32px; }
            .form-panel { padding: 38px 32px; }
        }

        /* focus visibility */
        a:focus-visible, button:focus-visible, input:focus-visible {
            outline: 3px solid var(--gold);
            outline-offset: 2px;
        }

        @media (prefers-reduced-motion: reduce) {
            * { transition: none !important; animation: none !important; }
        }
    </style>
</head>
<body>
    <div class="decor d1"></div>
    <div class="decor d2"></div>
    <div class="decor d3"></div>

    <div class="wrap">
        <!-- Left: school / brand panel -->
        <div class="panel">
            <div>
                <div class="badge-logo">
                    <img src="assets/img/logo_sdn5.png" alt="Logo SDN 5 Kota Serang">
                </div>
                <h1>Dokter Cilik</h1>
                <div class="school-name">SDN 5 Kota Serang &middot; Unit Kesehatan Sekolah</div>
                <p class="tagline">Belajar, peduli, dan menginspirasi generasi sehat &amp; berkarakter sejak dari sekolah.</p>
            </div>

            <div class="feature-list">
                <div class="feature-item">
                    <span class="feature-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                    </span>
                    Belajar ilmu kesehatan dengan menyenangkan
                </div>
                <div class="feature-item">
                    <span class="feature-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                    </span>
                    Peduli terhadap diri sendiri dan orang lain
                </div>
                <div class="feature-item">
                    <span class="feature-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l2.9 6.26 6.9.6-5.2 4.63 1.55 6.78L12 16.9l-6.15 3.37 1.55-6.78L2.2 8.86l6.9-.6z"/></svg>
                    </span>
                    Menginspirasi generasi sehat &amp; berkarakter
                </div>
            </div>
        </div>

        <!-- Right: login form -->
        <div class="form-panel">
            <div class="form-header">
                <span class="eyebrow">UKS System</span>
                <h2>Selamat datang kembali</h2>
                <p>Masuk untuk melanjutkan ke Dokter Cilik.</p>
            </div>

            <form id="loginForm">
                <div class="field">
                    <label for="username">Username</label>
                    <div class="input-shell">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        <input type="text" id="username" name="username" placeholder="Masukkan username" required>
                    </div>
                </div>

                <div class="field">
                    <label for="password">Password</label>
                    <div class="input-shell">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="10" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                        <input type="password" id="password" name="password" placeholder="Masukkan password" required>
                        <svg class="toggle-eye" id="togglePassword" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    </div>
                </div>

                <label class="remember-row">
                    <input type="checkbox" name="remember">
                    Ingat saya di perangkat ini
                </label>

                <button type="submit" class="btn-login">
                    Masuk
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="M13 6l6 6-6 6"/></svg>
                </button>
            </form>

            <div class="form-footer">
                &copy; <?php echo date('Y'); ?> SDN 5 Kota Serang &middot; Unit Kesehatan Sekolah
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {
            $('#togglePassword').on('click', function() {
                const pwd = $('#password');
                const isText = pwd.attr('type') === 'text';
                pwd.attr('type', isText ? 'password' : 'text');
            });

            $('#loginForm').on('submit', function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'proses/login.php',
                    type: 'POST',
                    data: $(this).serialize(),
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Login Berhasil',
                                text: 'Selamat datang di Dokter Cilik',
                                showConfirmButton: false,
                                timer: 1500
                            }).then(() => {
                                window.location.href = 'pages/dashboard.php';
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Login Gagal',
                                text: response.message
                            });
                        }
                    },
                    error: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Terjadi Kesalahan',
                            text: 'Tidak dapat terhubung ke server. Silakan coba lagi.'
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>