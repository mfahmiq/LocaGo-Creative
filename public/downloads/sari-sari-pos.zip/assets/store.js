'use strict';

const menu = document.querySelector('.menu-button');
const sidebar = document.querySelector('.sidebar');
const shade = document.querySelector('.mobile-shade');
const main = document.querySelector('.main-shell');

function showMenu(open) {
    sidebar.classList.toggle('open', open);
    shade.hidden = !open;
    menu.setAttribute('aria-expanded', String(open));
    main.inert = open;
    if (open) {
        sidebar.querySelector('a').focus();
    } else {
        menu.focus();
    }
}

if (menu && sidebar && shade) {
    menu.addEventListener('click', () => showMenu(true));
    shade.addEventListener('click', () => showMenu(false));
    document.addEventListener('keydown', event => {
        if (!sidebar.classList.contains('open')) return;
        if (event.key === 'Escape') showMenu(false);
        if (event.key === 'Tab') {
            const links = Array.from(sidebar.querySelectorAll('a[href], button:not(:disabled)'));
            if (event.shiftKey && document.activeElement === links[0]) {
                event.preventDefault();
                links.at(-1).focus();
            } else if (!event.shiftKey && document.activeElement === links.at(-1)) {
                event.preventDefault();
                links[0].focus();
            }
        }
    });
    matchMedia('(min-width: 761px)').addEventListener('change', event => {
        if (event.matches && sidebar.classList.contains('open')) showMenu(false);
    });
}

document.querySelectorAll('[data-print]').forEach(button => button.addEventListener('click', () => window.print()));
document.querySelectorAll('form[data-confirm]').forEach(form => {
    form.addEventListener('submit', event => {
        if (!window.confirm(form.dataset.confirm)) event.preventDefault();
    });
});

function setupBarcodeScanner(actions) {
    const dialog = document.querySelector('[data-barcode-scanner]');
    if (typeof dialog?.showModal !== 'function') return;

    const video = dialog.querySelector('video');
    const status = dialog.querySelector('[data-barcode-status]');
    let session;

    function stopCamera() {
        clearTimeout(session?.timer);
        session = undefined;
        video.srcObject?.getTracks().forEach(track => track.stop());
        video.srcObject = null;
        video.hidden = true;
    }

    function closeScanner() {
        stopCamera();
        dialog.close();
    }

    async function openScanner(event) {
        if (dialog.open) return;
        const onScan = actions.get(event.currentTarget.dataset.openBarcodeScanner);
        dialog.showModal();
        if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia) {
            status.textContent = 'Camera access requires HTTPS and a compatible browser. You can still enter the SKU manually.';
            return;
        }

        const zxing = window.ZXing;
        if (!zxing) {
            status.textContent = 'The barcode scanner could not load. Reload the page or enter the SKU manually.';
            return;
        }

        const { BarcodeFormat, DecodeHintType } = zxing;
        const hints = new Map([[DecodeHintType.POSSIBLE_FORMATS, [
            BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A, BarcodeFormat.UPC_E,
            BarcodeFormat.CODE_128, BarcodeFormat.CODE_39, BarcodeFormat.ITF
        ]]]);
        const reader = new zxing.BrowserMultiFormatReader(hints);
        const scan = {};
        session = scan;
        status.textContent = 'Waiting for camera access…';

        const readFrame = () => {
            if (session !== scan) return;
            let result;
            if (video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA) {
                try {
                    result = reader.decode(video);
                } catch (error) {
                    if (!(error instanceof zxing.NotFoundException || error instanceof zxing.ChecksumException
                        || error instanceof zxing.FormatException)) {
                        stopCamera();
                        status.textContent = 'The barcode scanner stopped. Try again or enter the SKU manually.';
                        return;
                    }
                }
            }
            if (result) {
                closeScanner();
                onScan(result.getText());
                return;
            }
            scan.timer = setTimeout(readFrame, 200);
        };

        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 } }, audio: false
            });
            if (session !== scan) {
                stream.getTracks().forEach(track => track.stop());
                return;
            }
            video.srcObject = stream;
            video.hidden = false;
            stream.getVideoTracks()[0]?.addEventListener('ended', () => {
                if (session !== scan) return;
                stopCamera();
                status.textContent = 'The camera disconnected. Reopen the scanner or enter the SKU manually.';
            });
            await video.play();
            if (session !== scan) return;
            status.textContent = 'Hold the barcode steady in view.';
            readFrame();
        } catch (error) {
            if (session !== scan) return;
            stopCamera();
            status.textContent = error.name === 'NotAllowedError'
                ? 'Allow camera access in your browser or enter the SKU manually.'
                : 'Could not open the camera. Check that a camera is available or enter the SKU manually.';
        }
    }

    for (const button of document.querySelectorAll('[data-open-barcode-scanner]')) {
        if (!actions.has(button.dataset.openBarcodeScanner)) continue;
        button.hidden = false;
        button.addEventListener('click', openScanner);
    }
    dialog.querySelector('[data-close-barcode-scanner]').addEventListener('click', closeScanner);
    dialog.addEventListener('cancel', event => {
        event.preventDefault();
        closeScanner();
    });
    window.addEventListener('pagehide', () => {
        if (dialog.open) closeScanner();
    });
}

const barcodeActions = new Map();
const productList = document.querySelector('[data-product-list]');
const productSearch = productList?.querySelector('[data-product-search]');
if (productSearch) {
    const rows = productList.querySelectorAll('[data-product-name]');
    const noMatches = productList.querySelector('[data-product-search-empty]');

    const filterProducts = (exactSku = false) => {
        const term = productSearch.value.trim().toLocaleLowerCase();
        let firstMatch;
        for (const row of rows) {
            const { productName, productSku } = row.dataset;
            const sku = productSku.toLocaleLowerCase();
            const matches = exactSku ? sku === term : sku.includes(term) || productName.toLocaleLowerCase().includes(term);
            row.hidden = !matches;
            if (matches) firstMatch ??= row;
        }
        noMatches.cells[0].textContent = exactSku
            ? 'No product uses this barcode as its SKU.'
            : 'No products match your search.';
        noMatches.hidden = Boolean(firstMatch);
        return firstMatch;
    };

    productSearch.addEventListener('input', () => filterProducts());
    filterProducts();
    barcodeActions.set('search', barcode => {
        productSearch.value = barcode;
        const match = filterProducts(true);
        match?.querySelector('a')?.focus();
    });
}

const skuScanStatus = document.querySelector('[data-sku-scan-status]');
if (skuScanStatus) {
    const sku = skuScanStatus.closest('form').elements.sku;
    barcodeActions.set('sku', barcode => {
        const value = barcode.trim();
        if (!value || value.length > sku.maxLength || /[\r\n]/.test(value)) {
            skuScanStatus.textContent = 'This barcode cannot be used as an SKU. Enter the SKU manually.';
            return;
        }
        sku.value = value;
        skuScanStatus.textContent = 'Barcode copied to SKU.';
    });
    sku.addEventListener('input', () => { skuScanStatus.textContent = ''; });
}

const stockForm = document.querySelector('[data-stock-form]');
if (stockForm) {
    const reason = stockForm.elements.reason;
    const direction = stockForm.elements.direction;
    const updateStock = () => {
        const canRemove = reason.value === 'adjustment';
        direction.options[1].disabled = !canRemove;
        if (!canRemove) direction.value = 'add';
        stockForm.elements.note.required = direction.value === 'remove';
    };
    reason.addEventListener('change', updateStock);
    direction.addEventListener('change', updateStock);
    updateStock();
}

const debtForm = document.querySelector('[data-debt-form]');
if (debtForm) {
    const referenceLabel = debtForm.querySelector('[data-debt-reference]');
    const updateReference = () => {
        const visible = debtForm.elements.method.value === 'gcash';
        referenceLabel.hidden = !visible;
        debtForm.elements.reference.disabled = !visible;
        debtForm.elements.reference.required = visible;
    };
    debtForm.elements.method.addEventListener('change', updateReference);
    updateReference();
}

const completed = document.querySelector('[data-sale-completed]');
if (completed) {
    try {
        sessionStorage.removeItem('sarisari-cart-' + completed.dataset.saleCompleted);
    } catch {
        // Checkout still works when session storage is unavailable.
    }
}

const pos = document.querySelector('[data-pos]');
if (pos) {
    const currency = new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' });
    const peso = cents => currency.format(cents / 100);
    const buttons = Array.from(pos.querySelectorAll('[data-add]'));
    const products = new Map(buttons.map(button => [button.dataset.add, {
        name: button.dataset.name,
        unit: button.dataset.unit,
        price: Number(button.dataset.price),
        stock: Number(button.dataset.stock)
    }]));
    const form = pos.querySelector('[data-checkout]');
    const items = pos.querySelector('[data-cart-items]');
    const status = pos.querySelector('[data-cart-status]');
    const cartScanStatus = pos.querySelector('[data-cart-scan-status]');
    const submit = pos.querySelector('[data-complete]');
    const clear = pos.querySelector('[data-clear-cart]');
    const exact = pos.querySelector('[data-exact]');
    const search = pos.querySelector('[data-catalog-search]');
    const filters = pos.querySelectorAll('[data-category]');
    const noMatches = pos.querySelector('[data-catalog-empty]');
    const storageKey = 'sarisari-cart-' + pos.dataset.user;
    const cart = new Map();
    let category = '';
    let total = 0;

    function announce(message = '') {
        if (cartScanStatus) cartScanStatus.textContent = '';
        status.textContent = message;
        status.hidden = !message;
    }

    try {
        const saved = JSON.parse(sessionStorage.getItem(storageKey) || '[]');
        for (const [id, quantity, price] of saved) {
            const product = products.get(id);
            if (product?.stock && Number.isInteger(quantity) && quantity > 0) {
                cart.set(id, Math.min(quantity, product.stock, 10000));
            }
            if (!product || product.stock < quantity || product.price !== price) {
                announce('The cart was updated to match current prices and stock. Review it before charging.');
            }
        }
    } catch {
        // Start with the current in-memory cart.
    }

    function filterCatalog() {
        const term = search.value.trim().toLocaleLowerCase();
        let visible = 0;
        for (const button of buttons) {
            const match = (!category || category === button.dataset.group)
                && [button.dataset.name, button.dataset.sku].some(value => value.toLocaleLowerCase().includes(term));
            button.hidden = !match;
            if (match) visible += 1;
        }
        if (noMatches) noMatches.hidden = visible > 0;
    }

    function tendered() {
        const match = /^(\d{1,12})(?:\.(\d{1,2}))?$/.exec(form.elements.tendered.value.trim());
        return match ? Number(match[1]) * 100 + Number((match[2] || '').padEnd(2, '0')) : 0;
    }

    function updatePayment() {
        const method = form.elements.method.value;
        for (const section of form.querySelectorAll('[data-payment]')) {
            const show = method === section.dataset.payment;
            section.hidden = !show;
            const control = section.querySelector('input, select');
            control.disabled = !show;
            control.required = show;
        }
        pos.querySelector('[data-change]').textContent = peso(Math.max(0, tendered() - total));
        submit.disabled = !cart.size || (method === 'cash' && tendered() < total)
            || (method === 'gcash' && !form.elements.reference.value.trim())
            || (method === 'utang' && !form.elements.customer_id.value);
    }

    function quantityButton(text, label, id, delta, disabled) {
        const button = document.createElement('button');
        button.type = 'button';
        button.textContent = text;
        button.setAttribute('aria-label', label);
        button.dataset.quantityId = id;
        button.dataset.delta = String(delta);
        button.disabled = disabled;
        return button;
    }

    function renderCart() {
        items.replaceChildren();
        let count = 0;
        total = 0;
        const order = [];
        for (const [id, quantity] of cart) {
            const product = products.get(id);
            const line = product.price * quantity;
            total += line;
            count += quantity;
            order.push({ id: Number(id), quantity, price: product.price });

            const row = document.createElement('li');
            const description = document.createElement('div');
            const name = document.createElement('strong');
            const unit = document.createElement('small');
            name.textContent = product.name;
            unit.textContent = peso(product.price) + ' / ' + product.unit;
            description.append(name, unit);

            const step = document.createElement('div');
            step.className = 'qty-step';
            const units = document.createElement('span');
            units.textContent = String(quantity);
            step.append(
                quantityButton('−', 'Remove one ' + product.name, id, -1, false),
                units,
                quantityButton('+', 'Add one ' + product.name, id, 1, quantity >= Math.min(product.stock, 10000))
            );
            const subtotal = document.createElement('strong');
            subtotal.textContent = peso(line);
            row.append(description, step, subtotal);
            items.append(row);
        }
        try {
            sessionStorage.setItem(storageKey, JSON.stringify(order.map(({ id, quantity, price }) => [String(id), quantity, price])));
        } catch {
            // An unavailable storage API does not affect the sale.
        }
        pos.querySelector('[data-empty-cart]').hidden = count > 0;
        pos.querySelector('[data-cart-count]').textContent = count + (count === 1 ? ' item' : ' items');
        document.querySelector('[data-cart-jump-count]').textContent = String(count);
        pos.querySelector('[data-total]').textContent = peso(total);
        pos.querySelector('[data-cart-json]').value = JSON.stringify(order);
        clear.disabled = !count;
        exact.disabled = !count;
        updatePayment();
    }

    function changeQuantity(id, change, reportError = announce) {
        const product = products.get(id);
        const current = cart.get(id) || 0;
        const next = current + change;
        const limit = Math.min(product.stock, 10000);
        if (next > limit) {
            reportError(limit ? 'Only ' + limit + ' available for this sale.' : product.name + ' is out of stock.');
            return false;
        }
        if (!current && cart.size >= 100) {
            reportError('A sale can include up to 100 different products.');
            return false;
        }
        if (next <= 0) cart.delete(id);
        else cart.set(id, next);
        announce();
        renderCart();
        return true;
    }

    if (cartScanStatus) {
        const reportScan = message => { cartScanStatus.textContent = message; };
        barcodeActions.set('cart', barcode => {
            const sku = barcode.trim().toLocaleLowerCase();
            const match = buttons.find(button => button.dataset.sku.toLocaleLowerCase() === sku);
            if (!match) {
                reportScan('No product available for sale matches this barcode.');
                return;
            }
            if (changeQuantity(match.dataset.add, 1, reportScan)) {
                reportScan(match.dataset.name + ' added to the cart.');
            }
        });
    }

    buttons.forEach(button => button.addEventListener('click', () => changeQuantity(button.dataset.add, 1)));
    items.addEventListener('click', event => {
        const button = event.target.closest('[data-quantity-id]');
        if (!button) return;
        const { quantityId, delta } = button.dataset;
        changeQuantity(quantityId, Number(delta));
        const replacements = Array.from(items.querySelectorAll('[data-quantity-id]')).filter(item => item.dataset.quantityId === quantityId);
        const focusTarget = replacements.find(item => item.dataset.delta === delta && !item.disabled)
            || replacements.find(item => !item.disabled)
            || buttons.find(item => item.dataset.add === quantityId && !item.hidden);
        focusTarget?.focus();
    });
    search.addEventListener('input', filterCatalog);
    filters.forEach(button => button.addEventListener('click', () => {
        category = button.dataset.category;
        filters.forEach(filter => {
            const active = button === filter;
            filter.classList.toggle('active', active);
            filter.setAttribute('aria-pressed', String(active));
        });
        filterCatalog();
    }));
    clear.addEventListener('click', () => {
        cart.clear();
        announce();
        renderCart();
        search.focus();
    });
    exact.addEventListener('click', () => {
        form.elements.tendered.value = (total / 100).toFixed(2);
        updatePayment();
    });
    form.addEventListener('input', updatePayment);
    form.addEventListener('change', updatePayment);
    form.addEventListener('submit', event => {
        updatePayment();
        if (submit.disabled) {
            event.preventDefault();
            return;
        }
        submit.disabled = true;
    });
    renderCart();
}

setupBarcodeScanner(barcodeActions);
