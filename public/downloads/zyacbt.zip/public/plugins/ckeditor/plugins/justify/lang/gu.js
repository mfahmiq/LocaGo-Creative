/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'justify', 'gu', {
	block: 'બ્લૉક, અંતરાય જસ્ટિફાઇ',
	center: 'સંકેંદ્રણ/સેંટરિંગ',
	left: 'ડાબી બાજુએ/બાજુ તરફ',
	right: 'જમણી બાજુએ/બાજુ તરફ'
} );
