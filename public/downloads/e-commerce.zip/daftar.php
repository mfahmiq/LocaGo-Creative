<?php
include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Bergabung Bersama Kami | Arc`teryx Store</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        :root {
            --bg-deep: #030305;
            --card-glass: rgba(30, 31, 38, 0.7);
            --accent-blue: #4c8dff;
            --accent-purple: #9333ea;
            --border: rgba(255, 255, 255, 0.1);
        }

        body {
            background-color: var(--bg-deep);
            color: #fff;
            font-family: 'Plus Jakarta Sans', sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .mesh-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background:
                radial-gradient(at 10% 10%, rgba(76, 141, 255, 0.1) 0px, transparent 40%),
                radial-gradient(at 90% 90%, rgba(147, 51, 234, 0.1) 0px, transparent 40%);
            z-index: -1;
        }

        .main-wrapper {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px 20px;
        }

        .register-card {
            background: var(--card-glass);
            backdrop-filter: blur(25px);
            border: 1px solid var(--border);
            border-radius: 30px;
            padding: 40px;
            width: 100%;
            max-width: 700px;
            /* Diperlebar untuk row input */
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5);
        }

        .form-label {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #888;
            margin-bottom: 8px;
        }

        .form-control {
            background: rgba(255, 255, 255, 0.05) !important;
            border: 1px solid var(--border) !important;
            color: #fff !important;
            border-radius: 12px;
            padding: 12px 15px;
            transition: 0.3s;
        }

        .form-control:focus {
            border-color: var(--accent-blue) !important;
            box-shadow: 0 0 0 4px rgba(76, 141, 255, 0.15) !important;
        }

        .btn-daftar {
            background: linear-gradient(90deg, var(--accent-blue), var(--accent-purple));
            border: none;
            border-radius: 12px;
            padding: 15px;
            font-weight: 700;
            color: #fff;
            transition: 0.3s;
            margin-top: 10px;
        }

        .btn-daftar:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 20px rgba(76, 141, 255, 0.4);
            color: #fff;
        }

        .text-gradient {
            background: linear-gradient(90deg, var(--accent-blue), var(--accent-purple));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>

<body>
    <div class="mesh-bg"></div>

    <?php include "./layout/navbar.php"; ?>

    <main class="main-wrapper">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 d-flex justify-content-center">
                    <div class="register-card">
                        <div class="text-center mb-5">
                            <h2 class="fw-800 mb-2">Buat <span class="text-gradient">Akun</span></h2>
                            <p class="text-muted small">Lengkapi data di bawah untuk mulai berbelanja</p>
                        </div>

                        <form method="post">
                            <div class="row g-3">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Nama Lengkap</label>
                                    <input type="text" class="form-control" name="nama" placeholder="Masukkan nama" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email Aktif</label>
                                    <input type="email" class="form-control" name="email" placeholder="nama@mail.com" required>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Password</label>
                                    <input type="password" class="form-control" name="password" placeholder="••••••••" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Nomor WhatsApp</label>
                                    <input type="text" class="form-control" name="telephone" placeholder="0812..." required>
                                </div>

                                <div class="col-12 mb-4">
                                    <label class="form-label">Alamat Lengkap</label>
                                    <textarea class="form-control" name="alamat" rows="3" placeholder="Jl. Nama Jalan, No. Rumah, RT/RW..." required></textarea>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-daftar w-100" name="daftar">
                                Daftar Sekarang <i class="bi bi-person-plus-fill ms-2"></i>
                            </button>
                        </form>

                        <div class="mt-4 text-center">
                            <p class="text-muted small">Sudah memiliki akun?
                                <a href="login.php" class="text-primary fw-bold text-decoration-none">Masuk di sini</a>
                            </p>
                        </div>

                        <?php
                        if (isset($_POST["daftar"])) {
                            // Sanitasi Input
                            $nama      = mysqli_real_escape_string($koneksi, $_POST["nama"]);
                            $email     = mysqli_real_escape_string($koneksi, $_POST["email"]);
                            $password  = mysqli_real_escape_string($koneksi, $_POST["password"]);
                            $telephone = mysqli_real_escape_string($koneksi, $_POST["telephone"]);
                            $alamat    = mysqli_real_escape_string($koneksi, $_POST["alamat"]);

                            // Cek Duplikasi Email
                            $ambil = $koneksi->query("SELECT * FROM pelanggan WHERE email_pelanggan='$email'");
                            if ($ambil->num_rows == 0) {
                                $koneksi->query("INSERT INTO pelanggan(email_pelanggan, password_pelanggan, nama_pelanggan, telephone_pelanggan, alamat_pelanggan)
                                                VALUES('$email', '$password', '$nama', '$telephone', '$alamat')");

                                echo "<div class='alert alert-success mt-4 text-center rounded-3'>Akun berhasil dibuat! Mengalihkan...</div>";
                                echo "<meta http-equiv='refresh' content='2;url=login.php'>";
                            } else {
                                echo "<div class='alert alert-danger mt-4 text-center rounded-3'>Gagal! Email sudah terdaftar.</div>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include "./layout/footer.php"; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>