<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

<style>
    :root {
        --bg-dark: #050507;
        --glass-bg: rgba(10, 10, 15, 0.75);
        /* Transparansi lebih tinggi untuk efek glass */
        --accent-grad: linear-gradient(135deg, #4c8dff 0%, #a54bff 100%);
        --border-color: rgba(255, 255, 255, 0.08);
    }

    body {
        padding-top: 85px !important;
        background-color: var(--bg-dark);
        font-family: 'Inter', sans-serif;
        color: #ffffff;
    }

    /* Navbar Glassmorphism */
    .navbar-dark-custom {
        background-color: var(--glass-bg) !important;
        backdrop-filter: blur(20px) saturate(180%);
        -webkit-backdrop-filter: blur(20px) saturate(180%);
        border-bottom: 1px solid var(--border-color);
        padding: 12px 0;
        position: fixed !important;
        top: 0;
        width: 100%;
        z-index: 1050;
        transition: all 0.4s ease;
    }

    /* Brand Logo dengan Gradient */
    .navbar-brand-custom {
        font-size: 1.6rem;
        font-weight: 800;
        letter-spacing: -0.5px;
        background: var(--accent-grad);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        display: flex;
        align-items: center;
        text-decoration: none !important;
    }

    /* Nav Link Styling */
    .nav-link-custom {
        color: rgba(255, 255, 255, 0.7) !important;
        font-size: 0.95rem;
        font-weight: 500;
        padding: 10px 18px !important;
        transition: all 0.3s ease;
        position: relative;
    }

    /* Hover Effect: Text Gradient & Underline Glow */
    .nav-link-custom:hover {
        color: #fff !important;
        background: var(--accent-grad);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }

    /* Cart Button Spefisik */
    .cart-btn {
        background: rgba(255, 255, 255, 0.06);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        margin: 0 5px;
        transition: all 0.3s ease;
    }

    .cart-btn:hover {
        background: rgba(255, 255, 255, 0.12);
        border-color: rgba(255, 255, 255, 0.2);
    }

    /* Auth Button (Login/Signup) */
    .btn-auth {
        background: var(--accent-grad);
        color: white !important;
        border-radius: 12px;
        padding: 10px 24px !important;
        font-weight: 600;
        margin-left: 12px;
        border: none;
        box-shadow: 0 4px 15px rgba(76, 141, 255, 0.2);
        transition: all 0.3s ease;
    }

    .btn-auth:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(76, 141, 255, 0.4);
        filter: brightness(1.1);
    }

    /* Logout Button Variant */
    .btn-logout {
        background: rgba(255, 59, 59, 0.1);
        color: #ff4d4d !important;
        border: 1px solid rgba(255, 59, 59, 0.2);
    }

    .btn-logout:hover {
        background: #ff4d4d;
        color: white !important;
        box-shadow: 0 4px 15px rgba(255, 77, 77, 0.3);
    }

    /* Desktop alignment */
    @media (min-width: 992px) {
        .navbar-nav {
            margin-left: auto !important;
            gap: 5px;
        }
    }

    /* Mobile Style Fixes */
    @media (max-width: 991px) {
        .navbar-collapse {
            background: var(--bg-dark);
            margin-top: 15px;
            padding: 20px;
            border-radius: 20px;
            border: 1px solid var(--border-color);
        }

        .btn-auth {
            margin: 10px 0 0 0;
            width: 100%;
            text-align: center;
        }

        .cart-btn {
            margin: 10px 0;
        }
    }

    .navbar-toggler {
        border: none !important;
        padding: 0;
    }

    .navbar-toggler:focus {
        box-shadow: none;
    }
</style>

<nav class="navbar navbar-expand-lg navbar-dark-custom">
    <div class="container">
        <a class="navbar-brand-custom" href="index.php">
            <i class="bi bi-lightning-charge-fill me-2"></i>Arc`teryx
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="text-white"><i class="bi bi-grid-fill fs-2"></i></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item">
                    <a class="nav-link-custom" href="index.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link-custom cart-btn" href="keranjang.php">
                        <i class="bi bi-bag-heart me-1"></i> Keranjang
                    </a>
                </li>

                <?php if (isset($_SESSION["pelanggan"])): ?>
                    <li class="nav-item">
                        <a class="nav-link-custom" href="riwayat.php">Riwayat</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-custom btn-auth btn-logout" href="logout.php">
                            <i class="bi bi-box-arrow-right me-1"></i> Logout
                        </a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link-custom" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-custom btn-auth shadow-sm" href="daftar.php">Sign Up</a>
                    </li>
                <?php endif; ?>

                <li class="nav-item">
                    <a class="nav-link-custom" href="checkout.php">
                        <i class="bi bi-shield-check me-1"></i> Checkout
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>