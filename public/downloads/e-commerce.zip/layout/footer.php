<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

<style>
    :root {
        --bg-dark: #050507;
        --glass-bg: rgba(10, 10, 15, 0.8);
        --accent-grad: linear-gradient(135deg, #4c8dff 0%, #a54bff 100%);
        --border-color: rgba(255, 255, 255, 0.08);
    }

    .footer-dark {
        background-color: var(--bg-dark);
        color: #a0a0a0;
        padding: 60px 0 30px;
        position: relative;
        border-top: 1px solid var(--border-color);
        overflow: hidden;
    }

    /* Efek Glow halus di latar belakang footer */
    .footer-dark::after {
        content: "";
        position: absolute;
        bottom: -50px;
        right: -50px;
        width: 300px;
        height: 300px;
        background: radial-gradient(circle, rgba(76, 141, 255, 0.05) 0%, transparent 70%);
        pointer-events: none;
    }

    .text-gradient {
        background: var(--accent-grad);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-weight: 800;
        letter-spacing: -0.5px;
    }

    .footer-dark h5 {
        color: #fff;
        font-size: 1.1rem;
        margin-bottom: 25px;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    .footer-dark p {
        font-size: 0.95rem;
        line-height: 1.8;
    }

    .footer-link {
        color: #a0a0a0;
        text-decoration: none;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 12px;
    }

    .footer-link:hover {
        color: #fff;
        transform: translateX(5px);
    }

    .footer-link i {
        background: var(--accent-grad);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-size: 1.2rem;
    }

    /* Social Media Icons */
    .social-icons {
        display: flex;
        gap: 15px;
        margin-top: 20px;
    }

    .social-btn {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid var(--border-color);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        transition: all 0.3s ease;
        text-decoration: none;
    }

    .social-btn:hover {
        background: var(--accent-grad);
        border-color: transparent;
        transform: translateY(-3px);
    }

    .footer-bottom {
        text-align: center;
        margin-top: 50px;
        padding-top: 25px;
        border-top: 1px solid var(--border-color);
        font-size: 0.85rem;
        color: #666;
    }
</style>

<footer class="footer-dark">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-4 col-md-6">
                <h2 class="text-gradient mb-3">E-Commerce</h2>
                <p>Web Official Store terpercaya untuk perlengkapan outdoor berkualitas. Kami menyediakan peralatan terbaik untuk petualangan Anda dengan standar keamanan tinggi.</p>
                <div class="social-icons">
                    <a href="#" class="social-btn"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="social-btn"><i class="bi bi-facebook"></i></a>
                    <a href="#" class="social-btn"><i class="bi bi-twitter-x"></i></a>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 d-flex flex-column align-items-lg-center">
                <div>
                    <h5>Navigasi</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="footer-link">Home</a></li>
                        <li><a href="keranjang.php" class="footer-link">Keranjang Belanja</a></li>
                        <li><a href="login.php" class="footer-link">Masuk Akun</a></li>
                        <li><a href="daftar.php" class="footer-link">Daftar Member</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-lg-4 col-md-12">
                <h5>Kontak Kami</h5>
                <a href="mailto:r1z4ld1@contact.com" class="footer-link">
                    <i class="bi bi-envelope-fill"></i> arc`teryx-official@store.com
                </a>
                <a href="https://wa.me/6281248265769" class="footer-link">
                    <i class="bi bi-whatsapp"></i> +62 822-9899-1234
                </a>
                <div class="footer-link">
                    <i class="bi bi-geo-alt-fill"></i> Central Sulawesi, Indonesia
                </div>
            </div>
        </div>

        <div class="footer-bottom">
            &copy; 2026 <span class="text-white fw-bold">Arc`teryx Official Store</span>. Crafted with <i class="bi bi-heart-fill text-danger"></i> by r1z4ld1.
        </div>
    </div>
</footer>