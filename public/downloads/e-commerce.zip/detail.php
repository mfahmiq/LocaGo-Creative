<?php
session_start();
include 'koneksi.php';

// Mendapatkan ID produk dari URL
$id_produk = $_GET["id"];

// Ambil data produk
$ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk'");
$detail = $ambil->fetch_assoc();

// Logika Beli
if (isset($_POST["beli"])) {
	$jumlah = $_POST["jumlah"];
	$_SESSION["keranjang"][$id_produk] = $jumlah;

	echo "<script>alert('Produk telah masuk ke keranjang');</script>";
	echo "<script>location='keranjang.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
	<meta charset="UTF-8">
	<title><?php echo $detail["nama_produk"]; ?> | Detail Arc`teryx</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

	<style>
		:root {
			--bg-deep: #030305;
			--card-glass: rgba(30, 31, 38, 0.7);
			--accent-blue: #4c8dff;
			--accent-purple: #a54bff;
			--text-pure: #ffffff;
			--border: rgba(255, 255, 255, 0.12);
		}

		body {
			background-color: var(--bg-deep);
			color: var(--text-pure);
			font-family: 'Plus Jakarta Sans', sans-serif;
			overflow-x: hidden;
		}

		h1,
		h2,
		h3,
		h4,
		.brand-font {
			font-family: 'Space Grotesk', sans-serif;
		}

		/* --- MESH BACKGROUND (Sama dengan Index) --- */
		.mesh-bg {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background:
				radial-gradient(at 0% 0%, rgba(76, 141, 255, 0.1) 0px, transparent 50%),
				radial-gradient(at 100% 100%, rgba(165, 75, 255, 0.1) 0px, transparent 50%);
			z-index: -1;
		}

		.konten {
			padding: 10px 0 80px;
		}

		/* --- PRODUCT STAGE --- */
		.product-stage {
			background: #ffffff;
			/* Putih bersih agar produk menonjol */
			border-radius: 40px;
			padding: 50px;
			display: flex;
			align-items: center;
			justify-content: center;
			min-height: 550px;
			position: relative;
			border: 1px solid var(--border);
			box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5);
		}

		.product-stage img {
			max-width: 100%;
			max-height: 450px;
			object-fit: contain;
			filter: drop-shadow(0 20px 30px rgba(0, 0, 0, 0.2));
			transition: transform 0.8s cubic-bezier(0.16, 1, 0.3, 1);
		}

		.product-stage:hover img {
			transform: scale(1.05) translateY(-10px);
		}

		/* --- INFO PANEL --- */
		.info-panel {
			padding-left: 50px;
		}

		.category-tag {
			display: inline-block;
			background: linear-gradient(90deg, var(--accent-blue), var(--accent-purple));
			padding: 6px 20px;
			border-radius: 50px;
			font-size: 12px;
			font-weight: 800;
			text-transform: uppercase;
			letter-spacing: 2px;
			margin-bottom: 25px;
		}

		.display-title {
			font-size: clamp(2.5rem, 4vw, 3.8rem);
			font-weight: 700;
			line-height: 1.1;
			margin-bottom: 20px;
			letter-spacing: -1px;
		}

		.price-wrapper {
			background: var(--card-glass);
			display: inline-block;
			padding: 15px 30px;
			border-radius: 20px;
			border: 1px solid var(--border);
			margin-bottom: 35px;
		}

		.price-text {
			font-size: 2rem;
			font-weight: 700;
			color: var(--text-pure);
			margin: 0;
		}

		/* --- QUANTITY & BUY --- */
		.purchase-zone {
			display: flex;
			gap: 15px;
			margin-bottom: 40px;
		}

		.input-qty-modern {
			background: var(--card-glass) !important;
			border: 1px solid var(--border) !important;
			color: white !important;
			width: 100px;
			height: 65px;
			border-radius: 20px;
			text-align: center;
			font-size: 1.3rem;
			font-weight: 700;
		}

		.btn-add-bag {
			background: #ffffff;
			color: #000000 !important;
			border: none;
			padding: 0 45px;
			height: 65px;
			border-radius: 20px;
			font-weight: 800;
			text-transform: uppercase;
			font-size: 1rem;
			transition: 0.4s;
			flex-grow: 1;
			display: flex;
			align-items: center;
			justify-content: center;
			gap: 10px;
		}

		.btn-add-bag:hover {
			background: var(--accent-blue);
			color: #ffffff !important;
			box-shadow: 0 15px 30px rgba(76, 141, 255, 0.4);
			transform: translateY(-3px);
		}

		/* --- DESCRIPTION --- */
		.desc-section {
			background: rgba(255, 255, 255, 0.03);
			border-radius: 25px;
			padding: 0px;
			border: 1px solid var(--border);
		}

		.desc-section h4 {
			font-size: 0.9rem;
			color: var(--accent-blue);
			text-transform: uppercase;
			letter-spacing: 3px;
			margin-bottom: 20px;
		}

		.desc-content {
			font-size: 1.05rem;
			color: #9e9797ff;
			line-height: 1.8;
		}

		@media (max-width: 991px) {
			.info-panel {
				padding-left: 0;
				margin-top: 50px;
			}

			.product-stage {
				min-height: 400px;
			}
		}
	</style>
</head>

<body>
	<div class="mesh-bg"></div>

	<?php include "./layout/navbar.php"; ?>

	<section class="konten">
		<div class="container">
			<div class="row align-items-center">

				<div class="col-lg-6">
					<div class="product-stage">
						<img src="foto_produk/<?php echo $detail['foto_produk']; ?>"
							alt="<?php echo $detail['nama_produk']; ?>">
					</div>
				</div>

				<div class="col-lg-6">
					<div class="info-panel">
						<span class="category-tag">Premium Collection</span>
						<h1 class="display-title"><?php echo $detail["nama_produk"]; ?></h1>

						<div class="price-wrapper">
							<p class="price-text">Rp <?php echo number_format($detail["harga_produk"], 0, ',', '.'); ?></p>
						</div>

						<div class="mb-4">
							<p class="text-muted mb-1">Status Ketersediaan</p>
							<div class="d-flex align-items-center gap-2">
								<span class="badge bg-success rounded-pill p-2"> </span>
								<span class="fw-bold"><?php echo $detail["stok_produk"]; ?> Unit Tersedia</span>
							</div>
						</div>

						<form method="post">
							<div class="purchase-zone">
								<input type="number" name="jumlah" value="1" min="1" max="<?php echo $detail['stok_produk']; ?>"
									class="form-control input-qty-modern">
								<button class="btn btn-add-bag" name="beli">
									<i class="bi bi-bag-plus-fill"></i> Masukan Keranjang
								</button>
							</div>
						</form>

						<div class="desc-section">
							<h4>Description</h4>
							<div class="desc-content">
								<?php echo nl2br($detail["deskripsi_produk"]); ?>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>

	<?php include "./layout/footer.php"; ?>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>