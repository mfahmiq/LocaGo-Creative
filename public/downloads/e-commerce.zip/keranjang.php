<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['pelanggan'])) {
	echo "<script>alert('Anda harus login');</script>";
	echo "<script>location='login.php';</script>";
	exit();
}

if (empty($_SESSION["keranjang"]) || !isset($_SESSION["keranjang"])) {
	echo "<script>alert('Keranjang kosong, silakan belanja dulu');</script>";
	echo "<script>location='index.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
	<meta charset="UTF-8">
	<title>Keranjang | Arc`teryx Store</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

	<style>
		:root {
			--bg-deep: #030305;
			--card-glass: rgba(30, 31, 38, 0.7);
			--accent-blue: #4c8dff;
			--border: rgba(255, 255, 255, 0.1);
		}

		body {
			background-color: var(--bg-deep);
			color: #fff;
			font-family: 'Plus Jakarta Sans', sans-serif;
			min-height: 100vh;
		}

		h2,
		.brand-font {
			font-family: 'Space Grotesk', sans-serif;
		}

		.mesh-bg {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background:
				radial-gradient(at 0% 0%, rgba(76, 141, 255, 0.08) 0px, transparent 50%),
				radial-gradient(at 100% 100%, rgba(165, 75, 255, 0.08) 0px, transparent 50%);
			z-index: -1;
		}

		.konten {
			padding: 10px 0 80px;
		}

		/* --- CART CARD DESIGN --- */
		.cart-container {
			background: var(--card-glass);
			backdrop-filter: blur(15px);
			border-radius: 30px;
			border: 1px solid var(--border);
			padding: 40px;
			box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
		}

		.table {
			--bs-table-bg: transparent;
			color: #fff;
			border-color: var(--border);
		}

		.table thead th {
			border-bottom: 2px solid var(--border);
			text-transform: uppercase;
			font-size: 11px;
			letter-spacing: 2px;
			color: var(--accent-blue);
			padding-bottom: 20px;
		}

		.cart-img {
			width: 80px;
			height: 80px;
			object-fit: contain;
			background: #fff;
			border-radius: 15px;
			padding: 5px;
		}

		.product-name {
			font-weight: 700;
			font-size: 1.1rem;
			margin-bottom: 0;
		}

		.qty-badge {
			background: rgba(255, 255, 255, 0.1);
			padding: 8px 20px;
			border-radius: 12px;
			border: 1px solid var(--border);
			font-weight: 700;
		}

		/* Styling Checkbox Custom */
		.form-check-input {
			background-color: transparent;
			border: 2px solid var(--accent-blue);
			width: 20px;
			height: 20px;
			cursor: pointer;
		}

		.form-check-input:checked {
			background-color: var(--accent-blue);
			border-color: var(--accent-blue);
		}

		/* --- ACTION BUTTONS --- */
		.btn-remove {
			background: rgba(255, 59, 48, 0.1);
			color: #ff3b30;
			border: 1px solid rgba(255, 59, 48, 0.2);
			border-radius: 12px;
			padding: 8px 12px;
			transition: 0.3s;
		}

		.btn-remove:hover {
			background: #ff3b30;
			color: #fff;
			box-shadow: 0 0 15px rgba(255, 59, 48, 0.4);
		}

		.btn-continue {
			color: #aaa;
			text-decoration: none;
			font-weight: 600;
			transition: 0.3s;
			display: flex;
			align-items: center;
			gap: 8px;
		}

		.btn-continue:hover {
			color: #fff;
		}

		.btn-checkout {
			background: #fff;
			color: #000 !important;
			border: none;
			border-radius: 18px;
			padding: 15px 35px;
			font-weight: 800;
			text-transform: uppercase;
			letter-spacing: 1px;
			transition: 0.3s;
			box-shadow: 0 10px 20px rgba(255, 255, 255, 0.1);
		}

		.btn-checkout:hover {
			background: var(--accent-blue);
			color: #fff !important;
			transform: translateY(-3px);
			box-shadow: 0 10px 25px rgba(76, 141, 255, 0.4);
		}

		.total-section {
			border-top: 1px solid var(--border);
			padding-top: 30px;
			margin-top: 20px;
		}
	</style>
</head>

<body>
	<div class="mesh-bg"></div>

	<?php include "./layout/navbar.php"; ?>

	<section class="konten">
		<div class="container">
			<div class="mb-5">
				<h2 class="display-5 fw-bold mb-2">Shopping <span style="color: var(--accent-blue)">Bag</span></h2>
				<p class="text-muted">Pilih produk yang ingin Anda checkout sekarang.</p>
			</div>

			<form action="checkout.php" method="POST">
				<div class="cart-container">
					<div class="table-responsive">
						<table class="table align-middle">
							<thead>
								<tr>
									<th width="50px">Pilih</th>
									<th>Produk</th>
									<th class="text-center">Harga</th>
									<th class="text-center">Jumlah</th>
									<th class="text-center">Subtotal</th>
									<th class="text-end">Aksi</th>
								</tr>
							</thead>
							<tbody>
								<?php
								$grand_total = 0;
								foreach ($_SESSION["keranjang"] as $id_produk => $jumlah):
									$ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk'");
									$pecah = $ambil->fetch_assoc();
									$subtotal = $pecah['harga_produk'] * $jumlah;
									$grand_total += $subtotal;
								?>
									<tr>
										<td>
											<input type="checkbox" name="pilih_produk[]" value="<?php echo $id_produk; ?>" class="form-check-input" checked>
										</td>
										<td>
											<div class="d-flex align-items-center gap-3">
												<img src="foto_produk/<?php echo $pecah['foto_produk']; ?>" class="cart-img">
												<div>
													<p class="product-name"><?php echo $pecah["nama_produk"]; ?></p>
													<small class="text-muted">Original Gear</small>
												</div>
											</div>
										</td>
										<td class="text-center">Rp <?php echo number_format($pecah["harga_produk"], 0, ',', '.'); ?></td>
										<td class="text-center">
											<span class="qty-badge"><?php echo $jumlah; ?></span>
										</td>
										<td class="text-center fw-bold" style="color: var(--accent-blue)">
											Rp <?php echo number_format($subtotal, 0, ',', '.'); ?>
										</td>
										<td class="text-end">
											<a href="hapuskeranjang.php?id=<?php echo $id_produk ?>"
												class="btn btn-remove"
												onclick="return confirm('Hapus item ini dari keranjang?');">
												<i class="bi bi-trash3-fill"></i>
											</a>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>

					<div class="total-section d-flex flex-column flex-md-row justify-content-between align-items-center gap-4">
						<a href="index.php" class="btn-continue">
							<i class="bi bi-arrow-left"></i> Kembali Belanja
						</a>

						<div class="d-flex align-items-center gap-4">
							<div class="text-end">
								<p class="text-muted mb-0 small uppercase">Estimasi Total Keranjang</p>
								<h3 class="fw-bold mb-0">Rp <?php echo number_format($grand_total, 0, ',', '.'); ?></h3>
							</div>
							<button type="submit" name="checkout" class="btn btn-checkout">
								Checkout
							</button>
						</div>
					</div>
				</div>
			</form>
		</div>
	</section>

	<?php include "./layout/footer.php"; ?>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>