<?php
session_start();
include 'koneksi.php';

if (!isset($_GET['id'])) {
	echo "<script>location='riwayat.php';</script>";
	exit();
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
	<meta charset="UTF-8">
	<title>Nota Pembelian #<?= $_GET['id'] ?> | Arc`teryx Store</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

	<style>
		:root {
			--bg-deep: #030305;
			--card-glass: rgba(30, 31, 38, 0.8);
			--accent-blue: #4c8dff;
			--border: rgba(255, 255, 255, 0.1);
		}

		body {
			background-color: var(--bg-deep);
			color: #fff;
			font-family: 'Plus Jakarta Sans', sans-serif;
			min-height: 100vh;
		}

		.konten {
			padding: 12px 0 80px;
		}

		.invoice-card {
			background: var(--card-glass);
			backdrop-filter: blur(20px);
			border-radius: 30px;
			border: 1px solid var(--border);
			padding: 40px;
		}

		.table-custom thead th {
			background: rgba(255, 255, 255, 0.03);
			border: none;
			color: #888;
			font-size: 0.75rem;
			text-transform: uppercase;
		}

		.table-custom td {
			padding: 20px 10px;
			border-bottom: 1px solid var(--border);
			vertical-align: middle;
		}

		.payment-box {
			background: rgba(76, 141, 255, 0.05);
			border: 1px solid rgba(76, 141, 255, 0.2);
			border-radius: 20px;
			padding: 20px;
		}

		.text {
			color: #adaaaaff;
		}

		.text p {
			margin-bottom: 1rem;
			text-align: center;
		}


		element.style {}

		[type=button]:not(:disabled),
		[type=reset]:not(:disabled),
		[type=submit]:not(:disabled),
		button:not(:disabled) {
			cursor: pointer;
		}

		[type=button]:not(:disabled),
		[type=reset]:not(:disabled),
		[type=submit]:not(:disabled),
		button:not(:disabled) {
			cursor: pointer;
		}

		.rounded-pill {
			border-radius: var(--bs-border-radius-pill) !important;
		}

		.py-2 {
			padding-top: .5rem !important;
			padding-bottom: .5rem !important;
		}

		.px-4 {
			padding-right: 1.5rem !important;
			padding-left: 1.5rem !important;
		}

		.me-2 {
			margin-right: .5rem !important;
		}
	</style>
</head>

<body>
	<?php include "./layout/navbar.php"; ?>

	<section class="konten">
		<div class="container">
			<?php
			$ambil = $koneksi->query("SELECT * FROM pembelian JOIN pelanggan 
                ON pembelian.id_pelanggan = pelanggan.id_pelanggan 
                WHERE pembelian.id_pembelian = '$_GET[id]'");
			$detail = $ambil->fetch_assoc();
			?>

			<div class="invoice-card mx-auto" style="max-width: 1000px;">
				<div class="d-flex justify-content-between mb-5">
					<div>
						<h2 class="fw-800 mb-0 text-white">INVOICE</h2>
						<span class="text-primary fw-bold">#ORD-<?= str_pad($detail['id_pembelian'], 5, '0', STR_PAD_LEFT); ?></span>
					</div>
					<div class="text-end">
						<h4 class="fw-800 text-white mb-0">Arc`teryx Official Store </h4>
						<small class="text-muted"><?= date("d F Y", strtotime($detail['tanggal_pembelian'])); ?></small>
					</div>
				</div>

				<div class="row mb-5">
					<div class="col-md-4">
						<div class="text">
							<label class="small text-uppercase">Pelanggan</label>
						</div>
						<p class="fw-bold mb-0"><?= $detail['nama_pelanggan']; ?></p>
						<small class="text-muted"><?= $detail['telephone_pelanggan']; ?></small>
					</div>
					<div class="col-md-4">
						<div class="text">
							<label class="small text-uppercase">Pengiriman Ke</label>
						</div>
						<p class="fw-bold mb-0"><?= $detail['nama_kota']; ?></p>
						<small class="text-muted">Ongkir: Rp <?= number_format($detail['tarif']); ?></small>
					</div>
					<div class="col-md-4 text-md-end">
						<div class="text">
							<label class="small text-uppercase">Alamat Lengkap</label>
						</div>
						<p class="small"><?= $detail['alamat_pengiriman']; ?></p>
					</div>
				</div>

				<table class="table table-custom text-white mb-4">
					<thead>
						<tr>
							<th class="text-center">Item</th>
							<th class="text-center">Harga</th>
							<th class="text-center">Berat</th>
							<th class="text-center">Qty</th>
							<th class="text-center">Total</th>
							<th class="text-end">SubTotal</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$ambil = $koneksi->query("SELECT * FROM pembelian_produk WHERE id_pembelian = '$_GET[id]'");
						while ($pecah = $ambil->fetch_assoc()):
						?>
							<tr>
								<td>
									<span class="fw-600 d-block"><?= $pecah['nama']; ?></span>

								</td>
								<td class="text-center">Rp <?= number_format($pecah['harga']); ?></td>
								<td class="text-muted"><?= $pecah['berat']; ?> gr</td>
								<td class="text-center"><?= $pecah['jumlah']; ?></td>
								<td class="text-end">Rp <?= number_format($pecah['subtotal'] ?? $pecah['Subtotal']); ?></td>
								<td class="text-end fw-bold">Rp <?= number_format($detail['total_pembelian']); ?></td>
							</tr>
						<?php endwhile; ?>
					</tbody>
				</table>

				<div class="row align-items-center">
					<div class="col-md-7">
						<div class="payment-box">
							<p class="small text-muted mb-2 text-uppercase fw-bold">Instruksi Pembayaran</p>
							<h5 class="text-primary fw-800 mb-1">BNI 89695338-0237</h5>
							<p class="mb-0 small">A.n <span class="text-white">Arc`teryx Official Store</span></p>
						</div>
					</div>
					<div class="col-md-5 text-md-end mt-4 mt-md-0">
						<div class="text">
							<p class="text">Grand Total</p>
						</div>
						<h2 class="fw-800 text-primary">Rp <?= number_format($detail['total_pembelian']); ?></h2>
					</div>
				</div>
			</div>

			<div class="text-center mt-4 no-print">
				<div class="btn">
					<button onclick="window.print()" class="btn btn-outline px-4 py-2 rounded-pill me-2">
						<i class="bi bi-printer me-2"></i>Cetak Nota
					</button>
				</div>
				<a href="riwayat.php" class="btn btn-primary px-4 py-2 rounded-pill">
					Ke Riwayat Belanja <i class="bi bi-arrow-right ms-2"></i>
				</a>
			</div>
		</div>
	</section>

	<?php include "./layout/footer.php"; ?>
</body>

</html>