<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['pelanggan'])) {
	echo "<script>alert('Anda harus login');</script>";
	echo "<script>location='login.php';</script>";
	exit();
}

// Logika Tambahan: Cek apakah ada produk yang dipilih dari keranjang
if (!isset($_POST['pilih_produk']) || empty($_POST['pilih_produk'])) {
	echo "<script>alert('Silakan pilih minimal satu produk untuk di-checkout');</script>";
	echo "<script>location='keranjang.php';</script>";
	exit();
}

// Ambil ID produk yang dicentang
$produk_pilihan = $_POST['pilih_produk'];
?>

<!DOCTYPE html>
<html lang="id">

<head>
	<meta charset="UTF-8">
	<title>Checkout | Arc`teryx Store</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

	<style>
		:root {
			--bg-deep: #030305;
			--card-glass: rgba(30, 31, 38, 0.8);
			--accent-blue: #4c8dff;
			--border: rgba(255, 255, 255, 0.1);
		}

		body {
			background-color: var(--bg-deep);
			color: #fff;
			font-family: 'Plus Jakarta Sans', sans-serif;
			display: flex;
			flex-direction: column;
			min-height: 100vh;
			margin: 0;
		}

		.mesh-bg {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background: radial-gradient(at 0% 0%, rgba(76, 141, 255, 0.05) 0px, transparent 50%),
				radial-gradient(at 100% 100%, rgba(165, 75, 255, 0.05) 0px, transparent 50%);
			z-index: -1;
		}

		.konten {
			padding-top: 10px;
			padding-bottom: 100px;
			flex: 1;
		}

		.checkout-card {
			background: var(--card-glass);
			backdrop-filter: blur(20px);
			border-radius: 24px;
			border: 1px solid var(--border);
			padding: 40px;
			height: 100%;
			box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
		}

		.form-label {
			font-size: 0.85rem;
			font-weight: 600;
			color: #adaaaaff;
			text-transform: uppercase;
			letter-spacing: 1px;
			margin-bottom: 8px;
			display: block;
		}

		.form-control,
		.form-select {
			background: rgba(0, 0, 0, 0.3) !important;
			border: 1px solid var(--border) !important;
			color: #fff !important;
			border-radius: 12px;
			padding: 12px 15px;
			margin-bottom: 15px;
		}

		.form-select option {
			background-color: #1a1d24;
			color: #fff;
		}

		.summary-item {
			display: flex;
			justify-content: space-between;
			padding: 15px 0;
			border-bottom: 1px dashed rgba(255, 255, 255, 0.1);
		}

		.btn-pay {
			background: #fff;
			color: #000 !important;
			border: none;
			border-radius: 16px;
			padding: 18px;
			font-weight: 800;
			text-transform: uppercase;
			width: 100%;
			margin-top: 25px;
			transition: 0.3s ease;
		}

		.btn-pay:hover {
			background: var(--accent-blue);
			color: #fff !important;
			transform: translateY(-3px);
			box-shadow: 0 10px 25px rgba(76, 141, 255, 0.4);
		}
	</style>
</head>

<body>
	<div class="mesh-bg"></div>
	<?php include "./layout/navbar.php"; ?>

	<section class="konten">
		<div class="container">
			<div class="mb-5">
				<h2 class="fw-bold mb-1"><i class="bi bi-shield-check text-primary me-2"></i>Secure Checkout</h2>
				<p class="text-muted">Hanya produk yang Anda pilih yang akan diproses.</p>
			</div>

			<form method="post">
				<?php foreach ($produk_pilihan as $id): ?>
					<input type="hidden" name="pilih_produk[]" value="<?= $id ?>">
				<?php endforeach; ?>

				<div class="row g-4">
					<div class="col-lg-7">
						<div class="checkout-card">
							<h5 class="mb-4 fw-bold text-primary">1. Informasi Pengiriman</h5>
							<div class="row">
								<div class="col-md-6">
									<label class="form-label">Nama Penerima</label>
									<input type="text" readonly value="<?= $_SESSION["pelanggan"]['nama_pelanggan'] ?>" class="form-control">
								</div>
								<div class="col-md-6">
									<label class="form-label">Nomor Telepon</label>
									<input type="text" readonly value="<?= $_SESSION["pelanggan"]['telephone_pelanggan'] ?>" class="form-control">
								</div>
							</div>

							<label class="form-label">Pilih Ongkos Kirim</label>
							<select class="form-select" name="id_ongkir" required>
								<option value="">-- Pilih Kota Tujuan --</option>
								<?php
								$ongkir = $koneksi->query("SELECT * FROM ongkir");
								while ($perongkir = $ongkir->fetch_assoc()):
								?>
									<option value="<?= $perongkir["id_ongkir"] ?>">
										<?= $perongkir['nama_kota'] ?> — Rp <?= number_format($perongkir['tarif'], 0, ',', '.') ?>
									</option>
								<?php endwhile; ?>
							</select>

							<label class="form-label">Alamat Lengkap</label>
							<textarea class="form-control" name="alamat_pengiriman" rows="4" placeholder="Alamat lengkap tujuan pengiriman..." required></textarea>
						</div>
					</div>

					<div class="col-lg-5">
						<div class="checkout-card">
							<h5 class="mb-4 fw-bold text-primary">2. Ringkasan Pesanan Pilihan</h5>

							<?php
							$totalbelanja = 0;
							// Iterasi HANYA pada produk yang dipilih
							foreach ($produk_pilihan as $id_produk):
								$jumlah = $_SESSION["keranjang"][$id_produk];
								$ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk'");
								$pecah = $ambil->fetch_assoc();
								$subtotal = $pecah['harga_produk'] * $jumlah;
								$totalbelanja += $subtotal;
							?>
								<div class="summary-item">
									<div class="text">
										<p class="mb-0 fw-bold text-white"><?= $pecah["nama_produk"] ?></p>
										<small class="text-muted"><?= $jumlah ?> x Rp <?= number_format($pecah['harga_produk'], 0, ',', '.') ?></small>
									</div>
									<span class="fw-bold">Rp <?= number_format($subtotal, 0, ',', '.') ?></span>
								</div>
							<?php endforeach; ?>

							<div class="mt-4 p-3 rounded-4" style="background: rgba(255,255,255,0.03);">
								<div class="d-flex justify-content-between mb-2">
									<span class="text-muted">Subtotal Belanja</span>
									<span class="fw-bold">Rp <?= number_format($totalbelanja, 0, ',', '.') ?></span>
								</div>
								<div class="d-flex justify-content-between mb-1">
									<span class="text-muted">Biaya Pengiriman</span>
									<span class="text-info small">Dihitung otomatis</span>
								</div>
								<hr class="my-3 opacity-10">
								<div class="d-flex justify-content-between align-items-center">
									<h4 class="mb-0 fw-bold">Total</h4>
									<h3 class="mb-0 fw-bold text-primary">Rp <?= number_format($totalbelanja, 0, ',', '.') ?></h3>
								</div>
							</div>

							<button class="btn btn-pay" name="checkout_final">
								Konfirmasi & Bayar <i class="bi bi-arrow-right ms-2"></i>
							</button>
						</div>
					</div>
				</div>
			</form>

			<?php
			if (isset($_POST["checkout_final"])) {
				$id_pelanggan = $_SESSION["pelanggan"]["id_pelanggan"];
				$id_ongkir = $_POST["id_ongkir"];
				$tanggal_pembelian = date("Y-m-d");
				$alamat_pengiriman = $koneksi->real_escape_string($_POST["alamat_pengiriman"]);

				$ambil = $koneksi->query("SELECT * FROM ongkir WHERE id_ongkir='$id_ongkir'");
				$ongkir = $ambil->fetch_assoc();
				$tarif = $ongkir['tarif'];
				$nama_kota = $ongkir['nama_kota'];

				$total_pembelian = $totalbelanja + $tarif;

				// 1. Simpan ke tabel pembelian
				$koneksi->query("INSERT INTO pembelian 
                    (id_pelanggan, id_ongkir, tanggal_pembelian, total_pembelian, nama_kota, tarif, alamat_pengiriman)
                    VALUES ('$id_pelanggan','$id_ongkir','$tanggal_pembelian','$total_pembelian','$nama_kota','$tarif','$alamat_pengiriman')");

				$id_pembelian_barusan = $koneksi->insert_id;

				// 2. Simpan ke tabel pembelian_produk & Update Stok
				foreach ($produk_pilihan as $id_produk) {
					$jumlah = $_SESSION["keranjang"][$id_produk];
					$ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk'");
					$produk = $ambil->fetch_assoc();

					$nama = $koneksi->real_escape_string($produk['nama_produk']);
					$harga = $produk['harga_produk'];
					$berat = $produk['berat_produk'];
					$subberat = $berat * $jumlah;
					$subtotal = $harga * $jumlah;

					$koneksi->query("INSERT INTO pembelian_produk 
                        (id_pembelian,id_produk,nama,harga,berat,subberat,jumlah,subtotal)
                        VALUES ('$id_pembelian_barusan','$id_produk','$nama','$harga','$berat','$subberat','$jumlah','$subtotal')");

					$koneksi->query("UPDATE produk SET stok_produk = stok_produk - $jumlah WHERE id_produk='$id_produk'");

					// 3. Hapus hanya produk yang sudah dibeli dari keranjang session
					unset($_SESSION["keranjang"][$id_produk]);
				}

				echo "<script>alert('Pembelian Berhasil!');</script>";
				echo "<script>location='nota.php?id=$id_pembelian_barusan';</script>";
			}
			?>
		</div>
	</section>

	<?php include "./layout/footer.php"; ?>
</body>

</html>