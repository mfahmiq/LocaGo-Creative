<h2>Data Pelanggan</h2>

<table class="table table-bordered text-center">
	<thead>
		<tr>
			<th class="text-center">No</th>
			<th class="text-center">Nama</th>
			<th class="text-center">Email</th>
			<th class="text-center">Telephone</th>
		</tr>
	</thead>
	<tbody>
		<?php $nomor = 1; ?>
		<?php $ambil = $koneksi->query("SELECT * FROM pelanggan"); ?>
		<?php while ($pecah = $ambil->fetch_assoc()) { ?>
			<tr>
				<td><?php echo $nomor; ?></td>
				<td><?php echo $pecah['nama_pelanggan']; ?> </td>
				<td><?php echo $pecah['email_pelanggan']; ?> </td>
				<td><?php echo $pecah['telephone_pelanggan']; ?></td>
			</tr>
			<?php $nomor++; ?>
		<?php } ?>

	</tbody>
</table>