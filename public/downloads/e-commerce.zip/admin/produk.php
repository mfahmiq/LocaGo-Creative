<h2>Data Produk</h2>
<a href="index.php?halaman=tambahproduk" class="btn btn-primary mb-10">Tambah Data</a>

<table class="table table-bordered text-center">
	<thead>
		<tr>
			<th class="text-center">no</th>
			<th class="text-center">nama</th>
			<th class="text-center">harga</th>
			<th class="text-center">berat</th>
			<th class="text-center">stok</th>
			<th class="text-center">foto</th>
			<th class="text-center">aksi</th>
		</tr>
	</thead>
	<tbody>
		<?php $nomor = 1; ?>
		<?php $ambil = $koneksi->query("SELECT * FROM produk"); ?>
		<?php while ($pecah = $ambil->fetch_assoc()) { ?>
			<tr>
				<td><?php echo $nomor; ?></td>
				<td><?php echo $pecah['nama_produk']; ?> </td>
				<td><?php echo $pecah['harga_produk']; ?> </td>
				<td><?php echo $pecah['berat_produk']; ?></td>
				<td><?php echo $pecah['stok_produk']; ?></td>
				<td>
					<img src="../foto_produk/<?php echo $pecah['foto_produk']; ?>" width="100">
				</td>
				<td>
					<a href="index.php?halaman=hapusproduk&id=<?php echo $pecah['id_produk']; ?>"
						class="btn btn-danger"
						onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?');">
						Hapus
					</a>

					<a href="index.php?halaman=ubahproduk&id=<?php echo $pecah['id_produk']; ?>" class="btn btn-warning">ubah</a>
				</td>
			</tr>
			<?php $nomor++; ?>
		<?php } ?>

	</tbody>
</table>