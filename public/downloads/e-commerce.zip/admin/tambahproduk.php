<h2>Tambah Data Produk</h2>

<form method="post" enctype="Multipart/form-data">
	<div class="form-group">
		<label>nama</label>
		<input type="text" class="form-control" name="nama">
	</div>
	<div class="form-group">
		<label>Harga (Rp)</label>
		<input type="number" class="form-control" name="harga">
	</div>
	<div class="form-group">
		<label>Berat (Gr)</label>
		<input type="number" class="form-control" name="berat">
	</div>
	<div class="form-group">
		<label>Stok</label>
		<input type="number" class="form-control" name="stok">
	</div>
	<div class="form-group">
		<label>Deskripsi</label>
		<textarea class="form-control" name="deskripsi" rows="10"></textarea>
	</div>
	<div class="form-group">
		<label>Foto</label>
		<input type="file" class="btn btn-primary" name="foto">
	</div>
	<button class="btn btn-primary" name="save">Simpan</button>
</form>
<?php
if (isset($_POST['save'])) {
	$nama_file = $_FILES['foto']['name'];
	$lokasi_file = $_FILES['foto']['tmp_name'];
	move_uploaded_file($lokasi_file, "../foto_produk/" . $nama_file);

	// Ambil nilai dari POST
	$nama_produk = $_POST['nama'];
	$harga_produk = $_POST['harga'];
	$berat_produk = $_POST['berat'];
	$stok_produk = $_POST['stok'];
	$deskripsi_produk = $_POST['deskripsi'];

	// Gunakan prepared statement
	$stmt = $koneksi->prepare("INSERT INTO produk (nama_produk, harga_produk, berat_produk, stok_produk, foto_produk, deskripsi_produk)
                               VALUES (?, ?, ?, ?, ?, ?)");

	if (!$stmt) {
		die("Prepare failed: " . $koneksi->error);
	}

	$stmt->bind_param("sdiiss", $nama_produk, $harga_produk, $berat_produk, $stok_produk, $nama_file, $deskripsi_produk);


	if ($stmt->execute()) {
		echo "<div class='alert alert-info'>Data Tersimpan</div>";
		echo "<meta http-equiv='refresh' content='1;url=index.php?halaman=produk'>";
	} else {
		echo "<div class='alert alert-danger'>Gagal menyimpan data: " . $stmt->error . "</div>";
	}

	$stmt->close();
}
?>