﻿<?php
session_start(); // penting!
$koneksi = new mysqli("localhost", "root", "", "toko_ecommerce");

if (!isset($_SESSION['admin'])) {
    echo "<script>alert('Anda harus login');</script>";
    echo "<script>location='login.php';</script>";
    exit();
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard Admin</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/custom.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <style>
        body {
            background-color: #f4f4f4;
        }

        .navbar-cls-top {
            background-color: #2c3e50;
        }

        .navbar-brand {
            color: #fff !important;
        }

        .sidebar-collapse .nav>li>a {
            color: #fff;
            background: #34495e;
            margin-bottom: 2px;
        }

        .sidebar-collapse .nav>li>a:hover {
            background: #1abc9c;
        }

        .text-center img {
            border-radius: 50%;
            margin-top: 10px;
        }

        .page-header {
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div id="wrapper">
        <!-- Top Navbar -->
        <nav class="navbar navbar-default navbar-cls-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <a class="navbar-brand" href="index.php">Admin Panel</a>
            </div>
            <div style="color: white; padding: 15px 50px 5px 50px; float: right; font-size: 16px;">
                Last access : Desember 2025 &nbsp;
            </div>
        </nav>

        <!-- Sidebar Navigation -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li class="text-center">
                        <img src="assets/img/find_user.png" class="user-image img-responsive" />
                        <h5 style="color: #fff;">Administrator</h5>
                    </li>
                    <li><a href="index.php"><i class="fa fa-home fa-fw"></i> Home</a></li>
                    <li><a href="index.php?halaman=produk"><i class="fa fa-tags fa-fw"></i> Produk</a></li>
                    <li><a href="index.php?halaman=pembelian"><i class="fa fa-shopping-cart fa-fw"></i> Pembelian</a></li>
                    <li><a href="index.php?halaman=pelanggan"><i class="fa fa-users fa-fw"></i> Pelanggan</a></li>
                    <li><a href="index.php?halaman=logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a></li>
                </ul>
            </div>
        </nav>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="page-header">Dashboard <small>Selamat datang, Admin!</small></h2>
                    </div>
                </div>

                <?php
                if (isset($_GET['halaman'])) {
                    $halaman = $_GET['halaman'];
                    switch ($halaman) {
                        case 'produk':
                            include 'produk.php';
                            break;
                        case 'pembelian':
                            include 'pembelian.php';
                            break;
                        case 'pelanggan':
                            include 'pelanggan.php';
                            break;
                        case 'detail':
                            include 'detail.php';
                            break;
                        case 'tambahproduk':
                            include 'tambahproduk.php';
                            break;
                        case 'hapusproduk':
                            include 'hapusproduk.php';
                            break;
                        case 'ubahproduk':
                            include 'ubahproduk.php';
                            break;
                        case 'logout':
                            include 'logout.php';
                            break;
                        case 'pembayaran':
                            include 'pembayaran.php';
                            break;
                        default:
                            include 'home.php';
                            break;
                    }
                } else {
                    include 'home.php';
                }
                ?>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.metisMenu.js"></script>
    <script src="assets/js/custom.js"></script>
</body>

</html>