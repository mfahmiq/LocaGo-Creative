<h2>Ubah Produk</h2>
<?php
$ambil = $koneksi->query("SELECT * FROM Produk WHERE id_produk='$_GET[id]'");
$pecah = $ambil->fetch_assoc();

//echo "<pre>";
//print_r($pecah);
//echo "</pre>";
?>
<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label>Nama Produk</label>
		<input type="text" name="nama" class="form-control" value="<?php echo $pecah['nama_produk']; ?> ">
	</div>
	<div class="form-group">
		<label>Harga Rp</label>
		<input type="number" class="form-control" name="harga" value="<?php echo $pecah['harga_produk']; ?>">
	</div>
	<div class="form-group">
		<label>Stock</label>
		<input type="number" class="form-control" name="stok" value="<?php echo $pecah['stok_produk']; ?>">
	</div>
	<div class="form-group">
		<label>Berat (Gr)</label>
		<input type="number" class="form-control" name="berat" value="<?php echo $pecah['berat_produk']; ?>">
	</div>
	<div class="form-group">
		<img src="../foto_produk/<?php echo $pecah['foto_produk'] ?>" width="200">
	</div>
	<div class="form-group">
		<label>Ganti Foto</label>
		<input type="file" name="foto" class="form-control">
	</div>
	<div class="form-group">
		<label>Deskripsi</label>
		<textarea name="deskripsi" class="form-control" rows="10">
			<?php echo $pecah['deskripsi_produk']; ?>
		</textarea>
	</div>
	<button class="btn btn-primary" name="ubah">Ubah</button>
</form>

<?php
if (isset($_POST['ubah'])) {
	$namafoto = $_FILES['foto']['name'];
	$lokasifoto = $_FILES['foto']['tmp_name'];

	// Ambil nilai form
	$nama_produk = $_POST['nama'];
	$harga_produk = $_POST['harga'];
	$stok_produk = $_POST['stok'];
	$berat_produk = $_POST['berat'];
	$deskripsi_produk = $_POST['deskripsi'];
	$id_produk = $_GET['id'];

	if (!empty($lokasifoto)) {
		move_uploaded_file($lokasifoto, "../foto_produk/$namafoto");

		// Query update dengan foto baru
		$stmt = $koneksi->prepare("UPDATE produk SET nama_produk=?, harga_produk=?, stok_produk=?, berat_produk=?, foto_produk=?, deskripsi_produk=? WHERE id_produk=?");
		$stmt->bind_param("sdissi", $nama_produk, $harga_produk, $stok_produk, $berat_produk, $namafoto, $deskripsi_produk, $id_produk);
	} else {
		// Query update tanpa ubah foto
		$stmt = $koneksi->prepare("UPDATE produk SET nama_produk=?, harga_produk=?, stok_produk=?, berat_produk=?, deskripsi_produk=? WHERE id_produk=?");
		$stmt->bind_param("sdissi", $nama_produk, $harga_produk, $stok_produk, $berat_produk, $deskripsi_produk, $id_produk);
	}

	if ($stmt->execute()) {
		echo "<script>alert('Data produk telah diubah');</script>";
		echo "<script>location='index.php?halaman=produk';</script>";
	} else {
		echo "<div class='alert alert-danger'>Gagal mengubah data: " . $stmt->error . "</div>";
	}

	$stmt->close();
}
?>