<?php
// skrip Koneksi
session_start();
$koneksi = new mysqli("localhost", "root", "", "toko_ecommerce");

?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin</title>
  <link href="assets/css/bootstrap.css" rel="stylesheet" />
  <link href="assets/css/font-awesome.css" rel="stylesheet" />
  <link href="assets/css/custom.css" rel="stylesheet" />
  <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

</head>

<body>
  <div class="container">
    <div class="row text-center ">
      <div class="col-md-12">
        <br /><br />
        <h2> Admin : Login</h2>

        <h5>( Silahkan Login Untuk Masuk Panel Admin )</h5>
        <br />
      </div>
    </div>
    <div class="row ">

      <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
        <div class="panel panel-default">
          <div class="panel-heading">
            <strong> Enter Details To Login </strong>
          </div>
          <div class="panel-body">
            <form action="" method="post">
              <br />
              <div class="form-group input-group">
                <span class="input-group-addon"><i class="fa fa-tag"></i></span>
                <input type="username" class="form-control" name="user" placeholder="username" required />
              </div>
              <div class="form-group input-group">
                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                <input type="password" class="form-control" name="pass" placeholder="password" required />
              </div>
              <div class="form-group">
                <label class="checkbox-inline">
                  <input type="checkbox" /> Remember me
                </label>
                <span class="pull-right">
                  <a href="#">Forget password ? </a>
                </span>
              </div>

              <button class="btn btn-primary" name="login">Login</button>
              <hr />
              Not register ? <a href="registeration.html">click here </a>
            </form>
            <?php if (isset($_POST['login'])) {
              $user = mysqli_real_escape_string($koneksi, $_POST['user']);
              $pass = mysqli_real_escape_string($koneksi, $_POST['pass']);
              $ambil = $koneksi->query("SELECT * FROM admin WHERE username='$user' AND password='$pass'");
              $yangcocok = mysqli_num_rows($ambil);
              if ($yangcocok == 1) {
                $_SESSION['admin'] = $ambil->fetch_assoc();
                echo "<div class='alert alert-info'>Login berhasil</div>";
                echo "<meta http-equiv='refresh' content='1;url=index.php?'>";
              } else {
                echo "<div class='alert alert-danger'>Login Gagal</div>";
                echo "<meta http-equiv='refresh' content='1;url=login.php?'>";
              }
            } ?>

          </div>

        </div>
      </div>


    </div>
  </div>


  <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
  <!-- JQUERY SCRIPTS -->
  <script src="assets/js/jquery-1.10.2.js"></script>
  <!-- BOOTSTRAP SCRIPTS -->
  <script src="assets/js/bootstrap.min.js"></script>
  <!-- METISMENU SCRIPTS -->
  <script src="assets/js/jquery.metisMenu.js"></script>
  <!-- CUSTOM SCRIPTS -->
  <script src="assets/js/custom.js"></script>

</body>

</html>