# E-Commerce Jaket Outdoor Arc'Teryx

Sebuah aplikasi web e-commerce yang didedikasikan khusus untuk penjualan produk jaket outdoor merek Arc'Teryx. Proyek ini dibangun dari awal menggunakan pemrograman PHP Native dan database MySQL untuk menunjukkan konsep dasar pengembangan web dan manajemen database.
project dibuat sejak di Sekolah Menengah Kejuruan khususnya jurusan RPL semasa kelas XI

## 📸 Screenshots

<!-- Ganti link gambar di bawah ini dengan file screenshot Anda -->

![Halaman Login](screenshots/halaman_login.png)
![Halaman Utama](screenshots/halaman_utama.png)
![Halaman Admin CRUD](screenshots/halaman_admin.png)

## 🚀 Fitur Utama

- **Katalog Produk Khusus:** Berfokus hanya pada produk jaket outdoor Arc'Teryx.
- **Keranjang Belanja:** Fungsi dasar e-commerce untuk memilih dan memesan jaket.
- **Halaman Admin (CRUD):** Panel khusus admin untuk **C**reate (tambah), **R**ead (lihat), **U**pdate (ubah), dan **D**elete (hapus) data produk, stok, serta kategori jaket.
- **Manajemen Database:** Struktur database yang rapi untuk menangani varian ukuran, warna, dan harga produk.

## 🛠️ Teknologi yang Digunakan

- **Backend:** PHP (Native)
- **Database:** MySQL
- **Frontend:** HTML5, CSS, JavaScript
- **Framework:** Bootstrap5

## ⚙️ Cara Instalasi

1. Clone repositori ini ke komputer Anda:
   ```bash
   git clone https://github.com
   ```
2. Pindahkan folder proyek ke direktori server lokal Anda (contoh: folder `htdocs` jika menggunakan XAMPP).
3. Buat database baru di phpMyAdmin (menjadi `toko_ecommerce`).
4. Import file database `.sql` yang tersedia di dalam proyek ini ke database baru tersebut.
5. Sesuaikan konfigurasi koneksi database pada file koneksi Anda (misal: `koneksi.php` atau `config.php`).
6. Buka browser dan akses proyek melalui url: `http://localhost/nama-folder-proyek`.
