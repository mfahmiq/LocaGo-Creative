<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION["pelanggan"]) || empty($_SESSION["pelanggan"])) {
	echo "<script>alert('Silakan login terlebih dahulu');</script>";
	echo "<script>location='login.php';</script>";
	exit();
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
	<meta charset="UTF-8">
	<title>Riwayat Belanja | Arc`teryx Store</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

	<style>
		:root {
			--bg-deep: #030305;
			--card-glass: rgba(30, 31, 38, 0.8);
			--accent-blue: #4c8dff;
			--border: rgba(255, 255, 255, 0.1);
		}

		body {
			background-color: var(--bg-deep);
			color: #fff;
			font-family: 'Plus Jakarta Sans', sans-serif;
			display: flex;
			flex-direction: column;
			min-height: 100vh;
		}

		.mesh-bg {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background:
				radial-gradient(at 0% 0%, rgba(76, 141, 255, 0.05) 0px, transparent 50%),
				radial-gradient(at 100% 100%, rgba(165, 75, 255, 0.05) 0px, transparent 50%);
			z-index: -1;
		}

		.riwayat {
			flex: 1;
			padding: 12px 0 80px;
		}

		.history-card {
			background: var(--card-glass);
			backdrop-filter: blur(20px);
			border-radius: 24px;
			border: 1px solid var(--border);
			padding: 30px;
			box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
		}

		.table-custom {
			border-collapse: separate;
			border-spacing: 0 12px;
		}

		.table-custom thead th {
			background: transparent;
			border: none;
			color: #888;
			font-size: 0.8rem;
			text-transform: uppercase;
			letter-spacing: 1px;
			padding: 15px;
		}

		.table-custom tbody tr {
			background: rgba(255, 255, 255, 0.03);
			transition: 0.3s;
		}

		.table-custom tbody tr:hover {
			background: rgba(255, 255, 255, 0.06);
			transform: scale(1.005);
		}

		.table-custom td {
			padding: 20px 15px;
			border: none;
			vertical-align: middle;
		}

		.table-custom tr td:first-child {
			border-radius: 15px 0 0 15px;
		}

		.table-custom tr td:last-child {
			border-radius: 0 15px 15px 0;
		}

		/* Status Badge Logic */
		.badge-status {
			padding: 6px 14px;
			border-radius: 50px;
			font-size: 11px;
			font-weight: 700;
			text-transform: uppercase;
		}

		.status-pending {
			background: rgba(255, 193, 7, 0.1);
			color: #ffc107;
			border: 1px solid rgba(255, 193, 7, 0.2);
		}

		.status-success {
			background: rgba(40, 167, 69, 0.1);
			color: #28a745;
			border: 1px solid rgba(40, 167, 69, 0.2);
		}

		.status-shipped {
			background: rgba(76, 141, 255, 0.1);
			color: #4c8dff;
			border: 1px solid rgba(76, 141, 255, 0.2);
		}

		.btn-action {
			border-radius: 10px;
			padding: 8px 16px;
			font-size: 0.85rem;
			font-weight: 600;
			transition: 0.3s;
		}

		.text-gradient {
			background: linear-gradient(90deg, #4c8dff, #9333ea);
			-webkit-background-clip: text;
			-webkit-text-fill-color: transparent;
		}
	</style>
</head>

<body>
	<div class="mesh-bg"></div>
	<?php include "./layout/navbar.php"; ?>

	<section class="riwayat">
		<div class="container">
			<div class="mb-5">
				<h2 class="fw-800 mb-1">Riwayat <span class="text-gradient">Belanja</span></h2>
				<p class="text-muted">Halo, <?= $_SESSION["pelanggan"]["nama_pelanggan"]; ?>. Pantau status pesanan Anda di sini.</p>
			</div>

			<div class="history-card">
				<div class="table-responsive">
					<table class="table table-custom text-white">
						<thead>
							<tr>
								<th class="text-center">ID</th>
								<th>Tanggal Transaksi</th>
								<th class="text-center">Status Pesanan</th>
								<th class="text-center">Total Pembayaran</th>
								<th class="text-center">Aksi</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$id_pelanggan = $_SESSION["pelanggan"]['id_pelanggan'];
							$ambil = $koneksi->query("SELECT * FROM pembelian WHERE id_pelanggan='$id_pelanggan' ORDER BY tanggal_pembelian DESC, id_pembelian DESC");

							if ($ambil->num_rows == 0): ?>
								<tr>
									<td colspan="5" class="text-center py-5">
										<i class="bi bi-cart-x fs-1 text-muted d-block mb-3"></i>
										<p class="text-muted">Belum ada riwayat transaksi.</p>
										<a href="index.php" class="btn btn-primary rounded-pill px-4">Mulai Belanja</a>
									</td>
								</tr>
							<?php endif;

							while ($pecah = $ambil->fetch_assoc()):
								$tanggal = date("d M Y", strtotime($pecah["tanggal_pembelian"]));

								// Penentuan warna badge berdasarkan status
								$status_raw = strtolower($pecah["status_pembelian"]);
								$status_class = "status-pending"; // default
								if ($status_raw == 'sudah kirim' || $status_raw == 'shipped') $status_class = "status-shipped";
								if ($status_raw == 'lunas' || $status_raw == 'selesai') $status_class = "status-success";

								$status_text = !empty($pecah["status_pembelian"]) ? $pecah["status_pembelian"] : "Menunggu Pembayaran";
								$total = number_format($pecah["total_pembelian"], 0, ',', '.');
								$resi = $pecah['resi_pengiriman'];
							?>
								<tr>
									<td class="text-center text-muted">#<?= $pecah["id_pembelian"] ?></td>
									<td>
										<span class="fw-600"><?= $tanggal ?></span>
									</td>
									<td class="text-center">
										<span class="badge-status <?= $status_class ?>"><?= $status_text ?></span>
										<?php if (!empty($resi)): ?>
											<div class="small mt-2" style="color: #4c8dff;">
												<i class="bi bi-truck me-1"></i> <?= $resi ?>
											</div>
										<?php endif; ?>
									</td>
									<td class="text-center fw-800">
										Rp <?= $total ?>
									</td>
									<td class="text-center">
										<div class="d-flex justify-content-center gap-2">
											<a href="nota.php?id=<?= $pecah["id_pembelian"]; ?>"
												class="btn btn-outline btn-action">
												<i class="bi bi-file-earmark-text me-1"></i> Nota
											</a>

											<?php if ($status_raw == 'pending' || empty($status_raw) || $status_raw == 'menunggu pembayaran'): ?>
												<a href="pembayaran.php?id=<?= $pecah["id_pembelian"]; ?>"
													class="btn btn-primary btn-action">
													<i class="bi bi-credit-card me-1"></i> Bayar
												</a>
											<?php else: ?>
												<a href="lihat_pembayaran.php?id=<?= $pecah["id_pembelian"]; ?>"
													class="btn btn-success btn-action">
													<i class="bi bi-eye me-1"></i> Bukti
												</a>
											<?php endif; ?>
										</div>
									</td>
								</tr>
							<?php endwhile; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</section>

	<?php include "./layout/footer.php"; ?>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>