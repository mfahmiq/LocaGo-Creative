<?php
session_start();
include 'koneksi.php';

$id_pembelian = $_GET["id"];

// Ambil data pembayaran bergabung dengan tabel pembelian
$ambil = $koneksi->query("SELECT * FROM pembayaran 
    LEFT JOIN pembelian ON pembayaran.id_pembelian = pembelian.id_pembelian 
    WHERE pembayaran.id_pembelian = '$id_pembelian'");
$detbay = $ambil->fetch_assoc();

// Jika data pembayaran belum ada (misal diakses paksa lewat URL)
if (empty($detbay)) {
    echo "<script>alert('Belum ada data pembayaran untuk pesanan ini');</script>";
    echo "<script>location='riwayat.php';</script>";
    exit();
}

// Proteksi: Pastikan hanya pemilik pesanan yang bisa melihat
if ($_SESSION["pelanggan"]["id_pelanggan"] !== $detbay["id_pelanggan"]) {
    echo "<script>alert('Akses tidak diizinkan');</script>";
    echo "<script>location='riwayat.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Bukti Pembayaran #<?= $id_pembelian ?> | Arc`teryx Store</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        :root {
            --bg-deep: #030305;
            --card-glass: rgba(30, 31, 38, 0.8);
            --accent-blue: #4c8dff;
            --border: rgba(255, 255, 255, 0.1);
        }

        body {
            background-color: var(--bg-deep);
            color: #fff;
            font-family: 'Plus Jakarta Sans', sans-serif;
            min-height: 100vh;
        }

        .mesh-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background:
                radial-gradient(at 0% 0%, rgba(76, 141, 255, 0.05) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(165, 75, 255, 0.05) 0px, transparent 50%);
            z-index: -1;
        }

        .konten {
            padding: 12px 0 80px;
        }

        .card-glass {
            background: var(--card-glass);
            backdrop-filter: blur(20px);
            border-radius: 24px;
            border: 1px solid var(--border);
            overflow: hidden;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5);
        }

        .info-label {
            font-size: 0.75rem;
            color: #888;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }

        .info-value {
            font-weight: 700;
            color: #fff;
            margin-bottom: 20px;
        }

        .img-preview {
            width: 100%;
            border-radius: 15px;
            border: 1px solid var(--border);
            cursor: zoom-in;
            transition: 0.3s;
        }

        .img-preview:hover {
            transform: scale(1.02);
            border-color: var(--accent-blue);
        }

        .status-pill {
            display: inline-block;
            padding: 8px 20px;
            border-radius: 50px;
            background: rgba(76, 141, 255, 0.1);
            color: var(--accent-blue);
            font-weight: 700;
            font-size: 0.8rem;
            border: 1px solid rgba(76, 141, 255, 0.2);
        }

        .info-label {
            color: #adaaaaff;
        }
    </style>
</head>

<body>
    <div class="mesh-bg"></div>
    <?php include "./layout/navbar.php"; ?>

    <section class="konten">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="card-glass">
                        <div class="row g-0">
                            <div class="col-md-5 p-5 border-end border-secondary border-opacity-25">
                                <div class="mb-4">
                                    <a href="riwayat.php" class="text-decoration-none small text-primary">
                                        <i class="bi bi-arrow-left me-2"></i>Kembali ke Riwayat
                                    </a>
                                </div>
                                <h3 class="fw-800 mb-4">Detail Pembayaran</h3>

                                <div class="info-label">Nama Penyetor</div>
                                <div class="info-value h5"><?= $detbay["nama"] ?></div>

                                <div class="info-label">Bank</div>
                                <div class="info-value h5"><?= $detbay["bank"] ?></div>

                                <div class="info-label">Tanggal Transfer</div>
                                <div class="info-value h5"><?= date("d F Y", strtotime($detbay["tanggal"])) ?></div>

                                <div class="info-label">Jumlah Dibayarkan</div>
                                <div class="info-value h4 text-primary fw-800">Rp <?= number_format($detbay["jumlah"]) ?></div>

                                <hr class="my-4 border-secondary opacity-25">

                                <div class="info-label mb-2">Status Saat Ini</div>
                                <div class="status-pill">
                                    <i class="bi bi-patch-check-fill me-2"></i><?= strtoupper($detbay["status_pembelian"]) ?>
                                </div>
                            </div>

                            <div class="col-md-7 p-5 bg-black bg-opacity-25">
                                <div class="text-center">
                                    <p class="info-label mb-3">Bukti Transfer (Digital Receipt)</p>
                                    <img src="bukti_pembayaran/<?= $detbay["bukti"] ?>"
                                        alt="Bukti Transfer"
                                        class="img-preview shadow-lg"
                                        data-bs-toggle="modal"
                                        data-bs-target="#imageModal">
                                    <p class="text-muted small mt-3">
                                        <i class="bi bi-zoom-in me-1"></i> Klik gambar untuk memperbesar
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content bg-transparent border-0">
                <div class="modal-body p-0">
                    <img src="bukti_pembayaran/<?= $detbay["bukti"] ?>" class="w-100 rounded-3">
                </div>
            </div>
        </div>
    </div>

    <?php include "./layout/footer.php"; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>