<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION["pelanggan"]) || empty($_SESSION["pelanggan"])) {
	echo "<script>alert('Silakan login terlebih dahulu');</script>";
	echo "<script>location='login.php';</script>";
	exit();
}

$idpem = $_GET["id"];
$ambil = $koneksi->query("SELECT * FROM pembelian WHERE id_pembelian='$idpem'");
$detpem = $ambil->fetch_assoc();

// Proteksi akses: pastikan ID pembelian valid dan milik pelanggan yang login
if (!$detpem || ($_SESSION["pelanggan"]["id_pelanggan"] !== $detpem["id_pelanggan"])) {
	echo "<script>alert('Akses tidak diizinkan');</script>";
	echo "<script>location='riwayat.php';</script>";
	exit();
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
	<meta charset="UTF-8">
	<title>Konfirmasi Pembayaran | Arc`teryx Store</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

	<style>
		:root {
			--bg-deep: #030305;
			--card-glass: rgba(30, 31, 38, 0.8);
			--accent-blue: #4c8dff;
			--border: rgba(255, 255, 255, 0.1);
		}

		body {
			background-color: var(--bg-deep);
			color: #fff;
			font-family: 'Plus Jakarta Sans', sans-serif;
			display: flex;
			flex-direction: column;
			min-height: 100vh;
		}

		.mesh-bg {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background:
				radial-gradient(at 0% 0%, rgba(76, 141, 255, 0.05) 0px, transparent 50%),
				radial-gradient(at 100% 100%, rgba(165, 75, 255, 0.05) 0px, transparent 50%);
			z-index: -1;
		}

		.konten {
			flex: 1;
			padding: 12px 0 80px;
		}

		.card-dark {
			background: var(--card-glass);
			backdrop-filter: blur(20px);
			border-radius: 24px;
			border: 1px solid var(--border);
			padding: 40px;
			box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
		}

		.form-label {
			font-size: 0.85rem;
			font-weight: 600;
			color: #888;
			text-transform: uppercase;
			letter-spacing: 1px;
			margin-bottom: 8px;
		}

		.form-control {
			background: rgba(0, 0, 0, 0.3) !important;
			border: 1px solid var(--border) !important;
			color: #fff !important;
			border-radius: 12px;
			padding: 12px 15px;
		}

		.form-control:focus {
			border-color: var(--accent-blue) !important;
			box-shadow: 0 0 0 4px rgba(76, 141, 255, 0.1) !important;
		}

		.tagihan-info {
			background: rgba(76, 141, 255, 0.1);
			border-left: 4px solid var(--accent-blue);
			padding: 20px;
			border-radius: 12px;
			margin-bottom: 30px;
		}

		.btn-kirim {
			background: linear-gradient(90deg, #4c8dff, #9333ea);
			border: none;
			border-radius: 12px;
			padding: 15px;
			font-weight: 700;
			color: #fff;
			transition: 0.3s;
			margin-top: 10px;
		}

		.btn-kirim:hover {
			transform: translateY(-2px);
			box-shadow: 0 10px 20px rgba(76, 141, 255, 0.3);
			color: #fff;
		}

		.text {
			color: #adaaaaff;
		}
	</style>
</head>

<body>
	<div class="mesh-bg"></div>

	<?php include './layout/navbar.php'; ?>

	<section class="konten">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-6">
					<div class="card-dark">
						<div class="text-center mb-4">
							<h3 class="fw-800 text-white">Konfirmasi Pembayaran</h3>
							<div class="text">
								<p class="small">ID Pembelian: #<?= $idpem ?></p>
							</div>
						</div>

						<div class="tagihan-info">
							<span class="text-muted d-block small mb-1 uppercase">Total yang harus dibayar</span>
							<h3 class="fw-800 text-white mb-0">Rp <?= number_format($detpem["total_pembelian"]); ?></h3>
						</div>

						<form method="post" enctype="multipart/form-data">
							<div class="mb-3">
								<div class="text">
									<label class="form-label">Nama Penyetor</label>
								</div>
								<input type="text" class="form-control" name="nama" placeholder="Contoh: Aldi Syahputra" required>
							</div>

							<div class="mb-3">
								<div class="text">
									<label class="form-label">Bank Asal</label>
								</div>
								<input type="text" class="form-control" name="bank" placeholder="Contoh: BNI / BCA / Mandiri" required>
							</div>

							<div class="mb-3">
								<div class="text">
									<label class="form-label">Jumlah Transfer (Rp)</label>
								</div>
								<input type="number" class="form-control" name="jumlah"
									min="<?= $detpem['total_pembelian']; ?>"
									placeholder="Sesuai nominal tagihan" required>
							</div>

							<div class="mb-4">
								<div class="text">
									<label class="form-label">Upload Bukti Transfer</label>
								</div>
								<input type="file" class="form-control" name="bukti" accept="image/*" required>
								<div class="form-text text-muted small mt-2">
									<div class="text">
										<i class="bi bi-info-circle me-1"></i> Format JPG/PNG, Maksimal 2MB.
									</div>
								</div>
							</div>

							<button class="btn btn-kirim w-100" name="kirim">
								Kirim Konfirmasi <i class="bi bi-send-fill ms-2"></i>
							</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>

	<?php
	if (isset($_POST["kirim"])) {
		$nama = $_POST["nama"];
		$bank = $_POST["bank"];
		$jumlah = $_POST["jumlah"];
		$tanggal = date("Y-m-d");

		$file = $_FILES["bukti"];
		$ext = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));
		$size = $file["size"];

		// Validasi format
		if (!in_array($ext, ['jpg', 'jpeg', 'png'])) {
			echo "<script>alert('Gagal! Hanya diperbolehkan format JPG atau PNG.');</script>";
		}
		// Validasi ukuran
		elseif ($size > 2000000) {
			echo "<script>alert('Gagal! Ukuran file maksimal adalah 2MB.');</script>";
		} else {
			// Buat folder bukti_pembayaran jika belum ada
			if (!file_exists('bukti_pembayaran')) {
				mkdir('bukti_pembayaran', 0777, true);
			}

			$namafiks = date("YmdHis") . "_" . preg_replace("/[^a-zA-Z0-9.]/", "_", $file["name"]);
			move_uploaded_file($file["tmp_name"], "bukti_pembayaran/$namafiks");

			// Simpan data ke tabel pembayaran
			$koneksi->query("INSERT INTO pembayaran (id_pembelian, nama, bank, jumlah, tanggal, bukti)
                            VALUES ('$idpem','$nama','$bank','$jumlah','$tanggal','$namafiks')");

			// Update status pembelian
			$koneksi->query("UPDATE pembelian SET status_pembelian='sudah kirim pembayaran'
                            WHERE id_pembelian='$idpem'");

			echo "<script>alert('Terima kasih! Bukti pembayaran telah kami terima. Kami akan segera memverifikasi pesanan Anda.');</script>";
			echo "<script>location='riwayat.php';</script>";
		}
	}
	?>

	<?php include "./layout/footer.php"; ?>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>