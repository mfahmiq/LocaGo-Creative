<?php
session_start();
include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">

<head>
	<meta charset="UTF-8">
	<title>Arc`teryx Official Store</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

	<style>
		:root {
			--bg-deep: #030305;
			/* Card dibuat sedikit lebih gelap agar teks putih terbaca jelas */
			--card-glass: rgba(30, 31, 38, 0.7);
			--accent-blue: #4c8dff;
			--accent-purple: #a54bff;
			--border: rgba(255, 255, 255, 0.12);
		}

		body {
			background-color: var(--bg-deep);
			color: #fff;
			font-family: 'Plus Jakarta Sans', sans-serif;
			letter-spacing: -0.2px;
		}

		h1,
		h2,
		h3,
		.brand-font {
			font-family: 'Space Grotesk', sans-serif;
		}

		.mesh-bg {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background:
				radial-gradient(at 0% 0%, rgba(76, 141, 255, 0.12) 0px, transparent 50%),
				radial-gradient(at 100% 100%, rgba(165, 75, 255, 0.12) 0px, transparent 50%);
			z-index: -1;
		}

		.hero-v2 {
			padding: 10px 0 60px;
			text-align: center;
		}

		.tagline {
			display: inline-block;
			background: linear-gradient(90deg, var(--accent-blue), var(--accent-purple));
			padding: 6px 18px;
			border-radius: 50px;
			font-size: 11px;
			font-weight: 800;
			text-transform: uppercase;
			letter-spacing: 2px;
			margin-bottom: 25px;
			box-shadow: 0 4px 15px rgba(76, 141, 255, 0.3);
		}

		.hero-v2 h1 {
			font-size: clamp(2.5rem, 5vw, 4rem);
			font-weight: 700;
			line-height: 1.1;
		}

		/* --- IMPROVED BENTO CARD --- */
		.product-bento {
			background: var(--card-glass);
			backdrop-filter: blur(15px);
			-webkit-backdrop-filter: blur(15px);
			border: 1px solid var(--border);
			border-radius: 28px;
			padding: 20px;
			height: 100%;
			transition: all 0.4s cubic-bezier(0.25, 1, 0.5, 1);
			position: relative;
		}

		.product-bento:hover {
			transform: translateY(-10px);
			border-color: var(--accent-blue);
			box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
		}

		/* Container gambar: Background putih bersih agar produk menonjol */
		.img-wrapper {
			background: #ffffff;
			border-radius: 20px;
			height: 220px;
			display: flex;
			align-items: center;
			justify-content: center;
			padding: 25px;
			margin-bottom: 20px;
			position: relative;
			overflow: hidden;
			/* Penting agar badge tidak keluar jalur */
		}

		.img-wrapper img {
			max-width: 100%;
			max-height: 100%;
			object-fit: contain;
			transition: 0.5s ease;
			z-index: 1;
			/* Di bawah badge harga */
		}

		/* FIXED PRICE BADGE: z-index lebih tinggi dari gambar */
		.price-badge {
			position: absolute;
			bottom: 12px;
			right: 12px;
			background: #000000;
			color: #ffffff;
			padding: 6px 14px;
			border-radius: 12px;
			font-weight: 800;
			font-size: 12px;
			z-index: 10;
			border: 1px solid rgba(255, 255, 255, 0.2);
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
		}

		/* FIXED PRODUCT NAME: Warna putih solid dengan sedikit bayangan agar kontras */
		.product-info h3 {
			font-size: 1.15rem;
			font-weight: 700;
			margin: 10px 0 20px;
			color: #ffffff;
			/* Putih Solid */
			text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
			/* Bayangan teks agar terbaca */
			min-height: 2.8rem;
			line-height: 1.3;
		}

		.btn-action-group {
			display: grid;
			grid-template-columns: 1fr 50px;
			gap: 12px;
		}

		.btn-buy {
			background: #ffffff;
			color: #000000 !important;
			border: none;
			border-radius: 16px;
			padding: 12px;
			font-weight: 800;
			text-transform: uppercase;
			font-size: 0.85rem;
			transition: 0.3s;
		}

		.btn-buy:hover {
			background: var(--accent-blue);
			color: #ffffff !important;
			box-shadow: 0 0 15px rgba(76, 141, 255, 0.5);
		}

		.btn-detail {
			background: rgba(255, 255, 255, 0.08);
			color: #ffffff;
			border: 1px solid var(--border);
			border-radius: 16px;
			display: flex;
			align-items: center;
			justify-content: center;
			transition: 0.3s;
		}

		.btn-detail:hover {
			background: #ffffff;
			color: #000000;
		}
	</style>
</head>

<body>
	<div class="mesh-bg"></div>

	<?php include "./layout/navbar.php"; ?>

	<header class="hero-v2">
		<div class="container">
			<span class="tagline">Arc`Teryx Official Store</span>
			<h1 class="fw-bold">Level Up Your <span style="color: var(--accent-blue)">Gear</span></h1>
			<p class="text-muted mt-3 mx-auto" style="max-width: 500px;">
				Eksplorasi koleksi produk jaket outdoor premium dari Arc`teryx dengan desain masa depan dan kualitas tanpa kompromi.
			</p>
		</div>
	</header>

	<section class="pb-5 mb-5">
		<div class="container">
			<div class="row g-4">
				<?php
				$ambil = $koneksi->query("SELECT * FROM produk");
				while ($perproduk = $ambil->fetch_assoc()) {
				?>
					<div class="col-xl-3 col-lg-4 col-md-6">
						<div class="product-bento">
							<div class="img-wrapper">
								<div class="price-badge">
									Rp <?php echo number_format($perproduk['harga_produk'], 0, ',', '.'); ?>
								</div>
								<img src="foto_produk/<?php echo $perproduk['foto_produk']; ?>"
									alt="<?php echo $perproduk['nama_produk']; ?>">
							</div>

							<div class="product-info text-center">
								<span class="text-primary small fw-bold text-uppercase" style="letter-spacing: 1.5px; font-size: 10px;">Premium Original</span>
								<h3><?php echo $perproduk['nama_produk']; ?></h3>

								<div class="btn-action-group">
									<a href="beli.php?id=<?php echo $perproduk['id_produk']; ?>" class="btn-buy text-decoration-none">
										BELI SEKARANG
									</a>
									<a href="detail.php?id=<?php echo $perproduk['id_produk']; ?>" class="btn-detail text-decoration-none">
										<i class="bi bi-eye"></i>
									</a>
								</div>
							</div>
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
	</section>

	<?php include "./layout/footer.php"; ?>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>