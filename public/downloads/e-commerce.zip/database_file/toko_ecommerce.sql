-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 16, 2025 at 05:21 AM
-- Server version: 8.0.30
-- PHP Version: 8.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`, `nama_lengkap`) VALUES
(1, 'admin', 'admin123\n', 'administrator'),
(2, 'aldi', '123\r\n', 'Rizaldi');

-- --------------------------------------------------------

--
-- Table structure for table `ongkir`
--

CREATE TABLE `ongkir` (
  `id_ongkir` int NOT NULL,
  `nama_kota` varchar(100) NOT NULL,
  `tarif` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `ongkir`
--

INSERT INTO `ongkir` (`id_ongkir`, `nama_kota`, `tarif`) VALUES
(1, 'palu ', '10000'),
(2, 'parigi', '20000'),
(3, 'poso', '30000'),
(4, 'toli-toli', '40000'),
(5, 'luwuk', '50000'),
(6, 'morowali', '60000');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int NOT NULL,
  `email_pelanggan` varchar(100) NOT NULL,
  `password_pelanggan` varchar(50) NOT NULL,
  `nama_pelanggan` varchar(100) NOT NULL,
  `telephone_pelanggan` varchar(25) NOT NULL,
  `alamat_pelanggan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `email_pelanggan`, `password_pelanggan`, `nama_pelanggan`, `telephone_pelanggan`, `alamat_pelanggan`) VALUES
(1, 'rizaldi@gmail.com', 'aldi123', 'aldi', '0898999856', ''),
(2, 'r1z4ld1@icloud.com', 'r1z4ld1', 'Rizaldi', '081248265769', ''),
(3, 'wita@gmail.com', '123', 'wita', '0808808888', '');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int NOT NULL,
  `id_pembelian` int NOT NULL,
  `nama` varchar(255) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `jumlah` int NOT NULL,
  `tanggal` date NOT NULL,
  `bukti` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_pembelian`, `nama`, `bank`, `jumlah`, `tanggal`, `bukti`) VALUES
(1, 1, 'Aldi', 'Mandiri', 4020000, '2025-05-23', '250523175621Struck.jpg'),
(2, 1, 'rizaldi', 'Syariah Indonesia', 4000040, '2025-05-23', '250523201634nota.jpg'),
(3, 2, 'Aldi', 'Syariah Indonesia', 13020000, '2025-05-23', '250523210406nota.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE `pembelian` (
  `id_pembelian` int NOT NULL,
  `id_pelanggan` int NOT NULL,
  `id_ongkir` int NOT NULL,
  `tanggal_pembelian` date NOT NULL,
  `total_pembelian` int NOT NULL,
  `nama_kota` varchar(100) NOT NULL,
  `tarif` int NOT NULL,
  `alamat_pengiriman` text NOT NULL,
  `status_pembelian` varchar(100) NOT NULL DEFAULT 'pending',
  `resi_pengiriman` varchar(59) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`id_pembelian`, `id_pelanggan`, `id_ongkir`, `tanggal_pembelian`, `total_pembelian`, `nama_kota`, `tarif`, `alamat_pengiriman`, `status_pembelian`, `resi_pengiriman`) VALUES
(1, 2, 4, '2025-05-23', 4000040, 'toli-toli', 40, 'salumpaga', 'lunas', 'jne084355789'),
(2, 1, 2, '2025-05-23', 13020000, 'parigi', 20000, 'jln.pangeran, no 47 kode pos (97768) parigi tengah', 'barang dikirim', 'spx797495902'),
(3, 3, 2, '2025-05-26', 8020000, 'parigi', 20000, 'kota parigi', 'pending', '');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian_produk`
--

CREATE TABLE `pembelian_produk` (
  `id_pembelian_produk` int NOT NULL,
  `id_pembelian` int NOT NULL,
  `id_produk` int NOT NULL,
  `jumlah` int NOT NULL,
  `nama` varchar(100) NOT NULL,
  `harga` int NOT NULL,
  `berat` int NOT NULL,
  `Subberat` int NOT NULL,
  `Subtotal` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pembelian_produk`
--

INSERT INTO `pembelian_produk` (`id_pembelian_produk`, `id_pembelian`, `id_produk`, `jumlah`, `nama`, `harga`, `berat`, `Subberat`, `Subtotal`) VALUES
(1, 1, 1, 1, 'Arc\'teryx Beta Ar Jaket -Men\'s Dark Moss Small', 4000000, 700, 700, 4000000),
(2, 2, 8, 1, 'Arc\'teryx Rush Gore-Tex Jacket -  The Last Hunt', 13000000, 900, 900, 13000000),
(3, 3, 1, 2, 'Arc\'teryx Beta Ar Jaket -Men\'s Dark Moss Small', 4000000, 700, 1400, 8000000);

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id_produk` int NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `harga_produk` int NOT NULL,
  `berat_produk` int NOT NULL,
  `foto_produk` varchar(100) NOT NULL,
  `deskripsi_produk` text NOT NULL,
  `stok_produk` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `harga_produk`, `berat_produk`, `foto_produk`, `deskripsi_produk`, `stok_produk`) VALUES
(1, 'Arc\'teryx Beta Ar Jaket -Men\'s Dark Moss Small ', 5000000, 700, 'arcteryx10.jpg', '						Arc\'teryx – Di Mana Teknologi Bertemu Petualangan.\r\nDirancang untuk menaklukkan alam bebas dengan kenyamanan tanpa kompromi, jaket Arc\'teryx menyatukan inovasi, fungsionalitas, dan estetika modern. Dibuat dari material premium dengan konstruksi presisi, jaket ini menawarkan perlindungan maksimal dalam cuaca ekstrem – dari puncak gunung bersalju hingga hutan hujan yang lembap.				', 1),
(2, 'Arc\'teryx -Beta LT Gore-Tex Pro Jacket Orange', 7500000, 370, 'arcteryc4.jpg', 'Arc\'teryx menciptakan pakaian berperforma tinggi untuk berbagai aktivitas dan kondisi yang beragam. - Jaket \'Beta LT\' ini terbuat dari GORE-TEX® Pro ringan yang tahan angin dan air - StormHood™ yang kompatibel dengan helm mudah disesuaikan dengan kunci kabel Cohaesive™ khusus yang ramah sarung tangan untuk memberikan perlindungan penuh - Panel belakang yang memanjang memperluas perlindungan saat membungkuk atau duduk', 6),
(5, 'Arc\'teryx Beta-Ar Gore-Tex Jacket - Star Dark Navy', 4999000, 1200, 'arcteryx3.jpg', 'Siap Hadapi Alam dengan Arc\'teryx.\r\nDipercaya oleh para pendaki, pemanjat tebing, dan petualang sejati. Jaket ini dibuat untuk bertahan di kondisi paling ekstrem – dengan bahan GORE-TEX® yang tahan air dan bernapas, potongan ergonomis, dan detail desain yang mendukung performa maksimal. Ini bukan sekadar jaket, ini adalah perlengkapan tempurmu di alam liar.', 7),
(6, 'Arc\'teryx Beta LT Jaket -Men\'s deep-maroon ', 8900000, 570, 'arcteryxmaroon.jpeg', '			Arc\'teryx – Di Mana Teknologi Bertemu Petualangan.\r\nDirancang untuk menaklukkan alam bebas dengan kenyamanan tanpa kompromi, jaket Arc\'teryx menyatukan inovasi, fungsionalitas, dan estetika modern. Dibuat dari material premium dengan konstruksi presisi, jaket ini menawarkan perlindungan maksimal dalam cuaca ekstrem – dari puncak gunung bersalju hingga hutan hujan yang lembap.		', 1),
(7, 'Arc\'teryx Rush Jaket women\'s - Down Sunset   ', 6777000, 890, 'arcteryx7.jpg', '						Arc\'teryx – Di Mana Teknologi Bertemu Petualangan.\r\nDirancang untuk menaklukkan alam bebas dengan kenyamanan tanpa kompromi, jaket Arc\'teryx menyatukan inovasi, fungsionalitas, dan estetika modern. Dibuat dari material premium dengan konstruksi presisi, jaket ini menawarkan perlindungan maksimal dalam cuaca ekstrem – dari puncak gunung bersalju hingga hutan hujan yang lembap.\r\n\r\n				', 11),
(8, 'Arc\'teryx Rush Gore-Tex Jacket -  The Last Hunt', 13000000, 900, 'arcteryx9.jpg', 'Siap Hadapi Alam dengan Arc\'teryx.\r\nDipercaya oleh para pendaki, pemanjat tebing, dan petualang sejati. Jaket ini dibuat untuk bertahan di kondisi paling ekstrem – dengan bahan GORE-TEX® yang tahan air dan bernapas, potongan ergonomis, dan detail desain yang mendukung performa maksimal. Ini bukan sekadar jaket, ini adalah perlengkapan tempurmu di alam liar.', 3),
(10, 'Arc\'teryx Alpha Sv Jacket -Men\'s Out-North Dark ', 13200000, 1400, 'arcteryxbetasv.jpg', '			Arc\'teryx – Di Mana Teknologi Bertemu Petualangan.\r\nDirancang untuk menaklukkan alam bebas dengan kenyamanan tanpa kompromi, jaket Arc\'teryx menyatukan inovasi, fungsionalitas, dan estetika modern. Dibuat dari material premium dengan konstruksi presisi, jaket ini menawarkan perlindungan maksimal dalam cuaca ekstrem – dari puncak gunung bersalju hingga hutan hujan yang lembap.		', 2),
(11, 'Arc\'teryx Beta SL Hybrid - women\'s Ocean-Deep ', 9999000, 1700, 'arcteryxblue.jpg', '			Nyaman. Keren. Siap Jelajah.\r\nJaket Arc\'teryx bukan cuma soal gaya, tapi juga soal siap menghadapi cuaca apa pun. Ringan, tahan angin, dan tahan air – cocok buat kamu yang suka naik gunung atau sekadar ngopi sambil hujan-hujanan. Sekali pakai, susah lepas.		', 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `ongkir`
--
ALTER TABLE `ongkir`
  ADD PRIMARY KEY (`id_ongkir`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id_pembelian`);

--
-- Indexes for table `pembelian_produk`
--
ALTER TABLE `pembelian_produk`
  ADD PRIMARY KEY (`id_pembelian_produk`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ongkir`
--
ALTER TABLE `ongkir`
  MODIFY `id_ongkir` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `id_pembelian` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pembelian_produk`
--
ALTER TABLE `pembelian_produk`
  MODIFY `id_pembelian_produk` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
