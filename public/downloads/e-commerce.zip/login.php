<?php
session_start();
include 'koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">

<head>
	<meta charset="UTF-8">
	<title>Login Pelanggan | Arc`teryx Store</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

	<style>
		:root {
			--bg-deep: #030305;
			--card-glass: rgba(30, 31, 38, 0.7);
			--accent-blue: #4c8dff;
			--accent-purple: #9333ea;
			--border: rgba(255, 255, 255, 0.1);
		}

		body {
			background-color: var(--bg-deep);
			color: #fff;
			font-family: 'Plus Jakarta Sans', sans-serif;
			min-height: 100vh;
			display: flex;
			flex-direction: column;
		}

		.mesh-bg {
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background:
				radial-gradient(at 10% 10%, rgba(76, 141, 255, 0.1) 0px, transparent 40%),
				radial-gradient(at 90% 90%, rgba(147, 51, 234, 0.1) 0px, transparent 40%);
			z-index: -1;
		}

		.login-section {
			flex: 1;
			display: flex;
			align-items: center;
			justify-content: center;
			padding: 10px 20px;
		}

		.login-card {
			background: var(--card-glass);
			backdrop-filter: blur(25px);
			border: 1px solid var(--border);
			border-radius: 30px;
			padding: 50px;
			width: 100%;
			max-width: 450px;
			box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5);
		}

		.form-control {
			background: rgba(255, 255, 255, 0.05) !important;
			border: 1px solid var(--border) !important;
			color: #fff !important;
			border-radius: 12px;
			padding: 12px 18px;
			transition: 0.3s;
		}

		.form-control:focus {
			border-color: var(--accent-blue) !important;
			box-shadow: 0 0 0 4px rgba(76, 141, 255, 0.15) !important;
		}

		.btn-login {
			background: linear-gradient(90deg, var(--accent-blue), var(--accent-purple));
			border: none;
			border-radius: 12px;
			padding: 14px;
			font-weight: 700;
			color: #fff;
			transition: 0.3s;
			margin-top: 20px;
		}

		.btn-login:hover {
			transform: translateY(-3px);
			box-shadow: 0 10px 20px rgba(76, 141, 255, 0.4);
			color: #fff;
		}

		.login-header h2 {
			font-weight: 800;
			letter-spacing: -1px;
		}

		.register-link {
			color: var(--accent-blue);
			text-decoration: none;
			font-weight: 600;
		}

		.register-link:hover {
			text-decoration: underline;
		}
	</style>
</head>

<body>
	<div class="mesh-bg"></div>

	<?php include "./layout/navbar.php"; ?>

	<div class="login-section">
		<div class="login-card">
			<div class="login-header text-center mb-5">
				<div class="mb-3">
					<i class="bi bi-shield-lock-fill text-primary" style="font-size: 3rem;"></i>
				</div>
				<h2>Selamat <span class="text-primary">Datang</span></h2>
				<p class="text-muted">Silakan masuk ke akun Anda</p>
			</div>

			<form method="post">
				<div class="mb-3">
					<label class="form-label small fw-bold text-uppercase text-muted">Email</label>
					<div class="input-group">
						<span class="input-group-text bg-transparent border-0 text-muted"><i class="bi bi-envelope"></i></span>
						<input type="email" class="form-control" name="email" placeholder="nama@email.com" required>
					</div>
				</div>

				<div class="mb-4">
					<label class="form-label small fw-bold text-uppercase text-muted">Password</label>
					<div class="input-group">
						<span class="input-group-text bg-transparent border-0 text-muted"><i class="bi bi-lock"></i></span>
						<input type="password" class="form-control" name="password" placeholder="••••••••" required>
					</div>
				</div>

				<button class="btn btn-login w-100" name="login">
					Masuk Sekarang <i class="bi bi-arrow-right ms-2"></i>
				</button>
			</form>

			<div class="mt-5 text-center">
				<p class="text-muted small">Belum punya akun?
					<a href="daftar.php" class="register-link">Daftar Gratis</a>
				</p>
			</div>
		</div>
	</div>

	<?php
	if (isset($_POST["login"])) {
		$email = $_POST["email"];
		$password = $_POST["password"];

		// Query cek akun di tabel pelanggan
		$ambil = $koneksi->query("SELECT * FROM pelanggan WHERE email_pelanggan='$email' AND password_pelanggan='$password'");
		$akun_cocok = $ambil->num_rows;

		if ($akun_cocok == 1) {
			$akun = $ambil->fetch_assoc();
			$_SESSION["pelanggan"] = $akun;

			echo "<div class='alert alert-success mt-3 text-center'>Login Berhasil</div>";

			// Jika ada keranjang, arahkan ke checkout, jika tidak ke riwayat
			if (isset($_SESSION["keranjang"]) or !empty($_SESSION["keranjang"])) {
				echo "<meta http-equiv='refresh' content='1;url=checkout.php'>";
			} else {
				echo "<meta http-equiv='refresh' content='1;url=riwayat.php'>";
			}
		} else {
			echo "<script>alert('Login Gagal, periksa email dan password Anda');</script>";
			echo "<meta http-equiv='refresh' content='1;url=login.php'>";
		}
	}
	?>

	<?php include "./layout/footer.php"; ?>
</body>

</html>