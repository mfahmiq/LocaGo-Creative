CREATE DATABASE IF NOT EXISTS `db_donasi_online`;
USE `db_donasi_online`;

CREATE TABLE IF NOT EXISTS `campaigns` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `target_dana` decimal(15,2) NOT NULL,
  `terkumpul` decimal(15,2) NOT NULL DEFAULT 0,
  `batas_waktu` date NOT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `campaigns` (`judul`, `target_dana`, `terkumpul`, `batas_waktu`) VALUES
('Bantuan Sarana Belajar Siswa Yatim Piatu', 50000000.00, 48500000.00, '2026-12-31');
