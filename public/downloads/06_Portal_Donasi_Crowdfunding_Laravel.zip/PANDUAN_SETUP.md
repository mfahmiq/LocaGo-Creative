# Panduan Portal Donasi Laravel
1. Jalankan `composer install` dan `npm install`.
2. Buat database `db_donasi_online` dan import `database.sql`.
3. Konfigurasi `.env` untuk database dan kunci API Payment Gateway.
4. Jalankan `php artisan serve`.
