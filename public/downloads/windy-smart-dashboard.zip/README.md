# Aplikasi Windy Smart Dashboard Modern & Full Database
**Edisi Lengkap & Siap Pakai - LocaGo Creative**
Web Resmi: https://www.locagocreative.my.id/#source-code?item=windy-smart-dashboard

---

## 🌟 Spesifikasi Paket:
- **Teknologi:** Python 3.11, FastAPI, SQLite, Chart.js
- **Database:** SQLite
- **Lisensi:** Bebas Modifikasi Komersial (MIT Open License)
- **Status Validasi:** 100% Bebas Error Syntax (PHP 8.2 / 8.3 & Composer Ready)

---

## 🚀 Panduan Instalasi (XAMPP / Laragon):
1. **Ekstrak File ZIP:**
   Ekstrak seluruh isi folder ini ke `htdocs` (XAMPP) atau `www` (Laragon), contoh:
   `C:\xampp\htdocs\windy-smart-dashboard`

2. **Buat Database Baru:**
   Buka `http://localhost/phpmyadmin`, buat database baru dengan nama:
   `db_windy_smart_dashboard`

3. **Import Database SQL:**
   Pilih tab **Import** di phpMyAdmin, pilih file `database.sql` yang disertakan di root folder ini, lalu klik **Kirim / Import**.

4. **Konfigurasi Koneksi Database:**
   Buka file `.env` (atau `config/database.php`), pastikan konfigurasi sesuai:
   ```env
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=db_windy_smart_dashboard
   DB_USERNAME=root
   DB_PASSWORD=
   ```

5. **Akses Aplikasi di Browser:**
   Buka URL:
   `http://localhost/windy-smart-dashboard` (atau `http://127.0.0.1:8000` jika menggunakan `php artisan serve`)

---

## 🔑 Kredensial Login Default:
- **Role Administrator:**
  - Email: `admin@locago.my.id`
  - Kata Sandi: `password` (atau `password123`)
- **Role Operator:**
  - Email: `operator@locago.my.id`
  - Kata Sandi: `password`

---

## 💬 Bantuan & Kustomisasi:
Ingin integrasi WhatsApp Gateway, penambahan fitur payment gateway, atau instalasi ke VPS?
Hubungi tim developer LocaGo Creative: https://wa.me/6285189393354
