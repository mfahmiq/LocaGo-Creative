-- Database Schema & Seed Data for Aplikasi Windy Smart Dashboard Modern & Full Database
-- Rebranded & Validated by LocaGo Creative Engine
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(50) DEFAULT 'admin',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO `users` (`name`, `email`, `password`, `role`) VALUES
('Administrator LocaGo', 'admin@locago.my.id', '$2y$10$abcdefghijklmnopqrstuvwxyz123456', 'admin'),
('Operator Kasir', 'operator@locago.my.id', '$2y$10$abcdefghijklmnopqrstuvwxyz123456', 'operator');
