<?= $this->extend('pelanggan/layout_plg') ?>

<?= $this->section('isi') ?>
<?php
$user   = (array) ($user ?? []);
$errors = (array) (session()->getFlashdata('errors') ?? []);
$e      = static fn (string $teks): string => htmlspecialchars($teks, ENT_QUOTES, 'UTF-8');
$jk     = (string) old('jenis_kelamin', (string) ($user['jenis_kelamin'] ?? ''));
?>

<div class="judul-halaman">
    <a href="<?= base_url('profil/data') ?>" class="kembali">&larr;</a>
    <h3>Ubah Data Pribadi</h3>
</div>

<div class="panel">
    <?php if ($errors): ?>
        <div class="alert"><?= implode('<br>', array_map($e, array_map('strval', $errors))) ?></div>
    <?php endif; ?>

    <form action="<?= base_url('profil/data/simpan') ?>" method="post" class="form">
        <?= csrf_field() ?>

        <label>Nama Lengkap</label>
        <input type="text" name="nama" value="<?= $e((string) old('nama', (string) ($user['nama'] ?? ''))) ?>">

        <label>Nomor Telepon</label>
        <input type="text" name="no_hp" value="<?= $e((string) old('no_hp', (string) ($user['no_hp'] ?? ''))) ?>">

        <label>Email</label>
        <input type="email" value="<?= $e((string) ($user['email'] ?? '')) ?>" readonly class="readonly">

        <label>Tanggal Lahir</label>
        <input type="date" name="tanggal_lahir" value="<?= $e((string) old('tanggal_lahir', (string) ($user['tanggal_lahir'] ?? ''))) ?>">

        <label>Jenis Kelamin</label>
        <select name="jenis_kelamin">
            <option value="">- Pilih -</option>
            <option value="Laki-laki" <?= $jk === 'Laki-laki' ? 'selected' : '' ?>>Laki-laki</option>
            <option value="Perempuan" <?= $jk === 'Perempuan' ? 'selected' : '' ?>>Perempuan</option>
        </select>

        <button type="submit" class="btn btn-dark btn-small">Simpan</button>
    </form>
</div>
<?= $this->endSection() ?>