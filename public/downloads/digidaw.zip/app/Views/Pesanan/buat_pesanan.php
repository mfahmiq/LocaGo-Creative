<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Pesanan - DigiWash</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@700&family=Roboto:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background: #F0EFEF;
            font-family: 'Roboto', sans-serif;
            display: flex;
            justify-content: center;
            min-height: 100vh;
        }
        .mobile-wrap {
            width: 100%;
            max-width: 402px;
            background: #F0EFEF;
            min-height: 100vh;
            padding-bottom: 40px;
        }

        /* ── Header ── */
        .page-header {
            display: flex;
            align-items: center;
            padding: 54px 24px 20px;
            position: relative;
        }
        .btn-back {
            width: 32px; height: 32px;
            display: flex; align-items: center; justify-content: center;
            text-decoration: none; color: #000;
            font-size: 20px; font-weight: 700; flex-shrink: 0;
        }
        .page-title {
            position: absolute; left: 50%; transform: translateX(-50%);
            font-family: 'Roboto', sans-serif; font-weight: 600;
            font-size: 20px; line-height: 22px; color: #000; white-space: nowrap;
        }

        /* ── Form area ── */
        .form-area { padding: 0 23px; }

        .section-label {
            font-family: 'Roboto', sans-serif; font-weight: 600;
            font-size: 13px; line-height: 22px; color: #000;
            display: block; margin-bottom: 6px;
        }

        /* ── Service box ── */
        .service-box {
            background: #fff; border-radius: 10px; padding: 14px 17px;
            margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        }
        .service-box-label {
            font-family: 'Roboto', sans-serif; font-weight: 600;
            font-size: 13px; line-height: 22px; color: #000; margin-bottom: 4px;
        }
        .service-box-inner {
            display: flex; align-items: center; justify-content: space-between; gap: 10px;
        }
        .service-box-icon { font-size: 32px; flex-shrink: 0; }
        .service-box-info { flex: 1; }
        .service-box-name {
            font-family: 'Roboto', sans-serif; font-weight: 600;
            font-size: 13px; line-height: 22px; color: #000;
        }
        .service-box-price {
            font-family: 'Roboto', sans-serif; font-weight: 400;
            font-size: 13px; line-height: 22px; color: #555;
        }
        .btn-ubah {
            font-family: 'Roboto', sans-serif; font-weight: 600;
            font-size: 15px; line-height: 22px; color: #033B59;
            text-decoration: none; white-space: nowrap;
            background: none; border: none; cursor: pointer; padding: 0;
        }

        /* ── Weight counter (Kiloan) ── */
        .weight-group {
            background: #fff; border: 1px solid #D2CBCB; border-radius: 10px;
            height: 46px; display: flex; align-items: center;
            justify-content: space-between; overflow: hidden; margin-bottom: 20px;
        }
        .counter-btn {
            width: 67px; height: 46px; background: transparent; border: none;
            font-family: 'Poppins', sans-serif; font-weight: 700; font-size: 24px;
            color: #000; cursor: pointer; display: flex; align-items: center;
            justify-content: center; transition: background 0.15s;
        }
        .counter-btn:hover { background: #f0eeee; }
        .counter-divider { width: 1px; height: 46px; background: #000; }
        .counter-value {
            flex: 1; text-align: center;
            font-family: 'Roboto', sans-serif; font-weight: 300; font-size: 20px;
            color: #000; border: none; background: transparent; outline: none;
        }

        /* ── Alamat info card ── */
        .info-card {
            background: #fff; border: 1px solid #D2CBCB; border-radius: 10px;
            padding: 10px 17px; margin-bottom: 20px;
            display: flex; align-items: flex-start; justify-content: space-between;
            gap: 8px; min-height: 55px;
        }
        .info-card-addr {
            font-family: 'Roboto', sans-serif; font-weight: 400;
            font-size: 12px; line-height: 22px; color: #000; flex: 1;
        }

        /* ── Input / Textarea ── */
        .input-box {
            background: #fff; border: 1px solid #D2CBCB; border-radius: 10px;
            height: 41px; width: 100%; padding: 8px 17px;
            font-family: 'Roboto', sans-serif; font-weight: 400;
            font-size: 13px; color: #000; outline: none; margin-bottom: 20px;
        }
        .input-box:focus { border-color: #033B59; }
        .textarea-box {
            background: #fff; border: 1px solid #D2CBCB; border-radius: 10px;
            width: 100%; padding: 10px 17px;
            font-family: 'Roboto', sans-serif; font-weight: 200;
            font-size: 13px; color: #000; outline: none;
            resize: vertical; min-height: 41px; margin-bottom: 20px;
        }
        .textarea-box::placeholder { color: #aaa; }
        .input-icon-group { position: relative; margin-bottom: 20px; }
        .input-icon-group .input-box { padding-right: 44px; margin-bottom: 0; }
        .input-icon {
            position: absolute; right: 12px; top: 50%;
            transform: translateY(-50%); font-size: 18px; opacity: 0.5;
            pointer-events: none;
        }

        /* ── Cost box ── */
        .cost-box {
            background: #CEE4F0; border-radius: 15px; padding: 14px 18px;
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 20px;
        }
        .cost-label { font-weight: 700; font-size: 16px; line-height: 22px; color: #000; }
        .cost-detail { font-weight: 700; font-size: 16px; line-height: 22px; color: #000; margin-top: 2px; }
        .cost-total { font-weight: 700; font-size: 24px; line-height: 22px; color: #019D13; }

        /* ── Submit button ── */
        .btn-submit {
            width: 100%; height: 41px; background: #033B59;
            border: 1px solid #D2CBCB; border-radius: 10px;
            font-family: 'Roboto', sans-serif; font-weight: 700;
            font-size: 16px; color: #fff; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            transition: background 0.2s;
        }
        .btn-submit:hover { background: #022c44; }

        /* ── Satuan grid ── */
        .satuan-banner {
            background: #E8F4FD; border-radius: 10px; padding: 12px 17px;
            margin-bottom: 16px; text-align: center;
            font-family: 'Roboto', sans-serif; font-weight: 600;
            font-size: 13px; line-height: 22px; color: #033B59;
        }
        .satuan-grid {
            display: grid; grid-template-columns: repeat(2, 1fr);
            gap: 12px; margin-bottom: 20px;
        }
        .satuan-card {
            background: #fff; border: 1px solid #e2e8f0; border-radius: 10px;
            padding: 12px 10px 10px; text-align: center; transition: border-color 0.2s;
        }
        .satuan-card:hover { border-color: #033B59; }
        .satuan-icon { font-size: 28px; margin-bottom: 4px; }
        .satuan-name { font-weight: 600; font-size: 12px; color: #1e293b; }
        .satuan-price { font-weight: 400; font-size: 11px; color: #64748b; margin: 2px 0 8px; }
        .satuan-counter { display: flex; align-items: center; justify-content: center; gap: 8px; }
        .satuan-btn {
            width: 28px; height: 28px; border-radius: 6px;
            border: 1px solid #D2CBCB; background: #fff;
            font-weight: 700; font-size: 16px; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            transition: background 0.15s;
        }
        .satuan-btn:hover { background: #f0eeee; }
        .satuan-qty { font-weight: 700; font-size: 14px; min-width: 20px; text-align: center; }
        .subtotal-bar {
            background: #CEE4F0; border-radius: 15px; padding: 10px 18px;
            display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;
        }
        .subtotal-label { font-weight: 700; font-size: 13px; color: #033B59; }
        .subtotal-val { font-weight: 700; font-size: 14px; color: #019D13; }

        /* ── BS5 Modal overrides ── */
        .modal-content { border-radius: 14px; }
        .modal-header { border-bottom: 1px solid #f0eeee; padding: 16px 20px 12px; }
        .modal-title { font-family: 'Roboto', sans-serif; font-weight: 700; font-size: 16px; color: #033B59; }
        .modal-body { padding: 16px 20px; font-size: 13px; color: #333; }
        .modal-footer { border-top: 1px solid #f0eeee; padding: 12px 20px; gap: 10px; }
    </style>
</head>
<body>
<div class="mobile-wrap">

    <!-- Header -->
    <div class="page-header">
        <a href="<?= base_url('pesanan/pilih-layanan') ?>" class="btn-back">&#8592;</a>
        <span class="page-title">Buat Pesanan</span>
    </div>

    <div class="form-area">
        <form action="<?= base_url('pesanan/ringkasan') ?>" method="post" id="formPesanan">
            <?= csrf_field() ?>
            <!-- Hidden inputs – JANGAN DIHAPUS -->
            <input type="hidden" name="layanan" value="<?= (string) $layanan ?>">
            <input type="hidden" name="alamat" id="inputAlamat" value="<?= (string) $alamat ?>">
            <input type="hidden" name="tanggal_penjemputan" value="<?= (string) $tanggal ?>">
            <input type="hidden" id="harga_per_kg" value="<?= (int) $harga_per_kg ?>">
            <input type="hidden" id="detail_satuan" name="detail_satuan" value="">

            <!-- ── SERVICE BOX ── -->
            <div class="service-box">
                <div class="service-box-label">Layanan</div>
                <div class="service-box-inner">
                    <span class="service-box-icon">
                        <?php
                            if ($layanan === 'Express')      echo '⚡';
                            elseif ($layanan === 'BedCover') echo '🛏️';
                            elseif ($layanan === 'Satuan')   echo '👔';
                            else                             echo '🧺';
                        ?>
                    </span>
                    <div class="service-box-info">
                        <div class="service-box-name">Laundry <?= (string) $layanan ?></div>
                        <div class="service-box-price">
                            <?= ($layanan === 'Satuan')
                                ? 'Pencucian per item'
                                : 'Rp ' . number_format((int) $harga_per_kg, 0, ',', '.') . ' / Kg' ?>
                        </div>
                    </div>
                    <a href="<?= base_url('pesanan/pilih-layanan') ?>" class="btn-ubah">Ubah</a>
                </div>
            </div>

            <?php if ($layanan === 'Satuan'): ?>
            <!-- ══ SATUAN MODE ══ -->
            <div class="satuan-banner">
                💡 Harga per item — pilih item yang ingin dicuci
            </div>

            <span class="section-label">Pilih Item Satuan</span>
            <div class="satuan-grid">

                <div class="satuan-card">
                    <div class="satuan-icon">🥼</div>
                    <div class="satuan-name">Jas Formal</div>
                    <div class="satuan-price">Rp 25.000</div>
                    <div class="satuan-counter">
                        <button type="button" class="satuan-btn" onclick="updateSatuan('jas',-1)">−</button>
                        <span id="qty_jas" class="satuan-qty">0</span>
                        <button type="button" class="satuan-btn" onclick="updateSatuan('jas',1)">+</button>
                    </div>
                </div>

                <div class="satuan-card">
                    <div class="satuan-icon">🧥</div>
                    <div class="satuan-name">Jaket</div>
                    <div class="satuan-price">Rp 15.000</div>
                    <div class="satuan-counter">
                        <button type="button" class="satuan-btn" onclick="updateSatuan('jaket',-1)">−</button>
                        <span id="qty_jaket" class="satuan-qty">0</span>
                        <button type="button" class="satuan-btn" onclick="updateSatuan('jaket',1)">+</button>
                    </div>
                </div>

                <div class="satuan-card">
                    <div class="satuan-icon">👗</div>
                    <div class="satuan-name">Gaun Pesta</div>
                    <div class="satuan-price">Rp 35.000</div>
                    <div class="satuan-counter">
                        <button type="button" class="satuan-btn" onclick="updateSatuan('gaun',-1)">−</button>
                        <span id="qty_gaun" class="satuan-qty">1</span>
                        <button type="button" class="satuan-btn" onclick="updateSatuan('gaun',1)">+</button>
                    </div>
                </div>

                <div class="satuan-card">
                    <div class="satuan-icon">👟</div>
                    <div class="satuan-name">Sepatu</div>
                    <div class="satuan-price">Rp 10.000</div>
                    <div class="satuan-counter">
                        <button type="button" class="satuan-btn" onclick="updateSatuan('sepatu',-1)">−</button>
                        <span id="qty_sepatu" class="satuan-qty">0</span>
                        <button type="button" class="satuan-btn" onclick="updateSatuan('sepatu',1)">+</button>
                    </div>
                </div>

                <div class="satuan-card">
                    <div class="satuan-icon">🧣</div>
                    <div class="satuan-name">Selimut</div>
                    <div class="satuan-price">Rp 20.000</div>
                    <div class="satuan-counter">
                        <button type="button" class="satuan-btn" onclick="updateSatuan('selimut',-1)">−</button>
                        <span id="qty_selimut" class="satuan-qty">0</span>
                        <button type="button" class="satuan-btn" onclick="updateSatuan('selimut',1)">+</button>
                    </div>
                </div>

                <div class="satuan-card">
                    <div class="satuan-icon">🎒</div>
                    <div class="satuan-name">Tas Ransel</div>
                    <div class="satuan-price">Rp 18.000</div>
                    <div class="satuan-counter">
                        <button type="button" class="satuan-btn" onclick="updateSatuan('tas',-1)">−</button>
                        <span id="qty_tas" class="satuan-qty">0</span>
                        <button type="button" class="satuan-btn" onclick="updateSatuan('tas',1)">+</button>
                    </div>
                </div>

                <div class="satuan-card">
                    <div class="satuan-icon">👕</div>
                    <div class="satuan-name">Kaos Oblong</div>
                    <div class="satuan-price">Rp 8.000</div>
                    <div class="satuan-counter">
                        <button type="button" class="satuan-btn" onclick="updateSatuan('kaos',-1)">−</button>
                        <span id="qty_kaos" class="satuan-qty">0</span>
                        <button type="button" class="satuan-btn" onclick="updateSatuan('kaos',1)">+</button>
                    </div>
                </div>

                <div class="satuan-card">
                    <div class="satuan-icon">✨</div>
                    <div class="satuan-name">Lainnya</div>
                    <div class="satuan-price">Rp 12.000</div>
                    <div class="satuan-counter">
                        <button type="button" class="satuan-btn" onclick="updateSatuan('lainnya',-1)">−</button>
                        <span id="qty_lainnya" class="satuan-qty">0</span>
                        <button type="button" class="satuan-btn" onclick="updateSatuan('lainnya',1)">+</button>
                    </div>
                </div>

            </div>

            <div class="subtotal-bar">
                <span class="subtotal-label">Subtotal Item</span>
                <span class="subtotal-val" id="subtotal_items">Rp 35.000</span>
            </div>

            <input type="hidden" name="berat" value="1">

            <?php else: ?>
            <!-- ══ KILOAN MODE ══ -->
            <span class="section-label">Berat Cucian (Kg)</span>
            <div class="weight-group">
                <button type="button" class="counter-btn" onclick="ubahBerat(-1)">−</button>
                <div class="counter-divider"></div>
                <input type="number" id="berat" name="berat" class="counter-value" value="5" min="1" readonly>
                <div class="counter-divider"></div>
                <button type="button" class="counter-btn" onclick="ubahBerat(1)">+</button>
            </div>
            <?php endif; ?>

            <!-- ── ALAMAT PENJEMPUTAN ── -->
            <span class="section-label">Alamat Penjemputan</span>
            <div class="info-card">
                <div class="info-card-addr" id="displayAlamat"><?= (string) $alamat ?></div>
                <button type="button" class="btn-ubah"
                    data-bs-toggle="modal" data-bs-target="#modalUbahAlamat">Ubah</button>
            </div>

            <!-- ── TANGGAL PENJEMPUTAN ── -->
            <span class="section-label">Tanggal Penjemputan</span>
            <div class="input-icon-group">
                <input type="text" class="input-box" value="<?= (string) $tanggal ?>" readonly>
                <span class="input-icon">📅</span>
            </div>

            <!-- ── CATATAN ── -->
            <span class="section-label">Catatan Tambahan (Opsional)</span>
            <textarea name="catatan" class="textarea-box"
                placeholder="Contoh : Rumah Putih Mobil Agya putih"></textarea>

            <!-- ── RINCIAN BIAYA ── -->
            <div class="cost-box">
                <div>
                    <div class="cost-label">Rincian Biaya</div>
                    <div class="cost-detail" id="text_calc">
                        5 Kg x Rp <?= number_format((int) $harga_per_kg, 0, ',', '.') ?>
                    </div>
                </div>
                <div class="cost-total" id="text_total">Rp 35.000</div>
            </div>
            <input type="hidden" id="total_harga" name="total_harga" value="35000">

            <!-- ── SUBMIT ── -->
            <button type="submit" class="btn-submit">Lanjut Ke Ringkasan</button>
        </form>
    </div><!-- /.form-area -->
</div><!-- /.mobile-wrap -->

<!-- ══ Modal Ubah Alamat (Bootstrap 5) ══ -->
<div class="modal fade" id="modalUbahAlamat" tabindex="-1" aria-labelledby="modalUbahAlamatLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalUbahAlamatLabel">📍 Ubah Alamat Penjemputan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <label for="inputAlamatBaru" class="form-label fw-semibold" style="font-size:13px; color:#333;">
                    Masukkan alamat baru:
                </label>
                <textarea id="inputAlamatBaru" class="form-control" rows="3"
                    style="font-size:13px; border-radius:10px; border-color:#D2CBCB;"
                    placeholder="Contoh: Jl. Mawar No. 5, RT 01/RW 03, Depok"></textarea>
                <div id="alamatError" class="text-danger mt-1" style="font-size:12px; display:none;">
                    Alamat tidak boleh kosong.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary rounded-3"
                    data-bs-dismiss="modal" style="font-size:13px;">Batal</button>
                <button type="button" class="btn rounded-3 fw-bold text-white"
                    style="background:#033B59; font-size:13px;" onclick="simpanAlamat()">
                    Simpan Alamat
                </button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    let isSatuan = <?= ($layanan === 'Satuan') ? 'true' : 'false' ?>;
    let itemsSatuan = {
        jas: 0, jaket: 0, gaun: 1, sepatu: 0,
        selimut: 0, tas: 0, kaos: 0, lainnya: 0
    };
    let hargaSatuan = {
        jas: 25000, jaket: 15000, gaun: 35000, sepatu: 10000,
        selimut: 20000, tas: 18000, kaos: 8000, lainnya: 12000
    };

    /* ── Kiloan counter ── */
    function ubahBerat(val) {
        let inputBerat = document.getElementById('berat');
        let newVal = Math.max(1, (parseInt(inputBerat.value) || 1) + val);
        inputBerat.value = newVal;
        hitungTotal();
    }

    /* ── Satuan counter ── */
    function updateSatuan(item, val) {
        if (itemsSatuan[item] + val >= 0) {
            itemsSatuan[item] += val;
            document.getElementById('qty_' + item).innerText = itemsSatuan[item];
            hitungTotal();
        }
    }

    /* ── Hitung total ── */
    function hitungTotal() {
        if (isSatuan) {
            let total = 0;
            for (let k in itemsSatuan) total += itemsSatuan[k] * hargaSatuan[k];

            document.getElementById('text_calc').innerText = 'Laundry Satuan';
            document.getElementById('text_total').innerText = 'Rp ' + total.toLocaleString('id-ID');
            document.getElementById('total_harga').value = total;
            document.getElementById('detail_satuan').value = JSON.stringify(itemsSatuan);

            let sub = document.getElementById('subtotal_items');
            if (sub) sub.innerText = 'Rp ' + total.toLocaleString('id-ID');
        } else {
            let berat = parseInt(document.getElementById('berat').value) || 1;
            let harga = parseInt(document.getElementById('harga_per_kg').value) || 0;
            let total = berat * harga;
            document.getElementById('text_calc').innerText = berat + ' Kg x Rp ' + harga.toLocaleString('id-ID');
            document.getElementById('text_total').innerText = 'Rp ' + total.toLocaleString('id-ID');
            document.getElementById('total_harga').value = total;
        }
    }

    /* ── Simpan alamat dari modal ── */
    function simpanAlamat() {
        let val = document.getElementById('inputAlamatBaru').value.trim();
        let errEl = document.getElementById('alamatError');
        if (!val) {
            errEl.style.display = 'block';
            return;
        }
        errEl.style.display = 'none';
        document.getElementById('inputAlamat').value = val;
        document.getElementById('displayAlamat').innerText = val;
        bootstrap.Modal.getInstance(document.getElementById('modalUbahAlamat')).hide();
    }

    /* Isi textarea modal saat dibuka */
    document.getElementById('modalUbahAlamat').addEventListener('show.bs.modal', function () {
        document.getElementById('inputAlamatBaru').value =
            document.getElementById('inputAlamat').value;
    });

    hitungTotal();
</script>
</body>
</html>