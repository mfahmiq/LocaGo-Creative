# Aplikasi Woocommerce Pos Modern & Full Database
**Edisi Lengkap & Siap Pakai - LocaGo Creative**
Web Resmi: https://www.locagocreative.my.id/#source-code?item=woocommerce-pos

---

## 🌟 Spesifikasi Paket:
- **Teknologi:** PHP 8.2, Laravel 11, MySQL, Tailwind CSS
- **Database:** MySQL (.sql)
- **Lisensi:** Bebas Modifikasi Komersial (MIT Open License)
- **Status Validasi:** 100% Bebas Error Syntax (PHP 8.2 / 8.3 & Composer Ready)

---

## 🚀 Panduan Instalasi (XAMPP / Laragon):
1. **Ekstrak File ZIP:**
   Ekstrak seluruh isi folder ini ke `htdocs` (XAMPP) atau `www` (Laragon), contoh:
   `C:\xampp\htdocs\woocommerce-pos`

2. **Buat Database Baru:**
   Buka `http://localhost/phpmyadmin`, buat database baru dengan nama:
   `db_woocommerce_pos`

3. **Import Database SQL:**
   Pilih tab **Import** di phpMyAdmin, pilih file `database.sql` yang disertakan di root folder ini, lalu klik **Kirim / Import**.

4. **Konfigurasi Koneksi Database:**
   Buka file `.env` (atau `config/database.php`), pastikan konfigurasi sesuai:
   ```env
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=db_woocommerce_pos
   DB_USERNAME=root
   DB_PASSWORD=
   ```

5. **Akses Aplikasi di Browser:**
   Buka URL:
   `http://localhost/woocommerce-pos` (atau `http://127.0.0.1:8000` jika menggunakan `php artisan serve`)

---

## 🔑 Kredensial Login Default:
- **Role Administrator:**
  - Email: `admin@locago.my.id`
  - Kata Sandi: `password` (atau `password123`)
- **Role Operator:**
  - Email: `operator@locago.my.id`
  - Kata Sandi: `password`

---

## 💬 Bantuan & Kustomisasi:
Ingin integrasi WhatsApp Gateway, penambahan fitur payment gateway, atau instalasi ke VPS?
Hubungi tim developer LocaGo Creative: https://wa.me/6285189393354
