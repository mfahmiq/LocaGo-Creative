<?php
require_once __DIR__ . '/includes/connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    csrf_verify();

    $client_name = input_str($_POST, 'client_name', 255);
    $email       = input_email($_POST, 'email');
    $service     = input_enum($_POST, 'service', ['haircut & styling', 'coloring', 'spa treatments', 'bridal makeup', 'other']);
    $rating      = input_int($_POST, 'rating', 1);
    $message     = input_str($_POST, 'message', 2000);

    // Server-side validation
    if ($client_name !== '' && $email && $service && $rating && $rating <= 5 && $message !== '') {
        // Keep the original label (e.g. "Haircut & Styling")
        $service = input_str($_POST, 'service', 100);

        $ok = db_query($conn, "INSERT INTO feedback (client_name, email, service, rating, message, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
            'sssis', [$client_name, $email, $service, $rating, $message]);

        if ($ok) {
            js_alert('Feedback submitted successfully!', 'feedback.php');
            exit();
        } else {
            js_alert('Error submitting feedback');
        }
    } else {
        js_alert('Please fill all fields');
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elegance Salon - Feedback</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600&family=Playfair+Display:ital,wght@0,400;0,600;1,400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/style.css">
    <style>
        /* --- Base Reset & Typography --- */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            /* Matches the dark charcoal background of the screenshot */
            background-color: #121212;
            color: #e0e0e0;
            font-family: 'Montserrat', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 40px 20px;
        }

        /* --- Form Container --- */
        .feedback-wrapper {
            background-color: #181818;
            /* Slightly lighter than body for contrast */
            border: 1px solid #333;
            padding: 50px;
            max-width: 700px;
            width: 100%;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.5);
        }

        /* --- Header Styling --- */
        .feedback-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .subtitle {
            font-size: 0.75rem;
            letter-spacing: 2px;
            color: #c5a059;
            /* Gold Accent */
            text-transform: uppercase;
            margin-bottom: 15px;
        }

        .feedback-header h2 {
            font-family: 'Playfair Display', serif;
            font-size: 3rem;
            font-weight: 400;
            color: #ffffff;
            margin-bottom: 15px;
        }

        .feedback-header h2 span {
            font-style: italic;
            color: #c5a059;
            /* Matching the "True" gold highlight in the image */
        }

        .description {
            font-size: 0.9rem;
            line-height: 1.6;
            color: #888;
            max-width: 80%;
            margin: 0 auto;
        }

        /* --- Form Elements --- */
        .feedback-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .form-row {
            display: flex;
            gap: 20px;
        }

        .half-width {
            flex: 1;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 0.85rem;
            margin-bottom: 8px;
            color: #aaa;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        input,
        select,
        textarea {
            background-color: #222;
            border: 1px solid #444;
            color: #fff;
            padding: 12px 15px;
            font-family: 'Montserrat', sans-serif;
            font-size: 0.95rem;
            transition: border-color 0.3s ease;
            outline: none;
        }

        input::placeholder,
        textarea::placeholder {
            color: #666;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: #c5a059;
            /* Gold border on focus */
        }

        textarea {
            resize: vertical;
        }

        /* Customizing the select dropdown slightly for dark mode */
        select option {
            background-color: #222;
            color: #fff;
        }

        /* --- Submit Button --- */
        .submit-btn {
            /* Matches the "BOOK NOW" button */
            background-color: #c5a059;
            color: #121212;
            border: none;
            padding: 16px 32px;
            font-size: 0.9rem;
            font-weight: 600;
            letter-spacing: 2px;
            text-transform: uppercase;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin-top: 10px;
            font-family: 'Montserrat', sans-serif;
            align-self: flex-start;
        }

        .submit-btn:hover {
            background-color: #dfb96b;
            transform: translateY(-2px);
        }

        /* --- Responsive Design --- */
        @media (max-width: 600px) {
            .form-row {
                flex-direction: column;
                gap: 20px;
            }

            .feedback-wrapper {
                padding: 30px 20px;
            }

            .feedback-header h2 {
                font-size: 2.2rem;
            }

            .submit-btn {
                width: 100%;
            }
        }
    </style>
</head>

<body>


    <div class="feedback-wrapper">
        <div class="feedback-header">
            <p class="subtitle">EST. 2008 — KARACHI'S PREMIER SALON</p>
            <h2>Share Your <span>Experience</span></h2>
            <p class="description">Help us continue to curate bespoke beauty experiences tailored to your individual identity.</p>
        </div>

        <form class="feedback-form" action="#" method="POST"><?= csrf_field() ?>

            <div class="form-row">
                <div class="form-group half-width">
                    <label for="client_name">Name</label>
                    <input type="text" id="client_name" name="client_name" placeholder="Jane Doe" required>
                </div>

                <div class="form-group half-width">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="jane@example.com" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group half-width">
                    <label for="service">Service Received</label>
                    <select id="service" name="service" required>
                        <option value="" disabled selected>Select a service...</option>
                        <option value="Haircut & Styling">Haircut & Styling</option>
                        <option value="Coloring">Coloring</option>
                        <option value="Spa Treatments">Spa Treatments</option>
                        <option value="Bridal Makeup">Bridal Makeup</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <div class="form-group half-width">
                    <label for="rating">Rating (1 to 5)</label>
                    <select id="rating" name="rating" required>
                        <option value="5">5 - Excellent</option>
                        <option value="4">4 - Very Good</option>
                        <option value="3">3 - Average</option>
                        <option value="2">2 - Poor</option>
                        <option value="1">1 - Terrible</option>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="message">Your Message</label>
                <textarea id="message" name="message" rows="5" placeholder="Tell us about your visit..." required></textarea>
            </div>

            <button type="submit" class="submit-btn">SUBMIT FEEDBACK</button>

        </form>
    </div>

</body>

</html>