<?php $current = basename($_SERVER['PHP_SELF']); ?>

<link rel="stylesheet" href="assets/style.css">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600&display=swap" rel="stylesheet">

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg" id="mainNav">
  <div class="container-fluid px-lg-5">
    <a class="navbar-brand" href="index.php">Elegance<span> Salon</span></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav gap-1">
        <li class="nav-item">
          <a class="nav-link <?= $current == 'index.php' ? 'active' : '' ?>" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $current == 'services.php' ? 'active' : '' ?>" href="services.php">Services</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $current == 'appointments.php' ? 'active' : '' ?>" href="appointments.php">Appointments</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?= $current == 'about.php' ? 'active' : '' ?>" href="about.php">About Us</a>
        </li>
        <li class="nav-item dropdown ms-3">
          <a class="nav-link dropdown-toggle d-flex align-items-center gap-2" href="#" role="button" data-bs-toggle="dropdown">
            <img src="img/logo.png" alt="Logo" style="height:40px; width:40px; border-radius:50%; object-fit:cover;">
          </a>
          <ul class="dropdown-menu dropdown-menu-end custom-dropdown">
            <li>
              <a class="dropdown-item" href="Login_page.php">
                <i class="bi bi-box-arrow-in-right me-2"></i> Login
              </a>
            </li>
            <li>
              <a class="dropdown-item" href="register.php">
                <i class="bi bi-person-plus me-2"></i> Register
              </a>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>