<?php
/**
 * Database connection (MySQLi).
 * Credentials come from includes/config.php (git-ignored), an optional .env file
 * in the project root, or environment variables. Falls back to config.example.php
 * (XAMPP defaults: root / blank password / salon_db).
 */
if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === basename(__FILE__)) { http_response_code(403); exit; }

require_once __DIR__ . '/security.php';

$db_config = is_file(__DIR__ . '/config.php')
    ? require __DIR__ . '/config.php'
    : require __DIR__ . '/config.example.php';

// Optional .env (KEY=VALUE lines) in the project root
$env_file = dirname(__DIR__) . '/.env';
$env_vars = [];
if (is_readable($env_file)) {
    foreach (file($env_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) continue;
        [$k, $v] = array_map('trim', explode('=', $line, 2));
        $env_vars[$k] = trim($v, "\"'");
    }
}
$env = function (string $key, $default) use ($env_vars) {
    $v = getenv($key);
    if ($v !== false && $v !== '') return $v;
    return array_key_exists($key, $env_vars) ? $env_vars[$key] : $default;
};

mysqli_report(MYSQLI_REPORT_OFF);
$conn = @mysqli_connect(
    $env('DB_HOST', $db_config['db_host']),
    $env('DB_USER', $db_config['db_user']),
    $env('DB_PASS', $db_config['db_pass']),
    $env('DB_NAME', $db_config['db_name']),
    (int) $env('DB_PORT', $db_config['db_port'] ?? 3306)
);
unset($db_config, $env_vars, $env, $env_file);

if (!$conn) {
    error_log('Elegance Salon DB connection failed: ' . mysqli_connect_error());
    die("Connection Failed");
}
mysqli_set_charset($conn, 'utf8mb4');
