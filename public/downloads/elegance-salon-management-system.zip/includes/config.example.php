<?php
/**
 * Elegance Salon - database configuration (example).
 *
 * Copy this file to includes/config.php and put your real credentials there.
 * includes/config.php is listed in .gitignore, so it is never committed.
 * If config.php is missing, these XAMPP defaults are used so the project
 * still runs out of the box on a local XAMPP install.
 *
 * Every value can also be overridden with an environment variable
 * (DB_HOST, DB_PORT, DB_USER, DB_PASS, DB_NAME), e.g. from your hosting panel
 * or a .env file in the project root (also git-ignored).
 */
if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === basename(__FILE__)) { http_response_code(403); exit; }

return [
    'db_host' => 'localhost',
    'db_port' => 3306,
    'db_user' => 'root',
    'db_pass' => '',
    'db_name' => 'salon_db',
];
