<?php
/**
 * Shared security helpers: hardened session, output escaping, CSRF protection,
 * input validation and a small prepared-statement helper.
 */
if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === basename(__FILE__)) { http_response_code(403); exit; }

if (session_status() === PHP_SESSION_NONE) {
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    ini_set('session.use_strict_mode', '1');
    session_start();
}

/** Escape a value for HTML output. */
function e($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Current CSRF token (created once per session). */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** Hidden input to place inside every POST form. */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

/** Is the supplied token valid? */
function csrf_valid(?string $token): bool
{
    return is_string($token) && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/** Stop the request with 403 unless a valid CSRF token was sent (POST body or ?csrf_token= for links). */
function csrf_verify(): void
{
    $token = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? null;
    if (!csrf_valid($token)) {
        http_response_code(403);
        exit('Invalid or missing security token. Please go back, refresh the page and try again.');
    }
}

/** Verify CSRF automatically for every POST request. */
function csrf_protect_post(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        csrf_verify();
    }
}

/* ---------- Input helpers (server-side validation) ---------- */

function input_str(array $src, string $key, int $max = 255): string
{
    $v = isset($src[$key]) && is_scalar($src[$key]) ? trim((string) $src[$key]) : '';
    return mb_substr($v, 0, $max);
}

function input_int(array $src, string $key, int $min = 0): ?int
{
    $v = filter_var($src[$key] ?? null, FILTER_VALIDATE_INT);
    return ($v === false || $v === null || $v < $min) ? null : (int) $v;
}

function input_float(array $src, string $key, float $min = 0): ?float
{
    $v = filter_var($src[$key] ?? null, FILTER_VALIDATE_FLOAT);
    return ($v === false || $v === null || $v < $min) ? null : (float) $v;
}

function input_email(array $src, string $key): ?string
{
    $v = filter_var(trim((string) ($src[$key] ?? '')), FILTER_VALIDATE_EMAIL);
    return $v === false ? null : mb_substr($v, 0, 100);
}

function input_enum(array $src, string $key, array $allowed, ?string $default = null): ?string
{
    $v = strtolower(trim((string) ($src[$key] ?? '')));
    return in_array($v, $allowed, true) ? $v : $default;
}

/** Normalise an HTML datetime-local value to MySQL DATETIME, or null if invalid. */
function input_datetime(array $src, string $key): ?string
{
    $v = trim((string) ($src[$key] ?? ''));
    foreach (['Y-m-d\TH:i', 'Y-m-d\TH:i:s', 'Y-m-d H:i', 'Y-m-d H:i:s'] as $fmt) {
        $d = DateTime::createFromFormat($fmt, $v);
        if ($d && $d->format($fmt) === $v) return $d->format('Y-m-d H:i:s');
    }
    return null;
}

function valid_phone(string $phone): bool
{
    return (bool) preg_match('/^\+?[0-9 \-]{7,20}$/', $phone);
}

/**
 * Run a prepared statement. $types is the mysqli bind string ("ssi"...).
 * Returns the mysqli_stmt on success, or false.
 */
function db_query(mysqli $conn, string $sql, string $types = '', array $params = [])
{
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        error_log('Prepare failed: ' . mysqli_error($conn));
        return false;
    }
    if ($types !== '') {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }
    if (!mysqli_stmt_execute($stmt)) {
        error_log('Execute failed: ' . mysqli_stmt_error($stmt));
        return false;
    }
    return $stmt;
}

/** Prepared SELECT returning the first row (assoc array) or null. */
function db_fetch_one(mysqli $conn, string $sql, string $types = '', array $params = []): ?array
{
    $stmt = db_query($conn, $sql, $types, $params);
    if (!$stmt) return null;
    $res = mysqli_stmt_get_result($stmt);
    $row = $res ? mysqli_fetch_assoc($res) : null;
    return $row ?: null;
}

/** Prepared SELECT returning a mysqli_result (iterate with mysqli_fetch_assoc). */
function db_select(mysqli $conn, string $sql, string $types = '', array $params = [])
{
    $stmt = db_query($conn, $sql, $types, $params);
    return $stmt ? mysqli_stmt_get_result($stmt) : false;
}

/** Safe JS alert + optional redirect (message is JSON-encoded, so it cannot break out of the script). */
function js_alert(string $message, ?string $redirect = null): void
{
    echo '<script>alert(' . json_encode($message, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ');'
        . ($redirect !== null ? 'window.location=' . json_encode($redirect, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT) . ';' : '')
        . '</script>';
}
