<!-- FOOTER -->
  <footer>
    <div class="container-fluid px-lg-5">
      <div class="row g-5 mb-4">
        <div class="col-lg-4">
          <div class="footer-brand">Elegance<span> Salon</span></div>
          <div class="footer-tagline">Redefine Beautiful</div>
          <p style="color:var(--text-muted-light);font-size:0.85rem;line-height:1.8;margin-top:1.5rem;max-width:280px;">Where artistry meets luxury — crafting beauty experiences that transcend the ordinary.</p>
          <div class="social-icons">
            <a href="#" class="social-icon"><i class="bi bi-instagram"></i></a>
            <a href="#" class="social-icon"><i class="bi bi-facebook"></i></a>
            <a href="#" class="social-icon"><i class="bi bi-tiktok"></i></a>
            <a href="#" class="social-icon"><i class="bi bi-pinterest"></i></a>
          </div>
        </div>
        <div class="col-sm-4 col-lg-2">
          <div class="footer-heading">Navigation</div>
          <ul class="footer-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a href="appointments.php">Appointments</a></li>
            <li><a href="about.php">About Us</a></li>
          </ul>
        </div>
        <div class="col-sm-4 col-lg-2">
          <div class="footer-heading">Services</div>
          <ul class="footer-links">
            <li><a href="#">Hair Styling</a></li>
            <li><a href="#">Skin Care</a></li>
            <li><a href="#">Nail Art</a></li>
            <li><a href="#">Bridal</a></li>
          </ul>
        </div>
        <div class="col-sm-4 col-lg-4">
          <div class="footer-heading">Visit Us</div>
          <ul class="footer-links">
            <li><a href="#"><i class="bi bi-geo-alt me-2"></i>12 Zamzama Blvd, DHA Phase 5, Karachi</a></li>
            <li><a href="tel:+922135000000"><i class="bi bi-telephone me-2"></i>+92 21 3500-0000</a></li>
            <li><a href="mailto:hello@elegancesalon.pk"><i class="bi bi-envelope me-2"></i>hello@elegancesalon.pk</a></li>
            <li><i class="bi bi-clock me-2"></i><span style="color:var(--text-muted-light);">Mon–Sat: 10am – 8pm</span></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <p>© 2024 Elegance Salon. All rights reserved.</p>
        <p>Designed with <span style="color:var(--gold);">♥</span> for beauty lovers</p>
      </div>
    </div>
  </footer>