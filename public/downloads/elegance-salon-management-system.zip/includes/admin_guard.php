<?php
/**
 * Admin auth guard - include at the very top of every page/handler in Admin/.
 *
 *   $allowed_roles = ['admin'];            // optional, set BEFORE including
 *   require_once __DIR__ . '/../includes/admin_guard.php';
 *
 * - Requires a logged-in, active staff account (admin / receptionist / stylist).
 * - Enforces the page's allowed roles (defaults to all staff roles).
 * - Verifies the CSRF token on every POST request.
 */
if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === basename(__FILE__)) { http_response_code(403); exit; }

require_once __DIR__ . '/connection.php';

$allowed_roles = $allowed_roles ?? ['admin', 'receptionist', 'stylist'];

if (empty($_SESSION['user_id']) || empty($_SESSION['role'])) {
    header('Location: ../Login_page.php');
    exit();
}

// Re-check the account on every request (deleted / deactivated users are logged out)
$guard_user = db_fetch_one($conn, 'SELECT id, role, is_active FROM users WHERE id = ?', 'i', [(int) $_SESSION['user_id']]);
if ($guard_user && $guard_user['role'] === 'user' && (int) $guard_user['is_active'] === 1) {
    // Customers stay logged in but cannot open the back office
    header('Location: ../index.php');
    exit();
}
if (!$guard_user || (int) $guard_user['is_active'] !== 1) {
    $_SESSION = [];
    session_destroy();
    header('Location: ../Login_page.php');
    exit();
}
$_SESSION['role'] = $guard_user['role'];

if (!in_array($_SESSION['role'], $allowed_roles, true)) {
    header('Location: dashboard.php');
    exit();
}
unset($guard_user);

// Idle timeout: 30 minutes
if (isset($_SESSION['last_activity']) && time() - $_SESSION['last_activity'] > 1800) {
    $_SESSION = [];
    session_destroy();
    header('Location: ../Login_page.php');
    exit();
}
$_SESSION['last_activity'] = time();

csrf_protect_post();
