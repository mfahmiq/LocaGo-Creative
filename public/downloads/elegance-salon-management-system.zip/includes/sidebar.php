<?php 
// 1. Ensure the session is started to access user roles
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$current = basename($_SERVER['PHP_SELF']); 

// 2. Get the role from the session (default to empty if not logged in)
$role = $_SESSION['role'] ?? ''; 
?>

<nav id='sidebar'>
    <div class='sidebar-header'>
        <h3>Elegance Admin</h3>
    </div>

    <div class='section-label'>Main</div>
    <a href='dashboard.php' class='nav-link <?= $current == "dashboard.php" ? "active" : "" ?>'>
        <i class='fas fa-th-large'></i> Dashboard
    </a>

    <?php if ($role == 'admin'): ?>
        <div class='section-label'>Personnel</div>
        <a href='users.php' class='nav-link <?= $current == "users.php" ? "active" : "" ?>'>
            <i class='fas fa-users-cog'></i> Manage Users
        </a>
        <a href='staff.php' class='nav-link <?= $current == "staff.php" ? "active" : "" ?>'>
            <i class='fas fa-scissors'></i> Manage Staff
        </a>
    <?php endif; ?>

    <div class='section-label'>Operations</div>
    <?php if ($role == 'admin' || $role == 'receptionist'): ?>
        <a href='clients.php' class='nav-link <?= $current == "clients.php" ? "active" : "" ?>'>
            <i class='fas fa-user-friends'></i> Manage Clients
        </a>
        <a href='commissions.php' class='nav-link <?= $current == "commissions.php" ? "active" : "" ?>'>
            <i class='fas fa-hand-holding-usd'></i> Commissions
    <?php endif; ?>
    
    <a href='services.php' class='nav-link <?= $current == "services.php" ? "active" : "" ?>'>
        <i class='fas fa-spa'></i> Manage Services
    </a>
    
    <a href='appointment.php' class='nav-link <?= $current == "appointment.php" ? "active" : "" ?>'>
        <i class='fas fa-calendar-check'></i> Appointments
    </a>

    <?php if ($role == 'admin' || $role == 'receptionist'): ?>
        <div class='section-label'>Inventory & Logistics</div>
        <a href='inventory.php' class='nav-link <?= $current == "inventory.php" ? "active" : "" ?>'>
            <i class='fas fa-boxes'></i> Inventory
        </a>
        <a href='suppliers.php' class='nav-link <?= $current == "suppliers.php" ? "active" : "" ?>'>
            <i class='fas fa-truck'></i> Suppliers
        </a>
    <?php endif; ?>

    <?php if ($role == 'admin'): ?>
        <div class='section-label'>Financials</div>
        <a href='payments.php' class='nav-link <?= $current == "payments.php" ? "active" : "" ?>'>
            <i class='fas fa-wallet'></i> Payments
        </a>
        <a href='invoices.php' class='nav-link <?= $current == "invoices.php" ? "active" : "" ?>'>
            <i class='fas fa-file-invoice'></i> Invoices
        </a>
        <a href='reports.php' class='nav-link <?= $current == "reports.php" ? "active" : "" ?>'>
            <i class='fas fa-chart-line'></i> Reports
        </a>
    <?php endif; ?>

    <div class='section-label'>Feedback</div>
    <a href='feedback.php' class='nav-link <?= $current == "feedback.php" ? "active" : "" ?>'>
        <i class='fas fa-comment-dots'></i> View Feedback
    </a>
</nav>