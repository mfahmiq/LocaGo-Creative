<?php
require_once __DIR__ . '/includes/connection.php';

// 1. Fetch Services for the dropdown
$services_result = mysqli_query($conn, "SELECT id, name, price FROM services");

// 2. Fetch Staff for the dropdown
$staff_result = mysqli_query($conn, "SELECT id, name FROM staff");

// 3. Handle Form Submission
if (isset($_POST['submit_booking'])) {
    csrf_verify();

    $full_name  = input_str($_POST, 'full_name', 255);
    $email      = input_email($_POST, 'email');
    $phone      = input_str($_POST, 'phone', 20);
    $service_id = input_int($_POST, 'service_id', 1);
    $staff_id   = input_int($_POST, 'staff_id', 1);
    $date_time  = input_datetime($_POST, 'date_time');
    $notes      = input_str($_POST, 'notes', 2000);

    // Server-side validation
    $service = $service_id ? db_fetch_one($conn, "SELECT price FROM services WHERE id = ?", 'i', [$service_id]) : null;
    if ($staff_id && !db_fetch_one($conn, "SELECT id FROM staff WHERE id = ?", 'i', [$staff_id])) {
        $staff_id = null;
    }
    if ($full_name === '' || !$email || !valid_phone($phone) || !$service || !$date_time) {
        js_alert('Please fill in all fields correctly (name, valid email, phone, service and date/time).', 'appointments.php');
        exit();
    }

    // Get price from services table based on selection
    $total_amount = $service['price'];

    // STEP A: Check if this person is already a client
    $client_row = db_fetch_one($conn, "SELECT id FROM clients WHERE email = ?", 's', [$email]);

    if ($client_row) {
        $client_id = (int) $client_row['id'];
    } else {
        // STEP B: If not a client, insert them
        db_query($conn, "INSERT INTO clients (name, email, phone) VALUES (?, ?, ?)", 'sss', [$full_name, $email, $phone]);
        $client_id = mysqli_insert_id($conn);
    }

    // STEP C: Insert the Appointment
    $ok = db_query($conn, "INSERT INTO appointments (client_id, service_id, staff_id, date_time, status, total_amount, notes) VALUES (?, ?, ?, ?, 'pending', ?, ?)",
        'iiisds', [$client_id, $service_id, $staff_id, $date_time, $total_amount, $notes]);

    // Check if appointment insert was successful
    if ($ok) {

        // Get the ID of the appointment we just created
        $appointment_id = mysqli_insert_id($conn);

        // STEP D: Insert into the payments table (unpaid until the visit)
        $pay_ok = db_query($conn, "INSERT INTO payments (appointment_id, amount, payment_method, status, paid_at, notes) VALUES (?, ?, 'cash', 'pending', NULL, 'Automated entry')",
            'id', [$appointment_id, $total_amount]);

        if ($pay_ok) {
            js_alert('Success! Appointment and Payment record created.', 'appointments.php');
            exit();
        } else {
            js_alert('Your appointment was saved, but the payment record could not be created. Please contact us.', 'appointments.php');
            exit();
        }

    } else {
        js_alert('Sorry, the appointment could not be booked. Please try again.', 'appointments.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Book Appointment — Elegance Salon</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Jost:wght@200;300;400;500&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
  <link rel="stylesheet" href="assets/style.css" />
  <link rel="stylesheet" href="assets/main.js" />
  <style>
    :root {
      --charcoal: #141414;
      --charcoal-mid: #1e1e1e;
      --charcoal-light: #2a2a2a;
      --gold: #c9a84c;
      --gold-light: #e2c97e;
      --gold-dim: rgba(201, 168, 76, 0.15);
      --cream: #f5f0e8;
      --text-muted-light: #9a9a9a;
      --transition: 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
      --error: #e57373;
      --success: #81c784;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      background-color: var(--charcoal);
      color: var(--cream);
      font-family: 'Jost', sans-serif;
      font-weight: 300;
      overflow-x: hidden;
    }

    h1,
    h2,
    h3,
    h4,
    h5 {
      font-family: 'Cormorant Garamond', serif;
    }

    ::selection {
      background: var(--gold);
      color: var(--charcoal);
    }

    /* NAVBAR */
    .navbar {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
      padding: 1rem 3rem;
      background: rgba(20, 20, 20, 0.97);
      backdrop-filter: blur(20px);
      border-bottom: 1px solid rgba(201, 168, 76, 0.2);
    }

    .navbar-brand {
      font-family: 'Cormorant Garamond', serif;
      font-size: 1.8rem;
      font-weight: 600;
      color: var(--gold) !important;
      text-decoration: none;
    }

    .navbar-brand span {
      color: var(--cream);
      font-weight: 300;
    }

    .nav-link {
      color: var(--cream) !important;
      font-size: 0.78rem;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      padding: 0.5rem 1.2rem !important;
      transition: color var(--transition);
      position: relative;
    }

    .nav-link::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 1.2rem;
      right: 1.2rem;
      height: 1px;
      background: var(--gold);
      transform: scaleX(0);
      transition: transform var(--transition);
    }

    .nav-link:hover::after,
    .nav-link.active::after {
      transform: scaleX(1);
    }

    .nav-link:hover,
    .nav-link.active {
      color: var(--gold) !important;
    }

    .navbar-toggler {
      border: 1px solid var(--gold);
    }

    .navbar-toggler-icon {
      filter: invert(1);
    }

    /* PAGE HERO */
    .page-hero {
      padding: 10rem 0 5rem;
      position: relative;
      overflow: hidden;
      text-align: center;
    }

    .page-hero::before {
      content: '';
      position: absolute;
      inset: 0;
      background: radial-gradient(ellipse 80% 60% at 50% 100%, rgba(201, 168, 76, 0.08) 0%, transparent 70%);
    }

    .page-hero-label {
      font-size: 0.65rem;
      letter-spacing: 0.5em;
      text-transform: uppercase;
      color: var(--gold);
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 1rem;
    }

    .page-hero-label::before,
    .page-hero-label::after {
      content: '';
      width: 30px;
      height: 1px;
      background: var(--gold);
      display: block;
    }

    .page-hero h1 {
      font-size: clamp(3rem, 6vw, 5.5rem);
      font-weight: 300;
      margin-bottom: 1.5rem;
    }

    .page-hero h1 em {
      color: var(--gold);
      font-style: italic;
    }

    .page-hero p {
      color: var(--text-muted-light);
      font-size: 1rem;
      max-width: 550px;
      margin: 0 auto;
      line-height: 1.9;
    }

    /* BOOKING SECTION */
    .booking-section {
      padding: 4rem 0 8rem;
    }

    /* STEPS */
    .steps-bar {
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 4rem;
      gap: 0;
    }

    .step {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.5rem;
      position: relative;
      flex: 1;
      max-width: 140px;
    }

    .step-num {
      width: 40px;
      height: 40px;
      border: 1px solid rgba(201, 168, 76, 0.3);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.75rem;
      letter-spacing: 0.1em;
      color: var(--text-muted-light);
      transition: var(--transition);
      background: var(--charcoal);
      position: relative;
      z-index: 2;
    }

    .step.active .step-num,
    .step.done .step-num {
      border-color: var(--gold);
      color: var(--charcoal);
      background: var(--gold);
    }

    .step-label {
      font-size: 0.65rem;
      letter-spacing: 0.15em;
      text-transform: uppercase;
      color: var(--text-muted-light);
      text-align: center;
    }

    .step.active .step-label {
      color: var(--gold);
    }

    .step-line {
      flex: 1;
      height: 1px;
      background: rgba(201, 168, 76, 0.2);
      margin: 0 0.5rem;
      margin-bottom: 1.5rem;
      transition: background var(--transition);
    }

    .step-line.done {
      background: var(--gold);
    }

    /* FORM CARD */
    .form-card {
      background: var(--charcoal-mid);
      border: 1px solid rgba(201, 168, 76, 0.12);
      padding: 3rem;
    }

    /* FORM STEPS */
    .form-step {
      display: none;
    }

    .form-step.active {
      display: block;
    }

    /* FORM ELEMENTS */
    .form-group {
      margin-bottom: 1.8rem;
    }

    .form-label-custom {
      font-size: 0.68rem;
      letter-spacing: 0.25em;
      text-transform: uppercase;
      color: var(--gold);
      display: block;
      margin-bottom: 0.7rem;
    }

    .form-input {
      width: 100%;
      background: transparent;
      border: none;
      border-bottom: 1px solid rgba(201, 168, 76, 0.2);
      color: var(--cream);
      font-family: 'Jost', sans-serif;
      font-size: 0.95rem;
      font-weight: 300;
      padding: 0.8rem 0;
      transition: border-color var(--transition);
      outline: none;
    }

    .form-input:focus {
      border-bottom-color: var(--gold);
    }

    .form-input::placeholder {
      color: var(--text-muted-light);
      font-size: 0.87rem;
    }

    .form-input option {
      background: var(--charcoal-mid);
      color: var(--cream);
    }

    .form-input.error {
      border-bottom-color: var(--error);
    }

    .error-msg {
      font-size: 0.72rem;
      color: var(--error);
      margin-top: 0.4rem;
      display: none;
    }

    .error-msg.show {
      display: block;
    }

    /* SERVICE PICKER */
    .service-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 1rem;
      margin-top: 0.5rem;
    }

    .service-pick {
      border: 1px solid rgba(201, 168, 76, 0.12);
      padding: 1.2rem;
      cursor: pointer;
      transition: var(--transition);
      position: relative;
    }

    .service-pick:hover {
      border-color: rgba(201, 168, 76, 0.4);
    }

    .service-pick.selected {
      border-color: var(--gold);
      background: var(--gold-dim);
    }

    .service-pick input {
      position: absolute;
      opacity: 0;
      pointer-events: none;
    }

    .service-pick-name {
      font-family: 'Cormorant Garamond', serif;
      font-size: 1.1rem;
      display: block;
      margin-bottom: 0.3rem;
    }

    .service-pick-price {
      font-size: 0.72rem;
      color: var(--gold);
      letter-spacing: 0.1em;
    }

    .service-check {
      position: absolute;
      top: 0.8rem;
      right: 0.8rem;
      width: 18px;
      height: 18px;
      border: 1px solid rgba(201, 168, 76, 0.3);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.6rem;
      color: transparent;
      transition: var(--transition);
    }

    .service-pick.selected .service-check {
      background: var(--gold);
      border-color: var(--gold);
      color: var(--charcoal);
    }

    /* TIME SLOTS */
    .time-slots {
      display: flex;
      flex-wrap: wrap;
      gap: 0.8rem;
      margin-top: 0.5rem;
    }

    .time-slot {
      border: 1px solid rgba(201, 168, 76, 0.15);
      padding: 0.6rem 1.2rem;
      font-size: 0.78rem;
      cursor: pointer;
      transition: var(--transition);
      color: var(--text-muted-light);
    }

    .time-slot:hover:not(.unavailable) {
      border-color: rgba(201, 168, 76, 0.4);
      color: var(--cream);
    }

    .time-slot.selected {
      border-color: var(--gold);
      color: var(--gold);
      background: var(--gold-dim);
    }

    .time-slot.unavailable {
      opacity: 0.3;
      cursor: not-allowed;
      text-decoration: line-through;
    }

    /* STYLIST CARDS */
    .stylist-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
      gap: 1rem;
    }

    .stylist-card {
      border: 1px solid rgba(201, 168, 76, 0.12);
      padding: 1.5rem 1rem;
      text-align: center;
      cursor: pointer;
      transition: var(--transition);
      position: relative;
    }

    .stylist-card:hover {
      border-color: rgba(201, 168, 76, 0.35);
    }

    .stylist-card.selected {
      border-color: var(--gold);
      background: var(--gold-dim);
    }

    .stylist-avatar {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      border: 1px solid rgba(201, 168, 76, 0.3);
      margin: 0 auto 0.8rem;
      background: var(--charcoal-light);
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Cormorant Garamond', serif;
      font-size: 1.4rem;
      color: var(--gold);
    }

    .stylist-name {
      font-size: 0.82rem;
      font-weight: 400;
      letter-spacing: 0.05em;
    }

    .stylist-role {
      font-size: 0.65rem;
      color: var(--text-muted-light);
      letter-spacing: 0.1em;
      text-transform: uppercase;
      margin-top: 0.2rem;
    }

    /* NAVIGATION BUTTONS */
    .form-nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 2.5rem;
      padding-top: 2rem;
      border-top: 1px solid rgba(201, 168, 76, 0.1);
    }

    .btn-gold {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      background: var(--gold);
      color: var(--charcoal);
      font-family: 'Jost', sans-serif;
      font-weight: 500;
      font-size: 0.75rem;
      letter-spacing: 0.25em;
      text-transform: uppercase;
      padding: 0.9rem 2rem;
      text-decoration: none;
      transition: var(--transition);
      border: 1px solid var(--gold);
      cursor: pointer;
    }

    .btn-gold:hover {
      background: transparent;
      color: var(--gold);
    }

    .btn-back {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      background: transparent;
      color: var(--text-muted-light);
      font-family: 'Jost', sans-serif;
      font-size: 0.75rem;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      border: none;
      cursor: pointer;
      transition: color var(--transition);
      padding: 0;
    }

    .btn-back:hover {
      color: var(--gold);
    }

    /* SUMMARY */
    .summary-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 0;
      border-bottom: 1px solid rgba(201, 168, 76, 0.08);
    }

    .summary-label {
      font-size: 0.68rem;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      color: var(--text-muted-light);
    }

    .summary-value {
      font-family: 'Cormorant Garamond', serif;
      font-size: 1.1rem;
      color: var(--cream);
    }

    .summary-total {
      font-size: 1.5rem;
      color: var(--gold);
    }

    /* CONFIRMATION */
    .confirmation-wrap {
      display: none;
      text-align: center;
      padding: 3rem;
    }

    .confirmation-wrap.show {
      display: block;
    }

    .confirm-icon {
      width: 80px;
      height: 80px;
      border: 2px solid var(--gold);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 2.5rem;
      color: var(--gold);
      margin: 0 auto 2rem;
      animation: pulse 1s ease;
    }

    @keyframes pulse {
      0% {
        transform: scale(0);
        opacity: 0;
      }

      70% {
        transform: scale(1.1);
      }

      100% {
        transform: scale(1);
        opacity: 1;
      }
    }

    .confirm-title {
      font-size: 2.5rem;
      font-weight: 300;
      margin-bottom: 1rem;
    }

    .confirm-title em {
      color: var(--gold);
      font-style: italic;
    }

    .confirm-ref {
      font-size: 0.8rem;
      letter-spacing: 0.3em;
      text-transform: uppercase;
      color: var(--text-muted-light);
      margin-bottom: 2rem;
    }

    .confirm-details {
      background: var(--charcoal-light);
      border: 1px solid rgba(201, 168, 76, 0.15);
      padding: 2rem;
      max-width: 400px;
      margin: 0 auto 2.5rem;
      text-align: left;
    }

    .confirm-detail-row {
      display: flex;
      justify-content: space-between;
      padding: 0.6rem 0;
      border-bottom: 1px solid rgba(255, 255, 255, 0.04);
      font-size: 0.85rem;
    }

    .confirm-detail-row:last-child {
      border: none;
    }

    .confirm-detail-row span:first-child {
      color: var(--text-muted-light);
      font-size: 0.75rem;
      letter-spacing: 0.1em;
    }

    .confirm-detail-row span:last-child {
      color: var(--cream);
    }

    /* SIDEBAR INFO */
    .info-panel {
      background: var(--charcoal-mid);
      border: 1px solid rgba(201, 168, 76, 0.12);
      padding: 2.5rem;
      height: fit-content;
    }

    .info-panel h4 {
      font-size: 1.5rem;
      font-weight: 300;
      margin-bottom: 0.5rem;
    }

    .info-panel h4 em {
      color: var(--gold);
      font-style: italic;
    }

    .info-item {
      display: flex;
      gap: 1rem;
      margin-bottom: 1.5rem;
    }

    .info-icon {
      color: var(--gold);
      font-size: 1rem;
      margin-top: 0.1rem;
      flex-shrink: 0;
    }

    .info-text strong {
      display: block;
      font-size: 0.8rem;
      letter-spacing: 0.1em;
      color: var(--cream);
      font-weight: 400;
      margin-bottom: 0.2rem;
    }

    .info-text span {
      font-size: 0.8rem;
      color: var(--text-muted-light);
      line-height: 1.7;
    }

    .policy-box {
      background: var(--gold-dim);
      border: 1px solid rgba(201, 168, 76, 0.2);
      padding: 1.5rem;
      margin-top: 2rem;
    }

    .policy-box p {
      font-size: 0.78rem;
      color: var(--text-muted-light);
      line-height: 1.7;
      margin: 0;
    }

    /* FOOTER */
    footer {
      background: #0e0e0e;
      padding: 5rem 0 2rem;
      border-top: 1px solid rgba(201, 168, 76, 0.1);
    }

    .footer-brand {
      font-family: 'Cormorant Garamond', serif;
      font-size: 2rem;
      font-weight: 600;
      color: var(--gold);
    }

    .footer-brand span {
      color: var(--cream);
      font-weight: 300;
    }

    .footer-tagline {
      font-size: 0.75rem;
      letter-spacing: 0.25em;
      text-transform: uppercase;
      color: var(--text-muted-light);
      margin-top: 0.5rem;
    }

    .footer-heading {
      font-size: 0.65rem;
      letter-spacing: 0.3em;
      text-transform: uppercase;
      color: var(--gold);
      margin-bottom: 1.5rem;
    }

    .footer-links {
      list-style: none;
      padding: 0;
    }

    .footer-links li {
      margin-bottom: 0.8rem;
    }

    .footer-links a {
      color: var(--text-muted-light);
      text-decoration: none;
      font-size: 0.87rem;
      transition: color var(--transition);
    }

    .footer-links a:hover {
      color: var(--gold);
    }

    .social-icons {
      display: flex;
      gap: 0.8rem;
      margin-top: 1.5rem;
    }

    .social-icon {
      width: 38px;
      height: 38px;
      border: 1px solid rgba(201, 168, 76, 0.25);
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--text-muted-light);
      text-decoration: none;
      font-size: 0.9rem;
      transition: var(--transition);
    }

    .social-icon:hover {
      border-color: var(--gold);
      color: var(--gold);
    }

    .footer-bottom {
      border-top: 1px solid rgba(255, 255, 255, 0.05);
      padding-top: 2rem;
      margin-top: 3rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 1rem;
    }

    .footer-bottom p {
      font-size: 0.75rem;
      color: var(--text-muted-light);
      margin: 0;
    }

    @media (max-width:991px) {
      .navbar {
        padding: 1rem 1.5rem;
      }

      .form-card {
        padding: 2rem 1.5rem;
      }
    }
  </style>
</head>

<body>

  <?php include "includes/header.php"; ?>

  <!-- PAGE HERO -->
  <section class="page-hero">
    <div class="page-hero-label">Reserve Your Visit</div>
    <h1>Book Your <em>Appointment</em></h1>
    <p>Reserve your place at Elegance Salon in just a few steps. We'll confirm your booking and send all details to your inbox.</p>
  </section>

  <!-- BOOKING -->
  <section class="booking-section">
    <div class="container-fluid px-lg-5">
      <div class="row g-5">
        <div class="col-lg-8">

          <!-- FORM CARD -->
          <div class="form-card" id="formCard">
            <form action="appointments.php" method="POST" class="p-2"><?= csrf_field() ?>
              <h3 class="mb-4">Book Your <em style="color:var(--gold); font-style:italic;">Visit</em></h3>

              <div class="row">
                <div class="col-md-4 mb-3">
                  <label class="form-label-custom">Full Name</label>
                  <input type="text" name="full_name" class="form-input" required placeholder="John Doe">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label-custom">Email Address</label>
                  <input type="email" name="email" class="form-input" required placeholder="john@example.com">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label-custom">Phone Number</label>
                  <input type="text" name="phone" class="form-input" required placeholder="0300-1234567">
                </div>

                <div class="col-md-6 mb-3">
                  <label class="form-label-custom">Select Service</label>
                  <select name="service_id" class="form-input" required>
                    <option value="">-- Choose Service --</option>
                    <?php while ($service = mysqli_fetch_assoc($services_result)): ?>
                      <option value="<?php echo e($service['id']); ?>">
                        <?php echo e($service['name']); ?> (Rs. <?php echo number_format($service['price']); ?>)
                      </option>
                    <?php endwhile; ?>
                  </select>
                </div>

                <div class="col-md-6 mb-3">
                  <label class="form-label-custom">Select Stylist</label>
                  <select name="staff_id" class="form-input" required>
                    <option value="">-- Choose Stylist --</option>
                    <?php while ($staff = mysqli_fetch_assoc($staff_result)): ?>
                      <option value="<?php echo e($staff['id']); ?>">
                        <?php echo e($staff['name']); ?>
                      </option>
                    <?php endwhile; ?>
                  </select>
                </div>

                <div class="col-md-6 mb-3">
                  <label class="form-label-custom">Date & Time</label>
                  <input type="datetime-local" name="date_time" class="form-input" required>
                </div>

                <div class="col-12 mb-4">
                  <label class="form-label-custom">Notes</label>
                  <textarea name="notes" class="form-input" rows="2"></textarea>
                </div>
              </div>

              <button type="submit" name="submit_booking" class="btn-gold w-100">
                Confirm & Register as Client
              </button>
            </form>

          </div>
        </div>

        <!-- SIDEBAR -->
        <div class="col-lg-4">
          <div class="info-panel">
            <h4>Before You <em>Arrive</em></h4>
            <p style="color:var(--text-muted-light);font-size:0.83rem;line-height:1.8;margin:1rem 0 2rem;">Everything you need to know to prepare for your visit.</p>
            <div class="info-item">
              <i class="bi bi-clock info-icon"></i>
              <div class="info-text"><strong>Arrive Early</strong><span>Please arrive 10 minutes before your appointment for a relaxed check-in.</span></div>
            </div>
            <div class="info-item">
              <i class="bi bi-x-circle info-icon"></i>
              <div class="info-text"><strong>Cancellation Policy</strong><span>Cancel or reschedule at least 24 hours in advance to avoid a cancellation fee.</span></div>
            </div>
            <div class="info-item">
              <i class="bi bi-cup-hot info-icon"></i>
              <div class="info-text"><strong>Complimentary Refresh</strong><span>Enjoy complimentary tea, coffee, or water during your visit.</span></div>
            </div>
            <div class="info-item">
              <i class="bi bi-telephone info-icon"></i>
              <div class="info-text"><strong>Need Help?</strong><span>Call us at +92 21 3500-0000, Mon–Sat 10am–8pm.</span></div>
            </div>
            <div class="policy-box">
              <p><i class="bi bi-geo-alt me-2" style="color:var(--gold);"></i>12 Zamzama Blvd, DHA Phase 5, Karachi. Free parking available on-site.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  

  <!-- FOOTER -->
  <?php include "includes/footer.php"; ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>