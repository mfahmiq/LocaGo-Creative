-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2026 at 04:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `salon_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `service_id` int(11) NOT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `date_time` datetime NOT NULL,
  `status` enum('pending','confirmed','completed','cancelled','no_show') DEFAULT 'pending',
  `total_amount` decimal(10,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `client_id`, `service_id`, `staff_id`, `date_time`, `status`, `total_amount`, `notes`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 2, '2026-04-22 21:50:00', 'completed', 3500.00, '', '2026-04-16 22:46:40', '2026-04-20 19:00:56'),
(2, 5, 5, 4, '2026-04-20 15:00:00', 'pending', 6500.00, '', '2026-04-16 22:51:51', '2026-04-16 22:51:51'),
(3, 6, 9, 2, '2026-04-23 12:50:00', 'completed', 4000.00, '', '2026-04-18 19:48:42', '2026-04-20 13:32:11'),
(4, 7, 4, 2, '2026-04-24 12:30:00', 'completed', 1800.00, '', '2026-04-18 19:50:39', '2026-04-20 13:32:20'),
(5, 8, 4, 1, '2026-04-20 16:00:00', 'pending', 1800.00, '', '2026-04-18 19:54:34', '2026-04-18 19:54:34'),
(6, 9, 5, 3, '2026-04-22 12:55:00', 'completed', 6500.00, '', '2026-04-18 19:55:53', '2026-04-20 19:04:00'),
(9, 11, 3, 2, '2026-04-20 15:10:00', 'completed', 4500.00, '', '2026-04-18 20:10:38', '2026-04-20 13:32:16'),
(11, 12, 6, 2, '2026-05-06 17:20:00', 'completed', 25000.00, '', '2026-04-18 20:11:58', '2026-04-20 13:30:01'),
(13, 13, 2, 2, '2026-04-30 14:20:00', 'completed', 12000.00, '', '2026-04-18 20:14:32', '2026-04-20 13:30:07'),
(14, 14, 5, 3, '2026-05-09 14:30:00', 'completed', 6500.00, '', '2026-04-18 21:26:41', '2026-04-20 19:03:49'),
(15, 15, 6, 2, '2026-04-30 19:30:00', 'completed', 25000.00, '', '2026-04-20 13:29:38', '2026-04-20 13:30:04'),
(16, 16, 7, 2, '2026-04-27 19:45:00', 'completed', 9000.00, '', '2026-04-20 13:44:54', '2026-04-20 19:01:11'),
(17, 6, 6, 2, '2026-04-13 18:01:00', 'completed', 25000.00, '', '2026-04-20 13:53:14', '2026-04-20 19:01:27');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `phone`, `email`, `notes`, `created_at`) VALUES
(1, 'Aisha', '+923001234571', 'aisha@example.com', NULL, '2026-04-05 16:01:29'),
(2, 'Sara Ahmed', '+923001234572', 'sara@example.com', NULL, '2026-04-05 16:01:29'),
(4, 'Aliyan', '03000000001', 'aliyan@example.com', NULL, '2026-04-07 14:31:49'),
(5, 'areeb', '12312312312', 'areeb@example.com', NULL, '2026-04-16 22:51:51'),
(6, 'Areeb', '03000000003', 'areeb.demo@example.com', NULL, '2026-04-18 19:48:42'),
(7, 'john', '12312312312', 'john12@example.com', NULL, '2026-04-18 19:50:39'),
(8, 'affan', '12345678911', 'affan@example.com', NULL, '2026-04-18 19:54:34'),
(9, 'dan', '12312312314', 'dan@example.com', NULL, '2026-04-18 19:55:53'),
(10, 'rida', '12345678911', 'rida1@example.com', NULL, '2026-04-18 20:04:36'),
(11, 'sara', '03000000002', 'sara@example.com', NULL, '2026-04-18 20:10:38'),
(12, 'zara', '12345678911', 'zara@example.com', NULL, '2026-04-18 20:11:58'),
(13, 'arash', '12345678915', 'arash@example.com', NULL, '2026-04-18 20:14:32'),
(14, 'test', '12345678913', 'test@example.com', NULL, '2026-04-18 21:26:41'),
(15, 'example', '12345678987', 'example12@example.com', NULL, '2026-04-20 13:29:38'),
(16, 'sara', '12345678911', 'sara12@example.com', NULL, '2026-04-20 13:44:54');

-- --------------------------------------------------------

--
-- Stand-in structure for view `dashboard_stats`
-- (See below for the actual view)
--
CREATE TABLE `dashboard_stats` (
`pending_appointments` bigint(21)
,`today_appointments` bigint(21)
,`total_clients` bigint(21)
,`low_stock_items` bigint(21)
);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `service` varchar(100) DEFAULT NULL,
  `rating` tinyint(4) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `client_name`, `email`, `service`, `rating`, `message`, `created_at`) VALUES
(1, 'example', 'user@example.com', 'Haircut & Styling', 5, 'very good', '2026-04-14 23:34:12'),
(2, 'example2', 'user2@example.com', 'Spa Treatments', 4, 'test', '2026-04-14 23:39:20'),
(3, 'example2', 'user2@example.com', 'Spa Treatments', 4, 'test', '2026-04-14 23:42:34'),
(4, 'example2', 'user2@example.com', 'Spa Treatments', 4, 'test', '2026-04-14 23:43:23'),
(5, 'example2', 'user2@example.com', 'Spa Treatments', 4, 'test', '2026-04-14 23:43:23'),
(6, 'example2', 'user2@example.com', 'Spa Treatments', 4, 'test', '2026-04-14 23:43:42'),
(7, 'example2', 'user2@example.com', 'Spa Treatments', 4, 'test', '2026-04-14 23:43:42');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `quantity` int(11) DEFAULT 0,
  `low_stock_threshold` int(11) DEFAULT 10,
  `cost_price` decimal(10,2) DEFAULT NULL,
  `supplier` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `name`, `sku`, `quantity`, `low_stock_threshold`, `cost_price`, `supplier`, `created_at`, `updated_at`) VALUES
(1, 'OPI Nail Polish', 'OPI-RED001', 5, 10, 450.00, 'Cosmetic Distributors', '2026-04-05 16:01:29', '2026-04-20 13:26:25'),
(2, 'Keratin Treatment Kit', 'KER-001', 8, 10, 2500.00, 'BeautyCorp', '2026-04-05 16:01:29', '2026-04-20 13:26:36'),
(3, 'Vitamin C Serum', 'VCS-100ML', 15, 10, 1200.00, 'Skincare Ltd', '2026-04-05 16:01:29', '2026-04-05 16:01:29'),
(4, 'HD Hair Spray', 'HD-HRSY001', 18, 5, 650.00, 'HD Cosmetics', '2026-04-20 19:07:01', '2026-04-20 19:07:12');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `client_name` varchar(100) DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `client_name`, `invoice_date`, `total_amount`, `status`) VALUES
(1, 'example', '2026-04-20', 18000.00, 'PAID');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `appointment_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` enum('cash','card','bank_transfer','online') DEFAULT 'cash',
  `status` enum('pending','paid','partial','refunded') DEFAULT 'paid',
  `paid_at` timestamp NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `appointment_id`, `amount`, `payment_method`, `status`, `paid_at`, `notes`, `created_at`) VALUES
(1, 9, 4500.00, 'cash', 'paid', NULL, 'Automated entry from booking', '2026-04-18 20:10:38'),
(2, 11, 25000.00, 'card', 'paid', NULL, 'Automated entry from booking', '2026-04-18 20:11:58'),
(3, 13, 12000.00, 'cash', 'pending', NULL, 'Automated entry', '2026-04-18 20:14:32'),
(4, 14, 6500.00, 'cash', 'paid', NULL, 'Automated entry', '2026-04-18 21:26:41'),
(5, 15, 25000.00, 'cash', 'pending', '2026-04-20 13:29:38', 'Automated entry', '2026-04-20 13:29:38'),
(6, 16, 9000.00, 'cash', 'pending', '2026-04-20 13:44:54', 'Automated entry', '2026-04-20 13:44:54'),
(7, 17, 25000.00, 'cash', 'pending', '2026-04-20 13:53:14', '', '2026-04-20 13:53:14');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `report_date` date DEFAULT NULL,
  `total_payments` decimal(10,2) DEFAULT 0.00,
  `total_appointments` int(11) DEFAULT 0,
  `total_clients` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` enum('hair','skin','nails','wellness','bridal') NOT NULL,
  `duration_minutes` int(11) NOT NULL DEFAULT 60,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `category`, `duration_minutes`, `price`, `description`) VALUES
(1, 'Signature Cut & Style', 'hair', 60, 3500.00, 'Precision haircut with blowout'),
(2, 'Balayage & Highlights', 'hair', 180, 12000.00, 'Hand-painted color technique'),
(3, 'Signature Glow Facial', 'skin', 75, 4500.00, 'Deep cleansing facial'),
(4, 'Luxury Manicure', 'nails', 60, 1800.00, 'Complete manicure service'),
(5, 'Aromatherapy Massage', 'wellness', 120, 6500.00, 'Full body massage'),
(6, 'Bridal Glam Package', 'bridal', 240, 25000.00, 'Complete bridal package'),
(7, 'Keratin Treatment', 'hair', 90, 9000.00, 'Hair smoothing treatment'),
(8, 'Gel Extension Set', 'nails', 75, 3500.00, 'Gel nail extensions'),
(9, 'flow Hair Cut', 'hair', 30, 4000.00, 'A textured Flow hair cut');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `role` enum('stylist','receptionist') NOT NULL,
  `commission_rate` decimal(5,4) DEFAULT 0.2000,
  `phone` varchar(20) DEFAULT NULL,
  `is_available` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `name`, `role`, `commission_rate`, `phone`, `is_available`, `created_at`) VALUES
(1, 'Zara Ali', 'stylist', 0.3999, '+923001234567', 1, '2026-04-05 16:01:29'),
(2, 'Nadia Hassan', 'stylist', 0.3000, '+923001234568', 1, '2026-04-05 16:01:29'),
(3, 'Rida Tariq', 'stylist', 0.2200, '+923001234569', 1, '2026-04-05 16:01:29'),
(4, 'Ahmed Khan', 'receptionist', 0.1000, '+923001234570', 1, '2026-04-05 16:01:29');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `contact_person`, `email`, `phone`, `address`, `created_at`) VALUES
(1, 'Based', 'Amir Ahmed', 'amira@example.com', '12345678923', 'Floor 6, Taimoor Tower, Saddar, Karachi', '2026-04-18 20:29:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','receptionist','stylist','user') DEFAULT 'user',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `is_active`, `created_at`) VALUES
(1, 'admin', 'admin@elegancesalon.pk', '$2y$12$T4h1XZ8zHq222ZjMaYvIdek5jqHsAhqRDGZYrg0F6wFi559Eg5Mx2', 'admin', 1, '2026-04-05 16:01:29'),
(2, 'areeb1', 'areeb123@example.com', '$2y$12$T4h1XZ8zHq222ZjMaYvIdek5jqHsAhqRDGZYrg0F6wFi559Eg5Mx2', 'stylist', 1, '2026-04-10 10:25:52'),
(3, 'areeb132', 'areeb.demo@example.com', '$2y$12$T4h1XZ8zHq222ZjMaYvIdek5jqHsAhqRDGZYrg0F6wFi559Eg5Mx2', 'receptionist', 1, '2026-04-10 10:26:22'),
(5, 'DemoUser', 'user@example.com', '$2y$12$T4h1XZ8zHq222ZjMaYvIdek5jqHsAhqRDGZYrg0F6wFi559Eg5Mx2', 'user', 1, '2026-04-14 23:19:26');

-- --------------------------------------------------------

--
-- Structure for view `dashboard_stats`
--
DROP TABLE IF EXISTS `dashboard_stats`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `dashboard_stats`  AS SELECT (select count(0) from `appointments` where `appointments`.`status` = 'pending') AS `pending_appointments`, (select count(0) from `appointments` where `appointments`.`status` = 'completed' and cast(`appointments`.`date_time` as date) = curdate()) AS `today_appointments`, (select count(0) from `clients`) AS `total_clients`, (select count(0) from `inventory` where `inventory`.`quantity` <= `inventory`.`low_stock_threshold`) AS `low_stock_items` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `staff_id` (`staff_id`),
  ADD KEY `idx_appointments_date` (`date_time`),
  ADD KEY `idx_appointments_status` (`status`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_feedback_rating` (`rating`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sku` (`sku`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `appointment_id` (`appointment_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_users_role` (`role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`),
  ADD CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
