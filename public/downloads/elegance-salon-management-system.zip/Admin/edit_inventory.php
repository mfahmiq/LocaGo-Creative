<?php
$allowed_roles = ['admin', 'receptionist'];
require_once __DIR__ . '/../includes/admin_guard.php';

// Get ID from URL
$id = input_int($_GET, 'id', 1);

// Fetch existing product data
$item = $id ? db_fetch_one($conn, "SELECT * FROM inventory WHERE id = ?", 'i', [$id]) : null;

if (!$item) {
    die("Product Not Found.");
}

// Update logic
if (isset($_POST['update'])) {
    $name       = input_str($_POST, 'name', 255);
    $sku        = input_str($_POST, 'sku', 100);
    $quantity   = input_int($_POST, 'quantity', 0);
    $low_stock  = input_int($_POST, 'low_stock', 0);
    $cost_price = input_float($_POST, 'cost_price', 0);
    $supplier   = input_str($_POST, 'supplier', 255);

    if ($name === '' || $sku === '' || $quantity === null || $low_stock === null || $cost_price === null) {
        js_alert('Please fill in all fields with valid values');
    } elseif (db_fetch_one($conn, "SELECT id FROM inventory WHERE sku = ? AND id != ?", 'si', [$sku, $id])) {
        // Check duplicate SKU (excluding current item)
        js_alert('SKU already exists!');
    } else {
        $ok = db_query($conn, "UPDATE inventory SET name = ?, sku = ?, quantity = ?, low_stock_threshold = ?, cost_price = ?, supplier = ? WHERE id = ?",
            'ssiidsi', [$name, $sku, $quantity, $low_stock, $cost_price, $supplier, $id]);

        if ($ok) {
            header("Location: inventory.php");
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Elegance Salon | Edit Product</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #121211;
            --card: #1a1a19;
            --gold: #c5a059;
            --text: #ffffff;
            --dim: #a0a0a0;
            --border: #333330;
        }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .form-card {
            background: var(--card);
            border: 1px solid var(--border);
            padding: 50px;
            width: 100%;
            max-width: 450px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
        }

        header {
            text-align: center;
            margin-bottom: 40px;
        }

        header p {
            color: var(--gold);
            font-size: 0.7rem;
            letter-spacing: 4px;
            text-transform: uppercase;
            margin-bottom: 10px;
        }

        h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.2rem;
            margin: 0;
            font-weight: 400;
        }

        h2 span {
            color: var(--gold);
            font-style: italic;
        }

        .input-group {
            margin-bottom: 30px;
        }

        label {
            display: block;
            font-size: 0.7rem;
            color: var(--gold);
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            background: transparent;
            border: none;
            border-bottom: 1px solid var(--border);
            color: var(--text);
            padding: 10px 0;
            font-size: 1rem;
        }

        input:focus {
            outline: none;
            border-bottom-color: var(--gold);
        }

        .btn-update {
            width: 100%;
            background-color: var(--gold);
            color: #000;
            border: none;
            padding: 15px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 2px;
            cursor: pointer;
            margin-top: 20px;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 25px;
            color: var(--dim);
            text-decoration: none;
            font-size: 0.75rem;
            letter-spacing: 1px;
        }

        .back-link:hover {
            color: var(--gold);
        }
    </style>
</head>

<body>
    <div class="form-card">
        <header>
            <p>Stock Adjustment</p>
            <h2>Edit <span>Product</span></h2>
        </header>
        <form method="POST"><?= csrf_field() ?>
            <div class="input-group">
                <label>Product Name</label>
                <input type="text" name="name" value="<?= e($item['name']) ?>" required>
            </div>
            <div class="input-group">
                <label>SKU</label>
                <input type="text" name="sku" value="<?= e($item['sku']) ?>" required>
            </div>
            <div style="display:flex; gap:20px;">
                <div class="input-group" style="flex:1;">
                    <label>Stock Level</label>
                    <input type="number" name="quantity" value="<?= e($item['quantity']) ?>" required>
                </div>
                <div class="input-group" style="flex:1;">
                    <label>Low Alert</label>
                    <input type="number" name="low_stock" value="<?= e($item['low_stock_threshold']) ?>" required>
                </div>
            </div>
            <div class="input-group">
                <label>Cost Price (Rs.)</label>
                <input type="number" step="0.01" name="cost_price" value="<?= e($item['cost_price']) ?>" required>
            </div>
            <div class="input-group">
                <label>Supplier</label>
                <input type="text" name="supplier" value="<?= e($item['supplier']) ?>" required>
            </div>
            <button type="submit" name="update" class="btn-update">Update Inventory</button>
            <a href="inventory.php" class="back-link">← Discard Changes</a>
        </form>
    </div>
</body>

</html>