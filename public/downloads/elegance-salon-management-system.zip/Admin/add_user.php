<?php
$allowed_roles = ['admin'];
require_once __DIR__ . '/../includes/admin_guard.php';

if (isset($_POST['submit'])) {

    $username = input_str($_POST, 'username', 50);
    $email    = input_email($_POST, 'email');
    $password = (string) ($_POST['password'] ?? '');
    $role     = input_enum($_POST, 'role', ['admin', 'receptionist', 'stylist', 'user']);

    // Basic validation
    if ($username === '' || !$email || $password === '' || !$role) {
        js_alert('All fields are required');
    } elseif (strlen($password) < 8 || strlen($password) > 72) {
        js_alert('Password must be between 8 and 72 characters');
    } else {

        // Check duplicate email
        if (db_fetch_one($conn, "SELECT id FROM users WHERE email = ?", 's', [$email])) {
            js_alert('Email already exists');
        } else {

            $hashed = password_hash($password, PASSWORD_DEFAULT);

            $ok = db_query($conn, "INSERT INTO users (username, email, password, role, is_active, created_at) VALUES (?, ?, ?, ?, 1, NOW())",
                'ssss', [$username, $email, $hashed, $role]);

            if ($ok) {
                header("Location: users.php");
                exit();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Elegance Salon | Add User</title>

<link href="https://fonts.googleapis.com/css2?family=Playfair+Display&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">

<style>
:root {
    --bg: #121211;
    --card: #1a1a19;
    --gold: #c5a059;
    --text: #ffffff;
    --dim: #a0a0a0;
    --border: #333330;
}

body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Montserrat', sans-serif;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

/* CARD */
.form-card {
    background: var(--card);
    border: 1px solid var(--border);
    padding: 50px;
    width: 100%;
    max-width: 450px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.5);
}

/* HEADER */
header {
    text-align: center;
    margin-bottom: 40px;
}

header p {
    color: var(--gold);
    font-size: 0.7rem;
    letter-spacing: 4px;
    text-transform: uppercase;
    margin-bottom: 10px;
}

h2 {
    font-family: 'Playfair Display', serif;
    font-size: 2.2rem;
    margin: 0;
    font-weight: 400;
}

h2 span {
    color: var(--gold);
    font-style: italic;
}

/* ALERTS */
.alert {
    padding: 12px;
    margin-bottom: 25px;
    font-size: 0.8rem;
}

.alert-success {
    background: #0d2b0d;
    color: #4caf50;
}

.alert-error {
    background: #2b0d0d;
    color: #e74c3c;
}

/* INPUTS */
.input-group {
    margin-bottom: 30px;
}

label {
    display: block;
    font-size: 0.7rem;
    color: var(--gold);
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin-bottom: 8px;
}

input, select {
    width: 100%;
    background: transparent;
    border: none;
    border-bottom: 1px solid var(--border);
    color: var(--text);
    padding: 10px 0;
    font-size: 1rem;
}

input:focus, select:focus {
    outline: none;
    border-bottom-color: var(--gold);
}

/* BUTTON */
.btn-update {
    width: 100%;
    background-color: var(--gold);
    color: #000;
    border: none;
    padding: 15px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 2px;
    cursor: pointer;
    margin-top: 20px;
}

/* BACK */
.back-link {
    display: block;
    text-align: center;
    margin-top: 25px;
    color: var(--dim);
    text-decoration: none;
    font-size: 0.75rem;
    letter-spacing: 1px;
}

.back-link:hover {
    color: var(--gold);
}
</style>
</head>

<body>

<div class="form-card">

    <header>
        <p>Account Creation</p>
        <h2>Add <span>User</span></h2>
    </header>

    <?php if (!empty($success)): ?>
        <div class="alert alert-success"><?= e($success) ?></div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST"><?= csrf_field() ?>

        <div class="input-group">
            <label>Username</label>
            <input type="text" name="username" value="<?= e($_POST['username'] ?? '') ?>" required>
        </div>

        <div class="input-group">
            <label>Email Address</label>
            <input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required>
        </div>

        <div class="input-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>

        <div class="input-group">
            <label>Role</label>
            <select name="role" required>
                <option value="">Select Role</option>
                <option value="admin" <?= (($_POST['role'] ?? '') === 'admin') ? 'selected' : '' ?>>Admin</option>
                <option value="receptionist" <?= (($_POST['role'] ?? '') === 'receptionist') ? 'selected' : '' ?>>Receptionist</option>
                <option value="stylist" <?= (($_POST['role'] ?? '') === 'stylist') ? 'selected' : '' ?>>Stylist</option>
                <option value="user" <?= (($_POST['role'] ?? '') === 'user') ? 'selected' : '' ?>>User</option>
            </select>
        </div>

        <button type="submit" name="submit" class="btn-update">Create User</button>

        <a href="users.php" class="back-link">← Cancel</a>

    </form>
</div>

</body>
</html>