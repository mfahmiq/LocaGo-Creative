<?php
$allowed_roles = ['admin'];
require_once __DIR__ . '/../includes/admin_guard.php';

// Fetch Invoices
$query = "SELECT * FROM invoices ORDER BY id DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Invoice Directory | Elegance Admin</title>
    <style>
        :root {
            --bg-dark: #0d0d0d;
            --card-bg: #161616;
            --gold: #c5a059;
            --text-main: #ffffff;
            --text-muted: #888888;
        }

        body {
            background-color: var(--bg-dark);
            color: var(--text-main);
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 50px;
        }

        /* Top Header Styling from User Directory */
        .admin-label {
            color: var(--gold);
            text-transform: uppercase;
            letter-spacing: 3px;
            font-size: 11px;
            margin-bottom: 5px;
        }

        .header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }

        .header-flex h1 {
            font-family: 'Georgia', serif;
            font-size: 42px;
            margin: 0;
            font-weight: normal;
        }

        .header-flex h1 span {
            font-style: italic;
            color: var(--gold);
        }

        /* Buttons from your template */
        .nav-buttons {
            display: flex;
            gap: 10px;
        }

        .btn-gold {
            background-color: var(--gold);
            border: none;
            padding: 12px 25px;
            font-weight: bold;
            cursor: pointer;
            text-transform: uppercase;
            font-size: 12px;
            text-decoration: none;
            color: black;
            transition: 0.3s;
        }

        .btn-gold:hover {
            background-color: #a68445;
        }

        /* Table Design from image_5826ba.png */
        .table-container {
            background-color: var(--card-bg);
            border: 1px solid #222;
            padding: 10px;
            margin-top: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            color: var(--gold);
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 2px;
            padding: 20px;
            border-bottom: 1px solid #333;
        }

        td {
            padding: 20px;
            border-bottom: 1px solid #222;
            font-size: 15px;
            color: #ccc;
        }

        .id-cell {
            color: var(--gold);
            font-weight: bold;
        }

        .status-badge {
            border: 1px solid var(--gold);
            color: var(--gold);
            padding: 4px 10px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Action Links from template */
        .actions a {
            text-decoration: none;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--gold);
        }

        .actions a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <div class="admin-label">Administration</div>
    
    <div class="header-flex">
        <h1>Invoice <span>Directory</span></h1>
        <div class="nav-buttons">
            <a href="generate_invoice.php" class="btn-gold">Add New Invoice</a>
            <a href="dashboard.php" class="btn-gold" style="background-color: #b38f4d;">Back to Dashboard</a>
        </div>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Client Name</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td class="id-cell"><?php echo e($row['id']); ?></td>
                            <td><?php echo e($row['client_name']); ?></td>
                            <td><?php echo date("M d, Y", strtotime($row['invoice_date'])); ?></td>
                            <td style="color: white; font-weight: 500;">
                                <?php echo number_format($row['total_amount'], 2); ?>
                            </td>
                            <td>
                                <span class="status-badge"><?php echo e($row['status']); ?></span>
                            </td>
                            <td class="actions">
                                <a href="view_invoice.php?id=<?php echo e($row['id']); ?>">View / Print</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px; color: #555;">No invoices found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</body>

</html>