<?php
require_once __DIR__ . '/../includes/admin_guard.php';
$message = "";
$service_id = input_int($_GET, 'id', 1); // Get the ID from the URL

// 1. Fetch current data to pre-fill the form
$service = $service_id ? db_fetch_one($conn, "SELECT * FROM services WHERE id = ?", 'i', [$service_id]) : null;
if (!$service) {
    die("Service Not Found.");
}

// 2. Handle the Update request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name        = input_str($_POST, 'name', 255);
    $category    = input_enum($_POST, 'category', ['hair', 'skin', 'nails', 'wellness', 'bridal']);
    $duration    = input_int($_POST, 'duration', 1);
    $price       = input_float($_POST, 'price', 0);
    $description = input_str($_POST, 'description', 5000);

    if ($name === '' || !$category || !$duration || $price === null) {
        $message = "Please fill in all fields with valid values.";
    } elseif (db_query($conn, "UPDATE services SET name = ?, category = ?, duration_minutes = ?, price = ?, description = ? WHERE id = ?",
            'ssidsi', [$name, $category, $duration, $price, $description, $service_id])) {
        $message = "Service updated successfully!";
        // Refresh local data so the form shows the new values
        $service['name'] = $name;
        $service['category'] = $category;
        $service['duration_minutes'] = $duration;
        $service['price'] = $price;
        $service['description'] = $description;
    } else {
        $message = "Error updating the service.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="form-style.css"> <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600&family=Playfair+Display:ital,wght@0,400;1,400&display=swap" rel="stylesheet">
        <style>* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    background-color: #0c0c0c; /* Black outer background */
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    font-family: 'Montserrat', sans-serif;
}

.registration-card {
    background-color: #1a1a1a;
    width: 100%;
    max-width: 500px;
    padding: 60px 50px;
    box-shadow: 0 20px 50px rgba(0,0,0,0.5);
    text-align: center;
}

/* Header */
.subtitle {
    font-size: 0.7rem;
    letter-spacing: 3px;
    color: #c5a059;
    text-transform: uppercase;
    margin-bottom: 10px;
}

h1 {
    font-family: 'Playfair Display', serif;
    font-size: 2.2rem;
    color: #fff;
    margin-bottom: 40px;
    font-weight: 400;
}

h1 span {
    font-style: italic;
    color: #c5a059;
}

/* Form Styling */
.salon-form {
    text-align: left;
}

.input-group {
    margin-bottom: 25px;
    display: flex;
    flex-direction: column;
}

.row {
    display: flex;
    gap: 20px;
}

.row .input-group {
    flex: 1;
}

label {
    font-size: 0.7rem;
    color: #c5a059;
    letter-spacing: 1.5px;
    margin-bottom: 10px;
}

input, select, textarea {
    background: transparent;
    border: none;
    border-bottom: 1px solid #333; 
    color: #888;
    padding: 10px 0;
    font-family: 'Montserrat', sans-serif;
    font-size: 0.9rem;
    outline: none;
    transition: border-color 0.3s;
}

input:focus, select:focus, textarea:focus {
    border-bottom: 1px solid #c5a059;
    color: #fff;
}

/* Button */
.submit-btn {
    background-color: #c5a059;
    color: #000;
    border: none;
    width: 100%;
    padding: 18px;
    font-weight: 600;
    letter-spacing: 2px;
    margin-top: 20px;
    cursor: pointer;
    font-family: 'Montserrat', sans-serif;
    transition: background 0.3s;
}

.submit-btn:hover {
    background-color: #dfb96b;
}

.cancel-link {
    display: block;
    margin-top: 25px;
    color: #888;
    text-decoration: none;
    font-size: 0.75rem;
    letter-spacing: 1px;
    text-align: center;
}

.cancel-link:hover {
    color: #fff;
}

.msg {
    color: #c5a059;
    font-size: 0.8rem;
    margin-bottom: 20px;
}</style>
    </head>
<body>

<div class="registration-card">
    <header class="card-header">
        <p class="subtitle">ADMINISTRATION</p>
        <h1>Edit <span>Service</span></h1>
    </header>

    <?php if($message) echo "<p class='msg'>" . e($message) . "</p>"; ?>

    <form action="edit_service.php?id=<?php echo (int) $service_id; ?>" method="POST" class="salon-form">
        
        <div class="input-group">
            <label>SERVICE NAME</label>
            <input type="text" name="name" value="<?php echo e($service['name']); ?>" required>
        </div>

        <div class="input-group">
            <label>CATEGORY</label>
            <select name="category" required>
                <option value="hair" <?php if($service['category'] == 'hair') echo 'selected'; ?>>Hair</option>
                <option value="skin" <?php if($service['category'] == 'skin') echo 'selected'; ?>>Skin</option>
                <option value="nails" <?php if($service['category'] == 'nails') echo 'selected'; ?>>Nails</option>
                <option value="wellness" <?php if($service['category'] == 'wellness') echo 'selected'; ?>>Wellness</option>
            </select>
        </div>

        <div class="row">
            <div class="input-group">
                <label>DURATION (MIN)</label>
                <input type="number" name="duration" value="<?php echo e($service['duration_minutes']); ?>" required>
            </div>
            <div class="input-group">
                <label>PRICE (PKR)</label>
                <input type="number" name="price" value="<?php echo e($service['price']); ?>" required>
            </div>
        </div>

        <div class="input-group">
            <label>DESCRIPTION</label>
            <textarea name="description" rows="3"><?php echo e($service['description']); ?></textarea>
        </div>

        <button type="submit" class="submit-btn">UPDATE SERVICE</button>
        
        <a href="services.php" class="cancel-link">← CANCEL & RETURN</a>
    </form>
</div>

</body>
</html>