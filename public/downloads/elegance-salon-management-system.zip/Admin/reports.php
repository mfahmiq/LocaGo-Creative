<?php
$allowed_roles = ['admin'];
require_once __DIR__ . '/../includes/admin_guard.php';

// ---------------------------------------------------------
// 1. TOP ROW STATS QUERIES
// ---------------------------------------------------------
$current_month = date('m');
$current_year = date('Y');

// Total Revenue (MTD) - Calculated from the Payments table for accuracy
$rev_query = mysqli_query($conn, "SELECT SUM(amount) as mtd_revenue FROM payments WHERE MONTH(paid_at) = MONTH(NOW()) AND YEAR(paid_at) = YEAR(NOW())");
$rev_data = mysqli_fetch_assoc($rev_query);
$mtd_revenue = $rev_data['mtd_revenue'] ?? 0;

// Total Appointments (MTD)
$appts_query = mysqli_query($conn, "SELECT COUNT(*) as mtd_appts FROM appointments WHERE MONTH(date_time) = '$current_month' AND YEAR(date_time) = '$current_year'");
$appts_data = mysqli_fetch_assoc($appts_query);
$mtd_appts = $appts_data['mtd_appts'] ?? 0;

// Low Stock Inventory (Using your specific low_stock_threshold column)
$stock_query = mysqli_query($conn, "SELECT COUNT(*) as low_stock FROM inventory WHERE quantity <= low_stock_threshold");
$stock_data = mysqli_fetch_assoc($stock_query);
$low_stock = $stock_data['low_stock'] ?? 0;

// Top Stylist (MTD) - Joined with the staff table
$top_staff_query = mysqli_query($conn, "
    SELECT s.name, SUM(a.total_amount) as total_earned 
    FROM appointments a
    JOIN staff s ON a.staff_id = s.id
    WHERE MONTH(a.date_time) = '$current_month' AND YEAR(a.date_time) = '$current_year' AND a.status = 'Completed'
    GROUP BY a.staff_id
    ORDER BY total_earned DESC LIMIT 1
");
$top_staff_data = mysqli_fetch_assoc($top_staff_query);
$top_staff_name = $top_staff_data['name'] ?? 'N/A';

// ---------------------------------------------------------
// 2. CHART DATA QUERIES
// ---------------------------------------------------------

// A. Sales Trends (Last 30 Days)
$sales_trend_sql = "
    SELECT DATE(paid_at) as sales_date, SUM(amount) as daily_total 
    FROM payments 
    WHERE paid_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    GROUP BY DATE(paid_at) 
    ORDER BY sales_date ASC
";
$sales_result = mysqli_query($conn, $sales_trend_sql);

$sales_dates = [];
$sales_totals = [];

while($row = mysqli_fetch_assoc($sales_result)) {
    // Format the date for the Chart.js labels (e.g., "Apr 15")
    $sales_dates[] = date('M d', strtotime($row['sales_date']));
    $sales_totals[] = $row['daily_total'];
}
// B. Service Popularity (Using services table)
$services_sql = "
    SELECT s.name, COUNT(a.id) as service_count 
    FROM appointments a
    JOIN services s ON a.service_id = s.id
    GROUP BY a.service_id
    ORDER BY service_count DESC LIMIT 5
";
$services_result = mysqli_query($conn, $services_sql);
$service_names = [];
$service_counts = [];
while ($row = mysqli_fetch_assoc($services_result)) {
  $service_names[] = $row['name'];
  $service_counts[] = $row['service_count'];
}

// C. Staff Performance (Revenue per staff member)
// Staff Performance - Fix: Using LEFT JOIN and checking status
$staff_perf_sql = "SELECT s.name, SUM(a.total_amount) as total FROM staff s JOIN appointments a ON s.id = a.staff_id GROUP BY s.id";
$staff_result = mysqli_query($conn, $staff_perf_sql);
$staff_names = [];
$staff_earnings = [];
while ($r = mysqli_fetch_assoc($staff_result)) {
  $staff_names[] = $r['name'];
  $staff_earnings[] = $r['total'];
}

// D. Peak Booking Hours
$hours_sql = "
    SELECT HOUR(date_time) as hr, COUNT(*) as appt_count 
    FROM appointments 
    GROUP BY HOUR(date_time)
    ORDER BY hr ASC
";
$hours_result = mysqli_query($conn, $hours_sql);
$hour_labels = [];
$hour_counts = [];
while ($row = mysqli_fetch_assoc($hours_result)) {
  $hour_labels[] = date("g A", strtotime($row['hr'] . ":00"));
  $hour_counts[] = $row['appt_count'];
}

// ---------------------------------------------------------
// 3. INVENTORY ALERT TABLE
// ---------------------------------------------------------
$inventory_alert = mysqli_query($conn, "SELECT name, sku, quantity, low_stock_threshold FROM inventory WHERE quantity <= low_stock_threshold ORDER BY quantity ASC LIMIT 5");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Elegance Salon | Reports & Analytics</title>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;1,400&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    :root {
      --bg: #121211;
      --card: #1a1a19;
      --gold: #c5a059;
      --text: #ffffff;
      --dim: #a0a0a0;
      --border: #333330;
    }

    body {
      background: var(--bg);
      color: var(--text);
      font-family: 'Montserrat', sans-serif;
      padding: 40px;
      margin: 0;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
    }

    header {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      margin-bottom: 40px;
      border-bottom: 1px solid var(--border);
      padding-bottom: 20px;
    }

    h2 {
      font-family: 'Playfair Display', serif;
      font-size: 2.5rem;
      margin: 0;
      font-weight: 400;
    }

    h2 span {
      color: var(--gold);
      font-style: italic;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 20px;
      margin-bottom: 40px;
    }

    .stat-card {
      background: var(--card);
      border: 1px solid var(--border);
      padding: 25px;
      border-left: 4px solid var(--gold);
    }

    .stat-card p {
      margin: 0;
      font-size: 0.7rem;
      color: var(--gold);
      text-transform: uppercase;
      letter-spacing: 2px;
    }

    .stat-card h3 {
      margin: 10px 0 0 0;
      font-size: 1.8rem;
      font-family: 'Playfair Display', serif;
    }

    .charts-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
      gap: 30px;
    }

    .chart-box {
      background: var(--card);
      border: 1px solid var(--border);
      padding: 25px;
    }

    .chart-box h4 {
      margin: 0 0 20px 0;
      font-size: 0.9rem;
      color: var(--gold);
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 15px;
    }

    th {
      text-align: left;
      font-size: 0.7rem;
      color: var(--gold);
      padding: 10px;
      border-bottom: 1px solid var(--border);
    }

    td {
      padding: 12px 10px;
      font-size: 0.85rem;
      border-bottom: 1px solid #252524;
      color: var(--dim);
    }

    .btn-back {
      color: var(--gold);
      text-decoration: none;
      font-size: 0.8rem;
      border: 1px solid var(--gold);
      padding: 8px 16px;
      transition: 0.3s;
    }

    .btn-back:hover {
      background: var(--gold);
      color: #000;
    }
  </style>
</head>

<body>

  <div class="container">
    <header>
      <div>
        <p style="letter-spacing: 3px; font-size: 0.7rem; color: var(--gold);">EXECUTIVE SUMMARY</p>
        <h2>Salon <span>Analytics</span></h2>
      </div>
      <a href="dashboard.php" class="btn-back">Dashboard</a>
    </header>

    <div class="stats-grid">
      <div class="stat-card">
        <p>Revenue (MTD)</p>
        <h3>$<?= number_format($mtd_revenue, 2) ?></h3>
      </div>
      <div class="stat-card">
        <p>Monthly Bookings</p>
        <h3><?= $mtd_appts ?></h3>
      </div>
      <div class="stat-card">
        <p>Top Performer</p>
        <h3><?= e($top_staff_name) ?></h3>
      </div>
      <div class="stat-card">
        <p>Inventory Alerts</p>
        <h3 style="color: #e74c3c;"><?= $low_stock ?></h3>
      </div>
    </div>

    <div class="charts-grid">
      <div class="chart-box">
        <h4>Income Trend (30 Days)</h4>
        <canvas id="incomeChart"></canvas>
      </div>
      <div class="chart-box">
        <h4>Service Popularity</h4>
        <canvas id="serviceChart"></canvas>
      </div>
      <div class="chart-box">
        <h4>Staff Revenue Generation</h4>
        <canvas id="staffChart"></canvas>
      </div>
      <div class="chart-box">
        <h4>Booking Peak Times</h4>
        <canvas id="peakChart"></canvas>
      </div>
    </div>

    <div class="chart-box" style="margin-top: 30px;">
      <h4>Stock Replenishment Required</h4>
      <table>
        <thead>
          <tr>
            <th>SKU</th>
            <th>Product Name</th>
            <th>Current Level</th>
            <th>Threshold</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($item = mysqli_fetch_assoc($inventory_alert)): ?>
            <tr>
              <td style="color: var(--gold);"><?= e($item['sku']) ?></td>
              <td style="color: var(--text);"><?= e($item['name']) ?></td>
              <td><?= e($item['quantity']) ?></td>
              <td><?= e($item['low_stock_threshold']) ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>

  <script>
    Chart.defaults.color = '#a0a0a0';
    Chart.defaults.font.family = 'Montserrat';
    const goldGrad = '#c5a059';

    // Income Trend
    new Chart(document.getElementById('incomeChart'), {
      type: 'line',
      data: {
        labels: <?= json_encode($sales_dates, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>,
        datasets: [{
          label: 'Revenue',
          data: <?= json_encode($sales_totals, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>,
          borderColor: goldGrad,
          tension: 0.3,
          fill: true,
          backgroundColor: 'rgba(197, 160, 89, 0.1)'
        }]
      }
    });

    // Service Popularity
    new Chart(document.getElementById('serviceChart'), {
      type: 'doughnut',
      data: {
        labels: <?= json_encode($service_names, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>,
        datasets: [{
          data: <?= json_encode($service_counts, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>,
          backgroundColor: ['#c5a059', '#a6823c', '#8c6e35', '#6b5120', '#4a3610'],
          borderWidth: 0
        }]
      }
    });

    // Staff Performance
    new Chart(document.getElementById('staffChart'), {
      type: 'bar',
      data: {
        labels: <?= json_encode($staff_names, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>,
        datasets: [{
          label: 'Revenue ($)',
          data: <?= json_encode($staff_earnings, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>,
          backgroundColor: goldGrad
        }]
      },
      options: {
        indexAxis: 'y'
      }
    });

    // Peak Hours
    new Chart(document.getElementById('peakChart'), {
      type: 'bar',
      data: {
        labels: <?= json_encode($hour_labels, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>,
        datasets: [{
          label: 'Appts',
          data: <?= json_encode($hour_counts, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>,
          backgroundColor: '#ffffff'
        }]
      }
    });
  </script>

</body>

</html>