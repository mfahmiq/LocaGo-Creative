<?php
$allowed_roles = ['admin', 'receptionist'];
require_once __DIR__ . '/../includes/admin_guard.php';

if (isset($_POST['submit'])) {
    $name       = input_str($_POST, 'name', 255);
    $sku        = input_str($_POST, 'sku', 100);
    $quantity   = input_int($_POST, 'quantity', 0);
    $low_stock  = input_int($_POST, 'low_stock', 0);
    $cost_price = input_float($_POST, 'cost_price', 0);
    $supplier   = input_str($_POST, 'supplier', 255);

    if ($name === '' || $sku === '' || $quantity === null || $low_stock === null || $cost_price === null) {
        $error = "Please fill in all fields with valid values";
    } elseif (db_fetch_one($conn, "SELECT id FROM inventory WHERE sku = ?", 's', [$sku])) {
        // Check duplicate SKU
        $error = "Product with this SKU already exists";
    } else {
        $ok = db_query($conn, "INSERT INTO inventory (name, sku, quantity, low_stock_threshold, cost_price, supplier, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())",
            'ssiids', [$name, $sku, $quantity, $low_stock, $cost_price, $supplier]);

        if ($ok) {
            header("Location: inventory.php");
            exit();
        } else {
            $error = "Database Error: could not save the product";
        }
    }
}
?>
<style>
:root {
    --bg: #121211;
    --card: #1a1a19;
    --gold: #c5a059;
    --text: #ffffff;
    --dim: #a0a0a0;
    --border: #333330;
}

body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Montserrat', sans-serif;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

/* CARD */
.form-card {
    background: var(--card);
    border: 1px solid var(--border);
    padding: 50px;
    width: 100%;
    max-width: 450px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.5);
}

/* HEADER */
header {
    text-align: center;
    margin-bottom: 40px;
}

header p {
    color: var(--gold);
    font-size: 0.7rem;
    letter-spacing: 4px;
    text-transform: uppercase;
    margin-bottom: 10px;
}

h2 {
    font-family: 'Playfair Display', serif;
    font-size: 2.2rem;
    margin: 0;
    font-weight: 400;
}

h2 span {
    color: var(--gold);
    font-style: italic;
}

/* ALERTS */
.alert {
    padding: 12px;
    margin-bottom: 25px;
    font-size: 0.8rem;
}

.alert-success {
    background: #0d2b0d;
    color: #4caf50;
}

.alert-error {
    background: #2b0d0d;
    color: #e74c3c;
}

/* INPUTS */
.input-group {
    margin-bottom: 30px;
}

label {
    display: block;
    font-size: 0.7rem;
    color: var(--gold);
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin-bottom: 8px;
}

input, select {
    width: 100%;
    background: transparent;
    border: none;
    border-bottom: 1px solid var(--border);
    color: var(--text);
    padding: 10px 0;
    font-size: 1rem;
}

input:focus, select:focus {
    outline: none;
    border-bottom-color: var(--gold);
}

/* BUTTON */
.btn-update {
    width: 100%;
    background-color: var(--gold);
    color: #000;
    border: none;
    padding: 15px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 2px;
    cursor: pointer;
    margin-top: 20px;
}

/* BACK */
.back-link {
    display: block;
    text-align: center;
    margin-top: 25px;
    color: var(--dim);
    text-decoration: none;
    font-size: 0.75rem;
    letter-spacing: 1px;
}

.back-link:hover {
    color: var(--gold);
}
</style>
</head>

<body>
<div class="form-card">
    <header>
        <p>Stock Management</p>
        <h2>Add <span>Product</span></h2>
    </header>

    <?php if (isset($error)): ?>
        <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST"><?= csrf_field() ?>
        <div class="input-group">
            <label>Product Name</label>
            <input type="text" name="name" required>
        </div>
        <div class="input-group">
            <label>SKU (Unique Code)</label>
            <input type="text" name="sku" placeholder="e.g. OPI-RED-01" required>
        </div>
        <div class="row" style="display:flex; gap:20px;">
            <div class="input-group" style="flex:1;">
                <label>Current Stock</label>
                <input type="number" name="quantity" required>
            </div>
            <div class="input-group" style="flex:1;">
                <label>Low Stock Alert</label>
                <input type="number" name="low_stock" value="5" required>
            </div>
        </div>
        <div class="input-group">
            <label>Cost Price (Rs.)</label>
            <input type="number" step="0.01" name="cost_price" required>
        </div>
        <div class="input-group">
            <label>Assign Supplier</label>
            <input type="text" name="supplier" required>
        </div>

        <button type="submit" name="submit" class="btn-update">Add to Inventory</button>
        <a href="inventory.php" class="back-link">← Cancel</a>
    </form>
</div>
</body>