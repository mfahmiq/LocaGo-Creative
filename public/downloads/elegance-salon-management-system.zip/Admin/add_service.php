<?php
require_once __DIR__ . '/../includes/admin_guard.php';

$message = ""; // To store success/error alerts

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name        = input_str($_POST, 'name', 255);
    $category    = input_enum($_POST, 'category', ['hair', 'skin', 'nails', 'wellness', 'bridal']);
    $duration    = input_int($_POST, 'duration', 1);
    $price       = input_float($_POST, 'price', 0);
    $description = input_str($_POST, 'description', 5000);

    if ($name === '' || !$category || !$duration || $price === null) {
        $message = "Please fill in all fields with valid values.";
    } elseif (db_query($conn, "INSERT INTO services (name, category, duration_minutes, price, description) VALUES (?, ?, ?, ?, ?)",
            'ssids', [$name, $category, $duration, $price, $description])) {
        $message = "Service added successfully!";
    } else {
        $message = "Error: could not save the service.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Elegance Salon - Add Service</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600&family=Playfair+Display:ital,wght@0,400;1,400&display=swap" rel="stylesheet">
    <style>
    * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    background-color: #0c0c0c; /* Black outer background */
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    font-family: 'Montserrat', sans-serif;
}

.registration-card {
    background-color: #1a1a1a; 
    width: 100%;
    max-width: 500px;
    padding: 60px 50px;
    box-shadow: 0 20px 50px rgba(0,0,0,0.5);
    text-align: center;
}

/* Header */
.subtitle {
    font-size: 0.7rem;
    letter-spacing: 3px;
    color: #c5a059;
    text-transform: uppercase;
    margin-bottom: 10px;
}

h1 {
    font-family: 'Playfair Display', serif;
    font-size: 2.2rem;
    color: #fff;
    margin-bottom: 40px;
    font-weight: 400;
}

h1 span {
    font-style: italic;
    color: #c5a059;
}

/* Form Styling */
.salon-form {
    text-align: left;
}

.input-group {
    margin-bottom: 25px;
    display: flex;
    flex-direction: column;
}

.row {
    display: flex;
    gap: 20px;
}

.row .input-group {
    flex: 1;
}

label {
    font-size: 0.7rem;
    color: #c5a059;
    letter-spacing: 1.5px;
    margin-bottom: 10px;
}

input, select, textarea {
    background: transparent;
    border: none;
    border-bottom: 1px solid #333;
    color: #888;
    padding: 10px 0;
    font-family: 'Montserrat', sans-serif;
    font-size: 0.9rem;
    outline: none;
    transition: border-color 0.3s;
}

input:focus, select:focus, textarea:focus {
    border-bottom: 1px solid #c5a059;
    color: #fff;
}

/* Button */
.submit-btn {
    background-color: #c5a059;
    color: #000;
    border: none;
    width: 100%;
    padding: 18px;
    font-weight: 600;
    letter-spacing: 2px;
    margin-top: 20px;
    cursor: pointer;
    font-family: 'Montserrat', sans-serif;
    transition: background 0.3s;
}

.submit-btn:hover {
    background-color: #dfb96b;
}

.cancel-link {
    display: block;
    margin-top: 25px;
    color: #888;
    text-decoration: none;
    font-size: 0.75rem;
    letter-spacing: 1px;
    text-align: center;
}

.cancel-link:hover {
    color: #fff;
}

.msg {
    color: #c5a059;
    font-size: 0.8rem;
    margin-bottom: 20px;
} </style>
</head>
<body>

<div class="registration-card">
    <header class="card-header">
        <p class="subtitle">ADMINISTRATION</p>
        <h1>New <span>Service</span></h1>
    </header>

    <?php if($message) echo "<p class='msg'>" . e($message) . "</p>"; ?>

    <form action="add_service.php" method="POST" class="salon-form"><?= csrf_field() ?>
        <div class="input-group">
            <label>SERVICE NAME</label>
            <input type="text" name="name" placeholder="e.g. Balayage Highlights" required>
        </div>

        <div class="input-group">
            <label>CATEGORY</label>
            <select name="category" required>
                <option value="hair">Hair</option>
                <option value="skin">Skin</option>
                <option value="nails">Nails</option>
                <option value="wellness">Wellness</option>
            </select>
        </div>

        <div class="row">
            <div class="input-group">
                <label>DURATION (MIN)</label>
                <input type="number" name="duration" placeholder="e.g. 60" required>
            </div>
            <div class="input-group">
                <label>PRICE (PKR)</label>
                <input type="number" name="price" placeholder="e.g. 3500" required>
            </div>
        </div>

        <div class="input-group">
            <label>DESCRIPTION</label>
            <textarea name="description" rows="3" placeholder="Brief details about the service..."></textarea>
        </div>

        <button type="submit" class="submit-btn">ADD TO DIRECTORY</button>
        
        <a href="services.php" class="cancel-link">← CANCEL & RETURN</a>
    </form>
</div>

</body>
</html>