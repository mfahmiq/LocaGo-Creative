<?php
require_once __DIR__ . '/../includes/admin_guard.php';

// Fetch lists for dropdowns
$clients  = mysqli_query($conn, "SELECT id, name FROM clients ORDER BY name");
$staff    = mysqli_query($conn, "SELECT id, name FROM staff WHERE role = 'stylist'");
$services = mysqli_query($conn, "SELECT id, name, price FROM services");

if (isset($_POST['submit'])) {
    $client_id    = input_int($_POST, 'client_id', 1);
    $service_id   = input_int($_POST, 'service_id', 1);
    $staff_id     = input_int($_POST, 'staff_id', 1);
    $date_time    = input_datetime($_POST, 'date_time');
    $total_amount = input_float($_POST, 'total_amount', 0);
    $notes        = input_str($_POST, 'notes', 2000);
    $status       = "pending";

    if (!$client_id || !$service_id || !$date_time
        || !db_fetch_one($conn, "SELECT id FROM clients WHERE id = ?", 'i', [$client_id])
        || !db_fetch_one($conn, "SELECT id FROM services WHERE id = ?", 'i', [$service_id])) {
        $error = "Please fill in all required fields.";
    } else {
        if ($total_amount === null) {
            $svc = db_fetch_one($conn, "SELECT price FROM services WHERE id = ?", 'i', [$service_id]);
            $total_amount = (float) $svc['price'];
        }
        $ok = db_query($conn, "INSERT INTO appointments (client_id, service_id, staff_id, date_time, status, total_amount, notes, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())",
            'iiissds', [$client_id, $service_id, $staff_id, $date_time, $status, $total_amount, $notes]);

        if ($ok) {
            header("Location: appointment.php");
            exit();
        } else {
            $error = "Could not save the appointment. Please check the values and try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Elegance Salon | Book Appointment</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #121211;
            --card: #1a1a19;
            --gold: #c5a059;
            --text: #ffffff;
            --dim: #a0a0a0;
            --border: #333330;
        }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px 0;
        }

        .form-card {
            background: var(--card);
            border: 1px solid var(--border);
            padding: 50px;
            width: 100%;
            max-width: 500px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.5);
        }

        header {
            text-align: center;
            margin-bottom: 40px;
        }

        header p {
            color: var(--gold);
            font-size: 0.7rem;
            letter-spacing: 4px;
            text-transform: uppercase;
            margin-bottom: 10px;
        }

        h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.2rem;
            margin: 0;
            font-weight: 400;
        }

        h2 span {
            color: var(--gold);
            font-style: italic;
        }

        .alert-error {
            background: #2b0d0d;
            color: #e74c3c;
            padding: 12px;
            margin-bottom: 25px;
            font-size: 0.8rem;
            border-left: 3px solid #e74c3c;
        }

        .input-group {
            margin-bottom: 25px;
        }

        label {
            display: block;
            font-size: 0.7rem;
            color: var(--gold);
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-bottom: 8px;
        }

        input, select, textarea {
            width: 100%;
            background: transparent;
            border: none;
            border-bottom: 1px solid var(--border);
            color: var(--text);
            padding: 10px 0;
            font-size: 0.95rem;
            box-sizing: border-box;
        }

        input:focus, select:focus, textarea:focus {
            outline: none;
            border-bottom-color: var(--gold);
        }

        /* Styling for the datetime-local picker icon */
        input[type="datetime-local"]::-webkit-calendar-picker-indicator {
            filter: invert(1);
        }

        .btn-update {
            width: 100%;
            background-color: var(--gold);
            color: #000;
            border: none;
            padding: 15px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 2px;
            cursor: pointer;
            margin-top: 20px;
            transition: 0.3s;
        }

        .btn-update:hover {
            background-color: #d4b477;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 25px;
            color: var(--dim);
            text-decoration: none;
            font-size: 0.75rem;
            letter-spacing: 1px;
        }

        .back-link:hover {
            color: var(--gold);
        }
    </style>
</head>
<body>

<div class="form-card">
    <header>
        <p>New Reservation</p>
        <h2>Book <span>Appointment</span></h2>
    </header>

    <?php if (!empty($error)): ?>
        <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST"><?= csrf_field() ?>
        <div class="input-group">
            <label>Select Client</label>
            <select name="client_id" required>
                <option value="">Choose Client...</option>
                <?php while($c = mysqli_fetch_assoc($clients)): ?>
                    <option value="<?= e($c['id']) ?>"><?= e($c['name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="input-group">
            <label>Service Required</label>
            <select name="service_id" id="service_select" required onchange="updatePrice()">
                <option value="">Select Service...</option>
                <?php while($s = mysqli_fetch_assoc($services)): ?>
                    <option value="<?= e($s['id']) ?>" data-price="<?= e($s['price']) ?>"><?= e($s['name']) ?> - $<?= e($s['price']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="input-group">
            <label>Assign Stylist</label>
            <select name="staff_id">
                <option value="">Any Available Stylist</option>
                <?php while($st = mysqli_fetch_assoc($staff)): ?>
                    <option value="<?= e($st['id']) ?>"><?= e($st['name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="input-group">
            <label>Date & Time</label>
            <input type="datetime-local" name="date_time" required>
        </div>

        <div class="input-group">
            <label>Total Amount ($)</label>
            <input type="number" step="0.01" name="total_amount" id="total_amount" placeholder="0.00">
        </div>

        <div class="input-group">
            <label>Special Notes</label>
            <textarea name="notes" rows="2" placeholder="Any special requests?"></textarea>
        </div>

        <button type="submit" name="submit" class="btn-update">Confirm Booking</button>
        <a href="appointment.php" class="back-link">← Back to Appointments</a>
    </form>
</div>

<script>
    // Simple script to auto-fill the price when a service is selected
    function updatePrice() {
        const select = document.getElementById('service_select');
        const priceInput = document.getElementById('total_amount');
        const selectedOption = select.options[select.selectedIndex];
        const price = selectedOption.getAttribute('data-price');
        
        if(price) {
            priceInput.value = price;
        }
    }
</script>

</body>
</html>