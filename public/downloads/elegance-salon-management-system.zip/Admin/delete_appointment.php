<?php
require_once __DIR__ . '/../includes/admin_guard.php';

// Deletes change data, so they require a valid CSRF token (sent in the link or a POST form)
csrf_verify();

$id = input_int($_GET + $_POST, 'id', 1);

if ($id) {
    db_query($conn, "DELETE FROM appointments WHERE id = ?", 'i', [$id]);
}

header("Location: appointment.php");
exit();
?>
