<?php
$allowed_roles = ['admin'];
require_once __DIR__ . '/../includes/admin_guard.php';

$id = input_int($_GET, 'id', 1);

// Fetch user
$user = $id ? db_fetch_one($conn, "SELECT * FROM users WHERE id = ?", 'i', [$id]) : null;

if (!$user) {
    die("User Not Found.");
}

// Update logic
if (isset($_POST['update'])) {

    $username  = input_str($_POST, 'username', 50);
    $email     = input_email($_POST, 'email');
    $role      = input_enum($_POST, 'role', ['admin', 'receptionist', 'stylist', 'user']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $password  = (string) ($_POST['password'] ?? '');

    if ($username === '' || !$email || !$role) {
        js_alert('Please fill in all required fields');
    } elseif ($password !== '' && (strlen($password) < 8 || strlen($password) > 72)) {
        js_alert('Password must be between 8 and 72 characters');
    } elseif (db_fetch_one($conn, "SELECT id FROM users WHERE email = ? AND id != ?", 'si', [$email, $id])) {
        // Check duplicate email
        js_alert('Email already exists!');
    } else {

        if ($password !== '') {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $ok = db_query($conn, "UPDATE users SET username = ?, email = ?, password = ?, role = ?, is_active = ? WHERE id = ?",
                'ssssii', [$username, $email, $hashed, $role, $is_active, $id]);
        } else {
            $ok = db_query($conn, "UPDATE users SET username = ?, email = ?, role = ?, is_active = ? WHERE id = ?",
                'sssii', [$username, $email, $role, $is_active, $id]);
        }

        if ($ok) {
            header("Location: users.php");
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Elegance Salon | Edit User</title>

<link href="https://fonts.googleapis.com/css2?family=Playfair+Display&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">

<style>
:root {
    --bg: #121211;
    --card: #1a1a19;
    --gold: #c5a059;
    --text: #ffffff;
    --dim: #a0a0a0;
    --border: #333330;
}

body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Montserrat', sans-serif;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

/* CARD */
.form-card {
    background: var(--card);
    border: 1px solid var(--border);
    padding: 50px;
    width: 100%;
    max-width: 450px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.5);
}

/* HEADER */
header {
    text-align: center;
    margin-bottom: 40px;
}

header p {
    color: var(--gold);
    font-size: 0.7rem;
    letter-spacing: 4px;
    text-transform: uppercase;
    margin-bottom: 10px;
}

h2 {
    font-family: 'Playfair Display', serif;
    font-size: 2.2rem;
    margin: 0;
    font-weight: 400;
}

h2 span {
    color: var(--gold);
    font-style: italic;
}

/* INPUTS */
.input-group {
    margin-bottom: 30px;
}

label {
    display: block;
    font-size: 0.7rem;
    color: var(--gold);
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin-bottom: 8px;
}

input, select {
    width: 100%;
    background: transparent;
    border: none;
    border-bottom: 1px solid var(--border);
    color: var(--text);
    padding: 10px 0;
    font-size: 1rem;
}

input:focus, select:focus {
    outline: none;
    border-bottom-color: var(--gold);
}

/* CHECKBOX FIX */
.checkbox-group {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-top: -10px;
}

.checkbox-group label {
    margin: 0;
    letter-spacing: 1px;
}

/* BUTTON */
.btn-update {
    width: 100%;
    background-color: var(--gold);
    color: #000;
    border: none;
    padding: 15px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 2px;
    cursor: pointer;
    margin-top: 20px;
}

/* BACK LINK */
.back-link {
    display: block;
    text-align: center;
    margin-top: 25px;
    color: var(--dim);
    text-decoration: none;
    font-size: 0.75rem;
    letter-spacing: 1px;
}

.back-link:hover {
    color: var(--gold);
}
</style>
</head>

<body>

<div class="form-card">

    <header>
        <p>Information Update</p>
        <h2>Edit <span>User</span></h2>
    </header>

    <form method="POST"><?= csrf_field() ?>

        <div class="input-group">
            <label>Username</label>
            <input type="text" name="username" value="<?= e($user['username']) ?>" required>
        </div>

        <div class="input-group">
            <label>Email Address</label>
            <input type="email" name="email" value="<?= e($user['email']) ?>" required>
        </div>

        <div class="input-group">
            <label>New Password</label>
            <input type="password" name="password" placeholder="Leave blank to keep same">
        </div>

        <div class="input-group">
            <label>Role</label>
            <select name="role">
                <option value="admin" <?= $user['role']=='admin'?'selected':'' ?>>Admin</option>
                <option value="stylist" <?= $user['role']=='stylist'?'selected':'' ?>>Stylist</option>
                <option value="receptionist" <?= $user['role']=='receptionist'?'selected':'' ?>>Receptionist</option>
                <option value="user" <?= $user['role']=='user'?'selected':'' ?>>User</option>
            </select>
        </div>

        <div class="input-group checkbox-group">
            <input type="checkbox" name="is_active" <?= $user['is_active'] ? 'checked' : '' ?>>
            <label>Active User</label>
        </div>

        <button type="submit" name="update" class="btn-update">Save Changes</button>

        <a href="users.php" class="back-link">← Discard Changes</a>

    </form>
</div>

</body>
</html>