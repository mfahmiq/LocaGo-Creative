<?php
$allowed_roles = ['admin'];
require_once __DIR__ . '/../includes/admin_guard.php';
$id = input_int($_GET, 'id', 1);

$data = $id ? db_fetch_one($conn, "SELECT * FROM payments WHERE id = ?", 'i', [$id]) : null;
if (!$data) {
    die("Payment Not Found.");
}

if (isset($_POST['save_changes'])) {
    $appt_id = input_int($_POST, 'appointment_id', 1);
    $amount  = input_float($_POST, 'amount', 0);
    $method  = input_enum($_POST, 'payment_method', ['cash', 'card', 'bank_transfer', 'online'], 'cash');
    $status  = isset($_POST['status_check']) ? 'paid' : 'pending'; // Checkbox logic
    $notes   = array_key_exists('notes', $_POST) ? input_str($_POST, 'notes', 2000) : (string) $data['notes'];

    if ($appt_id && $amount !== null && db_fetch_one($conn, "SELECT id FROM appointments WHERE id = ?", 'i', [$appt_id])) {
        $ok = db_query($conn, "UPDATE payments SET appointment_id = ?, amount = ?, payment_method = ?, status = ?, notes = ? WHERE id = ?",
            'idsssi', [$appt_id, $amount, $method, $status, $notes, $id]);
        if ($ok) {
            header("Location: payments.php");
            exit();
        }
    }
    js_alert('Please enter an existing appointment ID and a valid amount.');
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Payment</title>
    <style>
        /* Shared styles from Add page */
        body {
            background: #121212;
            color: white;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .card {
            background: #1a1a1a;
            padding: 50px;
            width: 450px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
        }

        .label-top {
            color: #c5a059;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-size: 10px;
            margin-bottom: 10px;
        }

        h1 {
            font-family: 'Georgia', serif;
            font-size: 32px;
            margin-top: 0;
            font-weight: normal;
        }

        h1 span {
            color: #c5a059;
            font-style: italic;
        }

        .form-group {
            text-align: left;
            margin-bottom: 25px;
        }

        label {
            display: block;
            color: #c5a059;
            font-size: 10px;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            background: transparent;
            border: none;
            border-bottom: 1px solid #333;
            color: white;
            padding: 10px 0;
            font-size: 16px;
            outline: none;
        }

        .status-container {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin: 20px 0;
        }

        .status-label {
            color: #c5a059;
            font-size: 10px;
            text-transform: uppercase;
            width: 60px;
            text-align: left;
        }

        input[type="checkbox"] {
            accent-color: #c5a059;
            transform: scale(1.2);
        }

        .btn {
            background: #c5a059;
            color: black;
            border: none;
            width: 100%;
            padding: 15px;
            font-weight: bold;
            text-transform: uppercase;
            cursor: pointer;
            margin-top: 20px;
        }

        .cancel {
            display: block;
            margin-top: 20px;
            color: #888;
            text-decoration: none;
            font-size: 12px;
        }
    </style>
</head>

<body>

    <div class="card">
        <div class="label-top">Information Update</div>
        <h1>Edit <span>Payment</span></h1>

        <form method="POST"><?= csrf_field() ?>
            <div class="form-group">
                <label>Appointment ID</label>
                <input type="number" name="appointment_id" value="<?php echo e($data['appointment_id']); ?>">
            </div>

            <div class="form-group">
                <label>Amount</label>
                <input type="text" name="amount" value="<?php echo e($data['amount']); ?>">
            </div>

            <div class="form-group">
                <label>Payment Method</label>
                <select name="payment_method">
                    <option value="cash" <?php if ($data['payment_method'] == 'cash') echo 'selected'; ?>>Cash</option>
                    <option value="card" <?php if ($data['payment_method'] == 'card') echo 'selected'; ?>>Card</option>
                </select>
            </div>

            <div class="status-container">
                <input type="checkbox" name="status_check" <?php if ($data['status'] == 'paid') echo 'checked'; ?>>
                <div class="status-label">Mark as Paid</div>
            </div>

            <button type="submit" name="save_changes" class="btn">Save Changes</button>
            <a href="payments.php" class="cancel">← Discard Changes</a>
        </form>
    </div>

</body>

</html>