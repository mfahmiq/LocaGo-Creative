<?php
$allowed_roles = ['admin'];
require_once __DIR__ . '/../includes/admin_guard.php';

$id = input_int($_GET, 'id', 1);

// Fetch staff member
$staff = $id ? db_fetch_one($conn, "SELECT * FROM staff WHERE id = ?", 'i', [$id]) : null;

if (!$staff) {
    die("Staff Member Not Found.");
}

// Update logic
if (isset($_POST['update'])) {

    $name            = input_str($_POST, 'name', 255);
    $role            = input_enum($_POST, 'role', ['stylist', 'receptionist']);
    $phone           = input_str($_POST, 'phone', 20);
    $commission_rate = input_float($_POST, 'commission_rate', 0);

    if ($name === '' || !$role || !valid_phone($phone) || $commission_rate === null || $commission_rate > 1) {
        js_alert('Please fill in all required fields (commission rate between 0 and 1)');
    } elseif (db_fetch_one($conn, "SELECT id FROM staff WHERE phone = ? AND id != ?", 'si', [$phone, $id])) {
        // Check duplicate phone
        js_alert('Phone already exists!');
    } else {
        $ok = db_query($conn, "UPDATE staff SET name = ?, role = ?, phone = ?, commission_rate = ? WHERE id = ?",
            'sssdi', [$name, $role, $phone, $commission_rate, $id]);

        if ($ok) {
            header("Location: staff.php");
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Elegance Salon | Edit Staff</title>

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        :root {
            --bg: #121211;
            --card: #1a1a19;
            --gold: #c5a059;
            --text: #ffffff;
            --dim: #a0a0a0;
            --border: #333330;
        }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        /* CARD */
        .form-card {
            background: var(--card);
            border: 1px solid var(--border);
            padding: 50px;
            width: 100%;
            max-width: 450px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
        }

        /* HEADER */
        header {
            text-align: center;
            margin-bottom: 40px;
        }

        header p {
            color: var(--gold);
            font-size: 0.7rem;
            letter-spacing: 4px;
            text-transform: uppercase;
            margin-bottom: 10px;
        }

        h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.2rem;
            margin: 0;
            font-weight: 400;
        }

        h2 span {
            color: var(--gold);
            font-style: italic;
        }

        /* INPUTS */
        .input-group {
            margin-bottom: 30px;
        }

        label {
            display: block;
            font-size: 0.7rem;
            color: var(--gold);
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-bottom: 8px;
        }

        input,
        select {
            width: 100%;
            background: transparent;
            border: none;
            border-bottom: 1px solid var(--border);
            color: var(--text);
            padding: 10px 0;
            font-size: 1rem;
        }

        input:focus,
        select:focus {
            outline: none;
            border-bottom-color: var(--gold);
        }

        /* CHECKBOX FIX */
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: -10px;
        }

        .checkbox-group label {
            margin: 0;
            letter-spacing: 1px;
        }

        /* BUTTON */
        .btn-update {
            width: 100%;
            background-color: var(--gold);
            color: #000;
            border: none;
            padding: 15px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 2px;
            cursor: pointer;
            margin-top: 20px;
        }

        /* BACK LINK */
        .back-link {
            display: block;
            text-align: center;
            margin-top: 25px;
            color: var(--dim);
            text-decoration: none;
            font-size: 0.75rem;
            letter-spacing: 1px;
        }

        .back-link:hover {
            color: var(--gold);
        }
    </style>
</head>

<body>

    <div class="form-card">

        <header>
            <p>Information Update</p>
            <h2>Edit <span>Staff</span></h2>
        </header>

        <form method="POST"><?= csrf_field() ?>

            <div class="input-group">
                <label>Full Name</label>
                <input type="text" name="name" value="<?= e($staff['name']) ?>" required>
            </div>

            <div class="input-group">
                <label>Role</label>
                <select name="role" required>
                    <option value="">Select Role</option>
                    <option value="receptionist" <?= ($staff['role'] === 'receptionist') ? 'selected' : '' ?>>Receptionist</option>
                    <option value="stylist" <?= ($staff['role'] === 'stylist') ? 'selected' : '' ?>>Stylist</option>
                </select>
            </div>

            <div class="input-group">
                <label>Commission Rate (%)</label>
                <input type="number" name="commission_rate" step="0.01" value="<?= e($staff['commission_rate']) ?>" required>
            </div>

            <div class="input-group">
                <label>Phone Number</label>
                <input type="text" name="phone" value="<?= e($staff['phone']) ?>" required>
            </div>
            <button type="submit" name="update" class="btn-update">Save Changes</button>

            <a href="staff.php" class="back-link">← Discard Changes</a>

        </form>
    </div>

</body>

</html>