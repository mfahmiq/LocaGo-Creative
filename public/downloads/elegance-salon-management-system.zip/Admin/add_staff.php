<?php
$allowed_roles = ['admin'];
require_once __DIR__ . '/../includes/admin_guard.php';

if (isset($_POST['submit'])) {

    // Validate inputs based on the 'staff' table fields
    $name            = input_str($_POST, 'name', 255);
    $role            = input_enum($_POST, 'role', ['stylist', 'receptionist']);
    $phone           = input_str($_POST, 'phone', 20);
    $commission_rate = input_float($_POST, 'commission_rate', 0);

    // Basic validation
    if ($name === '' || !$role || !valid_phone($phone) || $commission_rate === null || $commission_rate > 1) {
        js_alert('Please fill in all required fields (commission rate between 0 and 1)');
    } else {

        // Check if staff member already exists by phone to prevent duplicates
        if (db_fetch_one($conn, "SELECT id FROM staff WHERE phone = ?", 's', [$phone])) {
            js_alert('A staff member with this phone number already exists');
        } else {

            // is_available defaults to 1 (Available)
            $ok = db_query($conn, "INSERT INTO staff (name, role, commission_rate, phone, is_available, created_at) VALUES (?, ?, ?, ?, 1, NOW())",
                'ssds', [$name, $role, $commission_rate, $phone]);

            if ($ok) {
                header("Location: staff.php");
                exit();
            } else {
                js_alert('Error: could not save the staff member');
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Elegance Salon | Add Staff</title>

<link href="https://fonts.googleapis.com/css2?family=Playfair+Display&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">

<style>
:root {
    --bg: #121211;
    --card: #1a1a19;
    --gold: #c5a059;
    --text: #ffffff;
    --dim: #a0a0a0;
    --border: #333330;
}

body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Montserrat', sans-serif;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

.form-card {
    background: var(--card);
    border: 1px solid var(--border);
    padding: 50px;
    width: 100%;
    max-width: 450px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.5);
}

header {
    text-align: center;
    margin-bottom: 40px;
}

header p {
    color: var(--gold);
    font-size: 0.7rem;
    letter-spacing: 4px;
    text-transform: uppercase;
    margin-bottom: 10px;
}

h2 {
    font-family: 'Playfair Display', serif;
    font-size: 2.2rem;
    margin: 0;
    font-weight: 400;
}

h2 span {
    color: var(--gold);
    font-style: italic;
}

.input-group {
    margin-bottom: 30px;
}

label {
    display: block;
    font-size: 0.7rem;
    color: var(--gold);
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin-bottom: 8px;
}

input, select {
    width: 100%;
    background: transparent;
    border: none;
    border-bottom: 1px solid var(--border);
    color: var(--text);
    padding: 10px 0;
    font-size: 1rem;
}

input:focus, select:focus {
    outline: none;
    border-bottom-color: var(--gold);
}

.btn-update {
    width: 100%;
    background-color: var(--gold);
    color: #000;
    border: none;
    padding: 15px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 2px;
    cursor: pointer;
    margin-top: 20px;
}

.back-link {
    display: block;
    text-align: center;
    margin-top: 25px;
    color: var(--dim);
    text-decoration: none;
    font-size: 0.75rem;
    letter-spacing: 1px;
}

.back-link:hover {
    color: var(--gold);
}
</style>
</head>

<body>

<div class="form-card">

    <header>
        <p>Staff Management</p>
        <h2>Add <span>Member</span></h2>
    </header>

    <form method="POST"><?= csrf_field() ?>

        <div class="input-group">
            <label>Full Name</label>
            <input type="text" name="name" value="<?= e($_POST['name'] ?? '') ?>" required>
        </div>

        <div class="input-group">
            <label>Phone Number</label>
            <input type="text" name="phone" value="<?= e($_POST['phone'] ?? '') ?>" placeholder="e.g. +1 234 567 890" required>
        </div>

        <div class="input-group">
            <label>Staff Role</label>
            <select name="role" required>
                <option value="">Select Role</option>
                <option value="">Select Role</option>
                <option value="receptionist" <?= (($_POST['role'] ?? '') === 'receptionist') ? 'selected' : '' ?>>Receptionist</option>
                <option value="stylist" <?= (($_POST['role'] ?? '') === 'stylist') ? 'selected' : '' ?>>Stylist</option>
            </select>
        </div>

        <div class="input-group">
            <label>Commission Rate (%)</label>
            <input type="number" name="commission_rate" step="0.01" value="<?= e($_POST['commission_rate'] ?? '0.00') ?>" required>
        </div>

        <button type="submit" name="submit" class="btn-update">Register Staff</button>

        <a href="staff.php" class="back-link">← Cancel</a>

    </form>
</div>

</body>
</html>