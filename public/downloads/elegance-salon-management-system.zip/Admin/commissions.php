<?php
$allowed_roles = ['admin', 'receptionist'];
require_once __DIR__ . '/../includes/admin_guard.php';

// Fetch staff and calculate commissions
// We multiply total_amount by commission_rate (e.g., 3500.00 * 0.3999)
$query = "SELECT 
            s.name AS staff_name, 
            s.commission_rate,
            COUNT(a.id) AS total_services,
            SUM(a.total_amount) AS total_revenue,
            SUM(a.total_amount * s.commission_rate) AS total_commission
          FROM staff s
          LEFT JOIN appointments a ON s.id = a.staff_id
          GROUP BY s.id";

$result = mysqli_query($conn, $query);

if (!$result) {
    error_log("Commissions query failed: " . mysqli_error($conn));
    die("Could not load commissions.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Elegance Admin | Commissions</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        :root {
            --bg: #121211;
            --card: #1a1a19;
            --gold: #c5a059;
            --text: #ffffff;
            --dim: #a0a0a0;
            --border: #333330;
            --success: #81c784;
        }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            display: flex;
        }

        .main-content {
            flex: 1;
            padding: 40px;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            margin: 0;
        }

        h2 span {
            color: var(--gold);
            font-style: italic;
        }

        .btn-dashboard {
            background: var(--gold);
            color: #000;
            padding: 10px 20px;
            text-decoration: none;
            font-size: 0.8rem;
            font-weight: 600;
            border-radius: 2px;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        /* Table Design matching your screenshots */
        .custom-table-container {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 4px;
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #222221;
            color: var(--gold);
            text-transform: uppercase;
            font-size: 0.7rem;
            letter-spacing: 1px;
            padding: 15px 20px;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }

        td {
            padding: 15px 20px;
            border-bottom: 1px solid var(--border);
            font-size: 0.85rem;
        }

        .revenue-amt { color: var(--dim); }
        .commission-amt { color: var(--success); font-weight: 600; }
    </style>
</head>
<body>



    <div class="main-content">
        <header>
            <div>
                <h2>Staff <span>Commissions</span></h2>
                <p style="color:var(--dim); font-size: 0.8rem;">Earnings tracking based on completed appointments.</p>
            </div>
            <a href="dashboard.php" class="btn-dashboard">
                <i class="fas fa-th-large"></i> Dashboard
            </a>
        </header>

        <div class="custom-table-container">
            <table>
                <thead>
                    <tr>
                        <th>Stylist</th>
                        <th>Rate</th>
                        <th>Services</th>
                        <th>Total Revenue</th>
                        <th>Net Commission</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) { 
                            $revenue = $row['total_revenue'] ?? 0;
                            $commission = $row['total_commission'] ?? 0;
                    ?>
                        <tr>
                            <td><strong><?= e($row['staff_name']) ?></strong></td>
                            <td><?= ($row['commission_rate'] * 100) ?>%</td>
                            <td><?= e($row['total_services']) ?></td>
                            <td class="revenue-amt">Rs. <?= number_format($revenue, 2) ?></td>
                            <td class="commission-amt">Rs. <?= number_format($commission, 2) ?></td>
                        </tr>
                    <?php 
                        } 
                    } else {
                        echo "<tr><td colspan='5' style='padding:50px; text-align:center; color:var(--dim);'>No commission data found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>