<?php
$allowed_roles = ['admin', 'receptionist'];
require_once __DIR__ . '/../includes/admin_guard.php';

$id = input_int($_GET, 'id', 1);

// Fetch supplier
$supplier = $id ? db_fetch_one($conn, "SELECT * FROM suppliers WHERE id = ?", 'i', [$id]) : null;

if (!$supplier) {
    die("Supplier Not Found.");
}

if (isset($_POST['update'])) {
    $name           = input_str($_POST, 'name', 255);
    $contact_person = input_str($_POST, 'contact_person', 255);
    $email_raw      = input_str($_POST, 'email', 255);
    $email          = $email_raw === '' ? '' : input_email($_POST, 'email');
    $phone          = input_str($_POST, 'phone', 50);
    $address        = input_str($_POST, 'address', 2000);

    if ($name !== '' && $email !== null && ($phone === '' || valid_phone($phone))
        && db_query($conn, "UPDATE suppliers SET name = ?, contact_person = ?, email = ?, phone = ?, address = ? WHERE id = ?",
            'sssssi', [$name, $contact_person, $email, $phone, $address, $id])) {
        header("Location: suppliers.php");
        exit();
    }
    js_alert('Please enter a supplier name and a valid email / phone.');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Elegance Salon | Edit Supplier</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* Reuse CSS from above */
        :root {
            --bg: #121211;
            --card: #1a1a19;
            --gold: #c5a059;
            --text: #ffffff;
            --dim: #a0a0a0;
            --border: #333330;
        }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .form-card {
            background: var(--card);
            border: 1px solid var(--border);
            padding: 50px;
            width: 100%;
            max-width: 450px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
        }

        header {
            text-align: center;
            margin-bottom: 40px;
        }

        header p {
            color: var(--gold);
            font-size: 0.7rem;
            letter-spacing: 4px;
            text-transform: uppercase;
            margin-bottom: 10px;
        }

        h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.2rem;
            margin: 0;
            font-weight: 400;
        }

        h2 span {
            color: var(--gold);
            font-style: italic;
        }

        .input-group {
            margin-bottom: 30px;
        }

        label {
            display: block;
            font-size: 0.7rem;
            color: var(--gold);
            text-transform: uppercase;
            letter-spacing: 1.5px;
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            background: transparent;
            border: none;
            border-bottom: 1px solid var(--border);
            color: var(--text);
            padding: 10px 0;
            font-size: 1rem;
        }

        input:focus {
            outline: none;
            border-bottom-color: var(--gold);
        }

        .btn-update {
            width: 100%;
            background-color: var(--gold);
            color: #000;
            border: none;
            padding: 15px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 2px;
            cursor: pointer;
            margin-top: 20px;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 25px;
            color: var(--dim);
            text-decoration: none;
            font-size: 0.75rem;
            letter-spacing: 1px;
        }
    </style>
</head>

<body>
    <div class="form-card">
        <header>
            <p>Partnership Update</p>
            <h2>Edit <span>Supplier</span></h2>
        </header>
        <form method="POST"><?= csrf_field() ?>
            <div class="input-group">
                <label>Company Name</label>
                <input type="text" name="name" value="<?= e($supplier['name']) ?>" required>
            </div>
            <div class="input-group">
                <label>Contact Person</label>
                <input type="text" name="contact_person" value="<?= e($supplier['contact_person']) ?>" required>
            </div>
            <div class="input-group">
                <label>Email Address</label>
                <input type="email" name="email" value="<?= e($supplier['email']) ?>" required>
            </div>
            <div class="input-group">
                <label>Phone</label>
                <input type="text" name="phone" value="<?= e($supplier['phone']) ?>" required>
            </div>
            <div class="input-group">
                <label>Address</label>
                <input type="text" name="address" value="<?= e($supplier['address']) ?>">
            </div>
            <button type="submit" name="update" class="btn-update">Save Changes</button>
            <a href="suppliers.php" class="back-link">← Discard Changes</a>
        </form>
    </div>
</body>

</html>