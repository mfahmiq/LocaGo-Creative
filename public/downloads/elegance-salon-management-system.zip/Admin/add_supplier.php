<?php
$allowed_roles = ['admin', 'receptionist'];
require_once __DIR__ . '/../includes/admin_guard.php';

if (isset($_POST['submit'])) {
    $company_name   = input_str($_POST, 'name', 255);
    $contact_person = input_str($_POST, 'contact_person', 255);
    $email_raw      = input_str($_POST, 'email', 255);
    $email          = $email_raw === '' ? '' : input_email($_POST, 'email');
    $phone          = input_str($_POST, 'phone', 50);
    $address        = input_str($_POST, 'address', 2000);

    if ($company_name === '' || $email === null || ($phone !== '' && !valid_phone($phone))) {
        $error = "Please enter a supplier name and a valid email / phone.";
    } else {
        $ok = db_query($conn, "INSERT INTO suppliers (name, contact_person, email, phone, address, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
            'sssss', [$company_name, $contact_person, $email, $phone, $address]);

        if ($ok) {
            header("Location: suppliers.php");
            exit();
        } else {
            $error = "Error adding supplier.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Elegance Salon | Add User</title>

<link href="https://fonts.googleapis.com/css2?family=Playfair+Display&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">

<style>
:root {
    --bg: #121211;
    --card: #1a1a19;
    --gold: #c5a059;
    --text: #ffffff;
    --dim: #a0a0a0;
    --border: #333330;
}

body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Montserrat', sans-serif;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

/* CARD */
.form-card {
    background: var(--card);
    border: 1px solid var(--border);
    padding: 50px;
    width: 100%;
    max-width: 450px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.5);
}

/* HEADER */
header {
    text-align: center;
    margin-bottom: 40px;
}

header p {
    color: var(--gold);
    font-size: 0.7rem;
    letter-spacing: 4px;
    text-transform: uppercase;
    margin-bottom: 10px;
}

h2 {
    font-family: 'Playfair Display', serif;
    font-size: 2.2rem;
    margin: 0;
    font-weight: 400;
}

h2 span {
    color: var(--gold);
    font-style: italic;
}

/* ALERTS */
.alert {
    padding: 12px;
    margin-bottom: 25px;
    font-size: 0.8rem;
}

.alert-success {
    background: #0d2b0d;
    color: #4caf50;
}

.alert-error {
    background: #2b0d0d;
    color: #e74c3c;
}

/* INPUTS */
.input-group {
    margin-bottom: 30px;
}

label {
    display: block;
    font-size: 0.7rem;
    color: var(--gold);
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin-bottom: 8px;
}

input, select {
    width: 100%;
    background: transparent;
    border: none;
    border-bottom: 1px solid var(--border);
    color: var(--text);
    padding: 10px 0;
    font-size: 1rem;
}

input:focus, select:focus {
    outline: none;
    border-bottom-color: var(--gold);
}

/* BUTTON */
.btn-update {
    width: 100%;
    background-color: var(--gold);
    color: #000;
    border: none;
    padding: 15px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 2px;
    cursor: pointer;
    margin-top: 20px;
}

/* BACK */
.back-link {
    display: block;
    text-align: center;
    margin-top: 25px;
    color: var(--dim);
    text-decoration: none;
    font-size: 0.75rem;
    letter-spacing: 1px;
}

.back-link:hover {
    color: var(--gold);
}
</style>
</head>

<body>
<div class="form-card">
    <header>
        <p>Partnership Directory</p>
        <h2>Add <span>Supplier</span></h2>
    </header>

    <?php if (isset($error)): ?>
        <div class="alert alert-error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="POST"><?= csrf_field() ?>
        <div class="input-group">
            <label>Company Name</label>
            <input type="text" name="name" required>
        </div>
        <div class="input-group">
            <label>Contact Person</label>
            <input type="text" name="contact_person" required>
        </div>
        <div class="input-group">
            <label>Email Address</label>
            <input type="email" name="email" required>
        </div>
        <div class="input-group">
            <label>Phone Number</label>
            <input type="text" name="phone" required>
        </div>
        <div class="input-group">
            <label>Office Address</label>
            <input type="text" name="address">
        </div>

        <button type="submit" name="submit" class="btn-update">Save Supplier</button>
        <a href="suppliers.php" class="back-link">← Cancel</a>
    </form>
</div>
</body>