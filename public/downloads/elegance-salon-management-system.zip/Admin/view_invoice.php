<?php
$allowed_roles = ['admin'];
require_once __DIR__ . '/../includes/admin_guard.php';

// Get the ID from the URL
$id = input_int($_GET, 'id', 1);
if (!$id) {
    // If no ID is provided, go back to the list
    header("Location: invoices.php");
    exit();
}

// Fetch the specific invoice data
$invoice = db_fetch_one($conn, "SELECT * FROM invoices WHERE id = ?", 'i', [$id]);
if (!$invoice) {
    header("Location: invoices.php");
    exit();
}

// Basic Tax Calculation (Assuming 13% as per your template)
$subtotal = $invoice['total_amount'];
$tax_rate = 0.13;
$tax_amount = $subtotal * $tax_rate;
$grand_total = $subtotal + $tax_amount;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice #<?php echo (int) $id; ?> - Elegance Salon</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600&family=Playfair+Display:ital,wght@0,400;1,400&display=swap" rel="stylesheet">
    <style>
        /* (I kept your exact CSS styles here for consistency) */
        :root { --gold: #c5a059; --dark: #121212; --gray: #f4f4f4; --text-muted: #777; }
        body { background-color: #f9f9f9; font-family: 'Montserrat', sans-serif; color: var(--dark); margin: 0; padding: 20px; }
        .invoice-container { background-color: #fff; max-width: 850px; margin: 0 auto; padding: 50px; border: 1px solid #ddd; box-shadow: 0 0 20px rgba(0, 0, 0, 0.05); }
        .invoice-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; }
        .brand h1 { font-family: 'Playfair Display', serif; font-size: 2rem; letter-spacing: 2px; margin:0; }
        .brand span { color: var(--gold); font-weight: 300; }
        .brand p { font-size: 0.7rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; margin:5px 0; }
        .invoice-meta h2 { font-family: 'Playfair Display', serif; color: var(--gold); margin:0 0 10px 0; }
        .invoice-meta p { font-size: 0.85rem; margin: 3px 0; }
        .gold-divider { border: 0; height: 2px; background: var(--gold); margin: 30px 0; }
        .info-section { display: flex; justify-content: space-between; margin-bottom: 40px; }
        .info-box h3 { font-size: 0.8rem; text-transform: uppercase; color: var(--gold); margin-bottom: 10px; }
        .info-box p { font-size: 0.9rem; line-height: 1.5; margin: 0; }
        .invoice-table { width: 100%; border-collapse: collapse; margin-bottom: 40px; }
        .invoice-table th { text-align: left; background-color: var(--dark); color: #fff; padding: 12px; font-size: 0.8rem; text-transform: uppercase; }
        .invoice-table td { padding: 15px 12px; border-bottom: 1px solid #eee; font-size: 0.95rem; }
        .total-section { display: flex; justify-content: space-between; align-items: flex-end; }
        .paid-status { color: #27ae60; font-weight: bold; letter-spacing: 1px; }
        .calculation-box { width: 300px; }
        .calc-row { display: flex; justify-content: space-between; padding: 8px 0; font-size: 0.9rem; }
        .grand-total { border-top: 2px solid var(--gold); margin-top: 10px; padding-top: 15px; font-weight: 600; font-size: 1.1rem; color: var(--dark); }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .invoice-footer { margin-top: 60px; text-align: center; border-top: 1px solid #eee; padding-top: 20px; }
        .invoice-footer p { font-style: italic; font-family: 'Playfair Display', serif; color: var(--text-muted); font-size: 0.9rem; }
        .no-print { margin-top: 20px; background: var(--gold); color: white; border: none; padding: 10px 25px; cursor: pointer; text-transform: uppercase; font-weight: 600; }
        @media print { body { background: white; padding: 0; } .invoice-container { border: none; box-shadow: none; width: 100%; } .no-print { display: none; } }
    </style>
</head>

<body>

    <div class="invoice-container">
        <header class="invoice-header">
            <div class="brand">
                <h1>ELEGANCE <span>SALON</span></h1>
                <p>Karachi's Premier Salon</p>
            </div>
            <div class="invoice-meta">
                <h2>INVOICE</h2>
                <p><strong>Invoice #:</strong> INV-<?php echo str_pad($invoice['id'], 4, "0", STR_PAD_LEFT); ?></p>
                <p><strong>Date:</strong> <?php echo date("F d, Y", strtotime($invoice['invoice_date'])); ?></p>
            </div>
        </header>

        <hr class="gold-divider">

        <section class="info-section">
            <div class="info-box">
                <h3>Billed To:</h3>
                <p><strong><?php echo e($invoice['client_name']); ?></strong></p>
                <p>Valued Customer</p>
            </div>
            <div class="info-box text-right">
                <h3>From:</h3>
                <p><strong>Elegance Salon HQ</strong></p>
                <p>Zamzama Commercial Area</p>
                <p>DHA Phase 5, Karachi</p>
            </div>
        </section>

        <table class="invoice-table">
            <thead>
                <tr>
                    <th>Service / Product</th>
                    <th class="text-right">Price</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Services Rendered (Total Package)</td>
                    <td class="text-right"><?php echo number_format($subtotal); ?></td>
                </tr>
            </tbody>
        </table>

        <section class="total-section">
            <div class="payment-method">
                <p><strong>Status:</strong> <span class="paid-status"><?php echo e(strtoupper($invoice['status'])); ?></span></p>
            </div>
            <div class="calculation-box">
                <div class="calc-row">
                    <span>Subtotal:</span>
                    <span><?php echo number_format($subtotal); ?></span>
                </div>
                <div class="calc-row">
                    <span>Tax (13%):</span>
                    <span><?php echo number_format($tax_amount); ?></span>
                </div>
                <div class="calc-row grand-total">
                    <span>Grand Total (PKR):</span>
                    <span><?php echo number_format($grand_total); ?></span>
                </div>
            </div>
        </section>

        <footer class="invoice-footer">
            <p>Thank you for choosing Elegance. Where beauty finds its true expression.</p>
            <button onclick="window.print()" class="no-print">Print Invoice</button>
            <button onclick="location.href='invoices.php'" class="no-print" style="background:#444">Back</button>
        </footer>
    </div>

</body>
</html>