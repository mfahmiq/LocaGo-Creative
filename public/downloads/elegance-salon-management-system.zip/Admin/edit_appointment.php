<?php
require_once __DIR__ . '/../includes/admin_guard.php';

$id = input_int($_GET, 'id', 1);

// Fetch existing appointment details
$appointment = $id ? db_fetch_one($conn, "SELECT a.*, c.name AS client_name, st.name AS staff_name 
          FROM appointments a
          LEFT JOIN clients c ON a.client_id = c.id
          LEFT JOIN staff st ON a.staff_id = st.id
          WHERE a.id = ?", 'i', [$id]) : null;

if (!$appointment) {
    die("Appointment Not Found.");
}

// Fetch lists for the dropdowns
$staff    = mysqli_query($conn, "SELECT id, name FROM staff WHERE role = 'stylist'");
$services = mysqli_query($conn, "SELECT id, name FROM services");

// Update logic
if (isset($_POST['update'])) {

    $service_id   = input_int($_POST, 'service_id', 1);
    $staff_id     = input_int($_POST, 'staff_id', 1);
    $date_time    = input_datetime($_POST, 'date_time');
    $status       = input_enum($_POST, 'status', ['pending', 'confirmed', 'completed', 'cancelled', 'no_show']);
    $total_amount = input_float($_POST, 'total_amount', 0);
    $notes        = input_str($_POST, 'notes', 2000);

    if (!$service_id || !$date_time || !$status || $total_amount === null) {
        js_alert('Update failed: please check the values.');
    } elseif (db_query($conn, "UPDATE appointments SET service_id = ?, staff_id = ?, date_time = ?, status = ?, total_amount = ?, notes = ?, updated_at = NOW() WHERE id = ?",
            'iissdsi', [$service_id, $staff_id, $date_time, $status, $total_amount, $notes, $id])) {
        header("Location: appointment.php");
        exit();
    } else {
        js_alert('Update failed: please check the values.');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Elegance Salon | Edit Appointment</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">

<style>
:root {
    --bg: #121211;
    --card: #1a1a19;
    --gold: #c5a059;
    --text: #ffffff;
    --dim: #a0a0a0;
    --border: #333330;
}

body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Montserrat', sans-serif;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    padding: 40px 0;
}

.form-card {
    background: var(--card);
    border: 1px solid var(--border);
    padding: 50px;
    width: 100%;
    max-width: 500px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.5);
}

header {
    text-align: center;
    margin-bottom: 40px;
}

header p {
    color: var(--gold);
    font-size: 0.7rem;
    letter-spacing: 4px;
    text-transform: uppercase;
    margin-bottom: 10px;
}

h2 {
    font-family: 'Playfair Display', serif;
    font-size: 2.2rem;
    margin: 0;
    font-weight: 400;
}

h2 span {
    color: var(--gold);
    font-style: italic;
}

.input-group {
    margin-bottom: 25px;
}

label {
    display: block;
    font-size: 0.7rem;
    color: var(--gold);
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin-bottom: 8px;
}

input, select, textarea {
    width: 100%;
    background: transparent;
    border: none;
    border-bottom: 1px solid var(--border);
    color: var(--text);
    padding: 10px 0;
    font-size: 1rem;
}

input:focus, select:focus, textarea:focus {
    outline: none;
    border-bottom-color: var(--gold);
}

input[type="datetime-local"]::-webkit-calendar-picker-indicator {
    filter: invert(1);
}

.btn-update {
    width: 100%;
    background-color: var(--gold);
    color: #000;
    border: none;
    padding: 15px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 2px;
    cursor: pointer;
    margin-top: 20px;
}

.back-link {
    display: block;
    text-align: center;
    margin-top: 25px;
    color: var(--dim);
    text-decoration: none;
    font-size: 0.75rem;
    letter-spacing: 1px;
}

.back-link:hover {
    color: var(--gold);
}

.client-info {
    text-align: center;
    color: var(--dim);
    font-size: 0.8rem;
    margin-bottom: 20px;
    border: 1px solid var(--border);
    padding: 10px;
}
</style>
</head>

<body>

<div class="form-card">
    <header>
        <p>Manage Reservation #<?= $id ?></p>
        <h2>Edit <span>Appointment</span></h2>
    </header>

    <div class="client-info">
        Client: <strong style="color:var(--text)"><?= e($appointment['client_name']) ?></strong>
    </div>

    <form method="POST"><?= csrf_field() ?>

        <div class="input-group">
            <label>Service</label>
            <select name="service_id">
                <?php while($s = mysqli_fetch_assoc($services)): ?>
                    <option value="<?= e($s['id']) ?>" <?= $appointment['service_id'] == $s['id'] ? 'selected' : '' ?>>
                        <?= e($s['name']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="input-group">
            <label>Assigned Stylist</label>
            <select name="staff_id">
                <?php while($st = mysqli_fetch_assoc($staff)): ?>
                    <option value="<?= e($st['id']) ?>" <?= $appointment['staff_id'] == $st['id'] ? 'selected' : '' ?>>
                        <?= e($st['name']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="input-group">
            <label>Date & Time</label>
            <input type="datetime-local" name="date_time" value="<?= date('Y-m-d\TH:i', strtotime($appointment['date_time'])) ?>" required>
        </div>

        <div class="input-group">
            <label>Current Status</label>
            <select name="status">
                <option value="Pending" <?= strtolower($appointment['status'])=='pending'?'selected':'' ?>>Pending</option>
                <option value="Confirmed" <?= strtolower($appointment['status'])=='confirmed'?'selected':'' ?>>Confirmed</option>
                <option value="Completed" <?= strtolower($appointment['status'])=='completed'?'selected':'' ?>>Completed</option>
                <option value="Cancelled" <?= strtolower($appointment['status'])=='cancelled'?'selected':'' ?>>Cancelled</option>
            </select>
        </div>

        <div class="input-group">
            <label>Total Amount ($)</label>
            <input type="number" step="0.01" name="total_amount" value="<?= e($appointment['total_amount']) ?>">
        </div>

        <div class="input-group">
            <label>Notes</label>
            <textarea name="notes" rows="2"><?= e($appointment['notes']) ?></textarea>
        </div>

        <button type="submit" name="update" class="btn-update">Update Reservation</button>

        <a href="appointment.php" class="back-link">← Return to List</a>

    </form>
</div>

</body>
</html>