<?php
$allowed_roles = ['admin'];
require_once __DIR__ . '/../includes/admin_guard.php';

// Deletes change data, so they require a valid CSRF token (sent in the link or a POST form)
csrf_verify();

$id = input_int($_GET + $_POST, 'id', 1);

// An admin cannot delete their own account
if ($id && $id !== (int) $_SESSION['user_id']) {
    db_query($conn, "DELETE FROM users WHERE id = ?", 'i', [$id]);
}

header("Location: users.php");
exit();
?>
