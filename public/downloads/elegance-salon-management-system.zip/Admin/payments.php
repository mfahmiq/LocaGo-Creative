<?php
$allowed_roles = ['admin'];
require_once __DIR__ . '/../includes/admin_guard.php';

// Fetch payments from the database
$sql = "SELECT id, appointment_id, amount, payment_method, status, paid_at, notes FROM payments ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Directory | Administration</title>
    <style>
        :root {
            --bg-color: #0d0d0d;
            --card-bg: #161616;
            --gold: #c5a059;
            --text-main: #ffffff;
            --text-muted: #888888;
            --danger: #e74c3c;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-main);
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 50px;
        }

        /* Header UI */
        .admin-label {
            color: var(--gold);
            text-transform: uppercase;
            letter-spacing: 3px;
            font-size: 11px;
            margin-bottom: 5px;
        }

        .header-flex {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }

        .header-flex h1 {
            font-family: 'Georgia', serif;
            font-size: 42px;
            margin: 0;
            font-weight: normal;
        }

        .header-flex h1 span {
            font-style: italic;
            color: var(--gold);
        }

        .nav-buttons button {
            background-color: var(--gold);
            border: none;
            padding: 12px 20px;
            font-weight: bold;
            cursor: pointer;
            margin-left: 10px;
            text-transform: uppercase;
            font-size: 12px;
            transition: 0.3s;
        }

        .nav-buttons button:hover { background-color: #a68445; }

        /* Table Container */
        .table-container {
            background-color: var(--card-bg);
            border: 1px solid #222;
            padding: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            color: var(--gold);
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 1px;
            padding: 20px;
            border-bottom: 1px solid #333;
        }

        td {
            padding: 18px 20px;
            border-bottom: 1px solid #222;
            font-size: 14px;
            color: #ccc;
        }

        .id-cell { color: var(--gold); font-weight: bold; }
        .amt-cell { color: #fff; font-weight: 500; }
        
        /* Status Badges */
        .status { padding: 4px 8px; border-radius: 3px; font-size: 11px; text-transform: uppercase; }
        .paid { color: #2ecc71; }
        .pending { color: #f1c40f; }

        .actions a { text-decoration: none; font-size: 11px; text-transform: uppercase; }
        .edit-link { color: var(--gold); }
        .delete-link { color: var(--danger); }
        .sep { color: #444; margin: 0 5px; }
    </style>
</head>
<body>

    <div class="admin-label">Administration</div>
    
    <div class="header-flex">
        <h1>Payment <span>Directory</span></h1>
        <div class="nav-buttons">
            <button onclick="location.href='add_payment.php'">Add New Payment</button>
            <button style="background-color: #b38f4d;" onclick="location.href='dashboard.php'">Back to Dashboard</button>
        </div>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Appt ID</th>
                    <th>Amount</th>
                    <th>Method</th>
                    <th>Status</th>
                    <th>Paid At</th>
                    <th>Notes</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td class="id-cell"><?php echo e($row['id']); ?></td>
                        <td>#<?php echo e($row['appointment_id']); ?></td>
                        <td class="amt-cell">$<?php echo number_format($row['amount'], 2); ?></td>
                        <td><?php echo e(strtoupper($row['payment_method'])); ?></td>
                        <td>
                            <span class="status <?php echo ($row['status'] == 'paid') ? 'paid' : 'pending'; ?>">
                                <?php echo e($row['status']); ?>
                            </span>
                        </td>
                        <td><?php echo $row['paid_at'] ? date('M d, Y', strtotime($row['paid_at'])) : '---'; ?></td>
                        <td style="font-size: 12px; color: #777;"><?php echo e($row['notes']); ?></td>
                        <td class="actions">
                            <a href="edit-payment.php?id=<?php echo e($row['id']); ?>" class="edit-link">Edit</a>
                            <span class="sep">|</span>
                            <a href="delete_payment.php?id=<?php echo (int) $row['id']; ?>&amp;csrf_token=<?= e(csrf_token()) ?>" class="delete-link" onclick="return confirm('Delete record?')">Delete</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px;">No payment records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</body>
</html>
