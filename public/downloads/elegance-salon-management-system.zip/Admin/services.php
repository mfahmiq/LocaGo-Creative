<?php
require_once __DIR__ . '/../includes/admin_guard.php';

// Fetch all services
$sql = "SELECT * FROM services";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Administration - Inventory</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600&family=Playfair+Display:ital,wght@0,400;1,400&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: #0f0f0f;
            /* Very dark background */
            color: #ffffff;
            font-family: 'Montserrat', sans-serif;
            padding: 60px;
        }

        .admin-container {
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Header Section */
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-bottom: 40px;
        }

        .subtitle {
            font-size: 0.7rem;
            letter-spacing: 3px;
            color: #c5a059;
            /* Gold accent */
            margin-bottom: 10px;
        }

        h1 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            font-weight: 400;
        }

        h1 span {
            font-style: italic;
            color: #c5a059;
        }

        .add-btn {
            background-color: #c5a059;
            color: #000;
            border: none;
            padding: 12px 25px;
            font-weight: 600;
            letter-spacing: 1px;
            cursor: pointer;
            font-family: 'Montserrat', sans-serif;
            font-size: 0.8rem;
        }

        /* Table Card */
        .table-card {
            background-color: #161616;
            /* Darker card background */
            border: 1px solid #222;
            padding: 20px 40px;
        }

        .admin-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .admin-table th {
            text-align: left;
            color: #c5a059;
            font-size: 0.75rem;
            letter-spacing: 2px;
            padding: 20px 10px;
            border-bottom: 1px solid #333;
        }

        .admin-table td {
            padding: 20px 10px;
            border-bottom: 1px solid #222;
            font-size: 0.9rem;
            color: #ccc;
        }

        .item-name {
            color: #fff;
            font-weight: 400;
        }

        /* Actions Links */
        .actions {
            font-size: 0.8rem;
            letter-spacing: 1px;
        }

        .edit-link {
            color: #c5a059;
            text-decoration: none;
        }

        .delete-link {
            color: #e74c3c;
            /* Red for delete */
            text-decoration: none;
        }

        .edit-link:hover,
        .delete-link:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <div class="admin-container">
        <header class="admin-header">
            <div class="title-group">
                <p class="subtitle">ADMINISTRATION</p>
                <h1>Services <span>Directory</span></h1>
            </div>
                <div>
        <a href="add_service.php" class="add-btn">Add New Service</a>
        <a href="dashboard.php" class="add-btn">Back to Dashboard</a>
    </div>
        </header>

        <div class="table-card">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NAME</th>
                        <th>CATEGORY</th>
                        <th>DURATION (MIN)</th>
                        <th>PRICE (PKR)</th>
                        <th class="actions-head">ACTIONS</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . (int) $row['id'] . "</td>";
                            echo "<td class='item-name'>" . e($row['name']) . "</td>";
                            echo "<td>" . e($row['category']) . "</td>";
                            echo "<td>" . e($row['duration_minutes']) . "</td>";
                            echo "<td>" . number_format($row['price']) . "</td>";
                            echo "<td class='actions'>
                                <a href='edit_service.php?id=" . (int) $row['id'] . "' class='edit-link'>EDIT</a> | 
                                <a href='delete_service.php?id=" . (int) $row['id'] . "&amp;csrf_token=" . e(csrf_token()) . "' class='delete-link' onclick=\"return confirm('Delete this service?')\">DELETE</a>
                              </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6' style='text-align:center;'>No services found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>