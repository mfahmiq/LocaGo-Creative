<?php
require_once __DIR__ . '/../includes/admin_guard.php';

// Using a JOIN query to get names instead of just IDs for a better UI
$query = "SELECT 
            a.id, 
            c.name AS client_name, 
            s.name AS service_name, 
            st.name AS staff_name, 
            a.date_time, 
            a.status, 
            a.total_amount 
          FROM appointments a
          LEFT JOIN clients c ON a.client_id = c.id
          LEFT JOIN services s ON a.service_id = s.id
          LEFT JOIN staff st ON a.staff_id = st.id
          ORDER BY a.date_time DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elegance Salon | Appointment Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;1,400&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --bg-color: #121211;
            --card-bg: #1a1a19;
            --gold: #c5a059;
            --text-main: #ffffff;
            --text-dim: #a0a0a0;
            --accent-border: #333330;
            --status-pending: #f39c12;
            --status-completed: #27ae60;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-main);
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 40px;
            display: flex;
            justify-content: center;
        }

        .container {
            width: 100%;
            max-width: 1200px;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-bottom: 40px;
            border-bottom: 1px solid var(--accent-border);
            padding-bottom: 20px;
        }

        h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            margin: 0;
            font-weight: 400;
        }

        h2 span {
            color: var(--gold);
            font-style: italic;
        }

        .btn-group {
            display: flex;
            gap: 10px;
        }

        .btn-add {
            background-color: var(--gold);
            color: #000;
            text-decoration: none;
            padding: 12px 24px;
            font-size: 0.8rem;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            transition: opacity 0.3s ease;
        }

        .btn-add:hover {
            opacity: 0.8;
        }

        /* Table Styling */
        .table-wrapper {
            background: var(--card-bg);
            padding: 20px;
            border: 1px solid var(--accent-border);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th {
            text-transform: uppercase;
            font-size: 0.7rem;
            letter-spacing: 2px;
            color: var(--gold);
            padding: 15px;
            border-bottom: 1px solid var(--accent-border);
        }

        td {
            padding: 20px 15px;
            font-size: 0.85rem;
            color: var(--text-dim);
            border-bottom: 1px solid #252524;
        }

        .status-badge {
            font-size: 0.7rem;
            padding: 4px 8px;
            border: 1px solid var(--gold);
            color: var(--gold);
            text-transform: uppercase;
            font-weight: 600;
        }

        .price {
            color: var(--text-main);
            font-weight: 600;
        }

        tr:hover td {
            color: var(--text-main);
            background-color: #222220;
        }

        .action-links a {
            color: var(--gold);
            text-decoration: none;
            font-size: 0.75rem;
            margin: 0 5px;
            transition: border-bottom 0.3s;
            border-bottom: 1px solid transparent;
        }

        .action-links a:hover {
            border-bottom: 1px solid var(--gold);
        }

        .delete-link {
            color: #e74c3c !important;
        }
    </style>
</head>
<body>

<div class="container">
    <header>
        <div>
            <p style="color: var(--gold); font-size: 0.7rem; letter-spacing: 3px; margin-bottom: 10px;">RESERVATIONS</p>
            <h2>Appointment <span>Directory</span></h2>
        </div>
        <div class="btn-group">
            <a href="add_appointment.php" class="btn-add">New Booking</a>
            <a href="dashboard.php" class="btn-add">Dashboard</a>
        </div>
    </header>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Date & Time</th>
                    <th>Client</th>
                    <th>Service</th>
                    <th>Staff</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td style="color: var(--gold); font-weight: 600;">#<?php echo e($row['id']); ?></td>
                    <td style="color: var(--text-main);">
                        <?php echo date('M d, Y', strtotime($row['date_time'])); ?><br>
                        <small style="color: var(--gold);"><?php echo date('h:i A', strtotime($row['date_time'])); ?></small>
                    </td>
                    <td><?php echo e($row['client_name'] ?? 'Unknown'); ?></td>
                    <td><?php echo e($row['service_name'] ?? 'N/A'); ?></td>
                    <td><?php echo e($row['staff_name'] ?? 'Unassigned'); ?></td>
                    <td class="price">$<?php echo number_format($row['total_amount'], 2); ?></td>
                    <td><span class="status-badge"><?php echo e($row['status']); ?></span></td>
                    <td class="action-links">
                        <a href="edit_appointment.php?id=<?php echo e($row['id']); ?>">VIEW / EDIT</a>
                        <span style="color: #444;">|</span>
                        <a href="delete_appointment.php?id=<?php echo (int) $row['id']; ?>&amp;csrf_token=<?= e(csrf_token()) ?>" class="delete-link" onclick="return confirm('Cancel this appointment?')">CANCEL</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>