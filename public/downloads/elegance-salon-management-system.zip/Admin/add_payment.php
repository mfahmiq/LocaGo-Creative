<?php
$allowed_roles = ['admin'];
require_once __DIR__ . '/../includes/admin_guard.php';

if (isset($_POST['add_payment'])) {
    $appt_id = input_int($_POST, 'appointment_id', 1);
    $amount  = input_float($_POST, 'amount', 0);
    $method  = input_enum($_POST, 'payment_method', ['cash', 'card', 'bank_transfer', 'online'], 'cash');
    $status  = input_enum($_POST, 'status', ['pending', 'paid', 'partial', 'refunded'], 'pending');
    $notes   = input_str($_POST, 'notes', 2000);

    if ($appt_id && $amount !== null && db_fetch_one($conn, "SELECT id FROM appointments WHERE id = ?", 'i', [$appt_id])) {
        $ok = db_query($conn, "INSERT INTO payments (appointment_id, amount, payment_method, status, notes) VALUES (?, ?, ?, ?, ?)",
            'idsss', [$appt_id, $amount, $method, $status, $notes]);
        if ($ok) {
            header("Location: payments.php");
            exit();
        }
    }
    js_alert('Please enter an existing appointment ID and a valid amount.');
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Payment</title>
    <style>
        body { background: #121212; color: white; font-family: 'Segoe UI', sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .card { background: #1a1a1a; padding: 50px; width: 450px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); text-align: center; }
        .label-top { color: #c5a059; text-transform: uppercase; letter-spacing: 2px; font-size: 10px; margin-bottom: 10px; }
        h1 { font-family: 'Georgia', serif; font-size: 32px; margin-top: 0; font-weight: normal; }
        h1 span { color: #c5a059; font-style: italic; }
        
        .form-group { text-align: left; margin-bottom: 25px; }
        label { display: block; color: #c5a059; font-size: 10px; font-weight: bold; text-transform: uppercase; margin-bottom: 5px; }
        
        input[type="text"], input[type="number"], select, textarea {
            width: 100%; background: transparent; border: none; border-bottom: 1px solid #333; color: white; padding: 10px 0; font-size: 16px; outline: none;
        }
        input:focus { border-bottom: 1px solid #c5a059; }
        
        .btn { background: #c5a059; color: black; border: none; width: 100%; padding: 15px; font-weight: bold; text-transform: uppercase; cursor: pointer; margin-top: 20px; letter-spacing: 1px; }
        .cancel { display: block; margin-top: 20px; color: #888; text-decoration: none; font-size: 12px; }
    </style>
</head>
<body>

<div class="card">
    <div class="label-top">Transaction Entry</div>
    <h1>Add <span>Payment</span></h1>

    <form method="POST"><?= csrf_field() ?>
        <div class="form-group">
            <label>Appointment ID</label>
            <input type="number" name="appointment_id" required>
        </div>

        <div class="form-group">
            <label>Amount</label>
            <input type="text" name="amount" required placeholder="0.00">
        </div>

        <div class="form-group">
            <label>Payment Method</label>
            <select name="payment_method">
                <option value="cash">Cash</option>
                <option value="card">Card</option>
                <option value="online">Online</option>
            </select>
        </div>

        <div class="form-group">
            <label>Status</label>
            <select name="status">
                <option value="pending">Pending</option>
                <option value="paid">Paid</option>
            </select>
        </div>

        <button type="submit" name="add_payment" class="btn">Create Record</button>
        <a href="payments.php" class="cancel">← Cancel</a>
    </form>
</div>

</body>
</html>