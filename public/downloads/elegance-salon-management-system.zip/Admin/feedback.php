<?php
$allowed_roles = ['admin', 'receptionist'];
require_once __DIR__ . '/../includes/admin_guard.php';

// Fetch all feedback from the database
$query = "SELECT * FROM feedback ORDER BY id DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Elegance Admin | View Feedback</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display&family=Montserrat:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        :root {
            --bg: #121211;
            --card: #1a1a19;
            --gold: #c5a059;
            --text: #ffffff;
            --dim: #a0a0a0;
            --border: #333330;
        }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            display: flex;
        }

        .main-content {
            flex: 1;
            padding: 40px;
            position: relative;
        }

        /* Top Bar for Logout */
        .top-bar {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
        }

        .btn-logout {
            background: transparent;
            color: var(--dim);
            border: 1px solid var(--border);
            padding: 8px 15px;
            text-decoration: none;
            font-size: 0.7rem;
            letter-spacing: 1px;
            text-transform: uppercase;
            transition: 0.3s;
        }

        .btn-logout:hover {
            border-color: var(--gold);
            color: var(--gold);
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            margin: 0;
        }

        h2 span {
            color: var(--gold);
            font-style: italic;
        }

        /* The Dashboard Button */
        .btn-dashboard {
            background: var(--gold);
            color: #000;
            padding: 10px 20px;
            text-decoration: none;
            font-size: 0.8rem;
            font-weight: 600;
            border-radius: 2px;
            transition: 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-dashboard:hover {
            background: #e2c97e;
            transform: translateY(-2px);
        }

        /* Table Styles */
        .custom-table-container {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 4px;
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #222221;
            color: var(--gold);
            text-transform: uppercase;
            font-size: 0.7rem;
            padding: 15px 20px;
            text-align: left;
        }

        td {
            padding: 15px 20px;
            border-bottom: 1px solid var(--border);
            font-size: 0.85rem;
        }

        .rating-stars { color: var(--gold); }
        .text-muted { color: var(--dim); font-size: 0.75rem; }
    </style>
</head>
<body>

    <div class="main-content">
        <div class="top-bar">
            <a href="../logout.php" class="btn-logout">Logout</a>
        </div>

        <header>
            <div>
                <h2>Client <span>Feedback</span></h2>
                <p class="text-muted">Review what your clients are saying about Elegance Salon.</p>
            </div>
            
            <a href="dashboard.php" class="btn-dashboard">
                <i class="fas fa-th-large"></i> Dashboard
            </a>
        </header>

        <div class="custom-table-container">
            <table>
                <thead>
                    <tr>
                        <th>Client</th>
                        <th>Service</th>
                        <th>Rating</th>
                        <th>Message</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) { 
                    ?>
                        <tr>
                            <td>
                                <strong><?= e($row['client_name']) ?></strong><br>
                                <span class="text-muted"><?= e($row['email']) ?></span>
                            </td>
                            <td><?= e($row['service']) ?></td>
                            <td class="rating-stars">
                                <?php 
                                for ($i = 1; $i <= 5; $i++) {
                                    echo ($i <= $row['rating']) ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>';
                                }
                                ?>
                            </td>
                            <td><?= e($row['message']) ?></td>
                            <td class="text-muted">
                                <?= date('M d, Y', strtotime($row['created_at'])) ?>
                            </td>
                        </tr>
                    <?php 
                        } 
                    } else {
                        echo "<tr><td colspan='5' style='padding:50px; text-align:center;'>No feedback found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>