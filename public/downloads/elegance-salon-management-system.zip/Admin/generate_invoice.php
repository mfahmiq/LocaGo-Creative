<?php
$allowed_roles = ['admin'];
require_once __DIR__ . '/../includes/admin_guard.php';

if(isset($_POST['submit'])){
    $name   = input_str($_POST, 'client_name', 255);
    $amount = input_float($_POST, 'total_amount', 0);
    $date   = date("Y-m-d");
    $status = "PAID";

    if ($name !== '' && $amount !== null
        && db_query($conn, "INSERT INTO invoices (client_name, total_amount, invoice_date, status) VALUES (?, ?, ?, ?)", 'sdss', [$name, $amount, $date, $status])) {
        header("Location: invoices.php");
        exit();
    }
    js_alert('Please enter a client name and a valid amount.');
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Generate Invoice</title>
    <style>
        body { background: #0d0d0d; color: white; font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .form-card { background: #161616; padding: 40px; width: 400px; text-align: center; border: 1px solid #222; }
        h1 { font-family: 'Georgia', serif; font-weight: normal; }
        h1 span { color: #c5a059; font-style: italic; }
        .input-group { text-align: left; margin-bottom: 20px; }
        label { color: #c5a059; font-size: 10px; text-transform: uppercase; display: block; margin-bottom: 5px; }
        input { width: 100%; background: transparent; border: none; border-bottom: 1px solid #444; color: white; padding: 10px 0; outline: none; }
        input:focus { border-bottom: 1px solid #c5a059; }
        .btn { background: #c5a059; border: none; width: 100%; padding: 15px; font-weight: bold; cursor: pointer; margin-top: 20px; }
    </style>
</head>
<body>

<div class="form-card">
    <p style="color:#c5a059; font-size: 10px; letter-spacing: 2px;">BILLING SECTION</p>
    <h1>Generate <span>Invoice</span></h1>
    
    <form method="POST"><?= csrf_field() ?>
        <div class="input-group">
            <label>Client Name</label>
            <input type="text" name="client_name" required>
        </div>
        <div class="input-group">
            <label>Total Amount (PKR)</label>
            <input type="number" step="0.01" name="total_amount" required>
        </div>
        <button type="submit" name="submit" class="btn">GENERATE & SAVE</button>
        <a href="invoices.php" style="color:#666; font-size:12px; text-decoration:none; display:block; margin-top:15px;">← Back to List</a>
    </form>
</div>

</body>
</html>