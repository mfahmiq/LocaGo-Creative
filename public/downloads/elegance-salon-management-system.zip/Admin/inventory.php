<?php
$allowed_roles = ['admin', 'receptionist'];
require_once __DIR__ . '/../includes/admin_guard.php';
// Fetching from the inventory table
$result = mysqli_query($conn, "SELECT * FROM inventory");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Elegance Salon | Inventory</title>

        <style>
        :root {
            --bg-color: #121211;
            --card-bg: #1a1a19;
            --gold: #c5a059;
            --text-main: #ffffff;
            --text-dim: #a0a0a0;
            --accent-border: #333330;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-main);
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 40px;
            display: flex;
            justify-content: center;
        }

        .container {
            width: 100%;
            max-width: 1100px;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-bottom: 40px;
            border-bottom: 1px solid var(--accent-border);
            padding-bottom: 20px;
        }

        h2 {
            font-family: 'Playfair Display', serif;
            font-size: 2.5rem;
            margin: 0;
            font-weight: 400;
        }

        h2 span {
            color: var(--gold);
            font-style: italic;
        }

        .btn-add {
            background-color: var(--gold);
            color: #000;
            text-decoration: none;
            padding: 12px 24px;
            font-size: 0.8rem;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            transition: opacity 0.3s ease;
        }

        .btn-add:hover {
            opacity: 0.8;
        }

        /* Table Styling */
        .table-wrapper {
            background: var(--card-bg);
            padding: 20px;
            border: 1px solid var(--accent-border);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th {
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 2px;
            color: var(--gold);
            padding: 15px;
            border-bottom: 1px solid var(--accent-border);
        }

        td {
            padding: 20px 15px;
            font-size: 0.9rem;
            color: var(--text-dim);
            border-bottom: 1px solid #252524;
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover td {
            color: var(--text-main);
            background-color: #222220;
        }

        /* Action Links */
        .action-links a {
            color: var(--gold);
            text-decoration: none;
            font-size: 0.8rem;
            margin: 0 5px;
            transition: border-bottom 0.3s;
            border-bottom: 1px solid transparent;
        }

        .action-links a:hover {
            border-bottom: 1px solid var(--gold);
        }

        .delete-link {
            color: #e74c3c !important;
        }
    </style>
</head>
<body>

<div class="container">
    <header>
        <div>
            <p style="color: var(--gold); font-size: 0.7rem; letter-spacing: 3px; margin-bottom: 10px;">MANAGEMENT</p>
            <h2>Product <span>Inventory</span></h2>
        </div>
        <div>
            <a href="add_inventory.php" class="btn-add">Add Product</a>
            <a href="dashboard.php" class="btn-add">Back</a>
        </div>
    </header>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>SKU</th>
                    <th>Stock</th>
                    <th>Cost Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td style="color: var(--gold); font-weight: 600;"><?php echo e($row['id']); ?></td>
                    <td style="color: var(--text-main); font-weight: 500;"><?php echo e($row['name']); ?></td>
                    <td><?php echo e($row['sku']); ?></td>
                    <td style="<?php echo ($row['quantity'] <= $row['low_stock_threshold']) ? 'color: #e74c3c; font-weight: bold;' : ''; ?>">
                        <?php echo e($row['quantity']); ?>
                    </td>
                    <td>Rs. <?php echo number_format($row['cost_price'], 2); ?></td>
                    <td class="action-links">
                        <a href="edit_inventory.php?id=<?php echo e($row['id']); ?>">EDIT</a>
                        <span style="color: #444;">|</span>
                        <a href="delete_inventory.php?id=<?php echo (int) $row['id']; ?>&amp;csrf_token=<?= e(csrf_token()) ?>" class="delete-link" onclick="return confirm('Delete this product?')">DELETE</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>