<?php
require_once __DIR__ . '/includes/connection.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: Login_page.php");
    exit();
}
csrf_verify();

if (isset($_POST['login'])) {

    $email    = input_email($_POST, 'email');
    $password = (string) ($_POST['password'] ?? '');

    // Step 1: Get user by email ONLY (prepared statement)
    $row = $email ? db_fetch_one($conn, "SELECT id, password, role, is_active FROM users WHERE email = ? LIMIT 1", 's', [$email]) : null;

    // Step 2: Verify hashed password
    if ($row && (int) $row['is_active'] === 1 && password_verify($password, $row['password'])) {

        if (password_needs_rehash($row['password'], PASSWORD_DEFAULT)) {
            db_query($conn, "UPDATE users SET password = ? WHERE id = ?", 'si', [password_hash($password, PASSWORD_DEFAULT), (int) $row['id']]);
        }

        // Prevent session fixation
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $row['id'];
        $_SESSION['role'] = $row['role'];
        $_SESSION['last_activity'] = time();
        unset($_SESSION['csrf_token']);

        // Role-based redirect
        // If they are a regular 'user', send them to the home page
        if ($row['role'] == 'user') {
            header("Location: index.php");
        } else {
            // Everyone else (Admin, Stylist, Receptionist) goes to the same dashboard
            header("Location: Admin/dashboard.php");
        }

        exit();
    }

    js_alert('Invalid Credentials', 'Login_page.php');
}
?>
