<?php
require_once __DIR__ . '/includes/security.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: Login_page.php");
  exit();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Elegance Salon — Redefine Beautiful</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Jost:wght@200;300;400;500&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="assets/style.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
  <link rel="stylesheet" href="assets/main.js" />
  <style>
    /* ===== CSS VARIABLES ===== */
    :root {
      --charcoal: #141414;
      --charcoal-mid: #1e1e1e;
      --charcoal-light: #2a2a2a;
      --gold: #c9a84c;
      --gold-light: #e2c97e;
      --gold-dim: rgba(201, 168, 76, 0.15);
      --cream: #f5f0e8;
      --text-muted-light: #9a9a9a;
      --transition: 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      background-color: var(--charcoal);
      color: var(--cream);
      font-family: 'Jost', sans-serif;
      font-weight: 300;
      overflow-x: hidden;
    }

    h1,
    h2,
    h3,
    h4 {
      font-family: 'Cormorant Garamond', serif;
    }

    ::selection {
      background: var(--gold);
      color: var(--charcoal);
    }

    /* ===== NAVBAR ===== */
    .navbar {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
      padding: 1.5rem 3rem;
      transition: var(--transition);
      background: transparent;
    }

    .navbar.scrolled {
      background: rgba(20, 20, 20, 0.97);
      backdrop-filter: blur(20px);
      padding: 1rem 3rem;
      border-bottom: 1px solid rgba(201, 168, 76, 0.2);
    }

    .navbar-brand {
      font-family: 'Cormorant Garamond', serif;
      font-size: 1.8rem;
      font-weight: 600;
      color: var(--gold) !important;
      letter-spacing: 0.05em;
      text-decoration: none;
    }

    .navbar-brand span {
      color: var(--cream);
      font-weight: 300;
    }

    .nav-link {
      color: var(--cream) !important;
      font-family: 'Jost', sans-serif;
      font-weight: 300;
      font-size: 0.78rem;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      padding: 0.5rem 1.2rem !important;
      transition: color var(--transition);
      position: relative;
    }

    .nav-link::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 1.2rem;
      right: 1.2rem;
      height: 1px;
      background: var(--gold);
      transform: scaleX(0);
      transition: transform var(--transition);
    }

    .nav-link:hover::after,
    .nav-link.active::after {
      transform: scaleX(1);
    }

    .nav-link:hover,
    .nav-link.active {
      color: var(--gold) !important;
    }

    .navbar-toggler {
      border: 1px solid var(--gold);
    }

    .navbar-toggler-icon {
      filter: invert(1);
    }

    /* ===== HERO ===== */
    .hero {
      min-height: 100vh;
      position: relative;
      display: flex;
      align-items: center;
      overflow: hidden;
      background: var(--charcoal);
    }

    .hero-bg {
      position: absolute;
      inset: 0;
      background: radial-gradient(ellipse 60% 80% at 70% 50%, rgba(201, 168, 76, 0.08) 0%, transparent 70%), radial-gradient(ellipse 40% 60% at 20% 80%, rgba(201, 168, 76, 0.05) 0%, transparent 60%);
    }

    .hero-line {
      position: absolute;
      top: 0;
      right: 35%;
      width: 1px;
      height: 100%;
      background: linear-gradient(to bottom, transparent, rgba(201, 168, 76, 0.3), transparent);
    }

    .hero-content {
      position: relative;
      z-index: 2;
      padding-top: 6rem;
    }

    .hero-eyebrow {
      font-size: 0.7rem;
      letter-spacing: 0.4em;
      text-transform: uppercase;
      color: var(--gold);
      font-weight: 400;
      margin-bottom: 1.5rem;
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .hero-eyebrow::before {
      content: '';
      display: block;
      width: 40px;
      height: 1px;
      background: var(--gold);
    }

    .hero h1 {
      font-size: clamp(3.5rem, 7vw, 7rem);
      font-weight: 300;
      line-height: 1.05;
      margin-bottom: 1.5rem;
    }

    .hero h1 em {
      font-style: italic;
      color: var(--gold);
    }

    .hero-desc {
      font-size: 1rem;
      line-height: 1.9;
      color: var(--text-muted-light);
      max-width: 440px;
      margin-bottom: 2.5rem;
    }

    .btn-gold {
      display: inline-block;
      background: var(--gold);
      color: var(--charcoal);
      font-family: 'Jost', sans-serif;
      font-weight: 500;
      font-size: 0.75rem;
      letter-spacing: 0.25em;
      text-transform: uppercase;
      padding: 1rem 2.5rem;
      text-decoration: none;
      transition: var(--transition);
      border: 1px solid var(--gold);
    }

    .btn-gold:hover {
      background: transparent;
      color: var(--gold);
    }

    .btn-outline-gold {
      display: inline-block;
      background: transparent;
      color: var(--cream);
      font-family: 'Jost', sans-serif;
      font-weight: 400;
      font-size: 0.75rem;
      letter-spacing: 0.25em;
      text-transform: uppercase;
      padding: 1rem 2.5rem;
      text-decoration: none;
      transition: var(--transition);
      border: 1px solid rgba(245, 240, 232, 0.3);
    }

    .btn-outline-gold:hover {
      border-color: var(--gold);
      color: var(--gold);
    }

    .hero-image-wrap {
      position: relative;
      height: 85vh;
    }

    .hero-img-frame {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 380px;
      height: 540px;
    }

    .frame-box {
      width: 100%;
      height: 100%;
      background: var(--charcoal-light);
      border: 1px solid rgba(201, 168, 76, 0.3);
      overflow: hidden;
      position: relative;
    }

    .frame-box img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      opacity: 0.85;
      filter: sepia(15%);
    }

    .frame-deco {
      position: absolute;
      bottom: -20px;
      right: -20px;
      width: 120px;
      height: 120px;
      border: 1px solid rgba(201, 168, 76, 0.4);
      z-index: -1;
    }

    .frame-deco2 {
      position: absolute;
      top: -15px;
      left: -15px;
      width: 80px;
      height: 80px;
      border: 1px solid rgba(201, 168, 76, 0.2);
      z-index: -1;
    }

    .hero-stats {
      display: flex;
      gap: 2.5rem;
      margin-top: 3rem;
    }

    .stat-num {
      font-family: 'Cormorant Garamond', serif;
      font-size: 2.2rem;
      font-weight: 600;
      color: var(--gold);
      display: block;
      line-height: 1;
    }

    .stat-label {
      font-size: 0.65rem;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      color: var(--text-muted-light);
    }

    /* ===== WHY CHOOSE US ===== */
    .section-why {
      padding: 8rem 0;
    }

    .section-label {
      font-size: 0.65rem;
      letter-spacing: 0.4em;
      text-transform: uppercase;
      color: var(--gold);
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .section-label::before {
      content: '';
      width: 30px;
      height: 1px;
      background: var(--gold);
      display: block;
    }

    .section-title {
      font-size: clamp(2.2rem, 4vw, 3.5rem);
      font-weight: 300;
      line-height: 1.2;
      margin-bottom: 1rem;
    }

    .section-title em {
      font-style: italic;
      color: var(--gold);
    }

    .why-card {
      padding: 2.5rem;
      border: 1px solid rgba(201, 168, 76, 0.1);
      background: var(--charcoal-mid);
      transition: var(--transition);
      height: 100%;
      position: relative;
      overflow: hidden;
    }

    .why-card::before {
      content: '';
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 2px;
      background: linear-gradient(to right, var(--gold), transparent);
      transform: scaleX(0);
      transform-origin: left;
      transition: transform var(--transition);
    }

    .why-card:hover::before {
      transform: scaleX(1);
    }

    .why-card:hover {
      border-color: rgba(201, 168, 76, 0.3);
      transform: translateY(-4px);
    }

    .why-icon {
      font-size: 1.8rem;
      color: var(--gold);
      margin-bottom: 1.5rem;
    }

    .why-card h4 {
      font-size: 1.3rem;
      font-weight: 400;
      margin-bottom: 0.8rem;
    }

    .why-card p {
      font-size: 0.87rem;
      line-height: 1.9;
      color: var(--text-muted-light);
    }

    .gold-divider {
      height: 1px;
      background: linear-gradient(to right, transparent, var(--gold), transparent);
      margin: 0 auto;
      max-width: 400px;
    }

    /* ===== SERVICES ===== */
    .section-services {
      padding: 8rem 0;
      background: var(--charcoal-mid);
    }

    .service-card {
      position: relative;
      height: 420px;
      overflow: hidden;
      cursor: pointer;
    }

    .service-card img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.7s ease;
      filter: brightness(0.6) sepia(10%);
    }

    .service-card:hover img {
      transform: scale(1.08);
    }

    .service-overlay {
      position: absolute;
      inset: 0;
      background: linear-gradient(to top, rgba(20, 20, 20, 0.95) 0%, rgba(20, 20, 20, 0.2) 60%);
      display: flex;
      flex-direction: column;
      justify-content: flex-end;
      padding: 2rem;
    }

    .service-tag {
      font-size: 0.6rem;
      letter-spacing: 0.35em;
      text-transform: uppercase;
      color: var(--gold);
      margin-bottom: 0.5rem;
    }

    .service-card h3 {
      font-size: 1.8rem;
      font-weight: 300;
      margin-bottom: 0.5rem;
    }

    .service-card p {
      font-size: 0.82rem;
      color: var(--text-muted-light);
      line-height: 1.7;
      transform: translateY(10px);
      opacity: 0;
      transition: var(--transition);
    }

    .service-card:hover p {
      opacity: 1;
      transform: translateY(0);
    }

    .service-price {
      margin-top: 1rem;
      font-family: 'Cormorant Garamond', serif;
      font-size: 1.1rem;
      color: var(--gold);
    }

    .service-price::before {
      content: 'From ';
      font-size: 0.7rem;
      letter-spacing: 0.1em;
      color: var(--text-muted-light);
      font-family: 'Jost', sans-serif;
    }

    /* ===== TESTIMONIALS ===== */
    .section-testimonials {
      padding: 8rem 0;
    }

    .testimonial-slide {
      display: none;
    }

    .testimonial-slide.active {
      display: block;
    }

    .testimonial-card {
      background: var(--charcoal-light);
      border: 1px solid rgba(201, 168, 76, 0.15);
      padding: 3rem;
      position: relative;
    }

    .quote-mark {
      font-family: 'Cormorant Garamond', serif;
      font-size: 6rem;
      line-height: 0.5;
      color: var(--gold);
      opacity: 0.3;
      position: absolute;
      top: 1.5rem;
      left: 2rem;
    }

    .testimonial-text {
      font-family: 'Cormorant Garamond', serif;
      font-size: 1.5rem;
      font-style: italic;
      line-height: 1.7;
      color: var(--cream);
      margin-bottom: 2rem;
      padding-top: 1rem;
    }

    .testimonial-author {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .author-avatar {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      background: var(--gold-dim);
      border: 1px solid var(--gold);
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Cormorant Garamond', serif;
      font-size: 1.2rem;
      color: var(--gold);
    }

    .author-name {
      font-size: 0.85rem;
      letter-spacing: 0.1em;
      color: var(--cream);
      display: block;
    }

    .author-role {
      font-size: 0.7rem;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      color: var(--text-muted-light);
    }

    .stars {
      color: var(--gold);
      font-size: 0.8rem;
      margin-bottom: 0.5rem;
    }

    .testimonial-controls {
      display: flex;
      gap: 1rem;
      margin-top: 2rem;
    }

    .ctrl-btn {
      width: 45px;
      height: 45px;
      border: 1px solid rgba(201, 168, 76, 0.3);
      background: transparent;
      color: var(--gold);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: var(--transition);
      font-size: 1rem;
    }

    .ctrl-btn:hover {
      background: var(--gold);
      color: var(--charcoal);
    }

    /* ===== CTA ===== */
    .section-cta {
      padding: 6rem 0;
      background: linear-gradient(135deg, var(--charcoal-mid), var(--charcoal-light));
      border-top: 1px solid rgba(201, 168, 76, 0.15);
      border-bottom: 1px solid rgba(201, 168, 76, 0.15);
      text-align: center;
    }

    .section-cta h2 {
      font-size: clamp(2rem, 4vw, 3.5rem);
      font-weight: 300;
      margin-bottom: 1.5rem;
    }

    .section-cta p {
      color: var(--text-muted-light);
      font-size: 0.95rem;
      margin-bottom: 2.5rem;
      max-width: 500px;
      margin-left: auto;
      margin-right: auto;
    }

    /* ===== FOOTER ===== */
    footer {
      background: #0e0e0e;
      padding: 5rem 0 2rem;
      border-top: 1px solid rgba(201, 168, 76, 0.1);
    }

    .footer-brand {
      font-family: 'Cormorant Garamond', serif;
      font-size: 2rem;
      font-weight: 600;
      color: var(--gold);
    }

    .footer-brand span {
      color: var(--cream);
      font-weight: 300;
    }

    .footer-tagline {
      font-size: 0.75rem;
      letter-spacing: 0.25em;
      text-transform: uppercase;
      color: var(--text-muted-light);
      margin-top: 0.5rem;
    }

    .footer-heading {
      font-size: 0.65rem;
      letter-spacing: 0.3em;
      text-transform: uppercase;
      color: var(--gold);
      margin-bottom: 1.5rem;
    }

    .footer-links {
      list-style: none;
      padding: 0;
    }

    .footer-links li {
      margin-bottom: 0.8rem;
    }

    .footer-links a {
      color: var(--text-muted-light);
      text-decoration: none;
      font-size: 0.87rem;
      transition: color var(--transition);
    }

    .footer-links a:hover {
      color: var(--gold);
    }

    .social-icons {
      display: flex;
      gap: 0.8rem;
      margin-top: 1.5rem;
    }

    .social-icon {
      width: 38px;
      height: 38px;
      border: 1px solid rgba(201, 168, 76, 0.25);
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--text-muted-light);
      text-decoration: none;
      font-size: 0.9rem;
      transition: var(--transition);
    }

    .social-icon:hover {
      border-color: var(--gold);
      color: var(--gold);
    }

    .footer-bottom {
      border-top: 1px solid rgba(255, 255, 255, 0.05);
      padding-top: 2rem;
      margin-top: 3rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 1rem;
    }

    .footer-bottom p {
      font-size: 0.75rem;
      color: var(--text-muted-light);
      margin: 0;
    }

    @keyframes fadeUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .fade-up {
      animation: fadeUp 0.9s ease forwards;
    }

    .delay-1 {
      animation-delay: 0.15s;
      opacity: 0;
    }

    .delay-2 {
      animation-delay: 0.3s;
      opacity: 0;
    }

    .delay-3 {
      animation-delay: 0.45s;
      opacity: 0;
    }

    .delay-4 {
      animation-delay: 0.6s;
      opacity: 0;
    }

    @media (max-width:991px) {
      .navbar {
        padding: 1rem 1.5rem;
      }

      .navbar.scrolled {
        padding: 0.8rem 1.5rem;
      }

      .hero-image-wrap {
        height: 50vh;
        margin-top: 2rem;
      }

      .hero-img-frame {
        width: 260px;
        height: 360px;
      }
    }

    @media (max-width:768px) {
      .hero {
        min-height: auto;
        padding: 8rem 0 4rem;
      }
    }

    /* ===== DROPDOWN CUSTOM ===== */
    .custom-dropdown {
      background-color: var(--charcoal-mid);
      border: 1px solid rgba(201, 168, 76, 0.2);
      padding: 0.5rem 0;
    }

    .custom-dropdown .dropdown-item {
      color: var(--cream);
      font-size: 0.8rem;
      letter-spacing: 0.1em;
      transition: var(--transition);
    }

    .custom-dropdown .dropdown-item:hover {
      background-color: rgba(201, 168, 76, 0.1);
      color: var(--gold);
    }
  </style>
</head>

<body>

  <?php include "includes/header.php"; ?>

  <!-- HERO -->
  <section class="hero">
    <div class="hero-bg"></div>
    <div class="hero-line"></div>
    <div class="container-fluid px-lg-5">
      <div class="row align-items-center">
        <div class="col-lg-6">
          <div class="hero-content">
            <div class="hero-eyebrow fade-up">Est. 2008 — Karachi's Premier Salon</div>
            <h1 class="fade-up delay-1">Where Beauty<br>Finds Its <em>True</em><br>Expression</h1>
            <p class="hero-desc fade-up delay-2">Step into a world of refined elegance. Our master stylists curate bespoke beauty experiences tailored to your individual identity.</p>
            <div class="d-flex gap-3 flex-wrap fade-up delay-3">
              <a href="appointments.php" class="btn-gold">Book Now</a>
              <a href="services.php" class="btn-outline-gold">Our Services</a>
            </div>
            <div class="hero-stats fade-up delay-4">
              <div class="stat-item"><span class="stat-num">12K+</span><span class="stat-label">Happy Clients</span></div>
              <div class="stat-item"><span class="stat-num">18</span><span class="stat-label">Expert Stylists</span></div>
              <div class="stat-item"><span class="stat-num">15</span><span class="stat-label">Years of Art</span></div>
            </div>
          </div>
        </div>
        <div class="col-lg-6 d-none d-lg-block">
          <div class="hero-image-wrap">
            <div class="hero-img-frame">
              <div class="frame-box">
                <img src="https://images.unsplash.com/photo-1560066984-138dadb4c035?w=700&q=80" alt="Salon" />
              </div>
              <div class="frame-deco"></div>
              <div class="frame-deco2"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- WHY CHOOSE US -->
  <section class="section-why">
    <div class="container-fluid px-lg-5">
      <div class="row mb-5">
        <div class="col-lg-5">
          <div class="section-label">Our Promise</div>
          <h2 class="section-title">Why Choose <em>Elegance</em></h2>
          <p style="color:var(--text-muted-light);font-size:0.9rem;line-height:1.9;max-width:380px;">We don't just style hair — we craft experiences that leave you transformed, confident, and radiant.</p>
        </div>
      </div>
      <div class="row g-4">
        <div class="col-sm-6 col-lg-3">
          <div class="why-card">
            <div class="why-icon"><i class="bi bi-stars"></i></div>
            <h4>Master Artisans</h4>
            <p>Our stylists train internationally, bringing world-class technique to every appointment.</p>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="why-card">
            <div class="why-icon"><i class="bi bi-droplet"></i></div>
            <h4>Premium Products</h4>
            <p>We use only luxury, cruelty-free formulations that nourish and protect your hair and skin.</p>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="why-card">
            <div class="why-icon"><i class="bi bi-clock"></i></div>
            <h4>Your Schedule</h4>
            <p>Flexible booking with same-day and evening appointments to suit your lifestyle.</p>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="why-card">
            <div class="why-icon"><i class="bi bi-shield-check"></i></div>
            <h4>Hygiene First</h4>
            <p>Strict sanitization protocols ensuring a safe, pristine environment at all times.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <div class="container">
    <div class="gold-divider"></div>
  </div>

  <!-- SERVICES PREVIEW -->
  <section class="section-services">
    <div class="container-fluid px-lg-5">
      <div class="row mb-5 align-items-end">
        <div class="col-lg-6">
          <div class="section-label">Featured Services</div>
          <h2 class="section-title">Our <em>Signature</em><br>Treatments</h2>
        </div>
        <div class="col-lg-6 text-lg-end"><a href="services.php" class="btn-outline-gold">View All Services</a></div>
      </div>
      <div class="row g-3">
        <div class="col-lg-5">
          <div class="service-card">
            <img src="https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=700&q=80" alt="Hair" />
            <div class="service-overlay">
              <span class="service-tag">Hair</span>
              <h3>Luxury Hair Styling</h3>
              <p>From sleek blowouts to complex balayage, our hair artists create masterpieces uniquely you.</p>
              <div class="service-price">Rs. 3,500</div>
            </div>
          </div>
        </div>
        <div class="col-lg-7">
          <div class="row g-3">
            <div class="col-sm-6">
              <div class="service-card" style="height:200px;">
                <img src="https://images.unsplash.com/photo-1604654894610-df63bc536371?w=500&q=80" alt="Nails" />
                <div class="service-overlay"><span class="service-tag">Nails</span>
                  <h3 style="font-size:1.3rem;">Nail Artistry</h3>
                  <p>Precision gel sets.</p>
                  <div class="service-price">Rs. 1,800</div>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="service-card" style="height:200px;">
                <img src="https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=500&q=80" alt="Facial" />
                <div class="service-overlay"><span class="service-tag">Skin</span>
                  <h3 style="font-size:1.3rem;">Glow Facials</h3>
                  <p>Restore luminosity.</p>
                  <div class="service-price">Rs. 4,500</div>
                </div>
              </div>
            </div>
            <div class="col-12">
              <div class="service-card" style="height:200px;">
                <img src="https://images.unsplash.com/photo-1519823551278-64ac92734fb1?w=900&q=80" alt="Spa" />
                <div class="service-overlay"><span class="service-tag">Wellness</span>
                  <h3 style="font-size:1.3rem;">Full Spa Ritual</h3>
                  <p>A complete head-to-toe indulgence experience for the discerning client.</p>
                  <div class="service-price">Rs. 12,000</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- TESTIMONIALS -->
  <section class="section-testimonials">
    <div class="container-fluid px-lg-5">
      <div class="row mb-5">
        <div class="col-lg-5">
          <div class="section-label">Client Stories</div>
          <h2 class="section-title">Words of <em>Grace</em></h2>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-7">
          <div class="testimonial-slide active" id="t1">
            <div class="testimonial-card">
              <div class="quote-mark">"</div>
              <div class="stars">★★★★★</div>
              <p class="testimonial-text">Elegance Salon transformed not just my hair, but my entire confidence. The attention to detail and warmth of the staff is unmatched in all of Karachi.</p>
              <div class="testimonial-author">
                <div class="author-avatar">A</div>
                <div><span class="author-name">Amna Rashid</span><span class="author-role">Loyal Client since 2019</span></div>
              </div>
            </div>
          </div>
          <div class="testimonial-slide" id="t2">
            <div class="testimonial-card">
              <div class="quote-mark">"</div>
              <div class="stars">★★★★★</div>
              <p class="testimonial-text">I've been to salons across three countries, and Elegance stands among the very best. The balayage treatment they gave me lasted beautifully for months.</p>
              <div class="testimonial-author">
                <div class="author-avatar">S</div>
                <div><span class="author-name">Sara Khan</span><span class="author-role">Premium Member</span></div>
              </div>
            </div>
          </div>
          <div class="testimonial-slide" id="t3">
            <div class="testimonial-card">
              <div class="quote-mark">"</div>
              <div class="stars">★★★★★</div>
              <p class="testimonial-text">The bridal package was nothing short of magical. My team made me feel like royalty on the most important day of my life. Forever grateful.</p>
              <div class="testimonial-author">
                <div class="author-avatar">F</div>
                <div><span class="author-name">Fatima Malik</span><span class="author-role">Bridal Client</span></div>
              </div>
            </div>
          </div>
          <div class="testimonial-controls">
            <button class="ctrl-btn" onclick="prevSlide()"><i class="bi bi-arrow-left"></i></button>
            <button class="ctrl-btn" onclick="nextSlide()"><i class="bi bi-arrow-right"></i></button>
          </div>
        </div>
        <div class="col-lg-5 d-none d-lg-flex align-items-center justify-content-center">
          <div style="text-align:center;padding:3rem;">
            <div style="font-family:'Cormorant Garamond',serif;font-size:6rem;color:var(--gold);opacity:0.2;line-height:1;">4.9</div>
            <div class="stars" style="font-size:1.2rem;">★★★★★</div>
            <div style="font-size:0.75rem;letter-spacing:0.2em;text-transform:uppercase;color:var(--text-muted-light);margin-top:0.5rem;">Average Rating<br>from 2,400+ reviews</div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="section-cta">
    <div class="container">
      <div class="section-label justify-content-center">Ready to Begin?</div>
      <h2>Your Transformation<br>Awaits <em>You</em></h2>
      <p>Book your appointment today and step into the Elegance experience. New clients receive 20% off their first visit.</p>
      <a href="appointments.php" class="btn-gold">Reserve Your Appointment</a>
    </div>
  </section>

  <?php include "includes/footer.php"; ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Navbar scroll
    const nav = document.getElementById('mainNav');
    window.addEventListener('scroll', () => nav.classList.toggle('scrolled', window.scrollY > 60));

    // Testimonial slider
    let current = 1,
      total = 3;

    function showSlide(n) {
      document.querySelectorAll('.testimonial-slide').forEach(s => s.classList.remove('active'));
      document.getElementById('t' + n).classList.add('active');
    }

    function nextSlide() {
      current = current >= total ? 1 : current + 1;
      showSlide(current);
    }

    function prevSlide() {
      current = current <= 1 ? total : current - 1;
      showSlide(current);
    }
    setInterval(nextSlide, 5000);
  </script>
</body>

</html>