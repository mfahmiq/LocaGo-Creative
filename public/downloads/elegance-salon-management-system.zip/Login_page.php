<?php
require_once __DIR__ . '/includes/security.php';
?>


<!DOCTYPE html>
<html lang="en">

<head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Login | Elegance Salon</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

     <style>
          :root {
               --primary-gold: #c5a059;
               --dark-bg: #0f0f0f;
               --card-bg: #1a1a1a;
               --text-light: #e0e0e0;
          }

          body {
               background-color: var(--dark-bg);
               font-family: 'Poppins', sans-serif;
               color: var(--text-light);
               height: 100vh;
               display: flex;
               align-items: center;
               justify-content: center;
               margin: 0;
               overflow: hidden;
          }

          /* Background overlay effect */
          body::before {
               content: "";
               position: absolute;
               width: 100%;
               height: 100%;
               background: radial-gradient(circle at center, #1a1a1a 0%, #000000 100%);
               z-index: -1;
          }

          .login-card {
               background-color: var(--card-bg);
               border: 1px solid rgba(197, 160, 89, 0.2);
               padding: 3rem;
               border-radius: 0;
               width: 100%;
               max-width: 450px;
               box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5);
               position: relative;
          }

          /* Accent Line like the image */
          .login-card::before {
               content: "";
               position: absolute;
               top: 20px;
               left: 20px;
               width: 50px;
               height: 1px;
               background-color: var(--primary-gold);
          }

          .salon-logo {
               font-family: 'Playfair Display', serif;
               color: var(--primary-gold);
               font-size: 1.8rem;
               text-align: center;
               margin-bottom: 2rem;
               letter-spacing: 2px;
          }

          .login-title {
               font-family: 'Playfair Display', serif;
               font-size: 2.2rem;
               margin-bottom: 1.5rem;
               text-align: center;
          }

          .login-title span {
               color: var(--primary-gold);
               font-style: italic;
          }

          .form-control {
               background-color: transparent;
               border: none;
               border-bottom: 1px solid rgba(255, 255, 255, 0.2);
               border-radius: 0;
               color: white;
               padding: 0.8rem 0.5rem;
               margin-bottom: 1.5rem;
               transition: all 0.3s ease;
          }

          .form-control:focus {
               background-color: transparent;
               box-shadow: none;
               border-bottom: 1px solid var(--primary-gold);
               color: white;
          }

          .form-label {
               font-size: 0.8rem;
               color: var(--primary-gold);
               text-transform: uppercase;
               letter-spacing: 1px;
               margin-bottom: 0;
          }

          .btn-login {
               background-color: var(--primary-gold);
               color: #000;
               border: none;
               border-radius: 0;
               padding: 0.8rem;
               width: 100%;
               font-weight: 600;
               text-transform: uppercase;
               letter-spacing: 1px;
               margin-top: 1rem;
               transition: 0.3s;
          }

          .btn-login:hover {
               background-color: #b08d4a;
               color: #000;
               transform: translateY(-2px);
          }

          .forgot-pass {
               color: rgba(255, 255, 255, 0.5);
               text-decoration: none;
               font-size: 0.85rem;
               display: block;
               text-align: center;
               margin-top: 1.5rem;
          }

          .forgot-pass:hover {
               color: var(--primary-gold);
          }
     </style>
</head>


<body> 
     

     <div class="login-card">
          <div class="salon-logo">Elegance Salon</div>

          <h2 class="login-title">Welcome <span>Back</span></h2>

          <form action="login_logic.php" method="POST"><?= csrf_field() ?>

               <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="text" name="email" class="form-control" placeholder="Enter your email" required>
               </div>

               <div class="mb-4">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="••••••••" required>
               </div>

               <button type="submit" name="login" class="btn-login">Login to Account</button>

               <a href="register.php" class="forgot-pass">Don't have an account? Sign Up</a>

          </form>
     </div>

     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>