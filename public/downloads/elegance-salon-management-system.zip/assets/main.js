/* ═══════════════════════════════════════════════════════════
   ELEGANCE SALON — main.js
   ═══════════════════════════════════════════════════════════ */

/* ── Navbar scroll behavior ── */
const mainNav = document.getElementById('mainNav');
if (mainNav) {
  window.addEventListener('scroll', () => {
    mainNav.classList.toggle('scrolled', window.scrollY > 60);
  });
  // Init on load
  mainNav.classList.toggle('scrolled', window.scrollY > 60);
}

/* ── Hero particle effect ── */
const particleContainer = document.getElementById('particles');
if (particleContainer) {
  for (let i = 0; i < 30; i++) {
    const p = document.createElement('div');
    p.style.cssText = `
      position: absolute;
      width: ${Math.random() * 3 + 1}px;
      height: ${Math.random() * 3 + 1}px;
      background: rgba(201, 168, 76, ${Math.random() * 0.4 + 0.1});
      border-radius: 50%;
      left: ${Math.random() * 100}%;
      top: ${Math.random() * 100}%;
      animation: floatParticle ${Math.random() * 8 + 6}s ease-in-out infinite;
      animation-delay: ${Math.random() * 5}s;
    `;
    particleContainer.appendChild(p);
  }

  // Inject particle animation keyframes
  const style = document.createElement('style');
  style.textContent = `
    @keyframes floatParticle {
      0%, 100% { transform: translate(0, 0) scale(1); opacity: 0.3; }
      33%       { transform: translate(${Math.random() * 30 - 15}px, ${Math.random() * -40 - 10}px) scale(1.2); opacity: 0.7; }
      66%       { transform: translate(${Math.random() * 30 - 15}px, ${Math.random() * 20}px) scale(0.8); opacity: 0.5; }
    }
  `;
  document.head.appendChild(style);
}

/* ── Scroll reveal ── */
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(el => {
    if (el.isIntersecting) {
      el.target.classList.add('visible');
      revealObserver.unobserve(el.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.feature-card, .service-card, .pricing-card, .team-card, .value-card, .contact-item, .stat-item, .testimonial-card, .booking-info-panel, .story-text, .mission-pill').forEach(el => {
  el.classList.add('reveal');
  revealObserver.observe(el);
});

/* ══════════════════════════
   SERVICES PAGE — filter tabs
   ══════════════════════════ */
const filterBtns = document.querySelectorAll('.filter-btn');
const serviceCategories = document.querySelectorAll('.service-category');

if (filterBtns.length) {
  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const filter = btn.dataset.filter;
      serviceCategories.forEach(cat => {
        if (filter === 'all' || cat.dataset.category === filter) {
          cat.style.display = 'block';
          cat.style.animation = 'fadeUp 0.4s ease forwards';
        } else {
          cat.style.display = 'none';
        }
      });
    });
  });
}

/* ══════════════════════════
   APPOINTMENTS PAGE — Multi-step form
   ══════════════════════════ */
const servicesByCategory = {
  hair: [
    'Classic Cut & Style – PKR 2,500',
    'Balayage & Highlights – PKR 8,500',
    'Keratin Treatment – PKR 12,000',
    'Deep Conditioning – PKR 3,500',
    'Bridal Hair Styling – PKR 15,000',
    'Scalp Treatment – PKR 4,000'
  ],
  skin: [
    'Signature Facial – PKR 5,500',
    'Anti-Aging Facial – PKR 9,000',
    'Chemical Peel – PKR 7,500'
  ],
  nails: [
    'Classic Manicure – PKR 1,800',
    'Gel Manicure – PKR 3,200',
    'Luxury Pedicure – PKR 3,500'
  ],
  makeup: [
    'Party Makeup – PKR 6,500',
    'Bridal Makeup – PKR 25,000'
  ]
};

window.updateServices = function () {
  const cat = document.getElementById('serviceCategory').value;
  const sel = document.getElementById('serviceSelect');
  if (!sel) return;

  sel.innerHTML = '<option value="">Select a service...</option>';
  if (cat && servicesByCategory[cat]) {
    servicesByCategory[cat].forEach(s => {
      const opt = document.createElement('option');
      opt.value = s;
      opt.textContent = s;
      sel.appendChild(opt);
    });
  }
};

// Set min date to today
const dateInput = document.getElementById('apptDate');
if (dateInput) {
  const today = new Date().toISOString().split('T')[0];
  dateInput.setAttribute('min', today);

  dateInput.addEventListener('change', updateSummary);
  const timeEl = document.getElementById('apptTime');
  if (timeEl) timeEl.addEventListener('change', updateSummary);
}

function updateSummary() {
  const summaryContent = document.getElementById('summaryContent');
  if (!summaryContent) return;

  const fn = document.getElementById('firstName')?.value || '—';
  const ln = document.getElementById('lastName')?.value || '—';
  const service = document.getElementById('serviceSelect')?.value || '—';
  const date = document.getElementById('apptDate')?.value || '—';
  const time = document.getElementById('apptTime')?.value || '—';
  const stylist = document.getElementById('stylist')?.value || 'No Preference';

  summaryContent.innerHTML = `
    <div style="line-height:2;">
      <div><strong>Name:</strong> ${fn} ${ln}</div>
      <div><strong>Service:</strong> ${service}</div>
      <div><strong>Date:</strong> ${date ? formatDate(date) : '—'}</div>
      <div><strong>Time:</strong> ${time}</div>
      <div><strong>Stylist:</strong> ${stylist}</div>
    </div>
  `;
}

function formatDate(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

window.nextStep = function (current) {
  if (!validateStep(current)) return;
  document.getElementById('step' + current).style.display = 'none';
  const nextEl = document.getElementById('step' + (current + 1));
  if (nextEl) {
    nextEl.style.display = 'block';
    nextEl.style.animation = 'fadeUp 0.4s ease forwards';
  }
  if (current + 1 === 3) updateSummary();
};

window.prevStep = function (current) {
  document.getElementById('step' + current).style.display = 'none';
  const prevEl = document.getElementById('step' + (current - 1));
  if (prevEl) {
    prevEl.style.display = 'block';
  }
};

function validateStep(step) {
  let valid = true;

  if (step === 1) {
    const fields = ['firstName', 'lastName', 'email', 'phone'];
    fields.forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      if (!el.value.trim()) {
        el.classList.add('is-invalid');
        valid = false;
      } else if (id === 'email' && !isValidEmail(el.value)) {
        el.classList.add('is-invalid');
        valid = false;
      } else {
        el.classList.remove('is-invalid');
        el.classList.add('is-valid');
      }
    });
  }

  if (step === 2) {
    const fields = ['serviceCategory', 'serviceSelect'];
    fields.forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      if (!el.value.trim()) {
        el.classList.add('is-invalid');
        valid = false;
      } else {
        el.classList.remove('is-invalid');
        el.classList.add('is-valid');
      }
    });
  }

  return valid;
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/* Form submit */
const bookingForm = document.getElementById('bookingForm');
if (bookingForm) {
  bookingForm.addEventListener('submit', (e) => {
    e.preventDefault();

    // Validate step 3
    const dateEl = document.getElementById('apptDate');
    const timeEl = document.getElementById('apptTime');
    let valid = true;

    [dateEl, timeEl].forEach(el => {
      if (!el) return;
      if (!el.value) {
        el.classList.add('is-invalid');
        valid = false;
      } else {
        el.classList.remove('is-invalid');
        el.classList.add('is-valid');
      }
    });

    if (!valid) return;

    // Show loading
    const btn = document.getElementById('submitBtn');
    const text = btn.querySelector('.submit-text');
    const spinner = document.getElementById('submitSpinner');
    text.classList.add('d-none');
    spinner.classList.remove('d-none');
    btn.disabled = true;

    // Simulate API call
    setTimeout(() => {
      const firstName = document.getElementById('firstName').value;
      const lastName = document.getElementById('lastName').value;
      const email = document.getElementById('email').value;
      const service = document.getElementById('serviceSelect').value;
      const date = document.getElementById('apptDate').value;
      const time = document.getElementById('apptTime').value;
      const stylist = document.getElementById('stylist').value;

      // Show success
      bookingForm.style.display = 'none';
      const success = document.getElementById('bookingSuccess');
      success.style.display = 'block';

      document.getElementById('confirmedName').textContent = `${firstName} ${lastName}`;
      document.getElementById('confirmedEmail').textContent = email;
      document.getElementById('confirmationDetails').innerHTML = `
        <div style="line-height: 2.2; font-size: 0.9rem;">
          <div>📅 <strong style="color:var(--gold)">Date:</strong> ${formatDate(date)}</div>
          <div>⏰ <strong style="color:var(--gold)">Time:</strong> ${time}</div>
          <div>✂️ <strong style="color:var(--gold)">Service:</strong> ${service}</div>
          <div>👤 <strong style="color:var(--gold)">Stylist:</strong> ${stylist}</div>
        </div>
      `;

      success.style.animation = 'fadeUp 0.5s ease forwards';
    }, 1800);
  });
}

window.resetForm = function () {
  const form = document.getElementById('bookingForm');
  const success = document.getElementById('bookingSuccess');
  if (!form || !success) return;

  form.reset();
  form.querySelectorAll('.is-valid, .is-invalid').forEach(el => {
    el.classList.remove('is-valid', 'is-invalid');
  });

  // Reset to step 1
  document.getElementById('step1').style.display = 'block';
  document.getElementById('step2').style.display = 'none';
  document.getElementById('step3').style.display = 'none';

  success.style.display = 'none';
  form.style.display = 'block';

  const btn = document.getElementById('submitBtn');
  if (btn) {
    btn.querySelector('.submit-text').classList.remove('d-none');
    document.getElementById('submitSpinner').classList.add('d-none');
    btn.disabled = false;
  }
};

/* ══════════════════════════
   ABOUT PAGE — Star rating
   ══════════════════════════ */
const starRating = document.getElementById('starRating');
if (starRating) {
  const stars = starRating.querySelectorAll('span');
  const ratingVal = document.getElementById('ratingVal');
  let selectedRating = 0;

  stars.forEach((star, idx) => {
    star.addEventListener('mouseenter', () => {
      const val = parseInt(star.dataset.val);
      stars.forEach(s => {
        s.style.color = parseInt(s.dataset.val) <= val ? 'var(--gold)' : 'var(--dark-border)';
      });
    });
    star.addEventListener('mouseleave', () => {
      stars.forEach(s => {
        s.style.color = parseInt(s.dataset.val) <= selectedRating ? 'var(--gold)' : 'var(--dark-border)';
      });
    });
    star.addEventListener('click', () => {
      selectedRating = parseInt(star.dataset.val);
      if (ratingVal) ratingVal.value = selectedRating;
      stars.forEach(s => {
        s.style.color = parseInt(s.dataset.val) <= selectedRating ? 'var(--gold)' : 'var(--dark-border)';
      });
    });
  });
}

/* Feedback form */
const feedbackForm = document.getElementById('feedbackForm');
if (feedbackForm) {
  feedbackForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('fbName')?.value.trim();
    const email = document.getElementById('fbEmail')?.value.trim();
    const message = document.getElementById('fbMessage')?.value.trim();

    if (!name || !email || !message) {
      feedbackForm.querySelectorAll('input, textarea').forEach(el => {
        if (!el.value.trim()) el.classList.add('is-invalid');
        else el.classList.remove('is-invalid');
      });
      return;
    }

    feedbackForm.style.display = 'none';
    const successEl = document.getElementById('feedbackSuccess');
    if (successEl) {
      successEl.style.display = 'block';
      successEl.style.animation = 'fadeUp 0.5s ease forwards';
    }
  });
}

/* Remove is-invalid on input */
document.querySelectorAll('.luxury-input').forEach(el => {
  el.addEventListener('input', () => el.classList.remove('is-invalid'));
});
