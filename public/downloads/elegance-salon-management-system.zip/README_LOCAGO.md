# Warehouse & Inventory Management System - Elegance Salon Management System

```
========================================================================
📦 Warehouse & Inventory Management System - Elegance Salon Management System
Kategori     : Bisnis & Manajemen
Tech Stack   : PHP Native • PHP • MySQL
Database     : MySQL (.sql) (File: salon_db.sql)
Sumber Asli  : https://github.com/ShaheerKhanDev1/elegance-salon-management-system (GitHub Open Source)
Stars GitHub : ⭐ 0 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/elegance-salon-management-system`
     * Untuk Laragon: `C:/laragon/www/elegance-salon-management-system`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - File SQL ini membuat database `elegance_salon_management_system` sendiri — tidak perlu membuat
     database manual. Klik tab 'Import', pilih file SQL yang disertakan pada:
     `salon_db.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = elegance_salon_management_system

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/elegance-salon-management-system

5. AKUN LOGIN DEMO (dari README repo asli):
   - Admin: admin@elegancesalon.pk / Demo@12345
   - Stylist: areeb123@example.com / Demo@12345
   - Receptionist: areeb.demo@example.com / Demo@12345
   - Customer: user@example.com / Demo@12345

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
