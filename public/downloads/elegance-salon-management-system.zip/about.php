<?php
require_once __DIR__ . '/includes/connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    csrf_verify();

    $client_name = input_str($_POST, 'client_name', 255);
    $email       = input_email($_POST, 'email');
    $service     = input_enum($_POST, 'service', ['haircut & styling', 'coloring', 'spa treatments', 'bridal makeup', 'other']);
    $rating      = input_int($_POST, 'rating', 1);
    $message     = input_str($_POST, 'message', 2000);

    // Server-side validation
    if ($client_name !== '' && $email && $service && $rating && $rating <= 5 && $message !== '') {
        // Keep the original label (e.g. "Haircut & Styling")
        $service = input_str($_POST, 'service', 100);

        $ok = db_query($conn, "INSERT INTO feedback (client_name, email, service, rating, message, created_at) VALUES (?, ?, ?, ?, ?, NOW())",
            'sssis', [$client_name, $email, $service, $rating, $message]);

        if ($ok) {
            js_alert('Feedback submitted successfully!', 'about.php');
            exit();
        } else {
            js_alert('Error submitting feedback');
        }
    } else {
        js_alert('Please fill all fields');
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>About Us — Elegance Salon</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Jost:wght@200;300;400;500&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
  <link rel="stylesheet" href="assets/style.css" />
  <link rel="stylesheet" href="assets/main.js" />
  <style>
    :root {
      --charcoal: #141414;
      --charcoal-mid: #1e1e1e;
      --charcoal-light: #2a2a2a;
      --gold: #c9a84c;
      --gold-light: #e2c97e;
      --gold-dim: rgba(201, 168, 76, 0.15);
      --cream: #f5f0e8;
      --text-muted-light: #9a9a9a;
      --transition: 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html {
      scroll-behavior: smooth;
    }

    body {
      background-color: var(--charcoal);
      color: var(--cream);
      font-family: 'Jost', sans-serif;
      font-weight: 300;
      overflow-x: hidden;
    }

    h1,
    h2,
    h3,
    h4 {
      font-family: 'Cormorant Garamond', serif;
    }

    ::selection {
      background: var(--gold);
      color: var(--charcoal);
    }

    /* NAVBAR */
    .navbar {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1000;
      padding: 1rem 3rem;
      background: rgba(20, 20, 20, 0.97);
      backdrop-filter: blur(20px);
      border-bottom: 1px solid rgba(201, 168, 76, 0.2);
    }

    .navbar-brand {
      font-family: 'Cormorant Garamond', serif;
      font-size: 1.8rem;
      font-weight: 600;
      color: var(--gold) !important;
      text-decoration: none;
    }

    .navbar-brand span {
      color: var(--cream);
      font-weight: 300;
    }

    .nav-link {
      color: var(--cream) !important;
      font-size: 0.78rem;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      padding: 0.5rem 1.2rem !important;
      transition: color var(--transition);
      position: relative;
    }

    .nav-link::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 1.2rem;
      right: 1.2rem;
      height: 1px;
      background: var(--gold);
      transform: scaleX(0);
      transition: transform var(--transition);
    }

    .nav-link:hover::after,
    .nav-link.active::after {
      transform: scaleX(1);
    }

    .nav-link:hover,
    .nav-link.active {
      color: var(--gold) !important;
    }

    .navbar-toggler {
      border: 1px solid var(--gold);
    }

    .navbar-toggler-icon {
      filter: invert(1);
    }

    /* PAGE HERO */
    .page-hero {
      padding: 10rem 0 5rem;
      position: relative;
      overflow: hidden;
      text-align: center;
    }

    .page-hero::before {
      content: '';
      position: absolute;
      inset: 0;
      background: radial-gradient(ellipse 80% 60% at 50% 100%, rgba(201, 168, 76, 0.08) 0%, transparent 70%);
    }

    .page-hero-label {
      font-size: 0.65rem;
      letter-spacing: 0.5em;
      text-transform: uppercase;
      color: var(--gold);
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 1rem;
    }

    .page-hero-label::before,
    .page-hero-label::after {
      content: '';
      width: 30px;
      height: 1px;
      background: var(--gold);
      display: block;
    }

    .page-hero h1 {
      font-size: clamp(3rem, 6vw, 5.5rem);
      font-weight: 300;
      margin-bottom: 1.5rem;
    }

    .page-hero h1 em {
      color: var(--gold);
      font-style: italic;
    }

    .page-hero p {
      color: var(--text-muted-light);
      font-size: 1rem;
      max-width: 550px;
      margin: 0 auto;
      line-height: 1.9;
    }

    /* STORY SECTION */
    .section-story {
      padding: 8rem 0;
    }

    .story-img {
      position: relative;
    }

    .story-img-main {
      width: 100%;
      height: 520px;
      object-fit: cover;
      filter: brightness(0.8) sepia(10%);
    }

    .story-img-accent {
      position: absolute;
      bottom: -40px;
      right: -40px;
      width: 200px;
      height: 260px;
      object-fit: cover;
      filter: brightness(0.75) sepia(10%);
      border: 4px solid var(--charcoal);
    }

    .story-badge {
      position: absolute;
      top: 2rem;
      left: -1rem;
      background: var(--gold);
      color: var(--charcoal);
      padding: 1rem 1.5rem;
      font-family: 'Cormorant Garamond', serif;
    }

    .story-badge .num {
      font-size: 2.5rem;
      font-weight: 600;
      line-height: 1;
      display: block;
    }

    .story-badge .label {
      font-size: 0.65rem;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      font-family: 'Jost', sans-serif;
    }

    .section-label {
      font-size: 0.65rem;
      letter-spacing: 0.4em;
      text-transform: uppercase;
      color: var(--gold);
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .section-label::before {
      content: '';
      width: 30px;
      height: 1px;
      background: var(--gold);
      display: block;
    }

    .section-title {
      font-size: clamp(2.2rem, 4vw, 3.5rem);
      font-weight: 300;
      line-height: 1.2;
      margin-bottom: 1rem;
    }

    .section-title em {
      font-style: italic;
      color: var(--gold);
    }

    .story-text {
      color: var(--text-muted-light);
      font-size: 0.92rem;
      line-height: 2;
      margin-bottom: 1.2rem;
    }

    /* VALUES */
    .section-values {
      padding: 6rem 0;
      background: var(--charcoal-mid);
    }

    .value-item {
      display: flex;
      gap: 1.5rem;
      margin-bottom: 2.5rem;
    }

    .value-num {
      font-family: 'Cormorant Garamond', serif;
      font-size: 3rem;
      font-weight: 600;
      color: var(--gold);
      opacity: 0.25;
      line-height: 1;
      flex-shrink: 0;
      width: 60px;
      text-align: right;
    }

    .value-content h4 {
      font-size: 1.2rem;
      font-weight: 400;
      margin-bottom: 0.5rem;
    }

    .value-content p {
      font-size: 0.85rem;
      color: var(--text-muted-light);
      line-height: 1.8;
    }

    /* STATS STRIP */
    .stats-strip {
      background: var(--gold);
      padding: 4rem 0;
    }

    .stat-strip-item {
      text-align: center;
    }

    .stat-strip-num {
      font-family: 'Cormorant Garamond', serif;
      font-size: 3.5rem;
      font-weight: 600;
      color: var(--charcoal);
      display: block;
      line-height: 1;
    }

    .stat-strip-label {
      font-size: 0.7rem;
      letter-spacing: 0.25em;
      text-transform: uppercase;
      color: rgba(20, 20, 20, 0.65);
      margin-top: 0.3rem;
    }

    /* TEAM SECTION */
    .section-team {
      padding: 8rem 0;
    }

    .team-card {
      position: relative;
      overflow: hidden;
    }

    .team-img {
      width: 100%;
      height: 380px;
      object-fit: cover;
      object-position: top;
      filter: brightness(0.8) sepia(5%);
      transition: transform 0.7s ease, filter 0.5s ease;
    }

    .team-card:hover .team-img {
      transform: scale(1.05);
      filter: brightness(0.7);
    }

    .team-info {
      background: var(--charcoal-mid);
      border: 1px solid rgba(201, 168, 76, 0.12);
      border-top: 2px solid var(--gold);
      padding: 1.5rem;
    }

    .team-name {
      font-size: 1.4rem;
      font-weight: 300;
      margin-bottom: 0.2rem;
    }

    .team-role {
      font-size: 0.65rem;
      letter-spacing: 0.25em;
      text-transform: uppercase;
      color: var(--gold);
      margin-bottom: 0.8rem;
    }

    .team-bio {
      font-size: 0.8rem;
      color: var(--text-muted-light);
      line-height: 1.7;
      margin-bottom: 1rem;
    }

    .team-social {
      display: flex;
      gap: 0.5rem;
    }

    .team-soc {
      width: 30px;
      height: 30px;
      border: 1px solid rgba(201, 168, 76, 0.2);
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--text-muted-light);
      text-decoration: none;
      font-size: 0.75rem;
      transition: var(--transition);
    }

    .team-soc:hover {
      border-color: var(--gold);
      color: var(--gold);
    }

    /* MILESTONES */
    .section-milestones {
      padding: 6rem 0;
      background: var(--charcoal-mid);
    }

    .timeline {
      position: relative;
    }

    .timeline::before {
      content: '';
      position: absolute;
      left: 50%;
      top: 0;
      bottom: 0;
      width: 1px;
      background: linear-gradient(to bottom, transparent, var(--gold), transparent);
      transform: translateX(-50%);
    }

    .timeline-item {
      display: flex;
      gap: 3rem;
      align-items: flex-start;
      margin-bottom: 4rem;
      position: relative;
    }

    .timeline-item:nth-child(even) {
      flex-direction: row-reverse;
    }

    .timeline-year {
      font-family: 'Cormorant Garamond', serif;
      font-size: 2.5rem;
      font-weight: 300;
      color: var(--gold);
      opacity: 0.6;
      flex: 1;
      text-align: right;
      padding-top: 0.2rem;
    }

    .timeline-item:nth-child(even) .timeline-year {
      text-align: left;
    }

    .timeline-dot {
      width: 12px;
      height: 12px;
      background: var(--gold);
      border-radius: 50%;
      flex-shrink: 0;
      margin-top: 0.8rem;
      position: relative;
      z-index: 2;
    }

    .timeline-content {
      flex: 1;
    }

    .timeline-content h4 {
      font-size: 1.2rem;
      font-weight: 400;
      margin-bottom: 0.5rem;
    }

    .timeline-content p {
      font-size: 0.83rem;
      color: var(--text-muted-light);
      line-height: 1.8;
    }

    /* CONTACT SECTION */
    .section-contact {
      padding: 8rem 0;
    }

    .contact-card {
      background: var(--charcoal-mid);
      border: 1px solid rgba(201, 168, 76, 0.12);
      padding: 3rem;
      height: 100%;
    }

    .contact-card .icon-wrap {
      width: 50px;
      height: 50px;
      border: 1px solid rgba(201, 168, 76, 0.3);
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--gold);
      font-size: 1.2rem;
      margin-bottom: 1.5rem;
    }

    .contact-card h4 {
      font-size: 1.3rem;
      font-weight: 400;
      margin-bottom: 0.5rem;
    }

    .contact-card p,
    .contact-card a {
      font-size: 0.87rem;
      color: var(--text-muted-light);
      line-height: 1.8;
      text-decoration: none;
      display: block;
    }

    .contact-card a:hover {
      color: var(--gold);
    }

    /* MAP */
    .map-frame {
      width: 100%;
      height: 380px;
      border: 1px solid rgba(201, 168, 76, 0.15);
      overflow: hidden;
      position: relative;
      background: var(--charcoal-light);
    }

    .map-placeholder {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100%;
      gap: 1rem;
    }

    .map-placeholder i {
      font-size: 3rem;
      color: var(--gold);
      opacity: 0.5;
    }

    .map-placeholder p {
      font-size: 0.85rem;
      color: var(--text-muted-light);
      text-align: center;
    }

    .map-pin {
      font-size: 0.7rem;
      letter-spacing: 0.2em;
      text-transform: uppercase;
      color: var(--gold);
      border: 1px solid rgba(201, 168, 76, 0.3);
      padding: 0.5rem 1.2rem;
      margin-top: 0.5rem;
    }

    /* FEEDBACK FORM */
    .section-feedback {
      padding: 6rem 0;
      background: var(--charcoal-mid);
    }

    .form-input-fb {
      width: 100%;
      background: transparent;
      border: none;
      border-bottom: 1px solid rgba(201, 168, 76, 0.2);
      color: var(--cream);
      font-family: 'Jost', sans-serif;
      font-size: 0.95rem;
      font-weight: 300;
      padding: 0.8rem 0;
      transition: border-color var(--transition);
      outline: none;
    }

    .form-input-fb:focus {
      border-bottom-color: var(--gold);
    }

    .form-input-fb::placeholder {
      color: var(--text-muted-light);
      font-size: 0.87rem;
    }

    .form-label-fb {
      font-size: 0.68rem;
      letter-spacing: 0.25em;
      text-transform: uppercase;
      color: var(--gold);
      display: block;
      margin-bottom: 0.7rem;
    }

    .form-grp-fb {
      margin-bottom: 1.8rem;
    }

    .star-rating {
      display: flex;
      gap: 0.5rem;
      margin-top: 0.5rem;
    }

    .star-btn {
      font-size: 1.5rem;
      color: rgba(201, 168, 76, 0.2);
      cursor: pointer;
      transition: color var(--transition);
      background: none;
      border: none;
      padding: 0;
    }

    .star-btn.lit {
      color: var(--gold);
    }

    .btn-gold {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      background: var(--gold);
      color: var(--charcoal);
      font-family: 'Jost', sans-serif;
      font-weight: 500;
      font-size: 0.75rem;
      letter-spacing: 0.25em;
      text-transform: uppercase;
      padding: 0.9rem 2rem;
      text-decoration: none;
      transition: var(--transition);
      border: 1px solid var(--gold);
      cursor: pointer;
    }

    .btn-gold:hover {
      background: transparent;
      color: var(--gold);
    }

    .feedback-success {
      display: none;
      background: var(--gold-dim);
      border: 1px solid rgba(201, 168, 76, 0.3);
      padding: 1.5rem;
      text-align: center;
    }

    .feedback-success.show {
      display: block;
    }

    .feedback-success p {
      font-size: 0.9rem;
      color: var(--gold);
      margin: 0;
    }

    /* FOOTER */
    footer {
      background: #0e0e0e;
      padding: 5rem 0 2rem;
      border-top: 1px solid rgba(201, 168, 76, 0.1);
    }

    .footer-brand {
      font-family: 'Cormorant Garamond', serif;
      font-size: 2rem;
      font-weight: 600;
      color: var(--gold);
    }

    .footer-brand span {
      color: var(--cream);
      font-weight: 300;
    }

    .footer-tagline {
      font-size: 0.75rem;
      letter-spacing: 0.25em;
      text-transform: uppercase;
      color: var(--text-muted-light);
      margin-top: 0.5rem;
    }

    .footer-heading {
      font-size: 0.65rem;
      letter-spacing: 0.3em;
      text-transform: uppercase;
      color: var(--gold);
      margin-bottom: 1.5rem;
    }

    .footer-links {
      list-style: none;
      padding: 0;
    }

    .footer-links li {
      margin-bottom: 0.8rem;
    }

    .footer-links a {
      color: var(--text-muted-light);
      text-decoration: none;
      font-size: 0.87rem;
      transition: color var(--transition);
    }

    .footer-links a:hover {
      color: var(--gold);
    }

    .social-icons {
      display: flex;
      gap: 0.8rem;
      margin-top: 1.5rem;
    }

    .social-icon {
      width: 38px;
      height: 38px;
      border: 1px solid rgba(201, 168, 76, 0.25);
      display: flex;
      align-items: center;
      justify-content: center;
      color: var(--text-muted-light);
      text-decoration: none;
      font-size: 0.9rem;
      transition: var(--transition);
    }

    .social-icon:hover {
      border-color: var(--gold);
      color: var(--gold);
    }

    .footer-bottom {
      border-top: 1px solid rgba(255, 255, 255, 0.05);
      padding-top: 2rem;
      margin-top: 3rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 1rem;
    }

    .footer-bottom p {
      font-size: 0.75rem;
      color: var(--text-muted-light);
      margin: 0;
    }

    @media (max-width:991px) {
      .navbar {
        padding: 1rem 1.5rem;
      }

      .story-img-accent {
        display: none;
      }

      .timeline::before {
        left: 20px;
      }

      .timeline-item,
      .timeline-item:nth-child(even) {
        flex-direction: column;
        gap: 1rem;
      }

      .timeline-year {
        text-align: left !important;
        font-size: 1.8rem;
      }
    }

    /* Specific tweaks for the combined form */
    .feedback-container {
      max-width: 900px;
      margin: 0 auto;
      background: var(--charcoal-mid);
      padding: 4rem;
      border: 1px solid rgba(201, 168, 76, 0.15);
    }

    .form-row-custom {
      display: flex;
      gap: 2rem;
      margin-bottom: 2rem;
    }

    .half-width {
      flex: 1;
    }

    @media (max-width: 768px) {
      .form-row-custom {
        flex-direction: column;
        gap: 0;
      }
    }
  </style>
</head>

<body>

  <?php include "includes/header.php"; ?>

  <!-- PAGE HERO -->
  <section class="page-hero">
    <div class="page-hero-label">Our Story</div>
    <h1>More Than a Salon —<br>A <em>Legacy</em> of Beauty</h1>
    <p>For fifteen years we have been Karachi's most trusted destination for luxury beauty, built on passion, artistry, and an unwavering commitment to our clients.</p>
  </section>

  <!-- STORY / MISSION -->
  <section class="section-story">
    <div class="container-fluid px-lg-5">
      <div class="row align-items-center g-5">
        <div class="col-lg-5">
          <div class="story-img">
            <img class="story-img-main" src="https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?w=700&q=80" alt="Salon Interior" />
            <img class="story-img-accent d-none d-lg-block" src="https://images.unsplash.com/photo-1560066984-138dadb4c035?w=400&q=80" alt="Stylist" />
            <div class="story-badge">
              <span class="num">15</span>
              <span class="label">Years of Art</span>
            </div>
          </div>
        </div>
        <div class="col-lg-7">
          <div class="section-label">Our Origin</div>
          <h2 class="section-title">Where It All <em>Began</em></h2>
          <p class="story-text">In 2008, founder Nadia Hassan opened Elegance Salon with a singular vision: to bring the artistry and warmth of the world's finest salons to the heart of Karachi. Armed with a decade of training in London and Dubai, she believed that every client deserved more than a service — they deserved an experience.</p>
          <p class="story-text">What began as a small, eight-chair studio in DHA quickly earned a reputation for exceptional results and genuine care. Word spread. The clientele grew. And so did our team, attracting Karachi's most gifted stylists and beauty professionals who shared our philosophy.</p>
          <p class="story-text">Today, Elegance Salon stands as a landmark of beauty in Pakistan — a space where tradition meets innovation, and every client leaves feeling seen, celebrated, and transformed.</p>
          <div style="margin-top:2.5rem; padding:1.5rem; border-left:2px solid var(--gold); background:var(--gold-dim);">
            <p style="font-family:'Cormorant Garamond',serif;font-size:1.3rem;font-style:italic;line-height:1.7;color:var(--cream);margin:0;">"Beauty is not about looking perfect. It is about feeling entirely, gloriously, unapologetically yourself."</p>
            <p style="font-size:0.72rem;letter-spacing:0.2em;text-transform:uppercase;color:var(--gold);margin-top:0.8rem;">— Nadia Hassan, Founder</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- VALUES -->
  <section class="section-values">
    <div class="container-fluid px-lg-5">
      <div class="row">
        <div class="col-lg-5 mb-5 mb-lg-0">
          <div class="section-label">What Drives Us</div>
          <h2 class="section-title">Our Core <em>Values</em></h2>
          <p style="color:var(--text-muted-light);font-size:0.9rem;line-height:1.9;max-width:380px;margin-top:1rem;">These are not just words on a wall. They are the principles that guide every decision we make and every client we serve.</p>
        </div>
        <div class="col-lg-7">
          <div class="value-item">
            <div class="value-num">01</div>
            <div class="value-content">
              <h4>Artistry Without Compromise</h4>
              <p>We approach every client as a canvas, every appointment as a creative act. Mediocrity has no place in our salon.</p>
            </div>
          </div>
          <div class="value-item">
            <div class="value-num">02</div>
            <div class="value-content">
              <h4>Genuine Human Connection</h4>
              <p>We remember names, preferences, and milestones. Our relationships with clients span years, even generations.</p>
            </div>
          </div>
          <div class="value-item">
            <div class="value-num">03</div>
            <div class="value-content">
              <h4>Continuous Evolution</h4>
              <p>Beauty evolves. Our team trains regularly to stay ahead of global trends while honouring timeless technique.</p>
            </div>
          </div>
          <div class="value-item">
            <div class="value-num">04</div>
            <div class="value-content">
              <h4>Ethical & Sustainable Luxury</h4>
              <p>We use cruelty-free, sustainably sourced products. Elegance has a responsibility to the planet as well as our clients.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- STATS STRIP -->
  <div class="stats-strip">
    <div class="container-fluid px-lg-5">
      <div class="row g-4">
        <div class="col-6 col-md-3">
          <div class="stat-strip-item"><span class="stat-strip-num">12K+</span>
            <div class="stat-strip-label">Happy Clients</div>
          </div>
        </div>
        <div class="col-6 col-md-3">
          <div class="stat-strip-item"><span class="stat-strip-num">18</span>
            <div class="stat-strip-label">Expert Stylists</div>
          </div>
        </div>
        <div class="col-6 col-md-3">
          <div class="stat-strip-item"><span class="stat-strip-num">4.9★</span>
            <div class="stat-strip-label">Average Rating</div>
          </div>
        </div>
        <div class="col-6 col-md-3">
          <div class="stat-strip-item"><span class="stat-strip-num">15</span>
            <div class="stat-strip-label">Years of Excellence</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- TEAM -->
  <section class="section-team">
    <div class="container-fluid px-lg-5">
      <div class="row mb-5">
        <div class="col-lg-5">
          <div class="section-label">Our People</div>
          <h2 class="section-title">Meet the <em>Team</em></h2>
          <p style="color:var(--text-muted-light);font-size:0.9rem;line-height:1.9;max-width:380px;">Our team of 18 artists is the heart of Elegance. Each brings a unique perspective and a shared dedication to exceptional work.</p>
        </div>
      </div>
      <div class="row g-4">
        <div class="col-sm-6 col-lg-3">
          <div class="team-card">
            <img class="team-img" src="https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?w=400&q=80" alt="Nadia Hassan" />
            <div class="team-info">
              <div class="team-name">Nadia Hassan</div>
              <div class="team-role">Founder & Creative Director</div>
              <p class="team-bio">15+ years of international experience. Trained in London, Dubai, and New York. Nadia defines the Elegance aesthetic.</p>
              <div class="team-social">
                <a href="#" class="team-soc"><i class="bi bi-instagram"></i></a>
                <a href="#" class="team-soc"><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="team-card">
            <img class="team-img" src="https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&q=80" alt="Zara Ali" />
            <div class="team-info">
              <div class="team-name">Zara Ali</div>
              <div class="team-role">Senior Hair Stylist</div>
              <p class="team-bio">Colour specialist with a gift for balayage and lived-in tones. Zara's book is always full — and always worth the wait.</p>
              <div class="team-social">
                <a href="#" class="team-soc"><i class="bi bi-instagram"></i></a>
                <a href="#" class="team-soc"><i class="bi bi-tiktok"></i></a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="team-card">
            <img class="team-img" src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&q=80" alt="Rida Tariq" />
            <div class="team-info">
              <div class="team-name">Rida Tariq</div>
              <div class="team-role">Skin & Aesthetics Lead</div>
              <p class="team-bio">Certified aesthetician with expertise in advanced facial treatments and non-invasive skin therapies.</p>
              <div class="team-social">
                <a href="#" class="team-soc"><i class="bi bi-instagram"></i></a>
                <a href="#" class="team-soc"><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="team-card">
            <img class="team-img" src="https://images.unsplash.com/photo-1607990281513-2c110a25bd8c?w=400&q=80" alt="Sana Mirza" />
            <div class="team-info">
              <div class="team-name">Sana Mirza</div>
              <div class="team-role">Nail Artist & Technician</div>
              <p class="team-bio">International nail art competition winner. Sana transforms nails into wearable art with unmatched precision.</p>
              <div class="team-social">
                <a href="#" class="team-soc"><i class="bi bi-instagram"></i></a>
                <a href="#" class="team-soc"><i class="bi bi-pinterest"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- TIMELINE -->
  <section class="section-milestones">
    <div class="container-fluid px-lg-5">
      <div class="row mb-5">
        <div class="col text-center">
          <div class="section-label justify-content-center">Our Journey</div>
          <h2 class="section-title">Key <em>Milestones</em></h2>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <div class="timeline">
            <div class="timeline-item">
              <div class="timeline-year">2008</div>
              <div class="timeline-dot"></div>
              <div class="timeline-content">
                <h4>Doors Open</h4>
                <p>Nadia Hassan opens Elegance Salon in DHA Phase 5 with 8 chairs and a team of 4 passionate stylists.</p>
              </div>
            </div>
            <div class="timeline-item">
              <div class="timeline-year">2011</div>
              <div class="timeline-dot"></div>
              <div class="timeline-content">
                <h4>First Expansion</h4>
                <p>Doubled our floor space, added nail and skincare services, and grew our team to 12 specialists.</p>
              </div>
            </div>
            <div class="timeline-item">
              <div class="timeline-year">2015</div>
              <div class="timeline-dot"></div>
              <div class="timeline-content">
                <h4>Best Salon Award</h4>
                <p>Named Karachi's Best Luxury Salon by Beauty Magazine Pakistan for three consecutive years.</p>
              </div>
            </div>
            <div class="timeline-item">
              <div class="timeline-year">2019</div>
              <div class="timeline-dot"></div>
              <div class="timeline-content">
                <h4>Spa Wing Launch</h4>
                <p>Opened our dedicated wellness and spa wing, featuring private treatment rooms and a relaxation lounge.</p>
              </div>
            </div>
            <div class="timeline-item">
              <div class="timeline-year">2024</div>
              <div class="timeline-dot"></div>
              <div class="timeline-content">
                <h4>Digital Transformation</h4>
                <p>Launched our new online booking platform and digital client management system to serve you better.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- CONTACT -->
  <section class="section-contact">
    <div class="container-fluid px-lg-5">
      <div class="row mb-5">
        <div class="col-lg-5">
          <div class="section-label">Reach Us</div>
          <h2 class="section-title">Get In <em>Touch</em></h2>
          <p style="color:var(--text-muted-light);font-size:0.9rem;line-height:1.9;max-width:380px;">We'd love to hear from you — whether you have a question, a special request, or you'd simply like to say hello.</p>
        </div>
      </div>
      <div class="row g-4 mb-5">
        <div class="col-sm-6 col-lg-3">
          <div class="contact-card">
            <div class="icon-wrap"><i class="bi bi-geo-alt"></i></div>
            <h4>Address</h4>
            <p>12 Zamzama Boulevard<br>DHA Phase 5<br>Karachi, Pakistan</p>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="contact-card">
            <div class="icon-wrap"><i class="bi bi-telephone"></i></div>
            <h4>Phone</h4>
            <a href="tel:+922135000000">+92 21 3500-0000</a>
            <a href="tel:+923001234567">+92 300 123-4567</a>
            <p style="margin-top:0.5rem;">Mon–Sat: 10am – 8pm</p>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="contact-card">
            <div class="icon-wrap"><i class="bi bi-envelope"></i></div>
            <h4>Email</h4>
            <a href="mailto:hello@elegancesalon.pk">hello@elegancesalon.pk</a>
            <a href="mailto:bridal@elegancesalon.pk">bridal@elegancesalon.pk</a>
            <p style="margin-top:0.5rem;">Reply within 24 hours</p>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="contact-card">
            <div class="icon-wrap"><i class="bi bi-instagram"></i></div>
            <h4>Follow Us</h4>
            <a href="#">@elegancesalonkhi</a>
            <a href="#">Facebook: Elegance Salon</a>
            <a href="#">TikTok: @elegancesalon</a>
          </div>
        </div>
      </div>

      <!-- MAP -->
      <div class="map-frame">
        <div class="map-placeholder">
          <i class="bi bi-map"></i>
          <p>12 Zamzama Boulevard, DHA Phase 5, Karachi</p>
          <div class="map-pin"><i class="bi bi-geo-alt-fill me-2"></i>View on Google Maps</div>
        </div>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1810.6694655424712!2d67.03645783110481!3d24.818080314822854!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb33db195b65ecf%3A0xf59df636a8955c9f!2s12th%20Zamzama%20St%2C%20DHA%20Phase%205%20Defence%20V%20Karachi%2C%20Pakistan!5e0!3m2!1sen!2s!4v1776629797284!5m2!1sen!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      </div>
    </div>
  </section>

  <!-- FEEDBACK FORM -->
  <section class="page-hero">
    <div class="page-hero-label">Experience Excellence</div>
    <h1>Our <em>Clientele</em></h1>
    <p>Book your next visit or tell us about your recent transformation at Elegance.</p>
  </section>

  <section id="feedback" class="section-feedback">
    <div class="container">
      <div class="feedback-container">
        <div class="text-center mb-5">
          <div class="section-label justify-content-center">EST. 2008 — KARACHI'S PREMIER SALON</div>
          <h2 class="section-title">Share Your <em>Experience</em></h2>
          <p class="story-text">Help us continue to curate bespoke beauty experiences tailored to your individual identity.</p>
        </div>

        <form action="about.php" method="POST"><?= csrf_field() ?>
          <div class="form-row-custom">
            <div class="form-grp-fb half-width">
              <label class="form-label-fb" for="client_name">Full Name</label>
              <input type="text" id="client_name" name="client_name" class="form-input-fb" placeholder="Jane Doe" required>
            </div>

            <div class="form-grp-fb half-width">
              <label class="form-label-fb" for="email">Email Address</label>
              <input type="email" id="email" name="email" class="form-input-fb" placeholder="jane@example.com" required>
            </div>
          </div>

          <div class="form-row-custom">
            <div class="form-grp-fb half-width">
              <label class="form-label-fb" for="service">Service Received</label>
              <select id="service" name="service" class="form-input-fb" style="background: var(--charcoal-mid);" required>
                <option value="" disabled selected>Select a service...</option>
                <option value="Haircut & Styling">Haircut & Styling</option>
                <option value="Coloring">Coloring</option>
                <option value="Spa Treatments">Spa Treatments</option>
                <option value="Bridal Makeup">Bridal Makeup</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div class="form-grp-fb half-width">
              <label class="form-label-fb" for="rating">Rating</label>
              <select id="rating" name="rating" class="form-input-fb" style="background: var(--charcoal-mid);" required>
                <option value="5">5 - Excellent</option>
                <option value="4">4 - Very Good</option>
                <option value="3">3 - Average</option>
                <option value="2">2 - Poor</option>
                <option value="1">1 - Terrible</option>
              </select>
            </div>
          </div>

          <div class="form-grp-fb">
            <label class="form-label-fb" for="message">Your Message</label>
            <textarea id="message" name="message" class="form-input-fb" rows="4" placeholder="Tell us about your visit..." required></textarea>
          </div>

          <div class="text-center">
            <button type="submit" name="submit_feedback" class="btn-gold">
              SUBMIT FEEDBACK <i class="bi bi-arrow-right ms-2"></i>
            </button>
          </div>
        </form>
      </div>
    </div>
  </section>

  <?php include "includes/footer.php"; ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Star rating
    let currentRating = 0;

    function setRating(n) {
      currentRating = n;
      document.querySelectorAll('.star-btn').forEach((b, i) => b.classList.toggle('lit', i < n));
    }

    // Feedback form submission
    function submitFeedback() {
      const name = document.getElementById('fb-name').value.trim();
      const email = document.getElementById('fb-email').value.trim();
      const msg = document.getElementById('fb-message').value.trim();
      if (!name || !email || !msg) {
        alert('Please fill in your name, email, and feedback before submitting.');
        return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        alert('Please enter a valid email address.');
        return;
      }
      document.getElementById('feedbackForm').style.display = 'none';
      document.getElementById('feedbackSuccess').classList.add('show');
    }
  </script>
</body>

</html>