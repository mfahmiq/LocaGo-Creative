<?php
require_once __DIR__ . '/includes/connection.php'; // database connection file

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: register.php");
    exit();
}
csrf_verify();

if(isset($_POST['submit'])){

    $username = input_str($_POST, 'username', 50);
    $email    = input_email($_POST, 'email');
    $password = (string) ($_POST['password'] ?? '');

    // Server-side validation
    if (!preg_match('/^[A-Za-z0-9_.\- ]{3,50}$/', $username)) {
        js_alert('Username must be 3-50 characters (letters, numbers, spaces, . _ -).', 'register.php');
        exit();
    }
    if (!$email) {
        js_alert('Please enter a valid email address.', 'register.php');
        exit();
    }
    if (strlen($password) < 8 || strlen($password) > 72) {
        js_alert('Password must be between 8 and 72 characters.', 'register.php');
        exit();
    }

    // Password Hash (IMPORTANT for security)
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if email already exists
    $check = db_fetch_one($conn, "SELECT id FROM users WHERE email = ?", 's', [$email]);

    if($check){
        js_alert('Email already exists', 'register.php');
    } else {

        $ok = db_query($conn, "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'user')", 'sss', [$username, $email, $hashed_password]);

        if($ok){
            js_alert('Registration Successful', 'index.php');
        } else {
            js_alert('Error occurred', 'register.php');
        }
    }
}
?>
