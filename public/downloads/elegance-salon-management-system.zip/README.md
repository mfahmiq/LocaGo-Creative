<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:0F0F0F,50:8A6D2B,100:C9A84C&height=200&section=header&text=Elegance%20Salon&fontSize=60&fontColor=ffffff&fontAlignY=36&desc=Salon%20Website%20%2B%20Management%20System&descAlignY=58&descSize=18&animation=fadeIn" alt="Elegance Salon banner" width="100%" />

<img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&size=20&pause=1000&color=C9A84C&center=true&vCenter=true&width=620&lines=Online+appointment+booking;Clients%2C+staff+%26+services;Payments%2C+invoices+%26+commissions;Inventory%2C+suppliers+%26+reports" alt="Typing SVG" />

<p>
  <img src="https://img.shields.io/badge/PHP-8.x-777BB4?style=for-the-badge&logo=php&logoColor=white" alt="PHP" />
  <img src="https://img.shields.io/badge/MySQL-MySQLi-4479A1?style=for-the-badge&logo=mysql&logoColor=white" alt="MySQL" />
  <img src="https://img.shields.io/badge/Bootstrap-5-7952B3?style=for-the-badge&logo=bootstrap&logoColor=white" alt="Bootstrap" />
  <img src="https://img.shields.io/badge/JavaScript-ES6-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black" alt="JavaScript" />
  <img src="https://img.shields.io/badge/Chart.js-Reports-FF6384?style=for-the-badge&logo=chartdotjs&logoColor=white" alt="Chart.js" />
  <img src="https://img.shields.io/badge/HTML5-CSS3-E34F26?style=for-the-badge&logo=html5&logoColor=white" alt="HTML5 CSS3" />
</p>
<p>
  <img src="https://img.shields.io/badge/Architecture-Non--MVC-F97316?style=for-the-badge" alt="Non-MVC" />
  <img src="https://img.shields.io/badge/Server-XAMPP-FB7A24?style=for-the-badge&logo=xampp&logoColor=white" alt="XAMPP" />
</p>

</div>

---

## ✨ Overview

**Elegance Salon** is a luxury black-and-gold salon website with a complete **back-office management system**, built in plain **PHP + MySQL**. Customers can explore services and **book appointments online**, while admins, receptionists and stylists manage the whole salon from one dashboard — clients, staff, services, payments, invoices, inventory, suppliers, commissions, feedback and reports.

## 📸 Screenshots

| Home | Services |
|:---:|:---:|
| <img src="docs/screenshots/home.png" alt="Home page" /> | <img src="docs/screenshots/services.png" alt="Services" /> |
| **Book an appointment** | **Login** |
| <img src="docs/screenshots/booking.png" alt="Booking" /> | <img src="docs/screenshots/login.png" alt="Login" /> |
| **Admin dashboard** | **Appointments** |
| <img src="docs/screenshots/dashboard.png" alt="Dashboard" /> | <img src="docs/screenshots/appointments-admin.png" alt="Appointments" /> |
| **Reports & analytics** | **Invoices** |
| <img src="docs/screenshots/reports.png" alt="Reports" /> | <img src="docs/screenshots/invoices.png" alt="Invoices" /> |

## 🚀 Features

<table>
<tr>
<td width="50%" valign="top">

### 💇 Customer website
- Elegant landing page with animated particles
- Services catalogue by category with prices & duration
- Online **appointment booking**
- About page and customer **feedback** form
- Register / login with hashed passwords

</td>
<td width="50%" valign="top">

### 🗂️ Management dashboard
- Role-based access: **Admin, Receptionist, Stylist, User**
- Overview KPIs and recent appointments
- Appointments, clients, staff & services (full CRUD)
- Payments, **invoice generation** & invoice view
- Staff **commissions**, inventory with low-stock alerts, suppliers
- Feedback inbox and **Chart.js** reports

</td>
</tr>
</table>

## 🧰 Tech Stack

| Layer | Technology |
|---|---|
| Backend | PHP (procedural, MySQLi), sessions, `password_hash` / `password_verify` |
| Database | MySQL / MariaDB — 12 tables + `dashboard_stats` view (`salon_db.sql`) |
| Frontend | HTML5, CSS3, Bootstrap 5, Bootstrap Icons, Font Awesome, vanilla JavaScript |
| Charts | Chart.js |
| Server | Apache via XAMPP |

## 📁 Folder Structure (non-MVC)

```text
elegance-salon/
├── index.php            # home page
├── about.php            # about us
├── services.php         # services catalogue
├── appointments.php     # online booking
├── feedback.php         # customer feedback
├── Login_page.php       # login form      → login_logic.php
├── register.php         # sign-up form    → register_logic.php
├── logout.php
├── Admin/               # dashboard, appointments, clients, staff, services, payments,
│                        # invoices, inventory, suppliers, users, commissions, feedback, reports
├── includes/            # connection.php (MySQLi), security.php (CSRF, escaping, validation,
│                        # prepared-statement helpers), admin_guard.php (auth + roles),
│                        # config.example.php, header.php, footer.php, sidebar.php
├── assets/              # style.css, main.js
├── img/                 # logo
└── salon_db.sql         # database schema + demo data
```

## ⚙️ Run Locally (XAMPP)

1. Install **XAMPP** and start **Apache** and **MySQL**.
2. Clone into `htdocs`:
   ```bash
   cd C:/xampp/htdocs
   git clone https://github.com/ShaheerKhanDev1/elegance-salon-management-system.git Saloon
   ```
3. Open **http://localhost/phpmyadmin** → create a database named **`salon_db`** → **Import** `salon_db.sql`.
4. Database settings: the app works out of the box with XAMPP defaults (host `localhost`, user `root`, empty password, database `salon_db`) from `includes/config.example.php`. For other credentials copy it to **`includes/config.php`** (git-ignored) and edit it — or set `DB_HOST`, `DB_USER`, `DB_PASS`, `DB_NAME` in a `.env` file / environment variables.
5. Visit **http://localhost/Saloon/** 🎉

**Demo logins** (local demo data only — change them after importing):

| Role | E-mail | Password |
|---|---|---|
| Admin | `admin@elegancesalon.pk` | `Demo@12345` |
| Stylist | `areeb123@example.com` | `Demo@12345` |
| Receptionist | `areeb.demo@example.com` | `Demo@12345` |
| Customer | `user@example.com` | `Demo@12345` |

> ✅ All links, redirects and includes match the real file/folder names, so the project runs on case-sensitive Linux hosting (cPanel) as well as Windows/XAMPP.

## 🔐 Security

| Protection | How it works |
|---|---|
| 🔑 **Authentication** | `password_hash()` / `password_verify()` (bcrypt, auto-rehash), `session_regenerate_id()` on login, full session destroy on logout, 30-minute idle timeout for the back office |
| 🛡️ **Authorization** | `includes/admin_guard.php` runs at the top of **every** `Admin/` page and handler: logged-in + active account required, role checked per page (admin / receptionist / stylist), customers are kept out of the back office |
| 💉 **SQL injection** | Every query that uses input runs as a **MySQLi prepared statement** (`db_query()` / `db_fetch_one()` helpers) |
| ✅ **Validation** | Server-side checks for every field: e-mail, phone, integers, decimals, dates, whitelisted enums (roles, categories, statuses), length limits |
| 🧼 **XSS** | All user data is escaped on output with `e()` (`htmlspecialchars`, `ENT_QUOTES`, UTF-8); chart data is JSON-encoded safely |
| 🔁 **CSRF** | A per-session token in every POST form, verified in each handler; delete links carry the token too. Requests without a valid token get **403** |
| 🍪 **Sessions** | `HttpOnly`, `SameSite=Lax`, `Secure` on HTTPS, strict mode |
| 🗝️ **Secrets** | DB credentials live in `includes/config.php` or `.env` — both git-ignored. Only `config.example.php` (XAMPP defaults) is committed |
| 🚧 **Server-level** | `.htaccess` blocks directory listing and direct access to `includes/`, `*.sql`, `.env`, `.git*` and docs; include files also refuse direct requests |

Tested locally with PHP 8 + MariaDB: every customer page, booking, register/login, every admin page and CRUD flow, reports, plus negative tests (anonymous/role access, SQL-injection payloads, CSRF-less and forged-token requests, XSS payloads) — **100/100 checks passed**.

> The demo database contains **sample data only** (example e-mails, placeholder phone numbers, demo password).

## 👨‍💻 Author

<div align="center">

**Muhammad Shaheer Khan** — Full Stack Web Developer · *Web Solutions by Shaheer*

<a href="https://www.websolutionsbyshaheer.com"><img src="https://img.shields.io/badge/Website-websolutionsbyshaheer.com-8B5CF6?style=for-the-badge&logo=googlechrome&logoColor=white" alt="Website" /></a>
<a href="https://www.linkedin.com/in/muhammad-shaheer-khan-6a5155447"><img src="https://img.shields.io/badge/LinkedIn-Connect-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn" /></a>
<a href="mailto:shaheerrcodes@gmail.com"><img src="https://img.shields.io/badge/Email-shaheerrcodes@gmail.com-EA4335?style=for-the-badge&logo=gmail&logoColor=white" alt="Email" /></a>
<a href="https://github.com/ShaheerKhanDev1"><img src="https://img.shields.io/badge/GitHub-ShaheerKhanDev1-181717?style=for-the-badge&logo=github&logoColor=white" alt="GitHub" /></a>

⭐ If you like this project, give it a star!

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:C9A84C,50:8A6D2B,100:0F0F0F&height=110&section=footer" width="100%" alt="footer" />

</div>
