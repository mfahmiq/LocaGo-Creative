<?php include __DIR__ . '/includes/db.php'; ?>
<?php include __DIR__ . '/includes/function.php'; ?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SmartInventory Pro | Full System</title>
    
    <!-- Tailwind & Bootstrap -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
    <!-- External Custom CSS (../ ကို ဖြုတ်ထားပါတယ်) -->
    <link rel="stylesheet" href="assets/Css/dashboard.css">
    <link rel="stylesheet" href="assets/Css/product.css">
    <link rel="stylesheet" href="assets/Css/stockin.css">
    <link rel="stylesheet" href="assets/Css/stockout.css">
    <link rel="stylesheet" href="assets/Css/setting.css">

    <style>
        body { font-family: 'Inter', sans-serif; background-color: #F8FAFC; }
        .main-content { margin-left: 260px; }
        section { min-height: 100vh; width: 100%; }
    </style>
</head>
<body class="flex">

    <?php include __DIR__ . '/includes/sidebar.php'; ?>

    <div class="flex-1 main-content">
        <?php include __DIR__ . '/includes/navbar.php'; ?>

        <main>
            <section id="dashboard"> <?php include __DIR__ . '/pages/dashboard.php'; ?> </section>

            <!-- Product Section -->
            <section id="products"> <?php include __DIR__ . '/pages/product.php'; ?> </section>
             <section id="stockin"> <?php include __DIR__ . '/pages/stockin.php'; ?> </section>
             <section id="stockout"> <?php include __DIR__ . '/pages/stockout.php'; ?> </section>
            <section id="settings"> <?php include __DIR__ . '/pages/setting.php'; ?> </section>
        </main>
    </div>

</body>
</html>