<link rel="stylesheet" href="assets/Css/stockout.css">

<div class="stockout-wrapper">
    
    <div class="stockout-left-panel">
        <div class="panel-header">
            <h2>Stock Out</h2>
            <p>Process sales and removals with minimal input</p>
        </div>

        <div id="stockOutAlert" class="ui-alert hidden"></div>

        <form id="stockOutForm" autocomplete="off">
            <input type="hidden" name="action" value="stock_out">
            <input type="hidden" id="selected_product_id" name="product_id">

            <div class="content-card border-danger-focus">
                <label class="card-title">Select Product</label>
                <div class="search-box-wrapper">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" id="product_search_input" class="input-field shadow-input" placeholder="Search by name, SKU, or scan barcode...">
                    <div class="scanner-btn-icon">
                        <i class="fas fa-expand"></i>
                    </div>
                </div>
                <div id="searchDropdown" class="search-dropdown hidden"></div>
            </div>

            <div class="content-card">
                <label class="card-title">Transaction Details</label>
                
                <div class="form-group">
                    <label class="input-label">Reason *</label>
                    <select name="reason" class="input-field select-field" required>
                        <option value="Sale" selected>Sale (ရောင်းချခြင်း)</option>
                        <option value="Damage">Damage (ပျက်စီးဆုံးရှုံးမှု)</option>
                        <option value="Return">Return to Vendor (ကုမ္ပဏီပြန်သွင်းခြင်း)</option>
                        <option value="Adjustment">Inventory Adjustment (စာရင်းညှိခြင်း)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="input-label">Quantity to Remove *</label>
                    <input type="number" id="input_quantity" name="quantity" class="input-field" min="1" placeholder="Select a product first" required disabled>
                </div>

                <div class="form-group">
                    <label class="input-label">Reference Number (Optional)</label>
                    <input type="text" name="reference_no" class="input-field" placeholder="e.g., INV-2026-001">
                </div>

                <div class="form-group">
                    <label class="input-label">Notes</label>
                    <textarea name="remarks" id="input_remarks" class="input-field textarea-field" rows="3" placeholder="Enter specific batch details or removal notes..."></textarea>
                </div>

                <button type="submit" id="submitStockOutBtn" class="submit-action-btn" disabled>
                    <i class="fas fa-minus-circle"></i> Commit Dispatch Log
                </button>
            </div>
        </form>
    </div>

    <div class="stockout-right-panel">
        <div class="batch-summary-card">
            <h3>Batch Summary</h3>
            
            <div id="batchEmptyState" class="batch-empty-state">
                <div class="box-icon-container">
                    <i class="fas fa-box"></i>
                </div>
                <p class="main-text">No items in batch</p>
                <p class="sub-text">Search and add products to remove</p>
            </div>

            <div id="batchActiveState" class="batch-active-state hidden">
                <div class="summary-item-preview">
                    <div class="preview-icon"><i class="fas fa-tag"></i></div>
                    <div class="preview-details">
                        <h4 id="summary_p_name">Product Name</h4>
                        <span id="summary_p_sku">SKU: -</span>
                    </div>
                </div>
                <div class="summary-meta-row">
                    <span>ဆိုင်ရှိ လက်ရှိစတော့ကျန်:</span>
                    <strong id="summary_p_stock" class="text-info">0</strong>
                </div>
                <div class="summary-meta-row input-highlight-row">
                    <span>ရောင်းချ/နှုတ်မည့် ပမာဏ:</span>
                    <strong id="summary_p_added" class="text-danger">0</strong>
                </div>
                <div class="summary-meta-row total-calc-row">
                    <span>နှုတ်ပြီးပါက ကျန်မည့်စတော့:</span>
                    <strong id="summary_p_final">0</strong>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
(function() {
    const searchInput = document.getElementById('product_search_input');
    const dropdown = document.getElementById('searchDropdown');
    const hiddenId = document.getElementById('selected_product_id');
    const inputQty = document.getElementById('input_quantity');
    const submitBtn = document.getElementById('submitStockOutBtn');
    const form = document.getElementById('stockOutForm');
    const alertBox = document.getElementById('stockOutAlert');
    const remarksInput = document.getElementById('input_remarks');

    const emptyState = document.getElementById('batchEmptyState');
    const activeState = document.getElementById('batchActiveState');
    const sName = document.getElementById('summary_p_name');
    const sSku = document.getElementById('summary_p_sku');
    const sStock = document.getElementById('summary_p_stock');
    const sAdded = document.getElementById('summary_p_added');
    const sFinal = document.getElementById('summary_p_final');

    let currentAvailableStock = 0;
    let activeIndex = -1;
    let items = [];

    const clearAlert = () => {
        alertBox.classList.add('hidden');
        alertBox.classList.remove('alert-success', 'alert-error');
        alertBox.textContent = '';
    };

    const setAlert = (message, type = 'error') => {
        if (!message) {
            clearAlert();
            return;
        }
        alertBox.classList.remove('hidden', 'alert-success', 'alert-error');
        alertBox.classList.add(type === 'success' ? 'alert-success' : 'alert-error');
        alertBox.textContent = message;
    };

    const resetFormState = () => {
        hiddenId.value = '';
        currentAvailableStock = 0;
        activeIndex = -1;
        items = [];
        inputQty.value = '';
        inputQty.disabled = true;
        inputQty.removeAttribute('max');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-minus-circle"></i> Commit Dispatch Log';
        sName.textContent = '-';
        sSku.textContent = '-';
        sStock.textContent = '0';
        sAdded.textContent = '0';
        sFinal.textContent = '0';
        sFinal.style.color = '#1e293b';
        emptyState.classList.remove('hidden');
        activeState.classList.add('hidden');
        clearAlert();
    };

    const updateSummary = qty => {
        const enteredQty = Math.max(0, parseInt(qty, 10) || 0);
        sAdded.textContent = enteredQty;
        const dynamicFinal = currentAvailableStock - enteredQty;
        sFinal.textContent = dynamicFinal;
        sFinal.style.color = dynamicFinal < 0 ? '#dc2626' : '#1e293b';

        if (dynamicFinal < 0) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-exclamation-triangle"></i> စတော့ခ် မလုံလောက်ပါ';
            return;
        }

        if (hiddenId.value && enteredQty > 0) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-minus-circle"></i> Commit Dispatch Log';
            return;
        }

        submitBtn.disabled = true;
    };

    const normalizeProduct = item => {
        if (!item || typeof item !== 'object') {
            return { id: '', name: 'Unknown Product', sku: '-', current_stock: 0 };
        }
        const id = item.id || item.product_id || item.productId || item.ID || '';
        const name = item.name || item.product_name || item.title || item.productName || 'Unknown Product';
        const sku = item.sku || item.product_sku || item.SKU || item.productSKU || '-';
        const current_stock = parseInt(item.current_stock ?? item.stock ?? item.quantity ?? item.qty ?? item.stock_qty ?? 0, 10) || 0;
        return { id, name, sku, current_stock };
    };

    const chooseProduct = item => {
        const product = normalizeProduct(item);
        searchInput.value = product.name;
        hiddenId.value = product.id;
        currentAvailableStock = product.current_stock;
        inputQty.disabled = currentAvailableStock === 0;
        if (currentAvailableStock > 0) {
            inputQty.max = currentAvailableStock;
            inputQty.placeholder = 'e.g., 10';
        } else {
            inputQty.removeAttribute('max');
            inputQty.placeholder = 'Out of stock';
        }
        inputQty.value = '';
        inputQty.focus();
        submitBtn.disabled = true;
        sName.textContent = product.name;
        sSku.textContent = `SKU: ${product.sku}`;
        sStock.textContent = currentAvailableStock;
        updateSummary(0);
        emptyState.classList.add('hidden');
        activeState.classList.remove('hidden');
        dropdown.classList.add('hidden');
        activeIndex = -1;
        clearAlert();
    };

    const renderResults = data => {
        dropdown.innerHTML = '';
        const itemsData = Array.isArray(data)
            ? data
            : Array.isArray(data.data)
                ? data.data
                : Array.isArray(data.items)
                    ? data.items
                    : [];
        items = itemsData;
        if (!window._allSearchItemsCache) window._allSearchItemsCache = itemsData.slice();

        if (items.length === 0) {
            dropdown.innerHTML = '<div class="dropdown-item-node text-center text-muted">ကုန်ပစ္စည်း ရှာမတွေ့ပါ</div>';
            dropdown.classList.remove('hidden');
            return;
        }

        items.forEach((item, index) => {
            const product = normalizeProduct(item);
            const div = document.createElement('div');
            div.className = 'dropdown-item-node';
            div.tabIndex = 0;
            div.innerHTML = `
                <div class="node-info">
                    <span class="node-name">${product.name}</span>
                    <span class="node-sku">SKU: ${product.sku}</span>
                </div>
                <span class="node-badge status-${product.current_stock > 0 ? 'in' : 'out'}">လက်ကျန်: ${product.current_stock}</span>
            `;
            div.addEventListener('click', () => chooseProduct(product));
            div.addEventListener('keydown', evt => {
                if (evt.key === 'Enter') {
                    evt.preventDefault();
                    chooseProduct(product);
                }
            });
            dropdown.appendChild(div);
        });
        dropdown.classList.remove('hidden');
    };

    // Searchable dropdown: input handling, debounce, keyboard nav
    const debounce = (fn, delay = 250) => {
        let t;
        return (...args) => {
            clearTimeout(t);
            t = setTimeout(() => fn(...args), delay);
        };
    };

    // client-side search helper removed to avoid duplicate definition; server-side performSearch is used below

    // attach to search input if present
    if (searchInput) {
        const debouncedSearch = debounce(performSearch, 200);

        searchInput.addEventListener('input', e => {
            activeIndex = -1;
            hiddenId.value = '';
            const query = e.target.value.trim();
            if (!query) {
                performSearch('');
                return;
            }
            debouncedSearch(query);
        });

        searchInput.addEventListener('focus', () => {
            if (!searchInput.value.trim()) {
                performSearch('');
            }
        });

        searchInput.addEventListener('keydown', e => {
            const nodes = Array.from(dropdown.querySelectorAll('.dropdown-item-node'));
            if (nodes.length === 0) return;
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                activeIndex = Math.min(activeIndex + 1, nodes.length - 1);
                nodes.forEach(n => n.classList.remove('focused'));
                nodes[activeIndex].classList.add('focused');
                nodes[activeIndex].scrollIntoView({ block: 'nearest' });
                nodes[activeIndex].focus();
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                activeIndex = Math.max(activeIndex - 1, 0);
                nodes.forEach(n => n.classList.remove('focused'));
                nodes[activeIndex].classList.add('focused');
                nodes[activeIndex].scrollIntoView({ block: 'nearest' });
                nodes[activeIndex].focus();
            } else if (e.key === 'Escape') {
                dropdown.classList.add('hidden');
            } else if (e.key === 'Enter' && activeIndex >= 0) {
                e.preventDefault();
                chooseProduct(items[activeIndex]);
            }
        });
    }

    const performSearch = query => {
        const searchQuery = String(query || '').trim();
        const url = `../includes/function.php?action=search_product${searchQuery ? '&query=' + encodeURIComponent(searchQuery) : ''}`;

        fetch(url)
            .then(res => res.json())
            .then(renderResults)
            .catch(() => {
                dropdown.innerHTML = '<div class="dropdown-item-node text-center text-muted">Server error, please try again</div>';
                dropdown.classList.remove('hidden');
            });
    };


    inputQty.addEventListener('input', function() {
        let enteredQty = parseInt(this.value, 10);
        if (Number.isNaN(enteredQty)) {
            enteredQty = 0;
        }
        if (enteredQty < 0) {
            enteredQty = 0;
        }
        if (enteredQty > currentAvailableStock) {
            enteredQty = currentAvailableStock;
        }
        this.value = enteredQty;
        updateSummary(enteredQty);
    });

    document.addEventListener('click', function(e) {
        if (!searchInput.contains(e.target) && !dropdown.contains(e.target)) {
            dropdown.classList.add('hidden');
        }
    });

    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const selectedProductId = hiddenId.value;
        const quantityValue = parseInt(inputQty.value, 10) || 0;
        if (!selectedProductId || quantityValue <= 0) {
            setAlert('ကုန်ပစ္စည်းကိုရွေးပြီး မှန်ကန်သော ပမာဏထည့်သွင်းထားရပါမည်။', 'error');
            return;
        }

        if (quantityValue > currentAvailableStock) {
            setAlert('ထည့်သွင်းထားသော ပမာဏသည် လက်ကျန်ထက်ပိုပါသည်။', 'error');
            return;
        }

        const userRemarks = remarksInput.value;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing Dispatch...';

        fetch('../includes/function.php', {
            method: 'POST',
            body: new FormData(form)
        })
        .then(res => res.json())
        .then(data => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-minus-circle"></i> Commit Dispatch Log';
            if (data.status === 'success') {
                setAlert(data.message, 'success');
                form.reset();
                resetFormState();
                setTimeout(() => { window.location.reload(); }, 1200);
            } else {
                setAlert(data.message || 'စနစ်တွင်အမှားရှိပါသည်။', 'error');
                remarksInput.value = userRemarks;
            }
        })
        .catch(() => {
            submitBtn.disabled = false;
            setAlert('စနစ်ချိတ်ဆက်မှု ချို့ယွင်းချက် ရှိနေပါသည်။', 'error');
            remarksInput.value = userRemarks;
        });
    });

    resetFormState();
})();
</script>