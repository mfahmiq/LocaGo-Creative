<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<link rel="stylesheet" href="../assets/Css/contact.css">

<div class="contact-page-wrapper">
    <div class="contact-header">
        <h1>Get In Touch</h1>
        <p>Have questions? We would love to hear from you</p>
    </div>

    <div class="contact-grid">
        <div class="contact-info">
            <div class="info-box">
                <div class="icon-wrap"><i class="fa-solid fa-envelope"></i></div>
                <div class="info-text"><h3>Email Us</h3><p>support@smartinventory.com</p></div>
            </div>
            <div class="info-box">
                <div class="icon-wrap"><i class="fa-solid fa-phone"></i></div>
                <div class="info-text"><h3>Call Us</h3><p>+1 (555) 123-4567</p></div>
            </div>
            <div class="info-box">
                <div class="icon-wrap"><i class="fa-solid fa-location-dot"></i></div>
                <div class="info-text"><h3>Visit Us</h3><p>123 Business Avenue, NY</p></div>
            </div>
        </div>

        <div class="glass-card">
            <form>
                <div class="form-group"><label>Your Name</label><input type="text" placeholder="John Doe"></div>
                <div class="form-group"><label>Email Address</label><input type="email" placeholder="john@example.com"></div>
                <div class="form-group"><label>Message</label><textarea rows="5" placeholder="Your message..."></textarea></div>
                <button type="submit" class="btn-submit">Send Message</button>
            </form>
        </div>
    </div>

    <div class="cta-wrap">
        <div class="cta-box">
            <h2>Ready to transform your inventory management?</h2>
            <p>Join thousands of businesses that trust Smart Inventory to scale their operations.</p>
            <a href="pages/login.php" class="btn-white">Try Demo Now</a>
        </div>
    </div>

    <footer class="footer">
        <div class="footer-grid">
            <div class="footer-logo">
                <h2>📦 Smart Inventory</h2>
                <p>Smart inventory management for modern businesses.</p>
            </div>
            <div class="footer-col">
                <h4>Product</h4>
                <ul><li><a href="#">Features</a></li><li><a href="#">Pricing</a></li><li><a href="#">Solutions</a></li></ul>
            </div>
            <div class="footer-col">
                <h4>Company</h4>
                <ul><li><a href="#">About Us</a></li><li><a href="#">Careers</a></li><li><a href="#">Privacy Policy</a></li></ul>
            </div>
            <div class="footer-col">
                <h4>Support</h4>
                <ul><li><a href="#">Documentation</a></li><li><a href="#">Help Center</a></li><li><a href="#">Contact Us</a></li></ul>
            </div>
        </div>
    </footer>
</div>