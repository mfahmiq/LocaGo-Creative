<?php
// ၁။ အမှားအယွင်းများ (Errors) ရှိပါက screen ပေါ်တွင် တိုက်ရိုက်ပြသရန်
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ၂။ လမ်းကြောင်းမှန်အောင် ../ သုံးပြီး တစ်ဆင့်ပြန်ထွက်ကာ ဖိုင်များကို ချိတ်ဆက်ခြင်း

// --- Error မတက်အောင် Default variable များ ကြိုတင်သတ်မှတ်ခြင်း ---
$stock_percent = 0; 
$current_stock = 0;
$min_stock     = 0;
$p_name        = "No Product Found";
$p_sku         = "-";
$p_category    = "-";

// ၃။ Product Detail ယူခြင်း (ID 1 အတွက်) - $conn ရှိမှ အလုပ်လုပ်မည်
if (isset($conn)) {
    $p = getProductDetail($conn, 1); 

    // --- Logic စစ်ဆေးခြင်း ---
    if ($p && is_array($p)) {
        $current_stock = $p['current_stock'] ?? 0;
        $min_stock     = $p['min_stock'] ?? 0;
        $p_name        = $p['name'] ?? "Unknown Product";
        $p_sku         = $p['sku'] ?? "-";
        $p_category    = $p['category_name'] ?? "-";

        // DivisionByZero Error မတက်အောင် စစ်ဆေးခြင်း
        if ($min_stock > 0) {
            $stock_percent = ($current_stock / $min_stock) * 100;
        } else {
            $stock_percent = ($current_stock > 0) ? 100 : 0;
        }
    }

    // functions.php ထဲက data တွေကို လှမ်းယူမယ်
    $pStats   = getProductStats($conn) ?: ['total' => 0, 'active' => 0];
    $stockIn  = getStockIn($conn) ?: 0;
    $alerts   = getAlertCount($conn) ?: 0;
} else {
    // Database မချိတ်မိပါက default ပုံစံပြရန်
    $pStats   = ['total' => 0, 'active' => 0];
    $stockIn  = 0;
    $alerts   = 0;
}

$stockOut = 9; 

// Progress Bar Color
$bar_color = ($stock_percent <= 100) ? "#E67E22" : "#2ECC71";
?>

<div class="dashboard-container">
    <div class="welcome-banner">
        <div class="banner-content">
            <div class="banner-top-row">
                <div class="sparkle-icon"><i class="fas fa-sparkles"></i></div>
                <span class="live-badge">Live Dashboard</span>
            </div>
            <h1>Welcome Back! 👋</h1>
            <p>Here's what's happening with your inventory today</p>
        </div>
        <div class="banner-date">
            <small>Today's Date</small>
            <h3><?php echo date('M d, Y'); ?></h3>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="card-header">
                <div class="icon-box bg-blue"><i class="fas fa-box"></i></div>
                <i class="fas fa-eye view-btn"></i>
            </div>
            <div class="card-main">
                <small>TOTAL PRODUCTS</small>
                <h2><?php echo $pStats['total']; ?></h2>
            </div>
            <div class="card-footer">
                <span class="dot-green"></span> 
                <span class="footer-text"><?php echo $pStats['active']; ?> Active | <?php echo ($pStats['total'] - $pStats['active']); ?> Inactive</span>
            </div>
        </div>

        <div class="stat-card">
            <div class="card-header">
                <div class="icon-box bg-green"><i class="fas fa-arrow-trend-up"></i></div>
                <i class="fas fa-arrow-up-right-from-square view-btn"></i>
            </div>
            <div class="card-main">
                <small>STOCK RECEIVED</small>
                <h2><?php echo $stockIn; ?></h2>
            </div>
            <div class="card-footer">
                <span class="footer-tag bg-green-light text-green"><i class="fas fa-chart-line"></i> All Time</span>
            </div>
        </div>

        <div class="stat-card">
            <div class="card-header">
                <div class="icon-box bg-orange"><i class="fas fa-arrow-down-long"></i></div>
                <i class="fas fa-external-link-alt view-btn"></i>
            </div>
            <div class="card-main">
                <small>STOCK DISPATCHED</small>
                <h2><?php echo $stockOut; ?></h2>
            </div>
            <div class="card-footer">
                <span class="footer-tag text-orange"><i class="fas fa-chart-line"></i> All Time</span>
            </div>
        </div>

        <div class="stat-card">
            <div class="card-header">
                <div class="icon-box bg-red"><i class="fas fa-triangle-exclamation"></i></div>
                <i class="fas fa-eye view-btn"></i>
            </div>
            <div class="card-main">
                <small>CRITICAL ALERT</small>
                <h2 class="text-red"><?php echo $alerts; ?></h2>
            </div>
            <div class="card-footer">
                <span class="footer-tag text-red"><i class="fas fa-circle-exclamation"></i> Needs Attention</span>
            </div>
        </div>
    </div>
</div>

<div class="inventory-valuation-grid" style="max-width: 1100px; margin: 0 auto 30px;">
    <div class="value-card val-bg-blue">
        <div class="value-header">
            <div class="val-icon"><i class="fas fa-dollar-sign"></i></div>
            <span class="val-label">VALUE</span>
        </div>
        <div class="value-body">
            <p class="val-title">Total Inventory Value</p>
            <h1 class="val-amount">53.38M</h1>
            <p class="val-subtext">Cost: 41.21M MMK</p>
        </div>
    </div>

    <div class="value-card val-bg-green">
        <div class="value-header">
            <div class="val-icon"><i class="fas fa-bullseye"></i></div>
            <span class="val-label">PROFIT</span>
        </div>
        <div class="value-body">
            <p class="val-title">Potential Profit</p>
            <h1 class="val-amount">12.16M</h1>
            <p class="val-subtext">Margin: 29.5%</p>
        </div>
    </div>

    <div class="value-card val-bg-cyan">
        <div class="value-header">
            <div class="val-icon"><i class="fas fa-shopping-cart"></i></div>
            <span class="val-label">TODAY</span>
        </div>
        <div class="value-body">
            <p class="val-title">Today's Movements</p>
            <h1 class="val-amount text-cyan-dark">0</h1>
            <div class="val-movement-stats text-cyan-dark">
                <span><i class="fas fa-arrow-up"></i> 0</span>
                <span><i class="fas fa-arrow-down"></i> 0</span>
            </div>
        </div>
    </div>
</div>

<div class="critical-alert-section" style="max-width: 1100px; margin: 0 auto 30px;">
    <div class="alert-header-banner">
        <div class="alert-title-group">
            <div class="alert-main-icon"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="alert-text-group">
                <h2>Critical Stock Alerts <span class="alert-badge">2</span></h2>
                <p>Products requiring immediate restocking action</p>
            </div>
        </div>
        <button class="alert-view-btn">View All Products <i class="fas fa-arrow-right"></i></button>
    </div>

    <div class="alert-item-card">
        <div class="item-info-main">
            <h3>Height Adjustable Standing Desk</h3>
            <div class="item-status-tags">
                <span class="status-low-stock"><i class="fas fa-exclamation-circle"></i> LOW STOCK</span>
            </div>
            <div class="item-meta-details">
                <div class="meta-col"><small>SKU</small><p>FURN-DESK-005</p></div>
                <div class="meta-col"><small>CATEGORY</small><p>Furniture</p></div>
                <div class="meta-col meta-loc"><small>LOCATION</small><p>Warehouse B - Section 1</p></div>
                <div class="meta-col meta-sup"><small>SUPPLIER</small><p>Furniture Plus</p></div>
            </div>
        </div>

        <div class="item-stock-visual">
            <div class="stock-box current">
                <span class="stock-qty">3</span>
                <span class="stock-unit">pcs</span>
                <small>CURRENT STOCK</small>
            </div>
            <div class="stock-divider"></div>
            <div class="stock-box min">
                <span class="stock-qty">5</span>
                <span class="stock-unit">pcs</span>
                <small>MIN REQUIRED</small>
            </div>
        </div>
    </div>
</div>

<div class="dashboard-container" style="margin-top: 0; min-height: auto; padding-top: 0;">
    <div class="inventory-card">
        <div class="card-header">
            <h1 class="product-title"><?php echo $p_name; ?></h1>
            <?php if($current_stock < $min_stock && $min_stock > 0): ?>
                <div class="badge-low-stock">⚠️ LOW STOCK</div>
            <?php endif; ?>
        </div>

        <div class="card-content">
            <div class="meta-grid">
                <div class="meta-item"><span>SKU</span><strong><?php echo $p_sku; ?></strong></div>
                <div class="meta-item"><span>CATEGORY</span><strong><?php echo $p_category; ?></strong></div>
                <div class="meta-item"><span>LOCATION</span><strong>Warehouse B - Section 3</strong></div>
                <div class="meta-item"><span>SUPPLIER</span><strong>Furniture Plus</strong></div>
            </div>

            <div class="stock-display">
                <div class="stock-box box-card-mode card-orange">
                    <span class="box-label">CURRENT STOCK</span>
                    <div class="box-value"><?php echo $current_stock; ?> <small>pcs</small></div>
                </div>
                <div class="stock-box box-card-mode card-navy">
                    <span class="box-label">MIN REQUIRED</span>
                    <div class="box-value"><?php echo $min_stock; ?> <small>pcs</small></div>
                </div>
            </div>
        </div>

        <div class="status-footer">
            <p>Stock Level Status: <strong><?php echo round($stock_percent); ?>% of Minimum</strong></p>
            <div class="progress-track">
                <div class="progress-fill" style="width: <?php echo ($stock_percent > 100) ? 100 : $stock_percent; ?>%; background: <?php echo $bar_color; ?>;"></div>
            </div>
        </div>
    </div>

    <div class="bottom-grid">
        <div class="quick-actions">
            <h3>Quick Actions</h3>
            <div class="action-btn btn-blue">
                <div class="icon">📦</div>
                <div class="text">
                    <h4>Add New Product</h4>
                    <p>Register new inventory item</p>
                </div>
                <span class="chevron">&gt;</span>
            </div>
            <div class="action-btn btn-green">
                <div class="icon">📈</div>
                <div class="text">
                    <h4>Receive Stock</h4>
                    <p>Process incoming inventory</p>
                </div>
                <span class="chevron">&gt;</span>
            </div>
            <div class="action-btn btn-red">
                <div class="icon">📉</div>
                <div class="text">
                    <h4>Dispatch Stock</h4>
                    <p>Process sales or removals</p>
                </div>
                <span class="chevron">&gt;</span>
            </div>
        </div>

        <div class="recent-activity">
            <div class="activity-header">
                <h3>Recent Activity</h3>
                <a href="#" class="view-all">View All &gt;</a>
            </div>
            
            <?php 
            if (isset($conn)) {
                $activities = getRecentActivities($conn);
                if ($activities):
                    while($act = mysqli_fetch_assoc($activities)):
                        $type_class = ($act['type'] == 'in' || $act['type'] == 'restock') ? 'plus' : 'minus';
                        $sign = ($type_class == 'plus') ? '+' : '-';
            ?>
            <div class="activity-item">
                <div class="item-icon <?php echo $type_class; ?>"></div>
                <div class="item-info">
                    <strong><?php echo $act['product_name']; ?></strong>
                    <p><?php echo date('M d', strtotime($act['transaction_date'])); ?></p>
                </div>
                <div class="item-qty <?php echo $type_class; ?>">
                    <?php echo $sign . $act['quantity']; ?>
                    <span>total</span>
                </div>
            </div>
            <?php 
                    endwhile; 
                endif;
            } else {
                echo '<div class="activity-item">No recent activities found (DB connection required).</div>';
            }
            ?>
        </div>
    </div>
</div>

<div class="dashboard-wrapper" style="max-width: 1100px; margin: 0 auto;">
    <div class="inventory-card">
        <div class="card-header">
            <div class="icon-box theme-blue"><i class="fas fa-layer-group"></i></div>
            <h2>Inventory by Category</h2>
        </div>

        <?php 
        if (isset($conn)) {
            $categories = getInventoryByCategory($conn);
            $rank = 1;
            if ($categories && mysqli_num_rows($categories) > 0):
                while($cat = mysqli_fetch_assoc($categories)):
                    $cat_name = $cat['category_name'] ?? 'Uncategorized';
                    $cat_count = isset($cat['total_products']) ? (int)$cat['total_products'] : 0;
                    $cat_value = isset($cat['total_value']) ? number_format($cat['total_value']) : '0';
        ?>
        <div class="list-item">
            <div class="rank-badge circle"><?= $rank++; ?></div>
            <div class="item-details">
                <div class="top-row">
                    <span class="name"><?= $cat_name; ?></span>
                    <span class="count-tag"><?= $cat_count; ?> products</span>
                </div>
                <div class="progress-container">
                    <div class="progress-bar" style="width: 70%;"></div>
                </div>
            </div>
            <div class="price-info">
                <?= $cat_value; ?> MMK
            </div>
        </div>
        <?php
                endwhile;
            else:
                echo '<div class="list-item empty">No categories found.</div>';
            endif;
        } else {
            echo '<div class="list-item empty">No categories found (DB connection required).</div>';
        }
        ?>
    </div>

    <div class="inventory-card">
        <div class="card-header">
            <div class="icon-box theme-green"><i class="fas fa-dollar-sign"></i></div>
            <h2>Top Products by Value</h2>
        </div>

        <?php 
        if (isset($conn)) {
            $top_prods = getTopProducts($conn);
            $p_rank = 1;
            if ($top_prods && mysqli_num_rows($top_prods) > 0):
                while($prod = mysqli_fetch_assoc($top_prods)):
                    $pname = $prod['name'] ?? 'Unnamed';
                    $pstock = isset($prod['current_stock']) ? (int)$prod['current_stock'] : 0;
                    $pcat  = $prod['cat_name'] ?? '-';
                    $pval  = isset($prod['total_value']) ? number_format($prod['total_value']) : '0';
        ?>
        <div class="list-item">
            <div class="rank-badge square"><?= $p_rank++; ?></div>
            <div class="item-details">
                <div class="prod-title" style="font-weight: 700; color: #2d3748;"><?= $pname; ?></div>
                <div class="prod-sub" style="font-size: 12px; color: #718096; margin-top: 4px;"><?= $pstock; ?> pcs • <?= $pcat; ?></div>
            </div>
            <div class="price-info-bold">
                <?= $pval; ?> <br> <span>MMK</span>
            </div>
        </div>
        <?php
                endwhile;
            else:
                echo '<div class="list-item empty">No top products found.</div>';
            endif;
        } else {
            echo '<div class="list-item empty">No top products found (DB connection required).</div>';
        }
        ?>
    </div>
</div>