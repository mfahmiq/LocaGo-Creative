
<?php include '../includes/function.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="assets/Css/add_product.css">
</head>
<body>
    <div class="form-container">
        <h2>Add New Product</h2>
        <form action="save-product.php" method="POST">
            <input type="text" name="sku" placeholder="SKU Code" required>
            <input type="text" name="name" placeholder="Product Name" required>
            <select name="category_id">
                <?php 
                $cats = get_categories();
                while($c = mysqli_fetch_assoc($cats)) echo "<option value='".$c['id']."'>".$c['name']."</option>";
                ?>
            </select>
            <input type="text" name="location" placeholder="Warehouse Location">
            <input type="text" name="supplier" placeholder="Supplier Name">
            <input type="number" name="price_mmk" placeholder="Sale Price (MMK)">
            <input type="number" name="cost_price" placeholder="Cost Price (MMK)">
            <input type="number" name="current_stock" placeholder="Initial Stock">
            <input type="number" name="min_stock" placeholder="Minimum Stock Alert">
            <button type="submit" class="btn-save">Save Product</button>
        </form>
    </div>
</body>
</html>