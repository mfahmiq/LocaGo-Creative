

<link rel="stylesheet" href="../assets/Css/feature.css">

<main class="features-section">
    <div class="features-header">
        <h1>Powerful Features</h1>
        <p>Everything you need to manage your inventory efficiently and scale your business</p>
    </div>

    <div class="features-grid">
        <div class="feature-item">
            <div class="icon-box bg-blue">📦</div>
            <h3>Smart Inventory Tracking</h3>
            <p>Real-time tracking with automated stock management, barcode scanning, and intelligent alerts.</p>
        </div>

        <div class="feature-item">
            <div class="icon-box bg-purple">📈</div>
            <h3>Advanced Analytics</h3>
            <p>Comprehensive insights with predictive analytics, forecasting, and custom reports.</p>
        </div>

        <div class="feature-item">
            <div class="icon-box bg-green">🛡️</div>
            <h3>Enterprise Security</h3>
            <p>Bank-level encryption, role-based access control, and 99.9% uptime SLA.</p>
        </div>

        <div class="feature-item">
            <div class="icon-box bg-orange">⚡</div>
            <h3>Lightning Performance</h3>
            <p>Optimized for speed with instant updates and seamless multi-device sync.</p>
        </div>

        <div class="feature-item">
            <div class="icon-box bg-cyan">🏢</div>
            <h3>Multi-Warehouse Support</h3>
            <p>Manage multiple locations with centralized control and automated transfers.</p>
        </div>

        <div class="feature-item">
            <div class="icon-box bg-rose">📱</div>
            <h3>Mobile Ready</h3>
            <p>Full-featured mobile apps for iOS and Android with offline capabilities.</p>
        </div>
    </div>
</main>

