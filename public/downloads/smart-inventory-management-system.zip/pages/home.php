<section class="hero">
    <div class="badge">Next-Generation Inventory Management</div>
    <h1>Manage Your Inventory <br> Like Never Before</h1>
    <p>Streamline your operations with intelligent automation, real-time analytics, and powerful insights that drive business growth.</p>
    
    <div class="cta-buttons">
        <a href="pages/login.php" class="btn-primary">AdminLogin &rarr;</a>
        <a href="#about" class="btn-secondary">Learn More</a>
    </div>
</section>

<section class="stats-container">
    <div class="stat-card">
        <h2>10K+</h2>
        <p>Active Users</p>
    </div>
    <div class="stat-card">
        <h2>500K+</h2>
        <p>Products Managed</p>
    </div>
    <div class="stat-card">
        <h2 style="color: #00ff88;">99.9%</h2>
        <p>Uptime</p>
    </div>
    <div class="stat-card">
        <h2>50+</h2>
        <p>Countries</p>
    </div>
</section>