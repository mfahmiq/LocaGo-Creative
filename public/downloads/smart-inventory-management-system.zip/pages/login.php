<?php
session_start();

// includes folder ထဲက function.php ကို လှမ်းချိတ်ခြင်း
require_once(dirname(__DIR__) . '/includes/function.php');

$error = "";

// Form ထဲက Sign In ခလုတ်ကို နှိပ်လိုက်တဲ့အခါ အလုပ်လုပ်မယ့်အပိုင်း
if (isset($_POST['login_btn'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // function.php ထဲက function ကို လှမ်းခေါ်ပြီး စစ်ဆေးခိုင်းခြင်း
    $login_result = checkAdminLogin($conn, $username, $password);

    if ($login_result['success']) {
        // Login အောင်မြင်ရင် Session ထဲ data သိမ်းမယ်
        $admin_data = $login_result['data'];
        
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id']        = $admin_data['id'];
        $_SESSION['username']        = $admin_data['username'];
        $_SESSION['full_name']       = $admin_data['full_name'];

        // 🌟 ပြင်ဆင်လိုက်သည့်နေရာ- pages ထဲကနေ အပြင်ဘက်က ind.php ဆီ သွားရန် လမ်းကြောင်းကို ../ ခံပေးရပါသည်
        header("Location: ../ind.php");
        exit();
    } else {
        // Login မအောင်မြင်ရင် Error Message ပြမယ်
        $error = $login_result['message'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Inv - Admin Login</title>
    <link rel="stylesheet" href="../assets/Css/login.css">
</head>
<body>

<div class="login-container">
    <h2>Welcome Back!</h2>
    <p>Smart Inventory Management Pro</p>
    
    <?php if(!empty($error)): ?>
        <div class="error-msg">⚠️ <?php echo $error; ?></div>
    <?php endif; ?>

    <form action="login.php" method="POST">
        <div class="input-group">
            <label>Username</label>
            <input type="text" name="username" placeholder="Enter username" autocomplete="off" required>
        </div>
        
        <div class="input-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Enter password" required>
        </div>
        
        <button type="submit" name="login_btn">Sign In</button>
    </form>
</div>

</body>
</html>