

<link rel="stylesheet" href="../assets/Css/services.css">

<main class="services-section">
    <div class="services-header">
        <h1>Our Services</h1>
        <p>Comprehensive solutions designed to support your business growth</p>
    </div>

    <div class="services-grid">
        <div class="service-card">
            <div class="service-icon">☁️</div>
            <h2>Cloud-Based Solution</h2>
            <p>Access your inventory data anywhere, anytime with our secure cloud infrastructure.</p>
            <ul class="feature-list">
                <li>99.9% Uptime</li>
                <li>Auto Backups</li>
                <li>Global CDN</li>
                <li>SSL Security</li>
            </ul>
        </div>

        <div class="service-card">
            <div class="service-icon">🎧</div>
            <h2>24/7 Support</h2>
            <p>Round-the-clock expert support to ensure your business never stops.</p>
            <ul class="feature-list">
                <li>Live Chat</li>
                <li>Email Support</li>
                <li>Phone Support</li>
                <li>Video Tutorials</li>
            </ul>
        </div>

        <div class="service-card">
            <div class="service-icon">🔄</div>
            <h2>Regular Updates</h2>
            <p>Continuous improvements and new features based on customer feedback.</p>
            <ul class="feature-list">
                <li>Monthly Updates</li>
                <li>New Features</li>
                <li>Bug Fixes</li>
                <li>Performance Boost</li>
            </ul>
        </div>

        <div class="service-card">
            <div class="service-icon">🔒</div>
            <h2>Data Protection</h2>
            <p>Your data is encrypted and protected with industry-leading security measures.</p>
            <ul class="feature-list">
                <li>AES-256 Encryption</li>
                <li>GDPR Compliant</li>
                <li>Daily Backups</li>
                <li>Audit Logs</li>
            </ul>
        </div>
    </div>
</main>

