<?php
// C:\xampph\htdocs\project\pages\search_action.php

include '../includes/db.php';       // database ချိတ်တဲ့ဖိုင် (မှန်ပြီးသား)
include '../includes/function.php'; // 💡 s ဖြုတ်ထားပါတယ် (သင့်ဖိုင်နာမည်အတိုင်း)

$query = isset($_POST['query']) ? mysqli_real_escape_string($conn, $_POST['query']) : '';

// function.php ထဲက search function ကို လှမ်းသုံးတာပါ
$products = search_products($conn, $query);

if ($products && mysqli_num_rows($products) > 0) {
    while($row = mysqli_fetch_assoc($products)) {
        $stockClass = get_status_class($row['current_stock'], $row['min_stock']);
        $statusText = get_status_text($row['current_stock'], $row['min_stock']);
        
        echo "<tr>";
        echo "<td>
                <div class='product-info'>
                    <p class='p-name'>" . htmlspecialchars($row['name']) . "</p>
                    <small class='p-desc'>" . htmlspecialchars($row['location']) . "</small>
                </div>
              </td>";
        echo "<td>" . htmlspecialchars($row['sku']) . "</td>";
        echo "<td>" . htmlspecialchars($row['cat_name']) . "</td>";
        echo "<td>" . $row['current_stock'] . " pcs</td>";
        echo "<td>" . number_format($row['price_mmk']) . " MMK</td>";
        echo "<td><span class='status-badge $stockClass'>$statusText</span></td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6' style='text-align:center;'>ရှာဖွေမှု မတွေ့ရှိပါ။</td></tr>";
}
?>