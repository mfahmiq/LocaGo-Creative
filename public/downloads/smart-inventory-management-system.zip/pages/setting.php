<?php 
require_once 'includes/function.php';

// ၁။ Database တန်ဖိုးများကို Dynamic တွက်ချက်ခြင်း
$conn = getDBConnection();

// Total Products တွက်ချက်ရန်
$prod_res = mysqli_query($conn, "SELECT COUNT(*) as total FROM products");
$prod_row = mysqli_fetch_assoc($prod_res);
$total_products = $prod_row['total'] ?? 0;

// Total Movements (Transactions အဝင်/အထွက် စုစုပေါင်း)
$move_res = mysqli_query($conn, "SELECT COUNT(*) as total FROM transactions");
$move_row = mysqli_fetch_assoc($move_res);
$total_movements = $move_row['total'] ?? 0;

// Total Categories
$cat_res = get_categories(); // function.php ထဲမှ လှမ်းခေါ်သည်
$total_categories = mysqli_num_rows($cat_res);

// Database Storage Used Size တွက်ချက်ရန်
$db_name = "inventory_db";
$size_res = mysqli_query($conn, "SELECT SUM(data_length + index_length) AS total_size FROM information_schema.TABLES WHERE table_schema = '$db_name'");
$size_row = mysqli_fetch_assoc($size_res);
$storage_bytes = $size_row['total_size'] ?? 0;
// KB ပြောင်းလဲခြင်း
$storage_used = round($storage_bytes / 1024, 2) . " KB";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - SmartInventory Pro</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/Css/settings.css">
</head>
<body>

<div class="settings-page-container">
    
    <div class="settings-header">
        <h1>Settings</h1>
        <p>Manage system preferences and data</p>
    </div>

    <div id="settingsAlert" class="ui-notification hidden"></div>

    <div class="settings-card-panel">
        <div class="panel-inside-header">
            <div class="header-text-block">
                <h3>Product Categories</h3>
                <p>Manage inventory categories</p>
            </div>
            <button class="add-category-trigger-btn" onclick="toggleCategoryModal(true)">
                <i class="fa-solid fa-plus"></i> Add Category
            </button>
        </div>

        <div class="categories-capsule-grid">
            <?php 
            if ($total_categories > 0) {
                // Pointer ကို အစပြန်တင်ပြီး loop ပတ်ခြင်း
                mysqli_data_seek($cat_res, 0);
                while($row = mysqli_fetch_assoc($cat_res)) {
                    echo '<div class="category-capsule-item">'.htmlspecialchars($row['name']).'</div>';
                }
            } else {
                echo '<p class="text-muted">No categories created yet.</p>';
            }
            ?>
        </div>
        <div class="settings-card-panel">
    <div class="panel-inside-header">
        <div class="header-text-block">
            <h3>Data Management</h3>
            <p>Database backup နှင့် မှတ်တမ်းဟောင်းများ ရှင်းလင်းခြင်း</p>
        </div>
    </div>
    
    <div class="data-actions-row" style="display: flex; gap: 15px;">
        <a href="includes/function.php?action=backup_db" class="data-btn export-btn" style="text-decoration: none; padding: 10px 20px; background: #059669; color: white; border-radius: 8px;">
            <i class="fa-solid fa-download"></i> Backup Database
        </a>
        
        <button onclick="purgeData()" class="data-btn purge-btn" style="padding: 10px 20px; background: #dc2626; color: white; border: none; border-radius: 8px; cursor: pointer;">
            <i class="fa-solid fa-trash-can"></i> Purge History
        </button>
    </div>
</div>
    </div>

    <div class="settings-card-panel">
        <div class="panel-inside-header">
            <div class="header-text-block">
                <h3>System Information</h3>
            </div>
        </div>
        
        <div class="system-info-grid">
            <div class="info-stat-card">
                <span class="stat-label">Total Products</span>
                <span class="stat-value"><?php echo $total_products; ?></span>
            </div>
            <div class="info-stat-card">
                <span class="stat-label">Total Movements</span>
                <span class="stat-value"><?php echo $total_movements; ?></span>
            </div>
            <div class="info-stat-card">
                <span class="stat-label">Categories</span>
                <span class="stat-value"><?php echo $total_categories; ?></span>
            </div>
            <div class="info-stat-card">
                <span class="stat-label">Storage Used</span>
                <span class="stat-value"><?php echo $storage_used; ?></span>
            </div>
        </div>
    </div>

    <div class="settings-card-panel no-border-bg">
        <div class="about-section-block">
            <h3>About SmartInventory</h3>
            <p class="about-desc">A smart inventory management system designed to minimize user input errors with streamlined workflows, smart defaults, barcode scanning support, and batch operations.</p>
            <div class="about-footer-meta">
                <span>Version 1.0.0</span>
                <span class="dot-separator">•</span>
                <span>&copy; 2026 SmartInventory</span>
            </div>
        </div>
    </div>

</div>

<div id="categoryModal" class="custom-modal-overlay hidden">
    <div class="modal-box-content">
        <h4>Create New Category</h4>
        <form id="addCategoryForm">
            <input type="hidden" name="action" value="add_category">
            <div class="form-group-block">
                <label>Category Name *</label>
                <input type="text" name="category_name" placeholder="e.g., Sports Equipment" required>
            </div>
            <div class="modal-buttons-action">
                <button type="button" class="cancel-modal-btn" onclick="toggleCategoryModal(false)">Cancel</button>
                <button type="submit" class="save-modal-btn">Save Category</button>
            </div>
        </form>
    </div>
</div>

<script>
function toggleCategoryModal(show) {
    const modal = document.getElementById('categoryModal');
    if(show) modal.classList.remove('hidden');
    else modal.classList.add('hidden');
}

document.getElementById('addCategoryForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const alertBox = document.getElementById('settingsAlert');
    
    fetch('includes/function.php', {
        method: 'POST',
        body: new FormData(this)
    })
    .then(res => res.json())
    .then(data => {
        toggleCategoryModal(false);
        alertBox.classList.remove('hidden', 'success', 'error');
        
        if(data.status === 'success') {
            alertBox.classList.add('success');
            alertBox.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${data.message}`;
            setTimeout(() => { window.location.reload(); }, 1000);
        } else {
            alertBox.classList.add('error');
            alertBox.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> ${data.message}`;
        }
    });
});
function purgeData() {
    if(confirm('သတိပြုရန်! ဤလုပ်ဆောင်ချက်သည် Transaction မှတ်တမ်းအားလုံးကို ဖျက်ပစ်မည်ဖြစ်သည်။ သေချာပါသလား?')) {
        const formData = new FormData();
        formData.append('action', 'purge_data');

        fetch('includes/function.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            alert(data.message);
            if(data.status === 'success') window.location.reload();
        });
    }
}
</script>

</body>
</html>