

<link rel="stylesheet" href="../assets/Css/about.css">

<main class="about-section">
    <div class="container">
        <div class="content-left">
            <h1>About Smart Inventory</h1>
            <p>We are a team of passionate IT professionals dedicated to revolutionizing inventory management. With over 10 years of experience in enterprise software development, we understand the challenges businesses face in managing their stock efficiently.</p>
            <p>Our mission is to provide cutting-edge technology that empowers businesses of all sizes to streamline their operations, reduce costs, and scale confidently.</p>
            
            <div class="stats-container">
                <div class="stat-box">
                    <span class="stat-number">10+</span>
                    <span class="stat-label">Years Experience</span>
                </div>
                <div class="stat-box">
                    <span class="stat-number">10K+</span>
                    <span class="stat-label">Happy Customers</span>
                </div>
            </div>
        </div>

        <div class="content-right">
            <div class="feature-card">
                <span class="icon" style="color: #60a5fa;">🌐</span>
                <span class="card-title">Global Reach</span>
                <span class="card-sub">50+ Countries</span>
            </div>
            <div class="feature-card">
                <span class="icon" style="color: #f472b6;">🛡️</span>
                <span class="card-title">Secure & Safe</span>
                <span class="card-sub">Bank-Level Security</span>
            </div>
            <div class="feature-card">
                <span class="icon" style="color: #4ade80;">⚡</span>
                <span class="card-title">Fast & Reliable</span>
                <span class="card-sub">99.9% Uptime</span>
            </div>
            <div class="feature-card">
                <span class="icon" style="color: #fb923c;">📈</span>
                <span class="card-title">Always Growing</span>
                <span class="card-sub">Constant Updates</span>
            </div>
        </div>
    </div>
</main>

