<link rel="stylesheet" href="../assets/Css/pricing.css">

<main class="pricing-section">
    <div class="pricing-header">
        <h1>Simple, Transparent Pricing</h1>
        <p>Choose the perfect plan for your business needs</p>
    </div>

    <div class="pricing-grid">
        <div class="pricing-card">
            <h2>Starter</h2>
            <p class="desc">Perfect for small businesses</p>
            <div class="price">$29<span>/month</span></div>
            <ul class="pricing-features">
                <li>Up to 1,000 products</li>
                <li>Single warehouse</li>
                <li>Basic analytics</li>
                <li>Email support</li>
                <li>Mobile apps</li>
                <li>5 user accounts</li>
            </ul>
            <a href="pages/login.php" class="btn-price">Get Started</a>
        </div>

        <div class="pricing-card popular">
            <div class="popular-badge">Most Popular</div>
            <h2>Professional</h2>
            <p class="desc">Most popular for growing teams</p>
            <div class="price">$99<span>/month</span></div>
            <ul class="pricing-features">
                <li>Up to 10,000 products</li>
                <li>Up to 5 warehouses</li>
                <li>Advanced analytics</li>
                <li>Priority support</li>
                <li>API access</li>
                <li>20 user accounts</li>
                <li>Custom reports</li>
                <li>Barcode scanning</li>
            </ul>
            <a href="pages/login.php" class="btn-price gradient">Get Started</a>
        </div>

        <div class="pricing-card">
            <h2>Enterprise</h2>
            <p class="desc">For large organizations</p>
            <div class="price">Custom</div>
            <ul class="pricing-features">
                <li>Unlimited products</li>
                <li>Unlimited warehouses</li>
                <li>Enterprise analytics</li>
                <li>24/7 phone support</li>
                <li>Custom integrations</li>
                <li>Unlimited users</li>
                <li>Dedicated account manager</li>
                <li>SLA guarantee</li>
                <li>Custom training</li>
            </ul>
            <a href="pages/login.php" class="btn-price">Get Started</a>
        </div>
    </div>
</main>