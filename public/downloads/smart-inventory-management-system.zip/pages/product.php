<div class="header_container">
    <div class="title_group">
        <h1 class="maintitle">Product management</h1>
        <p class="subtitle">Manage your inventory products efficiently</p>
    </div>
    <div class="button_group">
        <a href="export_product.php" class="btn_export">Export Csv</a>
        <a href="add_product.php" class="btn_add">+ Add product</a>
    </div>
</div>

<div class="filter-container">
    <div class="search-wrapper">
        <span class="search-icon">🔍</span>
        <input type="text" id="searchInput" placeholder="Search by name, SKU, or category">
    </div>
    <select class="filter-select" id="categoryFilter">
        <option value="">All Categories</option>
        <?php
        // Try to load categories dynamically if function exists, otherwise keep some defaults
        if (function_exists('get_all_categories') && isset($conn)) {
            $cats = get_all_categories($conn);
            if ($cats && mysqli_num_rows($cats) > 0) {
                while ($c = mysqli_fetch_assoc($cats)) {
                    // normalize the category value to lowercase for consistent filtering
                    $val = strtolower(htmlspecialchars($c['name'] ?? $c['slug']));
                    $label = htmlspecialchars($c['name'] ?? $c['slug']);
                    echo "<option value=\"$val\">$label</option>";
                }
            }
        } else {
            echo '<option value="electronics">Electronics</option>';
            echo '<option value="gadgets">Gadgets</option>';
        }
        ?>
    </select>
    <select class="filter-select" id="stockFilter">
        <option value="">All Stock Level</option>
        <option value="instock">In Stock</option>
        <option value="lowstock">Low Stock</option>
        <option value="outofstock">Out Of Stock</option>
    </select>
    <button class="btn-more" id="moreFiltersBtn">
        <span>⚙️</span> More Filters
    </button>
    <div id="moreFiltersPanel" style="display:none; margin-left:10px;">
        <!-- Example extra filters -->
        <label style="margin-right:6px;">Supplier:
            <select id="supplierFilter" class="filter-select">
                <option value="">All</option>
                <option value="local">Local</option>
                <option value="import">Import</option>
            </select>
        </label>
        <label>Price Range:
            <select id="priceFilter" class="filter-select">
                <option value="">Any</option>
                <option value="0-10000">0 - 10,000</option>
                <option value="10001-50000">10,001 - 50,000</option>
            </select>
        </label>
    </div>
</div>

<div class="table-container">
    <table class="product-table">
        <thead>
            <tr>
                <th>PRODUCT</th>
                <th>SKU/BARCODE</th>
                <th>CATEGORY</th>
                <th>STOCK</th>
                <th>PRICE</th>
                <th>STATUS</th>
            </tr>
        </thead>
        <tbody id="productTableBody"> <!-- 💡 ID တိတိကျကျ ထည့်ပေးထားပါတယ် -->
            <?php
            // If get_all_products or DB not available, render an empty placeholder row.
            if (function_exists('get_all_products') && isset($conn)) {
                $products = get_all_products($conn);
                if ($products && mysqli_num_rows($products) > 0) {
                    while($row = mysqli_fetch_assoc($products)) {
                        $stockClass = function_exists('get_status_class') ? get_status_class($row['current_stock'], $row['min_stock']) : '';
                        $statusText = function_exists('get_status_text') ? get_status_text($row['current_stock'], $row['min_stock']) : '';
                        ?>
                        <tr data-category="<?php echo htmlspecialchars(strtolower($row['cat_name'])); ?>"
                            data-stock-status="<?php echo htmlspecialchars(strtolower($statusText)); ?>"
                            data-price="<?php echo htmlspecialchars($row['price_mmk']); ?>"
                            data-supplier="<?php echo htmlspecialchars(strtolower($row['supplier'] ?? '')); ?>">
                            <td>
                                <div class="product-info">
                                    <p class="p-name"><?php echo htmlspecialchars($row['name']); ?></p>
                                    <small class="p-desc"><?php echo htmlspecialchars($row['location']); ?></small>
                                </div>
                            </td>
                            <td><?php echo htmlspecialchars($row['sku']); ?></td>
                            <td><?php echo htmlspecialchars($row['cat_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['current_stock']); ?> pcs</td>
                            <td><?php echo number_format($row['price_mmk']); ?> MMK</td>
                            <td><span class="status-badge <?php echo htmlspecialchars($stockClass); ?>"><?php echo htmlspecialchars($statusText); ?></span></td>
                        </tr>
                        <?php
                    }
                } else {
                    echo "<tr><td colspan='6' style='text-align:center;'>No products found.</td></tr>";
                }
            } else {
                echo "<tr><td colspan='6' style='text-align:center;'>Products not loaded (missing function or DB connection).</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<!-- jQuery နဲ့ AJAX Script -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    // Debounced search + filters
    var debounceTimer = null;
    // keep a copy of original rows to allow client-side, case-insensitive filtering
    var originalRows = $('#productTableBody').html();
    function filterRows($rows, value, category, stock, supplier, price) {
        var q = $.trim(value).toLowerCase();
        var selectedCategory = category ? category.toLowerCase() : '';
        var selectedSupplier = supplier ? supplier.toLowerCase() : '';

        return $rows.filter(function() {
            var $row = $(this);
            var rowText = ($row.text() || '').toString().toLowerCase();
            var rowCategory = ($row.data('category') || '').toString().toLowerCase();
            var rowStock = ($row.data('stock-status') || '').toString().toLowerCase();
            var rowSupplier = ($row.data('supplier') || '').toString().toLowerCase();
            var rowPrice = parseInt($row.data('price') || $row.find('td').eq(4).text().replace(/[^0-9]/g, ''), 10);

            if (q && rowText.indexOf(q) === -1) {
                return false;
            }
            if (selectedCategory && rowCategory.indexOf(selectedCategory) === -1 && rowText.indexOf(selectedCategory) === -1) {
                return false;
            }
            if (stock) {
                if (stock === 'instock' && rowStock.indexOf('in stock') === -1 && rowStock.indexOf('instock') === -1 && rowText.indexOf('in stock') === -1 && rowText.indexOf('instock') === -1) {
                    return false;
                }
                if (stock === 'lowstock' && rowStock.indexOf('low stock') === -1 && rowStock.indexOf('lowstock') === -1 && rowText.indexOf('low stock') === -1 && rowText.indexOf('lowstock') === -1) {
                    return false;
                }
                if (stock === 'outofstock' && rowStock.indexOf('out of stock') === -1 && rowStock.indexOf('outofstock') === -1 && rowText.indexOf('out of stock') === -1 && rowText.indexOf('outofstock') === -1) {
                    return false;
                }
            }
            if (selectedSupplier && rowSupplier.indexOf(selectedSupplier) === -1 && rowText.indexOf(selectedSupplier) === -1) {
                return false;
            }
            if (price) {
                var range = price.split('-');
                if (range.length === 2) {
                    var minPrice = parseInt(range[0], 10);
                    var maxPrice = parseInt(range[1], 10);
                    if (isNaN(rowPrice) || rowPrice < minPrice || rowPrice > maxPrice) {
                        return false;
                    }
                }
            }
            return true;
        });
    }

    function doSearch() {
        var value = $('#searchInput').val();
        var category = $('#categoryFilter').val();
        var stock = $('#stockFilter').val();
        var supplier = $('#supplierFilter').length ? $('#supplierFilter').val() : '';
        var price = $('#priceFilter').length ? $('#priceFilter').val() : '';

        // quick client-side, case-insensitive filter to give instant feedback
        if (originalRows) {
            var $rows = $(originalRows);
            var matched = filterRows($rows, value, category, stock, supplier, price);
            if (matched.length > 0) {
                $('#productTableBody').html(matched);
            } else {
                $('#productTableBody').html("<tr><td colspan='6' style='text-align:center;'>No products found.</td></tr>");
            }
        }

        $.ajax({
            url: 'search_action.php',
            method: 'POST',
            data: {query: value, category: category, stock: stock, supplier: supplier, price: price},
            success: function(data){
                // If server returns empty or no <tr>, show a friendly no-results row
                var trimmed = $.trim(data);
                if (!trimmed || trimmed.indexOf('<tr') === -1) {
                    $('#productTableBody').html("<tr><td colspan='6' style='text-align:center;'>No products found.</td></tr>");
                } else {
                    $('#productTableBody').html(data);
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: " + error);
            }
        });
    }

    $('#searchInput').on('input', function(){
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(doSearch, 300);
    });

    $('#categoryFilter, #stockFilter').on('change', function(){
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(doSearch, 100);
    });

    // toggle more filters panel
    $('#moreFiltersBtn').on('click', function(){
        $('#moreFiltersPanel').toggle();
    });

    // watch extra filters
    $('#supplierFilter, #priceFilter').on('change', function(){
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(doSearch, 100);
    });

    // initial load
    doSearch();
});
</script>