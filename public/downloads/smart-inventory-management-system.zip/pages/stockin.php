<link rel="stylesheet" href="assets/Css/stockin.css">

<div class="stockin-wrapper">
    
    <div class="stockin-left-panel">
        <div id="panelHeader" class="panel-header" style="cursor:pointer;">
            <h2>Stock In <span id="panelToggleIcon" style="font-weight:normal; margin-left:8px;">&#9660;</span></h2>
            <p>Receive new inventory with minimal input</p>
        </div>

        <div id="stockInAlert" class="ui-alert hidden"></div>

        <form id="stockInForm" autocomplete="off">
            <input type="hidden" name="action" value="stock_in">
            <input type="hidden" id="selected_product_id" name="product_id">

            <div class="content-card">
                <label class="card-title">Select Product</label>
                <div class="search-box-wrapper">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" id="product_search_input" class="input-field shadow-input" placeholder="Search by name, SKU, or scan barcode...">
                    <div class="scanner-btn-icon">
                        <i class="fas fa-expand"></i>
                    </div>
                </div>
                <div id="searchDropdown" class="search-dropdown hidden"></div>
            </div>

            <div class="content-card">
                <label class="card-title">Additional Information (Optional)</label>
                
                <div class="form-group">
                    <label class="input-label">Quantity to Add *</label>
                    <input type="number" id="input_quantity" name="quantity" class="input-field" min="1" placeholder="e.g., 100" required disabled>
                </div>

                <div class="form-group">
                    <label class="input-label">Reference Number (PO, Invoice, etc.)</label>
                    <input type="text" name="reference_no" class="input-field" placeholder="e.g., PO-2026-001">
                </div>

                <div class="form-group">
                    <label class="input-label">Notes</label>
                    <textarea name="remarks" class="input-field textarea-field" rows="3" placeholder="Enter specific batch details or location notes..."></textarea>
                </div>

                <button type="submit" id="submitStockInBtn" class="submit-action-btn" disabled>
                    <i class="fas fa-check-circle"></i> Commit Procurement Log
                </button>
            </div>
        </form>
    </div>

    <div class="stockin-right-panel">
        <div class="batch-summary-card">
            <h3>Batch Summary</h3>
            
            <div id="batchEmptyState" class="batch-empty-state">
                <div class="box-icon-container">
                    <i class="fas fa-box"></i>
                </div>
                <p class="main-text">No items in batch</p>
                <p class="sub-text">Search and add products to receive</p>
            </div>

            <div id="batchActiveState" class="batch-active-state hidden">
                <div class="summary-item-preview">
                    <div class="preview-icon"><i class="fas fa-tag"></i></div>
                    <div class="preview-details">
                        <h4 id="summary_p_name">Product Name</h4>
                        <span id="summary_p_sku">SKU: -</span>
                    </div>
                </div>
                <div class="summary-meta-row">
                    <span>လက်ရှိစတော့ကျန်:</span>
                    <strong id="summary_p_stock">0</strong>
                </div>
                <div class="summary-meta-row input-highlight-row">
                    <span>အသစ်တိုးမည့်ပမာဏ:</span>
                    <strong id="summary_p_added">0</strong>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
(function() {
    // Collapse / Expand panel on header click
    const panelHeader = document.getElementById('panelHeader');
    const leftPanel = document.querySelector('.stockin-left-panel');
    const panelToggleIcon = document.getElementById('panelToggleIcon');
    panelHeader.addEventListener('click', function() {
        leftPanel.classList.toggle('collapsed');
        if (leftPanel.classList.contains('collapsed')) panelToggleIcon.innerHTML = '&#9654;';
        else panelToggleIcon.innerHTML = '&#9660;';
    });

    const searchInput = document.getElementById('product_search_input');
    const dropdown = document.getElementById('searchDropdown');
    const hiddenId = document.getElementById('selected_product_id');
    const inputQty = document.getElementById('input_quantity');
    const submitBtn = document.getElementById('submitStockInBtn');
    const form = document.getElementById('stockInForm');
    const alertBox = document.getElementById('stockInAlert');

    // Batch summary elements
    const emptyState = document.getElementById('batchEmptyState');
    const activeState = document.getElementById('batchActiveState');
    const sName = document.getElementById('summary_p_name');
    const sSku = document.getElementById('summary_p_sku');
    const sStock = document.getElementById('summary_p_stock');
    const sAdded = document.getElementById('summary_p_added');

    // ၁။ Auto-complete Search Event
    searchInput.addEventListener('input', function() {
        let val = this.value.trim();
        if (val.length < 1) {
            dropdown.classList.add('hidden');
            return;
        }

        fetch(`../includes/function.php?action=search_product&query=${encodeURIComponent(val)}`)
            .then(res => res.json())
            .then(data => {
                dropdown.innerHTML = '';
                if (data.length === 0) {
                    dropdown.innerHTML = '<div class="dropdown-item-node text-center text-muted">ကုန်ပစ္စည်း ရှာမတွေ့ပါ</div>';
                    dropdown.classList.remove('hidden');
                    return;
                }

                data.forEach(item => {
                    let div = document.createElement('div');
                    div.className = 'dropdown-item-node';
                    div.innerHTML = `
                        <div class="node-info">
                            <span class="node-name">${item.name}</span>
                            <span class="node-sku">SKU: ${item.sku}</span>
                        </div>
                        <span class="node-badge">လက်ကျန်: ${item.current_stock}</span>
                    `;
                    div.addEventListener('click', function() {
                        searchInput.value = item.name;
                        hiddenId.value = item.id;
                        
                        // Form Input များကို အလုပ်လုပ်ခွင့်ပြုခြင်း
                        inputQty.disabled = false;
                        // Enable submit only when a valid quantity is present
                        submitBtn.disabled = !(inputQty.value && parseInt(inputQty.value) > 0);
                        
                        // Batch Summary ကို ပြောင်းလဲခြင်း
                        sName.textContent = item.name;
                        sSku.textContent = `SKU: ${item.sku}`;
                        sStock.textContent = item.current_stock;
                        sAdded.textContent = inputQty.value || 0;
                        
                        emptyState.classList.add('hidden');
                        activeState.classList.remove('hidden');
                        dropdown.classList.add('hidden');
                    });
                    dropdown.appendChild(div);
                });
                dropdown.classList.remove('hidden');
            });
    });

    // အရေအတွက် ရိုက်ထည့်လိုက်ရင် ညာဘက် Batch Summary မှာ Live လိုက်ပြောင်းပေးရန်
    inputQty.addEventListener('input', function() {
        sAdded.textContent = this.value || 0;
        // Enable submit when a product is selected and quantity is valid
        const hasProduct = !!hiddenId.value;
        submitBtn.disabled = !(hasProduct && this.value && parseInt(this.value) > 0);
    });

    // နေရာလွတ်နှိပ်ရင် dropdown ပိတ်ရန်
    document.addEventListener('click', function(e) {
        if (!searchInput.contains(e.target) && !dropdown.contains(e.target)) {
            dropdown.classList.add('hidden');
        }
    });

    // ၂။ Form Submission (Ajax ဖြင့် စာရင်းသိမ်းဆည်းခြင်း)
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

        fetch('../includes/function.php', {
            method: 'POST',
            body: new FormData(this)
        })
        .then(res => res.json())
        .then(data => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-check-circle"></i> Commit Procurement Log';

            alertBox.classList.remove('hidden', 'alert-success', 'alert-error');
            if (data.status === 'success') {
                alertBox.classList.add('alert-success');
                alertBox.textContent = data.message;
                form.reset();
                inputQty.disabled = true;
                submitBtn.disabled = true;
                emptyState.classList.remove('hidden');
                activeState.classList.add('hidden');
                setTimeout(() => { window.location.reload(); }, 1200);
            } else {
                alertBox.classList.add('alert-error');
                alertBox.textContent = data.message;
            }
        })
        .catch(error => {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-check-circle"></i> Commit Procurement Log';
            alertBox.classList.remove('hidden', 'alert-success');
            alertBox.classList.add('alert-error');
            alertBox.textContent = 'Network error: ' + (error.message || 'Unable to reach server.');
        });
    });
})();
</script>