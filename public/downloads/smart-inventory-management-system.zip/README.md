# Smart Inventory Management System

**Smart Inventory Management Pro** is a web-based inventory management system developed using PHP and MySQL. It is designed to simplify product management, monitor stock movements, and provide essential inventory information through an intuitive administrative dashboard.

This project is developed for educational and training purposes to demonstrate practical PHP and MySQL application development.

---

## Project Overview

Smart Inventory Management System provides an organized approach to inventory management through a modern landing page and an interactive admin dashboard.

Administrators can manage product records, monitor incoming and outgoing stock, review inventory statistics, and identify critical stock conditions.

The system aims to improve inventory visibility, organize product information, and simplify inventory operations.

## Key Features

### 1. Modern Landing Page
- Professional user interface
- Modern gradient-based design
- Navigation sections: Home, About, Features, Services, Pricing, and Contact
- Administrator login access
- Hero section with call-to-action buttons

### 2. Admin Dashboard
- Interactive admin dashboard
- Welcome section
- Total Products overview
- Stock Received statistics
- Stock Dispatched statistics
- Critical Stock Alerts
- Notification indicator
- Product search functionality

### 3. Product Management
- Manage inventory products
- View product information
- Monitor active and inactive products
- Organize inventory records

### 4. Stock In Management
- Record incoming stock
- Monitor received quantities
- Track stock-in activities

### 5. Stock Out Management
- Record outgoing stock
- Monitor dispatched quantities
- Track stock-out activities

### 6. Settings Management
- Access system settings
- Manage available administrative configurations

### 7. Inventory Monitoring
- View inventory statistics
- Monitor stock movements
- Identify critical inventory alerts
- Review inventory activities through the dashboard

## System Interface

### Landing Page

The landing page introduces the Smart Inventory Management System with a modern interface, navigation sections, and administrator login access.

### Admin Dashboard

The dashboard provides an overview of inventory operations, including product totals, received stock, dispatched stock, and critical stock alerts.

## Dashboard Overview

| Metric | Description |
|---|---|
| Total Products | Displays the total number of products |
| Stock Received | Shows incoming stock quantities |
| Stock Dispatched | Shows outgoing stock quantities |
| Critical Alerts | Displays critical inventory alerts |

## Project Modules

| Module | Function |
|---|---|
| Home | Main landing page |
| About | System information |
| Features | System features overview |
| Services | Service information |
| Pricing | Pricing information |
| Contact | Contact section |
| Admin Dashboard | Inventory overview |
| Products | Product management |
| Stock In | Incoming stock management |
| Stock Out | Outgoing stock management |
| Settings | System configuration |

## Technologies Used

| Technology | Purpose |
|---|---|
| PHP | Application development and backend processing |
| MySQL | Database management |
| XAMPP | Local development environment |
| Apache | Web server |

## Installation & Setup

Follow the steps below to run the project locally.

### Requirements

- XAMPP
- PHP
- MySQL
- Web Browser
- Visual Studio Code or another code editor

### Step 1: Clone the Repository

Open your terminal and run:

```bash
git clone https://github.com/khaingmar123098-hue/Smart-Inventory-Management-System.git
```

Alternatively, download the project ZIP file and extract it.

### Step 2: Move the Project Folder

Move the project folder into your XAMPP `htdocs` directory.

Example:

```text
C:\xampp\htdocs\SmartInventory
```

### Step 3: Start XAMPP

Open XAMPP Control Panel and start:

- Apache
- MySQL

### Step 4: Create and Import the Database

1. Open phpMyAdmin.
2. Create a database named `inventory_db`.
3. Import the project's SQL database file.
4. Make sure the database has been imported successfully.

### Step 5: Configure Database Connection

Configure the database connection file using your local MySQL settings.

Example:

```php
$host = "localhost";
$user = "YOUR_DATABASE_USERNAME";
$pass = "YOUR_DATABASE_PASSWORD";
$dbname = "inventory_db";
```

Replace the example values with your own local database credentials.

**Important:** Do not upload private database credentials or sensitive information to a public GitHub repository.

### Step 6: Run the Application

Open your web browser and visit:

```text
http://localhost/SmartInventory/
```

Adjust the URL if your project folder name or Apache port is different.

## Project Objectives

- Simplify inventory management operations.
- Improve stock tracking and monitoring.
- Organize product information efficiently.
- Monitor incoming and outgoing stock.
- Provide a centralized inventory dashboard.
- Help administrators identify critical stock conditions.
- Demonstrate practical PHP and MySQL development.

## Security & Administration

The project includes an administrator login entry point and an administrative dashboard.

For safer project sharing:

- Keep database credentials outside the public repository.
- Use secure password hashing for administrator passwords.
- Avoid publishing real user information.
- Use demonstration data when sharing the database publicly.

This project is intended for educational and training purposes.

## Future Improvements

Potential enhancements for future versions include:

- Barcode and QR Code Integration
- Automated Low-Stock Notifications
- Inventory Reports and Analytics
- PDF and Excel Report Export
- Supplier Management
- Sales and Purchase Management
- Multi-user Role Management
- Advanced Search and Filtering
- Inventory Activity History

## Project Information

| Item | Details |
|---|---|
| Project Name | Smart Inventory Management System |
| Product Name | Smart Inventory Management Pro |
| Version | 1.0.0 |
| Project Type | Web-Based Inventory Management System |
| Category | Inventory & Stock Management |
| Target Users | Administrators and Business Owners |
| Purpose | Educational / Training Project |

## License

This project is developed for educational and training purposes.

Licensing and distribution terms should be defined by the project owner.

## Acknowledgement

Thank you for exploring **Smart Inventory Management System**.

This project demonstrates how PHP and MySQL can be used to develop an organized and user-friendly inventory management application.

---

**Smart Inventory Management Pro**

*Manage Your Inventory Like Never Before!*
