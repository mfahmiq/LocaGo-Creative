<footer style="text-align: center; padding: 50px; border-top: 1px solid rgba(255,255,255,0.1); margin-top: 50px;">
        <p style="color: #cbd5e1;">&copy; 2026 Smart Inventory Management System. All rights reserved.</p>
    </footer>
</body>
</html>