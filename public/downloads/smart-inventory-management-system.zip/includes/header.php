<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Inventory Management</title>
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* --- Base Reset --- */
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            /* about.css ထဲက Background Gradient အတိုင်း အတိအကျ ပြန်ညှိထားသည် */
            background: linear-gradient(135deg, #1e1b4b 0%, #312e81 50%, #4338ca 100%) !important;
            color: #ffffff !important;
            min-height: 100vh;
            line-height: 1.6;
            overflow-x: hidden;
        }

        /* --- ၁။ Navbar (Consistency for all pages) --- */
        .navbar {
            display: flex !important;
            justify-content: space-between !important;
            align-items: center !important;
            padding: 12px 8% !important;
            /* about.css feature-card glass look */
            background: rgba(255, 255, 255, 0.05) !important;
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            position: sticky; top: 0; z-index: 1000;
        }

        .navbar .logo {
            /* about.css pink accent color */
            background: linear-gradient(90deg, #f472b6, #fb923c) !important;
            -webkit-background-clip: text !important;
            -webkit-text-fill-color: transparent !important;
            font-weight: 800 !important;
            font-size: 1.5rem !important;
            letter-spacing: -0.5px;
        }

        .nav-links {
            display: flex !important;
            list-style: none !important;
            gap: 30px;
        }

        .nav-links li a {
            text-decoration: none !important;
            color: #cbd5e1 !important; /* about.css text color */
            font-size: 0.95rem;
            font-weight: 500;
            transition: 0.3s;
        }

        .nav-links li a:hover { color: #f472b6 !important; }

        /* --- ၂။ Hero Section (Spacing Adjustment) --- */
        .hero {
            padding: 60px 10% 40px !important;
            text-align: center !important;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .badge {
            background: rgba(244, 114, 182, 0.15);
            color: #f472b6;
            padding: 6px 16px;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            border: 1px solid rgba(244, 114, 182, 0.3);
            margin-bottom: 15px;
            display: inline-block;
        }

        .hero h1 {
            font-size: 3.5rem !important;
            font-weight: 800 !important;
            line-height: 1.1 !important;
            letter-spacing: -1.5px;
            margin-bottom: 20px !important;
            color: #ffffff;
        }

        .hero p {
            font-size: 1.1rem !important;
            color: #cbd5e1 !important;
            max-width: 650px;
            margin-bottom: 30px !important;
        }

        /* --- ၃။ Buttons (Pink/Orange Gradient from about.css) --- */
        .cta-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
        }

        .btn-get-started, .btn-primary {
            background: linear-gradient(135deg, #f472b6 0%, #fb923c 100%) !important;
            color: white !important;
            padding: 14px 32px !important;
            border-radius: 12px !important;
            text-decoration: none !important;
            font-weight: 700 !important;
            box-shadow: 0 10px 20px -5px rgba(244, 114, 182, 0.4) !important;
            transition: 0.3s ease;
        }

        .btn-secondary {
            background: rgba(255, 255, 255, 0.05) !important;
            color: white !important;
            padding: 14px 32px !important;
            border-radius: 12px !important;
            text-decoration: none !important;
            font-weight: 700 !important;
            border: 1px solid rgba(255, 255, 255, 0.15) !important;
            transition: 0.3s;
        }

        /* --- ၄။ Stats Section (Feature Card Style Matching) --- */
        .stats-container {
            display: flex !important;
            justify-content: center !important;
            gap: 25px !important;
            padding: 40px 8% 80px !important;
            flex-wrap: wrap !important;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.05) !important;
            backdrop-filter: blur(10px) !important;
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
            padding: 35px 20px !important;
            border-radius: 20px !important;
            text-align: center !important;
            min-width: 240px !important;
            flex: 1 !important;
            max-width: 280px !important;
        }

        .stat-card h2 {
            font-size: 2.5rem !important;
            color: #f472b6; /* Pink accent matching about.css icons */
            margin-bottom: 5px;
        }

        .stat-card p {
            color: #94a3b8 !important;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 1.5px;
        }
    </style>
</head>
<body>