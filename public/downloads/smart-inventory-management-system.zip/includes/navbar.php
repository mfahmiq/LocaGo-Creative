<nav class="flex justify-between items-center py-4 px-8 bg-white border-b border-gray-100">
    <div class="relative w-96">
        <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">🔍</span>
        <input type="text" class="block w-full pl-10 pr-3 py-2 border border-gray-200 rounded-2xl bg-gray-50 focus:outline-none" placeholder="Search for products...">
    </div>

    <div class="flex items-center space-x-6">
        <button class="relative text-gray-400 hover:text-blue-600">
            🔔 <span class="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] rounded-full px-1">3</span>
        </button>
        <div class="flex items-center space-x-3">
            <div class="text-right">
                <p class="text-sm font-bold">Khine</p>
                <p class="text-[10px] text-gray-400 italic">Admin</p>
            </div>
            <img src="profile.png" class="w-10 h-10 rounded-full border-2 border-blue-500" alt="Profile">
        </div>
    </div>
</nav>