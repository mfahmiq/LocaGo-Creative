<?php
// includes/function.php

// 1. Establish Database Connection
$conn = mysqli_connect("localhost", "root", "", "inventory_db");

if (!$conn) {
    header('Content-Type: application/json');
    die(json_encode(["status" => "error", "message" => "Database Connection failed: " . mysqli_connect_error()]));
}

// Helper to provide clean connection instance for modular scopes
function getDBConnection() {
    global $conn;
    if (!$conn) {
        $conn = mysqli_connect("localhost", "root", "", "inventory_db");
    }
    return $conn;
}

// 2. Get Total & Active Product Metrics
function getProductStats($conn) {
    $sql = "SELECT COUNT(*) as total, 
            SUM(CASE WHEN current_stock > 0 THEN 1 ELSE 0 END) as active 
            FROM products";
    $res = mysqli_query($conn, $sql);
    return mysqli_fetch_assoc($res);
}

// 3. Get Accumulated Inventory Valuation
function getInventoryValue($conn) {
    $sql = "SELECT SUM(price_mmk * current_stock) as total_val FROM products";
    $res = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($res);
    return $row['total_val'] ?? 0;
}

// 4. Cumulative Units Received (Calculated via Transaction Logs for data integrity)
function getStockIn($conn) {
    $sql = "SELECT SUM(quantity) as qty FROM transactions WHERE type = 'IN'";
    $res = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($res);
    return $row['qty'] ?? 0;
}

// 5. Critical Threshold Counter
function getAlertCount($conn) {
    $sql = "SELECT COUNT(*) as alert_count FROM products WHERE current_stock <= min_stock";
    $res = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($res);
    return $row['alert_count'] ?? 0;
}

// 6. Comprehensive Inventory Financial Valuation
function getInventoryValuation($conn) {
    $sql = "SELECT 
                SUM(price_mmk * current_stock) as total_sales_value,
                SUM(cost_price * current_stock) as total_cost_value
            FROM products";
    $result = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($result);
    
    $total_value = $data['total_sales_value'] ?? 0;
    $total_cost = $data['total_cost_value'] ?? 0;
    $potential_profit = $total_value - $total_cost;
    
    $margin = ($total_value > 0) ? ($potential_profit / $total_value) * 100 : 0;

    return [
        'total_value' => $total_value,
        'total_cost' => $total_cost,
        'profit' => $potential_profit,
        'margin' => $margin
    ];
}

// 7. Pull Critical Restock Alerts
function getDetailedAlerts($conn) {
    $sql = "SELECT p.*, c.name as category_name 
            FROM products p 
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.current_stock <= p.min_stock 
            ORDER BY p.current_stock ASC";
    return mysqli_query($conn, $sql);
}

// 8. Fetch Single Product Context
function getProductDetail($conn, $id) {
    $id = intval($id);
    $sql = "SELECT p.*, c.name as category_name 
            FROM products p 
            LEFT JOIN categories c ON p.category_id = c.id 
            WHERE p.id = $id";
    $result = mysqli_query($conn, $sql);
    return mysqli_fetch_assoc($result);
}

// 9. Fetch Recent System Ledger Actions
function getRecentActivities($conn) {
    $sql = "SELECT t.*, p.name as product_name 
            FROM transactions t 
            JOIN products p ON t.product_id = p.id 
            ORDER BY t.transaction_date DESC LIMIT 3";
    return mysqli_query($conn, $sql);
}

// 10. Segmented Categories Analysis
function getInventoryByCategory($conn) {
    $sql = "SELECT c.name as category_name, 
                   COUNT(p.id) as total_products, 
                   SUM(p.price_mmk * p.current_stock) as total_value 
            FROM categories c
            LEFT JOIN products p ON c.id = p.category_id
            GROUP BY c.id
            ORDER BY total_value DESC";
    return mysqli_query($conn, $sql);
}

// 11. Top Revenue Generating Assets
function getTopProducts($conn, $limit = 2) {
    $limit = intval($limit);
    $sql = "SELECT p.name, p.current_stock, c.name as cat_name, 
                   (p.price_mmk * p.current_stock) as total_value 
            FROM products p
            JOIN categories c ON p.category_id = c.id
            ORDER BY total_value DESC 
            LIMIT $limit";
    return mysqli_query($conn, $sql);
}

// 12. Standard Product Query Handler (Filters Supported)
function get_products($search = '', $category = '') {
    $conn = getDBConnection();
    $search = mysqli_real_escape_string($conn, $search);
    $category = mysqli_real_escape_string($conn, $category);
    
    $sql = "SELECT p.*, c.name AS category_name 
            FROM products p 
            LEFT JOIN categories c ON p.category_id = c.id WHERE 1=1";
    
    if ($search != '') {
        $sql .= " AND (p.name LIKE '%$search%' OR p.sku LIKE '%$search%')";
    }
    if ($category != '') {
        $sql .= " AND p.category_id = '$category'";
    }
    
    return mysqli_query($conn, $sql);
}

// 13. Fetch System Categories List
function get_categories() {
    $conn = getDBConnection();
    return mysqli_query($conn, "SELECT * FROM categories ORDER BY id DESC");
}

// 14. Fetch Chronological Raw Product Grid
function get_all_products($conn){
    $sql = "SELECT p.*, c.name as cat_name
            FROM products p
            LEFT JOIN categories c ON p.category_id=c.id
            ORDER BY p.id DESC";
    return mysqli_query($conn, $sql);
}

// 15 & 16. Utility Stock Evaluators
function get_status_class($current, $min){
    if ($current <= 0) return 'out-of-stock';
    if ($current <= $min) return 'low-stock';
    return 'in-stock';
}

function get_status_text($current, $min){
    if ($current <= 0) return 'Out of Stock';
    if ($current <= $min) return 'Low Stock';
    return 'In Stock';
}

// 17. Get System Settings Helper
function getSystemSetting($key, $default = '') {
    $conn = getDBConnection();
    $key = mysqli_real_escape_string($conn, trim($key));
    $sql = "SELECT meta_value FROM settings WHERE meta_key = '$key' LIMIT 1";
    $res = mysqli_query($conn, $sql);
    if ($res && $row = mysqli_fetch_assoc($res)) {
        return $row['meta_value'];
    }
    return $default;
}

// 18. Get Cumulative Units Dispatched
function getStockOutCount($conn) {
    $sql = "SELECT SUM(quantity) as qty FROM transactions WHERE type = 'OUT'";
    $res = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($res);
    return $row['qty'] ?? 0;
}

// 19. Fetch Active Outbound Ledger Logs
function getRecentDispatches($conn, $limit = 5) {
    $limit = intval($limit);
    $sql = "SELECT t.*, p.name as product_name, p.sku 
            FROM transactions t 
            JOIN products p ON t.product_id = p.id 
            WHERE t.type = 'OUT'
            ORDER BY t.transaction_date DESC LIMIT $limit";
    return mysqli_query($conn, $sql);
}


// =========================================================================
// ASYNCHRONOUS SECURITY API GATEWAYS (AJAX REQUESTS PROCESSING)
// =========================================================================

// REST API GATEWAY A: Dynamic Live Search Context
if (isset($_GET['action']) && $_GET['action'] == 'search_product') {
    $conn = getDBConnection();
    header('Content-Type: application/json');
    
    $search = mysqli_real_escape_string($conn, trim($_GET['query']));
    $products = [];
    
    if (strlen($search) >= 1) {
        $query = "SELECT id, sku, name, current_stock, cost_price FROM products WHERE name LIKE '%$search%' OR sku LIKE '%$search%' LIMIT 5";
        $result = mysqli_query($conn, $query);
        
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = [
                'id' => intval($row['id']),
                'sku' => htmlspecialchars($row['sku']),
                'name' => htmlspecialchars($row['name']),
                'current_stock' => intval($row['current_stock']),
                'cost_price' => floatval($row['cost_price'])
            ];
        }
    }
    
    echo json_encode($products);
    exit;
}

// REST API GATEWAY B: Secure Processing for Stock Procurement (STOCK IN)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'stock_in') {
    $conn = getDBConnection();
    header('Content-Type: application/json');
    
    $product_id = intval($_POST['product_id']);
    $qty = intval($_POST['quantity']);
    $reference_no = mysqli_real_escape_string($conn, trim($_POST['reference_no']));
    $remarks = mysqli_real_escape_string($conn, trim($_POST['remarks']));
    $user_id = 1; 

    if ($product_id <= 0 || $qty <= 0 || empty($reference_no)) {
        echo json_encode(['status' => 'error', 'message' => 'Validation Failed: Please fill in all required operational attributes.']);
        exit;
    }

    $p_query = "SELECT cost_price FROM products WHERE id = $product_id LIMIT 1";
    $p_result = mysqli_query($conn, $p_query);
    $product_data = mysqli_fetch_assoc($p_result);
    
    if (!$product_data) {
        echo json_encode(['status' => 'error', 'message' => 'Entity Conflict: Selected product reference could not be localized.']);
        exit;
    }
    
    $cost_price = floatval($product_data['cost_price']);
    $total_price = $cost_price * $qty;

    mysqli_begin_transaction($conn);

    try {
        $update_query = "UPDATE products SET current_stock = current_stock + $qty WHERE id = $product_id";
        if (!mysqli_query($conn, $update_query)) throw new Exception(mysqli_error($conn));
        
        $log_query = "INSERT INTO transactions (product_id, type, quantity, reference_no, user_id, remarks, total_price, transaction_date) 
                      VALUES ($product_id, 'IN', $qty, '$reference_no', $user_id, '$remarks', $total_price, NOW())";
        if (!mysqli_query($conn, $log_query)) throw new Exception(mysqli_error($conn));

        mysqli_commit($conn);
        echo json_encode(['status' => 'success', 'message' => 'Procurement transaction executed and ledger balance updated successfully.']);
    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo json_encode(['status' => 'error', 'message' => 'System Transaction Interrupted: ' . $e->getMessage()]);
    }
    exit;
}

// REST API GATEWAY C: Secure Processing for Stock Out / Dispatch (STOCK OUT)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'stock_out') {
    $conn = getDBConnection();
    header('Content-Type: application/json');
    
    $product_id = intval($_POST['product_id']);
    $qty = intval($_POST['quantity']);
    $reference_no = mysqli_real_escape_string($conn, trim($_POST['reference_no']));
    $remarks = mysqli_real_escape_string($conn, trim($_POST['remarks']));
    $user_id = 1; 

    if ($product_id <= 0 || $qty <= 0 || empty($reference_no)) {
        echo json_encode(['status' => 'error', 'message' => 'Validation Failed: Please fill in all required operational fields.']);
        exit;
    }

    mysqli_begin_transaction($conn);

    try {
        $stock_check_query = "SELECT current_stock, price_mmk FROM products WHERE id = $product_id LIMIT 1 FOR UPDATE";
        $stock_result = mysqli_query($conn, $stock_check_query);
        $product_data = mysqli_fetch_assoc($stock_result);

        if (!$product_data) {
            throw new Exception('Entity Conflict: Selected product variant could not be localized.');
        }

        $current_balance = intval($product_data['current_stock']);
        $selling_price = floatval($product_data['price_mmk']);
        $total_price = $selling_price * $qty;

        if ($current_balance < $qty) {
            throw new Exception("Inventory Deficit: Insufficient stock balance. Total remaining units available: {$current_balance}");
        }

        $deduct_query = "UPDATE products SET current_stock = current_stock - $qty WHERE id = $product_id";
        if (!mysqli_query($conn, $deduct_query)) throw new Exception(mysqli_error($conn));
        
        $log_query = "INSERT INTO transactions (product_id, type, quantity, reference_no, user_id, remarks, total_price, transaction_date) 
                      VALUES ($product_id, 'OUT', $qty, '$reference_no', $user_id, '$remarks', $total_price, NOW())";
        if (!mysqli_query($conn, $log_query)) throw new Exception(mysqli_error($conn));

        mysqli_commit($conn);
        echo json_encode(['status' => 'success', 'message' => 'Dispatch transaction authorized and ledger balance updated successfully.']);
    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo json_encode(['status' => 'error', 'message' => 'System Transaction Interrupted: ' . $e->getMessage()]);
    }
    exit;
}

// REST API GATEWAY D: Core System Preference Config Updates Engine (SETTINGS UPDATE)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'update_settings') {
    $conn = getDBConnection();
    header('Content-Type: application/json');

    $company_name = mysqli_real_escape_string($conn, trim($_POST['company_name']));
    $currency = mysqli_real_escape_string($conn, trim($_POST['currency']));
    $low_stock = intval($_POST['low_stock_threshold']);

    $configs = [
        'company_name' => $company_name,
        'currency' => $currency,
        'low_stock_threshold' => $low_stock
    ];

    mysqli_begin_transaction($conn);
    try {
        foreach ($configs as $meta_key => $meta_value) {
            $save_sql = "INSERT INTO settings (meta_key, meta_value) VALUES ('$meta_key', '$meta_value') 
                         ON DUPLICATE KEY UPDATE meta_value = '$meta_value'";
            if (!mysqli_query($conn, $save_sql)) throw new Exception(mysqli_error($conn));
        }
        mysqli_commit($conn);
        echo json_encode(['status' => 'success', 'message' => 'Global configurations committed to localized infrastructure successfully.']);
    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo json_encode(['status' => 'error', 'message' => 'Settings Transaction Interrupted: ' . $e->getMessage()]);
    }
    exit;
}

// REST API GATEWAY E: Settings မှ Category အသစ်ထည့်သွင်းခြင်းစနစ် (Add New Category)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add_category') {
    $conn = getDBConnection();
    header('Content-Type: application/json');

    $cat_name = mysqli_real_escape_string($conn, trim($_POST['category_name']));

    if (empty($cat_name)) {
        echo json_encode(['status' => 'error', 'message' => 'Category နာမည် ထည့်သွင်းပေးရန် လိုအပ်ပါသည်။']);
        exit;
    }

    // နာမည်တူ စာရင်းရှိမရှိ ကြိုတင်စစ်ဆေးခြင်း
    $check = mysqli_query($conn, "SELECT id FROM categories WHERE name = '$cat_name' LIMIT 1");
    if (mysqli_num_rows($check) > 0) {
        echo json_encode(['status' => 'error', 'message' => 'ဤ Category နာမည်သည် စနစ်ထဲတွင် ရှိပြီးသား ဖြစ်နေပါသည်။']);
        exit;
    }

    $sql = "INSERT INTO categories (name) VALUES ('$cat_name')";
    if (mysqli_query($conn, $sql)) {
        echo json_encode(['status' => 'success', 'message' => 'Category အသစ်ကို အောင်မြင်စွာ စာရင်းသွင်းပြီးပါပြီ။']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'သိမ်းဆည်းရာတွင် ချို့ယွင်းချက်ရှိခဲ့သည်- ' . mysqli_error($conn)]);
    }
    exit;
}

// DATA MANAGEMENT GATEWAY
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $conn = getDBConnection();
    
    // Transaction မှတ်တမ်းဟောင်းများ ရှင်းလင်းခြင်း (Purge)
    if ($_POST['action'] == 'purge_data') {
        header('Content-Type: application/json');
        $sql = "DELETE FROM transactions"; 
        if (mysqli_query($conn, $sql)) {
            echo json_encode(['status' => 'success', 'message' => 'မှတ်တမ်းဟောင်းများအားလုံး ရှင်းလင်းပြီးပါပြီ။']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Error: ' . mysqli_error($conn)]);
        }
        exit;
    }
}

// Database Backup ယူခြင်း
if (isset($_GET['action']) && $_GET['action'] == 'backup_db') {
    $filename = 'inventory_backup_' . date('Y-m-d_H-i-s') . '.sql';
    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename='.$filename);
    echo "-- SmartInventory Backup File\n-- Date: " . date('Y-m-d H:i:s');
    // ဤနေရာတွင် mysqldump သို့မဟုတ် db backup script ထည့်ရန်
    exit;
}

/**
 * ရိုးရိုးစာသား (Plain Text) ဖြင့် စစ်ဆေးပေးသည့် Admin Login Function
 */
function checkAdminLogin($conn, $username, $password) {
    $username = trim($username);
    $password = trim($password);

    if (empty($username) || empty($password)) {
        return [
            'success' => false, 
            'message' => 'ကျေးဇူးပြု၍ အချက်အလက်များ အကုန်ဖြည့်ပါ။'
        ];
    }

    // SQL Injection ကာကွယ်ရန်
    $safe_username = mysqli_real_escape_string($conn, $username);

    // Database ထဲမှာ ရှာဖွေခြင်း
    $query = "SELECT * FROM admins WHERE username = '$safe_username' LIMIT 1";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $admin_data = mysqli_fetch_assoc($result);
        
        // 🌟 password_verify အစား တိုက်ရိုက် (==) စစ်ဆေးခြင်း
        if ($password == $admin_data['password']) {
            return [
                'success' => true, 
                'message' => 'Login အောင်မြင်ပါသည်။',
                'data' => $admin_data
            ];
        } else {
            return [
                'success' => false, 
                'message' => 'Password မှားယွင်းနေပါသည်။'
            ];
        }
    } else {
        return [
            'success' => false, 
            'message' => 'အသုံးပြုသူအမည် (Username) မရှိပါ။'
        ];
    }
}