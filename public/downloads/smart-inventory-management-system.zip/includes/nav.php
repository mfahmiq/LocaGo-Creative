<nav class="navbar">
    <div class="logo">📦 Smart Inventory</div>
    
    <ul class="nav-links">
        <li><a href="#home">Home</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#features">Features</a></li>
        <li><a href="#service">Services</a></li>
        <li><a href="#pricing">Pricing</a></li>
        <li><a href="#contact">Contact</a></li>
    </ul>

    <a href="pages/login.php" class="btn-get-started">AdminLogin</a>
</nav>