<div class="fixed w-64 h-screen bg-[#001529] text-gray-300 p-6 shadow-2xl z-50">
    <div class="mb-10 px-4">
        <h2 class="text-2xl font-black italic text-white tracking-tighter">SMART INV.</h2>
        <p class="text-[10px] text-blue-400 font-bold uppercase tracking-widest">Management Pro</p>
    </div>
    
    <nav class="space-y-2">
        <a href="#dashboard" class="flex items-center gap-3 p-4 hover:bg-blue-600 hover:text-white rounded-2xl transition-all duration-300">
            <span>📊</span> Dashboard
        </a>
        <a href="#products" class="flex items-center gap-3 p-4 hover:bg-blue-600 hover:text-white rounded-2xl transition-all duration-300">
            <span>📦</span> Products
        </a>
        <a href="#stockin" class="flex items-center gap-3 p-4 hover:bg-blue-600 hover:text-white rounded-2xl transition-all duration-300">
            <span>📥</span> Stock In
        </a>
        <a href="#stockout" class="flex items-center gap-3 p-4 hover:bg-blue-600 hover:text-white rounded-2xl transition-all duration-300">
            <span>📤</span> Stock Out
        </a>
        <a href="#settings" class="flex items-center gap-3 p-4 hover:bg-blue-600 hover:text-white rounded-2xl transition-all duration-300 border-t border-gray-700 mt-4">
            <span>⚙️</span> Settings
        </a>
    </nav>
</div>