<?php
$host = "localhost";
$user = "YOUR_DATABASE_USERNAME";
$pass = "YOUR_DATABASE_PASSWORD";
$dbname = "inventory_db";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Database connection failed.");
}
?>