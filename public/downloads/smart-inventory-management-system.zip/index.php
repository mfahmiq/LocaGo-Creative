<?php include __DIR__ . '/includes/header.php'; ?>
<?php include __DIR__ . '/includes/nav.php'; ?>

<section id="home"> <?php include __DIR__ . '/pages/home.php'; ?> </section>
<section id="about"> <?php include __DIR__ . '/pages/about.php'; ?> </section>
<section id="features"> <?php include __DIR__ . '/pages/feature.php'; ?> </section>
 <section id="service"> <?php include __DIR__ . '/pages/service.php'; ?> </section>
 <section id="pricing"> <?php include __DIR__ . '/pages/pricing.php'; ?> </section>
<section id="contact"> <?php include __DIR__ . '/pages/contact.php'; ?> </section>


