<?php
$allowedRoles = [2];
require '../middleware/auth_chek.php';
require '../config/config.php';

$stmt = $pdo->query("
    SELECT
        laporan.report_id,
        laporan.judul,
        laporan.lokasi,
        laporan.tanggal_lapor,
        users.username
    FROM laporan
    JOIN users ON laporan.user_id = users.id
    WHERE laporan.status = 2
    ORDER BY laporan.tanggal_lapor ASC
");
$laporan = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head><title>Laporan Pending</title></head>
<body>

<h3>Laporan Pending</h3>

<table border="1" cellpadding="10">
<tr>
    <th>No</th>
    <th>Pelapor</th>
    <th>Judul</th>
    <th>Lokasi</th>
    <th>Aksi</th>
</tr>

<?php $no=1; foreach($laporan as $l): ?>
<tr>
    <td><?= $no++ ?></td>
    <td><?= htmlspecialchars($l['username']) ?></td>
    <td><?= htmlspecialchars($l['judul']) ?></td>
    <td><?= htmlspecialchars($l['lokasi']) ?></td>
    <td>
        <a href="ambil-laporan.php?id=<?= $l['report_id'] ?>"
           onclick="return confirm('Ambil laporan ini?')">
           Ambil
        </a>
    </td>
</tr>
<?php endforeach; ?>
</table>

</body>
</html>
