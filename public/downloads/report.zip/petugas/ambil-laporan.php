<?php
$allowedRoles = [2];
require '../middleware/auth_chek.php';
require '../config/config.php';

$report_id = intval($_GET['id']);
$technician_id = $_SESSION['user']['id'];

$stmt = $pdo->prepare("
    UPDATE laporan 
    SET status = 3, assigned_to = ?
    WHERE report_id = ? AND status = 2
");
$stmt->execute([$technician_id, $report_id]);

// tracking otomatis via trigger
header("Location: laporan-proses.php");
exit;
