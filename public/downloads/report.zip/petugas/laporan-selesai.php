<?php
$allowedRoles = [2];
require '../middleware/auth_chek.php';
require '../config/config.php';

$technician_id = $_SESSION['user']['id'];

$stmt = $pdo->prepare("
    SELECT report_id, judul, lokasi, tanggal_lapor
    FROM laporan
    WHERE status = 4 AND assigned_to = ?
    ORDER BY tanggal_lapor DESC
");
$stmt->execute([$technician_id]);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head><title>Riwayat Pekerjaan</title></head>
<body>

<h3>Riwayat Laporan Selesai</h3>

<table border="1" cellpadding="10">
<tr>
    <th>No</th>
    <th>Judul</th>
    <th>Lokasi</th>
    <th>Tanggal</th>
</tr>

<?php $no=1; foreach($data as $d): ?>
<tr>
    <td><?= $no++ ?></td>
    <td><?= htmlspecialchars($d['judul']) ?></td>
    <td><?= htmlspecialchars($d['lokasi']) ?></td>
    <td><?= $d['tanggal_lapor'] ?></td>
</tr>
<?php endforeach; ?>

</table>
</body>
</html>
