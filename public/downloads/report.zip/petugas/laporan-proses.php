<?php
$allowedRoles = [2];
require '../middleware/auth_chek.php';
require '../config/config.php';

$technician_id = $_SESSION['user']['id'];

$stmt = $pdo->prepare("
    SELECT
        report_id,
        judul,
        lokasi
    FROM laporan
    WHERE status = 3 AND assigned_to = ?
");
$stmt->execute([$technician_id]);
$laporan = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head><title>Laporan Diproses</title></head>
<body>

<h3>Laporan Dalam Proses</h3>

<table border="1" cellpadding="10">
<tr>
    <th>No</th>
    <th>Judul</th>
    <th>Lokasi</th>
    <th>Aksi</th>
</tr>

<?php $no=1; foreach($laporan as $l): ?>
<tr>
    <td><?= $no++ ?></td>
    <td><?= htmlspecialchars($l['judul']) ?></td>
    <td><?= htmlspecialchars($l['lokasi']) ?></td>
    <td>
        <a href="laporan-selesai.php?id=<?= $l['report_id'] ?>"
           onclick="return confirm('Selesaikan laporan?')">
           Selesai
        </a>
    </td>
</tr>
<?php endforeach; ?>
</table>

</body>
</html>
