<?php
// =======================================
// TAMBAH LAPORAN
// ROLE: USER (3)
// =======================================

$allowedRoles = [3];
require '../middleware/auth_chek.php';
require '../config/config.php';

$user_id = $_SESSION['user']['id'];
$error = '';

// ===============================
// PROSES SIMPAN LAPORAN
// ===============================
if (isset($_POST['submit'])) {

    $judul     = trim($_POST['judul']);
    $deskripsi = trim($_POST['deskripsi']);
    $lokasi    = trim($_POST['lokasi']);

    if ($judul === '' || $deskripsi === '' || $lokasi === '') {
        $error = "Semua field wajib diisi.";
    } else {

        // ===============================
        // UPLOAD FOTO (OPSIONAL)
        // ===============================
        $fotoName = null;

        if (!empty($_FILES['foto']['name'])) {

            $allowedExt = ['jpg','jpeg','png'];
            $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));

            if (!in_array($ext, $allowedExt)) {
                $error = "Format foto harus JPG / PNG.";
            } else {
                $fotoName = uniqid('laporan_') . '.' . $ext;
                $uploadPath = "../assets/img/" . $fotoName;

                if (!move_uploaded_file($_FILES['foto']['tmp_name'], $uploadPath)) {
                    $error = "Gagal upload foto.";
                }
            }
        }

        // ===============================
        // SIMPAN KE DATABASE
        // ===============================
        if ($error === '') {

$stmt = $pdo->prepare("
    INSERT INTO laporan 
    (user_id, judul, deskripsi, lokasi, status, assigned_to, tanggal_lapor)
    VALUES (?, ?, ?, ?, 1, NULL, NOW())
");

$stmt->execute([
    $user_id,
    $judul,
    $deskripsi,
    $lokasi
]);

        }   
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Buat Laporan</title>

<style>
body {
    font-family: Arial, sans-serif;
    background:#eef3f9;
    margin:0;
}

.header {
    background:#3b82f6;
    color:white;
    padding:15px 25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.container {
    margin:30px auto;
    background:white;
    padding:25px;
    border-radius:10px;
    max-width:600px;
}

label {
    display:block;
    margin-top:15px;
    font-weight:bold;
}

input, textarea {
    width:100%;
    padding:10px;
    margin-top:6px;
    border-radius:6px;
    border:1px solid #ccc;
}

textarea {
    resize:vertical;
}

.btn {
    margin-top:20px;
    padding:10px 16px;
    background:#3b82f6;
    color:white;
    border:none;
    border-radius:6px;
    cursor:pointer;
}

.btn-back {
    background:#64748b;
    margin-left:10px;
    text-decoration:none;
    color:white;
    padding:10px 16px;
    border-radius:6px;
}

.alert-error {
    background:#fee2e2;
    color:#991b1b;
    padding:10px;
    border-radius:6px;
    margin-bottom:15px;
}
</style>
</head>

<body>

<div class="header">
    <h3>Buat Laporan</h3>
    <a href="/LSP_FINAL/dashboard/user.php" style="color:white;text-decoration:none;">
        Kembali
    </a>
</div>

<div class="container">

    <?php if ($error): ?>
        <div class="alert-error"><?= $error ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">

        <label>Judul Laporan</label>
        <input type="text" name="judul" required>

        <label>Deskripsi</label>
        <textarea name="deskripsi" rows="4" required></textarea>

        <label>Lokasi</label>
        <input type="text" name="lokasi" required>

        <label>Foto (opsional)</label>
        <input type="file" name="foto" accept=".jpg,.jpeg,.png">

        <button type="submit" name="submit" class="btn">
            Simpan Laporan
        </button>

        <a href="/LSP_FINAL/dashboard/user.php" class="btn-back">
            Batal
        </a>

    </form>

</div>

</body>
</html>
