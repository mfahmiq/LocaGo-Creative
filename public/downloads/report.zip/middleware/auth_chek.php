<?php
// ======================================
// FILE : middleware/auth_chek.php
// FUNGSI : Middleware autentikasi & role
// DIPAKAI ADMIN, PETUGAS, DAN USER
// ======================================

session_start();

// ===============================
// CEK SUDAH LOGIN ATAU BELUM
// ===============================
if (
    !isset($_SESSION['user']) ||
    !isset($_SESSION['user']['login']) ||
    $_SESSION['user']['login'] !== true
) {
    header("Location: ../auth/login.php");
    exit;
}

// ===============================
// CEK ROLE (JIKA DIBATASI)
// ===============================
// $allowedRoles HARUS array
// Contoh:
// $allowedRoles = [1];       // admin
// $allowedRoles = [2];       // petugas
// $allowedRoles = [3];       // user
// $allowedRoles = [1,2];     // admin & petugas
// ===============================
if (isset($allowedRoles) && is_array($allowedRoles)) {

    if (!in_array($_SESSION['user']['role'], $allowedRoles)) {
        header("Location: ../auth/login.php");
        exit;
    }
}
