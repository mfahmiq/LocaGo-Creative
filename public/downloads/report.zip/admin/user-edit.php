<?php
$allowedRoles = [1];
require '../middleware/auth_chek.php';
require '../config/config.php';

if(!isset($_GET['id'])){ header("Location: user.php"); exit; }
$id = intval($_GET['id']);

// Ambil data user
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$user){ header("Location: user.php"); exit; }

$message = "";

if(isset($_POST['submit'])){
    $username = trim($_POST['username']);
    $role = intval($_POST['role']);
    $status = intval($_POST['status']);

    // Update password hanya jika diisi
    if(!empty($_POST['password'])){
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET username=?, password=?, role=?, status=? WHERE id=?");
        $stmt->execute([$username, $password, $role, $status, $id]);
    } else {
        $stmt = $pdo->prepare("UPDATE users SET username=?, role=?, status=? WHERE id=?");
        $stmt->execute([$username, $role, $status, $id]);
    }

    $message = "User berhasil diupdate.";
    header("Location: user.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit User</title>
<style>
body { font-family: Arial; background:#eef3f9; margin:0; }
.header { background:#3b82f6; color:white; padding:15px 25px; display:flex; justify-content:space-between; align-items:center;}
.header a { color:white; text-decoration:none; font-weight:bold; }
.container { margin:30px; background:white; padding:20px; border-radius:10px; width:400px; }
input, select { width:100%; padding:8px; margin:6px 0 12px; border:1px solid #ccc; border-radius:5px; }
.btn { padding:6px 12px; background:#3b82f6; color:white; border:none; border-radius:6px; cursor:pointer; }
</style>
</head>
<body>

<div class="header">
    <h3>Edit User</h3>
    <a href="user.php">Kembali</a>
</div>

<div class="container">
    <?php if($message) echo "<p>$message</p>"; ?>
    <form method="post">
        <label>Username</label>
        <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>

        <label>Password (kosongkan jika tidak diubah)</label>
        <input type="password" name="password">

        <label>Role</label>
        <select name="role" required>
            <option value="1" <?= $user['role']==1?'selected':'' ?>>Admin</option>
            <option value="2" <?= $user['role']==2?'selected':'' ?>>Petugas</option>
            <option value="3" <?= $user['role']==3?'selected':'' ?>>User</option>
        </select>

        <label>Status</label>
        <select name="status" required>
            <option value="1" <?= $user['status']==1?'selected':'' ?>>Aktif</option>
            <option value="0" <?= $user['status']==0?'selected':'' ?>>Nonaktif</option>
        </select>

        <button type="submit" name="submit" class="btn">Update</button>
    </form>
</div>

</body>
</html>
