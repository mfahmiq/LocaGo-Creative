<?php
// =======================================
// HALAMAN TAMBAH USER
// AKSES: HANYA ADMIN (ROLE = 1)
// =======================================

// Menentukan role yang diperbolehkan mengakses halaman ini
$allowedRoles = [1];

// Middleware untuk pengecekan login & hak akses user
require '../middleware/auth_chek.php';

// Koneksi database menggunakan PDO
require '../config/config.php';

// Variabel untuk menampung pesan notifikasi
$message = "";

// =======================================
// PROSES SIMPAN DATA USER
// =======================================

// Mengecek apakah form sudah disubmit
if(isset($_POST['submit'])){

    // Mengambil input username dan menghapus spasi di awal & akhir
    $username = trim($_POST['username']);

    // Mengenkripsi password menggunakan password_hash
    // PASSWORD_DEFAULT aman dan direkomendasikan
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Mengambil role dan mengubah ke tipe integer
    $role = intval($_POST['role']);

    // Mengambil status user (aktif / nonaktif)
    $status = intval($_POST['status']);

    // Menyimpan waktu pembuatan user
    $created_at = date('Y-m-d H:i:s');

    // Query INSERT menggunakan prepared statement (aman dari SQL Injection)
    $stmt = $pdo->prepare("
        INSERT INTO users 
        (username, password, role, status, created_at) 
        VALUES (?,?,?,?,?)
    ");

    // Menjalankan query dengan parameter
    $stmt->execute([$username, $password, $role, $status, $created_at]);

    // Pesan berhasil
    $message = "User berhasil ditambahkan.";

    // Redirect ke halaman data user setelah berhasil
    header("Location: user.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah User</title>

<!-- =======================================
     CSS SEDERHANA (NATIVE)
     Digunakan agar tampilan rapi dan jelas
======================================= -->
<style>
body {
    font-family: Arial;
    background:#eef3f9;
    margin:0;
}

.header {
    background:#3b82f6;
    color:white;
    padding:15px 25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.header a {
    color:white;
    text-decoration:none;
    font-weight:bold;
}

.container {
    margin:30px;
    background:white;
    padding:20px;
    border-radius:10px;
    width:400px;
}

input, select {
    width:100%;
    padding:8px;
    margin:6px 0 12px;
    border:1px solid #ccc;
    border-radius:5px;
}

.btn {
    padding:6px 12px;
    background:#3b82f6;
    color:white;
    border:none;
    border-radius:6px;
    cursor:pointer;
}
</style>
</head>

<body>

<!-- =======================================
     HEADER HALAMAN
======================================= -->
<div class="header">
    <h3>Tambah User</h3>
    <a href="user.php">Kembali</a>
</div>

<!-- =======================================
     FORM INPUT DATA USER
======================================= -->
<div class="container">

    <!-- Menampilkan pesan jika ada -->
    <?php if($message) echo "<p>$message</p>"; ?>

    <!-- Form menggunakan metode POST -->
    <form method="post">

        <!-- Input Username -->
        <label>Username</label>
        <input type="text" name="username" required>

        <!-- Input Password -->
        <label>Password</label>
        <input type="password" name="password" required>

        <!-- Pilihan Role User -->
        <label>Role</label>
        <select name="role" required>
            <option value="1">Admin</option>
            <option value="2">Petugas</option>
            <option value="3">User</option>
        </select>

        <!-- Status User -->
        <label>Status</label>
        <select name="status" required>
            <option value="1">Aktif</option>
            <option value="0">Nonaktif</option>
        </select>

        <!-- Tombol Submit -->
        <button type="submit" name="submit" class="btn">Simpan</button>

    </form>
</div>

</body>
</html>
