<?php
// =======================================
// LOG TRACKING PROGRESS LAPORAN
// ROLE: ADMIN
// =======================================

$allowedRoles = [1];
require '../middleware/auth_chek.php';
require '../config/config.php';

// ambil report_id dari URL
$report_id = isset($_GET['report_id']) ? intval($_GET['report_id']) : 0;

// function status text
function statusText($status) {
    switch ($status) {
        case 1: return 'Open';
        case 2: return 'Pending';
        case 3: return 'Process';
        case 4: return 'Done';
        case 5: return 'Reject';
        default: return 'Unknown';
    }
}

// =======================================
// EXPORT CSV
// =======================================
if (isset($_GET['export']) && $_GET['export'] == 'csv') {
    header("Content-Type: text/csv");
    header("Content-Disposition: attachment; filename=tracking_laporan_$report_id.csv");

    $output = fopen("php://output", "w");

    // header CSV
    fputcsv($output, [
        'No',
        'Status Awal',
        'Status Akhir',
        'Teknisi',
        'Catatan',
        'Waktu'
    ]);

    $stmt = $pdo->prepare("
        SELECT
            tp.status_awal,
            tp.status_akhir,
            tp.catatan,
            tp.created_at,
            u.username AS teknisi
        FROM tracking_progress tp
        LEFT JOIN users u ON tp.technician_id = u.id
        WHERE tp.report_id = ?
        ORDER BY tp.created_at ASC
    ");
    $stmt->execute([$report_id]);

    $no = 1;
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, [
            $no++,
            statusText($row['status_awal']),
            statusText($row['status_akhir']),
            $row['teknisi'] ?? '-',
            $row['catatan'],
            $row['created_at']
        ]);
    }

    fclose($output);
    exit;
}

// =======================================
// QUERY DATA TRACKING (TAMPIL HTML)
// =======================================
$stmt = $pdo->prepare("
    SELECT
        tp.status_awal,
        tp.status_akhir,
        tp.catatan,
        tp.created_at,
        u.username AS teknisi
    FROM tracking_progress tp
    LEFT JOIN users u ON tp.technician_id = u.id
    WHERE tp.report_id = ?
    ORDER BY tp.created_at ASC
");
$stmt->execute([$report_id]);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Log Tracking Laporan</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #eef3f9;
    margin: 0;
}
.header {
    background: #3b82f6;
    color: white;
    padding: 15px 25px;
    display: flex;
    justify-content: space-between;
}
.container {
    margin: 30px;
    background: white;
    padding: 20px;
    border-radius: 10px;
}
table {
    width: 100%;
    border-collapse: collapse;
}
th, td {
    padding: 12px;
    border: 1px solid #ddd;
}
th {
    background: #f1f5f9;
}
.btn {
    padding: 6px 12px;
    background: #16a34a;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-size: 14px;
}
</style>
</head>

<body>

<div class="header">
    <h3>Log Tracking Laporan (ID: <?= $report_id ?>)</h3>
    <a href="../dashboard/admin.php" style="color:white;">Kembali</a>
</div>

<div class="container">

<!-- TOMBOL EXPORT -->
<a href="laporan-log.php?report_id=<?= $report_id ?>&export=csv" class="btn">
    Export CSV
</a>

<br><br>

<table>
    <tr>
        <th>No</th>
        <th>Status Awal</th>
        <th>Status Akhir</th>
        <th>Teknisi</th>
        <th>Catatan</th>
        <th>Waktu</th>
    </tr>

    <?php if (count($logs) == 0): ?>
    <tr>
        <td colspan="6" style="text-align:center;">Belum ada log</td>
    </tr>
    <?php endif; ?>

    <?php $no = 1; foreach ($logs as $log): ?>
    <tr>
        <td><?= $no++ ?></td>
        <td><?= statusText($log['status_awal']) ?></td>
        <td><?= statusText($log['status_akhir']) ?></td>
        <td><?= $log['teknisi'] ?? '-' ?></td>
        <td><?= htmlspecialchars($log['catatan']) ?></td>
        <td><?= $log['created_at'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>
</div>

</body>
</html>
