<?php
// ===============================
// HALAMAN VALIDASI LAPORAN
// ROLE: ADMIN
// ===============================

$allowedRoles = [1];
require '../middleware/auth_chek.php';
require '../config/config.php';

// ===============================
// PROSES UPDATE STATUS LAPORAN
// ===============================
if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = intval($_GET['id']);
    $status = intval($_GET['status']);

    $stmt = $pdo->prepare("UPDATE laporan SET status = ? WHERE report_id = ?");
$stmt->execute([$status, $id]);


    header("Location: validasi.php");
    exit;
}

// ===============================
// AMBIL DATA LAPORAN
// ===============================
$stmt = $pdo->query("
    SELECT
        laporan.report_id,
        laporan.judul,
        laporan.lokasi,
        laporan.status,
        laporan.tanggal_lapor,
        users.username
    FROM laporan
    JOIN users ON laporan.user_id = users.id
    ORDER BY laporan.tanggal_lapor DESC
");



$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Validasi Laporan</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #eef3f9;
    margin: 0;
}

.header {
    background: #3b82f6;
    color: white;
    padding: 15px 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header a {
    color: white;
    text-decoration: none;
    font-weight: bold;
}

.container {
    margin: 30px;
    background: white;
    padding: 20px;
    border-radius: 10px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 12px;
    border: 1px solid #ddd;
}

th {
    background: #f1f5f9;
}

tr:hover {
    background: #f9fafb;
}

.badge {
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 13px;
    color: white;
}

.badge-open { background: #2563eb; }
.badge-process { background: #f59e0b; }
.badge-done { background: #16a34a; }
.badge-reject { background: #dc2626; }

.btn {
    padding: 6px 12px;
    background: #3b82f6;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-size: 14px;
}

.btn-warning { background: #f59e0b; }
.btn-success { background: #16a34a; }
.btn-danger { background: #dc2626; }
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <h3>Validasi Laporan</h3>
    <a href="../dashboard/admin.php">Kembali</a>
</div>

<!-- KONTEN -->
<div class="container">
    <p>Halaman ini digunakan untuk melakukan validasi laporan user.</p>

    <table>
        <tr>
            <th>ID</th>
            <th>Pelapor</th>
            <th>Judul</th>
            <th>Lokasi</th>
            <th>Status</th>
            <th>Tanggal Lapor</th>
            <th>Aksi</th>
        </tr>

        <?php foreach ($reports as $report): ?>
        <tr>
            <td><?= $report['report_id'] ?></td>
            <td><?= htmlspecialchars($report['username']) ?></td>
            <td><?= htmlspecialchars($report['judul']) ?></td>
            <td><?= htmlspecialchars($report['lokasi']) ?></td>
            <td>
                <?php
                switch ($report['status']) {
                    case 1: echo '<span class="badge badge-open">Open</span>'; break;
                    case 2: echo '<span class="badge badge-process">Process</span>'; break;
                    case 3: echo '<span class="badge badge-done">Done</span>'; break;
                    case 4: echo '<span class="badge badge-reject">Reject</span>'; break;
                }
                ?>
            </td>
            <td><?= $report['tanggal_lapor'] ?></td>
            <td>
                <?php if ($report['status'] == 1): ?>
                    <a href="validasi.php?id=<?= $report['report_id'] ?>&status=2"
                       class="btn btn-warning"
                       onclick="return confirm('Proses laporan ini?')">
                       Proses
                    </a>
                <?php elseif ($report['status'] == 2): ?>
                    <a href="validasi.php?id=<?= $report['report_id'] ?>&status=3"
                       class="btn btn-success"
                       onclick="return confirm('Selesaikan laporan ini?')">
                       Selesai
                    </a>
                <?php endif; ?>

                <a href="validasi.php?id=<?= $report['report_id'] ?>&status=4"
                   class="btn btn-danger"
                   onclick="return confirm('Tolak laporan ini?')">
                   Tolak
                </a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

</body>
</html>
