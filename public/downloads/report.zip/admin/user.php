<?php
// ===============================
// KELOLA USER + EXPORT
// ROLE: ADMIN
// ===============================

$allowedRoles = [1];
require '../middleware/auth_chek.php';
require '../config/config.php';

// ===============================
// EXPORT TXT
// ===============================
if (isset($_GET['export']) && $_GET['export'] == 'txt') {
    header("Content-Type: text/plain");
    header("Content-Disposition: attachment; filename=data_user.txt");

    $stmt = $pdo->query("SELECT id, username, role, status FROM users ORDER BY id ASC");

    echo "DATA USER\n";
    echo "=============================\n";

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "ID        : {$row['id']}\n";
        echo "Username  : {$row['username']}\n";
        echo "Role      : " . (
            $row['role'] == 1 ? 'Admin' :
            ($row['role'] == 2 ? 'Petugas' : 'User')
        ) . "\n";
        echo "Status    : " . ($row['status'] == 1 ? 'Aktif' : 'Nonaktif') . "\n";
        echo "-----------------------------\n";
    }
    exit;
}

// ===============================
// EXPORT CSV (EXCEL)
// ===============================
if (isset($_GET['export']) && $_GET['export'] == 'csv') {
    header("Content-Type: text/csv");
    header("Content-Disposition: attachment; filename=data_user.csv");

    $output = fopen("php://output", "w");
    fputcsv($output, ['ID', 'Username', 'Role', 'Status']);

    $stmt = $pdo->query("SELECT id, username, role, status FROM users ORDER BY id ASC");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, [
            $row['id'],
            $row['username'],
            $row['role'] == 1 ? 'Admin' : ($row['role'] == 2 ? 'Petugas' : 'User'),
            $row['status'] == 1 ? 'Aktif' : 'Nonaktif'
        ]);
    }
    fclose($output);
    exit;
}

// ===============================
// HAPUS USER
// ===============================
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);

    // Admin tidak boleh hapus dirinya sendiri
    if ($id != $_SESSION['user']['id']) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
    }

    header("Location: user.php");
    exit;
}

// ===============================
// AMBIL DATA USER
// ===============================
$stmt = $pdo->query("SELECT id, username, role, status FROM users ORDER BY id ASC");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Kelola User</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #eef3f9;
    margin: 0;
}

.header {
    background: #3b82f6;
    color: white;
    padding: 15px 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header a {
    color: white;
    text-decoration: none;
    font-weight: bold;
}

.container {
    margin: 30px;
    background: white;
    padding: 20px;
    border-radius: 10px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 12px;
    border: 1px solid #ddd;
}

th {
    background: #f1f5f9;
}

tr:hover {
    background: #f9fafb;
}

.btn {
    padding: 6px 12px;
    background: #3b82f6;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-size: 14px;
}

.btn-danger {
    background: #ef4444;
}

.btn-export {
    background: #16a34a;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <h3>Kelola User</h3>
    <a href="../dashboard/admin.php">Kembali</a>
</div>

<!-- KONTEN -->
<div class="container">

    <!-- TOMBOL -->
    <a href="user-add.php" class="btn">Tambah User</a>
    <a href="user.php?export=txt" class="btn btn-export">Export TXT</a>
    <a href="user.php?export=csv" class="btn btn-export">Export CSV</a>

    <br><br>

    <!-- TABEL -->
    <table>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Role</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>

        <?php foreach ($users as $user): ?>
        <tr>
            <td><?= htmlspecialchars($user['id']) ?></td>
            <td><?= htmlspecialchars($user['username']) ?></td>
            <td><?= $user['role']==1?'Admin':($user['role']==2?'Petugas':'User') ?></td>
            <td><?= $user['status']==1?'Aktif':'Nonaktif' ?></td>
            <td>
                <a href="user-edit.php?id=<?= $user['id'] ?>" class="btn">Edit</a>

                <?php if ($user['id'] != $_SESSION['user']['id']): ?>
                <a href="user.php?delete_id=<?= $user['id'] ?>"
                   class="btn btn-danger"
                   onclick="return confirm('Yakin ingin hapus user ini?')">
                   Hapus
                </a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

</div>

</body>
</html>
