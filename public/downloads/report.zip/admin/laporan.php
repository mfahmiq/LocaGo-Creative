<?php
// =======================================================
// LAPORAN DATA LAPORAN
// ROLE: ADMIN
// =======================================================

$allowedRoles = [1];
require '../middleware/auth_chek.php';
require '../config/config.php';

// =======================================================
// EXPORT CSV
// =======================================================
if (isset($_GET['export']) && $_GET['export'] == 'csv') {
    header("Content-Type: text/csv");
    header("Content-Disposition: attachment; filename=laporan_data_laporan.csv");

    $output = fopen("php://output", "w");
    fputcsv($output, [
        'ID Laporan','Pelapor','Judul','Lokasi','Status','Tanggal Lapor'
    ]);

    $stmt = $pdo->query("
        SELECT laporan.*, users.username
        FROM laporan
        JOIN users ON laporan.user_id = users.id
        ORDER BY laporan.tanggal_lapor DESC
    ");

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, [
            $row['report_id'],
            $row['username'],
            $row['judul'],
            $row['lokasi'],
            statusText($row['status']),
            $row['tanggal_lapor']
        ]);
    }
    fclose($output);
    exit;
}


// =======================================================
// STATISTIK LAPORAN
// =======================================================
$totalLaporan   = $pdo->query("SELECT COUNT(*) FROM laporan")->fetchColumn();
$openCount      = $pdo->query("SELECT COUNT(*) FROM laporan WHERE status=1")->fetchColumn();
$pendingCount   = $pdo->query("SELECT COUNT(*) FROM laporan WHERE status=2")->fetchColumn();
$processCount   = $pdo->query("SELECT COUNT(*) FROM laporan WHERE status=3")->fetchColumn();
$doneCount      = $pdo->query("SELECT COUNT(*) FROM laporan WHERE status=4")->fetchColumn();
$rejectCount    = $pdo->query("SELECT COUNT(*) FROM laporan WHERE status=5")->fetchColumn();


// =======================================================
// DATA TABEL LAPORAN
// =======================================================
$stmt = $pdo->query("
    SELECT laporan.*, users.username
    FROM laporan
    JOIN users ON laporan.user_id = users.id
    ORDER BY laporan.tanggal_lapor DESC
");
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);


// =======================================================
// FUNCTION STATUS
// =======================================================
function statusText($status) {
    switch ($status) {
        case 1: return 'Open';
        case 2: return 'Pending';
        case 3: return 'Process';
        case 4: return 'Done';
        case 5: return 'Reject';
        default: return 'Unknown';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Laporan Data Laporan</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #eef3f9;
    margin: 0;
}
.header {
    background: #3b82f6;
    color: white;
    padding: 15px 25px;
    display: flex;
    justify-content: space-between;
}
.container {
    margin: 30px;
}
.cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 15px;
    margin-bottom: 25px;
}
.card {
    background: white;
    padding: 15px;
    border-radius: 10px;
    text-align: center;
}
.card h2 { color: #3b82f6; }
.table-box {
    background: white;
    padding: 20px;
    border-radius: 10px;
}
table {
    width: 100%;
    border-collapse: collapse;
}
th, td {
    padding: 12px;
    border: 1px solid #ddd;
}
th { background: #f1f5f9; }
.btn {
    padding: 6px 12px;
    background: #16a34a;
    color: white;
    text-decoration: none;
    border-radius: 6px;
}
</style>
</head>

<body>

<div class="header">
    <h3>Laporan Data Laporan</h3>
    <a href="../dashboard/admin.php" style="color:white;">Kembali</a>
</div>

<div class="container">

    <!-- STATISTIK -->
    <div class="cards">
        <div class="card"><p>Total</p><h2><?= $totalLaporan ?></h2></div>
        <div class="card"><p>Open</p><h2><?= $openCount ?></h2></div>
        <div class="card"><p>Pending</p><h2><?= $pendingCount ?></h2></div>
        <div class="card"><p>Process</p><h2><?= $processCount ?></h2></div>
        <div class="card"><p>Done</p><h2><?= $doneCount ?></h2></div>
        <div class="card"><p>Reject</p><h2><?= $rejectCount ?></h2></div>
    </div>

    <a href="laporan.php?export=csv" class="btn">Export CSV</a>

    <br><br>

    <!-- TABEL -->
    <div class="table-box">
        <table>
            <tr>
                <th>ID</th>
                <th>Pelapor</th>
                <th>Judul</th>
                <th>Lokasi</th>
                <th>Status</th>
                <th>Tanggal</th>
            </tr>
            <?php foreach ($reports as $r): ?>
            <tr>
                <td><?= $r['report_id'] ?></td>
                <td><?= htmlspecialchars($r['username']) ?></td>
                <td><?= htmlspecialchars($r['judul']) ?></td>
                <td><?= htmlspecialchars($r['lokasi']) ?></td>
                <td><?= statusText($r['status']) ?></td>
                <td><?= $r['tanggal_lapor'] ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>

</div>
</body>
</html>
