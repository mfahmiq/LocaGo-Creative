-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 09, 2026 at 04:40 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_report`
--

-- --------------------------------------------------------

--
-- Table structure for table `laporan`
--

CREATE TABLE `laporan` (
  `report_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `judul` varchar(150) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `lokasi` varchar(100) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=open, 2=process, 3=done, 4=reject',
  `assigned_to` int(11) DEFAULT NULL,
  `tanggal_lapor` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `laporan`
--

INSERT INTO `laporan` (`report_id`, `user_id`, `judul`, `deskripsi`, `lokasi`, `status`, `assigned_to`, `tanggal_lapor`) VALUES
(1, 3, 'Laptop Layar Bergaris', 'Muncul garis hijau horizontal di tengah layar', 'Ruang ORACLE 1', 4, NULL, '2025-12-17 14:00:00'),
(2, 3, 'Kaca Pecah', 'Karena kena bola', 'LABPK', 1, NULL, '2025-12-17 16:59:20'),
(3, 3, 'Kaca Pecah', 'ketendang', 'RUANGAN 2', 1, NULL, '2025-12-17 16:59:42'),
(4, 3, 'WC mampet', 'banjir', 'di wc siswi', 3, 2, '2025-12-17 17:02:50');

--
-- Triggers `laporan`
--
DELIMITER $$
CREATE TRIGGER `after_update_laporan_status` AFTER UPDATE ON `laporan` FOR EACH ROW BEGIN
    -- hanya log jika status berubah
    IF OLD.status <> NEW.status THEN
        INSERT INTO tracking_progress (
            report_id,
            technician_id,
            status_awal,
            status_akhir,
            catatan,
            created_at
        ) VALUES (
            OLD.report_id,
            NEW.assigned_to,
            OLD.status,
            NEW.status,
            CONCAT(
                'Status berubah dari ',
                OLD.status,
                ' ke ',
                NEW.status
            ),
            NOW()
        );
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tracking_progress`
--

CREATE TABLE `tracking_progress` (
  `tracking_id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL,
  `technician_id` int(11) DEFAULT NULL,
  `status_awal` tinyint(4) NOT NULL,
  `status_akhir` tinyint(4) NOT NULL,
  `catatan` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tracking_progress`
--

INSERT INTO `tracking_progress` (`tracking_id`, `report_id`, `technician_id`, `status_awal`, `status_akhir`, `catatan`, `created_at`) VALUES
(4, 4, NULL, 1, 2, 'Status berubah dari 1 ke 2', '2025-12-17 17:03:32'),
(5, 4, 2, 2, 3, 'Status berubah dari 2 ke 3', '2025-12-17 17:04:35');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` tinyint(1) NOT NULL COMMENT '1=Admin, 2=Petugas, 3=User',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=Aktif, 0=Nonaktif'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `status`) VALUES
(1, 'admin', '$2y$10$7KyetRJp50MBq8in/yNg5eAtIVd/PBV2I/dTgBu1MyLAKzMJxwhxC', 1, 1),
(2, 'teknisi', '$2y$10$acIHnW3nBbcADRq/MN0wguSPqfBVPY0oDT90H/bRjxFm1IEJEL69q', 2, 1),
(3, 'user', '$2y$10$09gU7xMovRl..IMzmeud/.ibVbHcTiGFb7FjjAYS3kXS3cxhodf3a', 3, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `laporan`
--
ALTER TABLE `laporan`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `tracking_progress`
--
ALTER TABLE `tracking_progress`
  ADD PRIMARY KEY (`tracking_id`),
  ADD KEY `fk_tracking_report` (`report_id`),
  ADD KEY `fk_tracking_technician` (`technician_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `laporan`
--
ALTER TABLE `laporan`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tracking_progress`
--
ALTER TABLE `tracking_progress`
  MODIFY `tracking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tracking_progress`
--
ALTER TABLE `tracking_progress`
  ADD CONSTRAINT `fk_tracking_report` FOREIGN KEY (`report_id`) REFERENCES `laporan` (`report_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_tracking_technician` FOREIGN KEY (`technician_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
