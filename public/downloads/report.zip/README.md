# report
# School Facility Report  Proyek web *PHP Native* &amp; *CSS Sederhana* untuk skema Assistant Web Development (LSP KOMPETEN). Aplikasi mendigitalisasi pelaporan kerusakan fasilitas sekolah oleh siswa. ### 🛠️ Tech Stack * **Backend:** PHP Native * **Database:** MySQL * **Frontend:** HTML5 &amp; CSS3 Custom * **Security:** Bcrypt Hash (`password_hash`) *
