<?php
// ======================================
// FILE : auth/login.php
// ======================================
session_start();

// Jika sudah login, arahkan ke dashboard sesuai role
// ARRAY 2 DIMENSI
if (isset($_SESSION['user']['login']) && $_SESSION['user']['login'] === true) {

    if ($_SESSION['user']['role'] == 1) {
        header("Location: ../dashboard/admin.php");
    } elseif ($_SESSION['user']['role'] == 2) {
        header("Location: ../dashboard/petugas.php");
    } else {
        header("Location: ../dashboard/user.php");
    }
    exit;
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Login | REPORT</title>

<style>
/* ===============================
   RESET
   =============================== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, Helvetica, sans-serif;
}

/* ===============================
   BACKGROUND
   =============================== */
body {
    background-color: #eef3f9;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

/* ===============================
   LOGIN CONTAINER
   =============================== */
.login-wrapper {
    width: 420px;
    text-align: center;
}

/* ===============================
   LOGO + TITLE (SEJAJAR)
   =============================== */
.logo {
    display: flex;              /* bikin sejajar */
    align-items: center;        /* rata tengah vertikal */
    justify-content: center;    /* rata tengah horizontal */
    gap: 10px;                  /* jarak logo & teks */
    margin-bottom: 30px;
}

.logo img {
    width: 62px;                /* ukuran icon note */
}

.logo h1 {
    color: #3b82f6;
    font-size: 32px;
    font-weight: bold;
}

/* ===============================
   FORM
   =============================== */
.form-group {
    text-align: left;
    margin-bottom: 18px;
}

.form-group label {
    color: #3b82f6;
    font-size: 14px;
    margin-bottom: 6px;
    display: block;
}

.form-group input {
    width: 100%;
    padding: 12px;
    border-radius: 10px;
    border: 2px solid #3b82f6;
    font-size: 14px;
    outline: none;
}

/* ===============================
   BUTTON
   =============================== */
button {
    margin-top: 10px;
    background-color: #3b82f6;
    color: white;
    border: none;
    padding: 12px 40px;
    border-radius: 10px;
    font-size: 14px;
    font-weight: bold;
    cursor: pointer;
}

/* ===============================
   ERROR MESSAGE
   =============================== */
.alert-error {
    background-color: #fee2e2;
    color: #991b1b;
    padding: 10px;
    border-radius: 8px;
    font-size: 13px;
    margin-bottom: 15px;
}
</style>
</head>

<body>

<div class="login-wrapper">

    <!-- LOGO + TEXT -->
    <div class="logo">
        <img src="../assets/img/sticky-note.png" alt="Report Logo">
        <h1>Report</h1>
    </div>

    <!-- PESAN ERROR - ARRAY 1 DIMENSI -->
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert-error">
            <?= $_SESSION['error']; ?>
        </div>
    <?php unset($_SESSION['error']); endif; ?>

    <!-- FORM LOGIN -->
    <form action="login_process.php" method="POST">

        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" required autocomplete="off">

        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>

        <button type="submit">LOG-IN</button>

    </form>

</div>

</body>
</html>
