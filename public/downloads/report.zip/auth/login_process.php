<?php
session_start();
require_once '../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    $_SESSION['error'] = 'Username dan password wajib diisi';
    header('Location: login.php');
    exit;
}

$sql = "SELECT id, username, password, role, status
        FROM users
        WHERE username = ?
        LIMIT 1";

$stmt = $pdo->prepare($sql);
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    $_SESSION['error'] = 'Username tidak ditemukan';
    header('Location: login.php');
    exit;
}

if ((int)$user['status'] !== 1) {
    $_SESSION['error'] = 'Akun anda tidak aktif';
    header('Location: login.php');
    exit;
}

if (!password_verify($password, $user['password'])) {
    $_SESSION['error'] = 'Password salah';
    header('Location: login.php');
    exit;
}

$_SESSION['user'] = [
    'login'    => true,
    'id'       => $user['id'],
    'username' => $user['username'],
    'role'     => (int)$user['role']
];

switch ($_SESSION['user']['role']) {
    case 1:
        header('Location: ../dashboard/admin.php');
        break;
    case 2:
        header('Location: ../dashboard/petugas.php');
        break;
    default:
        header('Location: ../dashboard/user.php');
        break;
}
exit;
