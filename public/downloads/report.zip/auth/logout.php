<?php
// ======================================================
// FILE : auth/logout.php
// FUNGSI : Mengakhiri session login (logout user)
// ======================================================

// Memulai session
// Harus dipanggil agar session bisa dihancurkan
session_start();

// Menghapus semua data session
$_SESSION = [];

// Menghancurkan session
session_destroy();

// Redirect kembali ke halaman login
header("Location: login.php");
exit;
