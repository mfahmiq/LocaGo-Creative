<?php
/**
 * ==========================================================
 * FILE       : config.php
 * DESKRIPSI  : Konfigurasi dan koneksi database menggunakan PDO
 * ==========================================================
 */

/* Konfigurasi database */
$host     = "localhost";
$db_name  = "db_report";
$username = "root";
$password = "";

/* Data Source Name (DSN) */
$dsn = "mysql:host=$host;dbname=$db_name;charset=utf8";

try {
    /* Membuat objek koneksi PDO */
    $pdo = new PDO($dsn, $username, $password);

    /* Mengaktifkan mode error exception */
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    /* Set default fetch mode menjadi associative array */
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    /* Hentikan proses jika koneksi gagal */
    die("Koneksi database gagal!");
}