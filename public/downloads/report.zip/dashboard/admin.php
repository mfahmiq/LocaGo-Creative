<?php
// Role 1 = Admin
$allowedRoles = [1];
require '../middleware/auth_chek.php';

if (!isset($_SESSION['user']['login'])) {
    header('Location: ../auth/login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Admin</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #eef3f9;
    margin: 0;
}

.header {
    background: #3b82f6;
    color: white;
    padding: 15px 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header a {
    color: white;
    text-decoration: none;
    font-weight: bold;
}

.container {
    margin: 30px;
    background: white;
    padding: 20px;
    border-radius: 10px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 12px;
    border: 1px solid #ddd;
}

th {
    background: #f1f5f9;
}

tr:hover {
    background: #f9fafb;
}

.btn {
    padding: 6px 14px;
    background: #3b82f6;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-size: 14px;
}
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <h3>Dashboard Admin</h3>
    <a href="../auth/logout.php">Logout</a>
</div>

<!-- KONTEN -->
<div class="container">
    <h4>Menu Admin</h4>

    <table>
        <tr>
            <th>No</th>
            <th>Menu</th>
            <th>Deskripsi</th>
            <th>Aksi</th>
        </tr>

        <tr>
            <td>1</td>
            <td>Kelola User</td>
            <td>Tambah, ubah, hapus data user</td>
            <td>
                <a href="../admin/user.php" class="btn">Buka</a>
            </td>
        </tr>

        <tr>
            <td>2</td>
            <td>Validasi Laporan</td>
            <td>Pengecekan dan validasi laporan</td>
            <td>
                <a href="../admin/validasi.php" class="btn">Buka</a>
            </td>
        </tr>

        <tr>
            <td>3</td>
            <td>Laporan</td>
            <td>Laporan dan grafik sistem</td>
            <td>
                <a href="../admin/laporan.php" class="btn">Buka</a>
            </td>
        </tr>
        <tr>
    <td>2</td>
    <td>Laporan Log Aktivitas</td>
    <td>Riwayat perubahan data</td>
    <td>
        <a href="../admin/laporan-log.php" class="btn">Buka</a>
    </td>
</tr>
    </table>
</div>

</body>
</html>
