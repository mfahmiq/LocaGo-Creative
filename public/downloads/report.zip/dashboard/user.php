<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require '../config/config.php';

if (!isset($_SESSION['user']['login']) || $_SESSION['user']['login'] !== true) {
    header('Location: ../auth/login.php');
    exit;
}

$userId = $_SESSION['user']['id'];

/* ===============================
   DATA CHART
=============================== */
$stmtChart = $pdo->prepare("
    SELECT 
        SUM(CASE WHEN status = 4 THEN 1 ELSE 0 END) AS done,
        SUM(CASE WHEN status IN (1,2,3) THEN 1 ELSE 0 END) AS progress,
        SUM(CASE WHEN status = 5 THEN 1 ELSE 0 END) AS reject
    FROM laporan
    WHERE user_id = ?
");
$stmtChart->execute([$userId]);
$chart = $stmtChart->fetch(PDO::FETCH_ASSOC);

/* ===============================
   DATA LAPORAN
=============================== */
$stmt = $pdo->prepare("
    SELECT 
        laporan.*,
        users.username AS teknisi
    FROM laporan
    LEFT JOIN users ON laporan.assigned_to = users.id
    WHERE laporan.user_id = ?
    ORDER BY laporan.tanggal_lapor DESC
");
$stmt->execute([$userId]);
$laporan = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard User</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
*{
    box-sizing:border-box;
    font-family:Arial, sans-serif;
}
body{
    margin:0;
    background:#eef3f9;
}

/* ===============================
   SIDEBAR (FIX CLICK)
=============================== */
.sidebar{
    position:fixed;
    left:0;
    top:0;
    width:230px;
    height:100vh;
    background:#f8fbff;
    padding:20px;
    z-index:1000; /* 🔥 KUNCI */
}

.logo{
    font-weight:bold;
    color:#2563eb;
}

.add-btn{
    display:block;
    margin:20px 0;
    padding:10px;
    width:100%;
    background:#3b82f6;
    color:white;
    text-align:center;
    text-decoration:none;
    border-radius:8px;
    cursor:pointer;
    position:relative;
    z-index:1001; /* 🔥 KUNCI */
}
.add-btn:hover{
    background:#2563eb;
}

.menu a{
    display:block;
    padding:10px;
    border-radius:8px;
    text-decoration:none;
    color:#1e3a8a;
}
.menu a.active,
.menu a:hover{
    background:#e0ecff;
}

/* ===============================
   CONTENT
=============================== */
.content{
    margin-left:230px;
    min-height:100vh;
    display:flex;
    flex-direction:column;
    position:relative;
    z-index:1;
}

.header{
    background:#3b82f6;
    color:white;
    padding:16px 24px;
    display:flex;
    justify-content:space-between;
}

.main{
    padding:24px;
    flex:1;
}

/* ===============================
   SUMMARY
=============================== */
.summary{
    background:white;
    width:260px;
    margin:20px auto;
    padding:14px;
    text-align:center;
    border-radius:12px;
}

/* ===============================
   CHART
=============================== */
.donut-card{
    background:white;
    max-width:500px;
    margin:0 auto 30px;
    padding:20px;
    border-radius:16px;
}

/* ===============================
   TABLE
=============================== */
table{
    width:100%;
    border-collapse:collapse;
    background:white;
    border-radius:12px;
    overflow:hidden;
}
th,td{
    padding:14px;
    border-bottom:1px solid #e5e7eb;
}
th{
    background:#f1f5f9;
}
tr:hover{
    background:#f9fafb;
}

/* ===============================
   STATUS BADGE
=============================== */
.badge{
    padding:4px 10px;
    border-radius:12px;
    color:white;
    font-size:12px;
}
.open{background:#64748b}
.pending{background:#f59e0b}
.process{background:#3b82f6}
.done{background:#16a34a}
.reject{background:#dc2626}

/* ===============================
   FOOTER
=============================== */
.footer{
    background:#3b82f6;
    color:white;
    text-align:center;
    padding:12px;
    font-size:12px;
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<aside class="sidebar">
    <div class="logo">📘 Report App</div>

    <!-- 🔥 FIX: PAKAI <a> -->
    <a href="/LSP_FINAL/user/add-report.php" class="add-btn">
        + Buat Laporan
    </a>

    <div class="menu">
        <a class="active" href="#">📊 Dashboard</a>
    </div>
</aside>

<div class="content">

<!-- HEADER -->
<div class="header">
    <strong>DASHBOARD USER</strong>
    <a href="/LSP_FINAL/auth/logout.php" style="color:white;text-decoration:none;">
        Logout
    </a>
</div>

<div class="main">

<!-- SUMMARY -->
<div class="summary">
    <div>Total Laporan</div>
    <strong><?= count($laporan) ?></strong>
</div>

<!-- CHART -->
<div class="donut-card">
    <canvas id="donut"></canvas>
</div>

<!-- TABLE -->
<table>
<tr>
    <th>Judul</th>
    <th>Lokasi</th>
    <th>Status</th>
    <th>Petugas</th>
    <th>Tanggal</th>
</tr>

<?php if ($laporan): foreach ($laporan as $l): ?>
<tr>
    <td><?= htmlspecialchars($l['judul']) ?></td>
    <td><?= htmlspecialchars($l['lokasi']) ?></td>
    <td>
        <?php
        switch ($l['status']) {
            case 1: echo '<span class="badge open">Open</span>'; break;
            case 2: echo '<span class="badge pending">Pending</span>'; break;
            case 3: echo '<span class="badge process">Process</span>'; break;
            case 4: echo '<span class="badge done">Done</span>'; break;
            case 5: echo '<span class="badge reject">Reject</span>'; break;
        }
        ?>
    </td>
    <td><?= $l['teknisi'] ?? '-' ?></td>
    <td><?= date('d M Y', strtotime($l['tanggal_lapor'])) ?></td>
</tr>
<?php endforeach; else: ?>
<tr>
    <td colspan="5" style="text-align:center">
        Belum ada laporan
    </td>
</tr>
<?php endif; ?>
</table>

</div>

<div class="footer">© 2025 Report Application</div>
</div>

<script>
new Chart(document.getElementById('donut'),{
    type:'doughnut',
    data:{
        labels:['Progress','Selesai','Ditolak'],
        datasets:[{
            data:[
                <?= (int)$chart['progress'] ?>,
                <?= (int)$chart['done'] ?>,
                <?= (int)$chart['reject'] ?>
            ],
            borderWidth:0
        }]
    },
    options:{
        plugins:{
            legend:{position:'bottom'}
        }
    }
});
</script>

</body>
</html>
