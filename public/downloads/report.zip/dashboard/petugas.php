<?php
// ===============================
// DASHBOARD PETUGAS
// Role: 2
// ===============================
$allowedRoles = [2];
require '../middleware/auth_chek.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Petugas</title>

<style>
body {
    font-family: Arial, sans-serif;
    background: #eef3f9;
    margin: 0;
}
.header {
    background: #3b82f6;
    color: white;
    padding: 15px 25px;
    display: flex;
    justify-content: space-between;
}
.header a {
    color: white;
    text-decoration: none;
    font-weight: bold;
}
.container {
    margin: 30px;
}
table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 10px;
    overflow: hidden;
}
th, td {
    padding: 14px;
    border-bottom: 1px solid #e5e7eb;
}
th {
    background: #f1f5f9;
}
.btn {
    padding: 8px 14px;
    background: #3b82f6;
    color: white;
    text-decoration: none;
    border-radius: 6px;
}
.btn-success { background: #16a34a; }
.btn-warning { background: #f59e0b; }
</style>
</head>

<body>

<div class="header">
    <h3>Dashboard Petugas</h3>
    <a href="../auth/logout.php">Logout</a>
</div>

<div class="container">

<table>
<tr>
    <th>No</th>
    <th>Menu</th>
    <th>Deskripsi</th>
    <th>Aksi</th>
</tr>

<tr>
    <td>1</td>
    <td>Laporan Pending</td>
    <td>Laporan yang sudah disetujui admin dan siap diambil</td>
    <td>
        <a href="../petugas/laporan-pending.php" class="btn btn-success">
            Buka
        </a>
    </td>
</tr>

<tr>
    <td>2</td>
    <td>Laporan Diproses</td>
    <td>Laporan yang sedang kamu kerjakan</td>
    <td>
        <a href="../petugas/laporan-proses.php" class="btn btn-warning">
            Buka
        </a>
    </td>
</tr>

<tr>
    <td>3</td>
    <td>Riwayat Pekerjaan</td>
    <td>Laporan yang sudah selesai kamu kerjakan</td>
    <td>
        <a href="../petugas/laporan-selesai.php" class="btn">
            Buka
        </a>
    </td>
</tr>

</table>

</div>

</body>
</html>
