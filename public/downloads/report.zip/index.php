<?php
// ======================================
// FILE : index.php
// FUNGSI : Halaman awal aplikasi
// Mengecek status login dan mengarahkan
// pengguna ke dashboard sesuai role
// ======================================

session_start();

// Jika user sudah login
if (isset($_SESSION['user']['login']) && $_SESSION['user']['login'] === true) {

    // Arahkan berdasarkan role user
    switch ($_SESSION['user']['role']) {
        case 1:
            // Role 1 : Admin
            header("Location: dashboard/admin.php");
            break;

        case 2:
            // Role 2 : Petugas
            header("Location: dashboard/petugas.php");
            break;

        case 3:
            // Role 3 : User
            header("Location: dashboard/user.php");
            break;

        default:
            // Jika role tidak dikenali
            // hapus session dan kembali ke login
            session_unset();
            session_destroy();
            header("Location: auth/login.php");
            break;
    }
    exit;
}

// Jika user belum login
header("Location: auth/login.php");
exit;
