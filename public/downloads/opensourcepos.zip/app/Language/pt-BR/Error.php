<?php

return [
    'encryption_key_not_provisioned'   => '',
    'no_permission_module'             => 'Você não tem permissão para acessar o módulo chamado',
    'throttle_key_not_provisioned'     => '',
    'unable_to_create_env_file'        => 'Não foi possível criar {filePath} para provisionar throttle.key',
    'unable_to_lock_file'              => 'Não foi possível bloquear {filePath}: {reason}',
    'unable_to_open_lock_file'         => 'Não foi possível abrir {filePath}: {reason}',
    'unable_to_persist_encryption_key' => '',
    'unable_to_persist_throttle_key'   => 'Não foi possível persistir throttle.key em {filePath}',
    'unable_to_read_env_file'          => 'Não foi possível ler {filePath} para provisionar throttle.key',
    'unknown'                          => 'Desconhecido',
];
