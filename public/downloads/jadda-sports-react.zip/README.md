# Aplikasi Jadda Sports React Modern & Full Database (LocaGo Rebranded Edition)
Koleksi Source Code Siap Pakai dari LocaGo Creative (https://www.locagocreative.my.id)

## Fitur & Spesifikasi:
- Kategori: Next.js & React
- Teknologi: Next.js 15, TypeScript, Tailwind CSS, Stripe/QRIS
- Database: PostgreSQL (.sql)
- Lisensi: Bebas Modifikasi & Komersial

## Cara Instalasi:
1. Ekstrak file zip ke folder server web lokal Anda (htdocs / www).
2. Import file `database.sql` ke database Anda.
3. Sesuaikan konfigurasi database pada file `.env` atau `config.php`.
4. Buka di browser dan login dengan akun: admin@locago.my.id / password123.
