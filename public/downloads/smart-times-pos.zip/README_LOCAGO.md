# Sistem Point of Sale Modern - Smart Times Pos

```
========================================================================
📦 Sistem Point of Sale Modern - Smart Times Pos
Kategori     : Kasir & Point of Sale (POS)
Tech Stack   : Laravel • PHP • MySQL • React • Vite
Database     : MySQL (.sql) (File: backend/database/setup_smarttimes_db.sql)
Sumber Asli  : https://github.com/Ramsrinivash/smart-times-pos (GitHub Open Source)
Stars GitHub : ⭐ 0 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/smart-times-pos`
     * Untuk Laragon: `C:/laragon/www/smart-times-pos`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `smart_times_pos`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `backend/database/setup_smarttimes_db.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = smart_times_pos

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/smart-times-pos

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
