import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import Header from '../components/Layout/Header';
import { useAuth } from '../context/AuthContext';
import { Download, FileText, BarChart2, TrendingUp, RefreshCw, Users, Wrench, Truck, Eye, Printer } from 'lucide-react';
import { exportCSV, exportExcel } from '../utils/exportUtils';
import PrintableInvoice from '../components/PrintableInvoice';

const Reports = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('sales');

  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [gstMonth, setGstMonth] = useState(String(new Date().getMonth() + 1).padStart(2, '0'));
  const [gstYear, setGstYear] = useState(String(new Date().getFullYear()));

  const [salesData, setSalesData] = useState([]);
  const [profitData, setProfitData] = useState([]);
  const [stockData, setStockData] = useState(null);
  const [purchaseLedger, setPurchaseLedger] = useState([]);
  const [exchangeData, setExchangeData] = useState([]);
  const [loyaltyData, setLoyaltyData] = useState([]);
  const [serviceData, setServiceData] = useState([]);
  const [supplierDues, setSupplierDues] = useState([]);
  const [gstData, setGstData] = useState({ sales: [], purchases: [] });
  const [loading, setLoading] = useState(false);
  
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50;

  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [storeSettings, setStoreSettings] = useState(null);
  const [viewingBillFile, setViewingBillFile] = useState(null);

  useEffect(() => {
    api.getSettings().then(s => setStoreSettings(s)).catch(() => {});
  }, []);

  const handleViewInvoice = async (sale) => {
    try {
      const fullSale = await api.getSale(sale.id);
      setSelectedInvoice(fullSale || sale);
    } catch (err) {
      setSelectedInvoice(sale);
    }
  };

  const loadReport = async (tabId) => {
    setLoading(true);
    setCurrentPage(1); // Reset page on new load
    try {
      switch (tabId) {
        case 'sales': {
          const data = await api.getSalesReport(startDate || null, endDate || null);
          setSalesData(Array.isArray(data) ? data : []);
          break;
        }
        case 'profit': {
          const data = await api.getProfitReport(startDate || null, endDate || null);
          setProfitData(Array.isArray(data) ? data : []);
          break;
        }
        case 'stock': {
          const data = await api.getStockValuation();
          setStockData(data);
          break;
        }
        case 'purchase': {
          const data = await api.getPurchaseLedger();
          setPurchaseLedger(Array.isArray(data) ? data : []);
          break;
        }
        case 'exchange': {
          const data = await api.getExchangeReport();
          setExchangeData(Array.isArray(data) ? data : []);
          break;
        }
        case 'loyalty': {
          const data = await api.getLoyaltyReport();
          setLoyaltyData(Array.isArray(data) ? data : []);
          break;
        }
        case 'services': {
          const data = await api.getPendingServiceReport();
          setServiceData(Array.isArray(data) ? data : []);
          break;
        }
        case 'supplier_dues': {
          const data = await api.getSupplierDuesReport();
          setSupplierDues(Array.isArray(data) ? data : []);
          break;
        }
        case 'gst': {
          const data = await api.getGstReport(gstMonth, gstYear);
          setGstData(data || { sales: [], purchases: [] });
          break;
        }
        default: break;
      }
    } catch (err) {
      console.error('Report load error:', err);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadReport(activeTab);
  }, [activeTab]);

  const switchTab = (tabId) => {
    setActiveTab(tabId);
    if (tabId === 'gst') {
      // Auto-load GST report on tab switch
      setTimeout(() => loadReport('gst'), 50);
    }
  };

  const tabStyle = (t) => ({
    padding: '0.5rem 1rem',
    borderRadius: 'var(--radius-sm)',
    fontWeight: 600,
    fontSize: '0.82rem',
    cursor: 'pointer',
    border: 'none',
    background: activeTab === t ? 'var(--primary-gold)' : 'var(--surface-card)',
    color: activeTab === t ? '#000' : 'var(--text-primary)',
    transition: 'all 0.2s'
  });

  const fmt = (n) => `₹${Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  const tabs = [
    { id: 'sales', label: 'Daily/Monthly Sales', icon: <BarChart2 size={14} /> },
    ...(user.role !== 'sales' ? [
      { id: 'profit', label: 'Profit Margin', icon: <TrendingUp size={14} /> },
      { id: 'stock', label: 'Stock Valuation', icon: <FileText size={14} /> },
      { id: 'purchase', label: 'Purchase Ledger', icon: <FileText size={14} /> },
    ] : []),
    { id: 'exchange', label: 'Exchange Report', icon: <RefreshCw size={14} /> },
    { id: 'loyalty', label: 'Loyalty Points', icon: <Users size={14} /> },
    { id: 'services', label: 'Pending Repairs', icon: <Wrench size={14} /> },
    ...(user.role !== 'sales' ? [
      { id: 'supplier_dues', label: 'Supplier Dues', icon: <Truck size={14} /> },
      { id: 'gst', label: 'GST Report', icon: <FileText size={14} /> },
    ] : [])
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', width: '100%', minHeight: '100vh' }}>
      <Header searchPlaceholder="Search reports..." />
      <div className="page-container">
        <h1 className="page-title">Reports & Analytics</h1>
        <p className="page-subtitle">Business intelligence — exportable in Excel (.xlsx) and CSV formats.</p>

        {/* Date Filters */}
        {['sales', 'profit'].includes(activeTab) && (
          <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-end', marginBottom: '1.25rem', flexWrap: 'wrap' }}>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">From Date</label>
              <input type="date" className="form-control" value={startDate} onChange={e => setStartDate(e.target.value)} />
            </div>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">To Date</label>
              <input type="date" className="form-control" value={endDate} onChange={e => setEndDate(e.target.value)} />
            </div>
            <button className="btn btn-secondary" onClick={() => loadReport(activeTab)} style={{ height: '42px' }}>Apply Filter</button>
            <button className="btn btn-secondary" onClick={() => { setStartDate(''); setEndDate(''); setTimeout(() => loadReport(activeTab), 100); }} style={{ height: '42px' }}>Clear</button>
          </div>
        )}
        {activeTab === 'gst' && (
          <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-end', marginBottom: '1.25rem', flexWrap: 'wrap' }}>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Month</label>
              <select className="form-control" value={gstMonth} onChange={e => setGstMonth(e.target.value)}>
                {Array.from({ length: 12 }, (_, i) => {
                  const m = String(i + 1).padStart(2, '0');
                  return <option key={m} value={m}>{new Date(2000, i).toLocaleString('en-IN', { month: 'long' })}</option>;
                })}
              </select>
            </div>
            <div className="form-group" style={{ margin: 0 }}>
              <label className="form-label">Year</label>
              <input type="number" className="form-control" value={gstYear} onChange={e => setGstYear(e.target.value)} style={{ width: '100px' }} />
            </div>
            <button className="btn btn-secondary" onClick={() => loadReport('gst')} style={{ height: '42px' }}>Load GST Report</button>
          </div>
        )}

        {/* Tab Navigation */}
        <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
          {tabs.map(tab => (
            <button key={tab.id} style={tabStyle(tab.id)} onClick={() => switchTab(tab.id)}>
              {tab.icon} <span style={{ marginLeft: '0.25rem' }}>{tab.label}</span>
            </button>
          ))}
        </div>

        {loading && <div style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-secondary)' }}>Loading report data...</div>}

        {/* ── SALES REPORT ── */}
        {activeTab === 'sales' && !loading && (
          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
              <h3>Sales Report ({salesData.length} invoices)</h3>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button className="btn btn-secondary btn-sm" onClick={() => exportCSV(
                  ['Invoice No', 'Date', 'Customer', 'Phone', 'Invoice Type', 'Subtotal', 'Discount', 'GST', 'Net Amount', 'Payment Mode'],
                  salesData.map(s => [s.id, s.invoice_date, s.customer?.name, s.customer?.phone, s.invoice_type, s.subtotal, s.discount_amount, s.gst_amount, s.net_amount, s.payment_mode]),
                  'sales_report'
                )}>
                  <Download size={13} /> Export CSV
                </button>
                <button className="btn btn-primary btn-sm" onClick={() => exportExcel(
                  ['Invoice No', 'Date', 'Customer', 'Phone', 'Invoice Type', 'Subtotal', 'Discount', 'GST', 'Net Amount', 'Payment Mode'],
                  salesData.map(s => [s.id, s.invoice_date, s.customer?.name, s.customer?.phone, s.invoice_type, s.subtotal, s.discount_amount, s.gst_amount, s.net_amount, s.payment_mode]),
                  'sales_report', 'Sales Report'
                )}>
                  <Download size={13} /> Export Excel
                </button>
              </div>
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table className="data-table">
                <thead><tr>
                  <th>Invoice No</th><th>Date</th><th>Customer</th><th>Type</th>
                  <th>Subtotal</th><th>Discount</th><th>GST</th><th>Net Amount</th><th>Mode</th><th style={{ textAlign: 'center' }}>Action</th>
                </tr></thead>
                <tbody>
                  {salesData.length > 0 ? salesData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage).map(s => (
                    <tr key={s.id}>
                      <td>
                        <button
                          type="button"
                          onClick={() => handleViewInvoice(s)}
                          style={{
                            background: 'none',
                            border: 'none',
                            color: 'var(--primary-gold)',
                            fontFamily: 'monospace',
                            fontSize: '0.85rem',
                            fontWeight: 700,
                            cursor: 'pointer',
                            textDecoration: 'underline',
                            padding: 0
                          }}
                          title="Click to view full bill receipt"
                        >
                          {s.id}
                        </button>
                      </td>
                      <td>{s.invoice_date}</td>
                      <td>{s.customer?.name}<br /><small style={{ color: 'var(--text-secondary)' }}>{s.customer?.phone}</small></td>
                      <td><span className={`badge badge-${s.invoice_type === 'gst' ? 'success' : 'info'}`}>{s.invoice_type.toUpperCase()}</span></td>
                      <td>{fmt(s.subtotal)}</td>
                      <td style={{ color: 'var(--error)' }}>{fmt(s.discount_amount || 0)}</td>
                      <td>{fmt(s.gst_amount)}</td>
                      <td style={{ fontWeight: 700 }}>{fmt(s.net_amount)}</td>
                      <td style={{ textTransform: 'capitalize' }}>{s.payment_mode}</td>
                      <td style={{ textAlign: 'center' }}>
                        <button
                          className="btn btn-secondary btn-sm"
                          style={{ padding: '0.25rem 0.65rem', fontSize: '0.78rem', display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}
                          onClick={() => handleViewInvoice(s)}
                          title="View full generated bill invoice"
                        >
                          <Eye size={13} /> View Bill
                        </button>
                      </td>
                    </tr>
                  )) : (
                    <tr><td colSpan="10" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>No sales data for selected period.</td></tr>
                  )}
                </tbody>
                {salesData.length > 0 && (
                  <tfoot>
                    <tr style={{ fontWeight: 700, background: 'var(--surface-card)' }}>
                      <td colSpan="4">Total ({salesData.length} invoices)</td>
                      <td>{fmt(salesData.reduce((a, s) => a + Number(s.subtotal || 0), 0))}</td>
                      <td style={{ color: 'var(--error)' }}>{fmt(salesData.reduce((a, s) => a + Number(s.discount_amount || 0), 0))}</td>
                      <td>{fmt(salesData.reduce((a, s) => a + Number(s.gst_amount || 0), 0))}</td>
                      <td>{fmt(salesData.reduce((a, s) => a + Number(s.net_amount || 0), 0))}</td>
                      <td colSpan="2"></td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
            
            {/* Pagination Controls */}
            {salesData.length > itemsPerPage && (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1rem', padding: '0.5rem 0' }}>
                <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                  Showing {(currentPage - 1) * itemsPerPage + 1} to {Math.min(currentPage * itemsPerPage, salesData.length)} of {salesData.length} entries
                </span>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <button 
                    className="btn btn-secondary btn-sm" 
                    disabled={currentPage === 1} 
                    onClick={() => setCurrentPage(p => p - 1)}
                  >
                    Previous
                  </button>
                  <button 
                    className="btn btn-secondary btn-sm" 
                    disabled={currentPage === Math.ceil(salesData.length / itemsPerPage)} 
                    onClick={() => setCurrentPage(p => p + 1)}
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
            

          </div>
        )}

        {/* ── PROFIT REPORT ── */}
        {activeTab === 'profit' && !loading && user.role !== 'sales' && (
          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.75rem' }}>
              <div>
                <h3 style={{ margin: 0 }}>Audited Profit Margin Report (True GST Norms)</h3>
                <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                  Net Profit = Taxable Sales Revenue − Taxable Purchase Cost (Accounts for Input Tax Credit & Net GST Payable)
                </span>
              </div>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button className="btn btn-secondary btn-sm" onClick={() => exportCSV(
                  ['Invoice No', 'Type', 'Date', 'Customer', 'Net Sale', 'Cost Price', 'Taxable Cost (Base)', 'Output GST', 'Input Tax Credit', 'Net GST to Govt', 'Audited Profit', 'Margin %'],
                  profitData.map(s => {
                    const cost = s.total_cost || s?.items.reduce((a, si) => a + Number(si.cost_price || 0), 0);
                    const margin = Number(s.net_amount) > 0 ? ((Number(s.total_profit) / Number(s.net_amount)) * 100).toFixed(1) : 0;
                    return [
                      s.id, 
                      (s.invoice_type || 'nongst').toUpperCase(), 
                      s.invoice_date, 
                      s.customer?.name || 'Walk-in', 
                      s.net_amount, 
                      cost, 
                      s.taxable_cost || cost, 
                      s.output_gst || 0, 
                      s.input_gst || 0, 
                      s.net_tax_payable || 0, 
                      s.total_profit, 
                      margin + '%'
                    ];
                  }),
                  'audited_profit_report'
                )}>
                  <Download size={13} /> Export CSV
                </button>
                <button className="btn btn-primary btn-sm" onClick={() => exportExcel(
                  ['Invoice No', 'Type', 'Date', 'Customer', 'Net Sale', 'Cost Price', 'Taxable Cost (Base)', 'Output GST', 'Input Tax Credit', 'Net GST to Govt', 'Audited Profit', 'Margin %'],
                  profitData.map(s => {
                    const cost = s.total_cost || s?.items.reduce((a, si) => a + Number(si.cost_price || 0), 0);
                    const margin = Number(s.net_amount) > 0 ? ((Number(s.total_profit) / Number(s.net_amount)) * 100).toFixed(1) : 0;
                    return [
                      s.id, 
                      (s.invoice_type || 'nongst').toUpperCase(), 
                      s.invoice_date, 
                      s.customer?.name || 'Walk-in', 
                      s.net_amount, 
                      cost, 
                      s.taxable_cost || cost, 
                      s.output_gst || 0, 
                      s.input_gst || 0, 
                      s.net_tax_payable || 0, 
                      s.total_profit, 
                      margin + '%'
                    ];
                  }),
                  'audited_profit_report', 'Audited Profit Report'
                )}>
                  <Download size={13} /> Export Excel
                </button>
              </div>
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Invoice</th>
                    <th>Type</th>
                    <th>Date</th>
                    <th>Customer</th>
                    <th>Net Sale</th>
                    <th>Cost Price</th>
                    <th>Net GST to Govt</th>
                    <th>Audited Profit</th>
                    <th>Margin %</th>
                  </tr>
                </thead>
                <tbody>
                  {profitData.length > 0 ? profitData.map(s => {
                    const cost = s.total_cost || s?.items.reduce((a, si) => a + Number(si.cost_price || 0), 0);
                    const margin = Number(s.net_amount) > 0 ? ((Number(s.total_profit) / Number(s.net_amount)) * 100).toFixed(1) : 0;
                    const netTax = Number(s.net_tax_payable || 0);

                    return (
                      <tr key={s.id}>
                        <td style={{ fontFamily: 'monospace', fontSize: '0.82rem' }}>{s.id}</td>
                        <td>
                          <span className={`badge badge-${s.invoice_type === 'gst' ? 'info' : 'secondary'}`} style={{ fontSize: '0.72rem', textTransform: 'uppercase' }}>
                            {s.invoice_type || 'nongst'}
                          </span>
                        </td>
                        <td>{s.invoice_date}</td>
                        <td>{s.customer?.name || 'Walk-in Customer'}</td>
                        <td style={{ fontWeight: 600 }}>{fmt(s.net_amount)}</td>
                        <td style={{ color: 'var(--text-secondary)' }}>{fmt(cost)}</td>
                        <td style={{ fontSize: '0.8rem', color: netTax > 0 ? '#ef4444' : 'var(--text-secondary)' }}>
                          {netTax > 0 ? `₹${netTax.toFixed(2)}` : '₹0.00'}
                        </td>
                        <td style={{ color: Number(s.total_profit || 0) >= 0 ? 'var(--success)' : 'var(--error)', fontWeight: 700 }}>
                          {fmt(s.total_profit)}
                        </td>
                        <td>
                          <span className={`badge badge-${Number(margin) > 20 ? 'success' : Number(margin) > 10 ? 'warning' : 'danger'}`}>
                            {margin}%
                          </span>
                        </td>
                      </tr>
                    );
                  }) : (
                    <tr><td colSpan="9" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>No profit data for selected period.</td></tr>
                  )}
                </tbody>
                {profitData.length > 0 && (
                  <tfoot>
                    <tr style={{ fontWeight: 700 }}>
                      <td colSpan="4">Total</td>
                      <td>{fmt(profitData.reduce((a, s) => a + Number(s.net_amount || 0), 0))}</td>
                      <td>{fmt(profitData.reduce((a, s) => a + Number(s.total_cost || s?.items.reduce((b, si) => b + Number(si.cost_price || 0), 0)), 0))}</td>
                      <td style={{ color: '#ef4444' }}>{fmt(profitData.reduce((a, s) => a + Number(s.net_tax_payable || 0), 0))}</td>
                      <td style={{ color: 'var(--success)' }}>{fmt(profitData.reduce((a, s) => a + Number(s.total_profit || 0), 0))}</td>
                      <td></td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        )}

        {/* ── STOCK VALUATION ── */}
        {activeTab === 'stock' && !loading && stockData && user.role !== 'sales' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem' }}>
              <div className="card" style={{ textAlign: 'center' }}>
                <span className="card-title">Units In Stock</span>
                <h2 className="card-value">{stockData.total_in_stock_count}</h2>
              </div>
              <div className="card" style={{ textAlign: 'center' }}>
                <span className="card-title">Cost Valuation</span>
                <h2 className="card-value" style={{ color: 'var(--primary-gold)' }}>{fmt(stockData.total_cost_valuation)}</h2>
              </div>
              <div className="card" style={{ textAlign: 'center' }}>
                <span className="card-title">MRP Valuation</span>
                <h2 className="card-value">{fmt(stockData.total_mrp_valuation)}</h2>
              </div>
            </div>
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
                <h3>Brand-wise Stock Breakdown</h3>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <button className="btn btn-secondary btn-sm" onClick={() => exportCSV(
                    ['Brand', 'Units', 'Cost Value', 'MRP Value'],
                    stockData.breakdown_by_brand.map(b => [b.brand, b.count, b.cost_value, b.mrp_value]),
                    'stock_valuation'
                  )}><Download size={13} /> Export CSV</button>
                  <button className="btn btn-primary btn-sm" onClick={() => exportExcel(
                    ['Brand', 'Units', 'Cost Value', 'MRP Value'],
                    stockData.breakdown_by_brand.map(b => [b.brand, b.count, b.cost_value, b.mrp_value]),
                    'stock_valuation', 'Stock Valuation'
                  )}><Download size={13} /> Export Excel</button>
                </div>
              </div>
              <table className="data-table">
                <thead><tr><th>Brand</th><th>Units In Stock</th><th>Cost Valuation</th><th>MRP Valuation</th></tr></thead>
                <tbody>
                  {stockData.breakdown_by_brand.map((b, idx) => (
                    <tr key={idx}>
                      <td style={{ fontWeight: 600 }}>{b.brand}</td>
                      <td>{b.count}</td>
                      <td>{fmt(b.cost_value)}</td>
                      <td>{fmt(b.mrp_value)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ── PURCHASE LEDGER ── */}
        {activeTab === 'purchase' && !loading && user.role !== 'sales' && (
          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <h3>Purchase Ledger ({purchaseLedger.length} units)</h3>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button className="btn btn-secondary btn-sm" onClick={() => exportCSV(
                  ['Watch Serial', 'Brand', 'Model', 'Supplier', 'Purchase Date', 'Invoice Ref', 'MRP', 'Discount %', 'Cost Price', 'Selling Price', 'GST Rate', 'Status'],
                  purchaseLedger.map(r => [r.watch_id, r.brand, r.model, r.supplier_name, r.purchase_date, r.invoice_number, r.mrp, r.discount_percent, r.cost_price, r.selling_price, r.gst_rate + '%', r.watch_status]),
                  'purchase_ledger'
                )}><Download size={13} /> Export CSV</button>
                <button className="btn btn-primary btn-sm" onClick={() => exportExcel(
                  ['Watch Serial', 'Brand', 'Model', 'Supplier', 'Purchase Date', 'Invoice Ref', 'MRP', 'Discount %', 'Cost Price', 'Selling Price', 'GST Rate', 'Status'],
                  purchaseLedger.map(r => [r.watch_id, r.brand, r.model, r.supplier_name, r.purchase_date, r.invoice_number, r.mrp, r.discount_percent, r.cost_price, r.selling_price, r.gst_rate + '%', r.watch_status]),
                  'purchase_ledger', 'Purchase Ledger'
                )}><Download size={13} /> Export Excel</button>
              </div>
            </div>
            <div style={{ overflowX: 'auto' }}>
              <table className="data-table">
                <thead><tr>
                  <th>Watch ID</th><th>Brand / Model</th><th>Supplier</th><th>Invoice / Bill</th><th>Date</th>
                  <th>MRP</th><th>Disc %</th><th>Cost Price</th><th>Selling Price</th><th>GST</th><th>Status</th>
                </tr></thead>
                <tbody>
                  {purchaseLedger.length > 0 ? purchaseLedger.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage).map((r, idx) => (
                    <tr key={idx}>
                      <td style={{ fontFamily: 'monospace', fontSize: '0.82rem' }}>{r.watch_id}</td>
                      <td><strong>{r.brand}</strong><br /><small style={{ color: 'var(--text-secondary)' }}>{r.model}</small></td>
                      <td>{r.supplier_name}</td>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                          <span style={{ fontFamily: 'monospace', fontSize: '0.82rem' }}>{r.invoice_number || '—'}</span>
                          {r.bill_file && (
                            <button
                              type="button"
                              onClick={() => setViewingBillFile({ file: r.bill_file, title: `${r.supplier_name} - ${r.invoice_number}` })}
                              style={{
                                background: 'rgba(217, 119, 6, 0.15)',
                                border: '1px solid var(--primary-gold)',
                                color: 'var(--primary-gold)',
                                borderRadius: '4px',
                                padding: '2px 6px',
                                fontSize: '0.72rem',
                                cursor: 'pointer',
                                display: 'inline-flex',
                                alignItems: 'center',
                                gap: '3px'
                              }}
                              title="Click to view uploaded bill document"
                            >
                              <FileText size={11} /> Bill
                            </button>
                          )}
                        </div>
                      </td>
                      <td>{r.purchase_date}</td>
                      <td>{fmt(r.mrp)}</td>
                      <td>{r.discount_percent}%</td>
                      <td style={{ color: 'var(--primary-gold)' }}>{fmt(r.cost_price)}</td>
                      <td>{fmt(r.selling_price)}</td>
                      <td>{r.gst_rate}%</td>
                      <td><span className={`badge badge-${r.watch_status === 'in_stock' ? 'success' : r.watch_status === 'sold' ? 'info' : 'warning'}`}>{r.watch_status.replace('_', ' ')}</span></td>
                    </tr>
                  )) : (
                    <tr><td colSpan="10" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>No purchase data found.</td></tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls */}
            {purchaseLedger.length > itemsPerPage && (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1rem', padding: '0.5rem 0' }}>
                <span style={{ fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                  Showing {(currentPage - 1) * itemsPerPage + 1} to {Math.min(currentPage * itemsPerPage, purchaseLedger.length)} of {purchaseLedger.length} entries
                </span>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <button 
                    className="btn btn-secondary btn-sm" 
                    disabled={currentPage === 1} 
                    onClick={() => setCurrentPage(p => p - 1)}
                  >
                    Previous
                  </button>
                  <button 
                    className="btn btn-secondary btn-sm" 
                    disabled={currentPage === Math.ceil(purchaseLedger.length / itemsPerPage)} 
                    onClick={() => setCurrentPage(p => p + 1)}
                  >
                    Next
                  </button>
                </div>
              </div>
            )}

          </div>
        )}

        {/* ── EXCHANGE REPORT ── */}
        {activeTab === 'exchange' && !loading && (
          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <h3>Exchange Report ({exchangeData.length} exchanges)</h3>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button className="btn btn-secondary btn-sm" onClick={() => exportCSV(
                  ['Date', 'Customer', 'Orig Invoice', 'Returned Watch', 'Replacement Watch', 'Difference ₹', 'Type', 'Within Window'],
                  exchangeData.map(ex => [ex.exchange_date, ex.original_sale?.customer?.name, ex.original_sale_id, ex.returned_watch_id, ex.replacement_watch_id, ex.difference_amount, ex.exchange_type, ex.within_exchange_window ? 'Yes' : 'No']),
                  'exchange_report'
                )}><Download size={13} /> Export CSV</button>
                <button className="btn btn-primary btn-sm" onClick={() => exportExcel(
                  ['Date', 'Customer', 'Orig Invoice', 'Returned Watch', 'Replacement Watch', 'Difference ₹', 'Type', 'Within Window'],
                  exchangeData.map(ex => [ex.exchange_date, ex.original_sale?.customer?.name, ex.original_sale_id, ex.returned_watch_id, ex.replacement_watch_id, ex.difference_amount, ex.exchange_type, ex.within_exchange_window ? 'Yes' : 'No']),
                  'exchange_report', 'Exchange Report'
                )}><Download size={13} /> Export Excel</button>
              </div>
            </div>
            <table className="data-table">
              <thead><tr>
                <th>Date</th><th>Customer</th><th>Orig Invoice</th><th>Returned</th><th>Replacement</th><th>Difference</th><th>Type</th><th>Status</th>
              </tr></thead>
              <tbody>
                {exchangeData.length > 0 ? exchangeData.map(ex => (
                  <tr key={ex.id}>
                    <td>{ex.exchange_date}</td>
                    <td>{ex.original_sale?.customer?.name}</td>
                    <td style={{ fontFamily: 'monospace', fontSize: '0.82rem' }}>{ex.original_sale_id}</td>
                    <td style={{ fontFamily: 'monospace', fontSize: '0.82rem', color: 'var(--error)' }}>{ex.returned_watch_id}</td>
                    <td style={{ fontFamily: 'monospace', fontSize: '0.82rem', color: 'var(--success)' }}>{ex.replacement_watch_id}</td>
                    <td style={{ color: ex.difference_amount >= 0 ? 'var(--success)' : 'var(--error)' }}>{fmt(Math.abs(ex.difference_amount))}{ex.difference_amount < 0 ? ' (Refund)' : ''}</td>
                    <td><span className="badge badge-info">{ex.exchange_type.replace('_', ' ')}</span></td>
                    <td><span className={`badge badge-${ex.status === 'resellable' ? 'success' : ex.status === 'pending_review' ? 'warning' : 'info'}`}>{ex.status.replace('_', ' ')}</span></td>
                  </tr>
                )) : (
                  <tr><td colSpan="8" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>No exchanges recorded.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* ── LOYALTY POINTS REPORT ── */}
        {activeTab === 'loyalty' && !loading && (
          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <h3>Loyalty Points Ledger ({loyaltyData.length} transactions)</h3>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button className="btn btn-secondary btn-sm" onClick={() => exportCSV(
                  ['Date', 'Customer', 'Phone', 'Type', 'Points Earned', 'Points Redeemed', 'Reference', 'Remarks'],
                  loyaltyData.map(l => [l.created_at, l.customer?.name, l.customer?.phone, l.transaction_type, l.points_earned, l.points_redeemed, l.reference_id, l.remarks]),
                  'loyalty_report'
                )}><Download size={13} /> Export CSV</button>
                <button className="btn btn-primary btn-sm" onClick={() => exportExcel(
                  ['Date', 'Customer', 'Phone', 'Type', 'Points Earned', 'Points Redeemed', 'Reference', 'Remarks'],
                  loyaltyData.map(l => [l.created_at, l.customer?.name, l.customer?.phone, l.transaction_type, l.points_earned, l.points_redeemed, l.reference_id, l.remarks]),
                  'loyalty_report', 'Loyalty Report'
                )}><Download size={13} /> Export Excel</button>
              </div>
            </div>
            <table className="data-table">
              <thead><tr>
                <th>Date</th><th>Customer</th><th>Type</th><th>Earned</th><th>Redeemed</th><th>Reference</th>
              </tr></thead>
              <tbody>
                {loyaltyData.length > 0 ? loyaltyData.map(l => (
                  <tr key={l.id}>
                    <td>{l.created_at}</td>
                    <td>{l.customer?.name}<br /><small style={{ color: 'var(--text-secondary)' }}>{l.customer?.phone}</small></td>
                    <td><span className={`badge badge-${l.transaction_type === 'purchase' ? 'success' : l.transaction_type === 'redemption' ? 'warning' : 'danger'}`}>{l.transaction_type}</span></td>
                    <td style={{ color: 'var(--success)', fontWeight: 600 }}>{l.points_earned > 0 ? `+${l.points_earned} pts` : '—'}</td>
                    <td style={{ color: 'var(--error)', fontWeight: 600 }}>{l.points_redeemed > 0 ? `-${l.points_redeemed} pts` : '—'}</td>
                    <td style={{ fontFamily: 'monospace', fontSize: '0.82rem' }}>{l.reference_id}</td>
                  </tr>
                )) : (
                  <tr><td colSpan="6" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>No loyalty transactions yet.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* ── PENDING SERVICE JOBS ── */}
        {activeTab === 'services' && !loading && (
          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <h3>Pending Service Jobs ({serviceData.length})</h3>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button className="btn btn-secondary btn-sm" onClick={() => exportCSV(
                  ['Job Card No', 'Customer', 'Phone', 'Watch', 'Issue', 'Status', 'Due Date', 'Overdue', 'Estimate ₹'],
                  serviceData.map(j => [
                    j.id, j.customer?.name, j.customer?.phone,
                    j.watch_id || `${j.watch_details?.brand} ${j.watch_details?.model}`,
                    j.issue_reported, j.status, j.expected_delivery_date, j.is_overdue ? 'YES' : 'No', j.estimated_cost
                  ]),
                  'pending_services'
                )}><Download size={13} /> Export CSV</button>
                <button className="btn btn-primary btn-sm" onClick={() => exportExcel(
                  ['Job Card No', 'Customer', 'Phone', 'Watch', 'Issue', 'Status', 'Due Date', 'Overdue', 'Estimate ₹'],
                  serviceData.map(j => [
                    j.id, j.customer?.name, j.customer?.phone,
                    j.watch_id || `${j.watch_details?.brand} ${j.watch_details?.model}`,
                    j.issue_reported, j.status, j.expected_delivery_date, j.is_overdue ? 'YES' : 'No', j.estimated_cost
                  ]),
                  'pending_services', 'Service Report'
                )}><Download size={13} /> Export Excel</button>
              </div>
            </div>
            <table className="data-table">
              <thead><tr>
                <th>Job Card</th><th>Customer</th><th>Watch</th><th>Issue</th><th>Status</th><th>Due Date</th><th>Estimate</th>
              </tr></thead>
              <tbody>
                {serviceData.length > 0 ? serviceData.map(j => (
                  <tr key={j.id}>
                    <td style={{ fontFamily: 'monospace', fontSize: '0.82rem' }}>{j.id}</td>
                    <td>{j.customer?.name}<br /><small>{j.customer?.phone}</small></td>
                    <td style={{ fontSize: '0.85rem' }}>{j.watch_id || `${j.watch_details?.brand} ${j.watch_details?.model}`}</td>
                    <td style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', maxWidth: '200px' }}>{j.issue_reported}</td>
                    <td><span className={`badge badge-${j.status === 'received' ? 'danger' : j.status === 'in_repair' ? 'warning' : 'success'}`}>{j.status.replace('_', ' ')}</span></td>
                    <td style={{ color: j.is_overdue ? 'var(--error)' : 'inherit', fontWeight: j.is_overdue ? 700 : 400 }}>
                      {j.expected_delivery_date || 'N/A'}
                      {j.is_overdue && <span className="badge badge-danger" style={{ marginLeft: '0.5rem' }}>OVERDUE</span>}
                    </td>
                    <td>{fmt(j.estimated_cost)}</td>
                  </tr>
                )) : (
                  <tr><td colSpan="7" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>No pending repair jobs.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* ── SUPPLIER DUES ── */}
        {activeTab === 'supplier_dues' && !loading && user.role !== 'sales' && (
          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <h3>Supplier Outstanding Dues ({supplierDues.length} bills)</h3>
              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button className="btn btn-secondary btn-sm" onClick={() => exportCSV(
                  ['Purchase ID', 'Supplier', 'Invoice Ref', 'Date', 'Total Amount', 'Status'],
                  supplierDues.map(p => [p.id, p.supplier_name, p.invoice_number, p.purchase_date, p.total_amount, p.payment_status]),
                  'supplier_dues'
                )}><Download size={13} /> Export CSV</button>
                <button className="btn btn-primary btn-sm" onClick={() => exportExcel(
                  ['Purchase ID', 'Supplier', 'Invoice Ref', 'Date', 'Total Amount', 'Status'],
                  supplierDues.map(p => [p.id, p.supplier_name, p.invoice_number, p.purchase_date, p.total_amount, p.payment_status]),
                  'supplier_dues', 'Supplier Dues'
                )}><Download size={13} /> Export Excel</button>
              </div>
            </div>
            {supplierDues.length > 0 ? (
              <table className="data-table">
                <thead><tr>
                  <th>Purchase ID</th><th>Supplier</th><th>Invoice Ref</th><th>Date</th><th>Amount Due</th><th>Units</th>
                </tr></thead>
                <tbody>
                  {supplierDues.map(p => (
                    <tr key={p.id}>
                      <td>{p.id}</td>
                      <td><strong>{p.supplier_name}</strong></td>
                      <td style={{ fontFamily: 'monospace', fontSize: '0.82rem' }}>{p.invoice_number}</td>
                      <td>{p.purchase_date}</td>
                      <td style={{ color: 'var(--error)', fontWeight: 700 }}>{fmt(p.total_amount)}</td>
                      <td>{p?.watches?.length || 0} units</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr style={{ fontWeight: 700 }}>
                    <td colSpan="4">Total Outstanding</td>
                    <td style={{ color: 'var(--error)' }}>{fmt(supplierDues.reduce((a, p) => a + Number(p.total_amount || 0), 0))}</td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            ) : (
              <p style={{ textAlign: 'center', padding: '2rem', color: 'var(--success)' }}>No pending supplier dues — all purchase bills settled.</p>
            )}
          </div>
        )}

        {/* ── GST REPORT ── */}
        {activeTab === 'gst' && !loading && user.role !== 'sales' && (() => {
          const monthName = new Date(2000, Number(gstMonth) - 1).toLocaleString('en-IN', { month: 'long' });
          const totalGstSales = (gstData.sales || []).flatMap(s => (s?.items || [])).reduce((a, si) => a + Number(si?.gst_amount || 0), 0);
          const totalTaxableSales = (gstData.sales || []).flatMap(s => (s?.items || [])).reduce((a, si) => a + (Number(si?.price_sold || 0) - Number(si?.discount_amount || 0)), 0);
          
          const totalGstPurchases = (gstData.purchases || []).flatMap(p => (p?.watches || [])).reduce((a, w) => a + (Number(w?.cost_price || 0) - (Number(w?.cost_price || 0) / (1 + (Number(w?.gst_rate ?? 18)/100)))), 0);
          const totalTaxablePurchases = (gstData.purchases || []).flatMap(p => (p?.watches || [])).reduce((a, w) => a + (Number(w?.cost_price || 0) / (1 + (Number(w?.gst_rate ?? 18)/100))), 0);

          const netTaxDiff = totalGstSales - totalGstPurchases;
          const isPayable = netTaxDiff > 0;
          const recoveryLedger = gstData.recovery_ledger || [];

          const totalTrappedGst = recoveryLedger.reduce((a, r) => a + Number(r.pending_gst_balance || 0), 0);
          const totalGstRecovered = recoveryLedger.reduce((a, r) => a + Number(r.gst_recovered || 0), 0);

          return (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
              
              {/* ── TOP AUDITOR SUBMISSION & NET GST RECOVERY SUMMARY CARD ── */}
              <div className="card" style={{ background: 'linear-gradient(135deg, rgba(212,175,55,0.06) 0%, rgba(20,20,25,0.95) 100%)', border: '1px solid var(--primary-gold)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem', flexWrap: 'wrap', gap: '1rem' }}>
                  <div>
                    <h2 style={{ fontSize: '1.35rem', fontWeight: 800, margin: 0, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <FileText size={22} color="var(--primary-gold)" /> GST Monthly Auditor & Tax Recovery Summary
                    </h2>
                    <p style={{ margin: '0.25rem 0 0 0', fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
                      Official GSTR-3B & GSTR-1 Reconciliation for <strong>{monthName} {gstYear}</strong>
                    </p>
                  </div>
                  <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <button className="btn btn-secondary btn-sm" onClick={() => {
                      const subject = encodeURIComponent(`GST Filing Summary - ${monthName} ${gstYear} - Smart Times`);
                      const body = encodeURIComponent(
`Dear Auditor,

Please find the official GST summary for ${monthName} ${gstYear} (Smart Times POS):

1. OUTPUT TAX (Customer Sales):
   • Invoices Count: ${(gstData.sales || []).length}
   • Taxable Value: ₹${totalTaxableSales.toFixed(2)}
   • Total GST Collected: ₹${totalGstSales.toFixed(2)}
     - CGST: ₹${(totalGstSales/2).toFixed(2)}
     - SGST: ₹${(totalGstSales/2).toFixed(2)}

2. INPUT TAX CREDIT (Supplier Purchases):
   • Purchase Bills Count: ${(gstData.purchases || []).length}
   • Taxable Base Cost: ₹${totalTaxablePurchases.toFixed(2)}
   • Total Input GST Claimable: ₹${totalGstPurchases.toFixed(2)}
     - CGST: ₹${(totalGstPurchases/2).toFixed(2)}
     - SGST: ₹${(totalGstPurchases/2).toFixed(2)}

3. NET TAX STATUS FOR GSTR-3B:
   • Status: ${isPayable ? `PAYABLE TO GOVERNMENT: ₹${netTaxDiff.toFixed(2)}` : `EXCESS INPUT CREDIT CARRY FORWARD: ₹${Math.abs(netTaxDiff).toFixed(2)}`}

4. STOCK GST RECOVERY STATUS:
   • Total GST Recovered via Sales: ₹${totalGstRecovered.toFixed(2)}
   • Unsold Stock GST Balance to Recover: ₹${totalTrappedGst.toFixed(2)}

Regards,
Smart Times Showroom Management`);
                      window.open(`mailto:?subject=${subject}&body=${body}`);
                    }} style={{ background: '#6366f1', color: '#fff', borderColor: '#6366f1', display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                      📧 Email Auditor
                    </button>

                    <button className="btn btn-secondary btn-sm" onClick={() => {
                      const oldTitle = document.title;
                      document.title = `GST_Audit_Report_${gstMonth}_${gstYear}`;
                      window.print();
                      setTimeout(() => { document.title = oldTitle; }, 1000);
                    }} style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                      <Printer size={13} /> Print Auditor PDF
                    </button>

                    <button className="btn btn-primary btn-sm" onClick={() => {
                      const rows = [
                        ['--- GSTR-1 SALES SUMMARY ---', '', '', '', '', '', '', ''],
                        ['Invoice No', 'Date', 'Customer', 'GSTIN', 'Taxable Amt', 'CGST', 'SGST', 'Total GST'],
                        ...(gstData.sales || []).flatMap(s => (s?.items || []).map(si => [
                          s.id, s.invoice_date, s.customer?.name || 'Walk-in', s.customer?.gstin || 'B2C',
                          Number(si?.price_sold || 0) - Number(si?.discount_amount || 0),
                          Number(si?.gst_amount || 0) / 2, Number(si?.gst_amount || 0) / 2, Number(si?.gst_amount || 0)
                        ])),
                        ['', '', '', '', '', '', '', ''],
                        ['--- GSTR-3B PURCHASE ITC SUMMARY ---', '', '', '', '', '', '', ''],
                        ['Bill / Invoice No', 'Date', 'Supplier', 'Units', 'Taxable Cost', 'Input CGST', 'Input SGST', 'Total Input GST'],
                        ...(gstData.purchases || []).map(p => {
                          const pCost = (p.watches || []).reduce((a, w) => a + Number(w.cost_price || 0), 0);
                          const pRate = (p.watches?.[0]?.gst_rate || 18);
                          const pTaxable = (pRate > 0) ? (pCost / (1 + (pRate / 100))) : pCost;
                          const pGst = pCost - pTaxable;
                          return [
                            p.invoice_number || p.id, p.purchase_date, p.supplier_name, (p.watches || []).length,
                            pTaxable, pGst / 2, pGst / 2, pGst
                          ];
                        }),
                        ['', '', '', '', '', '', '', ''],
                        ['--- NET AUDITOR TAX RECONCILIATION ---', '', '', '', '', '', '', ''],
                        ['Metric', 'Amount (INR)', '', '', '', '', '', ''],
                        ['Output GST (Collected from Customers)', totalGstSales, '', '', '', '', '', ''],
                        ['Input Tax Credit (Paid to Suppliers)', totalGstPurchases, '', '', '', '', '', ''],
                        ['Net Tax Payable / (Credit Carry Forward)', netTaxDiff, '', '', '', '', '', '']
                      ];
                      exportExcel(rows[1], rows.slice(2), `GST_Auditor_Master_${gstMonth}_${gstYear}`, 'GST Master');
                    }} style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }}>
                      <Download size={13} /> Export Master Excel for Auditor
                    </button>
                  </div>
                </div>

                {/* 3 Metric Summary Boxes */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1rem' }}>
                  <div style={{ background: 'var(--surface-color)', padding: '1rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                      Output GST (Sales)
                    </div>
                    <div style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--primary-gold)', marginTop: '0.35rem' }}>
                      {fmt(totalGstSales)}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '0.25rem' }}>
                      Collected from customers ({(gstData.sales || []).length} Invoices)
                    </div>
                  </div>

                  <div style={{ background: 'var(--surface-color)', padding: '1rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-color)' }}>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                      Input Tax Credit (Purchases)
                    </div>
                    <div style={{ fontSize: '1.4rem', fontWeight: 800, color: '#3b82f6', marginTop: '0.35rem' }}>
                      {fmt(totalGstPurchases)}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '0.25rem' }}>
                      Paid to suppliers ({(gstData.purchases || []).length} Supplier Bills)
                    </div>
                  </div>

                  <div style={{ background: 'var(--surface-color)', padding: '1rem', borderRadius: 'var(--radius-sm)', border: `1px solid ${isPayable ? 'rgba(239, 68, 68, 0.4)' : 'rgba(34, 197, 94, 0.4)'}` }}>
                    <div style={{ fontSize: '0.8rem', color: isPayable ? '#ef4444' : 'var(--success)', textTransform: 'uppercase', letterSpacing: '0.5px', fontWeight: 700 }}>
                      {isPayable ? '🔴 Net GST Payable to Govt' : '🔵 Carry-Forward Credit Balance'}
                    </div>
                    <div style={{ fontSize: '1.4rem', fontWeight: 800, color: isPayable ? '#ef4444' : 'var(--success)', marginTop: '0.35rem' }}>
                      {fmt(Math.abs(netTaxDiff))}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '0.25rem' }}>
                      {isPayable 
                        ? 'Amount to pay in GSTR-3B before 20th' 
                        : 'No cash tax to pay; balance rolls over to next month'}
                    </div>
                  </div>
                </div>
              </div>

              {/* ── SUPPLIER BILL-WISE GST RECOVERY & BALANCE TRACKER ── */}
              <div className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                  <div>
                    <h3 style={{ margin: 0 }}>Supplier Bill-wise GST Recovery & Balance Tracker</h3>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                      Track how much GST was paid on each purchase bill, how much has been recovered from watch sales, and what balance remains trapped in unsold stock.
                    </span>
                  </div>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="btn btn-secondary btn-sm" onClick={() => exportCSV(
                      ['Supplier', 'Bill / Invoice No', 'Purchase Date', 'Total Units Bought', 'Units Sold', 'Unsold Units', 'Total GST Paid Upfront', 'GST Recovered from Sales', 'Pending GST Balance in Stock', 'Linked Sales Invoices'],
                      recoveryLedger.map(r => [
                        r.supplier_name, r.invoice_number, r.purchase_date, r.total_units, r.sold_units, r.unsold_units,
                        r.total_gst_paid, r.gst_recovered, r.pending_gst_balance, (r.sales_invoices || []).join(', ')
                      ]),
                      'gst_supplier_recovery_ledger'
                    )}>
                      <Download size={13} /> Export Recovery CSV
                    </button>
                    <button className="btn btn-primary btn-sm" onClick={() => exportExcel(
                      ['Supplier', 'Bill / Invoice No', 'Purchase Date', 'Total Units Bought', 'Units Sold', 'Unsold Units', 'Total GST Paid Upfront', 'GST Recovered from Sales', 'Pending GST Balance in Stock', 'Linked Sales Invoices'],
                      recoveryLedger.map(r => [
                        r.supplier_name, r.invoice_number, r.purchase_date, r.total_units, r.sold_units, r.unsold_units,
                        r.total_gst_paid, r.gst_recovered, r.pending_gst_balance, (r.sales_invoices || []).join(', ')
                      ]),
                      'gst_supplier_recovery_ledger', 'GST Recovery'
                    )}>
                      <Download size={13} /> Export Recovery Excel
                    </button>
                  </div>
                </div>

                <div style={{ overflowX: 'auto' }}>
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Supplier</th>
                        <th>Supplier Bill No</th>
                        <th>Bill Date</th>
                        <th>Units (Bought / Sold)</th>
                        <th>Total GST Paid Upfront</th>
                        <th>GST Recovered</th>
                        <th>Trapped GST in Stock</th>
                        <th>Linked Sales Invoices</th>
                        <th style={{ textAlign: 'center' }}>Doc</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recoveryLedger.length > 0 ? recoveryLedger.map((r, idx) => {
                        const pctRecovered = r.total_units > 0 ? Math.round((r.sold_units / r.total_units) * 100) : 0;
                        return (
                          <tr key={idx}>
                            <td><strong>{r.supplier_name}</strong></td>
                            <td style={{ fontFamily: 'monospace', fontWeight: 600 }}>{r.invoice_number || '—'}</td>
                            <td>{r.purchase_date}</td>
                            <td>
                              <span style={{ fontWeight: 600 }}>{r.sold_units} sold</span> of {r.total_units} units
                              <div style={{ background: 'var(--border-color)', height: '5px', borderRadius: '3px', marginTop: '4px', overflow: 'hidden', width: '100px' }}>
                                <div style={{ background: 'var(--success)', height: '100%', width: `${pctRecovered}%` }}></div>
                              </div>
                            </td>
                            <td style={{ fontWeight: 600, color: '#3b82f6' }}>{fmt(r.total_gst_paid)}</td>
                            <td style={{ fontWeight: 600, color: 'var(--success)' }}>{fmt(r.gst_recovered)}</td>
                            <td>
                              <span style={{ 
                                fontWeight: 700, 
                                color: r.pending_gst_balance > 0 ? '#eab308' : 'var(--success)',
                                background: r.pending_gst_balance > 0 ? 'rgba(234, 179, 8, 0.1)' : 'rgba(34, 197, 94, 0.1)',
                                padding: '2px 8px',
                                borderRadius: '4px'
                              }}>
                                {r.pending_gst_balance > 0 ? `₹${r.pending_gst_balance.toFixed(2)} (Pending)` : '✓ Fully Recovered'}
                              </span>
                            </td>
                            <td>
                              {(r.sales_invoices && r.sales_invoices.length > 0) ? (
                                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '3px' }}>
                                  {r.sales_invoices.map(sId => (
                                    <span key={sId} style={{ fontFamily: 'monospace', fontSize: '0.72rem', background: 'rgba(212, 175, 55, 0.15)', color: 'var(--primary-gold)', padding: '1px 5px', borderRadius: '3px' }}>
                                      {sId}
                                    </span>
                                  ))}
                                </div>
                              ) : (
                                <span style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>No units sold yet</span>
                              )}
                            </td>
                            <td style={{ textAlign: 'center' }}>
                              {r.bill_file ? (
                                <button
                                  type="button"
                                  onClick={() => setViewingBillFile({ file: r.bill_file, title: `${r.supplier_name} - ${r.invoice_number}` })}
                                  style={{
                                    background: 'rgba(217, 119, 6, 0.15)',
                                    border: '1px solid var(--primary-gold)',
                                    color: 'var(--primary-gold)',
                                    borderRadius: '4px',
                                    padding: '2px 6px',
                                    fontSize: '0.72rem',
                                    cursor: 'pointer',
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '3px'
                                  }}
                                  title="Click to view original supplier invoice document"
                                >
                                  <FileText size={11} /> Bill
                                </button>
                              ) : (
                                <span style={{ color: 'var(--text-secondary)', fontSize: '0.75rem' }}>—</span>
                              )}
                            </td>
                          </tr>
                        );
                      }) : (
                        <tr><td colSpan="9" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>No supplier purchases for this month to track.</td></tr>
                      )}
                    </tbody>
                    {recoveryLedger.length > 0 && (
                      <tfoot>
                        <tr style={{ fontWeight: 700, background: 'var(--surface-card)' }}>
                          <td colSpan="4">Total Recovery Balance</td>
                          <td style={{ color: '#3b82f6' }}>{fmt(recoveryLedger.reduce((a, r) => a + Number(r.total_gst_paid || 0), 0))}</td>
                          <td style={{ color: 'var(--success)' }}>{fmt(totalGstRecovered)}</td>
                          <td style={{ color: '#eab308' }}>{fmt(totalTrappedGst)}</td>
                          <td colSpan="2"></td>
                        </tr>
                      </tfoot>
                    )}
                  </table>
                </div>
              </div>

              {/* ── GST OUTPUT REPORT (SALES) ── */}
              <div className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
                  <h3>GST Output Report (Sales) — {monthName} {gstYear}</h3>
                  <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <button className="btn btn-secondary btn-sm" onClick={() => exportCSV(
                      ['Invoice No', 'Date', 'Customer', 'GSTIN', 'Watch Serial', 'HSN', 'Taxable Value', 'CGST', 'SGST', 'Total GST', 'Invoice Total'],
                      (gstData.sales || []).flatMap(s => (s?.items || []).map(si => [
                        s.id, s.invoice_date, s.customer?.name, s.customer?.gstin || 'N/A',
                        si.watch_id, si.watch?.hsn_code || '9102', (Number(si?.price_sold || 0) - Number(si?.discount_amount || 0)), Number(si?.gst_amount || 0) / 2, Number(si?.gst_amount || 0) / 2, Number(si?.gst_amount || 0), s.net_amount
                      ])),
                      'gst_output_report'
                    )}><Download size={13} /> Export CSV</button>
                    <button className="btn btn-primary btn-sm" onClick={() => exportExcel(
                      ['Invoice No', 'Date', 'Customer', 'GSTIN', 'Watch Serial', 'HSN', 'Taxable Value', 'CGST', 'SGST', 'Total GST', 'Invoice Total'],
                      (gstData.sales || []).flatMap(s => (s?.items || []).map(si => [
                        s.id, s.invoice_date, s.customer?.name, s.customer?.gstin || 'N/A',
                        si.watch_id, si.watch?.hsn_code || '9102', (Number(si?.price_sold || 0) - Number(si?.discount_amount || 0)), Number(si?.gst_amount || 0) / 2, Number(si?.gst_amount || 0) / 2, Number(si?.gst_amount || 0), s.net_amount
                      ])),
                      'gst_output_report', 'GST Output Report'
                    )}><Download size={13} /> Export Excel</button>
                  </div>
                </div>

                <div style={{ overflowX: 'auto' }}>
                  <table className="data-table">
                    <thead><tr>
                      <th>Invoice No</th><th>Date</th><th>Customer</th><th>Watch</th>
                      <th>Taxable Amt</th><th>CGST</th><th>SGST</th><th>Total GST</th>
                    </tr></thead>
                    <tbody>
                      {(gstData.sales && gstData.sales.length > 0) ? gstData.sales.flatMap(s => (s?.items || []).map((si, idx) => (
                        <tr key={`${s.id}-${idx}`}>
                          <td style={{ fontFamily: 'monospace', fontSize: '0.82rem' }}>{s.id}</td>
                          <td>{s.invoice_date}</td>
                          <td>{s.customer?.name}</td>
                          <td style={{ fontFamily: 'monospace', fontSize: '0.82rem' }}>{si.watch_id}</td>
                          <td>{fmt(Number(si?.price_sold || 0) - Number(si?.discount_amount || 0))}</td>
                          <td>{fmt(Number(si?.gst_amount || 0) / 2)}</td>
                          <td>{fmt(Number(si?.gst_amount || 0) / 2)}</td>
                          <td style={{ fontWeight: 700, color: 'var(--primary-gold)' }}>{fmt(Number(si?.gst_amount || 0))}</td>
                        </tr>
                      ))) : (
                        <tr><td colSpan="8" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>No GST sales invoices for selected month/year.</td></tr>
                      )}
                    </tbody>
                    {(gstData.sales && gstData.sales.length > 0) && (
                      <tfoot>
                        <tr style={{ fontWeight: 700 }}>
                          <td colSpan="4">Total Output</td>
                          <td>{fmt(totalTaxableSales)}</td>
                          <td>{fmt(totalGstSales / 2)}</td>
                          <td>{fmt(totalGstSales / 2)}</td>
                          <td style={{ color: 'var(--primary-gold)' }}>{fmt(totalGstSales)}</td>
                        </tr>
                      </tfoot>
                    )}
                  </table>
                </div>
              </div>

              {/* ── GST INPUT REPORT (PURCHASES) ── */}
              <div className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
                  <h3>GST Input Report (Purchases) — {monthName} {gstYear}</h3>
                  <div style={{ display: 'flex', gap: '0.5rem' }}>
                    <button className="btn btn-secondary btn-sm" onClick={() => exportCSV(
                      ['Supplier Bill No', 'Date', 'Supplier', 'Watch Serial', 'HSN', 'Taxable Value', 'CGST', 'SGST', 'Total GST', 'Total Amount'],
                      (gstData.purchases || []).flatMap(p => (p?.watches || []).map(w => {
                         const taxableValue = (Number(w?.cost_price || 0) / (1 + (Number(w?.gst_rate ?? 18)/100)));
                         const totalGst = (Number(w?.cost_price || 0) - taxableValue);
                         return [
                           p.invoice_number || p.id, p.purchase_date, p.supplier_name,
                           w.id, w.hsn_code || '9102', taxableValue, totalGst / 2, totalGst / 2, totalGst, Number(w?.cost_price || 0)
                         ];
                      })),
                      'gst_input_report'
                    )}><Download size={13} /> Export CSV</button>
                    <button className="btn btn-primary btn-sm" onClick={() => exportExcel(
                      ['Supplier Bill No', 'Date', 'Supplier', 'Watch Serial', 'HSN', 'Taxable Value', 'CGST', 'SGST', 'Total GST', 'Total Amount'],
                      (gstData.purchases || []).flatMap(p => (p?.watches || []).map(w => {
                         const taxableValue = (Number(w?.cost_price || 0) / (1 + (Number(w?.gst_rate ?? 18)/100)));
                         const totalGst = (Number(w?.cost_price || 0) - taxableValue);
                         return [
                           p.invoice_number || p.id, p.purchase_date, p.supplier_name,
                           w.id, w.hsn_code || '9102', taxableValue, totalGst / 2, totalGst / 2, totalGst, Number(w?.cost_price || 0)
                         ];
                      })),
                      'gst_input_report', 'GST Input Report'
                    )}><Download size={13} /> Export Excel</button>
                  </div>
                </div>

                <div style={{ overflowX: 'auto' }}>
                  <table className="data-table">
                    <thead><tr>
                      <th>Supplier Bill No</th><th>Date</th><th>Supplier</th><th>Watch</th>
                      <th>Taxable Amt</th><th>CGST</th><th>SGST</th><th>Total GST</th>
                    </tr></thead>
                    <tbody>
                      {(gstData.purchases && gstData.purchases.length > 0) ? gstData.purchases.flatMap(p => (p?.watches || []).map((w, idx) => {
                        const taxableValue = (Number(w?.cost_price || 0) / (1 + (Number(w?.gst_rate ?? 18)/100)));
                        const totalGst = (Number(w?.cost_price || 0) - taxableValue);
                        return (
                          <tr key={`${p.id}-${idx}`}>
                            <td style={{ fontFamily: 'monospace', fontSize: '0.82rem' }}>{p.invoice_number || p.id}</td>
                            <td>{p.purchase_date}</td>
                            <td>{p.supplier_name}</td>
                            <td style={{ fontFamily: 'monospace', fontSize: '0.82rem' }}>{w.id}</td>
                            <td>{fmt(taxableValue)}</td>
                            <td>{fmt(totalGst / 2)}</td>
                            <td>{fmt(totalGst / 2)}</td>
                            <td style={{ fontWeight: 700, color: 'var(--primary-gold)' }}>{fmt(totalGst)}</td>
                          </tr>
                        );
                      })) : (
                        <tr><td colSpan="8" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>No GST purchase invoices for selected month/year.</td></tr>
                      )}
                    </tbody>
                    {(gstData.purchases && gstData.purchases.length > 0) && (
                      <tfoot>
                        <tr style={{ fontWeight: 700 }}>
                          <td colSpan="4">Total Input</td>
                          <td>{fmt(totalTaxablePurchases)}</td>
                          <td>{fmt(totalGstPurchases / 2)}</td>
                          <td>{fmt(totalGstPurchases / 2)}</td>
                          <td style={{ color: 'var(--primary-gold)' }}>{fmt(totalGstPurchases)}</td>
                        </tr>
                      </tfoot>
                    )}
                  </table>
                </div>
              </div>

            </div>
          );
        })()}

        {/* Printable Invoice View / Reprint Modal Overlay */}
        {selectedInvoice && (
          <div className="modal-overlay no-print" style={{ overflowY: 'auto', padding: '2rem 1rem' }}>
            <div style={{ background: '#fff', borderRadius: '8px', maxWidth: '850px', margin: '0 auto', boxShadow: '0 20px 40px rgba(0,0,0,0.4)', padding: '1rem' }}>
              <PrintableInvoice
                invoice={selectedInvoice}
                storeSettings={storeSettings}
                currentUser={user}
                onClose={() => setSelectedInvoice(null)}
                onPrint={() => window.print()}
              />
            </div>
          </div>
        )}

        {/* Supplier Bill Document Modal */}
        {viewingBillFile && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.75)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000,
            padding: '1rem'
          }}>
            <div style={{
              background: 'var(--surface-color)',
              border: '1px solid var(--border-color)',
              borderRadius: 'var(--radius-md)',
              width: '100%',
              maxWidth: '900px',
              height: '85vh',
              display: 'flex',
              flexDirection: 'column',
              overflow: 'hidden',
              boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.5)'
            }}>
              <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '1rem 1.25rem',
                borderBottom: '1px solid var(--border-color)'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <FileText size={18} color="var(--primary-gold)" />
                  <h3 style={{ margin: 0, fontSize: '1.1rem' }}>Supplier Bill: {viewingBillFile.title}</h3>
                </div>
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={() => setViewingBillFile(null)}
                  style={{ padding: '0.3rem 0.6rem' }}
                >
                  ✕
                </button>
              </div>

              <div style={{ flex: 1, overflow: 'auto', padding: '1rem', display: 'flex', justifyContent: 'center', alignItems: 'center', background: '#0b0f19' }}>
                {viewingBillFile.file.startsWith('data:application/pdf') ? (
                  <iframe
                    src={viewingBillFile.file}
                    title="Supplier Bill PDF"
                    style={{ width: '100%', height: '100%', border: 'none', borderRadius: '4px' }}
                  />
                ) : (
                  <img
                    src={viewingBillFile.file}
                    alt="Supplier Bill"
                    style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', borderRadius: '4px' }}
                  />
                )}
              </div>

              <div style={{ padding: '0.75rem 1.25rem', borderTop: '1px solid var(--border-color)', display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
                <a
                  href={viewingBillFile.file}
                  download={`supplier_bill_${viewingBillFile.title.replace(/\s+/g, '_')}`}
                  className="btn btn-primary btn-sm"
                  style={{ textDecoration: 'none' }}
                >
                  Download Bill
                </a>
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={() => setViewingBillFile(null)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default Reports;
