<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Domains\Memberships\Services\MembershipLifecycleService;
use Illuminate\Console\Command;

final class MembershipEscalationsCommand extends Command
{
    protected $signature = 'gms:membership-escalations {--date= : As-of date Y-m-d}';

    protected $description = 'Open or upgrade membership escalations (E0–E5)';

    public function handle(MembershipLifecycleService $lifecycle): int
    {
        $date = $this->option('date');
        $date = is_string($date) && $date !== '' ? $date : null;

        $result = $lifecycle->syncEscalations($date);

        $this->info("Opened {$result['opened']} escalation(s); upgraded {$result['upgraded']}.");

        return self::SUCCESS;
    }
}
