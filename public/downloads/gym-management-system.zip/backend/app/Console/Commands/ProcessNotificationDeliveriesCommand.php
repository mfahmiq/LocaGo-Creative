<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Domains\Notifications\Contracts\NotificationDeliveryRepositoryInterface;
use App\Domains\Notifications\Jobs\DeliverNotificationJob;
use App\Domains\Notifications\Models\NotificationDelivery;
use Illuminate\Console\Command;

final class ProcessNotificationDeliveriesCommand extends Command
{
    protected $signature = 'gms:process-notification-deliveries {--limit=100 : Max deliveries to process}';

    protected $description = 'Dispatch due scheduled and retryable notification deliveries';

    public function handle(NotificationDeliveryRepositoryInterface $deliveries): int
    {
        $limit = max(1, (int) $this->option('limit'));
        $queued = 0;

        foreach ($deliveries->findDueScheduled($limit) as $delivery) {
            DeliverNotificationJob::dispatch($delivery->id)->onQueue(
                (string) config('gms.notifications.queue', 'notifications')
            );
            $queued++;
        }

        foreach ($deliveries->findDueForRetry($limit) as $delivery) {
            $deliveries->updateDelivery($delivery, [
                'status' => NotificationDelivery::STATUS_QUEUED,
            ]);
            DeliverNotificationJob::dispatch($delivery->id)->onQueue(
                (string) config('gms.notifications.queue', 'notifications')
            );
            $queued++;
        }

        $this->info("Queued {$queued} notification delivery job(s).");

        return self::SUCCESS;
    }
}
