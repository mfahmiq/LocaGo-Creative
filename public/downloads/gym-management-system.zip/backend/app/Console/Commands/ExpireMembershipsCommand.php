<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Domains\Memberships\Services\MembershipLifecycleService;
use Illuminate\Console\Command;

final class ExpireMembershipsCommand extends Command
{
    protected $signature = 'gms:expire-memberships {--date= : As-of date Y-m-d}';

    protected $description = 'Move past-due memberships into grace, then expire after the grace window';

    public function handle(MembershipLifecycleService $lifecycle): int
    {
        $date = $this->option('date');
        $date = is_string($date) && $date !== '' ? $date : null;

        $result = $lifecycle->expireMemberships($date);

        $this->info("Moved {$result['grace']} membership(s) to grace; expired {$result['expired']}.");

        return self::SUCCESS;
    }
}
