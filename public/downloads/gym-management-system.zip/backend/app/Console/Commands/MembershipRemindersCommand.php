<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Domains\Memberships\Services\MembershipLifecycleService;
use Illuminate\Console\Command;

final class MembershipRemindersCommand extends Command
{
    protected $signature = 'gms:membership-reminders {--date= : As-of date Y-m-d}';

    protected $description = 'Send membership expiry reminder notifications (T-14/7/3/1)';

    public function handle(MembershipLifecycleService $lifecycle): int
    {
        $date = $this->option('date');
        $date = is_string($date) && $date !== '' ? $date : null;

        $result = $lifecycle->sendReminders($date);

        $this->info("Sent reminders for {$result['sent']} membership(s); skipped {$result['skipped']}.");

        return self::SUCCESS;
    }
}
