<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Domains\Tenancy\Services\TenantLifecycleService;
use Illuminate\Console\Command;

final class ExpireTrialsCommand extends Command
{
    protected $signature = 'gms:expire-trials';

    protected $description = 'Suspend tenants whose trial period has ended';

    public function handle(TenantLifecycleService $lifecycle): int
    {
        $count = $lifecycle->expireTrials();

        $this->info("Expired {$count} trial tenant(s).");

        return self::SUCCESS;
    }
}
