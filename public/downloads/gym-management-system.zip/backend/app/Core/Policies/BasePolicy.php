<?php

declare(strict_types=1);

namespace App\Core\Policies;

use App\Domains\Identity\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Foundation\Auth\User as Authenticatable;

/**
 * Base policy helpers for portal + tenant-aware authorization.
 */
abstract class BasePolicy
{
    use HandlesAuthorization;

    protected function denyWithReason(string $message = 'This action is unauthorized.'): bool
    {
        return false;
    }

    protected function sameTenant(?Authenticatable $user, object $model): bool
    {
        $userTenantId = data_get($user, 'tenant_id');
        $modelTenantId = data_get($model, 'tenant_id');

        if ($userTenantId === null || $modelTenantId === null) {
            return false;
        }

        return (int) $userTenantId === (int) $modelTenantId;
    }

    protected function hasPermission(?Authenticatable $user, string $permission): bool
    {
        return $user instanceof User && $user->hasPermission($permission);
    }

    protected function branchAllowed(?Authenticatable $user, ?int $branchId): bool
    {
        if (! $user instanceof User || $branchId === null) {
            return true;
        }

        return $user->canAccessBranch($branchId);
    }
}
