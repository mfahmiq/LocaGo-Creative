<?php

declare(strict_types=1);

namespace App\Core\Mail;

use App\Core\Context\TenantContext;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

/**
 * Base mailable. Domain mailables should queue by default.
 */
abstract class TenantMailable extends Mailable implements ShouldQueue
{
    use Queueable;
    use SerializesModels;

    public ?int $tenantId = null;

    public function __construct()
    {
        $this->tenantId = TenantContext::idOrNull();
        $this->onQueue(config('gms.queues.default', 'default'));
    }

    abstract public function envelope(): Envelope;

    abstract public function content(): Content;
}
