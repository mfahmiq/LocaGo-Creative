<?php

declare(strict_types=1);

namespace App\Core\Notifications;

use App\Core\Context\TenantContext;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Notification;

/**
 * Base notification (mail + database/in-app channels).
 */
abstract class BaseNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public ?int $tenantId = null;

    public function __construct()
    {
        $this->tenantId = TenantContext::idOrNull();
        $this->onQueue(config('gms.queues.high', 'high'));
    }

    /**
     * @return list<string>
     */
    public function via(object $notifiable): array
    {
        return ['mail', 'database'];
    }
}
