<?php

declare(strict_types=1);

namespace App\Core\Exceptions;

use Exception;
use Symfony\Component\HttpFoundation\Response;

/**
 * Domain/business rule failure mapped to an API error response.
 */
class DomainException extends Exception
{
    /**
     * @param  array<string, mixed>  $context
     */
    public function __construct(
        string $message,
        protected string $errorCode = 'domain_error',
        int $code = Response::HTTP_UNPROCESSABLE_ENTITY,
        ?Exception $previous = null,
        protected array $context = []
    ) {
        parent::__construct($message, $code, $previous);
    }

    public function errorCode(): string
    {
        return $this->errorCode;
    }

    /**
     * @return array<string, mixed>
     */
    public function context(): array
    {
        return $this->context;
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        $payload = [
            'message' => $this->getMessage(),
            'code' => $this->errorCode(),
            'errors' => [],
        ];

        if ($this->context !== []) {
            $payload['data'] = $this->context;
        }

        return $payload;
    }
}
