<?php

declare(strict_types=1);

namespace App\Core\Http;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

/**
 * Shared list-query conventions for web + future mobile clients.
 *
 * Query params:
 * - page, per_page
 * - sort (field), direction (asc|desc)
 * - updated_since (ISO8601 / Y-m-d H:i:s) for delta sync
 * - q / search (when allowlisted)
 */
final class ApiQuery
{
    public static function perPage(Request $request): int
    {
        $default = (int) config('gms.api.pagination_default', 10);
        $max = (int) config('gms.api.pagination_max', 100);
        $requested = (int) $request->query('per_page', $default);

        return max(1, min($requested > 0 ? $requested : $default, $max));
    }

    /**
     * @param  list<string>  $allowed
     */
    public static function applySort(Builder $query, Request $request, array $allowed, string $default, string $defaultDirection = 'desc'): Builder
    {
        $sort = (string) $request->query('sort', $default);
        if (! in_array($sort, $allowed, true)) {
            $sort = $default;
        }

        $direction = strtolower((string) $request->query('direction', $defaultDirection));
        if (! in_array($direction, ['asc', 'desc'], true)) {
            $direction = $defaultDirection;
        }

        return $query->orderBy($sort, $direction);
    }

    public static function applyUpdatedSince(Builder $query, Request $request, string $column = 'updated_at'): Builder
    {
        $since = $request->query('updated_since');
        if (! is_string($since) || trim($since) === '') {
            return $query;
        }

        return $query->where($column, '>', $since);
    }

    /**
     * @return array{current_page: int, per_page: int, total: int, last_page: int, has_more: bool}
     */
    public static function meta(\Illuminate\Contracts\Pagination\LengthAwarePaginator $paginator): array
    {
        return [
            'current_page' => $paginator->currentPage(),
            'per_page' => $paginator->perPage(),
            'total' => $paginator->total(),
            'last_page' => $paginator->lastPage(),
            'has_more' => $paginator->hasMorePages(),
        ];
    }
}
