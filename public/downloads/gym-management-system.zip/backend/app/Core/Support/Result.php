<?php

declare(strict_types=1);

namespace App\Core\Support;

/**
 * Lightweight result object for service/action outcomes.
 *
 * @template T
 */
final class Result
{
    /**
     * @param  T  $value
     */
    private function __construct(
        private readonly bool $ok,
        private readonly mixed $value = null,
        private readonly ?string $message = null,
        private readonly ?string $errorCode = null
    ) {}

    /**
     * @template TValue
     *
     * @param  TValue  $value
     * @return self<TValue>
     */
    public static function success(mixed $value = null): self
    {
        return new self(true, $value);
    }

    /**
     * @return self<null>
     */
    public static function failure(string $message, string $errorCode = 'failed'): self
    {
        return new self(false, null, $message, $errorCode);
    }

    public function ok(): bool
    {
        return $this->ok;
    }

    public function failed(): bool
    {
        return ! $this->ok;
    }

    public function value(): mixed
    {
        return $this->value;
    }

    public function message(): ?string
    {
        return $this->message;
    }

    public function errorCode(): ?string
    {
        return $this->errorCode;
    }
}
