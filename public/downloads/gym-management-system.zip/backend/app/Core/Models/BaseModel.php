<?php

declare(strict_types=1);

namespace App\Core\Models;

use App\Core\Models\Concerns\HasAuditColumns;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

abstract class BaseModel extends Model
{
    use HasAuditColumns;
    use SoftDeletes;

    public $timestamps = true;

    protected $dateFormat = 'Y-m-d H:i:s.v';
}
