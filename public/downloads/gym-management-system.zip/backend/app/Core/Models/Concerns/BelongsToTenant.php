<?php

declare(strict_types=1);

namespace App\Core\Models\Concerns;

use App\Core\Context\TenantContext;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

/**
 * @mixin Model
 */
trait BelongsToTenant
{
    public static function bootBelongsToTenant(): void
    {
        static::creating(function (Model $model): void {
            if ($model->getAttribute('tenant_id') === null && TenantContext::check()) {
                $model->setAttribute('tenant_id', TenantContext::id());
            }
        });

        static::addGlobalScope('tenant', function (Builder $builder): void {
            if (TenantContext::check()) {
                $builder->where(
                    $builder->getModel()->getTable().'.tenant_id',
                    TenantContext::id()
                );
            }
        });
    }
}
