<?php

declare(strict_types=1);

namespace App\Core\Models\Concerns;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

/**
 * Sets created_by / updated_by / deleted_by from the authenticated user.
 *
 * Domain models that use this trait are expected to have these columns.
 *
 * @mixin Model
 */
trait HasAuditColumns
{
    public static function bootHasAuditColumns(): void
    {
        static::creating(function (Model $model): void {
            $userId = Auth::id();

            if ($userId === null) {
                return;
            }

            if ($model->getAttribute('created_by') === null) {
                $model->setAttribute('created_by', $userId);
            }

            $model->setAttribute('updated_by', $userId);
        });

        static::updating(function (Model $model): void {
            $userId = Auth::id();

            if ($userId !== null) {
                $model->setAttribute('updated_by', $userId);
            }
        });

        static::deleting(function (Model $model): void {
            if (method_exists($model, 'isForceDeleting') && $model->isForceDeleting()) {
                return;
            }

            $userId = Auth::id();

            if ($userId === null) {
                return;
            }

            $model->setAttribute('deleted_by', $userId);
            $model->saveQuietly();
        });
    }
}
