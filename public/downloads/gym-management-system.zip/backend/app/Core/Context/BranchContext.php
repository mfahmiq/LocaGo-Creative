<?php

declare(strict_types=1);

namespace App\Core\Context;

use RuntimeException;

/**
 * Request-scoped active branch binder for multi-branch operations.
 */
final class BranchContext
{
    private static ?int $id = null;

    public static function set(int $id): void
    {
        self::$id = $id;
    }

    public static function clear(): void
    {
        self::$id = null;
    }

    public static function check(): bool
    {
        return self::$id !== null;
    }

    public static function id(): int
    {
        if (self::$id === null) {
            throw new RuntimeException('Branch context is not set.');
        }

        return self::$id;
    }

    public static function idOrNull(): ?int
    {
        return self::$id;
    }
}
