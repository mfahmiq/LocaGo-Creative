<?php

declare(strict_types=1);

namespace App\Core\Context;

use RuntimeException;

/**
 * Request-scoped tenant binder for multi-tenant isolation.
 */
final class TenantContext
{
    private static ?int $id = null;

    private static ?string $slug = null;

    /** @var array<string, mixed> */
    private static array $attributes = [];

    public static function set(int $id, string $slug, array $attributes = []): void
    {
        self::$id = $id;
        self::$slug = $slug;
        self::$attributes = $attributes;
    }

    public static function clear(): void
    {
        self::$id = null;
        self::$slug = null;
        self::$attributes = [];
    }

    public static function check(): bool
    {
        return self::$id !== null;
    }

    public static function id(): int
    {
        if (self::$id === null) {
            throw new RuntimeException('Tenant context is not set.');
        }

        return self::$id;
    }

    public static function idOrNull(): ?int
    {
        return self::$id;
    }

    public static function slug(): ?string
    {
        return self::$slug;
    }

    /**
     * @return array<string, mixed>
     */
    public static function attributes(): array
    {
        return self::$attributes;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        return self::$attributes[$key] ?? $default;
    }
}
