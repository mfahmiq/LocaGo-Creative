<?php

declare(strict_types=1);

namespace App\Core\Contracts\Actions;

interface ActionInterface
{
    /**
     * Execute a single application use-case.
     *
     * @param  mixed  ...$args
     */
    public function execute(mixed ...$args): mixed;
}
