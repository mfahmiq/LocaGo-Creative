<?php

declare(strict_types=1);

namespace App\Core\Events;

use App\Core\Context\TenantContext;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * Base domain event. Always carries tenant_id for async consumers.
 */
abstract class DomainEvent
{
    use Dispatchable;
    use SerializesModels;

    public readonly ?int $tenantId;

    public function __construct()
    {
        $this->tenantId = TenantContext::idOrNull();
    }
}
