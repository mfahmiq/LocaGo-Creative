<?php

declare(strict_types=1);

namespace App\Core\Observers;

use Illuminate\Database\Eloquent\Model;

/**
 * Base observer. Domain observers should extend this for consistency.
 */
abstract class BaseObserver
{
    public function creating(Model $model): void
    {
    }

    public function created(Model $model): void
    {
    }

    public function updating(Model $model): void
    {
    }

    public function updated(Model $model): void
    {
    }

    public function deleting(Model $model): void
    {
    }

    public function deleted(Model $model): void
    {
    }

    public function restored(Model $model): void
    {
    }

    public function forceDeleted(Model $model): void
    {
    }
}
