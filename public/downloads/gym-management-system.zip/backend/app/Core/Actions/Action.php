<?php

declare(strict_types=1);

namespace App\Core\Actions;

use App\Core\Contracts\Actions\ActionInterface;
use Illuminate\Support\Facades\DB;

/**
 * Single-purpose use-case entry point.
 *
 * Prefer Actions for write use-cases that must stay transactional and testable.
 */
abstract class Action implements ActionInterface
{
    /**
     * Run the action inside a database transaction.
     *
     * @template TReturn
     *
     * @param  callable(): TReturn  $callback
     * @return TReturn
     */
    protected function transaction(callable $callback): mixed
    {
        return DB::transaction($callback);
    }
}
