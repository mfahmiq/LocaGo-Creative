<?php

declare(strict_types=1);

namespace App\Core\Listeners;

/**
 * Base listener for domain events.
 */
abstract class BaseListener
{
    /**
     * Handle the event.
     */
    abstract public function handle(object $event): void;
}
