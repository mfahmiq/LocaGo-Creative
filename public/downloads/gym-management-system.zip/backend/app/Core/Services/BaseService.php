<?php

declare(strict_types=1);

namespace App\Core\Services;

/**
 * Application service base.
 *
 * Services orchestrate repositories, actions, and infrastructure.
 * Keep services free of HTTP concerns (no Request/Response).
 */
abstract class BaseService
{
}
