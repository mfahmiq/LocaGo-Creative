<?php

declare(strict_types=1);

namespace App\Core\Jobs;

use App\Core\Context\TenantContext;
use App\Core\Jobs\Middleware\SetTenantContext;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

/**
 * Base queued job with tenant context restoration.
 */
abstract class TenantAwareJob implements ShouldQueue
{
    use Dispatchable;
    use InteractsWithQueue;
    use Queueable;
    use SerializesModels;

    public ?int $tenantId = null;

    public ?string $tenantSlug = null;

    /** @var array<string, mixed> */
    public array $tenantAttributes = [];

    public int $tries = 3;

    public function __construct()
    {
        $this->tenantId = TenantContext::idOrNull();
        $this->tenantSlug = TenantContext::slug();
        $this->tenantAttributes = TenantContext::attributes();
        $this->onQueue($this->queueName());
    }

    /**
     * @return list<object>
     */
    public function middleware(): array
    {
        return [new SetTenantContext];
    }

    protected function queueName(): string
    {
        return 'default';
    }
}
