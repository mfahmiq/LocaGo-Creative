<?php

declare(strict_types=1);

namespace App\Core\Jobs\Middleware;

use App\Core\Context\TenantContext;
use Closure;

/**
 * Restores tenant context for queued jobs that implement TenantAware.
 */
final class SetTenantContext
{
    /**
     * @param  object{tenantId?: int|null, tenantSlug?: string|null, tenantAttributes?: array<string, mixed>}  $job
     */
    public function handle(object $job, Closure $next): mixed
    {
        $tenantId = property_exists($job, 'tenantId') ? $job->tenantId : null;

        if (is_int($tenantId)) {
            $slug = property_exists($job, 'tenantSlug') && is_string($job->tenantSlug)
                ? $job->tenantSlug
                : (string) $tenantId;

            $attributes = property_exists($job, 'tenantAttributes') && is_array($job->tenantAttributes)
                ? $job->tenantAttributes
                : [];

            TenantContext::set($tenantId, $slug, $attributes);
        }

        try {
            return $next($job);
        } finally {
            TenantContext::clear();
        }
    }
}
