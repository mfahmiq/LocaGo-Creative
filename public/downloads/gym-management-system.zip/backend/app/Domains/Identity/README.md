﻿# Identity Domain

## Feature 1 — Admin Login (complete)

Endpoints:
- `POST /api/v1/admin/auth/login` — requires `X-Tenant-Slug`
- `GET /api/v1/admin/auth/me` — Bearer token + tenant header
- `POST /api/v1/admin/auth/logout` — Bearer token + tenant header

Demo credentials (seeded):
- Tenant slug: `demo-gym`
- Email: `admin@demo-gym.test`
- Password: `Password1!`

```bash
php artisan db:seed --class=AdminLoginDemoSeeder
```

## Feature 2 — Member Registration (complete)

- `POST /api/v1/member/auth/register` — requires `X-Tenant-Slug`
- Details: `app/Domains/Members/README.md`

## Feature 3 — Member Login (complete)

- `POST /api/v1/member/auth/login`
- `GET /api/v1/member/auth/me`
- `POST /api/v1/member/auth/logout`

## Feature 4 — Forgot Password (complete)

Admin:
- `POST /api/v1/admin/auth/forgot-password`
- `POST /api/v1/admin/auth/reset-password`

Member:
- `POST /api/v1/member/auth/forgot-password`
- `POST /api/v1/member/auth/reset-password`

## Feature 5 — Email Verification (complete)

Member:
- Verification email sent on registration
- `GET /api/v1/member/auth/email/verify/{id}/{hash}` (signed; `tenant` query param)
- `POST /api/v1/member/auth/email/resend`
- Login blocked until verified (`email_not_verified`)

## Feature 6 — Roles (complete)

Default system roles (per tenant): gym_owner, branch_manager, receptionist, trainer, senior_trainer, nutritionist, sales_executive, inventory_manager, accountant, customer_support, cleaner, maintenance_staff, auditor.

Endpoints use permission codes under `identity.*` (see `docs/RBAC.md`).

Admin login / `me` include `roles` + `permissions`. Demo admin is seeded as **gym_owner**.

## Feature 7 — Permissions (complete)

Enterprise catalog + hierarchy-flattened matrix in `Support/RbacCatalog.php`.

- `GET /api/v1/admin/permissions` (`identity.permissions.view`)
- `GET /api/v1/admin/roles/{id}/permissions` (`identity.permissions.view`)
- `PUT /api/v1/admin/roles/{id}/permissions` (`identity.permissions.manage`)
- Middleware: `EnsureHasPermission`, `EnsureBranchAccess` (`branch.scope`)
- Policies: Role, Staff, Member, AuditLog, PlatformTenant, SaasPlan

## Tenant Isolation / Platform / Trial / Audit

See:
- `app/Domains/Tenancy` — operable trial checks, lifecycle service, `gms:expire-trials`
- `app/Domains/Platform` — SaaS plans + entitlements + **Super Admin / Platform Support** roles
- `app/Domains/Audit` — audit writer + admin list API
- `docs/RBAC.md` — enterprise matrix reference

Platform Super Admin (seeded):
- Email: `superadmin@gms.test`
- Password: `Password1!`
- Role: `super_admin` (tenant_id null)
- `php artisan db:seed --class=PlatformOwnerSeeder`
