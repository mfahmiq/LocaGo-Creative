<?php

declare(strict_types=1);

namespace App\Domains\Identity\Services;

use App\Core\Services\BaseService;
use App\Domains\Identity\Actions\CreateRoleAction;
use App\Domains\Identity\Actions\DeleteRoleAction;
use App\Domains\Identity\Actions\SeedTenantRolesAction;
use App\Domains\Identity\Actions\SyncUserRolesAction;
use App\Domains\Identity\Actions\UpdateRoleAction;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Models\Role;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Collection;

final class RoleService extends BaseService
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles,
        private readonly SeedTenantRolesAction $seedTenantRolesAction,
        private readonly CreateRoleAction $createRoleAction,
        private readonly UpdateRoleAction $updateRoleAction,
        private readonly DeleteRoleAction $deleteRoleAction,
        private readonly SyncUserRolesAction $syncUserRolesAction
    ) {}

    /**
     * @return Collection<int, Role>
     */
    public function list(Tenant $tenant): Collection
    {
        return $this->roles->listForTenant($tenant->id);
    }

    public function find(Tenant $tenant, int $roleId): ?Role
    {
        return $this->roles->findForTenant($tenant->id, $roleId);
    }

    /**
     * @return list<Role>
     */
    public function seedDefaults(Tenant $tenant): array
    {
        return $this->seedTenantRolesAction->execute($tenant);
    }

    /**
     * @param  array{code: string, name: string}  $data
     */
    public function create(Tenant $tenant, array $data): Role
    {
        return $this->createRoleAction->execute($tenant, $data);
    }

    /**
     * @param  array{name?: string, code?: string}  $data
     */
    public function update(Tenant $tenant, int $roleId, array $data): Role
    {
        return $this->updateRoleAction->execute($tenant, $roleId, $data);
    }

    public function delete(Tenant $tenant, int $roleId): bool
    {
        return $this->deleteRoleAction->execute($tenant, $roleId);
    }

    /**
     * @param  list<int>  $roleIds
     */
    public function syncUserRoles(Tenant $tenant, int $userId, array $roleIds): User
    {
        return $this->syncUserRolesAction->execute($tenant, $userId, $roleIds);
    }
}
