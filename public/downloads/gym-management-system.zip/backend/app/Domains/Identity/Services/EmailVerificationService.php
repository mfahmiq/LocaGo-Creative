<?php

declare(strict_types=1);

namespace App\Domains\Identity\Services;

use App\Core\Services\BaseService;
use App\Domains\Identity\Actions\ResendEmailVerificationAction;
use App\Domains\Identity\Actions\VerifyEmailAction;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;

final class EmailVerificationService extends BaseService
{
    public function __construct(
        private readonly VerifyEmailAction $verifyEmailAction,
        private readonly ResendEmailVerificationAction $resendEmailVerificationAction
    ) {}

    public function verify(Tenant $tenant, int $userId, string $hash): User
    {
        return $this->verifyEmailAction->execute($tenant, $userId, $hash);
    }

    public function resend(Tenant $tenant, string $email): bool
    {
        return $this->resendEmailVerificationAction->execute($tenant, $email);
    }
}
