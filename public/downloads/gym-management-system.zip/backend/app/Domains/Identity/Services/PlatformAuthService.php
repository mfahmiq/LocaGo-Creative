<?php

declare(strict_types=1);

namespace App\Domains\Identity\Services;

use App\Core\Services\BaseService;
use App\Domains\Identity\Actions\PlatformLoginAction;
use App\Domains\Identity\Models\User;
use Laravel\Sanctum\PersonalAccessToken;

final class PlatformAuthService extends BaseService
{
    public function __construct(
        private readonly PlatformLoginAction $loginAction
    ) {}

    /**
     * @return array{user: User, token: string}
     */
    public function login(string $email, string $password, string $deviceName = 'platform-console'): array
    {
        return $this->loginAction->execute($email, $password, $deviceName);
    }

    public function logout(User $user): bool
    {
        $token = $user->currentAccessToken();

        if ($token instanceof PersonalAccessToken) {
            $token->delete();
        }

        return true;
    }
}
