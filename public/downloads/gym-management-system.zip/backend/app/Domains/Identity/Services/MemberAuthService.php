<?php

declare(strict_types=1);

namespace App\Domains\Identity\Services;

use App\Core\Services\BaseService;
use App\Domains\Identity\Actions\MemberLoginAction;
use App\Domains\Identity\Actions\MemberLogoutAction;
use App\Domains\Identity\Actions\MemberRegisterAction;
use App\Domains\Identity\Models\User;
use App\Domains\Members\Models\Member;
use App\Domains\Tenancy\Models\Tenant;

final class MemberAuthService extends BaseService
{
    public function __construct(
        private readonly MemberRegisterAction $registerAction,
        private readonly MemberLoginAction $loginAction,
        private readonly MemberLogoutAction $logoutAction
    ) {}

    /**
     * @param  array<string, mixed>  $data
     * @return array{user: User, member: Member, token: string, tenant: Tenant}
     */
    public function register(Tenant $tenant, array $data): array
    {
        return $this->registerAction->execute($tenant, $data);
    }

    /**
     * @return array{user: User, member: Member, token: string, tenant: Tenant}
     */
    public function login(
        Tenant $tenant,
        string $email,
        string $password,
        string $deviceName = 'member-portal'
    ): array {
        return $this->loginAction->execute($tenant, $email, $password, $deviceName);
    }

    public function logout(User $user): bool
    {
        return $this->logoutAction->execute($user);
    }
}
