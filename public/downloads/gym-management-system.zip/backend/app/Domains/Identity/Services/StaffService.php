<?php

declare(strict_types=1);

namespace App\Domains\Identity\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Identity\Actions\CreateStaffAction;
use App\Domains\Identity\Actions\SyncStaffBranchesAction;
use App\Domains\Identity\Actions\SyncUserRolesAction;
use App\Domains\Identity\Actions\UpdateStaffAction;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class StaffService extends BaseService
{
    public function __construct(
        private readonly UserRepositoryInterface $users,
        private readonly CreateStaffAction $createStaffAction,
        private readonly UpdateStaffAction $updateStaffAction,
        private readonly SyncUserRolesAction $syncUserRolesAction,
        private readonly SyncStaffBranchesAction $syncStaffBranchesAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->users->paginateStaffForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $userId): User
    {
        $user = $this->users->findStaffByIdForTenant($tenant->id, $userId);

        if ($user === null) {
            throw new DomainException('Staff user not found.', 'staff_not_found', Response::HTTP_NOT_FOUND);
        }

        return $user->load(['roles', 'branches']);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): User
    {
        return $this->createStaffAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $userId, array $data, ?User $actor = null): User
    {
        return $this->updateStaffAction->execute($tenant, $userId, $data, $actor);
    }

    /**
     * @param  list<int>  $roleIds
     */
    public function syncRoles(Tenant $tenant, int $userId, array $roleIds): User
    {
        return $this->syncUserRolesAction->execute($tenant, $userId, $roleIds)->load(['roles', 'branches']);
    }

    /**
     * @param  list<int>  $branchIds
     */
    public function syncBranches(Tenant $tenant, int $userId, array $branchIds): User
    {
        return $this->syncStaffBranchesAction->execute($tenant, $userId, $branchIds);
    }
}
