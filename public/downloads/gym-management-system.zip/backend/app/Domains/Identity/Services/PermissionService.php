<?php

declare(strict_types=1);

namespace App\Domains\Identity\Services;

use App\Core\Services\BaseService;
use App\Domains\Identity\Actions\ApplyDefaultRolePermissionsAction;
use App\Domains\Identity\Actions\SeedPermissionsAction;
use App\Domains\Identity\Actions\SyncRolePermissionsAction;
use App\Domains\Identity\Contracts\PermissionRepositoryInterface;
use App\Domains\Identity\Models\Permission;
use App\Domains\Identity\Models\Role;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Collection;

final class PermissionService extends BaseService
{
    public function __construct(
        private readonly PermissionRepositoryInterface $permissions,
        private readonly SeedPermissionsAction $seedPermissionsAction,
        private readonly ApplyDefaultRolePermissionsAction $applyDefaultRolePermissionsAction,
        private readonly SyncRolePermissionsAction $syncRolePermissionsAction
    ) {}

    /**
     * @return Collection<int, Permission>
     */
    public function list(): Collection
    {
        return $this->permissions->listAll();
    }

    /**
     * @return list<Permission>
     */
    public function seedCatalog(): array
    {
        return $this->seedPermissionsAction->execute();
    }

    public function applyDefaults(Tenant $tenant): bool
    {
        return $this->applyDefaultRolePermissionsAction->execute($tenant);
    }

    /**
     * @param  list<int>  $permissionIds
     */
    public function syncRolePermissions(Tenant $tenant, int $roleId, array $permissionIds): Role
    {
        return $this->syncRolePermissionsAction->execute($tenant, $roleId, $permissionIds);
    }
}
