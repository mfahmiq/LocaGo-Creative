<?php

declare(strict_types=1);

namespace App\Domains\Identity\Services;

use App\Core\Services\BaseService;
use App\Domains\Identity\Actions\ForgotPasswordAction;
use App\Domains\Identity\Actions\ResetPasswordAction;
use App\Domains\Tenancy\Models\Tenant;

final class PasswordResetService extends BaseService
{
    public function __construct(
        private readonly ForgotPasswordAction $forgotPasswordAction,
        private readonly ResetPasswordAction $resetPasswordAction
    ) {}

    public function sendResetLink(Tenant $tenant, string $email, string $portal): bool
    {
        return $this->forgotPasswordAction->execute($tenant, $email, $portal);
    }

    public function reset(Tenant $tenant, string $email, string $token, string $password, string $portal): bool
    {
        return $this->resetPasswordAction->execute($tenant, $email, $token, $password, $portal);
    }
}
