<?php

declare(strict_types=1);

namespace App\Domains\Identity\Services;

use App\Core\Services\BaseService;
use App\Domains\Identity\Actions\AdminLogoutAction;
use App\Domains\Identity\Actions\UnifiedPortalLoginAction;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;

final class AdminAuthService extends BaseService
{
    public function __construct(
        private readonly UnifiedPortalLoginAction $loginAction,
        private readonly AdminLogoutAction $logoutAction
    ) {}

    /**
     * @return array{
     *     user: User,
     *     token: string,
     *     portal: string,
     *     tenant: ?Tenant,
     *     branches: list<array{id: int, code: string, name: string}>,
     *     is_tenant_wide: bool
     * }
     */
    public function login(
        string $email,
        string $password,
        string $deviceName = 'admin-portal',
        ?string $tenantSlug = null
    ): array {
        return $this->loginAction->execute($email, $password, $deviceName, $tenantSlug);
    }

    public function logout(User $user): bool
    {
        return $this->logoutAction->execute($user);
    }
}
