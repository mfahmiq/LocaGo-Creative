<?php

declare(strict_types=1);

namespace App\Domains\Identity\Support;

use App\Domains\Identity\Models\Role;

/**
 * Enterprise RBAC catalog: permissions, roles, hierarchy, and seed-time flattened matrix.
 */
final class RbacCatalog
{
    /**
     * @return list<array{code: string, name: string, module: string}>
     */
    public static function permissions(): array
    {
        return [
            // Platform
            ['code' => 'platform.tenants.view', 'name' => 'View tenants', 'module' => 'platform'],
            ['code' => 'platform.tenants.manage', 'name' => 'Manage tenants', 'module' => 'platform'],
            ['code' => 'platform.plans.view', 'name' => 'View SaaS plans', 'module' => 'platform'],
            ['code' => 'platform.plans.manage', 'name' => 'Manage SaaS plans', 'module' => 'platform'],
            ['code' => 'platform.users.manage', 'name' => 'Manage platform users', 'module' => 'platform'],
            ['code' => 'platform.audit.view', 'name' => 'View platform audit logs', 'module' => 'platform'],
            ['code' => 'platform.billing.view', 'name' => 'View platform billing', 'module' => 'platform'],
            ['code' => 'platform.billing.manage', 'name' => 'Manage platform billing', 'module' => 'platform'],
            ['code' => 'platform.reports.view', 'name' => 'View platform reports', 'module' => 'platform'],
            ['code' => 'platform.reports.export', 'name' => 'Export platform reports', 'module' => 'platform'],

            // Identity
            ['code' => 'identity.roles.view', 'name' => 'View roles', 'module' => 'identity'],
            ['code' => 'identity.roles.manage', 'name' => 'Manage roles', 'module' => 'identity'],
            ['code' => 'identity.permissions.view', 'name' => 'View permissions', 'module' => 'identity'],
            ['code' => 'identity.permissions.manage', 'name' => 'Manage role permissions', 'module' => 'identity'],
            ['code' => 'identity.staff.view', 'name' => 'View staff', 'module' => 'identity'],
            ['code' => 'identity.staff.manage', 'name' => 'Manage staff', 'module' => 'identity'],
            ['code' => 'identity.staff.assign_roles', 'name' => 'Assign staff roles', 'module' => 'identity'],

            // Organization
            ['code' => 'organization.branches.view', 'name' => 'View branches', 'module' => 'organization'],
            ['code' => 'organization.branches.manage', 'name' => 'Manage branches', 'module' => 'organization'],
            ['code' => 'organization.settings.view', 'name' => 'View settings', 'module' => 'organization'],
            ['code' => 'organization.settings.manage', 'name' => 'Manage settings', 'module' => 'organization'],

            // Members / memberships
            ['code' => 'members.view', 'name' => 'View members', 'module' => 'members'],
            ['code' => 'members.create', 'name' => 'Create members', 'module' => 'members'],
            ['code' => 'members.update', 'name' => 'Update members', 'module' => 'members'],
            ['code' => 'members.export', 'name' => 'Export members', 'module' => 'members'],
            ['code' => 'memberships.plans.view', 'name' => 'View membership plans', 'module' => 'memberships'],
            ['code' => 'memberships.plans.manage', 'name' => 'Manage membership plans', 'module' => 'memberships'],
            ['code' => 'memberships.instances.view', 'name' => 'View memberships', 'module' => 'memberships'],
            ['code' => 'memberships.instances.manage', 'name' => 'Manage memberships', 'module' => 'memberships'],
            ['code' => 'memberships.instances.cancel', 'name' => 'Cancel memberships', 'module' => 'memberships'],
            ['code' => 'memberships.instances.freeze', 'name' => 'Freeze memberships', 'module' => 'memberships'],

            // Attendance / classes / training / nutrition
            ['code' => 'attendance.view', 'name' => 'View attendance', 'module' => 'attendance'],
            ['code' => 'attendance.check_in', 'name' => 'Check in members', 'module' => 'attendance'],
            ['code' => 'attendance.void', 'name' => 'Void attendance', 'module' => 'attendance'],
            ['code' => 'classes.view', 'name' => 'View classes', 'module' => 'classes'],
            ['code' => 'classes.manage', 'name' => 'Manage classes', 'module' => 'classes'],
            ['code' => 'classes.book_for_member', 'name' => 'Book classes for members', 'module' => 'classes'],
            ['code' => 'training.view', 'name' => 'View training', 'module' => 'training'],
            ['code' => 'training.manage', 'name' => 'Manage training', 'module' => 'training'],
            ['code' => 'nutrition.view', 'name' => 'View nutrition', 'module' => 'nutrition'],
            ['code' => 'nutrition.manage', 'name' => 'Manage nutrition', 'module' => 'nutrition'],
            // Workout programs reuse training.view / training.manage

            // Sales / billing / POS
            ['code' => 'sales.leads.view', 'name' => 'View sales leads', 'module' => 'sales'],
            ['code' => 'sales.leads.manage', 'name' => 'Manage sales leads', 'module' => 'sales'],
            ['code' => 'billing.invoices.view', 'name' => 'View invoices', 'module' => 'billing'],
            ['code' => 'billing.invoices.create', 'name' => 'Create invoices', 'module' => 'billing'],
            ['code' => 'billing.invoices.void', 'name' => 'Void invoices', 'module' => 'billing'],
            ['code' => 'billing.payments.view', 'name' => 'View payments', 'module' => 'billing'],
            ['code' => 'billing.payments.record', 'name' => 'Record payments', 'module' => 'billing'],
            ['code' => 'billing.payments.void', 'name' => 'Void payments', 'module' => 'billing'],
            ['code' => 'pos.sales.view', 'name' => 'View POS sales', 'module' => 'pos'],
            ['code' => 'pos.sales.create', 'name' => 'Create POS sales', 'module' => 'pos'],
            ['code' => 'pos.inventory.view', 'name' => 'View inventory', 'module' => 'pos'],
            ['code' => 'pos.inventory.manage', 'name' => 'Manage inventory', 'module' => 'pos'],
            ['code' => 'expenses.view', 'name' => 'View expenses', 'module' => 'expenses'],
            ['code' => 'expenses.manage', 'name' => 'Manage expenses', 'module' => 'expenses'],
            ['code' => 'marketing.offers.view', 'name' => 'View offers', 'module' => 'marketing'],
            ['code' => 'marketing.offers.manage', 'name' => 'Manage offers', 'module' => 'marketing'],
            ['code' => 'marketing.coupons.view', 'name' => 'View coupons', 'module' => 'marketing'],
            ['code' => 'marketing.coupons.manage', 'name' => 'Manage coupons', 'module' => 'marketing'],
            ['code' => 'marketing.referrals.view', 'name' => 'View referrals', 'module' => 'marketing'],
            ['code' => 'marketing.referrals.manage', 'name' => 'Manage referrals', 'module' => 'marketing'],
            ['code' => 'marketing.loyalty.view', 'name' => 'View loyalty', 'module' => 'marketing'],
            ['code' => 'marketing.loyalty.manage', 'name' => 'Manage loyalty', 'module' => 'marketing'],
            ['code' => 'notifications.view', 'name' => 'View notifications', 'module' => 'notifications'],
            ['code' => 'notifications.manage', 'name' => 'Manage notification templates', 'module' => 'notifications'],
            ['code' => 'notifications.send', 'name' => 'Send notifications', 'module' => 'notifications'],

            // Equipment / facilities / support
            ['code' => 'equipment.view', 'name' => 'View equipment', 'module' => 'equipment'],
            ['code' => 'equipment.manage', 'name' => 'Manage equipment', 'module' => 'equipment'],
            ['code' => 'facilities.tasks.view', 'name' => 'View facility tasks', 'module' => 'facilities'],
            ['code' => 'facilities.tasks.update_own', 'name' => 'Update own facility tasks', 'module' => 'facilities'],
            ['code' => 'facilities.tasks.manage', 'name' => 'Manage facility tasks', 'module' => 'facilities'],
            ['code' => 'support.tickets.view', 'name' => 'View support tickets', 'module' => 'support'],
            ['code' => 'support.tickets.manage', 'name' => 'Manage support tickets', 'module' => 'support'],

            // Reports / audit / entitlements
            ['code' => 'reports.view', 'name' => 'View reports', 'module' => 'reports'],
            ['code' => 'reports.export', 'name' => 'Export reports', 'module' => 'reports'],
            ['code' => 'audit.view', 'name' => 'View audit logs', 'module' => 'audit'],
            ['code' => 'entitlements.view', 'name' => 'View entitlements', 'module' => 'platform'],

            // Member portal (documented; gated by portal middleware)
            ['code' => 'member_portal.profile.view', 'name' => 'View own profile', 'module' => 'member_portal'],
            ['code' => 'member_portal.profile.update', 'name' => 'Update own profile', 'module' => 'member_portal'],
            ['code' => 'member_portal.membership.view', 'name' => 'View own membership', 'module' => 'member_portal'],
            ['code' => 'member_portal.membership.renew', 'name' => 'Renew own membership', 'module' => 'member_portal'],
            ['code' => 'member_portal.classes.book', 'name' => 'Book own classes', 'module' => 'member_portal'],
            ['code' => 'member_portal.classes.cancel', 'name' => 'Cancel own bookings', 'module' => 'member_portal'],
            ['code' => 'member_portal.attendance.view', 'name' => 'View own attendance', 'module' => 'member_portal'],
            ['code' => 'member_portal.invoices.view', 'name' => 'View own invoices', 'module' => 'member_portal'],
            ['code' => 'member_portal.notifications.view', 'name' => 'View own notifications', 'module' => 'member_portal'],
            ['code' => 'member_portal.support.view', 'name' => 'View own support tickets', 'module' => 'member_portal'],
            ['code' => 'member_portal.support.create', 'name' => 'Create support tickets', 'module' => 'member_portal'],
            ['code' => 'member_portal.workout.view', 'name' => 'View own workout plan', 'module' => 'member_portal'],
            ['code' => 'member_portal.nutrition.view', 'name' => 'View own nutrition plan', 'module' => 'member_portal'],
            ['code' => 'member_portal.loyalty.view', 'name' => 'View own loyalty points', 'module' => 'member_portal'],
        ];
    }

    /**
     * @return list<array{code: string, name: string}>
     */
    public static function tenantRoles(): array
    {
        return [
            ['code' => Role::CODE_GYM_OWNER, 'name' => 'Gym Owner'],
            ['code' => Role::CODE_BRANCH_MANAGER, 'name' => 'Branch Manager'],
            ['code' => Role::CODE_RECEPTIONIST, 'name' => 'Receptionist'],
            ['code' => Role::CODE_TRAINER, 'name' => 'Trainer'],
            ['code' => Role::CODE_SENIOR_TRAINER, 'name' => 'Senior Trainer'],
            ['code' => Role::CODE_NUTRITIONIST, 'name' => 'Nutritionist'],
            ['code' => Role::CODE_SALES_EXECUTIVE, 'name' => 'Sales Executive'],
            ['code' => Role::CODE_INVENTORY_MANAGER, 'name' => 'Inventory Manager'],
            ['code' => Role::CODE_ACCOUNTANT, 'name' => 'Accountant'],
            ['code' => Role::CODE_CUSTOMER_SUPPORT, 'name' => 'Customer Support'],
            ['code' => Role::CODE_CLEANER, 'name' => 'Cleaner'],
            ['code' => Role::CODE_MAINTENANCE_STAFF, 'name' => 'Maintenance Staff'],
            ['code' => Role::CODE_AUDITOR, 'name' => 'Auditor'],
            ['code' => Role::CODE_MEMBER, 'name' => 'Member'],
        ];
    }

    /**
     * @return list<array{code: string, name: string}>
     */
    public static function platformRoles(): array
    {
        return [
            ['code' => Role::CODE_SUPER_ADMIN, 'name' => 'Super Admin / Platform Owner'],
            ['code' => Role::CODE_PLATFORM_SUPPORT, 'name' => 'Platform Support'],
        ];
    }

    /**
     * Child roles whose base grants are unioned into the parent at seed time.
     *
     * @return array<string, list<string>>
     */
    public static function hierarchy(): array
    {
        return [
            Role::CODE_SENIOR_TRAINER => [Role::CODE_TRAINER],
            Role::CODE_BRANCH_MANAGER => [
                Role::CODE_RECEPTIONIST,
                Role::CODE_SALES_EXECUTIVE,
                Role::CODE_SENIOR_TRAINER,
                Role::CODE_INVENTORY_MANAGER,
                Role::CODE_CLEANER,
                Role::CODE_MAINTENANCE_STAFF,
            ],
        ];
    }

    /**
     * Roles that are tenant-wide (skip branch assignment requirement).
     * Only Gym Owner / Tenant Owner may access all branches in the tenant;
     * every other staff role is tenant + branch scoped via branch_user.
     *
     * @return list<string>
     */
    public static function tenantWideRoles(): array
    {
        return [
            Role::CODE_GYM_OWNER,
        ];
    }

    /**
     * Base grants before hierarchy expansion.
     *
     * @return array<string, list<string>>
     */
    public static function baseGrants(): array
    {
        $tenantCodes = array_values(array_filter(
            array_column(self::permissions(), 'code'),
            fn (string $code): bool => ! str_starts_with($code, 'platform.')
                && ! str_starts_with($code, 'member_portal.')
        ));

        $viewOnly = array_values(array_filter(
            $tenantCodes,
            fn (string $code): bool => str_ends_with($code, '.view')
                || $code === 'reports.export'
        ));

        return [
            Role::CODE_GYM_OWNER => $tenantCodes,

            Role::CODE_TRAINER => [
                'members.view',
                'organization.branches.view',
                'classes.view',
                'training.view',
                'training.manage',
                'attendance.view',
                'reports.view',
            ],

            Role::CODE_SENIOR_TRAINER => [
                'classes.manage',
                'members.update',
                'reports.view',
            ],

            Role::CODE_NUTRITIONIST => [
                'members.view',
                'organization.branches.view',
                'nutrition.view',
                'nutrition.manage',
                'reports.view',
            ],

            Role::CODE_RECEPTIONIST => [
                'members.view', 'members.create', 'members.update',
                'organization.branches.view',
                'memberships.plans.view', 'memberships.instances.view', 'memberships.instances.manage',
                'attendance.view', 'attendance.check_in',
                'classes.view', 'classes.book_for_member',
                'billing.invoices.view', 'billing.invoices.create',
                'billing.payments.view', 'billing.payments.record',
                'support.tickets.view', 'support.tickets.manage',
                'pos.sales.view', 'pos.sales.create',
                'sales.leads.view', 'sales.leads.manage',
                'marketing.offers.view', 'marketing.coupons.view',
                'notifications.view',
                'reports.view',
                'marketing.loyalty.view',
            ],

            Role::CODE_SALES_EXECUTIVE => [
                'members.view', 'members.create', 'members.update',
                'organization.branches.view',
                'memberships.plans.view', 'memberships.instances.view', 'memberships.instances.manage',
                'sales.leads.view', 'sales.leads.manage',
                'billing.invoices.view', 'billing.invoices.create',
                'billing.payments.view', 'billing.payments.record',
                'support.tickets.view',
                'reports.view',
                'marketing.loyalty.view',
            ],

            Role::CODE_INVENTORY_MANAGER => [
                'organization.branches.view',
                'pos.sales.view', 'pos.sales.create',
                'pos.inventory.view', 'pos.inventory.manage',
                'equipment.view', 'equipment.manage',
                'expenses.view',
                'reports.view',
            ],

            Role::CODE_CLEANER => [
                'organization.branches.view',
                'facilities.tasks.view',
                'facilities.tasks.update_own',
            ],

            Role::CODE_MAINTENANCE_STAFF => [
                'organization.branches.view',
                'equipment.view', 'equipment.manage',
                'facilities.tasks.view',
                'facilities.tasks.update_own',
            ],

            Role::CODE_ACCOUNTANT => [
                'members.view',
                'organization.branches.view',
                'billing.invoices.view', 'billing.invoices.create', 'billing.invoices.void',
                'billing.payments.view', 'billing.payments.record', 'billing.payments.void',
                'memberships.instances.view',
                'pos.sales.view', 'pos.inventory.view',
                'expenses.view', 'expenses.manage',
                'reports.view', 'reports.export',
                'audit.view',
                'marketing.loyalty.view',
            ],

            Role::CODE_CUSTOMER_SUPPORT => [
                'members.view', 'members.update',
                'organization.branches.view',
                'memberships.instances.view',
                'support.tickets.view', 'support.tickets.manage',
                'billing.invoices.view', 'billing.payments.view',
                'classes.view',
                'reports.view',
            ],

            Role::CODE_AUDITOR => $viewOnly,

            Role::CODE_BRANCH_MANAGER => [
                'identity.staff.view', 'identity.staff.manage', 'identity.staff.assign_roles',
                'identity.roles.view', 'identity.permissions.view',
                'organization.branches.view', 'organization.branches.manage',
                'organization.settings.view',
                'members.view', 'members.create', 'members.update', 'members.export',
                'memberships.plans.view', 'memberships.instances.view', 'memberships.instances.manage',
                'memberships.instances.cancel', 'memberships.instances.freeze',
                'attendance.view', 'attendance.check_in', 'attendance.void',
                'classes.view', 'classes.manage', 'classes.book_for_member',
                'training.view', 'training.manage',
                'nutrition.view',
                'sales.leads.view', 'sales.leads.manage',
                'billing.invoices.view', 'billing.invoices.create',
                'billing.payments.view', 'billing.payments.record',
                'pos.sales.view', 'pos.sales.create',
                'pos.inventory.view', 'pos.inventory.manage',
                'expenses.view', 'expenses.manage',
                'marketing.offers.view', 'marketing.offers.manage',
                'marketing.coupons.view', 'marketing.coupons.manage',
                'marketing.referrals.view', 'marketing.referrals.manage',
                'marketing.loyalty.view', 'marketing.loyalty.manage',
                'notifications.view', 'notifications.manage', 'notifications.send',
                'equipment.view', 'equipment.manage',
                'facilities.tasks.view', 'facilities.tasks.manage',
                'support.tickets.view', 'support.tickets.manage',
                'reports.view', 'reports.export',
                'audit.view',
                'entitlements.view',
            ],

            Role::CODE_SUPER_ADMIN => [
                'platform.tenants.view', 'platform.tenants.manage',
                'platform.plans.view', 'platform.plans.manage',
                'platform.users.manage',
                'platform.audit.view',
                'platform.billing.view', 'platform.billing.manage',
                'platform.reports.view', 'platform.reports.export',
            ],

            Role::CODE_PLATFORM_SUPPORT => [
                'platform.tenants.view',
                'platform.plans.view',
                'platform.audit.view',
                'platform.billing.view',
                'platform.reports.view',
            ],

            Role::CODE_MEMBER => [
                'member_portal.profile.view', 'member_portal.profile.update',
                'member_portal.membership.view', 'member_portal.membership.renew',
                'member_portal.classes.book', 'member_portal.classes.cancel',
                'member_portal.attendance.view',
                'member_portal.invoices.view',
                'member_portal.notifications.view',
                'member_portal.support.view', 'member_portal.support.create',
                'member_portal.workout.view', 'member_portal.nutrition.view',
                'member_portal.loyalty.view',
            ],
        ];
    }

    /**
     * Seed-time flattened matrix (hierarchy expanded).
     *
     * @return array<string, list<string>>
     */
    public static function flattenedMatrix(): array
    {
        $base = self::baseGrants();
        $hierarchy = self::hierarchy();
        $result = [];

        foreach ($base as $role => $grants) {
            $result[$role] = self::expandRole($role, $base, $hierarchy);
        }

        return $result;
    }

    /**
     * @param  array<string, list<string>>  $base
     * @param  array<string, list<string>>  $hierarchy
     * @return list<string>
     */
    private static function expandRole(string $role, array $base, array $hierarchy, array $stack = []): array
    {
        if (in_array($role, $stack, true)) {
            return $base[$role] ?? [];
        }

        $stack[] = $role;
        $codes = $base[$role] ?? [];

        foreach ($hierarchy[$role] ?? [] as $child) {
            $codes = array_merge($codes, self::expandRole($child, $base, $hierarchy, $stack));
        }

        $codes = array_values(array_unique($codes));
        sort($codes);

        return $codes;
    }
}
