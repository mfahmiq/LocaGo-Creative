<?php

declare(strict_types=1);

namespace App\Domains\Identity\Support;

/**
 * Tenant-aware password reset token storage key.
 *
 * The password_reset_tokens table is keyed by email only; we namespace with tenant_id
 * so the same email can exist across tenants safely.
 */
final class PasswordResetKey
{
    public static function make(int $tenantId, string $email): string
    {
        return $tenantId.'|'.strtolower(trim($email));
    }

    /**
     * @return array{0: int, 1: string}|null
     */
    public static function parse(string $key): ?array
    {
        if (! str_contains($key, '|')) {
            return null;
        }

        [$tenantId, $email] = explode('|', $key, 2);

        if (! is_numeric($tenantId) || $email === '') {
            return null;
        }

        return [(int) $tenantId, strtolower(trim($email))];
    }
}
