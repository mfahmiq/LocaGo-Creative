<?php

declare(strict_types=1);

namespace App\Domains\Identity\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\Role;
use App\Domains\Identity\Models\User;

final class RolePolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'identity.roles.view');
    }

    public function view(User $user, Role $role): bool
    {
        return $this->hasPermission($user, 'identity.roles.view')
            && $this->sameTenant($user, $role);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'identity.roles.manage');
    }

    public function update(User $user, Role $role): bool
    {
        return $this->hasPermission($user, 'identity.roles.manage')
            && $this->sameTenant($user, $role)
            && ! $role->isPlatformRole();
    }

    public function delete(User $user, Role $role): bool
    {
        return $this->update($user, $role) && ! $role->is_system;
    }

    public function syncPermissions(User $user, Role $role): bool
    {
        return $this->hasPermission($user, 'identity.permissions.manage')
            && $this->sameTenant($user, $role)
            && ! $role->isPlatformRole();
    }
}
