<?php

declare(strict_types=1);

namespace App\Domains\Identity\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;

final class StaffPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'identity.staff.view');
    }

    public function view(User $actor, User $staff): bool
    {
        return $this->hasPermission($actor, 'identity.staff.view')
            && $this->sameTenant($actor, $staff)
            && $staff->isStaff();
    }

    public function create(User $actor): bool
    {
        return $this->hasPermission($actor, 'identity.staff.manage');
    }

    public function update(User $actor, User $staff): bool
    {
        return $this->hasPermission($actor, 'identity.staff.manage')
            && $this->sameTenant($actor, $staff)
            && $staff->isStaff();
    }

    public function assignRoles(User $actor, User $staff): bool
    {
        if (! $this->hasPermission($actor, 'identity.staff.assign_roles')) {
            return false;
        }

        if (! $this->sameTenant($actor, $staff) || ! $staff->isStaff()) {
            return false;
        }

        // Branch managers cannot assign roles to gym owners.
        if ($staff->hasRole(\App\Domains\Identity\Models\Role::CODE_GYM_OWNER)
            && ! $actor->hasRole(\App\Domains\Identity\Models\Role::CODE_GYM_OWNER)) {
            return false;
        }

        return true;
    }
}
