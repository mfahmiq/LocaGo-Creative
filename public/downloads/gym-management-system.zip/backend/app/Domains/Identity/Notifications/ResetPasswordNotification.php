<?php

declare(strict_types=1);

namespace App\Domains\Identity\Notifications;

use App\Core\Notifications\BaseNotification;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Notifications\Messages\MailMessage;

final class ResetPasswordNotification extends BaseNotification
{
    public function __construct(
        private readonly string $token,
        private readonly Tenant $tenant,
        private readonly string $portal
    ) {
        parent::__construct();
    }

    public function resetToken(): string
    {
        return $this->token;
    }

    /**
     * @return list<string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $email = urlencode((string) $notifiable->email);
        $template = $this->portal === 'admin'
            ? config('gms.frontend.admin_reset_url')
            : config('gms.frontend.member_reset_url');

        $url = str_replace(
            ['{tenant}', '{token}', '{email}'],
            [$this->tenant->slug, urlencode($this->token), $email],
            (string) $template
        );

        $minutes = (int) config('gms.password_reset.expire_minutes', 60);

        return (new MailMessage)
            ->subject('Reset your '.$this->tenant->name.' password')
            ->greeting('Hello '.$notifiable->name.',')
            ->line('You are receiving this email because we received a password reset request for your account.')
            ->action('Reset Password', $url)
            ->line("This password reset link will expire in {$minutes} minutes.")
            ->line('If you did not request a password reset, no further action is required.');
    }
}
