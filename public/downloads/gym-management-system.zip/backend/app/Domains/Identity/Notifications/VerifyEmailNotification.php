<?php

declare(strict_types=1);

namespace App\Domains\Identity\Notifications;

use App\Core\Notifications\BaseNotification;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\URL;
use Illuminate\Notifications\Messages\MailMessage;

final class VerifyEmailNotification extends BaseNotification
{
    public function __construct(
        private readonly Tenant $tenant
    ) {
        parent::__construct();
    }

    /**
     * @return list<string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        /** @var User $notifiable */
        $verificationUrl = $this->verificationUrl($notifiable);

        return (new MailMessage)
            ->subject('Verify your email for '.$this->tenant->name)
            ->greeting('Hello '.$notifiable->name.',')
            ->line('Please click the button below to verify your email address.')
            ->action('Verify Email Address', $verificationUrl)
            ->line('If you did not create an account, no further action is required.');
    }

    public function verificationUrl(User $user): string
    {
        $expireMinutes = (int) config('gms.email_verification.expire_minutes', 60);

        $apiUrl = URL::temporarySignedRoute(
            'api.v1.member.auth.email.verify',
            Carbon::now()->addMinutes($expireMinutes),
            [
                'id' => $user->getKey(),
                'hash' => sha1($user->getEmailForVerification()),
                'tenant' => $this->tenant->slug,
            ]
        );

        $frontendTemplate = config('gms.frontend.member_verify_url');

        if (! is_string($frontendTemplate) || $frontendTemplate === '') {
            return $apiUrl;
        }

        $parts = parse_url($apiUrl);
        parse_str($parts['query'] ?? '', $query);

        return str_replace(
            ['{tenant}', '{id}', '{hash}', '{expires}', '{signature}'],
            [
                $this->tenant->slug,
                (string) $user->getKey(),
                sha1($user->getEmailForVerification()),
                (string) ($query['expires'] ?? ''),
                (string) ($query['signature'] ?? ''),
            ],
            $frontendTemplate
        );
    }
}
