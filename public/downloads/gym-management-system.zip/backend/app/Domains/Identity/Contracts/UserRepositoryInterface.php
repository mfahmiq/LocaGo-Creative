<?php

declare(strict_types=1);

namespace App\Domains\Identity\Contracts;

use App\Domains\Identity\Models\User;
use Illuminate\Support\Collection;

interface UserRepositoryInterface
{
    public function findStaffByTenantAndEmail(int $tenantId, string $email): ?User;

    public function findStaffByIdForTenant(int $tenantId, int $userId): ?User;

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateStaffForTenant(int $tenantId, array $filters = []): \Illuminate\Contracts\Pagination\LengthAwarePaginator;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createStaff(array $attributes): User;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateStaff(User $user, array $attributes): User;

    /**
     * Active and inactive staff rows sharing an email across tenants.
     *
     * @return Collection<int, User>
     */
    public function findStaffAccountsByEmail(string $email): Collection;

    public function findPlatformByEmail(string $email): ?User;

    public function findPlatformById(int $userId): ?User;

    /**
     * @return \Illuminate\Database\Eloquent\Collection<int, User>
     */
    public function listPlatformUsers(): \Illuminate\Database\Eloquent\Collection;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createPlatformUser(array $attributes): User;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updatePlatformUser(User $user, array $attributes): User;

    public function findMemberByTenantAndEmail(int $tenantId, string $email): ?User;

    public function findMemberByIdForTenant(int $tenantId, int $userId): ?User;

    public function findByTenantAndEmail(int $tenantId, string $email): ?User;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createMember(array $attributes): User;
}
