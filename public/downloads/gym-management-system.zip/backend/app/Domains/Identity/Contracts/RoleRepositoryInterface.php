<?php

declare(strict_types=1);

namespace App\Domains\Identity\Contracts;

use App\Domains\Identity\Models\Role;
use Illuminate\Database\Eloquent\Collection;

interface RoleRepositoryInterface
{
    /**
     * @return Collection<int, Role>
     */
    public function listForTenant(int $tenantId): Collection;

    public function findForTenant(int $tenantId, int $roleId): ?Role;

    public function findByCode(int $tenantId, string $code): ?Role;

    public function findPlatformByCode(string $code): ?Role;

    /**
     * @return Collection<int, Role>
     */
    public function listPlatformRoles(): Collection;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createRole(array $attributes): Role;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateRole(Role $role, array $attributes): Role;

    public function deleteRole(Role $role): bool;

    /**
     * @param  list<int>  $roleIds
     */
    public function syncUserRoles(int $userId, array $roleIds): void;
}
