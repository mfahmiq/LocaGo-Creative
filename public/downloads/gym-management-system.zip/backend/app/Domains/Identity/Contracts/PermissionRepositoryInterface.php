<?php

declare(strict_types=1);

namespace App\Domains\Identity\Contracts;

use App\Domains\Identity\Models\Permission;
use Illuminate\Database\Eloquent\Collection;

interface PermissionRepositoryInterface
{
    /**
     * @return Collection<int, Permission>
     */
    public function listAll(): Collection;

    public function findById(int $id): ?Permission;

    public function findByCode(string $code): ?Permission;

    /**
     * @param  array{code: string, name: string, module: string}  $attributes
     */
    public function createPermission(array $attributes): Permission;

    /**
     * @param  list<int>  $permissionIds
     */
    public function syncRolePermissions(int $roleId, array $permissionIds): void;

    /**
     * @return list<int>
     */
    public function permissionIdsForRole(int $roleId): array;
}
