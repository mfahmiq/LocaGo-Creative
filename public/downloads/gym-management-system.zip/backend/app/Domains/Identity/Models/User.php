<?php

declare(strict_types=1);

namespace App\Domains\Identity\Models;

use App\Core\Models\Concerns\HasAuditColumns;
use App\Domains\Identity\Notifications\VerifyEmailNotification;
use App\Domains\Organization\Models\Branch;
use App\Domains\Organization\Models\BranchUser;
use App\Domains\Identity\Support\RbacCatalog;
use App\Domains\Tenancy\Models\Tenant;
use Database\Factories\UserFactory;
use Illuminate\Auth\MustVerifyEmail as MustVerifyEmailTrait;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable implements MustVerifyEmail
{
    /** @use HasFactory<UserFactory> */
    use HasApiTokens;
    use HasAuditColumns;
    use HasFactory;
    use MustVerifyEmailTrait;
    use Notifiable;
    use SoftDeletes;

    public const TYPE_PLATFORM = 'platform';

    public const TYPE_STAFF = 'staff';

    public const TYPE_MEMBER = 'member';

    protected $table = 'users';

    protected $fillable = [
        'tenant_id',
        'user_type',
        'name',
        'email',
        'phone',
        'password',
        'email_verified_at',
        'is_active',
        'last_login_at',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'last_login_at' => 'datetime',
            'password' => 'hashed',
            'is_active' => 'boolean',
        ];
    }

    protected static function newFactory(): UserFactory
    {
        return UserFactory::new();
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class, 'user_roles');
    }

    public function branchAssignments(): HasMany
    {
        return $this->hasMany(BranchUser::class);
    }

    public function branches(): BelongsToMany
    {
        return $this->belongsToMany(Branch::class, 'branch_user')
            ->withPivot(['tenant_id', 'created_at', 'created_by']);
    }

    public function isTenantWideStaff(): bool
    {
        if (! $this->isStaff()) {
            return false;
        }

        foreach ($this->relationLoaded('roles') ? $this->roles : $this->roles()->get() as $role) {
            if (in_array($role->code, RbacCatalog::tenantWideRoles(), true)) {
                return true;
            }
        }

        return false;
    }

    public function canAccessBranch(int $branchId): bool
    {
        if ($this->isTenantWideStaff() || $this->hasRole(Role::CODE_GYM_OWNER)) {
            return true;
        }

        return $this->branchAssignments()
            ->where('branch_id', $branchId)
            ->exists();
    }

    public function hasRole(string $code): bool
    {
        if ($this->relationLoaded('roles')) {
            return $this->roles->contains(fn (Role $role): bool => $role->code === $code);
        }

        return $this->roles()->where('code', $code)->exists();
    }

    /**
     * @param  list<string>  $codes
     */
    public function hasAnyRole(array $codes): bool
    {
        if ($this->relationLoaded('roles')) {
            return $this->roles->contains(fn (Role $role): bool => in_array($role->code, $codes, true));
        }

        return $this->roles()->whereIn('code', $codes)->exists();
    }

    public function hasPermission(string $code): bool
    {
        return in_array($code, $this->permissionCodes(), true);
    }

    /**
     * @param  list<string>  $codes
     */
    public function hasAnyPermission(array $codes): bool
    {
        $owned = $this->permissionCodes();

        foreach ($codes as $code) {
            if (in_array($code, $owned, true)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return list<string>
     */
    public function permissionCodes(): array
    {
        if ($this->relationLoaded('roles')) {
            $roles = $this->roles;

            if ($roles->every(fn (Role $role): bool => $role->relationLoaded('permissions'))) {
                return $roles
                    ->flatMap(fn (Role $role) => $role->permissions->pluck('code'))
                    ->unique()
                    ->values()
                    ->all();
            }
        }

        return $this->roles()
            ->with('permissions')
            ->get()
            ->flatMap(fn (Role $role) => $role->permissions->pluck('code'))
            ->unique()
            ->values()
            ->all();
    }

    public function isStaff(): bool
    {
        return $this->user_type === self::TYPE_STAFF;
    }

    public function isMember(): bool
    {
        return $this->user_type === self::TYPE_MEMBER;
    }

    public function isPlatform(): bool
    {
        return $this->user_type === self::TYPE_PLATFORM;
    }

    public function canAccessAdminPortal(): bool
    {
        return $this->isStaff() && $this->is_active;
    }

    public function canAccessMemberPortal(): bool
    {
        return $this->isMember() && $this->is_active;
    }

    public function canAccessPlatformConsole(): bool
    {
        return $this->isPlatform() && $this->is_active && $this->tenant_id === null;
    }

    public function sendEmailVerificationNotification(): void
    {
        $tenant = $this->tenant;

        if ($tenant === null) {
            return;
        }

        $this->notify(new VerifyEmailNotification($tenant));
    }
}
