<?php

declare(strict_types=1);

namespace App\Domains\Identity\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Identity\Support\RbacCatalog;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Role extends BaseModel
{
    use BelongsToTenant;

    /** @deprecated Use CODE_GYM_OWNER */
    public const CODE_OWNER = 'gym_owner';

    public const CODE_GYM_OWNER = 'gym_owner';

    public const CODE_BRANCH_MANAGER = 'branch_manager';

    public const CODE_RECEPTIONIST = 'receptionist';

    public const CODE_TRAINER = 'trainer';

    public const CODE_SENIOR_TRAINER = 'senior_trainer';

    public const CODE_NUTRITIONIST = 'nutritionist';

    public const CODE_SALES_EXECUTIVE = 'sales_executive';

    public const CODE_INVENTORY_MANAGER = 'inventory_manager';

    public const CODE_ACCOUNTANT = 'accountant';

    public const CODE_CUSTOMER_SUPPORT = 'customer_support';

    public const CODE_CLEANER = 'cleaner';

    public const CODE_MAINTENANCE_STAFF = 'maintenance_staff';

    public const CODE_AUDITOR = 'auditor';

    public const CODE_MEMBER = 'member';

    public const CODE_SUPER_ADMIN = 'super_admin';

    public const CODE_PLATFORM_SUPPORT = 'platform_support';

    protected $table = 'roles';

    protected $fillable = [
        'tenant_id',
        'code',
        'name',
        'is_system',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'is_system' => 'boolean',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'user_roles');
    }

    public function permissions(): BelongsToMany
    {
        return $this->belongsToMany(Permission::class, 'role_permissions');
    }

    /**
     * @return list<array{code: string, name: string}>
     */
    public static function defaultCatalog(): array
    {
        return RbacCatalog::tenantRoles();
    }

    /**
     * @return list<array{code: string, name: string}>
     */
    public static function platformCatalog(): array
    {
        return RbacCatalog::platformRoles();
    }

    public function isPlatformRole(): bool
    {
        return $this->tenant_id === null
            && in_array($this->code, [self::CODE_SUPER_ADMIN, self::CODE_PLATFORM_SUPPORT], true);
    }

    public function isTenantWide(): bool
    {
        return in_array($this->code, RbacCatalog::tenantWideRoles(), true);
    }
}
