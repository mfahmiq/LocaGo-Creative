<?php

declare(strict_types=1);

namespace App\Domains\Identity\Models;

use App\Domains\Identity\Support\RbacCatalog;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Permission extends Model
{
    public $timestamps = true;

    protected $dateFormat = 'Y-m-d H:i:s.v';

    protected $table = 'permissions';

    protected $fillable = [
        'code',
        'name',
        'module',
    ];

    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class, 'role_permissions');
    }

    /**
     * @return list<array{code: string, name: string, module: string}>
     */
    public static function defaultCatalog(): array
    {
        return RbacCatalog::permissions();
    }

    /**
     * Flattened role → permission matrix (hierarchy expanded at seed time).
     *
     * @return array<string, list<string>>
     */
    public static function defaultRoleMatrix(): array
    {
        return RbacCatalog::flattenedMatrix();
    }
}
