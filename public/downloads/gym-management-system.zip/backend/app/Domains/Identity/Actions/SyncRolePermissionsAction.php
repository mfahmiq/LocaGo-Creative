<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Contracts\PermissionRepositoryInterface;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Models\Role;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class SyncRolePermissionsAction extends Action
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles,
        private readonly PermissionRepositoryInterface $permissions,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Role
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $roleId */
        $roleId = (int) $args[1];
        /** @var list<int> $permissionIds */
        $permissionIds = $args[2];

        $role = $this->roles->findForTenant($tenant->id, $roleId);

        if ($role === null) {
            throw new DomainException('Role not found.', 'role_not_found', Response::HTTP_NOT_FOUND);
        }

        $validIds = [];
        foreach ($permissionIds as $permissionId) {
            $permission = $this->permissions->findById((int) $permissionId);

            if ($permission === null) {
                throw new DomainException(
                    'One or more permissions are invalid.',
                    'invalid_permission_ids',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $validIds[] = $permission->id;
        }

        $oldIds = $this->permissions->permissionIdsForRole($role->id);

        $this->permissions->syncRolePermissions($role->id, $validIds);

        $this->audit->write(
            action: 'role.permissions_synced',
            entityType: 'role',
            entityId: $role->id,
            tenantId: $tenant->id,
            oldValues: ['permission_ids' => $oldIds],
            newValues: ['permission_ids' => $validIds]
        );

        return $role->load('permissions');
    }
}
