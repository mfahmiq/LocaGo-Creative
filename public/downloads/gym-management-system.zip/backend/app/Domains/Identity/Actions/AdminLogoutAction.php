<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Domains\Identity\Models\User;
use Laravel\Sanctum\PersonalAccessToken;

final class AdminLogoutAction extends Action
{
    public function execute(mixed ...$args): bool
    {
        /** @var User $user */
        $user = $args[0];

        $token = $user->currentAccessToken();

        if ($token instanceof PersonalAccessToken) {
            $token->delete();
        }

        return true;
    }
}
