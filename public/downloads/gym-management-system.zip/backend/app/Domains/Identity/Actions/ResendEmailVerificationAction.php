<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;

final class ResendEmailVerificationAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users
    ) {}

    /**
     * Always returns true to avoid account enumeration.
     */
    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var string $email */
        $email = strtolower(trim((string) $args[1]));

        $user = $this->users->findMemberByTenantAndEmail($tenant->id, $email);

        if ($user === null || ! $user->is_active || $user->hasVerifiedEmail() || ! $tenant->isOperable()) {
            return true;
        }

        $user->sendEmailVerificationNotification();

        return true;
    }
}
