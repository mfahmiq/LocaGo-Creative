<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\Role;
use App\Domains\Identity\Models\User;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Members\Models\Member;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Platform\Services\EntitlementGuard;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class MemberRegisterAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users,
        private readonly MemberRepositoryInterface $members,
        private readonly BranchRepositoryInterface $branches,
        private readonly RoleRepositoryInterface $roles,
        private readonly EntitlementGuard $entitlements
    ) {}

    /**
     * @param  array{
     *     first_name: string,
     *     last_name: string,
     *     email: string,
     *     password: string,
     *     phone?: string|null,
     *     home_branch_id?: int|null,
     *     device_name?: string
     * }  $data
     * @return array{user: User, member: Member, token: string, tenant: Tenant}
     */
    public function execute(mixed ...$args): array
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        return $this->transaction(function () use ($tenant, $data): array {
            $this->assertWithinMemberLimit($tenant);

            $email = strtolower(trim((string) $data['email']));

            if ($this->users->findByTenantAndEmail($tenant->id, $email) !== null
                || $this->members->emailExistsForTenant($tenant->id, $email)) {
                throw new DomainException(
                    'An account with this email already exists for this gym.',
                    'email_already_registered',
                    Response::HTTP_CONFLICT
                );
            }

            $branchId = isset($data['home_branch_id']) ? (int) $data['home_branch_id'] : null;
            $branch = $branchId
                ? $this->branches->findActiveForTenant($tenant->id, $branchId)
                : $this->branches->firstActiveForTenant($tenant->id);

            if ($branch === null) {
                throw new DomainException(
                    'No active branch is available for registration. Contact the gym.',
                    'branch_unavailable',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $user = $this->users->createMember([
                'tenant_id' => $tenant->id,
                'name' => trim($data['first_name'].' '.$data['last_name']),
                'email' => $email,
                'phone' => $data['phone'] ?? null,
                'password' => $data['password'],
                'email_verified_at' => null,
                'is_active' => true,
            ]);

            $member = $this->members->createMember([
                'tenant_id' => $tenant->id,
                'user_id' => $user->id,
                'home_branch_id' => $branch->id,
                'member_code' => $this->members->generateUniqueMemberCode($tenant->id),
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'email' => $email,
                'phone' => $data['phone'] ?? null,
                'status' => 'active',
                'joined_at' => now()->toDateString(),
                'referral_code' => $this->members->generateUniqueReferralCode($tenant->id),
            ]);

            $memberRole = $this->roles->findByCode($tenant->id, Role::CODE_MEMBER);
            if ($memberRole !== null) {
                $this->roles->syncUserRoles($user->id, [$memberRole->id]);
            }

            $token = $user->createToken(
                (string) ($data['device_name'] ?? 'member-portal'),
                ['member']
            )->plainTextToken;

            $user->sendEmailVerificationNotification();

            return [
                'user' => $user->fresh(),
                'member' => $member->fresh(),
                'token' => $token,
                'tenant' => $tenant,
            ];
        });
    }

    private function assertWithinMemberLimit(Tenant $tenant): void
    {
        $this->entitlements->assertCanAddMember($tenant);
    }
}
