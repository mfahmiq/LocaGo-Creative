<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\User;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Organization\Models\BranchUser;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

final class SyncStaffBranchesAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    /**
     * @param  list<int>  $branchIds
     */
    public function execute(mixed ...$args): User
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $userId */
        $userId = (int) $args[1];
        /** @var list<int> $branchIds */
        $branchIds = $args[2];

        $user = $this->users->findStaffByIdForTenant($tenant->id, $userId);

        if ($user === null) {
            throw new DomainException('Staff user not found.', 'staff_not_found', Response::HTTP_NOT_FOUND);
        }

        $validIds = [];
        foreach ($branchIds as $branchId) {
            $branch = $this->branches->findActiveForTenant($tenant->id, (int) $branchId);
            if ($branch === null) {
                throw new DomainException(
                    'One or more branches are invalid or inactive.',
                    'invalid_branch_ids',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }
            $validIds[] = $branch->id;
        }
        $validIds = array_values(array_unique($validIds));

        $oldIds = $user->branches()->pluck('branches.id')->all();

        BranchUser::query()
            ->where('tenant_id', $tenant->id)
            ->where('user_id', $user->id)
            ->delete();

        $actorId = Auth::id();
        $now = now();
        foreach ($validIds as $branchId) {
            BranchUser::query()->create([
                'tenant_id' => $tenant->id,
                'user_id' => $user->id,
                'branch_id' => $branchId,
                'created_at' => $now,
                'created_by' => $actorId,
            ]);
        }

        $this->audit->write(
            action: 'staff.branches_synced',
            entityType: 'user',
            entityId: $user->id,
            tenantId: $tenant->id,
            oldValues: ['branch_ids' => $oldIds],
            newValues: ['branch_ids' => $validIds]
        );

        return $user->load(['roles', 'branches']);
    }
}
