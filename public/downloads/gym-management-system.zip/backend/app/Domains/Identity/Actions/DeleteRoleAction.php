<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Models\Role;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeleteRoleAction extends Action
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $roleId */
        $roleId = (int) $args[1];

        $role = $this->roles->findForTenant($tenant->id, $roleId);

        if ($role === null) {
            throw new DomainException('Role not found.', 'role_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($role->is_system) {
            throw new DomainException(
                'System roles cannot be deleted.',
                'system_role_protected',
                Response::HTTP_FORBIDDEN
            );
        }

        if ($role->users()->exists()) {
            throw new DomainException(
                'Role is assigned to one or more users.',
                'role_in_use',
                Response::HTTP_CONFLICT
            );
        }

        return $this->roles->deleteRole($role);
    }
}
