<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\User;
use App\Domains\Identity\Notifications\ResetPasswordNotification;
use App\Domains\Identity\Support\PasswordResetKey;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

final class ForgotPasswordAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users
    ) {}

    /**
     * Always returns true to avoid account enumeration.
     */
    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var string $email */
        $email = strtolower(trim((string) $args[1]));
        /** @var string $portal admin|member */
        $portal = $args[2];

        $user = $portal === 'admin'
            ? $this->users->findStaffByTenantAndEmail($tenant->id, $email)
            : $this->users->findMemberByTenantAndEmail($tenant->id, $email);

        if ($user === null || ! $user->is_active || ! $tenant->isOperable()) {
            return true;
        }

        if ($portal === 'admin' && ! $user->canAccessAdminPortal()) {
            return true;
        }

        if ($portal === 'member' && ! $user->canAccessMemberPortal()) {
            return true;
        }

        $plainToken = Str::random(64);
        $key = PasswordResetKey::make($tenant->id, $email);

        DB::table('password_reset_tokens')->updateOrInsert(
            ['email' => $key],
            [
                'token' => Hash::make($plainToken),
                'created_at' => now(),
            ]
        );

        $user->notify(new ResetPasswordNotification($plainToken, $tenant, $portal));

        return true;
    }
}
