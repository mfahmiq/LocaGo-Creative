<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Models\Role;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateRoleAction extends Action
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles
    ) {}

    public function execute(mixed ...$args): Role
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $roleId */
        $roleId = (int) $args[1];
        /** @var array{name?: string, code?: string} $data */
        $data = $args[2];

        $role = $this->roles->findForTenant($tenant->id, $roleId);

        if ($role === null) {
            throw new DomainException('Role not found.', 'role_not_found', Response::HTTP_NOT_FOUND);
        }

        $payload = [];

        if (array_key_exists('name', $data)) {
            $payload['name'] = $data['name'];
        }

        if (array_key_exists('code', $data) && ! $role->is_system) {
            $code = strtolower(trim((string) $data['code']));
            $existing = $this->roles->findByCode($tenant->id, $code);

            if ($existing !== null && $existing->id !== $role->id) {
                throw new DomainException(
                    'A role with this code already exists.',
                    'role_code_exists',
                    Response::HTTP_CONFLICT
                );
            }

            $payload['code'] = $code;
        }

        if ($payload === []) {
            return $role;
        }

        return $this->roles->updateRole($role, $payload);
    }
}
