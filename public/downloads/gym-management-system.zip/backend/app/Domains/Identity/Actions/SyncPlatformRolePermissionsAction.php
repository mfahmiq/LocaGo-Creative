<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Contracts\PermissionRepositoryInterface;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Models\Role;
use Symfony\Component\HttpFoundation\Response;

final class SyncPlatformRolePermissionsAction extends Action
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles,
        private readonly PermissionRepositoryInterface $permissions,
        private readonly AuditWriter $audit
    ) {}

    /**
     * @param  list<int>  $permissionIds
     */
    public function execute(mixed ...$args): Role
    {
        /** @var int $roleId */
        $roleId = (int) $args[0];
        /** @var list<int> $permissionIds */
        $permissionIds = $args[1];

        $role = $this->roles->listPlatformRoles()->firstWhere('id', $roleId);

        if ($role === null) {
            throw new DomainException('Platform role not found.', 'role_not_found', Response::HTTP_NOT_FOUND);
        }

        $validIds = [];
        foreach ($permissionIds as $permissionId) {
            $permission = $this->permissions->findById((int) $permissionId);

            if ($permission === null || ! str_starts_with($permission->code, 'platform.')) {
                throw new DomainException(
                    'Only platform.* permissions can be assigned to platform roles.',
                    'invalid_permission_ids',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $validIds[] = $permission->id;
        }

        $oldIds = $this->permissions->permissionIdsForRole($role->id);
        $this->permissions->syncRolePermissions($role->id, $validIds);

        $this->audit->write(
            action: 'platform.role.permissions_synced',
            entityType: 'role',
            entityId: $role->id,
            tenantId: null,
            oldValues: ['permission_ids' => $oldIds],
            newValues: ['permission_ids' => $validIds]
        );

        return $role->load('permissions');
    }
}
