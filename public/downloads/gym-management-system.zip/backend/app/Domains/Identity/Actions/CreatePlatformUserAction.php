<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\User;
use Symfony\Component\HttpFoundation\Response;

final class CreatePlatformUserAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users,
        private readonly RoleRepositoryInterface $roles,
        private readonly AuditWriter $audit
    ) {}

    /**
     * @param  array{name: string, email: string, password: string, phone?: string|null, role_ids?: list<int>, is_active?: bool}  $data
     */
    public function execute(mixed ...$args): User
    {
        /** @var array{name: string, email: string, password: string, phone?: string|null, role_ids?: list<int>, is_active?: bool} $data */
        $data = $args[0];

        $email = strtolower(trim($data['email']));

        if ($this->users->findPlatformByEmail($email) !== null) {
            throw new DomainException(
                'A platform user with this email already exists.',
                'platform_user_email_exists',
                Response::HTTP_CONFLICT
            );
        }

        $roleIds = $this->validatePlatformRoleIds($data['role_ids'] ?? []);

        $user = $this->users->createPlatformUser([
            'name' => trim($data['name']),
            'email' => $email,
            'phone' => isset($data['phone']) && $data['phone'] !== '' ? trim((string) $data['phone']) : null,
            'password' => $data['password'],
            'email_verified_at' => now(),
            'is_active' => $data['is_active'] ?? true,
        ]);

        if ($roleIds !== []) {
            $this->roles->syncUserRoles($user->id, $roleIds);
        }

        $this->audit->write(
            action: 'platform.user.created',
            entityType: 'user',
            entityId: $user->id,
            tenantId: null,
            newValues: [
                'email' => $user->email,
                'name' => $user->name,
                'role_ids' => $roleIds,
            ]
        );

        return $user->load('roles');
    }

    /**
     * @param  list<int>  $roleIds
     * @return list<int>
     */
    private function validatePlatformRoleIds(array $roleIds): array
    {
        $validIds = [];
        $platformRoles = $this->roles->listPlatformRoles()->keyBy('id');

        foreach ($roleIds as $roleId) {
            $role = $platformRoles->get((int) $roleId);

            if ($role === null) {
                throw new DomainException(
                    'One or more roles are invalid for platform users.',
                    'invalid_role_ids',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $validIds[] = $role->id;
        }

        return $validIds;
    }
}
