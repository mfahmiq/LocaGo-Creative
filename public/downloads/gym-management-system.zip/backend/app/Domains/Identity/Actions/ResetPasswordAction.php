<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Support\PasswordResetKey;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpFoundation\Response;

final class ResetPasswordAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var string $email */
        $email = strtolower(trim((string) $args[1]));
        /** @var string $token */
        $token = (string) $args[2];
        /** @var string $password */
        $password = (string) $args[3];
        /** @var string $portal */
        $portal = (string) $args[4];

        return $this->transaction(function () use ($tenant, $email, $token, $password, $portal): bool {
            $user = $portal === 'admin'
                ? $this->users->findStaffByTenantAndEmail($tenant->id, $email)
                : $this->users->findMemberByTenantAndEmail($tenant->id, $email);

            if ($user === null || ! $user->is_active) {
                throw new DomainException(
                    'Invalid or expired password reset token.',
                    'invalid_reset_token',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $key = PasswordResetKey::make($tenant->id, $email);
            $record = DB::table('password_reset_tokens')->where('email', $key)->first();

            if ($record === null || ! Hash::check($token, $record->token)) {
                throw new DomainException(
                    'Invalid or expired password reset token.',
                    'invalid_reset_token',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $expireMinutes = (int) config('gms.password_reset.expire_minutes', 60);
            $createdAt = $record->created_at ? Carbon::parse($record->created_at) : null;

            if ($createdAt === null || $createdAt->copy()->addMinutes($expireMinutes)->isPast()) {
                DB::table('password_reset_tokens')->where('email', $key)->delete();

                throw new DomainException(
                    'Invalid or expired password reset token.',
                    'invalid_reset_token',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $user->forceFill([
                'password' => $password,
            ])->save();

            $user->tokens()->delete();

            DB::table('password_reset_tokens')->where('email', $key)->delete();

            return true;
        });
    }
}
