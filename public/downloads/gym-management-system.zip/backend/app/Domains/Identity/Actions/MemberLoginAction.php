<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\User;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Members\Models\Member;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpFoundation\Response;

final class MemberLoginAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users,
        private readonly MemberRepositoryInterface $members
    ) {}

    /**
     * @return array{user: User, member: Member, token: string, tenant: Tenant}
     */
    public function execute(mixed ...$args): array
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var string $email */
        $email = strtolower(trim((string) $args[1]));
        /** @var string $password */
        $password = $args[2];
        /** @var string $deviceName */
        $deviceName = $args[3] ?? 'member-portal';

        return $this->transaction(function () use ($tenant, $email, $password, $deviceName): array {
            $user = $this->users->findMemberByTenantAndEmail($tenant->id, $email);

            if ($user === null || ! Hash::check($password, $user->password)) {
                throw new DomainException(
                    'Invalid email or password.',
                    'invalid_credentials',
                    Response::HTTP_UNAUTHORIZED
                );
            }

            if (! $user->canAccessMemberPortal()) {
                throw new DomainException(
                    'Member account is inactive.',
                    'account_inactive',
                    Response::HTTP_FORBIDDEN
                );
            }

            if (! $tenant->isOperable()) {
                throw new DomainException(
                    'Tenant is not available for login.',
                    'tenant_inactive',
                    Response::HTTP_FORBIDDEN
                );
            }

            $member = $this->members->findByUserId($tenant->id, $user->id);

            if ($member === null) {
                throw new DomainException(
                    'Member profile not found.',
                    'member_profile_missing',
                    Response::HTTP_FORBIDDEN
                );
            }

            if ($member->status === 'blacklisted') {
                throw new DomainException(
                    'This member account is not allowed to sign in.',
                    'member_blacklisted',
                    Response::HTTP_FORBIDDEN
                );
            }

            if (! $user->hasVerifiedEmail()) {
                throw new DomainException(
                    'Please verify your email address before signing in.',
                    'email_not_verified',
                    Response::HTTP_FORBIDDEN
                );
            }

            $user->forceFill(['last_login_at' => now()])->save();

            $token = $user->createToken($deviceName, ['member'])->plainTextToken;

            return [
                'user' => $user->fresh(),
                'member' => $member,
                'token' => $token,
                'tenant' => $tenant,
            ];
        });
    }
}
