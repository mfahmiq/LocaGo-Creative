<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Auth\Events\Verified;
use Symfony\Component\HttpFoundation\Response;

final class VerifyEmailAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users
    ) {}

    public function execute(mixed ...$args): User
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $userId */
        $userId = (int) $args[1];
        /** @var string $hash */
        $hash = (string) $args[2];

        $user = $this->users->findMemberByIdForTenant($tenant->id, $userId);

        if ($user === null) {
            throw new DomainException(
                'Invalid verification link.',
                'invalid_verification_link',
                Response::HTTP_FORBIDDEN
            );
        }

        if (! hash_equals(sha1($user->getEmailForVerification()), $hash)) {
            throw new DomainException(
                'Invalid verification link.',
                'invalid_verification_link',
                Response::HTTP_FORBIDDEN
            );
        }

        if ($user->hasVerifiedEmail()) {
            return $user;
        }

        if ($user->markEmailAsVerified()) {
            event(new Verified($user));
        }

        return $user->fresh();
    }
}
