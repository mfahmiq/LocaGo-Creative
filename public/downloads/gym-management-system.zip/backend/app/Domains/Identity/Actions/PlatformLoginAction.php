<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\User;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpFoundation\Response;

final class PlatformLoginAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users
    ) {}

    /**
     * @return array{user: User, token: string}
     */
    public function execute(mixed ...$args): array
    {
        /** @var string $email */
        $email = $args[0];
        /** @var string $password */
        $password = $args[1];
        /** @var string $deviceName */
        $deviceName = $args[2] ?? 'platform-console';

        $user = $this->users->findPlatformByEmail($email);

        if ($user === null || ! Hash::check($password, $user->password)) {
            throw new DomainException(
                'Invalid email or password.',
                'invalid_credentials',
                Response::HTTP_UNAUTHORIZED
            );
        }

        if (! $user->canAccessPlatformConsole()) {
            throw new DomainException(
                'Platform account is inactive.',
                'account_inactive',
                Response::HTTP_FORBIDDEN
            );
        }

        $user->forceFill(['last_login_at' => now()])->save();

        $token = $user->createToken($deviceName, ['platform'])->plainTextToken;

        return [
            'user' => $user->fresh()->load('roles.permissions'),
            'token' => $token,
        ];
    }
}
