<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Domains\Identity\Contracts\PermissionRepositoryInterface;
use App\Domains\Identity\Models\Permission;

final class SeedPermissionsAction extends Action
{
    public function __construct(
        private readonly PermissionRepositoryInterface $permissions
    ) {}

    /**
     * @return list<Permission>
     */
    public function execute(mixed ...$args): array
    {
        $created = [];

        foreach (Permission::defaultCatalog() as $item) {
            $existing = $this->permissions->findByCode($item['code']);

            if ($existing !== null) {
                $created[] = $existing;

                continue;
            }

            $created[] = $this->permissions->createPermission($item);
        }

        return $created;
    }
}
