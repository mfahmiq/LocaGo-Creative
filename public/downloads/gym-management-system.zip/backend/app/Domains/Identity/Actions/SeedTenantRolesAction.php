<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Models\Role;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\DB;

final class SeedTenantRolesAction extends Action
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles
    ) {}

    /**
     * @return list<Role>
     */
    public function execute(mixed ...$args): array
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];

        $this->migrateLegacyOwner($tenant);

        $created = [];

        foreach (Role::defaultCatalog() as $item) {
            $existing = $this->roles->findByCode($tenant->id, $item['code']);

            if ($existing !== null) {
                if ($existing->name !== $item['name']) {
                    $this->roles->updateRole($existing, ['name' => $item['name']]);
                }
                $created[] = $existing->fresh();

                continue;
            }

            $created[] = $this->roles->createRole([
                'tenant_id' => $tenant->id,
                'code' => $item['code'],
                'name' => $item['name'],
                'is_system' => true,
            ]);
        }

        $this->retireObsoleteRoles($tenant);

        return $created;
    }

    /**
     * Soft-delete legacy system roles removed from the approved catalog.
     */
    private function retireObsoleteRoles(Tenant $tenant): void
    {
        $allowed = array_column(Role::defaultCatalog(), 'code');

        Role::query()
            ->withoutGlobalScope('tenant')
            ->where('tenant_id', $tenant->id)
            ->where('is_system', true)
            ->whereNotIn('code', $allowed)
            ->whereNull('deleted_at')
            ->each(function (Role $role): void {
                DB::table('user_roles')->where('role_id', $role->id)->delete();
                DB::table('role_permissions')->where('role_id', $role->id)->delete();
                $role->delete();
            });
    }

    /**
     * Cutover: rename legacy code `owner` → `gym_owner`.
     */
    private function migrateLegacyOwner(Tenant $tenant): void
    {
        $legacy = Role::query()
            ->withoutGlobalScope('tenant')
            ->where('tenant_id', $tenant->id)
            ->where('code', 'owner')
            ->first();

        if ($legacy === null) {
            return;
        }

        $target = $this->roles->findByCode($tenant->id, Role::CODE_GYM_OWNER);

        if ($target === null) {
            $legacy->forceFill([
                'code' => Role::CODE_GYM_OWNER,
                'name' => 'Gym Owner',
                'is_system' => true,
            ])->save();

            return;
        }

        DB::table('user_roles')
            ->where('role_id', $legacy->id)
            ->whereNotIn('user_id', function ($query) use ($target): void {
                $query->select('user_id')
                    ->from('user_roles')
                    ->where('role_id', $target->id);
            })
            ->update(['role_id' => $target->id]);

        DB::table('user_roles')->where('role_id', $legacy->id)->delete();
        DB::table('role_permissions')->where('role_id', $legacy->id)->delete();
        $legacy->delete();
    }
}
