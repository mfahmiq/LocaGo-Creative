<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Models\Role;
use Symfony\Component\HttpFoundation\Response;

final class UpdatePlatformRoleAction extends Action
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Role
    {
        /** @var int $roleId */
        $roleId = (int) $args[0];
        /** @var array{name?: string, code?: string} $data */
        $data = $args[1];

        $role = $this->roles->listPlatformRoles()->firstWhere('id', $roleId);

        if ($role === null) {
            throw new DomainException('Platform role not found.', 'role_not_found', Response::HTTP_NOT_FOUND);
        }

        $payload = [];
        $old = ['code' => $role->code, 'name' => $role->name];

        if (array_key_exists('name', $data)) {
            $payload['name'] = $data['name'];
        }

        if (array_key_exists('code', $data)) {
            if ($role->is_system) {
                throw new DomainException(
                    'System role codes cannot be changed.',
                    'system_role_protected',
                    Response::HTTP_FORBIDDEN
                );
            }

            $code = strtolower(trim((string) $data['code']));
            $existing = $this->roles->findPlatformByCode($code);

            if ($existing !== null && $existing->id !== $role->id) {
                throw new DomainException(
                    'A platform role with this code already exists.',
                    'role_code_exists',
                    Response::HTTP_CONFLICT
                );
            }

            $payload['code'] = $code;
        }

        if ($payload === []) {
            return $role;
        }

        $updated = $this->roles->updateRole($role, $payload);

        $this->audit->write(
            action: 'platform.role.updated',
            entityType: 'role',
            entityId: $updated->id,
            tenantId: null,
            oldValues: $old,
            newValues: ['code' => $updated->code, 'name' => $updated->name]
        );

        return $updated;
    }
}
