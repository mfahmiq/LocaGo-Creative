<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\Role;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateStaffAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users,
        private readonly RoleRepositoryInterface $roles,
        private readonly AuditWriter $audit
    ) {}

    /**
     * @param  array{name?: string, email?: string, phone?: string|null, is_active?: bool, password?: string}  $data
     */
    public function execute(mixed ...$args): User
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $userId */
        $userId = (int) $args[1];
        /** @var array{name?: string, email?: string, phone?: string|null, is_active?: bool, password?: string} $data */
        $data = $args[2];
        /** @var User|null $actor */
        $actor = $args[3] ?? null;

        $user = $this->users->findStaffByIdForTenant($tenant->id, $userId);

        if ($user === null) {
            throw new DomainException('Staff user not found.', 'staff_not_found', Response::HTTP_NOT_FOUND);
        }

        $payload = [];
        $old = [
            'name' => $user->name,
            'email' => $user->email,
            'phone' => $user->phone,
            'is_active' => $user->is_active,
        ];

        if (array_key_exists('name', $data)) {
            $payload['name'] = trim((string) $data['name']);
        }

        if (array_key_exists('phone', $data)) {
            $phone = $data['phone'];
            $payload['phone'] = is_string($phone) && trim($phone) !== '' ? trim($phone) : null;
        }

        if (array_key_exists('email', $data)) {
            $email = strtolower(trim((string) $data['email']));
            $existing = $this->users->findStaffByTenantAndEmail($tenant->id, $email);
            if ($existing !== null && $existing->id !== $user->id) {
                throw new DomainException(
                    'A staff user with this email already exists.',
                    'staff_email_exists',
                    Response::HTTP_CONFLICT
                );
            }
            $payload['email'] = $email;
        }

        if (array_key_exists('password', $data) && is_string($data['password']) && $data['password'] !== '') {
            $payload['password'] = $data['password'];
        }

        if (array_key_exists('is_active', $data)) {
            $nextActive = (bool) $data['is_active'];

            if ($actor instanceof User && $actor->id === $user->id && ! $nextActive) {
                throw new DomainException(
                    'You cannot deactivate your own account.',
                    'cannot_deactivate_self',
                    Response::HTTP_FORBIDDEN
                );
            }

            if ($user->is_active && ! $nextActive) {
                $this->guardLastActiveOwner($tenant, $user);
            }

            $payload['is_active'] = $nextActive;
        }

        if ($payload === []) {
            return $user->load(['roles', 'branches']);
        }

        $updated = $this->users->updateStaff($user, $payload)->load(['roles', 'branches']);

        $this->audit->write(
            action: 'staff.updated',
            entityType: 'user',
            entityId: $updated->id,
            tenantId: $tenant->id,
            oldValues: $old,
            newValues: [
                'name' => $updated->name,
                'email' => $updated->email,
                'phone' => $updated->phone,
                'is_active' => $updated->is_active,
                'password_changed' => array_key_exists('password', $payload),
            ]
        );

        return $updated;
    }

    private function guardLastActiveOwner(Tenant $tenant, User $user): void
    {
        $ownerRole = $this->roles->findByCode($tenant->id, Role::CODE_GYM_OWNER);

        if ($ownerRole === null || ! $user->roles()->where('roles.id', $ownerRole->id)->exists()) {
            return;
        }

        $otherActive = $ownerRole->users()
            ->where('users.id', '!=', $user->id)
            ->where('users.tenant_id', $tenant->id)
            ->where('users.user_type', User::TYPE_STAFF)
            ->where('users.is_active', true)
            ->whereNull('users.deleted_at')
            ->count();

        if ($otherActive === 0) {
            throw new DomainException(
                'Cannot deactivate the last active Gym Owner.',
                'last_owner_protected',
                Response::HTTP_FORBIDDEN
            );
        }
    }
}
