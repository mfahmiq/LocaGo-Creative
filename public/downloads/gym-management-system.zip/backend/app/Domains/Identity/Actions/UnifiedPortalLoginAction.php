<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\User;
use App\Domains\Organization\Models\Branch;
use App\Domains\Tenancy\Models\Tenant;
use App\Domains\Tenancy\Services\TenantResolver;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpFoundation\Response;

/**
 * Single Admin Portal login for platform operators and tenant staff.
 * Tenant slug is optional (only used to disambiguate the same email across tenants).
 */
final class UnifiedPortalLoginAction extends Action
{
    public const PORTAL_PLATFORM = 'platform';

    public const PORTAL_ADMIN = 'admin';

    public function __construct(
        private readonly UserRepositoryInterface $users,
        private readonly TenantResolver $tenants
    ) {}

    /**
     * @return array{
     *     user: User,
     *     token: string,
     *     portal: string,
     *     tenant: ?Tenant,
     *     branches: list<array{id: int, code: string, name: string}>,
     *     is_tenant_wide: bool
     * }
     */
    public function execute(mixed ...$args): array
    {
        /** @var string $email */
        $email = $args[0];
        /** @var string $password */
        $password = $args[1];
        /** @var string $deviceName */
        $deviceName = $args[2] ?? 'admin-portal';
        /** @var string|null $tenantSlug */
        $tenantSlug = $args[3] ?? null;

        return $this->transaction(function () use ($email, $password, $deviceName, $tenantSlug): array {
            $platform = $this->users->findPlatformByEmail($email);

            if ($platform !== null) {
                return $this->loginPlatform($platform, $password, $deviceName);
            }

            if (is_string($tenantSlug) && $tenantSlug !== '') {
                $tenant = $this->tenants->resolveFromSlug($tenantSlug);

                return $this->loginStaffForTenant($tenant, $email, $password, $deviceName);
            }

            $candidates = $this->users->findStaffAccountsByEmail($email);

            /** @var Collection<int, User> $matches */
            $matches = $candidates->filter(
                fn (User $user): bool => Hash::check($password, $user->password)
            )->values();

            if ($matches->isEmpty()) {
                throw new DomainException(
                    'Invalid email or password.',
                    'invalid_credentials',
                    Response::HTTP_UNAUTHORIZED
                );
            }

            if ($matches->count() > 1) {
                throw new DomainException(
                    'Multiple gym accounts use this email. Choose a tenant to continue.',
                    'ambiguous_tenant',
                    Response::HTTP_CONFLICT,
                    null,
                    [
                        'tenants' => $matches
                            ->map(function (User $user): array {
                                $tenant = $user->tenant;

                                return [
                                    'id' => $tenant?->id,
                                    'slug' => $tenant?->slug,
                                    'name' => $tenant?->name,
                                ];
                            })
                            ->filter(fn (array $row): bool => $row['slug'] !== null)
                            ->values()
                            ->all(),
                    ]
                );
            }

            /** @var User $user */
            $user = $matches->first();
            $tenant = $user->tenant;

            if (! $tenant instanceof Tenant) {
                throw new DomainException(
                    'Staff account is missing a tenant.',
                    'tenant_missing',
                    Response::HTTP_FORBIDDEN
                );
            }

            return $this->finalizeStaffLogin($user, $tenant, $deviceName);
        });
    }

    /**
     * @return array{
     *     user: User,
     *     token: string,
     *     portal: string,
     *     tenant: null,
     *     branches: list<array{id: int, code: string, name: string}>,
     *     is_tenant_wide: bool
     * }
     */
    private function loginPlatform(User $user, string $password, string $deviceName): array
    {
        if (! Hash::check($password, $user->password)) {
            throw new DomainException(
                'Invalid email or password.',
                'invalid_credentials',
                Response::HTTP_UNAUTHORIZED
            );
        }

        if (! $user->canAccessPlatformConsole()) {
            throw new DomainException(
                'Platform account is inactive.',
                'account_inactive',
                Response::HTTP_FORBIDDEN
            );
        }

        $user->forceFill(['last_login_at' => now()])->save();

        $token = $user->createToken($deviceName, ['platform'])->plainTextToken;

        return [
            'user' => $user->fresh()->load('roles.permissions'),
            'token' => $token,
            'portal' => self::PORTAL_PLATFORM,
            'tenant' => null,
            'branches' => [],
            'is_tenant_wide' => true,
        ];
    }

    /**
     * @return array{
     *     user: User,
     *     token: string,
     *     portal: string,
     *     tenant: Tenant,
     *     branches: list<array{id: int, code: string, name: string}>,
     *     is_tenant_wide: bool
     * }
     */
    private function loginStaffForTenant(Tenant $tenant, string $email, string $password, string $deviceName): array
    {
        $user = $this->users->findStaffByTenantAndEmail($tenant->id, $email);

        if ($user === null || ! Hash::check($password, $user->password)) {
            throw new DomainException(
                'Invalid email or password.',
                'invalid_credentials',
                Response::HTTP_UNAUTHORIZED
            );
        }

        return $this->finalizeStaffLogin($user, $tenant, $deviceName);
    }

    /**
     * @return array{
     *     user: User,
     *     token: string,
     *     portal: string,
     *     tenant: Tenant,
     *     branches: list<array{id: int, code: string, name: string}>,
     *     is_tenant_wide: bool
     * }
     */
    private function finalizeStaffLogin(User $user, Tenant $tenant, string $deviceName): array
    {
        if (! $user->canAccessAdminPortal()) {
            throw new DomainException(
                'Staff account is inactive.',
                'account_inactive',
                Response::HTTP_FORBIDDEN
            );
        }

        if (! $tenant->isOperable()) {
            throw new DomainException(
                'Tenant is not available for login.',
                'tenant_inactive',
                Response::HTTP_FORBIDDEN
            );
        }

        $this->tenants->bind($tenant);

        $user->forceFill(['last_login_at' => now()])->save();

        $token = $user->createToken($deviceName, ['admin'])->plainTextToken;
        $fresh = $user->fresh()->load(['roles.permissions', 'branchAssignments', 'branches']);
        $isTenantWide = $fresh->isTenantWideStaff();

        return [
            'user' => $fresh,
            'token' => $token,
            'portal' => self::PORTAL_ADMIN,
            'tenant' => $tenant,
            'branches' => $this->branchPayload($fresh, $tenant, $isTenantWide),
            'is_tenant_wide' => $isTenantWide,
        ];
    }

    /**
     * @return list<array{id: int, code: string, name: string}>
     */
    private function branchPayload(User $user, Tenant $tenant, bool $isTenantWide): array
    {
        $branches = $isTenantWide
            ? Branch::query()
                ->where('tenant_id', $tenant->id)
                ->where('is_active', true)
                ->whereNull('deleted_at')
                ->orderBy('name')
                ->get(['id', 'code', 'name'])
            : $user->branches()
                ->where('branches.is_active', true)
                ->whereNull('branches.deleted_at')
                ->orderBy('branches.name')
                ->get(['branches.id', 'branches.code', 'branches.name']);

        return $branches
            ->map(fn (Branch $branch): array => [
                'id' => (int) $branch->id,
                'code' => (string) $branch->code,
                'name' => (string) $branch->name,
            ])
            ->values()
            ->all();
    }
}
