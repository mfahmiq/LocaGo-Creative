<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Domains\Identity\Contracts\PermissionRepositoryInterface;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Models\Permission;
use App\Domains\Identity\Models\Role;
use App\Domains\Tenancy\Models\Tenant;

final class ApplyDefaultRolePermissionsAction extends Action
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles,
        private readonly PermissionRepositoryInterface $permissions
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];

        $codeToId = [];
        foreach ($this->permissions->listAll() as $permission) {
            $codeToId[$permission->code] = $permission->id;
        }

        foreach (Permission::defaultRoleMatrix() as $roleCode => $permissionCodes) {
            if (in_array($roleCode, [Role::CODE_SUPER_ADMIN, Role::CODE_PLATFORM_SUPPORT], true)) {
                continue;
            }

            $role = $this->roles->findByCode($tenant->id, $roleCode);

            if ($role === null) {
                continue;
            }

            $ids = [];
            foreach ($permissionCodes as $code) {
                if (isset($codeToId[$code])) {
                    $ids[] = $codeToId[$code];
                }
            }

            $this->permissions->syncRolePermissions($role->id, $ids);
        }

        return true;
    }
}
