<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\Role;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class SyncUserRolesAction extends Action
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles,
        private readonly UserRepositoryInterface $users,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): User
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $userId */
        $userId = (int) $args[1];
        /** @var list<int> $roleIds */
        $roleIds = $args[2];

        $user = $this->users->findStaffByIdForTenant($tenant->id, $userId);

        if ($user === null) {
            throw new DomainException('Staff user not found.', 'staff_not_found', Response::HTTP_NOT_FOUND);
        }

        $validIds = [];
        foreach ($roleIds as $roleId) {
            $role = $this->roles->findForTenant($tenant->id, (int) $roleId);

            if ($role === null) {
                throw new DomainException(
                    'One or more roles are invalid for this tenant.',
                    'invalid_role_ids',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $validIds[] = $role->id;
        }

        $ownerRole = $this->roles->findByCode($tenant->id, Role::CODE_GYM_OWNER);
        $hadOwner = $ownerRole !== null && $user->hasRole(Role::CODE_GYM_OWNER);
        $willHaveOwner = $ownerRole !== null && in_array($ownerRole->id, $validIds, true);

        if ($hadOwner && ! $willHaveOwner) {
            $otherOwners = $ownerRole->users()
                ->where('users.id', '!=', $user->id)
                ->where('users.tenant_id', $tenant->id)
                ->whereNull('users.deleted_at')
                ->count();

            if ($otherOwners === 0) {
                throw new DomainException(
                    'Cannot remove the last Owner role assignment.',
                    'last_owner_protected',
                    Response::HTTP_FORBIDDEN
                );
            }
        }

        $oldRoleIds = $user->roles()->pluck('roles.id')->all();

        $this->roles->syncUserRoles($user->id, $validIds);

        $this->audit->write(
            action: 'staff.roles_synced',
            entityType: 'user',
            entityId: $user->id,
            tenantId: $tenant->id,
            oldValues: ['role_ids' => $oldRoleIds],
            newValues: ['role_ids' => $validIds]
        );

        return $user->load('roles');
    }
}
