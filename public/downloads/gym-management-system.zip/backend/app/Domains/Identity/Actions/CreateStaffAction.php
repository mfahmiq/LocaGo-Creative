<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\User;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Organization\Models\BranchUser;
use App\Domains\Platform\Services\EntitlementGuard;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

final class CreateStaffAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users,
        private readonly RoleRepositoryInterface $roles,
        private readonly BranchRepositoryInterface $branches,
        private readonly EntitlementGuard $entitlements,
        private readonly AuditWriter $audit
    ) {}

    /**
     * @param  array{name: string, email: string, password: string, phone?: string|null, is_active?: bool, role_ids?: list<int>, branch_ids?: list<int>}  $data
     */
    public function execute(mixed ...$args): User
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array{name: string, email: string, password: string, phone?: string|null, is_active?: bool, role_ids?: list<int>, branch_ids?: list<int>} $data */
        $data = $args[1];

        return $this->transaction(function () use ($tenant, $data): User {
            $this->entitlements->assertCanAddSeat($tenant);

            $email = strtolower(trim($data['email']));

            if ($this->users->findStaffByTenantAndEmail($tenant->id, $email) !== null) {
                throw new DomainException(
                    'A staff user with this email already exists.',
                    'staff_email_exists',
                    Response::HTTP_CONFLICT
                );
            }

            $roleIds = $this->validateRoleIds($tenant->id, $data['role_ids'] ?? []);
            $branchIds = $this->validateBranchIds($tenant->id, $data['branch_ids'] ?? []);

            $user = $this->users->createStaff([
                'tenant_id' => $tenant->id,
                'name' => trim($data['name']),
                'email' => $email,
                'phone' => isset($data['phone']) && $data['phone'] !== '' ? trim((string) $data['phone']) : null,
                'password' => $data['password'],
                'email_verified_at' => now(),
                'is_active' => $data['is_active'] ?? true,
            ]);

            if ($roleIds !== []) {
                $this->roles->syncUserRoles($user->id, $roleIds);
            }

            $this->syncBranches($tenant->id, $user->id, $branchIds);

            $this->audit->write(
                action: 'staff.created',
                entityType: 'user',
                entityId: $user->id,
                tenantId: $tenant->id,
                newValues: [
                    'email' => $user->email,
                    'name' => $user->name,
                    'role_ids' => $roleIds,
                    'branch_ids' => $branchIds,
                ]
            );

            return $user->load(['roles', 'branches']);
        });
    }

    /**
     * @param  list<int>  $roleIds
     * @return list<int>
     */
    private function validateRoleIds(int $tenantId, array $roleIds): array
    {
        $valid = [];
        foreach ($roleIds as $roleId) {
            $role = $this->roles->findForTenant($tenantId, (int) $roleId);
            if ($role === null) {
                throw new DomainException(
                    'One or more roles are invalid for this tenant.',
                    'invalid_role_ids',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }
            $valid[] = $role->id;
        }

        return $valid;
    }

    /**
     * @param  list<int>  $branchIds
     * @return list<int>
     */
    private function validateBranchIds(int $tenantId, array $branchIds): array
    {
        $valid = [];
        foreach ($branchIds as $branchId) {
            $branch = $this->branches->findActiveForTenant($tenantId, (int) $branchId);
            if ($branch === null) {
                throw new DomainException(
                    'One or more branches are invalid or inactive.',
                    'invalid_branch_ids',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }
            $valid[] = $branch->id;
        }

        return array_values(array_unique($valid));
    }

    /**
     * @param  list<int>  $branchIds
     */
    private function syncBranches(int $tenantId, int $userId, array $branchIds): void
    {
        BranchUser::query()
            ->where('tenant_id', $tenantId)
            ->where('user_id', $userId)
            ->delete();

        $actorId = Auth::id();
        $now = now();

        foreach ($branchIds as $branchId) {
            BranchUser::query()->create([
                'tenant_id' => $tenantId,
                'user_id' => $userId,
                'branch_id' => $branchId,
                'created_at' => $now,
                'created_by' => $actorId,
            ]);
        }
    }
}
