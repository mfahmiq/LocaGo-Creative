<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Identity\Models\User;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpFoundation\Response;

final class ChangePasswordAction extends Action
{
    public function execute(mixed ...$args): User
    {
        /** @var User $user */
        $user = $args[0];
        /** @var string $currentPassword */
        $currentPassword = (string) $args[1];
        /** @var string $newPassword */
        $newPassword = (string) $args[2];

        if (! Hash::check($currentPassword, (string) $user->password)) {
            throw new DomainException(
                'Current password is incorrect.',
                'invalid_current_password',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $user->forceFill([
            'password' => Hash::make($newPassword),
        ])->save();

        return $user->refresh();
    }
}
