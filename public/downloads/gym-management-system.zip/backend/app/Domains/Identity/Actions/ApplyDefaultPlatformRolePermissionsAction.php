<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Domains\Identity\Contracts\PermissionRepositoryInterface;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Models\Permission;
use App\Domains\Identity\Models\Role;

final class ApplyDefaultPlatformRolePermissionsAction extends Action
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles,
        private readonly PermissionRepositoryInterface $permissions
    ) {}

    public function execute(mixed ...$args): bool
    {
        $codeToId = [];
        foreach ($this->permissions->listAll() as $permission) {
            $codeToId[$permission->code] = $permission->id;
        }

        $matrix = Permission::defaultRoleMatrix();

        foreach ([Role::CODE_SUPER_ADMIN, Role::CODE_PLATFORM_SUPPORT] as $roleCode) {
            $role = $this->roles->findPlatformByCode($roleCode);

            if ($role === null) {
                continue;
            }

            $ids = [];
            foreach ($matrix[$roleCode] ?? [] as $code) {
                if (isset($codeToId[$code])) {
                    $ids[] = $codeToId[$code];
                }
            }

            $this->permissions->syncRolePermissions($role->id, $ids);
        }

        return true;
    }
}
