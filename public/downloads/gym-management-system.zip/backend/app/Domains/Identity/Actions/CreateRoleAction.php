<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Models\Role;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CreateRoleAction extends Action
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles
    ) {}

    public function execute(mixed ...$args): Role
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array{code: string, name: string} $data */
        $data = $args[1];

        $code = strtolower(trim($data['code']));

        if ($this->roles->findByCode($tenant->id, $code) !== null) {
            throw new DomainException(
                'A role with this code already exists.',
                'role_code_exists',
                Response::HTTP_CONFLICT
            );
        }

        return $this->roles->createRole([
            'tenant_id' => $tenant->id,
            'code' => $code,
            'name' => $data['name'],
            'is_system' => false,
        ]);
    }
}
