<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\Role;
use App\Domains\Identity\Models\User;
use Symfony\Component\HttpFoundation\Response;

final class SyncPlatformUserRolesAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users,
        private readonly RoleRepositoryInterface $roles,
        private readonly AuditWriter $audit
    ) {}

    /**
     * @param  list<int>  $roleIds
     */
    public function execute(mixed ...$args): User
    {
        /** @var int $userId */
        $userId = (int) $args[0];
        /** @var list<int> $roleIds */
        $roleIds = $args[1];

        $user = $this->users->findPlatformById($userId);

        if ($user === null) {
            throw new DomainException('Platform user not found.', 'platform_user_not_found', Response::HTTP_NOT_FOUND);
        }

        $platformRoles = $this->roles->listPlatformRoles()->keyBy('id');
        $validIds = [];

        foreach ($roleIds as $roleId) {
            $role = $platformRoles->get((int) $roleId);

            if ($role === null) {
                throw new DomainException(
                    'One or more roles are invalid for platform users.',
                    'invalid_role_ids',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $validIds[] = $role->id;
        }

        $superAdmin = $this->roles->findPlatformByCode(Role::CODE_SUPER_ADMIN);
        $hadSuper = $superAdmin !== null && $user->roles()->where('roles.id', $superAdmin->id)->exists();
        $willHaveSuper = $superAdmin !== null && in_array($superAdmin->id, $validIds, true);

        if ($hadSuper && ! $willHaveSuper) {
            $otherSuperAdmins = $superAdmin->users()
                ->where('users.id', '!=', $user->id)
                ->whereNull('users.tenant_id')
                ->where('users.user_type', User::TYPE_PLATFORM)
                ->whereNull('users.deleted_at')
                ->count();

            if ($otherSuperAdmins === 0) {
                throw new DomainException(
                    'Cannot remove the last Super Admin role assignment.',
                    'last_super_admin_protected',
                    Response::HTTP_FORBIDDEN
                );
            }
        }

        $oldRoleIds = $user->roles()->pluck('roles.id')->all();
        $this->roles->syncUserRoles($user->id, $validIds);

        $this->audit->write(
            action: 'platform.user.roles_synced',
            entityType: 'user',
            entityId: $user->id,
            tenantId: null,
            oldValues: ['role_ids' => $oldRoleIds],
            newValues: ['role_ids' => $validIds]
        );

        return $user->load('roles');
    }
}
