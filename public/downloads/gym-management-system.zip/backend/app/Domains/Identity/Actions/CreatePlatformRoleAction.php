<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Models\Role;
use Symfony\Component\HttpFoundation\Response;

final class CreatePlatformRoleAction extends Action
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Role
    {
        /** @var array{code: string, name: string} $data */
        $data = $args[0];

        $code = strtolower(trim($data['code']));

        if ($this->roles->findPlatformByCode($code) !== null) {
            throw new DomainException(
                'A platform role with this code already exists.',
                'role_code_exists',
                Response::HTTP_CONFLICT
            );
        }

        $role = $this->roles->createRole([
            'tenant_id' => null,
            'code' => $code,
            'name' => $data['name'],
            'is_system' => false,
        ]);

        $this->audit->write(
            action: 'platform.role.created',
            entityType: 'role',
            entityId: $role->id,
            tenantId: null,
            newValues: ['code' => $role->code, 'name' => $role->name]
        );

        return $role;
    }
}
