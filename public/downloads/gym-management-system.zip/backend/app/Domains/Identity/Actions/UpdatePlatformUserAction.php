<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\Role;
use App\Domains\Identity\Models\User;
use Symfony\Component\HttpFoundation\Response;

final class UpdatePlatformUserAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users,
        private readonly RoleRepositoryInterface $roles,
        private readonly AuditWriter $audit
    ) {}

    /**
     * @param  array{name?: string, email?: string, phone?: string|null, is_active?: bool, password?: string}  $data
     */
    public function execute(mixed ...$args): User
    {
        /** @var int $userId */
        $userId = (int) $args[0];
        /** @var array{name?: string, email?: string, phone?: string|null, is_active?: bool, password?: string} $data */
        $data = $args[1];
        /** @var User|null $actor */
        $actor = $args[2] ?? null;

        $user = $this->users->findPlatformById($userId);

        if ($user === null) {
            throw new DomainException('Platform user not found.', 'platform_user_not_found', Response::HTTP_NOT_FOUND);
        }

        $payload = [];
        $old = [
            'name' => $user->name,
            'email' => $user->email,
            'phone' => $user->phone,
            'is_active' => $user->is_active,
        ];

        if (array_key_exists('name', $data)) {
            $payload['name'] = trim((string) $data['name']);
        }

        if (array_key_exists('phone', $data)) {
            $phone = $data['phone'];
            $payload['phone'] = is_string($phone) && trim($phone) !== '' ? trim($phone) : null;
        }

        if (array_key_exists('email', $data)) {
            $email = strtolower(trim((string) $data['email']));
            $existing = $this->users->findPlatformByEmail($email);

            if ($existing !== null && $existing->id !== $user->id) {
                throw new DomainException(
                    'A platform user with this email already exists.',
                    'platform_user_email_exists',
                    Response::HTTP_CONFLICT
                );
            }

            $payload['email'] = $email;
        }

        if (array_key_exists('password', $data) && is_string($data['password']) && $data['password'] !== '') {
            $payload['password'] = $data['password'];
        }

        if (array_key_exists('is_active', $data)) {
            $nextActive = (bool) $data['is_active'];

            if ($actor instanceof User && $actor->id === $user->id && ! $nextActive) {
                throw new DomainException(
                    'You cannot deactivate your own account.',
                    'cannot_deactivate_self',
                    Response::HTTP_FORBIDDEN
                );
            }

            if ($user->is_active && ! $nextActive) {
                $this->guardLastActiveSuperAdmin($user);
            }

            $payload['is_active'] = $nextActive;
        }

        if ($payload === []) {
            return $user->load('roles');
        }

        $updated = $this->users->updatePlatformUser($user, $payload)->load('roles');

        $this->audit->write(
            action: 'platform.user.updated',
            entityType: 'user',
            entityId: $updated->id,
            tenantId: null,
            oldValues: $old,
            newValues: [
                'name' => $updated->name,
                'email' => $updated->email,
                'phone' => $updated->phone,
                'is_active' => $updated->is_active,
                'password_changed' => array_key_exists('password', $payload),
            ]
        );

        return $updated;
    }

    private function guardLastActiveSuperAdmin(User $user): void
    {
        $superAdmin = $this->roles->findPlatformByCode(Role::CODE_SUPER_ADMIN);

        if ($superAdmin === null) {
            return;
        }

        $isSuperAdmin = $user->roles()->where('roles.id', $superAdmin->id)->exists();

        if (! $isSuperAdmin) {
            return;
        }

        $otherActive = $superAdmin->users()
            ->where('users.id', '!=', $user->id)
            ->whereNull('users.tenant_id')
            ->where('users.user_type', User::TYPE_PLATFORM)
            ->where('users.is_active', true)
            ->whereNull('users.deleted_at')
            ->count();

        if ($otherActive === 0) {
            throw new DomainException(
                'Cannot deactivate the last active Super Admin.',
                'last_super_admin_protected',
                Response::HTTP_FORBIDDEN
            );
        }
    }
}
