<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Context\TenantContext;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Models\Role;

final class SeedPlatformRolesAction extends Action
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles
    ) {}

    /**
     * @return list<Role>
     */
    public function execute(mixed ...$args): array
    {
        TenantContext::clear();

        $created = [];

        foreach (Role::platformCatalog() as $item) {
            $existing = $this->roles->findPlatformByCode($item['code']);

            if ($existing !== null) {
                $created[] = $existing;

                continue;
            }

            $created[] = $this->roles->createRole([
                'tenant_id' => null,
                'code' => $item['code'],
                'name' => $item['name'],
                'is_system' => true,
            ]);
        }

        return $created;
    }
}
