<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use Symfony\Component\HttpFoundation\Response;

final class DeletePlatformRoleAction extends Action
{
    public function __construct(
        private readonly RoleRepositoryInterface $roles,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var int $roleId */
        $roleId = (int) $args[0];

        $role = $this->roles->listPlatformRoles()->firstWhere('id', $roleId);

        if ($role === null) {
            throw new DomainException('Platform role not found.', 'role_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($role->is_system) {
            throw new DomainException(
                'System roles cannot be deleted.',
                'system_role_protected',
                Response::HTTP_FORBIDDEN
            );
        }

        if ($role->users()->exists()) {
            throw new DomainException(
                'Role is assigned to one or more users.',
                'role_in_use',
                Response::HTTP_CONFLICT
            );
        }

        $snapshot = ['code' => $role->code, 'name' => $role->name];
        $deleted = $this->roles->deleteRole($role);

        if ($deleted) {
            $this->audit->write(
                action: 'platform.role.deleted',
                entityType: 'role',
                entityId: $roleId,
                tenantId: null,
                oldValues: $snapshot
            );
        }

        return $deleted;
    }
}
