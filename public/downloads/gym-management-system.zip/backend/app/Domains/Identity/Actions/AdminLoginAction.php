<?php

declare(strict_types=1);

namespace App\Domains\Identity\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpFoundation\Response;

final class AdminLoginAction extends Action
{
    public function __construct(
        private readonly UserRepositoryInterface $users
    ) {}

    /**
     * @return array{user: User, token: string, tenant: Tenant}
     */
    public function execute(mixed ...$args): array
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var string $email */
        $email = $args[1];
        /** @var string $password */
        $password = $args[2];
        /** @var string $deviceName */
        $deviceName = $args[3] ?? 'admin-portal';

        return $this->transaction(function () use ($tenant, $email, $password, $deviceName): array {
            $user = $this->users->findStaffByTenantAndEmail($tenant->id, $email);

            if ($user === null || ! Hash::check($password, $user->password)) {
                throw new DomainException(
                    'Invalid email or password.',
                    'invalid_credentials',
                    Response::HTTP_UNAUTHORIZED
                );
            }

            if (! $user->canAccessAdminPortal()) {
                throw new DomainException(
                    'Staff account is inactive.',
                    'account_inactive',
                    Response::HTTP_FORBIDDEN
                );
            }

            if (! $tenant->isOperable()) {
                throw new DomainException(
                    'Tenant is not available for login.',
                    'tenant_inactive',
                    Response::HTTP_FORBIDDEN
                );
            }

            $user->forceFill(['last_login_at' => now()])->save();

            $token = $user->createToken($deviceName, ['admin'])->plainTextToken;

            return [
                'user' => $user->fresh()->load('roles.permissions'),
                'token' => $token,
                'tenant' => $tenant,
            ];
        });
    }
}
