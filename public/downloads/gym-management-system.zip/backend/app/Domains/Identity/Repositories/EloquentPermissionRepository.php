<?php

declare(strict_types=1);

namespace App\Domains\Identity\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Identity\Contracts\PermissionRepositoryInterface;
use App\Domains\Identity\Models\Permission;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;

/**
 * @extends BaseRepository<Permission>
 */
class EloquentPermissionRepository extends BaseRepository implements PermissionRepositoryInterface
{
    public function __construct(Permission $model)
    {
        parent::__construct($model);
    }

    public function listAll(): Collection
    {
        return $this->query()->orderBy('module')->orderBy('code')->get();
    }

    public function findById(int $id): ?Permission
    {
        return $this->query()->where('id', $id)->first();
    }

    public function findByCode(string $code): ?Permission
    {
        return $this->query()->where('code', $code)->first();
    }

    public function createPermission(array $attributes): Permission
    {
        /** @var Permission $permission */
        $permission = $this->query()->create($attributes);

        return $permission;
    }

    public function syncRolePermissions(int $roleId, array $permissionIds): void
    {
        DB::table('role_permissions')->where('role_id', $roleId)->delete();

        $rows = [];
        foreach (array_unique($permissionIds) as $permissionId) {
            $rows[] = [
                'role_id' => $roleId,
                'permission_id' => $permissionId,
            ];
        }

        if ($rows !== []) {
            DB::table('role_permissions')->insert($rows);
        }
    }

    public function permissionIdsForRole(int $roleId): array
    {
        return DB::table('role_permissions')
            ->where('role_id', $roleId)
            ->pluck('permission_id')
            ->map(fn ($id): int => (int) $id)
            ->all();
    }
}
