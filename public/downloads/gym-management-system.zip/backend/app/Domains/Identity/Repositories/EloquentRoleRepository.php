<?php

declare(strict_types=1);

namespace App\Domains\Identity\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Identity\Contracts\RoleRepositoryInterface;
use App\Domains\Identity\Models\Role;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;

/**
 * @extends BaseRepository<Role>
 */
class EloquentRoleRepository extends BaseRepository implements RoleRepositoryInterface
{
    public function __construct(Role $model)
    {
        parent::__construct($model);
    }

    public function listForTenant(int $tenantId): Collection
    {
        return $this->query()
            ->where('tenant_id', $tenantId)
            ->orderBy('name')
            ->get();
    }

    public function findForTenant(int $tenantId, int $roleId): ?Role
    {
        return $this->query()
            ->where('tenant_id', $tenantId)
            ->where('id', $roleId)
            ->first();
    }

    public function findByCode(int $tenantId, string $code): ?Role
    {
        return $this->query()
            ->where('tenant_id', $tenantId)
            ->where('code', $code)
            ->first();
    }

    public function findPlatformByCode(string $code): ?Role
    {
        return $this->query()
            ->withoutGlobalScope('tenant')
            ->whereNull('tenant_id')
            ->where('code', $code)
            ->first();
    }

    public function listPlatformRoles(): Collection
    {
        return $this->query()
            ->withoutGlobalScope('tenant')
            ->whereNull('tenant_id')
            ->orderBy('name')
            ->get();
    }

    public function createRole(array $attributes): Role
    {
        /** @var Role $role */
        $role = $this->query()->withoutGlobalScope('tenant')->create($attributes);

        return $role;
    }

    public function updateRole(Role $role, array $attributes): Role
    {
        $role->update($attributes);

        return $role->refresh();
    }

    public function deleteRole(Role $role): bool
    {
        return (bool) $role->delete();
    }

    public function syncUserRoles(int $userId, array $roleIds): void
    {
        DB::table('user_roles')->where('user_id', $userId)->delete();

        $rows = [];
        foreach (array_unique($roleIds) as $roleId) {
            $rows[] = [
                'user_id' => $userId,
                'role_id' => $roleId,
            ];
        }

        if ($rows !== []) {
            DB::table('user_roles')->insert($rows);
        }
    }
}
