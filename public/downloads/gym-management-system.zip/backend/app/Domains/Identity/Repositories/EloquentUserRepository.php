<?php

declare(strict_types=1);

namespace App\Domains\Identity\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\User;
use Illuminate\Support\Collection;

/**
 * @extends BaseRepository<User>
 */
class EloquentUserRepository extends BaseRepository implements UserRepositoryInterface
{
    public function __construct(User $model)
    {
        parent::__construct($model);
    }

    public function findStaffByTenantAndEmail(int $tenantId, string $email): ?User
    {
        return $this->query()
            ->where('tenant_id', $tenantId)
            ->where('user_type', User::TYPE_STAFF)
            ->where('email', $email)
            ->first();
    }

    public function findStaffByIdForTenant(int $tenantId, int $userId): ?User
    {
        return $this->query()
            ->where('tenant_id', $tenantId)
            ->where('user_type', User::TYPE_STAFF)
            ->where('id', $userId)
            ->first();
    }

    public function paginateStaffForTenant(int $tenantId, array $filters = []): \Illuminate\Contracts\Pagination\LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->with(['roles', 'branches'])
            ->where('tenant_id', $tenantId)
            ->where('user_type', User::TYPE_STAFF)
            ->orderBy('name');

        if (array_key_exists('is_active', $filters) && $filters['is_active'] !== null && $filters['is_active'] !== '') {
            $query->where('is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN));
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);
            $query->where(function ($q) use ($search): void {
                $q->where('name', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%")
                    ->orWhere('phone', 'like', "%{$search}%");
            });
        }

        if (! empty($filters['role_id'])) {
            $roleId = (int) $filters['role_id'];
            $query->whereHas('roles', fn ($q) => $q->where('roles.id', $roleId));
        }

        return $query->paginate($perPage);
    }

    public function createStaff(array $attributes): User
    {
        $attributes['user_type'] = User::TYPE_STAFF;

        /** @var User $user */
        $user = $this->query()->create($attributes);

        return $user;
    }

    public function updateStaff(User $user, array $attributes): User
    {
        $user->update($attributes);

        return $user->refresh();
    }

    public function findStaffAccountsByEmail(string $email): Collection
    {
        return $this->query()
            ->with('tenant')
            ->where('user_type', User::TYPE_STAFF)
            ->where('email', $email)
            ->whereNotNull('tenant_id')
            ->get();
    }

    public function findPlatformByEmail(string $email): ?User
    {
        return $this->query()
            ->whereNull('tenant_id')
            ->where('user_type', User::TYPE_PLATFORM)
            ->where('email', $email)
            ->first();
    }

    public function findPlatformById(int $userId): ?User
    {
        return $this->query()
            ->whereNull('tenant_id')
            ->where('user_type', User::TYPE_PLATFORM)
            ->where('id', $userId)
            ->first();
    }

    public function listPlatformUsers(): \Illuminate\Database\Eloquent\Collection
    {
        return $this->query()
            ->with('roles')
            ->whereNull('tenant_id')
            ->where('user_type', User::TYPE_PLATFORM)
            ->orderBy('name')
            ->get();
    }

    public function createPlatformUser(array $attributes): User
    {
        $attributes['tenant_id'] = null;
        $attributes['user_type'] = User::TYPE_PLATFORM;

        /** @var User $user */
        $user = $this->query()->create($attributes);

        return $user;
    }

    public function updatePlatformUser(User $user, array $attributes): User
    {
        $user->update($attributes);

        return $user->refresh();
    }

    public function findMemberByTenantAndEmail(int $tenantId, string $email): ?User
    {
        return $this->query()
            ->where('tenant_id', $tenantId)
            ->where('user_type', User::TYPE_MEMBER)
            ->where('email', $email)
            ->first();
    }

    public function findMemberByIdForTenant(int $tenantId, int $userId): ?User
    {
        return $this->query()
            ->where('tenant_id', $tenantId)
            ->where('user_type', User::TYPE_MEMBER)
            ->where('id', $userId)
            ->first();
    }

    public function findByTenantAndEmail(int $tenantId, string $email): ?User
    {
        return $this->query()
            ->where('tenant_id', $tenantId)
            ->where('email', $email)
            ->first();
    }

    public function createMember(array $attributes): User
    {
        $attributes['user_type'] = User::TYPE_MEMBER;

        /** @var User $user */
        $user = $this->query()->create($attributes);

        return $user;
    }
}
