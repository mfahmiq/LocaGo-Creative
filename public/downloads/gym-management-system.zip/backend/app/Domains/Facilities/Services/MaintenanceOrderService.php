<?php

declare(strict_types=1);

namespace App\Domains\Facilities\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Facilities\Actions\AssignMaintenanceOrderAction;
use App\Domains\Facilities\Actions\CancelMaintenanceOrderAction;
use App\Domains\Facilities\Actions\CompleteMaintenanceOrderAction;
use App\Domains\Facilities\Actions\CreateMaintenanceOrderAction;
use App\Domains\Facilities\Actions\DeleteMaintenanceOrderAction;
use App\Domains\Facilities\Actions\StartMaintenanceOrderAction;
use App\Domains\Facilities\Actions\UpdateMaintenanceOrderAction;
use App\Domains\Facilities\Actions\UpdateOwnMaintenanceOrderAction;
use App\Domains\Facilities\Contracts\MaintenanceOrderRepositoryInterface;
use App\Domains\Facilities\Models\MaintenanceOrder;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class MaintenanceOrderService extends BaseService
{
    public function __construct(
        private readonly MaintenanceOrderRepositoryInterface $orders,
        private readonly CreateMaintenanceOrderAction $createMaintenanceOrderAction,
        private readonly UpdateMaintenanceOrderAction $updateMaintenanceOrderAction,
        private readonly DeleteMaintenanceOrderAction $deleteMaintenanceOrderAction,
        private readonly AssignMaintenanceOrderAction $assignMaintenanceOrderAction,
        private readonly StartMaintenanceOrderAction $startMaintenanceOrderAction,
        private readonly CompleteMaintenanceOrderAction $completeMaintenanceOrderAction,
        private readonly CancelMaintenanceOrderAction $cancelMaintenanceOrderAction,
        private readonly UpdateOwnMaintenanceOrderAction $updateOwnMaintenanceOrderAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->orders->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $orderId): MaintenanceOrder
    {
        $order = $this->orders->findForTenant($tenant->id, $orderId);

        if ($order === null) {
            throw new DomainException(
                'Maintenance order not found.',
                'maintenance_order_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        return $order;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): MaintenanceOrder
    {
        return $this->createMaintenanceOrderAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $orderId, array $data): MaintenanceOrder
    {
        return $this->updateMaintenanceOrderAction->execute($tenant, $orderId, $data);
    }

    public function delete(Tenant $tenant, int $orderId): bool
    {
        return $this->deleteMaintenanceOrderAction->execute($tenant, $orderId);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function assign(Tenant $tenant, int $orderId, array $data): MaintenanceOrder
    {
        return $this->assignMaintenanceOrderAction->execute($tenant, $orderId, $data);
    }

    public function start(Tenant $tenant, int $orderId): MaintenanceOrder
    {
        return $this->startMaintenanceOrderAction->execute($tenant, $orderId);
    }

    public function complete(Tenant $tenant, int $orderId): MaintenanceOrder
    {
        return $this->completeMaintenanceOrderAction->execute($tenant, $orderId);
    }

    public function cancel(Tenant $tenant, int $orderId): MaintenanceOrder
    {
        return $this->cancelMaintenanceOrderAction->execute($tenant, $orderId);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function updateOwn(Tenant $tenant, int $orderId, User $user, array $data): MaintenanceOrder
    {
        return $this->updateOwnMaintenanceOrderAction->execute($tenant, $orderId, $user, $data);
    }
}
