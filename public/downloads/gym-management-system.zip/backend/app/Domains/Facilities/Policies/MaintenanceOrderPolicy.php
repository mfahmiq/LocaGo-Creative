<?php

declare(strict_types=1);

namespace App\Domains\Facilities\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Facilities\Models\MaintenanceOrder;
use App\Domains\Identity\Models\User;

final class MaintenanceOrderPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'facilities.tasks.view');
    }

    public function view(User $user, MaintenanceOrder $order): bool
    {
        return $this->hasPermission($user, 'facilities.tasks.view')
            && $this->sameTenant($user, $order)
            && $this->branchAllowed($user, (int) $order->branch_id);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'facilities.tasks.manage');
    }

    public function update(User $user, MaintenanceOrder $order): bool
    {
        return $this->hasPermission($user, 'facilities.tasks.manage')
            && $this->sameTenant($user, $order)
            && $this->branchAllowed($user, (int) $order->branch_id);
    }

    public function delete(User $user, MaintenanceOrder $order): bool
    {
        return $this->update($user, $order);
    }

    public function assign(User $user, MaintenanceOrder $order): bool
    {
        return $this->update($user, $order);
    }

    public function start(User $user, MaintenanceOrder $order): bool
    {
        return $this->update($user, $order);
    }

    public function complete(User $user, MaintenanceOrder $order): bool
    {
        return $this->update($user, $order);
    }

    public function cancel(User $user, MaintenanceOrder $order): bool
    {
        return $this->update($user, $order);
    }

    public function updateOwn(User $user, MaintenanceOrder $order): bool
    {
        return $this->hasPermission($user, 'facilities.tasks.update_own')
            && $this->sameTenant($user, $order)
            && $this->branchAllowed($user, (int) $order->branch_id)
            && (int) $order->assigned_user_id === (int) $user->id;
    }
}
