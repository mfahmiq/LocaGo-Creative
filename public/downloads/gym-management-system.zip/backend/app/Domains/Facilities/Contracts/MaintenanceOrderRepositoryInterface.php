<?php

declare(strict_types=1);

namespace App\Domains\Facilities\Contracts;

use App\Domains\Facilities\Models\MaintenanceOrder;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface MaintenanceOrderRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $orderId): ?MaintenanceOrder;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createOrder(array $attributes): MaintenanceOrder;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateOrder(MaintenanceOrder $order, array $attributes): MaintenanceOrder;

    public function deleteOrder(MaintenanceOrder $order): bool;
}
