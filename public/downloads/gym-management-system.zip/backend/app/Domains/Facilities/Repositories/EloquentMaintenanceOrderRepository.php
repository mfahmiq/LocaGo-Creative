<?php

declare(strict_types=1);

namespace App\Domains\Facilities\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Facilities\Contracts\MaintenanceOrderRepositoryInterface;
use App\Domains\Facilities\Models\MaintenanceOrder;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<MaintenanceOrder>
 */
class EloquentMaintenanceOrderRepository extends BaseRepository implements MaintenanceOrderRepositoryInterface
{
    public function __construct(MaintenanceOrder $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['branch', 'assignedUser'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('due_date')
            ->orderByDesc('id');

        if (! empty($filters['status'])) {
            $query->where('status', (string) $filters['status']);
        }

        if (! empty($filters['priority'])) {
            $query->where('priority', (string) $filters['priority']);
        }

        if (! empty($filters['branch_id'])) {
            $query->where('branch_id', (int) $filters['branch_id']);
        }

        if (! empty($filters['assigned_user_id'])) {
            $query->where('assigned_user_id', (int) $filters['assigned_user_id']);
        }

        if (! empty($filters['equipment_asset_id'])) {
            $query->where('equipment_asset_id', (int) $filters['equipment_asset_id']);
        }

        if (! empty($filters['from'])) {
            $query->whereDate('due_date', '>=', (string) $filters['from']);
        }

        if (! empty($filters['to'])) {
            $query->whereDate('due_date', '<=', (string) $filters['to']);
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);
            $query->where(function ($q) use ($search): void {
                $q->where('title', 'like', "%{$search}%")
                    ->orWhere('notes', 'like', "%{$search}%");
            });
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $orderId): ?MaintenanceOrder
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['branch', 'assignedUser'])
            ->where('tenant_id', $tenantId)
            ->where('id', $orderId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function createOrder(array $attributes): MaintenanceOrder
    {
        /** @var MaintenanceOrder $order */
        $order = $this->query()->withoutGlobalScopes()->create($attributes);

        return $order->load(['branch', 'assignedUser']);
    }

    public function updateOrder(MaintenanceOrder $order, array $attributes): MaintenanceOrder
    {
        $order->update($attributes);

        return $order->fresh(['branch', 'assignedUser']);
    }

    public function deleteOrder(MaintenanceOrder $order): bool
    {
        return (bool) $order->delete();
    }
}
