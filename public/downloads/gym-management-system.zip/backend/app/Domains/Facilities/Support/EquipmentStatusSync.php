<?php

declare(strict_types=1);

namespace App\Domains\Facilities\Support;

use App\Domains\Facilities\Models\MaintenanceOrder;
use App\Domains\Tenancy\Models\Tenant;

final class EquipmentStatusSync
{
    /**
     * When a maintenance order is completed, optionally restore linked equipment to in_service.
     */
    public static function syncOnComplete(Tenant $tenant, MaintenanceOrder $order): void
    {
        if ($order->equipment_asset_id === null) {
            return;
        }

        $equipmentClass = 'App\\Domains\\Equipment\\Models\\EquipmentAsset';

        // TODO: EquipmentAsset domain may be added by a sibling agent.
        if (! class_exists($equipmentClass)) {
            return;
        }

        $equipment = $equipmentClass::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenant->id)
            ->where('id', $order->equipment_asset_id)
            ->whereNull('deleted_at')
            ->first();

        if ($equipment !== null) {
            $equipment->update(['status' => 'in_service']);
        }
    }
}
