# Facilities Domain

The **Facilities** module maps to `maintenance_orders` in the database. There is no separate `facility_tasks` table — maintenance work orders are the facility task records exposed by this API.

## Admin Portal — Maintenance orders (complete)

Requires `auth:sanctum` + staff + `X-Tenant-Slug` + permissions (`facilities.tasks.view` / `facilities.tasks.manage` / `facilities.tasks.update_own`).

### Maintenance orders

| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/facilities/maintenance-orders` | view / manage |
| GET/PUT/DELETE | `/api/v1/admin/facilities/maintenance-orders/{id}` | view / manage |
| PUT | `/api/v1/admin/facilities/maintenance-orders/{id}/own` | update_own (assignee only) |
| POST | `/api/v1/admin/facilities/maintenance-orders/{id}/assign` | manage |
| POST | `/api/v1/admin/facilities/maintenance-orders/{id}/start` | manage |
| POST | `/api/v1/admin/facilities/maintenance-orders/{id}/complete` | manage |
| POST | `/api/v1/admin/facilities/maintenance-orders/{id}/cancel` | manage |

Statuses: `open` | `in_progress` | `done` | `cancelled`

Priorities: `low` | `medium` | `high` | `urgent`

### Rules

- `branch_id` is required on create and validated against active tenant branches
- `assigned_user_id` must reference an active staff user in the tenant
- Managers can CRUD and transition orders (`start` → `in_progress`, `complete` → `done` + `completed_at`, `cancel` → `cancelled`)
- Assignees with `facilities.tasks.update_own` may update their assigned orders only: notes and status transitions `open` → `in_progress` → `done`
- Terminal orders (`done`, `cancelled`) cannot be edited or reassigned
- On complete, if `equipment_asset_id` is set and `App\Domains\Equipment\Models\EquipmentAsset` exists, linked equipment status is set to `in_service`
- Optional `equipment_asset_id` is validated when the Equipment domain model is available

List filters: `status`, `priority`, `branch_id`, `assigned_user_id`, `equipment_asset_id`, `from`, `to`, `search`, `per_page`

Audited: `maintenance_order.*`

## Related modules

- **Equipment** (`equipment_assets`) — optional link from maintenance orders
- **Expenses** — may reference `maintenance_order_id` for maintenance-related costs
