<?php

declare(strict_types=1);

namespace App\Domains\Facilities\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Facilities\Contracts\MaintenanceOrderRepositoryInterface;
use App\Domains\Facilities\Models\MaintenanceOrder;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CancelMaintenanceOrderAction extends Action
{
    public function __construct(
        private readonly MaintenanceOrderRepositoryInterface $orders,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): MaintenanceOrder
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $orderId */
        $orderId = (int) $args[1];

        $order = $this->orders->findForTenant($tenant->id, $orderId);

        if ($order === null) {
            throw new DomainException('Maintenance order not found.', 'maintenance_order_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($order->isTerminal()) {
            throw new DomainException(
                'Completed or cancelled maintenance orders cannot be cancelled again.',
                'invalid_maintenance_order_status',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $updated = $this->orders->updateOrder($order, [
            'status' => MaintenanceOrder::STATUS_CANCELLED,
        ]);

        $this->audit->write(
            action: 'maintenance_order.cancelled',
            entityType: 'maintenance_order',
            entityId: $updated->id,
            tenantId: $tenant->id,
            oldValues: ['status' => $order->status],
            newValues: ['status' => MaintenanceOrder::STATUS_CANCELLED]
        );

        return $updated;
    }
}
