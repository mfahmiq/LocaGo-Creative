<?php

declare(strict_types=1);

namespace App\Domains\Facilities\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Facilities\Contracts\MaintenanceOrderRepositoryInterface;
use App\Domains\Facilities\Models\MaintenanceOrder;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class AssignMaintenanceOrderAction extends Action
{
    public function __construct(
        private readonly MaintenanceOrderRepositoryInterface $orders,
        private readonly UserRepositoryInterface $users,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): MaintenanceOrder
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $orderId */
        $orderId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        $order = $this->orders->findForTenant($tenant->id, $orderId);

        if ($order === null) {
            throw new DomainException('Maintenance order not found.', 'maintenance_order_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($order->isTerminal()) {
            throw new DomainException(
                'Completed or cancelled orders cannot be reassigned.',
                'maintenance_order_not_assignable',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $assignedUserId = isset($data['assigned_user_id']) ? (int) $data['assigned_user_id'] : null;

        if ($assignedUserId !== null) {
            $staff = $this->users->findStaffByIdForTenant($tenant->id, $assignedUserId);

            if ($staff === null || ! $staff->is_active) {
                throw new DomainException(
                    'Assigned user must be an active staff member in this tenant.',
                    'invalid_assignee',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }
        }

        $updated = $this->orders->updateOrder($order, [
            'assigned_user_id' => $assignedUserId,
        ]);

        $this->audit->write(
            action: 'maintenance_order.assigned',
            entityType: 'maintenance_order',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: ['assigned_user_id' => $assignedUserId]
        );

        return $updated;
    }
}
