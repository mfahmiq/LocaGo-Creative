<?php

declare(strict_types=1);

namespace App\Domains\Facilities\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Facilities\Contracts\MaintenanceOrderRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeleteMaintenanceOrderAction extends Action
{
    public function __construct(
        private readonly MaintenanceOrderRepositoryInterface $orders,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $orderId */
        $orderId = (int) $args[1];

        $order = $this->orders->findForTenant($tenant->id, $orderId);

        if ($order === null) {
            throw new DomainException('Maintenance order not found.', 'maintenance_order_not_found', Response::HTTP_NOT_FOUND);
        }

        $deleted = $this->orders->deleteOrder($order);

        $this->audit->write(
            action: 'maintenance_order.deleted',
            entityType: 'maintenance_order',
            entityId: $orderId,
            tenantId: $tenant->id,
            oldValues: ['title' => $order->title, 'status' => $order->status]
        );

        return $deleted;
    }
}
