<?php

declare(strict_types=1);

namespace App\Domains\Facilities\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Facilities\Contracts\MaintenanceOrderRepositoryInterface;
use App\Domains\Facilities\Models\MaintenanceOrder;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CreateMaintenanceOrderAction extends Action
{
    public function __construct(
        private readonly MaintenanceOrderRepositoryInterface $orders,
        private readonly BranchRepositoryInterface $branches,
        private readonly UserRepositoryInterface $users,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): MaintenanceOrder
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        $branchId = (int) $data['branch_id'];
        if ($this->branches->findActiveForTenant($tenant->id, $branchId) === null) {
            throw new DomainException('Branch is invalid or inactive.', 'invalid_branch', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        $this->validateEquipmentAsset($tenant, $data['equipment_asset_id'] ?? null);

        $assignedUserId = isset($data['assigned_user_id']) ? (int) $data['assigned_user_id'] : null;
        $this->validateAssignee($tenant, $assignedUserId);

        $order = $this->orders->createOrder([
            'tenant_id' => $tenant->id,
            'branch_id' => $branchId,
            'equipment_asset_id' => isset($data['equipment_asset_id']) ? (int) $data['equipment_asset_id'] : null,
            'title' => (string) $data['title'],
            'priority' => (string) ($data['priority'] ?? MaintenanceOrder::PRIORITY_MEDIUM),
            'status' => MaintenanceOrder::STATUS_OPEN,
            'assigned_user_id' => $assignedUserId,
            'due_date' => $data['due_date'] ?? null,
            'cost_amount' => isset($data['cost_amount'])
                ? number_format((float) $data['cost_amount'], 2, '.', '')
                : null,
            'currency_code' => isset($data['currency_code'])
                ? strtoupper((string) $data['currency_code'])
                : ($tenant->base_currency ?: 'INR'),
            'notes' => $data['notes'] ?? null,
        ]);

        $this->audit->write(
            action: 'maintenance_order.created',
            entityType: 'maintenance_order',
            entityId: $order->id,
            tenantId: $tenant->id,
            newValues: [
                'title' => $order->title,
                'status' => $order->status,
                'priority' => $order->priority,
            ]
        );

        return $order;
    }

    private function validateAssignee(Tenant $tenant, ?int $assignedUserId): void
    {
        if ($assignedUserId === null) {
            return;
        }

        $staff = $this->users->findStaffByIdForTenant($tenant->id, $assignedUserId);

        if ($staff === null || ! $staff->is_active) {
            throw new DomainException(
                'Assigned user must be an active staff member in this tenant.',
                'invalid_assignee',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }

    /**
     * @param  int|string|null  $equipmentAssetId
     */
    private function validateEquipmentAsset(Tenant $tenant, mixed $equipmentAssetId): void
    {
        if ($equipmentAssetId === null || $equipmentAssetId === '') {
            return;
        }

        $equipmentClass = 'App\\Domains\\Equipment\\Models\\EquipmentAsset';

        if (! class_exists($equipmentClass)) {
            return;
        }

        $exists = $equipmentClass::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenant->id)
            ->where('id', (int) $equipmentAssetId)
            ->whereNull('deleted_at')
            ->exists();

        if (! $exists) {
            throw new DomainException(
                'Equipment asset not found.',
                'equipment_asset_not_found',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }
}
