<?php

declare(strict_types=1);

namespace App\Domains\Facilities\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Facilities\Contracts\MaintenanceOrderRepositoryInterface;
use App\Domains\Facilities\Models\MaintenanceOrder;
use App\Domains\Facilities\Support\EquipmentStatusSync;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateOwnMaintenanceOrderAction extends Action
{
    public function __construct(
        private readonly MaintenanceOrderRepositoryInterface $orders,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): MaintenanceOrder
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $orderId */
        $orderId = (int) $args[1];
        /** @var User $user */
        $user = $args[2];
        /** @var array<string, mixed> $data */
        $data = $args[3];

        $order = $this->orders->findForTenant($tenant->id, $orderId);

        if ($order === null) {
            throw new DomainException('Maintenance order not found.', 'maintenance_order_not_found', Response::HTTP_NOT_FOUND);
        }

        if ((int) $order->assigned_user_id !== (int) $user->id) {
            throw new DomainException(
                'You can only update maintenance orders assigned to you.',
                'maintenance_order_not_assigned',
                Response::HTTP_FORBIDDEN
            );
        }

        if ($order->isTerminal()) {
            throw new DomainException(
                'Completed or cancelled orders cannot be updated.',
                'maintenance_order_not_editable',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $payload = [];

        if (array_key_exists('notes', $data)) {
            $payload['notes'] = $data['notes'];
        }

        if (array_key_exists('status', $data)) {
            $newStatus = (string) $data['status'];
            $this->assertOwnStatusTransition($order->status, $newStatus);
            $payload['status'] = $newStatus;

            if ($newStatus === MaintenanceOrder::STATUS_DONE) {
                $payload['completed_at'] = now();
            }
        }

        if ($payload === []) {
            return $order;
        }

        $updated = $this->orders->updateOrder($order, $payload);

        if (($payload['status'] ?? null) === MaintenanceOrder::STATUS_DONE) {
            EquipmentStatusSync::syncOnComplete($tenant, $updated);
        }

        $this->audit->write(
            action: 'maintenance_order.updated_own',
            entityType: 'maintenance_order',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: $payload
        );

        return $updated;
    }

    private function assertOwnStatusTransition(string $current, string $next): void
    {
        $allowed = [
            MaintenanceOrder::STATUS_OPEN => [MaintenanceOrder::STATUS_IN_PROGRESS],
            MaintenanceOrder::STATUS_IN_PROGRESS => [MaintenanceOrder::STATUS_DONE],
        ];

        if ($current === $next) {
            return;
        }

        if (! isset($allowed[$current]) || ! in_array($next, $allowed[$current], true)) {
            throw new DomainException(
                'Invalid maintenance order status transition.',
                'invalid_maintenance_order_status',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }
}
