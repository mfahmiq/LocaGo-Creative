<?php

declare(strict_types=1);

namespace App\Domains\Facilities\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Facilities\Contracts\MaintenanceOrderRepositoryInterface;
use App\Domains\Facilities\Models\MaintenanceOrder;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateMaintenanceOrderAction extends Action
{
    public function __construct(
        private readonly MaintenanceOrderRepositoryInterface $orders,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): MaintenanceOrder
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $orderId */
        $orderId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        $order = $this->orders->findForTenant($tenant->id, $orderId);

        if ($order === null) {
            throw new DomainException('Maintenance order not found.', 'maintenance_order_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($order->isTerminal()) {
            throw new DomainException(
                'Completed or cancelled orders cannot be updated.',
                'maintenance_order_not_editable',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $payload = [];

        if (array_key_exists('branch_id', $data)) {
            $branchId = (int) $data['branch_id'];
            if ($this->branches->findActiveForTenant($tenant->id, $branchId) === null) {
                throw new DomainException('Branch is invalid or inactive.', 'invalid_branch', Response::HTTP_UNPROCESSABLE_ENTITY);
            }
            $payload['branch_id'] = $branchId;
        }

        if (array_key_exists('equipment_asset_id', $data)) {
            $equipmentAssetId = $data['equipment_asset_id'] !== null ? (int) $data['equipment_asset_id'] : null;
            $this->validateEquipmentAsset($tenant, $equipmentAssetId);
            $payload['equipment_asset_id'] = $equipmentAssetId;
        }

        foreach (['title', 'notes'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = $data[$field];
            }
        }

        if (array_key_exists('priority', $data)) {
            $payload['priority'] = (string) $data['priority'];
        }

        if (array_key_exists('due_date', $data)) {
            $payload['due_date'] = $data['due_date'];
        }

        if (array_key_exists('cost_amount', $data)) {
            $payload['cost_amount'] = $data['cost_amount'] !== null
                ? number_format((float) $data['cost_amount'], 2, '.', '')
                : null;
        }

        if (array_key_exists('currency_code', $data)) {
            $payload['currency_code'] = $data['currency_code'] !== null
                ? strtoupper((string) $data['currency_code'])
                : null;
        }

        $updated = $this->orders->updateOrder($order, $payload);

        $this->audit->write(
            action: 'maintenance_order.updated',
            entityType: 'maintenance_order',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: $payload
        );

        return $updated;
    }

    private function validateEquipmentAsset(Tenant $tenant, ?int $equipmentAssetId): void
    {
        if ($equipmentAssetId === null) {
            return;
        }

        $equipmentClass = 'App\\Domains\\Equipment\\Models\\EquipmentAsset';

        if (! class_exists($equipmentClass)) {
            return;
        }

        $exists = $equipmentClass::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenant->id)
            ->where('id', $equipmentAssetId)
            ->whereNull('deleted_at')
            ->exists();

        if (! $exists) {
            throw new DomainException(
                'Equipment asset not found.',
                'equipment_asset_not_found',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }
}
