<?php

declare(strict_types=1);

namespace App\Domains\Facilities\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Facilities\Contracts\MaintenanceOrderRepositoryInterface;
use App\Domains\Facilities\Models\MaintenanceOrder;
use App\Domains\Facilities\Support\EquipmentStatusSync;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CompleteMaintenanceOrderAction extends Action
{
    public function __construct(
        private readonly MaintenanceOrderRepositoryInterface $orders,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): MaintenanceOrder
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $orderId */
        $orderId = (int) $args[1];

        $order = $this->orders->findForTenant($tenant->id, $orderId);

        if ($order === null) {
            throw new DomainException('Maintenance order not found.', 'maintenance_order_not_found', Response::HTTP_NOT_FOUND);
        }

        if (! $order->isInProgress()) {
            throw new DomainException(
                'Only in-progress maintenance orders can be completed.',
                'invalid_maintenance_order_status',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $updated = $this->orders->updateOrder($order, [
            'status' => MaintenanceOrder::STATUS_DONE,
            'completed_at' => now(),
        ]);

        EquipmentStatusSync::syncOnComplete($tenant, $updated);

        $this->audit->write(
            action: 'maintenance_order.completed',
            entityType: 'maintenance_order',
            entityId: $updated->id,
            tenantId: $tenant->id,
            oldValues: ['status' => MaintenanceOrder::STATUS_IN_PROGRESS],
            newValues: ['status' => MaintenanceOrder::STATUS_DONE]
        );

        return $updated;
    }
}
