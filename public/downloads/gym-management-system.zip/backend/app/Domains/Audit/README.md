﻿# Audit Domain

Immutable `audit_logs` writer + Admin Portal read API.

## Admin API
- `GET /api/v1/admin/audit-logs` — filters: `action`, `entity_type`, `actor_user_id`, `from`, `to`
- `GET /api/v1/admin/audit-logs/{id}`
- Permission: `audit.view`

## Instrumented actions (v1)
- `staff.roles_synced`
- `role.permissions_synced`
- `tenant.provisioned|activated|trial_extended|suspended|reactivated|trial_expired`

Use `AuditWriter::write(...)` from Actions/Services for additional critical mutations.
