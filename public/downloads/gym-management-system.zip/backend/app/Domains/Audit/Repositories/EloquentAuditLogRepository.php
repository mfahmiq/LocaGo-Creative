<?php

declare(strict_types=1);

namespace App\Domains\Audit\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Audit\Contracts\AuditLogRepositoryInterface;
use App\Domains\Audit\Models\AuditLog;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<AuditLog>
 */
class EloquentAuditLogRepository extends BaseRepository implements AuditLogRepositoryInterface
{
    public function __construct(AuditLog $model)
    {
        parent::__construct($model);
    }

    public function createLog(array $attributes): AuditLog
    {
        /** @var AuditLog $log */
        $log = $this->query()->create($attributes);

        return $log;
    }

    public function paginateForTenant(int $tenantId, array $filters = [], int $perPage = 25): LengthAwarePaginator
    {
        $query = $this->query()
            ->with(['actor:id,name,email'])
            ->where('tenant_id', $tenantId)
            ->orderByDesc('created_at')
            ->orderByDesc('id');

        if (! empty($filters['action'])) {
            $query->where('action', 'like', '%'.addcslashes(trim((string) $filters['action']), '%_\\').'%');
        }

        if (! empty($filters['entity_type'])) {
            $query->where('entity_type', $filters['entity_type']);
        }

        if (! empty($filters['actor_user_id'])) {
            $query->where('actor_user_id', (int) $filters['actor_user_id']);
        }

        if (! empty($filters['q'])) {
            $term = '%'.addcslashes(trim((string) $filters['q']), '%_\\').'%';
            $query->where(function ($inner) use ($term): void {
                $inner->where('action', 'like', $term)
                    ->orWhere('entity_type', 'like', $term)
                    ->orWhere('ip_address', 'like', $term)
                    ->orWhereRaw('CAST(entity_id AS CHAR) LIKE ?', [$term]);
            });
        }

        if (! empty($filters['from'])) {
            $query->where('created_at', '>=', $filters['from']);
        }

        if (! empty($filters['to'])) {
            $query->where('created_at', '<=', $filters['to']);
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $id): ?AuditLog
    {
        return $this->query()
            ->with(['actor:id,name,email'])
            ->where('tenant_id', $tenantId)
            ->where('id', $id)
            ->first();
    }

    public function tenantSummary(int $tenantId): array
    {
        $base = $this->query()->where('tenant_id', $tenantId);

        return [
            'total' => (clone $base)->count(),
            'last_24h' => (clone $base)->where('created_at', '>=', now()->subDay())->count(),
            'unique_actions' => (int) (clone $base)->distinct()->count('action'),
            'unique_actors' => (int) (clone $base)->whereNotNull('actor_user_id')->distinct()->count('actor_user_id'),
        ];
    }

    public function paginateForPlatform(array $filters = [], int $perPage = 25): LengthAwarePaginator
    {
        $query = $this->platformQuery()
            ->with(['actor:id,name,email', 'tenant:id,name,slug'])
            ->orderByDesc('created_at')
            ->orderByDesc('id');

        $this->applyAuditFilters($query, $filters);

        return $query->paginate($perPage);
    }

    public function findForPlatform(int $id): ?AuditLog
    {
        return $this->platformQuery()
            ->with(['actor:id,name,email', 'tenant:id,name,slug'])
            ->where('id', $id)
            ->first();
    }

    public function platformSummary(): array
    {
        $base = $this->platformQuery();

        return [
            'total' => (clone $base)->count(),
            'last_24h' => (clone $base)->where('created_at', '>=', now()->subDay())->count(),
            'unique_actions' => (int) (clone $base)->distinct()->count('action'),
            'unique_actors' => (int) (clone $base)->whereNotNull('actor_user_id')->distinct()->count('actor_user_id'),
        ];
    }

    /**
     * @return \Illuminate\Database\Eloquent\Builder<AuditLog>
     */
    private function platformQuery(): \Illuminate\Database\Eloquent\Builder
    {
        return $this->query()->where(function ($query): void {
            $query->whereNull('tenant_id')
                ->orWhere('action', 'like', 'platform.%')
                ->orWhere('action', 'like', 'tenant.%');
        });
    }

    /**
     * @param  \Illuminate\Database\Eloquent\Builder<AuditLog>  $query
     * @param  array<string, mixed>  $filters
     */
    private function applyAuditFilters($query, array $filters): void
    {
        if (! empty($filters['scope']) && $filters['scope'] === 'platform') {
            $query->where(function ($inner): void {
                $inner->whereNull('tenant_id')
                    ->orWhere('action', 'like', 'platform.%');
            });
        }

        if (! empty($filters['scope']) && $filters['scope'] === 'tenant') {
            $query->where('action', 'like', 'tenant.%');
        }

        if (! empty($filters['action'])) {
            $query->where('action', $filters['action']);
        }

        if (! empty($filters['entity_type'])) {
            $query->where('entity_type', $filters['entity_type']);
        }

        if (! empty($filters['actor_user_id'])) {
            $query->where('actor_user_id', (int) $filters['actor_user_id']);
        }

        if (! empty($filters['tenant_id'])) {
            $query->where('tenant_id', (int) $filters['tenant_id']);
        }

        if (! empty($filters['q'])) {
            $term = '%'.addcslashes(trim((string) $filters['q']), '%_\\').'%';
            $query->where(function ($inner) use ($term): void {
                $inner->where('action', 'like', $term)
                    ->orWhere('entity_type', 'like', $term)
                    ->orWhere('ip_address', 'like', $term)
                    ->orWhereRaw('CAST(entity_id AS CHAR) LIKE ?', [$term]);
            });
        }

        if (! empty($filters['from'])) {
            $query->where('created_at', '>=', $filters['from']);
        }

        if (! empty($filters['to'])) {
            $query->where('created_at', '<=', $filters['to']);
        }
    }
}
