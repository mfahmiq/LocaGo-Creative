<?php

declare(strict_types=1);

namespace App\Domains\Audit\Services;

use App\Core\Context\BranchContext;
use App\Core\Context\TenantContext;
use App\Core\Services\BaseService;
use App\Domains\Audit\Contracts\AuditLogRepositoryInterface;
use App\Domains\Audit\Models\AuditLog;
use App\Domains\Identity\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;

final class AuditWriter extends BaseService
{
    public function __construct(
        private readonly AuditLogRepositoryInterface $logs
    ) {}

    /**
     * @param  array<string, mixed>|null  $oldValues
     * @param  array<string, mixed>|null  $newValues
     */
    public function write(
        string $action,
        string $entityType,
        ?int $entityId = null,
        ?int $tenantId = null,
        ?array $oldValues = null,
        ?array $newValues = null,
        ?int $actorUserId = null,
        ?int $branchId = null
    ): AuditLog {
        $actor = $actorUserId;
        if ($actor === null) {
            $user = Auth::user();
            $actor = $user instanceof User ? $user->id : null;
        }

        return $this->logs->createLog([
            'tenant_id' => $tenantId ?? TenantContext::idOrNull(),
            'actor_user_id' => $actor,
            'branch_id' => $branchId ?? BranchContext::idOrNull(),
            'action' => $action,
            'entity_type' => $entityType,
            'entity_id' => $entityId,
            'old_values' => $oldValues,
            'new_values' => $newValues,
            'ip_address' => Request::ip(),
            'user_agent' => substr((string) Request::userAgent(), 0, 255) ?: null,
            'created_at' => now(),
        ]);
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    public function listForTenant(int $tenantId, array $filters = [], int $perPage = 25): LengthAwarePaginator
    {
        return $this->logs->paginateForTenant($tenantId, $filters, $perPage);
    }

    public function findForTenant(int $tenantId, int $id): ?AuditLog
    {
        return $this->logs->findForTenant($tenantId, $id);
    }

    /**
     * @return array{total: int, last_24h: int, unique_actions: int, unique_actors: int}
     */
    public function tenantSummary(int $tenantId): array
    {
        return $this->logs->tenantSummary($tenantId);
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    public function listForPlatform(array $filters = [], int $perPage = 25): LengthAwarePaginator
    {
        return $this->logs->paginateForPlatform($filters, $perPage);
    }

    public function findForPlatform(int $id): ?AuditLog
    {
        return $this->logs->findForPlatform($id);
    }

    /**
     * @return array{total: int, last_24h: int, unique_actions: int, unique_actors: int}
     */
    public function platformSummary(): array
    {
        return $this->logs->platformSummary();
    }
}
