<?php

declare(strict_types=1);

namespace App\Domains\Audit\Contracts;

use App\Domains\Audit\Models\AuditLog;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface AuditLogRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createLog(array $attributes): AuditLog;

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = [], int $perPage = 25): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $id): ?AuditLog;

    /**
     * @return array{total: int, last_24h: int, unique_actions: int, unique_actors: int}
     */
    public function tenantSummary(int $tenantId): array;

    /**
     * Platform console events: null-tenant rows plus platform.* / tenant.* actions.
     *
     * @param  array<string, mixed>  $filters
     */
    public function paginateForPlatform(array $filters = [], int $perPage = 25): LengthAwarePaginator;

    public function findForPlatform(int $id): ?AuditLog;

    /**
     * @return array{total: int, last_24h: int, unique_actions: int, unique_actors: int}
     */
    public function platformSummary(): array;
}
