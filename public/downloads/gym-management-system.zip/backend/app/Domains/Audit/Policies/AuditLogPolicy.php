<?php

declare(strict_types=1);

namespace App\Domains\Audit\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Audit\Models\AuditLog;
use App\Domains\Identity\Models\User;

final class AuditLogPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'audit.view');
    }

    public function view(User $user, AuditLog $log): bool
    {
        return $this->hasPermission($user, 'audit.view')
            && (int) $user->tenant_id === (int) $log->tenant_id;
    }
}
