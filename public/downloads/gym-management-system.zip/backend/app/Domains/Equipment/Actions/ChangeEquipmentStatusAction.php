<?php

declare(strict_types=1);

namespace App\Domains\Equipment\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Equipment\Contracts\EquipmentAssetRepositoryInterface;
use App\Domains\Equipment\Models\EquipmentAsset;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class ChangeEquipmentStatusAction extends Action
{
    private const STATUSES = [
        EquipmentAsset::STATUS_IN_SERVICE,
        EquipmentAsset::STATUS_UNDER_MAINTENANCE,
        EquipmentAsset::STATUS_RETIRED,
    ];

    public function __construct(
        private readonly EquipmentAssetRepositoryInterface $equipmentAssets,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): EquipmentAsset
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $equipmentAssetId */
        $equipmentAssetId = (int) $args[1];
        /** @var string $status */
        $status = (string) $args[2];

        if (! in_array($status, self::STATUSES, true)) {
            throw new DomainException(
                'Invalid equipment asset status.',
                'invalid_equipment_status',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $equipmentAsset = $this->equipmentAssets->findForTenant($tenant->id, $equipmentAssetId);

        if ($equipmentAsset === null) {
            throw new DomainException('Equipment asset not found.', 'equipment_asset_not_found', Response::HTTP_NOT_FOUND);
        }

        $oldStatus = $equipmentAsset->status;
        $updated = $this->equipmentAssets->updateEquipmentAsset($equipmentAsset, ['status' => $status]);

        $this->audit->write(
            action: 'equipment_asset.status_changed',
            entityType: 'equipment_asset',
            entityId: $updated->id,
            tenantId: $tenant->id,
            oldValues: ['status' => $oldStatus],
            newValues: ['status' => $status]
        );

        return $updated;
    }
}
