<?php

declare(strict_types=1);

namespace App\Domains\Equipment\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Equipment\Contracts\EquipmentAssetRepositoryInterface;
use App\Domains\Equipment\Models\EquipmentAsset;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Organization\Models\Room;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CreateEquipmentAssetAction extends Action
{
    public function __construct(
        private readonly EquipmentAssetRepositoryInterface $equipmentAssets,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): EquipmentAsset
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        $branchId = (int) $data['branch_id'];
        if ($this->branches->findActiveForTenant($tenant->id, $branchId) === null) {
            throw new DomainException('Branch is invalid or inactive.', 'invalid_branch', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        $roomId = isset($data['room_id']) ? (int) $data['room_id'] : null;
        if ($roomId !== null) {
            $this->assertRoom($tenant->id, $branchId, $roomId);
        }

        $assetTag = trim((string) $data['asset_tag']);
        if ($this->equipmentAssets->findByAssetTag($tenant->id, $assetTag) !== null) {
            throw new DomainException(
                'Equipment asset tag already exists.',
                'equipment_asset_tag_exists',
                Response::HTTP_CONFLICT
            );
        }

        $equipmentAsset = $this->equipmentAssets->createEquipmentAsset([
            'tenant_id' => $tenant->id,
            'branch_id' => $branchId,
            'room_id' => $roomId,
            'asset_tag' => $assetTag,
            'name' => trim((string) $data['name']),
            'category' => $data['category'] ?? null,
            'status' => EquipmentAsset::STATUS_IN_SERVICE,
            'purchase_date' => $data['purchase_date'] ?? null,
            'warranty_ends_on' => $data['warranty_ends_on'] ?? null,
            'vendor_name' => $data['vendor_name'] ?? null,
        ]);

        $this->audit->write(
            action: 'equipment_asset.created',
            entityType: 'equipment_asset',
            entityId: $equipmentAsset->id,
            tenantId: $tenant->id,
            newValues: [
                'asset_tag' => $equipmentAsset->asset_tag,
                'name' => $equipmentAsset->name,
                'status' => $equipmentAsset->status,
            ]
        );

        return $equipmentAsset;
    }

    private function assertRoom(int $tenantId, int $branchId, int $roomId): void
    {
        $exists = Room::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('branch_id', $branchId)
            ->where('id', $roomId)
            ->where('is_active', true)
            ->whereNull('deleted_at')
            ->exists();

        if (! $exists) {
            throw new DomainException(
                'Room is invalid or inactive for this branch.',
                'invalid_room',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }
}
