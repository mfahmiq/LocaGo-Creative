<?php

declare(strict_types=1);

namespace App\Domains\Equipment\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Equipment\Contracts\EquipmentAssetRepositoryInterface;
use App\Domains\Equipment\Models\EquipmentAsset;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Organization\Models\Room;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateEquipmentAssetAction extends Action
{
    public function __construct(
        private readonly EquipmentAssetRepositoryInterface $equipmentAssets,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): EquipmentAsset
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $equipmentAssetId */
        $equipmentAssetId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        $equipmentAsset = $this->equipmentAssets->findForTenant($tenant->id, $equipmentAssetId);

        if ($equipmentAsset === null) {
            throw new DomainException('Equipment asset not found.', 'equipment_asset_not_found', Response::HTTP_NOT_FOUND);
        }

        $payload = [];
        $branchId = $equipmentAsset->branch_id;

        if (array_key_exists('branch_id', $data)) {
            $branchId = (int) $data['branch_id'];
            if ($this->branches->findActiveForTenant($tenant->id, $branchId) === null) {
                throw new DomainException('Branch is invalid or inactive.', 'invalid_branch', Response::HTTP_UNPROCESSABLE_ENTITY);
            }
            $payload['branch_id'] = $branchId;
        }

        if (array_key_exists('room_id', $data)) {
            $roomId = $data['room_id'] !== null ? (int) $data['room_id'] : null;
            if ($roomId !== null) {
                $this->assertRoom($tenant->id, (int) $branchId, $roomId);
            }
            $payload['room_id'] = $roomId;
        } elseif (array_key_exists('branch_id', $data) && $equipmentAsset->room_id !== null) {
            $this->assertRoom($tenant->id, (int) $branchId, (int) $equipmentAsset->room_id);
        }

        if (array_key_exists('asset_tag', $data)) {
            $assetTag = trim((string) $data['asset_tag']);
            if ($this->equipmentAssets->findByAssetTag($tenant->id, $assetTag, $equipmentAsset->id) !== null) {
                throw new DomainException(
                    'Equipment asset tag already exists.',
                    'equipment_asset_tag_exists',
                    Response::HTTP_CONFLICT
                );
            }
            $payload['asset_tag'] = $assetTag;
        }

        foreach (['name', 'category', 'purchase_date', 'warranty_ends_on', 'vendor_name'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = $field === 'name' && $data[$field] !== null
                    ? trim((string) $data[$field])
                    : $data[$field];
            }
        }

        $updated = $this->equipmentAssets->updateEquipmentAsset($equipmentAsset, $payload);

        $this->audit->write(
            action: 'equipment_asset.updated',
            entityType: 'equipment_asset',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: $payload
        );

        return $updated;
    }

    private function assertRoom(int $tenantId, int $branchId, int $roomId): void
    {
        $exists = Room::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('branch_id', $branchId)
            ->where('id', $roomId)
            ->where('is_active', true)
            ->whereNull('deleted_at')
            ->exists();

        if (! $exists) {
            throw new DomainException(
                'Room is invalid or inactive for this branch.',
                'invalid_room',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }
}
