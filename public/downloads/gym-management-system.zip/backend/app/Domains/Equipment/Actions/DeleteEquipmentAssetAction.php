<?php

declare(strict_types=1);

namespace App\Domains\Equipment\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Equipment\Contracts\EquipmentAssetRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeleteEquipmentAssetAction extends Action
{
    public function __construct(
        private readonly EquipmentAssetRepositoryInterface $equipmentAssets,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $equipmentAssetId */
        $equipmentAssetId = (int) $args[1];

        $equipmentAsset = $this->equipmentAssets->findForTenant($tenant->id, $equipmentAssetId);

        if ($equipmentAsset === null) {
            throw new DomainException('Equipment asset not found.', 'equipment_asset_not_found', Response::HTTP_NOT_FOUND);
        }

        $deleted = $this->equipmentAssets->deleteEquipmentAsset($equipmentAsset);

        $this->audit->write(
            action: 'equipment_asset.deleted',
            entityType: 'equipment_asset',
            entityId: $equipmentAssetId,
            tenantId: $tenant->id,
            oldValues: [
                'asset_tag' => $equipmentAsset->asset_tag,
                'name' => $equipmentAsset->name,
            ]
        );

        return $deleted;
    }
}
