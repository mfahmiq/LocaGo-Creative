# Equipment Domain

## Admin Portal — Equipment (complete)

Requires `auth:sanctum` + staff + `X-Tenant-Slug` + permissions (`equipment.view` / `equipment.manage`).

### Equipment assets

| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/equipment` | view / manage |
| GET/PUT/DELETE | `/api/v1/admin/equipment/{id}` | view / manage |
| PATCH | `/api/v1/admin/equipment/{id}/status` | manage |

Statuses: `in_service` \| `under_maintenance` \| `retired`

`branch_id` is required on create and validated against active tenant branches. Optional `room_id` must belong to the same tenant and branch.

Duplicate `asset_tag` per tenant returns `409` with code `equipment_asset_tag_exists`.

List filters: `status`, `category`, `branch_id`, `room_id`, `search`, `per_page`

Audited: `equipment_asset.*`

## Next Admin modules
Optional: Facilities / Support / Leads.
