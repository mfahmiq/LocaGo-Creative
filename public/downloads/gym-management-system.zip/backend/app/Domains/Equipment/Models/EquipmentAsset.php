<?php

declare(strict_types=1);

namespace App\Domains\Equipment\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Organization\Models\Branch;
use App\Domains\Organization\Models\Room;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class EquipmentAsset extends BaseModel
{
    use BelongsToTenant;

    public const STATUS_IN_SERVICE = 'in_service';

    public const STATUS_UNDER_MAINTENANCE = 'under_maintenance';

    public const STATUS_RETIRED = 'retired';

    protected $table = 'equipment_assets';

    protected $fillable = [
        'tenant_id',
        'branch_id',
        'room_id',
        'asset_tag',
        'name',
        'category',
        'status',
        'purchase_date',
        'warranty_ends_on',
        'vendor_name',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'purchase_date' => 'date',
            'warranty_ends_on' => 'date',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function room(): BelongsTo
    {
        return $this->belongsTo(Room::class);
    }
}
