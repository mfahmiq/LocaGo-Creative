<?php

declare(strict_types=1);

namespace App\Domains\Equipment\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Equipment\Actions\ChangeEquipmentStatusAction;
use App\Domains\Equipment\Actions\CreateEquipmentAssetAction;
use App\Domains\Equipment\Actions\DeleteEquipmentAssetAction;
use App\Domains\Equipment\Actions\UpdateEquipmentAssetAction;
use App\Domains\Equipment\Contracts\EquipmentAssetRepositoryInterface;
use App\Domains\Equipment\Models\EquipmentAsset;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class EquipmentAssetService extends BaseService
{
    public function __construct(
        private readonly EquipmentAssetRepositoryInterface $equipmentAssets,
        private readonly CreateEquipmentAssetAction $createEquipmentAssetAction,
        private readonly UpdateEquipmentAssetAction $updateEquipmentAssetAction,
        private readonly DeleteEquipmentAssetAction $deleteEquipmentAssetAction,
        private readonly ChangeEquipmentStatusAction $changeEquipmentStatusAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->equipmentAssets->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $equipmentAssetId): EquipmentAsset
    {
        $equipmentAsset = $this->equipmentAssets->findForTenant($tenant->id, $equipmentAssetId);

        if ($equipmentAsset === null) {
            throw new DomainException(
                'Equipment asset not found.',
                'equipment_asset_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        return $equipmentAsset;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): EquipmentAsset
    {
        return $this->createEquipmentAssetAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $equipmentAssetId, array $data): EquipmentAsset
    {
        return $this->updateEquipmentAssetAction->execute($tenant, $equipmentAssetId, $data);
    }

    public function delete(Tenant $tenant, int $equipmentAssetId): bool
    {
        return $this->deleteEquipmentAssetAction->execute($tenant, $equipmentAssetId);
    }

    public function changeStatus(Tenant $tenant, int $equipmentAssetId, string $status): EquipmentAsset
    {
        return $this->changeEquipmentStatusAction->execute($tenant, $equipmentAssetId, $status);
    }
}
