<?php

declare(strict_types=1);

namespace App\Domains\Equipment\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Equipment\Contracts\EquipmentAssetRepositoryInterface;
use App\Domains\Equipment\Models\EquipmentAsset;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<EquipmentAsset>
 */
class EloquentEquipmentAssetRepository extends BaseRepository implements EquipmentAssetRepositoryInterface
{
    public function __construct(EquipmentAsset $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['branch', 'room'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('id');

        if (! empty($filters['status'])) {
            $query->where('status', (string) $filters['status']);
        }

        if (! empty($filters['category'])) {
            $query->where('category', (string) $filters['category']);
        }

        if (! empty($filters['branch_id'])) {
            $query->where('branch_id', (int) $filters['branch_id']);
        }

        if (! empty($filters['room_id'])) {
            $query->where('room_id', (int) $filters['room_id']);
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);
            $query->where(function ($q) use ($search): void {
                $q->where('asset_tag', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%")
                    ->orWhere('category', 'like', "%{$search}%")
                    ->orWhere('vendor_name', 'like', "%{$search}%");
            });
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $equipmentAssetId): ?EquipmentAsset
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['branch', 'room'])
            ->where('tenant_id', $tenantId)
            ->where('id', $equipmentAssetId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function findByAssetTag(int $tenantId, string $assetTag, ?int $excludeId = null): ?EquipmentAsset
    {
        $query = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('asset_tag', $assetTag)
            ->whereNull('deleted_at');

        if ($excludeId !== null) {
            $query->where('id', '!=', $excludeId);
        }

        return $query->first();
    }

    public function createEquipmentAsset(array $attributes): EquipmentAsset
    {
        /** @var EquipmentAsset $equipmentAsset */
        $equipmentAsset = $this->query()->withoutGlobalScopes()->create($attributes);

        return $equipmentAsset->load(['branch', 'room']);
    }

    public function updateEquipmentAsset(EquipmentAsset $equipmentAsset, array $attributes): EquipmentAsset
    {
        $equipmentAsset->update($attributes);

        return $equipmentAsset->fresh(['branch', 'room']);
    }

    public function deleteEquipmentAsset(EquipmentAsset $equipmentAsset): bool
    {
        return (bool) $equipmentAsset->delete();
    }
}
