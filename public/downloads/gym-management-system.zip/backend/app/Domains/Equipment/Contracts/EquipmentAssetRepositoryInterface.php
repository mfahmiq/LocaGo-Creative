<?php

declare(strict_types=1);

namespace App\Domains\Equipment\Contracts;

use App\Domains\Equipment\Models\EquipmentAsset;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface EquipmentAssetRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $equipmentAssetId): ?EquipmentAsset;

    public function findByAssetTag(int $tenantId, string $assetTag, ?int $excludeId = null): ?EquipmentAsset;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createEquipmentAsset(array $attributes): EquipmentAsset;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateEquipmentAsset(EquipmentAsset $equipmentAsset, array $attributes): EquipmentAsset;

    public function deleteEquipmentAsset(EquipmentAsset $equipmentAsset): bool;
}
