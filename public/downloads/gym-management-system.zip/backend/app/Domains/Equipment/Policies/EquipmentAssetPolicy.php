<?php

declare(strict_types=1);

namespace App\Domains\Equipment\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Equipment\Models\EquipmentAsset;
use App\Domains\Identity\Models\User;

final class EquipmentAssetPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'equipment.view');
    }

    public function view(User $user, EquipmentAsset $equipmentAsset): bool
    {
        return $this->hasPermission($user, 'equipment.view')
            && $this->sameTenant($user, $equipmentAsset)
            && $this->branchAllowed($user, (int) $equipmentAsset->branch_id);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'equipment.manage');
    }

    public function update(User $user, EquipmentAsset $equipmentAsset): bool
    {
        return $this->hasPermission($user, 'equipment.manage')
            && $this->sameTenant($user, $equipmentAsset)
            && $this->branchAllowed($user, (int) $equipmentAsset->branch_id);
    }

    public function delete(User $user, EquipmentAsset $equipmentAsset): bool
    {
        return $this->update($user, $equipmentAsset);
    }

    public function changeStatus(User $user, EquipmentAsset $equipmentAsset): bool
    {
        return $this->update($user, $equipmentAsset);
    }
}
