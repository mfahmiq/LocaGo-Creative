# Member Portal Domain

Thin orchestration layer for authenticated member self-service APIs. Resolves the logged-in member via `members.user_id` and delegates business rules to existing domain services/repositories.

## Components

| Class | Role |
| --- | --- |
| `CurrentMemberResolver` | `MemberRepositoryInterface::findByUserId($tenantId, $userId)` |
| `MemberPortalService` | Profile, memberships, attendance, invoices, notifications, classes, support, workout/nutrition |

Ownership checks throw `DomainException` with code `forbidden` (403) or `not_found` (404).

## HTTP layer

Controllers live under `app/Http/Controllers/Api/V1/Member/` (not Admin). Route definitions: `routes/api/v1/member-portal.php`.

Requires `auth:sanctum` + `EnsureMemberUser` + `X-Tenant-Slug` + `permission:member_portal.*`.

## Member Portal — Operational APIs

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/api/v1/member/profile` | `member_portal.profile.view` |
| PUT | `/api/v1/member/profile` | `member_portal.profile.update` |
| GET | `/api/v1/member/memberships` | `member_portal.membership.view` |
| GET | `/api/v1/member/memberships/{id}` | `member_portal.membership.view` |
| GET | `/api/v1/member/attendance` | `member_portal.attendance.view` |
| GET | `/api/v1/member/invoices` | `member_portal.invoices.view` |
| GET | `/api/v1/member/invoices/{id}` | `member_portal.invoices.view` |
| GET | `/api/v1/member/notifications` | `member_portal.notifications.view` |
| POST | `/api/v1/member/notifications/{id}/read` | `member_portal.notifications.view` |
| GET | `/api/v1/member/notifications/unread-count` | `member_portal.notifications.view` |
| GET | `/api/v1/member/class-schedules` | `member_portal.classes.book` |
| POST | `/api/v1/member/class-schedules/{id}/book` | `member_portal.classes.book` |
| GET | `/api/v1/member/bookings` | `member_portal.classes.book` or `member_portal.classes.cancel` |
| POST | `/api/v1/member/bookings/{id}/cancel` | `member_portal.classes.cancel` |
| GET | `/api/v1/member/support-tickets` | `member_portal.support.view` |
| POST | `/api/v1/member/support-tickets` | `member_portal.support.create` |
| GET | `/api/v1/member/support-tickets/{id}` | `member_portal.support.view` |
| POST | `/api/v1/member/support-tickets/{id}/reply` | `member_portal.support.view` |
| GET | `/api/v1/member/workout-plan` | `member_portal.workout.view` |
| GET | `/api/v1/member/nutrition-plan` | `member_portal.nutrition.view` |

### Profile update (allowed fields)

`phone`, `emergency_name`, `emergency_phone`, `gender`, `date_of_birth` — not email, home branch, status, or member code.

### Wiring (parent agent)

Inside `routes/api/v1/api.php`, after the member auth group:

```php
Route::prefix('member')->name('member.')->group(function (): void {
    // ... auth routes ...
    require base_path('routes/api/v1/member-portal.php');
});
```

Ensure the portal routes file is required **inside** the `member` prefix group (portal file adds its own `auth:sanctum` + `EnsureMemberUser` middleware).

## Auth (separate)

See `app/Domains/Members/README.md` — `/api/v1/member/auth/*`.
