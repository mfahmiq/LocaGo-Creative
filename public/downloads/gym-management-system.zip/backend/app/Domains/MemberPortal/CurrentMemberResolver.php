<?php

declare(strict_types=1);

namespace App\Domains\MemberPortal;

use App\Core\Exceptions\DomainException;
use App\Domains\Identity\Models\User;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Members\Models\Member;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CurrentMemberResolver
{
    public function __construct(
        private readonly MemberRepositoryInterface $members
    ) {}

    public function resolve(Tenant $tenant, User $user): Member
    {
        $member = $this->members->findByUserId($tenant->id, (int) $user->id);

        if ($member === null) {
            throw new DomainException(
                'Member profile not found.',
                'member_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        return $member;
    }
}
