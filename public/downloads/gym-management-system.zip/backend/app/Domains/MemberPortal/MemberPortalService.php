<?php

declare(strict_types=1);

namespace App\Domains\MemberPortal;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Attendance\Contracts\AttendanceRepositoryInterface;
use App\Domains\Billing\Contracts\InvoiceRepositoryInterface;
use App\Domains\Classes\Contracts\ClassBookingRepositoryInterface;
use App\Domains\Classes\Models\ClassBooking;
use App\Domains\Classes\Models\ClassSchedule;
use App\Domains\Classes\Services\ClassBookingService;
use App\Domains\Classes\Services\ClassScheduleService;
use App\Domains\Identity\Models\User;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Members\Models\Member;
use App\Domains\Memberships\Actions\MemberRenewMembershipAction;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Memberships\Services\MembershipService;
use App\Domains\Marketing\Services\LoyaltyService;
use App\Domains\Notifications\Models\InAppNotification;
use App\Domains\Nutrition\Models\MemberNutritionPlan;
use App\Domains\Support\Contracts\SupportTicketRepositoryInterface;
use App\Domains\Support\Models\SupportTicket;
use App\Domains\Tenancy\Models\Tenant;
use App\Domains\Training\Models\MemberWorkoutPlan;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class MemberPortalService extends BaseService
{
    public function __construct(
        private readonly CurrentMemberResolver $currentMember,
        private readonly MemberRepositoryInterface $members,
        private readonly MembershipService $memberships,
        private readonly AttendanceRepositoryInterface $attendances,
        private readonly InvoiceRepositoryInterface $invoices,
        private readonly ClassScheduleService $classSchedules,
        private readonly ClassBookingService $classBookings,
        private readonly ClassBookingRepositoryInterface $classBookingRepository,
        private readonly SupportTicketRepositoryInterface $supportTickets,
        private readonly MemberRenewMembershipAction $memberRenewMembershipAction,
        private readonly LoyaltyService $loyalty
    ) {}

    /**
     * @return array{member: Member, user: User}
     */
    public function profile(Tenant $tenant, User $user): array
    {
        $member = $this->currentMember->resolve($tenant, $user);

        return [
            'member' => $member,
            'user' => $user,
        ];
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function updateProfile(Tenant $tenant, User $user, array $data): Member
    {
        $member = $this->currentMember->resolve($tenant, $user);

        $payload = array_intersect_key($data, array_flip([
            'phone',
            'emergency_name',
            'emergency_phone',
            'gender',
            'date_of_birth',
        ]));

        return $this->members->updateMember($member, $payload);
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    public function listMemberships(Tenant $tenant, User $user, array $filters = []): LengthAwarePaginator
    {
        $member = $this->currentMember->resolve($tenant, $user);

        return $this->memberships->paginate($tenant, array_merge($filters, [
            'member_id' => $member->id,
        ]));
    }

    public function getMembership(Tenant $tenant, User $user, int $membershipId): Membership
    {
        $member = $this->currentMember->resolve($tenant, $user);
        $membership = $this->memberships->find($tenant, $membershipId);
        $this->assertOwnsMember($member, (int) $membership->member_id);

        return $membership;
    }

    /**
     * Memberships that still need renewal (expiring soon, grace, or expired).
     * Shown on the member dashboard until renewed.
     *
     * @return list<array<string, mixed>>
     */
    public function renewalAlerts(Tenant $tenant, User $user): array
    {
        $member = $this->currentMember->resolve($tenant, $user);
        $withinDays = (int) config('gms.memberships.expiring_soon_days', 30);

        $paginator = $this->memberships->paginate($tenant, [
            'member_id' => $member->id,
            'per_page' => 50,
        ]);

        $alerts = [];
        foreach ($paginator->items() as $membership) {
            /** @var Membership $membership */
            $isExpiring = $membership->isExpiringSoon($withinDays);
            $needsRenewal = $isExpiring
                || in_array($membership->status, [Membership::STATUS_GRACE, Membership::STATUS_EXPIRED], true);

            if (! $needsRenewal) {
                continue;
            }

            $alerts[] = [
                'membership_id' => $membership->id,
                'plan_name' => $membership->plan?->name,
                'status' => $membership->status,
                'display_status' => $membership->displayStatus($withinDays),
                'end_date' => $membership->end_date?->toDateString(),
                'days_until_end' => $membership->daysUntilEnd(),
                'is_expiring_soon' => $isExpiring,
                'message' => $isExpiring
                    ? sprintf(
                        'Your membership expires in %d day(s) on %s. Renew to stay active.',
                        max(0, (int) $membership->daysUntilEnd()),
                        $membership->end_date?->toDateString() ?? '—'
                    )
                    : sprintf(
                        'Your membership is %s. Renew to restore full access.',
                        $membership->status
                    ),
            ];
        }

        usort($alerts, static function (array $a, array $b): int {
            return ($a['days_until_end'] ?? 9999) <=> ($b['days_until_end'] ?? 9999);
        });

        return $alerts;
    }

    /**
     * @param  array<string, mixed>  $data
     * @return array{membership: Membership, invoice: \App\Domains\Billing\Models\Invoice|null}
     */
    public function renewMembership(Tenant $tenant, User $user, int $membershipId, array $data = []): array
    {
        $member = $this->currentMember->resolve($tenant, $user);

        return $this->memberRenewMembershipAction->execute($tenant, $membershipId, (int) $member->id, $data);
    }

    /**
     * @return array{account: \App\Domains\Marketing\Models\LoyaltyAccount, ledger: list<\App\Domains\Marketing\Models\LoyaltyLedgerEntry>, settings: \App\Domains\Marketing\Models\LoyaltySettings}
     */
    public function loyaltyOverview(Tenant $tenant, User $user): array
    {
        $member = $this->currentMember->resolve($tenant, $user);
        $account = $this->loyalty->getOrCreateAccount($tenant, (int) $member->id);
        $ledger = $this->loyalty->paginateLedger($tenant, (int) $member->id, ['per_page' => 10]);

        return [
            'account' => $account,
            'ledger' => $ledger->items(),
            'settings' => $this->loyalty->getOrCreateSettings($tenant),
        ];
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    public function listAttendance(Tenant $tenant, User $user, array $filters = []): LengthAwarePaginator
    {
        $member = $this->currentMember->resolve($tenant, $user);

        return $this->attendances->paginateForTenant($tenant->id, array_merge($filters, [
            'member_id' => $member->id,
        ]));
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    public function listInvoices(Tenant $tenant, User $user, array $filters = []): LengthAwarePaginator
    {
        $member = $this->currentMember->resolve($tenant, $user);

        return $this->invoices->paginateForTenant($tenant->id, array_merge($filters, [
            'member_id' => $member->id,
        ]));
    }

    public function getInvoice(Tenant $tenant, User $user, int $invoiceId): \App\Domains\Billing\Models\Invoice
    {
        $member = $this->currentMember->resolve($tenant, $user);
        $invoice = $this->invoices->findForTenant($tenant->id, $invoiceId);

        if ($invoice === null) {
            throw new DomainException('Invoice not found.', 'invoice_not_found', Response::HTTP_NOT_FOUND);
        }

        $this->assertOwnsMember($member, (int) $invoice->member_id);

        return $invoice;
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    public function listNotifications(Tenant $tenant, User $user, array $filters = []): LengthAwarePaginator
    {
        $this->currentMember->resolve($tenant, $user);

        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        return InAppNotification::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenant->id)
            ->where('user_id', $user->id)
            ->whereNull('deleted_at')
            ->orderByDesc('created_at')
            ->paginate($perPage);
    }

    public function markNotificationRead(Tenant $tenant, User $user, int $notificationId): InAppNotification
    {
        $this->currentMember->resolve($tenant, $user);

        $notification = InAppNotification::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenant->id)
            ->where('user_id', $user->id)
            ->where('id', $notificationId)
            ->whereNull('deleted_at')
            ->first();

        if ($notification === null) {
            throw new DomainException(
                'Notification not found.',
                'notification_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        if ($notification->read_at === null) {
            InAppNotification::query()
                ->withoutGlobalScopes()
                ->where('id', $notification->id)
                ->update(['read_at' => now()]);
        }

        $updated = InAppNotification::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenant->id)
            ->where('user_id', $user->id)
            ->where('id', $notificationId)
            ->whereNull('deleted_at')
            ->first();

        if ($updated === null) {
            throw new DomainException(
                'Notification not found.',
                'notification_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        return $updated;
    }

    public function unreadNotificationCount(Tenant $tenant, User $user): int
    {
        $this->currentMember->resolve($tenant, $user);

        return InAppNotification::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenant->id)
            ->where('user_id', $user->id)
            ->whereNull('read_at')
            ->whereNull('deleted_at')
            ->count();
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    public function listUpcomingClassSchedules(Tenant $tenant, User $user, array $filters = []): LengthAwarePaginator
    {
        $this->currentMember->resolve($tenant, $user);

        return $this->classSchedules->paginate($tenant, array_merge($filters, [
            'status' => ClassSchedule::STATUS_SCHEDULED,
            'from' => now()->toDateTimeString(),
        ]));
    }

    /**
     * @return array{type: string, booking?: ClassBooking, waitlist?: \App\Domains\Classes\Models\ClassWaitlistEntry}
     */
    public function bookClassSchedule(Tenant $tenant, User $user, int $scheduleId): array
    {
        $member = $this->currentMember->resolve($tenant, $user);

        return $this->classBookings->book($tenant, [
            'class_schedule_id' => $scheduleId,
            'member_id' => $member->id,
            'source' => ClassBooking::SOURCE_MEMBER,
        ]);
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    public function listBookings(Tenant $tenant, User $user, array $filters = []): LengthAwarePaginator
    {
        $member = $this->currentMember->resolve($tenant, $user);

        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = ClassBooking::query()
            ->withoutGlobalScopes()
            ->with(['schedule.classType', 'schedule.branch', 'schedule.instructor', 'schedule.room', 'membership'])
            ->where('tenant_id', $tenant->id)
            ->where('member_id', $member->id)
            ->whereNull('deleted_at')
            ->orderByDesc('booked_at');

        if (! empty($filters['status'])) {
            $query->where('status', (string) $filters['status']);
        }

        return $query->paginate($perPage);
    }

    public function cancelBooking(Tenant $tenant, User $user, int $bookingId, ?string $reason = null): ClassBooking
    {
        $member = $this->currentMember->resolve($tenant, $user);
        $booking = $this->classBookingRepository->findBookingForTenant($tenant->id, $bookingId);

        if ($booking === null) {
            throw new DomainException(
                'Booking not found.',
                'class_booking_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        $this->assertOwnsMember($member, (int) $booking->member_id);

        return $this->classBookings->cancelBooking($tenant, $bookingId, $reason);
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    public function listSupportTickets(Tenant $tenant, User $user, array $filters = []): LengthAwarePaginator
    {
        $member = $this->currentMember->resolve($tenant, $user);

        return $this->supportTickets->paginateForTenant($tenant->id, array_merge($filters, [
            'member_id' => $member->id,
        ]));
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function createSupportTicket(Tenant $tenant, User $user, array $data): SupportTicket
    {
        $member = $this->currentMember->resolve($tenant, $user);

        $priority = (string) ($data['priority'] ?? SupportTicket::PRIORITY_MEDIUM);
        if (! in_array($priority, [
            SupportTicket::PRIORITY_LOW,
            SupportTicket::PRIORITY_MEDIUM,
            SupportTicket::PRIORITY_HIGH,
            SupportTicket::PRIORITY_URGENT,
        ], true)) {
            throw new DomainException(
                'Invalid ticket priority.',
                'invalid_ticket_priority',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $ticket = $this->supportTickets->createTicket([
            'tenant_id' => $tenant->id,
            'member_id' => $member->id,
            'assigned_user_id' => null,
            'ticket_number' => $this->supportTickets->nextTicketNumber($tenant->id),
            'category' => (string) $data['category'],
            'subject' => (string) $data['subject'],
            'status' => SupportTicket::STATUS_OPEN,
            'priority' => $priority,
        ]);

        $this->supportTickets->createMessage([
            'tenant_id' => $tenant->id,
            'support_ticket_id' => $ticket->id,
            'sender_user_id' => null,
            'sender_member_id' => $member->id,
            'message' => (string) $data['message'],
            'attachment_path' => $data['attachment_path'] ?? null,
        ]);

        $loaded = $this->supportTickets->findForTenant($tenant->id, $ticket->id, true);

        if ($loaded === null) {
            throw new DomainException(
                'Support ticket not found.',
                'support_ticket_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        return $loaded;
    }

    public function getSupportTicket(Tenant $tenant, User $user, int $ticketId): SupportTicket
    {
        $member = $this->currentMember->resolve($tenant, $user);
        $ticket = $this->supportTickets->findForTenant($tenant->id, $ticketId, true);

        if ($ticket === null) {
            throw new DomainException(
                'Support ticket not found.',
                'support_ticket_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        $this->assertOwnsMember($member, (int) $ticket->member_id);

        return $ticket;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function replySupportTicket(Tenant $tenant, User $user, int $ticketId, array $data): SupportTicket
    {
        $member = $this->currentMember->resolve($tenant, $user);
        $ticket = $this->supportTickets->findForTenant($tenant->id, $ticketId);

        if ($ticket === null) {
            throw new DomainException(
                'Support ticket not found.',
                'support_ticket_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        $this->assertOwnsMember($member, (int) $ticket->member_id);

        if ($ticket->isClosed()) {
            throw new DomainException(
                'Cannot reply to a closed ticket.',
                'support_ticket_closed',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $this->supportTickets->createMessage([
            'tenant_id' => $tenant->id,
            'support_ticket_id' => $ticket->id,
            'sender_user_id' => null,
            'sender_member_id' => $member->id,
            'message' => (string) $data['message'],
            'attachment_path' => $data['attachment_path'] ?? null,
        ]);

        $updated = $this->supportTickets->findForTenant($tenant->id, $ticket->id, true);

        if ($updated === null) {
            throw new DomainException(
                'Support ticket not found.',
                'support_ticket_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        return $updated;
    }

    public function activeWorkoutPlan(Tenant $tenant, User $user): ?MemberWorkoutPlan
    {
        $member = $this->currentMember->resolve($tenant, $user);

        return MemberWorkoutPlan::query()
            ->withoutGlobalScopes()
            ->with(['workoutProgram.exercises', 'trainer.user'])
            ->where('tenant_id', $tenant->id)
            ->where('member_id', $member->id)
            ->where('is_published', true)
            ->where('status', MemberWorkoutPlan::STATUS_ACTIVE)
            ->whereNull('deleted_at')
            ->orderByDesc('id')
            ->first();
    }

    public function activeNutritionPlan(Tenant $tenant, User $user): ?MemberNutritionPlan
    {
        $member = $this->currentMember->resolve($tenant, $user);

        return MemberNutritionPlan::query()
            ->withoutGlobalScopes()
            ->with(['nutritionPlan', 'assignedByUser'])
            ->where('tenant_id', $tenant->id)
            ->where('member_id', $member->id)
            ->where('is_published', true)
            ->where('status', MemberNutritionPlan::STATUS_ACTIVE)
            ->whereNull('deleted_at')
            ->orderByDesc('id')
            ->first();
    }

    private function assertOwnsMember(Member $member, int $resourceMemberId): void
    {
        if ($resourceMemberId !== $member->id) {
            throw new DomainException(
                'You do not have access to this resource.',
                'forbidden',
                Response::HTTP_FORBIDDEN
            );
        }
    }
}
