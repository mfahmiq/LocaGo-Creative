<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Nutrition\Contracts\NutritionPlanRepositoryInterface;
use App\Domains\Nutrition\Models\MemberNutritionPlan;
use App\Domains\Nutrition\Models\NutritionPlan;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<NutritionPlan>
 */
class EloquentNutritionPlanRepository extends BaseRepository implements NutritionPlanRepositoryInterface
{
    public function __construct(NutritionPlan $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['createdByUser'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('id');

        if (array_key_exists('is_active', $filters) && $filters['is_active'] !== null && $filters['is_active'] !== '') {
            $query->where('is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN));
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);
            $query->where(function ($q) use ($search): void {
                $q->where('name', 'like', "%{$search}%")
                    ->orWhere('description', 'like', "%{$search}%");
            });
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $planId): ?NutritionPlan
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['createdByUser'])
            ->where('tenant_id', $tenantId)
            ->where('id', $planId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function findActiveForTenant(int $tenantId, int $planId): ?NutritionPlan
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['createdByUser'])
            ->where('tenant_id', $tenantId)
            ->where('id', $planId)
            ->where('is_active', true)
            ->whereNull('deleted_at')
            ->first();
    }

    public function createPlan(array $attributes): NutritionPlan
    {
        /** @var NutritionPlan $plan */
        $plan = $this->query()->withoutGlobalScopes()->create($attributes);

        return $plan->load(['createdByUser']);
    }

    public function updatePlan(NutritionPlan $plan, array $attributes): NutritionPlan
    {
        $plan->update($attributes);

        return $plan->fresh(['createdByUser']);
    }

    public function deletePlan(NutritionPlan $plan): bool
    {
        return (bool) $plan->delete();
    }

    public function hasActiveMemberAssignments(int $tenantId, int $planId): bool
    {
        return MemberNutritionPlan::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('nutrition_plan_id', $planId)
            ->where('status', MemberNutritionPlan::STATUS_ACTIVE)
            ->whereNull('deleted_at')
            ->exists();
    }
}
