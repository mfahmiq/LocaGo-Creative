<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Nutrition\Contracts\MemberNutritionPlanRepositoryInterface;
use App\Domains\Nutrition\Models\MemberNutritionPlan;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<MemberNutritionPlan>
 */
class EloquentMemberNutritionPlanRepository extends BaseRepository implements MemberNutritionPlanRepositoryInterface
{
    public function __construct(MemberNutritionPlan $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'nutritionPlan', 'assignedByUser'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('id');

        if (! empty($filters['member_id'])) {
            $query->where('member_id', (int) $filters['member_id']);
        }

        if (! empty($filters['nutrition_plan_id'])) {
            $query->where('nutrition_plan_id', (int) $filters['nutrition_plan_id']);
        }

        if (! empty($filters['status'])) {
            $query->where('status', (string) $filters['status']);
        }

        if (array_key_exists('is_published', $filters) && $filters['is_published'] !== null && $filters['is_published'] !== '') {
            $query->where('is_published', filter_var($filters['is_published'], FILTER_VALIDATE_BOOLEAN));
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $planId): ?MemberNutritionPlan
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'nutritionPlan', 'assignedByUser'])
            ->where('tenant_id', $tenantId)
            ->where('id', $planId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function createPlan(array $attributes): MemberNutritionPlan
    {
        /** @var MemberNutritionPlan $plan */
        $plan = $this->query()->withoutGlobalScopes()->create($attributes);

        return $plan->load(['member', 'nutritionPlan', 'assignedByUser']);
    }

    public function updatePlan(MemberNutritionPlan $plan, array $attributes): MemberNutritionPlan
    {
        $plan->update($attributes);

        return $plan->fresh(['member', 'nutritionPlan', 'assignedByUser']);
    }
}
