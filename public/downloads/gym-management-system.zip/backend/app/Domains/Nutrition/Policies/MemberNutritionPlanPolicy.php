<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Nutrition\Models\MemberNutritionPlan;

final class MemberNutritionPlanPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'nutrition.view');
    }

    public function view(User $user, MemberNutritionPlan $plan): bool
    {
        return $this->hasPermission($user, 'nutrition.view')
            && $this->sameTenant($user, $plan);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'nutrition.manage');
    }

    public function assign(User $user): bool
    {
        return $this->hasPermission($user, 'nutrition.manage');
    }

    public function publish(User $user, MemberNutritionPlan $plan): bool
    {
        return $this->hasPermission($user, 'nutrition.manage')
            && $this->sameTenant($user, $plan);
    }

    public function cancel(User $user, MemberNutritionPlan $plan): bool
    {
        return $this->publish($user, $plan);
    }
}
