<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Nutrition\Models\NutritionPlan;

final class NutritionPlanPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'nutrition.view');
    }

    public function view(User $user, NutritionPlan $plan): bool
    {
        return $this->hasPermission($user, 'nutrition.view')
            && $this->sameTenant($user, $plan);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'nutrition.manage');
    }

    public function update(User $user, NutritionPlan $plan): bool
    {
        return $this->hasPermission($user, 'nutrition.manage')
            && $this->sameTenant($user, $plan);
    }

    public function delete(User $user, NutritionPlan $plan): bool
    {
        return $this->update($user, $plan);
    }
}
