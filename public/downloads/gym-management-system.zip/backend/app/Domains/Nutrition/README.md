# Nutrition Domain

## Admin Portal — Nutrition plans & member assignments

Requires `auth:sanctum` + staff + `X-Tenant-Slug` + permissions (`nutrition.view` / `nutrition.manage`).

### Nutrition plans
| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/nutrition-plans` | view / manage |
| GET/PUT/DELETE | `/api/v1/admin/nutrition-plans/{id}` | view / manage |

Plan templates include name, description, macro targets (`calorie_target`, `protein_g`, `carbs_g`, `fat_g`), optional `file_path`, and `is_active`. On create, `created_by_user_id` is set from the authenticated staff user when available.

### Member nutrition plans
| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/member-nutrition-plans` | view / manage |
| GET | `/api/v1/admin/member-nutrition-plans/{id}` | view |
| POST | `/api/v1/admin/member-nutrition-plans/{id}/publish` | manage |
| POST | `/api/v1/admin/member-nutrition-plans/{id}/cancel` | manage |

Assignment statuses: `active` | `completed` | `cancelled`

List filters: `member_id`, `nutrition_plan_id`, `status`, `is_published`, `per_page`

### Rules
- Inactive nutrition plans cannot be assigned to members
- On assign, `assigned_by` is set from the authenticated staff user when available
- Delete plan blocked when active member assignments exist (`nutrition_plan_in_use`)
- Only `active` assignments can be published or cancelled
- Unpublished assignments are hidden from members

Audited: `nutrition_plan.*`, `member_nutrition_plan.*`
