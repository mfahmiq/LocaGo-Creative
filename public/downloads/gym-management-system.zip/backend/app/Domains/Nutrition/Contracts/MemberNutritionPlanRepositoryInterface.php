<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Contracts;

use App\Domains\Nutrition\Models\MemberNutritionPlan;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface MemberNutritionPlanRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $planId): ?MemberNutritionPlan;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createPlan(array $attributes): MemberNutritionPlan;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updatePlan(MemberNutritionPlan $plan, array $attributes): MemberNutritionPlan;
}
