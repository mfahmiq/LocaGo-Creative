<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Contracts;

use App\Domains\Nutrition\Models\NutritionPlan;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface NutritionPlanRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $planId): ?NutritionPlan;

    public function findActiveForTenant(int $tenantId, int $planId): ?NutritionPlan;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createPlan(array $attributes): NutritionPlan;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updatePlan(NutritionPlan $plan, array $attributes): NutritionPlan;

    public function deletePlan(NutritionPlan $plan): bool;

    public function hasActiveMemberAssignments(int $tenantId, int $planId): bool;
}
