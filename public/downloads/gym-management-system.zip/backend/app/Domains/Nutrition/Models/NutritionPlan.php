<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class NutritionPlan extends BaseModel
{
    use BelongsToTenant;

    protected $table = 'nutrition_plans';

    protected $fillable = [
        'tenant_id',
        'name',
        'description',
        'calorie_target',
        'protein_g',
        'carbs_g',
        'fat_g',
        'file_path',
        'created_by_user_id',
        'is_active',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'calorie_target' => 'integer',
            'protein_g' => 'integer',
            'carbs_g' => 'integer',
            'fat_g' => 'integer',
            'is_active' => 'boolean',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function createdByUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by_user_id');
    }

    public function memberPlans(): HasMany
    {
        return $this->hasMany(MemberNutritionPlan::class, 'nutrition_plan_id');
    }
}
