<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Nutrition\Contracts\NutritionPlanRepositoryInterface;
use App\Domains\Nutrition\Models\NutritionPlan;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateNutritionPlanAction extends Action
{
    public function __construct(
        private readonly NutritionPlanRepositoryInterface $plans,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): NutritionPlan
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $planId */
        $planId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        $plan = $this->plans->findForTenant($tenant->id, $planId);

        if ($plan === null) {
            throw new DomainException(
                'Nutrition plan not found.',
                'nutrition_plan_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        $payload = [];
        foreach (['name', 'description', 'calorie_target', 'protein_g', 'carbs_g', 'fat_g', 'file_path', 'is_active'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = $data[$field];
            }
        }

        $updated = $this->plans->updatePlan($plan, $payload);

        $this->audit->write(
            action: 'nutrition_plan.updated',
            entityType: 'nutrition_plan',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: $payload
        );

        return $updated;
    }
}
