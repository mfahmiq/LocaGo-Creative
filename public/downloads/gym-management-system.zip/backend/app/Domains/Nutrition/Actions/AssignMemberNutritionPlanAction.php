<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Nutrition\Contracts\MemberNutritionPlanRepositoryInterface;
use App\Domains\Nutrition\Contracts\NutritionPlanRepositoryInterface;
use App\Domains\Nutrition\Models\MemberNutritionPlan;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

final class AssignMemberNutritionPlanAction extends Action
{
    public function __construct(
        private readonly MemberNutritionPlanRepositoryInterface $plans,
        private readonly NutritionPlanRepositoryInterface $nutritionPlans,
        private readonly MemberRepositoryInterface $members,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): MemberNutritionPlan
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        $memberId = (int) $data['member_id'];
        $member = $this->members->findForTenant($tenant->id, $memberId);

        if ($member === null) {
            throw new DomainException('Member not found.', 'member_not_found', Response::HTTP_NOT_FOUND);
        }

        $nutritionPlanId = (int) $data['nutrition_plan_id'];
        $nutritionPlan = $this->nutritionPlans->findActiveForTenant($tenant->id, $nutritionPlanId);

        if ($nutritionPlan === null) {
            throw new DomainException(
                'Nutrition plan not found or inactive.',
                'nutrition_plan_not_found',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $assignedBy = Auth::id();

        $plan = $this->plans->createPlan([
            'tenant_id' => $tenant->id,
            'member_id' => $memberId,
            'nutrition_plan_id' => $nutritionPlanId,
            'assigned_by' => $assignedBy,
            'start_date' => (string) $data['start_date'],
            'end_date' => $data['end_date'] ?? null,
            'status' => MemberNutritionPlan::STATUS_ACTIVE,
            'is_published' => false,
            'notes' => $data['notes'] ?? null,
        ]);

        $this->audit->write(
            action: 'member_nutrition_plan.assigned',
            entityType: 'member_nutrition_plan',
            entityId: $plan->id,
            tenantId: $tenant->id,
            newValues: [
                'member_id' => $memberId,
                'nutrition_plan_id' => $nutritionPlanId,
                'assigned_by' => $assignedBy,
            ]
        );

        return $plan;
    }
}
