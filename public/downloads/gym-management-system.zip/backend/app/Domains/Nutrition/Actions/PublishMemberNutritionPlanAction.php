<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Nutrition\Contracts\MemberNutritionPlanRepositoryInterface;
use App\Domains\Nutrition\Models\MemberNutritionPlan;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class PublishMemberNutritionPlanAction extends Action
{
    public function __construct(
        private readonly MemberNutritionPlanRepositoryInterface $plans,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): MemberNutritionPlan
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $planId */
        $planId = (int) $args[1];

        $plan = $this->plans->findForTenant($tenant->id, $planId);

        if ($plan === null) {
            throw new DomainException(
                'Member nutrition plan not found.',
                'member_nutrition_plan_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        if ($plan->status !== MemberNutritionPlan::STATUS_ACTIVE) {
            throw new DomainException(
                'Only active nutrition plans can be published.',
                'invalid_nutrition_plan_status',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $updated = $this->plans->updatePlan($plan, ['is_published' => true]);

        $this->audit->write(
            action: 'member_nutrition_plan.published',
            entityType: 'member_nutrition_plan',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: ['is_published' => true]
        );

        return $updated;
    }
}
