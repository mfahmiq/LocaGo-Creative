<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Nutrition\Contracts\NutritionPlanRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeleteNutritionPlanAction extends Action
{
    public function __construct(
        private readonly NutritionPlanRepositoryInterface $plans,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $planId */
        $planId = (int) $args[1];

        $plan = $this->plans->findForTenant($tenant->id, $planId);

        if ($plan === null) {
            throw new DomainException(
                'Nutrition plan not found.',
                'nutrition_plan_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        if ($this->plans->hasActiveMemberAssignments($tenant->id, $planId)) {
            throw new DomainException(
                'Nutrition plan has active member assignments and cannot be deleted.',
                'nutrition_plan_in_use',
                Response::HTTP_CONFLICT
            );
        }

        $deleted = $this->plans->deletePlan($plan);

        $this->audit->write(
            action: 'nutrition_plan.deleted',
            entityType: 'nutrition_plan',
            entityId: $planId,
            tenantId: $tenant->id,
            oldValues: ['name' => $plan->name]
        );

        return $deleted;
    }
}
