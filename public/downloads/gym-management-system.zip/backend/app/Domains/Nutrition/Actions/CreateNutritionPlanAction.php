<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Actions;

use App\Core\Actions\Action;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Nutrition\Contracts\NutritionPlanRepositoryInterface;
use App\Domains\Nutrition\Models\NutritionPlan;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Auth;

final class CreateNutritionPlanAction extends Action
{
    public function __construct(
        private readonly NutritionPlanRepositoryInterface $plans,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): NutritionPlan
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        $createdByUserId = Auth::id();

        $plan = $this->plans->createPlan([
            'tenant_id' => $tenant->id,
            'name' => (string) $data['name'],
            'description' => $data['description'] ?? null,
            'calorie_target' => $data['calorie_target'] ?? null,
            'protein_g' => $data['protein_g'] ?? null,
            'carbs_g' => $data['carbs_g'] ?? null,
            'fat_g' => $data['fat_g'] ?? null,
            'file_path' => $data['file_path'] ?? null,
            'created_by_user_id' => $createdByUserId,
            'is_active' => (bool) ($data['is_active'] ?? true),
        ]);

        $this->audit->write(
            action: 'nutrition_plan.created',
            entityType: 'nutrition_plan',
            entityId: $plan->id,
            tenantId: $tenant->id,
            newValues: [
                'name' => $plan->name,
                'created_by_user_id' => $createdByUserId,
            ]
        );

        return $plan;
    }
}
