<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Nutrition\Actions\CreateNutritionPlanAction;
use App\Domains\Nutrition\Actions\DeleteNutritionPlanAction;
use App\Domains\Nutrition\Actions\UpdateNutritionPlanAction;
use App\Domains\Nutrition\Contracts\NutritionPlanRepositoryInterface;
use App\Domains\Nutrition\Models\NutritionPlan;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class NutritionPlanService extends BaseService
{
    public function __construct(
        private readonly NutritionPlanRepositoryInterface $plans,
        private readonly CreateNutritionPlanAction $createNutritionPlanAction,
        private readonly UpdateNutritionPlanAction $updateNutritionPlanAction,
        private readonly DeleteNutritionPlanAction $deleteNutritionPlanAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->plans->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $planId): NutritionPlan
    {
        $plan = $this->plans->findForTenant($tenant->id, $planId);

        if ($plan === null) {
            throw new DomainException(
                'Nutrition plan not found.',
                'nutrition_plan_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        return $plan;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): NutritionPlan
    {
        return $this->createNutritionPlanAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $planId, array $data): NutritionPlan
    {
        return $this->updateNutritionPlanAction->execute($tenant, $planId, $data);
    }

    public function delete(Tenant $tenant, int $planId): bool
    {
        return $this->deleteNutritionPlanAction->execute($tenant, $planId);
    }
}
