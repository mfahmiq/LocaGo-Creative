<?php

declare(strict_types=1);

namespace App\Domains\Nutrition\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Nutrition\Actions\AssignMemberNutritionPlanAction;
use App\Domains\Nutrition\Actions\CancelMemberNutritionPlanAction;
use App\Domains\Nutrition\Actions\PublishMemberNutritionPlanAction;
use App\Domains\Nutrition\Contracts\MemberNutritionPlanRepositoryInterface;
use App\Domains\Nutrition\Models\MemberNutritionPlan;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class MemberNutritionPlanService extends BaseService
{
    public function __construct(
        private readonly MemberNutritionPlanRepositoryInterface $plans,
        private readonly AssignMemberNutritionPlanAction $assignMemberNutritionPlanAction,
        private readonly PublishMemberNutritionPlanAction $publishMemberNutritionPlanAction,
        private readonly CancelMemberNutritionPlanAction $cancelMemberNutritionPlanAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->plans->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $planId): MemberNutritionPlan
    {
        $plan = $this->plans->findForTenant($tenant->id, $planId);

        if ($plan === null) {
            throw new DomainException(
                'Member nutrition plan not found.',
                'member_nutrition_plan_not_found',
                Response::HTTP_NOT_FOUND
            );
        }

        return $plan;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function assign(Tenant $tenant, array $data): MemberNutritionPlan
    {
        return $this->assignMemberNutritionPlanAction->execute($tenant, $data);
    }

    public function publish(Tenant $tenant, int $planId): MemberNutritionPlan
    {
        return $this->publishMemberNutritionPlanAction->execute($tenant, $planId);
    }

    public function cancel(Tenant $tenant, int $planId): MemberNutritionPlan
    {
        return $this->cancelMemberNutritionPlanAction->execute($tenant, $planId);
    }
}
