<?php

declare(strict_types=1);

namespace App\Domains\Attendance\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Attendance\Contracts\AttendanceRepositoryInterface;
use App\Domains\Attendance\Models\Attendance;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class VoidAttendanceAction extends Action
{
    public function __construct(
        private readonly AttendanceRepositoryInterface $attendances,
        private readonly MembershipRepositoryInterface $memberships,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Attendance
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $attendanceId */
        $attendanceId = (int) $args[1];
        /** @var string|null $reason */
        $reason = $args[2] ?? null;

        return $this->transaction(function () use ($tenant, $attendanceId, $reason): Attendance {
            $attendance = $this->attendances->findForTenant($tenant->id, $attendanceId);

            if ($attendance === null) {
                throw new DomainException('Attendance not found.', 'attendance_not_found', Response::HTTP_NOT_FOUND);
            }

            if ($attendance->status === Attendance::STATUS_VOIDED) {
                throw new DomainException(
                    'Attendance is already voided.',
                    'attendance_already_voided',
                    Response::HTTP_CONFLICT
                );
            }

            if ($attendance->membership_id !== null) {
                $membership = $this->memberships->findForTenant($tenant->id, (int) $attendance->membership_id);
                if ($membership !== null && $membership->visits_remaining !== null) {
                    $this->memberships->updateMembership($membership, [
                        'visits_remaining' => (int) $membership->visits_remaining + 1,
                    ]);
                }
            }

            $updated = $this->attendances->updateAttendance($attendance, [
                'status' => Attendance::STATUS_VOIDED,
                'void_reason' => $reason,
            ]);

            $this->audit->write(
                action: 'attendance.voided',
                entityType: 'attendance',
                entityId: $updated->id,
                tenantId: $tenant->id,
                oldValues: ['status' => Attendance::STATUS_VALID],
                newValues: ['status' => Attendance::STATUS_VOIDED, 'void_reason' => $reason]
            );

            return $updated;
        });
    }
}
