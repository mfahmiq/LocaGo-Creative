<?php

declare(strict_types=1);

namespace App\Domains\Attendance\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Attendance\Contracts\AttendanceRepositoryInterface;
use App\Domains\Attendance\Models\Attendance;
use App\Domains\Attendance\Services\CheckInEligibilityService;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Models\User;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

final class CheckInMemberAction extends Action
{
    public function __construct(
        private readonly CheckInEligibilityService $eligibility,
        private readonly AttendanceRepositoryInterface $attendances,
        private readonly MembershipRepositoryInterface $memberships,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Attendance
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        return $this->transaction(function () use ($tenant, $data): Attendance {
            $memberId = (int) $data['member_id'];
            $branchId = (int) $data['branch_id'];

            $result = $this->eligibility->evaluate($tenant, $memberId, $branchId);

            if (! $result['allowed'] || $result['membership'] === null) {
                throw new DomainException(
                    $result['message'],
                    $result['code'] ?? 'check_in_denied',
                    $this->statusForCode($result['code'] ?? null)
                );
            }

            $membership = $result['membership'];
            $method = (string) ($data['method'] ?? Attendance::METHOD_STAFF);

            if (! in_array($method, [Attendance::METHOD_STAFF, Attendance::METHOD_QR, Attendance::METHOD_CODE], true)) {
                $method = Attendance::METHOD_STAFF;
            }

            $staffId = Auth::id();
            $user = Auth::user();
            if ($user instanceof User && $staffId !== null && ! $user->canAccessBranch($branchId)) {
                throw new DomainException(
                    'You are not assigned to this branch.',
                    'branch_forbidden',
                    Response::HTTP_FORBIDDEN
                );
            }

            if ($membership->visits_remaining !== null) {
                $this->memberships->updateMembership($membership, [
                    'visits_remaining' => max(0, (int) $membership->visits_remaining - 1),
                ]);
            }

            $attendance = $this->attendances->createAttendance([
                'tenant_id' => $tenant->id,
                'branch_id' => $branchId,
                'member_id' => $memberId,
                'membership_id' => $membership->id,
                'checked_in_at' => now(),
                'method' => $method,
                'staff_user_id' => $staffId,
                'status' => Attendance::STATUS_VALID,
                'notes' => $data['notes'] ?? null,
            ]);

            $this->audit->write(
                action: 'attendance.checked_in',
                entityType: 'attendance',
                entityId: $attendance->id,
                tenantId: $tenant->id,
                newValues: [
                    'member_id' => $memberId,
                    'branch_id' => $branchId,
                    'membership_id' => $membership->id,
                    'method' => $method,
                ]
            );

            try {
                app(\App\Domains\Marketing\Services\LoyaltyService::class)
                    ->awardCheckIn($tenant, $memberId, (int) $attendance->id);
            } catch (\Throwable) {
                // Loyalty must never block check-in.
            }

            return $attendance;
        });
    }

    private function statusForCode(?string $code): int
    {
        return match ($code) {
            'member_not_found' => Response::HTTP_NOT_FOUND,
            'member_blacklisted', 'branch_forbidden' => Response::HTTP_FORBIDDEN,
            'duplicate_check_in' => Response::HTTP_CONFLICT,
            default => Response::HTTP_UNPROCESSABLE_ENTITY,
        };
    }
}
