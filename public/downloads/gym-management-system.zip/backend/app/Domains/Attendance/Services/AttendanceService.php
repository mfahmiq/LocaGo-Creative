<?php

declare(strict_types=1);

namespace App\Domains\Attendance\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Attendance\Actions\CheckInMemberAction;
use App\Domains\Attendance\Actions\VoidAttendanceAction;
use App\Domains\Attendance\Contracts\AttendanceRepositoryInterface;
use App\Domains\Attendance\Models\Attendance;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class AttendanceService extends BaseService
{
    public function __construct(
        private readonly AttendanceRepositoryInterface $attendances,
        private readonly CheckInEligibilityService $eligibilityService,
        private readonly CheckInMemberAction $checkInMemberAction,
        private readonly VoidAttendanceAction $voidAttendanceAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->attendances->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $attendanceId): Attendance
    {
        $attendance = $this->attendances->findForTenant($tenant->id, $attendanceId);

        if ($attendance === null) {
            throw new DomainException('Attendance not found.', 'attendance_not_found', Response::HTTP_NOT_FOUND);
        }

        return $attendance;
    }

    /**
     * @return array<string, mixed>
     */
    public function eligibility(Tenant $tenant, int $memberId, int $branchId): array
    {
        return $this->eligibilityService->evaluate($tenant, $memberId, $branchId);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function checkIn(Tenant $tenant, array $data): Attendance
    {
        return $this->checkInMemberAction->execute($tenant, $data);
    }

    public function void(Tenant $tenant, int $attendanceId, ?string $reason = null): Attendance
    {
        return $this->voidAttendanceAction->execute($tenant, $attendanceId, $reason);
    }
}
