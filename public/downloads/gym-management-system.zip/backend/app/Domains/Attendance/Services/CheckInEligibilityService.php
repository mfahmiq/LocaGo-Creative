<?php

declare(strict_types=1);

namespace App\Domains\Attendance\Services;

use App\Domains\Attendance\Contracts\AttendanceRepositoryInterface;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Carbon\Carbon;

/**
 * Walk-in check-in eligibility engine (staff-assisted V1).
 */
final class CheckInEligibilityService
{
    public function __construct(
        private readonly MemberRepositoryInterface $members,
        private readonly BranchRepositoryInterface $branches,
        private readonly AttendanceRepositoryInterface $attendances
    ) {}

    /**
     * @return array{
     *     allowed: bool,
     *     code: ?string,
     *     message: string,
     *     member: ?\App\Domains\Members\Models\Member,
     *     membership: ?Membership,
     *     recent_attendance_id: ?int,
     *     visits_remaining: ?int
     * }
     */
    public function evaluate(Tenant $tenant, int $memberId, int $branchId): array
    {
        $member = $this->members->findForTenant($tenant->id, $memberId);

        if ($member === null) {
            return $this->deny('member_not_found', 'Member not found.');
        }

        if ($member->status === 'blacklisted') {
            return $this->deny('member_blacklisted', 'Member is blacklisted and cannot check in.', $member);
        }

        if ($member->status !== 'active') {
            return $this->deny(
                'member_inactive',
                'Only active members can check in.',
                $member
            );
        }

        $branch = $this->branches->findActiveForTenant($tenant->id, $branchId);

        if ($branch === null) {
            return $this->deny('invalid_branch', 'Branch is invalid or inactive.', $member);
        }

        $window = (int) config('gms.attendance.duplicate_window_minutes', 30);
        $recent = $this->attendances->findRecentValidForMember($tenant->id, $memberId, $branchId, $window);

        if ($recent !== null) {
            return $this->deny(
                'duplicate_check_in',
                "Member already checked in within the last {$window} minutes.",
                $member,
                null,
                $recent->id
            );
        }

        $allowGrace = (bool) config('gms.attendance.allow_grace_status', true);
        $statuses = [Membership::STATUS_ACTIVE];
        if ($allowGrace) {
            $statuses[] = Membership::STATUS_GRACE;
        }

        $candidates = Membership::query()
            ->withoutGlobalScopes()
            ->with(['plan.branches'])
            ->where('tenant_id', $tenant->id)
            ->where('member_id', $memberId)
            ->whereNull('deleted_at')
            ->whereIn('status', array_merge($statuses, [
                Membership::STATUS_FROZEN,
                Membership::STATUS_EXPIRED,
                Membership::STATUS_PENDING,
                Membership::STATUS_CANCELLED,
            ]))
            ->orderByDesc('id')
            ->get();

        if ($candidates->isEmpty()) {
            return $this->deny('no_membership', 'Member has no membership.', $member);
        }

        $today = Carbon::today();
        $blocking = null;

        foreach ($candidates as $membership) {
            if ($membership->status === Membership::STATUS_FROZEN) {
                $blocking ??= $this->deny('membership_frozen', 'Membership is frozen.', $member, $membership);
                continue;
            }

            if ($membership->status === Membership::STATUS_EXPIRED) {
                $blocking ??= $this->deny('membership_expired', 'Membership is expired.', $member, $membership);
                continue;
            }

            if ($membership->status === Membership::STATUS_CANCELLED) {
                $blocking ??= $this->deny('membership_cancelled', 'Membership is cancelled.', $member, $membership);
                continue;
            }

            if ($membership->status === Membership::STATUS_PENDING) {
                $blocking ??= $this->deny('membership_pending', 'Membership is not activated yet.', $member, $membership);
                continue;
            }

            if (! in_array($membership->status, $statuses, true)) {
                continue;
            }

            if ($membership->start_date !== null && $membership->start_date->gt($today)) {
                $blocking ??= $this->deny('membership_not_started', 'Membership has not started yet.', $member, $membership);
                continue;
            }

            if ($membership->end_date !== null && $membership->end_date->lt($today)) {
                $blocking ??= $this->deny('membership_expired', 'Membership end date has passed.', $member, $membership);
                continue;
            }

            $plan = $membership->plan;

            if ($plan === null) {
                $blocking ??= $this->deny('plan_missing', 'Membership plan is missing.', $member, $membership);
                continue;
            }

            if (! $plan->allows_walkin) {
                $blocking ??= $this->deny('walkin_not_allowed', 'This plan does not allow walk-in access.', $member, $membership);
                continue;
            }

            if (! $plan->allows_all_branches) {
                $allowedIds = $plan->branches->pluck('id')->map(fn ($id) => (int) $id)->all();
                if ($allowedIds === [] || ! in_array($branchId, $allowedIds, true)) {
                    $blocking ??= $this->deny(
                        'branch_not_allowed',
                        'Membership plan does not allow this branch.',
                        $member,
                        $membership
                    );
                    continue;
                }
            }

            if ($membership->visits_remaining !== null && $membership->visits_remaining < 1) {
                $blocking ??= $this->deny('no_visits_remaining', 'No visits remaining on this membership.', $member, $membership);
                continue;
            }

            return [
                'allowed' => true,
                'code' => null,
                'message' => 'Eligible for check-in.',
                'member' => $member,
                'membership' => $membership,
                'recent_attendance_id' => null,
                'visits_remaining' => $membership->visits_remaining,
            ];
        }

        return $blocking ?? $this->deny('no_eligible_membership', 'No eligible membership for check-in.', $member);
    }

    /**
     * @return array{
     *     allowed: bool,
     *     code: ?string,
     *     message: string,
     *     member: ?\App\Domains\Members\Models\Member,
     *     membership: ?Membership,
     *     recent_attendance_id: ?int,
     *     visits_remaining: ?int
     * }
     */
    private function deny(
        string $code,
        string $message,
        mixed $member = null,
        ?Membership $membership = null,
        ?int $recentAttendanceId = null
    ): array {
        return [
            'allowed' => false,
            'code' => $code,
            'message' => $message,
            'member' => $member,
            'membership' => $membership,
            'recent_attendance_id' => $recentAttendanceId,
            'visits_remaining' => $membership?->visits_remaining,
        ];
    }
}
