<?php

declare(strict_types=1);

namespace App\Domains\Attendance\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Identity\Models\User;
use App\Domains\Members\Models\Member;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Organization\Models\Branch;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Attendance extends BaseModel
{
    use BelongsToTenant;

    public const STATUS_VALID = 'valid';

    public const STATUS_VOIDED = 'voided';

    public const METHOD_STAFF = 'staff';

    public const METHOD_QR = 'qr';

    public const METHOD_CODE = 'code';

    protected $table = 'attendances';

    protected $fillable = [
        'tenant_id',
        'branch_id',
        'member_id',
        'membership_id',
        'checked_in_at',
        'method',
        'staff_user_id',
        'status',
        'void_reason',
        'notes',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'checked_in_at' => 'datetime',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function member(): BelongsTo
    {
        return $this->belongsTo(Member::class);
    }

    public function membership(): BelongsTo
    {
        return $this->belongsTo(Membership::class);
    }

    public function staffUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'staff_user_id');
    }

    public function isValid(): bool
    {
        return $this->status === self::STATUS_VALID;
    }
}
