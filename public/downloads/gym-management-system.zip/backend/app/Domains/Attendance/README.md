﻿# Attendance Domain

## Admin Portal — Walk-in attendance (complete)

Staff-assisted check-in only (V1). Requires `auth:sanctum` + staff + `X-Tenant-Slug` + permissions.

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/api/v1/admin/attendance` | `attendance.view` |
| GET | `/api/v1/admin/attendance/eligibility` | `attendance.check_in` |
| POST | `/api/v1/admin/attendance/check-in` | `attendance.check_in` |
| GET | `/api/v1/admin/attendance/{id}` | `attendance.view` |
| POST | `/api/v1/admin/attendance/{id}/void` | `attendance.void` |

Query filters (list): `branch_id`, `member_id`, `status`, `date`, `from`, `to`, `per_page`

### Eligibility / check-in rules
- Member must be `active` (not blacklisted/inactive)
- Eligible membership: `active` (and `grace` when `gms.attendance.allow_grace_status`)
- Plan must `allows_walkin`
- Branch allowed via `allows_all_branches` or `membership_plan_branches`
- Visit packs require `visits_remaining > 0` (decremented on check-in; restored on void)
- Duplicate window: `gms.attendance.duplicate_window_minutes` (default 30) — blocked

Statuses: `valid` | `voided`  
Methods: `staff` | `qr` | `code`

Audited: `attendance.checked_in`, `attendance.voided`

## Next Admin modules
Personal Training / Trainers → … (Classes/Schedule complete)
