<?php

declare(strict_types=1);

namespace App\Domains\Attendance\Contracts;

use App\Domains\Attendance\Models\Attendance;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface AttendanceRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $attendanceId): ?Attendance;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createAttendance(array $attributes): Attendance;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateAttendance(Attendance $attendance, array $attributes): Attendance;

    public function findRecentValidForMember(
        int $tenantId,
        int $memberId,
        int $branchId,
        int $withinMinutes
    ): ?Attendance;
}
