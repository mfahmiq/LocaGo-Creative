<?php

declare(strict_types=1);

namespace App\Domains\Attendance\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Attendance\Models\Attendance;
use App\Domains\Identity\Models\User;

final class AttendancePolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'attendance.view');
    }

    public function view(User $user, Attendance $attendance): bool
    {
        return $this->hasPermission($user, 'attendance.view')
            && $this->sameTenant($user, $attendance)
            && $this->branchAllowed($user, (int) $attendance->branch_id);
    }

    public function checkIn(User $user): bool
    {
        return $this->hasPermission($user, 'attendance.check_in');
    }

    public function void(User $user, Attendance $attendance): bool
    {
        return $this->hasPermission($user, 'attendance.void')
            && $this->sameTenant($user, $attendance)
            && $this->branchAllowed($user, (int) $attendance->branch_id);
    }
}
