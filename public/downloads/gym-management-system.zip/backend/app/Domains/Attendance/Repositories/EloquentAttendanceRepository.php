<?php

declare(strict_types=1);

namespace App\Domains\Attendance\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Attendance\Contracts\AttendanceRepositoryInterface;
use App\Domains\Attendance\Models\Attendance;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<Attendance>
 */
class EloquentAttendanceRepository extends BaseRepository implements AttendanceRepositoryInterface
{
    public function __construct(Attendance $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'branch', 'membership.plan', 'staffUser'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('checked_in_at');

        if (! empty($filters['branch_id'])) {
            $query->where('branch_id', (int) $filters['branch_id']);
        }

        if (! empty($filters['member_id'])) {
            $query->where('member_id', (int) $filters['member_id']);
        }

        if (! empty($filters['status'])) {
            $query->where('status', (string) $filters['status']);
        }

        if (! empty($filters['method'])) {
            $query->where('method', (string) $filters['method']);
        }

        if (! empty($filters['date'])) {
            $query->whereDate('checked_in_at', (string) $filters['date']);
        }

        if (! empty($filters['from'])) {
            $query->where('checked_in_at', '>=', (string) $filters['from']);
        }

        if (! empty($filters['to'])) {
            $query->where('checked_in_at', '<=', (string) $filters['to']);
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $attendanceId): ?Attendance
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'branch', 'membership.plan', 'staffUser'])
            ->where('tenant_id', $tenantId)
            ->where('id', $attendanceId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function createAttendance(array $attributes): Attendance
    {
        /** @var Attendance $attendance */
        $attendance = $this->query()->withoutGlobalScopes()->create($attributes);

        return $attendance->load(['member', 'branch', 'membership.plan', 'staffUser']);
    }

    public function updateAttendance(Attendance $attendance, array $attributes): Attendance
    {
        $attendance->update($attributes);

        return $attendance->fresh(['member', 'branch', 'membership.plan', 'staffUser']);
    }

    public function findRecentValidForMember(
        int $tenantId,
        int $memberId,
        int $branchId,
        int $withinMinutes
    ): ?Attendance {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('member_id', $memberId)
            ->where('branch_id', $branchId)
            ->where('status', Attendance::STATUS_VALID)
            ->whereNull('deleted_at')
            ->where('checked_in_at', '>=', now()->subMinutes($withinMinutes))
            ->orderByDesc('checked_in_at')
            ->first();
    }
}
