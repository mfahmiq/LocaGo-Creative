<?php

declare(strict_types=1);

namespace App\Domains\Mobile\Models;

use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Identity\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DeviceToken extends Model
{
    use BelongsToTenant;

    public const PLATFORM_IOS = 'ios';

    public const PLATFORM_ANDROID = 'android';

    public const PLATFORM_WEB = 'web';

    public const PROVIDER_FCM = 'fcm';

    public const PROVIDER_APNS = 'apns';

    public const PROVIDER_HMS = 'hms';

    protected $table = 'device_tokens';

    protected $fillable = [
        'tenant_id',
        'user_id',
        'platform',
        'provider',
        'token',
        'device_name',
        'app_version',
        'locale',
        'is_active',
        'last_seen_at',
    ];

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
            'last_seen_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
