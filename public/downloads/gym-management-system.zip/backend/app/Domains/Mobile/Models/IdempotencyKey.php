<?php

declare(strict_types=1);

namespace App\Domains\Mobile\Models;

use Illuminate\Database\Eloquent\Model;

class IdempotencyKey extends Model
{
    protected $table = 'idempotency_keys';

    protected $fillable = [
        'tenant_id',
        'user_id',
        'key',
        'method',
        'path',
        'request_hash',
        'response_code',
        'response_body',
        'expires_at',
    ];

    protected function casts(): array
    {
        return [
            'expires_at' => 'datetime',
            'response_code' => 'integer',
        ];
    }
}
