<?php

declare(strict_types=1);

namespace App\Domains\Mobile\Models;

use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Identity\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Storage;

class MediaFile extends Model
{
    use BelongsToTenant;

    protected $table = 'media_files';

    protected $fillable = [
        'tenant_id',
        'user_id',
        'collection',
        'disk',
        'path',
        'original_name',
        'mime_type',
        'size',
        'meta',
    ];

    protected function casts(): array
    {
        return [
            'size' => 'integer',
            'meta' => 'array',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function temporaryUrl(int $minutes = 30): ?string
    {
        $disk = Storage::disk($this->disk);
        if (method_exists($disk, 'temporaryUrl')) {
            try {
                return $disk->temporaryUrl($this->path, now()->addMinutes($minutes));
            } catch (\Throwable) {
                return null;
            }
        }

        return null;
    }
}
