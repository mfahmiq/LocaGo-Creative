<?php

declare(strict_types=1);

namespace App\Domains\Mobile\Jobs;

use App\Core\Jobs\TenantAwareJob;
use App\Domains\Mobile\Models\MediaFile;
use Illuminate\Support\Facades\Log;

/**
 * Example background job for mobile-triggered heavy work (image processing, scanning).
 * Clients can poll GET /member/jobs/{id} while the database queue driver is used.
 */
final class ProcessMediaUploadJob extends TenantAwareJob
{
    public function __construct(public readonly int $mediaFileId)
    {
        parent::__construct();
    }

    protected function queueName(): string
    {
        return (string) config('gms.queues.default', 'default');
    }

    public function handle(): void
    {
        $media = MediaFile::query()->find($this->mediaFileId);
        if ($media === null) {
            return;
        }

        $this->tenantId = (int) $media->tenant_id;

        $meta = $media->meta ?? [];
        $meta['processed_at'] = now()->toIso8601String();
        $meta['processing_status'] = 'completed';
        $media->forceFill(['meta' => $meta])->save();

        Log::info('mobile.media.processed', [
            'tenant_id' => $media->tenant_id,
            'media_id' => $this->mediaFileId,
        ]);
    }
}
