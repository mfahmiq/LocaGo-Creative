<?php

declare(strict_types=1);

namespace App\Domains\Mobile\Services;

use App\Core\Services\BaseService;
use App\Domains\Billing\Models\Invoice;
use App\Domains\Identity\Models\User;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Notifications\Models\InAppNotification;
use App\Domains\Tenancy\Models\Tenant;
use App\Http\Resources\Member\MemberProfileResource;
use App\Http\Resources\Member\MemberUserResource;
use Illuminate\Support\Carbon;

final class MobileSyncService extends BaseService
{
    public function __construct(
        private readonly MemberRepositoryInterface $members
    ) {}

    /**
     * Delta payload for offline-friendly mobile clients.
     *
     * @return array<string, mixed>
     */
    public function syncMember(Tenant $tenant, User $user, ?string $updatedSince = null): array
    {
        $since = $updatedSince ? Carbon::parse($updatedSince) : null;
        $serverTime = now()->toIso8601String();
        $member = $this->members->findByUserId($tenant->id, $user->id);

        $membershipsQuery = Membership::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenant->id)
            ->where('member_id', $member?->id)
            ->whereNull('deleted_at');
        if ($since) {
            $membershipsQuery->where('updated_at', '>', $since);
        }

        $invoicesQuery = Invoice::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenant->id)
            ->where('member_id', $member?->id)
            ->whereNull('deleted_at');
        if ($since) {
            $invoicesQuery->where('updated_at', '>', $since);
        }

        $notificationsQuery = InAppNotification::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenant->id)
            ->where('user_id', $user->id)
            ->whereNull('deleted_at');
        if ($since) {
            $notificationsQuery->where('updated_at', '>', $since);
        }

        $profileChanged = $member === null
            || $since === null
            || $member->updated_at?->gt($since)
            || $user->updated_at?->gt($since);

        return [
            'server_time' => $serverTime,
            'sync_token' => $serverTime,
            'scope' => 'member',
            'changes' => [
                'profile' => $profileChanged && $member !== null
                    ? [
                        'member' => (new MemberProfileResource($member))->resolve(),
                        'user' => (new MemberUserResource($user))->resolve(),
                    ]
                    : null,
                'memberships' => [
                    'upserts' => $membershipsQuery->orderBy('id')->limit(200)->get()->map(fn (Membership $m) => [
                        'id' => $m->id,
                        'status' => $m->status,
                        'start_date' => $m->start_date?->toDateString(),
                        'end_date' => $m->end_date?->toDateString(),
                        'membership_plan_id' => $m->membership_plan_id,
                        'branch_id' => $m->branch_id,
                        'updated_at' => $m->updated_at?->toIso8601String(),
                    ])->all(),
                    'deleted_ids' => [],
                ],
                'invoices' => [
                    'upserts' => $invoicesQuery->orderBy('id')->limit(200)->get()->map(fn (Invoice $i) => [
                        'id' => $i->id,
                        'invoice_number' => $i->invoice_number,
                        'status' => $i->status,
                        'grand_total' => $i->grand_total,
                        'balance_due' => $i->balance_due,
                        'issue_date' => $i->issue_date?->toDateString(),
                        'updated_at' => $i->updated_at?->toIso8601String(),
                    ])->all(),
                    'deleted_ids' => [],
                ],
                'notifications' => [
                    'upserts' => $notificationsQuery->orderByDesc('id')->limit(200)->get()->map(fn (InAppNotification $n) => [
                        'id' => $n->id,
                        'title' => $n->title ?? null,
                        'body' => $n->body,
                        'event_key' => $n->event_key,
                        'read_at' => $n->read_at?->toIso8601String(),
                        'created_at' => $n->created_at?->toIso8601String(),
                        'updated_at' => $n->updated_at?->toIso8601String(),
                    ])->all(),
                    'deleted_ids' => [],
                ],
            ],
        ];
    }
}
