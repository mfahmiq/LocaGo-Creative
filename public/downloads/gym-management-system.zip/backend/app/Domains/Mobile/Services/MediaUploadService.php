<?php

declare(strict_types=1);

namespace App\Domains\Mobile\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Identity\Models\User;
use App\Domains\Mobile\Models\MediaFile;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

final class MediaUploadService extends BaseService
{
    /**
     * @param  array<string, mixed>  $options
     */
    public function store(Tenant $tenant, User $user, UploadedFile $file, array $options = []): MediaFile
    {
        $collection = (string) ($options['collection'] ?? 'attachment');
        $allowedCollections = (array) config('gms.api.media.collections', ['avatar', 'document', 'attachment']);
        if (! in_array($collection, $allowedCollections, true)) {
            throw new DomainException('Invalid media collection.', 'invalid_media_collection', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        $maxKb = (int) config('gms.api.media.max_kilobytes', 5120);
        if ($file->getSize() > $maxKb * 1024) {
            throw new DomainException(
                "File exceeds maximum size of {$maxKb} KB.",
                'media_too_large',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $disk = (string) config('gms.storage.disk', 'local');
        $root = trim((string) config('gms.storage.tenants_root', 'tenants'), '/');
        $ext = $file->getClientOriginalExtension() ?: $file->extension() ?: 'bin';
        $filename = Str::uuid()->toString().'.'.$ext;

        Storage::disk($disk)->putFileAs(
            "{$root}/{$tenant->id}/media/{$collection}",
            $file,
            $filename
        );

        return MediaFile::query()->create([
            'tenant_id' => $tenant->id,
            'user_id' => $user->id,
            'collection' => $collection,
            'disk' => $disk,
            'path' => "{$root}/{$tenant->id}/media/{$collection}/{$filename}",
            'original_name' => $file->getClientOriginalName(),
            'mime_type' => (string) ($file->getMimeType() ?: 'application/octet-stream'),
            'size' => (int) $file->getSize(),
            'meta' => [
                'app_version' => $options['app_version'] ?? null,
                'device_name' => $options['device_name'] ?? null,
            ],
        ]);
    }
}
