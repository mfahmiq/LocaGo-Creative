<?php

declare(strict_types=1);

namespace App\Domains\Mobile\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Identity\Models\User;
use App\Domains\Mobile\Models\DeviceToken;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeviceTokenService extends BaseService
{
    /**
     * @param  array<string, mixed>  $data
     */
    public function register(Tenant $tenant, User $user, array $data): DeviceToken
    {
        $token = trim((string) $data['token']);
        $platform = (string) $data['platform'];
        $provider = (string) ($data['provider'] ?? DeviceToken::PROVIDER_FCM);

        if (! in_array($platform, [DeviceToken::PLATFORM_IOS, DeviceToken::PLATFORM_ANDROID, DeviceToken::PLATFORM_WEB], true)) {
            throw new DomainException('Invalid platform.', 'invalid_platform', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        /** @var DeviceToken $device */
        $device = DeviceToken::query()->updateOrCreate(
            [
                'tenant_id' => $tenant->id,
                'token' => $token,
            ],
            [
                'user_id' => $user->id,
                'platform' => $platform,
                'provider' => $provider,
                'device_name' => $data['device_name'] ?? null,
                'app_version' => $data['app_version'] ?? null,
                'locale' => $data['locale'] ?? null,
                'is_active' => true,
                'last_seen_at' => now(),
            ]
        );

        return $device;
    }

    public function unregister(Tenant $tenant, User $user, string $token): void
    {
        DeviceToken::query()
            ->where('tenant_id', $tenant->id)
            ->where('user_id', $user->id)
            ->where('token', $token)
            ->update([
                'is_active' => false,
                'updated_at' => now(),
            ]);
    }

    /**
     * @return list<DeviceToken>
     */
    public function listForUser(Tenant $tenant, User $user): array
    {
        return DeviceToken::query()
            ->where('tenant_id', $tenant->id)
            ->where('user_id', $user->id)
            ->where('is_active', true)
            ->orderByDesc('last_seen_at')
            ->get()
            ->all();
    }

    /**
     * @return list<string>
     */
    public function activeTokensForUser(int $tenantId, int $userId, ?string $provider = null): array
    {
        $query = DeviceToken::query()
            ->where('tenant_id', $tenantId)
            ->where('user_id', $userId)
            ->where('is_active', true);

        if ($provider !== null) {
            $query->where('provider', $provider);
        }

        return $query->pluck('token')->map(fn ($t) => (string) $t)->all();
    }
}
