# Mobile API domain

Supports future Android / iOS clients without a parallel backend.

## Endpoints

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/api/v1/mobile/capabilities` | Machine-readable contract |
| GET | `/api/v1/member/sync` | Offline delta sync (`updated_since`) |
| GET/POST/DELETE | `/api/v1/member/devices` | Push device token registry |
| POST | `/api/v1/member/media` | Multipart upload |
| GET | `/api/v1/member/media/{id}/download` | Authorized download |
| GET/DELETE | `/api/v1/member/sessions` | Multi-device session control |
| GET | `/api/v1/member/jobs/{jobId}` | Background job polling |

## Tables

- `device_tokens`
- `idempotency_keys`
- `media_files`

## Docs

See `docs/MOBILE_API.md`.
