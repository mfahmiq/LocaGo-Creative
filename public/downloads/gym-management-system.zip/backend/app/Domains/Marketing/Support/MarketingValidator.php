<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Support;

use App\Core\Exceptions\DomainException;
use App\Domains\Marketing\Models\Coupon;
use App\Domains\Marketing\Models\Offer;
use Carbon\CarbonInterface;
use Symfony\Component\HttpFoundation\Response;

final class MarketingValidator
{
    /**
     * @param  array<string, mixed>  $data
     */
    public static function assertDiscountType(array $data, ?string $field = 'discount_type'): void
    {
        $type = (string) ($data[$field] ?? '');

        if (! in_array($type, [Offer::DISCOUNT_TYPE_PERCENT, Offer::DISCOUNT_TYPE_FIXED], true)) {
            throw new DomainException(
                'Discount type must be percent or fixed.',
                'invalid_discount_type',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }

    public static function assertDateWindow(CarbonInterface|string $startsAt, CarbonInterface|string $endsAt): void
    {
        $start = $startsAt instanceof CarbonInterface ? $startsAt : now()->parse((string) $startsAt);
        $end = $endsAt instanceof CarbonInterface ? $endsAt : now()->parse((string) $endsAt);

        if ($end->lte($start)) {
            throw new DomainException(
                'End date must be after start date.',
                'invalid_date_window',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }

    public static function assertCouponRedeemable(Coupon $coupon, ?int $memberId, int $memberRedemptionCount): void
    {
        if (! $coupon->is_active) {
            throw new DomainException('Coupon is inactive.', 'coupon_inactive', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        $now = now();

        if ($now->lt($coupon->starts_at) || $now->gt($coupon->ends_at)) {
            throw new DomainException('Coupon is expired or not yet active.', 'coupon_expired', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        if ($coupon->max_redemptions !== null && $coupon->redeemed_count >= $coupon->max_redemptions) {
            throw new DomainException('Coupon redemption limit reached.', 'coupon_exhausted', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        if ($memberId !== null && $memberRedemptionCount >= $coupon->per_member_limit) {
            throw new DomainException(
                'Member has reached the coupon redemption limit.',
                'coupon_member_limit',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }
}
