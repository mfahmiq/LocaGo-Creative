<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Marketing\Contracts\ReferralRepositoryInterface;
use App\Domains\Marketing\Models\Referral;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<Referral>
 */
class EloquentReferralRepository extends BaseRepository implements ReferralRepositoryInterface
{
    public function __construct(Referral $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['referrer', 'referee'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('created_at')
            ->orderByDesc('id');

        if (! empty($filters['status'])) {
            $query->where('status', (string) $filters['status']);
        }

        if (! empty($filters['referrer_member_id'])) {
            $query->where('referrer_member_id', (int) $filters['referrer_member_id']);
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $referralId): ?Referral
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['referrer', 'referee'])
            ->where('tenant_id', $tenantId)
            ->where('id', $referralId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function findByRefereeMemberId(int $tenantId, int $refereeMemberId): ?Referral
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('referee_member_id', $refereeMemberId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function createReferral(array $attributes): Referral
    {
        /** @var Referral $referral */
        $referral = $this->query()->withoutGlobalScopes()->create($attributes);

        return $referral->load(['referrer', 'referee']);
    }

    public function updateReferral(Referral $referral, array $attributes): Referral
    {
        $referral->update($attributes);

        return $referral->fresh(['referrer', 'referee']);
    }
}
