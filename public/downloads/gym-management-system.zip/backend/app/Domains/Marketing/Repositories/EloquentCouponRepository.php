<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Marketing\Contracts\CouponRepositoryInterface;
use App\Domains\Marketing\Models\Coupon;
use App\Domains\Marketing\Models\CouponRedemption;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<Coupon>
 */
class EloquentCouponRepository extends BaseRepository implements CouponRepositoryInterface
{
    public function __construct(Coupon $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('starts_at')
            ->orderByDesc('id');

        if (array_key_exists('is_active', $filters) && $filters['is_active'] !== null && $filters['is_active'] !== '') {
            $query->where('is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN));
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);
            $query->where('code', 'like', "%{$search}%");
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $couponId): ?Coupon
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('id', $couponId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function findByCode(int $tenantId, string $code, ?int $exceptCouponId = null): ?Coupon
    {
        $query = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('code', $code)
            ->whereNull('deleted_at');

        if ($exceptCouponId !== null) {
            $query->where('id', '!=', $exceptCouponId);
        }

        return $query->first();
    }

    public function countRedemptionsForMember(int $tenantId, int $couponId, int $memberId): int
    {
        return CouponRedemption::query()
            ->where('tenant_id', $tenantId)
            ->where('coupon_id', $couponId)
            ->where('member_id', $memberId)
            ->count();
    }

    public function createCoupon(array $attributes): Coupon
    {
        /** @var Coupon $coupon */
        $coupon = $this->query()->withoutGlobalScopes()->create($attributes);

        return $coupon;
    }

    public function updateCoupon(Coupon $coupon, array $attributes): Coupon
    {
        $coupon->update($attributes);

        return $coupon->fresh();
    }

    public function deleteCoupon(Coupon $coupon): bool
    {
        return (bool) $coupon->delete();
    }

    public function incrementRedeemedCount(Coupon $coupon): Coupon
    {
        $coupon->increment('redeemed_count');

        return $coupon->fresh();
    }

    public function createRedemption(array $attributes): CouponRedemption
    {
        return CouponRedemption::query()->create($attributes);
    }
}
