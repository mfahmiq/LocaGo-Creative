<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Marketing\Contracts\OfferRepositoryInterface;
use App\Domains\Marketing\Models\Offer;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<Offer>
 */
class EloquentOfferRepository extends BaseRepository implements OfferRepositoryInterface
{
    public function __construct(Offer $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('starts_at')
            ->orderByDesc('id');

        if (array_key_exists('is_active', $filters) && $filters['is_active'] !== null && $filters['is_active'] !== '') {
            $query->where('is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN));
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);
            $query->where(function ($q) use ($search): void {
                $q->where('code', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%");
            });
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $offerId): ?Offer
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('id', $offerId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function findByCode(int $tenantId, string $code, ?int $exceptOfferId = null): ?Offer
    {
        $query = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('code', $code)
            ->whereNull('deleted_at');

        if ($exceptOfferId !== null) {
            $query->where('id', '!=', $exceptOfferId);
        }

        return $query->first();
    }

    public function createOffer(array $attributes): Offer
    {
        /** @var Offer $offer */
        $offer = $this->query()->withoutGlobalScopes()->create($attributes);

        return $offer;
    }

    public function updateOffer(Offer $offer, array $attributes): Offer
    {
        $offer->update($attributes);

        return $offer->fresh();
    }

    public function deleteOffer(Offer $offer): bool
    {
        return (bool) $offer->delete();
    }
}
