<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Marketing\Actions\CreateCouponAction;
use App\Domains\Marketing\Actions\DeleteCouponAction;
use App\Domains\Marketing\Actions\RedeemCouponAction;
use App\Domains\Marketing\Actions\UpdateCouponAction;
use App\Domains\Marketing\Contracts\CouponRepositoryInterface;
use App\Domains\Marketing\Models\Coupon;
use App\Domains\Marketing\Models\CouponRedemption;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class CouponService extends BaseService
{
    public function __construct(
        private readonly CouponRepositoryInterface $coupons,
        private readonly CreateCouponAction $createCouponAction,
        private readonly UpdateCouponAction $updateCouponAction,
        private readonly DeleteCouponAction $deleteCouponAction,
        private readonly RedeemCouponAction $redeemCouponAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->coupons->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $couponId): Coupon
    {
        $coupon = $this->coupons->findForTenant($tenant->id, $couponId);

        if ($coupon === null) {
            throw new DomainException('Coupon not found.', 'coupon_not_found', Response::HTTP_NOT_FOUND);
        }

        return $coupon;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): Coupon
    {
        return $this->createCouponAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $couponId, array $data): Coupon
    {
        return $this->updateCouponAction->execute($tenant, $couponId, $data);
    }

    public function delete(Tenant $tenant, int $couponId): bool
    {
        return $this->deleteCouponAction->execute($tenant, $couponId);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function redeem(Tenant $tenant, int $couponId, array $data): CouponRedemption
    {
        return $this->redeemCouponAction->execute($tenant, $couponId, $data);
    }
}
