<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Marketing\Actions\CreateReferralAction;
use App\Domains\Marketing\Actions\DisqualifyReferralAction;
use App\Domains\Marketing\Actions\QualifyReferralAction;
use App\Domains\Marketing\Actions\RewardReferralAction;
use App\Domains\Marketing\Contracts\ReferralRepositoryInterface;
use App\Domains\Marketing\Models\Referral;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class ReferralService extends BaseService
{
    public function __construct(
        private readonly ReferralRepositoryInterface $referrals,
        private readonly CreateReferralAction $createReferralAction,
        private readonly QualifyReferralAction $qualifyReferralAction,
        private readonly RewardReferralAction $rewardReferralAction,
        private readonly DisqualifyReferralAction $disqualifyReferralAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->referrals->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $referralId): Referral
    {
        $referral = $this->referrals->findForTenant($tenant->id, $referralId);

        if ($referral === null) {
            throw new DomainException('Referral not found.', 'referral_not_found', Response::HTTP_NOT_FOUND);
        }

        return $referral;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): Referral
    {
        return $this->createReferralAction->execute($tenant, $data);
    }

    public function qualify(Tenant $tenant, int $referralId): Referral
    {
        return $this->qualifyReferralAction->execute($tenant, $referralId);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function reward(Tenant $tenant, int $referralId, array $data = []): Referral
    {
        return $this->rewardReferralAction->execute($tenant, $referralId, $data);
    }

    public function disqualify(Tenant $tenant, int $referralId): Referral
    {
        return $this->disqualifyReferralAction->execute($tenant, $referralId);
    }
}
