<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Marketing\Models\LoyaltyAccount;
use App\Domains\Marketing\Models\LoyaltyLedgerEntry;
use App\Domains\Marketing\Models\LoyaltySettings;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

final class LoyaltyService extends BaseService
{
    public function __construct(private readonly AuditWriter $audit) {}

    public function getOrCreateSettings(Tenant $tenant): LoyaltySettings
    {
        $settings = LoyaltySettings::query()->where('tenant_id', $tenant->id)->first();
        if ($settings !== null) {
            return $settings;
        }

        return LoyaltySettings::query()->create([
            'tenant_id' => $tenant->id,
            'is_enabled' => true,
            'points_per_check_in' => 10,
            'points_per_100_currency' => 5,
            'points_per_referral' => 100,
            'redeem_value_per_100_points' => 10,
        ]);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function updateSettings(Tenant $tenant, array $data): LoyaltySettings
    {
        $settings = $this->getOrCreateSettings($tenant);
        $settings->fill(array_intersect_key($data, array_flip([
            'is_enabled',
            'points_per_check_in',
            'points_per_100_currency',
            'points_per_referral',
            'redeem_value_per_100_points',
        ])));
        $settings->save();

        $this->audit->write(
            action: 'loyalty.settings_updated',
            entityType: 'loyalty_settings',
            entityId: $settings->id,
            tenantId: $tenant->id,
            newValues: $settings->toArray()
        );

        return $settings->fresh();
    }

    public function getOrCreateAccount(Tenant $tenant, int $memberId): LoyaltyAccount
    {
        $account = LoyaltyAccount::query()
            ->where('tenant_id', $tenant->id)
            ->where('member_id', $memberId)
            ->first();

        if ($account !== null) {
            return $account;
        }

        return LoyaltyAccount::query()->create([
            'tenant_id' => $tenant->id,
            'member_id' => $memberId,
            'points_balance' => 0,
            'lifetime_earned' => 0,
            'lifetime_redeemed' => 0,
        ]);
    }

    public function earn(
        Tenant $tenant,
        int $memberId,
        int $points,
        string $reason,
        ?string $sourceType = null,
        ?int $sourceId = null,
        ?string $notes = null
    ): LoyaltyAccount {
        if ($points <= 0) {
            return $this->getOrCreateAccount($tenant, $memberId);
        }

        return DB::transaction(function () use ($tenant, $memberId, $points, $reason, $sourceType, $sourceId, $notes): LoyaltyAccount {
            $account = LoyaltyAccount::query()
                ->where('tenant_id', $tenant->id)
                ->where('member_id', $memberId)
                ->lockForUpdate()
                ->first();

            if ($account === null) {
                $account = $this->getOrCreateAccount($tenant, $memberId);
                $account = LoyaltyAccount::query()->whereKey($account->id)->lockForUpdate()->firstOrFail();
            }

            $account->update([
                'points_balance' => $account->points_balance + $points,
                'lifetime_earned' => $account->lifetime_earned + $points,
            ]);

            LoyaltyLedgerEntry::query()->create([
                'tenant_id' => $tenant->id,
                'loyalty_account_id' => $account->id,
                'member_id' => $memberId,
                'points' => $points,
                'reason' => $reason,
                'source_type' => $sourceType,
                'source_id' => $sourceId,
                'notes' => $notes,
                'created_at' => now(),
                'created_by' => Auth::id(),
            ]);

            return $account->fresh();
        });
    }

    public function redeem(Tenant $tenant, int $memberId, int $points, ?string $notes = null): LoyaltyAccount
    {
        if ($points <= 0) {
            throw new DomainException('Redeem points must be positive.', 'invalid_points', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        return DB::transaction(function () use ($tenant, $memberId, $points, $notes): LoyaltyAccount {
            $account = LoyaltyAccount::query()
                ->where('tenant_id', $tenant->id)
                ->where('member_id', $memberId)
                ->lockForUpdate()
                ->first();

            if ($account === null || $account->points_balance < $points) {
                throw new DomainException('Insufficient loyalty points.', 'insufficient_points', Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $account->update([
                'points_balance' => $account->points_balance - $points,
                'lifetime_redeemed' => $account->lifetime_redeemed + $points,
            ]);

            LoyaltyLedgerEntry::query()->create([
                'tenant_id' => $tenant->id,
                'loyalty_account_id' => $account->id,
                'member_id' => $memberId,
                'points' => -$points,
                'reason' => 'redeem',
                'notes' => $notes,
                'created_at' => now(),
                'created_by' => Auth::id(),
            ]);

            return $account->fresh();
        });
    }

    public function adjust(Tenant $tenant, int $memberId, int $points, ?string $notes = null): LoyaltyAccount
    {
        if ($points === 0) {
            throw new DomainException('Points adjustment cannot be zero.', 'invalid_points', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        if ($points > 0) {
            return $this->earn($tenant, $memberId, $points, 'manual', null, null, $notes);
        }

        return $this->redeem($tenant, $memberId, abs($points), $notes);
    }

    public function awardCheckIn(Tenant $tenant, int $memberId, int $attendanceId): void
    {
        $settings = $this->getOrCreateSettings($tenant);
        if (! $settings->is_enabled || $settings->points_per_check_in < 1) {
            return;
        }

        $this->earn(
            $tenant,
            $memberId,
            (int) $settings->points_per_check_in,
            'check_in',
            'attendance',
            $attendanceId
        );
    }

    public function awardPurchase(Tenant $tenant, int $memberId, int $saleId, float $grandTotal): void
    {
        $settings = $this->getOrCreateSettings($tenant);
        if (! $settings->is_enabled || $settings->points_per_100_currency < 1 || $grandTotal <= 0) {
            return;
        }

        $points = (int) floor(($grandTotal / 100) * $settings->points_per_100_currency);
        if ($points < 1) {
            return;
        }

        $this->earn($tenant, $memberId, $points, 'purchase', 'sale', $saleId);
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateLedger(Tenant $tenant, int $memberId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(max((int) ($filters['per_page'] ?? 10), 1), 100);

        return LoyaltyLedgerEntry::query()
            ->where('tenant_id', $tenant->id)
            ->where('member_id', $memberId)
            ->orderByDesc('id')
            ->paginate($perPage);
    }
}
