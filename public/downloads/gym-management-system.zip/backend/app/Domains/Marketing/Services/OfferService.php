<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Marketing\Actions\CreateOfferAction;
use App\Domains\Marketing\Actions\DeleteOfferAction;
use App\Domains\Marketing\Actions\UpdateOfferAction;
use App\Domains\Marketing\Contracts\OfferRepositoryInterface;
use App\Domains\Marketing\Models\Offer;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class OfferService extends BaseService
{
    public function __construct(
        private readonly OfferRepositoryInterface $offers,
        private readonly CreateOfferAction $createOfferAction,
        private readonly UpdateOfferAction $updateOfferAction,
        private readonly DeleteOfferAction $deleteOfferAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->offers->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $offerId): Offer
    {
        $offer = $this->offers->findForTenant($tenant->id, $offerId);

        if ($offer === null) {
            throw new DomainException('Offer not found.', 'offer_not_found', Response::HTTP_NOT_FOUND);
        }

        return $offer;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): Offer
    {
        return $this->createOfferAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $offerId, array $data): Offer
    {
        return $this->updateOfferAction->execute($tenant, $offerId, $data);
    }

    public function delete(Tenant $tenant, int $offerId): bool
    {
        return $this->deleteOfferAction->execute($tenant, $offerId);
    }
}
