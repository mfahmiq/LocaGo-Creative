<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Marketing\Contracts\ReferralRepositoryInterface;
use App\Domains\Marketing\Models\Referral;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class RewardReferralAction extends Action
{
    public function __construct(
        private readonly ReferralRepositoryInterface $referrals,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Referral
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        $referralId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        $referral = $this->referrals->findForTenant($tenant->id, $referralId);

        if ($referral === null) {
            throw new DomainException('Referral not found.', 'referral_not_found', Response::HTTP_NOT_FOUND);
        }

        if (! $referral->isQualified()) {
            throw new DomainException(
                'Only qualified referrals can be rewarded.',
                'invalid_referral_status',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $payload = [
            'status' => Referral::STATUS_REWARDED,
            'rewarded_at' => now(),
        ];

        if (array_key_exists('reward_type', $data)) {
            $payload['reward_type'] = $data['reward_type'] !== null ? (string) $data['reward_type'] : null;
        }

        if (array_key_exists('reward_reference', $data)) {
            $payload['reward_reference'] = $data['reward_reference'] !== null ? (string) $data['reward_reference'] : null;
        }

        $updated = $this->referrals->updateReferral($referral, $payload);

        $this->audit->write(
            action: 'referral.rewarded',
            entityType: 'referral',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: $payload
        );

        return $updated;
    }
}
