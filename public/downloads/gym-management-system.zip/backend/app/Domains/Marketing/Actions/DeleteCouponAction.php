<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Marketing\Contracts\CouponRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeleteCouponAction extends Action
{
    public function __construct(
        private readonly CouponRepositoryInterface $coupons,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        $couponId = (int) $args[1];

        $coupon = $this->coupons->findForTenant($tenant->id, $couponId);

        if ($coupon === null) {
            throw new DomainException('Coupon not found.', 'coupon_not_found', Response::HTTP_NOT_FOUND);
        }

        $deleted = $this->coupons->deleteCoupon($coupon);

        $this->audit->write(
            action: 'coupon.deleted',
            entityType: 'coupon',
            entityId: $couponId,
            tenantId: $tenant->id,
            oldValues: ['code' => $coupon->code]
        );

        return $deleted;
    }
}
