<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Marketing\Contracts\OfferRepositoryInterface;
use App\Domains\Marketing\Models\Offer;
use App\Domains\Marketing\Support\MarketingValidator;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CreateOfferAction extends Action
{
    public function __construct(
        private readonly OfferRepositoryInterface $offers,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Offer
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        MarketingValidator::assertDiscountType($data);
        MarketingValidator::assertDateWindow((string) $data['starts_at'], (string) $data['ends_at']);

        $code = strtoupper(trim((string) $data['code']));

        if ($this->offers->findByCode($tenant->id, $code) !== null) {
            throw new DomainException('Offer code already exists.', 'offer_code_exists', Response::HTTP_CONFLICT);
        }

        $offer = $this->offers->createOffer([
            'tenant_id' => $tenant->id,
            'code' => $code,
            'name' => trim((string) $data['name']),
            'discount_type' => (string) $data['discount_type'],
            'discount_value' => number_format((float) $data['discount_value'], 2, '.', ''),
            'starts_at' => (string) $data['starts_at'],
            'ends_at' => (string) $data['ends_at'],
            'is_active' => (bool) ($data['is_active'] ?? true),
            'stackable_with_coupon' => (bool) ($data['stackable_with_coupon'] ?? false),
        ]);

        $this->audit->write(
            action: 'offer.created',
            entityType: 'offer',
            entityId: $offer->id,
            tenantId: $tenant->id,
            newValues: ['code' => $offer->code, 'name' => $offer->name]
        );

        return $offer;
    }
}
