<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Marketing\Contracts\CouponRepositoryInterface;
use App\Domains\Marketing\Models\CouponRedemption;
use App\Domains\Marketing\Support\MarketingValidator;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

final class RedeemCouponAction extends Action
{
    public function __construct(
        private readonly CouponRepositoryInterface $coupons,
        private readonly MemberRepositoryInterface $members,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): CouponRedemption
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        $couponId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        return $this->transaction(function () use ($tenant, $couponId, $data): CouponRedemption {
            $coupon = $this->coupons->findForTenant($tenant->id, $couponId);

            if ($coupon === null) {
                throw new DomainException('Coupon not found.', 'coupon_not_found', Response::HTTP_NOT_FOUND);
            }

            $memberId = isset($data['member_id']) ? (int) $data['member_id'] : null;
            $invoiceId = isset($data['invoice_id']) ? (int) $data['invoice_id'] : null;

            if ($memberId !== null && $this->members->findForTenant($tenant->id, $memberId) === null) {
                throw new DomainException('Member not found.', 'member_not_found', Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $memberRedemptionCount = $memberId !== null
                ? $this->coupons->countRedemptionsForMember($tenant->id, $coupon->id, $memberId)
                : 0;

            MarketingValidator::assertCouponRedeemable($coupon, $memberId, $memberRedemptionCount);

            $redemption = $this->coupons->createRedemption([
                'tenant_id' => $tenant->id,
                'coupon_id' => $coupon->id,
                'member_id' => $memberId,
                'invoice_id' => $invoiceId,
                'redeemed_at' => now(),
                'created_at' => now(),
                'created_by' => Auth::id(),
            ]);

            $updatedCoupon = $this->coupons->incrementRedeemedCount($coupon);

            $this->audit->write(
                action: 'coupon.redeemed',
                entityType: 'coupon',
                entityId: $updatedCoupon->id,
                tenantId: $tenant->id,
                newValues: [
                    'redemption_id' => $redemption->id,
                    'member_id' => $memberId,
                    'invoice_id' => $invoiceId,
                    'redeemed_count' => $updatedCoupon->redeemed_count,
                ]
            );

            return $redemption;
        });
    }
}
