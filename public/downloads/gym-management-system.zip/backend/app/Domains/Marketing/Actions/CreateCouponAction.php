<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Marketing\Contracts\CouponRepositoryInterface;
use App\Domains\Marketing\Models\Coupon;
use App\Domains\Marketing\Support\MarketingValidator;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CreateCouponAction extends Action
{
    public function __construct(
        private readonly CouponRepositoryInterface $coupons,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Coupon
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        MarketingValidator::assertDiscountType($data);
        MarketingValidator::assertDateWindow((string) $data['starts_at'], (string) $data['ends_at']);

        $code = strtoupper(trim((string) $data['code']));

        if ($this->coupons->findByCode($tenant->id, $code) !== null) {
            throw new DomainException('Coupon code already exists.', 'coupon_code_exists', Response::HTTP_CONFLICT);
        }

        $coupon = $this->coupons->createCoupon([
            'tenant_id' => $tenant->id,
            'code' => $code,
            'discount_type' => (string) $data['discount_type'],
            'discount_value' => number_format((float) $data['discount_value'], 2, '.', ''),
            'max_redemptions' => isset($data['max_redemptions']) ? (int) $data['max_redemptions'] : null,
            'per_member_limit' => (int) ($data['per_member_limit'] ?? 1),
            'redeemed_count' => 0,
            'starts_at' => (string) $data['starts_at'],
            'ends_at' => (string) $data['ends_at'],
            'is_active' => (bool) ($data['is_active'] ?? true),
        ]);

        $this->audit->write(
            action: 'coupon.created',
            entityType: 'coupon',
            entityId: $coupon->id,
            tenantId: $tenant->id,
            newValues: ['code' => $coupon->code]
        );

        return $coupon;
    }
}
