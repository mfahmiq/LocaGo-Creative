<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Marketing\Contracts\CouponRepositoryInterface;
use App\Domains\Marketing\Models\Coupon;
use App\Domains\Marketing\Support\MarketingValidator;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateCouponAction extends Action
{
    public function __construct(
        private readonly CouponRepositoryInterface $coupons,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Coupon
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        $couponId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        $coupon = $this->coupons->findForTenant($tenant->id, $couponId);

        if ($coupon === null) {
            throw new DomainException('Coupon not found.', 'coupon_not_found', Response::HTTP_NOT_FOUND);
        }

        $payload = [];

        if (array_key_exists('code', $data)) {
            $code = strtoupper(trim((string) $data['code']));
            if ($this->coupons->findByCode($tenant->id, $code, $coupon->id) !== null) {
                throw new DomainException('Coupon code already exists.', 'coupon_code_exists', Response::HTTP_CONFLICT);
            }
            $payload['code'] = $code;
        }

        if (array_key_exists('discount_type', $data)) {
            MarketingValidator::assertDiscountType($data);
            $payload['discount_type'] = (string) $data['discount_type'];
        }

        if (array_key_exists('discount_value', $data)) {
            $payload['discount_value'] = number_format((float) $data['discount_value'], 2, '.', '');
        }

        if (array_key_exists('max_redemptions', $data)) {
            $payload['max_redemptions'] = $data['max_redemptions'] !== null ? (int) $data['max_redemptions'] : null;
        }

        if (array_key_exists('per_member_limit', $data)) {
            $payload['per_member_limit'] = (int) $data['per_member_limit'];
        }

        if (array_key_exists('starts_at', $data)) {
            $payload['starts_at'] = (string) $data['starts_at'];
        }

        if (array_key_exists('ends_at', $data)) {
            $payload['ends_at'] = (string) $data['ends_at'];
        }

        if (array_key_exists('is_active', $data)) {
            $payload['is_active'] = (bool) $data['is_active'];
        }

        $startsAt = $payload['starts_at'] ?? $coupon->starts_at;
        $endsAt = $payload['ends_at'] ?? $coupon->ends_at;
        MarketingValidator::assertDateWindow($startsAt, $endsAt);

        $updated = $this->coupons->updateCoupon($coupon, $payload);

        $this->audit->write(
            action: 'coupon.updated',
            entityType: 'coupon',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: $payload
        );

        return $updated;
    }
}
