<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Marketing\Contracts\OfferRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeleteOfferAction extends Action
{
    public function __construct(
        private readonly OfferRepositoryInterface $offers,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        $offerId = (int) $args[1];

        $offer = $this->offers->findForTenant($tenant->id, $offerId);

        if ($offer === null) {
            throw new DomainException('Offer not found.', 'offer_not_found', Response::HTTP_NOT_FOUND);
        }

        $deleted = $this->offers->deleteOffer($offer);

        $this->audit->write(
            action: 'offer.deleted',
            entityType: 'offer',
            entityId: $offerId,
            tenantId: $tenant->id,
            oldValues: ['code' => $offer->code, 'name' => $offer->name]
        );

        return $deleted;
    }
}
