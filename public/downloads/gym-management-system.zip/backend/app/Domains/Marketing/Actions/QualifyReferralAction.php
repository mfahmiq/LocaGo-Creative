<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Marketing\Contracts\ReferralRepositoryInterface;
use App\Domains\Marketing\Models\Referral;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class QualifyReferralAction extends Action
{
    public function __construct(
        private readonly ReferralRepositoryInterface $referrals,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Referral
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        $referralId = (int) $args[1];

        $referral = $this->referrals->findForTenant($tenant->id, $referralId);

        if ($referral === null) {
            throw new DomainException('Referral not found.', 'referral_not_found', Response::HTTP_NOT_FOUND);
        }

        if (! $referral->isPending()) {
            throw new DomainException(
                'Only pending referrals can be qualified.',
                'invalid_referral_status',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $updated = $this->referrals->updateReferral($referral, [
            'status' => Referral::STATUS_QUALIFIED,
            'qualified_at' => now(),
        ]);

        $this->audit->write(
            action: 'referral.qualified',
            entityType: 'referral',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: ['status' => Referral::STATUS_QUALIFIED]
        );

        return $updated;
    }
}
