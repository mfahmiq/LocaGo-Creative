<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Marketing\Contracts\ReferralRepositoryInterface;
use App\Domains\Marketing\Models\Referral;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CreateReferralAction extends Action
{
    public function __construct(
        private readonly ReferralRepositoryInterface $referrals,
        private readonly MemberRepositoryInterface $members,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Referral
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        $referrerMemberId = (int) $data['referrer_member_id'];
        $refereeMemberId = (int) $data['referee_member_id'];

        if ($referrerMemberId === $refereeMemberId) {
            throw new DomainException(
                'Referrer and referee must be different members.',
                'referral_same_member',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        if ($this->members->findForTenant($tenant->id, $referrerMemberId) === null) {
            throw new DomainException('Referrer member not found.', 'referrer_not_found', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        if ($this->members->findForTenant($tenant->id, $refereeMemberId) === null) {
            throw new DomainException('Referee member not found.', 'referee_not_found', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        if ($this->referrals->findByRefereeMemberId($tenant->id, $refereeMemberId) !== null) {
            throw new DomainException(
                'Referee member has already been referred.',
                'referee_already_referred',
                Response::HTTP_CONFLICT
            );
        }

        $referral = $this->referrals->createReferral([
            'tenant_id' => $tenant->id,
            'referrer_member_id' => $referrerMemberId,
            'referee_member_id' => $refereeMemberId,
            'status' => Referral::STATUS_PENDING,
        ]);

        $this->audit->write(
            action: 'referral.created',
            entityType: 'referral',
            entityId: $referral->id,
            tenantId: $tenant->id,
            newValues: [
                'referrer_member_id' => $referrerMemberId,
                'referee_member_id' => $refereeMemberId,
                'status' => Referral::STATUS_PENDING,
            ]
        );

        return $referral;
    }
}
