<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Marketing\Contracts\OfferRepositoryInterface;
use App\Domains\Marketing\Models\Offer;
use App\Domains\Marketing\Support\MarketingValidator;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateOfferAction extends Action
{
    public function __construct(
        private readonly OfferRepositoryInterface $offers,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Offer
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        $offerId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        $offer = $this->offers->findForTenant($tenant->id, $offerId);

        if ($offer === null) {
            throw new DomainException('Offer not found.', 'offer_not_found', Response::HTTP_NOT_FOUND);
        }

        $payload = [];

        if (array_key_exists('code', $data)) {
            $code = strtoupper(trim((string) $data['code']));
            if ($this->offers->findByCode($tenant->id, $code, $offer->id) !== null) {
                throw new DomainException('Offer code already exists.', 'offer_code_exists', Response::HTTP_CONFLICT);
            }
            $payload['code'] = $code;
        }

        if (array_key_exists('name', $data)) {
            $payload['name'] = trim((string) $data['name']);
        }

        if (array_key_exists('discount_type', $data)) {
            MarketingValidator::assertDiscountType($data);
            $payload['discount_type'] = (string) $data['discount_type'];
        }

        if (array_key_exists('discount_value', $data)) {
            $payload['discount_value'] = number_format((float) $data['discount_value'], 2, '.', '');
        }

        if (array_key_exists('starts_at', $data)) {
            $payload['starts_at'] = (string) $data['starts_at'];
        }

        if (array_key_exists('ends_at', $data)) {
            $payload['ends_at'] = (string) $data['ends_at'];
        }

        if (array_key_exists('is_active', $data)) {
            $payload['is_active'] = (bool) $data['is_active'];
        }

        if (array_key_exists('stackable_with_coupon', $data)) {
            $payload['stackable_with_coupon'] = (bool) $data['stackable_with_coupon'];
        }

        $startsAt = $payload['starts_at'] ?? $offer->starts_at;
        $endsAt = $payload['ends_at'] ?? $offer->ends_at;
        MarketingValidator::assertDateWindow($startsAt, $endsAt);

        $updated = $this->offers->updateOffer($offer, $payload);

        $this->audit->write(
            action: 'offer.updated',
            entityType: 'offer',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: $payload
        );

        return $updated;
    }
}
