<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Models;

use App\Core\Models\Concerns\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;

class LoyaltySettings extends Model
{
    use BelongsToTenant;

    protected $table = 'loyalty_settings';

    protected $fillable = [
        'tenant_id',
        'is_enabled',
        'points_per_check_in',
        'points_per_100_currency',
        'points_per_referral',
        'redeem_value_per_100_points',
    ];

    protected function casts(): array
    {
        return [
            'is_enabled' => 'boolean',
            'points_per_check_in' => 'integer',
            'points_per_100_currency' => 'integer',
            'points_per_referral' => 'integer',
            'redeem_value_per_100_points' => 'integer',
        ];
    }
}
