<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Models;

use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Members\Models\Member;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class LoyaltyAccount extends Model
{
    use BelongsToTenant;

    protected $table = 'loyalty_accounts';

    protected $fillable = [
        'tenant_id',
        'member_id',
        'points_balance',
        'lifetime_earned',
        'lifetime_redeemed',
    ];

    protected function casts(): array
    {
        return [
            'points_balance' => 'integer',
            'lifetime_earned' => 'integer',
            'lifetime_redeemed' => 'integer',
        ];
    }

    public function member(): BelongsTo
    {
        return $this->belongsTo(Member::class);
    }

    public function ledger(): HasMany
    {
        return $this->hasMany(LoyaltyLedgerEntry::class, 'loyalty_account_id');
    }
}
