<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Models;

use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Members\Models\Member;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CouponRedemption extends Model
{
    use BelongsToTenant;

    public $timestamps = false;

    protected $table = 'coupon_redemptions';

    protected $fillable = [
        'tenant_id',
        'coupon_id',
        'member_id',
        'invoice_id',
        'redeemed_at',
        'created_at',
        'created_by',
    ];

    protected function casts(): array
    {
        return [
            'redeemed_at' => 'datetime',
            'created_at' => 'datetime',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function coupon(): BelongsTo
    {
        return $this->belongsTo(Coupon::class);
    }

    public function member(): BelongsTo
    {
        return $this->belongsTo(Member::class);
    }
}
