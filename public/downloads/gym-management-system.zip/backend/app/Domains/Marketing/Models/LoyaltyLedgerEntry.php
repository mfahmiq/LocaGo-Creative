<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Models;

use App\Core\Models\Concerns\BelongsToTenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LoyaltyLedgerEntry extends Model
{
    use BelongsToTenant;

    public $timestamps = false;

    protected $table = 'loyalty_ledger';

    protected $fillable = [
        'tenant_id',
        'loyalty_account_id',
        'member_id',
        'points',
        'reason',
        'source_type',
        'source_id',
        'notes',
        'created_at',
        'created_by',
    ];

    protected function casts(): array
    {
        return [
            'points' => 'integer',
            'created_at' => 'datetime',
        ];
    }

    public function account(): BelongsTo
    {
        return $this->belongsTo(LoyaltyAccount::class, 'loyalty_account_id');
    }
}
