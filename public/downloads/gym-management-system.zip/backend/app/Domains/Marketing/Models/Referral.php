<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Members\Models\Member;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Referral extends BaseModel
{
    use BelongsToTenant;

    public const STATUS_PENDING = 'pending';

    public const STATUS_QUALIFIED = 'qualified';

    public const STATUS_REWARDED = 'rewarded';

    public const STATUS_DISQUALIFIED = 'disqualified';

    protected $table = 'referrals';

    protected $fillable = [
        'tenant_id',
        'referrer_member_id',
        'referee_member_id',
        'status',
        'qualified_at',
        'rewarded_at',
        'reward_type',
        'reward_reference',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'qualified_at' => 'datetime',
            'rewarded_at' => 'datetime',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function referrer(): BelongsTo
    {
        return $this->belongsTo(Member::class, 'referrer_member_id');
    }

    public function referee(): BelongsTo
    {
        return $this->belongsTo(Member::class, 'referee_member_id');
    }

    public function isPending(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }

    public function isQualified(): bool
    {
        return $this->status === self::STATUS_QUALIFIED;
    }
}
