# Marketing Domain

## Admin Portal — Offers / Coupons / Referrals (complete)

Requires `auth:sanctum` + staff + `X-Tenant-Slug` + marketing permissions.

Routes live in `routes/api/v1/admin/marketing.php` (included from `api.php`).

## Admin Portal — Offers, Coupons, Referrals

Requires `auth:sanctum` + staff + `X-Tenant-Slug` + permissions (`marketing.*.view` / `marketing.*.manage`).

Wire routes (if not using `MarketingServiceProvider`): `require __DIR__.'/admin/marketing.php';` inside the admin middleware group in `routes/api/v1/api.php`.

### Offers

| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/offers` | view / manage |
| GET/PUT/DELETE | `/api/v1/admin/offers/{id}` | view / manage |

Codes are stored uppercase and unique per tenant. `discount_type`: `percent` \| `fixed`. `ends_at` must be after `starts_at`.

List filters: `is_active`, `search`, `per_page`

Audited: `offer.*`

### Coupons

| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/coupons` | view / manage |
| GET/PUT/DELETE | `/api/v1/admin/coupons/{id}` | view / manage |
| POST | `/api/v1/admin/coupons/{id}/redeem` | manage |

Redeem body (optional): `member_id`, `invoice_id`

Redeem validates active window, `max_redemptions`, and `per_member_limit`. Increments `redeemed_count` and creates a `coupon_redemptions` row.

Domain error codes: `coupon_inactive`, `coupon_expired`, `coupon_exhausted`, `coupon_member_limit`

List filters: `is_active`, `search`, `per_page`

Audited: `coupon.*`

### Referrals

| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/referrals` | view / manage |
| GET | `/api/v1/admin/referrals/{id}` | view |
| POST | `/api/v1/admin/referrals/{id}/qualify` | manage |
| POST | `/api/v1/admin/referrals/{id}/reward` | manage |
| POST | `/api/v1/admin/referrals/{id}/disqualify` | manage |

Create requires distinct referrer/referee members; referee must not already have a referral record.

Statuses: `pending` → `qualified` → `rewarded` \| `disqualified`

Reward body (optional): `reward_type`, `reward_reference`

List filters: `status`, `referrer_member_id`, `per_page`

Audited: `referral.*`
