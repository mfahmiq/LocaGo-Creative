<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Contracts;

use App\Domains\Marketing\Models\Referral;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface ReferralRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $referralId): ?Referral;

    public function findByRefereeMemberId(int $tenantId, int $refereeMemberId): ?Referral;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createReferral(array $attributes): Referral;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateReferral(Referral $referral, array $attributes): Referral;
}
