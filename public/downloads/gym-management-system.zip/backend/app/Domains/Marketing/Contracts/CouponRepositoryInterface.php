<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Contracts;

use App\Domains\Marketing\Models\Coupon;
use App\Domains\Marketing\Models\CouponRedemption;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface CouponRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $couponId): ?Coupon;

    public function findByCode(int $tenantId, string $code, ?int $exceptCouponId = null): ?Coupon;

    public function countRedemptionsForMember(int $tenantId, int $couponId, int $memberId): int;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createCoupon(array $attributes): Coupon;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateCoupon(Coupon $coupon, array $attributes): Coupon;

    public function deleteCoupon(Coupon $coupon): bool;

    public function incrementRedeemedCount(Coupon $coupon): Coupon;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createRedemption(array $attributes): CouponRedemption;
}
