<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Contracts;

use App\Domains\Marketing\Models\Offer;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface OfferRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $offerId): ?Offer;

    public function findByCode(int $tenantId, string $code, ?int $exceptOfferId = null): ?Offer;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createOffer(array $attributes): Offer;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateOffer(Offer $offer, array $attributes): Offer;

    public function deleteOffer(Offer $offer): bool;
}
