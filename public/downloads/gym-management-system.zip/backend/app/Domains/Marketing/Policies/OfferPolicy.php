<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Marketing\Models\Offer;

final class OfferPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'marketing.offers.view');
    }

    public function view(User $user, Offer $offer): bool
    {
        return $this->hasPermission($user, 'marketing.offers.view')
            && $this->sameTenant($user, $offer);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'marketing.offers.manage');
    }

    public function update(User $user, Offer $offer): bool
    {
        return $this->hasPermission($user, 'marketing.offers.manage')
            && $this->sameTenant($user, $offer);
    }

    public function delete(User $user, Offer $offer): bool
    {
        return $this->update($user, $offer);
    }
}
