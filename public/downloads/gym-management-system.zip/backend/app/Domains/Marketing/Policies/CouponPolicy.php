<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Marketing\Models\Coupon;

final class CouponPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'marketing.coupons.view');
    }

    public function view(User $user, Coupon $coupon): bool
    {
        return $this->hasPermission($user, 'marketing.coupons.view')
            && $this->sameTenant($user, $coupon);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'marketing.coupons.manage');
    }

    public function update(User $user, Coupon $coupon): bool
    {
        return $this->hasPermission($user, 'marketing.coupons.manage')
            && $this->sameTenant($user, $coupon);
    }

    public function delete(User $user, Coupon $coupon): bool
    {
        return $this->update($user, $coupon);
    }

    public function redeem(User $user, Coupon $coupon): bool
    {
        return $this->update($user, $coupon);
    }
}
