<?php

declare(strict_types=1);

namespace App\Domains\Marketing\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Marketing\Models\Referral;

final class ReferralPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'marketing.referrals.view');
    }

    public function view(User $user, Referral $referral): bool
    {
        return $this->hasPermission($user, 'marketing.referrals.view')
            && $this->sameTenant($user, $referral);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'marketing.referrals.manage');
    }

    public function qualify(User $user, Referral $referral): bool
    {
        return $this->hasPermission($user, 'marketing.referrals.manage')
            && $this->sameTenant($user, $referral);
    }

    public function reward(User $user, Referral $referral): bool
    {
        return $this->qualify($user, $referral);
    }

    public function disqualify(User $user, Referral $referral): bool
    {
        return $this->qualify($user, $referral);
    }
}
