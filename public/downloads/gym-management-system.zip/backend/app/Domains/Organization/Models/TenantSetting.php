<?php

declare(strict_types=1);

namespace App\Domains\Organization\Models;

use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TenantSetting extends Model
{
    protected $dateFormat = 'Y-m-d H:i:s.v';

    protected $table = 'tenant_settings';

    protected $fillable = [
        'tenant_id',
        'settings_json',
        'updated_by',
    ];

    protected function casts(): array
    {
        return [
            'settings_json' => 'array',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }
}
