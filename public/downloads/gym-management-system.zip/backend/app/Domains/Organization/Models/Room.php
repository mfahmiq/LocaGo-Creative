<?php

declare(strict_types=1);

namespace App\Domains\Organization\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Room extends BaseModel
{
    use BelongsToTenant;

    protected $table = 'rooms';

    protected $fillable = [
        'tenant_id',
        'branch_id',
        'name',
        'capacity',
        'is_active',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'capacity' => 'integer',
            'is_active' => 'boolean',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }
}
