<?php

declare(strict_types=1);

namespace App\Domains\Organization\Services;

use App\Core\Services\BaseService;
use App\Domains\Organization\Actions\UpdateOrganizationAction;
use App\Domains\Organization\Models\TenantSetting;
use App\Domains\Platform\Services\SaasPlanService;
use App\Domains\Tenancy\Models\Tenant;

final class OrganizationService extends BaseService
{
    public function __construct(
        private readonly UpdateOrganizationAction $updateOrganizationAction,
        private readonly SaasPlanService $plans
    ) {}

    /**
     * @return array{
     *   tenant: Tenant,
     *   settings: array<string, mixed>,
     *   entitlements: array<string, mixed>
     * }
     */
    public function show(Tenant $tenant): array
    {
        $tenant->loadMissing('saasPlan');
        $setting = TenantSetting::query()->where('tenant_id', $tenant->id)->first();
        $settings = is_array($setting?->settings_json) ? $setting->settings_json : [];

        return [
            'tenant' => $tenant,
            'settings' => $this->normalizeSettings($settings),
            'entitlements' => $this->plans->entitlementsForTenant($tenant),
        ];
    }

    /**
     * @param  array<string, mixed>  $data
     * @return array{
     *   tenant: Tenant,
     *   settings: array<string, mixed>,
     *   entitlements: array<string, mixed>
     * }
     */
    public function update(Tenant $tenant, array $data): array
    {
        $result = $this->updateOrganizationAction->execute($tenant, $data);

        return [
            'tenant' => $result['tenant'],
            'settings' => $this->normalizeSettings($result['settings']),
            'entitlements' => $this->plans->entitlementsForTenant($result['tenant']),
        ];
    }

    /**
     * @param  array<string, mixed>  $settings
     * @return array<string, mixed>
     */
    private function normalizeSettings(array $settings): array
    {
        $branding = is_array($settings['branding'] ?? null) ? $settings['branding'] : [];

        return [
            'website' => $settings['website'] ?? null,
            'tagline' => $settings['tagline'] ?? null,
            'branding' => [
                'primary_color' => $branding['primary_color'] ?? null,
                'accent_color' => $branding['accent_color'] ?? null,
                'support_email' => $branding['support_email'] ?? null,
            ],
        ];
    }
}
