<?php

declare(strict_types=1);

namespace App\Domains\Organization\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Identity\Models\User;
use App\Domains\Organization\Actions\ChangeBranchStatusAction;
use App\Domains\Organization\Actions\CreateBranchAction;
use App\Domains\Organization\Actions\DeleteBranchAction;
use App\Domains\Organization\Actions\SyncBranchStaffAction;
use App\Domains\Organization\Actions\UpdateBranchAction;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Organization\Models\Branch;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Symfony\Component\HttpFoundation\Response;

final class BranchService extends BaseService
{
    public function __construct(
        private readonly BranchRepositoryInterface $branches,
        private readonly CreateBranchAction $createBranchAction,
        private readonly UpdateBranchAction $updateBranchAction,
        private readonly DeleteBranchAction $deleteBranchAction,
        private readonly ChangeBranchStatusAction $changeBranchStatusAction,
        private readonly SyncBranchStaffAction $syncBranchStaffAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->branches->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $branchId): Branch
    {
        $branch = $this->branches->findForTenant($tenant->id, $branchId);

        if ($branch === null) {
            throw new DomainException('Branch not found.', 'branch_not_found', Response::HTTP_NOT_FOUND);
        }

        return $branch->loadCount('users');
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): Branch
    {
        return $this->createBranchAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $branchId, array $data): Branch
    {
        return $this->updateBranchAction->execute($tenant, $branchId, $data);
    }

    public function delete(Tenant $tenant, int $branchId): bool
    {
        return $this->deleteBranchAction->execute($tenant, $branchId);
    }

    public function changeStatus(Tenant $tenant, int $branchId, bool $isActive): Branch
    {
        return $this->changeBranchStatusAction->execute($tenant, $branchId, $isActive);
    }

    /**
     * @return Collection<int, User>
     */
    public function staff(Tenant $tenant, int $branchId): Collection
    {
        $this->find($tenant, $branchId);

        return $this->branches->staffForBranch($tenant->id, $branchId);
    }

    /**
     * @param  list<int>  $userIds
     * @return array{branch: Branch, staff: Collection<int, User>}
     */
    public function syncStaff(Tenant $tenant, int $branchId, array $userIds): array
    {
        return $this->syncBranchStaffAction->execute($tenant, $branchId, $userIds);
    }

    /**
     * @return array{total: int, active: int, inactive: int}
     */
    public function summary(Tenant $tenant): array
    {
        $total = $this->branches->countForTenant($tenant->id);
        $active = $this->branches->countForTenant($tenant->id, true);

        return [
            'total' => $total,
            'active' => $active,
            'inactive' => max(0, $total - $active),
        ];
    }
}
