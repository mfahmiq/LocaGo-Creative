<?php

declare(strict_types=1);

namespace App\Domains\Organization\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Organization\Models\Branch;

final class BranchPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'organization.branches.view');
    }

    public function view(User $user, Branch $branch): bool
    {
        return $this->hasPermission($user, 'organization.branches.view')
            && $this->sameTenant($user, $branch)
            && $this->branchAllowed($user, (int) $branch->id);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'organization.branches.manage');
    }

    public function update(User $user, Branch $branch): bool
    {
        return $this->hasPermission($user, 'organization.branches.manage')
            && $this->sameTenant($user, $branch)
            && $this->branchAllowed($user, (int) $branch->id);
    }

    public function delete(User $user, Branch $branch): bool
    {
        return $this->update($user, $branch);
    }

    public function syncStaff(User $user, Branch $branch): bool
    {
        return $this->update($user, $branch);
    }
}
