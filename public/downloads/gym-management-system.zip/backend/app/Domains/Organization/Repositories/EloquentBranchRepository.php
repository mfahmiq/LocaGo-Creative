<?php

declare(strict_types=1);

namespace App\Domains\Organization\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Identity\Models\User;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Organization\Models\Branch;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

/**
 * @extends BaseRepository<Branch>
 */
class EloquentBranchRepository extends BaseRepository implements BranchRepositoryInterface
{
    public function __construct(Branch $model)
    {
        parent::__construct($model);
    }

    public function findActiveForTenant(int $tenantId, int $branchId): ?Branch
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('id', $branchId)
            ->where('is_active', true)
            ->whereNull('deleted_at')
            ->first();
    }

    public function firstActiveForTenant(int $tenantId): ?Branch
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('is_active', true)
            ->whereNull('deleted_at')
            ->orderBy('id')
            ->first();
    }

    public function listActiveForTenant(int $tenantId): Collection
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('is_active', true)
            ->whereNull('deleted_at')
            ->orderBy('name')
            ->orderBy('id')
            ->get(['id', 'code', 'name']);
    }

    public function findForTenant(int $tenantId, int $branchId): ?Branch
    {
        return $this->query()
            ->where('tenant_id', $tenantId)
            ->where('id', $branchId)
            ->first();
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->where('tenant_id', $tenantId)
            ->withCount('users')
            ->orderBy('name')
            ->orderBy('id');

        if (array_key_exists('is_active', $filters) && $filters['is_active'] !== null && $filters['is_active'] !== '') {
            $active = filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
            if ($active !== null) {
                $query->where('is_active', $active);
            }
        }

        if (! empty($filters['search'])) {
            $term = '%'.addcslashes(trim((string) $filters['search']), '%_\\').'%';
            $query->where(function ($inner) use ($term): void {
                $inner->where('name', 'like', $term)
                    ->orWhere('code', 'like', $term)
                    ->orWhere('city', 'like', $term)
                    ->orWhere('email', 'like', $term)
                    ->orWhere('phone', 'like', $term);
            });
        }

        return $query->paginate($perPage);
    }

    public function createBranch(array $attributes): Branch
    {
        /** @var Branch $branch */
        $branch = $this->query()->create($attributes);

        return $branch->loadCount('users');
    }

    public function updateBranch(Branch $branch, array $attributes): Branch
    {
        $branch->fill($attributes);
        $branch->save();

        return $branch->fresh()->loadCount('users');
    }

    public function deleteBranch(Branch $branch): bool
    {
        return (bool) $branch->delete();
    }

    public function countForTenant(int $tenantId, ?bool $activeOnly = null): int
    {
        $query = $this->query()->where('tenant_id', $tenantId);

        if ($activeOnly === true) {
            $query->where('is_active', true);
        }

        return $query->count();
    }

    public function staffForBranch(int $tenantId, int $branchId): Collection
    {
        return User::query()
            ->where('tenant_id', $tenantId)
            ->where('user_type', User::TYPE_STAFF)
            ->whereHas('branches', function ($query) use ($branchId): void {
                $query->where('branches.id', $branchId);
            })
            ->orderBy('name')
            ->get(['id', 'name', 'email', 'is_active']);
    }
}
