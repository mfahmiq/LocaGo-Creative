<?php

declare(strict_types=1);

namespace App\Domains\Organization\Contracts;

use App\Domains\Organization\Models\Branch;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

interface BranchRepositoryInterface
{
    public function findActiveForTenant(int $tenantId, int $branchId): ?Branch;

    public function firstActiveForTenant(int $tenantId): ?Branch;

    /**
     * @return Collection<int, Branch>
     */
    public function listActiveForTenant(int $tenantId): Collection;

    public function findForTenant(int $tenantId, int $branchId): ?Branch;

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createBranch(array $attributes): Branch;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateBranch(Branch $branch, array $attributes): Branch;

    public function deleteBranch(Branch $branch): bool;

    public function countForTenant(int $tenantId, ?bool $activeOnly = null): int;

    /**
     * @return Collection<int, \App\Domains\Identity\Models\User>
     */
    public function staffForBranch(int $tenantId, int $branchId): Collection;
}
