<?php

declare(strict_types=1);

namespace App\Domains\Organization\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Organization\Models\Branch;
use App\Domains\Platform\Services\EntitlementGuard;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CreateBranchAction extends Action
{
    public function __construct(
        private readonly BranchRepositoryInterface $branches,
        private readonly EntitlementGuard $entitlements,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Branch
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        $this->entitlements->assertCanAddBranch($tenant);

        $code = strtoupper(trim((string) $data['code']));
        $exists = Branch::query()
            ->where('tenant_id', $tenant->id)
            ->where('code', $code)
            ->exists();

        if ($exists) {
            throw new DomainException(
                'A branch with this code already exists.',
                'branch_code_taken',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $branch = $this->branches->createBranch([
            'tenant_id' => $tenant->id,
            'code' => $code,
            'name' => trim((string) $data['name']),
            'phone' => $data['phone'] ?? null,
            'email' => $data['email'] ?? null,
            'address_line1' => $data['address_line1'] ?? null,
            'address_line2' => $data['address_line2'] ?? null,
            'city' => $data['city'] ?? null,
            'state' => $data['state'] ?? null,
            'postal_code' => $data['postal_code'] ?? null,
            'country_code' => strtoupper((string) ($data['country_code'] ?? $tenant->primary_country ?: 'IN')),
            'timezone' => $data['timezone'] ?? $tenant->timezone,
            'capacity' => isset($data['capacity']) ? (int) $data['capacity'] : null,
            'is_active' => array_key_exists('is_active', $data) ? (bool) $data['is_active'] : true,
        ]);

        $this->audit->write(
            action: 'branch.created',
            entityType: 'branch',
            entityId: $branch->id,
            tenantId: $tenant->id,
            newValues: [
                'code' => $branch->code,
                'name' => $branch->name,
                'is_active' => $branch->is_active,
            ]
        );

        return $branch;
    }
}
