<?php

declare(strict_types=1);

namespace App\Domains\Organization\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Organization\Models\Branch;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class ChangeBranchStatusAction extends Action
{
    public function __construct(
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Branch
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $branchId */
        $branchId = (int) $args[1];
        /** @var bool $isActive */
        $isActive = (bool) $args[2];

        $branch = $this->branches->findForTenant($tenant->id, $branchId);

        if ($branch === null) {
            throw new DomainException('Branch not found.', 'branch_not_found', Response::HTTP_NOT_FOUND);
        }

        if (! $isActive && $branch->is_active) {
            $activeCount = $this->branches->countForTenant($tenant->id, true);
            if ($activeCount <= 1) {
                throw new DomainException(
                    'Cannot deactivate the only active branch.',
                    'last_active_branch',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }
        }

        $old = $branch->is_active;
        $updated = $this->branches->updateBranch($branch, ['is_active' => $isActive]);

        $this->audit->write(
            action: 'branch.status_changed',
            entityType: 'branch',
            entityId: $updated->id,
            tenantId: $tenant->id,
            oldValues: ['is_active' => $old],
            newValues: ['is_active' => $updated->is_active]
        );

        return $updated;
    }
}
