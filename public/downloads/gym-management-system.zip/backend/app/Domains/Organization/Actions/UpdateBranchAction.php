<?php

declare(strict_types=1);

namespace App\Domains\Organization\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Organization\Models\Branch;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateBranchAction extends Action
{
    public function __construct(
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Branch
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $branchId */
        $branchId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        $branch = $this->branches->findForTenant($tenant->id, $branchId);

        if ($branch === null) {
            throw new DomainException('Branch not found.', 'branch_not_found', Response::HTTP_NOT_FOUND);
        }

        if (isset($data['code'])) {
            $code = strtoupper(trim((string) $data['code']));
            $taken = Branch::query()
                ->where('tenant_id', $tenant->id)
                ->where('code', $code)
                ->where('id', '!=', $branch->id)
                ->exists();

            if ($taken) {
                throw new DomainException(
                    'A branch with this code already exists.',
                    'branch_code_taken',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }
            $data['code'] = $code;
        }

        if (isset($data['name'])) {
            $data['name'] = trim((string) $data['name']);
        }

        if (isset($data['country_code'])) {
            $data['country_code'] = strtoupper((string) $data['country_code']);
        }

        $old = [
            'code' => $branch->code,
            'name' => $branch->name,
            'is_active' => $branch->is_active,
        ];

        $updated = $this->branches->updateBranch($branch, $data);

        $this->audit->write(
            action: 'branch.updated',
            entityType: 'branch',
            entityId: $updated->id,
            tenantId: $tenant->id,
            oldValues: $old,
            newValues: [
                'code' => $updated->code,
                'name' => $updated->name,
                'is_active' => $updated->is_active,
            ]
        );

        return $updated;
    }
}
