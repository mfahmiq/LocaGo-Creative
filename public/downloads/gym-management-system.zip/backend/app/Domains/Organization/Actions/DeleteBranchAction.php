<?php

declare(strict_types=1);

namespace App\Domains\Organization\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Organization\Models\BranchUser;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeleteBranchAction extends Action
{
    public function __construct(
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $branchId */
        $branchId = (int) $args[1];

        $branch = $this->branches->findForTenant($tenant->id, $branchId);

        if ($branch === null) {
            throw new DomainException('Branch not found.', 'branch_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($this->branches->countForTenant($tenant->id) <= 1) {
            throw new DomainException(
                'Cannot delete the only branch for this gym.',
                'last_branch',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        BranchUser::query()
            ->where('tenant_id', $tenant->id)
            ->where('branch_id', $branch->id)
            ->delete();

        $deleted = $this->branches->deleteBranch($branch);

        $this->audit->write(
            action: 'branch.deleted',
            entityType: 'branch',
            entityId: $branchId,
            tenantId: $tenant->id,
            oldValues: [
                'code' => $branch->code,
                'name' => $branch->name,
            ]
        );

        return $deleted;
    }
}
