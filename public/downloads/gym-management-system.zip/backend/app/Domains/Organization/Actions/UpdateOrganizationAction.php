<?php

declare(strict_types=1);

namespace App\Domains\Organization\Actions;

use App\Core\Actions\Action;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Organization\Models\TenantSetting;
use App\Domains\Tenancy\Models\Tenant;
use App\Domains\Tenancy\Services\TenantResolver;
use Illuminate\Support\Facades\Auth;

final class UpdateOrganizationAction extends Action
{
    public function __construct(
        private readonly AuditWriter $audit,
        private readonly TenantResolver $tenants
    ) {}

    /**
     * @param  array<string, mixed>  $data
     * @return array{tenant: Tenant, settings: array<string, mixed>}
     */
    public function execute(mixed ...$args): array
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        $profileKeys = [
            'name',
            'legal_name',
            'email',
            'phone',
            'logo_path',
            'primary_country',
            'base_currency',
            'timezone',
        ];

        $oldProfile = $tenant->only($profileKeys);
        $updates = [];

        foreach ($profileKeys as $key) {
            if (! array_key_exists($key, $data)) {
                continue;
            }

            $value = $data[$key];
            if (is_string($value)) {
                $value = trim($value);
                if ($value === '') {
                    $value = in_array($key, ['legal_name', 'email', 'phone', 'logo_path'], true)
                        ? null
                        : $value;
                }
            }

            if ($key === 'primary_country' && is_string($value)) {
                $value = strtoupper($value);
            }
            if ($key === 'base_currency' && is_string($value)) {
                $value = strtoupper($value);
            }
            if ($key === 'name' && is_string($value)) {
                $value = $value === '' ? $tenant->name : $value;
            }

            $updates[$key] = $value;
        }

        if ($updates !== []) {
            $tenant->fill($updates);
            $tenant->save();
        }

        $settingsPayload = is_array($data['settings'] ?? null) ? $data['settings'] : [];
        $setting = TenantSetting::query()->firstOrNew(['tenant_id' => $tenant->id]);
        $current = is_array($setting->settings_json) ? $setting->settings_json : [];

        $merged = $current;
        if (array_key_exists('website', $settingsPayload)) {
            $website = trim((string) ($settingsPayload['website'] ?? ''));
            $merged['website'] = $website === '' ? null : $website;
        }
        if (array_key_exists('tagline', $settingsPayload)) {
            $tagline = trim((string) ($settingsPayload['tagline'] ?? ''));
            $merged['tagline'] = $tagline === '' ? null : $tagline;
        }
        if (isset($settingsPayload['branding']) && is_array($settingsPayload['branding'])) {
            $branding = is_array($merged['branding'] ?? null) ? $merged['branding'] : [];
            foreach (['primary_color', 'accent_color', 'support_email'] as $brandKey) {
                if (! array_key_exists($brandKey, $settingsPayload['branding'])) {
                    continue;
                }
                $raw = $settingsPayload['branding'][$brandKey];
                $text = is_string($raw) ? trim($raw) : '';
                $branding[$brandKey] = $text === '' ? null : $text;
            }
            $merged['branding'] = $branding;
        }

        $setting->settings_json = $merged;
        $setting->updated_by = Auth::id();
        $setting->save();

        $this->tenants->bind($tenant->fresh());

        $this->audit->write(
            action: 'organization.updated',
            entityType: 'tenant',
            entityId: $tenant->id,
            tenantId: $tenant->id,
            oldValues: [
                'profile' => $oldProfile,
                'settings' => $current,
            ],
            newValues: [
                'profile' => $tenant->fresh()->only($profileKeys),
                'settings' => $merged,
            ]
        );

        return [
            'tenant' => $tenant->fresh()->load('saasPlan'),
            'settings' => $merged,
        ];
    }
}
