<?php

declare(strict_types=1);

namespace App\Domains\Organization\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Models\User;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Organization\Models\Branch;
use App\Domains\Organization\Models\BranchUser;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

final class SyncBranchStaffAction extends Action
{
    public function __construct(
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    /**
     * @param  list<int>  $userIds
     * @return array{branch: Branch, staff: Collection<int, User>}
     */
    public function execute(mixed ...$args): array
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $branchId */
        $branchId = (int) $args[1];
        /** @var list<int> $userIds */
        $userIds = $args[2];

        $branch = $this->branches->findForTenant($tenant->id, $branchId);

        if ($branch === null) {
            throw new DomainException('Branch not found.', 'branch_not_found', Response::HTTP_NOT_FOUND);
        }

        if (! $branch->is_active) {
            throw new DomainException(
                'Cannot assign staff to an inactive branch.',
                'branch_inactive',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $uniqueIds = array_values(array_unique(array_map('intval', $userIds)));

        $validUsers = User::query()
            ->where('tenant_id', $tenant->id)
            ->where('user_type', User::TYPE_STAFF)
            ->whereIn('id', $uniqueIds)
            ->pluck('id')
            ->all();

        if (count($validUsers) !== count($uniqueIds)) {
            throw new DomainException(
                'One or more staff users are invalid.',
                'invalid_staff_ids',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $oldIds = BranchUser::query()
            ->where('tenant_id', $tenant->id)
            ->where('branch_id', $branch->id)
            ->pluck('user_id')
            ->map(fn ($id) => (int) $id)
            ->all();

        BranchUser::query()
            ->where('tenant_id', $tenant->id)
            ->where('branch_id', $branch->id)
            ->delete();

        $actorId = Auth::id();
        $now = now();
        foreach ($validUsers as $userId) {
            BranchUser::query()->create([
                'tenant_id' => $tenant->id,
                'user_id' => $userId,
                'branch_id' => $branch->id,
                'created_at' => $now,
                'created_by' => $actorId,
            ]);
        }

        $this->audit->write(
            action: 'branch.staff_synced',
            entityType: 'branch',
            entityId: $branch->id,
            tenantId: $tenant->id,
            oldValues: ['user_ids' => $oldIds],
            newValues: ['user_ids' => $validUsers]
        );

        return [
            'branch' => $branch->fresh()->loadCount('users'),
            'staff' => $this->branches->staffForBranch($tenant->id, $branch->id),
        ];
    }
}
