﻿# Organization Domain

Business module placeholder. Implement Actions, Services, Repositories, Models, Policies, Events here.
Do not put HTTP controllers in this folder — keep them under `app/Http/Controllers/Api/V1`.
