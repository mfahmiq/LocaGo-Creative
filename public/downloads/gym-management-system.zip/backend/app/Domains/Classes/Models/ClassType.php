<?php

declare(strict_types=1);

namespace App\Domains\Classes\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ClassType extends BaseModel
{
    use BelongsToTenant;

    protected $table = 'class_types';

    protected $fillable = [
        'tenant_id',
        'code',
        'name',
        'category',
        'default_duration_minutes',
        'default_capacity',
        'waitlist_enabled',
        'is_active',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'default_duration_minutes' => 'integer',
            'default_capacity' => 'integer',
            'waitlist_enabled' => 'boolean',
            'is_active' => 'boolean',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function schedules(): HasMany
    {
        return $this->hasMany(ClassSchedule::class, 'class_type_id');
    }
}
