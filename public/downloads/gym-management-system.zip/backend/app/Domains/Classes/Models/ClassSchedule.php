<?php

declare(strict_types=1);

namespace App\Domains\Classes\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Identity\Models\User;
use App\Domains\Organization\Models\Branch;
use App\Domains\Organization\Models\Room;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ClassSchedule extends BaseModel
{
    use BelongsToTenant;

    public const STATUS_SCHEDULED = 'scheduled';

    public const STATUS_CANCELLED = 'cancelled';

    public const STATUS_COMPLETED = 'completed';

    public const WAITLIST_AUTO = 'auto';

    public const WAITLIST_MANUAL = 'manual';

    public const WAITLIST_BOTH = 'both';

    protected $table = 'class_schedules';

    protected $fillable = [
        'tenant_id',
        'branch_id',
        'class_type_id',
        'instructor_user_id',
        'room_id',
        'starts_at',
        'ends_at',
        'capacity',
        'booked_count',
        'waitlist_count',
        'waitlist_mode',
        'status',
        'recurrence_group_id',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'starts_at' => 'datetime',
            'ends_at' => 'datetime',
            'capacity' => 'integer',
            'booked_count' => 'integer',
            'waitlist_count' => 'integer',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function classType(): BelongsTo
    {
        return $this->belongsTo(ClassType::class, 'class_type_id');
    }

    public function instructor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'instructor_user_id');
    }

    public function room(): BelongsTo
    {
        return $this->belongsTo(Room::class);
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(ClassBooking::class, 'class_schedule_id');
    }

    public function waitlistEntries(): HasMany
    {
        return $this->hasMany(ClassWaitlistEntry::class, 'class_schedule_id');
    }

    public function hasOpenSeats(): bool
    {
        return $this->booked_count < $this->capacity;
    }
}
