<?php

declare(strict_types=1);

namespace App\Domains\Classes\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Members\Models\Member;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ClassWaitlistEntry extends BaseModel
{
    use BelongsToTenant;

    public const STATUS_WAITING = 'waiting';

    public const STATUS_OFFERED = 'offered';

    public const STATUS_PROMOTED = 'promoted';

    public const STATUS_EXPIRED = 'expired';

    public const STATUS_CANCELLED = 'cancelled';

    protected $table = 'class_waitlist_entries';

    protected $fillable = [
        'tenant_id',
        'class_schedule_id',
        'member_id',
        'position',
        'status',
        'offered_at',
        'offer_expires_at',
        'promoted_booking_id',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'position' => 'integer',
            'offered_at' => 'datetime',
            'offer_expires_at' => 'datetime',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function schedule(): BelongsTo
    {
        return $this->belongsTo(ClassSchedule::class, 'class_schedule_id');
    }

    public function member(): BelongsTo
    {
        return $this->belongsTo(Member::class);
    }

    public function promotedBooking(): BelongsTo
    {
        return $this->belongsTo(ClassBooking::class, 'promoted_booking_id');
    }
}
