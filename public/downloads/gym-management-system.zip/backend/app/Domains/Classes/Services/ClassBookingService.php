<?php

declare(strict_types=1);

namespace App\Domains\Classes\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Classes\Actions\BookMemberIntoClassAction;
use App\Domains\Classes\Actions\CancelClassBookingAction;
use App\Domains\Classes\Actions\MarkClassAttendanceAction;
use App\Domains\Classes\Actions\PromoteWaitlistEntryAction;
use App\Domains\Classes\Contracts\ClassBookingRepositoryInterface;
use App\Domains\Classes\Models\ClassAttendance;
use App\Domains\Classes\Models\ClassBooking;
use App\Domains\Classes\Models\ClassWaitlistEntry;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Collection;
use Symfony\Component\HttpFoundation\Response;

final class ClassBookingService extends BaseService
{
    public function __construct(
        private readonly ClassBookingRepositoryInterface $bookings,
        private readonly BookMemberIntoClassAction $bookMemberIntoClassAction,
        private readonly CancelClassBookingAction $cancelClassBookingAction,
        private readonly PromoteWaitlistEntryAction $promoteWaitlistEntryAction,
        private readonly MarkClassAttendanceAction $markClassAttendanceAction
    ) {}

    /**
     * @param  array<string, mixed>  $data
     * @return array{type: string, booking?: ClassBooking, waitlist?: ClassWaitlistEntry}
     */
    public function book(Tenant $tenant, array $data): array
    {
        return $this->bookMemberIntoClassAction->execute($tenant, $data);
    }

    public function findBooking(Tenant $tenant, int $bookingId): ClassBooking
    {
        $booking = $this->bookings->findBookingForTenant($tenant->id, $bookingId);

        if ($booking === null) {
            throw new DomainException('Booking not found.', 'class_booking_not_found', Response::HTTP_NOT_FOUND);
        }

        return $booking;
    }

    /**
     * @return Collection<int, ClassBooking>
     */
    public function roster(Tenant $tenant, int $scheduleId): Collection
    {
        return $this->bookings->listBookingsForSchedule($tenant->id, $scheduleId);
    }

    /**
     * @return Collection<int, ClassWaitlistEntry>
     */
    public function waitlist(Tenant $tenant, int $scheduleId): Collection
    {
        return $this->bookings->listWaitlistForSchedule($tenant->id, $scheduleId);
    }

    public function cancelBooking(Tenant $tenant, int $bookingId, ?string $reason = null): ClassBooking
    {
        return $this->cancelClassBookingAction->execute($tenant, $bookingId, $reason);
    }

    public function promote(Tenant $tenant, int $waitlistId): ClassBooking
    {
        return $this->promoteWaitlistEntryAction->execute($tenant, $waitlistId);
    }

    public function markAttendance(Tenant $tenant, int $bookingId, string $status): ClassAttendance
    {
        return $this->markClassAttendanceAction->execute($tenant, $bookingId, $status);
    }
}
