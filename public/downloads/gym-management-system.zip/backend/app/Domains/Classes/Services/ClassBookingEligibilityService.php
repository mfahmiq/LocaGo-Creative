<?php

declare(strict_types=1);

namespace App\Domains\Classes\Services;

use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Tenancy\Models\Tenant;
use Carbon\Carbon;

final class ClassBookingEligibilityService
{
    public function __construct(
        private readonly MemberRepositoryInterface $members
    ) {}

    /**
     * @return array{
     *     allowed: bool,
     *     code: ?string,
     *     message: string,
     *     member: ?\App\Domains\Members\Models\Member,
     *     membership: ?Membership
     * }
     */
    public function evaluate(Tenant $tenant, int $memberId, int $branchId): array
    {
        $member = $this->members->findForTenant($tenant->id, $memberId);

        if ($member === null) {
            return $this->deny('member_not_found', 'Member not found.');
        }

        if ($member->status === 'blacklisted') {
            return $this->deny('member_blacklisted', 'Member is blacklisted.', $member);
        }

        if ($member->status !== 'active') {
            return $this->deny('member_inactive', 'Only active members can book classes.', $member);
        }

        $allowGrace = (bool) config('gms.attendance.allow_grace_status', true);
        $statuses = [Membership::STATUS_ACTIVE];
        if ($allowGrace) {
            $statuses[] = Membership::STATUS_GRACE;
        }

        $candidates = Membership::query()
            ->withoutGlobalScopes()
            ->with(['plan.branches'])
            ->where('tenant_id', $tenant->id)
            ->where('member_id', $memberId)
            ->whereNull('deleted_at')
            ->whereIn('status', array_merge($statuses, [
                Membership::STATUS_FROZEN,
                Membership::STATUS_EXPIRED,
                Membership::STATUS_PENDING,
                Membership::STATUS_CANCELLED,
            ]))
            ->orderByDesc('id')
            ->get();

        if ($candidates->isEmpty()) {
            return $this->deny('no_membership', 'Member has no membership.', $member);
        }

        $today = Carbon::today();
        $blocking = null;

        foreach ($candidates as $membership) {
            if ($membership->status === Membership::STATUS_FROZEN) {
                $blocking ??= $this->deny('membership_frozen', 'Membership is frozen.', $member, $membership);
                continue;
            }

            if (in_array($membership->status, [Membership::STATUS_EXPIRED, Membership::STATUS_CANCELLED, Membership::STATUS_PENDING], true)) {
                $blocking ??= $this->deny(
                    'membership_'.$membership->status,
                    'Membership is not eligible for booking.',
                    $member,
                    $membership
                );
                continue;
            }

            if (! in_array($membership->status, $statuses, true)) {
                continue;
            }

            if ($membership->start_date !== null && $membership->start_date->gt($today)) {
                $blocking ??= $this->deny('membership_not_started', 'Membership has not started yet.', $member, $membership);
                continue;
            }

            if ($membership->end_date !== null && $membership->end_date->lt($today)) {
                $blocking ??= $this->deny('membership_expired', 'Membership end date has passed.', $member, $membership);
                continue;
            }

            $plan = $membership->plan;
            if ($plan === null) {
                $blocking ??= $this->deny('plan_missing', 'Membership plan is missing.', $member, $membership);
                continue;
            }

            if (! $plan->allows_all_branches) {
                $allowedIds = $plan->branches->pluck('id')->map(fn ($id) => (int) $id)->all();
                if ($allowedIds === [] || ! in_array($branchId, $allowedIds, true)) {
                    $blocking ??= $this->deny('branch_not_allowed', 'Plan does not allow this branch.', $member, $membership);
                    continue;
                }
            }

            if ($membership->visits_remaining !== null && $membership->visits_remaining < 1) {
                $blocking ??= $this->deny('no_visits_remaining', 'No visits remaining.', $member, $membership);
                continue;
            }

            return [
                'allowed' => true,
                'code' => null,
                'message' => 'Eligible to book.',
                'member' => $member,
                'membership' => $membership,
            ];
        }

        return $blocking ?? $this->deny('no_eligible_membership', 'No eligible membership for booking.', $member);
    }

    /**
     * @return array{
     *     allowed: bool,
     *     code: ?string,
     *     message: string,
     *     member: ?\App\Domains\Members\Models\Member,
     *     membership: ?Membership
     * }
     */
    private function deny(
        string $code,
        string $message,
        mixed $member = null,
        ?Membership $membership = null
    ): array {
        return [
            'allowed' => false,
            'code' => $code,
            'message' => $message,
            'member' => $member,
            'membership' => $membership,
        ];
    }
}
