<?php

declare(strict_types=1);

namespace App\Domains\Classes\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Classes\Actions\CreateClassTypeAction;
use App\Domains\Classes\Actions\DeleteClassTypeAction;
use App\Domains\Classes\Actions\UpdateClassTypeAction;
use App\Domains\Classes\Contracts\ClassTypeRepositoryInterface;
use App\Domains\Classes\Models\ClassType;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class ClassTypeService extends BaseService
{
    public function __construct(
        private readonly ClassTypeRepositoryInterface $types,
        private readonly CreateClassTypeAction $createClassTypeAction,
        private readonly UpdateClassTypeAction $updateClassTypeAction,
        private readonly DeleteClassTypeAction $deleteClassTypeAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->types->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $typeId): ClassType
    {
        $type = $this->types->findForTenant($tenant->id, $typeId);

        if ($type === null) {
            throw new DomainException('Class type not found.', 'class_type_not_found', Response::HTTP_NOT_FOUND);
        }

        return $type;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): ClassType
    {
        return $this->createClassTypeAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $typeId, array $data): ClassType
    {
        return $this->updateClassTypeAction->execute($tenant, $typeId, $data);
    }

    public function delete(Tenant $tenant, int $typeId): bool
    {
        return $this->deleteClassTypeAction->execute($tenant, $typeId);
    }
}
