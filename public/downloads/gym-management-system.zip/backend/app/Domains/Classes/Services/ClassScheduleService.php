<?php

declare(strict_types=1);

namespace App\Domains\Classes\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Classes\Actions\CancelClassScheduleAction;
use App\Domains\Classes\Actions\CreateClassScheduleAction;
use App\Domains\Classes\Contracts\ClassScheduleRepositoryInterface;
use App\Domains\Classes\Models\ClassSchedule;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Symfony\Component\HttpFoundation\Response;

final class ClassScheduleService extends BaseService
{
    public function __construct(
        private readonly ClassScheduleRepositoryInterface $schedules,
        private readonly CreateClassScheduleAction $createClassScheduleAction,
        private readonly CancelClassScheduleAction $cancelClassScheduleAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->schedules->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $scheduleId): ClassSchedule
    {
        $schedule = $this->schedules->findForTenant($tenant->id, $scheduleId);

        if ($schedule === null) {
            throw new DomainException('Class schedule not found.', 'class_schedule_not_found', Response::HTTP_NOT_FOUND);
        }

        return $schedule;
    }

    /**
     * @param  array<string, mixed>  $data
     * @return Collection<int, ClassSchedule>
     */
    public function create(Tenant $tenant, array $data): Collection
    {
        return $this->createClassScheduleAction->execute($tenant, $data);
    }

    public function cancel(Tenant $tenant, int $scheduleId): ClassSchedule
    {
        return $this->cancelClassScheduleAction->execute($tenant, $scheduleId);
    }
}
