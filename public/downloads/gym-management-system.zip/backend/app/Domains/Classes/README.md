﻿# Classes Domain

## Admin Portal — Class types, schedules, bookings (complete)

Requires `auth:sanctum` + staff + `X-Tenant-Slug` + permissions.

### Class types
| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/class-types` | view / manage |
| GET/PUT/DELETE | `/api/v1/admin/class-types/{id}` | view / manage |

### Schedules
| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/class-schedules` | view / manage |
| GET | `/api/v1/admin/class-schedules/{id}` | view |
| POST | `/api/v1/admin/class-schedules/{id}/cancel` | manage |
| GET | `/api/v1/admin/class-schedules/{id}/roster` | view |
| GET | `/api/v1/admin/class-schedules/{id}/waitlist` | view |

Create supports optional weekly recurrence: `recurrence: { frequency: "weekly", count: N }` (max 52). Instructor/room overlap blocked.

### Bookings & waitlist
| Method | Path | Permission |
| --- | --- | --- |
| POST | `/api/v1/admin/bookings` | `classes.book_for_member` |
| POST | `/api/v1/admin/bookings/{id}/cancel` | `classes.book_for_member` |
| POST | `/api/v1/admin/bookings/{id}/attendance` | `classes.manage` |
| POST | `/api/v1/admin/waitlist/{id}/promote` | `classes.book_for_member` |

Booking body: `class_schedule_id`, `member_id`, optional `waitlist_if_full` (default true).

When full + waitlist enabled → returns `{ type: "waitlist", waitlist: ... }`.  
Otherwise `{ type: "booking", booking: ... }`.

### Rules
- Active membership required (grace allowed via `gms.attendance.allow_grace_status`)
- Branch must match plan scope; visit packs decrement on book / restore on cancel
- Cancel booking auto-promotes next waitlist entry when `waitlist_mode` is `auto` or `both`
- Class attendance is separate from walk-in attendance (`attended` \| `no_show`)

Audited: `class_type.*`, `class_schedule.*`, `class_booking.*`, `class_waitlist.*`, `class_attendance.marked`

## Next Admin modules
Billing / Payments → … (Training complete)
