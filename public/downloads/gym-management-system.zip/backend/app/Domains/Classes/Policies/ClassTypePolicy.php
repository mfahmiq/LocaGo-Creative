<?php

declare(strict_types=1);

namespace App\Domains\Classes\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Classes\Models\ClassType;
use App\Domains\Identity\Models\User;

final class ClassTypePolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'classes.view');
    }

    public function view(User $user, ClassType $type): bool
    {
        return $this->hasPermission($user, 'classes.view')
            && $this->sameTenant($user, $type);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'classes.manage');
    }

    public function update(User $user, ClassType $type): bool
    {
        return $this->hasPermission($user, 'classes.manage')
            && $this->sameTenant($user, $type);
    }

    public function delete(User $user, ClassType $type): bool
    {
        return $this->update($user, $type);
    }
}
