<?php

declare(strict_types=1);

namespace App\Domains\Classes\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Classes\Models\ClassBooking;
use App\Domains\Classes\Models\ClassSchedule;
use App\Domains\Identity\Models\User;

final class ClassSchedulePolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'classes.view');
    }

    public function view(User $user, ClassSchedule $schedule): bool
    {
        return $this->hasPermission($user, 'classes.view')
            && $this->sameTenant($user, $schedule)
            && $this->branchAllowed($user, (int) $schedule->branch_id);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'classes.manage');
    }

    public function cancel(User $user, ClassSchedule $schedule): bool
    {
        return $this->hasPermission($user, 'classes.manage')
            && $this->sameTenant($user, $schedule)
            && $this->branchAllowed($user, (int) $schedule->branch_id);
    }

    public function book(User $user): bool
    {
        return $this->hasPermission($user, 'classes.book_for_member');
    }

    public function manageBooking(User $user, ClassBooking $booking): bool
    {
        $schedule = $booking->relationLoaded('schedule')
            ? $booking->schedule
            : $booking->schedule()->first();

        $branchId = $schedule !== null ? (int) $schedule->branch_id : null;

        return ($this->hasPermission($user, 'classes.book_for_member') || $this->hasPermission($user, 'classes.manage'))
            && $this->sameTenant($user, $booking)
            && $this->branchAllowed($user, $branchId);
    }
}
