<?php

declare(strict_types=1);

namespace App\Domains\Classes\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Classes\Contracts\ClassTypeRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeleteClassTypeAction extends Action
{
    public function __construct(
        private readonly ClassTypeRepositoryInterface $types,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $typeId */
        $typeId = (int) $args[1];

        $type = $this->types->findForTenant($tenant->id, $typeId);

        if ($type === null) {
            throw new DomainException('Class type not found.', 'class_type_not_found', Response::HTTP_NOT_FOUND);
        }

        $deleted = $this->types->deleteType($type);

        $this->audit->write(
            action: 'class_type.deleted',
            entityType: 'class_type',
            entityId: $typeId,
            tenantId: $tenant->id,
            oldValues: ['code' => $type->code, 'name' => $type->name]
        );

        return $deleted;
    }
}
