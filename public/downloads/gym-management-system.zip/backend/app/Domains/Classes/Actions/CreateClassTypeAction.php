<?php

declare(strict_types=1);

namespace App\Domains\Classes\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Classes\Contracts\ClassTypeRepositoryInterface;
use App\Domains\Classes\Models\ClassType;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CreateClassTypeAction extends Action
{
    public function __construct(
        private readonly ClassTypeRepositoryInterface $types,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): ClassType
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        $code = strtoupper(trim((string) $data['code']));

        if ($this->types->codeExistsForTenant($tenant->id, $code)) {
            throw new DomainException(
                'A class type with this code already exists.',
                'class_type_code_exists',
                Response::HTTP_CONFLICT
            );
        }

        $capacity = (int) ($data['default_capacity'] ?? 20);
        if ($capacity < 1) {
            throw new DomainException(
                'Default capacity must be at least 1.',
                'invalid_capacity',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $type = $this->types->createType([
            'tenant_id' => $tenant->id,
            'code' => $code,
            'name' => $data['name'],
            'category' => $data['category'] ?? null,
            'default_duration_minutes' => (int) ($data['default_duration_minutes'] ?? 60),
            'default_capacity' => $capacity,
            'waitlist_enabled' => (bool) ($data['waitlist_enabled'] ?? true),
            'is_active' => (bool) ($data['is_active'] ?? true),
        ]);

        $this->audit->write(
            action: 'class_type.created',
            entityType: 'class_type',
            entityId: $type->id,
            tenantId: $tenant->id,
            newValues: ['code' => $type->code, 'name' => $type->name]
        );

        return $type;
    }
}
