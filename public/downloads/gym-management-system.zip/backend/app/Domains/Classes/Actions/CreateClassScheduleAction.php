<?php

declare(strict_types=1);

namespace App\Domains\Classes\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Classes\Contracts\ClassScheduleRepositoryInterface;
use App\Domains\Classes\Contracts\ClassTypeRepositoryInterface;
use App\Domains\Classes\Models\ClassSchedule;
use App\Domains\Identity\Models\User;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Organization\Models\Room;
use App\Domains\Tenancy\Models\Tenant;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

final class CreateClassScheduleAction extends Action
{
    public function __construct(
        private readonly ClassScheduleRepositoryInterface $schedules,
        private readonly ClassTypeRepositoryInterface $types,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    /**
     * @return Collection<int, ClassSchedule>
     */
    public function execute(mixed ...$args): Collection
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        return $this->transaction(function () use ($tenant, $data): Collection {
            $type = $this->types->findActiveForTenant($tenant->id, (int) $data['class_type_id']);

            if ($type === null) {
                throw new DomainException(
                    'Class type not found or inactive.',
                    'class_type_not_found',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $branchId = (int) $data['branch_id'];
            if ($this->branches->findActiveForTenant($tenant->id, $branchId) === null) {
                throw new DomainException('Branch is invalid or inactive.', 'invalid_branch', Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $instructorId = isset($data['instructor_user_id']) ? (int) $data['instructor_user_id'] : null;
            if ($instructorId !== null) {
                $this->assertInstructor($tenant->id, $instructorId);
            }

            $roomId = isset($data['room_id']) ? (int) $data['room_id'] : null;
            if ($roomId !== null) {
                $this->assertRoom($tenant->id, $branchId, $roomId);
            }

            $startsAt = Carbon::parse((string) $data['starts_at']);
            $endsAt = isset($data['ends_at'])
                ? Carbon::parse((string) $data['ends_at'])
                : $startsAt->copy()->addMinutes((int) $type->default_duration_minutes);

            if ($endsAt->lte($startsAt)) {
                throw new DomainException(
                    'ends_at must be after starts_at.',
                    'invalid_schedule_times',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $capacity = (int) ($data['capacity'] ?? $type->default_capacity);
            if ($capacity < 1) {
                throw new DomainException('Capacity must be at least 1.', 'invalid_capacity', Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $waitlistMode = (string) ($data['waitlist_mode'] ?? ClassSchedule::WAITLIST_BOTH);
            if (! in_array($waitlistMode, [
                ClassSchedule::WAITLIST_AUTO,
                ClassSchedule::WAITLIST_MANUAL,
                ClassSchedule::WAITLIST_BOTH,
            ], true)) {
                $waitlistMode = ClassSchedule::WAITLIST_BOTH;
            }

            $occurrences = $this->buildOccurrences($startsAt, $endsAt, $data['recurrence'] ?? null);
            $groupId = $occurrences->count() > 1 ? (string) Str::uuid() : null;
            $created = collect();

            foreach ($occurrences as [$occStart, $occEnd]) {
                if ($instructorId !== null && $this->schedules->hasInstructorConflict($tenant->id, $instructorId, $occStart, $occEnd)) {
                    throw new DomainException(
                        'Instructor has a conflicting schedule.',
                        'instructor_conflict',
                        Response::HTTP_CONFLICT
                    );
                }

                if ($roomId !== null && $this->schedules->hasRoomConflict($tenant->id, $roomId, $occStart, $occEnd)) {
                    throw new DomainException(
                        'Room has a conflicting schedule.',
                        'room_conflict',
                        Response::HTTP_CONFLICT
                    );
                }

                $schedule = $this->schedules->createSchedule([
                    'tenant_id' => $tenant->id,
                    'branch_id' => $branchId,
                    'class_type_id' => $type->id,
                    'instructor_user_id' => $instructorId,
                    'room_id' => $roomId,
                    'starts_at' => $occStart,
                    'ends_at' => $occEnd,
                    'capacity' => $capacity,
                    'booked_count' => 0,
                    'waitlist_count' => 0,
                    'waitlist_mode' => $waitlistMode,
                    'status' => ClassSchedule::STATUS_SCHEDULED,
                    'recurrence_group_id' => $groupId,
                ]);

                $created->push($schedule);
            }

            $this->audit->write(
                action: 'class_schedule.created',
                entityType: 'class_schedule',
                entityId: $created->first()?->id,
                tenantId: $tenant->id,
                newValues: [
                    'count' => $created->count(),
                    'class_type_id' => $type->id,
                    'recurrence_group_id' => $groupId,
                ]
            );

            return $created;
        });
    }

    /**
     * @return Collection<int, array{0: Carbon, 1: Carbon}>
     */
    private function buildOccurrences(Carbon $startsAt, Carbon $endsAt, mixed $recurrence): Collection
    {
        $durationSeconds = $startsAt->diffInSeconds($endsAt);
        $items = collect([[$startsAt->copy(), $endsAt->copy()]]);

        if (! is_array($recurrence) || empty($recurrence['frequency'])) {
            return $items;
        }

        $frequency = (string) $recurrence['frequency'];
        if ($frequency !== 'weekly') {
            throw new DomainException(
                'Only weekly recurrence is supported in V1.',
                'unsupported_recurrence',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $count = max(1, min((int) ($recurrence['count'] ?? 1), 52));

        for ($i = 1; $i < $count; $i++) {
            $nextStart = $startsAt->copy()->addWeeks($i);
            $nextEnd = $nextStart->copy()->addSeconds($durationSeconds);
            $items->push([$nextStart, $nextEnd]);
        }

        return $items;
    }

    private function assertInstructor(int $tenantId, int $userId): void
    {
        $exists = User::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('id', $userId)
            ->where('is_active', true)
            ->whereNull('deleted_at')
            ->exists();

        if (! $exists) {
            throw new DomainException(
                'Instructor user is invalid or inactive.',
                'invalid_instructor',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }

    private function assertRoom(int $tenantId, int $branchId, int $roomId): void
    {
        $exists = Room::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('branch_id', $branchId)
            ->where('id', $roomId)
            ->where('is_active', true)
            ->whereNull('deleted_at')
            ->exists();

        if (! $exists) {
            throw new DomainException(
                'Room is invalid or inactive for this branch.',
                'invalid_room',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }
}
