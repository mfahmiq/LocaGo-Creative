<?php

declare(strict_types=1);

namespace App\Domains\Classes\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Classes\Contracts\ClassBookingRepositoryInterface;
use App\Domains\Classes\Contracts\ClassScheduleRepositoryInterface;
use App\Domains\Classes\Models\ClassBooking;
use App\Domains\Classes\Models\ClassSchedule;
use App\Domains\Classes\Models\ClassWaitlistEntry;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CancelClassScheduleAction extends Action
{
    public function __construct(
        private readonly ClassScheduleRepositoryInterface $schedules,
        private readonly ClassBookingRepositoryInterface $bookings,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): ClassSchedule
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $scheduleId */
        $scheduleId = (int) $args[1];

        return $this->transaction(function () use ($tenant, $scheduleId): ClassSchedule {
            $schedule = $this->schedules->findForTenant($tenant->id, $scheduleId);

            if ($schedule === null) {
                throw new DomainException('Class schedule not found.', 'class_schedule_not_found', Response::HTTP_NOT_FOUND);
            }

            if ($schedule->status === ClassSchedule::STATUS_CANCELLED) {
                throw new DomainException(
                    'Schedule is already cancelled.',
                    'schedule_already_cancelled',
                    Response::HTTP_CONFLICT
                );
            }

            foreach ($this->bookings->listBookingsForSchedule($tenant->id, $schedule->id) as $booking) {
                if ($booking->status === ClassBooking::STATUS_BOOKED) {
                    $this->bookings->updateBooking($booking, [
                        'status' => ClassBooking::STATUS_CANCELLED,
                        'cancelled_at' => now(),
                        'cancel_reason' => 'Class cancelled',
                    ]);
                }
            }

            foreach ($this->bookings->listWaitlistForSchedule($tenant->id, $schedule->id) as $entry) {
                $this->bookings->updateWaitlist($entry, [
                    'status' => ClassWaitlistEntry::STATUS_CANCELLED,
                ]);
            }

            $updated = $this->schedules->updateSchedule($schedule, [
                'status' => ClassSchedule::STATUS_CANCELLED,
                'booked_count' => 0,
                'waitlist_count' => 0,
            ]);

            $this->audit->write(
                action: 'class_schedule.cancelled',
                entityType: 'class_schedule',
                entityId: $updated->id,
                tenantId: $tenant->id
            );

            return $updated;
        });
    }
}
