<?php

declare(strict_types=1);

namespace App\Domains\Classes\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Classes\Contracts\ClassTypeRepositoryInterface;
use App\Domains\Classes\Models\ClassType;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateClassTypeAction extends Action
{
    public function __construct(
        private readonly ClassTypeRepositoryInterface $types,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): ClassType
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $typeId */
        $typeId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        $type = $this->types->findForTenant($tenant->id, $typeId);

        if ($type === null) {
            throw new DomainException('Class type not found.', 'class_type_not_found', Response::HTTP_NOT_FOUND);
        }

        if (isset($data['code'])) {
            $code = strtoupper(trim((string) $data['code']));
            if ($this->types->codeExistsForTenant($tenant->id, $code, $type->id)) {
                throw new DomainException(
                    'A class type with this code already exists.',
                    'class_type_code_exists',
                    Response::HTTP_CONFLICT
                );
            }
            $data['code'] = $code;
        }

        if (array_key_exists('default_capacity', $data) && (int) $data['default_capacity'] < 1) {
            throw new DomainException(
                'Default capacity must be at least 1.',
                'invalid_capacity',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $payload = [];
        foreach ([
            'code', 'name', 'category', 'default_duration_minutes', 'default_capacity',
            'waitlist_enabled', 'is_active',
        ] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = $data[$field];
            }
        }

        $updated = $this->types->updateType($type, $payload);

        $this->audit->write(
            action: 'class_type.updated',
            entityType: 'class_type',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: ['code' => $updated->code, 'is_active' => $updated->is_active]
        );

        return $updated;
    }
}
