<?php

declare(strict_types=1);

namespace App\Domains\Classes\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Classes\Contracts\ClassBookingRepositoryInterface;
use App\Domains\Classes\Contracts\ClassScheduleRepositoryInterface;
use App\Domains\Classes\Models\ClassBooking;
use App\Domains\Classes\Models\ClassSchedule;
use App\Domains\Classes\Models\ClassWaitlistEntry;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CancelClassBookingAction extends Action
{
    public function __construct(
        private readonly ClassBookingRepositoryInterface $bookings,
        private readonly ClassScheduleRepositoryInterface $schedules,
        private readonly MembershipRepositoryInterface $memberships,
        private readonly PromoteWaitlistEntryAction $promoteWaitlistEntryAction,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): ClassBooking
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $bookingId */
        $bookingId = (int) $args[1];
        /** @var string|null $reason */
        $reason = $args[2] ?? null;

        return $this->transaction(function () use ($tenant, $bookingId, $reason): ClassBooking {
            $booking = $this->bookings->findBookingForTenant($tenant->id, $bookingId);

            if ($booking === null) {
                throw new DomainException('Booking not found.', 'class_booking_not_found', Response::HTTP_NOT_FOUND);
            }

            if ($booking->status !== ClassBooking::STATUS_BOOKED) {
                throw new DomainException(
                    'Only booked reservations can be cancelled.',
                    'invalid_booking_status',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $schedule = $this->schedules->findForTenant($tenant->id, (int) $booking->class_schedule_id);

            if ($booking->membership_id !== null) {
                $membership = $this->memberships->findForTenant($tenant->id, (int) $booking->membership_id);
                if ($membership !== null && $membership->visits_remaining !== null) {
                    $this->memberships->updateMembership($membership, [
                        'visits_remaining' => (int) $membership->visits_remaining + 1,
                    ]);
                }
            }

            $updated = $this->bookings->updateBooking($booking, [
                'status' => ClassBooking::STATUS_CANCELLED,
                'cancelled_at' => now(),
                'cancel_reason' => $reason,
            ]);

            if ($schedule !== null && $schedule->status === ClassSchedule::STATUS_SCHEDULED) {
                $this->schedules->updateSchedule($schedule, [
                    'booked_count' => max(0, (int) $schedule->booked_count - 1),
                ]);

                $mode = $schedule->waitlist_mode;
                if (in_array($mode, [ClassSchedule::WAITLIST_AUTO, ClassSchedule::WAITLIST_BOTH], true)) {
                    $next = $this->bookings->findNextWaiting($schedule->id);
                    if ($next !== null) {
                        $this->promoteWaitlistEntryAction->execute($tenant, $next->id);
                    }
                }
            }

            $this->audit->write(
                action: 'class_booking.cancelled',
                entityType: 'class_booking',
                entityId: $updated->id,
                tenantId: $tenant->id,
                newValues: ['cancel_reason' => $reason]
            );

            return $updated;
        });
    }
}
