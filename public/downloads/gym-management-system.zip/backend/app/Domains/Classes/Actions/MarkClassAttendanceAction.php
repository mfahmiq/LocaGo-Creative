<?php

declare(strict_types=1);

namespace App\Domains\Classes\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Classes\Contracts\ClassBookingRepositoryInterface;
use App\Domains\Classes\Contracts\ClassScheduleRepositoryInterface;
use App\Domains\Classes\Models\ClassAttendance;
use App\Domains\Classes\Models\ClassBooking;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

final class MarkClassAttendanceAction extends Action
{
    public function __construct(
        private readonly ClassBookingRepositoryInterface $bookings,
        private readonly ClassScheduleRepositoryInterface $schedules,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): ClassAttendance
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $bookingId */
        $bookingId = (int) $args[1];
        /** @var string $status */
        $status = (string) $args[2];

        return $this->transaction(function () use ($tenant, $bookingId, $status): ClassAttendance {
            if (! in_array($status, [ClassAttendance::STATUS_ATTENDED, ClassAttendance::STATUS_NO_SHOW], true)) {
                throw new DomainException(
                    'Status must be attended or no_show.',
                    'invalid_attendance_status',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $booking = $this->bookings->findBookingForTenant($tenant->id, $bookingId);

            if ($booking === null) {
                throw new DomainException('Booking not found.', 'class_booking_not_found', Response::HTTP_NOT_FOUND);
            }

            if (! in_array($booking->status, [
                ClassBooking::STATUS_BOOKED,
                ClassBooking::STATUS_ATTENDED,
                ClassBooking::STATUS_NO_SHOW,
            ], true)) {
                throw new DomainException(
                    'Cannot mark attendance for this booking.',
                    'invalid_booking_status',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $schedule = $this->schedules->findForTenant($tenant->id, (int) $booking->class_schedule_id);
            if ($schedule === null) {
                throw new DomainException('Class schedule not found.', 'class_schedule_not_found', Response::HTTP_NOT_FOUND);
            }

            $bookingStatus = $status === ClassAttendance::STATUS_ATTENDED
                ? ClassBooking::STATUS_ATTENDED
                : ClassBooking::STATUS_NO_SHOW;

            $this->bookings->updateBooking($booking, ['status' => $bookingStatus]);

            $existing = $this->bookings->findClassAttendance($schedule->id, (int) $booking->member_id);

            if ($existing !== null) {
                $attendance = $this->bookings->updateClassAttendance($existing, [
                    'status' => $status,
                    'marked_at' => now(),
                    'marked_by' => Auth::id(),
                    'class_booking_id' => $booking->id,
                ]);
            } else {
                $attendance = $this->bookings->createClassAttendance([
                    'tenant_id' => $tenant->id,
                    'class_schedule_id' => $schedule->id,
                    'class_booking_id' => $booking->id,
                    'member_id' => $booking->member_id,
                    'status' => $status,
                    'marked_at' => now(),
                    'marked_by' => Auth::id(),
                ]);
            }

            $this->audit->write(
                action: 'class_attendance.marked',
                entityType: 'class_attendance',
                entityId: $attendance->id,
                tenantId: $tenant->id,
                newValues: ['status' => $status, 'booking_id' => $booking->id]
            );

            return $attendance;
        });
    }
}
