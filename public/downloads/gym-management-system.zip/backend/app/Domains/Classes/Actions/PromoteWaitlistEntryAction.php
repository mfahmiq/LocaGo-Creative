<?php

declare(strict_types=1);

namespace App\Domains\Classes\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Classes\Contracts\ClassBookingRepositoryInterface;
use App\Domains\Classes\Contracts\ClassScheduleRepositoryInterface;
use App\Domains\Classes\Models\ClassBooking;
use App\Domains\Classes\Models\ClassSchedule;
use App\Domains\Classes\Models\ClassWaitlistEntry;
use App\Domains\Classes\Services\ClassBookingEligibilityService;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class PromoteWaitlistEntryAction extends Action
{
    public function __construct(
        private readonly ClassBookingRepositoryInterface $bookings,
        private readonly ClassScheduleRepositoryInterface $schedules,
        private readonly ClassBookingEligibilityService $eligibility,
        private readonly MembershipRepositoryInterface $memberships,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): ClassBooking
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $waitlistId */
        $waitlistId = (int) $args[1];

        return $this->transaction(function () use ($tenant, $waitlistId): ClassBooking {
            $entry = $this->bookings->findWaitlistForTenant($tenant->id, $waitlistId);

            if ($entry === null) {
                throw new DomainException('Waitlist entry not found.', 'waitlist_not_found', Response::HTTP_NOT_FOUND);
            }

            if ($entry->status !== ClassWaitlistEntry::STATUS_WAITING) {
                throw new DomainException(
                    'Only waiting entries can be promoted.',
                    'invalid_waitlist_status',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $schedule = $this->schedules->findForTenant($tenant->id, (int) $entry->class_schedule_id);

            if ($schedule === null || $schedule->status !== ClassSchedule::STATUS_SCHEDULED) {
                throw new DomainException(
                    'Schedule is not available for promotion.',
                    'invalid_schedule_status',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            if (! $schedule->hasOpenSeats()) {
                throw new DomainException('Class has no open seats.', 'class_full', Response::HTTP_CONFLICT);
            }

            $result = $this->eligibility->evaluate($tenant, (int) $entry->member_id, (int) $schedule->branch_id);

            if (! $result['allowed'] || $result['membership'] === null) {
                throw new DomainException(
                    $result['message'],
                    $result['code'] ?? 'booking_denied',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $membership = $result['membership'];

            if ($membership->visits_remaining !== null) {
                $this->memberships->updateMembership($membership, [
                    'visits_remaining' => max(0, (int) $membership->visits_remaining - 1),
                ]);
            }

            $existing = $this->bookings->findBookingForScheduleMember($schedule->id, (int) $entry->member_id);

            if ($existing !== null && $existing->status === ClassBooking::STATUS_CANCELLED) {
                $booking = $this->bookings->updateBooking($existing, [
                    'membership_id' => $membership->id,
                    'status' => ClassBooking::STATUS_BOOKED,
                    'booked_at' => now(),
                    'cancelled_at' => null,
                    'cancel_reason' => null,
                    'source' => ClassBooking::SOURCE_ADMIN,
                ]);
            } else {
                $booking = $this->bookings->createBooking([
                    'tenant_id' => $tenant->id,
                    'class_schedule_id' => $schedule->id,
                    'member_id' => $entry->member_id,
                    'membership_id' => $membership->id,
                    'status' => ClassBooking::STATUS_BOOKED,
                    'booked_at' => now(),
                    'source' => ClassBooking::SOURCE_ADMIN,
                ]);
            }

            $this->bookings->updateWaitlist($entry, [
                'status' => ClassWaitlistEntry::STATUS_PROMOTED,
                'promoted_booking_id' => $booking->id,
            ]);

            $this->schedules->updateSchedule($schedule, [
                'booked_count' => (int) $schedule->booked_count + 1,
                'waitlist_count' => max(0, (int) $schedule->waitlist_count - 1),
            ]);

            $this->audit->write(
                action: 'class_waitlist.promoted',
                entityType: 'class_waitlist_entry',
                entityId: $entry->id,
                tenantId: $tenant->id,
                newValues: ['booking_id' => $booking->id]
            );

            return $booking;
        });
    }
}
