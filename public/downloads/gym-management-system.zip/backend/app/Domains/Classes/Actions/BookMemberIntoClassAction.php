<?php

declare(strict_types=1);

namespace App\Domains\Classes\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Classes\Contracts\ClassBookingRepositoryInterface;
use App\Domains\Classes\Contracts\ClassScheduleRepositoryInterface;
use App\Domains\Classes\Models\ClassBooking;
use App\Domains\Classes\Models\ClassSchedule;
use App\Domains\Classes\Models\ClassWaitlistEntry;
use App\Domains\Classes\Services\ClassBookingEligibilityService;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class BookMemberIntoClassAction extends Action
{
    public function __construct(
        private readonly ClassScheduleRepositoryInterface $schedules,
        private readonly ClassBookingRepositoryInterface $bookings,
        private readonly ClassBookingEligibilityService $eligibility,
        private readonly MembershipRepositoryInterface $memberships,
        private readonly AuditWriter $audit
    ) {}

    /**
     * @return array{type: string, booking?: ClassBooking, waitlist?: ClassWaitlistEntry}
     */
    public function execute(mixed ...$args): array
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        return $this->transaction(function () use ($tenant, $data): array {
            $schedule = $this->schedules->findForTenant($tenant->id, (int) $data['class_schedule_id']);

            if ($schedule === null) {
                throw new DomainException('Class schedule not found.', 'class_schedule_not_found', Response::HTTP_NOT_FOUND);
            }

            if ($schedule->status !== ClassSchedule::STATUS_SCHEDULED) {
                throw new DomainException(
                    'Only scheduled classes can be booked.',
                    'invalid_schedule_status',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $memberId = (int) $data['member_id'];
            $result = $this->eligibility->evaluate($tenant, $memberId, (int) $schedule->branch_id);

            if (! $result['allowed'] || $result['membership'] === null) {
                throw new DomainException(
                    $result['message'],
                    $result['code'] ?? 'booking_denied',
                    $result['code'] === 'member_not_found' ? Response::HTTP_NOT_FOUND : Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $existing = $this->bookings->findBookingForScheduleMember($schedule->id, $memberId);
            if ($existing !== null && $existing->status === ClassBooking::STATUS_BOOKED) {
                throw new DomainException(
                    'Member is already booked for this class.',
                    'already_booked',
                    Response::HTTP_CONFLICT
                );
            }

            $waitlistExisting = $this->bookings->findWaitlistForScheduleMember($schedule->id, $memberId);
            if ($waitlistExisting !== null && in_array($waitlistExisting->status, [
                ClassWaitlistEntry::STATUS_WAITING,
                ClassWaitlistEntry::STATUS_OFFERED,
            ], true)) {
                throw new DomainException(
                    'Member is already on the waitlist.',
                    'already_waitlisted',
                    Response::HTTP_CONFLICT
                );
            }

            $membership = $result['membership'];
            $forceWaitlist = (bool) ($data['waitlist_if_full'] ?? true);

            if (! $schedule->hasOpenSeats()) {
                $type = $schedule->classType;
                if (! $forceWaitlist || $type === null || ! $type->waitlist_enabled) {
                    throw new DomainException(
                        'Class is full.',
                        'class_full',
                        Response::HTTP_CONFLICT
                    );
                }

                if ($waitlistExisting !== null && $waitlistExisting->status === ClassWaitlistEntry::STATUS_CANCELLED) {
                    $entry = $this->bookings->updateWaitlist($waitlistExisting, [
                        'status' => ClassWaitlistEntry::STATUS_WAITING,
                        'position' => $this->bookings->nextWaitlistPosition($schedule->id),
                        'promoted_booking_id' => null,
                    ]);
                } else {
                    $entry = $this->bookings->createWaitlist([
                        'tenant_id' => $tenant->id,
                        'class_schedule_id' => $schedule->id,
                        'member_id' => $memberId,
                        'position' => $this->bookings->nextWaitlistPosition($schedule->id),
                        'status' => ClassWaitlistEntry::STATUS_WAITING,
                    ]);
                }

                $this->schedules->updateSchedule($schedule, [
                    'waitlist_count' => (int) $schedule->waitlist_count + 1,
                ]);

                $this->audit->write(
                    action: 'class_waitlist.joined',
                    entityType: 'class_waitlist_entry',
                    entityId: $entry->id,
                    tenantId: $tenant->id,
                    newValues: ['schedule_id' => $schedule->id, 'member_id' => $memberId]
                );

                return ['type' => 'waitlist', 'waitlist' => $entry];
            }

            if ($membership->visits_remaining !== null) {
                $this->memberships->updateMembership($membership, [
                    'visits_remaining' => max(0, (int) $membership->visits_remaining - 1),
                ]);
            }

            if ($existing !== null && $existing->status === ClassBooking::STATUS_CANCELLED) {
                $booking = $this->bookings->updateBooking($existing, [
                    'membership_id' => $membership->id,
                    'status' => ClassBooking::STATUS_BOOKED,
                    'booked_at' => now(),
                    'cancelled_at' => null,
                    'cancel_reason' => null,
                    'source' => (string) ($data['source'] ?? ClassBooking::SOURCE_ADMIN),
                ]);
            } else {
                $booking = $this->bookings->createBooking([
                    'tenant_id' => $tenant->id,
                    'class_schedule_id' => $schedule->id,
                    'member_id' => $memberId,
                    'membership_id' => $membership->id,
                    'status' => ClassBooking::STATUS_BOOKED,
                    'booked_at' => now(),
                    'source' => (string) ($data['source'] ?? ClassBooking::SOURCE_ADMIN),
                ]);
            }

            $this->schedules->updateSchedule($schedule, [
                'booked_count' => (int) $schedule->booked_count + 1,
            ]);

            $this->audit->write(
                action: 'class_booking.created',
                entityType: 'class_booking',
                entityId: $booking->id,
                tenantId: $tenant->id,
                newValues: [
                    'schedule_id' => $schedule->id,
                    'member_id' => $memberId,
                    'membership_id' => $membership->id,
                ]
            );

            return ['type' => 'booking', 'booking' => $booking];
        });
    }
}
