<?php

declare(strict_types=1);

namespace App\Domains\Classes\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Classes\Contracts\ClassScheduleRepositoryInterface;
use App\Domains\Classes\Models\ClassSchedule;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Carbon;

/**
 * @extends BaseRepository<ClassSchedule>
 */
class EloquentClassScheduleRepository extends BaseRepository implements ClassScheduleRepositoryInterface
{
    public function __construct(ClassSchedule $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['classType', 'branch', 'instructor', 'room'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderBy('starts_at');

        if (! empty($filters['branch_id'])) {
            $query->where('branch_id', (int) $filters['branch_id']);
        }

        if (! empty($filters['class_type_id'])) {
            $query->where('class_type_id', (int) $filters['class_type_id']);
        }

        if (! empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        if (! empty($filters['from'])) {
            $query->where('starts_at', '>=', (string) $filters['from']);
        }

        if (! empty($filters['to'])) {
            $query->where('starts_at', '<=', (string) $filters['to']);
        }

        if (! empty($filters['date'])) {
            $query->whereDate('starts_at', (string) $filters['date']);
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $scheduleId): ?ClassSchedule
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['classType', 'branch', 'instructor', 'room'])
            ->where('tenant_id', $tenantId)
            ->where('id', $scheduleId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function createSchedule(array $attributes): ClassSchedule
    {
        /** @var ClassSchedule $schedule */
        $schedule = $this->query()->withoutGlobalScopes()->create($attributes);

        return $schedule->load(['classType', 'branch', 'instructor', 'room']);
    }

    public function updateSchedule(ClassSchedule $schedule, array $attributes): ClassSchedule
    {
        $schedule->update($attributes);

        return $schedule->fresh(['classType', 'branch', 'instructor', 'room']);
    }

    public function hasInstructorConflict(
        int $tenantId,
        int $instructorUserId,
        Carbon $startsAt,
        Carbon $endsAt,
        ?int $exceptScheduleId = null
    ): bool {
        $query = $this->overlapQuery($tenantId, $startsAt, $endsAt, $exceptScheduleId)
            ->where('instructor_user_id', $instructorUserId);

        return $query->exists();
    }

    public function hasRoomConflict(
        int $tenantId,
        int $roomId,
        Carbon $startsAt,
        Carbon $endsAt,
        ?int $exceptScheduleId = null
    ): bool {
        $query = $this->overlapQuery($tenantId, $startsAt, $endsAt, $exceptScheduleId)
            ->where('room_id', $roomId);

        return $query->exists();
    }

    private function overlapQuery(int $tenantId, Carbon $startsAt, Carbon $endsAt, ?int $exceptScheduleId)
    {
        $query = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('status', ClassSchedule::STATUS_SCHEDULED)
            ->whereNull('deleted_at')
            ->where('starts_at', '<', $endsAt)
            ->where('ends_at', '>', $startsAt);

        if ($exceptScheduleId !== null) {
            $query->where('id', '!=', $exceptScheduleId);
        }

        return $query;
    }
}
