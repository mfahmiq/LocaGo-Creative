<?php

declare(strict_types=1);

namespace App\Domains\Classes\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Classes\Contracts\ClassTypeRepositoryInterface;
use App\Domains\Classes\Models\ClassType;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<ClassType>
 */
class EloquentClassTypeRepository extends BaseRepository implements ClassTypeRepositoryInterface
{
    public function __construct(ClassType $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderBy('name');

        if (array_key_exists('is_active', $filters) && $filters['is_active'] !== null && $filters['is_active'] !== '') {
            $query->where('is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN));
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);
            $query->where(function ($q) use ($search): void {
                $q->where('code', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%")
                    ->orWhere('category', 'like', "%{$search}%");
            });
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $classTypeId): ?ClassType
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('id', $classTypeId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function findActiveForTenant(int $tenantId, int $classTypeId): ?ClassType
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('id', $classTypeId)
            ->where('is_active', true)
            ->whereNull('deleted_at')
            ->first();
    }

    public function codeExistsForTenant(int $tenantId, string $code, ?int $exceptId = null): bool
    {
        $query = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('code', $code)
            ->whereNull('deleted_at');

        if ($exceptId !== null) {
            $query->where('id', '!=', $exceptId);
        }

        return $query->exists();
    }

    public function createType(array $attributes): ClassType
    {
        /** @var ClassType $type */
        $type = $this->query()->withoutGlobalScopes()->create($attributes);

        return $type;
    }

    public function updateType(ClassType $type, array $attributes): ClassType
    {
        $type->update($attributes);

        return $type->refresh();
    }

    public function deleteType(ClassType $type): bool
    {
        return (bool) $type->delete();
    }
}
