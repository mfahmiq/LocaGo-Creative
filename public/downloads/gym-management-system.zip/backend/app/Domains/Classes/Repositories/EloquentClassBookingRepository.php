<?php

declare(strict_types=1);

namespace App\Domains\Classes\Repositories;

use App\Domains\Classes\Contracts\ClassBookingRepositoryInterface;
use App\Domains\Classes\Models\ClassAttendance;
use App\Domains\Classes\Models\ClassBooking;
use App\Domains\Classes\Models\ClassWaitlistEntry;
use Illuminate\Support\Collection;

class EloquentClassBookingRepository implements ClassBookingRepositoryInterface
{
    public function findBookingForTenant(int $tenantId, int $bookingId): ?ClassBooking
    {
        return ClassBooking::query()
            ->withoutGlobalScopes()
            ->with(['member', 'schedule.classType', 'membership'])
            ->where('tenant_id', $tenantId)
            ->where('id', $bookingId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function findBookingForScheduleMember(int $scheduleId, int $memberId): ?ClassBooking
    {
        return ClassBooking::query()
            ->withoutGlobalScopes()
            ->where('class_schedule_id', $scheduleId)
            ->where('member_id', $memberId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function listBookingsForSchedule(int $tenantId, int $scheduleId): Collection
    {
        return ClassBooking::query()
            ->withoutGlobalScopes()
            ->with(['member', 'membership'])
            ->where('tenant_id', $tenantId)
            ->where('class_schedule_id', $scheduleId)
            ->whereNull('deleted_at')
            ->whereIn('status', [
                ClassBooking::STATUS_BOOKED,
                ClassBooking::STATUS_ATTENDED,
                ClassBooking::STATUS_NO_SHOW,
            ])
            ->orderBy('booked_at')
            ->get();
    }

    public function createBooking(array $attributes): ClassBooking
    {
        /** @var ClassBooking $booking */
        $booking = ClassBooking::query()->withoutGlobalScopes()->create($attributes);

        return $booking->load(['member', 'schedule.classType', 'membership']);
    }

    public function updateBooking(ClassBooking $booking, array $attributes): ClassBooking
    {
        $booking->update($attributes);

        return $booking->fresh(['member', 'schedule.classType', 'membership']);
    }

    public function findWaitlistForTenant(int $tenantId, int $waitlistId): ?ClassWaitlistEntry
    {
        return ClassWaitlistEntry::query()
            ->withoutGlobalScopes()
            ->with(['member', 'schedule'])
            ->where('tenant_id', $tenantId)
            ->where('id', $waitlistId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function findWaitlistForScheduleMember(int $scheduleId, int $memberId): ?ClassWaitlistEntry
    {
        return ClassWaitlistEntry::query()
            ->withoutGlobalScopes()
            ->where('class_schedule_id', $scheduleId)
            ->where('member_id', $memberId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function nextWaitlistPosition(int $scheduleId): int
    {
        $max = (int) ClassWaitlistEntry::query()
            ->withoutGlobalScopes()
            ->where('class_schedule_id', $scheduleId)
            ->whereNull('deleted_at')
            ->whereIn('status', [ClassWaitlistEntry::STATUS_WAITING, ClassWaitlistEntry::STATUS_OFFERED])
            ->max('position');

        return $max + 1;
    }

    public function findNextWaiting(int $scheduleId): ?ClassWaitlistEntry
    {
        return ClassWaitlistEntry::query()
            ->withoutGlobalScopes()
            ->where('class_schedule_id', $scheduleId)
            ->where('status', ClassWaitlistEntry::STATUS_WAITING)
            ->whereNull('deleted_at')
            ->orderBy('position')
            ->first();
    }

    public function listWaitlistForSchedule(int $tenantId, int $scheduleId): Collection
    {
        return ClassWaitlistEntry::query()
            ->withoutGlobalScopes()
            ->with(['member'])
            ->where('tenant_id', $tenantId)
            ->where('class_schedule_id', $scheduleId)
            ->whereNull('deleted_at')
            ->whereIn('status', [ClassWaitlistEntry::STATUS_WAITING, ClassWaitlistEntry::STATUS_OFFERED])
            ->orderBy('position')
            ->get();
    }

    public function createWaitlist(array $attributes): ClassWaitlistEntry
    {
        /** @var ClassWaitlistEntry $entry */
        $entry = ClassWaitlistEntry::query()->withoutGlobalScopes()->create($attributes);

        return $entry->load(['member', 'schedule']);
    }

    public function updateWaitlist(ClassWaitlistEntry $entry, array $attributes): ClassWaitlistEntry
    {
        $entry->update($attributes);

        return $entry->fresh(['member', 'schedule', 'promotedBooking']);
    }

    public function findClassAttendance(int $scheduleId, int $memberId): ?ClassAttendance
    {
        return ClassAttendance::query()
            ->withoutGlobalScopes()
            ->where('class_schedule_id', $scheduleId)
            ->where('member_id', $memberId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function createClassAttendance(array $attributes): ClassAttendance
    {
        /** @var ClassAttendance $attendance */
        $attendance = ClassAttendance::query()->withoutGlobalScopes()->create($attributes);

        return $attendance;
    }

    public function updateClassAttendance(ClassAttendance $attendance, array $attributes): ClassAttendance
    {
        $attendance->update($attributes);

        return $attendance->refresh();
    }
}
