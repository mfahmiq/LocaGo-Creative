<?php

declare(strict_types=1);

namespace App\Domains\Classes\Contracts;

use App\Domains\Classes\Models\ClassSchedule;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Carbon;

interface ClassScheduleRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $scheduleId): ?ClassSchedule;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createSchedule(array $attributes): ClassSchedule;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateSchedule(ClassSchedule $schedule, array $attributes): ClassSchedule;

    public function hasInstructorConflict(
        int $tenantId,
        int $instructorUserId,
        Carbon $startsAt,
        Carbon $endsAt,
        ?int $exceptScheduleId = null
    ): bool;

    public function hasRoomConflict(
        int $tenantId,
        int $roomId,
        Carbon $startsAt,
        Carbon $endsAt,
        ?int $exceptScheduleId = null
    ): bool;
}
