<?php

declare(strict_types=1);

namespace App\Domains\Classes\Contracts;

use App\Domains\Classes\Models\ClassType;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface ClassTypeRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $classTypeId): ?ClassType;

    public function findActiveForTenant(int $tenantId, int $classTypeId): ?ClassType;

    public function codeExistsForTenant(int $tenantId, string $code, ?int $exceptId = null): bool;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createType(array $attributes): ClassType;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateType(ClassType $type, array $attributes): ClassType;

    public function deleteType(ClassType $type): bool;
}
