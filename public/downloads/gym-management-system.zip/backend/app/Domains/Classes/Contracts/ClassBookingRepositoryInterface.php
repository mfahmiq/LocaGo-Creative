<?php

declare(strict_types=1);

namespace App\Domains\Classes\Contracts;

use App\Domains\Classes\Models\ClassAttendance;
use App\Domains\Classes\Models\ClassBooking;
use App\Domains\Classes\Models\ClassWaitlistEntry;
use Illuminate\Support\Collection;

interface ClassBookingRepositoryInterface
{
    public function findBookingForTenant(int $tenantId, int $bookingId): ?ClassBooking;

    public function findBookingForScheduleMember(int $scheduleId, int $memberId): ?ClassBooking;

    /**
     * @return Collection<int, ClassBooking>
     */
    public function listBookingsForSchedule(int $tenantId, int $scheduleId): Collection;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createBooking(array $attributes): ClassBooking;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateBooking(ClassBooking $booking, array $attributes): ClassBooking;

    public function findWaitlistForTenant(int $tenantId, int $waitlistId): ?ClassWaitlistEntry;

    public function findWaitlistForScheduleMember(int $scheduleId, int $memberId): ?ClassWaitlistEntry;

    public function nextWaitlistPosition(int $scheduleId): int;

    public function findNextWaiting(int $scheduleId): ?ClassWaitlistEntry;

    /**
     * @return Collection<int, ClassWaitlistEntry>
     */
    public function listWaitlistForSchedule(int $tenantId, int $scheduleId): Collection;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createWaitlist(array $attributes): ClassWaitlistEntry;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateWaitlist(ClassWaitlistEntry $entry, array $attributes): ClassWaitlistEntry;

    public function findClassAttendance(int $scheduleId, int $memberId): ?ClassAttendance;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createClassAttendance(array $attributes): ClassAttendance;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateClassAttendance(ClassAttendance $attendance, array $attributes): ClassAttendance;
}
