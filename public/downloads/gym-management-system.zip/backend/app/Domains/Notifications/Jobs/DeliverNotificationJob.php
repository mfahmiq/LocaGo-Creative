<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Jobs;

use App\Core\Jobs\TenantAwareJob;
use App\Domains\Notifications\Engine\NotificationDeliveryProcessor;
use App\Domains\Notifications\Models\NotificationDelivery;

final class DeliverNotificationJob extends TenantAwareJob
{
    public int $tries = 1;

    public function __construct(public readonly int $deliveryId)
    {
        parent::__construct();
    }

    protected function queueName(): string
    {
        return (string) config('gms.notifications.queue', 'notifications');
    }

    public function handle(NotificationDeliveryProcessor $processor): void
    {
        $delivery = NotificationDelivery::query()->withoutGlobalScopes()->find($this->deliveryId);
        if ($delivery !== null) {
            $this->tenantId = (int) $delivery->tenant_id;
        }

        $processor->process($this->deliveryId);
    }
}
