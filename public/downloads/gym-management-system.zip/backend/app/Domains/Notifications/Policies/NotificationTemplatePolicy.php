<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Notifications\Models\NotificationTemplate;

final class NotificationTemplatePolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'notifications.manage');
    }

    public function view(User $user, NotificationTemplate $template): bool
    {
        if (! $this->hasPermission($user, 'notifications.manage')) {
            return false;
        }

        if ($template->isSystemDefault()) {
            return true;
        }

        return $this->sameTenant($user, $template);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'notifications.manage');
    }

    public function update(User $user, NotificationTemplate $template): bool
    {
        return $this->hasPermission($user, 'notifications.manage')
            && ! $template->isSystemDefault()
            && $this->sameTenant($user, $template);
    }

    public function delete(User $user, NotificationTemplate $template): bool
    {
        return $this->update($user, $template);
    }
}
