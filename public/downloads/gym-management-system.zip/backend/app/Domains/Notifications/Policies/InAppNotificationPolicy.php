<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Notifications\Models\InAppNotification;

final class InAppNotificationPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'notifications.view');
    }

    public function view(User $user, InAppNotification $notification): bool
    {
        return $this->hasPermission($user, 'notifications.view')
            && $this->sameTenant($user, $notification)
            && (int) $user->id === (int) $notification->user_id;
    }

    public function markRead(User $user, InAppNotification $notification): bool
    {
        return $this->view($user, $notification);
    }

    public function send(User $user): bool
    {
        return $this->hasPermission($user, 'notifications.send');
    }
}
