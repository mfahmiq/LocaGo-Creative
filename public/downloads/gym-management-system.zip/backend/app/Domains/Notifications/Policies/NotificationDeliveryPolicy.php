<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Notifications\Models\NotificationDelivery;

final class NotificationDeliveryPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'notifications.view');
    }

    public function view(User $user, NotificationDelivery $delivery): bool
    {
        return $this->hasPermission($user, 'notifications.view')
            && $this->sameTenant($user, $delivery);
    }
}
