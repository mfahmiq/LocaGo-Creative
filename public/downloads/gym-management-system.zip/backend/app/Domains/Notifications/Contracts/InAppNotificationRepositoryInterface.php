<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Contracts;

use App\Domains\Notifications\Models\InAppNotification;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface InAppNotificationRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForUser(int $tenantId, int $userId, array $filters = []): LengthAwarePaginator;

    public function findForUser(int $tenantId, int $userId, int $notificationId): ?InAppNotification;

    public function unreadCountForUser(int $tenantId, int $userId): int;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createNotification(array $attributes): InAppNotification;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateNotification(InAppNotification $notification, array $attributes): InAppNotification;
}
