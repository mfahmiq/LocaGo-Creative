<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Contracts;

use App\Domains\Notifications\Models\NotificationTemplate;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface NotificationTemplateRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $templateId): ?NotificationTemplate;

    public function findOwnedForTenant(int $tenantId, int $templateId): ?NotificationTemplate;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createTemplate(array $attributes): NotificationTemplate;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateTemplate(NotificationTemplate $template, array $attributes): NotificationTemplate;

    public function deleteTemplate(NotificationTemplate $template): bool;

    public function findActiveForEventChannel(int $tenantId, string $eventKey, string $channel): ?NotificationTemplate;
}
