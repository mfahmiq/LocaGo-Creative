<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Contracts;

use App\Domains\Notifications\Models\NotificationDelivery;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface NotificationDeliveryRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createDelivery(array $attributes): NotificationDelivery;

    public function findByIdempotencyKey(int $tenantId, string $idempotencyKey): ?NotificationDelivery;

    public function findDelivery(int $deliveryId): ?NotificationDelivery;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateDelivery(NotificationDelivery $delivery, array $attributes): NotificationDelivery;

    /**
     * @return list<NotificationDelivery>
     */
    public function findDueForRetry(int $limit = 100): array;

    /**
     * @return list<NotificationDelivery>
     */
    public function findDueScheduled(int $limit = 100): array;
}
