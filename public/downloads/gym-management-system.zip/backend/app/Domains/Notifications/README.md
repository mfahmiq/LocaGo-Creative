﻿# Notifications Domain — Centralized Engine

## Channels

| Channel | Status |
| --- | --- |
| `in_app` | Live — writes `notifications` inbox rows |
| `email` | Live — delivery log + fake/SMTP-ready provider |
| `whatsapp` | Live — requires `members.whatsapp_opt_in` + phone |
| `push` | Stub — reserved for FCM/APNs |

## Events (`NotificationEventCatalog`)

- `member.registered` — New Registration  
- `membership.activated` — Membership Activated  
- `membership.expiring` — Membership Expiring  
- `membership.expired` — Membership Expired  
- `payment.successful` / `payment.failed`  
- `class.reminder`  
- `member.birthday`  
- `training.pt_reminder`

## Engine entry point

```php
app(NotificationEngine::class)->notify($tenant, 'membership.expiring', [
    'member_ids' => [$memberId],
    'channels' => ['in_app', 'email', 'whatsapp'],
    'payload' => ['end_date' => '2026-08-01', 'days_remaining' => 7],
    'idempotency_prefix' => 'membership:123:membership.expiring:t7:2026-07-25',
    'scheduled_for' => null, // or Carbon for delayed send
    'queue' => true,
]);
```

Flow: resolve template → respect preferences → create `notification_deliveries` (`queued`) → `DeliverNotificationJob` → channel adapter → `sent` / `failed` + retry schedule.

## Templates

System defaults seeded by `NotificationTemplateSeeder` (`tenant_id = null`).  
Placeholders: `{{member_first_name}}`, `{{end_date}}`, `{{days_remaining}}`, `{{plan_name}}`, `{{gym_name}}`, …

Admin CRUD: `/api/v1/admin/notification-templates`

## Queue / retry / scheduling

- Queue name: `gms.queues.notifications` / `gms.notifications.queue`
- Job: `DeliverNotificationJob`
- Retry backoff: `gms.notifications.retry.backoff_seconds`
- Scheduler: `gms:process-notification-deliveries` every 5 minutes (due scheduled + failed retries)
- Membership reminders: `gms:membership-reminders` daily 09:00  
  Offsets: `reminder_offsets_days` (default 30/15/7/3/1) + `post_expiry_reminder_offsets_days` (1/3/7)

## Logs & delivery status

Table `notification_deliveries`: `queued|sent|failed`, `attempts`, `max_attempts`, `next_retry_at`, `scheduled_for`, `idempotency_key`.  
Admin list: `GET /api/v1/admin/notification-deliveries`

## Preferences

Table `notification_preferences` (per member/user, event, channel).  
Engine skips disabled channels.

## Membership renewal reminder surfaces

1. **Member notification center** — in-app rows for `membership.expiring` / `membership.expired`  
2. **Member dashboard** — `GET /api/v1/member/memberships/renewal-alerts` banner until renewed  
3. **WhatsApp** — automatic via engine on configured offsets when opted in
