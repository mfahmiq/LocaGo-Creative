<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Notifications\Contracts\NotificationTemplateRepositoryInterface;
use App\Domains\Notifications\Models\NotificationTemplate;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\QueryException;
use Symfony\Component\HttpFoundation\Response;

final class UpdateNotificationTemplateAction extends Action
{
    public function __construct(
        private readonly NotificationTemplateRepositoryInterface $templates,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): NotificationTemplate
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $templateId */
        $templateId = $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        $template = $this->templates->findOwnedForTenant($tenant->id, $templateId);
        if ($template === null) {
            throw new DomainException('Notification template not found.', 'notification_template_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($template->isSystemDefault()) {
            throw new DomainException('System default templates are read-only.', 'notification_template_read_only', Response::HTTP_FORBIDDEN);
        }

        $attributes = [];
        foreach (['event_key', 'subject', 'body', 'is_active'] as $field) {
            if (array_key_exists($field, $data)) {
                $attributes[$field] = $data[$field];
            }
        }

        if (array_key_exists('channel', $data)) {
            $channel = (string) $data['channel'];
            if (! in_array($channel, [
                NotificationTemplate::CHANNEL_EMAIL,
                NotificationTemplate::CHANNEL_IN_APP,
                NotificationTemplate::CHANNEL_WHATSAPP,
                NotificationTemplate::CHANNEL_PUSH,
            ], true)) {
                throw new DomainException('Invalid notification channel.', 'invalid_notification_channel', Response::HTTP_UNPROCESSABLE_ENTITY);
            }
            $attributes['channel'] = $channel;
        }

        try {
            $template = $this->templates->updateTemplate($template, $attributes);
        } catch (QueryException) {
            throw new DomainException(
                'A template already exists for this event and channel.',
                'notification_template_duplicate',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $this->audit->write(
            action: 'notification_template.updated',
            entityType: 'notification_template',
            entityId: $template->id,
            tenantId: $tenant->id,
            newValues: [
                'event_key' => $template->event_key,
                'channel' => $template->channel,
                'is_active' => $template->is_active,
            ]
        );

        return $template;
    }
}
