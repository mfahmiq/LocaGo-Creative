<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Notifications\Contracts\NotificationTemplateRepositoryInterface;
use App\Domains\Notifications\Models\NotificationTemplate;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\QueryException;
use Symfony\Component\HttpFoundation\Response;

final class CreateNotificationTemplateAction extends Action
{
    public function __construct(
        private readonly NotificationTemplateRepositoryInterface $templates,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): NotificationTemplate
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        $channel = (string) $data['channel'];
        $this->assertValidChannel($channel);

        try {
            $template = $this->templates->createTemplate([
                'tenant_id' => $tenant->id,
                'event_key' => (string) $data['event_key'],
                'channel' => $channel,
                'subject' => $data['subject'] ?? null,
                'body' => (string) $data['body'],
                'is_active' => (bool) ($data['is_active'] ?? true),
            ]);
        } catch (QueryException) {
            throw new DomainException(
                'A template already exists for this event and channel.',
                'notification_template_duplicate',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $this->audit->write(
            action: 'notification_template.created',
            entityType: 'notification_template',
            entityId: $template->id,
            tenantId: $tenant->id,
            newValues: [
                'event_key' => $template->event_key,
                'channel' => $template->channel,
                'is_active' => $template->is_active,
            ]
        );

        return $template;
    }

    private function assertValidChannel(string $channel): void
    {
        if (! in_array($channel, [
            NotificationTemplate::CHANNEL_EMAIL,
            NotificationTemplate::CHANNEL_IN_APP,
            NotificationTemplate::CHANNEL_WHATSAPP,
            NotificationTemplate::CHANNEL_PUSH,
        ], true)) {
            throw new DomainException('Invalid notification channel.', 'invalid_notification_channel', Response::HTTP_UNPROCESSABLE_ENTITY);
        }
    }
}
