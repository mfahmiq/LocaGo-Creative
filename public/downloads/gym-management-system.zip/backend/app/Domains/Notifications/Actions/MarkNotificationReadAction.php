<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Notifications\Contracts\InAppNotificationRepositoryInterface;
use App\Domains\Notifications\Models\InAppNotification;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class MarkNotificationReadAction extends Action
{
    public function __construct(
        private readonly InAppNotificationRepositoryInterface $notifications
    ) {}

    public function execute(mixed ...$args): InAppNotification
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $userId */
        $userId = $args[1];
        /** @var int $notificationId */
        $notificationId = $args[2];

        $notification = $this->notifications->findForUser($tenant->id, $userId, $notificationId);
        if ($notification === null) {
            throw new DomainException('Notification not found.', 'notification_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($notification->isRead()) {
            return $notification;
        }

        return $this->notifications->updateNotification($notification, [
            'read_at' => now(),
        ]);
    }
}
