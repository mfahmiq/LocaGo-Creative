<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Identity\Contracts\UserRepositoryInterface;
use App\Domains\Identity\Models\User;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Notifications\Contracts\InAppNotificationRepositoryInterface;
use App\Domains\Notifications\Contracts\NotificationDeliveryRepositoryInterface;
use App\Domains\Notifications\Models\InAppNotification;
use App\Domains\Notifications\Models\NotificationDelivery;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

final class SendNotificationAction extends Action
{
    public function __construct(
        private readonly InAppNotificationRepositoryInterface $notifications,
        private readonly NotificationDeliveryRepositoryInterface $deliveries,
        private readonly UserRepositoryInterface $users,
        private readonly MemberRepositoryInterface $members,
        private readonly AuditWriter $audit
    ) {}

    /**
     * @return array{notifications: list<InAppNotification>, deliveries: list<NotificationDelivery>}
     */
    public function execute(mixed ...$args): array
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        return $this->transaction(function () use ($tenant, $data): array {
            $targets = $this->resolveTargets($tenant, $data);
            $channels = $this->resolveChannels($data);
            $eventKey = (string) $data['event_key'];
            $title = (string) $data['title'];
            $body = (string) $data['body'];
            $dataJson = $data['data_json'] ?? null;

            $createdNotifications = [];
            $createdDeliveries = [];

            foreach ($targets as $target) {
                $inAppNotification = null;

                if (in_array(NotificationDelivery::CHANNEL_IN_APP, $channels, true)) {
                    $inAppNotification = $this->notifications->createNotification([
                        'tenant_id' => $tenant->id,
                        'user_id' => $target->id,
                        'event_key' => $eventKey,
                        'title' => $title,
                        'body' => $body,
                        'data_json' => $dataJson,
                        'read_at' => null,
                    ]);
                    $createdNotifications[] = $inAppNotification;
                }

                if (in_array(NotificationDelivery::CHANNEL_EMAIL, $channels, true)) {
                    $createdDeliveries[] = $this->deliveries->createDelivery([
                        'tenant_id' => $tenant->id,
                        'notification_id' => $inAppNotification?->id,
                        'user_id' => $target->id,
                        'channel' => NotificationDelivery::CHANNEL_EMAIL,
                        'recipient' => $target->email,
                        'event_key' => $eventKey,
                        'status' => NotificationDelivery::STATUS_SENT,
                        'provider_message_id' => 'fake-'.(string) Str::uuid(),
                        'error_message' => null,
                        'sent_at' => now(),
                    ]);
                }

                if (in_array(NotificationDelivery::CHANNEL_WHATSAPP, $channels, true)) {
                    $whatsapp = $this->resolveWhatsappRecipient($tenant, $target);
                    if ($whatsapp === null) {
                        $createdDeliveries[] = $this->deliveries->createDelivery([
                            'tenant_id' => $tenant->id,
                            'notification_id' => $inAppNotification?->id,
                            'user_id' => $target->id,
                            'channel' => NotificationDelivery::CHANNEL_WHATSAPP,
                            'recipient' => 'unresolved',
                            'event_key' => $eventKey,
                            'status' => NotificationDelivery::STATUS_FAILED,
                            'provider_message_id' => null,
                            'error_message' => 'Member has no WhatsApp opt-in or phone.',
                            'sent_at' => null,
                        ]);
                    } else {
                        $createdDeliveries[] = $this->deliveries->createDelivery([
                            'tenant_id' => $tenant->id,
                            'notification_id' => $inAppNotification?->id,
                            'user_id' => $target->id,
                            'channel' => NotificationDelivery::CHANNEL_WHATSAPP,
                            'recipient' => $whatsapp,
                            'event_key' => $eventKey,
                            'status' => NotificationDelivery::STATUS_SENT,
                            'provider_message_id' => 'fake-wa-'.(string) Str::uuid(),
                            'error_message' => null,
                            'sent_at' => now(),
                        ]);
                    }
                }
            }

            $this->audit->write(
                action: 'notification.sent',
                entityType: 'notification',
                entityId: $createdNotifications[0]->id ?? ($createdDeliveries[0]->id ?? 0),
                tenantId: $tenant->id,
                newValues: [
                    'event_key' => $eventKey,
                    'recipient_count' => count($targets),
                    'channels' => $channels,
                ]
            );

            return [
                'notifications' => $createdNotifications,
                'deliveries' => $createdDeliveries,
            ];
        });
    }

    /**
     * @param  array<string, mixed>  $data
     * @return list<User>
     */
    private function resolveTargets(Tenant $tenant, array $data): array
    {
        $targets = [];
        $seen = [];

        $userIds = array_map('intval', $data['user_ids'] ?? []);
        foreach ($userIds as $userId) {
            if ($userId <= 0 || isset($seen[$userId])) {
                continue;
            }

            $user = $this->users->findStaffByIdForTenant($tenant->id, $userId)
                ?? $this->users->findMemberByIdForTenant($tenant->id, $userId);

            if ($user === null) {
                throw new DomainException('Recipient user not found.', 'notification_recipient_not_found', Response::HTTP_NOT_FOUND);
            }

            $seen[$userId] = true;
            $targets[] = $user;
        }

        $memberIds = array_map('intval', $data['member_ids'] ?? []);
        foreach ($memberIds as $memberId) {
            if ($memberId <= 0) {
                continue;
            }

            $member = $this->members->findForTenant($tenant->id, $memberId);
            if ($member === null) {
                throw new DomainException('Member not found.', 'member_not_found', Response::HTTP_NOT_FOUND);
            }

            if ($member->user_id === null) {
                throw new DomainException('Member has no linked user account.', 'member_user_not_linked', Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $userId = (int) $member->user_id;
            if (isset($seen[$userId])) {
                continue;
            }

            $user = $this->users->findMemberByIdForTenant($tenant->id, $userId);
            if ($user === null) {
                throw new DomainException('Member user not found.', 'member_user_not_found', Response::HTTP_NOT_FOUND);
            }

            $seen[$userId] = true;
            $targets[] = $user;
        }

        if ($targets === []) {
            throw new DomainException('At least one recipient is required.', 'notification_recipients_required', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        return $targets;
    }

    /**
     * @param  array<string, mixed>  $data
     * @return list<string>
     */
    private function resolveChannels(array $data): array
    {
        $channels = $data['channels'] ?? [NotificationDelivery::CHANNEL_IN_APP];
        if (! is_array($channels) || $channels === []) {
            $channels = [NotificationDelivery::CHANNEL_IN_APP];
        }

        $valid = [];
        foreach ($channels as $channel) {
            $channel = (string) $channel;
            if (! in_array($channel, [
                NotificationDelivery::CHANNEL_IN_APP,
                NotificationDelivery::CHANNEL_EMAIL,
                NotificationDelivery::CHANNEL_WHATSAPP,
            ], true)) {
                throw new DomainException('Invalid notification channel.', 'invalid_notification_channel', Response::HTTP_UNPROCESSABLE_ENTITY);
            }
            $valid[$channel] = $channel;
        }

        return array_values($valid);
    }

    private function resolveWhatsappRecipient(Tenant $tenant, User $user): ?string
    {
        $member = $this->members->findByUserId($tenant->id, (int) $user->id);
        if ($member === null) {
            return null;
        }

        return $member->whatsappRecipient();
    }
}
