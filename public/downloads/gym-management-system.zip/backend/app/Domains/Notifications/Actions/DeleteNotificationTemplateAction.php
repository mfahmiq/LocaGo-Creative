<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Notifications\Contracts\NotificationTemplateRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeleteNotificationTemplateAction extends Action
{
    public function __construct(
        private readonly NotificationTemplateRepositoryInterface $templates,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $templateId */
        $templateId = $args[1];

        $template = $this->templates->findOwnedForTenant($tenant->id, $templateId);
        if ($template === null) {
            throw new DomainException('Notification template not found.', 'notification_template_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($template->isSystemDefault()) {
            throw new DomainException('System default templates are read-only.', 'notification_template_read_only', Response::HTTP_FORBIDDEN);
        }

        $this->templates->deleteTemplate($template);

        $this->audit->write(
            action: 'notification_template.deleted',
            entityType: 'notification_template',
            entityId: $template->id,
            tenantId: $tenant->id,
            oldValues: [
                'event_key' => $template->event_key,
                'channel' => $template->channel,
            ]
        );

        return true;
    }
}
