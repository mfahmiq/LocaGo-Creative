<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Models;

use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class NotificationDelivery extends Model
{
    use BelongsToTenant;

    public const STATUS_QUEUED = 'queued';

    public const STATUS_SENT = 'sent';

    public const STATUS_FAILED = 'failed';

    public const CHANNEL_EMAIL = 'email';

    public const CHANNEL_IN_APP = 'in_app';

    public const CHANNEL_WHATSAPP = 'whatsapp';

    public const CHANNEL_PUSH = 'push';

    /** @var list<string> */
    public const CHANNELS = [
        self::CHANNEL_EMAIL,
        self::CHANNEL_IN_APP,
        self::CHANNEL_WHATSAPP,
        self::CHANNEL_PUSH,
    ];

    protected $table = 'notification_deliveries';

    protected $dateFormat = 'Y-m-d H:i:s.v';

    protected $fillable = [
        'tenant_id',
        'notification_id',
        'user_id',
        'member_id',
        'channel',
        'recipient',
        'event_key',
        'status',
        'attempts',
        'max_attempts',
        'next_retry_at',
        'scheduled_for',
        'idempotency_key',
        'provider_message_id',
        'error_message',
        'sent_at',
    ];

    protected function casts(): array
    {
        return [
            'sent_at' => 'datetime',
            'next_retry_at' => 'datetime',
            'scheduled_for' => 'datetime',
            'attempts' => 'integer',
            'max_attempts' => 'integer',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function notification(): BelongsTo
    {
        return $this->belongsTo(InAppNotification::class, 'notification_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
