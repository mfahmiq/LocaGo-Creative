<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Identity\Models\User;
use App\Domains\Members\Models\Member;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class NotificationPreference extends BaseModel
{
    use BelongsToTenant;

    protected $table = 'notification_preferences';

    protected $fillable = [
        'tenant_id',
        'user_id',
        'member_id',
        'event_key',
        'channel',
        'is_enabled',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'is_enabled' => 'boolean',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function member(): BelongsTo
    {
        return $this->belongsTo(Member::class);
    }
}
