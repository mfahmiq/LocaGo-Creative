<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Models;

use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class InAppNotification extends Model
{
    use BelongsToTenant;
    use SoftDeletes;

    public $timestamps = true;

    protected $dateFormat = 'Y-m-d H:i:s.v';

    protected $table = 'notifications';

    protected $fillable = [
        'tenant_id',
        'user_id',
        'event_key',
        'title',
        'body',
        'data_json',
        'read_at',
    ];

    protected function casts(): array
    {
        return [
            'data_json' => 'array',
            'read_at' => 'datetime',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function isRead(): bool
    {
        return $this->read_at !== null;
    }
}
