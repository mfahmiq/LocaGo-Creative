<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Models;

use App\Core\Models\BaseModel;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class NotificationTemplate extends BaseModel
{
    public const CHANNEL_EMAIL = 'email';

    public const CHANNEL_IN_APP = 'in_app';

    public const CHANNEL_WHATSAPP = 'whatsapp';

    public const CHANNEL_PUSH = 'push';

    protected $table = 'notification_templates';

    protected $fillable = [
        'tenant_id',
        'event_key',
        'channel',
        'subject',
        'body',
        'is_active',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function isSystemDefault(): bool
    {
        return $this->tenant_id === null;
    }
}
