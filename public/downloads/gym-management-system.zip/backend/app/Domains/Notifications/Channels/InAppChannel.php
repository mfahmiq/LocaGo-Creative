<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Channels;

use App\Domains\Notifications\Contracts\InAppNotificationRepositoryInterface;
use App\Domains\Notifications\Models\NotificationDelivery;

final class InAppChannel implements NotificationChannelInterface
{
    public function __construct(
        private readonly InAppNotificationRepositoryInterface $notifications
    ) {}

    public function key(): string
    {
        return NotificationDelivery::CHANNEL_IN_APP;
    }

    public function send(array $message): array
    {
        $delivery = $message['delivery'];
        $tenant = $message['tenant'];

        if ($delivery->user_id === null) {
            return [
                'status' => NotificationDelivery::STATUS_FAILED,
                'error_message' => 'In-app notification requires a linked user account.',
            ];
        }

        $notification = $this->notifications->createNotification([
            'tenant_id' => $tenant->id,
            'user_id' => $delivery->user_id,
            'event_key' => $delivery->event_key,
            'title' => $message['title'],
            'body' => $message['body'],
            'data_json' => $message['payload'] ?? null,
            'read_at' => null,
        ]);

        return [
            'status' => NotificationDelivery::STATUS_SENT,
            'provider_message_id' => 'in-app-'.$notification->id,
            'notification_id' => $notification->id,
        ];
    }
}
