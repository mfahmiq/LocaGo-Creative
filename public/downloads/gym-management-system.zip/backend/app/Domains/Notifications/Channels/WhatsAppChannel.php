<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Channels;

use App\Domains\Notifications\Models\NotificationDelivery;
use Illuminate\Support\Str;

final class WhatsAppChannel implements NotificationChannelInterface
{
    public function key(): string
    {
        return NotificationDelivery::CHANNEL_WHATSAPP;
    }

    public function send(array $message): array
    {
        $provider = (string) config('gms.notifications.providers.whatsapp', 'fake');
        $recipient = (string) $message['delivery']->recipient;

        if ($recipient === '' || $recipient === 'unresolved') {
            return [
                'status' => NotificationDelivery::STATUS_FAILED,
                'error_message' => 'WhatsApp recipient missing or member not opted in.',
            ];
        }

        if ($provider === 'disabled') {
            return [
                'status' => NotificationDelivery::STATUS_FAILED,
                'error_message' => 'WhatsApp provider is disabled.',
            ];
        }

        // Fake provider. Replace with Meta Cloud API adapter.
        return [
            'status' => NotificationDelivery::STATUS_SENT,
            'provider_message_id' => 'fake-wa-'.(string) Str::uuid(),
        ];
    }
}
