<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Channels;

use App\Domains\Notifications\Models\NotificationDelivery;
use App\Domains\Tenancy\Models\Tenant;

interface NotificationChannelInterface
{
    public function key(): string;

    /**
     * @param  array{
     *   delivery: NotificationDelivery,
     *   tenant: Tenant,
     *   title: string,
     *   body: string,
     *   subject?: string|null,
     *   payload?: array<string, mixed>
     * }  $message
     * @return array{status: string, provider_message_id?: string|null, error_message?: string|null, notification_id?: int|null}
     */
    public function send(array $message): array;
}
