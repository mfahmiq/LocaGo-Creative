<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Channels;

use App\Domains\Mobile\Models\DeviceToken;
use App\Domains\Notifications\Models\NotificationDelivery;
use Illuminate\Support\Facades\Log;

/**
 * Push channel (FCM / APNs / HMS).
 *
 * When provider=log, tokens are resolved and logged so mobile registration
 * can be verified without a production push vendor.
 * Wire a real adapter when GMS_NOTIFICATION_PUSH_PROVIDER=fcm|apns.
 */
final class PushChannel implements NotificationChannelInterface
{
    public function key(): string
    {
        return NotificationDelivery::CHANNEL_PUSH;
    }

    public function send(array $message): array
    {
        $provider = (string) config('gms.notifications.providers.push', 'disabled');

        if ($provider === 'disabled') {
            return [
                'status' => NotificationDelivery::STATUS_FAILED,
                'error_message' => 'Push notifications are not configured yet.',
            ];
        }

        $tenantId = isset($message['tenant_id']) ? (int) $message['tenant_id'] : null;
        $userId = isset($message['user_id']) ? (int) $message['user_id'] : null;
        $tokens = [];

        if ($tenantId && $userId) {
            $tokens = DeviceToken::query()
                ->where('tenant_id', $tenantId)
                ->where('user_id', $userId)
                ->where('is_active', true)
                ->pluck('token')
                ->map(fn ($t) => (string) $t)
                ->all();
        }

        if ($tokens === []) {
            return [
                'status' => NotificationDelivery::STATUS_FAILED,
                'error_message' => 'No active device tokens for recipient.',
            ];
        }

        if ($provider === 'log') {
            Log::info('push.notification.dispatch', [
                'provider' => $provider,
                'tenant_id' => $tenantId,
                'user_id' => $userId,
                'token_count' => count($tokens),
                'title' => $message['title'] ?? null,
                'body' => $message['body'] ?? null,
            ]);

            return [
                'status' => NotificationDelivery::STATUS_SENT,
                'provider_message_id' => 'log-'.uniqid('', true),
            ];
        }

        return [
            'status' => NotificationDelivery::STATUS_FAILED,
            'error_message' => "Push provider adapter [{$provider}] is not implemented yet. Registered tokens: ".count($tokens),
        ];
    }
}
