<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Channels;

use App\Domains\Notifications\Models\NotificationDelivery;
use Illuminate\Support\Str;

final class EmailChannel implements NotificationChannelInterface
{
    public function key(): string
    {
        return NotificationDelivery::CHANNEL_EMAIL;
    }

    public function send(array $message): array
    {
        $provider = (string) config('gms.notifications.providers.email', 'fake');

        if ($provider === 'disabled') {
            return [
                'status' => NotificationDelivery::STATUS_FAILED,
                'error_message' => 'Email provider is disabled.',
            ];
        }

        // Fake provider records success. Swap with SMTP/SES/Mailgun adapter later.
        return [
            'status' => NotificationDelivery::STATUS_SENT,
            'provider_message_id' => 'fake-email-'.(string) Str::uuid(),
        ];
    }
}
