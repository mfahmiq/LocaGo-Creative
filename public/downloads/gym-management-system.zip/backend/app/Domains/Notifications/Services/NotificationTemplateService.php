<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Notifications\Actions\CreateNotificationTemplateAction;
use App\Domains\Notifications\Actions\DeleteNotificationTemplateAction;
use App\Domains\Notifications\Actions\UpdateNotificationTemplateAction;
use App\Domains\Notifications\Contracts\NotificationTemplateRepositoryInterface;
use App\Domains\Notifications\Models\NotificationTemplate;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class NotificationTemplateService extends BaseService
{
    public function __construct(
        private readonly NotificationTemplateRepositoryInterface $templates,
        private readonly CreateNotificationTemplateAction $createNotificationTemplateAction,
        private readonly UpdateNotificationTemplateAction $updateNotificationTemplateAction,
        private readonly DeleteNotificationTemplateAction $deleteNotificationTemplateAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->templates->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $templateId): NotificationTemplate
    {
        $template = $this->templates->findForTenant($tenant->id, $templateId);

        if ($template === null) {
            throw new DomainException('Notification template not found.', 'notification_template_not_found', Response::HTTP_NOT_FOUND);
        }

        return $template;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): NotificationTemplate
    {
        return $this->createNotificationTemplateAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $templateId, array $data): NotificationTemplate
    {
        return $this->updateNotificationTemplateAction->execute($tenant, $templateId, $data);
    }

    public function delete(Tenant $tenant, int $templateId): void
    {
        $this->deleteNotificationTemplateAction->execute($tenant, $templateId);
    }
}
