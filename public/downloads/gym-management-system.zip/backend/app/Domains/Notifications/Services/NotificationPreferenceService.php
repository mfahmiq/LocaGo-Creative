<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Services;

use App\Domains\Notifications\Models\NotificationDelivery;
use App\Domains\Notifications\Models\NotificationPreference;
use App\Domains\Notifications\Support\NotificationEventCatalog;
use App\Domains\Tenancy\Models\Tenant;

final class NotificationPreferenceService
{
    /**
     * @return list<array{event_key: string, channel: string, is_enabled: bool}>
     */
    public function listForMember(Tenant $tenant, int $memberId, ?int $userId): array
    {
        $defaults = [];
        foreach (NotificationEventCatalog::all() as $eventKey => $meta) {
            foreach ($meta['default_channels'] as $channel) {
                $defaults[] = [
                    'event_key' => $eventKey,
                    'channel' => $channel,
                    'is_enabled' => true,
                ];
            }
        }

        $prefs = NotificationPreference::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenant->id)
            ->whereNull('deleted_at')
            ->where(function ($q) use ($memberId, $userId): void {
                $q->where('member_id', $memberId);
                if ($userId !== null) {
                    $q->orWhere('user_id', $userId);
                }
            })
            ->get();

        $map = [];
        foreach ($defaults as $row) {
            $map[$row['event_key'].'|'.$row['channel']] = $row;
        }
        foreach ($prefs as $pref) {
            $map[$pref->event_key.'|'.$pref->channel] = [
                'event_key' => $pref->event_key,
                'channel' => $pref->channel,
                'is_enabled' => (bool) $pref->is_enabled,
            ];
        }

        return array_values($map);
    }

    /**
     * @param  list<array{event_key: string, channel: string, is_enabled: bool}>  $rows
     * @return list<array{event_key: string, channel: string, is_enabled: bool}>
     */
    public function syncForMember(Tenant $tenant, int $memberId, ?int $userId, array $rows): array
    {
        foreach ($rows as $row) {
            $eventKey = (string) ($row['event_key'] ?? '*');
            $channel = (string) ($row['channel'] ?? '');
            if (! in_array($channel, NotificationDelivery::CHANNELS, true)) {
                continue;
            }

            NotificationPreference::query()->updateOrCreate(
                [
                    'tenant_id' => $tenant->id,
                    'member_id' => $memberId,
                    'user_id' => $userId,
                    'event_key' => $eventKey,
                    'channel' => $channel,
                ],
                [
                    'is_enabled' => (bool) ($row['is_enabled'] ?? true),
                ]
            );
        }

        return $this->listForMember($tenant, $memberId, $userId);
    }
}
