<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Services;

use App\Core\Services\BaseService;
use App\Domains\Notifications\Contracts\NotificationDeliveryRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

final class NotificationDeliveryService extends BaseService
{
    public function __construct(
        private readonly NotificationDeliveryRepositoryInterface $deliveries
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->deliveries->paginateForTenant($tenant->id, $filters);
    }
}
