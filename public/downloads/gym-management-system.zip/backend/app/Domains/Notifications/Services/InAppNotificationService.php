<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Notifications\Actions\MarkNotificationReadAction;
use App\Domains\Notifications\Actions\SendNotificationAction;
use App\Domains\Notifications\Contracts\InAppNotificationRepositoryInterface;
use App\Domains\Notifications\Models\InAppNotification;
use App\Domains\Notifications\Models\NotificationDelivery;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class InAppNotificationService extends BaseService
{
    public function __construct(
        private readonly InAppNotificationRepositoryInterface $notifications,
        private readonly SendNotificationAction $sendNotificationAction,
        private readonly MarkNotificationReadAction $markNotificationReadAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateInbox(Tenant $tenant, int $userId, array $filters = []): LengthAwarePaginator
    {
        return $this->notifications->paginateForUser($tenant->id, $userId, $filters);
    }

    public function findInbox(Tenant $tenant, int $userId, int $notificationId): InAppNotification
    {
        $notification = $this->notifications->findForUser($tenant->id, $userId, $notificationId);

        if ($notification === null) {
            throw new DomainException('Notification not found.', 'notification_not_found', Response::HTTP_NOT_FOUND);
        }

        return $notification;
    }

    public function unreadCount(Tenant $tenant, int $userId): int
    {
        return $this->notifications->unreadCountForUser($tenant->id, $userId);
    }

    public function markRead(Tenant $tenant, int $userId, int $notificationId): InAppNotification
    {
        return $this->markNotificationReadAction->execute($tenant, $userId, $notificationId);
    }

    /**
     * @param  array<string, mixed>  $data
     * @return array{notifications: list<InAppNotification>, deliveries: list<NotificationDelivery>}
     */
    public function send(Tenant $tenant, array $data): array
    {
        return $this->sendNotificationAction->execute($tenant, $data);
    }
}
