<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Notifications\Contracts\NotificationDeliveryRepositoryInterface;
use App\Domains\Notifications\Models\NotificationDelivery;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<NotificationDelivery>
 */
class EloquentNotificationDeliveryRepository extends BaseRepository implements NotificationDeliveryRepositoryInterface
{
    public function __construct(NotificationDelivery $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['user', 'notification'])
            ->where('tenant_id', $tenantId)
            ->orderByDesc('created_at')
            ->orderByDesc('id');

        if (! empty($filters['status'])) {
            $query->where('status', (string) $filters['status']);
        }

        if (! empty($filters['channel'])) {
            $query->where('channel', (string) $filters['channel']);
        }

        if (! empty($filters['event_key'])) {
            $query->where('event_key', (string) $filters['event_key']);
        }

        if (! empty($filters['user_id'])) {
            $query->where('user_id', (int) $filters['user_id']);
        }

        return $query->paginate($perPage);
    }

    public function createDelivery(array $attributes): NotificationDelivery
    {
        /** @var NotificationDelivery $delivery */
        $delivery = $this->query()->withoutGlobalScopes()->create($attributes);

        return $delivery->load(['user', 'notification']);
    }

    public function findByIdempotencyKey(int $tenantId, string $idempotencyKey): ?NotificationDelivery
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('idempotency_key', $idempotencyKey)
            ->first();
    }

    public function findDelivery(int $deliveryId): ?NotificationDelivery
    {
        return $this->query()->withoutGlobalScopes()->where('id', $deliveryId)->first();
    }

    public function updateDelivery(NotificationDelivery $delivery, array $attributes): NotificationDelivery
    {
        $delivery->update($attributes);

        return $delivery->refresh();
    }

    public function findDueForRetry(int $limit = 100): array
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('status', NotificationDelivery::STATUS_FAILED)
            ->whereColumn('attempts', '<', 'max_attempts')
            ->whereNotNull('next_retry_at')
            ->where('next_retry_at', '<=', now())
            ->orderBy('next_retry_at')
            ->limit($limit)
            ->get()
            ->all();
    }

    public function findDueScheduled(int $limit = 100): array
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('status', NotificationDelivery::STATUS_QUEUED)
            ->whereNotNull('scheduled_for')
            ->where('scheduled_for', '<=', now())
            ->orderBy('scheduled_for')
            ->limit($limit)
            ->get()
            ->all();
    }
}
