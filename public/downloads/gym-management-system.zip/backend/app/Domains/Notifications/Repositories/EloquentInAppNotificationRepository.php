<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Notifications\Contracts\InAppNotificationRepositoryInterface;
use App\Domains\Notifications\Models\InAppNotification;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<InAppNotification>
 */
class EloquentInAppNotificationRepository extends BaseRepository implements InAppNotificationRepositoryInterface
{
    public function __construct(InAppNotification $model)
    {
        parent::__construct($model);
    }

    public function paginateForUser(int $tenantId, int $userId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['user'])
            ->where('tenant_id', $tenantId)
            ->where('user_id', $userId)
            ->whereNull('deleted_at')
            ->orderByDesc('created_at')
            ->orderByDesc('id');

        if (isset($filters['unread']) && filter_var($filters['unread'], FILTER_VALIDATE_BOOLEAN)) {
            $query->whereNull('read_at');
        }

        if (! empty($filters['event_key'])) {
            $query->where('event_key', (string) $filters['event_key']);
        }

        return $query->paginate($perPage);
    }

    public function findForUser(int $tenantId, int $userId, int $notificationId): ?InAppNotification
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['user'])
            ->where('tenant_id', $tenantId)
            ->where('user_id', $userId)
            ->where('id', $notificationId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function unreadCountForUser(int $tenantId, int $userId): int
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('user_id', $userId)
            ->whereNull('read_at')
            ->whereNull('deleted_at')
            ->count();
    }

    public function createNotification(array $attributes): InAppNotification
    {
        /** @var InAppNotification $notification */
        $notification = $this->query()->withoutGlobalScopes()->create($attributes);

        return $notification->load(['user']);
    }

    public function updateNotification(InAppNotification $notification, array $attributes): InAppNotification
    {
        $notification->update($attributes);

        return $notification->fresh(['user']);
    }
}
