<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Notifications\Contracts\NotificationTemplateRepositoryInterface;
use App\Domains\Notifications\Models\NotificationTemplate;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<NotificationTemplate>
 */
class EloquentNotificationTemplateRepository extends BaseRepository implements NotificationTemplateRepositoryInterface
{
    public function __construct(NotificationTemplate $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->where(function ($q) use ($tenantId): void {
                $q->where('tenant_id', $tenantId)
                    ->orWhereNull('tenant_id');
            })
            ->whereNull('deleted_at')
            ->orderByRaw('CASE WHEN tenant_id IS NULL THEN 1 ELSE 0 END')
            ->orderBy('event_key')
            ->orderBy('channel');

        if (! empty($filters['event_key'])) {
            $query->where('event_key', (string) $filters['event_key']);
        }

        if (! empty($filters['channel'])) {
            $query->where('channel', (string) $filters['channel']);
        }

        if (isset($filters['is_active'])) {
            $query->where('is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN));
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $templateId): ?NotificationTemplate
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('id', $templateId)
            ->where(function ($q) use ($tenantId): void {
                $q->where('tenant_id', $tenantId)
                    ->orWhereNull('tenant_id');
            })
            ->whereNull('deleted_at')
            ->first();
    }

    public function findOwnedForTenant(int $tenantId, int $templateId): ?NotificationTemplate
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('id', $templateId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function createTemplate(array $attributes): NotificationTemplate
    {
        /** @var NotificationTemplate $template */
        $template = $this->query()->withoutGlobalScopes()->create($attributes);

        return $template;
    }

    public function updateTemplate(NotificationTemplate $template, array $attributes): NotificationTemplate
    {
        $template->update($attributes);

        return $template->refresh();
    }

    public function deleteTemplate(NotificationTemplate $template): bool
    {
        return (bool) $template->delete();
    }

    public function findActiveForEventChannel(int $tenantId, string $eventKey, string $channel): ?NotificationTemplate
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('event_key', $eventKey)
            ->where('channel', $channel)
            ->where('is_active', true)
            ->whereNull('deleted_at')
            ->where(function ($q) use ($tenantId): void {
                $q->where('tenant_id', $tenantId)->orWhereNull('tenant_id');
            })
            ->orderByRaw('CASE WHEN tenant_id IS NULL THEN 1 ELSE 0 END')
            ->first();
    }
}
