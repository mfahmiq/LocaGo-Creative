<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Support;

use App\Domains\Notifications\Models\NotificationDelivery;

/**
 * Canonical notification events and default channel matrix.
 */
final class NotificationEventCatalog
{
    public const NEW_REGISTRATION = 'member.registered';

    public const MEMBERSHIP_ACTIVATED = 'membership.activated';

    public const MEMBERSHIP_EXPIRING = 'membership.expiring';

    public const MEMBERSHIP_EXPIRED = 'membership.expired';

    public const PAYMENT_SUCCESSFUL = 'payment.successful';

    public const PAYMENT_FAILED = 'payment.failed';

    public const CLASS_REMINDER = 'class.reminder';

    public const BIRTHDAY_GREETING = 'member.birthday';

    public const PT_REMINDER = 'training.pt_reminder';

    /**
     * @return array<string, array{label: string, default_channels: list<string>, description: string}>
     */
    public static function all(): array
    {
        return [
            self::NEW_REGISTRATION => [
                'label' => 'New Registration',
                'description' => 'Triggered when a member account is created.',
                'default_channels' => [
                    NotificationDelivery::CHANNEL_IN_APP,
                    NotificationDelivery::CHANNEL_EMAIL,
                    NotificationDelivery::CHANNEL_WHATSAPP,
                ],
            ],
            self::MEMBERSHIP_ACTIVATED => [
                'label' => 'Membership Activated',
                'description' => 'Triggered when a membership becomes active.',
                'default_channels' => [
                    NotificationDelivery::CHANNEL_IN_APP,
                    NotificationDelivery::CHANNEL_EMAIL,
                    NotificationDelivery::CHANNEL_WHATSAPP,
                ],
            ],
            self::MEMBERSHIP_EXPIRING => [
                'label' => 'Membership Expiring',
                'description' => 'Scheduled reminder before membership end date.',
                'default_channels' => [
                    NotificationDelivery::CHANNEL_IN_APP,
                    NotificationDelivery::CHANNEL_EMAIL,
                    NotificationDelivery::CHANNEL_WHATSAPP,
                ],
            ],
            self::MEMBERSHIP_EXPIRED => [
                'label' => 'Membership Expired',
                'description' => 'Triggered on/after membership expiry.',
                'default_channels' => [
                    NotificationDelivery::CHANNEL_IN_APP,
                    NotificationDelivery::CHANNEL_EMAIL,
                    NotificationDelivery::CHANNEL_WHATSAPP,
                ],
            ],
            self::PAYMENT_SUCCESSFUL => [
                'label' => 'Payment Successful',
                'description' => 'Triggered when a payment is captured.',
                'default_channels' => [
                    NotificationDelivery::CHANNEL_IN_APP,
                    NotificationDelivery::CHANNEL_EMAIL,
                ],
            ],
            self::PAYMENT_FAILED => [
                'label' => 'Payment Failed',
                'description' => 'Triggered when a payment attempt fails.',
                'default_channels' => [
                    NotificationDelivery::CHANNEL_IN_APP,
                    NotificationDelivery::CHANNEL_EMAIL,
                    NotificationDelivery::CHANNEL_WHATSAPP,
                ],
            ],
            self::CLASS_REMINDER => [
                'label' => 'Class Reminder',
                'description' => 'Reminder before a booked class starts.',
                'default_channels' => [
                    NotificationDelivery::CHANNEL_IN_APP,
                    NotificationDelivery::CHANNEL_WHATSAPP,
                    NotificationDelivery::CHANNEL_PUSH,
                ],
            ],
            self::BIRTHDAY_GREETING => [
                'label' => 'Birthday Greeting',
                'description' => 'Member birthday greeting.',
                'default_channels' => [
                    NotificationDelivery::CHANNEL_IN_APP,
                    NotificationDelivery::CHANNEL_EMAIL,
                    NotificationDelivery::CHANNEL_WHATSAPP,
                ],
            ],
            self::PT_REMINDER => [
                'label' => 'Personal Training Reminder',
                'description' => 'Reminder before a PT session.',
                'default_channels' => [
                    NotificationDelivery::CHANNEL_IN_APP,
                    NotificationDelivery::CHANNEL_WHATSAPP,
                    NotificationDelivery::CHANNEL_PUSH,
                ],
            ],
        ];
    }

    public static function isKnown(string $eventKey): bool
    {
        return array_key_exists($eventKey, self::all());
    }

    /**
     * @return list<string>
     */
    public static function defaultChannels(string $eventKey): array
    {
        return self::all()[$eventKey]['default_channels']
            ?? config('gms.notifications.default_channels', ['in_app', 'email']);
    }
}
