<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Support;

final class TemplateRenderer
{
    /**
     * Replace {{key}} placeholders with payload values.
     *
     * @param  array<string, mixed>  $payload
     */
    public static function render(string $template, array $payload): string
    {
        return (string) preg_replace_callback(
            '/\{\{\s*([a-zA-Z0-9_.]+)\s*\}\}/',
            static function (array $matches) use ($payload): string {
                $key = $matches[1];
                $value = data_get($payload, $key);

                if ($value === null) {
                    return '';
                }

                if (is_bool($value)) {
                    return $value ? 'yes' : 'no';
                }

                if (is_scalar($value)) {
                    return (string) $value;
                }

                return '';
            },
            $template
        );
    }
}
