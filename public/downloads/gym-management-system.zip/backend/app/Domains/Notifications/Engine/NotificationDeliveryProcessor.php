<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Engine;

use App\Domains\Notifications\Channels\EmailChannel;
use App\Domains\Notifications\Channels\InAppChannel;
use App\Domains\Notifications\Channels\NotificationChannelInterface;
use App\Domains\Notifications\Channels\PushChannel;
use App\Domains\Notifications\Channels\WhatsAppChannel;
use App\Domains\Notifications\Contracts\NotificationDeliveryRepositoryInterface;
use App\Domains\Notifications\Models\NotificationDelivery;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Log;

final class NotificationDeliveryProcessor
{
    public function __construct(
        private readonly NotificationDeliveryRepositoryInterface $deliveries,
        private readonly NotificationEngine $engine,
        private readonly InAppChannel $inApp,
        private readonly EmailChannel $email,
        private readonly WhatsAppChannel $whatsApp,
        private readonly PushChannel $push
    ) {}

    public function process(int $deliveryId): NotificationDelivery
    {
        $delivery = $this->deliveries->findDelivery($deliveryId);
        if ($delivery === null) {
            throw new \RuntimeException('Notification delivery not found: '.$deliveryId);
        }

        if ($delivery->status === NotificationDelivery::STATUS_SENT) {
            return $delivery;
        }

        if ($delivery->scheduled_for !== null && $delivery->scheduled_for->isFuture()) {
            return $delivery;
        }

        $tenant = Tenant::query()->withoutGlobalScopes()->find($delivery->tenant_id);
        if ($tenant === null) {
            return $this->deliveries->updateDelivery($delivery, [
                'status' => NotificationDelivery::STATUS_FAILED,
                'error_message' => 'Tenant not found.',
                'attempts' => $delivery->attempts + 1,
            ]);
        }

        $content = cache()->get($this->engine->contentCacheKey($delivery->id), [
            'title' => 'Notification',
            'body' => 'You have a new notification.',
            'subject' => 'Notification',
            'payload' => [],
        ]);

        $channel = $this->resolveChannel((string) $delivery->channel);
        $attempts = (int) $delivery->attempts + 1;

        try {
            $result = $channel->send([
                'delivery' => $delivery,
                'tenant' => $tenant,
                'title' => (string) ($content['title'] ?? 'Notification'),
                'body' => (string) ($content['body'] ?? ''),
                'subject' => $content['subject'] ?? null,
                'payload' => is_array($content['payload'] ?? null) ? $content['payload'] : [],
            ]);
        } catch (\Throwable $e) {
            Log::error('notification.delivery.exception', [
                'delivery_id' => $delivery->id,
                'error' => $e->getMessage(),
            ]);
            $result = [
                'status' => NotificationDelivery::STATUS_FAILED,
                'error_message' => substr($e->getMessage(), 0, 255),
            ];
        }

        $status = (string) ($result['status'] ?? NotificationDelivery::STATUS_FAILED);
        $attributes = [
            'attempts' => $attempts,
            'status' => $status,
            'provider_message_id' => $result['provider_message_id'] ?? $delivery->provider_message_id,
            'error_message' => $result['error_message'] ?? null,
            'notification_id' => $result['notification_id'] ?? $delivery->notification_id,
        ];

        if ($status === NotificationDelivery::STATUS_SENT) {
            $attributes['sent_at'] = now();
            $attributes['next_retry_at'] = null;
        } else {
            $attributes['next_retry_at'] = $this->nextRetryAt($attempts, (int) $delivery->max_attempts);
            if ($attributes['next_retry_at'] === null) {
                $attributes['status'] = NotificationDelivery::STATUS_FAILED;
            } else {
                // Stay failed but eligible for retry command/job.
                $attributes['status'] = NotificationDelivery::STATUS_FAILED;
            }
        }

        return $this->deliveries->updateDelivery($delivery, $attributes);
    }

    private function resolveChannel(string $channel): NotificationChannelInterface
    {
        return match ($channel) {
            NotificationDelivery::CHANNEL_IN_APP => $this->inApp,
            NotificationDelivery::CHANNEL_EMAIL => $this->email,
            NotificationDelivery::CHANNEL_WHATSAPP => $this->whatsApp,
            NotificationDelivery::CHANNEL_PUSH => $this->push,
            default => throw new \InvalidArgumentException('Unknown notification channel: '.$channel),
        };
    }

    private function nextRetryAt(int $attempts, int $maxAttempts): ?\Carbon\CarbonInterface
    {
        if ($attempts >= $maxAttempts) {
            return null;
        }

        /** @var list<int> $backoff */
        $backoff = config('gms.notifications.retry.backoff_seconds', [60, 300, 900, 3600]);
        $seconds = $backoff[min($attempts - 1, count($backoff) - 1)] ?? 3600;

        return now()->addSeconds((int) $seconds);
    }
}
