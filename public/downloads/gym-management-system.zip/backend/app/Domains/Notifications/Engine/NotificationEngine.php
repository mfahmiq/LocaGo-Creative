<?php

declare(strict_types=1);

namespace App\Domains\Notifications\Engine;

use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Members\Models\Member;
use App\Domains\Notifications\Contracts\NotificationDeliveryRepositoryInterface;
use App\Domains\Notifications\Contracts\NotificationTemplateRepositoryInterface;
use App\Domains\Notifications\Jobs\DeliverNotificationJob;
use App\Domains\Notifications\Models\NotificationDelivery;
use App\Domains\Notifications\Models\NotificationPreference;
use App\Domains\Notifications\Support\NotificationEventCatalog;
use App\Domains\Notifications\Support\TemplateRenderer;
use App\Domains\Tenancy\Models\Tenant;
use Carbon\Carbon;
use Carbon\CarbonInterface;
use Illuminate\Support\Facades\Log;

final class NotificationEngine
{
    public function __construct(
        private readonly NotificationTemplateRepositoryInterface $templates,
        private readonly NotificationDeliveryRepositoryInterface $deliveries,
        private readonly MemberRepositoryInterface $members
    ) {}

    /**
     * Dispatch a catalog event to one or more recipients across channels.
     *
     * @param  array{
     *   member_ids?: list<int>,
     *   user_ids?: list<int>,
     *   channels?: list<string>|null,
     *   payload?: array<string, mixed>,
     *   title?: string|null,
     *   body?: string|null,
     *   subject?: string|null,
     *   idempotency_prefix?: string|null,
     *   scheduled_for?: CarbonInterface|string|null,
     *   queue?: bool
     * }  $options
     * @return list<NotificationDelivery>
     */
    public function notify(Tenant $tenant, string $eventKey, array $options = []): array
    {
        $channels = $options['channels'] ?? NotificationEventCatalog::defaultChannels($eventKey);
        $channels = array_values(array_unique(array_map('strval', $channels)));
        $payload = $options['payload'] ?? [];
        $queue = (bool) ($options['queue'] ?? true);
        $scheduledFor = $options['scheduled_for'] ?? null;
        if (is_string($scheduledFor) && $scheduledFor !== '') {
            $scheduledFor = Carbon::parse($scheduledFor);
        }

        $created = [];

        foreach ($options['member_ids'] ?? [] as $memberId) {
            $member = $this->members->findForTenant($tenant->id, (int) $memberId);
            if ($member === null) {
                continue;
            }
            foreach ($channels as $channel) {
                $delivery = $this->queueForMember(
                    tenant: $tenant,
                    eventKey: $eventKey,
                    channel: $channel,
                    member: $member,
                    payload: $payload,
                    title: $options['title'] ?? null,
                    body: $options['body'] ?? null,
                    subject: $options['subject'] ?? null,
                    idempotencyPrefix: $options['idempotency_prefix'] ?? null,
                    scheduledFor: $scheduledFor instanceof CarbonInterface ? $scheduledFor : null,
                    queue: $queue
                );
                if ($delivery !== null) {
                    $created[] = $delivery;
                }
            }
        }

        foreach ($options['user_ids'] ?? [] as $userId) {
            foreach ($channels as $channel) {
                $delivery = $this->queueForUser(
                    tenant: $tenant,
                    eventKey: $eventKey,
                    channel: $channel,
                    userId: (int) $userId,
                    memberId: null,
                    payload: $payload,
                    title: $options['title'] ?? null,
                    body: $options['body'] ?? null,
                    subject: $options['subject'] ?? null,
                    idempotencyPrefix: $options['idempotency_prefix'] ?? null,
                    scheduledFor: $scheduledFor instanceof CarbonInterface ? $scheduledFor : null,
                    queue: $queue
                );
                if ($delivery !== null) {
                    $created[] = $delivery;
                }
            }
        }

        return $created;
    }

    private function queueForMember(
        Tenant $tenant,
        string $eventKey,
        string $channel,
        Member $member,
        array $payload,
        ?string $title,
        ?string $body,
        ?string $subject,
        ?string $idempotencyPrefix,
        ?CarbonInterface $scheduledFor,
        bool $queue
    ): ?NotificationDelivery {
        if (! $this->channelEnabled($tenant->id, $eventKey, $channel, $member->user_id, $member->id)) {
            return null;
        }

        $recipient = $this->resolveRecipient($channel, $member, $member->user_id);
        if ($recipient === null) {
            return null;
        }

        return $this->createAndDispatch(
            tenant: $tenant,
            eventKey: $eventKey,
            channel: $channel,
            recipient: $recipient,
            userId: $member->user_id !== null ? (int) $member->user_id : null,
            memberId: (int) $member->id,
            payload: array_merge($payload, [
                'member_id' => $member->id,
                'member_first_name' => $member->first_name,
                'member_last_name' => $member->last_name,
                'member_email' => $member->email,
            ]),
            title: $title,
            body: $body,
            subject: $subject,
            idempotencyPrefix: $idempotencyPrefix,
            scheduledFor: $scheduledFor,
            queue: $queue
        );
    }

    private function queueForUser(
        Tenant $tenant,
        string $eventKey,
        string $channel,
        int $userId,
        ?int $memberId,
        array $payload,
        ?string $title,
        ?string $body,
        ?string $subject,
        ?string $idempotencyPrefix,
        ?CarbonInterface $scheduledFor,
        bool $queue
    ): ?NotificationDelivery {
        if (! $this->channelEnabled($tenant->id, $eventKey, $channel, $userId, $memberId)) {
            return null;
        }

        $member = $memberId !== null ? $this->members->findForTenant($tenant->id, $memberId) : null;
        $recipient = $this->resolveRecipient($channel, $member, $userId);
        if ($recipient === null) {
            return null;
        }

        return $this->createAndDispatch(
            tenant: $tenant,
            eventKey: $eventKey,
            channel: $channel,
            recipient: $recipient,
            userId: $userId,
            memberId: $memberId,
            payload: $payload,
            title: $title,
            body: $body,
            subject: $subject,
            idempotencyPrefix: $idempotencyPrefix,
            scheduledFor: $scheduledFor,
            queue: $queue
        );
    }

    /**
     * @param  array<string, mixed>  $payload
     */
    private function createAndDispatch(
        Tenant $tenant,
        string $eventKey,
        string $channel,
        string $recipient,
        ?int $userId,
        ?int $memberId,
        array $payload,
        ?string $title,
        ?string $body,
        ?string $subject,
        ?string $idempotencyPrefix,
        ?CarbonInterface $scheduledFor,
        bool $queue
    ): ?NotificationDelivery {
        $idempotencyKey = $idempotencyPrefix !== null
            ? substr($idempotencyPrefix.':'.$channel, 0, 190)
            : null;

        if ($idempotencyKey !== null) {
            $existing = $this->deliveries->findByIdempotencyKey($tenant->id, $idempotencyKey);
            if ($existing !== null) {
                return $existing;
            }
        }

        [$resolvedTitle, $resolvedBody, $resolvedSubject] = $this->resolveContent(
            tenantId: $tenant->id,
            eventKey: $eventKey,
            channel: $channel,
            payload: $payload,
            title: $title,
            body: $body,
            subject: $subject
        );

        $maxAttempts = (int) config('gms.notifications.retry.max_attempts', 5);

        try {
            $delivery = $this->deliveries->createDelivery([
                'tenant_id' => $tenant->id,
                'notification_id' => null,
                'user_id' => $userId,
                'member_id' => $memberId,
                'channel' => $channel,
                'recipient' => $recipient,
                'event_key' => $eventKey,
                'status' => NotificationDelivery::STATUS_QUEUED,
                'attempts' => 0,
                'max_attempts' => $maxAttempts,
                'next_retry_at' => null,
                'scheduled_for' => $scheduledFor,
                'idempotency_key' => $idempotencyKey,
                'provider_message_id' => null,
                'error_message' => null,
                'sent_at' => null,
            ]);
        } catch (\Throwable $e) {
            Log::warning('notification.engine.duplicate_or_create_failed', [
                'event_key' => $eventKey,
                'channel' => $channel,
                'error' => $e->getMessage(),
            ]);

            if ($idempotencyKey !== null) {
                return $this->deliveries->findByIdempotencyKey($tenant->id, $idempotencyKey);
            }

            return null;
        }

        // Persist rendered content on payload for the worker via temporary cache key on delivery id.
        cache()->put($this->contentCacheKey($delivery->id), [
            'title' => $resolvedTitle,
            'body' => $resolvedBody,
            'subject' => $resolvedSubject,
            'payload' => $payload,
        ], now()->addDays(7));

        $shouldDispatchNow = $scheduledFor === null || $scheduledFor->lessThanOrEqualTo(now());

        if ($queue && $shouldDispatchNow) {
            DeliverNotificationJob::dispatch($delivery->id)->onQueue(
                (string) config('gms.notifications.queue', 'notifications')
            );
        } elseif (! $queue && $shouldDispatchNow) {
            app(NotificationDeliveryProcessor::class)->process($delivery->id);
            $delivery = $this->deliveries->findDelivery($delivery->id) ?? $delivery;
        }

        return $delivery;
    }

    /**
     * @param  array<string, mixed>  $payload
     * @return array{0: string, 1: string, 2: string|null}
     */
    private function resolveContent(
        int $tenantId,
        string $eventKey,
        string $channel,
        array $payload,
        ?string $title,
        ?string $body,
        ?string $subject
    ): array {
        $template = $this->templates->findActiveForEventChannel($tenantId, $eventKey, $channel);

        $resolvedTitle = $title
            ?? ($template?->subject ? TemplateRenderer::render((string) $template->subject, $payload) : null)
            ?? (NotificationEventCatalog::all()[$eventKey]['label'] ?? 'Notification');

        $resolvedBody = $body
            ?? ($template ? TemplateRenderer::render((string) $template->body, $payload) : null)
            ?? 'You have a new notification.';

        $resolvedSubject = $subject
            ?? ($template?->subject ? TemplateRenderer::render((string) $template->subject, $payload) : $resolvedTitle);

        return [$resolvedTitle, $resolvedBody, $resolvedSubject];
    }

    private function channelEnabled(
        int $tenantId,
        string $eventKey,
        string $channel,
        ?int $userId,
        ?int $memberId
    ): bool {
        if (! in_array($channel, NotificationDelivery::CHANNELS, true)) {
            return false;
        }

        $query = NotificationPreference::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('channel', $channel)
            ->whereNull('deleted_at')
            ->where(function ($q) use ($eventKey): void {
                $q->where('event_key', $eventKey)->orWhere('event_key', '*');
            });

        if ($memberId !== null) {
            $query->where(function ($q) use ($memberId, $userId): void {
                $q->where('member_id', $memberId);
                if ($userId !== null) {
                    $q->orWhere('user_id', $userId);
                }
            });
        } elseif ($userId !== null) {
            $query->where('user_id', $userId);
        } else {
            return true;
        }

        $pref = $query
            ->orderByRaw("CASE WHEN event_key = ? THEN 0 ELSE 1 END", [$eventKey])
            ->first();

        if ($pref === null) {
            return true;
        }

        return (bool) $pref->is_enabled;
    }

    private function resolveRecipient(string $channel, ?Member $member, ?int $userId): ?string
    {
        return match ($channel) {
            NotificationDelivery::CHANNEL_IN_APP,
            NotificationDelivery::CHANNEL_PUSH => $userId !== null ? 'user:'.$userId : null,
            NotificationDelivery::CHANNEL_EMAIL => $member?->email ?: null,
            NotificationDelivery::CHANNEL_WHATSAPP => $member?->whatsappRecipient(),
            default => null,
        };
    }

    public function contentCacheKey(int $deliveryId): string
    {
        return 'notification.delivery.content.'.$deliveryId;
    }
}
