<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Services;

use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Memberships\Models\MembershipEscalation;
use App\Domains\Notifications\Contracts\NotificationDeliveryRepositoryInterface;
use App\Domains\Notifications\Engine\NotificationEngine;
use App\Domains\Notifications\Models\NotificationDelivery;
use App\Domains\Notifications\Support\NotificationEventCatalog;
use App\Domains\Tenancy\Models\Tenant;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

final class MembershipLifecycleService
{
    public function __construct(
        private readonly MembershipRepositoryInterface $memberships,
        private readonly NotificationDeliveryRepositoryInterface $deliveries,
        private readonly NotificationEngine $notifications,
        private readonly AuditWriter $audit
    ) {}

    /**
     * Move past-due active → grace, then grace past window → expired.
     *
     * @return array{grace: int, expired: int}
     */
    public function expireMemberships(?string $asOfDate = null): array
    {
        $asOf = $asOfDate ?? now()->toDateString();
        $graceDays = (int) config('gms.memberships.grace_days', 3);
        $toGrace = 0;
        $toExpired = 0;

        foreach ($this->memberships->findActivePastEndDate($asOf) as $membership) {
            if ($graceDays > 0) {
                $this->memberships->updateMembership($membership, [
                    'status' => Membership::STATUS_GRACE,
                ]);
                $toGrace++;
                $this->audit->write(
                    action: 'membership.grace',
                    entityType: 'membership',
                    entityId: $membership->id,
                    tenantId: $membership->tenant_id,
                    newValues: ['status' => Membership::STATUS_GRACE, 'as_of' => $asOf]
                );
            } else {
                $this->memberships->updateMembership($membership, [
                    'status' => Membership::STATUS_EXPIRED,
                ]);
                $toExpired++;
                $this->auditExpire($membership, $asOf);
            }
        }

        foreach ($this->memberships->findGracePastGraceWindow($asOf, max(0, $graceDays)) as $membership) {
            $this->memberships->updateMembership($membership, [
                'status' => Membership::STATUS_EXPIRED,
            ]);
            $toExpired++;
            $this->auditExpire($membership, $asOf);
        }

        return ['grace' => $toGrace, 'expired' => $toExpired];
    }

    /**
     * Send configurable pre-expiry and post-expiry renewal reminders via the notification engine.
     *
     * @return array{sent: int, skipped: int}
     */
    public function sendReminders(?string $asOfDate = null): array
    {
        $asOf = $asOfDate ?? now()->toDateString();
        /** @var list<int|string> $offsets */
        $offsets = config('gms.memberships.reminder_offsets_days', [30, 15, 7, 3, 1]);
        /** @var list<int|string> $postOffsets */
        $postOffsets = config('gms.memberships.post_expiry_reminder_offsets_days', [1, 3, 7]);
        $sent = 0;
        $skipped = 0;

        foreach ($offsets as $offset) {
            $offset = (int) $offset;
            $endDate = Carbon::parse($asOf)->addDays($offset)->toDateString();

            foreach ($this->memberships->findActiveEndingOn($endDate) as $membership) {
                $count = $this->dispatchMembershipReminder(
                    membership: $membership,
                    eventKey: NotificationEventCatalog::MEMBERSHIP_EXPIRING,
                    daysRemaining: $offset,
                    daysAfterExpire: null,
                    asOf: $asOf,
                    offsetLabel: 't'.$offset
                );
                $count > 0 ? $sent++ : $skipped++;
            }
        }

        foreach ($postOffsets as $offset) {
            $offset = (int) $offset;
            $endDate = Carbon::parse($asOf)->subDays($offset)->toDateString();

            foreach ($this->memberships->findEndedOnStatuses(
                $endDate,
                [Membership::STATUS_GRACE, Membership::STATUS_EXPIRED]
            ) as $membership) {
                $count = $this->dispatchMembershipReminder(
                    membership: $membership,
                    eventKey: NotificationEventCatalog::MEMBERSHIP_EXPIRED,
                    daysRemaining: null,
                    daysAfterExpire: $offset,
                    asOf: $asOf,
                    offsetLabel: 'p'.$offset
                );
                $count > 0 ? $sent++ : $skipped++;
            }
        }

        return ['sent' => $sent, 'skipped' => $skipped];
    }

    private function dispatchMembershipReminder(
        Membership $membership,
        string $eventKey,
        ?int $daysRemaining,
        ?int $daysAfterExpire,
        string $asOf,
        string $offsetLabel
    ): int {
        $member = $membership->member;
        if ($member === null) {
            return 0;
        }

        $tenant = Tenant::query()->withoutGlobalScopes()->find($membership->tenant_id);
        if ($tenant === null) {
            return 0;
        }

        $endDate = $membership->end_date?->toDateString() ?? '';
        $payload = [
            'membership_id' => $membership->id,
            'plan_name' => $membership->plan?->name ?? 'Membership',
            'end_date' => $endDate,
            'days_remaining' => $daysRemaining,
            'days_after_expire' => $daysAfterExpire,
            'gym_name' => $tenant->name,
            'renewal_required' => true,
        ];

        $deliveries = $this->notifications->notify($tenant, $eventKey, [
            'member_ids' => [(int) $member->id],
            'channels' => [
                NotificationDelivery::CHANNEL_IN_APP,
                NotificationDelivery::CHANNEL_EMAIL,
                NotificationDelivery::CHANNEL_WHATSAPP,
            ],
            'payload' => $payload,
            'idempotency_prefix' => sprintf(
                'membership:%d:%s:%s:%s',
                $membership->id,
                $eventKey,
                $offsetLabel,
                $asOf
            ),
            'queue' => true,
        ]);

        Log::info('membership.reminder.dispatched', [
            'membership_id' => $membership->id,
            'event_key' => $eventKey,
            'deliveries' => count($deliveries),
        ]);

        return count($deliveries);
    }

    /**
     * Open/upgrade escalations based on lifecycle rules.
     *
     * @return array{opened: int, upgraded: int}
     */
    public function syncEscalations(?string $asOfDate = null): array
    {
        $asOf = $asOfDate ?? now()->toDateString();
        $cfg = config('gms.memberships.escalation', []);
        $e1Before = (int) ($cfg['e1_days_before_end'] ?? 3);
        $e2After = (int) ($cfg['e2_days_after_expire'] ?? 1);
        $e3After = (int) ($cfg['e3_days_after_expire'] ?? 7);
        $highValue = (float) ($cfg['high_value_price'] ?? 10000);
        $opened = 0;
        $upgraded = 0;

        foreach ($this->memberships->findEscalationCandidates() as $membership) {
            $tier = $this->resolveTier($membership, $asOf, $e1Before, $e2After, $e3After, $highValue);
            if ($tier === null) {
                continue;
            }

            $result = $this->ensureEscalation($membership, $tier, $asOf);
            if ($result === 'opened') {
                $opened++;
            } elseif ($result === 'upgraded') {
                $upgraded++;
            }
        }

        $opened += $this->openDeliveryFailureEscalations($asOf);

        return ['opened' => $opened, 'upgraded' => $upgraded];
    }

    /**
     * @return array<string, mixed>
     */
    public function dashboardAlerts(Tenant $tenant): array
    {
        $days = (int) config('gms.memberships.expiring_soon_days', 14);
        $expiring = $this->memberships->findActiveEndingWithinDays($tenant->id, $days);
        $sample = $expiring->take(5)->map(fn (Membership $m) => [
            'id' => $m->id,
            'member_id' => $m->member_id,
            'member_name' => trim(($m->member?->first_name ?? '').' '.($m->member?->last_name ?? '')),
            'end_date' => $m->end_date?->toDateString(),
            'plan' => $m->plan?->name,
            'display_status' => $m->displayStatus($days),
        ])->values()->all();

        return [
            'expiring_soon' => [
                'count' => $this->memberships->countExpiringSoonForTenant($tenant->id, $days),
                'within_days' => $days,
                'sample' => $sample,
            ],
            'grace' => [
                'count' => $this->memberships->countForTenantByStatus($tenant->id, Membership::STATUS_GRACE),
            ],
            'expired' => [
                'count' => $this->memberships->countForTenantByStatus($tenant->id, Membership::STATUS_EXPIRED),
            ],
            'escalations' => [
                'open_count' => $this->memberships->countOpenEscalationsForTenant($tenant->id),
                'by_tier' => $this->memberships->countOpenEscalationsByTier($tenant->id),
            ],
        ];
    }

    private function auditExpire(Membership $membership, string $asOf): void
    {
        $this->audit->write(
            action: 'membership.expired',
            entityType: 'membership',
            entityId: $membership->id,
            tenantId: $membership->tenant_id,
            newValues: ['status' => Membership::STATUS_EXPIRED, 'as_of' => $asOf]
        );
    }

    private function resolveTier(
        Membership $membership,
        string $asOf,
        int $e1Before,
        int $e2After,
        int $e3After,
        float $highValue
    ): ?string {
        $end = $membership->end_date?->toDateString();
        if ($end === null) {
            return null;
        }

        $asOfCarbon = Carbon::parse($asOf)->startOfDay();
        $endCarbon = Carbon::parse($end)->startOfDay();
        $daysUntil = (int) round(($endCarbon->getTimestamp() - $asOfCarbon->getTimestamp()) / 86400);
        $daysAfter = (int) round(($asOfCarbon->getTimestamp() - $endCarbon->getTimestamp()) / 86400);
        $price = (float) $membership->price_snapshot;
        $isHighValue = $price >= $highValue;

        if ($membership->status === Membership::STATUS_ACTIVE && $daysUntil >= 0) {
            if ($isHighValue && $daysUntil <= $e1Before) {
                return MembershipEscalation::TIER_E4;
            }
            if ($daysUntil <= $e1Before) {
                return MembershipEscalation::TIER_E1;
            }
            if ($daysUntil <= (int) config('gms.memberships.expiring_soon_days', 14)) {
                return MembershipEscalation::TIER_E0;
            }

            return null;
        }

        if (in_array($membership->status, [Membership::STATUS_GRACE, Membership::STATUS_EXPIRED], true)) {
            if ($isHighValue) {
                return MembershipEscalation::TIER_E4;
            }
            if ($daysAfter >= $e3After) {
                return MembershipEscalation::TIER_E3;
            }
            if ($daysAfter >= $e2After) {
                return MembershipEscalation::TIER_E2;
            }
        }

        return null;
    }

    private function ensureEscalation(Membership $membership, string $tier, string $asOf): string
    {
        $open = $this->memberships->findOpenEscalationForMembership((int) $membership->id);

        if ($open === null) {
            $this->memberships->createEscalation([
                'tenant_id' => $membership->tenant_id,
                'membership_id' => $membership->id,
                'member_id' => $membership->member_id,
                'tier' => $tier,
                'status' => MembershipEscalation::STATUS_OPEN,
                'reason' => 'Auto-opened by lifecycle sync on '.$asOf,
                'opened_at' => now(),
            ]);

            return 'opened';
        }

        if (MembershipEscalation::tierRank($tier) > MembershipEscalation::tierRank((string) $open->tier)) {
            $this->memberships->updateEscalation($open, [
                'tier' => $tier,
                'reason' => 'Escalated to '.$tier.' on '.$asOf,
            ]);

            return 'upgraded';
        }

        return 'unchanged';
    }

    private function openDeliveryFailureEscalations(string $asOf): int
    {
        $failures = NotificationDelivery::query()
            ->withoutGlobalScopes()
            ->where('status', NotificationDelivery::STATUS_FAILED)
            ->where('event_key', 'like', 'membership.%')
            ->whereDate('created_at', '>=', Carbon::parse($asOf)->subDay()->toDateString())
            ->get();

        $opened = 0;
        foreach ($failures as $failure) {
            foreach ($this->memberships->findEscalationCandidates() as $membership) {
                $member = $membership->member;
                if ($member === null || (int) $membership->tenant_id !== (int) $failure->tenant_id) {
                    continue;
                }
                $matches = $failure->recipient === $member->email
                    || $failure->recipient === $member->whatsappRecipient()
                    || $failure->recipient === $member->phone;
                if (! $matches) {
                    continue;
                }
                $result = $this->ensureEscalation($membership, MembershipEscalation::TIER_E5, $asOf);
                if ($result === 'opened' || $result === 'upgraded') {
                    $opened++;
                }
                break;
            }
        }

        return $opened;
    }
}
