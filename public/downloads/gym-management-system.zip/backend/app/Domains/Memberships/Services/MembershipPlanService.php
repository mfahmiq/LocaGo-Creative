<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Memberships\Actions\CreateMembershipPlanAction;
use App\Domains\Memberships\Actions\DeleteMembershipPlanAction;
use App\Domains\Memberships\Actions\UpdateMembershipPlanAction;
use App\Domains\Memberships\Contracts\MembershipPlanRepositoryInterface;
use App\Domains\Memberships\Models\MembershipPlan;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class MembershipPlanService extends BaseService
{
    public function __construct(
        private readonly MembershipPlanRepositoryInterface $plans,
        private readonly CreateMembershipPlanAction $createMembershipPlanAction,
        private readonly UpdateMembershipPlanAction $updateMembershipPlanAction,
        private readonly DeleteMembershipPlanAction $deleteMembershipPlanAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->plans->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $planId): MembershipPlan
    {
        $plan = $this->plans->findForTenant($tenant->id, $planId);

        if ($plan === null) {
            throw new DomainException('Membership plan not found.', 'membership_plan_not_found', Response::HTTP_NOT_FOUND);
        }

        return $plan;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): MembershipPlan
    {
        return $this->createMembershipPlanAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $planId, array $data): MembershipPlan
    {
        return $this->updateMembershipPlanAction->execute($tenant, $planId, $data);
    }

    public function delete(Tenant $tenant, int $planId): bool
    {
        return $this->deleteMembershipPlanAction->execute($tenant, $planId);
    }
}
