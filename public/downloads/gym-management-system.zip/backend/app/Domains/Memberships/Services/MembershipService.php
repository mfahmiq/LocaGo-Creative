<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Memberships\Actions\ActivateMembershipAction;
use App\Domains\Memberships\Actions\CancelMembershipAction;
use App\Domains\Memberships\Actions\CreateMembershipAction;
use App\Domains\Memberships\Actions\FreezeMembershipAction;
use App\Domains\Memberships\Actions\RenewMembershipAction;
use App\Domains\Memberships\Actions\UnfreezeMembershipAction;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Memberships\Models\MembershipEscalation;
use App\Domains\Memberships\Models\MembershipRenewal;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class MembershipService extends BaseService
{
    public function __construct(
        private readonly MembershipRepositoryInterface $memberships,
        private readonly MembershipLifecycleService $lifecycle,
        private readonly CreateMembershipAction $createMembershipAction,
        private readonly ActivateMembershipAction $activateMembershipAction,
        private readonly CancelMembershipAction $cancelMembershipAction,
        private readonly FreezeMembershipAction $freezeMembershipAction,
        private readonly UnfreezeMembershipAction $unfreezeMembershipAction,
        private readonly RenewMembershipAction $renewMembershipAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->memberships->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $membershipId): Membership
    {
        $membership = $this->memberships->findForTenant($tenant->id, $membershipId);

        if ($membership === null) {
            throw new DomainException('Membership not found.', 'membership_not_found', Response::HTTP_NOT_FOUND);
        }

        return $membership;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): Membership
    {
        return $this->createMembershipAction->execute($tenant, $data);
    }

    public function activate(Tenant $tenant, int $membershipId): Membership
    {
        return $this->activateMembershipAction->execute($tenant, $membershipId);
    }

    public function cancel(Tenant $tenant, int $membershipId, ?string $reason = null): Membership
    {
        return $this->cancelMembershipAction->execute($tenant, $membershipId, $reason);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function freeze(Tenant $tenant, int $membershipId, array $data): Membership
    {
        return $this->freezeMembershipAction->execute($tenant, $membershipId, $data);
    }

    public function unfreeze(Tenant $tenant, int $membershipId): Membership
    {
        return $this->unfreezeMembershipAction->execute($tenant, $membershipId);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function renew(Tenant $tenant, int $membershipId, array $data = []): Membership
    {
        $data['change_type'] = $data['change_type'] ?? MembershipRenewal::CHANGE_RENEW;

        return $this->renewMembershipAction->execute($tenant, $membershipId, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function upgrade(Tenant $tenant, int $membershipId, array $data): Membership
    {
        $data['change_type'] = MembershipRenewal::CHANGE_UPGRADE;

        return $this->renewMembershipAction->execute($tenant, $membershipId, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function downgrade(Tenant $tenant, int $membershipId, array $data): Membership
    {
        $data['change_type'] = MembershipRenewal::CHANGE_DOWNGRADE;

        return $this->renewMembershipAction->execute($tenant, $membershipId, $data);
    }

    /**
     * @return array<string, mixed>
     */
    public function dashboardAlerts(Tenant $tenant): array
    {
        return $this->lifecycle->dashboardAlerts($tenant);
    }

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateEscalations(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->memberships->paginateEscalationsForTenant($tenant->id, $filters);
    }

    public function findEscalation(Tenant $tenant, int $escalationId): MembershipEscalation
    {
        $escalation = $this->memberships->findEscalationForTenant($tenant->id, $escalationId);

        if ($escalation === null) {
            throw new DomainException('Escalation not found.', 'escalation_not_found', Response::HTTP_NOT_FOUND);
        }

        return $escalation;
    }

    public function ackEscalation(Tenant $tenant, int $escalationId, ?int $assignedUserId = null): MembershipEscalation
    {
        $escalation = $this->findEscalation($tenant, $escalationId);

        if ($escalation->status === MembershipEscalation::STATUS_RESOLVED) {
            throw new DomainException(
                'Escalation is already resolved.',
                'escalation_already_resolved',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        return $this->memberships->updateEscalation($escalation, [
            'status' => MembershipEscalation::STATUS_ACKED,
            'acked_at' => now(),
            'assigned_user_id' => $assignedUserId ?? $escalation->assigned_user_id,
        ]);
    }

    public function resolveEscalation(Tenant $tenant, int $escalationId): MembershipEscalation
    {
        $escalation = $this->findEscalation($tenant, $escalationId);

        if ($escalation->status === MembershipEscalation::STATUS_RESOLVED) {
            throw new DomainException(
                'Escalation is already resolved.',
                'escalation_already_resolved',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        return $this->memberships->updateEscalation($escalation, [
            'status' => MembershipEscalation::STATUS_RESOLVED,
            'resolved_at' => now(),
        ]);
    }
}
