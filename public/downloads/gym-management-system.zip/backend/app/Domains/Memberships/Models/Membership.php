<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Members\Models\Member;
use App\Domains\Organization\Models\Branch;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Membership extends BaseModel
{
    use BelongsToTenant;

    public const STATUS_PENDING = 'pending';

    public const STATUS_ACTIVE = 'active';

    public const STATUS_GRACE = 'grace';

    public const STATUS_FROZEN = 'frozen';

    public const STATUS_EXPIRED = 'expired';

    public const STATUS_CANCELLED = 'cancelled';

    protected $table = 'memberships';

    protected $fillable = [
        'tenant_id',
        'member_id',
        'membership_plan_id',
        'branch_id',
        'status',
        'start_date',
        'end_date',
        'visits_remaining',
        'price_snapshot',
        'currency_code',
        'activated_at',
        'cancelled_at',
        'cancel_reason',
        'notes',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'start_date' => 'date',
            'end_date' => 'date',
            'visits_remaining' => 'integer',
            'price_snapshot' => 'decimal:2',
            'activated_at' => 'datetime',
            'cancelled_at' => 'datetime',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function member(): BelongsTo
    {
        return $this->belongsTo(Member::class);
    }

    public function plan(): BelongsTo
    {
        return $this->belongsTo(MembershipPlan::class, 'membership_plan_id');
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function freezes(): HasMany
    {
        return $this->hasMany(MembershipFreeze::class);
    }

    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }

    public function isFrozen(): bool
    {
        return $this->status === self::STATUS_FROZEN;
    }

    public function isExpiringSoon(?int $withinDays = null): bool
    {
        if ($this->status !== self::STATUS_ACTIVE || $this->end_date === null) {
            return false;
        }

        $days = $withinDays ?? (int) config('gms.memberships.expiring_soon_days', 14);
        $today = now()->startOfDay();
        $end = $this->end_date->copy()->startOfDay();

        return $end->greaterThanOrEqualTo($today)
            && $end->lessThanOrEqualTo($today->copy()->addDays($days));
    }

    public function displayStatus(?int $withinDays = null): string
    {
        if ($this->isExpiringSoon($withinDays)) {
            return 'expiring_soon';
        }

        return (string) $this->status;
    }

    public function daysUntilEnd(): ?int
    {
        if ($this->end_date === null) {
            return null;
        }

        $today = now()->startOfDay()->getTimestamp();
        $end = $this->end_date->copy()->startOfDay()->getTimestamp();

        return (int) round(($end - $today) / 86400);
    }
}

