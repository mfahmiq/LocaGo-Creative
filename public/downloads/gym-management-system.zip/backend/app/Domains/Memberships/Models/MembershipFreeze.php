<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MembershipFreeze extends BaseModel
{
    use BelongsToTenant;

    public const STATUS_ACTIVE = 'active';

    public const STATUS_COMPLETED = 'completed';

    public const STATUS_CANCELLED = 'cancelled';

    protected $table = 'membership_freezes';

    protected $fillable = [
        'tenant_id',
        'membership_id',
        'start_date',
        'end_date',
        'actual_end_date',
        'days_count',
        'extends_end_date',
        'reason',
        'status',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'start_date' => 'date',
            'end_date' => 'date',
            'actual_end_date' => 'date',
            'days_count' => 'integer',
            'extends_end_date' => 'boolean',
        ];
    }

    public function membership(): BelongsTo
    {
        return $this->belongsTo(Membership::class);
    }
}
