<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Members\Models\Member;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MembershipRenewal extends BaseModel
{
    use BelongsToTenant;

    public const STATUS_REQUESTED = 'requested';

    public const STATUS_COMPLETED = 'completed';

    public const STATUS_CANCELLED = 'cancelled';

    public const CHANGE_RENEW = 'renew';

    public const CHANGE_UPGRADE = 'upgrade';

    public const CHANGE_DOWNGRADE = 'downgrade';

    protected $table = 'membership_renewals';

    protected $fillable = [
        'tenant_id',
        'member_id',
        'from_membership_id',
        'to_membership_id',
        'membership_plan_id',
        'invoice_id',
        'request_source',
        'change_type',
        'status',
        'renewed_at',
        'notes',
        'created_by',
        'updated_by',
        'deleted_by',
    ];


    protected function casts(): array
    {
        return [
            'renewed_at' => 'datetime',
        ];
    }

    public function member(): BelongsTo
    {
        return $this->belongsTo(Member::class);
    }

    public function fromMembership(): BelongsTo
    {
        return $this->belongsTo(Membership::class, 'from_membership_id');
    }

    public function toMembership(): BelongsTo
    {
        return $this->belongsTo(Membership::class, 'to_membership_id');
    }

    public function plan(): BelongsTo
    {
        return $this->belongsTo(MembershipPlan::class, 'membership_plan_id');
    }
}
