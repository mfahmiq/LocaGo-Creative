<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Organization\Models\Branch;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class MembershipPlan extends BaseModel
{
    use BelongsToTenant;

    protected $table = 'membership_plans';

    protected $fillable = [
        'tenant_id',
        'code',
        'name',
        'description',
        'plan_type',
        'duration_days',
        'visit_limit',
        'price',
        'currency_code',
        'allows_walkin',
        'allows_all_branches',
        'freeze_allowed',
        'max_freeze_days',
        'tax_rate_id',
        'is_active',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'duration_days' => 'integer',
            'visit_limit' => 'integer',
            'price' => 'decimal:2',
            'allows_walkin' => 'boolean',
            'allows_all_branches' => 'boolean',
            'freeze_allowed' => 'boolean',
            'max_freeze_days' => 'integer',
            'is_active' => 'boolean',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function branches(): BelongsToMany
    {
        return $this->belongsToMany(Branch::class, 'membership_plan_branches')
            ->withPivot(['tenant_id']);
    }

    public function memberships(): HasMany
    {
        return $this->hasMany(Membership::class, 'membership_plan_id');
    }
}
