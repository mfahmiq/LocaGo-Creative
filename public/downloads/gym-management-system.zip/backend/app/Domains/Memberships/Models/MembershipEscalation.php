<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Identity\Models\User;
use App\Domains\Members\Models\Member;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MembershipEscalation extends BaseModel
{
    use BelongsToTenant;

    public const STATUS_OPEN = 'open';

    public const STATUS_ACKED = 'acked';

    public const STATUS_RESOLVED = 'resolved';

    public const TIER_E0 = 'E0';

    public const TIER_E1 = 'E1';

    public const TIER_E2 = 'E2';

    public const TIER_E3 = 'E3';

    public const TIER_E4 = 'E4';

    public const TIER_E5 = 'E5';

    /** @var list<string> */
    public const TIERS = [
        self::TIER_E0,
        self::TIER_E1,
        self::TIER_E2,
        self::TIER_E3,
        self::TIER_E4,
        self::TIER_E5,
    ];

    protected $table = 'membership_escalations';

    protected $fillable = [
        'tenant_id',
        'membership_id',
        'member_id',
        'tier',
        'status',
        'assigned_user_id',
        'reason',
        'opened_at',
        'acked_at',
        'resolved_at',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'opened_at' => 'datetime',
            'acked_at' => 'datetime',
            'resolved_at' => 'datetime',
        ];
    }

    public function membership(): BelongsTo
    {
        return $this->belongsTo(Membership::class);
    }

    public function member(): BelongsTo
    {
        return $this->belongsTo(Member::class);
    }

    public function assignedUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_user_id');
    }

    public static function tierRank(string $tier): int
    {
        $index = array_search($tier, self::TIERS, true);

        return $index === false ? -1 : $index;
    }
}
