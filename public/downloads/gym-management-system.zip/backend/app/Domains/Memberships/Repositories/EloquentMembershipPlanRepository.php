<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Memberships\Contracts\MembershipPlanRepositoryInterface;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Memberships\Models\MembershipPlan;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<MembershipPlan>
 */
class EloquentMembershipPlanRepository extends BaseRepository implements MembershipPlanRepositoryInterface
{
    public function __construct(MembershipPlan $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['branches'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('id');

        if (array_key_exists('is_active', $filters) && $filters['is_active'] !== null && $filters['is_active'] !== '') {
            $query->where('is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN));
        }

        if (! empty($filters['plan_type'])) {
            $query->where('plan_type', $filters['plan_type']);
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);
            $query->where(function ($q) use ($search): void {
                $q->where('code', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%");
            });
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $planId): ?MembershipPlan
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['branches'])
            ->where('tenant_id', $tenantId)
            ->where('id', $planId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function codeExistsForTenant(int $tenantId, string $code, ?int $exceptPlanId = null): bool
    {
        $query = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('code', $code)
            ->whereNull('deleted_at');

        if ($exceptPlanId !== null) {
            $query->where('id', '!=', $exceptPlanId);
        }

        return $query->exists();
    }

    public function createPlan(array $attributes): MembershipPlan
    {
        /** @var MembershipPlan $plan */
        $plan = $this->query()->withoutGlobalScopes()->create($attributes);

        return $plan->load('branches');
    }

    public function updatePlan(MembershipPlan $plan, array $attributes): MembershipPlan
    {
        $plan->update($attributes);

        return $plan->fresh(['branches']) ?? $plan->load('branches');
    }

    public function deletePlan(MembershipPlan $plan): bool
    {
        return (bool) $plan->delete();
    }

    public function syncBranches(MembershipPlan $plan, int $tenantId, array $branchIds): void
    {
        $sync = [];
        foreach ($branchIds as $branchId) {
            $sync[(int) $branchId] = ['tenant_id' => $tenantId];
        }

        $plan->branches()->sync($sync);
    }

    public function clearBranches(MembershipPlan $plan): void
    {
        $plan->branches()->detach();
    }

    public function hasActiveMemberships(int $planId): bool
    {
        return Membership::query()
            ->withoutGlobalScopes()
            ->where('membership_plan_id', $planId)
            ->whereNull('deleted_at')
            ->whereIn('status', [
                Membership::STATUS_PENDING,
                Membership::STATUS_ACTIVE,
                Membership::STATUS_GRACE,
                Membership::STATUS_FROZEN,
            ])
            ->exists();
    }
}
