<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Memberships\Models\MembershipEscalation;
use App\Domains\Memberships\Models\MembershipFreeze;
use App\Domains\Memberships\Models\MembershipPlan;
use App\Domains\Memberships\Models\MembershipRenewal;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

/**
 * @extends BaseRepository<Membership>
 */
class EloquentMembershipRepository extends BaseRepository implements MembershipRepositoryInterface
{
    public function __construct(Membership $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'plan', 'branch'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at');

        $status = (string) ($filters['status'] ?? '');
        if ($status === 'expiring_soon') {
            $days = (int) ($filters['expiring_days'] ?? config('gms.memberships.expiring_soon_days', 14));
            $today = now()->toDateString();
            $until = now()->addDays($days)->toDateString();
            $query->where('status', Membership::STATUS_ACTIVE)
                ->whereNotNull('end_date')
                ->whereDate('end_date', '>=', $today)
                ->whereDate('end_date', '<=', $until)
                ->orderBy('end_date')
                ->orderBy('id');
        } else {
            if ($status !== '') {
                $query->where('status', $status);
            }
            $query->orderByDesc('id');
        }

        if (! empty($filters['member_id'])) {
            $query->where('member_id', (int) $filters['member_id']);
        }

        if (! empty($filters['membership_plan_id'])) {
            $query->where('membership_plan_id', (int) $filters['membership_plan_id']);
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $membershipId): ?Membership
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'plan', 'branch', 'freezes'])
            ->where('tenant_id', $tenantId)
            ->where('id', $membershipId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function findActivePlanForTenant(int $tenantId, int $planId): ?MembershipPlan
    {
        return MembershipPlan::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('id', $planId)
            ->where('is_active', true)
            ->whereNull('deleted_at')
            ->first();
    }

    public function createMembership(array $attributes): Membership
    {
        /** @var Membership $membership */
        $membership = $this->query()->withoutGlobalScopes()->create($attributes);

        return $membership->load(['member', 'plan', 'branch']);
    }

    public function updateMembership(Membership $membership, array $attributes): Membership
    {
        $membership->update($attributes);

        return $membership->fresh(['member', 'plan', 'branch', 'freezes']);
    }

    public function findActiveFreeze(int $membershipId): ?MembershipFreeze
    {
        return MembershipFreeze::query()
            ->withoutGlobalScopes()
            ->where('membership_id', $membershipId)
            ->where('status', MembershipFreeze::STATUS_ACTIVE)
            ->whereNull('deleted_at')
            ->latest('id')
            ->first();
    }

    public function createFreeze(array $attributes): MembershipFreeze
    {
        /** @var MembershipFreeze $freeze */
        $freeze = MembershipFreeze::query()->withoutGlobalScopes()->create($attributes);

        return $freeze;
    }

    public function updateFreeze(MembershipFreeze $freeze, array $attributes): MembershipFreeze
    {
        $freeze->update($attributes);

        return $freeze->refresh();
    }

    public function createRenewal(array $attributes): MembershipRenewal
    {
        /** @var MembershipRenewal $renewal */
        $renewal = MembershipRenewal::query()->withoutGlobalScopes()->create($attributes);

        return $renewal;
    }

    public function findActiveEndingOn(string $endDate): Collection
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'plan', 'tenant'])
            ->where('status', Membership::STATUS_ACTIVE)
            ->whereNull('deleted_at')
            ->whereDate('end_date', $endDate)
            ->orderBy('id')
            ->get();
    }

    public function findEndedOnStatuses(string $endDate, array $statuses): Collection
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'plan', 'tenant'])
            ->whereIn('status', $statuses)
            ->whereNull('deleted_at')
            ->whereDate('end_date', $endDate)
            ->orderBy('id')
            ->get();
    }

    public function findActivePastEndDate(string $asOfDate): Collection
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'plan'])
            ->where('status', Membership::STATUS_ACTIVE)
            ->whereNull('deleted_at')
            ->whereNotNull('end_date')
            ->whereDate('end_date', '<', $asOfDate)
            ->orderBy('id')
            ->get();
    }

    public function findGracePastGraceWindow(string $asOfDate, int $graceDays): Collection
    {
        $cutoff = \Carbon\Carbon::parse($asOfDate)->subDays($graceDays)->toDateString();

        return $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'plan'])
            ->where('status', Membership::STATUS_GRACE)
            ->whereNull('deleted_at')
            ->whereNotNull('end_date')
            ->whereDate('end_date', '<', $cutoff)
            ->orderBy('id')
            ->get();
    }

    public function findActiveEndingWithinDays(int $tenantId, int $withinDays): Collection
    {
        $today = now()->toDateString();
        $until = now()->addDays($withinDays)->toDateString();

        return $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'plan', 'branch'])
            ->where('tenant_id', $tenantId)
            ->where('status', Membership::STATUS_ACTIVE)
            ->whereNull('deleted_at')
            ->whereNotNull('end_date')
            ->whereDate('end_date', '>=', $today)
            ->whereDate('end_date', '<=', $until)
            ->orderBy('end_date')
            ->get();
    }

    public function countForTenantByStatus(int $tenantId, string $status): int
    {
        return (int) $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('status', $status)
            ->whereNull('deleted_at')
            ->count();
    }

    public function countExpiringSoonForTenant(int $tenantId, int $withinDays): int
    {
        $today = now()->toDateString();
        $until = now()->addDays($withinDays)->toDateString();

        return (int) $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('status', Membership::STATUS_ACTIVE)
            ->whereNull('deleted_at')
            ->whereNotNull('end_date')
            ->whereDate('end_date', '>=', $today)
            ->whereDate('end_date', '<=', $until)
            ->count();
    }

    public function paginateEscalationsForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = MembershipEscalation::query()
            ->withoutGlobalScopes()
            ->with(['member', 'membership.plan', 'assignedUser'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('opened_at')
            ->orderByDesc('id');

        if (! empty($filters['status'])) {
            $query->where('status', (string) $filters['status']);
        }

        if (! empty($filters['tier'])) {
            $query->where('tier', (string) $filters['tier']);
        }

        if (! empty($filters['membership_id'])) {
            $query->where('membership_id', (int) $filters['membership_id']);
        }

        return $query->paginate($perPage);
    }

    public function findEscalationForTenant(int $tenantId, int $escalationId): ?MembershipEscalation
    {
        return MembershipEscalation::query()
            ->withoutGlobalScopes()
            ->with(['member', 'membership.plan', 'assignedUser'])
            ->where('tenant_id', $tenantId)
            ->where('id', $escalationId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function findOpenEscalationForMembership(int $membershipId): ?MembershipEscalation
    {
        return MembershipEscalation::query()
            ->withoutGlobalScopes()
            ->where('membership_id', $membershipId)
            ->whereIn('status', [MembershipEscalation::STATUS_OPEN, MembershipEscalation::STATUS_ACKED])
            ->whereNull('deleted_at')
            ->orderByDesc('id')
            ->first();
    }

    public function createEscalation(array $attributes): MembershipEscalation
    {
        /** @var MembershipEscalation $escalation */
        $escalation = MembershipEscalation::query()->withoutGlobalScopes()->create($attributes);

        return $escalation->load(['member', 'membership.plan']);
    }

    public function updateEscalation(MembershipEscalation $escalation, array $attributes): MembershipEscalation
    {
        $escalation->update($attributes);

        return $escalation->fresh(['member', 'membership.plan', 'assignedUser']);
    }

    public function resolveOpenEscalationsForMembership(int $membershipId): int
    {
        return MembershipEscalation::query()
            ->withoutGlobalScopes()
            ->where('membership_id', $membershipId)
            ->whereIn('status', [MembershipEscalation::STATUS_OPEN, MembershipEscalation::STATUS_ACKED])
            ->whereNull('deleted_at')
            ->update([
                'status' => MembershipEscalation::STATUS_RESOLVED,
                'resolved_at' => now(),
            ]);
    }

    public function countOpenEscalationsForTenant(int $tenantId): int
    {
        return (int) MembershipEscalation::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->whereIn('status', [MembershipEscalation::STATUS_OPEN, MembershipEscalation::STATUS_ACKED])
            ->whereNull('deleted_at')
            ->count();
    }

    public function countOpenEscalationsByTier(int $tenantId): array
    {
        $rows = MembershipEscalation::query()
            ->withoutGlobalScopes()
            ->selectRaw('tier, COUNT(*) as aggregate')
            ->where('tenant_id', $tenantId)
            ->whereIn('status', [MembershipEscalation::STATUS_OPEN, MembershipEscalation::STATUS_ACKED])
            ->whereNull('deleted_at')
            ->groupBy('tier')
            ->pluck('aggregate', 'tier')
            ->all();

        $counts = [];
        foreach (MembershipEscalation::TIERS as $tier) {
            $counts[$tier] = (int) ($rows[$tier] ?? 0);
        }

        return $counts;
    }

    public function findEscalationCandidates(): Collection
    {
        $expiringDays = (int) config('gms.memberships.expiring_soon_days', 14);
        $until = now()->addDays($expiringDays)->toDateString();

        return $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'plan'])
            ->whereNull('deleted_at')
            ->whereNotNull('end_date')
            ->where(function ($q) use ($until): void {
                $q->where(function ($inner) use ($until): void {
                    $inner->where('status', Membership::STATUS_ACTIVE)
                        ->whereDate('end_date', '<=', $until);
                })->orWhereIn('status', [Membership::STATUS_GRACE, Membership::STATUS_EXPIRED]);
            })
            ->orderBy('id')
            ->get();
    }
}
