﻿# Memberships Domain

## Admin Portal — Membership plans (complete)

Requires `auth:sanctum` + staff + `X-Tenant-Slug` + permissions.

Plan types: `time` | `visit` | `hybrid`

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/api/v1/admin/membership-plans` | `memberships.plans.view` |
| POST | `/api/v1/admin/membership-plans` | `memberships.plans.manage` |
| GET | `/api/v1/admin/membership-plans/{id}` | `memberships.plans.view` |
| PUT | `/api/v1/admin/membership-plans/{id}` | `memberships.plans.manage` |
| DELETE | `/api/v1/admin/membership-plans/{id}` | `memberships.plans.manage` |

Query filters (list): `search`, `plan_type`, `is_active`, `per_page`

### Rules
- `time` requires `duration_days`; `visit` requires `visit_limit`; `hybrid` requires both
- `allows_all_branches=false` requires `branch_ids` (synced to `membership_plan_branches`)
- Code unique per tenant; price changes do not alter existing membership snapshots
- Soft-delete blocked while pending/active/grace/frozen memberships exist — set `is_active=false` to archive/unsellable instead

Audited: `membership_plan.created`, `membership_plan.updated`, `membership_plan.deleted`

## Admin Portal — Membership instances (complete)

Requires `auth:sanctum` + staff + `X-Tenant-Slug` + permissions.

Membership instances bind a member to a plan with lifecycle status:
`pending` | `active` | `grace` | `frozen` | `expired` | `cancelled`

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/api/v1/admin/memberships` | `memberships.instances.view` |
| POST | `/api/v1/admin/memberships` | `memberships.instances.manage` |
| GET | `/api/v1/admin/memberships/{id}` | `memberships.instances.view` |
| POST | `/api/v1/admin/memberships/{id}/activate` | `memberships.instances.manage` |
| POST | `/api/v1/admin/memberships/{id}/cancel` | `memberships.instances.cancel` |
| POST | `/api/v1/admin/memberships/{id}/freeze` | `memberships.instances.freeze` |
| POST | `/api/v1/admin/memberships/{id}/unfreeze` | `memberships.instances.freeze` |
| POST | `/api/v1/admin/memberships/{id}/renew` | `memberships.instances.manage` |

Query filters (list): `status`, `member_id`, `membership_plan_id`, `per_page`

### Create body highlights
- `member_id`, `membership_plan_id` (required)
- `branch_id` (optional; defaults to member home branch)
- `activate_now` (optional bool) — creates as `active` when true
- Snapshots `price`, `currency_code`, and `visit_limit` from the plan

### Lifecycle notes
- **Freeze**: only `active`; plan must allow freezes; optional `extends_end_date`
- **Renew**: creates a new active membership + renewal row; prior `active` becomes `expired`; blocked while frozen
- **Cancel**: sets `cancelled` with optional reason

Audited actions: `membership.created`, `membership.activated`, `membership.cancelled`, `membership.frozen`, `membership.unfrozen`, `membership.renewed`

## Next Admin modules
Classes / Schedule → … (Attendance complete — see Attendance domain)
