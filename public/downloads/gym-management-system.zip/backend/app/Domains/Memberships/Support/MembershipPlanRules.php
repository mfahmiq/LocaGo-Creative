<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Support;

use App\Core\Exceptions\DomainException;
use Symfony\Component\HttpFoundation\Response;

final class MembershipPlanRules
{
    public const TYPE_TIME = 'time';

    public const TYPE_VISIT = 'visit';

    public const TYPE_HYBRID = 'hybrid';

    /**
     * @param  array<string, mixed>  $data
     */
    public static function assertTypeFields(array $data): void
    {
        $type = (string) ($data['plan_type'] ?? '');

        if ($type === self::TYPE_TIME) {
            if (empty($data['duration_days'])) {
                throw new DomainException(
                    'Time-based plans require duration_days.',
                    'duration_days_required',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }
        }

        if ($type === self::TYPE_VISIT) {
            if (empty($data['visit_limit'])) {
                throw new DomainException(
                    'Visit-based plans require visit_limit.',
                    'visit_limit_required',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }
        }

        if ($type === self::TYPE_HYBRID) {
            if (empty($data['duration_days']) || empty($data['visit_limit'])) {
                throw new DomainException(
                    'Hybrid plans require duration_days and visit_limit.',
                    'hybrid_fields_required',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }
        }
    }

    /**
     * @param  array<string, mixed>  $data
     * @param  array<string, mixed>  $existing
     * @return array<string, mixed>
     */
    public static function mergeForUpdate(array $data, array $existing): array
    {
        return array_merge($existing, $data);
    }
}
