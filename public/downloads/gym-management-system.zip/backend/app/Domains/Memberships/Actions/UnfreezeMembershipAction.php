<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Memberships\Models\MembershipFreeze;
use App\Domains\Tenancy\Models\Tenant;
use Carbon\Carbon;
use Symfony\Component\HttpFoundation\Response;

final class UnfreezeMembershipAction extends Action
{
    public function __construct(
        private readonly MembershipRepositoryInterface $memberships,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Membership
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $membershipId */
        $membershipId = (int) $args[1];

        return $this->transaction(function () use ($tenant, $membershipId): Membership {
            $membership = $this->memberships->findForTenant($tenant->id, $membershipId);

            if ($membership === null) {
                throw new DomainException('Membership not found.', 'membership_not_found', Response::HTTP_NOT_FOUND);
            }

            if ($membership->status !== Membership::STATUS_FROZEN) {
                throw new DomainException(
                    'Only frozen memberships can be unfrozen.',
                    'invalid_membership_status',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $freeze = $this->memberships->findActiveFreeze($membership->id);

            if ($freeze === null) {
                throw new DomainException(
                    'No active freeze found for this membership.',
                    'freeze_not_found',
                    Response::HTTP_NOT_FOUND
                );
            }

            $today = Carbon::today();
            $payload = [
                'status' => Membership::STATUS_ACTIVE,
            ];

            // If unfrozen early and end was extended for full freeze window, claw back unused days.
            if ($freeze->extends_end_date && $membership->end_date !== null && $today->lt($freeze->end_date)) {
                $unused = $today->diffInDays($freeze->end_date);
                if ($unused > 0) {
                    $payload['end_date'] = $membership->end_date->copy()->subDays($unused)->toDateString();
                }
            }

            $this->memberships->updateFreeze($freeze, [
                'status' => MembershipFreeze::STATUS_COMPLETED,
                'actual_end_date' => $today->toDateString(),
            ]);

            $updated = $this->memberships->updateMembership($membership, $payload);

            $this->audit->write(
                action: 'membership.unfrozen',
                entityType: 'membership',
                entityId: $updated->id,
                tenantId: $tenant->id,
                newValues: ['status' => Membership::STATUS_ACTIVE]
            );

            return $updated;
        });
    }
}
