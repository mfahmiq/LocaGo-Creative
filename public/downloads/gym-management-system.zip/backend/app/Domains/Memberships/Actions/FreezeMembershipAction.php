<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Memberships\Models\MembershipFreeze;
use App\Domains\Tenancy\Models\Tenant;
use Carbon\Carbon;
use Symfony\Component\HttpFoundation\Response;

final class FreezeMembershipAction extends Action
{
    public function __construct(
        private readonly MembershipRepositoryInterface $memberships,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Membership
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $membershipId */
        $membershipId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        return $this->transaction(function () use ($tenant, $membershipId, $data): Membership {
            $membership = $this->memberships->findForTenant($tenant->id, $membershipId);

            if ($membership === null) {
                throw new DomainException('Membership not found.', 'membership_not_found', Response::HTTP_NOT_FOUND);
            }

            if ($membership->status !== Membership::STATUS_ACTIVE) {
                throw new DomainException(
                    'Only active memberships can be frozen.',
                    'invalid_membership_status',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $plan = $membership->plan;

            if ($plan === null || ! $plan->freeze_allowed) {
                throw new DomainException(
                    'This plan does not allow freezes.',
                    'freeze_not_allowed',
                    Response::HTTP_FORBIDDEN
                );
            }

            if ($this->memberships->findActiveFreeze($membership->id) !== null) {
                throw new DomainException(
                    'An active freeze already exists.',
                    'freeze_overlap',
                    Response::HTTP_CONFLICT
                );
            }

            $start = Carbon::parse((string) $data['start_date'])->startOfDay();
            $end = Carbon::parse((string) $data['end_date'])->startOfDay();

            if ($end->lt($start)) {
                throw new DomainException(
                    'Freeze end date must be on or after start date.',
                    'invalid_freeze_dates',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $days = $start->diffInDays($end) + 1;

            if ($plan->max_freeze_days !== null && $days > (int) $plan->max_freeze_days) {
                throw new DomainException(
                    'Freeze exceeds max allowed days for this plan.',
                    'freeze_days_exceeded',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $extends = (bool) ($data['extends_end_date'] ?? true);

            $this->memberships->createFreeze([
                'tenant_id' => $tenant->id,
                'membership_id' => $membership->id,
                'start_date' => $start->toDateString(),
                'end_date' => $end->toDateString(),
                'days_count' => $days,
                'extends_end_date' => $extends,
                'reason' => $data['reason'] ?? null,
                'status' => MembershipFreeze::STATUS_ACTIVE,
            ]);

            $payload = ['status' => Membership::STATUS_FROZEN];

            if ($extends && $membership->end_date !== null) {
                $payload['end_date'] = $membership->end_date->copy()->addDays($days)->toDateString();
            }

            $updated = $this->memberships->updateMembership($membership, $payload);

            $this->audit->write(
                action: 'membership.frozen',
                entityType: 'membership',
                entityId: $updated->id,
                tenantId: $tenant->id,
                newValues: [
                    'status' => Membership::STATUS_FROZEN,
                    'days' => $days,
                    'extends_end_date' => $extends,
                ]
            );

            return $updated;
        });
    }
}
