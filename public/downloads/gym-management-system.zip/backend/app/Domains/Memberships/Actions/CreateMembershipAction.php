<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Carbon\Carbon;
use Symfony\Component\HttpFoundation\Response;

final class CreateMembershipAction extends Action
{
    public function __construct(
        private readonly MembershipRepositoryInterface $memberships,
        private readonly MemberRepositoryInterface $members,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Membership
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        return $this->transaction(function () use ($tenant, $data): Membership {
            $member = $this->members->findForTenant($tenant->id, (int) $data['member_id']);

            if ($member === null) {
                throw new DomainException('Member not found.', 'member_not_found', Response::HTTP_NOT_FOUND);
            }

            $plan = $this->memberships->findActivePlanForTenant($tenant->id, (int) $data['membership_plan_id']);

            if ($plan === null) {
                throw new DomainException(
                    'Membership plan not found or inactive.',
                    'membership_plan_not_found',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $branchId = isset($data['branch_id']) ? (int) $data['branch_id'] : (int) $member->home_branch_id;

            if ($this->branches->findActiveForTenant($tenant->id, $branchId) === null) {
                throw new DomainException(
                    'Branch is invalid or inactive.',
                    'invalid_branch',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $start = Carbon::parse((string) ($data['start_date'] ?? now()->toDateString()))->startOfDay();
            $end = null;

            if ($plan->duration_days !== null) {
                $end = $start->copy()->addDays((int) $plan->duration_days)->subDay();
            }

            if (! empty($data['end_date'])) {
                $end = Carbon::parse((string) $data['end_date'])->startOfDay();
            }

            $activateNow = (bool) ($data['activate_now'] ?? false);
            $status = $activateNow ? Membership::STATUS_ACTIVE : Membership::STATUS_PENDING;

            $membership = $this->memberships->createMembership([
                'tenant_id' => $tenant->id,
                'member_id' => $member->id,
                'membership_plan_id' => $plan->id,
                'branch_id' => $branchId,
                'status' => $status,
                'start_date' => $start->toDateString(),
                'end_date' => $end?->toDateString(),
                'visits_remaining' => $plan->visit_limit,
                'price_snapshot' => $plan->price,
                'currency_code' => $plan->currency_code ?: $tenant->base_currency,
                'activated_at' => $activateNow ? now() : null,
                'notes' => $data['notes'] ?? null,
            ]);

            $this->audit->write(
                action: 'membership.created',
                entityType: 'membership',
                entityId: $membership->id,
                tenantId: $tenant->id,
                newValues: [
                    'member_id' => $membership->member_id,
                    'plan_id' => $membership->membership_plan_id,
                    'status' => $membership->status,
                ]
            );

            return $membership;
        });
    }
}
