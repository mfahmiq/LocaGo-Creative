<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Billing\Services\InvoiceService;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Memberships\Models\MembershipRenewal;
use App\Domains\Memberships\Services\MembershipService;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

/**
 * Member-initiated online renewal: activates renewed membership and issues an unpaid invoice.
 *
 * @return array{membership: Membership, invoice: \App\Domains\Billing\Models\Invoice|null}
 */
final class MemberRenewMembershipAction extends Action
{
    public function __construct(
        private readonly MembershipService $memberships,
        private readonly InvoiceService $invoices,
        private readonly RenewMembershipAction $renewMembershipAction
    ) {}

    public function execute(mixed ...$args): array
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $membershipId */
        $membershipId = (int) $args[1];
        /** @var int $memberId */
        $memberId = (int) $args[2];
        /** @var array<string, mixed> $data */
        $data = $args[3] ?? [];

        return $this->transaction(function () use ($tenant, $membershipId, $memberId, $data): array {
            $from = $this->memberships->find($tenant, $membershipId);

            if ((int) $from->member_id !== $memberId) {
                throw new DomainException('Membership not found.', 'membership_not_found', Response::HTTP_NOT_FOUND);
            }

            $pending = MembershipRenewal::query()
                ->where('tenant_id', $tenant->id)
                ->where('from_membership_id', $from->id)
                ->where('status', MembershipRenewal::STATUS_REQUESTED)
                ->whereNull('deleted_at')
                ->exists();

            if ($pending) {
                throw new DomainException(
                    'A renewal request is already pending for this membership.',
                    'renewal_already_requested',
                    Response::HTTP_CONFLICT
                );
            }

            $payload = [
                'membership_plan_id' => $data['membership_plan_id'] ?? $from->membership_plan_id,
                'change_type' => $data['change_type'] ?? MembershipRenewal::CHANGE_RENEW,
                'start_mode' => $data['start_mode'] ?? 'from_end_date',
                'notes' => $data['notes'] ?? 'Online renewal via member portal',
                'request_source' => 'member',
            ];

            $to = $this->renewMembershipAction->execute($tenant, $membershipId, $payload);
            $to->loadMissing('plan');

            $invoice = null;
            $price = (float) ($to->price_snapshot ?? $to->plan?->price ?? 0);
            if ($price > 0) {
                $invoice = $this->invoices->create($tenant, [
                    'member_id' => $memberId,
                    'branch_id' => $to->branch_id,
                    'currency_code' => $to->currency_code ?: $tenant->base_currency,
                    'issue_now' => true,
                    'due_date' => now()->addDays(7)->toDateString(),
                    'source_type' => 'membership_renewal',
                    'source_id' => $to->id,
                    'notes' => 'Membership renewal — pay at gym or online',
                    'items' => [[
                        'description' => 'Membership: '.($to->plan?->name ?? 'Plan').' (renewal)',
                        'quantity' => 1,
                        'unit_price' => $price,
                        'discount_amount' => 0,
                        'tax_rate_percent' => null,
                    ]],
                ]);

                MembershipRenewal::query()
                    ->where('tenant_id', $tenant->id)
                    ->where('to_membership_id', $to->id)
                    ->whereNull('deleted_at')
                    ->orderByDesc('id')
                    ->limit(1)
                    ->update(['invoice_id' => $invoice->id]);
            }

            return [
                'membership' => $to->fresh(['plan', 'member']),
                'invoice' => $invoice,
            ];
        });
    }
}
