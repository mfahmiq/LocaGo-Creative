<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Memberships\Contracts\MembershipPlanRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeleteMembershipPlanAction extends Action
{
    public function __construct(
        private readonly MembershipPlanRepositoryInterface $plans,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $planId */
        $planId = (int) $args[1];

        $plan = $this->plans->findForTenant($tenant->id, $planId);

        if ($plan === null) {
            throw new DomainException('Membership plan not found.', 'membership_plan_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($this->plans->hasActiveMemberships($plan->id)) {
            throw new DomainException(
                'Cannot delete a plan with active memberships. Deactivate it instead.',
                'membership_plan_in_use',
                Response::HTTP_CONFLICT
            );
        }

        $deleted = $this->plans->deletePlan($plan);

        $this->audit->write(
            action: 'membership_plan.deleted',
            entityType: 'membership_plan',
            entityId: $planId,
            tenantId: $tenant->id,
            oldValues: [
                'code' => $plan->code,
                'name' => $plan->name,
                'is_active' => $plan->is_active,
            ]
        );

        return $deleted;
    }
}
