<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Memberships\Models\MembershipRenewal;
use App\Domains\Tenancy\Models\Tenant;
use Carbon\Carbon;
use Symfony\Component\HttpFoundation\Response;

final class RenewMembershipAction extends Action
{
    public function __construct(
        private readonly MembershipRepositoryInterface $memberships,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Membership
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $membershipId */
        $membershipId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        return $this->transaction(function () use ($tenant, $membershipId, $data): Membership {
            $from = $this->memberships->findForTenant($tenant->id, $membershipId);

            if ($from === null) {
                throw new DomainException('Membership not found.', 'membership_not_found', Response::HTTP_NOT_FOUND);
            }

            if ($from->status === Membership::STATUS_FROZEN) {
                throw new DomainException(
                    'Unfreeze the membership before renewing.',
                    'membership_frozen',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            if (! in_array($from->status, [
                Membership::STATUS_PENDING,
                Membership::STATUS_ACTIVE,
                Membership::STATUS_EXPIRED,
                Membership::STATUS_GRACE,
                Membership::STATUS_CANCELLED,
            ], true)) {
                throw new DomainException(
                    'Membership cannot be renewed from current status.',
                    'invalid_membership_status',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $changeType = (string) ($data['change_type'] ?? MembershipRenewal::CHANGE_RENEW);
            if (! in_array($changeType, [
                MembershipRenewal::CHANGE_RENEW,
                MembershipRenewal::CHANGE_UPGRADE,
                MembershipRenewal::CHANGE_DOWNGRADE,
            ], true)) {
                throw new DomainException(
                    'Invalid change type.',
                    'invalid_change_type',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $planId = (int) ($data['membership_plan_id'] ?? $from->membership_plan_id);
            $plan = $this->memberships->findActivePlanForTenant($tenant->id, $planId);

            if ($plan === null) {
                throw new DomainException(
                    'Membership plan not found or inactive.',
                    'membership_plan_not_found',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $fromPrice = (float) $from->price_snapshot;
            $toPrice = (float) $plan->price;

            if ($changeType === MembershipRenewal::CHANGE_UPGRADE) {
                if ($plan->id === (int) $from->membership_plan_id) {
                    throw new DomainException(
                        'Upgrade requires a different membership plan.',
                        'upgrade_same_plan',
                        Response::HTTP_UNPROCESSABLE_ENTITY
                    );
                }
                if ($toPrice <= $fromPrice) {
                    throw new DomainException(
                        'Upgrade plan must have a higher price than the current membership.',
                        'upgrade_price_invalid',
                        Response::HTTP_UNPROCESSABLE_ENTITY
                    );
                }
            }

            if ($changeType === MembershipRenewal::CHANGE_DOWNGRADE) {
                if ($plan->id === (int) $from->membership_plan_id) {
                    throw new DomainException(
                        'Downgrade requires a different membership plan.',
                        'downgrade_same_plan',
                        Response::HTTP_UNPROCESSABLE_ENTITY
                    );
                }
                if ($toPrice >= $fromPrice) {
                    throw new DomainException(
                        'Downgrade plan must have a lower price than the current membership.',
                        'downgrade_price_invalid',
                        Response::HTTP_UNPROCESSABLE_ENTITY
                    );
                }
            }

            $fromEnd = $from->end_date?->copy();
            $startMode = (string) ($data['start_mode'] ?? 'from_end_date');

            if (! empty($data['start_date'])) {
                $start = Carbon::parse((string) $data['start_date'])->startOfDay();
            } elseif ($startMode === 'from_end_date' && $fromEnd !== null && $fromEnd->isFuture()) {
                $start = $fromEnd->copy()->addDay();
            } else {
                $start = Carbon::today();
            }

            $end = null;
            if ($plan->duration_days !== null) {
                $end = $start->copy()->addDays((int) $plan->duration_days)->subDay();
            }

            $to = $this->memberships->createMembership([
                'tenant_id' => $tenant->id,
                'member_id' => $from->member_id,
                'membership_plan_id' => $plan->id,
                'branch_id' => $from->branch_id,
                'status' => Membership::STATUS_ACTIVE,
                'start_date' => $start->toDateString(),
                'end_date' => $end?->toDateString(),
                'visits_remaining' => $plan->visit_limit,
                'price_snapshot' => $plan->price,
                'currency_code' => $plan->currency_code ?: $tenant->base_currency,
                'activated_at' => now(),
                'notes' => $data['notes'] ?? null,
            ]);

            $this->memberships->createRenewal([
                'tenant_id' => $tenant->id,
                'member_id' => $from->member_id,
                'from_membership_id' => $from->id,
                'to_membership_id' => $to->id,
                'membership_plan_id' => $plan->id,
                'request_source' => (string) ($data['request_source'] ?? 'admin'),
                'change_type' => $changeType,
                'status' => MembershipRenewal::STATUS_COMPLETED,
                'renewed_at' => now(),
                'notes' => $data['notes'] ?? null,
            ]);

            if (in_array($from->status, [Membership::STATUS_ACTIVE, Membership::STATUS_GRACE], true)) {
                $this->memberships->updateMembership($from, [
                    'status' => Membership::STATUS_EXPIRED,
                ]);
            }

            $this->memberships->resolveOpenEscalationsForMembership((int) $from->id);

            $auditAction = match ($changeType) {
                MembershipRenewal::CHANGE_UPGRADE => 'membership.upgraded',
                MembershipRenewal::CHANGE_DOWNGRADE => 'membership.downgraded',
                default => 'membership.renewed',
            };

            $this->audit->write(
                action: $auditAction,
                entityType: 'membership',
                entityId: $to->id,
                tenantId: $tenant->id,
                oldValues: [
                    'from_membership_id' => $from->id,
                    'from_plan_id' => $from->membership_plan_id,
                    'from_price' => $fromPrice,
                ],
                newValues: [
                    'to_membership_id' => $to->id,
                    'plan_id' => $plan->id,
                    'change_type' => $changeType,
                    'to_price' => $toPrice,
                ]
            );

            return $to;
        });
    }
}
