<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Memberships\Contracts\MembershipPlanRepositoryInterface;
use App\Domains\Memberships\Models\MembershipPlan;
use App\Domains\Memberships\Support\MembershipPlanRules;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

final class CreateMembershipPlanAction extends Action
{
    public function __construct(
        private readonly MembershipPlanRepositoryInterface $plans,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): MembershipPlan
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        return $this->transaction(function () use ($tenant, $data): MembershipPlan {
            $code = strtoupper(trim((string) $data['code']));

            if ($this->plans->codeExistsForTenant($tenant->id, $code)) {
                throw new DomainException(
                    'A plan with this code already exists.',
                    'membership_plan_code_exists',
                    Response::HTTP_CONFLICT
                );
            }

            MembershipPlanRules::assertTypeFields($data);

            $allowsAll = (bool) ($data['allows_all_branches'] ?? false);
            $branchIds = array_values(array_unique(array_map('intval', $data['branch_ids'] ?? [])));

            $this->assertBranchScope($tenant->id, $allowsAll, $branchIds);
            $this->assertTaxRate($tenant->id, $data['tax_rate_id'] ?? null);

            $plan = $this->plans->createPlan([
                'tenant_id' => $tenant->id,
                'code' => $code,
                'name' => $data['name'],
                'description' => $data['description'] ?? null,
                'plan_type' => $data['plan_type'],
                'duration_days' => $data['duration_days'] ?? null,
                'visit_limit' => $data['visit_limit'] ?? null,
                'price' => $data['price'],
                'currency_code' => strtoupper((string) ($data['currency_code'] ?? $tenant->base_currency ?: 'INR')),
                'allows_walkin' => (bool) ($data['allows_walkin'] ?? true),
                'allows_all_branches' => $allowsAll,
                'freeze_allowed' => (bool) ($data['freeze_allowed'] ?? true),
                'max_freeze_days' => $data['max_freeze_days'] ?? null,
                'tax_rate_id' => $data['tax_rate_id'] ?? null,
                'is_active' => (bool) ($data['is_active'] ?? true),
            ]);

            if (! $allowsAll) {
                $this->plans->syncBranches($plan, $tenant->id, $branchIds);
            }

            $this->audit->write(
                action: 'membership_plan.created',
                entityType: 'membership_plan',
                entityId: $plan->id,
                tenantId: $tenant->id,
                newValues: [
                    'code' => $plan->code,
                    'plan_type' => $plan->plan_type,
                    'price' => $plan->price,
                    'is_active' => $plan->is_active,
                ]
            );

            return $plan->load('branches');
        });
    }

    /**
     * @param  list<int>  $branchIds
     */
    private function assertBranchScope(int $tenantId, bool $allowsAll, array $branchIds): void
    {
        if ($allowsAll) {
            return;
        }

        if ($branchIds === []) {
            throw new DomainException(
                'branch_ids are required when allows_all_branches is false.',
                'branch_ids_required',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        foreach ($branchIds as $branchId) {
            if ($this->branches->findActiveForTenant($tenantId, $branchId) === null) {
                throw new DomainException(
                    'One or more branches are invalid or inactive.',
                    'invalid_branch',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }
        }
    }

    private function assertTaxRate(int $tenantId, mixed $taxRateId): void
    {
        if ($taxRateId === null || $taxRateId === '') {
            return;
        }

        $exists = DB::table('tax_rates')
            ->where('tenant_id', $tenantId)
            ->where('id', (int) $taxRateId)
            ->where('is_active', 1)
            ->whereNull('deleted_at')
            ->exists();

        if (! $exists) {
            throw new DomainException(
                'Tax rate is invalid or inactive.',
                'invalid_tax_rate',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }
}
