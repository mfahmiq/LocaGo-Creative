<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CancelMembershipAction extends Action
{
    public function __construct(
        private readonly MembershipRepositoryInterface $memberships,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Membership
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $membershipId */
        $membershipId = (int) $args[1];
        /** @var string|null $reason */
        $reason = $args[2] ?? null;

        $membership = $this->memberships->findForTenant($tenant->id, $membershipId);

        if ($membership === null) {
            throw new DomainException('Membership not found.', 'membership_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($membership->status === Membership::STATUS_CANCELLED) {
            throw new DomainException(
                'Membership is already cancelled.',
                'membership_already_cancelled',
                Response::HTTP_CONFLICT
            );
        }

        $old = $membership->status;

        $updated = $this->memberships->updateMembership($membership, [
            'status' => Membership::STATUS_CANCELLED,
            'cancelled_at' => now(),
            'cancel_reason' => $reason,
        ]);

        $this->audit->write(
            action: 'membership.cancelled',
            entityType: 'membership',
            entityId: $updated->id,
            tenantId: $tenant->id,
            oldValues: ['status' => $old],
            newValues: ['status' => Membership::STATUS_CANCELLED, 'cancel_reason' => $reason]
        );

        return $updated;
    }
}
