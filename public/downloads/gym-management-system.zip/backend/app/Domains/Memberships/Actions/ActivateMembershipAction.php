<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Memberships\Contracts\MembershipRepositoryInterface;
use App\Domains\Memberships\Models\Membership;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class ActivateMembershipAction extends Action
{
    public function __construct(
        private readonly MembershipRepositoryInterface $memberships,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Membership
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $membershipId */
        $membershipId = (int) $args[1];

        $membership = $this->memberships->findForTenant($tenant->id, $membershipId);

        if ($membership === null) {
            throw new DomainException('Membership not found.', 'membership_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($membership->status !== Membership::STATUS_PENDING) {
            throw new DomainException(
                'Only pending memberships can be activated.',
                'invalid_membership_status',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $updated = $this->memberships->updateMembership($membership, [
            'status' => Membership::STATUS_ACTIVE,
            'activated_at' => now(),
        ]);

        $this->audit->write(
            action: 'membership.activated',
            entityType: 'membership',
            entityId: $updated->id,
            tenantId: $tenant->id,
            oldValues: ['status' => Membership::STATUS_PENDING],
            newValues: ['status' => Membership::STATUS_ACTIVE]
        );

        return $updated;
    }
}
