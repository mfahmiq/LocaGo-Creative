<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Memberships\Contracts\MembershipPlanRepositoryInterface;
use App\Domains\Memberships\Models\MembershipPlan;
use App\Domains\Memberships\Support\MembershipPlanRules;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

final class UpdateMembershipPlanAction extends Action
{
    public function __construct(
        private readonly MembershipPlanRepositoryInterface $plans,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): MembershipPlan
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $planId */
        $planId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        return $this->transaction(function () use ($tenant, $planId, $data): MembershipPlan {
            $plan = $this->plans->findForTenant($tenant->id, $planId);

            if ($plan === null) {
                throw new DomainException('Membership plan not found.', 'membership_plan_not_found', Response::HTTP_NOT_FOUND);
            }

            if (isset($data['code'])) {
                $code = strtoupper(trim((string) $data['code']));
                if ($this->plans->codeExistsForTenant($tenant->id, $code, $plan->id)) {
                    throw new DomainException(
                        'A plan with this code already exists.',
                        'membership_plan_code_exists',
                        Response::HTTP_CONFLICT
                    );
                }
                $data['code'] = $code;
            }

            $merged = MembershipPlanRules::mergeForUpdate($data, [
                'plan_type' => $plan->plan_type,
                'duration_days' => $plan->duration_days,
                'visit_limit' => $plan->visit_limit,
            ]);
            MembershipPlanRules::assertTypeFields($merged);

            $allowsAll = array_key_exists('allows_all_branches', $data)
                ? (bool) $data['allows_all_branches']
                : (bool) $plan->allows_all_branches;

            $branchIds = array_key_exists('branch_ids', $data)
                ? array_values(array_unique(array_map('intval', $data['branch_ids'] ?? [])))
                : $plan->branches->pluck('id')->map(fn ($id) => (int) $id)->all();

            if (array_key_exists('allows_all_branches', $data) || array_key_exists('branch_ids', $data)) {
                $this->assertBranchScope($tenant->id, $allowsAll, $branchIds);
            }

            if (array_key_exists('tax_rate_id', $data)) {
                $this->assertTaxRate($tenant->id, $data['tax_rate_id']);
            }

            $payload = [];
            foreach ([
                'code', 'name', 'description', 'plan_type', 'duration_days', 'visit_limit',
                'price', 'currency_code', 'allows_walkin', 'allows_all_branches',
                'freeze_allowed', 'max_freeze_days', 'tax_rate_id', 'is_active',
            ] as $field) {
                if (array_key_exists($field, $data)) {
                    $payload[$field] = $data[$field];
                }
            }

            if (isset($payload['currency_code'])) {
                $payload['currency_code'] = strtoupper((string) $payload['currency_code']);
            }

            $updated = $this->plans->updatePlan($plan, $payload);

            if (array_key_exists('allows_all_branches', $data) || array_key_exists('branch_ids', $data)) {
                if ($allowsAll) {
                    $this->plans->clearBranches($updated);
                } else {
                    $this->plans->syncBranches($updated, $tenant->id, $branchIds);
                }
            }

            $this->audit->write(
                action: 'membership_plan.updated',
                entityType: 'membership_plan',
                entityId: $updated->id,
                tenantId: $tenant->id,
                newValues: [
                    'code' => $updated->code,
                    'is_active' => $updated->is_active,
                    'price' => $updated->price,
                ]
            );

            return $updated->load('branches');
        });
    }

    /**
     * @param  list<int>  $branchIds
     */
    private function assertBranchScope(int $tenantId, bool $allowsAll, array $branchIds): void
    {
        if ($allowsAll) {
            return;
        }

        if ($branchIds === []) {
            throw new DomainException(
                'branch_ids are required when allows_all_branches is false.',
                'branch_ids_required',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        foreach ($branchIds as $branchId) {
            if ($this->branches->findActiveForTenant($tenantId, $branchId) === null) {
                throw new DomainException(
                    'One or more branches are invalid or inactive.',
                    'invalid_branch',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }
        }
    }

    private function assertTaxRate(int $tenantId, mixed $taxRateId): void
    {
        if ($taxRateId === null || $taxRateId === '') {
            return;
        }

        $exists = DB::table('tax_rates')
            ->where('tenant_id', $tenantId)
            ->where('id', (int) $taxRateId)
            ->where('is_active', 1)
            ->whereNull('deleted_at')
            ->exists();

        if (! $exists) {
            throw new DomainException(
                'Tax rate is invalid or inactive.',
                'invalid_tax_rate',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }
    }
}
