<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Memberships\Models\Membership;

final class MembershipPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'memberships.instances.view');
    }

    public function view(User $user, Membership $membership): bool
    {
        return $this->hasPermission($user, 'memberships.instances.view')
            && $this->sameTenant($user, $membership);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'memberships.instances.manage');
    }

    public function activate(User $user, Membership $membership): bool
    {
        return $this->hasPermission($user, 'memberships.instances.manage')
            && $this->sameTenant($user, $membership);
    }

    public function cancel(User $user, Membership $membership): bool
    {
        return $this->hasPermission($user, 'memberships.instances.cancel')
            && $this->sameTenant($user, $membership);
    }

    public function freeze(User $user, Membership $membership): bool
    {
        return $this->hasPermission($user, 'memberships.instances.freeze')
            && $this->sameTenant($user, $membership);
    }

    public function unfreeze(User $user, Membership $membership): bool
    {
        return $this->freeze($user, $membership);
    }

    public function renew(User $user, Membership $membership): bool
    {
        return $this->hasPermission($user, 'memberships.instances.manage')
            && $this->sameTenant($user, $membership);
    }

    public function upgrade(User $user, Membership $membership): bool
    {
        return $this->renew($user, $membership);
    }

    public function downgrade(User $user, Membership $membership): bool
    {
        return $this->renew($user, $membership);
    }

    public function viewEscalations(User $user): bool
    {
        return $this->hasPermission($user, 'memberships.instances.view');
    }

    public function manageEscalations(User $user): bool
    {
        return $this->hasPermission($user, 'memberships.instances.manage');
    }
}
