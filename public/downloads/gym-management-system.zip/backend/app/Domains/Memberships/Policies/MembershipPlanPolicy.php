<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Memberships\Models\MembershipPlan;

final class MembershipPlanPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'memberships.plans.view');
    }

    public function view(User $user, MembershipPlan $plan): bool
    {
        return $this->hasPermission($user, 'memberships.plans.view')
            && $this->sameTenant($user, $plan);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'memberships.plans.manage');
    }

    public function update(User $user, MembershipPlan $plan): bool
    {
        return $this->hasPermission($user, 'memberships.plans.manage')
            && $this->sameTenant($user, $plan);
    }

    public function delete(User $user, MembershipPlan $plan): bool
    {
        return $this->update($user, $plan);
    }
}
