<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Contracts;

use App\Domains\Memberships\Models\MembershipPlan;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface MembershipPlanRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $planId): ?MembershipPlan;

    public function codeExistsForTenant(int $tenantId, string $code, ?int $exceptPlanId = null): bool;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createPlan(array $attributes): MembershipPlan;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updatePlan(MembershipPlan $plan, array $attributes): MembershipPlan;

    public function deletePlan(MembershipPlan $plan): bool;

    /**
     * @param  list<int>  $branchIds
     */
    public function syncBranches(MembershipPlan $plan, int $tenantId, array $branchIds): void;

    public function clearBranches(MembershipPlan $plan): void;

    public function hasActiveMemberships(int $planId): bool;
}
