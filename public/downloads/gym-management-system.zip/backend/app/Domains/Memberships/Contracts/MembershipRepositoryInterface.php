<?php

declare(strict_types=1);

namespace App\Domains\Memberships\Contracts;

use App\Domains\Memberships\Models\Membership;
use App\Domains\Memberships\Models\MembershipEscalation;
use App\Domains\Memberships\Models\MembershipFreeze;
use App\Domains\Memberships\Models\MembershipPlan;
use App\Domains\Memberships\Models\MembershipRenewal;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

interface MembershipRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $membershipId): ?Membership;

    public function findActivePlanForTenant(int $tenantId, int $planId): ?MembershipPlan;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createMembership(array $attributes): Membership;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateMembership(Membership $membership, array $attributes): Membership;

    public function findActiveFreeze(int $membershipId): ?MembershipFreeze;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createFreeze(array $attributes): MembershipFreeze;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateFreeze(MembershipFreeze $freeze, array $attributes): MembershipFreeze;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createRenewal(array $attributes): MembershipRenewal;

    /**
     * @return Collection<int, Membership>
     */
    public function findActiveEndingOn(string $endDate): Collection;

    /**
     * Memberships in given statuses ending on a specific date.
     *
     * @param  list<string>  $statuses
     * @return Collection<int, Membership>
     */
    public function findEndedOnStatuses(string $endDate, array $statuses): Collection;

    /**
     * @return Collection<int, Membership>
     */
    public function findActivePastEndDate(string $asOfDate): Collection;

    /**
     * @return Collection<int, Membership>
     */
    public function findGracePastGraceWindow(string $asOfDate, int $graceDays): Collection;

    /**
     * @return Collection<int, Membership>
     */
    public function findActiveEndingWithinDays(int $tenantId, int $withinDays): Collection;

    public function countForTenantByStatus(int $tenantId, string $status): int;

    public function countExpiringSoonForTenant(int $tenantId, int $withinDays): int;

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateEscalationsForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findEscalationForTenant(int $tenantId, int $escalationId): ?MembershipEscalation;

    public function findOpenEscalationForMembership(int $membershipId): ?MembershipEscalation;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createEscalation(array $attributes): MembershipEscalation;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateEscalation(MembershipEscalation $escalation, array $attributes): MembershipEscalation;

    public function resolveOpenEscalationsForMembership(int $membershipId): int;

    public function countOpenEscalationsForTenant(int $tenantId): int;

    /**
     * @return array<string, int>
     */
    public function countOpenEscalationsByTier(int $tenantId): array;

    /**
     * Candidates for escalation evaluation (active/grace/expired with end_date).
     *
     * @return Collection<int, Membership>
     */
    public function findEscalationCandidates(): Collection;
}
