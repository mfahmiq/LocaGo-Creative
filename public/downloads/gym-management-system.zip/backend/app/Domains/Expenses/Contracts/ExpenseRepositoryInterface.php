<?php

declare(strict_types=1);

namespace App\Domains\Expenses\Contracts;

use App\Domains\Expenses\Models\Expense;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface ExpenseRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $expenseId): ?Expense;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createExpense(array $attributes): Expense;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateExpense(Expense $expense, array $attributes): Expense;

    public function deleteExpense(Expense $expense): bool;
}
