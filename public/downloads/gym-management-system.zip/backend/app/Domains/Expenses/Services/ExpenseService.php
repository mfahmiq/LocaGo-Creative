<?php

declare(strict_types=1);

namespace App\Domains\Expenses\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Expenses\Actions\ApproveExpenseAction;
use App\Domains\Expenses\Actions\CreateExpenseAction;
use App\Domains\Expenses\Actions\DeleteExpenseAction;
use App\Domains\Expenses\Actions\RejectExpenseAction;
use App\Domains\Expenses\Actions\UpdateExpenseAction;
use App\Domains\Expenses\Actions\VoidExpenseAction;
use App\Domains\Expenses\Contracts\ExpenseRepositoryInterface;
use App\Domains\Expenses\Models\Expense;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class ExpenseService extends BaseService
{
    public function __construct(
        private readonly ExpenseRepositoryInterface $expenses,
        private readonly CreateExpenseAction $createExpenseAction,
        private readonly UpdateExpenseAction $updateExpenseAction,
        private readonly DeleteExpenseAction $deleteExpenseAction,
        private readonly ApproveExpenseAction $approveExpenseAction,
        private readonly RejectExpenseAction $rejectExpenseAction,
        private readonly VoidExpenseAction $voidExpenseAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->expenses->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $expenseId): Expense
    {
        $expense = $this->expenses->findForTenant($tenant->id, $expenseId);

        if ($expense === null) {
            throw new DomainException('Expense not found.', 'expense_not_found', Response::HTTP_NOT_FOUND);
        }

        return $expense;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): Expense
    {
        return $this->createExpenseAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $expenseId, array $data): Expense
    {
        return $this->updateExpenseAction->execute($tenant, $expenseId, $data);
    }

    public function delete(Tenant $tenant, int $expenseId): bool
    {
        return $this->deleteExpenseAction->execute($tenant, $expenseId);
    }

    public function approve(Tenant $tenant, int $expenseId): Expense
    {
        return $this->approveExpenseAction->execute($tenant, $expenseId);
    }

    public function reject(Tenant $tenant, int $expenseId): Expense
    {
        return $this->rejectExpenseAction->execute($tenant, $expenseId);
    }

    public function void(Tenant $tenant, int $expenseId): Expense
    {
        return $this->voidExpenseAction->execute($tenant, $expenseId);
    }
}
