# Expenses Domain

## Admin Portal — Expenses (complete)

Requires `auth:sanctum` + staff + `X-Tenant-Slug` + permissions (`expenses.view` / `expenses.manage`).

### Expenses

| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/expenses` | view / manage |
| GET/PUT/DELETE | `/api/v1/admin/expenses/{id}` | view / manage |
| POST | `/api/v1/admin/expenses/{id}/approve` | manage |
| POST | `/api/v1/admin/expenses/{id}/reject` | manage |
| POST | `/api/v1/admin/expenses/{id}/void` | manage |

Statuses: `recorded` \| `approved` \| `rejected` \| `void`

Only `recorded` expenses can be updated or status-transitioned. Optional `branch_id` is validated against active tenant branches.

List filters: `status`, `category`, `branch_id`, `from`, `to`, `search`, `per_page`

Audited: `expense.*`

## Next Admin modules
Admin core catalog complete (through Reports).
