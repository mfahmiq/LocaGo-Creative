<?php

declare(strict_types=1);

namespace App\Domains\Expenses\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Expenses\Models\Expense;
use App\Domains\Identity\Models\User;

final class ExpensePolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'expenses.view');
    }

    public function view(User $user, Expense $expense): bool
    {
        return $this->hasPermission($user, 'expenses.view')
            && $this->sameTenant($user, $expense)
            && $this->branchAllowed($user, $expense->branch_id !== null ? (int) $expense->branch_id : null);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'expenses.manage');
    }

    public function update(User $user, Expense $expense): bool
    {
        return $this->hasPermission($user, 'expenses.manage')
            && $this->sameTenant($user, $expense)
            && $this->branchAllowed($user, $expense->branch_id !== null ? (int) $expense->branch_id : null);
    }

    public function delete(User $user, Expense $expense): bool
    {
        return $this->update($user, $expense);
    }

    public function approve(User $user, Expense $expense): bool
    {
        return $this->update($user, $expense);
    }

    public function reject(User $user, Expense $expense): bool
    {
        return $this->update($user, $expense);
    }

    public function void(User $user, Expense $expense): bool
    {
        return $this->update($user, $expense);
    }
}
