<?php

declare(strict_types=1);

namespace App\Domains\Expenses\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Organization\Models\Branch;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Expense extends BaseModel
{
    use BelongsToTenant;

    public const STATUS_RECORDED = 'recorded';

    public const STATUS_APPROVED = 'approved';

    public const STATUS_REJECTED = 'rejected';

    public const STATUS_VOID = 'void';

    protected $table = 'expenses';

    protected $fillable = [
        'tenant_id',
        'branch_id',
        'category',
        'vendor_name',
        'amount',
        'tax_amount',
        'currency_code',
        'expense_date',
        'status',
        'receipt_path',
        'maintenance_order_id',
        'notes',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:2',
            'tax_amount' => 'decimal:2',
            'expense_date' => 'date',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function isRecorded(): bool
    {
        return $this->status === self::STATUS_RECORDED;
    }
}
