<?php

declare(strict_types=1);

namespace App\Domains\Expenses\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Expenses\Contracts\ExpenseRepositoryInterface;
use App\Domains\Expenses\Models\Expense;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<Expense>
 */
class EloquentExpenseRepository extends BaseRepository implements ExpenseRepositoryInterface
{
    public function __construct(Expense $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['branch'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('expense_date')
            ->orderByDesc('id');

        if (! empty($filters['status'])) {
            $query->where('status', (string) $filters['status']);
        }

        if (! empty($filters['category'])) {
            $query->where('category', (string) $filters['category']);
        }

        if (! empty($filters['branch_id'])) {
            $query->where('branch_id', (int) $filters['branch_id']);
        }

        if (! empty($filters['from'])) {
            $query->whereDate('expense_date', '>=', (string) $filters['from']);
        }

        if (! empty($filters['to'])) {
            $query->whereDate('expense_date', '<=', (string) $filters['to']);
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);
            $query->where(function ($q) use ($search): void {
                $q->where('category', 'like', "%{$search}%")
                    ->orWhere('vendor_name', 'like', "%{$search}%")
                    ->orWhere('notes', 'like', "%{$search}%");
            });
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $expenseId): ?Expense
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['branch'])
            ->where('tenant_id', $tenantId)
            ->where('id', $expenseId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function createExpense(array $attributes): Expense
    {
        /** @var Expense $expense */
        $expense = $this->query()->withoutGlobalScopes()->create($attributes);

        return $expense->load('branch');
    }

    public function updateExpense(Expense $expense, array $attributes): Expense
    {
        $expense->update($attributes);

        return $expense->fresh(['branch']);
    }

    public function deleteExpense(Expense $expense): bool
    {
        return (bool) $expense->delete();
    }
}
