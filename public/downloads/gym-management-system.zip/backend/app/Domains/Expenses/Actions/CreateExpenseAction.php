<?php

declare(strict_types=1);

namespace App\Domains\Expenses\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Expenses\Contracts\ExpenseRepositoryInterface;
use App\Domains\Expenses\Models\Expense;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CreateExpenseAction extends Action
{
    public function __construct(
        private readonly ExpenseRepositoryInterface $expenses,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Expense
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        $branchId = isset($data['branch_id']) ? (int) $data['branch_id'] : null;
        if ($branchId !== null && $this->branches->findActiveForTenant($tenant->id, $branchId) === null) {
            throw new DomainException('Branch is invalid or inactive.', 'invalid_branch', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        $expense = $this->expenses->createExpense([
            'tenant_id' => $tenant->id,
            'branch_id' => $branchId,
            'category' => (string) $data['category'],
            'vendor_name' => $data['vendor_name'] ?? null,
            'amount' => number_format((float) $data['amount'], 2, '.', ''),
            'tax_amount' => number_format((float) ($data['tax_amount'] ?? 0), 2, '.', ''),
            'currency_code' => strtoupper((string) ($data['currency_code'] ?? $tenant->base_currency ?: 'INR')),
            'expense_date' => (string) $data['expense_date'],
            'status' => Expense::STATUS_RECORDED,
            'receipt_path' => $data['receipt_path'] ?? null,
            'maintenance_order_id' => isset($data['maintenance_order_id']) ? (int) $data['maintenance_order_id'] : null,
            'notes' => $data['notes'] ?? null,
        ]);

        $this->audit->write(
            action: 'expense.created',
            entityType: 'expense',
            entityId: $expense->id,
            tenantId: $tenant->id,
            newValues: [
                'category' => $expense->category,
                'amount' => $expense->amount,
                'status' => $expense->status,
            ]
        );

        return $expense;
    }
}
