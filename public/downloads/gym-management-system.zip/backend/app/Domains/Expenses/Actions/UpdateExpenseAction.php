<?php

declare(strict_types=1);

namespace App\Domains\Expenses\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Expenses\Contracts\ExpenseRepositoryInterface;
use App\Domains\Expenses\Models\Expense;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateExpenseAction extends Action
{
    public function __construct(
        private readonly ExpenseRepositoryInterface $expenses,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Expense
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $expenseId */
        $expenseId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        $expense = $this->expenses->findForTenant($tenant->id, $expenseId);

        if ($expense === null) {
            throw new DomainException('Expense not found.', 'expense_not_found', Response::HTTP_NOT_FOUND);
        }

        if (! $expense->isRecorded()) {
            throw new DomainException(
                'Only recorded expenses can be updated.',
                'expense_not_editable',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $payload = [];

        if (array_key_exists('branch_id', $data)) {
            $branchId = $data['branch_id'] !== null ? (int) $data['branch_id'] : null;
            if ($branchId !== null && $this->branches->findActiveForTenant($tenant->id, $branchId) === null) {
                throw new DomainException('Branch is invalid or inactive.', 'invalid_branch', Response::HTTP_UNPROCESSABLE_ENTITY);
            }
            $payload['branch_id'] = $branchId;
        }

        foreach (['category', 'vendor_name', 'receipt_path', 'notes'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = $data[$field];
            }
        }

        if (array_key_exists('amount', $data)) {
            $payload['amount'] = number_format((float) $data['amount'], 2, '.', '');
        }

        if (array_key_exists('tax_amount', $data)) {
            $payload['tax_amount'] = number_format((float) $data['tax_amount'], 2, '.', '');
        }

        if (array_key_exists('currency_code', $data)) {
            $payload['currency_code'] = strtoupper((string) $data['currency_code']);
        }

        if (array_key_exists('expense_date', $data)) {
            $payload['expense_date'] = (string) $data['expense_date'];
        }

        if (array_key_exists('maintenance_order_id', $data)) {
            $payload['maintenance_order_id'] = $data['maintenance_order_id'] !== null
                ? (int) $data['maintenance_order_id']
                : null;
        }

        $updated = $this->expenses->updateExpense($expense, $payload);

        $this->audit->write(
            action: 'expense.updated',
            entityType: 'expense',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: $payload
        );

        return $updated;
    }
}
