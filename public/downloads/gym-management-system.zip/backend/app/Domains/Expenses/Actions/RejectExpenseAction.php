<?php

declare(strict_types=1);

namespace App\Domains\Expenses\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Expenses\Contracts\ExpenseRepositoryInterface;
use App\Domains\Expenses\Models\Expense;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class RejectExpenseAction extends Action
{
    public function __construct(
        private readonly ExpenseRepositoryInterface $expenses,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Expense
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $expenseId */
        $expenseId = (int) $args[1];

        $expense = $this->expenses->findForTenant($tenant->id, $expenseId);

        if ($expense === null) {
            throw new DomainException('Expense not found.', 'expense_not_found', Response::HTTP_NOT_FOUND);
        }

        if (! $expense->isRecorded()) {
            throw new DomainException(
                'Expense status can only be changed from recorded.',
                'invalid_expense_status',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $updated = $this->expenses->updateExpense($expense, ['status' => Expense::STATUS_REJECTED]);

        $this->audit->write(
            action: 'expense.rejected',
            entityType: 'expense',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: ['status' => Expense::STATUS_REJECTED]
        );

        return $updated;
    }
}
