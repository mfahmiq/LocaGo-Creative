<?php

declare(strict_types=1);

namespace App\Domains\Expenses\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Expenses\Contracts\ExpenseRepositoryInterface;
use App\Domains\Expenses\Models\Expense;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class ApproveExpenseAction extends Action
{
    public function __construct(
        private readonly ExpenseRepositoryInterface $expenses,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Expense
    {
        return $this->transition($args[0], (int) $args[1], Expense::STATUS_APPROVED, 'expense.approved');
    }

    private function transition(Tenant $tenant, int $expenseId, string $status, string $auditAction): Expense
    {
        $expense = $this->expenses->findForTenant($tenant->id, $expenseId);

        if ($expense === null) {
            throw new DomainException('Expense not found.', 'expense_not_found', Response::HTTP_NOT_FOUND);
        }

        if (! $expense->isRecorded()) {
            throw new DomainException(
                'Expense status can only be changed from recorded.',
                'invalid_expense_status',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $updated = $this->expenses->updateExpense($expense, ['status' => $status]);

        $this->audit->write(
            action: $auditAction,
            entityType: 'expense',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: ['status' => $status]
        );

        return $updated;
    }
}
