<?php

declare(strict_types=1);

namespace App\Domains\Expenses\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Expenses\Contracts\ExpenseRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeleteExpenseAction extends Action
{
    public function __construct(
        private readonly ExpenseRepositoryInterface $expenses,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $expenseId */
        $expenseId = (int) $args[1];

        $expense = $this->expenses->findForTenant($tenant->id, $expenseId);

        if ($expense === null) {
            throw new DomainException('Expense not found.', 'expense_not_found', Response::HTTP_NOT_FOUND);
        }

        $deleted = $this->expenses->deleteExpense($expense);

        $this->audit->write(
            action: 'expense.deleted',
            entityType: 'expense',
            entityId: $expenseId,
            tenantId: $tenant->id,
            oldValues: ['category' => $expense->category, 'amount' => $expense->amount]
        );

        return $deleted;
    }
}
