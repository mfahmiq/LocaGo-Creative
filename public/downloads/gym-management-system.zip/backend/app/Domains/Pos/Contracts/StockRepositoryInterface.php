<?php

declare(strict_types=1);

namespace App\Domains\Pos\Contracts;

use App\Domains\Pos\Models\ProductStock;
use App\Domains\Pos\Models\StockMovement;
use Illuminate\Support\Collection;

interface StockRepositoryInterface
{
    public function findStock(int $tenantId, int $productId, int $branchId): ?ProductStock;

    public function getOrCreateStock(int $tenantId, int $productId, int $branchId): ProductStock;

    /**
     * @return Collection<int, ProductStock>
     */
    public function listForProduct(int $tenantId, int $productId): Collection;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createMovement(array $attributes): StockMovement;

    public function applyDelta(ProductStock $stock, int $delta): ProductStock;
}
