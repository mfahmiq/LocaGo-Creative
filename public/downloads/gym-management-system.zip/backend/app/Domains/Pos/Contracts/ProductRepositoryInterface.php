<?php

declare(strict_types=1);

namespace App\Domains\Pos\Contracts;

use App\Domains\Pos\Models\Product;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface ProductRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $productId): ?Product;

    public function findActiveForTenant(int $tenantId, int $productId): ?Product;

    public function findBySku(int $tenantId, string $sku, ?int $excludeId = null): ?Product;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createProduct(array $attributes): Product;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateProduct(Product $product, array $attributes): Product;

    public function deleteProduct(Product $product): bool;
}
