<?php

declare(strict_types=1);

namespace App\Domains\Pos\Contracts;

use App\Domains\Pos\Models\Sale;
use App\Domains\Pos\Models\SaleItem;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

interface SaleRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $saleId): ?Sale;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createSale(array $attributes): Sale;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateSale(Sale $sale, array $attributes): Sale;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createSaleItem(array $attributes): SaleItem;

    /**
     * @return Collection<int, SaleItem>
     */
    public function listItems(int $saleId): Collection;
}
