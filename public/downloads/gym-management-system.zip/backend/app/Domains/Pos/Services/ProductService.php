<?php

declare(strict_types=1);

namespace App\Domains\Pos\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Pos\Actions\CreateProductAction;
use App\Domains\Pos\Actions\DeleteProductAction;
use App\Domains\Pos\Actions\UpdateProductAction;
use App\Domains\Pos\Contracts\ProductRepositoryInterface;
use App\Domains\Pos\Contracts\StockRepositoryInterface;
use App\Domains\Pos\Models\Product;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Symfony\Component\HttpFoundation\Response;

final class ProductService extends BaseService
{
    public function __construct(
        private readonly ProductRepositoryInterface $products,
        private readonly StockRepositoryInterface $stock,
        private readonly CreateProductAction $createProductAction,
        private readonly UpdateProductAction $updateProductAction,
        private readonly DeleteProductAction $deleteProductAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->products->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $productId): Product
    {
        $product = $this->products->findForTenant($tenant->id, $productId);

        if ($product === null) {
            throw new DomainException('Product not found.', 'product_not_found', Response::HTTP_NOT_FOUND);
        }

        return $product;
    }

    /**
     * @return Collection<int, \App\Domains\Pos\Models\ProductStock>
     */
    public function listStock(Tenant $tenant, int $productId): Collection
    {
        $this->find($tenant, $productId);

        return $this->stock->listForProduct($tenant->id, $productId);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): Product
    {
        return $this->createProductAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $productId, array $data): Product
    {
        return $this->updateProductAction->execute($tenant, $productId, $data);
    }

    public function delete(Tenant $tenant, int $productId): bool
    {
        return $this->deleteProductAction->execute($tenant, $productId);
    }
}
