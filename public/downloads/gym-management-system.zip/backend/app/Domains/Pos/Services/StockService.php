<?php

declare(strict_types=1);

namespace App\Domains\Pos\Services;

use App\Core\Services\BaseService;
use App\Domains\Pos\Actions\AdjustStockAction;
use App\Domains\Pos\Actions\DamageStockAction;
use App\Domains\Pos\Actions\ReceiveStockAction;
use App\Domains\Pos\Models\ProductStock;
use App\Domains\Tenancy\Models\Tenant;

final class StockService extends BaseService
{
    public function __construct(
        private readonly ReceiveStockAction $receiveStockAction,
        private readonly AdjustStockAction $adjustStockAction,
        private readonly DamageStockAction $damageStockAction
    ) {}

    /**
     * @param  array<string, mixed>  $data
     */
    public function receive(Tenant $tenant, int $productId, array $data): ProductStock
    {
        return $this->receiveStockAction->execute($tenant, $productId, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function adjust(Tenant $tenant, int $productId, array $data): ProductStock
    {
        return $this->adjustStockAction->execute($tenant, $productId, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function damage(Tenant $tenant, int $productId, array $data): ProductStock
    {
        return $this->damageStockAction->execute($tenant, $productId, $data);
    }
}
