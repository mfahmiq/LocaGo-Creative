<?php

declare(strict_types=1);

namespace App\Domains\Pos\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Pos\Actions\CreateSaleAction;
use App\Domains\Pos\Actions\VoidSaleAction;
use App\Domains\Pos\Contracts\SaleRepositoryInterface;
use App\Domains\Pos\Models\Sale;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class SaleService extends BaseService
{
    public function __construct(
        private readonly SaleRepositoryInterface $sales,
        private readonly CreateSaleAction $createSaleAction,
        private readonly VoidSaleAction $voidSaleAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->sales->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $saleId): Sale
    {
        $sale = $this->sales->findForTenant($tenant->id, $saleId);

        if ($sale === null) {
            throw new DomainException('Sale not found.', 'sale_not_found', Response::HTTP_NOT_FOUND);
        }

        return $sale;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): Sale
    {
        return $this->createSaleAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function void(Tenant $tenant, int $saleId, array $data = []): Sale
    {
        return $this->voidSaleAction->execute($tenant, $saleId, $data);
    }
}
