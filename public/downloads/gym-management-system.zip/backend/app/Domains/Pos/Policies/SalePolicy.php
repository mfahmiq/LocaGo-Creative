<?php

declare(strict_types=1);

namespace App\Domains\Pos\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Pos\Models\Sale;

final class SalePolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'pos.sales.view');
    }

    public function view(User $user, Sale $sale): bool
    {
        return $this->hasPermission($user, 'pos.sales.view')
            && $this->sameTenant($user, $sale)
            && $this->branchAllowed($user, $sale->branch_id !== null ? (int) $sale->branch_id : null);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'pos.sales.create');
    }

    public function void(User $user, Sale $sale): bool
    {
        return $this->hasPermission($user, 'pos.sales.create')
            && $this->sameTenant($user, $sale)
            && $this->branchAllowed($user, $sale->branch_id !== null ? (int) $sale->branch_id : null);
    }
}
