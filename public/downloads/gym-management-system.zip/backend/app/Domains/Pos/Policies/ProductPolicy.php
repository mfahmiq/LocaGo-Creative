<?php

declare(strict_types=1);

namespace App\Domains\Pos\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Pos\Models\Product;

final class ProductPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'pos.inventory.view');
    }

    public function view(User $user, Product $product): bool
    {
        return $this->hasPermission($user, 'pos.inventory.view')
            && $this->sameTenant($user, $product);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'pos.inventory.manage');
    }

    public function update(User $user, Product $product): bool
    {
        return $this->hasPermission($user, 'pos.inventory.manage')
            && $this->sameTenant($user, $product);
    }

    public function delete(User $user, Product $product): bool
    {
        return $this->update($user, $product);
    }

    public function manageStock(User $user, Product $product): bool
    {
        return $this->update($user, $product);
    }
}
