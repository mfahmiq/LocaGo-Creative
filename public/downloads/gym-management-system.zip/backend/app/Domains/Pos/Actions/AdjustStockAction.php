<?php

declare(strict_types=1);

namespace App\Domains\Pos\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Pos\Contracts\ProductRepositoryInterface;
use App\Domains\Pos\Contracts\StockRepositoryInterface;
use App\Domains\Pos\Models\ProductStock;
use App\Domains\Pos\Models\StockMovement;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

final class AdjustStockAction extends Action
{
    public function __construct(
        private readonly ProductRepositoryInterface $products,
        private readonly StockRepositoryInterface $stock,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): ProductStock
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $productId */
        $productId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        return $this->transaction(function () use ($tenant, $productId, $data): ProductStock {
            $product = $this->products->findForTenant($tenant->id, $productId);

            if ($product === null) {
                throw new DomainException('Product not found.', 'product_not_found', Response::HTTP_NOT_FOUND);
            }

            $branchId = (int) $data['branch_id'];
            if ($this->branches->findActiveForTenant($tenant->id, $branchId) === null) {
                throw new DomainException('Branch is invalid or inactive.', 'invalid_branch', Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $stock = $this->stock->getOrCreateStock($tenant->id, $productId, $branchId);

            if (array_key_exists('quantity', $data) && $data['quantity'] !== null) {
                $target = (int) $data['quantity'];
                if ($target < 0) {
                    throw new DomainException(
                        'Stock quantity cannot be negative.',
                        'invalid_quantity',
                        Response::HTTP_UNPROCESSABLE_ENTITY
                    );
                }
                $delta = $target - $stock->quantity;
            } elseif (array_key_exists('quantity_delta', $data)) {
                $delta = (int) $data['quantity_delta'];
                $target = $stock->quantity + $delta;
                if ($target < 0) {
                    throw new DomainException(
                        'Adjustment would result in negative stock.',
                        'insufficient_stock',
                        Response::HTTP_UNPROCESSABLE_ENTITY
                    );
                }
            } else {
                throw new DomainException(
                    'Either quantity or quantity_delta is required.',
                    'adjustment_value_required',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            if ($delta === 0) {
                return $stock->load('branch');
            }

            $updated = $this->stock->applyDelta($stock, $delta);

            $this->stock->createMovement([
                'tenant_id' => $tenant->id,
                'product_id' => $productId,
                'branch_id' => $branchId,
                'movement_type' => StockMovement::TYPE_ADJUST,
                'quantity_delta' => $delta,
                'reason' => $data['reason'] ?? null,
                'reference_type' => null,
                'reference_id' => null,
                'created_at' => now(),
                'created_by' => Auth::id(),
            ]);

            $this->audit->write(
                action: 'stock.adjusted',
                entityType: 'product',
                entityId: $productId,
                tenantId: $tenant->id,
                newValues: ['branch_id' => $branchId, 'quantity_delta' => $delta]
            );

            return $updated->load('branch');
        });
    }
}
