<?php

declare(strict_types=1);

namespace App\Domains\Pos\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Pos\Contracts\ProductRepositoryInterface;
use App\Domains\Pos\Models\Product;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateProductAction extends Action
{
    public function __construct(
        private readonly ProductRepositoryInterface $products,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Product
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $productId */
        $productId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        $product = $this->products->findForTenant($tenant->id, $productId);

        if ($product === null) {
            throw new DomainException('Product not found.', 'product_not_found', Response::HTTP_NOT_FOUND);
        }

        $attributes = [];

        if (array_key_exists('sku', $data)) {
            $sku = strtoupper(trim((string) $data['sku']));
            if ($this->products->findBySku($tenant->id, $sku, $product->id) !== null) {
                throw new DomainException(
                    'Product SKU already exists.',
                    'product_sku_exists',
                    Response::HTTP_CONFLICT
                );
            }
            $attributes['sku'] = $sku;
        }

        foreach (['name', 'description', 'unit_price', 'tax_rate_id', 'low_stock_threshold', 'is_active'] as $field) {
            if (array_key_exists($field, $data)) {
                $attributes[$field] = $data[$field];
            }
        }

        if (array_key_exists('currency_code', $data)) {
            $attributes['currency_code'] = strtoupper((string) $data['currency_code']);
        }

        $updated = $this->products->updateProduct($product, $attributes);

        $this->audit->write(
            action: 'product.updated',
            entityType: 'product',
            entityId: $product->id,
            tenantId: $tenant->id,
            newValues: $attributes
        );

        return $updated;
    }
}
