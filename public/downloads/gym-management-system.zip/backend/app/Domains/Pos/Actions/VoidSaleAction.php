<?php

declare(strict_types=1);

namespace App\Domains\Pos\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Pos\Contracts\SaleRepositoryInterface;
use App\Domains\Pos\Contracts\StockRepositoryInterface;
use App\Domains\Pos\Models\Sale;
use App\Domains\Pos\Models\StockMovement;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

final class VoidSaleAction extends Action
{
    public function __construct(
        private readonly SaleRepositoryInterface $sales,
        private readonly StockRepositoryInterface $stock,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Sale
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $saleId */
        $saleId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2] ?? [];

        return $this->transaction(function () use ($tenant, $saleId, $data): Sale {
            $sale = $this->sales->findForTenant($tenant->id, $saleId);

            if ($sale === null) {
                throw new DomainException('Sale not found.', 'sale_not_found', Response::HTTP_NOT_FOUND);
            }

            if (! $sale->isCompleted()) {
                throw new DomainException(
                    'Only completed sales can be voided.',
                    'sale_not_voidable',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            foreach ($sale->items as $item) {
                if ($item->product_id === null) {
                    continue;
                }

                $productId = (int) $item->product_id;
                $qty = (int) $item->quantity;
                $stockRow = $this->stock->getOrCreateStock($tenant->id, $productId, (int) $sale->branch_id);
                $this->stock->applyDelta($stockRow, $qty);

                $this->stock->createMovement([
                    'tenant_id' => $tenant->id,
                    'product_id' => $productId,
                    'branch_id' => (int) $sale->branch_id,
                    'movement_type' => StockMovement::TYPE_VOID_SALE,
                    'quantity_delta' => $qty,
                    'reason' => $data['reason'] ?? null,
                    'reference_type' => 'sale',
                    'reference_id' => $sale->id,
                    'created_at' => now(),
                    'created_by' => Auth::id(),
                ]);
            }

            $updated = $this->sales->updateSale($sale, ['status' => Sale::STATUS_VOID]);

            $this->audit->write(
                action: 'sale.voided',
                entityType: 'sale',
                entityId: $sale->id,
                tenantId: $tenant->id,
                newValues: ['status' => Sale::STATUS_VOID]
            );

            return $updated;
        });
    }
}
