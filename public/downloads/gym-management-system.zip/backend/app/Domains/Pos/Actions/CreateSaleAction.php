<?php

declare(strict_types=1);

namespace App\Domains\Pos\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Billing\Actions\CreateInvoiceAction;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Pos\Contracts\ProductRepositoryInterface;
use App\Domains\Pos\Contracts\SaleRepositoryInterface;
use App\Domains\Pos\Contracts\StockRepositoryInterface;
use App\Domains\Pos\Models\Sale;
use App\Domains\Pos\Models\StockMovement;
use App\Domains\Marketing\Contracts\CouponRepositoryInterface;
use App\Domains\Marketing\Models\Coupon;
use App\Domains\Marketing\Services\LoyaltyService;
use App\Domains\Marketing\Support\MarketingValidator;
use App\Domains\Pos\Support\SaleTotalsCalculator;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

final class CreateSaleAction extends Action
{
    public function __construct(
        private readonly SaleRepositoryInterface $sales,
        private readonly ProductRepositoryInterface $products,
        private readonly StockRepositoryInterface $stock,
        private readonly BranchRepositoryInterface $branches,
        private readonly MemberRepositoryInterface $members,
        private readonly CreateInvoiceAction $createInvoice,
        private readonly CouponRepositoryInterface $coupons,
        private readonly LoyaltyService $loyalty,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Sale
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        return $this->transaction(function () use ($tenant, $data): Sale {
            $items = $data['items'] ?? [];
            if (! is_array($items) || $items === []) {
                throw new DomainException(
                    'At least one sale item is required.',
                    'sale_items_required',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $branchId = (int) $data['branch_id'];
            if ($this->branches->findActiveForTenant($tenant->id, $branchId) === null) {
                throw new DomainException('Branch is invalid or inactive.', 'invalid_branch', Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $memberId = isset($data['member_id']) ? (int) $data['member_id'] : null;
            if ($memberId !== null && $this->members->findForTenant($tenant->id, $memberId) === null) {
                throw new DomainException('Member not found.', 'member_not_found', Response::HTTP_NOT_FOUND);
            }

            $lineInputs = [];
            foreach ($items as $item) {
                if (! is_array($item)) {
                    continue;
                }

                $productId = isset($item['product_id']) ? (int) $item['product_id'] : null;
                $description = trim((string) ($item['description'] ?? ''));
                $quantity = max(1, (int) ($item['quantity'] ?? 1));

                if ($productId !== null) {
                    $product = $this->products->findActiveForTenant($tenant->id, $productId);
                    if ($product === null) {
                        throw new DomainException(
                            'Product not found or inactive.',
                            'product_not_found',
                            Response::HTTP_UNPROCESSABLE_ENTITY
                        );
                    }

                    $stock = $this->stock->findStock($tenant->id, $productId, $branchId);
                    $available = $stock?->quantity ?? 0;
                    if ($available < $quantity) {
                        throw new DomainException(
                            "Insufficient stock for product {$product->sku}.",
                            'insufficient_stock',
                            Response::HTTP_UNPROCESSABLE_ENTITY
                        );
                    }

                    if ($description === '') {
                        $description = $product->name;
                    }

                    $unitPrice = $item['unit_price'] ?? $product->unit_price;
                } else {
                    if ($description === '') {
                        throw new DomainException(
                            'Item description is required when product_id is omitted.',
                            'item_description_required',
                            Response::HTTP_UNPROCESSABLE_ENTITY
                        );
                    }
                    $unitPrice = $item['unit_price'] ?? 0;
                }

                $lineInputs[] = [
                    'product_id' => $productId,
                    'description' => $description,
                    'quantity' => $quantity,
                    'unit_price' => $unitPrice,
                    'discount_amount' => $item['discount_amount'] ?? 0,
                    'tax_amount' => $item['tax_amount'] ?? 0,
                ];
            }

            $totals = SaleTotalsCalculator::calculate($lineInputs);
            $currency = strtoupper((string) ($data['currency_code'] ?? $tenant->base_currency ?: 'INR'));
            $cashierId = Auth::id();

            $coupon = null;
            $couponDiscount = 0.0;
            $couponCode = trim((string) ($data['coupon_code'] ?? ''));
            if ($couponCode !== '') {
                $coupon = $this->coupons->findByCode($tenant->id, strtoupper($couponCode));
                if ($coupon === null) {
                    throw new DomainException('Coupon not found.', 'coupon_not_found', Response::HTTP_UNPROCESSABLE_ENTITY);
                }
                $memberRedeemCount = $memberId !== null
                    ? $this->coupons->countRedemptionsForMember($tenant->id, $coupon->id, $memberId)
                    : 0;
                MarketingValidator::assertCouponRedeemable($coupon, $memberId, $memberRedeemCount);

                $base = (float) $totals['subtotal'] - (float) $totals['discount_total'];
                $couponDiscount = $coupon->discount_type === Coupon::DISCOUNT_TYPE_PERCENT
                    ? round($base * ((float) $coupon->discount_value / 100), 2)
                    : min($base, (float) $coupon->discount_value);
                $couponDiscount = max(0, $couponDiscount);
            }

            $discountTotal = round((float) $totals['discount_total'] + $couponDiscount, 2);
            $grandTotal = max(0, round((float) $totals['subtotal'] - $discountTotal + (float) $totals['tax_total'], 2));

            $sale = $this->sales->createSale([
                'tenant_id' => $tenant->id,
                'branch_id' => $branchId,
                'member_id' => $memberId,
                'coupon_id' => $coupon?->id,
                'cashier_user_id' => $cashierId,
                'status' => Sale::STATUS_COMPLETED,
                'currency_code' => $currency,
                'subtotal' => $totals['subtotal'],
                'discount_total' => $discountTotal,
                'tax_total' => $totals['tax_total'],
                'grand_total' => $grandTotal,
                'sold_at' => $data['sold_at'] ?? now(),
            ]);

            foreach ($totals['items'] as $line) {
                $this->sales->createSaleItem([
                    'tenant_id' => $tenant->id,
                    'sale_id' => $sale->id,
                    'product_id' => $line['product_id'],
                    'description' => $line['description'],
                    'quantity' => $line['quantity'],
                    'unit_price' => $line['unit_price'],
                    'discount_amount' => $line['discount_amount'],
                    'tax_amount' => $line['tax_amount'],
                    'line_total' => $line['line_total'],
                    'created_at' => now(),
                ]);

                if ($line['product_id'] !== null) {
                    $productId = (int) $line['product_id'];
                    $qty = (int) $line['quantity'];
                    $stockRow = $this->stock->getOrCreateStock($tenant->id, $productId, $branchId);
                    $this->stock->applyDelta($stockRow, -$qty);

                    $this->stock->createMovement([
                        'tenant_id' => $tenant->id,
                        'product_id' => $productId,
                        'branch_id' => $branchId,
                        'movement_type' => StockMovement::TYPE_SALE,
                        'quantity_delta' => -$qty,
                        'reason' => null,
                        'reference_type' => 'sale',
                        'reference_id' => $sale->id,
                        'created_at' => now(),
                        'created_by' => $cashierId,
                    ]);
                }
            }

            $invoice = null;
            if ((bool) ($data['create_invoice'] ?? false)) {
                $invoiceItems = array_map(static fn (array $line): array => [
                    'description' => $line['description'],
                    'quantity' => $line['quantity'],
                    'unit_price' => $line['unit_price'],
                    'discount_amount' => $line['discount_amount'],
                    'tax_rate_percent' => null,
                ], $totals['items']);

                $invoice = $this->createInvoice->execute($tenant, [
                    'member_id' => $memberId,
                    'branch_id' => $branchId,
                    'currency_code' => $currency,
                    'issue_now' => true,
                    'source_type' => 'sale',
                    'source_id' => $sale->id,
                    'items' => $invoiceItems,
                ]);

                if ($coupon !== null) {
                    $invoice->forceFill(['coupon_id' => $coupon->id])->save();
                }

                $sale = $this->sales->updateSale($sale, ['invoice_id' => $invoice->id]);
            }

            if ($coupon !== null) {
                $this->coupons->createRedemption([
                    'tenant_id' => $tenant->id,
                    'coupon_id' => $coupon->id,
                    'member_id' => $memberId,
                    'invoice_id' => $invoice?->id,
                    'redeemed_at' => now(),
                    'created_by' => $cashierId,
                ]);
                $this->coupons->incrementRedeemedCount($coupon);
            }

            if ($memberId !== null) {
                try {
                    $this->loyalty->awardPurchase($tenant, $memberId, (int) $sale->id, (float) $sale->grand_total);
                } catch (\Throwable) {
                    // Loyalty must never block POS.
                }
            }

            $this->audit->write(
                action: 'sale.created',
                entityType: 'sale',
                entityId: $sale->id,
                tenantId: $tenant->id,
                newValues: [
                    'branch_id' => $branchId,
                    'grand_total' => $sale->grand_total,
                    'status' => $sale->status,
                    'coupon_id' => $coupon?->id,
                ]
            );

            return $this->sales->findForTenant($tenant->id, $sale->id) ?? $sale;
        });
    }
}
