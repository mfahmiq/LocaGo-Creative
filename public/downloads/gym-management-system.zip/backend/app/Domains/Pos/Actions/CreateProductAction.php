<?php

declare(strict_types=1);

namespace App\Domains\Pos\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Pos\Contracts\ProductRepositoryInterface;
use App\Domains\Pos\Models\Product;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CreateProductAction extends Action
{
    public function __construct(
        private readonly ProductRepositoryInterface $products,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Product
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        $sku = strtoupper(trim((string) $data['sku']));

        if ($this->products->findBySku($tenant->id, $sku) !== null) {
            throw new DomainException(
                'Product SKU already exists.',
                'product_sku_exists',
                Response::HTTP_CONFLICT
            );
        }

        $product = $this->products->createProduct([
            'tenant_id' => $tenant->id,
            'sku' => $sku,
            'name' => trim((string) $data['name']),
            'description' => $data['description'] ?? null,
            'unit_price' => $data['unit_price'] ?? 0,
            'currency_code' => strtoupper((string) ($data['currency_code'] ?? $tenant->base_currency ?: 'INR')),
            'tax_rate_id' => isset($data['tax_rate_id']) ? (int) $data['tax_rate_id'] : null,
            'low_stock_threshold' => (int) ($data['low_stock_threshold'] ?? 5),
            'is_active' => (bool) ($data['is_active'] ?? true),
        ]);

        $this->audit->write(
            action: 'product.created',
            entityType: 'product',
            entityId: $product->id,
            tenantId: $tenant->id,
            newValues: ['sku' => $product->sku, 'name' => $product->name]
        );

        return $product;
    }
}
