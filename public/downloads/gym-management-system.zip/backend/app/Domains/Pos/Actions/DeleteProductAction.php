<?php

declare(strict_types=1);

namespace App\Domains\Pos\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Pos\Contracts\ProductRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeleteProductAction extends Action
{
    public function __construct(
        private readonly ProductRepositoryInterface $products,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $productId */
        $productId = (int) $args[1];

        $product = $this->products->findForTenant($tenant->id, $productId);

        if ($product === null) {
            throw new DomainException('Product not found.', 'product_not_found', Response::HTTP_NOT_FOUND);
        }

        $deleted = $this->products->deleteProduct($product);

        $this->audit->write(
            action: 'product.deleted',
            entityType: 'product',
            entityId: $productId,
            tenantId: $tenant->id,
            oldValues: ['sku' => $product->sku, 'name' => $product->name]
        );

        return $deleted;
    }
}
