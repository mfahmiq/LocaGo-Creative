<?php

declare(strict_types=1);

namespace App\Domains\Pos\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Pos\Contracts\ProductRepositoryInterface;
use App\Domains\Pos\Contracts\StockRepositoryInterface;
use App\Domains\Pos\Models\ProductStock;
use App\Domains\Pos\Models\StockMovement;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

final class DamageStockAction extends Action
{
    public function __construct(
        private readonly ProductRepositoryInterface $products,
        private readonly StockRepositoryInterface $stock,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): ProductStock
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $productId */
        $productId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        return $this->transaction(function () use ($tenant, $productId, $data): ProductStock {
            $product = $this->products->findForTenant($tenant->id, $productId);

            if ($product === null) {
                throw new DomainException('Product not found.', 'product_not_found', Response::HTTP_NOT_FOUND);
            }

            $branchId = (int) $data['branch_id'];
            if ($this->branches->findActiveForTenant($tenant->id, $branchId) === null) {
                throw new DomainException('Branch is invalid or inactive.', 'invalid_branch', Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $quantity = (int) $data['quantity'];
            if ($quantity <= 0) {
                throw new DomainException(
                    'Damage quantity must be positive.',
                    'invalid_quantity',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $stock = $this->stock->getOrCreateStock($tenant->id, $productId, $branchId);

            if ($stock->quantity < $quantity) {
                throw new DomainException(
                    'Insufficient stock for damage write-off.',
                    'insufficient_stock',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $updated = $this->stock->applyDelta($stock, -$quantity);

            $this->stock->createMovement([
                'tenant_id' => $tenant->id,
                'product_id' => $productId,
                'branch_id' => $branchId,
                'movement_type' => StockMovement::TYPE_DAMAGE,
                'quantity_delta' => -$quantity,
                'reason' => $data['reason'] ?? null,
                'reference_type' => null,
                'reference_id' => null,
                'created_at' => now(),
                'created_by' => Auth::id(),
            ]);

            $this->audit->write(
                action: 'stock.damaged',
                entityType: 'product',
                entityId: $productId,
                tenantId: $tenant->id,
                newValues: ['branch_id' => $branchId, 'quantity' => $quantity]
            );

            return $updated->load('branch');
        });
    }
}
