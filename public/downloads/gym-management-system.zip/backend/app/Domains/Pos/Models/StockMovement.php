<?php

declare(strict_types=1);

namespace App\Domains\Pos\Models;

use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Organization\Models\Branch;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StockMovement extends Model
{
    use BelongsToTenant;

    public const TYPE_RECEIVE = 'receive';

    public const TYPE_SALE = 'sale';

    public const TYPE_ADJUST = 'adjust';

    public const TYPE_DAMAGE = 'damage';

    public const TYPE_VOID_SALE = 'void_sale';

    public $timestamps = false;

    protected $table = 'stock_movements';

    protected $fillable = [
        'tenant_id',
        'product_id',
        'branch_id',
        'movement_type',
        'quantity_delta',
        'reason',
        'reference_type',
        'reference_id',
        'created_at',
        'created_by',
    ];

    protected function casts(): array
    {
        return [
            'quantity_delta' => 'integer',
            'created_at' => 'datetime',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }
}
