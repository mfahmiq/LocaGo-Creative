﻿# Pos Domain

## Admin Portal — Products, inventory & POS sales (V1)

Requires `auth:sanctum` + staff + `X-Tenant-Slug` + POS permissions.

Routes are registered via `App\Providers\PosServiceProvider` (not `routes/api/v1/api.php`).

### Products & inventory
| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/products` | `pos.inventory.view` / `pos.inventory.manage` |
| GET/PUT/DELETE | `/api/v1/admin/products/{id}` | view / manage |
| GET | `/api/v1/admin/products/{id}/stock` | view |
| POST | `/api/v1/admin/products/{id}/stock/receive` | manage |
| POST | `/api/v1/admin/products/{id}/stock/adjust` | manage |
| POST | `/api/v1/admin/products/{id}/stock/damage` | manage |

**Receive:** `{ branch_id, quantity, reason? }` — positive delta, movement type `receive`.

**Adjust:** `{ branch_id, quantity? | quantity_delta?, reason? }` — absolute `quantity` (set level) or signed `quantity_delta`.

**Damage:** `{ branch_id, quantity, reason? }` — writes negative delta, movement type `damage`.

### Sales (checkout)
| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/sales` | `pos.sales.view` / `pos.sales.create` |
| GET | `/api/v1/admin/sales/{id}` | view |
| POST | `/api/v1/admin/sales/{id}/void` | create |

Statuses: `completed` | `void`

Create body highlights:
- `branch_id`, optional `member_id`, optional `create_invoice` (issues billing invoice via `CreateInvoiceAction`)
- `items[]`: `product_id` (optional), `description`, `quantity`, `unit_price`, `discount_amount`, `tax_amount`
- Line total = `qty × unit_price − discount + tax` (see `SaleTotalsCalculator`)
- Validates branch, active products, and branch stock before completing sale
- Decrements `product_stocks` and records `stock_movements` with type `sale`
- `cashier_user_id` = authenticated staff user

**Void sale:** only when `status=completed`. Restores stock via `void_sale` movements. Sets sale status to `void`.

> **Note:** Voiding a sale does **not** auto-void its linked invoice. Handle invoice void separately in Billing if needed.

Audited: `product.*`, `stock.*`, `sale.*`

## Wiring checklist (for integrators)

Wiring: repository bindings + policies in central providers; routes via `routes/api/v1/admin/pos.php` included from `api.php`.

## Next Admin modules
Admin core catalog complete (through Reports).
