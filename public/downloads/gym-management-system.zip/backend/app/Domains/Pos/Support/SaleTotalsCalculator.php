<?php

declare(strict_types=1);

namespace App\Domains\Pos\Support;

use App\Domains\Billing\Support\Money;

/**
 * @phpstan-type LineInput array{
 *     description: string,
 *     quantity?: int|string,
 *     unit_price: float|int|string,
 *     discount_amount?: float|int|string,
 *     tax_amount?: float|int|string,
 *     product_id?: int|null
 * }
 */
final class SaleTotalsCalculator
{
    /**
     * @param  list<LineInput>  $items
     * @return array{
     *     items: list<array<string, mixed>>,
     *     subtotal: string,
     *     discount_total: string,
     *     tax_total: string,
     *     grand_total: string
     * }
     */
    public static function calculate(array $items): array
    {
        $computed = [];
        $subtotal = '0.00';
        $discountTotal = '0.00';
        $taxTotal = '0.00';

        foreach ($items as $item) {
            $qty = max(1, (int) ($item['quantity'] ?? 1));
            $unit = Money::round($item['unit_price']);
            $discount = Money::round($item['discount_amount'] ?? 0);
            $tax = Money::round($item['tax_amount'] ?? 0);
            $gross = Money::mul((string) $qty, $unit);
            $lineTotal = Money::add(Money::sub($gross, $discount), $tax);

            if (Money::cmp($lineTotal, '0.00') < 0) {
                $lineTotal = '0.00';
            }

            $computed[] = [
                'product_id' => isset($item['product_id']) ? (int) $item['product_id'] : null,
                'description' => (string) $item['description'],
                'quantity' => $qty,
                'unit_price' => $unit,
                'discount_amount' => $discount,
                'tax_amount' => $tax,
                'line_total' => $lineTotal,
            ];

            $subtotal = Money::add($subtotal, $gross);
            $discountTotal = Money::add($discountTotal, $discount);
            $taxTotal = Money::add($taxTotal, $tax);
        }

        $grand = Money::add(Money::sub($subtotal, $discountTotal), $taxTotal);

        return [
            'items' => $computed,
            'subtotal' => $subtotal,
            'discount_total' => $discountTotal,
            'tax_total' => $taxTotal,
            'grand_total' => $grand,
        ];
    }
}
