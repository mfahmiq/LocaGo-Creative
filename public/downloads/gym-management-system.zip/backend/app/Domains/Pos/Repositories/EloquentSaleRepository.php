<?php

declare(strict_types=1);

namespace App\Domains\Pos\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Pos\Contracts\SaleRepositoryInterface;
use App\Domains\Pos\Models\Sale;
use App\Domains\Pos\Models\SaleItem;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

/**
 * @extends BaseRepository<Sale>
 */
class EloquentSaleRepository extends BaseRepository implements SaleRepositoryInterface
{
    public function __construct(Sale $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['branch', 'member', 'cashier', 'items'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('sold_at')
            ->orderByDesc('id');

        if (! empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        if (! empty($filters['branch_id'])) {
            $query->where('branch_id', (int) $filters['branch_id']);
        }

        if (! empty($filters['member_id'])) {
            $query->where('member_id', (int) $filters['member_id']);
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $saleId): ?Sale
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['branch', 'member', 'cashier', 'invoice', 'items.product'])
            ->where('tenant_id', $tenantId)
            ->where('id', $saleId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function createSale(array $attributes): Sale
    {
        /** @var Sale $sale */
        $sale = $this->query()->withoutGlobalScopes()->create($attributes);

        return $sale->load(['branch', 'member', 'cashier', 'items']);
    }

    public function updateSale(Sale $sale, array $attributes): Sale
    {
        $sale->update($attributes);

        return $sale->fresh(['branch', 'member', 'cashier', 'invoice', 'items.product']);
    }

    public function createSaleItem(array $attributes): SaleItem
    {
        /** @var SaleItem $item */
        $item = SaleItem::query()->withoutGlobalScopes()->create($attributes);

        return $item;
    }

    public function listItems(int $saleId): Collection
    {
        return SaleItem::query()
            ->withoutGlobalScopes()
            ->with(['product'])
            ->where('sale_id', $saleId)
            ->orderBy('id')
            ->get();
    }
}
