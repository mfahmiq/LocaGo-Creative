<?php

declare(strict_types=1);

namespace App\Domains\Pos\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Pos\Contracts\ProductRepositoryInterface;
use App\Domains\Pos\Models\Product;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<Product>
 */
class EloquentProductRepository extends BaseRepository implements ProductRepositoryInterface
{
    public function __construct(Product $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('id');

        if (array_key_exists('is_active', $filters) && $filters['is_active'] !== null && $filters['is_active'] !== '') {
            $query->where('is_active', filter_var($filters['is_active'], FILTER_VALIDATE_BOOLEAN));
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);
            $query->where(function ($q) use ($search): void {
                $q->where('name', 'like', "%{$search}%")
                    ->orWhere('sku', 'like', "%{$search}%");
            });
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $productId): ?Product
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('id', $productId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function findActiveForTenant(int $tenantId, int $productId): ?Product
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('id', $productId)
            ->where('is_active', true)
            ->whereNull('deleted_at')
            ->first();
    }

    public function findBySku(int $tenantId, string $sku, ?int $excludeId = null): ?Product
    {
        $query = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('sku', $sku)
            ->whereNull('deleted_at');

        if ($excludeId !== null) {
            $query->where('id', '!=', $excludeId);
        }

        return $query->first();
    }

    public function createProduct(array $attributes): Product
    {
        /** @var Product $product */
        $product = $this->query()->withoutGlobalScopes()->create($attributes);

        return $product;
    }

    public function updateProduct(Product $product, array $attributes): Product
    {
        $product->update($attributes);

        return $product->fresh();
    }

    public function deleteProduct(Product $product): bool
    {
        return (bool) $product->delete();
    }
}
