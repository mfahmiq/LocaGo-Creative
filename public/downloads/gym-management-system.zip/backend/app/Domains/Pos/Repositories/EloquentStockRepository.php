<?php

declare(strict_types=1);

namespace App\Domains\Pos\Repositories;

use App\Domains\Pos\Contracts\StockRepositoryInterface;
use App\Domains\Pos\Models\ProductStock;
use App\Domains\Pos\Models\StockMovement;
use Illuminate\Support\Collection;

class EloquentStockRepository implements StockRepositoryInterface
{
    public function findStock(int $tenantId, int $productId, int $branchId): ?ProductStock
    {
        return ProductStock::query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('product_id', $productId)
            ->where('branch_id', $branchId)
            ->first();
    }

    public function getOrCreateStock(int $tenantId, int $productId, int $branchId): ProductStock
    {
        $stock = $this->findStock($tenantId, $productId, $branchId);

        if ($stock !== null) {
            return $stock;
        }

        /** @var ProductStock $stock */
        $stock = ProductStock::query()->withoutGlobalScopes()->create([
            'tenant_id' => $tenantId,
            'product_id' => $productId,
            'branch_id' => $branchId,
            'quantity' => 0,
        ]);

        return $stock;
    }

    public function listForProduct(int $tenantId, int $productId): Collection
    {
        return ProductStock::query()
            ->withoutGlobalScopes()
            ->with(['branch'])
            ->where('tenant_id', $tenantId)
            ->where('product_id', $productId)
            ->orderBy('branch_id')
            ->get();
    }

    public function createMovement(array $attributes): StockMovement
    {
        /** @var StockMovement $movement */
        $movement = StockMovement::query()->withoutGlobalScopes()->create($attributes);

        return $movement;
    }

    public function applyDelta(ProductStock $stock, int $delta): ProductStock
    {
        $stock->update(['quantity' => $stock->quantity + $delta]);

        return $stock->fresh(['branch']);
    }
}
