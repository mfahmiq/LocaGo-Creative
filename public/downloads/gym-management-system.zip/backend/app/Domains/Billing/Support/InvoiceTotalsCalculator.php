<?php

declare(strict_types=1);

namespace App\Domains\Billing\Support;

/**
 * @phpstan-type LineInput array{
 *     description: string,
 *     quantity?: float|int|string,
 *     unit_price: float|int|string,
 *     discount_amount?: float|int|string,
 *     tax_rate_percent?: float|int|string|null,
 *     item_type?: string|null,
 *     item_id?: int|null
 * }
 */
final class InvoiceTotalsCalculator
{
    /**
     * @param  list<LineInput>  $items
     * @return array{
     *     items: list<array<string, mixed>>,
     *     subtotal: string,
     *     discount_total: string,
     *     tax_total: string,
     *     grand_total: string
     * }
     */
    public static function calculate(array $items): array
    {
        $computed = [];
        $subtotal = '0.00';
        $discountTotal = '0.00';
        $taxTotal = '0.00';

        foreach ($items as $item) {
            $qty = Money::round($item['quantity'] ?? 1);
            $unit = Money::round($item['unit_price']);
            $discount = Money::round($item['discount_amount'] ?? 0);
            $gross = Money::mul($qty, $unit);
            $net = Money::sub($gross, $discount);
            if (Money::cmp($net, '0.00') < 0) {
                $net = '0.00';
            }

            $rate = $item['tax_rate_percent'] ?? null;
            $taxAmount = '0.00';
            if ($rate !== null && $rate !== '') {
                $taxAmount = Money::round(((float) $net) * ((float) $rate) / 100);
            }

            $lineTotal = Money::add($net, $taxAmount);

            $computed[] = [
                'description' => (string) $item['description'],
                'quantity' => $qty,
                'unit_price' => $unit,
                'discount_amount' => $discount,
                'tax_rate_percent' => $rate !== null && $rate !== '' ? Money::round((float) $rate) : null,
                'tax_amount' => $taxAmount,
                'line_total' => $lineTotal,
                'item_type' => $item['item_type'] ?? null,
                'item_id' => isset($item['item_id']) ? (int) $item['item_id'] : null,
            ];

            $subtotal = Money::add($subtotal, $gross);
            $discountTotal = Money::add($discountTotal, $discount);
            $taxTotal = Money::add($taxTotal, $taxAmount);
        }

        $grand = Money::add(Money::sub($subtotal, $discountTotal), $taxTotal);

        return [
            'items' => $computed,
            'subtotal' => $subtotal,
            'discount_total' => $discountTotal,
            'tax_total' => $taxTotal,
            'grand_total' => $grand,
        ];
    }
}
