<?php

declare(strict_types=1);

namespace App\Domains\Billing\Support;

final class Money
{
    public static function round(float|string $value): string
    {
        return number_format((float) $value, 2, '.', '');
    }

    public static function add(string ...$values): string
    {
        $sum = '0.00';
        foreach ($values as $value) {
            $sum = self::round((float) $sum + (float) $value);
        }

        return $sum;
    }

    public static function sub(string $left, string $right): string
    {
        return self::round((float) $left - (float) $right);
    }

    public static function mul(string $left, string $right): string
    {
        return self::round((float) $left * (float) $right);
    }

    public static function cmp(string $left, string $right): int
    {
        return (float) $left <=> (float) $right;
    }
}
