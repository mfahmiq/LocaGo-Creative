<?php

declare(strict_types=1);

namespace App\Domains\Billing\Contracts;

use App\Domains\Billing\Models\Payment;
use App\Domains\Billing\Models\PaymentAllocation;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface PaymentRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $paymentId): ?Payment;

    public function nextPaymentNumber(int $tenantId): string;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createPayment(array $attributes): Payment;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updatePayment(Payment $payment, array $attributes): Payment;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createAllocation(array $attributes): PaymentAllocation;
}
