<?php

declare(strict_types=1);

namespace App\Domains\Billing\Contracts;

use App\Domains\Billing\Models\Invoice;
use App\Domains\Billing\Models\InvoiceItem;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

interface InvoiceRepositoryInterface
{
    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;

    public function findForTenant(int $tenantId, int $invoiceId): ?Invoice;

    public function nextInvoiceNumber(int $tenantId): string;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createInvoice(array $attributes): Invoice;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updateInvoice(Invoice $invoice, array $attributes): Invoice;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createItem(array $attributes): InvoiceItem;

    public function deleteItemsForInvoice(int $invoiceId): void;

    /**
     * @return Collection<int, InvoiceItem>
     */
    public function listItems(int $invoiceId): Collection;
}
