<?php

declare(strict_types=1);

namespace App\Domains\Billing\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Billing\Actions\RecordPaymentAction;
use App\Domains\Billing\Actions\VoidPaymentAction;
use App\Domains\Billing\Contracts\PaymentRepositoryInterface;
use App\Domains\Billing\Models\Payment;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class PaymentService extends BaseService
{
    public function __construct(
        private readonly PaymentRepositoryInterface $payments,
        private readonly RecordPaymentAction $recordPaymentAction,
        private readonly VoidPaymentAction $voidPaymentAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->payments->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $paymentId): Payment
    {
        $payment = $this->payments->findForTenant($tenant->id, $paymentId);

        if ($payment === null) {
            throw new DomainException('Payment not found.', 'payment_not_found', Response::HTTP_NOT_FOUND);
        }

        return $payment;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function record(Tenant $tenant, array $data): Payment
    {
        return $this->recordPaymentAction->execute($tenant, $data);
    }

    public function void(Tenant $tenant, int $paymentId, ?string $reason = null): Payment
    {
        return $this->voidPaymentAction->execute($tenant, $paymentId, $reason);
    }
}
