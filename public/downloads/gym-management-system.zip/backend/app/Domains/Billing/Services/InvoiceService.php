<?php

declare(strict_types=1);

namespace App\Domains\Billing\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Billing\Actions\CreateInvoiceAction;
use App\Domains\Billing\Actions\IssueInvoiceAction;
use App\Domains\Billing\Actions\UpdateInvoiceAction;
use App\Domains\Billing\Actions\VoidInvoiceAction;
use App\Domains\Billing\Contracts\InvoiceRepositoryInterface;
use App\Domains\Billing\Models\Invoice;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class InvoiceService extends BaseService
{
    public function __construct(
        private readonly InvoiceRepositoryInterface $invoices,
        private readonly CreateInvoiceAction $createInvoiceAction,
        private readonly UpdateInvoiceAction $updateInvoiceAction,
        private readonly IssueInvoiceAction $issueInvoiceAction,
        private readonly VoidInvoiceAction $voidInvoiceAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->invoices->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $invoiceId): Invoice
    {
        $invoice = $this->invoices->findForTenant($tenant->id, $invoiceId);

        if ($invoice === null) {
            throw new DomainException('Invoice not found.', 'invoice_not_found', Response::HTTP_NOT_FOUND);
        }

        return $invoice;
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): Invoice
    {
        return $this->createInvoiceAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $invoiceId, array $data): Invoice
    {
        return $this->updateInvoiceAction->execute($tenant, $invoiceId, $data);
    }

    public function issue(Tenant $tenant, int $invoiceId): Invoice
    {
        return $this->issueInvoiceAction->execute($tenant, $invoiceId);
    }

    public function void(Tenant $tenant, int $invoiceId, ?string $reason = null): Invoice
    {
        return $this->voidInvoiceAction->execute($tenant, $invoiceId, $reason);
    }
}
