<?php

declare(strict_types=1);

namespace App\Domains\Billing\Models;

use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PaymentAllocation extends Model
{
    use BelongsToTenant;

    public $timestamps = false;

    protected $table = 'payment_allocations';

    protected $fillable = [
        'tenant_id',
        'payment_id',
        'invoice_id',
        'amount',
        'created_at',
        'created_by',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:2',
            'created_at' => 'datetime',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function payment(): BelongsTo
    {
        return $this->belongsTo(Payment::class);
    }

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }
}
