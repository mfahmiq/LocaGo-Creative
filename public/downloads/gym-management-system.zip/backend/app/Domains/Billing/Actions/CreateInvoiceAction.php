<?php

declare(strict_types=1);

namespace App\Domains\Billing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Billing\Contracts\InvoiceRepositoryInterface;
use App\Domains\Billing\Models\Invoice;
use App\Domains\Billing\Support\InvoiceTotalsCalculator;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CreateInvoiceAction extends Action
{
    public function __construct(
        private readonly InvoiceRepositoryInterface $invoices,
        private readonly MemberRepositoryInterface $members,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Invoice
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        return $this->transaction(function () use ($tenant, $data): Invoice {
            $items = $data['items'] ?? [];
            if (! is_array($items) || $items === []) {
                throw new DomainException(
                    'At least one invoice item is required.',
                    'invoice_items_required',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $memberId = isset($data['member_id']) ? (int) $data['member_id'] : null;
            if ($memberId !== null && $this->members->findForTenant($tenant->id, $memberId) === null) {
                throw new DomainException('Member not found.', 'member_not_found', Response::HTTP_NOT_FOUND);
            }

            $branchId = isset($data['branch_id']) ? (int) $data['branch_id'] : null;
            if ($branchId !== null && $this->branches->findActiveForTenant($tenant->id, $branchId) === null) {
                throw new DomainException('Branch is invalid or inactive.', 'invalid_branch', Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $totals = InvoiceTotalsCalculator::calculate($items);
            $issueNow = (bool) ($data['issue_now'] ?? false);

            $invoice = $this->invoices->createInvoice([
                'tenant_id' => $tenant->id,
                'branch_id' => $branchId,
                'member_id' => $memberId,
                'invoice_number' => $this->invoices->nextInvoiceNumber($tenant->id),
                'status' => $issueNow ? Invoice::STATUS_ISSUED : Invoice::STATUS_DRAFT,
                'currency_code' => strtoupper((string) ($data['currency_code'] ?? $tenant->base_currency ?: 'INR')),
                'subtotal' => $totals['subtotal'],
                'discount_total' => $totals['discount_total'],
                'tax_total' => $totals['tax_total'],
                'grand_total' => $totals['grand_total'],
                'amount_paid' => '0.00',
                'balance_due' => $totals['grand_total'],
                'issue_date' => $issueNow ? now()->toDateString() : ($data['issue_date'] ?? null),
                'due_date' => $data['due_date'] ?? null,
                'notes' => $data['notes'] ?? null,
                'source_type' => $data['source_type'] ?? 'misc',
                'source_id' => $data['source_id'] ?? null,
            ]);

            foreach ($totals['items'] as $line) {
                $this->invoices->createItem([
                    'tenant_id' => $tenant->id,
                    'invoice_id' => $invoice->id,
                    ...$line,
                    'created_at' => now(),
                ]);
            }

            $this->audit->write(
                action: 'invoice.created',
                entityType: 'invoice',
                entityId: $invoice->id,
                tenantId: $tenant->id,
                newValues: [
                    'invoice_number' => $invoice->invoice_number,
                    'status' => $invoice->status,
                    'grand_total' => $invoice->grand_total,
                ]
            );

            return $this->invoices->findForTenant($tenant->id, $invoice->id) ?? $invoice;
        });
    }
}
