<?php

declare(strict_types=1);

namespace App\Domains\Billing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Billing\Contracts\InvoiceRepositoryInterface;
use App\Domains\Billing\Models\Invoice;
use App\Domains\Billing\Support\Money;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class VoidInvoiceAction extends Action
{
    public function __construct(
        private readonly InvoiceRepositoryInterface $invoices,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Invoice
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $invoiceId */
        $invoiceId = (int) $args[1];
        /** @var string|null $reason */
        $reason = $args[2] ?? null;

        $invoice = $this->invoices->findForTenant($tenant->id, $invoiceId);

        if ($invoice === null) {
            throw new DomainException('Invoice not found.', 'invoice_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($invoice->status === Invoice::STATUS_VOID) {
            throw new DomainException('Invoice is already void.', 'invoice_already_void', Response::HTTP_CONFLICT);
        }

        if ($invoice->status === Invoice::STATUS_PAID || Money::cmp((string) $invoice->amount_paid, '0.00') > 0) {
            throw new DomainException(
                'Cannot void an invoice with payments. Reverse payments first.',
                'invoice_has_payments',
                Response::HTTP_CONFLICT
            );
        }

        if (! in_array($invoice->status, [Invoice::STATUS_DRAFT, Invoice::STATUS_ISSUED, Invoice::STATUS_OVERDUE], true)) {
            throw new DomainException(
                'Invoice cannot be voided from current status.',
                'invalid_invoice_status',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $notes = $invoice->notes;
        if ($reason) {
            $notes = trim((string) $notes."\nVoid reason: ".$reason);
        }

        $updated = $this->invoices->updateInvoice($invoice, [
            'status' => Invoice::STATUS_VOID,
            'balance_due' => '0.00',
            'notes' => $notes,
        ]);

        $this->audit->write(
            action: 'invoice.voided',
            entityType: 'invoice',
            entityId: $updated->id,
            tenantId: $tenant->id,
            newValues: ['reason' => $reason]
        );

        return $updated;
    }
}
