<?php

declare(strict_types=1);

namespace App\Domains\Billing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Billing\Contracts\InvoiceRepositoryInterface;
use App\Domains\Billing\Contracts\PaymentRepositoryInterface;
use App\Domains\Billing\Models\Invoice;
use App\Domains\Billing\Models\Payment;
use App\Domains\Billing\Support\Money;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

final class RecordPaymentAction extends Action
{
    public function __construct(
        private readonly PaymentRepositoryInterface $payments,
        private readonly InvoiceRepositoryInterface $invoices,
        private readonly MemberRepositoryInterface $members,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Payment
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        return $this->transaction(function () use ($tenant, $data): Payment {
            $amount = Money::round($data['amount']);
            if (Money::cmp($amount, '0.00') <= 0) {
                throw new DomainException(
                    'Payment amount must be greater than zero.',
                    'invalid_payment_amount',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $method = (string) $data['method'];
            $allowedMethods = [
                Payment::METHOD_CASH,
                Payment::METHOD_CARD,
                Payment::METHOD_UPI,
                Payment::METHOD_BANK_TRANSFER,
                Payment::METHOD_OTHER,
            ];
            if (! in_array($method, $allowedMethods, true)) {
                throw new DomainException('Invalid payment method.', 'invalid_payment_method', Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            $memberId = isset($data['member_id']) ? (int) $data['member_id'] : null;
            if ($memberId !== null && $this->members->findForTenant($tenant->id, $memberId) === null) {
                throw new DomainException('Member not found.', 'member_not_found', Response::HTTP_NOT_FOUND);
            }

            $branchId = isset($data['branch_id']) ? (int) $data['branch_id'] : null;
            if ($branchId !== null && $this->branches->findActiveForTenant($tenant->id, $branchId) === null) {
                throw new DomainException('Branch is invalid or inactive.', 'invalid_branch', Response::HTTP_UNPROCESSABLE_ENTITY);
            }

            /** @var list<array{invoice_id: int, amount: float|int|string}> $allocations */
            $allocations = $data['allocations'] ?? [];
            if (! is_array($allocations) || $allocations === []) {
                throw new DomainException(
                    'At least one allocation is required.',
                    'allocations_required',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $allocSum = '0.00';
            $resolved = [];

            foreach ($allocations as $row) {
                $invoiceId = (int) $row['invoice_id'];
                $allocAmount = Money::round($row['amount']);
                if (Money::cmp($allocAmount, '0.00') <= 0) {
                    throw new DomainException(
                        'Allocation amount must be greater than zero.',
                        'invalid_allocation_amount',
                        Response::HTTP_UNPROCESSABLE_ENTITY
                    );
                }

                $invoice = $this->invoices->findForTenant($tenant->id, $invoiceId);
                if ($invoice === null) {
                    throw new DomainException('Invoice not found.', 'invoice_not_found', Response::HTTP_NOT_FOUND);
                }

                if (! $invoice->isOpen()) {
                    throw new DomainException(
                        'Payments can only be allocated to open invoices.',
                        'invoice_not_open',
                        Response::HTTP_UNPROCESSABLE_ENTITY
                    );
                }

                if (Money::cmp($allocAmount, (string) $invoice->balance_due) > 0) {
                    throw new DomainException(
                        'Allocation exceeds invoice balance due.',
                        'allocation_exceeds_balance',
                        Response::HTTP_UNPROCESSABLE_ENTITY
                    );
                }

                if ($memberId !== null && $invoice->member_id !== null && (int) $invoice->member_id !== $memberId) {
                    throw new DomainException(
                        'Invoice member does not match payment member.',
                        'member_mismatch',
                        Response::HTTP_UNPROCESSABLE_ENTITY
                    );
                }

                $allocSum = Money::add($allocSum, $allocAmount);
                $resolved[] = ['invoice' => $invoice, 'amount' => $allocAmount];
            }

            if (Money::cmp($allocSum, $amount) !== 0) {
                throw new DomainException(
                    'Allocation total must equal payment amount.',
                    'allocation_sum_mismatch',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $currency = strtoupper((string) ($data['currency_code'] ?? $resolved[0]['invoice']->currency_code));

            $payment = $this->payments->createPayment([
                'tenant_id' => $tenant->id,
                'branch_id' => $branchId,
                'member_id' => $memberId ?? $resolved[0]['invoice']->member_id,
                'payment_number' => $this->payments->nextPaymentNumber($tenant->id),
                'amount' => $amount,
                'currency_code' => $currency,
                'method' => $method,
                'reference' => $data['reference'] ?? null,
                'status' => Payment::STATUS_COMPLETED,
                'paid_at' => $data['paid_at'] ?? now(),
                'received_by' => Auth::id(),
                'notes' => $data['notes'] ?? null,
            ]);

            foreach ($resolved as $row) {
                /** @var Invoice $invoice */
                $invoice = $row['invoice'];
                $allocAmount = $row['amount'];

                $this->payments->createAllocation([
                    'tenant_id' => $tenant->id,
                    'payment_id' => $payment->id,
                    'invoice_id' => $invoice->id,
                    'amount' => $allocAmount,
                    'created_at' => now(),
                    'created_by' => Auth::id(),
                ]);

                $paid = Money::add((string) $invoice->amount_paid, $allocAmount);
                $balance = Money::sub((string) $invoice->grand_total, $paid);
                if (Money::cmp($balance, '0.00') < 0) {
                    $balance = '0.00';
                }

                $status = Money::cmp($balance, '0.00') === 0
                    ? Invoice::STATUS_PAID
                    : Invoice::STATUS_PARTIALLY_PAID;

                $this->invoices->updateInvoice($invoice, [
                    'amount_paid' => $paid,
                    'balance_due' => $balance,
                    'status' => $status,
                ]);
            }

            $this->audit->write(
                action: 'payment.recorded',
                entityType: 'payment',
                entityId: $payment->id,
                tenantId: $tenant->id,
                newValues: [
                    'payment_number' => $payment->payment_number,
                    'amount' => $amount,
                    'method' => $method,
                ]
            );

            return $this->payments->findForTenant($tenant->id, $payment->id) ?? $payment;
        });
    }
}
