<?php

declare(strict_types=1);

namespace App\Domains\Billing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Billing\Contracts\InvoiceRepositoryInterface;
use App\Domains\Billing\Contracts\PaymentRepositoryInterface;
use App\Domains\Billing\Models\Invoice;
use App\Domains\Billing\Models\Payment;
use App\Domains\Billing\Support\Money;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class VoidPaymentAction extends Action
{
    public function __construct(
        private readonly PaymentRepositoryInterface $payments,
        private readonly InvoiceRepositoryInterface $invoices,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Payment
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $paymentId */
        $paymentId = (int) $args[1];
        /** @var string|null $reason */
        $reason = $args[2] ?? null;

        return $this->transaction(function () use ($tenant, $paymentId, $reason): Payment {
            $payment = $this->payments->findForTenant($tenant->id, $paymentId);

            if ($payment === null) {
                throw new DomainException('Payment not found.', 'payment_not_found', Response::HTTP_NOT_FOUND);
            }

            if ($payment->status === Payment::STATUS_REVERSED) {
                throw new DomainException(
                    'Payment is already reversed.',
                    'payment_already_reversed',
                    Response::HTTP_CONFLICT
                );
            }

            foreach ($payment->allocations as $allocation) {
                $invoice = $this->invoices->findForTenant($tenant->id, (int) $allocation->invoice_id);
                if ($invoice === null || $invoice->status === Invoice::STATUS_VOID) {
                    continue;
                }

                $paid = Money::sub((string) $invoice->amount_paid, (string) $allocation->amount);
                if (Money::cmp($paid, '0.00') < 0) {
                    $paid = '0.00';
                }
                $balance = Money::sub((string) $invoice->grand_total, $paid);

                $status = match (true) {
                    Money::cmp($paid, '0.00') === 0 => Invoice::STATUS_ISSUED,
                    Money::cmp($balance, '0.00') === 0 => Invoice::STATUS_PAID,
                    default => Invoice::STATUS_PARTIALLY_PAID,
                };

                $this->invoices->updateInvoice($invoice, [
                    'amount_paid' => $paid,
                    'balance_due' => $balance,
                    'status' => $status,
                ]);
            }

            $notes = $payment->notes;
            if ($reason) {
                $notes = trim((string) $notes."\nReversal reason: ".$reason);
            }

            $updated = $this->payments->updatePayment($payment, [
                'status' => Payment::STATUS_REVERSED,
                'notes' => $notes,
            ]);

            $this->audit->write(
                action: 'payment.voided',
                entityType: 'payment',
                entityId: $updated->id,
                tenantId: $tenant->id,
                newValues: ['reason' => $reason]
            );

            return $updated;
        });
    }
}
