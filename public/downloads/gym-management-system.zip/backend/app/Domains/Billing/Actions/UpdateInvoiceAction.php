<?php

declare(strict_types=1);

namespace App\Domains\Billing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Billing\Contracts\InvoiceRepositoryInterface;
use App\Domains\Billing\Models\Invoice;
use App\Domains\Billing\Support\InvoiceTotalsCalculator;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateInvoiceAction extends Action
{
    public function __construct(
        private readonly InvoiceRepositoryInterface $invoices,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Invoice
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $invoiceId */
        $invoiceId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        return $this->transaction(function () use ($tenant, $invoiceId, $data): Invoice {
            $invoice = $this->invoices->findForTenant($tenant->id, $invoiceId);

            if ($invoice === null) {
                throw new DomainException('Invoice not found.', 'invoice_not_found', Response::HTTP_NOT_FOUND);
            }

            if (! $invoice->isDraft()) {
                throw new DomainException(
                    'Only draft invoices can be updated.',
                    'invoice_not_editable',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $payload = [];
            foreach (['due_date', 'notes', 'source_type', 'source_id'] as $field) {
                if (array_key_exists($field, $data)) {
                    $payload[$field] = $data[$field];
                }
            }

            if (isset($data['items']) && is_array($data['items'])) {
                if ($data['items'] === []) {
                    throw new DomainException(
                        'At least one invoice item is required.',
                        'invoice_items_required',
                        Response::HTTP_UNPROCESSABLE_ENTITY
                    );
                }

                $totals = InvoiceTotalsCalculator::calculate($data['items']);
                $this->invoices->deleteItemsForInvoice($invoice->id);

                foreach ($totals['items'] as $line) {
                    $this->invoices->createItem([
                        'tenant_id' => $tenant->id,
                        'invoice_id' => $invoice->id,
                        ...$line,
                        'created_at' => now(),
                    ]);
                }

                $payload = array_merge($payload, [
                    'subtotal' => $totals['subtotal'],
                    'discount_total' => $totals['discount_total'],
                    'tax_total' => $totals['tax_total'],
                    'grand_total' => $totals['grand_total'],
                    'balance_due' => $totals['grand_total'],
                    'amount_paid' => '0.00',
                ]);
            }

            $updated = $this->invoices->updateInvoice($invoice, $payload);

            $this->audit->write(
                action: 'invoice.updated',
                entityType: 'invoice',
                entityId: $updated->id,
                tenantId: $tenant->id,
                newValues: ['grand_total' => $updated->grand_total]
            );

            return $updated;
        });
    }
}
