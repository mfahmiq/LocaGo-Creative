<?php

declare(strict_types=1);

namespace App\Domains\Billing\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Billing\Contracts\InvoiceRepositoryInterface;
use App\Domains\Billing\Models\Invoice;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class IssueInvoiceAction extends Action
{
    public function __construct(
        private readonly InvoiceRepositoryInterface $invoices,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Invoice
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $invoiceId */
        $invoiceId = (int) $args[1];

        $invoice = $this->invoices->findForTenant($tenant->id, $invoiceId);

        if ($invoice === null) {
            throw new DomainException('Invoice not found.', 'invoice_not_found', Response::HTTP_NOT_FOUND);
        }

        if (! $invoice->isDraft()) {
            throw new DomainException(
                'Only draft invoices can be issued.',
                'invalid_invoice_status',
                Response::HTTP_UNPROCESSABLE_ENTITY
            );
        }

        $updated = $this->invoices->updateInvoice($invoice, [
            'status' => Invoice::STATUS_ISSUED,
            'issue_date' => $invoice->issue_date?->toDateString() ?? now()->toDateString(),
        ]);

        $this->audit->write(
            action: 'invoice.issued',
            entityType: 'invoice',
            entityId: $updated->id,
            tenantId: $tenant->id,
            oldValues: ['status' => Invoice::STATUS_DRAFT],
            newValues: ['status' => Invoice::STATUS_ISSUED]
        );

        return $updated;
    }
}
