<?php

declare(strict_types=1);

namespace App\Domains\Billing\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Billing\Models\Payment;
use App\Domains\Identity\Models\User;

final class PaymentPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'billing.payments.view');
    }

    public function view(User $user, Payment $payment): bool
    {
        return $this->hasPermission($user, 'billing.payments.view')
            && $this->sameTenant($user, $payment)
            && $this->branchAllowed($user, $payment->branch_id !== null ? (int) $payment->branch_id : null);
    }

    public function record(User $user): bool
    {
        return $this->hasPermission($user, 'billing.payments.record');
    }

    public function void(User $user, Payment $payment): bool
    {
        return $this->hasPermission($user, 'billing.payments.void')
            && $this->sameTenant($user, $payment);
    }
}
