<?php

declare(strict_types=1);

namespace App\Domains\Billing\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Billing\Models\Invoice;
use App\Domains\Identity\Models\User;

final class InvoicePolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'billing.invoices.view');
    }

    public function view(User $user, Invoice $invoice): bool
    {
        return $this->hasPermission($user, 'billing.invoices.view')
            && $this->sameTenant($user, $invoice)
            && $this->branchAllowed($user, $invoice->branch_id !== null ? (int) $invoice->branch_id : null);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'billing.invoices.create');
    }

    public function update(User $user, Invoice $invoice): bool
    {
        return $this->hasPermission($user, 'billing.invoices.create')
            && $this->sameTenant($user, $invoice);
    }

    public function issue(User $user, Invoice $invoice): bool
    {
        return $this->update($user, $invoice);
    }

    public function void(User $user, Invoice $invoice): bool
    {
        return $this->hasPermission($user, 'billing.invoices.void')
            && $this->sameTenant($user, $invoice);
    }
}
