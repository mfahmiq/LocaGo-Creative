﻿# Billing Domain

## Admin Portal — Invoices & offline payments (complete)

Requires `auth:sanctum` + staff + `X-Tenant-Slug` + billing permissions.

### Invoices
| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/invoices` | view / create |
| GET/PUT | `/api/v1/admin/invoices/{id}` | view / create (draft only) |
| POST | `/api/v1/admin/invoices/{id}/issue` | create |
| POST | `/api/v1/admin/invoices/{id}/void` | void |

Statuses: `draft` \| `issued` \| `partially_paid` \| `paid` \| `void` \| `overdue`

Create body highlights: `items[]` with `description`, `unit_price`, optional `quantity`, `discount_amount`, `tax_rate_percent`; optional `issue_now`.

Issued invoices are immutable except via payment allocation or void (unpaid only).

### Payments (offline V1)
| Method | Path | Permission |
| --- | --- | --- |
| GET/POST | `/api/v1/admin/payments` | view / record |
| GET | `/api/v1/admin/payments/{id}` | view |
| POST | `/api/v1/admin/payments/{id}/void` | void |

Methods: `cash` \| `card` \| `upi` \| `bank_transfer` \| `other`

Recording requires `allocations[]` summing exactly to `amount`. Allocations cannot exceed invoice `balance_due`. Void reverses allocations and restores invoice balances.

Audited: `invoice.*`, `payment.*`

## Next Admin modules
Admin core catalog complete (through Reports).
