<?php

declare(strict_types=1);

namespace App\Domains\Billing\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Billing\Contracts\InvoiceRepositoryInterface;
use App\Domains\Billing\Models\Invoice;
use App\Domains\Billing\Models\InvoiceItem;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

/**
 * @extends BaseRepository<Invoice>
 */
class EloquentInvoiceRepository extends BaseRepository implements InvoiceRepositoryInterface
{
    public function __construct(Invoice $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'branch', 'items'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('id');

        if (! empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        if (! empty($filters['member_id'])) {
            $query->where('member_id', (int) $filters['member_id']);
        }

        if (! empty($filters['branch_id'])) {
            $query->where('branch_id', (int) $filters['branch_id']);
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);
            $query->where('invoice_number', 'like', "%{$search}%");
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $invoiceId): ?Invoice
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'branch', 'items', 'allocations.payment'])
            ->where('tenant_id', $tenantId)
            ->where('id', $invoiceId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function nextInvoiceNumber(int $tenantId): string
    {
        $prefix = 'INV-'.now()->format('Ymd').'-';
        $latest = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('invoice_number', 'like', $prefix.'%')
            ->orderByDesc('invoice_number')
            ->value('invoice_number');

        $seq = 1;
        if (is_string($latest) && preg_match('/-(\d+)$/', $latest, $m)) {
            $seq = (int) $m[1] + 1;
        }

        return $prefix.str_pad((string) $seq, 4, '0', STR_PAD_LEFT);
    }

    public function createInvoice(array $attributes): Invoice
    {
        /** @var Invoice $invoice */
        $invoice = $this->query()->withoutGlobalScopes()->create($attributes);

        return $invoice->load(['member', 'branch', 'items']);
    }

    public function updateInvoice(Invoice $invoice, array $attributes): Invoice
    {
        $invoice->update($attributes);

        return $invoice->fresh(['member', 'branch', 'items', 'allocations.payment']);
    }

    public function createItem(array $attributes): InvoiceItem
    {
        /** @var InvoiceItem $item */
        $item = InvoiceItem::query()->withoutGlobalScopes()->create($attributes);

        return $item;
    }

    public function deleteItemsForInvoice(int $invoiceId): void
    {
        InvoiceItem::query()
            ->withoutGlobalScopes()
            ->where('invoice_id', $invoiceId)
            ->delete();
    }

    public function listItems(int $invoiceId): Collection
    {
        return InvoiceItem::query()
            ->withoutGlobalScopes()
            ->where('invoice_id', $invoiceId)
            ->orderBy('id')
            ->get();
    }
}
