<?php

declare(strict_types=1);

namespace App\Domains\Billing\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Billing\Contracts\PaymentRepositoryInterface;
use App\Domains\Billing\Models\Payment;
use App\Domains\Billing\Models\PaymentAllocation;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * @extends BaseRepository<Payment>
 */
class EloquentPaymentRepository extends BaseRepository implements PaymentRepositoryInterface
{
    public function __construct(Payment $model)
    {
        parent::__construct($model);
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'branch', 'allocations.invoice', 'receivedByUser'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('paid_at');

        if (! empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        if (! empty($filters['member_id'])) {
            $query->where('member_id', (int) $filters['member_id']);
        }

        if (! empty($filters['branch_id'])) {
            $query->where('branch_id', (int) $filters['branch_id']);
        }

        if (! empty($filters['method'])) {
            $query->where('method', $filters['method']);
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);
            $query->where(function ($q) use ($search): void {
                $q->where('payment_number', 'like', "%{$search}%")
                    ->orWhere('reference', 'like', "%{$search}%");
            });
        }

        return $query->paginate($perPage);
    }

    public function findForTenant(int $tenantId, int $paymentId): ?Payment
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->with(['member', 'branch', 'allocations.invoice', 'receivedByUser'])
            ->where('tenant_id', $tenantId)
            ->where('id', $paymentId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function nextPaymentNumber(int $tenantId): string
    {
        $prefix = 'PAY-'.now()->format('Ymd').'-';
        $latest = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('payment_number', 'like', $prefix.'%')
            ->orderByDesc('payment_number')
            ->value('payment_number');

        $seq = 1;
        if (is_string($latest) && preg_match('/-(\d+)$/', $latest, $m)) {
            $seq = (int) $m[1] + 1;
        }

        return $prefix.str_pad((string) $seq, 4, '0', STR_PAD_LEFT);
    }

    public function createPayment(array $attributes): Payment
    {
        /** @var Payment $payment */
        $payment = $this->query()->withoutGlobalScopes()->create($attributes);

        return $payment->load(['member', 'branch', 'allocations.invoice', 'receivedByUser']);
    }

    public function updatePayment(Payment $payment, array $attributes): Payment
    {
        $payment->update($attributes);

        return $payment->fresh(['member', 'branch', 'allocations.invoice', 'receivedByUser']);
    }

    public function createAllocation(array $attributes): PaymentAllocation
    {
        /** @var PaymentAllocation $allocation */
        $allocation = PaymentAllocation::query()->withoutGlobalScopes()->create($attributes);

        return $allocation;
    }
}
