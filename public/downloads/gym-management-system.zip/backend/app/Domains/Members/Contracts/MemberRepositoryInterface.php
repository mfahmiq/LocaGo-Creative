<?php

declare(strict_types=1);

namespace App\Domains\Members\Contracts;

use App\Domains\Members\Models\Member;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface MemberRepositoryInterface
{
    public function createMember(array $attributes): Member;

    public function updateMember(Member $member, array $attributes): Member;

    public function deleteMember(Member $member): bool;

    public function findForTenant(int $tenantId, int $memberId): ?Member;

    public function findByUserId(int $tenantId, int $userId): ?Member;

    public function countForTenant(int $tenantId): int;

    public function emailExistsForTenant(int $tenantId, string $email, ?int $exceptMemberId = null): bool;

    public function generateUniqueMemberCode(int $tenantId): string;

    public function generateUniqueReferralCode(int $tenantId): string;

    /**
     * @param  array{
     *     search?: string|null,
     *     status?: string|null,
     *     home_branch_id?: int|null,
     *     per_page?: int
     * }  $filters
     */
    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator;
}
