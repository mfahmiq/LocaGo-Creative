<?php

declare(strict_types=1);

namespace App\Domains\Members\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MemberNote extends BaseModel
{
    use BelongsToTenant;

    protected $table = 'member_notes';

    protected $fillable = [
        'tenant_id',
        'member_id',
        'note',
        'is_alert',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'is_alert' => 'boolean',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function member(): BelongsTo
    {
        return $this->belongsTo(Member::class);
    }
}
