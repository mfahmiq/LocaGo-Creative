<?php

declare(strict_types=1);

namespace App\Domains\Members\Models;

use App\Core\Models\BaseModel;
use App\Core\Models\Concerns\BelongsToTenant;
use App\Domains\Identity\Models\User;
use App\Domains\Organization\Models\Branch;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Member extends BaseModel
{
    use BelongsToTenant;

    protected $table = 'members';

    protected $fillable = [
        'tenant_id',
        'user_id',
        'home_branch_id',
        'member_code',
        'first_name',
        'last_name',
        'email',
        'phone',
        'whatsapp_opt_in',
        'whatsapp_phone',
        'gender',
        'date_of_birth',
        'photo_path',
        'emergency_name',
        'emergency_phone',
        'status',
        'joined_at',
        'referral_code',
        'referred_by_member_id',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'date_of_birth' => 'date',
            'joined_at' => 'date',
            'whatsapp_opt_in' => 'boolean',
        ];
    }

    public function whatsappRecipient(): ?string
    {
        if (! $this->whatsapp_opt_in) {
            return null;
        }

        $phone = trim((string) ($this->whatsapp_phone ?: $this->phone));

        return $phone !== '' ? $phone : null;
    }


    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function homeBranch(): BelongsTo
    {
        return $this->belongsTo(Branch::class, 'home_branch_id');
    }
}
