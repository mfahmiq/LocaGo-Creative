<?php

declare(strict_types=1);

namespace App\Domains\Members\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Members\Models\Member;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Str;

/**
 * @extends BaseRepository<Member>
 */
class EloquentMemberRepository extends BaseRepository implements MemberRepositoryInterface
{
    public function __construct(Member $model)
    {
        parent::__construct($model);
    }

    public function createMember(array $attributes): Member
    {
        /** @var Member $member */
        $member = $this->query()->withoutGlobalScopes()->create($attributes);

        return $member;
    }

    public function updateMember(Member $member, array $attributes): Member
    {
        $member->update($attributes);

        return $member->refresh();
    }

    public function deleteMember(Member $member): bool
    {
        return (bool) $member->delete();
    }

    public function findForTenant(int $tenantId, int $memberId): ?Member
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('id', $memberId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function findByUserId(int $tenantId, int $userId): ?Member
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('user_id', $userId)
            ->whereNull('deleted_at')
            ->first();
    }

    public function countForTenant(int $tenantId): int
    {
        return $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->count();
    }

    public function emailExistsForTenant(int $tenantId, string $email, ?int $exceptMemberId = null): bool
    {
        $query = $this->query()
            ->withoutGlobalScopes()
            ->where('tenant_id', $tenantId)
            ->where('email', $email)
            ->whereNull('deleted_at');

        if ($exceptMemberId !== null) {
            $query->where('id', '!=', $exceptMemberId);
        }

        return $query->exists();
    }

    public function generateUniqueMemberCode(int $tenantId): string
    {
        do {
            $code = 'MEM-'.strtoupper(Str::random(8));
        } while (
            $this->query()
                ->withoutGlobalScopes()
                ->where('tenant_id', $tenantId)
                ->where('member_code', $code)
                ->exists()
        );

        return $code;
    }

    public function generateUniqueReferralCode(int $tenantId): string
    {
        do {
            $code = strtoupper(Str::random(8));
        } while (
            $this->query()
                ->withoutGlobalScopes()
                ->where('tenant_id', $tenantId)
                ->where('referral_code', $code)
                ->exists()
        );

        return $code;
    }

    public function paginateForTenant(int $tenantId, array $filters = []): LengthAwarePaginator
    {
        $perPage = min(
            max((int) ($filters['per_page'] ?? config('gms.api.pagination_default', 10)), 1),
            (int) config('gms.api.pagination_max', 100)
        );

        $query = $this->query()
            ->withoutGlobalScopes()
            ->with(['homeBranch'])
            ->where('tenant_id', $tenantId)
            ->whereNull('deleted_at')
            ->orderByDesc('id');

        if (! empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        if (! empty($filters['home_branch_id'])) {
            $query->where('home_branch_id', (int) $filters['home_branch_id']);
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);
            $query->where(function ($q) use ($search): void {
                $q->where('first_name', 'like', "%{$search}%")
                    ->orWhere('last_name', 'like', "%{$search}%")
                    ->orWhere('email', 'like', "%{$search}%")
                    ->orWhere('phone', 'like', "%{$search}%")
                    ->orWhere('member_code', 'like', "%{$search}%");
            });
        }

        return $query->paginate($perPage);
    }
}
