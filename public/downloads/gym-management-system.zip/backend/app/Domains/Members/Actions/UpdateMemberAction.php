<?php

declare(strict_types=1);

namespace App\Domains\Members\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Members\Models\Member;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class UpdateMemberAction extends Action
{
    public function __construct(
        private readonly MemberRepositoryInterface $members,
        private readonly BranchRepositoryInterface $branches,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Member
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $memberId */
        $memberId = (int) $args[1];
        /** @var array<string, mixed> $data */
        $data = $args[2];

        $member = $this->members->findForTenant($tenant->id, $memberId);

        if ($member === null) {
            throw new DomainException('Member not found.', 'member_not_found', Response::HTTP_NOT_FOUND);
        }

        if (array_key_exists('home_branch_id', $data) && $data['home_branch_id'] !== null) {
            $branch = $this->branches->findActiveForTenant($tenant->id, (int) $data['home_branch_id']);

            if ($branch === null) {
                throw new DomainException(
                    'Home branch is invalid or inactive.',
                    'invalid_home_branch',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }
        }

        if (array_key_exists('email', $data) && $data['email'] !== null && $data['email'] !== '') {
            $email = strtolower(trim((string) $data['email']));
            if ($this->members->emailExistsForTenant($tenant->id, $email, $member->id)) {
                throw new DomainException(
                    'A member with this email already exists.',
                    'member_email_exists',
                    Response::HTTP_CONFLICT
                );
            }
            $data['email'] = $email;
        }

        $old = $member->only([
            'first_name', 'last_name', 'email', 'phone', 'status', 'home_branch_id',
        ]);

        $payload = array_intersect_key($data, array_flip([
            'home_branch_id', 'first_name', 'last_name', 'email', 'phone', 'gender',
            'date_of_birth', 'emergency_name', 'emergency_phone', 'status', 'joined_at',
            'referred_by_member_id',
        ]));

        $updated = $this->members->updateMember($member, $payload);

        $this->audit->write(
            action: 'member.updated',
            entityType: 'member',
            entityId: $updated->id,
            tenantId: $tenant->id,
            oldValues: $old,
            newValues: $updated->only(array_keys($old))
        );

        return $updated->load('homeBranch');
    }
}
