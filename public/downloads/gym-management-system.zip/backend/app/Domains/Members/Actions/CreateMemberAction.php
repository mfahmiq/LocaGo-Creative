<?php

declare(strict_types=1);

namespace App\Domains\Members\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Members\Models\Member;
use App\Domains\Organization\Contracts\BranchRepositoryInterface;
use App\Domains\Platform\Services\EntitlementGuard;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class CreateMemberAction extends Action
{
    public function __construct(
        private readonly MemberRepositoryInterface $members,
        private readonly BranchRepositoryInterface $branches,
        private readonly EntitlementGuard $entitlements,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Member
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var array<string, mixed> $data */
        $data = $args[1];

        return $this->transaction(function () use ($tenant, $data): Member {
            $this->entitlements->assertCanAddMember($tenant);

            $branch = $this->branches->findActiveForTenant($tenant->id, (int) $data['home_branch_id']);

            if ($branch === null) {
                throw new DomainException(
                    'Home branch is invalid or inactive.',
                    'invalid_home_branch',
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }

            $email = isset($data['email']) ? strtolower(trim((string) $data['email'])) : null;

            if ($email !== null && $email !== '' && $this->members->emailExistsForTenant($tenant->id, $email)) {
                throw new DomainException(
                    'A member with this email already exists.',
                    'member_email_exists',
                    Response::HTTP_CONFLICT
                );
            }

            $member = $this->members->createMember([
                'tenant_id' => $tenant->id,
                'user_id' => null,
                'home_branch_id' => $branch->id,
                'member_code' => $this->members->generateUniqueMemberCode($tenant->id),
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'email' => $email ?: null,
                'phone' => $data['phone'] ?? null,
                'gender' => $data['gender'] ?? null,
                'date_of_birth' => $data['date_of_birth'] ?? null,
                'emergency_name' => $data['emergency_name'] ?? null,
                'emergency_phone' => $data['emergency_phone'] ?? null,
                'status' => $data['status'] ?? 'active',
                'joined_at' => $data['joined_at'] ?? now()->toDateString(),
                'referral_code' => $this->members->generateUniqueReferralCode($tenant->id),
                'referred_by_member_id' => $data['referred_by_member_id'] ?? null,
            ]);

            $this->audit->write(
                action: 'member.created',
                entityType: 'member',
                entityId: $member->id,
                tenantId: $tenant->id,
                newValues: [
                    'member_code' => $member->member_code,
                    'status' => $member->status,
                    'email' => $member->email,
                ]
            );

            return $member->load('homeBranch');
        });
    }
}
