<?php

declare(strict_types=1);

namespace App\Domains\Members\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Members\Models\Member;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class ChangeMemberStatusAction extends Action
{
    private const STATUSES = ['lead', 'active', 'inactive', 'blacklisted'];

    public function __construct(
        private readonly MemberRepositoryInterface $members,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): Member
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $memberId */
        $memberId = (int) $args[1];
        /** @var string $status */
        $status = (string) $args[2];

        if (! in_array($status, self::STATUSES, true)) {
            throw new DomainException('Invalid member status.', 'invalid_member_status', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        $member = $this->members->findForTenant($tenant->id, $memberId);

        if ($member === null) {
            throw new DomainException('Member not found.', 'member_not_found', Response::HTTP_NOT_FOUND);
        }

        $old = $member->status;
        $updated = $this->members->updateMember($member, ['status' => $status]);

        $this->audit->write(
            action: 'member.status_changed',
            entityType: 'member',
            entityId: $updated->id,
            tenantId: $tenant->id,
            oldValues: ['status' => $old],
            newValues: ['status' => $status]
        );

        return $updated->load('homeBranch');
    }
}
