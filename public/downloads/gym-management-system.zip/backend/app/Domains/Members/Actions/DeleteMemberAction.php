<?php

declare(strict_types=1);

namespace App\Domains\Members\Actions;

use App\Core\Actions\Action;
use App\Core\Exceptions\DomainException;
use App\Domains\Audit\Services\AuditWriter;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Members\Models\Member;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

final class DeleteMemberAction extends Action
{
    public function __construct(
        private readonly MemberRepositoryInterface $members,
        private readonly AuditWriter $audit
    ) {}

    public function execute(mixed ...$args): bool
    {
        /** @var Tenant $tenant */
        $tenant = $args[0];
        /** @var int $memberId */
        $memberId = (int) $args[1];

        $member = $this->members->findForTenant($tenant->id, $memberId);

        if ($member === null) {
            throw new DomainException('Member not found.', 'member_not_found', Response::HTTP_NOT_FOUND);
        }

        $deleted = $this->members->deleteMember($member);

        $this->audit->write(
            action: 'member.deleted',
            entityType: 'member',
            entityId: $memberId,
            tenantId: $tenant->id,
            oldValues: [
                'member_code' => $member->member_code,
                'email' => $member->email,
                'status' => $member->status,
            ]
        );

        return $deleted;
    }
}
