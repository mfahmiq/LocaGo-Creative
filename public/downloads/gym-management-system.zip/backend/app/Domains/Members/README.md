﻿# Members Domain

## Admin Portal — Members (complete)

Requires `auth:sanctum` + staff + `X-Tenant-Slug` + permissions.

| Method | Path | Permission |
| --- | --- | --- |
| GET | `/api/v1/admin/members` | `members.view` |
| POST | `/api/v1/admin/members` | `members.create` |
| GET | `/api/v1/admin/members/{id}` | `members.view` |
| PUT | `/api/v1/admin/members/{id}` | `members.update` |
| DELETE | `/api/v1/admin/members/{id}` | `members.update` |
| PATCH | `/api/v1/admin/members/{id}/status` | `members.update` |

Query filters (list): `search`, `status`, `home_branch_id`, `per_page`

Staff-created members do **not** auto-create portal users (`user_id` null). Portal accounts come from Member Registration.

Statuses: `lead` \| `active` \| `inactive` \| `blacklisted`

Audited actions: `member.created`, `member.updated`, `member.deleted`, `member.status_changed`

## Member Portal — Auth (complete)

- `POST /api/v1/member/auth/register`
- `POST /api/v1/member/auth/login`
- `GET /api/v1/member/auth/me`
- `POST /api/v1/member/auth/logout`
- Email verification + password reset

## Member Portal — Operations (complete)

See [`app/Domains/MemberPortal/README.md`](../MemberPortal/README.md) for the full endpoint list, permissions, and route wiring.

Requires `auth:sanctum` + member user + `X-Tenant-Slug` + `member_portal.*` permissions (via `CODE_MEMBER` role).

## Next Admin modules
Personal Training / Trainers → … (Classes/Schedule complete)
