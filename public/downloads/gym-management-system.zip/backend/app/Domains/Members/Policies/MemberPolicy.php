<?php

declare(strict_types=1);

namespace App\Domains\Members\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Members\Models\Member;

final class MemberPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $this->hasPermission($user, 'members.view');
    }

    public function view(User $user, Member $member): bool
    {
        return $this->hasPermission($user, 'members.view')
            && $this->sameTenant($user, $member)
            && $this->branchAllowed($user, $member->home_branch_id !== null ? (int) $member->home_branch_id : null);
    }

    public function create(User $user): bool
    {
        return $this->hasPermission($user, 'members.create')
            || $this->hasPermission($user, 'members.manage');
    }

    public function update(User $user, Member $member): bool
    {
        return ($this->hasPermission($user, 'members.update') || $this->hasPermission($user, 'members.manage'))
            && $this->sameTenant($user, $member);
    }

    public function delete(User $user, Member $member): bool
    {
        return $this->update($user, $member);
    }

    public function changeStatus(User $user, Member $member): bool
    {
        return $this->update($user, $member);
    }
}
