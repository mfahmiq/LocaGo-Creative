<?php

declare(strict_types=1);

namespace App\Domains\Members\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Members\Actions\ChangeMemberStatusAction;
use App\Domains\Members\Actions\CreateMemberAction;
use App\Domains\Members\Actions\DeleteMemberAction;
use App\Domains\Members\Actions\UpdateMemberAction;
use App\Domains\Members\Contracts\MemberRepositoryInterface;
use App\Domains\Members\Models\Member;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\Response;

final class MemberService extends BaseService
{
    public function __construct(
        private readonly MemberRepositoryInterface $members,
        private readonly CreateMemberAction $createMemberAction,
        private readonly UpdateMemberAction $updateMemberAction,
        private readonly DeleteMemberAction $deleteMemberAction,
        private readonly ChangeMemberStatusAction $changeMemberStatusAction
    ) {}

    /**
     * @param  array<string, mixed>  $filters
     */
    public function paginate(Tenant $tenant, array $filters = []): LengthAwarePaginator
    {
        return $this->members->paginateForTenant($tenant->id, $filters);
    }

    public function find(Tenant $tenant, int $memberId): Member
    {
        $member = $this->members->findForTenant($tenant->id, $memberId);

        if ($member === null) {
            throw new DomainException('Member not found.', 'member_not_found', Response::HTTP_NOT_FOUND);
        }

        return $member->load('homeBranch');
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(Tenant $tenant, array $data): Member
    {
        return $this->createMemberAction->execute($tenant, $data);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(Tenant $tenant, int $memberId, array $data): Member
    {
        return $this->updateMemberAction->execute($tenant, $memberId, $data);
    }

    public function delete(Tenant $tenant, int $memberId): bool
    {
        return $this->deleteMemberAction->execute($tenant, $memberId);
    }

    public function changeStatus(Tenant $tenant, int $memberId, string $status): Member
    {
        return $this->changeMemberStatusAction->execute($tenant, $memberId, $status);
    }
}
