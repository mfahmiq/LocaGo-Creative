<?php

declare(strict_types=1);

namespace App\Domains\Platform\Contracts;

use App\Domains\Platform\Models\SaasPlan;
use App\Domains\Platform\Models\SaasPlanLimit;
use Illuminate\Database\Eloquent\Collection;

interface SaasPlanRepositoryInterface
{
    /**
     * @return Collection<int, SaasPlan>
     */
    public function listAll(): Collection;

    public function findById(int $id): ?SaasPlan;

    public function findByCode(string $code): ?SaasPlan;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function createPlan(array $attributes): SaasPlan;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function updatePlan(SaasPlan $plan, array $attributes): SaasPlan;

    public function deletePlan(SaasPlan $plan): bool;

    /**
     * @param  array<string, mixed>  $attributes
     */
    public function upsertLimits(SaasPlan $plan, array $attributes): SaasPlanLimit;
}
