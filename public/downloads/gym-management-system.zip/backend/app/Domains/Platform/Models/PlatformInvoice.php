<?php

declare(strict_types=1);

namespace App\Domains\Platform\Models;

use App\Core\Models\BaseModel;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PlatformInvoice extends BaseModel
{
    public const STATUS_ISSUED = 'issued';

    public const STATUS_PAID = 'paid';

    public const STATUS_VOID = 'void';

    public const STATUS_OVERDUE = 'overdue';

    protected $table = 'platform_invoices';

    protected $fillable = [
        'tenant_id',
        'invoice_number',
        'status',
        'currency_code',
        'subtotal',
        'tax_total',
        'grand_total',
        'due_date',
        'issued_at',
        'paid_at',
        'billing_mode',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'subtotal' => 'decimal:2',
            'tax_total' => 'decimal:2',
            'grand_total' => 'decimal:2',
            'due_date' => 'date',
            'issued_at' => 'datetime',
            'paid_at' => 'datetime',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(PlatformPayment::class, 'platform_invoice_id');
    }
}
