<?php

declare(strict_types=1);

namespace App\Domains\Platform\Models;

use App\Core\Models\BaseModel;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class SaasPlan extends BaseModel
{
    protected $table = 'saas_plans';

    protected $fillable = [
        'code',
        'name',
        'description',
        'price',
        'currency_code',
        'billing_interval',
        'is_active',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'price' => 'decimal:2',
            'is_active' => 'boolean',
        ];
    }

    public function limits(): HasOne
    {
        return $this->hasOne(SaasPlanLimit::class, 'saas_plan_id');
    }

    public function tenants(): HasMany
    {
        return $this->hasMany(Tenant::class, 'saas_plan_id');
    }
}
