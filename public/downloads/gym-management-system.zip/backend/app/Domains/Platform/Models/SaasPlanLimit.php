<?php

declare(strict_types=1);

namespace App\Domains\Platform\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SaasPlanLimit extends Model
{
    public $timestamps = true;

    protected $dateFormat = 'Y-m-d H:i:s.v';

    protected $table = 'saas_plan_limits';

    protected $fillable = [
        'saas_plan_id',
        'max_seats',
        'max_branches',
        'max_members',
        'module_pos',
        'module_nutrition',
        'module_waitlist',
        'module_referral',
        'module_equipment',
        'storage_mb',
    ];

    protected function casts(): array
    {
        return [
            'max_seats' => 'integer',
            'max_branches' => 'integer',
            'max_members' => 'integer',
            'module_pos' => 'boolean',
            'module_nutrition' => 'boolean',
            'module_waitlist' => 'boolean',
            'module_referral' => 'boolean',
            'module_equipment' => 'boolean',
            'storage_mb' => 'integer',
        ];
    }

    public function plan(): BelongsTo
    {
        return $this->belongsTo(SaasPlan::class, 'saas_plan_id');
    }
}
