<?php

declare(strict_types=1);

namespace App\Domains\Platform\Models;

use App\Core\Models\BaseModel;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PlatformPayment extends BaseModel
{
    protected $table = 'platform_payments';

    protected $fillable = [
        'tenant_id',
        'platform_invoice_id',
        'amount',
        'currency_code',
        'method',
        'reference',
        'paid_at',
        'created_by',
        'updated_by',
        'deleted_by',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:2',
            'paid_at' => 'datetime',
        ];
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(PlatformInvoice::class, 'platform_invoice_id');
    }
}
