<?php

declare(strict_types=1);

namespace App\Domains\Platform\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Platform\Models\SaasPlan;

final class SaasPlanPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->canAccessPlatformConsole()
            && $this->hasPermission($user, 'platform.plans.view');
    }

    public function manage(User $user, ?SaasPlan $plan = null): bool
    {
        return $user->canAccessPlatformConsole()
            && $this->hasPermission($user, 'platform.plans.manage');
    }
}
