<?php

declare(strict_types=1);

namespace App\Domains\Platform\Policies;

use App\Core\Policies\BasePolicy;
use App\Domains\Identity\Models\User;
use App\Domains\Tenancy\Models\Tenant;

final class PlatformTenantPolicy extends BasePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->canAccessPlatformConsole()
            && $this->hasPermission($user, 'platform.tenants.view');
    }

    public function manage(User $user, ?Tenant $tenant = null): bool
    {
        return $user->canAccessPlatformConsole()
            && $this->hasPermission($user, 'platform.tenants.manage');
    }
}
