<?php

declare(strict_types=1);

namespace App\Domains\Platform\Repositories;

use App\Core\Repositories\BaseRepository;
use App\Domains\Platform\Contracts\SaasPlanRepositoryInterface;
use App\Domains\Platform\Models\SaasPlan;
use App\Domains\Platform\Models\SaasPlanLimit;
use Illuminate\Database\Eloquent\Collection;

/**
 * @extends BaseRepository<SaasPlan>
 */
class EloquentSaasPlanRepository extends BaseRepository implements SaasPlanRepositoryInterface
{
    public function __construct(SaasPlan $model)
    {
        parent::__construct($model);
    }

    public function listAll(): Collection
    {
        return $this->query()->with('limits')->orderBy('name')->get();
    }

    public function findById(int $id): ?SaasPlan
    {
        return $this->query()->with('limits')->where('id', $id)->first();
    }

    public function findByCode(string $code): ?SaasPlan
    {
        return $this->query()->with('limits')->where('code', $code)->first();
    }

    public function createPlan(array $attributes): SaasPlan
    {
        /** @var SaasPlan $plan */
        $plan = $this->query()->create($attributes);

        return $plan->load('limits');
    }

    public function updatePlan(SaasPlan $plan, array $attributes): SaasPlan
    {
        $plan->update($attributes);

        return $plan->fresh('limits');
    }

    public function deletePlan(SaasPlan $plan): bool
    {
        return (bool) $plan->delete();
    }

    public function upsertLimits(SaasPlan $plan, array $attributes): SaasPlanLimit
    {
        /** @var SaasPlanLimit $limits */
        $limits = SaasPlanLimit::query()->updateOrCreate(
            ['saas_plan_id' => $plan->id],
            $attributes
        );

        return $limits;
    }
}
