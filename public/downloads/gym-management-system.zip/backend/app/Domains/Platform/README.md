﻿# Platform Domain

## Roles
| Code | Name | Scope |
| --- | --- | --- |
| `super_admin` | Super Admin / Platform Owner | Full platform console |
| `platform_support` | Platform Support | View tenants/plans/audit |

Seed: `php artisan db:seed --class=PlatformOwnerSeeder`  
Demo Super Admin: `superadmin@gms.test` / `Password1!`

## Auth
- `POST /api/v1/platform/auth/login` — no tenant header
- `GET /api/v1/platform/auth/me`
- `POST /api/v1/platform/auth/logout`
- Sanctum ability: `platform`

## SaaS Plans
- `GET/POST /api/v1/platform/saas-plans` (`platform.plans.view` / `manage`)
- `GET/PUT/DELETE /api/v1/platform/saas-plans/{id}`
- `PUT /api/v1/platform/saas-plans/{id}/limits`

## Tenant lifecycle
- `GET/POST /api/v1/platform/tenants` (`platform.tenants.view` / `manage`)
- `POST .../activate|extend-trial|suspend|reactivate`
- `PUT .../plan`

## Entitlements (Admin Portal)
- `GET /api/v1/admin/entitlements` — requires `entitlements.view`
- `EntitlementGuard` enforces seats / branches / members / modules
