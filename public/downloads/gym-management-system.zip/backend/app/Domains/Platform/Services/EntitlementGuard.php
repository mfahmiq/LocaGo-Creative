<?php

declare(strict_types=1);

namespace App\Domains\Platform\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Tenancy\Models\Tenant;
use Symfony\Component\HttpFoundation\Response;

/**
 * Enforces SaaS plan limits and module entitlements at write boundaries.
 */
final class EntitlementGuard extends BaseService
{
    public function __construct(
        private readonly SaasPlanService $plans
    ) {}

    public function assertCanAddSeat(Tenant $tenant): void
    {
        $entitlements = $this->plans->entitlementsForTenant($tenant);
        $max = (int) ($entitlements['limits']?->max_seats ?? 0);

        if ($entitlements['usage']['seats'] >= $max) {
            throw new DomainException(
                'Staff seat limit reached for this plan.',
                'seat_limit_reached',
                Response::HTTP_FORBIDDEN
            );
        }
    }

    public function assertCanAddBranch(Tenant $tenant): void
    {
        $entitlements = $this->plans->entitlementsForTenant($tenant);
        $max = (int) ($entitlements['limits']?->max_branches ?? 0);

        if ($entitlements['usage']['branches'] >= $max) {
            throw new DomainException(
                'Branch limit reached for this plan.',
                'branch_limit_reached',
                Response::HTTP_FORBIDDEN
            );
        }
    }

    public function assertCanAddMember(Tenant $tenant): void
    {
        $entitlements = $this->plans->entitlementsForTenant($tenant);
        $max = (int) ($entitlements['limits']?->max_members ?? 0);

        if ($entitlements['usage']['members'] >= $max) {
            throw new DomainException(
                'Member limit reached for this plan.',
                'member_limit_reached',
                Response::HTTP_FORBIDDEN
            );
        }
    }

    public function assertModuleEnabled(Tenant $tenant, string $module): void
    {
        $entitlements = $this->plans->entitlementsForTenant($tenant);
        $enabled = (bool) ($entitlements['modules'][$module] ?? false);

        if (! $enabled) {
            throw new DomainException(
                'Module is not enabled on this plan.',
                'module_not_entitled',
                Response::HTTP_FORBIDDEN
            );
        }
    }
}
