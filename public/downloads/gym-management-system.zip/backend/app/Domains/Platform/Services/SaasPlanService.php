<?php

declare(strict_types=1);

namespace App\Domains\Platform\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Identity\Models\User;
use App\Domains\Organization\Models\Branch;
use App\Domains\Members\Models\Member;
use App\Domains\Platform\Contracts\SaasPlanRepositoryInterface;
use App\Domains\Platform\Models\SaasPlan;
use App\Domains\Platform\Models\SaasPlanLimit;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Database\Eloquent\Collection;
use Symfony\Component\HttpFoundation\Response;

final class SaasPlanService extends BaseService
{
    public function __construct(
        private readonly SaasPlanRepositoryInterface $plans
    ) {}

    /**
     * @return Collection<int, SaasPlan>
     */
    public function list(): Collection
    {
        return $this->plans->listAll();
    }

    public function find(int $id): ?SaasPlan
    {
        return $this->plans->findById($id);
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function create(array $data): SaasPlan
    {
        $code = strtolower(trim((string) $data['code']));

        if ($this->plans->findByCode($code) !== null) {
            throw new DomainException('Plan code already exists.', 'saas_plan_code_exists', Response::HTTP_CONFLICT);
        }

        $plan = $this->plans->createPlan([
            'code' => $code,
            'name' => $data['name'],
            'description' => $data['description'] ?? null,
            'price' => $data['price'] ?? 0,
            'currency_code' => $data['currency_code'] ?? 'USD',
            'billing_interval' => $data['billing_interval'] ?? 'monthly',
            'is_active' => $data['is_active'] ?? true,
        ]);

        $this->plans->upsertLimits($plan, $this->defaultLimits($data['limits'] ?? []));

        return $plan->fresh('limits');
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function update(int $id, array $data): SaasPlan
    {
        $plan = $this->requirePlan($id);
        $payload = [];

        foreach (['name', 'description', 'price', 'currency_code', 'billing_interval', 'is_active'] as $field) {
            if (array_key_exists($field, $data)) {
                $payload[$field] = $data[$field];
            }
        }

        if (isset($data['code'])) {
            $code = strtolower(trim((string) $data['code']));
            $existing = $this->plans->findByCode($code);
            if ($existing !== null && $existing->id !== $plan->id) {
                throw new DomainException('Plan code already exists.', 'saas_plan_code_exists', Response::HTTP_CONFLICT);
            }
            $payload['code'] = $code;
        }

        return $this->plans->updatePlan($plan, $payload);
    }

    /**
     * @param  array<string, mixed>  $limits
     */
    public function updateLimits(int $id, array $limits): SaasPlan
    {
        $plan = $this->requirePlan($id);
        $existing = $plan->limits;
        $merged = [
            'max_seats' => (int) ($limits['max_seats'] ?? $existing?->max_seats ?? 5),
            'max_branches' => (int) ($limits['max_branches'] ?? $existing?->max_branches ?? 1),
            'max_members' => (int) ($limits['max_members'] ?? $existing?->max_members ?? 500),
            'module_pos' => (bool) ($limits['module_pos'] ?? $existing?->module_pos ?? true),
            'module_nutrition' => (bool) ($limits['module_nutrition'] ?? $existing?->module_nutrition ?? false),
            'module_waitlist' => (bool) ($limits['module_waitlist'] ?? $existing?->module_waitlist ?? true),
            'module_referral' => (bool) ($limits['module_referral'] ?? $existing?->module_referral ?? false),
            'module_equipment' => (bool) ($limits['module_equipment'] ?? $existing?->module_equipment ?? false),
            'storage_mb' => (int) ($limits['storage_mb'] ?? $existing?->storage_mb ?? 1024),
        ];
        $this->plans->upsertLimits($plan, $merged);

        return $plan->fresh('limits');
    }

    public function delete(int $id): bool
    {
        $plan = $this->requirePlan($id);

        if ($plan->tenants()->exists()) {
            throw new DomainException(
                'Plan is assigned to one or more tenants.',
                'saas_plan_in_use',
                Response::HTTP_CONFLICT
            );
        }

        return $this->plans->deletePlan($plan);
    }

    public function assignToTenant(Tenant $tenant, int $planId): Tenant
    {
        $plan = $this->requirePlan($planId);

        if (! $plan->is_active) {
            throw new DomainException('Plan is inactive.', 'saas_plan_inactive', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        $tenant->forceFill(['saas_plan_id' => $plan->id])->save();

        return $tenant->fresh();
    }

    /**
     * @return array{plan: SaasPlan|null, limits: SaasPlanLimit|null, usage: array<string, int>, modules: array<string, bool>}
     */
    public function entitlementsForTenant(Tenant $tenant): array
    {
        $plan = $this->plans->findById((int) $tenant->saas_plan_id);
        $limits = $plan?->limits;

        $usage = [
            'seats' => User::query()
                ->where('tenant_id', $tenant->id)
                ->where('user_type', User::TYPE_STAFF)
                ->whereNull('deleted_at')
                ->count(),
            'branches' => Branch::query()
                ->where('tenant_id', $tenant->id)
                ->whereNull('deleted_at')
                ->count(),
            'members' => Member::query()
                ->where('tenant_id', $tenant->id)
                ->whereNull('deleted_at')
                ->count(),
        ];

        $modules = [
            'pos' => (bool) ($limits?->module_pos ?? false),
            'nutrition' => (bool) ($limits?->module_nutrition ?? false),
            'waitlist' => (bool) ($limits?->module_waitlist ?? false),
            'referral' => (bool) ($limits?->module_referral ?? false),
            'equipment' => (bool) ($limits?->module_equipment ?? false),
        ];

        return [
            'plan' => $plan,
            'limits' => $limits,
            'usage' => $usage,
            'modules' => $modules,
        ];
    }

    private function requirePlan(int $id): SaasPlan
    {
        $plan = $this->plans->findById($id);

        if ($plan === null) {
            throw new DomainException('SaaS plan not found.', 'saas_plan_not_found', Response::HTTP_NOT_FOUND);
        }

        return $plan;
    }

    /**
     * @param  array<string, mixed>  $limits
     * @return array<string, mixed>
     */
    private function defaultLimits(array $limits): array
    {
        return [
            'max_seats' => (int) ($limits['max_seats'] ?? 5),
            'max_branches' => (int) ($limits['max_branches'] ?? 1),
            'max_members' => (int) ($limits['max_members'] ?? 500),
            'module_pos' => (bool) ($limits['module_pos'] ?? true),
            'module_nutrition' => (bool) ($limits['module_nutrition'] ?? false),
            'module_waitlist' => (bool) ($limits['module_waitlist'] ?? true),
            'module_referral' => (bool) ($limits['module_referral'] ?? false),
            'module_equipment' => (bool) ($limits['module_equipment'] ?? false),
            'storage_mb' => (int) ($limits['storage_mb'] ?? 1024),
        ];
    }
}
