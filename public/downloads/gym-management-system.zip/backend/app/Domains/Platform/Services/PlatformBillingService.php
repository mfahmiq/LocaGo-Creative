<?php

declare(strict_types=1);

namespace App\Domains\Platform\Services;

use App\Core\Exceptions\DomainException;
use App\Core\Services\BaseService;
use App\Domains\Platform\Models\PlatformInvoice;
use App\Domains\Platform\Models\PlatformPayment;
use App\Domains\Platform\Models\SaasPlan;
use App\Domains\Tenancy\Models\Tenant;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

final class PlatformBillingService extends BaseService
{
    /**
     * @return array{
     *   summary: array<string, mixed>,
     *   invoices: list<PlatformInvoice>,
     *   payments: list<PlatformPayment>,
     *   subscriptions: list<array<string, mixed>>
     * }
     */
    public function overview(?string $status = null): array
    {
        $this->refreshOverdueStatuses();

        $invoicesQuery = PlatformInvoice::query()
            ->with(['tenant:id,name,slug,status,saas_plan_id', 'tenant.saasPlan:id,name,code,price,currency_code,billing_interval'])
            ->orderByDesc('issued_at')
            ->orderByDesc('id');

        if (is_string($status) && $status !== '') {
            $invoicesQuery->where('status', $status);
        }

        /** @var Collection<int, PlatformInvoice> $invoices */
        $invoices = $invoicesQuery->limit(100)->get();

        $payments = PlatformPayment::query()
            ->with(['tenant:id,name,slug'])
            ->orderByDesc('paid_at')
            ->limit(50)
            ->get();

        $subscriptions = $this->subscriptionRoster();

        $openStatuses = [PlatformInvoice::STATUS_ISSUED, PlatformInvoice::STATUS_OVERDUE];
        $outstanding = (float) PlatformInvoice::query()
            ->whereIn('status', $openStatuses)
            ->sum('grand_total');

        $collectedMonth = (float) PlatformPayment::query()
            ->where('paid_at', '>=', now()->startOfMonth())
            ->sum('amount');

        $mrr = 0.0;
        foreach ($subscriptions as $row) {
            if (($row['billable'] ?? false) !== true) {
                continue;
            }
            $mrr += (float) $row['monthly_amount'];
        }

        return [
            'summary' => [
                'mrr' => round($mrr, 2),
                'currency_code' => 'USD',
                'outstanding' => round($outstanding, 2),
                'collected_this_month' => round($collectedMonth, 2),
                'open_invoices' => PlatformInvoice::query()->whereIn('status', $openStatuses)->count(),
                'paid_invoices' => PlatformInvoice::query()->where('status', PlatformInvoice::STATUS_PAID)->count(),
                'billable_tenants' => collect($subscriptions)->where('billable', true)->count(),
                'trial_tenants' => Tenant::query()->where('status', 'trial')->whereNull('deleted_at')->count(),
            ],
            'invoices' => $invoices->all(),
            'payments' => $payments->all(),
            'subscriptions' => $subscriptions,
        ];
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function issueInvoice(array $data): PlatformInvoice
    {
        $tenant = Tenant::query()->with('saasPlan')->find((int) $data['tenant_id']);

        if ($tenant === null) {
            throw new DomainException('Tenant not found.', 'tenant_not_found', Response::HTTP_NOT_FOUND);
        }

        $plan = $tenant->saasPlan;
        $currency = strtoupper((string) ($data['currency_code'] ?? $plan?->currency_code ?? 'USD'));
        $subtotal = array_key_exists('subtotal', $data)
            ? (float) $data['subtotal']
            : (float) ($plan?->price ?? 0);
        $taxTotal = (float) ($data['tax_total'] ?? 0);
        $grandTotal = round($subtotal + $taxTotal, 2);

        if ($grandTotal <= 0) {
            throw new DomainException('Invoice total must be greater than zero.', 'invalid_amount', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        return DB::transaction(function () use ($tenant, $data, $currency, $subtotal, $taxTotal, $grandTotal): PlatformInvoice {
            $invoice = PlatformInvoice::query()->create([
                'tenant_id' => $tenant->id,
                'invoice_number' => $this->nextInvoiceNumber(),
                'status' => PlatformInvoice::STATUS_ISSUED,
                'currency_code' => $currency,
                'subtotal' => $subtotal,
                'tax_total' => $taxTotal,
                'grand_total' => $grandTotal,
                'due_date' => $data['due_date'] ?? now()->addDays(14)->toDateString(),
                'issued_at' => now(),
                'billing_mode' => $data['billing_mode'] ?? 'manual',
            ]);

            return $invoice->load(['tenant.saasPlan']);
        });
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public function recordPayment(int $invoiceId, array $data): PlatformPayment
    {
        $invoice = PlatformInvoice::query()->with('tenant')->find($invoiceId);

        if ($invoice === null) {
            throw new DomainException('Invoice not found.', 'platform_invoice_not_found', Response::HTTP_NOT_FOUND);
        }

        if (in_array($invoice->status, [PlatformInvoice::STATUS_PAID, PlatformInvoice::STATUS_VOID], true)) {
            throw new DomainException('Invoice cannot accept payments.', 'invoice_not_payable', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        $amount = (float) $data['amount'];
        if ($amount <= 0) {
            throw new DomainException('Payment amount must be greater than zero.', 'invalid_amount', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        return DB::transaction(function () use ($invoice, $data, $amount): PlatformPayment {
            $payment = PlatformPayment::query()->create([
                'tenant_id' => $invoice->tenant_id,
                'platform_invoice_id' => $invoice->id,
                'amount' => $amount,
                'currency_code' => $invoice->currency_code,
                'method' => $data['method'] ?? 'bank_transfer',
                'reference' => $data['reference'] ?? null,
                'paid_at' => $data['paid_at'] ?? now(),
            ]);

            $paidTotal = (float) $invoice->payments()->sum('amount');
            if ($paidTotal + 0.0001 >= (float) $invoice->grand_total) {
                $invoice->forceFill([
                    'status' => PlatformInvoice::STATUS_PAID,
                    'paid_at' => now(),
                ])->save();
            }

            return $payment->load(['tenant', 'invoice']);
        });
    }

    public function voidInvoice(int $invoiceId): PlatformInvoice
    {
        $invoice = PlatformInvoice::query()->with('tenant.saasPlan')->find($invoiceId);

        if ($invoice === null) {
            throw new DomainException('Invoice not found.', 'platform_invoice_not_found', Response::HTTP_NOT_FOUND);
        }

        if ($invoice->status === PlatformInvoice::STATUS_PAID) {
            throw new DomainException('Paid invoices cannot be voided.', 'invoice_paid', Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        if ($invoice->status === PlatformInvoice::STATUS_VOID) {
            return $invoice;
        }

        $invoice->forceFill(['status' => PlatformInvoice::STATUS_VOID])->save();

        return $invoice->fresh(['tenant.saasPlan']);
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function subscriptionRoster(): array
    {
        $tenants = Tenant::query()
            ->with('saasPlan')
            ->whereNull('deleted_at')
            ->orderBy('name')
            ->get();

        $rows = [];

        foreach ($tenants as $tenant) {
            /** @var SaasPlan|null $plan */
            $plan = $tenant->saasPlan;
            $price = (float) ($plan?->price ?? 0);
            $interval = $plan?->billing_interval ?? 'monthly';
            $monthly = $interval === 'yearly' ? $price / 12 : $price;
            $billable = in_array($tenant->status, ['active'], true) && $price > 0;

            $openBalance = (float) PlatformInvoice::query()
                ->where('tenant_id', $tenant->id)
                ->whereIn('status', [PlatformInvoice::STATUS_ISSUED, PlatformInvoice::STATUS_OVERDUE])
                ->sum('grand_total');

            $rows[] = [
                'tenant_id' => $tenant->id,
                'tenant_name' => $tenant->name,
                'tenant_slug' => $tenant->slug,
                'tenant_status' => $tenant->status,
                'plan_id' => $plan?->id,
                'plan_name' => $plan?->name,
                'plan_code' => $plan?->code,
                'price' => $price,
                'currency_code' => $plan?->currency_code ?? 'USD',
                'billing_interval' => $interval,
                'monthly_amount' => round($monthly, 2),
                'billable' => $billable,
                'open_balance' => round($openBalance, 2),
                'trial_ends_at' => $tenant->trial_ends_at?->toIso8601String(),
            ];
        }

        return $rows;
    }

    private function nextInvoiceNumber(): string
    {
        do {
            $number = 'PINV-'.now()->format('Ymd').'-'.Str::upper(Str::random(4));
        } while (PlatformInvoice::query()->where('invoice_number', $number)->exists());

        return $number;
    }

    private function refreshOverdueStatuses(): void
    {
        PlatformInvoice::query()
            ->where('status', PlatformInvoice::STATUS_ISSUED)
            ->whereNotNull('due_date')
            ->whereDate('due_date', '<', now()->toDateString())
            ->update(['status' => PlatformInvoice::STATUS_OVERDUE]);
    }
}
