import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Download, RefreshCw } from 'lucide-react'
import {
  downloadReportExport,
  fetchReportExports,
  type ReportExport,
  type ReportExportStatus,
} from '@/api/reports'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { findReportByKey } from '@/config/reportDefinitions'
import { formatDate } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

function statusTone(
  status: ReportExportStatus,
): 'neutral' | 'accent' | 'success' | 'danger' | 'warning' {
  switch (status) {
    case 'completed':
      return 'success'
    case 'failed':
      return 'danger'
    case 'processing':
      return 'accent'
    case 'queued':
      return 'warning'
    default:
      return 'neutral'
  }
}

function humanize(key: string) {
  return key
    .replace(/[._]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/\b\w/g, (c) => c.toUpperCase())
}

export function ReportExportsPage() {
  const { branches, hasPermission } = useAuth()
  const { showSuccess } = useFeedback()
  const queryClient = useQueryClient()
  const canExport = hasPermission('reports.export')
  const [page, setPage] = useState(1)
  const [error, setError] = useState<string | null>(null)

  const exportsQuery = useQuery({
    queryKey: ['reports', 'exports', page],
    queryFn: () => fetchReportExports({ page, per_page: DEFAULT_PAGE_SIZE }),
    enabled: canExport,
  })

  const downloadMutation = useMutation({
    mutationFn: (id: number) => downloadReportExport(id),
    onSuccess: () => showSuccess('Download started.'),
    onError: (err) =>
      setError(err instanceof ApiError ? err.message : 'Unable to download export.'),
  })

  if (!canExport) {
    return (
      <div className="animate-fade-up space-y-4">
        <PageHeader title="Export center" description="Server-side report CSV history." />
        <Alert tone="danger">
          Your role needs <code>reports.export</code> to manage server exports.
        </Alert>
      </div>
    )
  }

  const columns: Column<ReportExport>[] = [
    {
      key: 'id',
      header: 'ID',
      cell: (r) => <span className="tabular-nums text-muted">#{r.id}</span>,
    },
    {
      key: 'report',
      header: 'Report',
      cell: (r) => (
        <div>
          <div className="font-medium">
            {findReportByKey(r.report_key)?.name ?? humanize(r.report_key)}
          </div>
          <div className="text-xs text-muted">{r.report_key}</div>
        </div>
      ),
    },
    {
      key: 'filters',
      header: 'Filters',
      cell: (r) => {
        const branch =
          r.filters?.branch_id != null
            ? branches.find((b) => b.id === r.filters.branch_id)?.name
            : undefined
        const range =
          r.filters?.from && r.filters?.to
            ? `${r.filters.from} → ${r.filters.to}`
            : r.filters?.from || r.filters?.to || 'All dates'
        return (
          <span className="text-sm text-muted">
            {range}
            {branch ? ` · ${branch}` : ''}
          </span>
        )
      },
    },
    {
      key: 'status',
      header: 'Status',
      cell: (r) => <Badge tone={statusTone(r.status)}>{r.status}</Badge>,
    },
    {
      key: 'requester',
      header: 'Requested by',
      cell: (r) => r.requester?.name ?? '—',
    },
    {
      key: 'finished',
      header: 'Finished',
      cell: (r) => formatDate(r.finished_at ?? r.created_at),
    },
    {
      key: 'actions',
      header: '',
      cell: (r) =>
        r.status === 'completed' && r.file_path ? (
          <Button
            size="sm"
            variant="secondary"
            loading={downloadMutation.isPending && downloadMutation.variables === r.id}
            onClick={() => downloadMutation.mutate(r.id)}
          >
            <Download className="h-4 w-4" />
            Download
          </Button>
        ) : (
          <span className="text-xs text-muted">—</span>
        ),
    },
  ]

  return (
    <div className="animate-fade-up space-y-6">
      <PageHeader
        title="Export center"
        description="Server CSV exports generated from report dashboards. Client Excel/PDF exports are available on each report page."
        actions={
          <Button
            size="sm"
            variant="secondary"
            onClick={() => void queryClient.invalidateQueries({ queryKey: ['reports', 'exports'] })}
          >
            <RefreshCw className="h-4 w-4" />
            Refresh
          </Button>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <Card>
        <CardTitle>Server export history</CardTitle>
        <CardDescription className="mb-4">
          Requires <code>reports.export</code>. Files are stored securely and downloadable when completed.
        </CardDescription>
        {exportsQuery.isLoading ? (
          <div className="flex justify-center py-12">
            <Spinner label="Loading exports…" />
          </div>
        ) : (
          <>
            <DataTable
              columns={columns}
              rows={exportsQuery.data?.data ?? []}
              rowKey={(r) => r.id}
            />
            <div className="mt-4">
              <Pagination meta={exportsQuery.data?.meta} onPageChange={setPage} />
            </div>
          </>
        )}
      </Card>
    </div>
  )
}
