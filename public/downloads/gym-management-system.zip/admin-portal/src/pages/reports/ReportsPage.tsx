import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Activity,
  BarChart3,
  FileSpreadsheet,
  Receipt,
  RefreshCw,
  Server,
  ShoppingCart,
  UserRound,
  Users,
  Wallet,
} from 'lucide-react'
import {
  createReportExport,
  fetchReportCatalog,
  fetchReportExports,
  runReport,
  type ReportCatalogItem,
  type ReportExport,
  type ReportExportStatus,
} from '@/api/reports'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useBranchFilter } from '@/hooks/useBranchFilter'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { ReportExportActions } from '@/components/reports/ReportExportActions'
import { SimpleBarChart } from '@/components/charts/SimpleBarChart'
import { formatDate, formatMoney, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'
import type { ExportColumn } from '@/lib/exportReport'

type MetricRow = {
  id: string
  metric: string
  value: string
  raw: string | number
}

const REPORT_ICONS: Record<string, typeof Users> = {
  members_summary: Users,
  memberships_summary: UserRound,
  attendance_summary: Activity,
  sales_summary: ShoppingCart,
  expenses_summary: Wallet,
  invoices_summary: Receipt,
}

function daysAgoIso(days: number) {
  const d = new Date()
  d.setDate(d.getDate() - days)
  return d.toISOString().slice(0, 10)
}

function todayIso() {
  return new Date().toISOString().slice(0, 10)
}

function humanize(key: string) {
  return key
    .replace(/[._]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/\b\w/g, (c) => c.toUpperCase())
}

function toNum(value: unknown) {
  const n = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(n) ? n : 0
}

function formatMetricValue(
  key: string,
  value: unknown,
  currency: string,
): { display: string; raw: string | number } {
  if (value == null) return { display: '—', raw: '' }
  if (typeof value === 'object') return { display: '—', raw: '' }

  const lower = key.toLowerCase()
  const isMoney =
    lower.includes('amount') ||
    lower === 'grand_total' ||
    lower.endsWith('_amount') ||
    lower.includes('revenue') ||
    (lower.includes('total') && (lower.includes('grand') || lower.includes('money')))

  if (isMoney && (typeof value === 'number' || typeof value === 'string')) {
    const n = toNum(value)
    return { display: formatMoney(n, currency), raw: n }
  }

  if (typeof value === 'number' || (typeof value === 'string' && value !== '' && !Number.isNaN(Number(value)))) {
    const n = toNum(value)
    if (Number.isInteger(n) || lower.includes('count') || lower === 'total' || lower.includes('valid')) {
      return { display: formatNumber(n), raw: n }
    }
    return { display: formatMoney(n, currency), raw: n }
  }

  return { display: String(value), raw: String(value) }
}

function flattenSummary(
  summary: Record<string, unknown> | undefined,
  currency: string,
  prefix = '',
): MetricRow[] {
  if (!summary) return []
  const rows: MetricRow[] = []

  for (const [key, value] of Object.entries(summary)) {
    const path = prefix ? `${prefix}.${key}` : key
    const label = humanize(path)

    if (value && typeof value === 'object' && !Array.isArray(value)) {
      const nested = value as Record<string, unknown>
      const keys = Object.keys(nested)
      const looksLikeStatusBucket =
        keys.includes('count') || keys.includes('total_amount') || typeof nested.count === 'number'

      if (looksLikeStatusBucket && ('count' in nested || 'total_amount' in nested)) {
        const count = nested.count != null ? formatNumber(toNum(nested.count)) : null
        const amount =
          nested.total_amount != null ? formatMoney(toNum(nested.total_amount), currency) : null
        const parts = [count != null ? `${count} items` : null, amount].filter(Boolean)
        rows.push({
          id: path,
          metric: label,
          value: parts.join(' · ') || '—',
          raw: toNum(nested.total_amount ?? nested.count ?? 0),
        })
      } else {
        rows.push(...flattenSummary(nested, currency, path))
      }
    } else {
      const formatted = formatMetricValue(key, value, currency)
      rows.push({
        id: path,
        metric: label,
        value: formatted.display,
        raw: formatted.raw,
      })
    }
  }

  return rows
}

function statusTone(
  status: ReportExportStatus,
): 'neutral' | 'accent' | 'success' | 'danger' | 'warning' {
  switch (status) {
    case 'completed':
      return 'success'
    case 'failed':
      return 'danger'
    case 'processing':
      return 'accent'
    case 'queued':
      return 'warning'
    default:
      return 'neutral'
  }
}

function filterLabel(from: string, to: string, branchName?: string) {
  const range =
    from && to ? `${from} → ${to}` : from ? `From ${from}` : to ? `Until ${to}` : 'All dates'
  return branchName ? `${range} · ${branchName}` : range
}

export function ReportsPage() {
  const { branches, branchId, tenant, hasPermission } = useAuth()
  const { showSuccess } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('reports.view')
  const canServerExport = hasPermission('reports.export')
  const canExportFiles = canServerExport || canView
  const currency = tenant?.base_currency || 'INR'

  const [from, setFrom] = useState(daysAgoIso(30))
  const [to, setTo] = useState(todayIso())
  const [branchFilter, setBranchFilter] = useBranchFilter()
  const [applied, setApplied] = useState({
    from: daysAgoIso(30),
    to: todayIso(),
    branch_id: (branchId ?? '') as number | '',
  })

  useEffect(() => {
    setApplied((current) => ({
      ...current,
      branch_id: branchId ?? '',
    }))
  }, [branchId])
  const [selectedKey, setSelectedKey] = useState<string | null>(null)
  const [exportPage, setExportPage] = useState(1)
  const [error, setError] = useState<string | null>(null)

  const errMsg = (err: unknown, fallback: string) => {
    if (err instanceof ApiError) return err.message
    if (err instanceof Error && err.message) return err.message
    return fallback
  }

  const catalogQuery = useQuery({
    queryKey: ['reports', 'catalog'],
    queryFn: fetchReportCatalog,
    enabled: canView,
  })

  const runQuery = useQuery({
    queryKey: ['reports', 'run', selectedKey, applied],
    queryFn: () =>
      runReport(selectedKey!, {
        from: applied.from || undefined,
        to: applied.to || undefined,
        branch_id: applied.branch_id || undefined,
      }),
    enabled: canView && Boolean(selectedKey),
  })

  const exportsQuery = useQuery({
    queryKey: ['reports', 'exports', exportPage],
    queryFn: () => fetchReportExports({ page: exportPage, per_page: DEFAULT_PAGE_SIZE }),
    enabled: canServerExport,
  })

  const serverExportMutation = useMutation({
    mutationFn: () =>
      createReportExport({
        report_key: selectedKey!,
        filters: {
          from: applied.from || null,
          to: applied.to || null,
          branch_id: typeof applied.branch_id === 'number' ? applied.branch_id : null,
        },
      }),
    onSuccess: (row) => {
      setError(null)
      showSuccess(`Server CSV export ${row.status}: #${row.id}`)
      void queryClient.invalidateQueries({ queryKey: ['reports', 'exports'] })
    },
    onError: (err) => setError(errMsg(err, 'Unable to create server export.')),
  })

  const catalog = catalogQuery.data ?? []

  useEffect(() => {
    if (!selectedKey && catalog.length > 0) {
      setSelectedKey(catalog[0].key)
    }
  }, [catalog, selectedKey])

  const selected = catalog.find((item) => item.key === selectedKey) ?? null
  const branchName =
    typeof applied.branch_id === 'number'
      ? branches.find((b) => b.id === applied.branch_id)?.name
      : undefined

  const metricRows = useMemo(
    () => flattenSummary(runQuery.data?.summary as Record<string, unknown> | undefined, currency),
    [runQuery.data?.summary, currency],
  )

  const chartPoints = useMemo(() => {
    const summary = runQuery.data?.summary as Record<string, unknown> | undefined
    if (!summary) return []

    const byStatus = summary.by_status
    if (byStatus && typeof byStatus === 'object') {
      return Object.entries(byStatus as Record<string, unknown>).map(([key, value]) => {
        if (value && typeof value === 'object') {
          const bucket = value as Record<string, unknown>
          return {
            label: humanize(key),
            value: toNum(bucket.count ?? bucket.total_amount ?? 0),
          }
        }
        return { label: humanize(key), value: toNum(value) }
      })
    }

    return metricRows
      .filter((row) => typeof row.raw === 'number' && row.raw > 0)
      .slice(0, 8)
      .map((row) => ({ label: row.metric.split(' · ').pop() || row.metric, value: toNum(row.raw) }))
  }, [runQuery.data?.summary, metricRows])

  const headlineStats = useMemo(() => {
    const summary = (runQuery.data?.summary ?? {}) as Record<string, unknown>
    const stats: Array<{ label: string; value: string }> = []

    if (summary.total != null) {
      stats.push({ label: 'Total', value: formatNumber(toNum(summary.total)) })
    }
    if (summary.total_count != null) {
      stats.push({ label: 'Records', value: formatNumber(toNum(summary.total_count)) })
    }
    if (summary.completed_count != null) {
      stats.push({ label: 'Completed', value: formatNumber(toNum(summary.completed_count)) })
    }
    if (summary.valid != null) {
      stats.push({ label: 'Valid', value: formatNumber(toNum(summary.valid)) })
    }
    if (summary.voided != null) {
      stats.push({ label: 'Voided', value: formatNumber(toNum(summary.voided)) })
    }
    if (summary.grand_total != null) {
      stats.push({ label: 'Grand total', value: formatMoney(toNum(summary.grand_total), currency) })
    }
    if (summary.total_amount != null) {
      stats.push({ label: 'Amount', value: formatMoney(toNum(summary.total_amount), currency) })
    }

    if (stats.length === 0 && metricRows.length) {
      return metricRows.slice(0, 4).map((row) => ({ label: row.metric, value: row.value }))
    }
    return stats.slice(0, 4)
  }, [runQuery.data?.summary, metricRows, currency])

  const exportColumns: ExportColumn<MetricRow>[] = [
    { key: 'metric', header: 'Metric', value: (r) => r.metric },
    { key: 'value', header: 'Value', value: (r) => r.value },
  ]

  const metricColumns: Column<MetricRow>[] = [
    {
      key: 'metric',
      header: 'Metric',
      cell: (r) => <span className="font-medium text-ink">{r.metric}</span>,
    },
    {
      key: 'value',
      header: 'Value',
      className: 'text-right font-semibold tabular-nums',
      cell: (r) => r.value,
    },
  ]

  const historyColumns: Column<ReportExport>[] = [
    {
      key: 'id',
      header: 'ID',
      cell: (r) => <span className="tabular-nums text-muted">#{r.id}</span>,
    },
    {
      key: 'report',
      header: 'Report',
      cell: (r) => (
        <div>
          <div className="font-medium">{catalog.find((c) => c.key === r.report_key)?.name ?? humanize(r.report_key)}</div>
          <div className="text-xs text-muted">{r.report_key}</div>
        </div>
      ),
    },
    {
      key: 'filters',
      header: 'Filters',
      cell: (r) => {
        const b =
          r.filters?.branch_id != null
            ? branches.find((x) => x.id === r.filters.branch_id)?.name
            : undefined
        return (
          <span className="text-sm text-muted">
            {filterLabel(r.filters?.from ?? '', r.filters?.to ?? '', b)}
          </span>
        )
      },
    },
    {
      key: 'status',
      header: 'Status',
      cell: (r) => <Badge tone={statusTone(r.status)}>{r.status}</Badge>,
    },
    {
      key: 'requester',
      header: 'Requested by',
      cell: (r) => r.requester?.name ?? '—',
    },
    {
      key: 'finished',
      header: 'Finished',
      cell: (r) => formatDate(r.finished_at ?? r.created_at),
    },
  ]

  const applyFilters = () => {
    setApplied({
      from,
      to,
      branch_id: branchFilter,
    })
    setError(null)
  }

  const selectReport = (item: ReportCatalogItem) => {
    setSelectedKey(item.key)
    setError(null)
  }

  if (!canView) {
    return (
      <div className="space-y-4">
        <PageHeader title="Reports" description="Analytics and exports." />
        <Alert tone="info">
          Your role needs <code>reports.view</code> to open analytics.
        </Alert>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Reports"
        description="Run gym analytics for a date range and branch, then export PDF or Excel."
        actions={
          <Button
            variant="secondary"
            size="sm"
            onClick={() => {
              void catalogQuery.refetch()
              if (selectedKey) void runQuery.refetch()
              if (canServerExport) void exportsQuery.refetch()
            }}
          >
            <RefreshCw className="h-4 w-4" />
            Refresh
          </Button>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}
      {catalogQuery.isError ? (
        <Alert tone="danger">{errMsg(catalogQuery.error, 'Unable to load report catalog.')}</Alert>
      ) : null}

      <Card className="space-y-4">
        <div>
          <CardTitle>Filters</CardTitle>
          <CardDescription>Applied to every report you run or export.</CardDescription>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-1.5">
            <Label htmlFor="report-from">From</Label>
            <Input
              id="report-from"
              type="date"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="report-to">To</Label>
            <Input
              id="report-to"
              type="date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="report-branch">Branch</Label>
            <Select
              id="report-branch"
              value={branchFilter === '' ? '' : String(branchFilter)}
              onChange={(e) =>
                setBranchFilter(e.target.value ? Number(e.target.value) : '')
              }
            >
              <option value="">All branches</option>
              {branches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </Select>
          </div>
          <div className="flex items-end">
            <Button className="w-full sm:w-auto" onClick={applyFilters}>
              Apply filters
            </Button>
          </div>
        </div>
        <p className="text-xs text-muted">
          Active range: {filterLabel(applied.from, applied.to, branchName)}
        </p>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {catalogQuery.isLoading
          ? Array.from({ length: 6 }).map((_, i) => (
              <Card key={i} className="h-28 animate-pulse bg-surface-2" />
            ))
          : catalog.map((item) => {
              const Icon = REPORT_ICONS[item.key] ?? BarChart3
              const active = selectedKey === item.key
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => selectReport(item)}
                  className={cn(
                    'rounded-xl border p-4 text-left transition',
                    'hover:border-accent/40 hover:bg-surface-2/60',
                    active
                      ? 'border-accent bg-accent/5 shadow-sm ring-1 ring-accent/20'
                      : 'border-border bg-surface',
                  )}
                >
                  <div className="flex items-start gap-3">
                    <span
                      className={cn(
                        'inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg',
                        active ? 'bg-accent text-white' : 'bg-surface-2 text-ink',
                      )}
                    >
                      <Icon className="h-5 w-5" />
                    </span>
                    <div className="min-w-0">
                      <div className="font-semibold text-ink">{item.name}</div>
                      <p className="mt-1 text-sm text-muted line-clamp-2">
                        {item.description || humanize(item.key)}
                      </p>
                    </div>
                  </div>
                </button>
              )
            })}
      </div>

      {!selectedKey ? (
        <Card className="flex flex-col items-center justify-center gap-2 py-16 text-center">
          <BarChart3 className="h-10 w-10 text-muted" />
          <CardTitle>Select a report</CardTitle>
          <CardDescription>
            Choose a catalog item above to run analytics for the active filters.
          </CardDescription>
        </Card>
      ) : (
        <Card className="space-y-5">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <CardTitle>{selected?.name ?? humanize(selectedKey)}</CardTitle>
                <Badge tone="accent">{selectedKey}</Badge>
              </div>
              <CardDescription className="mt-1">
                {selected?.description || 'Summary analytics for the selected period.'}
                {' · '}
                {filterLabel(applied.from, applied.to, branchName)}
              </CardDescription>
            </div>
            <div className="flex flex-col items-stretch gap-2 sm:items-end">
              {canExportFiles ? (
                <ReportExportActions
                  reportKey={selectedKey}
                  reportName={selected?.name ?? humanize(selectedKey)}
                  columns={exportColumns}
                  rows={metricRows}
                  subtitle={filterLabel(applied.from, applied.to, branchName)}
                  disabled={runQuery.isLoading || metricRows.length === 0}
                />
              ) : (
                <Badge tone="neutral">Export needs reports.export</Badge>
              )}
              {canServerExport ? (
                <Button
                  size="sm"
                  variant="secondary"
                  disabled={!selectedKey || serverExportMutation.isPending}
                  onClick={() => serverExportMutation.mutate()}
                >
                  <Server className="h-4 w-4" />
                  {serverExportMutation.isPending ? 'Saving…' : 'Save CSV on server'}
                </Button>
              ) : null}
            </div>
          </div>

          {runQuery.isLoading ? (
            <div className="flex items-center justify-center gap-2 py-16 text-muted">
              <Spinner />
              Running report…
            </div>
          ) : runQuery.isError ? (
            <Alert tone="danger">{errMsg(runQuery.error, 'Unable to run this report.')}</Alert>
          ) : (
            <>
              {headlineStats.length ? (
                <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                  {headlineStats.map((stat) => (
                    <div
                      key={stat.label}
                      className="rounded-xl border border-border bg-surface-2/50 px-4 py-3"
                    >
                      <div className="text-xs font-medium uppercase tracking-wide text-muted">
                        {stat.label}
                      </div>
                      <div className="mt-1 text-2xl font-semibold tabular-nums text-ink">
                        {stat.value}
                      </div>
                    </div>
                  ))}
                </div>
              ) : null}

              <div className="grid gap-5 xl:grid-cols-5">
                <div className="space-y-3 xl:col-span-3">
                  <div className="flex items-center gap-2">
                    <FileSpreadsheet className="h-4 w-4 text-muted" />
                    <h3 className="text-sm font-semibold text-ink">Breakdown</h3>
                  </div>
                  <DataTable
                    columns={metricColumns}
                    rows={metricRows}
                    rowKey={(r) => r.id}
                    emptyTitle="No metrics"
                    emptyDescription="This report returned an empty summary for the selected filters."
                  />
                </div>
                <div className="xl:col-span-2">
                  {chartPoints.length ? (
                    <SimpleBarChart title="Distribution" data={chartPoints} />
                  ) : (
                    <p className="rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted">
                      No chartable values for this summary.
                    </p>
                  )}
                </div>
              </div>
            </>
          )}
        </Card>
      )}

      {canServerExport ? (
        <Card className="space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <CardTitle>Server export history</CardTitle>
              <CardDescription>
                CSV files generated on the server when you use “Save CSV on server”.
              </CardDescription>
            </div>
            <Badge tone="neutral">{exportsQuery.data?.meta.total ?? 0} total</Badge>
          </div>
          {exportsQuery.isLoading ? (
            <div className="flex justify-center py-10">
              <Spinner />
            </div>
          ) : exportsQuery.isError ? (
            <Alert tone="danger">{errMsg(exportsQuery.error, 'Unable to load export history.')}</Alert>
          ) : (
            <>
              <DataTable
                columns={historyColumns}
                rows={exportsQuery.data?.data ?? []}
                rowKey={(r) => String(r.id)}
                emptyTitle="No exports yet"
                emptyDescription="Run a report and save a CSV to build history here."
              />
              <Pagination meta={exportsQuery.data?.meta} onPageChange={setExportPage} />
            </>
          )}
        </Card>
      ) : null}
    </div>
  )
}
