import { Link } from 'react-router-dom'
import { Download, FileSpreadsheet, RefreshCw, Server } from 'lucide-react'
import { Alert } from '@/components/ui/Alert'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { PageHeader } from '@/components/ui/PageHeader'
import { Select } from '@/components/ui/Select'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { SimpleBarChart } from '@/components/charts/SimpleBarChart'
import { ReportExportActions } from '@/components/reports/ReportExportActions'
import type { TenantReportDefinition } from '@/config/reportDefinitions'
import { useTenantReport, type ReportTableRow } from '@/pages/reports/useTenantReport'

export function TenantReportDashboard({ definition }: { definition: TenantReportDefinition }) {
  const report = useTenantReport(definition)
  const Icon = definition.icon

  if (!report.canView) {
    return (
      <div className="animate-fade-up space-y-4">
        <PageHeader title={definition.name} description={definition.description} />
        <Alert tone="danger">You do not have permission to view reports.</Alert>
      </div>
    )
  }

  const tableColumns: Column<ReportTableRow>[] = report.displayColumns.map((col) => ({
    key: col.key,
    header: col.label,
    cell: (row) => (
      <span className="tabular-nums text-ink">{report.formatCell(col.key, row[col.key], report.currency)}</span>
    ),
  }))

  return (
    <div className="animate-fade-up space-y-6">
      <PageHeader
        title={definition.name}
        description={definition.description}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="accent">{definition.category}</Badge>
            {report.canExportFiles ? (
              <ReportExportActions
                reportKey={definition.key}
                reportName={definition.name}
                columns={report.exportColumns}
                rows={report.tableRows}
                subtitle={report.subtitle}
                disabled={report.runQuery.isLoading}
              />
            ) : null}
            {report.canServerExport ? (
              <Button
                size="sm"
                variant="secondary"
                loading={report.serverExportMutation.isPending}
                disabled={report.runQuery.isLoading}
                onClick={() => report.serverExportMutation.mutate()}
              >
                <Server className="h-4 w-4" />
                Server CSV
              </Button>
            ) : null}
          </div>
        }
      />

      <Card>
        <div className="flex flex-wrap items-end gap-3">
          <div className="min-w-[140px] flex-1 space-y-1.5">
            <Label htmlFor="report-from">From</Label>
            <Input
              id="report-from"
              type="date"
              value={report.from}
              onChange={(e) => report.setFrom(e.target.value)}
            />
          </div>
          <div className="min-w-[140px] flex-1 space-y-1.5">
            <Label htmlFor="report-to">To</Label>
            <Input
              id="report-to"
              type="date"
              value={report.to}
              onChange={(e) => report.setTo(e.target.value)}
            />
          </div>
          <div className="min-w-[180px] flex-[1.2] space-y-1.5">
            <Label htmlFor="report-branch">Branch</Label>
            <Select
              id="report-branch"
              value={report.branchFilter === '' ? '' : String(report.branchFilter)}
              onChange={(e) =>
                report.setBranchFilter(e.target.value ? Number(e.target.value) : '')
              }
            >
              <option value="">All branches</option>
              {report.branches.map((branch) => (
                <option key={branch.id} value={branch.id}>
                  {branch.name}
                </option>
              ))}
            </Select>
          </div>
          <Button onClick={report.applyFilters}>
            <RefreshCw className="h-4 w-4" />
            Run report
          </Button>
          <Link
            to="/reports/exports"
            className="inline-flex h-11 items-center gap-2 rounded-xl border border-white/15 bg-white/10 px-4 text-sm font-semibold text-ink transition hover:bg-white/16"
          >
            <Download className="h-4 w-4" />
            Export history
          </Link>
        </div>
        <p className="mt-3 text-xs text-muted">{report.subtitle}</p>
      </Card>

      {report.errMsg ? <Alert tone="danger">{report.errMsg}</Alert> : null}

      {report.runQuery.isLoading ? (
        <div className="flex justify-center py-16">
          <Spinner label="Generating report…" />
        </div>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {report.kpis.map((kpi) => (
              <Card key={kpi.label} className="relative overflow-hidden">
                <div className="absolute top-3 right-3 rounded-lg bg-accent/15 p-2 text-accent">
                  <Icon className="h-4 w-4" />
                </div>
                <p className="text-xs font-semibold tracking-wide text-muted uppercase">{kpi.label}</p>
                <p className="mt-2 font-display text-2xl font-bold text-ink tabular-nums">{kpi.value}</p>
              </Card>
            ))}
            {report.kpis.length === 0 ? (
              <Card className="sm:col-span-2 xl:col-span-4">
                <CardTitle>No KPI data</CardTitle>
                <CardDescription>Try adjusting the date range or branch filter.</CardDescription>
              </Card>
            ) : null}
          </div>

          <div className="grid gap-4 xl:grid-cols-5">
            <div className="xl:col-span-2">
              {report.chartPoints.length > 0 ? (
                <SimpleBarChart
                  title="Trend / breakdown"
                  description="Visual summary for the selected filters."
                  data={report.chartPoints}
                />
              ) : (
                <Card className="h-full">
                  <CardTitle>Chart</CardTitle>
                  <CardDescription className="mt-3">No chart series for this period.</CardDescription>
                </Card>
              )}
            </div>
            <Card className="xl:col-span-3">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <CardTitle>Detail table</CardTitle>
                  <CardDescription>
                    {report.tableRows.length} row(s) · Export Excel/PDF from the header actions
                  </CardDescription>
                </div>
                <Badge tone="neutral">
                  <FileSpreadsheet className="mr-1 inline h-3.5 w-3.5" />
                  Export ready
                </Badge>
              </div>
              {report.tableRows.length === 0 ? (
                <p className="py-10 text-center text-sm text-muted">No detail rows for these filters.</p>
              ) : (
                <DataTable
                  columns={tableColumns}
                  rows={report.tableRows}
                  rowKey={(r) => r.id}
                />
              )}
            </Card>
          </div>
        </>
      )}
    </div>
  )
}
