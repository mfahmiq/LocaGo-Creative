import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { createReportExport, runReport, type ReportRunParams } from '@/api/reports'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useBranchFilter } from '@/hooks/useBranchFilter'
import { useFeedback } from '@/feedback/FeedbackProvider'
import type { ExportColumn } from '@/lib/exportReport'
import { formatMoney, formatNumber } from '@/lib/format'
import type { TenantReportDefinition } from '@/config/reportDefinitions'

export type ReportTableRow = Record<string, string | number | null | undefined> & { id: string }

export type ReportKpi = { label: string; value: string }

function daysAgoIso(days: number) {
  const d = new Date()
  d.setDate(d.getDate() - days)
  return d.toISOString().slice(0, 10)
}

function todayIso() {
  return new Date().toISOString().slice(0, 10)
}

function toNum(value: unknown) {
  const n = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(n) ? n : 0
}

function humanize(key: string) {
  return key
    .replace(/[._]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/\b\w/g, (c) => c.toUpperCase())
}

function isMoneyKey(key: string) {
  const lower = key.toLowerCase()
  return (
    lower.includes('amount') ||
    lower.includes('total') ||
    lower.includes('revenue') ||
    lower.includes('collected') ||
    lower.includes('billed') ||
    lower.includes('outstanding') ||
    lower.includes('sales') ||
    lower.includes('value') ||
    lower.includes('price') ||
    lower.includes('ticket') ||
    lower.includes('position')
  )
}

function formatCell(key: string, value: unknown, currency: string): string {
  if (value == null || value === '') return '—'
  if (typeof value === 'object') return JSON.stringify(value)
  const lower = key.toLowerCase()
  if (typeof value === 'number' || (typeof value === 'string' && value !== '' && !Number.isNaN(Number(value)))) {
    const n = toNum(value)
    if (isMoneyKey(key) && !lower.includes('count') && !lower.includes('rate') && !lower.includes('days')) {
      return formatMoney(n, currency)
    }
    if (lower.includes('rate') || lower.includes('percent') || lower.includes('completion')) {
      return `${formatNumber(n)}%`
    }
    if (Number.isInteger(n) || lower.includes('count') || lower.includes('qty') || lower.includes('members')) {
      return formatNumber(n)
    }
    if (isMoneyKey(key)) return formatMoney(n, currency)
    return formatNumber(n)
  }
  return String(value)
}

function pickKpis(summary: Record<string, unknown>, currency: string): ReportKpi[] {
  const preferred = [
    'total_memberships',
    'active',
    'expiring_in_30_days',
    'invoice_count',
    'billed_total',
    'collected_total',
    'outstanding_total',
    'net_position',
    'total',
    'valid',
    'valid_rate',
    'trainer_count',
    'completed_sessions',
    'branch_count',
    'total_active_members',
    'total_assets',
    'in_service',
    'warranty_expiring_60_days',
    'product_count',
    'low_stock_lines',
    'inventory_value',
    'renewal_requests',
    'completed_renewals',
    'total_count',
    'completed_count',
    'grand_total',
    'average_ticket',
    'total_members',
    'new_members',
    'paying_members',
    'unique_visitors',
  ]

  const kpis: ReportKpi[] = []
  for (const key of preferred) {
    if (!(key in summary)) continue
    const value = summary[key]
    if (value == null || typeof value === 'object') continue
    kpis.push({ label: humanize(key), value: formatCell(key, value, currency) })
    if (kpis.length >= 4) break
  }

  if (kpis.length > 0) return kpis

  for (const [key, value] of Object.entries(summary)) {
    if (value == null || typeof value === 'object') continue
    kpis.push({ label: humanize(key), value: formatCell(key, value, currency) })
    if (kpis.length >= 4) break
  }
  return kpis
}

export function useTenantReport(definition: TenantReportDefinition) {
  const { branches, branchId, tenant, hasPermission } = useAuth()
  const { showSuccess } = useFeedback()
  const queryClient = useQueryClient()
  const currency = tenant?.base_currency || 'INR'
  const canView = hasPermission('reports.view')
  const canServerExport = hasPermission('reports.export')
  const canExportFiles = canServerExport || canView

  const [from, setFrom] = useState(daysAgoIso(30))
  const [to, setTo] = useState(todayIso())
  const [branchFilter, setBranchFilter] = useBranchFilter()
  const [applied, setApplied] = useState<ReportRunParams>({
    from: daysAgoIso(30),
    to: todayIso(),
    branch_id: (branchId ?? '') as number | '',
  })
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    setApplied((current) => ({
      ...current,
      branch_id: branchId ?? '',
    }))
  }, [branchId])

  const runQuery = useQuery({
    queryKey: ['reports', 'run', definition.key, applied],
    queryFn: () =>
      runReport(definition.key, {
        from: applied.from || undefined,
        to: applied.to || undefined,
        branch_id: applied.branch_id || undefined,
      }),
    enabled: canView,
  })

  const serverExportMutation = useMutation({
    mutationFn: () =>
      createReportExport({
        report_key: definition.key,
        filters: {
          from: applied.from || null,
          to: applied.to || null,
          branch_id: typeof applied.branch_id === 'number' ? applied.branch_id : null,
        },
      }),
    onSuccess: (row) => {
      setError(null)
      showSuccess(`Server CSV export ${row.status}: #${row.id}`)
      void queryClient.invalidateQueries({ queryKey: ['reports', 'exports'] })
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to create server export.')
    },
  })

  const summary = (runQuery.data?.summary ?? {}) as Record<string, unknown>

  const kpis = useMemo(() => pickKpis(summary, currency), [summary, currency])

  const chartPoints = useMemo(() => {
    const series = summary.series
    if (Array.isArray(series)) {
      return series
        .map((item) => {
          if (!item || typeof item !== 'object') return null
          const row = item as Record<string, unknown>
          return {
            label: String(row.label ?? ''),
            value: toNum(row.value),
          }
        })
        .filter((p): p is { label: string; value: number } => Boolean(p?.label))
        .slice(0, 14)
    }

    const byStatus = summary.by_status
    if (byStatus && typeof byStatus === 'object') {
      return Object.entries(byStatus as Record<string, unknown>).map(([key, value]) => {
        if (value && typeof value === 'object') {
          const bucket = value as Record<string, unknown>
          return { label: humanize(key), value: toNum(bucket.count ?? bucket.total_amount ?? 0) }
        }
        return { label: humanize(key), value: toNum(value) }
      })
    }

    return []
  }, [summary])

  const columnsMeta = useMemo(() => {
    const cols = summary.columns
    if (Array.isArray(cols) && cols.length > 0) {
      return cols
        .map((col) => {
          if (!col || typeof col !== 'object') return null
          const c = col as Record<string, unknown>
          const key = String(c.key ?? '')
          if (!key) return null
          return { key, label: String(c.label ?? humanize(key)) }
        })
        .filter((c): c is { key: string; label: string } => Boolean(c))
    }
    return []
  }, [summary])

  const tableRows: ReportTableRow[] = useMemo(() => {
    const rows = summary.rows
    if (!Array.isArray(rows)) return []
    return rows.map((row, index) => {
      const source = row && typeof row === 'object' ? (row as Record<string, unknown>) : {}
      const next: ReportTableRow = { id: String(index) }
      for (const [key, value] of Object.entries(source)) {
        if (value == null || typeof value === 'string' || typeof value === 'number') {
          next[key] = value as string | number | null | undefined
        } else {
          next[key] = String(value)
        }
      }
      return next
    })
  }, [summary])

  const displayColumns = useMemo(() => {
    if (columnsMeta.length > 0) return columnsMeta
    if (tableRows.length === 0) return []
    return Object.keys(tableRows[0])
      .filter((k) => k !== 'id')
      .map((key) => ({ key, label: humanize(key) }))
  }, [columnsMeta, tableRows])

  const exportColumns: ExportColumn<ReportTableRow>[] = useMemo(
    () =>
      displayColumns.map((col) => ({
        key: col.key,
        header: col.label,
        value: (row) => formatCell(col.key, row[col.key], currency),
      })),
    [displayColumns, currency],
  )

  const branchName =
    typeof applied.branch_id === 'number'
      ? branches.find((b) => b.id === applied.branch_id)?.name
      : undefined

  const subtitle = [
    applied.from && applied.to ? `${applied.from} → ${applied.to}` : null,
    branchName ?? 'All branches',
  ]
    .filter(Boolean)
    .join(' · ')

  const applyFilters = () => {
    setError(null)
    setApplied({
      from,
      to,
      branch_id: branchFilter,
    })
  }

  const errMsg =
    error ||
    (runQuery.error instanceof ApiError
      ? runQuery.error.message
      : runQuery.error
        ? 'Unable to load report.'
        : null)

  return {
    canView,
    canServerExport,
    canExportFiles,
    currency,
    branches,
    from,
    setFrom,
    to,
    setTo,
    branchFilter,
    setBranchFilter,
    applied,
    applyFilters,
    runQuery,
    kpis,
    chartPoints,
    tableRows,
    displayColumns,
    exportColumns,
    subtitle,
    errMsg,
    serverExportMutation,
    formatCell,
  }
}
