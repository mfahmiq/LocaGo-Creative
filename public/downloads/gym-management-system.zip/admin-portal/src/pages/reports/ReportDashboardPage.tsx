import { Navigate, useParams } from 'react-router-dom'
import { findReportBySlug } from '@/config/reportDefinitions'
import { TenantReportDashboard } from '@/pages/reports/TenantReportDashboard'
import { Alert } from '@/components/ui/Alert'
import { PageHeader } from '@/components/ui/PageHeader'

export function ReportDashboardPage() {
  const { reportSlug } = useParams<{ reportSlug: string }>()
  const definition = findReportBySlug(reportSlug)

  if (!reportSlug) {
    return <Navigate to="/reports" replace />
  }

  if (!definition) {
    return (
      <div className="animate-fade-up space-y-4">
        <PageHeader title="Report not found" description="This report is not in the catalog." />
        <Alert tone="danger">Unknown report “{reportSlug}”.</Alert>
      </div>
    )
  }

  return <TenantReportDashboard definition={definition} />
}
