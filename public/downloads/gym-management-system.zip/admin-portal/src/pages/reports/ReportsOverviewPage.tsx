import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import {
  ArrowRight,
  Download,
  FileBarChart2,
  FileSpreadsheet,
  FileText,
  RefreshCw,
  Search,
  ShieldCheck,
} from 'lucide-react'
import { fetchReportCatalog, runReport } from '@/api/reports'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { Alert } from '@/components/ui/Alert'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { PageHeader } from '@/components/ui/PageHeader'
import { Spinner } from '@/components/ui/Spinner'
import { ReportExportActions } from '@/components/reports/ReportExportActions'
import { TENANT_REPORTS, type TenantReportDefinition } from '@/config/reportDefinitions'
import { formatMoney, formatNumber } from '@/lib/format'
import {
  exportRowsToExcel,
  exportRowsToPdf,
  type ExportColumn,
} from '@/lib/exportReport'
import { cn } from '@/lib/cn'

type CatalogExportRow = {
  id: string
  name: string
  category: string
  description: string
  path: string
}

const CATEGORY_ORDER = ['Membership', 'Finance', 'Operations', 'Performance', 'Assets', 'Analytics']

function daysAgoIso(days: number) {
  const d = new Date()
  d.setDate(d.getDate() - days)
  return d.toISOString().slice(0, 10)
}

function todayIso() {
  return new Date().toISOString().slice(0, 10)
}

function toNum(value: unknown) {
  const n = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(n) ? n : 0
}

export function ReportsOverviewPage() {
  const { hasPermission, tenant, branchId, branches } = useAuth()
  const { showSuccess } = useFeedback()
  const canView = hasPermission('reports.view')
  const canExport = hasPermission('reports.export')
  const currency = tenant?.base_currency || 'INR'

  const [search, setSearch] = useState('')
  const [category, setCategory] = useState<string>('All')

  const catalogQuery = useQuery({
    queryKey: ['reports', 'catalog'],
    queryFn: fetchReportCatalog,
    enabled: canView,
  })

  const snapshotFilters = useMemo(
    () => ({
      from: daysAgoIso(30),
      to: todayIso(),
      branch_id: branchId ?? undefined,
    }),
    [branchId],
  )

  const membershipSnap = useQuery({
    queryKey: ['reports', 'overview', 'membership_report', snapshotFilters],
    queryFn: () => runReport('membership_report', snapshotFilters),
    enabled: canView,
  })

  const revenueSnap = useQuery({
    queryKey: ['reports', 'overview', 'revenue_report', snapshotFilters],
    queryFn: () => runReport('revenue_report', snapshotFilters),
    enabled: canView,
  })

  const attendanceSnap = useQuery({
    queryKey: ['reports', 'overview', 'attendance_report', snapshotFilters],
    queryFn: () => runReport('attendance_report', snapshotFilters),
    enabled: canView,
  })

  const salesSnap = useQuery({
    queryKey: ['reports', 'overview', 'sales_report', snapshotFilters],
    queryFn: () => runReport('sales_report', snapshotFilters),
    enabled: canView,
  })

  const apiKeys = useMemo(
    () => new Set((catalogQuery.data ?? []).map((item) => item.key)),
    [catalogQuery.data],
  )

  const categories = useMemo(() => {
    const present = [...new Set(TENANT_REPORTS.map((r) => r.category))]
    return [
      'All',
      ...CATEGORY_ORDER.filter((c) => present.includes(c)),
      ...present.filter((c) => !CATEGORY_ORDER.includes(c)),
    ]
  }, [])

  const filteredReports = useMemo(() => {
    const q = search.trim().toLowerCase()
    return TENANT_REPORTS.filter((report) => {
      if (category !== 'All' && report.category !== category) return false
      if (!q) return true
      return (
        report.name.toLowerCase().includes(q) ||
        report.description.toLowerCase().includes(q) ||
        report.category.toLowerCase().includes(q)
      )
    })
  }, [category, search])

  const grouped = useMemo(() => {
    const map = new Map<string, TenantReportDefinition[]>()
    for (const report of filteredReports) {
      const list = map.get(report.category) ?? []
      list.push(report)
      map.set(report.category, list)
    }
    const ordered = CATEGORY_ORDER.filter((c) => map.has(c))
    const extras = [...map.keys()].filter((c) => !CATEGORY_ORDER.includes(c))
    return [...ordered, ...extras].map((c) => ({ category: c, reports: map.get(c)! }))
  }, [filteredReports])

  const branchLabel =
    branchId != null ? branches.find((b) => b.id === branchId)?.name ?? `Branch #${branchId}` : 'All branches'

  const snapshotLoading =
    membershipSnap.isLoading || revenueSnap.isLoading || attendanceSnap.isLoading || salesSnap.isLoading

  const kpis = [
    {
      label: 'Active memberships',
      value: formatNumber(toNum(membershipSnap.data?.summary?.active)),
      hint: `${formatNumber(toNum(membershipSnap.data?.summary?.expiring_in_30_days))} expiring ≤ 30 days`,
      to: '/reports/membership',
    },
    {
      label: 'Collected (30d)',
      value: formatMoney(toNum(revenueSnap.data?.summary?.collected_total), currency),
      hint: `${formatMoney(toNum(revenueSnap.data?.summary?.outstanding_total), currency)} outstanding`,
      to: '/reports/revenue',
    },
    {
      label: 'Check-ins (30d)',
      value: formatNumber(toNum(attendanceSnap.data?.summary?.total)),
      hint: `${formatNumber(toNum(attendanceSnap.data?.summary?.valid_rate))}% valid rate`,
      to: '/reports/attendance',
    },
    {
      label: 'POS sales (30d)',
      value: formatMoney(toNum(salesSnap.data?.summary?.grand_total), currency),
      hint: `${formatNumber(toNum(salesSnap.data?.summary?.completed_count))} completed tickets`,
      to: '/reports/sales',
    },
  ]

  const catalogExportRows: CatalogExportRow[] = TENANT_REPORTS.map((r) => ({
    id: r.key,
    name: r.name,
    category: r.category,
    description: r.description,
    path: r.path,
  }))

  const catalogExportColumns: ExportColumn<CatalogExportRow>[] = [
    { key: 'name', header: 'Report', value: (r) => r.name },
    { key: 'category', header: 'Category', value: (r) => r.category },
    { key: 'description', header: 'Description', value: (r) => r.description },
    { key: 'path', header: 'Path', value: (r) => r.path },
  ]

  const snapshotError =
    (membershipSnap.error instanceof ApiError && membershipSnap.error.message) ||
    (revenueSnap.error instanceof ApiError && revenueSnap.error.message) ||
    (attendanceSnap.error instanceof ApiError && attendanceSnap.error.message) ||
    (salesSnap.error instanceof ApiError && salesSnap.error.message) ||
    (catalogQuery.error instanceof ApiError && catalogQuery.error.message) ||
    null

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-4">
        <PageHeader title="Reports" description="Analytics and operational insights." />
        <Alert tone="danger">
          Your role needs <code>reports.view</code> to open the reports library.
        </Alert>
      </div>
    )
  }

  return (
    <div className="animate-fade-up space-y-6">
      <PageHeader
        title="Reports"
        description="Professional dashboards for memberships, revenue, operations, and performance. Export any report to Excel or PDF."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                void catalogQuery.refetch()
                void membershipSnap.refetch()
                void revenueSnap.refetch()
                void attendanceSnap.refetch()
                void salesSnap.refetch()
                showSuccess('Reports refreshed.')
              }}
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
            {canExport ? (
              <Link
                to="/reports/exports"
                className="inline-flex h-9 items-center gap-2 rounded-xl border border-white/15 bg-white/10 px-3 text-sm font-semibold text-ink transition hover:bg-white/16"
              >
                <Download className="h-4 w-4" />
                Export center
              </Link>
            ) : null}
          </div>
        }
      />

      {snapshotError ? <Alert tone="danger">{snapshotError}</Alert> : null}

      <Card className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(198,255,26,0.12),transparent_55%)]" />
        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <Badge tone="accent">Report library</Badge>
              <Badge tone="neutral">{branchLabel}</Badge>
              <Badge tone="neutral">Last 30 days</Badge>
              {canExport ? <Badge tone="success">Server export enabled</Badge> : null}
            </div>
            <CardTitle className="text-xl normal-case tracking-normal sm:text-2xl">
              Choose a dashboard, filter the period, then export
            </CardTitle>
            <CardDescription className="mt-2 max-w-xl text-sm leading-relaxed">
              {TENANT_REPORTS.length} specialized reports with live KPIs, charts, detail tables, and
              one-click Excel or PDF downloads. Access is enforced by RBAC.
            </CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                const file = exportRowsToExcel(
                  'report-catalog',
                  'Report catalog',
                  catalogExportColumns,
                  catalogExportRows,
                )
                showSuccess(`Excel downloaded: ${file}`)
              }}
            >
              <FileSpreadsheet className="h-4 w-4" />
              Catalog Excel
            </Button>
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                const file = exportRowsToPdf(
                  'report-catalog',
                  'Report catalog',
                  catalogExportColumns,
                  catalogExportRows,
                  `${tenant?.name ?? 'Gym'} · ${branchLabel}`,
                )
                showSuccess(`PDF downloaded: ${file}`)
              }}
            >
              <FileText className="h-4 w-4" />
              Catalog PDF
            </Button>
          </div>
        </div>
      </Card>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {snapshotLoading
          ? Array.from({ length: 4 }).map((_, i) => (
              <Card key={i} className="h-28 animate-pulse bg-white/5" />
            ))
          : kpis.map((kpi) => (
              <Link key={kpi.label} to={kpi.to} className="group block">
                <Card className="h-full transition group-hover:border-accent/35 group-hover:bg-white/[0.07]">
                  <p className="text-xs font-semibold tracking-wide text-muted uppercase">{kpi.label}</p>
                  <p className="mt-2 font-display text-3xl font-bold text-ink tabular-nums">{kpi.value}</p>
                  <p className="mt-2 text-xs text-muted">{kpi.hint}</p>
                  <p className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-accent opacity-0 transition group-hover:opacity-100">
                    Open report <ArrowRight className="h-3.5 w-3.5" />
                  </p>
                </Card>
              </Link>
            ))}
      </div>

      <Card>
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="relative min-w-0 flex-1 lg:max-w-md">
            <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search reports by name or topic…"
              className="pl-10"
              aria-label="Search reports"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((item) => {
              const active = category === item
              return (
                <button
                  key={item}
                  type="button"
                  onClick={() => setCategory(item)}
                  className={cn(
                    'rounded-xl px-3 py-2 text-sm font-semibold transition',
                    active
                      ? 'bg-accent text-accent-ink'
                      : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                  )}
                >
                  {item}
                </button>
              )
            })}
          </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3 text-xs text-muted">
          <span className="inline-flex items-center gap-1.5">
            <FileBarChart2 className="h-3.5 w-3.5 text-accent" />
            Showing {filteredReports.length} of {TENANT_REPORTS.length} dashboards
          </span>
          <span className="inline-flex items-center gap-1.5">
            <ShieldCheck className="h-3.5 w-3.5 text-success" />
            {catalogQuery.isLoading
              ? 'Checking API catalog…'
              : catalogQuery.isSuccess
                ? `API catalog online · ${apiKeys.size} keys`
                : 'API catalog unavailable'}
          </span>
        </div>
      </Card>

      {catalogQuery.isLoading && filteredReports.length === 0 ? (
        <div className="flex justify-center py-16">
          <Spinner label="Loading report library…" />
        </div>
      ) : filteredReports.length === 0 ? (
        <Card className="py-12 text-center">
          <CardTitle className="text-base normal-case tracking-normal">No reports match</CardTitle>
          <CardDescription className="mt-2">Try another category or clear the search.</CardDescription>
          <Button
            className="mt-5"
            size="sm"
            variant="secondary"
            onClick={() => {
              setSearch('')
              setCategory('All')
            }}
          >
            Clear filters
          </Button>
        </Card>
      ) : (
        grouped.map((group) => (
          <section key={group.category} className="space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-accent" />
                <h2 className="font-display text-lg font-semibold tracking-wide text-ink uppercase">
                  {group.category}
                </h2>
                <Badge tone="neutral">{group.reports.length}</Badge>
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {group.reports.map((report) => {
                const Icon = report.icon
                const available = !catalogQuery.isSuccess || apiKeys.has(report.key)
                return (
                  <Link
                    key={report.key}
                    to={available ? report.path : '#'}
                    onClick={(e) => {
                      if (!available) e.preventDefault()
                    }}
                    className={cn('group block', !available && 'cursor-not-allowed opacity-60')}
                    aria-disabled={!available}
                  >
                    <Card className="relative h-full overflow-hidden transition group-hover:border-accent/40 group-hover:bg-white/[0.07]">
                      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-accent/50 to-transparent opacity-0 transition group-hover:opacity-100" />
                      <div className="flex items-start justify-between gap-3">
                        <div className="rounded-xl bg-accent/15 p-2.5 text-accent transition group-hover:bg-accent group-hover:text-accent-ink">
                          <Icon className="h-5 w-5" />
                        </div>
                        <div className="flex flex-col items-end gap-1">
                          <Badge tone="neutral">{report.category}</Badge>
                          {available ? (
                            <span className="text-[10px] font-semibold tracking-wide text-success uppercase">
                              Ready
                            </span>
                          ) : (
                            <span className="text-[10px] font-semibold tracking-wide text-warning uppercase">
                              Unavailable
                            </span>
                          )}
                        </div>
                      </div>
                      <CardTitle className="mt-4 text-base normal-case tracking-normal">
                        {report.name}
                      </CardTitle>
                      <CardDescription className="mt-1.5 line-clamp-2">
                        {report.description}
                      </CardDescription>
                      <div className="mt-5 flex items-center justify-between gap-2">
                        <span className="inline-flex items-center gap-1 text-sm font-semibold text-accent">
                          Open dashboard
                          <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
                        </span>
                        <span className="text-[11px] text-muted">Excel · PDF</span>
                      </div>
                    </Card>
                  </Link>
                )
              })}
            </div>
          </section>
        ))
      )}

      <Card>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <CardTitle className="text-base normal-case tracking-normal">Export this directory</CardTitle>
            <CardDescription>
              Download the full report catalog as Excel or PDF for sharing with your team.
            </CardDescription>
          </div>
          <ReportExportActions
            reportKey="report-catalog"
            reportName="Report catalog"
            columns={catalogExportColumns}
            rows={catalogExportRows}
            subtitle={`${tenant?.name ?? 'Gym'} · ${branchLabel}`}
          />
        </div>
      </Card>
    </div>
  )
}
