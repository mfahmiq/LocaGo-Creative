import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  AlertTriangle,
  CheckCircle2,
  Clock3,
  PauseCircle,
  PlayCircle,
  Plus,
  RefreshCw,
  Snowflake,
  Ticket,
  X,
} from 'lucide-react'
import {
  activateMembership,
  ackMembershipEscalation,
  cancelMembership,
  createMembership,
  downgradeMembership,
  fetchMembership,
  fetchMembershipDashboardAlerts,
  fetchMembershipEscalations,
  fetchMemberships,
  freezeMembership,
  renewMembership,
  resolveMembershipEscalation,
  unfreezeMembership,
  upgradeMembership,
  type Membership,
  type MembershipDisplayStatus,
  type MembershipStatus,
} from '@/api/memberships'
import { fetchMembers } from '@/api/members'
import { fetchMembershipPlans } from '@/api/membershipPlans'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatMoney, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'

type StatusFilter = '' | MembershipDisplayStatus
type PanelAction = 'freeze' | 'renew' | 'upgrade' | 'downgrade' | 'cancel' | null
type PageTab = 'instances' | 'escalations'

const STATUS_FILTERS: Array<{ value: StatusFilter; label: string }> = [
  { value: '', label: 'All Status' },
  { value: 'active', label: 'Active' },
  { value: 'expiring_soon', label: 'Expiring soon' },
  { value: 'pending', label: 'Pending' },
  { value: 'frozen', label: 'Frozen' },
  { value: 'grace', label: 'Grace' },
  { value: 'expired', label: 'Expired' },
  { value: 'cancelled', label: 'Cancelled' },
]

function todayIso() {
  return new Date().toISOString().slice(0, 10)
}

function addDaysIso(days: number) {
  const d = new Date()
  d.setDate(d.getDate() + days)
  return d.toISOString().slice(0, 10)
}

function memberLabel(m?: {
  first_name?: string
  last_name?: string
  member_code?: string
} | null) {
  if (!m) return '—'
  const name = `${m.first_name ?? ''} ${m.last_name ?? ''}`.trim()
  return name ? `${name}${m.member_code ? ` (${m.member_code})` : ''}` : m.member_code || '—'
}

function statusTone(
  status: MembershipDisplayStatus,
): 'success' | 'accent' | 'warning' | 'danger' | 'neutral' {
  switch (status) {
    case 'active':
      return 'success'
    case 'expiring_soon':
    case 'grace':
      return 'warning'
    case 'pending':
      return 'accent'
    case 'frozen':
      return 'neutral'
    case 'expired':
    case 'cancelled':
      return 'danger'
    default:
      return 'neutral'
  }
}

function statusLabel(status: MembershipDisplayStatus): string {
  switch (status) {
    case 'expiring_soon':
      return 'Expiring soon'
    case 'pending':
      return 'Pending'
    case 'active':
      return 'Active'
    case 'frozen':
      return 'Frozen'
    case 'grace':
      return 'Grace'
    case 'expired':
      return 'Expired'
    case 'cancelled':
      return 'Cancelled'
    default:
      return status
  }
}

function canRenewStatus(status: MembershipStatus) {
  return status === 'active' || status === 'grace' || status === 'expired' || status === 'cancelled'
}

export function MembershipsPage() {
  const { branches, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('memberships.instances.view')
  const canManage = hasPermission('memberships.instances.manage')
  const canCancel = hasPermission('memberships.instances.cancel')
  const canFreeze = hasPermission('memberships.instances.freeze')

  const [tab, setTab] = useState<PageTab>('instances')
  const [page, setPage] = useState(1)
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('')
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  const [panelAction, setPanelAction] = useState<PanelAction>(null)
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }

  const [createMemberId, setCreateMemberId] = useState<number | ''>('')
  const [createPlanId, setCreatePlanId] = useState<number | ''>('')
  const [createBranchId, setCreateBranchId] = useState<number | ''>('')
  const [createStartDate, setCreateStartDate] = useState(todayIso())
  const [createActivateNow, setCreateActivateNow] = useState(true)
  const [createNotes, setCreateNotes] = useState('')
  const [memberSearch, setMemberSearch] = useState('')

  const [freezeStart, setFreezeStart] = useState(todayIso())
  const [freezeEnd, setFreezeEnd] = useState(addDaysIso(7))
  const [freezeExtend, setFreezeExtend] = useState(true)
  const [freezeReason, setFreezeReason] = useState('')
  const [cancelReason, setCancelReason] = useState('')
  const [renewPlanId, setRenewPlanId] = useState<number | ''>('')
  const [renewStartMode, setRenewStartMode] = useState<'from_end_date' | 'today'>('from_end_date')
  const [changePlanId, setChangePlanId] = useState<number | ''>('')
  const [changeStartMode, setChangeStartMode] = useState<'from_end_date' | 'today'>('from_end_date')

  const listQuery = useQuery({
    queryKey: ['admin', 'memberships', page, statusFilter],
    queryFn: () =>
      fetchMemberships({
        page,
        per_page: DEFAULT_PAGE_SIZE,
        status: statusFilter,
      }),
    enabled: canView && tab === 'instances',
  })

  const alertsQuery = useQuery({
    queryKey: ['admin', 'memberships', 'alerts'],
    queryFn: fetchMembershipDashboardAlerts,
    enabled: canView,
  })

  const statsQuery = useQuery({
    queryKey: ['admin', 'memberships', 'stats'],
    queryFn: async () => {
      const [all, active, pending, frozen] = await Promise.all([
        fetchMemberships({ page: 1, per_page: 1 }),
        fetchMemberships({ page: 1, per_page: 1, status: 'active' }),
        fetchMemberships({ page: 1, per_page: 1, status: 'pending' }),
        fetchMemberships({ page: 1, per_page: 1, status: 'frozen' }),
      ])
      return {
        total: all.meta.total,
        active: active.meta.total,
        pending: pending.meta.total,
        frozen: frozen.meta.total,
      }
    },
    enabled: canView,
  })

  const selectedQuery = useQuery({
    queryKey: ['admin', 'memberships', 'detail', selectedId],
    queryFn: () => fetchMembership(selectedId!),
    enabled: canView && selectedId != null,
  })

  const plansQuery = useQuery({
    queryKey: ['admin', 'membership-plans', 'active-options'],
    queryFn: () => fetchMembershipPlans({ page: 1, per_page: 100, is_active: true }),
    enabled: canView,
  })

  const membersQuery = useQuery({
    queryKey: ['admin', 'members', 'membership-picker', memberSearch],
    queryFn: () =>
      fetchMembers({
        page: 1,
        per_page: 50,
        search: memberSearch,
        status: 'active',
      }),
    enabled: canView && (showCreate || memberSearch.length > 0),
  })

  const escalationsQuery = useQuery({
    queryKey: ['admin', 'memberships', 'escalations'],
    queryFn: () => fetchMembershipEscalations({ page: 1, per_page: 20, status: 'open' }),
    enabled: canView && tab === 'escalations',
  })

  const rows = listQuery.data?.data ?? []
  const meta = listQuery.data?.meta
  const plans = plansQuery.data?.data ?? []
  const members = membersQuery.data?.data ?? []
  const alerts = alertsQuery.data
  const selected = useMemo(() => {
    if (selectedId == null) return null
    return selectedQuery.data ?? rows.find((row) => row.id === selectedId) ?? null
  }, [selectedId, selectedQuery.data, rows])

  useEffect(() => {
    setPanelAction(null)
    setCancelReason('')
    setFieldErrors({})
    if (selected) {
      setRenewPlanId(selected.membership_plan_id)
      setChangePlanId('')
      setFreezeStart(todayIso())
      setFreezeEnd(addDaysIso(7))
      setFreezeExtend(true)
      setFreezeReason('')
    }
  }, [selected?.id])

  const invalidate = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'memberships'] })
  }

  const apiError = (err: unknown, fallback: string) =>
    err instanceof ApiError ? err.message : fallback

  const createMutation = useMutation({
    mutationFn: createMembership,
    onSuccess: async (row) => {
      setError(null)
      showSuccess(`Membership #${row.id} created.`)
      setShowCreate(false)
      setCreateMemberId('')
      setCreatePlanId('')
      setCreateBranchId('')
      setCreateNotes('')
      setCreateActivateNow(true)
      setCreateStartDate(todayIso())
      setStatusFilter('')
      setPage(1)
      await invalidate()
      setSelectedId(row.id)
    },
    onError: (err) => setError(apiError(err, 'Unable to create membership.')),
  })

  const activateMutation = useMutation({
    mutationFn: activateMembership,
    onSuccess: async (row) => {
      setError(null)
      showSuccess(`Membership #${row.id} activated.`)
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to activate membership.')),
  })

  const freezeMutation = useMutation({
    mutationFn: (payload: {
      start_date: string
      end_date: string
      extends_end_date: boolean
      reason?: string
    }) => freezeMembership(selectedId!, payload),
    onSuccess: async (row) => {
      setError(null)
      showSuccess(`Membership #${row.id} frozen.`)
      setPanelAction(null)
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to freeze membership.')),
  })

  const unfreezeMutation = useMutation({
    mutationFn: unfreezeMembership,
    onSuccess: async (row) => {
      setError(null)
      showSuccess(`Membership #${row.id} unfrozen.`)
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to unfreeze membership.')),
  })

  const cancelMutation = useMutation({
    mutationFn: (reason: string) => cancelMembership(selectedId!, reason || null),
    onSuccess: async (row) => {
      setError(null)
      showSuccess(`Membership #${row.id} cancelled.`)
      setPanelAction(null)
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to cancel membership.')),
  })

  const renewMutation = useMutation({
    mutationFn: () =>
      renewMembership(selectedId!, {
        membership_plan_id: renewPlanId || undefined,
        start_mode: renewStartMode,
      }),
    onSuccess: async (row) => {
      setError(null)
      showSuccess(`Renewed as membership #${row.id}.`)
      setPanelAction(null)
      await invalidate()
      setSelectedId(row.id)
    },
    onError: (err) => setError(apiError(err, 'Unable to renew membership.')),
  })

  const upgradeMutation = useMutation({
    mutationFn: () =>
      upgradeMembership(selectedId!, {
        membership_plan_id: Number(changePlanId),
        start_mode: changeStartMode,
      }),
    onSuccess: async (row) => {
      setError(null)
      showSuccess(`Upgraded to membership #${row.id}.`)
      setPanelAction(null)
      await invalidate()
      setSelectedId(row.id)
    },
    onError: (err) => setError(apiError(err, 'Unable to upgrade membership.')),
  })

  const downgradeMutation = useMutation({
    mutationFn: () =>
      downgradeMembership(selectedId!, {
        membership_plan_id: Number(changePlanId),
        start_mode: changeStartMode,
      }),
    onSuccess: async (row) => {
      setError(null)
      showSuccess(`Downgraded to membership #${row.id}.`)
      setPanelAction(null)
      await invalidate()
      setSelectedId(row.id)
    },
    onError: (err) => setError(apiError(err, 'Unable to downgrade membership.')),
  })

  const ackMutation = useMutation({
    mutationFn: ackMembershipEscalation,
    onSuccess: async () => {
      showSuccess('Escalation acknowledged.')
      await queryClient.invalidateQueries({ queryKey: ['admin', 'memberships'] })
    },
    onError: (err) => setError(apiError(err, 'Unable to acknowledge escalation.')),
  })

  const resolveMutation = useMutation({
    mutationFn: resolveMembershipEscalation,
    onSuccess: async () => {
      showSuccess('Escalation resolved.')
      await queryClient.invalidateQueries({ queryKey: ['admin', 'memberships'] })
    },
    onError: (err) => setError(apiError(err, 'Unable to resolve escalation.')),
  })

  const onCreate = (event: FormEvent) => {
    event.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'createMemberId', label: 'Member', value: createMemberId },
      { key: 'createPlanId', label: 'Plan', value: createPlanId },
    ])
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    createMutation.mutate({
      member_id: Number(createMemberId),
      membership_plan_id: Number(createPlanId),
      branch_id: createBranchId ? Number(createBranchId) : null,
      start_date: createStartDate || null,
      activate_now: createActivateNow,
      notes: createNotes.trim() || null,
    })
  }

  const onActivate = async (row: Membership) => {
    const ok = await confirm({
      title: 'Activate membership?',
      message: `Activate membership #${row.id} for ${memberLabel(row.member)}?`,
      confirmLabel: 'Activate',
      tone: 'primary',
    })
    if (!ok) return
    activateMutation.mutate(row.id)
  }

  const onUnfreeze = async (row: Membership) => {
    const ok = await confirm({
      title: 'Unfreeze membership?',
      message: `Resume access for ${memberLabel(row.member)}? Unused freeze extension days may be clawed back.`,
      confirmLabel: 'Unfreeze',
      tone: 'primary',
    })
    if (!ok) return
    unfreezeMutation.mutate(row.id)
  }

  const columns: Column<Membership>[] = [
    {
      key: 'member',
      header: 'Member',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">{memberLabel(row.member)}</p>
          <p className="mt-0.5 text-xs text-muted">#{row.id}</p>
        </button>
      ),
    },
    {
      key: 'plan',
      header: 'Plan',
      cell: (row) => (
        <div>
          <p className="text-sm font-medium text-ink">{row.plan?.name ?? '—'}</p>
          <p className="font-mono text-xs text-muted">{row.plan?.code}</p>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={statusTone(row.display_status)}>{statusLabel(row.display_status)}</Badge>
      ),
    },
    {
      key: 'dates',
      header: 'Period',
      cell: (row) => (
        <div className="text-sm text-ink">
          <p>
            {formatDate(row.start_date)} → {formatDate(row.end_date)}
          </p>
          {row.days_until_end != null && row.status === 'active' ? (
            <p className="text-xs text-muted">{row.days_until_end} days left</p>
          ) : null}
        </div>
      ),
    },
    {
      key: 'price',
      header: 'Price',
      cell: (row) => (
        <span className="font-semibold text-ink">
          {formatMoney(row.price_snapshot, row.currency_code || 'INR')}
        </span>
      ),
    },
    {
      key: 'visits',
      header: 'Visits',
      cell: (row) => (
        <span className="text-sm text-muted">
          {row.visits_remaining != null ? formatNumber(row.visits_remaining) : '—'}
        </span>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedId(row.id)}>
          Manage
        </Button>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader
          title="Memberships"
          description="Membership instances, renewals, freezes."
        />
        <Alert tone="danger">You do not have permission to view memberships.</Alert>
      </div>
    )
  }

  const stats = statsQuery.data

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Memberships"
        description="Membership instances, renewals, freezes, and escalations."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">Gym</Badge>
            {canManage ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowCreate(true)
                  setError(null)
                  setFieldErrors({})
                  setTab('instances')
                }}
              >
                <Plus className="h-4 w-4" />
                Sell membership
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<Ticket className="h-4 w-4" />}
          label="Total instances"
          value={formatNumber(stats?.total ?? meta?.total ?? 0)}
        />
        <SummaryChip
          icon={<CheckCircle2 className="h-4 w-4" />}
          label="Active"
          value={formatNumber(stats?.active ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<Clock3 className="h-4 w-4" />}
          label={`Expiring (${alerts?.expiring_soon.within_days ?? 30}d)`}
          value={formatNumber(alerts?.expiring_soon.count ?? 0)}
          onClick={() => {
            setTab('instances')
            setStatusFilter('expiring_soon')
            setPage(1)
            setSelectedId(null)
          }}
        />
        <SummaryChip
          icon={<AlertTriangle className="h-4 w-4" />}
          label="Open escalations"
          value={formatNumber(alerts?.escalations.open_count ?? 0)}
          onClick={() => {
            setTab('escalations')
            setSelectedId(null)
          }}
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {(
          [
            { id: 'instances' as const, label: 'Instances' },
            { id: 'escalations' as const, label: 'Escalations' },
          ] as const
        ).map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => {
              setTab(item.id)
              setSelectedId(null)
              setError(null)
            }}
            className={cn(
              'rounded-xl px-3 py-2 text-sm font-semibold transition',
              tab === item.id
                ? 'bg-accent text-accent-ink'
                : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
            )}
          >
            {item.label}
            {item.id === 'escalations' && (alerts?.escalations.open_count ?? 0) > 0
              ? ` (${alerts?.escalations.open_count})`
              : ''}
          </button>
        ))}
      </div>

      {showCreate && canManage && tab === 'instances' ? (
        <Card className="border-accent/25">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <CardTitle>Sell membership</CardTitle>
              <CardDescription>
                Assign a plan to a member. Activate now or leave pending for later.
              </CardDescription>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowCreate(false)}
              aria-label="Close create form"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form onSubmit={onCreate} noValidate className="grid gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <Label htmlFor="create-member-search">Find member</Label>
              <Input
                id="create-member-search"
                value={memberSearch}
                onChange={(e) => setMemberSearch(e.target.value)}
                placeholder="Search name, email, code…"
              />
            </div>
            <Field
              label="Member"
              htmlFor="create-member"
              required
              error={fieldErrors.createMemberId}
              className="sm:col-span-2"
            >
              <Select
                id="create-member"
                value={createMemberId === '' ? '' : String(createMemberId)}
                onChange={(e) => {
                  setCreateMemberId(e.target.value ? Number(e.target.value) : '')
                  clearFieldError('createMemberId')
                }}
                aria-invalid={Boolean(fieldErrors.createMemberId)}
              >
                <option value="">Select member…</option>
                {members.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.full_name} ({m.member_code})
                  </option>
                ))}
              </Select>
              {membersQuery.isPending ? (
                <p className="mt-1 text-xs text-muted">Loading members…</p>
              ) : null}
            </Field>
            <Field label="Plan" htmlFor="create-plan" required error={fieldErrors.createPlanId}>
              <Select
                id="create-plan"
                value={createPlanId === '' ? '' : String(createPlanId)}
                onChange={(e) => {
                  setCreatePlanId(e.target.value ? Number(e.target.value) : '')
                  clearFieldError('createPlanId')
                }}
                aria-invalid={Boolean(fieldErrors.createPlanId)}
              >
                <option value="">Select plan…</option>
                {plans.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} — {formatMoney(p.price, p.currency_code)}
                  </option>
                ))}
              </Select>
            </Field>
            <div>
              <Label htmlFor="create-branch">Branch (optional)</Label>
              <Select
                id="create-branch"
                value={createBranchId === '' ? '' : String(createBranchId)}
                onChange={(e) =>
                  setCreateBranchId(e.target.value ? Number(e.target.value) : '')
                }
              >
                <option value="">Member home branch</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label htmlFor="create-start">Start date</Label>
              <Input
                id="create-start"
                type="date"
                value={createStartDate}
                onChange={(e) => setCreateStartDate(e.target.value)}
              />
            </div>
            <div className="flex items-end">
              <label className="flex items-center gap-2 pb-2 text-sm text-ink">
                <input
                  type="checkbox"
                  checked={createActivateNow}
                  onChange={(e) => setCreateActivateNow(e.target.checked)}
                />
                Activate now
              </label>
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="create-notes">Notes</Label>
              <Textarea
                id="create-notes"
                value={createNotes}
                onChange={(e) => setCreateNotes(e.target.value)}
                rows={2}
              />
            </div>
            <div className="flex flex-wrap gap-2 sm:col-span-2">
              <Button type="submit" loading={createMutation.isPending}>
                Create membership
              </Button>
              <Button type="button" variant="ghost" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      {tab === 'instances' ? (
        <>
          <Card>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-end">
              <Select
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value as StatusFilter)
                  setPage(1)
                  setSelectedId(null)
                }}
                aria-label="Filter by status"
                className="sm:w-56"
              >
                {STATUS_FILTERS.map((filter) => (
                  <option key={filter.label} value={filter.value}>
                    {filter.label}
                  </option>
                ))}
              </Select>
            </div>
          </Card>

          <div className={cn('grid gap-4', selectedId != null ? 'xl:grid-cols-[1fr_26rem]' : '')}>
            <div className="min-w-0">
              {listQuery.isPending ? (
                <div className="flex justify-center py-20">
                  <Spinner label="Loading memberships…" />
                </div>
              ) : listQuery.isError ? (
                <Alert tone="danger">
                  {listQuery.error instanceof ApiError
                    ? listQuery.error.message
                    : 'Unable to load memberships.'}
                  <div className="mt-3">
                    <Button size="sm" variant="secondary" onClick={() => void listQuery.refetch()}>
                      Try again
                    </Button>
                  </div>
                </Alert>
              ) : (
                <>
                  <DataTable
                    columns={columns}
                    rows={rows}
                    rowKey={(row) => row.id}
                    emptyTitle="No memberships match"
                    emptyDescription={
                      (meta?.total ?? 0) === 0 && !statusFilter
                        ? 'Sell the first membership for this gym.'
                        : 'Try another status filter.'
                    }
                  />
                  <Pagination
                    meta={meta}
                    onPageChange={(next) => {
                      setPage(next)
                      setSelectedId(null)
                    }}
                  />
                </>
              )}
            </div>

            {selectedId != null && !selected && selectedQuery.isPending ? (
              <aside className="animate-slide-in">
                <Card className="sticky top-4">
                  <div className="flex justify-center py-12">
                    <Spinner label="Loading membership…" />
                  </div>
                </Card>
              </aside>
            ) : null}

            {selected ? (
              <aside className="animate-slide-in">
                <Card className="sticky top-4 max-h-[calc(100vh-6rem)] space-y-4 overflow-y-auto">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                        <Ticket className="h-5 w-5" />
                      </div>
                      <CardTitle className="truncate text-base">
                        {memberLabel(selected.member)}
                      </CardTitle>
                      <CardDescription>
                        #{selected.id} · {selected.plan?.name ?? 'Plan'}
                      </CardDescription>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setSelectedId(null)}
                      aria-label="Close details"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Badge tone={statusTone(selected.display_status)}>
                      {statusLabel(selected.display_status)}
                    </Badge>
                    {selected.branch ? (
                      <Badge tone="neutral">{selected.branch.name}</Badge>
                    ) : null}
                  </div>

                  <dl className="space-y-2 text-sm">
                    <DetailRow
                      label="Period"
                      value={`${formatDate(selected.start_date)} → ${formatDate(selected.end_date)}`}
                    />
                    <DetailRow
                      label="Price"
                      value={formatMoney(
                        selected.price_snapshot,
                        selected.currency_code || 'INR',
                      )}
                    />
                    <DetailRow
                      label="Visits left"
                      value={
                        selected.visits_remaining != null
                          ? formatNumber(selected.visits_remaining)
                          : '—'
                      }
                    />
                    {selected.cancel_reason ? (
                      <DetailRow label="Cancel reason" value={selected.cancel_reason} />
                    ) : null}
                    {selected.notes ? <DetailRow label="Notes" value={selected.notes} /> : null}
                  </dl>

                  <div className="flex flex-wrap gap-2 border-t border-white/12 pt-4">
                    {canManage && selected.status === 'pending' ? (
                      <Button
                        size="sm"
                        loading={activateMutation.isPending}
                        onClick={() => void onActivate(selected)}
                      >
                        <PlayCircle className="h-4 w-4" />
                        Activate
                      </Button>
                    ) : null}
                    {canFreeze && selected.status === 'active' ? (
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => setPanelAction(panelAction === 'freeze' ? null : 'freeze')}
                      >
                        <Snowflake className="h-4 w-4" />
                        Freeze
                      </Button>
                    ) : null}
                    {canFreeze && selected.status === 'frozen' ? (
                      <Button
                        size="sm"
                        variant="secondary"
                        loading={unfreezeMutation.isPending}
                        onClick={() => void onUnfreeze(selected)}
                      >
                        <PlayCircle className="h-4 w-4" />
                        Unfreeze
                      </Button>
                    ) : null}
                    {canManage && canRenewStatus(selected.status) ? (
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => setPanelAction(panelAction === 'renew' ? null : 'renew')}
                      >
                        <RefreshCw className="h-4 w-4" />
                        Renew
                      </Button>
                    ) : null}
                    {canManage && canRenewStatus(selected.status) ? (
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() =>
                          setPanelAction(panelAction === 'upgrade' ? null : 'upgrade')
                        }
                      >
                        Upgrade
                      </Button>
                    ) : null}
                    {canManage && canRenewStatus(selected.status) ? (
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() =>
                          setPanelAction(panelAction === 'downgrade' ? null : 'downgrade')
                        }
                      >
                        Downgrade
                      </Button>
                    ) : null}
                    {canCancel && selected.status !== 'cancelled' ? (
                      <Button
                        size="sm"
                        variant="danger"
                        onClick={() => setPanelAction(panelAction === 'cancel' ? null : 'cancel')}
                      >
                        Cancel
                      </Button>
                    ) : null}
                  </div>

                  {panelAction === 'freeze' ? (
                    <ActionPanel
                      title="Freeze membership"
                      onClose={() => setPanelAction(null)}
                    >
                      <div className="space-y-3">
                        <Field
                          label="Start date"
                          htmlFor="freeze-start"
                          required
                          error={fieldErrors.freezeStart}
                        >
                          <Input
                            id="freeze-start"
                            type="date"
                            value={freezeStart}
                            aria-invalid={Boolean(fieldErrors.freezeStart)}
                            onChange={(e) => {
                              clearFieldError('freezeStart')
                              setFreezeStart(e.target.value)
                            }}
                          />
                        </Field>
                        <Field
                          label="End date"
                          htmlFor="freeze-end"
                          required
                          error={fieldErrors.freezeEnd}
                        >
                          <Input
                            id="freeze-end"
                            type="date"
                            value={freezeEnd}
                            aria-invalid={Boolean(fieldErrors.freezeEnd)}
                            onChange={(e) => {
                              clearFieldError('freezeEnd')
                              setFreezeEnd(e.target.value)
                            }}
                          />
                        </Field>
                        <label className="flex items-center gap-2 text-sm text-ink">
                          <input
                            type="checkbox"
                            checked={freezeExtend}
                            onChange={(e) => setFreezeExtend(e.target.checked)}
                          />
                          Extend membership end date
                        </label>
                        <div>
                          <Label htmlFor="freeze-reason">Reason</Label>
                          <Input
                            id="freeze-reason"
                            value={freezeReason}
                            onChange={(e) => setFreezeReason(e.target.value)}
                          />
                        </div>
                        <Button
                          size="sm"
                          loading={freezeMutation.isPending}
                          onClick={() => {
                            const next = collectRequiredErrors([
                              { key: 'freezeStart', label: 'Start date', value: freezeStart },
                              { key: 'freezeEnd', label: 'End date', value: freezeEnd },
                            ])
                            setFieldErrors(next)
                            if (Object.keys(next).length) return
                            freezeMutation.mutate({
                              start_date: freezeStart,
                              end_date: freezeEnd,
                              extends_end_date: freezeExtend,
                              reason: freezeReason.trim() || undefined,
                            })
                          }}
                        >
                          <PauseCircle className="h-4 w-4" />
                          Confirm freeze
                        </Button>
                      </div>
                    </ActionPanel>
                  ) : null}

                  {panelAction === 'renew' ? (
                    <ActionPanel title="Renew membership" onClose={() => setPanelAction(null)}>
                      <div className="space-y-3">
                        <div>
                          <Label htmlFor="renew-plan">Plan</Label>
                          <Select
                            id="renew-plan"
                            value={renewPlanId === '' ? '' : String(renewPlanId)}
                            onChange={(e) =>
                              setRenewPlanId(e.target.value ? Number(e.target.value) : '')
                            }
                          >
                            {plans.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.name} — {formatMoney(p.price, p.currency_code)}
                              </option>
                            ))}
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="renew-mode">Start</Label>
                          <Select
                            id="renew-mode"
                            value={renewStartMode}
                            onChange={(e) =>
                              setRenewStartMode(e.target.value as 'from_end_date' | 'today')
                            }
                          >
                            <option value="from_end_date">From current end date</option>
                            <option value="today">Starting today</option>
                          </Select>
                        </div>
                        <p className="text-xs text-muted">
                          Creates a new membership and expires the current one when active or in
                          grace.
                        </p>
                        <Button
                          size="sm"
                          loading={renewMutation.isPending}
                          onClick={() => renewMutation.mutate()}
                        >
                          <RefreshCw className="h-4 w-4" />
                          Confirm renewal
                        </Button>
                      </div>
                    </ActionPanel>
                  ) : null}

                  {panelAction === 'upgrade' || panelAction === 'downgrade' ? (
                    <ActionPanel
                      title={panelAction === 'upgrade' ? 'Upgrade plan' : 'Downgrade plan'}
                      onClose={() => setPanelAction(null)}
                    >
                      <div className="space-y-3">
                        <div>
                          <Label htmlFor="change-plan">New plan</Label>
                          <Select
                            id="change-plan"
                            value={changePlanId === '' ? '' : String(changePlanId)}
                            onChange={(e) =>
                              setChangePlanId(e.target.value ? Number(e.target.value) : '')
                            }
                          >
                            <option value="">Select plan…</option>
                            {plans
                              .filter((p) => p.id !== selected.membership_plan_id)
                              .map((p) => (
                                <option key={p.id} value={p.id}>
                                  {p.name} — {formatMoney(p.price, p.currency_code)}
                                </option>
                              ))}
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="change-mode">Start</Label>
                          <Select
                            id="change-mode"
                            value={changeStartMode}
                            onChange={(e) =>
                              setChangeStartMode(e.target.value as 'from_end_date' | 'today')
                            }
                          >
                            <option value="from_end_date">From current end date</option>
                            <option value="today">Starting today</option>
                          </Select>
                        </div>
                        <p className="text-xs text-muted">
                          {panelAction === 'upgrade'
                            ? 'New plan price must be higher than the current snapshot.'
                            : 'New plan price must be lower than the current snapshot.'}
                        </p>
                        <Button
                          size="sm"
                          loading={
                            panelAction === 'upgrade'
                              ? upgradeMutation.isPending
                              : downgradeMutation.isPending
                          }
                          disabled={!changePlanId}
                          onClick={() => {
                            if (panelAction === 'upgrade') upgradeMutation.mutate()
                            else downgradeMutation.mutate()
                          }}
                        >
                          Confirm {panelAction}
                        </Button>
                      </div>
                    </ActionPanel>
                  ) : null}

                  {panelAction === 'cancel' ? (
                    <ActionPanel title="Cancel membership" onClose={() => setPanelAction(null)}>
                      <div className="space-y-3">
                        <div>
                          <Label htmlFor="cancel-reason">Reason (optional)</Label>
                          <Textarea
                            id="cancel-reason"
                            value={cancelReason}
                            onChange={(e) => setCancelReason(e.target.value)}
                            rows={2}
                          />
                        </div>
                        <Button
                          size="sm"
                          variant="danger"
                          loading={cancelMutation.isPending}
                          onClick={() => cancelMutation.mutate(cancelReason.trim())}
                        >
                          Confirm cancel
                        </Button>
                      </div>
                    </ActionPanel>
                  ) : null}
                </Card>
              </aside>
            ) : null}
          </div>
        </>
      ) : (
        <Card>
          <CardTitle className="mb-1">Open escalations</CardTitle>
          <CardDescription className="mb-4">
            Follow up on grace/expiry escalations. Acknowledge or resolve from here.
          </CardDescription>
          {escalationsQuery.isPending ? (
            <div className="flex justify-center py-12">
              <Spinner label="Loading escalations…" />
            </div>
          ) : (escalationsQuery.data?.data.length ?? 0) === 0 ? (
            <p className="rounded-xl border border-white/10 bg-white/[0.04] px-4 py-6 text-center text-sm text-muted">
              No open escalations.
            </p>
          ) : (
            <div className="space-y-3">
              {escalationsQuery.data?.data.map((item) => (
                <div
                  key={item.id}
                  className="flex flex-col gap-3 rounded-xl border border-white/10 bg-white/[0.04] p-4 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div className="min-w-0">
                    <div className="mb-1 flex flex-wrap items-center gap-2">
                      <Badge tone="warning">{item.tier}</Badge>
                      <Badge tone="neutral">{item.status}</Badge>
                    </div>
                    <p className="font-semibold text-ink">{memberLabel(item.member)}</p>
                    <p className="text-sm text-muted">
                      Membership #{item.membership_id}
                      {item.membership?.plan?.name ? ` · ${item.membership.plan.name}` : ''}
                      {item.reason ? ` · ${item.reason}` : ''}
                    </p>
                    <p className="text-xs text-muted">Opened {formatDate(item.opened_at)}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => {
                        setTab('instances')
                        setSelectedId(item.membership_id)
                      }}
                    >
                      View
                    </Button>
                    {canManage && item.status === 'open' ? (
                      <Button
                        size="sm"
                        variant="secondary"
                        loading={ackMutation.isPending}
                        onClick={() => ackMutation.mutate(item.id)}
                      >
                        Ack
                      </Button>
                    ) : null}
                    {canManage && item.status !== 'resolved' ? (
                      <Button
                        size="sm"
                        loading={resolveMutation.isPending}
                        onClick={() => resolveMutation.mutate(item.id)}
                      >
                        Resolve
                      </Button>
                    ) : null}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}
    </div>
  )
}

function ActionPanel({
  title,
  onClose,
  children,
}: {
  title: string
  onClose: () => void
  children: ReactNode
}) {
  return (
    <div className="rounded-xl border border-accent/25 bg-accent/5 p-3">
      <div className="mb-3 flex items-center justify-between gap-2">
        <p className="text-sm font-semibold text-ink">{title}</p>
        <Button size="sm" variant="ghost" onClick={onClose} aria-label="Close action">
          <X className="h-4 w-4" />
        </Button>
      </div>
      {children}
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
  onClick,
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
  onClick?: () => void
}) {
  const Comp = onClick ? 'button' : 'div'
  return (
    <Comp
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3 text-left transition',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
        onClick ? 'hover:border-accent/40 hover:bg-white/[0.07]' : '',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </Comp>
  )
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="shrink-0 text-muted">{label}</dt>
      <dd className="text-right font-semibold text-ink">{value}</dd>
    </div>
  )
}
