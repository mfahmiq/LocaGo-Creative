import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  CheckCircle2,
  ClipboardList,
  Plus,
  Search,
  Trash2,
  Wrench,
  X,
} from 'lucide-react'
import {
  assignMaintenanceOrder,
  cancelMaintenanceOrder,
  changeEquipmentStatus,
  completeMaintenanceOrder,
  createEquipmentAsset,
  createMaintenanceOrder,
  deleteEquipmentAsset,
  deleteMaintenanceOrder,
  fetchEquipmentAsset,
  fetchEquipmentAssets,
  fetchMaintenanceOrder,
  fetchMaintenanceOrders,
  startMaintenanceOrder,
  updateEquipmentAsset,
  updateMaintenanceOrder,
  updateOwnMaintenanceOrder,
  type EquipmentAsset,
  type EquipmentStatus,
  type MaintenanceOrder,
  type MaintenancePriority,
  type MaintenanceStatus,
} from '@/api/equipment'
import { fetchStaff } from '@/api/staff'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useBranchFilter } from '@/hooks/useBranchFilter'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatMoney, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'

type PageTab = 'assets' | 'tasks'

function assetStatusTone(
  status: EquipmentStatus,
): 'success' | 'warning' | 'danger' | 'neutral' {
  switch (status) {
    case 'in_service':
      return 'success'
    case 'under_maintenance':
      return 'warning'
    case 'retired':
      return 'danger'
    default:
      return 'neutral'
  }
}

function assetStatusLabel(status: EquipmentStatus) {
  switch (status) {
    case 'in_service':
      return 'In service'
    case 'under_maintenance':
      return 'Under maintenance'
    case 'retired':
      return 'Retired'
    default:
      return status
  }
}

function taskStatusTone(
  status: MaintenanceStatus,
): 'accent' | 'warning' | 'success' | 'danger' | 'neutral' {
  switch (status) {
    case 'open':
      return 'accent'
    case 'in_progress':
      return 'warning'
    case 'done':
      return 'success'
    case 'cancelled':
      return 'danger'
    default:
      return 'neutral'
  }
}

function priorityTone(
  priority: MaintenancePriority,
): 'neutral' | 'accent' | 'warning' | 'danger' {
  switch (priority) {
    case 'low':
      return 'neutral'
    case 'medium':
      return 'accent'
    case 'high':
      return 'warning'
    case 'urgent':
      return 'danger'
    default:
      return 'neutral'
  }
}

const emptyAssetForm = {
  branch_id: '' as number | '',
  asset_tag: '',
  name: '',
  category: '',
  purchase_date: '',
  warranty_ends_on: '',
  vendor_name: '',
}

const emptyTaskForm = {
  branch_id: '' as number | '',
  equipment_asset_id: '' as number | '',
  title: '',
  priority: 'medium' as MaintenancePriority,
  assigned_user_id: '' as number | '',
  due_date: '',
  cost_amount: '',
  currency_code: 'INR',
  notes: '',
}

export function EquipmentPage() {
  const { user, branches, branchId, tenant, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canViewAssets = hasPermission('equipment.view')
  const canManageAssets = hasPermission('equipment.manage')
  const canViewTasks = hasPermission('facilities.tasks.view')
  const canManageTasks = hasPermission('facilities.tasks.manage')
  const canUpdateOwn = hasPermission('facilities.tasks.update_own')
  const canStaff = hasPermission('identity.staff.view')
  const canView = canViewAssets || canViewTasks

  const defaultCurrency = tenant?.base_currency || 'INR'

  const [tab, setTab] = useState<PageTab>('assets')
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!canViewAssets && canViewTasks) setTab('tasks')
    else if (canViewAssets && !canViewTasks) setTab('assets')
  }, [canViewAssets, canViewTasks])

  // Assets
  const [assetPage, setAssetPage] = useState(1)
  const [assetStatus, setAssetStatus] = useState<'' | EquipmentStatus>('')
  const [assetBranch, setAssetBranch] = useBranchFilter()
  const [assetSearch, setAssetSearch] = useState('')
  const [appliedAssetSearch, setAppliedAssetSearch] = useState('')
  const [selectedAssetId, setSelectedAssetId] = useState<number | null>(null)
  const [showAssetForm, setShowAssetForm] = useState(false)
  const [editingAsset, setEditingAsset] = useState<EquipmentAsset | null>(null)
  const [assetForm, setAssetForm] = useState(emptyAssetForm)
  const [assetFieldErrors, setAssetFieldErrors] = useState<FieldErrors>({})

  const clearAssetFieldError = (key: string) => {
    setAssetFieldErrors((prev) => {
      if (!prev[key]) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  // Tasks
  const [taskPage, setTaskPage] = useState(1)
  const [taskStatus, setTaskStatus] = useState<'' | MaintenanceStatus>('open')
  const [taskBranch, setTaskBranch] = useBranchFilter()
  const [taskSearch, setTaskSearch] = useState('')
  const [appliedTaskSearch, setAppliedTaskSearch] = useState('')
  const [selectedTaskId, setSelectedTaskId] = useState<number | null>(null)
  const [showTaskForm, setShowTaskForm] = useState(false)
  const [editingTask, setEditingTask] = useState<MaintenanceOrder | null>(null)
  const [taskForm, setTaskForm] = useState({
    ...emptyTaskForm,
    currency_code: defaultCurrency,
  })
  const [assignUserId, setAssignUserId] = useState<number | ''>('')
  const [taskFieldErrors, setTaskFieldErrors] = useState<FieldErrors>({})

  const clearTaskFieldError = (key: string) => {
    setTaskFieldErrors((prev) => {
      if (!prev[key]) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  useEffect(() => {
    setAssetForm((f) => ({ ...f, branch_id: branchId ?? '' }))
    setTaskForm((f) => ({ ...f, branch_id: branchId ?? '' }))
  }, [branchId])

  const assetsQuery = useQuery({
    queryKey: [
      'admin',
      'equipment',
      assetPage,
      assetStatus,
      assetBranch,
      appliedAssetSearch,
    ],
    queryFn: () =>
      fetchEquipmentAssets({
        page: assetPage,
        per_page: DEFAULT_PAGE_SIZE,
        status: assetStatus,
        branch_id: assetBranch,
        search: appliedAssetSearch,
      }),
    enabled: canViewAssets && tab === 'assets',
  })

  const assetOptionsQuery = useQuery({
    queryKey: ['admin', 'equipment', 'options', taskBranch],
    queryFn: () =>
      fetchEquipmentAssets({
        page: 1,
        per_page: 100,
        branch_id: taskBranch,
        status: '',
      }),
    enabled: canViewTasks && (tab === 'tasks' || showTaskForm),
  })

  const statsQuery = useQuery({
    queryKey: ['admin', 'equipment', 'stats', assetBranch],
    queryFn: async () => {
      const [inService, maintenance, openTasks, urgent] = await Promise.all([
        canViewAssets
          ? fetchEquipmentAssets({
              page: 1,
              per_page: 1,
              status: 'in_service',
              branch_id: assetBranch,
            })
          : Promise.resolve({ meta: { total: 0 } }),
        canViewAssets
          ? fetchEquipmentAssets({
              page: 1,
              per_page: 1,
              status: 'under_maintenance',
              branch_id: assetBranch,
            })
          : Promise.resolve({ meta: { total: 0 } }),
        canViewTasks
          ? fetchMaintenanceOrders({
              page: 1,
              per_page: 1,
              status: 'open',
              branch_id: taskBranch,
            })
          : Promise.resolve({ meta: { total: 0 } }),
        canViewTasks
          ? fetchMaintenanceOrders({
              page: 1,
              per_page: 1,
              priority: 'urgent',
              status: 'open',
              branch_id: taskBranch,
            })
          : Promise.resolve({ meta: { total: 0 } }),
      ])
      return {
        inService: inService.meta.total,
        maintenance: maintenance.meta.total,
        openTasks: openTasks.meta.total,
        urgent: urgent.meta.total,
      }
    },
    enabled: canView,
  })

  const selectedAssetQuery = useQuery({
    queryKey: ['admin', 'equipment', 'detail', selectedAssetId],
    queryFn: () => fetchEquipmentAsset(selectedAssetId!),
    enabled: canViewAssets && selectedAssetId != null && tab === 'assets',
  })

  const tasksQuery = useQuery({
    queryKey: [
      'admin',
      'maintenance-orders',
      taskPage,
      taskStatus,
      taskBranch,
      appliedTaskSearch,
    ],
    queryFn: () =>
      fetchMaintenanceOrders({
        page: taskPage,
        per_page: DEFAULT_PAGE_SIZE,
        status: taskStatus,
        branch_id: taskBranch,
        search: appliedTaskSearch,
      }),
    enabled: canViewTasks && tab === 'tasks',
  })

  const selectedTaskQuery = useQuery({
    queryKey: ['admin', 'maintenance-orders', 'detail', selectedTaskId],
    queryFn: () => fetchMaintenanceOrder(selectedTaskId!),
    enabled: canViewTasks && selectedTaskId != null && tab === 'tasks',
  })

  const staffQuery = useQuery({
    queryKey: ['admin', 'staff', 'facility-assignees'],
    queryFn: () => fetchStaff({ page: 1, per_page: 100, is_active: true }),
    enabled:
      canStaff &&
      canViewTasks &&
      (showTaskForm || selectedTaskId != null || canManageTasks),
  })

  const assets = assetsQuery.data?.data ?? []
  const assetOptions = assetOptionsQuery.data?.data ?? []
  const tasks = tasksQuery.data?.data ?? []
  const staff = staffQuery.data?.data ?? []

  const selectedAsset = useMemo(() => {
    if (selectedAssetId == null) return null
    return selectedAssetQuery.data ?? assets.find((a) => a.id === selectedAssetId) ?? null
  }, [selectedAssetId, selectedAssetQuery.data, assets])

  const selectedTask = useMemo(() => {
    if (selectedTaskId == null) return null
    return selectedTaskQuery.data ?? tasks.find((t) => t.id === selectedTaskId) ?? null
  }, [selectedTaskId, selectedTaskQuery.data, tasks])

  const assetNameById = useMemo(() => {
    const map = new Map<number, string>()
    for (const a of [...assets, ...assetOptions]) {
      map.set(a.id, `${a.name} (${a.asset_tag})`)
    }
    return map
  }, [assets, assetOptions])

  useEffect(() => {
    if (selectedTask) {
      setAssignUserId(selectedTask.assigned_user_id ?? '')
    }
  }, [selectedTask?.id])

  const invalidate = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'equipment'] })
    await queryClient.invalidateQueries({ queryKey: ['admin', 'maintenance-orders'] })
  }

  const apiError = (err: unknown, fallback: string) =>
    err instanceof ApiError ? err.message : fallback

  const saveAssetMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        branch_id: Number(assetForm.branch_id),
        asset_tag: assetForm.asset_tag.trim().toUpperCase(),
        name: assetForm.name.trim(),
        category: assetForm.category.trim() || null,
        purchase_date: assetForm.purchase_date || null,
        warranty_ends_on: assetForm.warranty_ends_on || null,
        vendor_name: assetForm.vendor_name.trim() || null,
      }
      if (editingAsset) return updateEquipmentAsset(editingAsset.id, payload)
      return createEquipmentAsset(payload)
    },
    onSuccess: async (asset) => {
      setError(null)
      showSuccess(
        editingAsset ? `Asset “${asset.name}” updated.` : `Asset “${asset.name}” created.`,
      )
      setShowAssetForm(false)
      setEditingAsset(null)
      setAssetForm({ ...emptyAssetForm, branch_id: branchId ?? '' })
      await invalidate()
      setSelectedAssetId(asset.id)
    },
    onError: (err) => setError(apiError(err, 'Unable to save asset.')),
  })

  const deleteAssetMutation = useMutation({
    mutationFn: deleteEquipmentAsset,
    onSuccess: async () => {
      showSuccess('Asset deleted.')
      setSelectedAssetId(null)
      setEditingAsset(null)
      setShowAssetForm(false)
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to delete asset.')),
  })

  const statusAssetMutation = useMutation({
    mutationFn: ({ id, status }: { id: number; status: EquipmentStatus }) =>
      changeEquipmentStatus(id, status),
    onSuccess: async (asset) => {
      showSuccess(`Status set to ${assetStatusLabel(asset.status)}.`)
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to change asset status.')),
  })

  const saveTaskMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        branch_id: Number(taskForm.branch_id),
        equipment_asset_id: taskForm.equipment_asset_id
          ? Number(taskForm.equipment_asset_id)
          : null,
        title: taskForm.title.trim(),
        priority: taskForm.priority,
        assigned_user_id: taskForm.assigned_user_id
          ? Number(taskForm.assigned_user_id)
          : null,
        due_date: taskForm.due_date || null,
        cost_amount: taskForm.cost_amount ? Number(taskForm.cost_amount) : null,
        currency_code: taskForm.currency_code.trim().toUpperCase() || defaultCurrency,
        notes: taskForm.notes.trim() || null,
      }
      if (editingTask) return updateMaintenanceOrder(editingTask.id, payload)
      return createMaintenanceOrder(payload)
    },
    onSuccess: async (order) => {
      setError(null)
      showSuccess(
        editingTask ? `Task “${order.title}” updated.` : `Task “${order.title}” created.`,
      )
      setShowTaskForm(false)
      setEditingTask(null)
      setTaskForm({
        ...emptyTaskForm,
        branch_id: branchId ?? '',
        currency_code: defaultCurrency,
      })
      setTaskStatus('open')
      await invalidate()
      setSelectedTaskId(order.id)
      setTab('tasks')
    },
    onError: (err) => setError(apiError(err, 'Unable to save task.')),
  })

  const deleteTaskMutation = useMutation({
    mutationFn: deleteMaintenanceOrder,
    onSuccess: async () => {
      showSuccess('Task deleted.')
      setSelectedTaskId(null)
      setEditingTask(null)
      setShowTaskForm(false)
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to delete task.')),
  })

  const assignMutation = useMutation({
    mutationFn: () =>
      assignMaintenanceOrder(
        selectedTaskId!,
        assignUserId === '' ? null : Number(assignUserId),
      ),
    onSuccess: async () => {
      showSuccess('Assignee updated.')
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to assign task.')),
  })

  const startMutation = useMutation({
    mutationFn: startMaintenanceOrder,
    onSuccess: async () => {
      showSuccess('Task started.')
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to start task.')),
  })

  const completeMutation = useMutation({
    mutationFn: completeMaintenanceOrder,
    onSuccess: async () => {
      showSuccess('Task completed.')
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to complete task.')),
  })

  const cancelMutation = useMutation({
    mutationFn: cancelMaintenanceOrder,
    onSuccess: async () => {
      showSuccess('Task cancelled.')
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to cancel task.')),
  })

  const ownMutation = useMutation({
    mutationFn: (status: 'in_progress' | 'done') =>
      updateOwnMaintenanceOrder(selectedTaskId!, { status }),
    onSuccess: async (_, status) => {
      showSuccess(status === 'done' ? 'Marked done.' : 'Marked in progress.')
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to update your task.')),
  })

  const openCreateAsset = () => {
    setEditingAsset(null)
    setAssetForm({ ...emptyAssetForm, branch_id: branchId ?? '' })
    setShowAssetForm(true)
    setError(null)
    setAssetFieldErrors({})
  }

  const openEditAsset = (asset: EquipmentAsset) => {
    setEditingAsset(asset)
    setAssetForm({
      branch_id: asset.branch_id,
      asset_tag: asset.asset_tag,
      name: asset.name,
      category: asset.category ?? '',
      purchase_date: asset.purchase_date ?? '',
      warranty_ends_on: asset.warranty_ends_on ?? '',
      vendor_name: asset.vendor_name ?? '',
    })
    setShowAssetForm(true)
    setSelectedAssetId(asset.id)
    setError(null)
    setAssetFieldErrors({})
  }

  const openCreateTask = (prefillAssetId?: number) => {
    setEditingTask(null)
    setTaskForm({
      ...emptyTaskForm,
      branch_id: branchId ?? '',
      currency_code: defaultCurrency,
      equipment_asset_id: prefillAssetId ?? '',
    })
    setShowTaskForm(true)
    setTab('tasks')
    setError(null)
    setTaskFieldErrors({})
  }

  const openEditTask = (task: MaintenanceOrder) => {
    setEditingTask(task)
    setTaskForm({
      branch_id: task.branch_id,
      equipment_asset_id: task.equipment_asset_id ?? '',
      title: task.title,
      priority: task.priority,
      assigned_user_id: task.assigned_user_id ?? '',
      due_date: task.due_date ?? '',
      cost_amount: task.cost_amount != null ? String(task.cost_amount) : '',
      currency_code: task.currency_code || defaultCurrency,
      notes: task.notes ?? '',
    })
    setShowTaskForm(true)
    setSelectedTaskId(task.id)
    setError(null)
    setTaskFieldErrors({})
  }

  const onSaveAsset = (event: FormEvent) => {
    event.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'branch_id', label: 'Branch', value: assetForm.branch_id },
      { key: 'asset_tag', label: 'Asset tag', value: assetForm.asset_tag },
      { key: 'name', label: 'Name', value: assetForm.name },
    ])
    if (Object.keys(errors).length > 0) {
      setAssetFieldErrors(errors)
      return
    }
    setAssetFieldErrors({})
    saveAssetMutation.mutate()
  }

  const onSaveTask = (event: FormEvent) => {
    event.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'branch_id', label: 'Branch', value: taskForm.branch_id },
      { key: 'title', label: 'Title', value: taskForm.title },
    ])
    if (Object.keys(errors).length > 0) {
      setTaskFieldErrors(errors)
      return
    }
    setTaskFieldErrors({})
    saveTaskMutation.mutate()
  }

  const onDeleteAsset = async (asset: EquipmentAsset) => {
    const ok = await confirm({
      title: 'Delete asset?',
      message: `Delete “${asset.name}” (${asset.asset_tag})?`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (!ok) return
    deleteAssetMutation.mutate(asset.id)
  }

  const onDeleteTask = async (task: MaintenanceOrder) => {
    const ok = await confirm({
      title: 'Delete task?',
      message: `Delete “${task.title}”?`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (!ok) return
    deleteTaskMutation.mutate(task.id)
  }

  const isAssignee =
    selectedTask != null && user?.id != null && selectedTask.assigned_user_id === user.id

  const assetColumns: Column<EquipmentAsset>[] = [
    {
      key: 'asset',
      header: 'Asset',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedAssetId(row.id)}
        >
          <p className="font-semibold text-ink">{row.name}</p>
          <p className="mt-0.5 font-mono text-xs text-muted">{row.asset_tag}</p>
        </button>
      ),
    },
    {
      key: 'category',
      header: 'Category',
      cell: (row) => <span className="text-sm text-muted">{row.category || '—'}</span>,
    },
    {
      key: 'branch',
      header: 'Branch',
      cell: (row) => <span className="text-sm text-ink">{row.branch?.name ?? '—'}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={assetStatusTone(row.status)}>{assetStatusLabel(row.status)}</Badge>
      ),
    },
    {
      key: 'vendor',
      header: 'Vendor',
      cell: (row) => <span className="text-sm text-muted">{row.vendor_name || '—'}</span>,
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedAssetId(row.id)}>
          Manage
        </Button>
      ),
    },
  ]

  const taskColumns: Column<MaintenanceOrder>[] = [
    {
      key: 'task',
      header: 'Task',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedTaskId(row.id)}
        >
          <p className="font-semibold text-ink">{row.title}</p>
          <p className="mt-0.5 text-xs text-muted">
            {row.equipment_asset_id
              ? assetNameById.get(row.equipment_asset_id) || `Asset #${row.equipment_asset_id}`
              : 'No linked asset'}
          </p>
        </button>
      ),
    },
    {
      key: 'priority',
      header: 'Priority',
      cell: (row) => <Badge tone={priorityTone(row.priority)}>{row.priority}</Badge>,
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={taskStatusTone(row.status)}>
          {row.status === 'in_progress' ? 'In progress' : row.status}
        </Badge>
      ),
    },
    {
      key: 'assignee',
      header: 'Assignee',
      cell: (row) => (
        <span className="text-sm text-muted">{row.assigned_user?.name ?? 'Unassigned'}</span>
      ),
    },
    {
      key: 'due',
      header: 'Due',
      cell: (row) => <span className="text-sm text-ink">{formatDate(row.due_date)}</span>,
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedTaskId(row.id)}>
          Manage
        </Button>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader title="Equipment" description="Assets and facility tasks." />
        <Alert tone="danger">You do not have permission to view equipment or facility tasks.</Alert>
      </div>
    )
  }

  const stats = statsQuery.data

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Equipment"
        description="Assets and facility tasks — inventory, maintenance, and work orders."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">Gym</Badge>
            {canManageAssets && tab === 'assets' ? (
              <Button size="sm" onClick={openCreateAsset}>
                <Plus className="h-4 w-4" />
                New asset
              </Button>
            ) : null}
            {canManageTasks && tab === 'tasks' ? (
              <Button size="sm" onClick={() => openCreateTask()}>
                <Plus className="h-4 w-4" />
                New task
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<Wrench className="h-4 w-4" />}
          label="In service"
          value={formatNumber(stats?.inService ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<Wrench className="h-4 w-4" />}
          label="Under maintenance"
          value={formatNumber(stats?.maintenance ?? 0)}
        />
        <SummaryChip
          icon={<ClipboardList className="h-4 w-4" />}
          label="Open tasks"
          value={formatNumber(stats?.openTasks ?? 0)}
        />
        <SummaryChip
          icon={<CheckCircle2 className="h-4 w-4" />}
          label="Urgent open"
          value={formatNumber(stats?.urgent ?? 0)}
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {canViewAssets ? (
          <button
            type="button"
            onClick={() => {
              setTab('assets')
              setError(null)
              setShowTaskForm(false)
              setSelectedTaskId(null)
            }}
            className={cn(
              'rounded-xl px-3 py-2 text-sm font-semibold transition',
              tab === 'assets'
                ? 'bg-accent text-accent-ink'
                : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
            )}
          >
            Assets
          </button>
        ) : null}
        {canViewTasks ? (
          <button
            type="button"
            onClick={() => {
              setTab('tasks')
              setError(null)
              setShowAssetForm(false)
              setSelectedAssetId(null)
            }}
            className={cn(
              'rounded-xl px-3 py-2 text-sm font-semibold transition',
              tab === 'tasks'
                ? 'bg-accent text-accent-ink'
                : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
            )}
          >
            Facility tasks
          </button>
        ) : null}
      </div>

      {tab === 'assets' && canViewAssets ? (
        <>
          {showAssetForm && canManageAssets ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>{editingAsset ? 'Edit asset' : 'Add equipment asset'}</CardTitle>
                  <CardDescription>
                    Track gym equipment with tags, warranty, and service status.
                  </CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setShowAssetForm(false)
                    setEditingAsset(null)
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form noValidate onSubmit={onSaveAsset} className="grid gap-3 sm:grid-cols-2">
                <Field
                  label="Branch"
                  htmlFor="asset-branch"
                  required
                  error={assetFieldErrors.branch_id}
                >
                  <Select
                    id="asset-branch"
                    value={assetForm.branch_id === '' ? '' : String(assetForm.branch_id)}
                    onChange={(e) => {
                      clearAssetFieldError('branch_id')
                      setAssetForm((f) => ({
                        ...f,
                        branch_id: e.target.value ? Number(e.target.value) : '',
                      }))
                    }}
                    required
                    aria-invalid={Boolean(assetFieldErrors.branch_id)}
                  >
                    <option value="">Select…</option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field
                  label="Asset tag"
                  htmlFor="asset-tag"
                  required
                  error={assetFieldErrors.asset_tag}
                >
                  <Input
                    id="asset-tag"
                    value={assetForm.asset_tag}
                    onChange={(e) => {
                      clearAssetFieldError('asset_tag')
                      setAssetForm((f) => ({
                        ...f,
                        asset_tag: e.target.value.toUpperCase(),
                      }))
                    }}
                    className="font-mono"
                    placeholder="EQ-001"
                    required
                    aria-invalid={Boolean(assetFieldErrors.asset_tag)}
                  />
                </Field>
                <Field
                  label="Name"
                  htmlFor="asset-name"
                  required
                  error={assetFieldErrors.name}
                  className="sm:col-span-2"
                >
                  <Input
                    id="asset-name"
                    value={assetForm.name}
                    onChange={(e) => {
                      clearAssetFieldError('name')
                      setAssetForm((f) => ({ ...f, name: e.target.value }))
                    }}
                    required
                    aria-invalid={Boolean(assetFieldErrors.name)}
                  />
                </Field>
                <Field label="Category" htmlFor="asset-category">
                  <Input
                    id="asset-category"
                    value={assetForm.category}
                    onChange={(e) =>
                      setAssetForm((f) => ({ ...f, category: e.target.value }))
                    }
                    placeholder="Cardio, strength…"
                  />
                </Field>
                <Field label="Vendor" htmlFor="asset-vendor">
                  <Input
                    id="asset-vendor"
                    value={assetForm.vendor_name}
                    onChange={(e) =>
                      setAssetForm((f) => ({ ...f, vendor_name: e.target.value }))
                    }
                  />
                </Field>
                <Field label="Purchase date" htmlFor="asset-purchase-date">
                  <Input
                    id="asset-purchase-date"
                    type="date"
                    value={assetForm.purchase_date}
                    onChange={(e) =>
                      setAssetForm((f) => ({ ...f, purchase_date: e.target.value }))
                    }
                  />
                </Field>
                <Field label="Warranty ends" htmlFor="asset-warranty">
                  <Input
                    id="asset-warranty"
                    type="date"
                    value={assetForm.warranty_ends_on}
                    onChange={(e) =>
                      setAssetForm((f) => ({ ...f, warranty_ends_on: e.target.value }))
                    }
                  />
                </Field>
                <div className="flex flex-wrap gap-2 sm:col-span-2">
                  <Button type="submit" loading={saveAssetMutation.isPending}>
                    {editingAsset ? 'Save asset' : 'Create asset'}
                  </Button>
                  {editingAsset ? (
                    <Button
                      type="button"
                      variant="ghost"
                      className="text-danger"
                      loading={deleteAssetMutation.isPending}
                      onClick={() => void onDeleteAsset(editingAsset)}
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete
                    </Button>
                  ) : null}
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => {
                      setShowAssetForm(false)
                      setEditingAsset(null)
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          <Card>
            <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
              <div className="flex flex-wrap gap-2">
                {(
                  [
                    { value: '' as const, label: 'All' },
                    { value: 'in_service' as const, label: 'In service' },
                    { value: 'under_maintenance' as const, label: 'Maintenance' },
                    { value: 'retired' as const, label: 'Retired' },
                  ] as const
                ).map((filter) => (
                  <button
                    key={filter.label}
                    type="button"
                    onClick={() => {
                      setAssetStatus(filter.value)
                      setAssetPage(1)
                      setSelectedAssetId(null)
                    }}
                    className={cn(
                      'rounded-xl px-3 py-2 text-sm font-semibold transition',
                      assetStatus === filter.value
                        ? 'bg-accent text-accent-ink'
                        : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                    )}
                  >
                    {filter.label}
                  </button>
                ))}
              </div>
              <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
                <div>
                  <Label>Branch</Label>
                  <Select
                    value={assetBranch === '' ? '' : String(assetBranch)}
                    onChange={(e) => {
                      setAssetBranch(e.target.value ? Number(e.target.value) : '')
                      setAssetPage(1)
                    }}
                    className="sm:w-40"
                  >
                    <option value="">All</option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </Select>
                </div>
                <div className="relative min-w-[12rem]">
                  <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
                  <Input
                    value={assetSearch}
                    onChange={(e) => setAssetSearch(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        setAppliedAssetSearch(assetSearch.trim())
                        setAssetPage(1)
                      }
                    }}
                    placeholder="Search assets…"
                    className="pl-10"
                  />
                </div>
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    setAppliedAssetSearch(assetSearch.trim())
                    setAssetPage(1)
                  }}
                >
                  Search
                </Button>
              </div>
            </div>
          </Card>

          <div
            className={cn(
              'grid gap-4',
              selectedAssetId != null && !showAssetForm ? 'xl:grid-cols-[1fr_26rem]' : '',
            )}
          >
            <div className="min-w-0">
              {assetsQuery.isPending ? (
                <div className="flex justify-center py-20">
                  <Spinner label="Loading assets…" />
                </div>
              ) : (
                <>
                  <DataTable
                    columns={assetColumns}
                    rows={assets}
                    rowKey={(row) => row.id}
                    emptyTitle="No assets"
                    emptyDescription="Add equipment assets to track inventory and maintenance."
                  />
                  <Pagination
                    meta={assetsQuery.data?.meta}
                    onPageChange={(p) => {
                      setAssetPage(p)
                      setSelectedAssetId(null)
                    }}
                  />
                </>
              )}
            </div>

            {selectedAsset && !showAssetForm ? (
              <aside className="animate-slide-in">
                <Card className="sticky top-4 space-y-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                        <Wrench className="h-5 w-5" />
                      </div>
                      <CardTitle className="text-base">{selectedAsset.name}</CardTitle>
                      <CardDescription className="font-mono">
                        {selectedAsset.asset_tag}
                      </CardDescription>
                    </div>
                    <Button size="sm" variant="ghost" onClick={() => setSelectedAssetId(null)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  <Badge tone={assetStatusTone(selectedAsset.status)}>
                    {assetStatusLabel(selectedAsset.status)}
                  </Badge>
                  <dl className="space-y-2 text-sm">
                    <DetailRow label="Branch" value={selectedAsset.branch?.name ?? '—'} />
                    <DetailRow label="Category" value={selectedAsset.category || '—'} />
                    <DetailRow label="Vendor" value={selectedAsset.vendor_name || '—'} />
                    <DetailRow label="Purchased" value={formatDate(selectedAsset.purchase_date)} />
                    <DetailRow
                      label="Warranty"
                      value={formatDate(selectedAsset.warranty_ends_on)}
                    />
                  </dl>

                  {canManageAssets ? (
                    <div className="space-y-3 border-t border-white/12 pt-4">
                      <Label>Change status</Label>
                      <Select
                        value={selectedAsset.status}
                        onChange={(e) =>
                          statusAssetMutation.mutate({
                            id: selectedAsset.id,
                            status: e.target.value as EquipmentStatus,
                          })
                        }
                      >
                        <option value="in_service">In service</option>
                        <option value="under_maintenance">Under maintenance</option>
                        <option value="retired">Retired</option>
                      </Select>
                      <div className="flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => openEditAsset(selectedAsset)}
                        >
                          Edit
                        </Button>
                        {canManageTasks ? (
                          <Button
                            size="sm"
                            onClick={() => openCreateTask(selectedAsset.id)}
                          >
                            Create task
                          </Button>
                        ) : null}
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-danger"
                          loading={deleteAssetMutation.isPending}
                          onClick={() => void onDeleteAsset(selectedAsset)}
                        >
                          <Trash2 className="h-4 w-4" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  ) : null}
                </Card>
              </aside>
            ) : null}
          </div>
        </>
      ) : null}

      {tab === 'tasks' && canViewTasks ? (
        <>
          {showTaskForm && canManageTasks ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>
                    {editingTask ? 'Edit facility task' : 'Create facility task'}
                  </CardTitle>
                  <CardDescription>
                    Work orders for repairs, inspections, and facility upkeep.
                  </CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setShowTaskForm(false)
                    setEditingTask(null)
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form noValidate onSubmit={onSaveTask} className="grid gap-3 sm:grid-cols-2">
                <Field
                  label="Title"
                  htmlFor="task-title"
                  required
                  error={taskFieldErrors.title}
                  className="sm:col-span-2"
                >
                  <Input
                    id="task-title"
                    value={taskForm.title}
                    onChange={(e) => {
                      clearTaskFieldError('title')
                      setTaskForm((f) => ({ ...f, title: e.target.value }))
                    }}
                    required
                    aria-invalid={Boolean(taskFieldErrors.title)}
                  />
                </Field>
                <Field
                  label="Branch"
                  htmlFor="task-branch"
                  required
                  error={taskFieldErrors.branch_id}
                >
                  <Select
                    id="task-branch"
                    value={taskForm.branch_id === '' ? '' : String(taskForm.branch_id)}
                    onChange={(e) => {
                      clearTaskFieldError('branch_id')
                      setTaskForm((f) => ({
                        ...f,
                        branch_id: e.target.value ? Number(e.target.value) : '',
                      }))
                    }}
                    required
                    aria-invalid={Boolean(taskFieldErrors.branch_id)}
                  >
                    <option value="">Select…</option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </Select>
                </Field>
                <div>
                  <Label>Priority</Label>
                  <Select
                    value={taskForm.priority}
                    onChange={(e) =>
                      setTaskForm((f) => ({
                        ...f,
                        priority: e.target.value as MaintenancePriority,
                      }))
                    }
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </Select>
                </div>
                <div>
                  <Label>Linked asset (optional)</Label>
                  <Select
                    value={
                      taskForm.equipment_asset_id === ''
                        ? ''
                        : String(taskForm.equipment_asset_id)
                    }
                    onChange={(e) =>
                      setTaskForm((f) => ({
                        ...f,
                        equipment_asset_id: e.target.value ? Number(e.target.value) : '',
                      }))
                    }
                  >
                    <option value="">None</option>
                    {assetOptions.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.name} ({a.asset_tag})
                      </option>
                    ))}
                  </Select>
                </div>
                <div>
                  <Label>Assignee (optional)</Label>
                  <Select
                    value={
                      taskForm.assigned_user_id === ''
                        ? ''
                        : String(taskForm.assigned_user_id)
                    }
                    onChange={(e) =>
                      setTaskForm((f) => ({
                        ...f,
                        assigned_user_id: e.target.value ? Number(e.target.value) : '',
                      }))
                    }
                  >
                    <option value="">Unassigned</option>
                    {staff.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </Select>
                </div>
                <div>
                  <Label>Due date</Label>
                  <Input
                    type="date"
                    value={taskForm.due_date}
                    onChange={(e) =>
                      setTaskForm((f) => ({ ...f, due_date: e.target.value }))
                    }
                  />
                </div>
                <div>
                  <Label>Cost</Label>
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    value={taskForm.cost_amount}
                    onChange={(e) =>
                      setTaskForm((f) => ({ ...f, cost_amount: e.target.value }))
                    }
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label>Notes</Label>
                  <Textarea
                    value={taskForm.notes}
                    onChange={(e) => setTaskForm((f) => ({ ...f, notes: e.target.value }))}
                    rows={2}
                  />
                </div>
                <div className="flex flex-wrap gap-2 sm:col-span-2">
                  <Button type="submit" loading={saveTaskMutation.isPending}>
                    {editingTask ? 'Save task' : 'Create task'}
                  </Button>
                  {editingTask ? (
                    <Button
                      type="button"
                      variant="ghost"
                      className="text-danger"
                      loading={deleteTaskMutation.isPending}
                      onClick={() => void onDeleteTask(editingTask)}
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete
                    </Button>
                  ) : null}
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => {
                      setShowTaskForm(false)
                      setEditingTask(null)
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          <Card>
            <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
              <div className="flex flex-wrap gap-2">
                {(
                  [
                    { value: '' as const, label: 'All' },
                    { value: 'open' as const, label: 'Open' },
                    { value: 'in_progress' as const, label: 'In progress' },
                    { value: 'done' as const, label: 'Done' },
                    { value: 'cancelled' as const, label: 'Cancelled' },
                  ] as const
                ).map((filter) => (
                  <button
                    key={filter.label}
                    type="button"
                    onClick={() => {
                      setTaskStatus(filter.value)
                      setTaskPage(1)
                      setSelectedTaskId(null)
                    }}
                    className={cn(
                      'rounded-xl px-3 py-2 text-sm font-semibold transition',
                      taskStatus === filter.value
                        ? 'bg-accent text-accent-ink'
                        : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                    )}
                  >
                    {filter.label}
                  </button>
                ))}
              </div>
              <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
                <div>
                  <Label>Branch</Label>
                  <Select
                    value={taskBranch === '' ? '' : String(taskBranch)}
                    onChange={(e) => {
                      setTaskBranch(e.target.value ? Number(e.target.value) : '')
                      setTaskPage(1)
                    }}
                    className="sm:w-40"
                  >
                    <option value="">All</option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </Select>
                </div>
                <div className="relative min-w-[12rem]">
                  <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
                  <Input
                    value={taskSearch}
                    onChange={(e) => setTaskSearch(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        setAppliedTaskSearch(taskSearch.trim())
                        setTaskPage(1)
                      }
                    }}
                    placeholder="Search tasks…"
                    className="pl-10"
                  />
                </div>
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    setAppliedTaskSearch(taskSearch.trim())
                    setTaskPage(1)
                  }}
                >
                  Search
                </Button>
              </div>
            </div>
          </Card>

          <div
            className={cn(
              'grid gap-4',
              selectedTaskId != null && !showTaskForm ? 'xl:grid-cols-[1fr_26rem]' : '',
            )}
          >
            <div className="min-w-0">
              {tasksQuery.isPending ? (
                <div className="flex justify-center py-20">
                  <Spinner label="Loading tasks…" />
                </div>
              ) : (
                <>
                  <DataTable
                    columns={taskColumns}
                    rows={tasks}
                    rowKey={(row) => row.id}
                    emptyTitle="No facility tasks"
                    emptyDescription="Create a maintenance or facility work order."
                  />
                  <Pagination
                    meta={tasksQuery.data?.meta}
                    onPageChange={(p) => {
                      setTaskPage(p)
                      setSelectedTaskId(null)
                    }}
                  />
                </>
              )}
            </div>

            {selectedTask && !showTaskForm ? (
              <aside className="animate-slide-in">
                <Card className="sticky top-4 max-h-[calc(100vh-6rem)] space-y-4 overflow-y-auto">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                        <ClipboardList className="h-5 w-5" />
                      </div>
                      <CardTitle className="text-base">{selectedTask.title}</CardTitle>
                      <CardDescription>
                        {selectedTask.branch?.name ?? 'Facility task'}
                      </CardDescription>
                    </div>
                    <Button size="sm" variant="ghost" onClick={() => setSelectedTaskId(null)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Badge tone={taskStatusTone(selectedTask.status)}>
                      {selectedTask.status === 'in_progress'
                        ? 'In progress'
                        : selectedTask.status}
                    </Badge>
                    <Badge tone={priorityTone(selectedTask.priority)}>
                      {selectedTask.priority}
                    </Badge>
                  </div>
                  <dl className="space-y-2 text-sm">
                    <DetailRow
                      label="Asset"
                      value={
                        selectedTask.equipment_asset_id
                          ? assetNameById.get(selectedTask.equipment_asset_id) ||
                            `#${selectedTask.equipment_asset_id}`
                          : '—'
                      }
                    />
                    <DetailRow
                      label="Assignee"
                      value={selectedTask.assigned_user?.name ?? 'Unassigned'}
                    />
                    <DetailRow label="Due" value={formatDate(selectedTask.due_date)} />
                    <DetailRow
                      label="Cost"
                      value={
                        selectedTask.cost_amount != null
                          ? formatMoney(
                              selectedTask.cost_amount,
                              selectedTask.currency_code || defaultCurrency,
                            )
                          : '—'
                      }
                    />
                    <DetailRow
                      label="Completed"
                      value={formatDate(selectedTask.completed_at)}
                    />
                  </dl>
                  {selectedTask.notes ? (
                    <p className="text-sm text-muted">{selectedTask.notes}</p>
                  ) : null}

                  {canManageTasks &&
                  selectedTask.status !== 'done' &&
                  selectedTask.status !== 'cancelled' ? (
                    <div className="space-y-3 border-t border-white/12 pt-4">
                      <Label>Assignee</Label>
                      <div className="flex gap-2">
                        <Select
                          value={assignUserId === '' ? '' : String(assignUserId)}
                          onChange={(e) =>
                            setAssignUserId(e.target.value ? Number(e.target.value) : '')
                          }
                          className="flex-1"
                        >
                          <option value="">Unassigned</option>
                          {staff.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.name}
                            </option>
                          ))}
                        </Select>
                        <Button
                          size="sm"
                          variant="secondary"
                          loading={assignMutation.isPending}
                          onClick={() => assignMutation.mutate()}
                        >
                          Save
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {selectedTask.status === 'open' ? (
                          <Button
                            size="sm"
                            loading={startMutation.isPending}
                            onClick={() => startMutation.mutate(selectedTask.id)}
                          >
                            Start
                          </Button>
                        ) : null}
                        {selectedTask.status === 'in_progress' ? (
                          <Button
                            size="sm"
                            loading={completeMutation.isPending}
                            onClick={() => completeMutation.mutate(selectedTask.id)}
                          >
                            Complete
                          </Button>
                        ) : null}
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => openEditTask(selectedTask)}
                        >
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="danger"
                          loading={cancelMutation.isPending}
                          onClick={() => cancelMutation.mutate(selectedTask.id)}
                        >
                          Cancel
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-danger"
                          loading={deleteTaskMutation.isPending}
                          onClick={() => void onDeleteTask(selectedTask)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ) : null}

                  {canUpdateOwn &&
                  isAssignee &&
                  (selectedTask.status === 'open' ||
                    selectedTask.status === 'in_progress') ? (
                    <div className="space-y-2 border-t border-white/12 pt-4">
                      <p className="text-sm font-semibold text-ink">My task actions</p>
                      <div className="flex flex-wrap gap-2">
                        {selectedTask.status === 'open' ? (
                          <Button
                            size="sm"
                            variant="secondary"
                            loading={ownMutation.isPending}
                            onClick={() => ownMutation.mutate('in_progress')}
                          >
                            Start my task
                          </Button>
                        ) : null}
                        {selectedTask.status === 'in_progress' ? (
                          <Button
                            size="sm"
                            loading={ownMutation.isPending}
                            onClick={() => ownMutation.mutate('done')}
                          >
                            Mark done
                          </Button>
                        ) : null}
                      </div>
                    </div>
                  ) : null}
                </Card>
              </aside>
            ) : null}
          </div>
        </>
      ) : null}
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="shrink-0 text-muted">{label}</dt>
      <dd className="text-right font-semibold text-ink">{value}</dd>
    </div>
  )
}
