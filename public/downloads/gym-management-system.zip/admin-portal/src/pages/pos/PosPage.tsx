import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Minus,
  Plus,
  Printer,
  Search,
  ShoppingCart,
  Trash2,
  X,
} from 'lucide-react'
import {
  createSale,
  fetchProductStock,
  fetchProducts,
  fetchSale,
  fetchSales,
  voidSale,
  type Product,
  type Sale,
  type SaleStatus,
} from '@/api/pos'
import { fetchMembers } from '@/api/members'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useBranchFilter } from '@/hooks/useBranchFilter'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatMoney, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { printSaleReceipt } from '@/pages/pos/printSale'

type PageTab = 'checkout' | 'history'

type CartLine = {
  key: string
  product_id: number | null
  sku?: string
  description: string
  quantity: number
  unit_price: number
  discount_amount: number
  tax_amount: number
  stock?: number | null
}

function toNum(value: string | number | null | undefined) {
  const n = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(n) ? n : 0
}

function lineTotal(line: CartLine) {
  return Math.max(
    0,
    line.quantity * line.unit_price - line.discount_amount + line.tax_amount,
  )
}

function memberLabel(m?: {
  first_name?: string
  last_name?: string
  member_code?: string
  full_name?: string
} | null) {
  if (!m) return '—'
  if (m.full_name) {
    return m.member_code ? `${m.full_name} (${m.member_code})` : m.full_name
  }
  const name = `${m.first_name ?? ''} ${m.last_name ?? ''}`.trim()
  return name ? `${name}${m.member_code ? ` (${m.member_code})` : ''}` : m.member_code || '—'
}

export function PosPage() {
  const { branches, tenant, hasPermission, user } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canViewSales = hasPermission('pos.sales.view')
  const canCreateSales = hasPermission('pos.sales.create')
  const canViewInventory = hasPermission('pos.inventory.view')
  const canViewMembers = hasPermission('members.view')
  const canView = canViewSales

  const defaultCurrency = tenant?.base_currency || 'INR'
  const gymName = tenant?.name || 'Gym'
  const gymSlug = tenant?.slug

  const [tab, setTab] = useState<PageTab>('checkout')
  const [error, setError] = useState<string | null>(null)
  const [checkoutFieldErrors, setCheckoutFieldErrors] = useState<FieldErrors>({})
  const [adhocFieldErrors, setAdhocFieldErrors] = useState<FieldErrors>({})

  const clearCheckoutFieldError = (key: string) => {
    setCheckoutFieldErrors((prev) => {
      if (!prev[key]) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  const clearAdhocFieldError = (key: string) => {
    setAdhocFieldErrors((prev) => {
      if (!prev[key]) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  // Checkout
  const [checkoutBranch, setCheckoutBranch] = useBranchFilter()
  const [productSearch, setProductSearch] = useState('')
  const [appliedProductSearch, setAppliedProductSearch] = useState('')
  const [cart, setCart] = useState<CartLine[]>([])
  const [memberId, setMemberId] = useState<number | ''>('')
  const [memberSearch, setMemberSearch] = useState('')
  const [couponCode, setCouponCode] = useState('')
  const [createInvoice, setCreateInvoice] = useState(false)
  const [showAdhoc, setShowAdhoc] = useState(false)
  const [adhocDesc, setAdhocDesc] = useState('')
  const [adhocPrice, setAdhocPrice] = useState('')
  const [adhocQty, setAdhocQty] = useState('1')
  const [lastSale, setLastSale] = useState<Sale | null>(null)

  // History
  const [salePage, setSalePage] = useState(1)
  const [saleStatus, setSaleStatus] = useState<'' | SaleStatus>('')
  const [saleBranch, setSaleBranch] = useBranchFilter()
  const [selectedSaleId, setSelectedSaleId] = useState<number | null>(null)

  const errMsg = (err: unknown, fallback: string) => {
    if (err instanceof ApiError) return err.message
    if (err instanceof Error && err.message) return err.message
    return fallback
  }

  const productsQuery = useQuery({
    queryKey: ['admin', 'products', 'pos', appliedProductSearch],
    queryFn: () =>
      fetchProducts({
        page: 1,
        per_page: 24,
        search: appliedProductSearch,
        is_active: true,
      }),
    enabled: canViewInventory && tab === 'checkout',
  })

  const products = productsQuery.data?.data ?? []

  const stockQuery = useQuery({
    queryKey: [
      'admin',
      'product-stock-map',
      checkoutBranch,
      products.map((p) => p.id).join(','),
    ],
    queryFn: async () => {
      const entries = await Promise.all(
        products.map(async (p) => {
          const stocks = await fetchProductStock(p.id)
          const atBranch = stocks.find((s) => s.branch_id === Number(checkoutBranch))
          return [p.id, atBranch?.quantity ?? 0] as const
        }),
      )
      return Object.fromEntries(entries) as Record<number, number>
    },
    enabled:
      canViewInventory &&
      tab === 'checkout' &&
      checkoutBranch !== '' &&
      products.length > 0,
  })

  const stockMap = stockQuery.data ?? {}

  useEffect(() => {
    if (!stockQuery.data) return
    setCart((rows) =>
      rows.map((r) =>
        r.product_id != null && stockQuery.data[r.product_id] != null
          ? { ...r, stock: stockQuery.data[r.product_id] }
          : r,
      ),
    )
  }, [stockQuery.data])

  const membersQuery = useQuery({
    queryKey: ['admin', 'members', 'pos-picker', memberSearch],
    queryFn: () =>
      fetchMembers({
        page: 1,
        per_page: 20,
        search: memberSearch || undefined,
        status: 'active',
      }),
    enabled: canViewMembers && tab === 'checkout',
  })

  const statsQuery = useQuery({
    queryKey: ['admin', 'pos-stats'],
    queryFn: async () => {
      const [completed, voided, all] = await Promise.all([
        fetchSales({ page: 1, per_page: 1, status: 'completed' }),
        fetchSales({ page: 1, per_page: 1, status: 'void' }),
        fetchSales({ page: 1, per_page: 1 }),
      ])
      return {
        completed: completed.meta.total,
        voided: voided.meta.total,
        all: all.meta.total,
      }
    },
    enabled: canViewSales,
  })

  const salesQuery = useQuery({
    queryKey: ['admin', 'sales', salePage, saleStatus, saleBranch],
    queryFn: () =>
      fetchSales({
        page: salePage,
        per_page: DEFAULT_PAGE_SIZE,
        status: saleStatus,
        branch_id: saleBranch,
      }),
    enabled: canViewSales && tab === 'history',
  })

  const saleDetailQuery = useQuery({
    queryKey: ['admin', 'sales', selectedSaleId],
    queryFn: () => fetchSale(selectedSaleId!),
    enabled: canViewSales && selectedSaleId != null && tab === 'history',
  })

  const cartTotals = useMemo(() => {
    const subtotal = cart.reduce((s, l) => s + l.quantity * l.unit_price, 0)
    const discount = cart.reduce((s, l) => s + l.discount_amount, 0)
    const tax = cart.reduce((s, l) => s + l.tax_amount, 0)
    const grand = cart.reduce((s, l) => s + lineTotal(l), 0)
    const items = cart.reduce((s, l) => s + l.quantity, 0)
    return { subtotal, discount, tax, grand, items }
  }, [cart])

  const invalidatePos = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['admin', 'sales'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'pos-stats'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'product-stock-map'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'products'] }),
    ])
  }

  const completeSaleMutation = useMutation({
    mutationFn: async () => {
      for (const line of cart) {
        if (line.product_id != null && line.stock != null && line.quantity > line.stock) {
          throw new Error(`Insufficient stock for ${line.description}.`)
        }
      }
      return createSale({
        branch_id: Number(checkoutBranch),
        member_id: memberId === '' ? null : Number(memberId),
        currency_code: defaultCurrency,
        create_invoice: createInvoice,
        coupon_code: couponCode.trim() || null,
        items: cart.map((line) => ({
          product_id: line.product_id,
          description: line.description,
          quantity: line.quantity,
          unit_price: line.unit_price,
          discount_amount: line.discount_amount,
          tax_amount: line.tax_amount,
        })),
      })
    },
    onSuccess: async (sale) => {
      showSuccess(`Sale #${sale.id} completed · ${formatMoney(sale.grand_total, sale.currency_code)}`)
      setCouponCode('')
      setLastSale(sale)
      setCart([])
      setMemberId('')
      setCreateInvoice(false)
      setError(null)
      await invalidatePos()
    },
    onError: (err) => setError(errMsg(err, 'Could not complete sale.')),
  })

  const voidMutation = useMutation({
    mutationFn: ({ id, reason }: { id: number; reason?: string }) => voidSale(id, reason),
    onSuccess: async (sale) => {
      showSuccess(`Sale #${sale.id} voided. Stock restored.`)
      await invalidatePos()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'sales', sale.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not void sale.')),
  })

  const addProduct = (product: Product) => {
    const stock = stockMap[product.id]
    const stockQty = stock ?? null
    if (stockQty != null && stockQty <= 0) {
      setError(`${product.name} is out of stock at this branch.`)
      return
    }
    setError(null)
    setCheckoutFieldErrors((prev) => {
      if (!prev.cart) return prev
      const next = { ...prev }
      delete next.cart
      return next
    })
    setCart((rows) => {
      const existing = rows.find((r) => r.product_id === product.id)
      if (existing) {
        const nextQty = existing.quantity + 1
        if (stockQty != null && nextQty > stockQty) {
          setError(`Only ${stockQty} in stock for ${product.name}.`)
          return rows
        }
        return rows.map((r) =>
          r.key === existing.key
            ? { ...r, quantity: nextQty, stock: stockQty }
            : r,
        )
      }
      return [
        ...rows,
        {
          key: `p-${product.id}`,
          product_id: product.id,
          sku: product.sku,
          description: product.name,
          quantity: 1,
          unit_price: toNum(product.unit_price),
          discount_amount: 0,
          tax_amount: 0,
          stock: stockQty,
        },
      ]
    })
  }

  const onCompleteSale = () => {
    const errors = collectRequiredErrors([
      { key: 'branch_id', label: 'Branch', value: checkoutBranch },
    ])
    if (cart.length === 0) {
      errors.cart = 'Add at least one item to the cart.'
    }
    if (Object.keys(errors).length > 0) {
      setCheckoutFieldErrors(errors)
      return
    }
    setCheckoutFieldErrors({})
    completeSaleMutation.mutate()
  }

  const addAdhoc = (e: FormEvent) => {
    e.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'description', label: 'Description', value: adhocDesc },
      { key: 'unit_price', label: 'Unit price', value: adhocPrice },
    ])
    if (Object.keys(errors).length > 0) {
      setAdhocFieldErrors(errors)
      return
    }
    const qty = Math.max(1, Math.floor(toNum(adhocQty) || 1))
    setCart((rows) => [
      ...rows,
      {
        key: `adhoc-${Date.now()}`,
        product_id: null,
        description: adhocDesc.trim(),
        quantity: qty,
        unit_price: toNum(adhocPrice),
        discount_amount: 0,
        tax_amount: 0,
        stock: null,
      },
    ])
    setAdhocDesc('')
    setAdhocPrice('')
    setAdhocQty('1')
    setShowAdhoc(false)
    setAdhocFieldErrors({})
    setCheckoutFieldErrors((prev) => {
      if (!prev.cart) return prev
      const next = { ...prev }
      delete next.cart
      return next
    })
    setError(null)
  }

  const updateCartQty = (key: string, quantity: number) => {
    setCart((rows) =>
      rows
        .map((r) => {
          if (r.key !== key) return r
          const qty = Math.max(1, Math.floor(quantity))
          if (r.stock != null && qty > r.stock) {
            setError(`Only ${r.stock} in stock for ${r.description}.`)
            return { ...r, quantity: r.stock }
          }
          return { ...r, quantity: qty }
        })
        .filter((r) => r.quantity > 0),
    )
  }

  const onVoid = async (sale: Sale) => {
    const ok = await confirm({
      title: 'Void sale?',
      message: `Void sale #${sale.id}? Stock will be restored. Linked invoices are not voided automatically.`,
      confirmLabel: 'Void sale',
      tone: 'danger',
    })
    if (!ok) return
    const reason = window.prompt('Void reason (optional):') ?? undefined
    voidMutation.mutate({ id: sale.id, reason: reason || undefined })
  }

  const branchName = (id: number | null | undefined) =>
    branches.find((b) => b.id === id)?.name ?? (id ? `Branch #${id}` : '—')

  const printSale = (sale: Sale, memberName?: string | null) => {
    printSaleReceipt(sale, {
      gymName,
      gymSlug,
      branchName: branchName(sale.branch_id),
      memberLabel: memberName || (sale.member_id ? `Member #${sale.member_id}` : 'Walk-in customer'),
    })
  }

  const saleColumns: Column<Sale>[] = [
    {
      key: 'id',
      header: 'Sale',
      cell: (row) => (
        <div>
          <p className="font-medium text-ink">#{row.id}</p>
          <p className="text-xs text-muted">{formatDate(row.sold_at)}</p>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.status === 'completed' ? 'success' : 'danger'}>
          {row.status}
        </Badge>
      ),
    },
    {
      key: 'branch',
      header: 'Branch',
      cell: (row) => (
        <span className="text-sm text-ink">{branchName(row.branch_id)}</span>
      ),
    },
    {
      key: 'total',
      header: 'Total',
      cell: (row) => (
        <span className="text-sm font-medium text-ink">
          {formatMoney(row.grand_total, row.currency_code)}
        </span>
      ),
    },
    {
      key: 'items',
      header: 'Items',
      cell: (row) => (
        <span className="text-sm text-muted">{(row.items ?? []).length || '—'}</span>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <div className="flex justify-end gap-2">
          <Button
            size="sm"
            variant="ghost"
            title="Print receipt"
            onClick={(e) => {
              e.stopPropagation()
              printSale(row)
            }}
          >
            <Printer className="h-4 w-4" />
          </Button>
          <Button size="sm" variant="secondary" onClick={() => setSelectedSaleId(row.id)}>
            Open
          </Button>
        </div>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader title="POS" description="Retail checkout." />
        <Alert tone="danger">You do not have permission to view POS sales.</Alert>
      </div>
    )
  }

  const stats = statsQuery.data
  const selectedSale = saleDetailQuery.data
  const members = membersQuery.data?.data ?? []

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="POS"
        description="Retail checkout — sell products, complete sales, and print receipts."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">{defaultCurrency}</Badge>
            {canCreateSales && tab === 'checkout' ? (
              <Button
                size="sm"
                disabled={cart.length === 0 || completeSaleMutation.isPending}
                onClick={() => completeSaleMutation.mutate()}
              >
                <ShoppingCart className="h-4 w-4" />
                {completeSaleMutation.isPending
                  ? 'Processing…'
                  : `Charge ${formatMoney(cartTotals.grand, defaultCurrency)}`}
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <SummaryChip
          icon={<ShoppingCart className="h-4 w-4" />}
          label="Completed sales"
          value={formatNumber(stats?.completed ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<ShoppingCart className="h-4 w-4" />}
          label="Voided"
          value={formatNumber(stats?.voided ?? 0)}
        />
        <SummaryChip
          icon={<ShoppingCart className="h-4 w-4" />}
          label="Cart items"
          value={formatNumber(cartTotals.items)}
        />
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => {
            setTab('checkout')
            setError(null)
            setSelectedSaleId(null)
          }}
          className={cn(
            'rounded-xl px-3 py-2 text-sm font-semibold transition',
            tab === 'checkout'
              ? 'bg-accent text-accent-ink'
              : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
          )}
        >
          Checkout
        </button>
        <button
          type="button"
          onClick={() => {
            setTab('history')
            setError(null)
          }}
          className={cn(
            'rounded-xl px-3 py-2 text-sm font-semibold transition',
            tab === 'history'
              ? 'bg-accent text-accent-ink'
              : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
          )}
        >
          Sales history
        </button>
      </div>

      {tab === 'checkout' ? (
        <>
          {lastSale ? (
            <Alert tone="success">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <span>
                  Sale #{lastSale.id} completed for{' '}
                  {formatMoney(lastSale.grand_total, lastSale.currency_code)}
                  {lastSale.invoice_id ? ` · Invoice #${lastSale.invoice_id} created` : ''}
                </span>
                <div className="flex gap-2">
                  <Button size="sm" variant="secondary" onClick={() => printSale(lastSale)}>
                    <Printer className="h-4 w-4" />
                    Print receipt
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setLastSale(null)}>
                    Dismiss
                  </Button>
                </div>
              </div>
            </Alert>
          ) : null}

          <div className="grid gap-4 xl:grid-cols-[1.4fr_1fr]">
            <div className="space-y-4">
              <Card>
                <div className="mb-4 flex flex-wrap items-end gap-3">
                  <div className="min-w-[160px]">
                    <Field
                      label="Branch"
                      htmlFor="pos-branch"
                      required
                      error={checkoutFieldErrors.branch_id}
                    >
                      <Select
                        id="pos-branch"
                        aria-invalid={Boolean(checkoutFieldErrors.branch_id)}
                        value={checkoutBranch === '' ? '' : String(checkoutBranch)}
                        onChange={(e) => {
                          clearCheckoutFieldError('branch_id')
                          setCheckoutBranch(e.target.value ? Number(e.target.value) : '')
                          setCart((rows) =>
                            rows.map((r) =>
                              r.product_id != null
                                ? { ...r, stock: stockMap[r.product_id] ?? r.stock }
                                : r,
                            ),
                          )
                        }}
                      >
                        <option value="">Select branch</option>
                        {branches.map((b) => (
                          <option key={b.id} value={b.id}>
                            {b.name}
                          </option>
                        ))}
                      </Select>
                    </Field>
                  </div>
                  <div className="min-w-[200px] flex-1">
                    <Label>Search products</Label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Name or SKU…"
                        value={productSearch}
                        disabled={!canViewInventory}
                        onChange={(e) => setProductSearch(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            setAppliedProductSearch(productSearch.trim())
                          }
                        }}
                      />
                      <Button
                        size="sm"
                        variant="secondary"
                        disabled={!canViewInventory}
                        onClick={() => setAppliedProductSearch(productSearch.trim())}
                      >
                        <Search className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  {canCreateSales ? (
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => setShowAdhoc((v) => !v)}
                    >
                      <Plus className="h-4 w-4" />
                      Custom item
                    </Button>
                  ) : null}
                </div>

                {!canViewInventory ? (
                  <Alert tone="info">
                    Product catalog requires inventory view permission. You can still add custom
                    items below.
                  </Alert>
                ) : productsQuery.isLoading ? (
                  <div className="flex justify-center py-12">
                    <Spinner />
                  </div>
                ) : productsQuery.isError ? (
                  <Alert tone="danger">
                    {productsQuery.error instanceof ApiError
                      ? productsQuery.error.message
                      : 'Failed to load products.'}
                  </Alert>
                ) : products.length === 0 ? (
                  <Alert tone="info">
                    No active products found. Add stock in Inventory, or sell a custom item.
                  </Alert>
                ) : (
                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                    {products.map((product) => {
                      const stock = stockMap[product.id]
                      const outOfStock = checkoutBranch !== '' && stock === 0
                      return (
                        <button
                          key={product.id}
                          type="button"
                          disabled={!canCreateSales || outOfStock || checkoutBranch === ''}
                          onClick={() => addProduct(product)}
                          className={cn(
                            'rounded-2xl border px-3 py-3 text-left transition',
                            outOfStock
                              ? 'cursor-not-allowed border-white/8 bg-white/[0.02] opacity-55'
                              : 'border-white/12 bg-white/[0.04] hover:border-accent/40 hover:bg-accent/10',
                          )}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <p className="font-semibold text-ink">{product.name}</p>
                              <p className="text-xs text-muted">{product.sku}</p>
                            </div>
                            <Badge tone={outOfStock ? 'danger' : 'neutral'}>
                              {stockQuery.isLoading
                                ? '…'
                                : checkoutBranch === ''
                                  ? '—'
                                  : `${stock ?? 0} left`}
                            </Badge>
                          </div>
                          <p className="mt-3 text-base font-semibold text-ink">
                            {formatMoney(product.unit_price, product.currency_code || defaultCurrency)}
                          </p>
                        </button>
                      )
                    })}
                  </div>
                )}
              </Card>

              {showAdhoc && canCreateSales ? (
                <Card className="border-accent/25">
                  <div className="mb-3 flex items-start justify-between">
                    <div>
                      <CardTitle>Custom item</CardTitle>
                      <CardDescription>
                        Sell a one-off line without a catalog product (no stock deduction).
                      </CardDescription>
                    </div>
                    <Button size="sm" variant="ghost" onClick={() => setShowAdhoc(false)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  <form noValidate onSubmit={addAdhoc} className="grid gap-3 sm:grid-cols-4">
                    <Field
                      label="Description"
                      htmlFor="adhoc-description"
                      required
                      error={adhocFieldErrors.description}
                      className="sm:col-span-2"
                    >
                      <Input
                        id="adhoc-description"
                        required
                        aria-invalid={Boolean(adhocFieldErrors.description)}
                        value={adhocDesc}
                        onChange={(e) => {
                          clearAdhocFieldError('description')
                          setAdhocDesc(e.target.value)
                        }}
                        placeholder="Service fee, towel rental…"
                      />
                    </Field>
                    <Field
                      label="Unit price"
                      htmlFor="adhoc-unit-price"
                      required
                      error={adhocFieldErrors.unit_price}
                    >
                      <Input
                        id="adhoc-unit-price"
                        required
                        aria-invalid={Boolean(adhocFieldErrors.unit_price)}
                        type="number"
                        min="0"
                        step="0.01"
                        value={adhocPrice}
                        onChange={(e) => {
                          clearAdhocFieldError('unit_price')
                          setAdhocPrice(e.target.value)
                        }}
                      />
                    </Field>
                    <Field label="Qty" htmlFor="adhoc-qty">
                      <Input
                        id="adhoc-qty"
                        type="number"
                        min="1"
                        step="1"
                        value={adhocQty}
                        onChange={(e) => setAdhocQty(e.target.value)}
                      />
                    </Field>
                    <div className="sm:col-span-4 flex justify-end">
                      <Button type="submit" size="sm">
                        Add to cart
                      </Button>
                    </div>
                  </form>
                </Card>
              ) : null}
            </div>

            <Card className="h-fit border-accent/20 xl:sticky xl:top-4">
              <div className="mb-4">
                <CardTitle>Cart</CardTitle>
                <CardDescription>
                  {cartTotals.items} item{cartTotals.items === 1 ? '' : 's'} ·{' '}
                  {user?.name ? `Cashier ${user.name}` : 'Ready to charge'}
                </CardDescription>
              </div>

              <div className="mb-4 space-y-3">
                {canViewMembers ? (
                  <div>
                    <Label>Member (optional)</Label>
                    <Input
                      className="mb-2"
                      placeholder="Search members…"
                      value={memberSearch}
                      onChange={(e) => setMemberSearch(e.target.value)}
                    />
                    <Select
                      value={memberId === '' ? '' : String(memberId)}
                      onChange={(e) =>
                        setMemberId(e.target.value ? Number(e.target.value) : '')
                      }
                    >
                      <option value="">Walk-in customer</option>
                      {members.map((m) => (
                        <option key={m.id} value={m.id}>
                          {memberLabel(m)}
                        </option>
                      ))}
                    </Select>
                  </div>
                ) : (
                  <div>
                    <Label>Member ID (optional)</Label>
                    <Input
                      type="number"
                      placeholder="Leave blank for walk-in"
                      value={memberId === '' ? '' : memberId}
                      onChange={(e) =>
                        setMemberId(e.target.value ? Number(e.target.value) : '')
                      }
                    />
                  </div>
                )}

                <div>
                  <Label htmlFor="pos-coupon">Coupon code</Label>
                  <Input
                    id="pos-coupon"
                    className="mt-1.5"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                    placeholder="Optional promo code"
                  />
                </div>

                <label className="flex items-center gap-2 text-sm text-ink">
                  <input
                    type="checkbox"
                    checked={createInvoice}
                    onChange={(e) => setCreateInvoice(e.target.checked)}
                    className="h-4 w-4 rounded border-white/20"
                  />
                  Create billing invoice for this sale
                </label>
              </div>

              {checkoutFieldErrors.cart ? (
                <p className="mb-3 text-xs font-medium text-danger" role="alert">
                  {checkoutFieldErrors.cart}
                </p>
              ) : null}

              {cart.length === 0 ? (
                <div className="rounded-xl border border-dashed border-white/15 px-4 py-10 text-center text-sm text-muted">
                  Tap a product to add it to the cart.
                </div>
              ) : (
                <div className="space-y-3">
                  {cart.map((line) => (
                    <div
                      key={line.key}
                      className="rounded-xl border border-white/10 bg-white/[0.03] p-3"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="text-sm font-semibold text-ink">{line.description}</p>
                          {line.sku ? (
                            <p className="text-xs text-muted">{line.sku}</p>
                          ) : (
                            <p className="text-xs text-muted">Custom item</p>
                          )}
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setCart((rows) => rows.filter((r) => r.key !== line.key))}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="mt-3 flex flex-wrap items-center gap-2">
                        <div className="flex items-center gap-1 rounded-lg border border-white/12 bg-white/5 p-0.5">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => updateCartQty(line.key, line.quantity - 1)}
                            disabled={line.quantity <= 1}
                          >
                            <Minus className="h-3.5 w-3.5" />
                          </Button>
                          <span className="min-w-[2rem] text-center text-sm font-semibold text-ink">
                            {line.quantity}
                          </span>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => updateCartQty(line.key, line.quantity + 1)}
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                        <Input
                          className="w-28"
                          type="number"
                          min="0"
                          step="0.01"
                          title="Unit price"
                          value={line.unit_price}
                          onChange={(e) =>
                            setCart((rows) =>
                              rows.map((r) =>
                                r.key === line.key
                                  ? { ...r, unit_price: toNum(e.target.value) }
                                  : r,
                              ),
                            )
                          }
                        />
                        <Input
                          className="w-24"
                          type="number"
                          min="0"
                          step="0.01"
                          title="Discount"
                          placeholder="Disc"
                          value={line.discount_amount || ''}
                          onChange={(e) =>
                            setCart((rows) =>
                              rows.map((r) =>
                                r.key === line.key
                                  ? { ...r, discount_amount: toNum(e.target.value) }
                                  : r,
                              ),
                            )
                          }
                        />
                        <span className="ml-auto text-sm font-semibold text-ink">
                          {formatMoney(lineTotal(line), defaultCurrency)}
                        </span>
                      </div>
                      {line.stock != null ? (
                        <p className="mt-1 text-xs text-muted">Stock available: {line.stock}</p>
                      ) : null}
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-4 space-y-1.5 border-t border-white/10 pt-4 text-sm">
                <div className="flex justify-between text-muted">
                  <span>Subtotal</span>
                  <span>{formatMoney(cartTotals.subtotal, defaultCurrency)}</span>
                </div>
                <div className="flex justify-between text-muted">
                  <span>Discount</span>
                  <span>{formatMoney(cartTotals.discount, defaultCurrency)}</span>
                </div>
                <div className="flex justify-between text-muted">
                  <span>Tax</span>
                  <span>{formatMoney(cartTotals.tax, defaultCurrency)}</span>
                </div>
                <div className="flex justify-between text-base font-semibold text-ink">
                  <span>Total</span>
                  <span>{formatMoney(cartTotals.grand, defaultCurrency)}</span>
                </div>
              </div>

              <div className="mt-4 flex flex-col gap-2">
                {canCreateSales ? (
                  <Button
                    disabled={completeSaleMutation.isPending}
                    onClick={onCompleteSale}
                  >
                    <ShoppingCart className="h-4 w-4" />
                    {completeSaleMutation.isPending ? 'Processing…' : 'Complete sale'}
                  </Button>
                ) : (
                  <Alert tone="info">You can view the register but cannot complete sales.</Alert>
                )}
                {cart.length > 0 ? (
                  <Button size="sm" variant="secondary" onClick={() => setCart([])}>
                    Clear cart
                  </Button>
                ) : null}
              </div>
            </Card>
          </div>
        </>
      ) : null}

      {tab === 'history' ? (
        <>
          <Card>
            <div className="mb-4 flex flex-wrap items-end gap-3">
              <div>
                <Label>Status</Label>
                <Select
                  value={saleStatus}
                  onChange={(e) => {
                    setSaleStatus(e.target.value as '' | SaleStatus)
                    setSalePage(1)
                  }}
                >
                  <option value="">All</option>
                  <option value="completed">Completed</option>
                  <option value="void">Void</option>
                </Select>
              </div>
              <div>
                <Label>Branch</Label>
                <Select
                  value={saleBranch === '' ? '' : String(saleBranch)}
                  onChange={(e) => {
                    setSaleBranch(e.target.value ? Number(e.target.value) : '')
                    setSalePage(1)
                  }}
                >
                  <option value="">All branches</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </Select>
              </div>
            </div>

            {salesQuery.isLoading ? (
              <div className="flex justify-center py-12">
                <Spinner />
              </div>
            ) : salesQuery.isError ? (
              <Alert tone="danger">
                {salesQuery.error instanceof ApiError
                  ? salesQuery.error.message
                  : 'Failed to load sales.'}
              </Alert>
            ) : (
              <>
                <DataTable
                  columns={saleColumns}
                  rows={salesQuery.data?.data ?? []}
                  rowKey={(r) => r.id}
                  emptyTitle="No sales yet"
                  emptyDescription="Completed checkouts will appear here."
                />
                <Pagination
                  meta={salesQuery.data?.meta}
                  onPageChange={(p) => {
                    setSalePage(p)
                    setSelectedSaleId(null)
                  }}
                />
              </>
            )}
          </Card>

          {selectedSaleId != null ? (
            <Card className="border-accent/20">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Sale detail</CardTitle>
                  <CardDescription>Sale #{selectedSaleId}</CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setSelectedSaleId(null)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>

              {saleDetailQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Spinner />
                </div>
              ) : selectedSale ? (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone={selectedSale.status === 'completed' ? 'success' : 'danger'}>
                      {selectedSale.status}
                    </Badge>
                    <span className="text-sm text-muted">
                      {branchName(selectedSale.branch_id)} · {formatDate(selectedSale.sold_at)}
                    </span>
                    {selectedSale.member_id ? (
                      <span className="text-sm text-muted">
                        · Member #{selectedSale.member_id}
                      </span>
                    ) : (
                      <span className="text-sm text-muted">· Walk-in</span>
                    )}
                    {selectedSale.invoice_id ? (
                      <Badge tone="accent">Invoice #{selectedSale.invoice_id}</Badge>
                    ) : null}
                  </div>

                  <div className="grid gap-3 sm:grid-cols-3">
                    <DetailStat
                      label="Subtotal"
                      value={formatMoney(selectedSale.subtotal, selectedSale.currency_code)}
                    />
                    <DetailStat
                      label="Tax"
                      value={formatMoney(selectedSale.tax_total, selectedSale.currency_code)}
                    />
                    <DetailStat
                      label="Grand total"
                      value={formatMoney(selectedSale.grand_total, selectedSale.currency_code)}
                    />
                  </div>

                  <div className="overflow-x-auto rounded-xl border border-white/10">
                    <table className="w-full text-left text-sm">
                      <thead className="bg-white/[0.04] text-xs uppercase tracking-wide text-muted">
                        <tr>
                          <th className="px-3 py-2 font-medium">Item</th>
                          <th className="px-3 py-2 font-medium">Qty</th>
                          <th className="px-3 py-2 font-medium">Unit</th>
                          <th className="px-3 py-2 font-medium text-right">Line total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(selectedSale.items ?? []).map((item) => (
                          <tr key={item.id} className="border-t border-white/8">
                            <td className="px-3 py-2 text-ink">
                              <div>{item.description}</div>
                              {item.product?.sku ? (
                                <div className="text-xs text-muted">{item.product.sku}</div>
                              ) : null}
                            </td>
                            <td className="px-3 py-2 text-muted">{item.quantity}</td>
                            <td className="px-3 py-2 text-muted">
                              {formatMoney(item.unit_price, selectedSale.currency_code)}
                            </td>
                            <td className="px-3 py-2 text-right text-ink">
                              {formatMoney(item.line_total, selectedSale.currency_code)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Button size="sm" onClick={() => printSale(selectedSale)}>
                      <Printer className="h-4 w-4" />
                      Print receipt
                    </Button>
                    {canCreateSales && selectedSale.status === 'completed' ? (
                      <Button
                        size="sm"
                        variant="danger"
                        disabled={voidMutation.isPending}
                        onClick={() => onVoid(selectedSale)}
                      >
                        Void sale
                      </Button>
                    ) : null}
                  </div>
                </div>
              ) : (
                <Alert tone="danger">Sale not found.</Alert>
              )}
            </Card>
          ) : null}
        </>
      ) : null}
    </div>
  )
}

function DetailStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-0.5 text-sm font-semibold text-ink">{value}</p>
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}
