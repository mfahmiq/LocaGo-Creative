import type { Sale } from '@/api/pos'
import { formatDate, formatMoney } from '@/lib/format'

function escapeHtml(value: string | number | null | undefined): string {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

function statusLabel(status: string) {
  return status.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
}

function openPrintWindow(html: string, title: string) {
  const blob = new Blob([html], { type: 'text/html;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const popup = window.open(url, '_blank', 'noopener,noreferrer,width=720,height=960')
  if (!popup) {
    const frame = document.createElement('iframe')
    frame.title = title
    frame.style.position = 'fixed'
    frame.style.right = '0'
    frame.style.bottom = '0'
    frame.style.width = '0'
    frame.style.height = '0'
    frame.style.border = '0'
    document.body.appendChild(frame)
    frame.srcdoc = html
    frame.onload = () => {
      frame.contentWindow?.focus()
      frame.contentWindow?.print()
      setTimeout(() => {
        document.body.removeChild(frame)
        URL.revokeObjectURL(url)
      }, 1000)
    }
  } else {
    setTimeout(() => URL.revokeObjectURL(url), 60_000)
  }
}

const documentStyles = `
  @page { margin: 12mm; size: A4; }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    padding: 24px 28px;
    font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif;
    color: #152033;
    background: #fff;
    font-size: 13px;
    line-height: 1.45;
  }
  .sheet { max-width: 640px; margin: 0 auto; }
  .top {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    align-items: flex-start;
    border-bottom: 2px solid #152033;
    padding-bottom: 16px;
    margin-bottom: 20px;
  }
  .brand-name {
    font-family: Georgia, "Times New Roman", serif;
    font-size: 24px;
    font-weight: 700;
    margin: 0 0 4px;
  }
  .brand-sub { color: #5b6578; font-size: 12px; margin: 0; }
  .doc-type { text-align: right; }
  .doc-type h2 {
    margin: 0;
    font-size: 20px;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: #1f4e79;
  }
  .doc-type .num { margin-top: 6px; font-size: 14px; font-weight: 700; }
  .meta {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-bottom: 18px;
  }
  .box {
    border: 1px solid #d7dde8;
    border-radius: 8px;
    padding: 12px 14px;
    background: #f8fafc;
  }
  .box h3 {
    margin: 0 0 6px;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: #5b6578;
  }
  .box p { margin: 0 0 3px; }
  table { width: 100%; border-collapse: collapse; margin: 8px 0 16px; }
  th, td {
    padding: 9px 10px;
    border-bottom: 1px solid #e4e9f2;
    text-align: left;
    vertical-align: top;
  }
  th {
    background: #eef3f8;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: #3d4a5f;
  }
  td.num, th.num { text-align: right; white-space: nowrap; }
  .totals {
    width: 260px;
    margin-left: auto;
    border: 1px solid #d7dde8;
    border-radius: 8px;
    overflow: hidden;
  }
  .totals .row {
    display: flex;
    justify-content: space-between;
    padding: 8px 14px;
    border-bottom: 1px solid #e8edf5;
  }
  .totals .row:last-child { border-bottom: 0; }
  .totals .grand {
    background: #1f4e79;
    color: #fff;
    font-weight: 700;
    font-size: 15px;
  }
  .badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 600;
    background: #e8f0f8;
    color: #1f4e79;
  }
  .footer {
    margin-top: 24px;
    font-size: 11px;
    color: #6b7587;
    display: flex;
    justify-content: space-between;
    gap: 12px;
  }
`

export function printSaleReceipt(
  sale: Sale,
  opts: {
    gymName: string
    gymSlug?: string | null
    branchName?: string | null
    memberLabel?: string | null
  },
) {
  const currency = sale.currency_code || 'INR'
  const rows = (sale.items ?? [])
    .map(
      (item) => `
      <tr>
        <td>
          ${escapeHtml(item.description)}
          ${
            item.product?.sku
              ? `<div style="color:#5b6578;font-size:11px">${escapeHtml(item.product.sku)}</div>`
              : ''
          }
        </td>
        <td class="num">${escapeHtml(item.quantity)}</td>
        <td class="num">${escapeHtml(formatMoney(item.unit_price, currency))}</td>
        <td class="num">${escapeHtml(formatMoney(item.discount_amount, currency))}</td>
        <td class="num">${escapeHtml(formatMoney(item.line_total, currency))}</td>
      </tr>`,
    )
    .join('')

  const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Sale receipt #${escapeHtml(sale.id)}</title>
  <style>${documentStyles}</style>
</head>
<body>
  <div class="sheet">
    <div class="top">
      <div>
        <p class="brand-name">${escapeHtml(opts.gymName)}</p>
        <p class="brand-sub">${opts.gymSlug ? escapeHtml(opts.gymSlug) : 'Retail POS'} · Sale receipt</p>
      </div>
      <div class="doc-type">
        <h2>Receipt</h2>
        <div class="num">Sale #${escapeHtml(sale.id)}</div>
        <div style="margin-top:8px"><span class="badge">${escapeHtml(statusLabel(sale.status))}</span></div>
      </div>
    </div>

    <div class="meta">
      <div class="box">
        <h3>Customer</h3>
        <p><strong>${escapeHtml(opts.memberLabel || 'Walk-in customer')}</strong></p>
        ${opts.branchName ? `<p>Branch: ${escapeHtml(opts.branchName)}</p>` : ''}
      </div>
      <div class="box">
        <h3>Sale details</h3>
        <p>Date: <strong>${escapeHtml(formatDate(sale.sold_at))}</strong></p>
        <p>Currency: <strong>${escapeHtml(currency)}</strong></p>
        ${
          sale.invoice_id
            ? `<p>Invoice linked: <strong>#${escapeHtml(sale.invoice_id)}</strong></p>`
            : ''
        }
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th>Item</th>
          <th class="num">Qty</th>
          <th class="num">Unit</th>
          <th class="num">Discount</th>
          <th class="num">Amount</th>
        </tr>
      </thead>
      <tbody>
        ${rows || `<tr><td colspan="5">No items</td></tr>`}
      </tbody>
    </table>

    <div class="totals">
      <div class="row"><span>Subtotal</span><span>${escapeHtml(formatMoney(sale.subtotal, currency))}</span></div>
      <div class="row"><span>Discount</span><span>${escapeHtml(formatMoney(sale.discount_total, currency))}</span></div>
      <div class="row"><span>Tax</span><span>${escapeHtml(formatMoney(sale.tax_total, currency))}</span></div>
      <div class="row grand"><span>Total</span><span>${escapeHtml(formatMoney(sale.grand_total, currency))}</span></div>
    </div>

    <div class="footer">
      <span>Generated ${escapeHtml(formatDate(new Date().toISOString()))}</span>
      <span>Thank you for shopping with us</span>
    </div>
  </div>
  <script>window.onload = function () { window.print(); }</script>
</body>
</html>`

  openPrintWindow(html, `Sale #${sale.id}`)
}
