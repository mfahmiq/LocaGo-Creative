import { useMemo, useState, type FormEvent } from 'react'
import { Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Banknote,
  FileText,
  Plus,
  RefreshCw,
  Search,
  Wallet,
  X,
} from 'lucide-react'
import {
  fetchPlatformBillingOverview,
  issuePlatformInvoice,
  recordPlatformInvoicePayment,
  voidPlatformInvoice,
  type PlatformInvoice,
  type PlatformSubscriptionRow,
} from '@/api/platform'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { SimpleBarChart } from '@/components/charts/SimpleBarChart'
import { formatDate, formatMoney, formatNumber } from '@/lib/format'
import { cn } from '@/lib/cn'
import { tenantStatusTone } from '@/pages/platform/tenantHelpers'
import { useClientPagination } from '@/hooks/useClientPagination'

type TabKey = 'subscriptions' | 'invoices' | 'payments'

function invoiceTone(status: string): 'success' | 'warning' | 'danger' | 'neutral' | 'accent' {
  switch (status) {
    case 'paid':
      return 'success'
    case 'issued':
      return 'accent'
    case 'overdue':
      return 'warning'
    case 'void':
      return 'neutral'
    default:
      return 'neutral'
  }
}

export function PlatformBillingPage() {
  const { hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('platform.billing.view')
  const canManage = hasPermission('platform.billing.manage')

  const [tab, setTab] = useState<TabKey>('subscriptions')
  const [search, setSearch] = useState('')
  const [invoiceStatus, setInvoiceStatus] = useState('')
  const [showIssue, setShowIssue] = useState(false)
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<number | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }

  const [issueForm, setIssueForm] = useState({
    tenant_id: '',
    subtotal: '',
    tax_total: '0',
    due_date: '',
  })
  const [payForm, setPayForm] = useState({
    amount: '',
    method: 'bank_transfer',
    reference: '',
  })

  const billingQuery = useQuery({
    queryKey: ['platform', 'billing', 'overview', invoiceStatus || 'all'],
    queryFn: () => fetchPlatformBillingOverview(invoiceStatus || undefined),
    enabled: canView,
  })

  const data = billingQuery.data
  const summary = data?.summary
  const subscriptions = data?.subscriptions ?? []
  const invoices = data?.invoices ?? []
  const payments = data?.payments ?? []

  const selectedInvoice = useMemo(
    () => invoices.find((invoice) => invoice.id === selectedInvoiceId) ?? null,
    [invoices, selectedInvoiceId],
  )

  const filteredSubscriptions = useMemo(() => {
    const q = search.trim().toLowerCase()
    if (!q) return subscriptions
    return subscriptions.filter(
      (row) =>
        row.tenant_name.toLowerCase().includes(q) ||
        row.tenant_slug.toLowerCase().includes(q) ||
        (row.plan_name ?? '').toLowerCase().includes(q),
    )
  }, [subscriptions, search])

  const filteredInvoices = useMemo(() => {
    const q = search.trim().toLowerCase()
    if (!q) return invoices
    return invoices.filter(
      (row) =>
        row.invoice_number.toLowerCase().includes(q) ||
        (row.tenant?.name ?? '').toLowerCase().includes(q) ||
        (row.tenant?.slug ?? '').toLowerCase().includes(q),
    )
  }, [invoices, search])

  const filteredPayments = useMemo(() => {
    const q = search.trim().toLowerCase()
    if (!q) return payments
    return payments.filter(
      (row) =>
        (row.tenant?.name ?? '').toLowerCase().includes(q) ||
        (row.invoice?.invoice_number ?? '').toLowerCase().includes(q) ||
        (row.reference ?? '').toLowerCase().includes(q),
    )
  }, [payments, search])

  const subscriptionsPage = useClientPagination(
    filteredSubscriptions,
    `${tab}|${search}|subs|${filteredSubscriptions.length}`,
  )
  const invoicesPage = useClientPagination(
    filteredInvoices,
    `${tab}|${search}|inv|${filteredInvoices.length}`,
  )
  const paymentsPage = useClientPagination(
    filteredPayments,
    `${tab}|${search}|pay|${filteredPayments.length}`,
  )

  const planMix = useMemo(() => {
    const map = new Map<string, number>()
    for (const row of subscriptions) {
      if (!row.billable) continue
      const key = row.plan_name ?? 'Unassigned'
      map.set(key, (map.get(key) ?? 0) + row.monthly_amount)
    }
    return [...map.entries()].map(([label, value]) => ({
      label,
      value: Math.round(value * 100) / 100,
    }))
  }, [subscriptions])

  const invalidate = () =>
    void queryClient.invalidateQueries({ queryKey: ['platform', 'billing'] })

  const issueMutation = useMutation({
    mutationFn: issuePlatformInvoice,
    onSuccess: (invoice) => {
      setError(null)
      showSuccess(`Invoice ${invoice.invoice_number} issued.`)
      setShowIssue(false)
      setIssueForm({ tenant_id: '', subtotal: '', tax_total: '0', due_date: '' })
      setSelectedInvoiceId(invoice.id)
      setTab('invoices')
      invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to issue invoice.')
    },
  })

  const payMutation = useMutation({
    mutationFn: ({
      invoiceId,
      payload,
    }: {
      invoiceId: number
      payload: { amount: number; method?: string; reference?: string }
    }) => recordPlatformInvoicePayment(invoiceId, payload),
    onSuccess: () => {
      setError(null)
      showSuccess('Payment recorded.')
      setPayForm({ amount: '', method: 'bank_transfer', reference: '' })
      invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to record payment.')
    },
  })

  const voidMutation = useMutation({
    mutationFn: voidPlatformInvoice,
    onSuccess: (invoice) => {
      setError(null)
      showSuccess(`Invoice ${invoice.invoice_number} voided.`)
      invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to void invoice.')
    },
  })

  const openIssueForTenant = (row: PlatformSubscriptionRow) => {
    setShowIssue(true)
    setIssueForm({
      tenant_id: String(row.tenant_id),
      subtotal: row.price > 0 ? String(row.price) : '',
      tax_total: '0',
      due_date: '',
    })
    setTab('invoices')
  }

  const onIssue = (event: FormEvent) => {
    event.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'tenant_id', label: 'Tenant', value: issueForm.tenant_id },
    ])
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    issueMutation.mutate({
      tenant_id: Number(issueForm.tenant_id),
      subtotal: issueForm.subtotal ? Number(issueForm.subtotal) : undefined,
      tax_total: Number(issueForm.tax_total) || 0,
      due_date: issueForm.due_date || undefined,
      billing_mode: 'manual',
    })
  }

  const onPay = (event: FormEvent) => {
    event.preventDefault()
    if (!selectedInvoice) return
    const amount = payForm.amount || String(selectedInvoice.grand_total)
    const errors = collectRequiredErrors([
      { key: 'amount', label: 'Amount', value: amount },
    ])
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    payMutation.mutate({
      invoiceId: selectedInvoice.id,
      payload: {
        amount: Number(payForm.amount) || Number(selectedInvoice.grand_total),
        method: payForm.method,
        reference: payForm.reference.trim() || undefined,
      },
    })
  }

  const onVoid = async (invoice: PlatformInvoice) => {
    const ok = await confirm({
      title: 'Void invoice?',
      message: `Void ${invoice.invoice_number}? This cannot be undone.`,
      confirmLabel: 'Void',
      tone: 'danger',
    })
    if (!ok) return
    voidMutation.mutate(invoice.id)
  }

  const subscriptionColumns: Column<PlatformSubscriptionRow>[] = [
    {
      key: 'tenant',
      header: 'Tenant',
      cell: (row) => (
        <div>
          <p className="font-semibold">{row.tenant_name}</p>
          <p className="font-mono text-xs text-muted">/{row.tenant_slug}</p>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => <Badge tone={tenantStatusTone(row.tenant_status)}>{row.tenant_status}</Badge>,
    },
    {
      key: 'plan',
      header: 'Plan',
      cell: (row) => (
        <span className="text-sm">
          {row.plan_name ?? '—'}
          <span className="mt-0.5 block text-xs text-muted">{row.plan_code ?? ''}</span>
        </span>
      ),
    },
    {
      key: 'price',
      header: 'Subscription',
      cell: (row) => (
        <span className="text-sm">
          {formatMoney(row.price, row.currency_code)}
          <span className="mt-0.5 block text-xs text-muted">/{row.billing_interval}</span>
        </span>
      ),
    },
    {
      key: 'mrr',
      header: 'Monthly',
      cell: (row) =>
        row.billable ? (
          formatMoney(row.monthly_amount, row.currency_code)
        ) : (
          <span className="text-muted">—</span>
        ),
    },
    {
      key: 'balance',
      header: 'Open balance',
      cell: (row) =>
        row.open_balance > 0 ? (
          <span className="font-semibold text-warning">
            {formatMoney(row.open_balance, row.currency_code)}
          </span>
        ) : (
          <span className="text-muted">—</span>
        ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) =>
        canManage ? (
          <Button size="sm" variant="secondary" onClick={() => openIssueForTenant(row)}>
            Issue invoice
          </Button>
        ) : null,
    },
  ]

  const invoiceColumns: Column<PlatformInvoice>[] = [
    {
      key: 'number',
      header: 'Invoice',
      cell: (row) => (
        <button type="button" className="text-left hover:text-accent" onClick={() => setSelectedInvoiceId(row.id)}>
          <p className="font-semibold">{row.invoice_number}</p>
          <p className="text-xs text-muted">{row.tenant?.name ?? '—'}</p>
        </button>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => <Badge tone={invoiceTone(row.status)}>{row.status}</Badge>,
    },
    {
      key: 'total',
      header: 'Total',
      cell: (row) => formatMoney(row.grand_total, row.currency_code),
    },
    {
      key: 'due',
      header: 'Due',
      cell: (row) => formatDate(row.due_date),
    },
    {
      key: 'issued',
      header: 'Issued',
      cell: (row) => formatDate(row.issued_at),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedInvoiceId(row.id)}>
          Manage
        </Button>
      ),
    },
  ]

  if (!canView) {
    return (
      <Alert tone="info">
        Platform billing requires <code>platform.billing.view</code>.
      </Alert>
    )
  }

  return (
    <div className="animate-fade-up space-y-6">
      <PageHeader
        title="Platform billing"
        description="Tenant billing overview — subscriptions, manual invoices, and payment collection for the SaaS platform."
        actions={
          <div className="flex flex-wrap gap-2">
            {canManage ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowIssue(true)
                  setSelectedInvoiceId(null)
                }}
              >
                <Plus className="h-4 w-4" />
                Issue invoice
              </Button>
            ) : (
              <Badge tone="neutral">View only</Badge>
            )}
            <Button size="sm" variant="secondary" onClick={() => invalidate()}>
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      {billingQuery.isError ? (
        <Alert tone="danger">
          {billingQuery.error instanceof ApiError
            ? billingQuery.error.message
            : 'Unable to load billing overview.'}
          <div className="mt-3">
            <Button size="sm" variant="secondary" onClick={() => void billingQuery.refetch()}>
              Try again
            </Button>
          </div>
        </Alert>
      ) : null}

      {billingQuery.isPending ? (
        <div className="flex justify-center py-20">
          <Spinner label="Loading billing…" />
        </div>
      ) : (
        <>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <SummaryChip
              label="Estimated MRR"
              value={formatMoney(summary?.mrr ?? 0, summary?.currency_code ?? 'USD')}
              hint={`${formatNumber(summary?.billable_tenants ?? 0)} billable tenants`}
              icon={Wallet}
              accent
            />
            <SummaryChip
              label="Outstanding"
              value={formatMoney(summary?.outstanding ?? 0, summary?.currency_code ?? 'USD')}
              hint={`${formatNumber(summary?.open_invoices ?? 0)} open invoices`}
              icon={FileText}
            />
            <SummaryChip
              label="Collected this month"
              value={formatMoney(
                summary?.collected_this_month ?? 0,
                summary?.currency_code ?? 'USD',
              )}
              hint={`${formatNumber(summary?.paid_invoices ?? 0)} paid invoices`}
              icon={Banknote}
            />
            <SummaryChip
              label="On trial"
              value={formatNumber(summary?.trial_tenants ?? 0)}
              hint="Not billed until activated"
              icon={FileText}
            />
          </div>

          <div className="grid gap-4 xl:grid-cols-[1.1fr_0.9fr]">
            <SimpleBarChart
              title="MRR by plan"
              description="Monthly contribution from active paid subscriptions"
              data={planMix.length ? planMix : [{ label: 'None', value: 0 }]}
            />
            <Card>
              <CardTitle>Billing shortcuts</CardTitle>
              <CardDescription>Jump to related platform tools</CardDescription>
              <div className="mt-4 grid gap-2 sm:grid-cols-2">
                <Link
                  to="/platform/tenants"
                  className="rounded-xl border border-white/12 bg-white/6 px-3 py-3 text-sm font-semibold transition hover:border-accent/40 hover:bg-accent-soft/40"
                >
                  Manage tenants
                </Link>
                <Link
                  to="/platform/plans"
                  className="rounded-xl border border-white/12 bg-white/6 px-3 py-3 text-sm font-semibold transition hover:border-accent/40 hover:bg-accent-soft/40"
                >
                  SaaS plans
                </Link>
                <Link
                  to="/platform/reports/billing"
                  className="rounded-xl border border-white/12 bg-white/6 px-3 py-3 text-sm font-semibold transition hover:border-accent/40 hover:bg-accent-soft/40"
                >
                  Billing reports
                </Link>
                <button
                  type="button"
                  onClick={() => setTab('invoices')}
                  className="rounded-xl border border-white/12 bg-white/6 px-3 py-3 text-left text-sm font-semibold transition hover:border-accent/40 hover:bg-accent-soft/40"
                >
                  Open invoices
                </button>
              </div>
            </Card>
          </div>

          {showIssue && canManage ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Issue platform invoice</CardTitle>
                  <CardDescription>
                    Creates a manual SaaS invoice. Leave amount blank to use the tenant’s plan price.
                  </CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setShowIssue(false)} aria-label="Close">
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form onSubmit={onIssue} noValidate className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                <Field
                  label="Tenant"
                  htmlFor="issue-tenant"
                  required
                  error={fieldErrors.tenant_id}
                  className="sm:col-span-2"
                >
                  <Select
                    id="issue-tenant"
                    value={issueForm.tenant_id}
                    onChange={(e) => {
                      const id = e.target.value
                      const sub = subscriptions.find((row) => String(row.tenant_id) === id)
                      setIssueForm((c) => ({
                        ...c,
                        tenant_id: id,
                        subtotal:
                          c.subtotal || (sub && sub.price > 0 ? String(sub.price) : c.subtotal),
                      }))
                      clearFieldError('tenant_id')
                    }}
                    aria-invalid={Boolean(fieldErrors.tenant_id)}
                  >
                    <option value="">Select tenant</option>
                    {subscriptions.map((row) => (
                      <option key={row.tenant_id} value={row.tenant_id}>
                        {row.tenant_name} (/{row.tenant_slug}) — {row.tenant_status}
                      </option>
                    ))}
                  </Select>
                </Field>
                <div>
                  <Label htmlFor="issue-subtotal">Subtotal</Label>
                  <Input
                    id="issue-subtotal"
                    type="number"
                    min={0.01}
                    step="0.01"
                    value={issueForm.subtotal}
                    onChange={(e) => setIssueForm((c) => ({ ...c, subtotal: e.target.value }))}
                    placeholder="Plan price default"
                  />
                </div>
                <div>
                  <Label htmlFor="issue-tax">Tax</Label>
                  <Input
                    id="issue-tax"
                    type="number"
                    min={0}
                    step="0.01"
                    value={issueForm.tax_total}
                    onChange={(e) => setIssueForm((c) => ({ ...c, tax_total: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="issue-due">Due date</Label>
                  <Input
                    id="issue-due"
                    type="date"
                    value={issueForm.due_date}
                    onChange={(e) => setIssueForm((c) => ({ ...c, due_date: e.target.value }))}
                  />
                </div>
                <div className="flex items-end gap-2 sm:col-span-2 xl:col-span-4">
                  <Button type="submit" loading={issueMutation.isPending}>
                    Issue invoice
                  </Button>
                  <Button type="button" variant="ghost" onClick={() => setShowIssue(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          <Card className="p-4 sm:p-5">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div className="flex flex-wrap gap-2">
                {(
                  [
                    { key: 'subscriptions', label: 'Subscriptions' },
                    { key: 'invoices', label: 'Invoices' },
                    { key: 'payments', label: 'Payments' },
                  ] as const
                ).map((item) => (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => setTab(item.key)}
                    className={cn(
                      'rounded-xl px-3 py-2 text-sm font-semibold transition',
                      tab === item.key
                        ? 'bg-accent text-accent-ink'
                        : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                    )}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              <div className="flex w-full flex-col gap-3 sm:flex-row lg:max-w-xl">
                {tab === 'invoices' ? (
                  <Select
                    value={invoiceStatus}
                    onChange={(e) => setInvoiceStatus(e.target.value)}
                    aria-label="Invoice status"
                    className="sm:w-40"
                  >
                    <option value="">All statuses</option>
                    <option value="issued">Issued</option>
                    <option value="overdue">Overdue</option>
                    <option value="paid">Paid</option>
                    <option value="void">Void</option>
                  </Select>
                ) : null}
                <div className="relative flex-1">
                  <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
                  <Input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search…"
                    className="pl-10"
                  />
                </div>
              </div>
            </div>
          </Card>

          <div className={cn('grid gap-4', selectedInvoice && tab === 'invoices' ? 'xl:grid-cols-[1fr_22rem]' : '')}>
            <div className="min-w-0">
              {tab === 'subscriptions' ? (
                <>
                  <DataTable
                    columns={subscriptionColumns}
                    rows={subscriptionsPage.rows}
                    rowKey={(row) => row.tenant_id}
                    emptyTitle="No subscriptions"
                    emptyDescription="Provision tenants and assign SaaS plans to see billing rows."
                  />
                  <Pagination meta={subscriptionsPage.meta} onPageChange={subscriptionsPage.setPage} />
                </>
              ) : null}

              {tab === 'invoices' ? (
                <>
                  <DataTable
                    columns={invoiceColumns}
                    rows={invoicesPage.rows}
                    rowKey={(row) => row.id}
                    emptyTitle="No invoices"
                    emptyDescription="Issue a manual invoice for a gym tenant to begin collection."
                  />
                  <Pagination meta={invoicesPage.meta} onPageChange={invoicesPage.setPage} />
                </>
              ) : null}

              {tab === 'payments' ? (
                <>
                <DataTable
                  columns={[
                    {
                      key: 'tenant',
                      header: 'Tenant',
                      cell: (row) => row.tenant?.name ?? '—',
                    },
                    {
                      key: 'invoice',
                      header: 'Invoice',
                      cell: (row) => row.invoice?.invoice_number ?? '—',
                    },
                    {
                      key: 'amount',
                      header: 'Amount',
                      cell: (row) => formatMoney(row.amount, row.currency_code),
                    },
                    {
                      key: 'method',
                      header: 'Method',
                      cell: (row) => row.method,
                    },
                    {
                      key: 'ref',
                      header: 'Reference',
                      cell: (row) => row.reference ?? '—',
                    },
                    {
                      key: 'paid',
                      header: 'Paid at',
                      cell: (row) => formatDate(row.paid_at),
                    },
                  ]}
                  rows={paymentsPage.rows}
                  rowKey={(row) => row.id}
                  emptyTitle="No payments yet"
                  emptyDescription="Record a payment against an open invoice."
                />
                <Pagination meta={paymentsPage.meta} onPageChange={paymentsPage.setPage} />
                </>
              ) : null}
            </div>

            {selectedInvoice && tab === 'invoices' ? (
              <aside className="animate-slide-in">
                <Card className="sticky top-4">
                  <div className="mb-4 flex items-start justify-between gap-2">
                    <div>
                      <CardTitle className="text-base">{selectedInvoice.invoice_number}</CardTitle>
                      <CardDescription>{selectedInvoice.tenant?.name}</CardDescription>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setSelectedInvoiceId(null)}
                      aria-label="Close"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>

                  <Badge tone={invoiceTone(selectedInvoice.status)}>{selectedInvoice.status}</Badge>

                  <dl className="mt-4 space-y-2 text-sm">
                    <Detail label="Total" value={formatMoney(selectedInvoice.grand_total, selectedInvoice.currency_code)} />
                    <Detail label="Tax" value={formatMoney(selectedInvoice.tax_total, selectedInvoice.currency_code)} />
                    <Detail label="Due" value={formatDate(selectedInvoice.due_date)} />
                    <Detail label="Issued" value={formatDate(selectedInvoice.issued_at)} />
                    <Detail label="Paid" value={formatDate(selectedInvoice.paid_at)} />
                    <Detail label="Mode" value={selectedInvoice.billing_mode} />
                  </dl>

                  {canManage &&
                  (selectedInvoice.status === 'issued' || selectedInvoice.status === 'overdue') ? (
                    <div className="mt-5 space-y-4 border-t border-white/12 pt-4">
                      <form onSubmit={onPay} noValidate className="space-y-3">
                        <p className="text-xs font-semibold tracking-wide text-muted uppercase">
                          Record payment
                        </p>
                        <Field label="Amount" htmlFor="pay-amount" required error={fieldErrors.amount}>
                          <Input
                            id="pay-amount"
                            type="number"
                            min={0.01}
                            step="0.01"
                            value={payForm.amount || String(selectedInvoice.grand_total)}
                            onChange={(e) => {
                              setPayForm((c) => ({ ...c, amount: e.target.value }))
                              clearFieldError('amount')
                            }}
                            aria-invalid={Boolean(fieldErrors.amount)}
                          />
                        </Field>
                        <div>
                          <Label htmlFor="pay-method">Method</Label>
                          <Select
                            id="pay-method"
                            value={payForm.method}
                            onChange={(e) => setPayForm((c) => ({ ...c, method: e.target.value }))}
                          >
                            <option value="bank_transfer">Bank transfer</option>
                            <option value="card">Card</option>
                            <option value="upi">UPI</option>
                            <option value="cash">Cash</option>
                            <option value="other">Other</option>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="pay-ref">Reference</Label>
                          <Input
                            id="pay-ref"
                            value={payForm.reference}
                            onChange={(e) => setPayForm((c) => ({ ...c, reference: e.target.value }))}
                            placeholder="Optional"
                          />
                        </div>
                        <Button type="submit" loading={payMutation.isPending} className="w-full">
                          Record payment
                        </Button>
                      </form>

                      <Button
                        variant="danger"
                        size="sm"
                        className="w-full"
                        disabled={voidMutation.isPending}
                        onClick={() => void onVoid(selectedInvoice)}
                      >
                        Void invoice
                      </Button>
                    </div>
                  ) : null}
                </Card>
              </aside>
            ) : null}
          </div>
        </>
      )}
    </div>
  )
}

function SummaryChip({
  label,
  value,
  hint,
  icon: Icon,
  accent = false,
}: {
  label: string
  value: string
  hint: string
  icon: typeof Wallet
  accent?: boolean
}) {
  return (
    <Card className={cn('relative overflow-hidden', accent && 'border-accent/35')}>
      <div
        className={cn(
          'absolute -right-6 -top-6 h-24 w-24 rounded-full opacity-70',
          accent ? 'bg-accent/20' : 'bg-white/10',
        )}
      />
      <div className="relative flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-muted">{label}</p>
          <p className="mt-2 font-display text-2xl font-bold tracking-wide text-ink xl:text-3xl">
            {value}
          </p>
          <p className="mt-1 text-xs text-muted">{hint}</p>
        </div>
        <div
          className={cn(
            'flex h-10 w-10 items-center justify-center rounded-xl',
            accent ? 'bg-accent text-accent-ink' : 'bg-white/12 text-ink',
          )}
        >
          <Icon className="h-4 w-4" />
        </div>
      </div>
    </Card>
  )
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-muted">{label}</dt>
      <dd className="font-medium text-ink">{value}</dd>
    </div>
  )
}
