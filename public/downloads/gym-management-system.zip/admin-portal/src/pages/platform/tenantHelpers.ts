import type { PlatformTenantStatus } from '@/api/platform'
import type { Badge } from '@/components/ui/Badge'
import type { ComponentProps } from 'react'

type BadgeTone = ComponentProps<typeof Badge>['tone']

export function tenantStatusTone(status: PlatformTenantStatus): BadgeTone {
  switch (status) {
    case 'active':
      return 'success'
    case 'trial':
      return 'accent'
    case 'suspended':
      return 'danger'
    case 'cancelled':
      return 'neutral'
    default:
      return 'neutral'
  }
}

export function daysUntil(iso?: string | null): number | null {
  if (!iso) return null
  const target = new Date(iso).getTime()
  if (Number.isNaN(target)) return null
  const diff = target - Date.now()
  return Math.ceil(diff / (1000 * 60 * 60 * 24))
}
