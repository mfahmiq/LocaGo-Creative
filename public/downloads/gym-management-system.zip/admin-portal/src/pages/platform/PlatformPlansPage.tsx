import { useEffect, useMemo, useState, type Dispatch, type FormEvent, type SetStateAction } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Check,
  CreditCard,
  Plus,
  RefreshCw,
  Search,
  Trash2,
  X,
} from 'lucide-react'
import {
  createSaasPlan,
  deleteSaasPlan,
  fetchPlatformTenants,
  fetchSaasPlans,
  updateSaasPlan,
  updateSaasPlanLimits,
  type SaasPlan,
} from '@/api/platform'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatMoney, formatNumber } from '@/lib/format'
import { cn } from '@/lib/cn'
import { useClientPagination } from '@/hooks/useClientPagination'

const MODULE_OPTIONS = [
  { key: 'module_pos', label: 'POS' },
  { key: 'module_nutrition', label: 'Nutrition' },
  { key: 'module_waitlist', label: 'Waitlist' },
  { key: 'module_referral', label: 'Referral' },
  { key: 'module_equipment', label: 'Equipment' },
] as const

type ModuleKey = (typeof MODULE_OPTIONS)[number]['key']

type PlanFormState = {
  code: string
  name: string
  description: string
  price: string
  currency_code: string
  billing_interval: 'monthly' | 'yearly'
  is_active: boolean
  max_seats: string
  max_branches: string
  max_members: string
  storage_mb: string
  modules: Record<ModuleKey, boolean>
}

const emptyForm = (): PlanFormState => ({
  code: '',
  name: '',
  description: '',
  price: '0',
  currency_code: 'USD',
  billing_interval: 'monthly',
  is_active: true,
  max_seats: '10',
  max_branches: '2',
  max_members: '500',
  storage_mb: '1024',
  modules: {
    module_pos: true,
    module_nutrition: false,
    module_waitlist: true,
    module_referral: false,
    module_equipment: false,
  },
})

function formFromPlan(plan: SaasPlan): PlanFormState {
  return {
    code: plan.code,
    name: plan.name,
    description: plan.description ?? '',
    price: String(plan.price ?? 0),
    currency_code: plan.currency_code || 'USD',
    billing_interval: (plan.billing_interval as 'monthly' | 'yearly') || 'monthly',
    is_active: plan.is_active,
    max_seats: String(plan.limits?.max_seats ?? 10),
    max_branches: String(plan.limits?.max_branches ?? 2),
    max_members: String(plan.limits?.max_members ?? 500),
    storage_mb: String(plan.limits?.storage_mb ?? 1024),
    modules: {
      module_pos: Boolean(plan.limits?.module_pos),
      module_nutrition: Boolean(plan.limits?.module_nutrition),
      module_waitlist: Boolean(plan.limits?.module_waitlist),
      module_referral: Boolean(plan.limits?.module_referral),
      module_equipment: Boolean(plan.limits?.module_equipment),
    },
  }
}

export function PlatformPlansPage() {
  const { hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()
  const canManage = hasPermission('platform.plans.manage')
  const canViewTenants = hasPermission('platform.tenants.view')

  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all')
  const [showCreate, setShowCreate] = useState(false)
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }
  const [createForm, setCreateForm] = useState<PlanFormState>(emptyForm)
  const [editForm, setEditForm] = useState<PlanFormState>(emptyForm)

  const plansQuery = useQuery({
    queryKey: ['platform', 'saas-plans'],
    queryFn: fetchSaasPlans,
  })

  const tenantsQuery = useQuery({
    queryKey: ['platform', 'tenants'],
    queryFn: () => fetchPlatformTenants(),
    enabled: canViewTenants,
  })

  const plans = plansQuery.data ?? []
  const tenants = tenantsQuery.data ?? []

  const adoption = useMemo(() => {
    const map = new Map<number, number>()
    for (const tenant of tenants) {
      if (tenant.saas_plan_id == null) continue
      map.set(tenant.saas_plan_id, (map.get(tenant.saas_plan_id) ?? 0) + 1)
    }
    return map
  }, [tenants])

  const stats = useMemo(() => {
    const active = plans.filter((plan) => plan.is_active).length
    return {
      total: plans.length,
      active,
      inactive: plans.length - active,
      assigned: [...adoption.values()].reduce((sum, n) => sum + n, 0),
    }
  }, [plans, adoption])

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase()
    return plans
      .filter((plan) => {
        if (statusFilter === 'active') return plan.is_active
        if (statusFilter === 'inactive') return !plan.is_active
        return true
      })
      .filter((plan) => {
        if (!q) return true
        return (
          plan.name.toLowerCase().includes(q) ||
          plan.code.toLowerCase().includes(q) ||
          (plan.description ?? '').toLowerCase().includes(q)
        )
      })
      .sort((a, b) => a.name.localeCompare(b.name))
  }, [plans, search, statusFilter])

  const {
    rows: pageRows,
    meta: pageMeta,
    setPage,
  } = useClientPagination(rows, `${statusFilter}|${search}|${rows.length}`)

  const selected = useMemo(
    () => plans.find((plan) => plan.id === selectedId) ?? null,
    [plans, selectedId],
  )

  useEffect(() => {
    if (selected) setEditForm(formFromPlan(selected))
  }, [selected])

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ['platform', 'saas-plans'] })
  }

  const createMutation = useMutation({
    mutationFn: createSaasPlan,
    onSuccess: (plan) => {
      setError(null)
      showSuccess(`Plan “${plan.name}” created.`)
      setShowCreate(false)
      setCreateForm(emptyForm())
      setSelectedId(plan.id)
      invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to create plan.')
    },
  })

  const updateMutation = useMutation({
    mutationFn: async (plan: SaasPlan) => {
      const updated = await updateSaasPlan(plan.id, {
        code: editForm.code.trim().toLowerCase(),
        name: editForm.name.trim(),
        description: editForm.description.trim() || null,
        price: Number(editForm.price) || 0,
        currency_code: editForm.currency_code.trim().toUpperCase() || 'USD',
        billing_interval: editForm.billing_interval,
        is_active: editForm.is_active,
      })
      await updateSaasPlanLimits(plan.id, {
        max_seats: Number(editForm.max_seats) || 1,
        max_branches: Number(editForm.max_branches) || 1,
        max_members: Number(editForm.max_members) || 1,
        storage_mb: Number(editForm.storage_mb) || 1,
        ...editForm.modules,
      })
      return updated
    },
    onSuccess: () => {
      setError(null)
      showSuccess('Plan saved.')
      invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to save plan.')
    },
  })

  const toggleActiveMutation = useMutation({
    mutationFn: (plan: SaasPlan) => updateSaasPlan(plan.id, { is_active: !plan.is_active }),
    onSuccess: (plan) => {
      setError(null)
      showSuccess(`Plan “${plan.name}” marked ${plan.is_active ? 'active' : 'inactive'}.`)
      invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update status.')
    },
  })

  const deleteMutation = useMutation({
    mutationFn: (plan: SaasPlan) => deleteSaasPlan(plan.id),
    onSuccess: () => {
      setError(null)
      showSuccess('Plan deleted.')
      setSelectedId(null)
      invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to delete plan.')
    },
  })

  const onCreate = (event: FormEvent) => {
    event.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'code', label: 'Code', value: createForm.code },
      { key: 'name', label: 'Name', value: createForm.name },
    ])
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    createMutation.mutate({
      code: createForm.code.trim().toLowerCase(),
      name: createForm.name.trim(),
      description: createForm.description.trim() || undefined,
      price: Number(createForm.price) || 0,
      currency_code: createForm.currency_code.trim().toUpperCase() || 'USD',
      billing_interval: createForm.billing_interval,
      is_active: createForm.is_active,
      limits: {
        max_seats: Number(createForm.max_seats) || 1,
        max_branches: Number(createForm.max_branches) || 1,
        max_members: Number(createForm.max_members) || 1,
        storage_mb: Number(createForm.storage_mb) || 1,
        ...createForm.modules,
      },
    })
  }

  const onSave = (event: FormEvent) => {
    event.preventDefault()
    if (!selected) return
    const errors = collectRequiredErrors([
      { key: 'code', label: 'Code', value: editForm.code },
      { key: 'name', label: 'Name', value: editForm.name },
    ])
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    updateMutation.mutate(selected)
  }

  const onToggleActive = async (plan: SaasPlan) => {
    const activating = !plan.is_active
    const ok = await confirm({
      title: activating ? 'Activate plan?' : 'Deactivate plan?',
      message: activating
        ? `Activate “${plan.name}” (${plan.code})? It will become available for new tenant assignments.`
        : `Deactivate “${plan.name}” (${plan.code})? It will no longer be offered for new assignments. Existing tenants keep their plan.`,
      confirmLabel: activating ? 'Activate' : 'Deactivate',
      tone: activating ? 'primary' : 'danger',
    })
    if (!ok) return
    toggleActiveMutation.mutate(plan)
  }

  const onDelete = async (plan: SaasPlan) => {
    const inUse = adoption.get(plan.id) ?? 0
    if (inUse > 0) {
      setError(`“${plan.name}” is assigned to ${inUse} tenant(s). Reassign them before deleting.`)
      return
    }
    const ok = await confirm({
      title: 'Delete plan?',
      message: `Permanently delete “${plan.name}” (${plan.code})? This cannot be undone.`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (!ok) return
    deleteMutation.mutate(plan)
  }

  const columns: Column<SaasPlan>[] = [
    {
      key: 'name',
      header: 'Plan',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">{row.name}</p>
          <p className="font-mono text-xs text-muted">{row.code}</p>
        </button>
      ),
    },
    {
      key: 'price',
      header: 'Pricing',
      cell: (row) => (
        <span className="text-sm">
          {formatMoney(row.price, row.currency_code)}
          <span className="mt-0.5 block text-xs text-muted">/{row.billing_interval}</span>
        </span>
      ),
    },
    {
      key: 'limits',
      header: 'Entitlements',
      cell: (row) => (
        <span className="text-sm">
          {formatNumber(row.limits?.max_members ?? 0)} members
          <span className="mt-0.5 block text-xs text-muted">
            {formatNumber(row.limits?.max_branches ?? 0)} branches ·{' '}
            {formatNumber(row.limits?.max_seats ?? 0)} seats
          </span>
        </span>
      ),
    },
    {
      key: 'modules',
      header: 'Modules',
      cell: (row) => {
        const enabled = MODULE_OPTIONS.filter((m) => Boolean(row.limits?.[m.key])).map(
          (m) => m.label,
        )
        return (
          <span className="text-xs text-muted">
            {enabled.length ? enabled.join(' · ') : 'Core only'}
          </span>
        )
      },
    },
    {
      key: 'tenants',
      header: 'Tenants',
      cell: (row) => (
        <Badge tone={adoption.get(row.id) ? 'accent' : 'neutral'}>
          {formatNumber(adoption.get(row.id) ?? 0)}
        </Badge>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.is_active ? 'success' : 'neutral'}>
          {row.is_active ? 'active' : 'inactive'}
        </Badge>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedId(row.id)}>
          Manage
        </Button>
      ),
    },
  ]

  return (
    <div className="animate-fade-up space-y-6">
      <PageHeader
        title="SaaS plans"
        description="Platform subscription plans — pricing, entitlement limits, and module access for gym tenants."
        actions={
          <div className="flex flex-wrap gap-2">
            {canManage ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowCreate(true)
                  setSelectedId(null)
                }}
              >
                <Plus className="h-4 w-4" />
                New plan
              </Button>
            ) : (
              <Badge tone="neutral">View only</Badge>
            )}
            <Button size="sm" variant="secondary" onClick={() => invalidate()}>
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      {plansQuery.isError ? (
        <Alert tone="danger">
          {plansQuery.error instanceof ApiError
            ? plansQuery.error.message
            : 'Unable to load SaaS plans.'}
          <div className="mt-3">
            <Button size="sm" variant="secondary" onClick={() => void plansQuery.refetch()}>
              Try again
            </Button>
          </div>
        </Alert>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip label="Plans" value={formatNumber(stats.total)} />
        <SummaryChip label="Active" value={formatNumber(stats.active)} tone="success" />
        <SummaryChip label="Inactive" value={formatNumber(stats.inactive)} />
        <SummaryChip
          label="Tenant assignments"
          value={formatNumber(stats.assigned)}
          tone="accent"
        />
      </div>

      {showCreate && canManage ? (
        <Card className="border-accent/25">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <CardTitle>Create subscription plan</CardTitle>
              <CardDescription>
                Code must start with a letter and use lowercase letters, numbers, and underscores.
              </CardDescription>
            </div>
            <Button size="sm" variant="ghost" onClick={() => setShowCreate(false)} aria-label="Close">
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form onSubmit={onCreate} noValidate className="space-y-4">
            <PlanFormFields
              form={createForm}
              setForm={setCreateForm}
              codeEditable
              fieldErrors={fieldErrors}
              clearFieldError={clearFieldError}
            />
            <div className="flex flex-wrap gap-2">
              <Button type="submit" loading={createMutation.isPending}>
                Create plan
              </Button>
              <Button type="button" variant="ghost" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <Card className="p-4 sm:p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2">
            {(
              [
                { value: 'all', label: 'All', count: stats.total },
                { value: 'active', label: 'Active', count: stats.active },
                { value: 'inactive', label: 'Inactive', count: stats.inactive },
              ] as const
            ).map((filter) => {
              const active = statusFilter === filter.value
              return (
                <button
                  key={filter.value}
                  type="button"
                  onClick={() => setStatusFilter(filter.value)}
                  className={cn(
                    'inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition',
                    active
                      ? 'bg-accent text-accent-ink'
                      : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                  )}
                >
                  {filter.label}
                  <span
                    className={cn(
                      'rounded-md px-1.5 py-0.5 text-[11px]',
                      active ? 'bg-black/15' : 'bg-white/10',
                    )}
                  >
                    {filter.count}
                  </span>
                </button>
              )
            })}
          </div>
          <div className="relative w-full lg:max-w-sm">
            <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, code, description…"
              className="pl-10"
              aria-label="Search plans"
            />
          </div>
        </div>
      </Card>

      <div className={cn('grid gap-4', selected ? 'xl:grid-cols-[1fr_24rem]' : '')}>
        <div className="min-w-0">
          {plansQuery.isPending ? (
            <div className="flex justify-center py-20">
              <Spinner label="Loading plans…" />
            </div>
          ) : (
            <DataTable
              columns={columns}
              rows={pageRows}
              rowKey={(row) => row.id}
              emptyTitle="No plans match"
              emptyDescription="Adjust filters or create a new subscription plan."
            />
          )}
          <Pagination meta={pageMeta} onPageChange={setPage} />
        </div>

        {selected ? (
          <aside className="animate-slide-in">
            <Card className="sticky top-4">
              <div className="mb-4 flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                    <CreditCard className="h-5 w-5" />
                  </div>
                  <CardTitle className="truncate text-base">{selected.name}</CardTitle>
                  <CardDescription className="font-mono">{selected.code}</CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedId(null)}
                  aria-label="Close details"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="mb-4 flex flex-wrap gap-2">
                <Badge tone={selected.is_active ? 'success' : 'neutral'}>
                  {selected.is_active ? 'active' : 'inactive'}
                </Badge>
                <Badge tone="neutral">
                  {formatNumber(adoption.get(selected.id) ?? 0)} tenant
                  {(adoption.get(selected.id) ?? 0) === 1 ? '' : 's'}
                </Badge>
              </div>

              <dl className="mb-4 space-y-2 text-sm">
                <div className="flex justify-between gap-3">
                  <dt className="text-muted">Price</dt>
                  <dd className="font-medium text-ink">
                    {formatMoney(selected.price, selected.currency_code)} /{' '}
                    {selected.billing_interval}
                  </dd>
                </div>
                <div className="flex justify-between gap-3">
                  <dt className="text-muted">Created</dt>
                  <dd className="font-medium text-ink">{formatDate(selected.created_at)}</dd>
                </div>
              </dl>

              {canManage ? (
                <form onSubmit={onSave} noValidate className="space-y-4 border-t border-white/12 pt-4">
                  <PlanFormFields
                    form={editForm}
                    setForm={setEditForm}
                    codeEditable
                    compact
                    fieldErrors={fieldErrors}
                    clearFieldError={clearFieldError}
                  />

                  <div className="flex flex-wrap gap-2">
                    <Button type="submit" loading={updateMutation.isPending}>
                      <Check className="h-4 w-4" />
                      Save changes
                    </Button>
                    <Button
                      type="button"
                      variant="secondary"
                      disabled={toggleActiveMutation.isPending}
                      onClick={() => void onToggleActive(selected)}
                    >
                      {selected.is_active ? 'Deactivate' : 'Activate'}
                    </Button>
                    <Button
                      type="button"
                      variant="danger"
                      disabled={deleteMutation.isPending}
                      onClick={() => void onDelete(selected)}
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete
                    </Button>
                  </div>
                </form>
              ) : (
                <p className="border-t border-white/12 pt-4 text-sm text-muted">
                  View only. Editing requires platform.plans.manage.
                </p>
              )}
            </Card>
          </aside>
        ) : null}
      </div>
    </div>
  )
}

function PlanFormFields({
  form,
  setForm,
  codeEditable,
  compact = false,
  fieldErrors = {},
  clearFieldError,
}: {
  form: PlanFormState
  setForm: Dispatch<SetStateAction<PlanFormState>>
  codeEditable: boolean
  compact?: boolean
  fieldErrors?: FieldErrors
  clearFieldError?: (key: string) => void
}) {
  const clear = (key: string) => clearFieldError?.(key)
  return (
    <div className={cn('grid gap-3', compact ? 'grid-cols-1' : 'sm:grid-cols-2 xl:grid-cols-4')}>
      <Field label="Code" htmlFor={`code-${compact ? 'edit' : 'create'}`} required error={fieldErrors.code}>
        <Input
          id={`code-${compact ? 'edit' : 'create'}`}
          pattern="^[a-z][a-z0-9_]*$"
          value={form.code}
          disabled={!codeEditable && compact}
          onChange={(e) => {
            setForm((c) => ({ ...c, code: e.target.value.toLowerCase() }))
            clear('code')
          }}
          placeholder="growth"
          aria-invalid={Boolean(fieldErrors.code)}
        />
      </Field>
      <Field label="Name" htmlFor={`name-${compact ? 'edit' : 'create'}`} required error={fieldErrors.name}>
        <Input
          id={`name-${compact ? 'edit' : 'create'}`}
          value={form.name}
          onChange={(e) => {
            setForm((c) => ({ ...c, name: e.target.value }))
            clear('name')
          }}
          aria-invalid={Boolean(fieldErrors.name)}
        />
      </Field>
      <Field label="Price" htmlFor={`price-${compact ? 'edit' : 'create'}`}>
        <Input
          id={`price-${compact ? 'edit' : 'create'}`}
          type="number"
          min={0}
          step="0.01"
          value={form.price}
          onChange={(e) => setForm((c) => ({ ...c, price: e.target.value }))}
        />
      </Field>
      <Field label="Currency" htmlFor={`currency-${compact ? 'edit' : 'create'}`}>
        <Input
          id={`currency-${compact ? 'edit' : 'create'}`}
          maxLength={3}
          value={form.currency_code}
          onChange={(e) => setForm((c) => ({ ...c, currency_code: e.target.value.toUpperCase() }))}
        />
      </Field>
      <Field label="Billing interval" htmlFor={`interval-${compact ? 'edit' : 'create'}`}>
        <Select
          id={`interval-${compact ? 'edit' : 'create'}`}
          value={form.billing_interval}
          onChange={(e) =>
            setForm((c) => ({
              ...c,
              billing_interval: e.target.value as 'monthly' | 'yearly',
            }))
          }
        >
          <option value="monthly">Monthly</option>
          <option value="yearly">Yearly</option>
        </Select>
      </Field>
      <Field label="Max members" htmlFor={`members-${compact ? 'edit' : 'create'}`}>
        <Input
          id={`members-${compact ? 'edit' : 'create'}`}
          type="number"
          min={1}
          value={form.max_members}
          onChange={(e) => setForm((c) => ({ ...c, max_members: e.target.value }))}
        />
      </Field>
      <Field label="Max branches" htmlFor={`branches-${compact ? 'edit' : 'create'}`}>
        <Input
          id={`branches-${compact ? 'edit' : 'create'}`}
          type="number"
          min={1}
          value={form.max_branches}
          onChange={(e) => setForm((c) => ({ ...c, max_branches: e.target.value }))}
        />
      </Field>
      <Field label="Max seats" htmlFor={`seats-${compact ? 'edit' : 'create'}`}>
        <Input
          id={`seats-${compact ? 'edit' : 'create'}`}
          type="number"
          min={1}
          value={form.max_seats}
          onChange={(e) => setForm((c) => ({ ...c, max_seats: e.target.value }))}
        />
      </Field>
      <Field label="Storage (MB)" htmlFor={`storage-${compact ? 'edit' : 'create'}`}>
        <Input
          id={`storage-${compact ? 'edit' : 'create'}`}
          type="number"
          min={1}
          value={form.storage_mb}
          onChange={(e) => setForm((c) => ({ ...c, storage_mb: e.target.value }))}
        />
      </Field>
      <div className={cn(compact ? '' : 'sm:col-span-2 xl:col-span-4')}>
        <Label>Modules</Label>
        <div className="mt-1.5 flex flex-wrap gap-2">
          {MODULE_OPTIONS.map((module) => {
            const on = form.modules[module.key]
            return (
              <button
                key={module.key}
                type="button"
                onClick={() =>
                  setForm((c) => ({
                    ...c,
                    modules: { ...c.modules, [module.key]: !c.modules[module.key] },
                  }))
                }
                className={cn(
                  'rounded-xl px-3 py-2 text-sm font-semibold transition',
                  on ? 'bg-accent text-accent-ink' : 'bg-white/8 text-muted hover:bg-white/12',
                )}
              >
                {module.label}
              </button>
            )
          })}
        </div>
      </div>
      <div className={cn(compact ? '' : 'sm:col-span-2 xl:col-span-4')}>
        <Label htmlFor={`desc-${compact ? 'edit' : 'create'}`}>Description</Label>
        <Textarea
          id={`desc-${compact ? 'edit' : 'create'}`}
          value={form.description}
          onChange={(e) => setForm((c) => ({ ...c, description: e.target.value }))}
          placeholder="What this plan includes…"
          className="min-h-20"
        />
      </div>
      <div className={cn('flex items-center gap-2', compact ? '' : 'sm:col-span-2 xl:col-span-4')}>
        <input
          id={`active-${compact ? 'edit' : 'create'}`}
          type="checkbox"
          checked={form.is_active}
          onChange={(e) => setForm((c) => ({ ...c, is_active: e.target.checked }))}
          className="h-4 w-4 rounded border-white/20"
        />
        <Label htmlFor={`active-${compact ? 'edit' : 'create'}`} className="mb-0">
          Plan is active and assignable
        </Label>
      </div>
    </div>
  )
}

function SummaryChip({
  label,
  value,
  tone = 'neutral',
}: {
  label: string
  value: string
  tone?: 'neutral' | 'success' | 'accent'
}) {
  const tones = {
    neutral: 'border-white/12 bg-white/6',
    success: 'border-success/25 bg-success/10',
    accent: 'border-accent/30 bg-accent/10',
  }
  return (
    <div className={cn('rounded-2xl border px-4 py-3', tones[tone])}>
      <p className="text-xs font-semibold tracking-wide text-muted uppercase">{label}</p>
      <p className="mt-1 font-display text-2xl font-bold text-ink">{value}</p>
    </div>
  )
}
