import type { ReactNode } from 'react'
import { PageHeader } from '@/components/ui/PageHeader'
import { Badge } from '@/components/ui/Badge'
import { ReportExportActions } from '@/components/reports/ReportExportActions'
import type { ExportColumn } from '@/lib/exportReport'

export function PlatformReportShell<T>({
  title,
  description,
  reportKey,
  columns,
  rows,
  subtitle,
  loading,
  children,
  canExport = true,
}: {
  title: string
  description: string
  reportKey: string
  columns: ExportColumn<T>[]
  rows: T[]
  subtitle?: string
  loading?: boolean
  children: ReactNode
  canExport?: boolean
}) {
  return (
    <div className="animate-fade-up space-y-6">
      <PageHeader
        title={title}
        description={description}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="accent">Platform analytics</Badge>
            {canExport ? (
              <ReportExportActions
                reportKey={reportKey}
                reportName={title}
                columns={columns}
                rows={rows}
                subtitle={subtitle}
                disabled={loading}
              />
            ) : null}
          </div>
        }
      />
      {children}
    </div>
  )
}
