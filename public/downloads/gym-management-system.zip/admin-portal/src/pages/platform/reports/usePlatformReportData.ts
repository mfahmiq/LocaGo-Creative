import { useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  fetchPlatformBillingOverview,
  fetchPlatformTenants,
  fetchSaasPlans,
  type PlatformSubscriptionRow,
  type PlatformTenant,
  type SaasPlan,
} from '@/api/platform'
import { useAuth } from '@/auth/AuthContext'
import { daysUntil } from '@/pages/platform/tenantHelpers'

export function usePlatformReportData() {
  const { hasPermission } = useAuth()
  const canTenants = hasPermission('platform.tenants.view') || hasPermission('platform.reports.view')
  const canPlans = hasPermission('platform.plans.view') || hasPermission('platform.reports.view')
  const canBilling =
    hasPermission('platform.billing.view') || hasPermission('platform.reports.view')

  const tenantsQuery = useQuery({
    queryKey: ['platform', 'tenants'],
    queryFn: () => fetchPlatformTenants(),
    enabled: canTenants,
  })

  const plansQuery = useQuery({
    queryKey: ['platform', 'saas-plans'],
    queryFn: fetchSaasPlans,
    enabled: canPlans,
  })

  const billingQuery = useQuery({
    queryKey: ['platform', 'billing', 'overview', 'all'],
    queryFn: () => fetchPlatformBillingOverview(),
    enabled: canBilling,
  })

  const tenants = tenantsQuery.data ?? []
  const plans = plansQuery.data ?? []
  const billing = billingQuery.data

  const analytics = useMemo(() => buildAnalytics(tenants, plans, billing?.subscriptions ?? []), [
    tenants,
    plans,
    billing?.subscriptions,
  ])

  return {
    tenantsQuery,
    plansQuery,
    billingQuery,
    tenants,
    plans,
    billing,
    analytics,
    loading: tenantsQuery.isPending || plansQuery.isPending || (canBilling && billingQuery.isPending),
  }
}

export type PlatformReportAnalytics = ReturnType<typeof buildAnalytics>

function buildAnalytics(
  tenants: PlatformTenant[],
  plans: SaasPlan[],
  subscriptions: PlatformSubscriptionRow[],
) {
  const byStatus = {
    active: 0,
    trial: 0,
    suspended: 0,
    cancelled: 0,
    other: 0,
  }
  for (const tenant of tenants) {
    if (tenant.status in byStatus) {
      byStatus[tenant.status as keyof typeof byStatus] += 1
    } else {
      byStatus.other += 1
    }
  }

  const createdBuckets = new Map<string, number>()
  for (const tenant of tenants) {
    const key = tenant.created_at ? tenant.created_at.slice(0, 7) : 'unknown'
    createdBuckets.set(key, (createdBuckets.get(key) ?? 0) + 1)
  }
  const growth = [...createdBuckets.entries()]
    .filter(([key]) => key !== 'unknown')
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-8)
    .map(([label, value]) => ({ label, value }))

  const trialsEndingSoon = tenants.filter((tenant) => {
    if (tenant.status !== 'trial') return false
    const days = daysUntil(tenant.trial_ends_at)
    return days != null && days >= 0 && days <= 7
  })

  const planAdoption = plans.map((plan) => {
    const assigned = tenants.filter((tenant) => tenant.saas_plan_id === plan.id)
    return {
      plan,
      tenants: assigned.length,
      active: assigned.filter((t) => t.status === 'active').length,
      trial: assigned.filter((t) => t.status === 'trial').length,
      suspended: assigned.filter((t) => t.status === 'suspended').length,
    }
  })

  const mrr = subscriptions
    .filter((row) => row.billable)
    .reduce((sum, row) => sum + row.monthly_amount, 0)

  return {
    totalTenants: tenants.length,
    byStatus,
    growth,
    trialsEndingSoon,
    planAdoption,
    activePlans: plans.filter((p) => p.is_active).length,
    mrr,
    statusChart: [
      { label: 'Active', value: byStatus.active },
      { label: 'Trial', value: byStatus.trial },
      { label: 'Suspended', value: byStatus.suspended },
      { label: 'Cancelled', value: byStatus.cancelled },
    ],
    planChart: planAdoption.map((row) => ({
      label: row.plan.name,
      value: row.tenants,
    })),
  }
}
