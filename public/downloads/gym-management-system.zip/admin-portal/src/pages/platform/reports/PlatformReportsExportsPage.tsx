import { useMemo, useState } from 'react'
import { Download, FileSpreadsheet, FileText, Trash2 } from 'lucide-react'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { formatDate, formatNumber } from '@/lib/format'
import {
  clearExportHistory,
  exportRowsToExcel,
  exportRowsToPdf,
  readExportHistory,
  type ExportColumn,
  type ExportHistoryEntry,
} from '@/lib/exportReport'
import { usePlatformReportData } from '@/pages/platform/reports/usePlatformReportData'
import { Spinner } from '@/components/ui/Spinner'
import { useClientPagination } from '@/hooks/useClientPagination'

type CatalogItem = {
  key: string
  name: string
  description: string
  permission: 'view' | 'export'
}

const CATALOG: CatalogItem[] = [
  {
    key: 'platform-overview',
    name: 'Platform overview KPIs',
    description: 'Cross-tenant KPI snapshot',
    permission: 'view',
  },
  {
    key: 'platform-tenants',
    name: 'Tenant directory',
    description: 'Full tenant roster with status and plan',
    permission: 'view',
  },
  {
    key: 'platform-billing',
    name: 'Billing & subscriptions',
    description: 'Subscriptions plus invoice ledger',
    permission: 'view',
  },
  {
    key: 'platform-plans',
    name: 'Plan adoption',
    description: 'SaaS plan mix and entitlement limits',
    permission: 'view',
  },
]

export function PlatformReportsExportsPage() {
  const { hasPermission } = useAuth()
  const { showSuccess } = useFeedback()
  const canExport = hasPermission('platform.reports.export')
  const canView = hasPermission('platform.reports.view') || canExport
  const { tenants, plans, billing, analytics, loading } = usePlatformReportData()
  const [historyVersion, setHistoryVersion] = useState(0)

  const history = useMemo(() => {
    void historyVersion
    return readExportHistory()
  }, [historyVersion])

  const historyPage = useClientPagination(history, history.length)

  const refreshHistory = () => setHistoryVersion((v) => v + 1)

  const runExport = (item: CatalogItem, format: 'excel' | 'pdf') => {
    if (item.key === 'platform-overview') {
      const rows = [
        { metric: 'Total tenants', value: analytics.totalTenants },
        { metric: 'Active', value: analytics.byStatus.active },
        { metric: 'Trial', value: analytics.byStatus.trial },
        { metric: 'Suspended', value: analytics.byStatus.suspended },
        { metric: 'Active plans', value: analytics.activePlans },
        { metric: 'MRR', value: billing?.summary.mrr ?? analytics.mrr },
        { metric: 'Outstanding', value: billing?.summary.outstanding ?? 0 },
      ]
      const columns: ExportColumn<(typeof rows)[number]>[] = [
        { key: 'metric', header: 'Metric', value: (r) => r.metric },
        { key: 'value', header: 'Value', value: (r) => r.value },
      ]
      if (format === 'excel') exportRowsToExcel(item.key, item.name, columns, rows)
      else exportRowsToPdf(item.key, item.name, columns, rows)
    }

    if (item.key === 'platform-tenants') {
      const columns: ExportColumn<(typeof tenants)[number]>[] = [
        { key: 'name', header: 'Name', value: (r) => r.name },
        { key: 'slug', header: 'Slug', value: (r) => r.slug },
        { key: 'status', header: 'Status', value: (r) => r.status },
        { key: 'plan', header: 'Plan', value: (r) => r.saas_plan?.name ?? '' },
        { key: 'country', header: 'Country', value: (r) => r.primary_country ?? '' },
        { key: 'created', header: 'Created', value: (r) => r.created_at ?? '' },
      ]
      if (format === 'excel') exportRowsToExcel(item.key, item.name, columns, tenants)
      else exportRowsToPdf(item.key, item.name, columns, tenants)
    }

    if (item.key === 'platform-billing') {
      const rows = (billing?.subscriptions ?? []).map((row) => ({
        tenant: row.tenant_name,
        plan: row.plan_name ?? '',
        status: row.tenant_status,
        monthly: row.monthly_amount,
        balance: row.open_balance,
      }))
      const columns: ExportColumn<(typeof rows)[number]>[] = [
        { key: 'tenant', header: 'Tenant', value: (r) => r.tenant },
        { key: 'plan', header: 'Plan', value: (r) => r.plan },
        { key: 'status', header: 'Status', value: (r) => r.status },
        { key: 'monthly', header: 'Monthly', value: (r) => r.monthly },
        { key: 'balance', header: 'Open balance', value: (r) => r.balance },
      ]
      if (format === 'excel') exportRowsToExcel(item.key, item.name, columns, rows)
      else exportRowsToPdf(item.key, item.name, columns, rows)
    }

    if (item.key === 'platform-plans') {
      const rows = analytics.planAdoption.map(({ plan, tenants: count, active, trial }) => ({
        name: plan.name,
        code: plan.code,
        price: plan.price,
        tenants: count,
        active,
        trial,
        max_members: plan.limits?.max_members ?? 0,
      }))
      const columns: ExportColumn<(typeof rows)[number]>[] = [
        { key: 'name', header: 'Plan', value: (r) => r.name },
        { key: 'code', header: 'Code', value: (r) => r.code },
        { key: 'price', header: 'Price', value: (r) => r.price },
        { key: 'tenants', header: 'Tenants', value: (r) => r.tenants },
        { key: 'active', header: 'Active', value: (r) => r.active },
        { key: 'trial', header: 'Trial', value: (r) => r.trial },
        { key: 'max_members', header: 'Max members', value: (r) => r.max_members },
      ]
      if (format === 'excel') exportRowsToExcel(item.key, item.name, columns, rows)
      else exportRowsToPdf(item.key, item.name, columns, rows)
    }

    refreshHistory()
    showSuccess(`${format.toUpperCase()} export generated for ${item.name}.`)
  }

  const historyColumns: Column<ExportHistoryEntry>[] = [
    {
      key: 'report',
      header: 'Report',
      cell: (r) => (
        <div>
          <p className="font-semibold">{r.reportName}</p>
          <p className="font-mono text-xs text-muted">{r.fileName}</p>
        </div>
      ),
    },
    {
      key: 'format',
      header: 'Format',
      cell: (r) => (
        <Badge tone={r.format === 'excel' ? 'accent' : 'neutral'}>{r.format.toUpperCase()}</Badge>
      ),
    },
    { key: 'rows', header: 'Rows', cell: (r) => formatNumber(r.rowCount) },
    { key: 'created', header: 'Generated', cell: (r) => formatDate(r.createdAt) },
  ]

  if (!canView) {
    return (
      <Alert tone="info">
        Platform report exports require <code>platform.reports.view</code> or{' '}
        <code>platform.reports.export</code>.
      </Alert>
    )
  }

  return (
    <div className="animate-fade-up space-y-6">
      <PageHeader
        title="Report exports"
        description="Download platform report files as Excel (CSV) or PDF. Recent downloads are listed below."
        actions={
          <div className="flex flex-wrap gap-2">
            <Badge tone="accent">Export center</Badge>
            {!canExport ? <Badge tone="neutral">View + export via reports.view</Badge> : null}
          </div>
        }
      />

      {loading ? (
        <div className="flex justify-center py-16">
          <Spinner label="Preparing export catalog…" />
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {CATALOG.map((item) => (
            <Card key={item.key}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <CardTitle className="text-base">{item.name}</CardTitle>
                  <CardDescription>{item.description}</CardDescription>
                </div>
                <Download className="h-5 w-5 text-accent" />
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <Button
                  size="sm"
                  variant="secondary"
                  disabled={!canView || (item.key === 'platform-tenants' && tenants.length === 0)}
                  onClick={() => runExport(item, 'excel')}
                >
                  <FileSpreadsheet className="h-4 w-4" />
                  Excel
                </Button>
                <Button
                  size="sm"
                  variant="secondary"
                  disabled={!canView || (item.key === 'platform-plans' && plans.length === 0)}
                  onClick={() => runExport(item, 'pdf')}
                >
                  <FileText className="h-4 w-4" />
                  PDF
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <div className="flex items-center justify-between gap-3">
        <h2 className="font-display text-lg font-bold uppercase tracking-wide text-ink">
          Recent exports
        </h2>
        {history.length > 0 ? (
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              clearExportHistory()
              refreshHistory()
              showSuccess('Export history cleared.')
            }}
          >
            <Trash2 className="h-4 w-4" />
            Clear history
          </Button>
        ) : null}
      </div>

      <DataTable
        columns={historyColumns}
        rows={historyPage.rows}
        rowKey={(row) => row.id}
        emptyTitle="No exports yet"
        emptyDescription="Generate an Excel or PDF report from the catalog above."
      />
      <Pagination meta={historyPage.meta} onPageChange={historyPage.setPage} />
    </div>
  )
}
