import { Alert } from '@/components/ui/Alert'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Spinner } from '@/components/ui/Spinner'
import { SimpleBarChart } from '@/components/charts/SimpleBarChart'
import { SimpleLineChart } from '@/components/charts/SimpleLineChart'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatNumber } from '@/lib/format'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import type { PlatformTenant } from '@/api/platform'
import type { ExportColumn } from '@/lib/exportReport'
import { PlatformReportShell } from '@/pages/platform/reports/PlatformReportShell'
import { usePlatformReportData } from '@/pages/platform/reports/usePlatformReportData'
import { daysUntil, tenantStatusTone } from '@/pages/platform/tenantHelpers'
import { useClientPagination } from '@/hooks/useClientPagination'

export function PlatformReportsTenantsPage() {
  const { hasPermission } = useAuth()
  const canExport = hasPermission('platform.reports.export') || hasPermission('platform.reports.view')
  const { tenants, analytics, loading, tenantsQuery } = usePlatformReportData()

  const rows = [...tenants].sort((a, b) => a.name.localeCompare(b.name))
  const { rows: pageRows, meta, setPage } = useClientPagination(rows, rows.length)

  const exportColumns: ExportColumn<PlatformTenant>[] = [
    { key: 'name', header: 'Name', value: (r) => r.name },
    { key: 'slug', header: 'Slug', value: (r) => r.slug },
    { key: 'status', header: 'Status', value: (r) => r.status },
    { key: 'plan', header: 'Plan', value: (r) => r.saas_plan?.name ?? '' },
    { key: 'country', header: 'Country', value: (r) => r.primary_country ?? '' },
    { key: 'currency', header: 'Currency', value: (r) => r.base_currency ?? '' },
    { key: 'trial_ends', header: 'Trial ends', value: (r) => r.trial_ends_at ?? '' },
    { key: 'created', header: 'Created', value: (r) => r.created_at ?? '' },
  ]

  const columns: Column<PlatformTenant>[] = [
    {
      key: 'name',
      header: 'Tenant',
      cell: (r) => (
        <div>
          <p className="font-semibold">{r.name}</p>
          <p className="font-mono text-xs text-muted">/{r.slug}</p>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (r) => <Badge tone={tenantStatusTone(r.status)}>{r.status}</Badge>,
    },
    { key: 'plan', header: 'Plan', cell: (r) => r.saas_plan?.name ?? '—' },
    { key: 'country', header: 'Country', cell: (r) => r.primary_country ?? '—' },
    {
      key: 'trial',
      header: 'Trial',
      cell: (r) => {
        if (!r.trial_ends_at) return '—'
        const days = daysUntil(r.trial_ends_at)
        return (
          <span>
            {formatDate(r.trial_ends_at)}
            {days != null ? (
              <span className="mt-0.5 block text-xs text-muted">
                {days < 0 ? 'Expired' : `${days}d left`}
              </span>
            ) : null}
          </span>
        )
      },
    },
    { key: 'created', header: 'Created', cell: (r) => formatDate(r.created_at) },
  ]

  return (
    <PlatformReportShell
      title="Tenant reports"
      description="Tenant growth, status, and activation trends across the platform."
      reportKey="platform-tenants"
      columns={exportColumns}
      rows={rows}
      loading={loading}
      canExport={canExport}
    >
      {tenantsQuery.isError ? (
        <Alert tone="danger">
          {tenantsQuery.error instanceof ApiError
            ? tenantsQuery.error.message
            : 'Unable to load tenants.'}
        </Alert>
      ) : null}

      {loading ? (
        <div className="flex justify-center py-20">
          <Spinner label="Loading tenant trends…" />
        </div>
      ) : (
        <>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <Stat label="Total" value={formatNumber(analytics.totalTenants)} />
            <Stat label="Active" value={formatNumber(analytics.byStatus.active)} />
            <Stat label="Trial" value={formatNumber(analytics.byStatus.trial)} />
            <Stat
              label="Trials ≤ 7 days"
              value={formatNumber(analytics.trialsEndingSoon.length)}
            />
          </div>

          <div className="grid gap-4 xl:grid-cols-2">
            <SimpleLineChart
              title="Provisioning trend"
              description="New tenants by month"
              data={
                analytics.growth.length
                  ? analytics.growth
                  : [{ label: '—', value: 0 }]
              }
            />
            <SimpleBarChart
              title="Status distribution"
              description="Current lifecycle mix"
              data={analytics.statusChart}
            />
          </div>

          {analytics.trialsEndingSoon.length > 0 ? (
            <Card>
              <CardTitle>Trials ending soon</CardTitle>
              <CardDescription>Follow up before expiry</CardDescription>
              <ul className="mt-3 space-y-2">
                {analytics.trialsEndingSoon.slice(0, 8).map((tenant) => (
                  <li
                    key={tenant.id}
                    className="flex items-center justify-between rounded-xl border border-white/12 bg-white/6 px-3 py-2 text-sm"
                  >
                    <span className="font-medium">{tenant.name}</span>
                    <span className="text-muted">{formatDate(tenant.trial_ends_at)}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ) : null}

          <DataTable
            columns={columns}
            rows={pageRows}
            rowKey={(row) => row.id}
            emptyTitle="No tenants"
            emptyDescription="Provision gyms to populate this report."
          />
          <Pagination meta={meta} onPageChange={setPage} />
        </>
      )}
    </PlatformReportShell>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <Card>
      <p className="text-xs font-semibold tracking-wide text-muted uppercase">{label}</p>
      <p className="mt-1 font-display text-3xl font-bold text-ink">{value}</p>
    </Card>
  )
}
