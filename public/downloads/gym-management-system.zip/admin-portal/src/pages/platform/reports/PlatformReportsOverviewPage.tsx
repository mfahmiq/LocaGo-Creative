import { Link } from 'react-router-dom'
import { Building2, CreditCard, Download, Receipt } from 'lucide-react'
import { Alert } from '@/components/ui/Alert'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Spinner } from '@/components/ui/Spinner'
import { SimpleBarChart } from '@/components/charts/SimpleBarChart'
import { DataTable, type Column } from '@/components/table/DataTable'
import { formatMoney, formatNumber } from '@/lib/format'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { PlatformReportShell } from '@/pages/platform/reports/PlatformReportShell'
import { usePlatformReportData } from '@/pages/platform/reports/usePlatformReportData'
import type { ExportColumn } from '@/lib/exportReport'

type OverviewRow = {
  metric: string
  value: string
  detail: string
}

export function PlatformReportsOverviewPage() {
  const { hasPermission } = useAuth()
  const canExport = hasPermission('platform.reports.export') || hasPermission('platform.reports.view')
  const { analytics, tenants, billing, loading, tenantsQuery, billingQuery } = usePlatformReportData()

  const overviewRows: OverviewRow[] = [
    {
      metric: 'Total tenants',
      value: formatNumber(analytics.totalTenants),
      detail: `${formatNumber(analytics.byStatus.active)} active · ${formatNumber(analytics.byStatus.trial)} trial`,
    },
    {
      metric: 'Suspended',
      value: formatNumber(analytics.byStatus.suspended),
      detail: 'Access paused',
    },
    {
      metric: 'Active SaaS plans',
      value: formatNumber(analytics.activePlans),
      detail: 'Assignable catalog',
    },
    {
      metric: 'Estimated MRR',
      value: formatMoney(billing?.summary.mrr ?? analytics.mrr, billing?.summary.currency_code ?? 'USD'),
      detail: `${formatNumber(billing?.summary.billable_tenants ?? 0)} billable`,
    },
    {
      metric: 'Outstanding invoices',
      value: formatMoney(
        billing?.summary.outstanding ?? 0,
        billing?.summary.currency_code ?? 'USD',
      ),
      detail: `${formatNumber(billing?.summary.open_invoices ?? 0)} open`,
    },
    {
      metric: 'Collected this month',
      value: formatMoney(
        billing?.summary.collected_this_month ?? 0,
        billing?.summary.currency_code ?? 'USD',
      ),
      detail: `${formatNumber(billing?.summary.paid_invoices ?? 0)} paid invoices`,
    },
    {
      metric: 'Trials ending ≤ 7 days',
      value: formatNumber(analytics.trialsEndingSoon.length),
      detail: 'Needs follow-up',
    },
  ]

  const exportColumns: ExportColumn<OverviewRow>[] = [
    { key: 'metric', header: 'Metric', value: (r) => r.metric },
    { key: 'value', header: 'Value', value: (r) => r.value },
    { key: 'detail', header: 'Detail', value: (r) => r.detail },
  ]

  const snapshotColumns: Column<OverviewRow>[] = [
    { key: 'metric', header: 'KPI', cell: (r) => <span className="font-semibold">{r.metric}</span> },
    { key: 'value', header: 'Value', className: 'font-semibold', cell: (r) => r.value },
    { key: 'detail', header: 'Notes', cell: (r) => <span className="text-muted">{r.detail}</span> },
  ]

  const error =
    (tenantsQuery.error instanceof ApiError && tenantsQuery.error.message) ||
    (billingQuery.error instanceof ApiError && billingQuery.error.message) ||
    null

  return (
    <PlatformReportShell
      title="Platform reports"
      description="Cross-tenant KPIs and platform analytics across gyms, plans, and billing."
      reportKey="platform-overview"
      columns={exportColumns}
      rows={overviewRows}
      subtitle={`${tenants.length} tenants`}
      loading={loading}
      canExport={canExport}
    >
      {error ? <Alert tone="danger">{error}</Alert> : null}

      {loading ? (
        <div className="flex justify-center py-20">
          <Spinner label="Loading platform analytics…" />
        </div>
      ) : (
        <>
          <div className="grid gap-4 xl:grid-cols-2">
            <SimpleBarChart
              title="Tenant status mix"
              description="Live platform footprint"
              data={analytics.statusChart}
            />
            <SimpleBarChart
              title="Plan adoption"
              description="Tenants per SaaS plan"
              data={
                analytics.planChart.length
                  ? analytics.planChart
                  : [{ label: 'None', value: 0 }]
              }
            />
          </div>

          <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
            <DataTable
              columns={snapshotColumns}
              rows={overviewRows}
              rowKey={(row) => row.metric}
              emptyTitle="No KPIs yet"
              emptyDescription="Provision tenants to populate platform analytics."
            />
            <Card>
              <CardTitle>Report library</CardTitle>
              <CardDescription>Open a focused report or download exports</CardDescription>
              <div className="mt-4 grid gap-2">
                <ReportLink to="/platform/reports/tenants" icon={Building2} label="Tenant trends" />
                <ReportLink to="/platform/reports/billing" icon={Receipt} label="Billing summary" />
                <ReportLink to="/platform/reports/plans" icon={CreditCard} label="Plan adoption" />
                <ReportLink to="/platform/reports/exports" icon={Download} label="Export center" />
              </div>
            </Card>
          </div>
        </>
      )}
    </PlatformReportShell>
  )
}

function ReportLink({
  to,
  label,
  icon: Icon,
}: {
  to: string
  label: string
  icon: typeof Building2
}) {
  return (
    <Link
      to={to}
      className="flex items-center gap-3 rounded-xl border border-white/12 bg-white/6 px-3 py-3 text-sm font-semibold transition hover:border-accent/40 hover:bg-accent-soft/40"
    >
      <Icon className="h-4 w-4 text-accent" />
      {label}
    </Link>
  )
}
