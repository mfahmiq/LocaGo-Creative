import { Alert } from '@/components/ui/Alert'
import { Card } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Spinner } from '@/components/ui/Spinner'
import { SimpleBarChart } from '@/components/charts/SimpleBarChart'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatMoney, formatNumber } from '@/lib/format'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import type { PlatformInvoice, PlatformSubscriptionRow } from '@/api/platform'
import type { ExportColumn } from '@/lib/exportReport'
import { PlatformReportShell } from '@/pages/platform/reports/PlatformReportShell'
import { usePlatformReportData } from '@/pages/platform/reports/usePlatformReportData'
import { useClientPagination } from '@/hooks/useClientPagination'

type BillingExportRow = {
  type: string
  reference: string
  tenant: string
  status: string
  amount: string
  date: string
}

export function PlatformReportsBillingPage() {
  const { hasPermission } = useAuth()
  const canExport = hasPermission('platform.reports.export') || hasPermission('platform.reports.view')
  const { billing, analytics, loading, billingQuery } = usePlatformReportData()

  const subscriptions = billing?.subscriptions ?? []
  const invoices = billing?.invoices ?? []
  const subscriptionsPage = useClientPagination(subscriptions, subscriptions.length)
  const invoicesPage = useClientPagination(invoices, invoices.length)
  const summary = billing?.summary

  const exportRows: BillingExportRow[] = [
    ...subscriptions.map((row) => ({
      type: 'subscription',
      reference: row.plan_code ?? '',
      tenant: row.tenant_name,
      status: row.tenant_status,
      amount: String(row.monthly_amount),
      date: row.trial_ends_at ?? '',
    })),
    ...invoices.map((row) => ({
      type: 'invoice',
      reference: row.invoice_number,
      tenant: row.tenant?.name ?? '',
      status: row.status,
      amount: String(row.grand_total),
      date: row.issued_at ?? '',
    })),
  ]

  const exportColumns: ExportColumn<BillingExportRow>[] = [
    { key: 'type', header: 'Type', value: (r) => r.type },
    { key: 'reference', header: 'Reference', value: (r) => r.reference },
    { key: 'tenant', header: 'Tenant', value: (r) => r.tenant },
    { key: 'status', header: 'Status', value: (r) => r.status },
    { key: 'amount', header: 'Amount', value: (r) => r.amount },
    { key: 'date', header: 'Date', value: (r) => r.date },
  ]

  const mrrByPlan = (() => {
    const map = new Map<string, number>()
    for (const row of subscriptions) {
      if (!row.billable) continue
      const key = row.plan_name ?? 'Unassigned'
      map.set(key, (map.get(key) ?? 0) + row.monthly_amount)
    }
    return [...map.entries()].map(([label, value]) => ({
      label,
      value: Math.round(value * 100) / 100,
    }))
  })()

  const subscriptionColumns: Column<PlatformSubscriptionRow>[] = [
    {
      key: 'tenant',
      header: 'Tenant',
      cell: (r) => (
        <div>
          <p className="font-semibold">{r.tenant_name}</p>
          <p className="font-mono text-xs text-muted">/{r.tenant_slug}</p>
        </div>
      ),
    },
    { key: 'plan', header: 'Plan', cell: (r) => r.plan_name ?? '—' },
    {
      key: 'price',
      header: 'Price',
      cell: (r) => `${formatMoney(r.price, r.currency_code)} / ${r.billing_interval}`,
    },
    {
      key: 'mrr',
      header: 'Monthly',
      cell: (r) =>
        r.billable ? formatMoney(r.monthly_amount, r.currency_code) : <span className="text-muted">—</span>,
    },
    {
      key: 'balance',
      header: 'Open balance',
      cell: (r) =>
        r.open_balance > 0 ? formatMoney(r.open_balance, r.currency_code) : '—',
    },
  ]

  const invoiceColumns: Column<PlatformInvoice>[] = [
    { key: 'number', header: 'Invoice', cell: (r) => r.invoice_number },
    { key: 'tenant', header: 'Tenant', cell: (r) => r.tenant?.name ?? '—' },
    {
      key: 'status',
      header: 'Status',
      cell: (r) => <Badge tone="neutral">{r.status}</Badge>,
    },
    {
      key: 'total',
      header: 'Total',
      cell: (r) => formatMoney(r.grand_total, r.currency_code),
    },
    { key: 'due', header: 'Due', cell: (r) => formatDate(r.due_date) },
    { key: 'issued', header: 'Issued', cell: (r) => formatDate(r.issued_at) },
  ]

  return (
    <PlatformReportShell
      title="Billing reports"
      description="Subscription revenue and platform billing summaries across all gym tenants."
      reportKey="platform-billing"
      columns={exportColumns}
      rows={exportRows}
      loading={loading}
      canExport={canExport}
    >
      {billingQuery.isError ? (
        <Alert tone="danger">
          {billingQuery.error instanceof ApiError
            ? billingQuery.error.message
            : 'Unable to load billing analytics.'}
        </Alert>
      ) : null}

      {loading ? (
        <div className="flex justify-center py-20">
          <Spinner label="Loading billing analytics…" />
        </div>
      ) : (
        <>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <Stat
              label="Estimated MRR"
              value={formatMoney(summary?.mrr ?? analytics.mrr, summary?.currency_code ?? 'USD')}
            />
            <Stat
              label="Outstanding"
              value={formatMoney(summary?.outstanding ?? 0, summary?.currency_code ?? 'USD')}
            />
            <Stat
              label="Collected MTD"
              value={formatMoney(
                summary?.collected_this_month ?? 0,
                summary?.currency_code ?? 'USD',
              )}
            />
            <Stat label="Open invoices" value={formatNumber(summary?.open_invoices ?? 0)} />
          </div>

          <SimpleBarChart
            title="MRR by plan"
            description="Monthly contribution from billable tenants"
            data={mrrByPlan.length ? mrrByPlan : [{ label: 'None', value: 0 }]}
          />

          <div className="space-y-3">
            <h2 className="font-display text-lg font-bold uppercase tracking-wide text-ink">
              Subscriptions
            </h2>
            <DataTable
              columns={subscriptionColumns}
              rows={subscriptionsPage.rows}
              rowKey={(row) => row.tenant_id}
              emptyTitle="No subscriptions"
              emptyDescription="Assign SaaS plans to tenants to see revenue rows."
            />
            <Pagination meta={subscriptionsPage.meta} onPageChange={subscriptionsPage.setPage} />
          </div>

          <div className="space-y-3">
            <h2 className="font-display text-lg font-bold uppercase tracking-wide text-ink">
              Recent invoices
            </h2>
            <DataTable
              columns={invoiceColumns}
              rows={invoicesPage.rows}
              rowKey={(row) => row.id}
              emptyTitle="No invoices"
              emptyDescription="Issue platform invoices from Billing to populate this report."
            />
            <Pagination meta={invoicesPage.meta} onPageChange={invoicesPage.setPage} />
          </div>
        </>
      )}
    </PlatformReportShell>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <Card>
      <p className="text-xs font-semibold tracking-wide text-muted uppercase">{label}</p>
      <p className="mt-1 font-display text-2xl font-bold text-ink xl:text-3xl">{value}</p>
    </Card>
  )
}
