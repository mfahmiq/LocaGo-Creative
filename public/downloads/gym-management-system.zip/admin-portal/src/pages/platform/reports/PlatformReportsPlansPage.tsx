import { Alert } from '@/components/ui/Alert'
import { Card } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Spinner } from '@/components/ui/Spinner'
import { SimpleBarChart } from '@/components/charts/SimpleBarChart'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatMoney, formatNumber } from '@/lib/format'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import type { ExportColumn } from '@/lib/exportReport'
import { PlatformReportShell } from '@/pages/platform/reports/PlatformReportShell'
import { usePlatformReportData } from '@/pages/platform/reports/usePlatformReportData'
import { useClientPagination } from '@/hooks/useClientPagination'

type PlanRow = {
  id: number
  name: string
  code: string
  price: string
  interval: string
  active: boolean
  tenants: number
  activeTenants: number
  trialTenants: number
  suspendedTenants: number
  maxMembers: number
  maxBranches: number
  maxSeats: number
  modules: string
}

export function PlatformReportsPlansPage() {
  const { hasPermission } = useAuth()
  const canExport = hasPermission('platform.reports.export') || hasPermission('platform.reports.view')
  const { analytics, plans, loading, plansQuery } = usePlatformReportData()

  const rows: PlanRow[] = analytics.planAdoption.map(({ plan, tenants, active, trial, suspended }) => {
    const modules = [
      plan.limits?.module_pos ? 'POS' : null,
      plan.limits?.module_nutrition ? 'Nutrition' : null,
      plan.limits?.module_waitlist ? 'Waitlist' : null,
      plan.limits?.module_referral ? 'Referral' : null,
      plan.limits?.module_equipment ? 'Equipment' : null,
    ]
      .filter(Boolean)
      .join(', ')

    return {
      id: plan.id,
      name: plan.name,
      code: plan.code,
      price: formatMoney(plan.price, plan.currency_code),
      interval: plan.billing_interval,
      active: plan.is_active,
      tenants,
      activeTenants: active,
      trialTenants: trial,
      suspendedTenants: suspended,
      maxMembers: plan.limits?.max_members ?? 0,
      maxBranches: plan.limits?.max_branches ?? 0,
      maxSeats: plan.limits?.max_seats ?? 0,
      modules: modules || 'Core',
    }
  })

  const { rows: pageRows, meta, setPage } = useClientPagination(rows, rows.length)

  const exportColumns: ExportColumn<PlanRow>[] = [
    { key: 'name', header: 'Plan', value: (r) => r.name },
    { key: 'code', header: 'Code', value: (r) => r.code },
    { key: 'price', header: 'Price', value: (r) => r.price },
    { key: 'interval', header: 'Interval', value: (r) => r.interval },
    { key: 'active', header: 'Active', value: (r) => (r.active ? 'yes' : 'no') },
    { key: 'tenants', header: 'Tenants', value: (r) => r.tenants },
    { key: 'activeTenants', header: 'Active tenants', value: (r) => r.activeTenants },
    { key: 'trialTenants', header: 'Trial tenants', value: (r) => r.trialTenants },
    { key: 'maxMembers', header: 'Max members', value: (r) => r.maxMembers },
    { key: 'maxBranches', header: 'Max branches', value: (r) => r.maxBranches },
    { key: 'maxSeats', header: 'Max seats', value: (r) => r.maxSeats },
    { key: 'modules', header: 'Modules', value: (r) => r.modules },
  ]

  const columns: Column<PlanRow>[] = [
    {
      key: 'name',
      header: 'Plan',
      cell: (r) => (
        <div>
          <p className="font-semibold">{r.name}</p>
          <p className="font-mono text-xs text-muted">{r.code}</p>
        </div>
      ),
    },
    {
      key: 'price',
      header: 'Pricing',
      cell: (r) => (
        <span>
          {r.price}
          <span className="mt-0.5 block text-xs text-muted">/{r.interval}</span>
        </span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (r) => <Badge tone={r.active ? 'success' : 'neutral'}>{r.active ? 'active' : 'inactive'}</Badge>,
    },
    {
      key: 'tenants',
      header: 'Adoption',
      cell: (r) => (
        <span>
          {formatNumber(r.tenants)} tenants
          <span className="mt-0.5 block text-xs text-muted">
            {formatNumber(r.activeTenants)} active · {formatNumber(r.trialTenants)} trial
          </span>
        </span>
      ),
    },
    {
      key: 'limits',
      header: 'Entitlements',
      cell: (r) =>
        `${formatNumber(r.maxMembers)} members · ${formatNumber(r.maxBranches)} branches · ${formatNumber(r.maxSeats)} seats`,
    },
    { key: 'modules', header: 'Modules', cell: (r) => <span className="text-xs text-muted">{r.modules}</span> },
  ]

  return (
    <PlatformReportShell
      title="Plan adoption"
      description="SaaS plan mix and entitlement usage across tenants."
      reportKey="platform-plans"
      columns={exportColumns}
      rows={rows}
      loading={loading}
      canExport={canExport}
    >
      {plansQuery.isError ? (
        <Alert tone="danger">
          {plansQuery.error instanceof ApiError
            ? plansQuery.error.message
            : 'Unable to load plan analytics.'}
        </Alert>
      ) : null}

      {loading ? (
        <div className="flex justify-center py-20">
          <Spinner label="Loading plan adoption…" />
        </div>
      ) : (
        <>
          <div className="grid gap-3 sm:grid-cols-3">
            <Card>
              <p className="text-xs font-semibold tracking-wide text-muted uppercase">Plans</p>
              <p className="mt-1 font-display text-3xl font-bold text-ink">
                {formatNumber(plans.length)}
              </p>
            </Card>
            <Card>
              <p className="text-xs font-semibold tracking-wide text-muted uppercase">Active plans</p>
              <p className="mt-1 font-display text-3xl font-bold text-ink">
                {formatNumber(analytics.activePlans)}
              </p>
            </Card>
            <Card>
              <p className="text-xs font-semibold tracking-wide text-muted uppercase">Assigned tenants</p>
              <p className="mt-1 font-display text-3xl font-bold text-ink">
                {formatNumber(rows.reduce((sum, row) => sum + row.tenants, 0))}
              </p>
            </Card>
          </div>

          <SimpleBarChart
            title="Tenants per plan"
            description="Adoption across the SaaS catalog"
            data={
              analytics.planChart.length
                ? analytics.planChart
                : [{ label: 'None', value: 0 }]
            }
          />

          <DataTable
            columns={columns}
            rows={pageRows}
            rowKey={(row) => row.id}
            emptyTitle="No plans"
            emptyDescription="Create SaaS plans to populate adoption analytics."
          />
          <Pagination meta={meta} onPageChange={setPage} />
        </>
      )}
    </PlatformReportShell>
  )
}
