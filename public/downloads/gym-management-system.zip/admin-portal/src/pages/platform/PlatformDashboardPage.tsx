import { useMemo, useState, type FormEvent } from 'react'
import { Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Building2,
  CreditCard,
  FileBarChart2,
  PauseCircle,
  PlayCircle,
  Plus,
  RefreshCw,
  Shield,
  Timer,
  UserCog,
} from 'lucide-react'
import {
  activatePlatformTenant,
  extendPlatformTenantTrial,
  fetchPlatformTenants,
  fetchSaasPlans,
  provisionPlatformTenant,
  reactivatePlatformTenant,
  suspendPlatformTenant,
  type PlatformTenant,
} from '@/api/platform'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Spinner } from '@/components/ui/Spinner'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { DataTable, type Column } from '@/components/table/DataTable'
import { SimpleBarChart } from '@/components/charts/SimpleBarChart'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { formatDate, formatMoney, formatNumber } from '@/lib/format'
import { cn } from '@/lib/cn'
import { daysUntil, tenantStatusTone } from '@/pages/platform/tenantHelpers'

export function PlatformDashboardPage() {
  const { user, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canViewTenants = hasPermission('platform.tenants.view')
  const canManageTenants = hasPermission('platform.tenants.manage')
  const canViewPlans = hasPermission('platform.plans.view')
  const canManagePlans = hasPermission('platform.plans.manage')
  const canViewReports = hasPermission('platform.reports.view')
  const canManageUsers = hasPermission('platform.users.manage')
  const canViewRbac =
    canManageUsers ||
    canViewTenants ||
    hasPermission('platform.audit.view') ||
    canViewReports

  const [showProvision, setShowProvision] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})
  const [form, setForm] = useState({
    name: '',
    slug: '',
    saas_plan_id: '',
    email: '',
    primary_country: 'IN',
    trial_days: '14',
  })

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }

  const tenantsQuery = useQuery({
    queryKey: ['platform', 'tenants'],
    queryFn: () => fetchPlatformTenants(),
    enabled: canViewTenants,
  })

  const plansQuery = useQuery({
    queryKey: ['platform', 'saas-plans'],
    queryFn: fetchSaasPlans,
    enabled: canViewPlans || canManageTenants,
  })

  const invalidateTenants = () =>
    void queryClient.invalidateQueries({ queryKey: ['platform', 'tenants'] })

  const provisionMutation = useMutation({
    mutationFn: provisionPlatformTenant,
    onSuccess: (tenant) => {
      setActionError(null)
      setFieldErrors({})
      showSuccess(`Tenant “${tenant.name}” provisioned.`)
      setShowProvision(false)
      setForm({
        name: '',
        slug: '',
        saas_plan_id: form.saas_plan_id,
        email: '',
        primary_country: 'IN',
        trial_days: '14',
      })
      invalidateTenants()
    },
    onError: (err) => {
      setActionError(err instanceof ApiError ? err.message : 'Unable to provision tenant.')
    },
  })

  const lifecycleMutation = useMutation({
    mutationFn: async ({
      action,
      tenant,
    }: {
      action: 'activate' | 'suspend' | 'reactivate' | 'extend'
      tenant: PlatformTenant
    }) => {
      if (action === 'activate') return activatePlatformTenant(tenant.id)
      if (action === 'suspend') return suspendPlatformTenant(tenant.id, 'manual')
      if (action === 'reactivate') return reactivatePlatformTenant(tenant.id)
      return extendPlatformTenantTrial(tenant.id, 7)
    },
    onSuccess: (_data, vars) => {
      setActionError(null)
      const labels = {
        activate: 'activated',
        suspend: 'suspended',
        reactivate: 'reactivated',
        extend: 'trial extended by 7 days',
      } as const
      showSuccess(`${vars.tenant.name} ${labels[vars.action]}.`)
      invalidateTenants()
    },
    onError: (err) => {
      setActionError(err instanceof ApiError ? err.message : 'Lifecycle action failed.')
    },
  })

  const tenants = tenantsQuery.data ?? []
  const plans = plansQuery.data ?? []

  const stats = useMemo(() => {
    const byStatus = {
      active: 0,
      trial: 0,
      suspended: 0,
      cancelled: 0,
      other: 0,
    }
    for (const tenant of tenants) {
      if (tenant.status in byStatus) {
        byStatus[tenant.status as keyof typeof byStatus] += 1
      } else {
        byStatus.other += 1
      }
    }

    const trialsEndingSoon = tenants.filter((tenant) => {
      if (tenant.status !== 'trial') return false
      const days = daysUntil(tenant.trial_ends_at)
      return days != null && days >= 0 && days <= 7
    })

    const planAdoption = plans.map((plan) => ({
      label: plan.name,
      value: tenants.filter((tenant) => tenant.saas_plan_id === plan.id).length,
    }))

    return {
      total: tenants.length,
      ...byStatus,
      activePlans: plans.filter((plan) => plan.is_active).length,
      trialsEndingSoon,
      planAdoption,
      statusChart: [
        { label: 'Active', value: byStatus.active },
        { label: 'Trial', value: byStatus.trial },
        { label: 'Suspended', value: byStatus.suspended },
        { label: 'Cancelled', value: byStatus.cancelled },
      ],
    }
  }, [tenants, plans])

  const recentTenants = useMemo(
    () =>
      [...tenants]
        .sort((a, b) => {
          const aTime = a.created_at ? new Date(a.created_at).getTime() : 0
          const bTime = b.created_at ? new Date(b.created_at).getTime() : 0
          return bTime - aTime
        })
        .slice(0, 8),
    [tenants],
  )

  const runLifecycle = async (
    action: 'activate' | 'suspend' | 'reactivate' | 'extend',
    tenant: PlatformTenant,
  ) => {
    if (!canManageTenants) return

    if (action === 'activate') {
      const ok = await confirm({
        title: 'Activate tenant?',
        message: `Activate “${tenant.name}” (/${tenant.slug})? The gym will move to an active subscription state.`,
        confirmLabel: 'Activate',
        tone: 'primary',
      })
      if (!ok) return
    }

    if (action === 'reactivate') {
      const ok = await confirm({
        title: 'Reactivate tenant?',
        message: `Reactivate “${tenant.name}” (/${tenant.slug})? Staff and members will regain portal access.`,
        confirmLabel: 'Reactivate',
        tone: 'primary',
      })
      if (!ok) return
    }

    if (action === 'suspend') {
      const ok = await confirm({
        title: 'Suspend tenant?',
        message: `Suspend “${tenant.name}” (/${tenant.slug})? Staff and members for this gym will lose access.`,
        confirmLabel: 'Suspend',
        tone: 'danger',
      })
      if (!ok) return
    }

    lifecycleMutation.mutate({ action, tenant })
  }

  const submitProvision = (event: FormEvent) => {
    event.preventDefault()
    const next = collectRequiredErrors([
      { key: 'name', label: 'Gym name', value: form.name },
      { key: 'slug', label: 'Slug', value: form.slug },
      { key: 'saas_plan_id', label: 'SaaS plan', value: form.saas_plan_id },
    ])
    setFieldErrors(next)
    if (Object.keys(next).length) return
    provisionMutation.mutate({
      name: form.name.trim(),
      slug: form.slug.trim().toLowerCase(),
      saas_plan_id: Number(form.saas_plan_id),
      email: form.email.trim() || undefined,
      primary_country: form.primary_country.trim() || undefined,
      trial_days: Number(form.trial_days) || 14,
    })
  }

  const columns: Column<PlatformTenant>[] = [
    {
      key: 'name',
      header: 'Tenant',
      cell: (row) => (
        <div>
          <p className="font-semibold text-ink">{row.name}</p>
          <p className="font-mono text-xs text-muted">/{row.slug}</p>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => <Badge tone={tenantStatusTone(row.status)}>{row.status}</Badge>,
    },
    {
      key: 'plan',
      header: 'Plan',
      cell: (row) => row.saas_plan?.name ?? plans.find((p) => p.id === row.saas_plan_id)?.name ?? '—',
    },
    {
      key: 'trial',
      header: 'Trial ends',
      cell: (row) => {
        if (row.status !== 'trial') return '—'
        const days = daysUntil(row.trial_ends_at)
        return (
          <span>
            {formatDate(row.trial_ends_at)}
            {days != null ? (
              <span className="ml-1 text-xs text-muted">
                ({days < 0 ? 'expired' : `${days}d`})
              </span>
            ) : null}
          </span>
        )
      },
    },
    {
      key: 'actions',
      header: 'Actions',
      className: 'text-right',
      cell: (row) =>
        canManageTenants ? (
          <div className="flex flex-wrap justify-end gap-1.5">
            {(row.status === 'trial' || row.status === 'suspended') && (
              <Button
                size="sm"
                variant="secondary"
                disabled={lifecycleMutation.isPending}
                onClick={() => void runLifecycle('activate', row)}
              >
                <PlayCircle className="h-3.5 w-3.5" />
                Activate
              </Button>
            )}
            {row.status === 'trial' && (
              <Button
                size="sm"
                variant="ghost"
                disabled={lifecycleMutation.isPending}
                onClick={() => void runLifecycle('extend', row)}
              >
                <Timer className="h-3.5 w-3.5" />
                +7d
              </Button>
            )}
            {(row.status === 'active' || row.status === 'trial') && (
              <Button
                size="sm"
                variant="danger"
                disabled={lifecycleMutation.isPending}
                onClick={() => void runLifecycle('suspend', row)}
              >
                <PauseCircle className="h-3.5 w-3.5" />
                Suspend
              </Button>
            )}
            {row.status === 'suspended' && (
              <Button
                size="sm"
                variant="secondary"
                disabled={lifecycleMutation.isPending}
                onClick={() => void runLifecycle('reactivate', row)}
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Reactivate
              </Button>
            )}
          </div>
        ) : (
          <span className="text-xs text-muted">View only</span>
        ),
    },
  ]

  const loading =
    (canViewTenants && tenantsQuery.isPending) || (canViewPlans && plansQuery.isPending)

  const firstName = user?.name?.split(' ')[0] ?? 'Admin'

  return (
    <div className="animate-fade-up space-y-6">
      <PageHeader
        title={`Welcome, ${firstName}`}
        description="Manage gym tenants, plans, and platform operators from one secure console."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="accent">Super Admin</Badge>
            {canManageTenants ? (
              <Button size="sm" onClick={() => setShowProvision((open) => !open)}>
                <Plus className="h-4 w-4" />
                New tenant
              </Button>
            ) : null}
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                invalidateTenants()
                void queryClient.invalidateQueries({ queryKey: ['platform', 'saas-plans'] })
              }}
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
          </div>
        }
      />

      {actionError ? (
        <Alert tone="danger" className="mb-2">
          {actionError}
        </Alert>
      ) : null}

      {!canViewTenants && !canViewPlans ? (
        <Alert tone="info">
          Your platform role can sign in, but does not include tenant or plan view permissions yet.
        </Alert>
      ) : null}

      {showProvision && canManageTenants ? (
        <Card>
          <CardTitle>Provision gym tenant</CardTitle>
          <CardDescription>Creates a trial tenant on the selected SaaS plan.</CardDescription>
          <form
            noValidate
            onSubmit={submitProvision}
            className="mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-3"
          >
            <Field label="Gym name" htmlFor="tenant-name" required error={fieldErrors.name}>
              <Input
                id="tenant-name"
                value={form.name}
                aria-invalid={Boolean(fieldErrors.name)}
                onChange={(e) => {
                  clearFieldError('name')
                  const name = e.target.value
                  setForm((current) => ({
                    ...current,
                    name,
                    slug:
                      current.slug === '' || current.slug === slugify(current.name)
                        ? slugify(name)
                        : current.slug,
                  }))
                }}
                placeholder="Peak Performance Gym"
              />
            </Field>
            <Field label="Slug" htmlFor="tenant-slug" required error={fieldErrors.slug}>
              <Input
                id="tenant-slug"
                value={form.slug}
                aria-invalid={Boolean(fieldErrors.slug)}
                onChange={(e) => {
                  clearFieldError('slug')
                  setForm((c) => ({ ...c, slug: e.target.value.toLowerCase() }))
                }}
                placeholder="peak-performance"
              />
            </Field>
            <Field
              label="SaaS plan"
              htmlFor="tenant-plan"
              required
              error={fieldErrors.saas_plan_id}
            >
              <Select
                id="tenant-plan"
                value={form.saas_plan_id}
                aria-invalid={Boolean(fieldErrors.saas_plan_id)}
                onChange={(e) => {
                  clearFieldError('saas_plan_id')
                  setForm((c) => ({ ...c, saas_plan_id: e.target.value }))
                }}
              >
                <option value="">Select plan</option>
                {plans.map((plan) => (
                  <option key={plan.id} value={plan.id}>
                    {plan.name} ({plan.code})
                  </option>
                ))}
              </Select>
            </Field>
            <div>
              <Label htmlFor="tenant-email">Owner email</Label>
              <Input
                id="tenant-email"
                type="email"
                value={form.email}
                onChange={(e) => setForm((c) => ({ ...c, email: e.target.value }))}
                placeholder="owner@gym.test"
              />
            </div>
            <div>
              <Label htmlFor="tenant-country">Country</Label>
              <Input
                id="tenant-country"
                maxLength={2}
                value={form.primary_country}
                onChange={(e) =>
                  setForm((c) => ({ ...c, primary_country: e.target.value.toUpperCase() }))
                }
                placeholder="IN"
              />
            </div>
            <div>
              <Label htmlFor="tenant-trial">Trial days</Label>
              <Input
                id="tenant-trial"
                type="number"
                min={1}
                max={365}
                value={form.trial_days}
                onChange={(e) => setForm((c) => ({ ...c, trial_days: e.target.value }))}
              />
            </div>
            <div className="flex items-end gap-2 sm:col-span-2 xl:col-span-3">
              <Button type="submit" loading={provisionMutation.isPending}>
                Provision tenant
              </Button>
              <Button type="button" variant="ghost" onClick={() => setShowProvision(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      {loading ? (
        <div className="flex justify-center py-20">
          <Spinner label="Loading platform console…" />
        </div>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
            <KpiCard label="Tenants" value={formatNumber(stats.total)} hint="All gyms" icon={Building2} />
            <KpiCard
              label="Active"
              value={formatNumber(stats.active)}
              hint="Live subscriptions"
              icon={PlayCircle}
              accent
            />
            <KpiCard label="On trial" value={formatNumber(stats.trial)} hint="Evaluation period" icon={Timer} />
            <KpiCard
              label="Suspended"
              value={formatNumber(stats.suspended)}
              hint="Access paused"
              icon={PauseCircle}
            />
            <KpiCard
              label="SaaS plans"
              value={formatNumber(stats.activePlans)}
              hint="Active catalog"
              icon={CreditCard}
            />
          </div>

          {stats.trialsEndingSoon.length > 0 ? (
            <Alert tone="info">
              <p className="font-semibold">
                {formatNumber(stats.trialsEndingSoon.length)} trial
                {stats.trialsEndingSoon.length === 1 ? '' : 's'} ending within 7 days
              </p>
              <p className="mt-1 text-xs opacity-80">
                {stats.trialsEndingSoon
                  .slice(0, 4)
                  .map((t) => `${t.name} (${formatDate(t.trial_ends_at)})`)
                  .join(' · ')}
              </p>
            </Alert>
          ) : null}

          <div className="grid gap-4 xl:grid-cols-[1.15fr_0.85fr]">
            {canViewTenants ? (
              <SimpleBarChart
                title="Tenant status mix"
                description="Live counts across the platform"
                data={stats.statusChart}
              />
            ) : (
              <Card>
                <CardTitle>Tenant status mix</CardTitle>
                <CardDescription>Requires platform.tenants.view</CardDescription>
              </Card>
            )}

            <Card>
              <CardTitle>Quick actions</CardTitle>
              <CardDescription>Jump to core platform workflows</CardDescription>
              <div className="mt-4 grid gap-2 sm:grid-cols-2">
                <QuickLink
                  to="/platform/tenants"
                  label="Manage tenants"
                  description="Lifecycle & plans"
                  icon={Building2}
                  enabled={canViewTenants}
                />
                <QuickLink
                  to="/platform/plans"
                  label="SaaS plans"
                  description="Pricing & limits"
                  icon={CreditCard}
                  enabled={canViewPlans}
                />
                <QuickLink
                  to="/platform/reports"
                  label="Reports"
                  description="Platform analytics"
                  icon={FileBarChart2}
                  enabled={canViewReports}
                />
                <QuickLink
                  to="/platform/settings/rbac"
                  label="RBAC"
                  description="Roles & access"
                  icon={Shield}
                  enabled={canViewRbac}
                />
                <QuickLink
                  to="/platform/settings/users"
                  label="Operators"
                  description="Platform users"
                  icon={UserCog}
                  enabled={canManageUsers}
                />
                <QuickLink
                  to="/platform/billing"
                  label="Billing"
                  description="Subscriptions"
                  icon={CreditCard}
                  enabled={hasPermission('platform.billing.view')}
                />
              </div>
            </Card>
          </div>

          <div className="grid gap-4 xl:grid-cols-[1.25fr_0.75fr]">
            <div>
              <div className="mb-3 flex items-center justify-between gap-3">
                <div>
                  <h2 className="font-display text-lg font-bold uppercase tracking-wide text-ink">
                    Recent tenants
                  </h2>
                  <p className="text-sm text-muted">Lifecycle controls respect your RBAC grants.</p>
                </div>
                {canViewTenants ? (
                  <Link
                    to="/platform/tenants"
                    className="text-sm font-semibold text-accent hover:brightness-110"
                  >
                    View all
                  </Link>
                ) : null}
              </div>
              {canViewTenants ? (
                <DataTable
                  columns={columns}
                  rows={recentTenants}
                  rowKey={(row) => row.id}
                  emptyTitle="No tenants yet"
                  emptyDescription="Provision your first gym tenant to get started."
                />
              ) : (
                <Alert tone="info">Tenant list requires platform.tenants.view.</Alert>
              )}
            </div>

            <div className="space-y-4">
              <Card>
                <CardTitle>Plan adoption</CardTitle>
                <CardDescription>Tenants per SaaS plan</CardDescription>
                {canViewPlans || canViewTenants ? (
                  <ul className="mt-4 space-y-2.5">
                    {stats.planAdoption.length ? (
                      stats.planAdoption.map((row) => (
                        <li
                          key={row.label}
                          className="flex items-center justify-between rounded-xl border border-white/12 bg-white/6 px-3 py-2.5"
                        >
                          <span className="text-sm font-medium text-ink">{row.label}</span>
                          <Badge tone="neutral">{formatNumber(row.value)}</Badge>
                        </li>
                      ))
                    ) : (
                      <li className="text-sm text-muted">No plans in catalog.</li>
                    )}
                  </ul>
                ) : (
                  <p className="mt-3 text-sm text-muted">Requires plan or tenant view access.</p>
                )}
                {canManagePlans ? (
                  <Link
                    to="/platform/plans"
                    className="mt-4 inline-flex text-sm font-semibold text-accent hover:brightness-110"
                  >
                    Manage plans
                  </Link>
                ) : null}
              </Card>

              <Card>
                <CardTitle>Session</CardTitle>
                <CardDescription>Signed-in platform operator</CardDescription>
                <dl className="mt-4 space-y-3 text-sm">
                  <div className="flex justify-between gap-3">
                    <dt className="text-muted">Name</dt>
                    <dd className="font-medium text-ink">{user?.name ?? '—'}</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="text-muted">Email</dt>
                    <dd className="truncate font-medium text-ink">{user?.email ?? '—'}</dd>
                  </div>
                  <div className="flex justify-between gap-3">
                    <dt className="text-muted">Roles</dt>
                    <dd className="text-right font-medium text-ink">
                      {(user?.roles ?? []).map((role) => role.name).join(', ') || '—'}
                    </dd>
                  </div>
                </dl>
                {canViewPlans && plans[0] ? (
                  <p className="mt-4 rounded-xl border border-white/12 bg-white/6 px-3 py-2 text-xs text-muted">
                    Catalog lead plan:{' '}
                    <span className="font-semibold text-ink">
                      {plans.find((p) => p.code === 'starter')?.name ?? plans[0].name}
                    </span>{' '}
                    ·{' '}
                    {formatMoney(
                      plans.find((p) => p.code === 'starter')?.price ?? plans[0].price,
                      plans.find((p) => p.code === 'starter')?.currency_code ??
                        plans[0].currency_code,
                    )}
                  </p>
                ) : null}
              </Card>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

function slugify(value: string) {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80)
}

function KpiCard({
  label,
  value,
  hint,
  icon: Icon,
  accent = false,
}: {
  label: string
  value: string
  hint: string
  icon: typeof Building2
  accent?: boolean
}) {
  return (
    <Card className={cn('relative overflow-hidden', accent && 'border-accent/35')}>
      <div
        className={cn(
          'absolute -right-6 -top-6 h-24 w-24 rounded-full opacity-70',
          accent ? 'bg-accent/20' : 'bg-white/10',
        )}
      />
      <div className="relative flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-muted">{label}</p>
          <p className="mt-2 font-display text-3xl font-bold tracking-wide text-ink xl:text-4xl">
            {value}
          </p>
          <p className="mt-1 text-xs text-muted">{hint}</p>
        </div>
        <div
          className={cn(
            'flex h-10 w-10 items-center justify-center rounded-xl',
            accent ? 'bg-accent text-accent-ink' : 'bg-white/12 text-ink',
          )}
        >
          <Icon className="h-4 w-4" />
        </div>
      </div>
    </Card>
  )
}

function QuickLink({
  to,
  label,
  description,
  icon: Icon,
  enabled,
}: {
  to: string
  label: string
  description: string
  icon: typeof Building2
  enabled: boolean
}) {
  if (!enabled) {
    return (
      <div className="rounded-xl border border-dashed border-white/12 bg-white/4 px-3 py-3 opacity-50">
        <div className="flex items-center gap-2 text-sm font-semibold text-muted">
          <Icon className="h-4 w-4" />
          {label}
        </div>
        <p className="mt-1 text-xs text-muted">Permission required</p>
      </div>
    )
  }

  return (
    <Link
      to={to}
      className="rounded-xl border border-white/12 bg-white/6 px-3 py-3 transition hover:border-accent/40 hover:bg-accent-soft/40"
    >
      <div className="flex items-center gap-2 text-sm font-semibold text-ink">
        <Icon className="h-4 w-4 text-accent" />
        {label}
      </div>
      <p className="mt-1 text-xs text-muted">{description}</p>
    </Link>
  )
}
