import { useEffect, useMemo, useState, type FormEvent } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Building2,
  PauseCircle,
  PlayCircle,
  Plus,
  RefreshCw,
  Search,
  Timer,
  X,
} from 'lucide-react'
import {
  activatePlatformTenant,
  assignPlatformTenantPlan,
  extendPlatformTenantTrial,
  fetchPlatformTenants,
  fetchSaasPlans,
  provisionPlatformTenant,
  reactivatePlatformTenant,
  suspendPlatformTenant,
  type PlatformTenant,
  type PlatformTenantStatus,
} from '@/api/platform'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatNumber } from '@/lib/format'
import { cn } from '@/lib/cn'
import { daysUntil, tenantStatusTone } from '@/pages/platform/tenantHelpers'
import { useClientPagination } from '@/hooks/useClientPagination'

const STATUS_FILTERS: Array<{ value: '' | PlatformTenantStatus; label: string }> = [
  { value: '', label: 'All' },
  { value: 'active', label: 'Active' },
  { value: 'trial', label: 'Trial' },
  { value: 'suspended', label: 'Suspended' },
  { value: 'cancelled', label: 'Cancelled' },
]

const emptyProvision = {
  name: '',
  slug: '',
  legal_name: '',
  saas_plan_id: '',
  email: '',
  phone: '',
  primary_country: 'IN',
  base_currency: 'INR',
  timezone: 'Asia/Kolkata',
  trial_days: '14',
}

export function PlatformTenantsPage() {
  const { hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canManage = hasPermission('platform.tenants.manage')
  const canViewPlans = hasPermission('platform.plans.view') || canManage

  const [statusFilter, setStatusFilter] = useState<'' | PlatformTenantStatus>('')
  const [search, setSearch] = useState('')
  const [showProvision, setShowProvision] = useState(false)
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }
  const [form, setForm] = useState(emptyProvision)
  const [extendDays, setExtendDays] = useState('7')
  const [suspendReason, setSuspendReason] = useState('manual')
  const [assignPlanId, setAssignPlanId] = useState('')

  const tenantsQuery = useQuery({
    queryKey: ['platform', 'tenants'],
    queryFn: () => fetchPlatformTenants(),
  })

  const plansQuery = useQuery({
    queryKey: ['platform', 'saas-plans'],
    queryFn: fetchSaasPlans,
    enabled: canViewPlans,
  })

  const plans = plansQuery.data ?? []
  const tenants = tenantsQuery.data ?? []

  useEffect(() => {
    if (!form.saas_plan_id && plans.length > 0) {
      const starter = plans.find((plan) => plan.code === 'starter') ?? plans[0]
      setForm((current) => ({ ...current, saas_plan_id: String(starter.id) }))
    }
  }, [plans, form.saas_plan_id])

  const invalidate = () => void queryClient.invalidateQueries({ queryKey: ['platform', 'tenants'] })

  const stats = useMemo(() => {
    const counts = { total: tenants.length, active: 0, trial: 0, suspended: 0, cancelled: 0 }
    for (const tenant of tenants) {
      if (tenant.status === 'active') counts.active += 1
      else if (tenant.status === 'trial') counts.trial += 1
      else if (tenant.status === 'suspended') counts.suspended += 1
      else if (tenant.status === 'cancelled') counts.cancelled += 1
    }
    const endingSoon = tenants.filter((tenant) => {
      if (tenant.status !== 'trial') return false
      const days = daysUntil(tenant.trial_ends_at)
      return days != null && days >= 0 && days <= 7
    }).length
    return { ...counts, endingSoon }
  }, [tenants])

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase()
    return tenants
      .filter((tenant) => (statusFilter ? tenant.status === statusFilter : true))
      .filter((tenant) => {
        if (!q) return true
        return (
          tenant.name.toLowerCase().includes(q) ||
          tenant.slug.toLowerCase().includes(q) ||
          (tenant.email ?? '').toLowerCase().includes(q) ||
          (tenant.saas_plan?.name ?? '').toLowerCase().includes(q) ||
          (tenant.primary_country ?? '').toLowerCase().includes(q)
        )
      })
      .sort((a, b) => a.name.localeCompare(b.name))
  }, [tenants, statusFilter, search])

  const {
    rows: pageRows,
    meta: pageMeta,
    setPage,
  } = useClientPagination(rows, `${statusFilter}|${search}|${rows.length}`)

  const selected = useMemo(
    () => tenants.find((tenant) => tenant.id === selectedId) ?? null,
    [tenants, selectedId],
  )

  useEffect(() => {
    if (selected) {
      setAssignPlanId(selected.saas_plan_id ? String(selected.saas_plan_id) : '')
      setExtendDays('7')
      setSuspendReason('manual')
    }
  }, [selected])

  const provisionMutation = useMutation({
    mutationFn: provisionPlatformTenant,
    onSuccess: (tenant) => {
      setError(null)
      showSuccess(`Tenant “${tenant.name}” provisioned.`)
      setShowProvision(false)
      setForm((current) => ({ ...emptyProvision, saas_plan_id: current.saas_plan_id }))
      setSelectedId(tenant.id)
      invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to provision tenant.')
    },
  })

  const actionMutation = useMutation({
    mutationFn: async (input: {
      type: 'activate' | 'suspend' | 'reactivate' | 'extend' | 'assign'
      tenant: PlatformTenant
      days?: number
      reason?: string
      planId?: number
    }) => {
      const { type, tenant } = input
      if (type === 'activate') return activatePlatformTenant(tenant.id)
      if (type === 'suspend') return suspendPlatformTenant(tenant.id, input.reason)
      if (type === 'reactivate') return reactivatePlatformTenant(tenant.id)
      if (type === 'extend') return extendPlatformTenantTrial(tenant.id, input.days ?? 7)
      return assignPlatformTenantPlan(tenant.id, input.planId!)
    },
    onSuccess: (tenant, vars) => {
      setError(null)
      const messages: Record<typeof vars.type, string> = {
        activate: 'activated',
        suspend: 'suspended',
        reactivate: 'reactivated',
        extend: `trial extended by ${vars.days ?? 7} days`,
        assign: 'plan updated',
      }
      showSuccess(`${tenant.name} ${messages[vars.type]}.`)
      invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Action failed.')
    },
  })

  const onProvision = (event: FormEvent) => {
    event.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'name', label: 'Gym name', value: form.name },
      { key: 'slug', label: 'URL slug', value: form.slug },
      { key: 'saas_plan_id', label: 'SaaS plan', value: form.saas_plan_id },
    ])
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    provisionMutation.mutate({
      name: form.name.trim(),
      slug: form.slug.trim().toLowerCase(),
      legal_name: form.legal_name.trim() || undefined,
      saas_plan_id: Number(form.saas_plan_id),
      email: form.email.trim() || undefined,
      phone: form.phone.trim() || undefined,
      primary_country: form.primary_country.trim() || undefined,
      base_currency: form.base_currency.trim() || undefined,
      timezone: form.timezone.trim() || undefined,
      trial_days: Number(form.trial_days) || 14,
    })
  }

  const runSuspend = async (tenant: PlatformTenant) => {
    const ok = await confirm({
      title: 'Suspend tenant?',
      message: `Suspend “${tenant.name}” (/${tenant.slug})? Gym staff and members will lose access until reactivation.`,
      confirmLabel: 'Suspend',
      tone: 'danger',
    })
    if (!ok) return
    actionMutation.mutate({ type: 'suspend', tenant, reason: suspendReason.trim() || 'manual' })
  }

  const runActivate = async (tenant: PlatformTenant) => {
    const ok = await confirm({
      title: 'Activate tenant?',
      message: `Activate “${tenant.name}” (/${tenant.slug})? The gym will move to an active subscription state.`,
      confirmLabel: 'Activate',
      tone: 'primary',
    })
    if (!ok) return
    actionMutation.mutate({ type: 'activate', tenant })
  }

  const runReactivate = async (tenant: PlatformTenant) => {
    const ok = await confirm({
      title: 'Reactivate tenant?',
      message: `Reactivate “${tenant.name}” (/${tenant.slug})? Staff and members will regain portal access.`,
      confirmLabel: 'Reactivate',
      tone: 'primary',
    })
    if (!ok) return
    actionMutation.mutate({ type: 'reactivate', tenant })
  }

  const columns: Column<PlatformTenant>[] = [
    {
      key: 'name',
      header: 'Gym tenant',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">{row.name}</p>
          <p className="font-mono text-xs text-muted">/{row.slug}</p>
        </button>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => <Badge tone={tenantStatusTone(row.status)}>{row.status}</Badge>,
    },
    {
      key: 'plan',
      header: 'Plan',
      cell: (row) => (
        <span className="text-sm">
          {row.saas_plan?.name ?? '—'}
          {row.saas_plan?.code ? (
            <span className="mt-0.5 block font-mono text-[11px] text-muted">{row.saas_plan.code}</span>
          ) : null}
        </span>
      ),
    },
    {
      key: 'region',
      header: 'Region',
      cell: (row) => (
        <span className="text-sm">
          {row.primary_country ?? '—'}
          <span className="mt-0.5 block text-xs text-muted">
            {row.base_currency ?? '—'} · {row.timezone ?? '—'}
          </span>
        </span>
      ),
    },
    {
      key: 'trial',
      header: 'Trial',
      cell: (row) => {
        if (!row.trial_ends_at) return <span className="text-muted">—</span>
        const days = daysUntil(row.trial_ends_at)
        const urgent = row.status === 'trial' && days != null && days <= 7
        return (
          <span className={cn('text-sm', urgent && 'text-warning')}>
            {formatDate(row.trial_ends_at)}
            {days != null ? (
              <span className="mt-0.5 block text-xs text-muted">
                {days < 0 ? 'Expired' : `${days} day${days === 1 ? '' : 's'} left`}
              </span>
            ) : null}
          </span>
        )
      },
    },
    {
      key: 'created',
      header: 'Created',
      cell: (row) => formatDate(row.created_at),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedId(row.id)}>
          Manage
        </Button>
      ),
    },
  ]

  return (
    <div className="animate-fade-up space-y-6">
      <PageHeader
        title="Tenants"
        description="Manage gym tenants — provision, activate, suspend, assign plans, and extend trials from one place."
        actions={
          <div className="flex flex-wrap gap-2">
            {canManage ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowProvision(true)
                  setSelectedId(null)
                }}
              >
                <Plus className="h-4 w-4" />
                New tenant
              </Button>
            ) : (
              <Badge tone="neutral">View only</Badge>
            )}
            <Button
              size="sm"
              variant="secondary"
              onClick={() => {
                invalidate()
                void queryClient.invalidateQueries({ queryKey: ['platform', 'saas-plans'] })
              }}
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      {tenantsQuery.isError ? (
        <Alert tone="danger">
          {tenantsQuery.error instanceof ApiError
            ? tenantsQuery.error.message
            : 'Unable to load tenants.'}
          <div className="mt-3">
            <Button size="sm" variant="secondary" onClick={() => void tenantsQuery.refetch()}>
              Try again
            </Button>
          </div>
        </Alert>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <SummaryChip label="Total" value={formatNumber(stats.total)} />
        <SummaryChip label="Active" value={formatNumber(stats.active)} tone="success" />
        <SummaryChip label="Trial" value={formatNumber(stats.trial)} tone="accent" />
        <SummaryChip label="Suspended" value={formatNumber(stats.suspended)} tone="danger" />
        <SummaryChip
          label="Trials ≤ 7 days"
          value={formatNumber(stats.endingSoon)}
          tone={stats.endingSoon > 0 ? 'warning' : 'neutral'}
        />
      </div>

      {showProvision && canManage ? (
        <Card className="border-accent/25">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <CardTitle>Provision gym tenant</CardTitle>
              <CardDescription>
                Creates a trial tenant, seeds roles, and assigns the selected SaaS plan.
              </CardDescription>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowProvision(false)}
              aria-label="Close provision form"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form onSubmit={onProvision} noValidate className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <Field label="Gym name" htmlFor="tenant-name" required error={fieldErrors.name}>
              <Input
                id="tenant-name"
                value={form.name}
                onChange={(e) => {
                  const name = e.target.value
                  setForm((c) => ({
                    ...c,
                    name,
                    slug: c.slug === '' || c.slug === slugify(c.name) ? slugify(name) : c.slug,
                  }))
                  clearFieldError('name')
                }}
                placeholder="Peak Performance Gym"
                aria-invalid={Boolean(fieldErrors.name)}
              />
            </Field>
            <Field label="URL slug" htmlFor="tenant-slug" required error={fieldErrors.slug}>
              <Input
                id="tenant-slug"
                value={form.slug}
                onChange={(e) => {
                  setForm((c) => ({ ...c, slug: e.target.value.toLowerCase() }))
                  clearFieldError('slug')
                }}
                placeholder="peak-performance"
                aria-invalid={Boolean(fieldErrors.slug)}
              />
            </Field>
            <Field label="Legal name" htmlFor="tenant-legal">
              <Input
                id="tenant-legal"
                value={form.legal_name}
                onChange={(e) => setForm((c) => ({ ...c, legal_name: e.target.value }))}
                placeholder="Optional"
              />
            </Field>
            <Field label="SaaS plan" htmlFor="tenant-plan" required error={fieldErrors.saas_plan_id}>
              <Select
                id="tenant-plan"
                value={form.saas_plan_id}
                onChange={(e) => {
                  setForm((c) => ({ ...c, saas_plan_id: e.target.value }))
                  clearFieldError('saas_plan_id')
                }}
                aria-invalid={Boolean(fieldErrors.saas_plan_id)}
              >
                <option value="">Select plan</option>
                {plans.map((plan) => (
                  <option key={plan.id} value={plan.id}>
                    {plan.name} ({plan.code})
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Owner email" htmlFor="tenant-email">
              <Input
                id="tenant-email"
                type="email"
                value={form.email}
                onChange={(e) => setForm((c) => ({ ...c, email: e.target.value }))}
              />
            </Field>
            <Field label="Phone" htmlFor="tenant-phone">
              <Input
                id="tenant-phone"
                value={form.phone}
                onChange={(e) => setForm((c) => ({ ...c, phone: e.target.value }))}
              />
            </Field>
            <Field label="Country" htmlFor="tenant-country">
              <Input
                id="tenant-country"
                maxLength={2}
                value={form.primary_country}
                onChange={(e) =>
                  setForm((c) => ({ ...c, primary_country: e.target.value.toUpperCase() }))
                }
              />
            </Field>
            <Field label="Currency" htmlFor="tenant-currency">
              <Input
                id="tenant-currency"
                maxLength={3}
                value={form.base_currency}
                onChange={(e) =>
                  setForm((c) => ({ ...c, base_currency: e.target.value.toUpperCase() }))
                }
              />
            </Field>
            <Field label="Timezone" htmlFor="tenant-tz">
              <Input
                id="tenant-tz"
                value={form.timezone}
                onChange={(e) => setForm((c) => ({ ...c, timezone: e.target.value }))}
                placeholder="Asia/Kolkata"
              />
            </Field>
            <Field label="Trial days" htmlFor="tenant-trial">
              <Input
                id="tenant-trial"
                type="number"
                min={1}
                max={365}
                value={form.trial_days}
                onChange={(e) => setForm((c) => ({ ...c, trial_days: e.target.value }))}
              />
            </Field>
            <div className="flex items-end gap-2 sm:col-span-2 xl:col-span-4">
              <Button type="submit" loading={provisionMutation.isPending}>
                Provision tenant
              </Button>
              <Button type="button" variant="ghost" onClick={() => setShowProvision(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <Card className="p-4 sm:p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2">
            {STATUS_FILTERS.map((filter) => {
              const count =
                filter.value === ''
                  ? stats.total
                  : filter.value === 'active'
                    ? stats.active
                    : filter.value === 'trial'
                      ? stats.trial
                      : filter.value === 'suspended'
                        ? stats.suspended
                        : stats.cancelled
              const active = statusFilter === filter.value
              return (
                <button
                  key={filter.label}
                  type="button"
                  onClick={() => setStatusFilter(filter.value)}
                  className={cn(
                    'inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition',
                    active
                      ? 'bg-accent text-accent-ink'
                      : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                  )}
                >
                  {filter.label}
                  <span
                    className={cn(
                      'rounded-md px-1.5 py-0.5 text-[11px]',
                      active ? 'bg-black/15' : 'bg-white/10',
                    )}
                  >
                    {count}
                  </span>
                </button>
              )
            })}
          </div>

          <div className="relative w-full lg:max-w-sm">
            <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, slug, email, plan…"
              className="pl-10"
              aria-label="Search tenants"
            />
          </div>
        </div>
      </Card>

      <div className={cn('grid gap-4', selected ? 'xl:grid-cols-[1fr_22rem]' : '')}>
        <div className="min-w-0">
          {tenantsQuery.isPending ? (
            <div className="flex justify-center py-20">
              <Spinner label="Loading tenants…" />
            </div>
          ) : (
            <DataTable
              columns={columns}
              rows={pageRows}
              rowKey={(row) => row.id}
              emptyTitle="No tenants match"
              emptyDescription="Try another status filter, clear search, or provision a new gym."
            />
          )}
          <Pagination meta={pageMeta} onPageChange={setPage} />
        </div>

        {selected ? (
          <aside className="animate-slide-in">
            <Card className="sticky top-4">
              <div className="mb-4 flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                    <Building2 className="h-5 w-5" />
                  </div>
                  <CardTitle className="truncate text-base">{selected.name}</CardTitle>
                  <CardDescription className="font-mono">/{selected.slug}</CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedId(null)}
                  aria-label="Close details"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="mb-4 flex flex-wrap gap-2">
                <Badge tone={tenantStatusTone(selected.status)}>{selected.status}</Badge>
                {selected.saas_plan ? <Badge tone="neutral">{selected.saas_plan.name}</Badge> : null}
              </div>

              <dl className="space-y-2.5 text-sm">
                <DetailRow label="Email" value={selected.email ?? '—'} />
                <DetailRow label="Phone" value={selected.phone ?? '—'} />
                <DetailRow label="Country" value={selected.primary_country ?? '—'} />
                <DetailRow label="Currency" value={selected.base_currency ?? '—'} />
                <DetailRow label="Timezone" value={selected.timezone ?? '—'} />
                <DetailRow label="Trial ends" value={formatDate(selected.trial_ends_at)} />
                <DetailRow label="Suspended" value={formatDate(selected.suspended_at)} />
                <DetailRow label="Created" value={formatDate(selected.created_at)} />
              </dl>

              {canManage ? (
                <div className="mt-5 space-y-4 border-t border-white/12 pt-4">
                  <div>
                    <p className="mb-2 text-xs font-semibold tracking-wide text-muted uppercase">
                      Lifecycle
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {(selected.status === 'trial' || selected.status === 'suspended') && (
                        <Button
                          size="sm"
                          variant="secondary"
                          disabled={actionMutation.isPending}
                          onClick={() => void runActivate(selected)}
                        >
                          <PlayCircle className="h-3.5 w-3.5" />
                          Activate
                        </Button>
                      )}
                      {selected.status === 'suspended' && (
                        <Button
                          size="sm"
                          variant="secondary"
                          disabled={actionMutation.isPending}
                          onClick={() => void runReactivate(selected)}
                        >
                          <RefreshCw className="h-3.5 w-3.5" />
                          Reactivate
                        </Button>
                      )}
                      {(selected.status === 'active' || selected.status === 'trial') && (
                        <Button
                          size="sm"
                          variant="danger"
                          disabled={actionMutation.isPending}
                          onClick={() => void runSuspend(selected)}
                        >
                          <PauseCircle className="h-3.5 w-3.5" />
                          Suspend
                        </Button>
                      )}
                    </div>
                  </div>

                  {(selected.status === 'active' || selected.status === 'trial') && (
                    <div>
                      <Label htmlFor="suspend-reason">Suspend reason</Label>
                      <Input
                        id="suspend-reason"
                        value={suspendReason}
                        onChange={(e) => setSuspendReason(e.target.value)}
                        placeholder="manual, non_payment…"
                      />
                    </div>
                  )}

                  {selected.status === 'trial' ? (
                    <div>
                      <Label htmlFor="extend-days">Extend trial (days)</Label>
                      <div className="flex gap-2">
                        <Input
                          id="extend-days"
                          type="number"
                          min={1}
                          max={365}
                          value={extendDays}
                          onChange={(e) => setExtendDays(e.target.value)}
                        />
                        <Button
                          size="md"
                          variant="secondary"
                          disabled={actionMutation.isPending}
                          onClick={() =>
                            actionMutation.mutate({
                              type: 'extend',
                              tenant: selected,
                              days: Number(extendDays) || 7,
                            })
                          }
                        >
                          <Timer className="h-4 w-4" />
                          Extend
                        </Button>
                      </div>
                    </div>
                  ) : null}

                  {canViewPlans ? (
                    <div>
                      <Label htmlFor="assign-plan">Assign SaaS plan</Label>
                      <div className="flex gap-2">
                        <Select
                          id="assign-plan"
                          value={assignPlanId}
                          onChange={(e) => setAssignPlanId(e.target.value)}
                        >
                          <option value="">Select plan</option>
                          {plans.map((plan) => (
                            <option key={plan.id} value={plan.id}>
                              {plan.name}
                            </option>
                          ))}
                        </Select>
                        <Button
                          size="md"
                          variant="secondary"
                          disabled={
                            actionMutation.isPending ||
                            !assignPlanId ||
                            Number(assignPlanId) === selected.saas_plan_id
                          }
                          onClick={() =>
                            actionMutation.mutate({
                              type: 'assign',
                              tenant: selected,
                              planId: Number(assignPlanId),
                            })
                          }
                        >
                          Save
                        </Button>
                      </div>
                    </div>
                  ) : null}
                </div>
              ) : (
                <p className="mt-5 border-t border-white/12 pt-4 text-sm text-muted">
                  You can view tenants. Lifecycle changes require platform.tenants.manage.
                </p>
              )}
            </Card>
          </aside>
        ) : null}
      </div>
    </div>
  )
}

function SummaryChip({
  label,
  value,
  tone = 'neutral',
}: {
  label: string
  value: string
  tone?: 'neutral' | 'success' | 'accent' | 'danger' | 'warning'
}) {
  const tones = {
    neutral: 'border-white/12 bg-white/6',
    success: 'border-success/25 bg-success/10',
    accent: 'border-accent/30 bg-accent/10',
    danger: 'border-danger/25 bg-danger/10',
    warning: 'border-warning/30 bg-warning/10',
  }
  return (
    <div className={cn('rounded-2xl border px-4 py-3', tones[tone])}>
      <p className="text-xs font-semibold tracking-wide text-muted uppercase">{label}</p>
      <p className="mt-1 font-display text-2xl font-bold text-ink">{value}</p>
    </div>
  )
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <dt className="text-muted">{label}</dt>
      <dd className="max-w-[60%] text-right font-medium break-all text-ink">{value}</dd>
    </div>
  )
}

function slugify(value: string) {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80)
}
