import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  CalendarDays,
  CheckCircle2,
  ClipboardList,
  Plus,
  Search,
  Trash2,
  UserPlus,
  Users,
  X,
  XCircle,
} from 'lucide-react'
import {
  bookClassForMember,
  cancelClassBooking,
  cancelClassSchedule,
  createClassSchedules,
  createClassType,
  deleteClassType,
  fetchClassRoster,
  fetchClassSchedule,
  fetchClassSchedules,
  fetchClassTypes,
  fetchClassWaitlist,
  markClassAttendance,
  promoteWaitlistEntry,
  updateClassType,
  type ClassBooking,
  type ClassSchedule,
  type ClassScheduleStatus,
  type ClassType,
  type ClassWaitlistEntry,
  type WaitlistMode,
} from '@/api/classes'
import { fetchMembers, type Member } from '@/api/members'
import { fetchStaff } from '@/api/staff'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useBranchFilter } from '@/hooks/useBranchFilter'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'

type PageTab = 'schedules' | 'types'
type ScheduleStatusFilter = '' | ClassScheduleStatus
type DetailPanel = 'book' | null

const SCHEDULE_STATUS_FILTERS: Array<{ value: ScheduleStatusFilter; label: string }> = [
  { value: '', label: 'All Status' },
  { value: 'scheduled', label: 'Scheduled' },
  { value: 'cancelled', label: 'Cancelled' },
  { value: 'completed', label: 'Completed' },
]

function todayIso() {
  return new Date().toISOString().slice(0, 10)
}

function toLocalInputValue(date = new Date()) {
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`
}

function tomorrowAt(hour: number, minute = 0) {
  const d = new Date()
  d.setDate(d.getDate() + 1)
  d.setHours(hour, minute, 0, 0)
  return toLocalInputValue(d)
}

function formatDateTime(value?: string | null): string {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return new Intl.DateTimeFormat(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date)
}

function formatTimeRange(starts?: string | null, ends?: string | null) {
  if (!starts) return '—'
  const start = new Date(starts)
  if (Number.isNaN(start.getTime())) return starts
  const startLabel = new Intl.DateTimeFormat(undefined, {
    hour: '2-digit',
    minute: '2-digit',
  }).format(start)
  if (!ends) return startLabel
  const end = new Date(ends)
  if (Number.isNaN(end.getTime())) return startLabel
  return `${startLabel} – ${new Intl.DateTimeFormat(undefined, {
    hour: '2-digit',
    minute: '2-digit',
  }).format(end)}`
}

function memberLabel(m?: {
  first_name?: string
  last_name?: string
  member_code?: string
  full_name?: string
} | null) {
  if (!m) return '—'
  if (m.full_name) {
    return m.member_code ? `${m.full_name} (${m.member_code})` : m.full_name
  }
  const name = `${m.first_name ?? ''} ${m.last_name ?? ''}`.trim()
  return name ? `${name}${m.member_code ? ` (${m.member_code})` : ''}` : m.member_code || '—'
}

function scheduleStatusTone(
  status: ClassScheduleStatus,
): 'success' | 'danger' | 'neutral' | 'accent' {
  switch (status) {
    case 'scheduled':
      return 'success'
    case 'cancelled':
      return 'danger'
    case 'completed':
      return 'accent'
    default:
      return 'neutral'
  }
}

function bookingStatusTone(
  status: string,
): 'success' | 'danger' | 'neutral' | 'warning' | 'accent' {
  switch (status) {
    case 'booked':
      return 'accent'
    case 'attended':
      return 'success'
    case 'no_show':
      return 'warning'
    case 'cancelled':
      return 'danger'
    default:
      return 'neutral'
  }
}

function localInputToApi(value: string) {
  if (!value) return value
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:00`
}

export function ClassesPage() {
  const { branches, branchId, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('classes.view')
  const canManage = hasPermission('classes.manage')
  const canBook = hasPermission('classes.book_for_member')
  const canStaff = hasPermission('identity.staff.view')

  const [tab, setTab] = useState<PageTab>('schedules')
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }

  // Schedules state
  const [page, setPage] = useState(1)
  const [statusFilter, setStatusFilter] = useState<ScheduleStatusFilter>('scheduled')
  const [branchFilter, setBranchFilter] = useBranchFilter()
  const [dateFilter, setDateFilter] = useState(todayIso())
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [showCreateSchedule, setShowCreateSchedule] = useState(false)
  const [detailPanel, setDetailPanel] = useState<DetailPanel>(null)

  const [schedBranchId, setSchedBranchId] = useState<number | ''>(branchId ?? '')
  const [schedTypeId, setSchedTypeId] = useState<number | ''>('')
  const [schedInstructorId, setSchedInstructorId] = useState<number | ''>('')
  const [schedStartsAt, setSchedStartsAt] = useState(tomorrowAt(10))
  const [schedEndsAt, setSchedEndsAt] = useState('')
  const [schedCapacity, setSchedCapacity] = useState('')
  const [schedWaitlistMode, setSchedWaitlistMode] = useState<WaitlistMode>('both')
  const [schedRecurrence, setSchedRecurrence] = useState(false)
  const [schedRecurrenceCount, setSchedRecurrenceCount] = useState('4')

  const [memberSearch, setMemberSearch] = useState('')
  const [appliedMemberSearch, setAppliedMemberSearch] = useState('')
  const [bookMemberId, setBookMemberId] = useState<number | ''>('')
  const [waitlistIfFull, setWaitlistIfFull] = useState(true)

  // Types state
  const [typesPage, setTypesPage] = useState(1)
  const [typeSearch, setTypeSearch] = useState('')
  const [appliedTypeSearch, setAppliedTypeSearch] = useState('')
  const [typeActiveFilter, setTypeActiveFilter] = useState<'' | 'active' | 'inactive'>('')
  const [showCreateType, setShowCreateType] = useState(false)
  const [editingType, setEditingType] = useState<ClassType | null>(null)
  const [typeForm, setTypeForm] = useState({
    code: '',
    name: '',
    category: '',
    default_duration_minutes: '60',
    default_capacity: '20',
    waitlist_enabled: true,
    is_active: true,
  })

  useEffect(() => {
    setSchedBranchId(branchId ?? '')
  }, [branchId])

  const typesOptionsQuery = useQuery({
    queryKey: ['admin', 'class-types', 'options'],
    queryFn: () => fetchClassTypes({ page: 1, per_page: 100, is_active: true }),
    enabled: canView,
  })

  const schedulesQuery = useQuery({
    queryKey: [
      'admin',
      'class-schedules',
      page,
      statusFilter,
      branchFilter,
      dateFilter,
    ],
    queryFn: () =>
      fetchClassSchedules({
        page,
        per_page: DEFAULT_PAGE_SIZE,
        status: statusFilter,
        branch_id: branchFilter,
        date: dateFilter || undefined,
      }),
    enabled: canView && tab === 'schedules',
  })

  const statsQuery = useQuery({
    queryKey: ['admin', 'class-schedules', 'stats', dateFilter, branchFilter],
    queryFn: async () => {
      const [scheduled, cancelled, today] = await Promise.all([
        fetchClassSchedules({
          page: 1,
          per_page: 1,
          status: 'scheduled',
          date: dateFilter || undefined,
          branch_id: branchFilter,
        }),
        fetchClassSchedules({
          page: 1,
          per_page: 1,
          status: 'cancelled',
          date: dateFilter || undefined,
          branch_id: branchFilter,
        }),
        fetchClassSchedules({
          page: 1,
          per_page: 1,
          date: dateFilter || todayIso(),
          branch_id: branchFilter,
        }),
      ])
      return {
        scheduled: scheduled.meta.total,
        cancelled: cancelled.meta.total,
        today: today.meta.total,
      }
    },
    enabled: canView,
  })

  const selectedQuery = useQuery({
    queryKey: ['admin', 'class-schedules', 'detail', selectedId],
    queryFn: () => fetchClassSchedule(selectedId!),
    enabled: canView && selectedId != null,
  })

  const rosterQuery = useQuery({
    queryKey: ['admin', 'class-schedules', 'roster', selectedId],
    queryFn: () => fetchClassRoster(selectedId!),
    enabled: canView && selectedId != null,
  })

  const waitlistQuery = useQuery({
    queryKey: ['admin', 'class-schedules', 'waitlist', selectedId],
    queryFn: () => fetchClassWaitlist(selectedId!),
    enabled: canView && selectedId != null,
  })

  const staffQuery = useQuery({
    queryKey: ['admin', 'staff', 'class-instructors'],
    queryFn: () => fetchStaff({ page: 1, per_page: 100, is_active: true }),
    enabled: canManage && canStaff && (showCreateSchedule || tab === 'schedules'),
  })

  const membersQuery = useQuery({
    queryKey: ['admin', 'members', 'class-book', appliedMemberSearch],
    queryFn: () =>
      fetchMembers({
        page: 1,
        per_page: 20,
        search: appliedMemberSearch,
        status: 'active',
      }),
    enabled: canBook && detailPanel === 'book' && appliedMemberSearch.length > 0,
  })

  const typesQuery = useQuery({
    queryKey: [
      'admin',
      'class-types',
      typesPage,
      appliedTypeSearch,
      typeActiveFilter,
    ],
    queryFn: () =>
      fetchClassTypes({
        page: typesPage,
        per_page: DEFAULT_PAGE_SIZE,
        search: appliedTypeSearch,
        is_active:
          typeActiveFilter === '' ? '' : typeActiveFilter === 'active',
      }),
    enabled: canView && tab === 'types',
  })

  const rows = schedulesQuery.data?.data ?? []
  const meta = schedulesQuery.data?.meta
  const classTypes = typesOptionsQuery.data?.data ?? []
  const instructors = staffQuery.data?.data ?? []
  const members = membersQuery.data?.data ?? []
  const roster = rosterQuery.data ?? []
  const waitlist = waitlistQuery.data ?? []
  const selected = useMemo(() => {
    if (selectedId == null) return null
    return selectedQuery.data ?? rows.find((row) => row.id === selectedId) ?? null
  }, [selectedId, selectedQuery.data, rows])

  useEffect(() => {
    setDetailPanel(null)
    setBookMemberId('')
    setMemberSearch('')
    setAppliedMemberSearch('')
  }, [selected?.id])

  const invalidateSchedules = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'class-schedules'] })
  }

  const invalidateTypes = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'class-types'] })
  }

  const apiError = (err: unknown, fallback: string) =>
    err instanceof ApiError ? err.message : fallback

  const createScheduleMutation = useMutation({
    mutationFn: createClassSchedules,
    onSuccess: async (created) => {
      setError(null)
      showSuccess(
        created.length > 1
          ? `${created.length} sessions scheduled.`
          : `Session “${created[0]?.class_type?.name ?? 'Class'}” scheduled.`,
      )
      setShowCreateSchedule(false)
      resetScheduleForm()
      setDateFilter(created[0]?.starts_at?.slice(0, 10) || dateFilter)
      setStatusFilter('scheduled')
      setPage(1)
      await invalidateSchedules()
      if (created[0]) setSelectedId(created[0].id)
    },
    onError: (err) => setError(apiError(err, 'Unable to create schedule.')),
  })

  const cancelScheduleMutation = useMutation({
    mutationFn: cancelClassSchedule,
    onSuccess: async (row) => {
      setError(null)
      showSuccess(`Session #${row.id} cancelled.`)
      await invalidateSchedules()
    },
    onError: (err) => setError(apiError(err, 'Unable to cancel schedule.')),
  })

  const bookMutation = useMutation({
    mutationFn: bookClassForMember,
    onSuccess: async (result) => {
      setError(null)
      if (result.type === 'booking') {
        showSuccess(`Booked for ${memberLabel(result.booking.member)}.`)
      } else {
        showSuccess(
          `Added to waitlist (position ${result.waitlist.position}) for ${memberLabel(result.waitlist.member)}.`,
        )
      }
      setDetailPanel(null)
      setBookMemberId('')
      setMemberSearch('')
      setAppliedMemberSearch('')
      await invalidateSchedules()
    },
    onError: (err) => setError(apiError(err, 'Unable to book member.')),
  })

  const cancelBookingMutation = useMutation({
    mutationFn: (bookingId: number) => cancelClassBooking(bookingId),
    onSuccess: async () => {
      setError(null)
      showSuccess('Booking cancelled.')
      await invalidateSchedules()
    },
    onError: (err) => setError(apiError(err, 'Unable to cancel booking.')),
  })

  const promoteMutation = useMutation({
    mutationFn: promoteWaitlistEntry,
    onSuccess: async (booking) => {
      setError(null)
      showSuccess(`Promoted ${memberLabel(booking.member)} into a booking.`)
      await invalidateSchedules()
    },
    onError: (err) => setError(apiError(err, 'Unable to promote waitlist entry.')),
  })

  const attendanceMutation = useMutation({
    mutationFn: ({
      bookingId,
      status,
    }: {
      bookingId: number
      status: 'attended' | 'no_show'
    }) => markClassAttendance(bookingId, status),
    onSuccess: async (_, vars) => {
      setError(null)
      showSuccess(vars.status === 'attended' ? 'Marked attended.' : 'Marked no-show.')
      await invalidateSchedules()
    },
    onError: (err) => setError(apiError(err, 'Unable to mark attendance.')),
  })

  const createTypeMutation = useMutation({
    mutationFn: createClassType,
    onSuccess: async (type) => {
      setError(null)
      showSuccess(`Class type “${type.name}” created.`)
      setShowCreateType(false)
      resetTypeForm()
      await invalidateTypes()
    },
    onError: (err) => setError(apiError(err, 'Unable to create class type.')),
  })

  const updateTypeMutation = useMutation({
    mutationFn: (payload: Parameters<typeof updateClassType>[1]) =>
      updateClassType(editingType!.id, payload),
    onSuccess: async (type) => {
      setError(null)
      showSuccess(`Class type “${type.name}” updated.`)
      setEditingType(null)
      resetTypeForm()
      await invalidateTypes()
    },
    onError: (err) => setError(apiError(err, 'Unable to update class type.')),
  })

  const deleteTypeMutation = useMutation({
    mutationFn: deleteClassType,
    onSuccess: async () => {
      setError(null)
      showSuccess('Class type deleted.')
      setEditingType(null)
      await invalidateTypes()
    },
    onError: (err) => setError(apiError(err, 'Unable to delete class type.')),
  })

  const resetScheduleForm = () => {
    setSchedTypeId('')
    setSchedInstructorId('')
    setSchedStartsAt(tomorrowAt(10))
    setSchedEndsAt('')
    setSchedCapacity('')
    setSchedWaitlistMode('both')
    setSchedRecurrence(false)
    setSchedRecurrenceCount('4')
    if (branchId != null) setSchedBranchId(branchId)
  }

  const resetTypeForm = () => {
    setTypeForm({
      code: '',
      name: '',
      category: '',
      default_duration_minutes: '60',
      default_capacity: '20',
      waitlist_enabled: true,
      is_active: true,
    })
  }

  const onCreateSchedule = (event: FormEvent) => {
    event.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'schedBranchId', label: 'Branch', value: schedBranchId },
      { key: 'schedTypeId', label: 'Class type', value: schedTypeId },
      { key: 'schedStartsAt', label: 'Starts at', value: schedStartsAt },
    ])
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    createScheduleMutation.mutate({
      branch_id: Number(schedBranchId),
      class_type_id: Number(schedTypeId),
      instructor_user_id: schedInstructorId ? Number(schedInstructorId) : null,
      starts_at: localInputToApi(schedStartsAt),
      ends_at: schedEndsAt ? localInputToApi(schedEndsAt) : null,
      capacity: schedCapacity ? Number(schedCapacity) : null,
      waitlist_mode: schedWaitlistMode,
      recurrence: schedRecurrence
        ? { frequency: 'weekly', count: Number(schedRecurrenceCount) || 1 }
        : null,
    })
  }

  const onCancelSchedule = async (row: ClassSchedule) => {
    const ok = await confirm({
      title: 'Cancel session?',
      message: `Cancel “${row.class_type?.name ?? 'class'}” on ${formatDateTime(row.starts_at)}? Bookings and waitlist entries will be cancelled.`,
      confirmLabel: 'Cancel session',
      tone: 'danger',
    })
    if (!ok) return
    cancelScheduleMutation.mutate(row.id)
  }

  const onBook = (event: FormEvent) => {
    event.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'bookMemberId', label: 'Member', value: bookMemberId },
    ])
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    if (!selectedId) return
    bookMutation.mutate({
      class_schedule_id: selectedId,
      member_id: Number(bookMemberId),
      waitlist_if_full: waitlistIfFull,
    })
  }

  const onCancelBooking = async (booking: ClassBooking) => {
    const ok = await confirm({
      title: 'Cancel booking?',
      message: `Cancel booking for ${memberLabel(booking.member)}?`,
      confirmLabel: 'Cancel booking',
      tone: 'danger',
    })
    if (!ok) return
    cancelBookingMutation.mutate(booking.id)
  }

  const onPromote = async (entry: ClassWaitlistEntry) => {
    const ok = await confirm({
      title: 'Promote from waitlist?',
      message: `Book ${memberLabel(entry.member)} into an open seat?`,
      confirmLabel: 'Promote',
      tone: 'primary',
    })
    if (!ok) return
    promoteMutation.mutate(entry.id)
  }

  const openEditType = (type: ClassType) => {
    setEditingType(type)
    setShowCreateType(false)
    setTypeForm({
      code: type.code,
      name: type.name,
      category: type.category ?? '',
      default_duration_minutes: String(type.default_duration_minutes),
      default_capacity: String(type.default_capacity),
      waitlist_enabled: type.waitlist_enabled,
      is_active: type.is_active,
    })
  }

  const typePayload = () => ({
    code: typeForm.code.trim().toUpperCase(),
    name: typeForm.name.trim(),
    category: typeForm.category.trim() || null,
    default_duration_minutes: Number(typeForm.default_duration_minutes) || 60,
    default_capacity: Number(typeForm.default_capacity) || 20,
    waitlist_enabled: typeForm.waitlist_enabled,
    is_active: typeForm.is_active,
  })

  const onSaveType = (event: FormEvent) => {
    event.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'typeCode', label: 'Code', value: typeForm.code },
      { key: 'typeName', label: 'Name', value: typeForm.name },
    ])
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    if (editingType) updateTypeMutation.mutate(typePayload())
    else createTypeMutation.mutate(typePayload())
  }

  const onDeleteType = async (type: ClassType) => {
    const ok = await confirm({
      title: 'Delete class type?',
      message: `Delete “${type.name}” (${type.code})? Existing schedules are kept but this type will be removed from the catalog.`,
      confirmLabel: 'Delete type',
      tone: 'danger',
    })
    if (!ok) return
    deleteTypeMutation.mutate(type.id)
  }

  const scheduleColumns: Column<ClassSchedule>[] = [
    {
      key: 'when',
      header: 'When',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">{formatDateTime(row.starts_at)}</p>
          <p className="mt-0.5 text-xs text-muted">
            {formatTimeRange(row.starts_at, row.ends_at)}
          </p>
        </button>
      ),
    },
    {
      key: 'class',
      header: 'Class',
      cell: (row) => (
        <div>
          <p className="text-sm font-medium text-ink">{row.class_type?.name ?? '—'}</p>
          <p className="font-mono text-xs text-muted">{row.class_type?.code}</p>
        </div>
      ),
    },
    {
      key: 'branch',
      header: 'Branch',
      cell: (row) => <span className="text-sm text-ink">{row.branch?.name ?? '—'}</span>,
    },
    {
      key: 'instructor',
      header: 'Instructor',
      cell: (row) => (
        <span className="text-sm text-muted">{row.instructor?.name ?? 'Unassigned'}</span>
      ),
    },
    {
      key: 'capacity',
      header: 'Seats',
      cell: (row) => (
        <span className="text-sm text-ink">
          {row.booked_count}/{row.capacity}
          {row.waitlist_count > 0 ? (
            <span className="text-muted"> · WL {row.waitlist_count}</span>
          ) : null}
        </span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={scheduleStatusTone(row.status)}>
          {row.status.charAt(0).toUpperCase() + row.status.slice(1)}
        </Badge>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedId(row.id)}>
          Manage
        </Button>
      ),
    },
  ]

  const typeColumns: Column<ClassType>[] = [
    {
      key: 'type',
      header: 'Class type',
      cell: (row) => (
        <div>
          <p className="font-semibold text-ink">{row.name}</p>
          <p className="font-mono text-xs text-muted">{row.code}</p>
        </div>
      ),
    },
    {
      key: 'category',
      header: 'Category',
      cell: (row) => <span className="text-sm text-muted">{row.category || '—'}</span>,
    },
    {
      key: 'defaults',
      header: 'Defaults',
      cell: (row) => (
        <span className="text-sm text-ink">
          {row.default_duration_minutes} min · {row.default_capacity} seats
        </span>
      ),
    },
    {
      key: 'waitlist',
      header: 'Waitlist',
      cell: (row) => (
        <Badge tone={row.waitlist_enabled ? 'success' : 'neutral'}>
          {row.waitlist_enabled ? 'Enabled' : 'Off'}
        </Badge>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.is_active ? 'success' : 'danger'}>
          {row.is_active ? 'Active' : 'Inactive'}
        </Badge>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) =>
        canManage ? (
          <Button size="sm" variant="secondary" onClick={() => openEditType(row)}>
            Edit
          </Button>
        ) : null,
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader title="Classes" description="Schedules and bookings." />
        <Alert tone="danger">You do not have permission to view classes.</Alert>
      </div>
    )
  }

  const stats = statsQuery.data
  const activeRoster = roster.filter((b) => b.status !== 'cancelled')
  const waitingList = waitlist.filter((w) => w.status === 'waiting')

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Classes"
        description="Schedules and bookings — class types, sessions, roster, and waitlist."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">Gym</Badge>
            {tab === 'schedules' && canManage ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowCreateSchedule(true)
                  setError(null)
                  setFieldErrors({})
                }}
              >
                <Plus className="h-4 w-4" />
                New session
              </Button>
            ) : null}
            {tab === 'types' && canManage ? (
              <Button
                size="sm"
                onClick={() => {
                  setEditingType(null)
                  resetTypeForm()
                  setShowCreateType(true)
                  setError(null)
                  setFieldErrors({})
                }}
              >
                <Plus className="h-4 w-4" />
                New class type
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <SummaryChip
          icon={<CalendarDays className="h-4 w-4" />}
          label="Sessions on date"
          value={formatNumber(stats?.today ?? 0)}
        />
        <SummaryChip
          icon={<CheckCircle2 className="h-4 w-4" />}
          label="Scheduled"
          value={formatNumber(stats?.scheduled ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<XCircle className="h-4 w-4" />}
          label="Cancelled"
          value={formatNumber(stats?.cancelled ?? 0)}
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {(
          [
            { id: 'schedules' as const, label: 'Schedules' },
            { id: 'types' as const, label: 'Class types' },
          ] as const
        ).map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => {
              setTab(item.id)
              setSelectedId(null)
              setError(null)
              setShowCreateSchedule(false)
              setShowCreateType(false)
              setEditingType(null)
            }}
            className={cn(
              'rounded-xl px-3 py-2 text-sm font-semibold transition',
              tab === item.id
                ? 'bg-accent text-accent-ink'
                : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
            )}
          >
            {item.label}
          </button>
        ))}
      </div>

      {tab === 'schedules' ? (
        <>
          {showCreateSchedule && canManage ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Schedule a session</CardTitle>
                  <CardDescription>
                    Create one session or a weekly recurrence series.
                  </CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setShowCreateSchedule(false)}
                  aria-label="Close"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form onSubmit={onCreateSchedule} noValidate className="grid gap-3 sm:grid-cols-2">
                <Field
                  label="Branch"
                  htmlFor="sched-branch"
                  required
                  error={fieldErrors.schedBranchId}
                >
                  <Select
                    id="sched-branch"
                    value={schedBranchId === '' ? '' : String(schedBranchId)}
                    onChange={(e) => {
                      setSchedBranchId(e.target.value ? Number(e.target.value) : '')
                      clearFieldError('schedBranchId')
                    }}
                    aria-invalid={Boolean(fieldErrors.schedBranchId)}
                  >
                    <option value="">Select branch…</option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field
                  label="Class type"
                  htmlFor="sched-type"
                  required
                  error={fieldErrors.schedTypeId}
                >
                  <Select
                    id="sched-type"
                    value={schedTypeId === '' ? '' : String(schedTypeId)}
                    onChange={(e) => {
                      setSchedTypeId(e.target.value ? Number(e.target.value) : '')
                      clearFieldError('schedTypeId')
                    }}
                    aria-invalid={Boolean(fieldErrors.schedTypeId)}
                  >
                    <option value="">Select type…</option>
                    {classTypes.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name} ({t.default_duration_minutes} min)
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field
                  label="Starts at"
                  htmlFor="sched-start"
                  required
                  error={fieldErrors.schedStartsAt}
                >
                  <Input
                    id="sched-start"
                    type="datetime-local"
                    value={schedStartsAt}
                    onChange={(e) => {
                      setSchedStartsAt(e.target.value)
                      clearFieldError('schedStartsAt')
                    }}
                    aria-invalid={Boolean(fieldErrors.schedStartsAt)}
                  />
                </Field>
                <div>
                  <Label htmlFor="sched-end">Ends at (optional)</Label>
                  <Input
                    id="sched-end"
                    type="datetime-local"
                    value={schedEndsAt}
                    onChange={(e) => setSchedEndsAt(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="sched-instructor">Instructor (optional)</Label>
                  <Select
                    id="sched-instructor"
                    value={schedInstructorId === '' ? '' : String(schedInstructorId)}
                    onChange={(e) =>
                      setSchedInstructorId(e.target.value ? Number(e.target.value) : '')
                    }
                  >
                    <option value="">Unassigned</option>
                    {instructors.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </Select>
                </div>
                <div>
                  <Label htmlFor="sched-capacity">Capacity (optional)</Label>
                  <Input
                    id="sched-capacity"
                    type="number"
                    min="1"
                    value={schedCapacity}
                    onChange={(e) => setSchedCapacity(e.target.value)}
                    placeholder="Type default"
                  />
                </div>
                <div>
                  <Label htmlFor="sched-waitlist">Waitlist mode</Label>
                  <Select
                    id="sched-waitlist"
                    value={schedWaitlistMode}
                    onChange={(e) => setSchedWaitlistMode(e.target.value as WaitlistMode)}
                  >
                    <option value="auto">Auto promote</option>
                    <option value="manual">Manual only</option>
                    <option value="both">Auto + manual</option>
                  </Select>
                </div>
                <div className="flex items-end gap-3">
                  <label className="flex items-center gap-2 pb-2 text-sm text-ink">
                    <input
                      type="checkbox"
                      checked={schedRecurrence}
                      onChange={(e) => setSchedRecurrence(e.target.checked)}
                    />
                    Weekly recurrence
                  </label>
                  {schedRecurrence ? (
                    <Input
                      type="number"
                      min="1"
                      max="52"
                      value={schedRecurrenceCount}
                      onChange={(e) => setSchedRecurrenceCount(e.target.value)}
                      className="w-24"
                      aria-label="Recurrence count"
                    />
                  ) : null}
                </div>
                <div className="flex flex-wrap gap-2 sm:col-span-2">
                  <Button type="submit" loading={createScheduleMutation.isPending}>
                    Create session
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => setShowCreateSchedule(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          <Card>
            <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-end sm:justify-end">
              <div>
                <Label htmlFor="sched-status-filter">Status</Label>
                <Select
                  id="sched-status-filter"
                  value={statusFilter}
                  onChange={(e) => {
                    setStatusFilter(e.target.value as ScheduleStatusFilter)
                    setPage(1)
                    setSelectedId(null)
                  }}
                  aria-label="Filter by status"
                  className="sm:w-44"
                >
                  {SCHEDULE_STATUS_FILTERS.map((filter) => (
                    <option key={filter.label} value={filter.value}>
                      {filter.label}
                    </option>
                  ))}
                </Select>
              </div>
              <div>
                <Label htmlFor="sched-date">Date</Label>
                <Input
                  id="sched-date"
                  type="date"
                  value={dateFilter}
                  onChange={(e) => {
                    setDateFilter(e.target.value)
                    setPage(1)
                    setSelectedId(null)
                  }}
                />
              </div>
              <div>
                <Label htmlFor="sched-branch-filter">Branch</Label>
                <Select
                  id="sched-branch-filter"
                  value={branchFilter === '' ? '' : String(branchFilter)}
                  onChange={(e) => {
                    setBranchFilter(e.target.value ? Number(e.target.value) : '')
                    setPage(1)
                    setSelectedId(null)
                  }}
                  className="sm:w-44"
                >
                  <option value="">All branches</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </Select>
              </div>
            </div>
          </Card>

          <div className={cn('grid gap-4', selectedId != null ? 'xl:grid-cols-[1fr_28rem]' : '')}>
            <div className="min-w-0">
              {schedulesQuery.isPending ? (
                <div className="flex justify-center py-20">
                  <Spinner label="Loading schedules…" />
                </div>
              ) : schedulesQuery.isError ? (
                <Alert tone="danger">
                  {schedulesQuery.error instanceof ApiError
                    ? schedulesQuery.error.message
                    : 'Unable to load schedules.'}
                  <div className="mt-3">
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => void schedulesQuery.refetch()}
                    >
                      Try again
                    </Button>
                  </div>
                </Alert>
              ) : (
                <>
                  <DataTable
                    columns={scheduleColumns}
                    rows={rows}
                    rowKey={(row) => row.id}
                    emptyTitle="No sessions match"
                    emptyDescription="Try another date or create a new session."
                  />
                  <Pagination
                    meta={meta}
                    onPageChange={(next) => {
                      setPage(next)
                      setSelectedId(null)
                    }}
                  />
                </>
              )}
            </div>

            {selectedId != null && !selected && selectedQuery.isPending ? (
              <aside className="animate-slide-in">
                <Card className="sticky top-4">
                  <div className="flex justify-center py-12">
                    <Spinner label="Loading session…" />
                  </div>
                </Card>
              </aside>
            ) : null}

            {selected ? (
              <aside className="animate-slide-in">
                <Card className="sticky top-4 max-h-[calc(100vh-6rem)] space-y-4 overflow-y-auto">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                        <ClipboardList className="h-5 w-5" />
                      </div>
                      <CardTitle className="truncate text-base">
                        {selected.class_type?.name ?? 'Class'}
                      </CardTitle>
                      <CardDescription>{formatDateTime(selected.starts_at)}</CardDescription>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setSelectedId(null)}
                      aria-label="Close"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Badge tone={scheduleStatusTone(selected.status)}>
                      {selected.status}
                    </Badge>
                    <Badge tone="neutral">
                      {selected.booked_count}/{selected.capacity} seats
                    </Badge>
                    {selected.waitlist_count > 0 ? (
                      <Badge tone="warning">WL {selected.waitlist_count}</Badge>
                    ) : null}
                  </div>

                  <dl className="space-y-2 text-sm">
                    <DetailRow label="Branch" value={selected.branch?.name ?? '—'} />
                    <DetailRow
                      label="Instructor"
                      value={selected.instructor?.name ?? 'Unassigned'}
                    />
                    <DetailRow
                      label="Time"
                      value={formatTimeRange(selected.starts_at, selected.ends_at)}
                    />
                    <DetailRow label="Waitlist mode" value={String(selected.waitlist_mode)} />
                  </dl>

                  <div className="flex flex-wrap gap-2 border-t border-white/12 pt-4">
                    {canBook && selected.status === 'scheduled' ? (
                      <Button
                        size="sm"
                        onClick={() =>
                          setDetailPanel(detailPanel === 'book' ? null : 'book')
                        }
                      >
                        <UserPlus className="h-4 w-4" />
                        Book member
                      </Button>
                    ) : null}
                    {canManage && selected.status === 'scheduled' ? (
                      <Button
                        size="sm"
                        variant="danger"
                        loading={cancelScheduleMutation.isPending}
                        onClick={() => void onCancelSchedule(selected)}
                      >
                        Cancel session
                      </Button>
                    ) : null}
                  </div>

                  {detailPanel === 'book' ? (
                    <div className="rounded-xl border border-accent/25 bg-accent/5 p-3">
                      <div className="mb-3 flex items-center justify-between">
                        <p className="text-sm font-semibold text-ink">Book member</p>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setDetailPanel(null)}
                          aria-label="Close book form"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                      <form onSubmit={onBook} noValidate className="space-y-3">
                        <div>
                          <Label htmlFor="book-search">Find member</Label>
                          <div className="flex gap-2">
                            <Input
                              id="book-search"
                              value={memberSearch}
                              onChange={(e) => setMemberSearch(e.target.value)}
                              placeholder="Name or code…"
                            />
                            <Button
                              type="button"
                              size="sm"
                              variant="secondary"
                              onClick={() => setAppliedMemberSearch(memberSearch.trim())}
                            >
                              <Search className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <Field
                          label="Member"
                          htmlFor="book-member"
                          required
                          error={fieldErrors.bookMemberId}
                        >
                          <Select
                            id="book-member"
                            value={bookMemberId === '' ? '' : String(bookMemberId)}
                            onChange={(e) => {
                              setBookMemberId(e.target.value ? Number(e.target.value) : '')
                              clearFieldError('bookMemberId')
                            }}
                            aria-invalid={Boolean(fieldErrors.bookMemberId)}
                          >
                            <option value="">Select…</option>
                            {members.map((m: Member) => (
                              <option key={m.id} value={m.id}>
                                {m.full_name} ({m.member_code})
                              </option>
                            ))}
                          </Select>
                        </Field>
                        <label className="flex items-center gap-2 text-sm text-ink">
                          <input
                            type="checkbox"
                            checked={waitlistIfFull}
                            onChange={(e) => setWaitlistIfFull(e.target.checked)}
                          />
                          Add to waitlist if full
                        </label>
                        <Button type="submit" size="sm" loading={bookMutation.isPending}>
                          Confirm booking
                        </Button>
                      </form>
                    </div>
                  ) : null}

                  <div className="space-y-3 border-t border-white/12 pt-4">
                    <p className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink">
                      <Users className="h-3.5 w-3.5" />
                      Roster ({activeRoster.length})
                    </p>
                    {rosterQuery.isPending ? (
                      <Spinner label="Loading roster…" />
                    ) : activeRoster.length === 0 ? (
                      <p className="text-sm text-muted">No bookings yet.</p>
                    ) : (
                      <div className="max-h-56 space-y-2 overflow-y-auto">
                        {activeRoster.map((booking) => (
                          <div
                            key={booking.id}
                            className="rounded-xl border border-white/10 bg-white/[0.04] p-3"
                          >
                            <div className="flex items-start justify-between gap-2">
                              <div className="min-w-0">
                                <p className="truncate text-sm font-semibold text-ink">
                                  {memberLabel(booking.member)}
                                </p>
                                <Badge
                                  tone={bookingStatusTone(booking.status)}
                                  className="mt-1"
                                >
                                  {booking.status}
                                </Badge>
                              </div>
                            </div>
                            <div className="mt-2 flex flex-wrap gap-1.5">
                              {canManage &&
                              (booking.status === 'booked' ||
                                booking.status === 'attended' ||
                                booking.status === 'no_show') ? (
                                <>
                                  <Button
                                    size="sm"
                                    variant="secondary"
                                    loading={attendanceMutation.isPending}
                                    onClick={() =>
                                      attendanceMutation.mutate({
                                        bookingId: booking.id,
                                        status: 'attended',
                                      })
                                    }
                                  >
                                    Attended
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    loading={attendanceMutation.isPending}
                                    onClick={() =>
                                      attendanceMutation.mutate({
                                        bookingId: booking.id,
                                        status: 'no_show',
                                      })
                                    }
                                  >
                                    No-show
                                  </Button>
                                </>
                              ) : null}
                              {canBook && booking.status === 'booked' ? (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  loading={cancelBookingMutation.isPending}
                                  onClick={() => void onCancelBooking(booking)}
                                >
                                  Cancel
                                </Button>
                              ) : null}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="space-y-3 border-t border-white/12 pt-4">
                    <p className="text-sm font-semibold text-ink">
                      Waitlist ({waitingList.length})
                    </p>
                    {waitlistQuery.isPending ? (
                      <Spinner label="Loading waitlist…" />
                    ) : waitingList.length === 0 ? (
                      <p className="text-sm text-muted">Waitlist is empty.</p>
                    ) : (
                      <div className="max-h-40 space-y-2 overflow-y-auto">
                        {waitingList.map((entry) => (
                          <div
                            key={entry.id}
                            className="flex items-center justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2"
                          >
                            <div className="min-w-0">
                              <p className="truncate text-sm font-semibold text-ink">
                                #{entry.position} · {memberLabel(entry.member)}
                              </p>
                            </div>
                            {canBook && selected.status === 'scheduled' ? (
                              <Button
                                size="sm"
                                variant="secondary"
                                loading={promoteMutation.isPending}
                                onClick={() => void onPromote(entry)}
                              >
                                Promote
                              </Button>
                            ) : null}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </Card>
              </aside>
            ) : null}
          </div>
        </>
      ) : (
        <>
          {(showCreateType || editingType) && canManage ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>{editingType ? 'Edit class type' : 'Create class type'}</CardTitle>
                  <CardDescription>
                    Catalog entry used when scheduling sessions.
                  </CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setShowCreateType(false)
                    setEditingType(null)
                  }}
                  aria-label="Close"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form onSubmit={onSaveType} noValidate className="grid gap-3 sm:grid-cols-2">
                <Field label="Code" htmlFor="type-code" required error={fieldErrors.typeCode}>
                  <Input
                    id="type-code"
                    value={typeForm.code}
                    onChange={(e) => {
                      setTypeForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))
                      clearFieldError('typeCode')
                    }}
                    className="font-mono"
                    aria-invalid={Boolean(fieldErrors.typeCode)}
                  />
                </Field>
                <Field label="Name" htmlFor="type-name" required error={fieldErrors.typeName}>
                  <Input
                    id="type-name"
                    value={typeForm.name}
                    onChange={(e) => {
                      setTypeForm((f) => ({ ...f, name: e.target.value }))
                      clearFieldError('typeName')
                    }}
                    aria-invalid={Boolean(fieldErrors.typeName)}
                  />
                </Field>
                <div>
                  <Label htmlFor="type-category">Category</Label>
                  <Input
                    id="type-category"
                    value={typeForm.category}
                    onChange={(e) => setTypeForm((f) => ({ ...f, category: e.target.value }))}
                    placeholder="yoga, hiit…"
                  />
                </div>
                <div>
                  <Label htmlFor="type-duration">Default duration (min)</Label>
                  <Input
                    id="type-duration"
                    type="number"
                    min="5"
                    max="480"
                    value={typeForm.default_duration_minutes}
                    onChange={(e) =>
                      setTypeForm((f) => ({
                        ...f,
                        default_duration_minutes: e.target.value,
                      }))
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="type-capacity">Default capacity</Label>
                  <Input
                    id="type-capacity"
                    type="number"
                    min="1"
                    value={typeForm.default_capacity}
                    onChange={(e) =>
                      setTypeForm((f) => ({ ...f, default_capacity: e.target.value }))
                    }
                  />
                </div>
                <div className="space-y-2 rounded-xl border border-white/10 bg-white/[0.03] p-3 sm:col-span-2">
                  <label className="flex items-center justify-between gap-3 text-sm text-ink">
                    <span>Waitlist enabled</span>
                    <input
                      type="checkbox"
                      checked={typeForm.waitlist_enabled}
                      onChange={(e) =>
                        setTypeForm((f) => ({ ...f, waitlist_enabled: e.target.checked }))
                      }
                    />
                  </label>
                  <label className="flex items-center justify-between gap-3 text-sm text-ink">
                    <span>Active</span>
                    <input
                      type="checkbox"
                      checked={typeForm.is_active}
                      onChange={(e) =>
                        setTypeForm((f) => ({ ...f, is_active: e.target.checked }))
                      }
                    />
                  </label>
                </div>
                <div className="flex flex-wrap gap-2 sm:col-span-2">
                  <Button
                    type="submit"
                    loading={createTypeMutation.isPending || updateTypeMutation.isPending}
                  >
                    {editingType ? 'Save changes' : 'Create type'}
                  </Button>
                  {editingType ? (
                    <Button
                      type="button"
                      variant="ghost"
                      className="text-danger"
                      loading={deleteTypeMutation.isPending}
                      onClick={() => void onDeleteType(editingType)}
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete
                    </Button>
                  ) : null}
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => {
                      setShowCreateType(false)
                      setEditingType(null)
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          <Card>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap gap-2">
                {(
                  [
                    { value: '' as const, label: 'All' },
                    { value: 'active' as const, label: 'Active' },
                    { value: 'inactive' as const, label: 'Inactive' },
                  ] as const
                ).map((filter) => {
                  const active = typeActiveFilter === filter.value
                  return (
                    <button
                      key={filter.label}
                      type="button"
                      onClick={() => {
                        setTypeActiveFilter(filter.value)
                        setTypesPage(1)
                      }}
                      className={cn(
                        'rounded-xl px-3 py-2 text-sm font-semibold transition',
                        active
                          ? 'bg-accent text-accent-ink'
                          : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                      )}
                    >
                      {filter.label}
                    </button>
                  )
                })}
              </div>
              <div className="flex gap-2">
                <div className="relative min-w-[12rem] flex-1">
                  <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
                  <Input
                    value={typeSearch}
                    onChange={(e) => setTypeSearch(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        setAppliedTypeSearch(typeSearch.trim())
                        setTypesPage(1)
                      }
                    }}
                    placeholder="Search types…"
                    className="pl-10"
                  />
                </div>
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    setAppliedTypeSearch(typeSearch.trim())
                    setTypesPage(1)
                  }}
                >
                  Search
                </Button>
              </div>
            </div>
          </Card>

          {typesQuery.isPending ? (
            <div className="flex justify-center py-20">
              <Spinner label="Loading class types…" />
            </div>
          ) : typesQuery.isError ? (
            <Alert tone="danger">
              {typesQuery.error instanceof ApiError
                ? typesQuery.error.message
                : 'Unable to load class types.'}
            </Alert>
          ) : (
            <>
              <DataTable
                columns={typeColumns}
                rows={typesQuery.data?.data ?? []}
                rowKey={(row) => row.id}
                emptyTitle="No class types"
                emptyDescription="Create a class type before scheduling sessions."
              />
              <Pagination meta={typesQuery.data?.meta} onPageChange={setTypesPage} />
            </>
          )}
        </>
      )}
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="shrink-0 text-muted">{label}</dt>
      <dd className="text-right font-semibold text-ink">{value}</dd>
    </div>
  )
}
