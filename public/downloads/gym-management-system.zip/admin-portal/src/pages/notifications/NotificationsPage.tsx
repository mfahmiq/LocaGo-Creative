import { useEffect, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Bell,
  BellRing,
  Mail,
  Plus,
  Send,
  Trash2,
  X,
} from 'lucide-react'
import {
  createNotificationTemplate,
  deleteNotificationTemplate,
  eventLabel,
  fetchInboxNotification,
  fetchInboxNotifications,
  fetchNotificationDeliveries,
  fetchNotificationTemplate,
  fetchNotificationTemplates,
  fetchUnreadNotificationCount,
  markNotificationRead,
  NOTIFICATION_EVENTS,
  sendNotification,
  updateNotificationTemplate,
  type DeliveryStatus,
  type InAppNotification,
  type NotificationChannel,
  type NotificationDelivery,
  type NotificationTemplate,
} from '@/api/notifications'
import { fetchMembers } from '@/api/members'
import { fetchStaff } from '@/api/staff'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'

type PageTab = 'inbox' | 'send' | 'templates' | 'deliveries'

function channelLabel(channel: string) {
  switch (channel) {
    case 'in_app':
      return 'In-app'
    case 'email':
      return 'Email'
    case 'whatsapp':
      return 'WhatsApp'
    case 'push':
      return 'Push'
    default:
      return channel
  }
}

function deliveryTone(
  status: DeliveryStatus,
): 'success' | 'warning' | 'danger' | 'neutral' {
  switch (status) {
    case 'sent':
      return 'success'
    case 'queued':
      return 'warning'
    case 'failed':
      return 'danger'
    default:
      return 'neutral'
  }
}

function memberLabel(m: {
  first_name?: string
  last_name?: string
  member_code?: string
  full_name?: string
}) {
  if (m.full_name) {
    return m.member_code ? `${m.full_name} (${m.member_code})` : m.full_name
  }
  const name = `${m.first_name ?? ''} ${m.last_name ?? ''}`.trim()
  return name ? `${name}${m.member_code ? ` (${m.member_code})` : ''}` : m.member_code || '—'
}

export function NotificationsPage() {
  const { hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('notifications.view')
  const canManage = hasPermission('notifications.manage')
  const canSend = hasPermission('notifications.send')
  const canViewMembers = hasPermission('members.view')
  const canViewStaff = hasPermission('identity.staff.view')
  const canAccess = canView || canManage || canSend

  const [tab, setTab] = useState<PageTab>('inbox')
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }

  useEffect(() => {
    const allowed: PageTab[] = []
    if (canView) {
      allowed.push('inbox', 'deliveries')
    }
    if (canSend) allowed.push('send')
    if (canManage) allowed.push('templates')
    if (allowed.length > 0 && !allowed.includes(tab)) setTab(allowed[0])
  }, [canView, canManage, canSend, tab])

  // Inbox
  const [inboxPage, setInboxPage] = useState(1)
  const [inboxUnread, setInboxUnread] = useState<'' | '1' | '0'>('')
  const [selectedInboxId, setSelectedInboxId] = useState<number | null>(null)

  // Send
  const [sendEventKey, setSendEventKey] = useState('member.registered')
  const [sendCustomEvent, setSendCustomEvent] = useState(false)
  const [sendTitle, setSendTitle] = useState('')
  const [sendBody, setSendBody] = useState('')
  const [sendChannels, setSendChannels] = useState<Array<'in_app' | 'email' | 'whatsapp'>>([
    'in_app',
  ])
  const [selectedStaffIds, setSelectedStaffIds] = useState<number[]>([])
  const [selectedMemberIds, setSelectedMemberIds] = useState<number[]>([])
  const [staffSearch, setStaffSearch] = useState('')
  const [memberSearch, setMemberSearch] = useState('')
  const [lastSendSummary, setLastSendSummary] = useState<string | null>(null)

  // Templates
  const [tplPage, setTplPage] = useState(1)
  const [tplEvent, setTplEvent] = useState('')
  const [tplChannel, setTplChannel] = useState<'' | NotificationChannel>('')
  const [tplActive, setTplActive] = useState<'' | '1' | '0'>('')
  const [selectedTplId, setSelectedTplId] = useState<number | null>(null)
  const [showTplForm, setShowTplForm] = useState(false)
  const [editingTpl, setEditingTpl] = useState<NotificationTemplate | null>(null)
  const [tplForm, setTplForm] = useState({
    event_key: 'member.registered',
    channel: 'in_app' as NotificationChannel,
    subject: '',
    body: '',
    is_active: true,
  })

  // Deliveries
  const [delPage, setDelPage] = useState(1)
  const [delStatus, setDelStatus] = useState<'' | DeliveryStatus>('')
  const [delChannel, setDelChannel] = useState<'' | NotificationChannel>('')
  const [delEvent, setDelEvent] = useState('')

  const errMsg = (err: unknown, fallback: string) => {
    if (err instanceof ApiError) return err.message
    if (err instanceof Error && err.message) return err.message
    return fallback
  }

  const invalidate = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['admin', 'notifications'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'notification-templates'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'notification-deliveries'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'notification-stats'] }),
    ])
  }

  const unreadQuery = useQuery({
    queryKey: ['admin', 'notifications', 'unread-count'],
    queryFn: fetchUnreadNotificationCount,
    enabled: canView,
  })

  const statsQuery = useQuery({
    queryKey: ['admin', 'notification-stats'],
    queryFn: async () => {
      const [queued, sent, failed, templates] = await Promise.all([
        canView
          ? fetchNotificationDeliveries({ page: 1, per_page: 1, status: 'queued' })
          : Promise.resolve(null),
        canView
          ? fetchNotificationDeliveries({ page: 1, per_page: 1, status: 'sent' })
          : Promise.resolve(null),
        canView
          ? fetchNotificationDeliveries({ page: 1, per_page: 1, status: 'failed' })
          : Promise.resolve(null),
        canManage
          ? fetchNotificationTemplates({ page: 1, per_page: 1, is_active: true })
          : Promise.resolve(null),
      ])
      return {
        queued: queued?.meta.total ?? 0,
        sent: sent?.meta.total ?? 0,
        failed: failed?.meta.total ?? 0,
        templates: templates?.meta.total ?? 0,
      }
    },
    enabled: canAccess,
  })

  const inboxQuery = useQuery({
    queryKey: ['admin', 'notifications', 'inbox', inboxPage, inboxUnread],
    queryFn: () =>
      fetchInboxNotifications({
        page: inboxPage,
        per_page: DEFAULT_PAGE_SIZE,
        unread: inboxUnread === '' ? '' : inboxUnread === '1',
      }),
    enabled: canView && tab === 'inbox',
  })

  const inboxDetailQuery = useQuery({
    queryKey: ['admin', 'notifications', selectedInboxId],
    queryFn: () => fetchInboxNotification(selectedInboxId!),
    enabled: canView && selectedInboxId != null && tab === 'inbox',
  })

  const templatesQuery = useQuery({
    queryKey: ['admin', 'notification-templates', tplPage, tplEvent, tplChannel, tplActive],
    queryFn: () =>
      fetchNotificationTemplates({
        page: tplPage,
        per_page: DEFAULT_PAGE_SIZE,
        event_key: tplEvent || undefined,
        channel: tplChannel,
        is_active: tplActive === '' ? '' : tplActive === '1',
      }),
    enabled: canManage && tab === 'templates',
  })

  const templateDetailQuery = useQuery({
    queryKey: ['admin', 'notification-templates', selectedTplId],
    queryFn: () => fetchNotificationTemplate(selectedTplId!),
    enabled: canManage && selectedTplId != null && tab === 'templates',
  })

  const deliveriesQuery = useQuery({
    queryKey: [
      'admin',
      'notification-deliveries',
      delPage,
      delStatus,
      delChannel,
      delEvent,
    ],
    queryFn: () =>
      fetchNotificationDeliveries({
        page: delPage,
        per_page: DEFAULT_PAGE_SIZE,
        status: delStatus,
        channel: delChannel,
        event_key: delEvent || undefined,
      }),
    enabled: canView && tab === 'deliveries',
  })

  const staffQuery = useQuery({
    queryKey: ['admin', 'staff', 'notify-picker', staffSearch],
    queryFn: () =>
      fetchStaff({
        page: 1,
        per_page: 30,
        search: staffSearch || undefined,
        is_active: true,
      }),
    enabled: canSend && canViewStaff && tab === 'send',
  })

  const membersQuery = useQuery({
    queryKey: ['admin', 'members', 'notify-picker', memberSearch],
    queryFn: () =>
      fetchMembers({
        page: 1,
        per_page: 30,
        search: memberSearch || undefined,
        status: 'active',
      }),
    enabled: canSend && canViewMembers && tab === 'send',
  })

  const openCreateTemplate = () => {
    setEditingTpl(null)
    setTplForm({
      event_key: 'member.registered',
      channel: 'in_app',
      subject: '',
      body: 'Hello {{member_first_name}}, …',
      is_active: true,
    })
    setShowTplForm(true)
    setSelectedTplId(null)
    setError(null)
  }

  const openEditTemplate = (tpl: NotificationTemplate) => {
    setEditingTpl(tpl)
    setTplForm({
      event_key: tpl.event_key,
      channel: tpl.channel,
      subject: tpl.subject ?? '',
      body: tpl.body,
      is_active: tpl.is_active,
    })
    setShowTplForm(true)
    setError(null)
  }

  const saveTplMutation = useMutation({
    mutationFn: async () => {
      if (!tplForm.event_key.trim()) throw new Error('Event key is required.')
      if (!tplForm.body.trim()) throw new Error('Body is required.')
      const payload = {
        event_key: tplForm.event_key.trim(),
        channel: tplForm.channel,
        subject: tplForm.subject.trim() || null,
        body: tplForm.body,
        is_active: tplForm.is_active,
      }
      if (editingTpl) return updateNotificationTemplate(editingTpl.id, payload)
      return createNotificationTemplate(payload)
    },
    onSuccess: async (row) => {
      showSuccess(editingTpl ? 'Template updated.' : 'Template created.')
      setShowTplForm(false)
      setEditingTpl(null)
      setSelectedTplId(row.id)
      setError(null)
      await invalidate()
    },
    onError: (err) => setError(errMsg(err, 'Could not save template.')),
  })

  const deleteTplMutation = useMutation({
    mutationFn: (id: number) => deleteNotificationTemplate(id),
    onSuccess: async () => {
      showSuccess('Template deleted.')
      setSelectedTplId(null)
      await invalidate()
    },
    onError: (err) => setError(errMsg(err, 'Could not delete template.')),
  })

  const markReadMutation = useMutation({
    mutationFn: (id: number) => markNotificationRead(id),
    onSuccess: async (row) => {
      showSuccess('Marked as read.')
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'notifications', row.id] })
      await queryClient.invalidateQueries({
        queryKey: ['admin', 'notifications', 'unread-count'],
      })
    },
    onError: (err) => setError(errMsg(err, 'Could not mark as read.')),
  })

  const sendMutation = useMutation({
    mutationFn: async () => {
      const eventKey = sendCustomEvent ? sendEventKey.trim() : sendEventKey
      if (!eventKey) throw new Error('Event key is required.')
      if (!sendTitle.trim() || !sendBody.trim()) {
        throw new Error('Title and body are required.')
      }
      if (selectedStaffIds.length === 0 && selectedMemberIds.length === 0) {
        throw new Error('Select at least one staff user or member.')
      }
      if (sendChannels.length === 0) throw new Error('Select at least one channel.')
      return sendNotification({
        event_key: eventKey,
        title: sendTitle.trim(),
        body: sendBody.trim(),
        user_ids: selectedStaffIds,
        member_ids: selectedMemberIds,
        channels: sendChannels,
      })
    },
    onSuccess: async (result) => {
      const summary = `Sent ${result.notifications.length} in-app · ${result.deliveries.length} delivery log(s).`
      showSuccess(summary)
      setLastSendSummary(summary)
      setSendTitle('')
      setSendBody('')
      setSelectedStaffIds([])
      setSelectedMemberIds([])
      setError(null)
      await invalidate()
      await queryClient.invalidateQueries({
        queryKey: ['admin', 'notifications', 'unread-count'],
      })
    },
    onError: (err) => setError(errMsg(err, 'Could not send notification.')),
  })

  const onDeleteTemplate = async (tpl: NotificationTemplate) => {
    if (tpl.is_system_default) {
      setError('System default templates are read-only.')
      return
    }
    const ok = await confirm({
      title: 'Delete template?',
      message: `Delete template for ${tpl.event_key} (${channelLabel(tpl.channel)})?`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (ok) deleteTplMutation.mutate(tpl.id)
  }

  const toggleChannel = (channel: 'in_app' | 'email' | 'whatsapp') => {
    setSendChannels((prev) =>
      prev.includes(channel) ? prev.filter((c) => c !== channel) : [...prev, channel],
    )
  }

  const toggleId = (
    list: number[],
    setList: (ids: number[]) => void,
    id: number,
  ) => {
    setList(list.includes(id) ? list.filter((x) => x !== id) : [...list, id])
  }

  const inboxColumns: Column<InAppNotification>[] = [
    {
      key: 'title',
      header: 'Notification',
      cell: (row) => (
        <div>
          <p className={cn('font-medium', row.is_read ? 'text-ink' : 'text-accent')}>
            {row.title}
          </p>
          <p className="line-clamp-1 text-xs text-muted">{row.body}</p>
        </div>
      ),
    },
    {
      key: 'event',
      header: 'Event',
      cell: (row) => (
        <span className="text-xs text-muted">{eventLabel(row.event_key)}</span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.is_read ? 'neutral' : 'accent'}>
          {row.is_read ? 'Read' : 'Unread'}
        </Badge>
      ),
    },
    {
      key: 'when',
      header: 'Received',
      cell: (row) => <span className="text-sm text-muted">{formatDate(row.created_at)}</span>,
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedInboxId(row.id)}>
          Open
        </Button>
      ),
    },
  ]

  const templateColumns: Column<NotificationTemplate>[] = [
    {
      key: 'event',
      header: 'Event',
      cell: (row) => (
        <div>
          <p className="font-medium text-ink">{eventLabel(row.event_key)}</p>
          <p className="font-mono text-xs text-muted">{row.event_key}</p>
        </div>
      ),
    },
    {
      key: 'channel',
      header: 'Channel',
      cell: (row) => <Badge tone="neutral">{channelLabel(row.channel)}</Badge>,
    },
    {
      key: 'subject',
      header: 'Subject',
      cell: (row) => (
        <span className="line-clamp-1 text-sm text-ink">{row.subject || '—'}</span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <div className="flex flex-wrap gap-1">
          <Badge tone={row.is_active ? 'success' : 'neutral'}>
            {row.is_active ? 'Active' : 'Inactive'}
          </Badge>
          {row.is_system_default ? <Badge tone="accent">System</Badge> : null}
        </div>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedTplId(row.id)}>
          Open
        </Button>
      ),
    },
  ]

  const deliveryColumns: Column<NotificationDelivery>[] = [
    {
      key: 'event',
      header: 'Delivery',
      cell: (row) => (
        <div>
          <p className="font-medium text-ink">{eventLabel(row.event_key)}</p>
          <p className="text-xs text-muted">{row.recipient || '—'}</p>
        </div>
      ),
    },
    {
      key: 'channel',
      header: 'Channel',
      cell: (row) => <span className="text-sm text-ink">{channelLabel(row.channel)}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => <Badge tone={deliveryTone(row.status)}>{row.status}</Badge>,
    },
    {
      key: 'sent',
      header: 'Sent',
      cell: (row) => (
        <span className="text-sm text-muted">{formatDate(row.sent_at || row.created_at)}</span>
      ),
    },
    {
      key: 'error',
      header: 'Notes',
      cell: (row) => (
        <span className="line-clamp-1 text-xs text-muted">
          {row.error_message || row.provider_message_id || '—'}
        </span>
      ),
    },
  ]

  if (!canAccess) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader title="Notifications" description="Templates, send, deliveries." />
        <Alert tone="danger">You do not have permission to view notifications.</Alert>
      </div>
    )
  }

  const stats = statsQuery.data
  const selectedInbox = inboxDetailQuery.data
  const selectedTpl = templateDetailQuery.data
  const staff = staffQuery.data?.data ?? []
  const members = membersQuery.data?.data ?? []

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Notifications"
        description="Templates, send, and delivery logs — keep staff and members informed."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            {canView ? (
              <Badge tone={(unreadQuery.data ?? 0) > 0 ? 'accent' : 'neutral'}>
                {formatNumber(unreadQuery.data ?? 0)} unread
              </Badge>
            ) : null}
            {canManage && tab === 'templates' ? (
              <Button size="sm" onClick={openCreateTemplate}>
                <Plus className="h-4 w-4" />
                New template
              </Button>
            ) : null}
            {canSend && tab !== 'send' ? (
              <Button size="sm" variant="secondary" onClick={() => setTab('send')}>
                <Send className="h-4 w-4" />
                Compose
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<BellRing className="h-4 w-4" />}
          label="Unread inbox"
          value={formatNumber(unreadQuery.data ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<Mail className="h-4 w-4" />}
          label="Deliveries sent"
          value={formatNumber(stats?.sent ?? 0)}
        />
        <SummaryChip
          icon={<Bell className="h-4 w-4" />}
          label="Queued"
          value={formatNumber(stats?.queued ?? 0)}
        />
        <SummaryChip
          icon={<Send className="h-4 w-4" />}
          label="Failed"
          value={formatNumber(stats?.failed ?? 0)}
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {canView ? (
          <TabButton
            active={tab === 'inbox'}
            onClick={() => {
              setTab('inbox')
              setError(null)
            }}
          >
            Inbox
          </TabButton>
        ) : null}
        {canSend ? (
          <TabButton
            active={tab === 'send'}
            onClick={() => {
              setTab('send')
              setError(null)
            }}
          >
            Send
          </TabButton>
        ) : null}
        {canManage ? (
          <TabButton
            active={tab === 'templates'}
            onClick={() => {
              setTab('templates')
              setError(null)
            }}
          >
            Templates
          </TabButton>
        ) : null}
        {canView ? (
          <TabButton
            active={tab === 'deliveries'}
            onClick={() => {
              setTab('deliveries')
              setError(null)
            }}
          >
            Deliveries
          </TabButton>
        ) : null}
      </div>

      {tab === 'inbox' && canView ? (
        <>
          <Card>
            <div className="mb-4 flex flex-wrap items-end gap-3">
              <div>
                <Label>Filter</Label>
                <Select
                  value={inboxUnread}
                  onChange={(e) => {
                    setInboxUnread(e.target.value as '' | '1' | '0')
                    setInboxPage(1)
                  }}
                >
                  <option value="">All</option>
                  <option value="1">Unread</option>
                  <option value="0">Read</option>
                </Select>
              </div>
            </div>
            {inboxQuery.isLoading ? (
              <div className="flex justify-center py-12">
                <Spinner />
              </div>
            ) : inboxQuery.isError ? (
              <Alert tone="danger">
                {inboxQuery.error instanceof ApiError
                  ? inboxQuery.error.message
                  : 'Failed to load inbox.'}
              </Alert>
            ) : (
              <>
                <DataTable
                  columns={inboxColumns}
                  rows={inboxQuery.data?.data ?? []}
                  rowKey={(r) => r.id}
                  emptyTitle="Inbox empty"
                  emptyDescription="Notifications sent to you will appear here."
                />
                <Pagination
                  meta={inboxQuery.data?.meta}
                  onPageChange={(p) => {
                    setInboxPage(p)
                    setSelectedInboxId(null)
                  }}
                />
              </>
            )}
          </Card>

          {selectedInboxId != null ? (
            <Card className="border-accent/20">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Notification</CardTitle>
                  <CardDescription>#{selectedInboxId}</CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setSelectedInboxId(null)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              {inboxDetailQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Spinner />
                </div>
              ) : selectedInbox ? (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone={selectedInbox.is_read ? 'neutral' : 'accent'}>
                      {selectedInbox.is_read ? 'Read' : 'Unread'}
                    </Badge>
                    <span className="text-sm text-muted">
                      {eventLabel(selectedInbox.event_key)} · {formatDate(selectedInbox.created_at)}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-ink">{selectedInbox.title}</h3>
                    <p className="mt-2 whitespace-pre-wrap text-sm text-muted">
                      {selectedInbox.body}
                    </p>
                  </div>
                  {!selectedInbox.is_read ? (
                    <Button
                      size="sm"
                      disabled={markReadMutation.isPending}
                      onClick={() => markReadMutation.mutate(selectedInbox.id)}
                    >
                      Mark as read
                    </Button>
                  ) : null}
                </div>
              ) : (
                <Alert tone="danger">Notification not found.</Alert>
              )}
            </Card>
          ) : null}
        </>
      ) : null}

      {tab === 'send' && canSend ? (
        <Card className="border-accent/25">
          <div className="mb-4">
            <CardTitle>Send notification</CardTitle>
            <CardDescription>
              Deliver to staff users and/or members via in-app, email, and WhatsApp.
            </CardDescription>
          </div>
          {lastSendSummary ? <Alert tone="success">{lastSendSummary}</Alert> : null}
          <form
            onSubmit={(e: FormEvent) => {
              e.preventDefault()
              const eventKey = sendCustomEvent ? sendEventKey.trim() : sendEventKey
              const errors = collectRequiredErrors([
                { key: 'event_key', label: 'Event key', value: eventKey },
                { key: 'title', label: 'Title', value: sendTitle },
                { key: 'body', label: 'Body', value: sendBody },
              ])
              if (Object.keys(errors).length > 0) {
                setFieldErrors(errors)
                return
              }
              if (selectedStaffIds.length === 0 && selectedMemberIds.length === 0) {
                setError('Select at least one staff user or member.')
                return
              }
              if (sendChannels.length === 0) {
                setError('Select at least one channel.')
                return
              }
              setFieldErrors({})
              sendMutation.mutate()
            }}
            noValidate
            className="mt-4 space-y-4"
          >
            <div className="grid gap-3 sm:grid-cols-2">
              <div>
                <Label>Event</Label>
                {!sendCustomEvent ? (
                  <Select
                    value={sendEventKey}
                    onChange={(e) => {
                      setSendEventKey(e.target.value)
                      clearFieldError('event_key')
                    }}
                  >
                    {NOTIFICATION_EVENTS.map((ev) => (
                      <option key={ev.key} value={ev.key}>
                        {ev.label}
                      </option>
                    ))}
                  </Select>
                ) : (
                  <Field label="Event key" required error={fieldErrors.event_key}>
                    <Input
                      value={sendEventKey}
                      onChange={(e) => {
                        setSendEventKey(e.target.value)
                        clearFieldError('event_key')
                      }}
                      placeholder="manual.staff_alert"
                      className="font-mono"
                      aria-invalid={Boolean(fieldErrors.event_key)}
                    />
                  </Field>
                )}
                <label className="mt-2 flex items-center gap-2 text-xs text-muted">
                  <input
                    type="checkbox"
                    checked={sendCustomEvent}
                    onChange={(e) => {
                      setSendCustomEvent(e.target.checked)
                      if (!e.target.checked) setSendEventKey('member.registered')
                    }}
                    className="h-3.5 w-3.5 rounded border-white/20"
                  />
                  Use custom event key
                </label>
              </div>
              <div>
                <Label>Channels</Label>
                <div className="mt-2 flex flex-wrap gap-3">
                  {(['in_app', 'email', 'whatsapp'] as const).map((ch) => (
                    <label key={ch} className="flex items-center gap-2 text-sm text-ink">
                      <input
                        type="checkbox"
                        checked={sendChannels.includes(ch)}
                        onChange={() => toggleChannel(ch)}
                        className="h-4 w-4 rounded border-white/20"
                      />
                      {channelLabel(ch)}
                    </label>
                  ))}
                </div>
              </div>
              <Field label="Title" required error={fieldErrors.title} className="sm:col-span-2">
                <Input
                  value={sendTitle}
                  onChange={(e) => {
                    setSendTitle(e.target.value)
                    clearFieldError('title')
                  }}
                  placeholder="Notification title"
                  aria-invalid={Boolean(fieldErrors.title)}
                />
              </Field>
              <Field label="Body" required error={fieldErrors.body} className="sm:col-span-2">
                <Textarea
                  rows={4}
                  value={sendBody}
                  onChange={(e) => {
                    setSendBody(e.target.value)
                    clearFieldError('body')
                  }}
                  placeholder="Message content"
                  aria-invalid={Boolean(fieldErrors.body)}
                />
              </Field>
            </div>

            <div className="grid gap-4 lg:grid-cols-2">
              <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                <div className="mb-2 flex items-center justify-between gap-2">
                  <Label>Staff recipients</Label>
                  <span className="text-xs text-muted">{selectedStaffIds.length} selected</span>
                </div>
                {canViewStaff ? (
                  <>
                    <Input
                      className="mb-2"
                      placeholder="Search staff…"
                      value={staffSearch}
                      onChange={(e) => setStaffSearch(e.target.value)}
                    />
                    <div className="max-h-48 space-y-1 overflow-y-auto">
                      {staff.map((s) => (
                        <label
                          key={s.id}
                          className="flex cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-sm hover:bg-white/5"
                        >
                          <input
                            type="checkbox"
                            checked={selectedStaffIds.includes(s.id)}
                            onChange={() =>
                              toggleId(selectedStaffIds, setSelectedStaffIds, s.id)
                            }
                            className="h-4 w-4 rounded border-white/20"
                          />
                          <span className="text-ink">{s.name}</span>
                          <span className="text-xs text-muted">{s.email}</span>
                        </label>
                      ))}
                      {staff.length === 0 ? (
                        <p className="px-2 py-3 text-xs text-muted">No staff found.</p>
                      ) : null}
                    </div>
                  </>
                ) : (
                  <Alert tone="info">Staff list requires identity.staff.view.</Alert>
                )}
              </div>

              <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                <div className="mb-2 flex items-center justify-between gap-2">
                  <Label>Member recipients</Label>
                  <span className="text-xs text-muted">{selectedMemberIds.length} selected</span>
                </div>
                {canViewMembers ? (
                  <>
                    <Input
                      className="mb-2"
                      placeholder="Search members…"
                      value={memberSearch}
                      onChange={(e) => setMemberSearch(e.target.value)}
                    />
                    <div className="max-h-48 space-y-1 overflow-y-auto">
                      {members.map((m) => (
                        <label
                          key={m.id}
                          className="flex cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-sm hover:bg-white/5"
                        >
                          <input
                            type="checkbox"
                            checked={selectedMemberIds.includes(m.id)}
                            onChange={() =>
                              toggleId(selectedMemberIds, setSelectedMemberIds, m.id)
                            }
                            className="h-4 w-4 rounded border-white/20"
                          />
                          <span className="text-ink">{memberLabel(m)}</span>
                        </label>
                      ))}
                      {members.length === 0 ? (
                        <p className="px-2 py-3 text-xs text-muted">No members found.</p>
                      ) : null}
                    </div>
                  </>
                ) : (
                  <Alert tone="info">Member list requires members.view.</Alert>
                )}
              </div>
            </div>

            <div className="flex justify-end">
              <Button type="submit" disabled={sendMutation.isPending}>
                <Send className="h-4 w-4" />
                {sendMutation.isPending ? 'Sending…' : 'Send notification'}
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      {tab === 'templates' && canManage ? (
        <>
          {showTplForm ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>
                    {editingTpl ? 'Edit template' : 'Create template'}
                  </CardTitle>
                  <CardDescription>
                    Use placeholders like {'{{member_first_name}}'}, {'{{gym_name}}'},{' '}
                    {'{{plan_name}}'}.
                  </CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setShowTplForm(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  const errors = collectRequiredErrors([
                    { key: 'event_key', label: 'Event key', value: tplForm.event_key },
                    { key: 'body', label: 'Body', value: tplForm.body },
                  ])
                  if (Object.keys(errors).length > 0) {
                    setFieldErrors(errors)
                    return
                  }
                  setFieldErrors({})
                  saveTplMutation.mutate()
                }}
                noValidate
                className="grid gap-3 sm:grid-cols-2"
              >
                <div>
                  <Label>Event key</Label>
                  <Select
                    value={
                      NOTIFICATION_EVENTS.some((e) => e.key === tplForm.event_key)
                        ? tplForm.event_key
                        : '__custom__'
                    }
                    onChange={(e) => {
                      if (e.target.value === '__custom__') {
                        setTplForm((f) => ({ ...f, event_key: 'custom.event' }))
                      } else {
                        setTplForm((f) => ({ ...f, event_key: e.target.value }))
                      }
                      clearFieldError('event_key')
                    }}
                  >
                    {NOTIFICATION_EVENTS.map((ev) => (
                      <option key={ev.key} value={ev.key}>
                        {ev.label}
                      </option>
                    ))}
                    <option value="__custom__">Custom…</option>
                  </Select>
                  {!NOTIFICATION_EVENTS.some((e) => e.key === tplForm.event_key) ? (
                    <Input
                      className="mt-2 font-mono"
                      value={tplForm.event_key}
                      onChange={(e) => {
                        setTplForm((f) => ({ ...f, event_key: e.target.value }))
                        clearFieldError('event_key')
                      }}
                      aria-invalid={Boolean(fieldErrors.event_key)}
                    />
                  ) : null}
                  {fieldErrors.event_key ? (
                    <p className="mt-1 text-xs font-medium text-danger" role="alert">
                      {fieldErrors.event_key}
                    </p>
                  ) : null}
                </div>
                <div>
                  <Label>Channel</Label>
                  <Select
                    value={tplForm.channel}
                    onChange={(e) =>
                      setTplForm((f) => ({
                        ...f,
                        channel: e.target.value as NotificationChannel,
                      }))
                    }
                  >
                    <option value="in_app">In-app</option>
                    <option value="email">Email</option>
                    <option value="whatsapp">WhatsApp</option>
                    <option value="push">Push</option>
                  </Select>
                </div>
                <div className="sm:col-span-2">
                  <Label>Subject</Label>
                  <Input
                    value={tplForm.subject}
                    onChange={(e) => setTplForm((f) => ({ ...f, subject: e.target.value }))}
                    placeholder="Optional subject (email)"
                  />
                </div>
                <Field label="Body" required error={fieldErrors.body} className="sm:col-span-2">
                  <Textarea
                    rows={5}
                    value={tplForm.body}
                    onChange={(e) => {
                      setTplForm((f) => ({ ...f, body: e.target.value }))
                      clearFieldError('body')
                    }}
                    aria-invalid={Boolean(fieldErrors.body)}
                  />
                </Field>
                <div className="flex items-end">
                  <label className="flex items-center gap-2 text-sm text-ink">
                    <input
                      type="checkbox"
                      checked={tplForm.is_active}
                      onChange={(e) =>
                        setTplForm((f) => ({ ...f, is_active: e.target.checked }))
                      }
                      className="h-4 w-4 rounded border-white/20"
                    />
                    Active
                  </label>
                </div>
                <div className="flex justify-end gap-2 sm:col-span-2">
                  <Button type="button" variant="secondary" onClick={() => setShowTplForm(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={saveTplMutation.isPending}>
                    {saveTplMutation.isPending
                      ? 'Saving…'
                      : editingTpl
                        ? 'Save changes'
                        : 'Create template'}
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          <Card>
            <div className="mb-4 flex flex-wrap items-end gap-3">
              <div>
                <Label>Event</Label>
                <Select
                  value={tplEvent}
                  onChange={(e) => {
                    setTplEvent(e.target.value)
                    setTplPage(1)
                  }}
                >
                  <option value="">All events</option>
                  {NOTIFICATION_EVENTS.map((ev) => (
                    <option key={ev.key} value={ev.key}>
                      {ev.label}
                    </option>
                  ))}
                </Select>
              </div>
              <div>
                <Label>Channel</Label>
                <Select
                  value={tplChannel}
                  onChange={(e) => {
                    setTplChannel(e.target.value as '' | NotificationChannel)
                    setTplPage(1)
                  }}
                >
                  <option value="">All</option>
                  <option value="in_app">In-app</option>
                  <option value="email">Email</option>
                  <option value="whatsapp">WhatsApp</option>
                  <option value="push">Push</option>
                </Select>
              </div>
              <div>
                <Label>Status</Label>
                <Select
                  value={tplActive}
                  onChange={(e) => {
                    setTplActive(e.target.value as '' | '1' | '0')
                    setTplPage(1)
                  }}
                >
                  <option value="">All</option>
                  <option value="1">Active</option>
                  <option value="0">Inactive</option>
                </Select>
              </div>
            </div>
            {templatesQuery.isLoading ? (
              <div className="flex justify-center py-12">
                <Spinner />
              </div>
            ) : templatesQuery.isError ? (
              <Alert tone="danger">
                {templatesQuery.error instanceof ApiError
                  ? templatesQuery.error.message
                  : 'Failed to load templates.'}
              </Alert>
            ) : (
              <>
                <DataTable
                  columns={templateColumns}
                  rows={templatesQuery.data?.data ?? []}
                  rowKey={(r) => r.id}
                  emptyTitle="No templates"
                  emptyDescription="Create a template or rely on system defaults."
                />
                <Pagination
                  meta={templatesQuery.data?.meta}
                  onPageChange={(p) => {
                    setTplPage(p)
                    setSelectedTplId(null)
                  }}
                />
              </>
            )}
          </Card>

          {selectedTplId != null ? (
            <Card className="border-accent/20">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Template detail</CardTitle>
                  <CardDescription>#{selectedTplId}</CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setSelectedTplId(null)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              {templateDetailQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Spinner />
                </div>
              ) : selectedTpl ? (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone={selectedTpl.is_active ? 'success' : 'neutral'}>
                      {selectedTpl.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                    <Badge tone="neutral">{channelLabel(selectedTpl.channel)}</Badge>
                    {selectedTpl.is_system_default ? (
                      <Badge tone="accent">System default</Badge>
                    ) : null}
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <DetailStat label="Event" value={eventLabel(selectedTpl.event_key)} />
                    <DetailStat label="Event key" value={selectedTpl.event_key} />
                    <DetailStat label="Subject" value={selectedTpl.subject || '—'} />
                  </div>
                  <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                    <p className="mb-1 text-xs text-muted">Body</p>
                    <p className="whitespace-pre-wrap text-sm text-ink">{selectedTpl.body}</p>
                  </div>
                  {!selectedTpl.is_system_default ? (
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => openEditTemplate(selectedTpl)}
                      >
                        Edit
                      </Button>
                      <Button
                        size="sm"
                        variant="danger"
                        disabled={deleteTplMutation.isPending}
                        onClick={() => onDeleteTemplate(selectedTpl)}
                      >
                        <Trash2 className="h-4 w-4" />
                        Delete
                      </Button>
                    </div>
                  ) : (
                    <Alert tone="info">System default templates are read-only.</Alert>
                  )}
                </div>
              ) : (
                <Alert tone="danger">Template not found.</Alert>
              )}
            </Card>
          ) : null}
        </>
      ) : null}

      {tab === 'deliveries' && canView ? (
        <Card>
          <div className="mb-4 flex flex-wrap items-end gap-3">
            <div>
              <Label>Status</Label>
              <Select
                value={delStatus}
                onChange={(e) => {
                  setDelStatus(e.target.value as '' | DeliveryStatus)
                  setDelPage(1)
                }}
              >
                <option value="">All</option>
                <option value="queued">Queued</option>
                <option value="sent">Sent</option>
                <option value="failed">Failed</option>
              </Select>
            </div>
            <div>
              <Label>Channel</Label>
              <Select
                value={delChannel}
                onChange={(e) => {
                  setDelChannel(e.target.value as '' | NotificationChannel)
                  setDelPage(1)
                }}
              >
                <option value="">All</option>
                <option value="in_app">In-app</option>
                <option value="email">Email</option>
                <option value="whatsapp">WhatsApp</option>
                <option value="push">Push</option>
              </Select>
            </div>
            <div>
              <Label>Event key</Label>
              <Input
                list="delivery-events"
                value={delEvent}
                onChange={(e) => {
                  setDelEvent(e.target.value)
                  setDelPage(1)
                }}
                placeholder="Filter by event"
                className="font-mono"
              />
              <datalist id="delivery-events">
                {NOTIFICATION_EVENTS.map((ev) => (
                  <option key={ev.key} value={ev.key} />
                ))}
              </datalist>
            </div>
          </div>
          {deliveriesQuery.isLoading ? (
            <div className="flex justify-center py-12">
              <Spinner />
            </div>
          ) : deliveriesQuery.isError ? (
            <Alert tone="danger">
              {deliveriesQuery.error instanceof ApiError
                ? deliveriesQuery.error.message
                : 'Failed to load deliveries.'}
            </Alert>
          ) : (
            <>
              <DataTable
                columns={deliveryColumns}
                rows={deliveriesQuery.data?.data ?? []}
                rowKey={(r) => r.id}
                emptyTitle="No deliveries"
                emptyDescription="Outbound delivery attempts will appear here."
              />
              <Pagination
                meta={deliveriesQuery.data?.meta}
                onPageChange={setDelPage}
              />
            </>
          )}
        </Card>
      ) : null}
    </div>
  )
}

function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean
  onClick: () => void
  children: ReactNode
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'rounded-xl px-3 py-2 text-sm font-semibold transition',
        active
          ? 'bg-accent text-accent-ink'
          : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
      )}
    >
      {children}
    </button>
  )
}

function DetailStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-0.5 text-sm font-semibold text-ink">{value}</p>
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}
