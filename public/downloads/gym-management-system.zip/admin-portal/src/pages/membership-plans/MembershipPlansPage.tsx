import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  CalendarDays,
  CheckCircle2,
  CreditCard,
  PauseCircle,
  PlayCircle,
  Plus,
  Search,
  Ticket,
  Trash2,
  X,
} from 'lucide-react'
import {
  createMembershipPlan,
  deleteMembershipPlan,
  fetchMembershipPlan,
  fetchMembershipPlans,
  updateMembershipPlan,
  type MembershipPlan,
  type PlanType,
} from '@/api/membershipPlans'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatMoney, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'

type ActiveFilter = '' | 'active' | 'inactive'

type PlanFormState = {
  code: string
  name: string
  description: string
  plan_type: PlanType
  duration_days: string
  visit_limit: string
  price: string
  currency_code: string
  allows_walkin: boolean
  allows_all_branches: boolean
  branch_ids: number[]
  freeze_allowed: boolean
  max_freeze_days: string
  is_active: boolean
}

function emptyForm(currency: string): PlanFormState {
  return {
    code: '',
    name: '',
    description: '',
    plan_type: 'time',
    duration_days: '30',
    visit_limit: '',
    price: '',
    currency_code: currency,
    allows_walkin: true,
    allows_all_branches: true,
    branch_ids: [],
    freeze_allowed: true,
    max_freeze_days: '10',
    is_active: true,
  }
}

function planFromModel(plan: MembershipPlan): PlanFormState {
  return {
    code: plan.code,
    name: plan.name,
    description: plan.description ?? '',
    plan_type: plan.plan_type,
    duration_days: plan.duration_days != null ? String(plan.duration_days) : '',
    visit_limit: plan.visit_limit != null ? String(plan.visit_limit) : '',
    price: String(plan.price ?? ''),
    currency_code: plan.currency_code || 'INR',
    allows_walkin: plan.allows_walkin,
    allows_all_branches: plan.allows_all_branches,
    branch_ids: (plan.branches ?? []).map((b) => b.id),
    freeze_allowed: plan.freeze_allowed,
    max_freeze_days: plan.max_freeze_days != null ? String(plan.max_freeze_days) : '',
    is_active: plan.is_active,
  }
}

function planTypeLabel(type: PlanType): string {
  switch (type) {
    case 'time':
      return 'Time-based'
    case 'visit':
      return 'Visit-based'
    case 'hybrid':
      return 'Hybrid'
    default:
      return type
  }
}

function planTypeTone(type: PlanType): 'accent' | 'neutral' | 'success' {
  switch (type) {
    case 'time':
      return 'accent'
    case 'visit':
      return 'neutral'
    case 'hybrid':
      return 'success'
    default:
      return 'neutral'
  }
}

function formatEntitlement(plan: MembershipPlan): string {
  const parts: string[] = []
  if (plan.duration_days) parts.push(`${plan.duration_days} days`)
  if (plan.visit_limit) parts.push(`${plan.visit_limit} visits`)
  return parts.length > 0 ? parts.join(' · ') : '—'
}

function toPayload(form: PlanFormState) {
  const needsDuration = form.plan_type === 'time' || form.plan_type === 'hybrid'
  const needsVisits = form.plan_type === 'visit' || form.plan_type === 'hybrid'

  return {
    code: form.code.trim().toUpperCase(),
    name: form.name.trim(),
    description: form.description.trim() || null,
    plan_type: form.plan_type,
    duration_days: needsDuration && form.duration_days ? Number(form.duration_days) : null,
    visit_limit: needsVisits && form.visit_limit ? Number(form.visit_limit) : null,
    price: Number(form.price),
    currency_code: form.currency_code.trim().toUpperCase() || 'INR',
    allows_walkin: form.allows_walkin,
    allows_all_branches: form.allows_all_branches,
    branch_ids: form.allows_all_branches ? [] : form.branch_ids,
    freeze_allowed: form.freeze_allowed,
    max_freeze_days:
      form.freeze_allowed && form.max_freeze_days ? Number(form.max_freeze_days) : null,
    is_active: form.is_active,
  }
}

function collectPlanFormErrors(form: PlanFormState): FieldErrors {
  const needsDuration = form.plan_type === 'time' || form.plan_type === 'hybrid'
  const needsVisits = form.plan_type === 'visit' || form.plan_type === 'hybrid'
  const errors = collectRequiredErrors([
    { key: 'code', label: 'Code', value: form.code },
    { key: 'name', label: 'Name', value: form.name },
    { key: 'price', label: 'Price', value: form.price },
    ...(needsDuration
      ? [{ key: 'duration_days', label: 'Duration (days)', value: form.duration_days }]
      : []),
    ...(needsVisits
      ? [{ key: 'visit_limit', label: 'Visit limit', value: form.visit_limit }]
      : []),
  ])
  if (form.price !== '' && (Number.isNaN(Number(form.price)) || Number(form.price) < 0)) {
    errors.price = 'Enter a valid price (0 or greater).'
  }
  if (!form.allows_all_branches && form.branch_ids.length === 0) {
    errors.branch_ids = 'Select at least one branch, or enable all branches.'
  }
  return errors
}

export function MembershipPlansPage() {
  const { tenant, branches, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('memberships.plans.view')
  const canManage = hasPermission('memberships.plans.manage')
  const defaultCurrency = tenant?.base_currency || 'INR'

  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [activeFilter, setActiveFilter] = useState<ActiveFilter>('')
  const [typeFilter, setTypeFilter] = useState<PlanType | ''>('')
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }
  const [createForm, setCreateForm] = useState(() => emptyForm(defaultCurrency))
  const [editForm, setEditForm] = useState<PlanFormState>(() => emptyForm(defaultCurrency))

  const plansQuery = useQuery({
    queryKey: ['admin', 'membership-plans', page, appliedSearch, activeFilter, typeFilter],
    queryFn: () =>
      fetchMembershipPlans({
        page,
        per_page: DEFAULT_PAGE_SIZE,
        search: appliedSearch,
        plan_type: typeFilter,
        is_active: activeFilter === '' ? '' : activeFilter === 'active',
      }),
    enabled: canView,
  })

  const statsQuery = useQuery({
    queryKey: ['admin', 'membership-plans', 'stats'],
    queryFn: async () => {
      const [all, active, inactive, time, visit, hybrid] = await Promise.all([
        fetchMembershipPlans({ page: 1, per_page: 1 }),
        fetchMembershipPlans({ page: 1, per_page: 1, is_active: true }),
        fetchMembershipPlans({ page: 1, per_page: 1, is_active: false }),
        fetchMembershipPlans({ page: 1, per_page: 1, plan_type: 'time' }),
        fetchMembershipPlans({ page: 1, per_page: 1, plan_type: 'visit' }),
        fetchMembershipPlans({ page: 1, per_page: 1, plan_type: 'hybrid' }),
      ])
      return {
        total: all.meta.total,
        active: active.meta.total,
        inactive: inactive.meta.total,
        time: time.meta.total,
        visit: visit.meta.total,
        hybrid: hybrid.meta.total,
      }
    },
    enabled: canView,
  })

  const selectedQuery = useQuery({
    queryKey: ['admin', 'membership-plans', 'detail', selectedId],
    queryFn: () => fetchMembershipPlan(selectedId!),
    enabled: canView && selectedId != null,
  })

  const rows = plansQuery.data?.data ?? []
  const meta = plansQuery.data?.meta
  const selected = useMemo(() => {
    if (selectedId == null) return null
    return selectedQuery.data ?? rows.find((row) => row.id === selectedId) ?? null
  }, [selectedId, selectedQuery.data, rows])

  useEffect(() => {
    if (!selected) return
    setEditForm(planFromModel(selected))
    // eslint-disable-next-line react-hooks/exhaustive-deps -- selected?.id
  }, [selected?.id])

  const invalidate = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'membership-plans'] })
  }

  const apiErrorMessage = (err: unknown, fallback: string) => {
    if (!(err instanceof ApiError)) return fallback
    if (err.code === 'membership_plan_in_use') {
      return 'This plan has active memberships. Deactivate it instead of deleting.'
    }
    if (err.code === 'membership_plan_code_exists') {
      return 'A plan with this code already exists.'
    }
    return err.message || fallback
  }

  const createMutation = useMutation({
    mutationFn: createMembershipPlan,
    onSuccess: async (plan) => {
      setError(null)
      showSuccess(`Plan “${plan.name}” created.`)
      setShowCreate(false)
      setCreateForm(emptyForm(defaultCurrency))
      setSearch('')
      setAppliedSearch('')
      setActiveFilter('')
      setTypeFilter('')
      setPage(1)
      await invalidate()
      setSelectedId(plan.id)
      setEditForm(planFromModel(plan))
    },
    onError: (err) => setError(apiErrorMessage(err, 'Unable to create plan.')),
  })

  const updateMutation = useMutation({
    mutationFn: (payload: ReturnType<typeof toPayload>) =>
      updateMembershipPlan(selectedId!, payload),
    onSuccess: async (plan) => {
      setError(null)
      showSuccess(`Plan “${plan.name}” updated.`)
      setEditForm(planFromModel(plan))
      await invalidate()
    },
    onError: (err) => setError(apiErrorMessage(err, 'Unable to update plan.')),
  })

  const toggleActiveMutation = useMutation({
    mutationFn: ({ planId, isActive }: { planId: number; isActive: boolean }) =>
      updateMembershipPlan(planId, { is_active: isActive }),
    onSuccess: async (plan) => {
      setError(null)
      showSuccess(plan.is_active ? `“${plan.name}” is now sellable.` : `“${plan.name}” deactivated.`)
      if (selectedId === plan.id) setEditForm(planFromModel(plan))
      await invalidate()
    },
    onError: (err) => setError(apiErrorMessage(err, 'Unable to update plan status.')),
  })

  const deleteMutation = useMutation({
    mutationFn: (planId: number) => deleteMembershipPlan(planId),
    onSuccess: async () => {
      setError(null)
      showSuccess('Plan deleted.')
      setSelectedId(null)
      await invalidate()
    },
    onError: (err) => setError(apiErrorMessage(err, 'Unable to delete plan.')),
  })

  const applySearch = () => {
    setPage(1)
    setSelectedId(null)
    setAppliedSearch(search.trim())
  }

  const onCreate = (event: FormEvent) => {
    event.preventDefault()
    const errors = collectPlanFormErrors(createForm)
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    createMutation.mutate(toPayload(createForm))
  }

  const onSave = (event: FormEvent) => {
    event.preventDefault()
    if (!selected) return
    const errors = collectPlanFormErrors(editForm)
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    updateMutation.mutate(toPayload(editForm))
  }

  const onToggleActive = async (plan: MembershipPlan) => {
    const next = !plan.is_active
    const ok = await confirm({
      title: next ? 'Activate plan?' : 'Deactivate plan?',
      message: next
        ? `Make “${plan.name}” available for new memberships?`
        : `Hide “${plan.name}” from new sales? Existing memberships stay valid.`,
      confirmLabel: next ? 'Activate' : 'Deactivate',
      tone: next ? 'primary' : 'danger',
    })
    if (!ok) return
    toggleActiveMutation.mutate({ planId: plan.id, isActive: next })
  }

  const onDelete = async (plan: MembershipPlan) => {
    const ok = await confirm({
      title: 'Delete plan?',
      message: `Permanently remove “${plan.name}” (${plan.code}) from the catalog? Plans with active memberships cannot be deleted.`,
      confirmLabel: 'Delete plan',
      tone: 'danger',
    })
    if (!ok) return
    deleteMutation.mutate(plan.id)
  }

  const editDirty =
    selected != null &&
    JSON.stringify(toPayload(editForm)) !== JSON.stringify(toPayload(planFromModel(selected)))

  const columns: Column<MembershipPlan>[] = [
    {
      key: 'plan',
      header: 'Plan',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">{row.name}</p>
          <p className="mt-0.5 font-mono text-xs text-muted">{row.code}</p>
        </button>
      ),
    },
    {
      key: 'type',
      header: 'Type',
      cell: (row) => <Badge tone={planTypeTone(row.plan_type)}>{planTypeLabel(row.plan_type)}</Badge>,
    },
    {
      key: 'entitlement',
      header: 'Access',
      cell: (row) => <span className="text-sm text-ink">{formatEntitlement(row)}</span>,
    },
    {
      key: 'price',
      header: 'Price',
      cell: (row) => (
        <span className="font-semibold text-ink">
          {formatMoney(row.price, row.currency_code || defaultCurrency)}
        </span>
      ),
    },
    {
      key: 'branches',
      header: 'Branches',
      cell: (row) =>
        row.allows_all_branches ? (
          <span className="text-sm text-muted">All branches</span>
        ) : (
          <span className="text-sm text-ink">
            {(row.branches ?? [])
              .slice(0, 2)
              .map((b) => b.name)
              .join(', ') || 'Restricted'}
            {(row.branches?.length ?? 0) > 2 ? ` +${(row.branches?.length ?? 0) - 2}` : ''}
          </span>
        ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.is_active ? 'success' : 'danger'}>
          {row.is_active ? 'Active' : 'Inactive'}
        </Badge>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <div className="flex flex-wrap justify-end gap-1.5">
          <Button size="sm" variant="secondary" onClick={() => setSelectedId(row.id)}>
            Manage
          </Button>
          {canManage ? (
            <Button
              size="sm"
              variant={row.is_active ? 'ghost' : 'secondary'}
              loading={toggleActiveMutation.isPending}
              onClick={() => void onToggleActive(row)}
            >
              {row.is_active ? (
                <>
                  <PauseCircle className="h-4 w-4" />
                  Deactivate
                </>
              ) : (
                <>
                  <PlayCircle className="h-4 w-4" />
                  Activate
                </>
              )}
            </Button>
          ) : null}
        </div>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader
          title="Membership plans"
          description="Plan catalog for the gym."
        />
        <Alert tone="danger">You do not have permission to view membership plans.</Alert>
      </div>
    )
  }

  const stats = statsQuery.data

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Membership plans"
        description="Plan catalog for the gym — pricing, duration, visits, and branch access."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">Gym</Badge>
            {canManage ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowCreate(true)
                  setError(null)
                  setCreateForm(emptyForm(defaultCurrency))
                }}
              >
                <Plus className="h-4 w-4" />
                New plan
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      {plansQuery.isError ? (
        <Alert tone="danger">
          {plansQuery.error instanceof ApiError
            ? plansQuery.error.message
            : 'Unable to load membership plans.'}
          <div className="mt-3">
            <Button size="sm" variant="secondary" onClick={() => void plansQuery.refetch()}>
              Try again
            </Button>
          </div>
        </Alert>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<CreditCard className="h-4 w-4" />}
          label="Total plans"
          value={formatNumber(stats?.total ?? meta?.total ?? 0)}
        />
        <SummaryChip
          icon={<CheckCircle2 className="h-4 w-4" />}
          label="Active"
          value={formatNumber(stats?.active ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<CalendarDays className="h-4 w-4" />}
          label="Time-based"
          value={formatNumber(stats?.time ?? 0)}
        />
        <SummaryChip
          icon={<Ticket className="h-4 w-4" />}
          label="Visit / hybrid"
          value={formatNumber((stats?.visit ?? 0) + (stats?.hybrid ?? 0))}
        />
      </div>

      {showCreate && canManage ? (
        <Card className="border-accent/25">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <CardTitle>Create membership plan</CardTitle>
              <CardDescription>
                Define pricing, access rules, and which branches can sell this plan.
              </CardDescription>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowCreate(false)}
              aria-label="Close create form"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form onSubmit={onCreate} noValidate>
            <PlanFormFields
              idPrefix="new"
              form={createForm}
              onChange={setCreateForm}
              branches={branches}
              fieldErrors={fieldErrors}
              clearFieldError={clearFieldError}
            />
            <div className="mt-4 flex flex-wrap gap-2">
              <Button type="submit" loading={createMutation.isPending}>
                Create plan
              </Button>
              <Button type="button" variant="ghost" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <Card>
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2">
            {(
              [
                { value: '' as ActiveFilter, label: 'All' },
                { value: 'active' as ActiveFilter, label: 'Active' },
                { value: 'inactive' as ActiveFilter, label: 'Inactive' },
              ] as const
            ).map((filter) => {
              const active = activeFilter === filter.value
              return (
                <button
                  key={filter.label}
                  type="button"
                  onClick={() => {
                    setActiveFilter(filter.value)
                    setPage(1)
                    setSelectedId(null)
                  }}
                  className={cn(
                    'rounded-xl px-3 py-2 text-sm font-semibold transition',
                    active
                      ? 'bg-accent text-accent-ink'
                      : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                  )}
                >
                  {filter.label}
                </button>
              )
            })}
          </div>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <Select
              value={typeFilter}
              onChange={(e) => {
                setTypeFilter((e.target.value || '') as PlanType | '')
                setPage(1)
                setSelectedId(null)
              }}
              aria-label="Filter by plan type"
              className="sm:w-44"
            >
              <option value="">All types</option>
              <option value="time">Time-based</option>
              <option value="visit">Visit-based</option>
              <option value="hybrid">Hybrid</option>
            </Select>
            <div className="relative min-w-[14rem] flex-1 sm:max-w-xs">
              <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') applySearch()
                }}
                placeholder="Search name or code…"
                className="pl-10"
                aria-label="Search plans"
              />
            </div>
            <Button size="sm" variant="secondary" onClick={applySearch}>
              Search
            </Button>
          </div>
        </div>
      </Card>

      <div className={cn('grid gap-4', selectedId != null ? 'xl:grid-cols-[1fr_26rem]' : '')}>
        <div className="min-w-0">
          {plansQuery.isPending ? (
            <div className="flex justify-center py-20">
              <Spinner label="Loading plans…" />
            </div>
          ) : (
            <>
              <DataTable
                columns={columns}
                rows={rows}
                rowKey={(row) => row.id}
                emptyTitle="No plans match"
                emptyDescription={
                  (meta?.total ?? 0) === 0 && !appliedSearch && !activeFilter && !typeFilter
                    ? 'Create the first membership plan for this gym.'
                    : 'Try another filter or clear the search.'
                }
              />
              <Pagination
                meta={meta}
                onPageChange={(next) => {
                  setPage(next)
                  setSelectedId(null)
                }}
              />
            </>
          )}
        </div>

        {selectedId != null && !selected && selectedQuery.isPending ? (
          <aside className="animate-slide-in">
            <Card className="sticky top-4">
              <div className="flex justify-center py-12">
                <Spinner label="Loading plan…" />
              </div>
            </Card>
          </aside>
        ) : null}

        {selected ? (
          <aside className="animate-slide-in">
            <Card className="sticky top-4 max-h-[calc(100vh-6rem)] space-y-4 overflow-y-auto">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                    <CreditCard className="h-5 w-5" />
                  </div>
                  <CardTitle className="truncate text-base">{selected.name}</CardTitle>
                  <CardDescription className="font-mono">{selected.code}</CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedId(null)}
                  aria-label="Close details"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="flex flex-wrap gap-2">
                <Badge tone={selected.is_active ? 'success' : 'danger'}>
                  {selected.is_active ? 'Active' : 'Inactive'}
                </Badge>
                <Badge tone={planTypeTone(selected.plan_type)}>
                  {planTypeLabel(selected.plan_type)}
                </Badge>
              </div>

              <dl className="space-y-2 text-sm">
                <DetailRow
                  label="Price"
                  value={formatMoney(selected.price, selected.currency_code || defaultCurrency)}
                />
                <DetailRow label="Access" value={formatEntitlement(selected)} />
                <DetailRow
                  label="Branches"
                  value={
                    selected.allows_all_branches
                      ? 'All branches'
                      : (selected.branches ?? []).map((b) => b.name).join(', ') || 'Restricted'
                  }
                />
              </dl>

              {canManage ? (
                <form onSubmit={onSave} noValidate className="space-y-3 border-t border-white/12 pt-4">
                  <p className="text-sm font-semibold text-ink">Edit plan</p>
                  <PlanFormFields
                    idPrefix="edit"
                    form={editForm}
                    onChange={setEditForm}
                    branches={branches}
                    compact
                    fieldErrors={fieldErrors}
                    clearFieldError={clearFieldError}
                  />
                  <Button
                    type="submit"
                    size="sm"
                    loading={updateMutation.isPending}
                    disabled={!editDirty}
                  >
                    Save changes
                  </Button>
                </form>
              ) : null}

              {canManage ? (
                <div className="space-y-2 border-t border-white/12 pt-4">
                  <Button
                    size="sm"
                    variant={selected.is_active ? 'danger' : 'secondary'}
                    loading={toggleActiveMutation.isPending}
                    onClick={() => void onToggleActive(selected)}
                    className="w-full"
                  >
                    {selected.is_active ? (
                      <>
                        <PauseCircle className="h-4 w-4" />
                        Deactivate plan
                      </>
                    ) : (
                      <>
                        <PlayCircle className="h-4 w-4" />
                        Activate plan
                      </>
                    )}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    loading={deleteMutation.isPending}
                    onClick={() => void onDelete(selected)}
                    className="w-full text-danger hover:bg-danger/10"
                  >
                    <Trash2 className="h-4 w-4" />
                    Delete plan
                  </Button>
                </div>
              ) : null}
            </Card>
          </aside>
        ) : null}
      </div>
    </div>
  )
}

function PlanFormFields({
  idPrefix,
  form,
  onChange,
  branches,
  compact = false,
  fieldErrors = {},
  clearFieldError,
}: {
  idPrefix: string
  form: PlanFormState
  onChange: (next: PlanFormState) => void
  branches: Array<{ id: number; code: string; name: string }>
  compact?: boolean
  fieldErrors?: FieldErrors
  clearFieldError?: (key: string) => void
}) {
  const needsDuration = form.plan_type === 'time' || form.plan_type === 'hybrid'
  const needsVisits = form.plan_type === 'visit' || form.plan_type === 'hybrid'
  const set = <K extends keyof PlanFormState>(key: K, value: PlanFormState[K]) =>
    onChange({ ...form, [key]: value })
  const clear = (key: string) => clearFieldError?.(key)

  return (
    <div className={cn('grid gap-3', compact ? 'grid-cols-1' : 'sm:grid-cols-2')}>
      <Field
        label="Code"
        htmlFor={`${idPrefix}-code`}
        required
        error={fieldErrors.code}
      >
        <Input
          id={`${idPrefix}-code`}
          value={form.code}
          onChange={(e) => {
            set('code', e.target.value.toUpperCase())
            clear('code')
          }}
          placeholder="MONTHLY"
          className="font-mono"
          aria-invalid={Boolean(fieldErrors.code)}
        />
      </Field>
      <Field
        label="Name"
        htmlFor={`${idPrefix}-name`}
        required
        error={fieldErrors.name}
      >
        <Input
          id={`${idPrefix}-name`}
          value={form.name}
          onChange={(e) => {
            set('name', e.target.value)
            clear('name')
          }}
          placeholder="Monthly Unlimited"
          aria-invalid={Boolean(fieldErrors.name)}
        />
      </Field>
      <div className={compact ? undefined : 'sm:col-span-2'}>
        <Label htmlFor={`${idPrefix}-description`}>Description</Label>
        <Textarea
          id={`${idPrefix}-description`}
          value={form.description}
          onChange={(e) => set('description', e.target.value)}
          rows={compact ? 2 : 3}
          placeholder="What’s included for members…"
        />
      </div>
      <div>
        <Label htmlFor={`${idPrefix}-type`}>Plan type</Label>
        <Select
          id={`${idPrefix}-type`}
          value={form.plan_type}
          onChange={(e) => set('plan_type', e.target.value as PlanType)}
        >
          <option value="time">Time-based</option>
          <option value="visit">Visit-based</option>
          <option value="hybrid">Hybrid</option>
        </Select>
      </div>
      <Field
        label="Price"
        htmlFor={`${idPrefix}-price`}
        required
        error={fieldErrors.price}
      >
        <Input
          id={`${idPrefix}-price`}
          type="number"
          min="0"
          step="0.01"
          value={form.price}
          onChange={(e) => {
            set('price', e.target.value)
            clear('price')
          }}
          aria-invalid={Boolean(fieldErrors.price)}
        />
      </Field>
      {needsDuration ? (
        <Field
          label="Duration (days)"
          htmlFor={`${idPrefix}-duration`}
          required
          error={fieldErrors.duration_days}
        >
          <Input
            id={`${idPrefix}-duration`}
            type="number"
            min="1"
            value={form.duration_days}
            onChange={(e) => {
              set('duration_days', e.target.value)
              clear('duration_days')
            }}
            aria-invalid={Boolean(fieldErrors.duration_days)}
          />
        </Field>
      ) : null}
      {needsVisits ? (
        <Field
          label="Visit limit"
          htmlFor={`${idPrefix}-visits`}
          required
          error={fieldErrors.visit_limit}
        >
          <Input
            id={`${idPrefix}-visits`}
            type="number"
            min="1"
            value={form.visit_limit}
            onChange={(e) => {
              set('visit_limit', e.target.value)
              clear('visit_limit')
            }}
            aria-invalid={Boolean(fieldErrors.visit_limit)}
          />
        </Field>
      ) : null}
      <div>
        <Label htmlFor={`${idPrefix}-currency`}>Currency</Label>
        <Input
          id={`${idPrefix}-currency`}
          value={form.currency_code}
          onChange={(e) => set('currency_code', e.target.value.toUpperCase())}
          maxLength={3}
          className="font-mono uppercase"
        />
      </div>

      <div className={cn('space-y-2 rounded-xl border border-white/10 bg-white/[0.03] p-3', compact ? undefined : 'sm:col-span-2')}>
        <ToggleRow
          label="Active (sellable)"
          checked={form.is_active}
          onChange={(v) => set('is_active', v)}
        />
        <ToggleRow
          label="Allow walk-in check-in"
          checked={form.allows_walkin}
          onChange={(v) => set('allows_walkin', v)}
        />
        <ToggleRow
          label="Available at all branches"
          checked={form.allows_all_branches}
          onChange={(v) => set('allows_all_branches', v)}
        />
        <ToggleRow
          label="Allow membership freeze"
          checked={form.freeze_allowed}
          onChange={(v) => set('freeze_allowed', v)}
        />
      </div>

      {!form.allows_all_branches ? (
        <div className={compact ? undefined : 'sm:col-span-2'}>
          <Field label="Branches" required error={fieldErrors.branch_ids}>
            <div className="mt-1.5 max-h-40 space-y-1.5 overflow-y-auto rounded-xl border border-white/10 bg-white/[0.03] p-2">
              {branches.length === 0 ? (
                <p className="px-2 py-1.5 text-sm text-muted">No branches available.</p>
              ) : (
                branches.map((branch) => {
                  const checked = form.branch_ids.includes(branch.id)
                  return (
                    <label
                      key={branch.id}
                      className={cn(
                        'flex cursor-pointer items-start gap-2.5 rounded-lg px-2.5 py-2 transition',
                        checked ? 'bg-accent/15' : 'hover:bg-white/8',
                      )}
                    >
                      <input
                        type="checkbox"
                        className="mt-1"
                        checked={checked}
                        onChange={() => {
                          set(
                            'branch_ids',
                            checked
                              ? form.branch_ids.filter((id) => id !== branch.id)
                              : [...form.branch_ids, branch.id],
                          )
                          clear('branch_ids')
                        }}
                      />
                      <span className="min-w-0">
                        <span className="block text-sm font-semibold text-ink">{branch.name}</span>
                        <span className="block font-mono text-xs text-muted">{branch.code}</span>
                      </span>
                    </label>
                  )
                })
              )}
            </div>
          </Field>
        </div>
      ) : null}

      {form.freeze_allowed ? (
        <div>
          <Label htmlFor={`${idPrefix}-freeze-days`}>Max freeze days</Label>
          <Input
            id={`${idPrefix}-freeze-days`}
            type="number"
            min="1"
            value={form.max_freeze_days}
            onChange={(e) => set('max_freeze_days', e.target.value)}
            placeholder="Optional"
          />
        </div>
      ) : null}
    </div>
  )
}

function ToggleRow({
  label,
  checked,
  onChange,
}: {
  label: string
  checked: boolean
  onChange: (value: boolean) => void
}) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-3 text-sm text-ink">
      <span>{label}</span>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
    </label>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="shrink-0 text-muted">{label}</dt>
      <dd className="text-right font-semibold text-ink">{value}</dd>
    </div>
  )
}
