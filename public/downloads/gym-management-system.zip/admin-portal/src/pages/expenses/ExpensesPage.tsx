import { useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  CheckCircle2,
  Plus,
  Search,
  Trash2,
  Wallet,
  X,
  XCircle,
} from 'lucide-react'
import {
  approveExpense,
  createExpense,
  deleteExpense,
  fetchExpense,
  fetchExpenses,
  rejectExpense,
  updateExpense,
  voidExpense,
  type Expense,
  type ExpenseStatus,
} from '@/api/expenses'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useBranchFilter } from '@/hooks/useBranchFilter'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatMoney, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'

const CATEGORY_SUGGESTIONS = [
  'Rent',
  'Utilities',
  'Salaries',
  'Maintenance',
  'Supplies',
  'Marketing',
  'Insurance',
  'Equipment',
  'Misc',
]

function todayIso() {
  return new Date().toISOString().slice(0, 10)
}

function toNum(value: string | number | null | undefined) {
  const n = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(n) ? n : 0
}

function statusTone(
  status: ExpenseStatus,
): 'neutral' | 'accent' | 'success' | 'danger' | 'warning' {
  switch (status) {
    case 'recorded':
      return 'accent'
    case 'approved':
      return 'success'
    case 'rejected':
      return 'warning'
    case 'void':
      return 'danger'
    default:
      return 'neutral'
  }
}

const emptyForm = {
  branch_id: '' as number | '',
  category: '',
  vendor_name: '',
  amount: '',
  tax_amount: '0',
  currency_code: '',
  expense_date: todayIso(),
  receipt_path: '',
  notes: '',
}

export function ExpensesPage() {
  const { branches, branchId, tenant, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('expenses.view')
  const canManage = hasPermission('expenses.manage')
  const defaultCurrency = tenant?.base_currency || 'INR'

  const [error, setError] = useState<string | null>(null)
  const [page, setPage] = useState(1)
  const [status, setStatus] = useState<'' | ExpenseStatus>('')
  const [category, setCategory] = useState('')
  const [branchFilter, setBranchFilter] = useBranchFilter()
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState<Expense | null>(null)
  const [form, setForm] = useState(emptyForm)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  const errMsg = (err: unknown, fallback: string) => {
    if (err instanceof ApiError) return err.message
    if (err instanceof Error && err.message) return err.message
    return fallback
  }

  const invalidate = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['admin', 'expenses'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'expense-stats'] }),
    ])
  }

  const listQuery = useQuery({
    queryKey: [
      'admin',
      'expenses',
      page,
      status,
      category,
      branchFilter,
      from,
      to,
      appliedSearch,
    ],
    queryFn: () =>
      fetchExpenses({
        page,
        per_page: DEFAULT_PAGE_SIZE,
        status,
        category: category || undefined,
        branch_id: branchFilter,
        from: from || undefined,
        to: to || undefined,
        search: appliedSearch,
      }),
    enabled: canView,
  })

  const statsQuery = useQuery({
    queryKey: ['admin', 'expense-stats'],
    queryFn: async () => {
      const [recorded, approved, rejected, voided] = await Promise.all([
        fetchExpenses({ page: 1, per_page: 1, status: 'recorded' }),
        fetchExpenses({ page: 1, per_page: 1, status: 'approved' }),
        fetchExpenses({ page: 1, per_page: 1, status: 'rejected' }),
        fetchExpenses({ page: 1, per_page: 1, status: 'void' }),
      ])
      return {
        recorded: recorded.meta.total,
        approved: approved.meta.total,
        rejected: rejected.meta.total,
        voided: voided.meta.total,
      }
    },
    enabled: canView,
  })

  const detailQuery = useQuery({
    queryKey: ['admin', 'expenses', selectedId],
    queryFn: () => fetchExpense(selectedId!),
    enabled: canView && selectedId != null,
  })

  const openCreate = () => {
    setEditing(null)
    setForm({
      ...emptyForm,
      branch_id: branchId ?? '',
      currency_code: defaultCurrency,
      expense_date: todayIso(),
    })
    setShowForm(true)
    setSelectedId(null)
    setError(null)
    setFieldErrors({})
  }

  const openEdit = (expense: Expense) => {
    setEditing(expense)
    setForm({
      branch_id: expense.branch_id ?? '',
      category: expense.category,
      vendor_name: expense.vendor_name ?? '',
      amount: String(expense.amount),
      tax_amount: String(expense.tax_amount ?? 0),
      currency_code: expense.currency_code || defaultCurrency,
      expense_date: expense.expense_date?.slice(0, 10) || todayIso(),
      receipt_path: expense.receipt_path ?? '',
      notes: expense.notes ?? '',
    })
    setShowForm(true)
    setError(null)
    setFieldErrors({})
  }

  const saveMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        branch_id: form.branch_id === '' ? null : Number(form.branch_id),
        category: form.category.trim(),
        vendor_name: form.vendor_name.trim() || null,
        amount: toNum(form.amount),
        tax_amount: toNum(form.tax_amount),
        currency_code: form.currency_code.trim() || defaultCurrency,
        expense_date: form.expense_date,
        receipt_path: form.receipt_path.trim() || null,
        notes: form.notes.trim() || null,
      }
      if (editing) return updateExpense(editing.id, payload)
      return createExpense(payload)
    },
    onSuccess: async (row) => {
      showSuccess(
        editing ? `Expense #${row.id} updated.` : `Expense #${row.id} recorded.`,
      )
      setShowForm(false)
      setEditing(null)
      setSelectedId(row.id)
      setError(null)
      await invalidate()
    },
    onError: (err) => setError(errMsg(err, 'Could not save expense.')),
  })

  const approveMutation = useMutation({
    mutationFn: (id: number) => approveExpense(id),
    onSuccess: async (row) => {
      showSuccess(`Expense #${row.id} approved.`)
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'expenses', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not approve expense.')),
  })

  const rejectMutation = useMutation({
    mutationFn: (id: number) => rejectExpense(id),
    onSuccess: async (row) => {
      showSuccess(`Expense #${row.id} rejected.`)
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'expenses', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not reject expense.')),
  })

  const voidMutation = useMutation({
    mutationFn: (id: number) => voidExpense(id),
    onSuccess: async (row) => {
      showSuccess(`Expense #${row.id} voided.`)
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'expenses', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not void expense.')),
  })

  const deleteMutation = useMutation({
    mutationFn: (id: number) => deleteExpense(id),
    onSuccess: async () => {
      showSuccess('Expense deleted.')
      setSelectedId(null)
      setShowForm(false)
      await invalidate()
    },
    onError: (err) => setError(errMsg(err, 'Could not delete expense.')),
  })

  const onSave = (e: FormEvent) => {
    e.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'category', label: 'Category', value: form.category },
      { key: 'amount', label: 'Amount', value: form.amount },
      { key: 'expense_date', label: 'Expense date', value: form.expense_date },
    ])
    if (form.amount !== '' && toNum(form.amount) <= 0) {
      errors.amount = 'Amount must be greater than zero.'
    }
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    saveMutation.mutate()
  }

  const onApprove = async (expense: Expense) => {
    const ok = await confirm({
      title: 'Approve expense?',
      message: `Approve ${formatMoney(expense.amount, expense.currency_code)} for ${expense.category}?`,
      confirmLabel: 'Approve',
      tone: 'primary',
    })
    if (ok) approveMutation.mutate(expense.id)
  }

  const onReject = async (expense: Expense) => {
    const ok = await confirm({
      title: 'Reject expense?',
      message: `Reject expense #${expense.id} (${expense.category})?`,
      confirmLabel: 'Reject',
      tone: 'danger',
    })
    if (ok) rejectMutation.mutate(expense.id)
  }

  const onVoid = async (expense: Expense) => {
    const ok = await confirm({
      title: 'Void expense?',
      message: `Void expense #${expense.id}? This marks it as void without deleting the record.`,
      confirmLabel: 'Void',
      tone: 'danger',
    })
    if (ok) voidMutation.mutate(expense.id)
  }

  const onDelete = async (expense: Expense) => {
    const ok = await confirm({
      title: 'Delete expense?',
      message: `Permanently delete expense #${expense.id}? This cannot be undone.`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (ok) deleteMutation.mutate(expense.id)
  }

  const pageTotal = (listQuery.data?.data ?? []).reduce(
    (sum, row) => sum + toNum(row.amount) + toNum(row.tax_amount),
    0,
  )

  const columns: Column<Expense>[] = [
    {
      key: 'date',
      header: 'Date',
      cell: (row) => (
        <div>
          <p className="font-medium text-ink">{formatDate(row.expense_date)}</p>
          <p className="text-xs text-muted">#{row.id}</p>
        </div>
      ),
    },
    {
      key: 'category',
      header: 'Category',
      cell: (row) => (
        <div>
          <p className="font-medium text-ink">{row.category}</p>
          <p className="text-xs text-muted">{row.vendor_name || 'No vendor'}</p>
        </div>
      ),
    },
    {
      key: 'branch',
      header: 'Branch',
      cell: (row) => (
        <span className="text-sm text-ink">
          {row.branch?.name ?? (row.branch_id ? `Branch #${row.branch_id}` : '—')}
        </span>
      ),
    },
    {
      key: 'amount',
      header: 'Amount',
      cell: (row) => (
        <div className="text-right sm:text-left">
          <p className="text-sm font-semibold text-ink">
            {formatMoney(row.amount, row.currency_code)}
          </p>
          {toNum(row.tax_amount) > 0 ? (
            <p className="text-xs text-muted">
              +{formatMoney(row.tax_amount, row.currency_code)} tax
            </p>
          ) : null}
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => <Badge tone={statusTone(row.status)}>{row.status}</Badge>,
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button
          size="sm"
          variant="secondary"
          onClick={() => {
            setSelectedId(row.id)
            setShowForm(false)
            setError(null)
          }}
        >
          Open
        </Button>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader title="Expenses" description="Expense ledger." />
        <Alert tone="danger">You do not have permission to view expenses.</Alert>
      </div>
    )
  }

  const selected = detailQuery.data
  const stats = statsQuery.data
  const expenses = listQuery.data?.data ?? []

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Expenses"
        description="Expense ledger — record, approve, reject, and void gym operating costs."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">{defaultCurrency}</Badge>
            {canManage ? (
              <Button size="sm" onClick={openCreate}>
                <Plus className="h-4 w-4" />
                Record expense
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<Wallet className="h-4 w-4" />}
          label="Pending review"
          value={formatNumber(stats?.recorded ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<CheckCircle2 className="h-4 w-4" />}
          label="Approved"
          value={formatNumber(stats?.approved ?? 0)}
        />
        <SummaryChip
          icon={<XCircle className="h-4 w-4" />}
          label="Rejected"
          value={formatNumber(stats?.rejected ?? 0)}
        />
        <SummaryChip
          icon={<Wallet className="h-4 w-4" />}
          label="Voided"
          value={formatNumber(stats?.voided ?? 0)}
        />
      </div>

      {showForm && canManage ? (
        <Card className="border-accent/25">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <CardTitle>
                {editing ? `Edit expense #${editing.id}` : 'Record expense'}
              </CardTitle>
              <CardDescription>
                New expenses start as recorded. Only recorded entries can be edited or
                approved.
              </CardDescription>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => {
                setShowForm(false)
                setEditing(null)
              }}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form noValidate onSubmit={onSave} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field
              label="Category"
              htmlFor="expense-category"
              required
              error={fieldErrors.category}
            >
              <Input
                id="expense-category"
                required
                aria-invalid={Boolean(fieldErrors.category)}
                list="expense-categories"
                value={form.category}
                onChange={(e) => {
                  clearFieldError('category')
                  setForm((f) => ({ ...f, category: e.target.value }))
                }}
                placeholder="Utilities, Rent…"
              />
              <datalist id="expense-categories">
                {CATEGORY_SUGGESTIONS.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
            </Field>
            <Field label="Vendor" htmlFor="expense-vendor">
              <Input
                id="expense-vendor"
                value={form.vendor_name}
                onChange={(e) => setForm((f) => ({ ...f, vendor_name: e.target.value }))}
                placeholder="Optional vendor name"
              />
            </Field>
            <Field label="Branch" htmlFor="expense-branch">
              <Select
                id="expense-branch"
                value={form.branch_id === '' ? '' : String(form.branch_id)}
                onChange={(e) =>
                  setForm((f) => ({
                    ...f,
                    branch_id: e.target.value ? Number(e.target.value) : '',
                  }))
                }
              >
                <option value="">No branch</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Amount" htmlFor="expense-amount" required error={fieldErrors.amount}>
              <Input
                id="expense-amount"
                required
                aria-invalid={Boolean(fieldErrors.amount)}
                type="number"
                min="0.01"
                step="0.01"
                value={form.amount}
                onChange={(e) => {
                  clearFieldError('amount')
                  setForm((f) => ({ ...f, amount: e.target.value }))
                }}
              />
            </Field>
            <Field label="Tax amount" htmlFor="expense-tax">
              <Input
                id="expense-tax"
                type="number"
                min="0"
                step="0.01"
                value={form.tax_amount}
                onChange={(e) => setForm((f) => ({ ...f, tax_amount: e.target.value }))}
              />
            </Field>
            <Field label="Currency" htmlFor="expense-currency">
              <Input
                id="expense-currency"
                maxLength={3}
                className="uppercase"
                value={form.currency_code}
                onChange={(e) =>
                  setForm((f) => ({ ...f, currency_code: e.target.value.toUpperCase() }))
                }
                placeholder={defaultCurrency}
              />
            </Field>
            <Field
              label="Expense date"
              htmlFor="expense-date"
              required
              error={fieldErrors.expense_date}
            >
              <Input
                id="expense-date"
                required
                aria-invalid={Boolean(fieldErrors.expense_date)}
                type="date"
                value={form.expense_date}
                onChange={(e) => {
                  clearFieldError('expense_date')
                  setForm((f) => ({ ...f, expense_date: e.target.value }))
                }}
              />
            </Field>
            <Field label="Receipt path / ref" htmlFor="expense-receipt">
              <Input
                id="expense-receipt"
                value={form.receipt_path}
                onChange={(e) => setForm((f) => ({ ...f, receipt_path: e.target.value }))}
                placeholder="Optional receipt reference"
              />
            </Field>
            <Field label="Notes" htmlFor="expense-notes" className="sm:col-span-2 lg:col-span-3">
              <Textarea
                id="expense-notes"
                rows={2}
                value={form.notes}
                onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                placeholder="Optional notes"
              />
            </Field>
            <div className="flex justify-end gap-2 sm:col-span-2 lg:col-span-3">
              <Button
                type="button"
                variant="secondary"
                onClick={() => {
                  setShowForm(false)
                  setEditing(null)
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saveMutation.isPending}>
                {saveMutation.isPending
                  ? 'Saving…'
                  : editing
                    ? 'Save changes'
                    : 'Record expense'}
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <Card>
        <div className="mb-4 flex flex-wrap items-end gap-3">
          <div className="min-w-[180px] flex-1">
            <Label>Search</Label>
            <div className="flex gap-2">
              <Input
                placeholder="Vendor, notes, category…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    setAppliedSearch(search.trim())
                    setPage(1)
                  }
                }}
              />
              <Button
                size="sm"
                variant="secondary"
                onClick={() => {
                  setAppliedSearch(search.trim())
                  setPage(1)
                }}
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div>
            <Label>Status</Label>
            <Select
              value={status}
              onChange={(e) => {
                setStatus(e.target.value as '' | ExpenseStatus)
                setPage(1)
              }}
            >
              <option value="">All</option>
              <option value="recorded">Recorded</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
              <option value="void">Void</option>
            </Select>
          </div>
          <div>
            <Label>Category</Label>
            <Input
              list="expense-filter-categories"
              value={category}
              onChange={(e) => {
                setCategory(e.target.value)
                setPage(1)
              }}
              placeholder="Any"
            />
            <datalist id="expense-filter-categories">
              {CATEGORY_SUGGESTIONS.map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>
          </div>
          <div>
            <Label>Branch</Label>
            <Select
              value={branchFilter === '' ? '' : String(branchFilter)}
              onChange={(e) => {
                setBranchFilter(e.target.value ? Number(e.target.value) : '')
                setPage(1)
              }}
            >
              <option value="">All branches</option>
              {branches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label>From</Label>
            <Input
              type="date"
              value={from}
              onChange={(e) => {
                setFrom(e.target.value)
                setPage(1)
              }}
            />
          </div>
          <div>
            <Label>To</Label>
            <Input
              type="date"
              value={to}
              onChange={(e) => {
                setTo(e.target.value)
                setPage(1)
              }}
            />
          </div>
        </div>

        {expenses.length > 0 ? (
          <p className="mb-3 text-xs text-muted">
            Page total (amount + tax):{' '}
            <span className="font-semibold text-ink">
              {formatMoney(pageTotal, defaultCurrency)}
            </span>
          </p>
        ) : null}

        {listQuery.isLoading ? (
          <div className="flex justify-center py-12">
            <Spinner />
          </div>
        ) : listQuery.isError ? (
          <Alert tone="danger">
            {listQuery.error instanceof ApiError
              ? listQuery.error.message
              : 'Failed to load expenses.'}
          </Alert>
        ) : (
          <>
            <DataTable
              columns={columns}
              rows={expenses}
              rowKey={(r) => r.id}
              emptyTitle="No expenses"
              emptyDescription="Record an expense to start the ledger."
            />
            <Pagination
              meta={listQuery.data?.meta}
              onPageChange={(p) => {
                setPage(p)
                setSelectedId(null)
              }}
            />
          </>
        )}
      </Card>

      {selectedId != null ? (
        <Card className="border-accent/20">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <CardTitle>Expense detail</CardTitle>
              <CardDescription>Expense #{selectedId}</CardDescription>
            </div>
            <Button size="sm" variant="ghost" onClick={() => setSelectedId(null)}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          {detailQuery.isLoading ? (
            <div className="flex justify-center py-8">
              <Spinner />
            </div>
          ) : selected ? (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                <Badge tone={statusTone(selected.status)}>{selected.status}</Badge>
                <span className="text-sm font-medium text-ink">{selected.category}</span>
                <span className="text-sm text-muted">
                  · {formatDate(selected.expense_date)}
                </span>
                {selected.branch ? (
                  <span className="text-sm text-muted">· {selected.branch.name}</span>
                ) : null}
              </div>

              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <DetailStat
                  label="Amount"
                  value={formatMoney(selected.amount, selected.currency_code)}
                />
                <DetailStat
                  label="Tax"
                  value={formatMoney(selected.tax_amount, selected.currency_code)}
                />
                <DetailStat
                  label="Total"
                  value={formatMoney(
                    toNum(selected.amount) + toNum(selected.tax_amount),
                    selected.currency_code,
                  )}
                />
                <DetailStat label="Vendor" value={selected.vendor_name || '—'} />
              </div>

              {selected.notes ? (
                <p className="text-sm text-muted">
                  <span className="font-medium text-ink">Notes: </span>
                  {selected.notes}
                </p>
              ) : null}
              {selected.receipt_path ? (
                <p className="text-sm text-muted">
                  <span className="font-medium text-ink">Receipt: </span>
                  {selected.receipt_path}
                </p>
              ) : null}
              {selected.maintenance_order_id ? (
                <p className="text-sm text-muted">
                  Linked maintenance order #{selected.maintenance_order_id}
                </p>
              ) : null}

              {canManage ? (
                <div className="flex flex-wrap gap-2">
                  {selected.status === 'recorded' ? (
                    <>
                      <Button size="sm" variant="secondary" onClick={() => openEdit(selected)}>
                        Edit
                      </Button>
                      <Button
                        size="sm"
                        disabled={approveMutation.isPending}
                        onClick={() => onApprove(selected)}
                      >
                        <CheckCircle2 className="h-4 w-4" />
                        Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="secondary"
                        disabled={rejectMutation.isPending}
                        onClick={() => onReject(selected)}
                      >
                        <XCircle className="h-4 w-4" />
                        Reject
                      </Button>
                      <Button
                        size="sm"
                        variant="danger"
                        disabled={voidMutation.isPending}
                        onClick={() => onVoid(selected)}
                      >
                        Void
                      </Button>
                    </>
                  ) : (
                    <Alert tone="info">
                      Only recorded expenses can be edited or status-transitioned.
                    </Alert>
                  )}
                  <Button
                    size="sm"
                    variant="danger"
                    disabled={deleteMutation.isPending}
                    onClick={() => onDelete(selected)}
                  >
                    <Trash2 className="h-4 w-4" />
                    Delete
                  </Button>
                </div>
              ) : null}
            </div>
          ) : (
            <Alert tone="danger">Expense not found.</Alert>
          )}
        </Card>
      ) : null}
    </div>
  )
}

function DetailStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-0.5 text-sm font-semibold text-ink">{value}</p>
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}
