import { useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  AlertTriangle,
  Boxes,
  Package,
  PackagePlus,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react'
import {
  adjustStock,
  createProduct,
  damageStock,
  deleteProduct,
  fetchProduct,
  fetchProductStock,
  fetchProducts,
  receiveStock,
  updateProduct,
  type Product,
  type ProductStock,
} from '@/api/pos'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useBranchFilter } from '@/hooks/useBranchFilter'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatMoney, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'

type StockAction = 'receive' | 'adjust' | 'damage'

const emptyProductForm = {
  sku: '',
  name: '',
  description: '',
  unit_price: '',
  currency_code: '',
  low_stock_threshold: '5',
  is_active: true,
}

function toNum(value: string | number | null | undefined) {
  const n = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(n) ? n : 0
}

function totalStock(stocks: ProductStock[] | undefined) {
  return (stocks ?? []).reduce((sum, s) => sum + (s.quantity ?? 0), 0)
}

function isLowStock(product: Product, stocks: ProductStock[] | undefined) {
  const total = totalStock(stocks)
  return total <= (product.low_stock_threshold ?? 0)
}

export function InventoryPage() {
  const { branches, branchId, tenant, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('pos.inventory.view')
  const canManage = hasPermission('pos.inventory.manage')
  const defaultCurrency = tenant?.base_currency || 'INR'

  const [error, setError] = useState<string | null>(null)
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [activeFilter, setActiveFilter] = useState<'' | '1' | '0'>('')
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState<Product | null>(null)
  const [form, setForm] = useState(emptyProductForm)
  const [productFieldErrors, setProductFieldErrors] = useState<FieldErrors>({})
  const [stockFieldErrors, setStockFieldErrors] = useState<FieldErrors>({})

  const clearProductFieldError = (key: string) => {
    setProductFieldErrors((prev) => {
      if (!prev[key]) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  const clearStockFieldError = (key: string) => {
    setStockFieldErrors((prev) => {
      if (!prev[key]) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  const [stockAction, setStockAction] = useState<StockAction>('receive')
  const [stockBranch, setStockBranch] = useBranchFilter()
  const [stockQty, setStockQty] = useState('')
  const [stockDelta, setStockDelta] = useState('')
  const [stockMode, setStockMode] = useState<'set' | 'delta'>('set')
  const [stockReason, setStockReason] = useState('')

  const errMsg = (err: unknown, fallback: string) => {
    if (err instanceof ApiError) return err.message
    if (err instanceof Error && err.message) return err.message
    return fallback
  }

  const invalidate = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['admin', 'products'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'product-stock'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'inventory-stats'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'product-stock-map'] }),
    ])
  }

  const listQuery = useQuery({
    queryKey: ['admin', 'products', 'inventory', page, appliedSearch, activeFilter],
    queryFn: () =>
      fetchProducts({
        page,
        per_page: DEFAULT_PAGE_SIZE,
        search: appliedSearch,
        is_active: activeFilter === '' ? '' : activeFilter === '1',
      }),
    enabled: canView,
  })

  const products = listQuery.data?.data ?? []

  const pageStockQuery = useQuery({
    queryKey: ['admin', 'product-stock-map', 'inventory-page', products.map((p) => p.id).join(',')],
    queryFn: async () => {
      const entries = await Promise.all(
        products.map(async (p) => [p.id, await fetchProductStock(p.id)] as const),
      )
      return Object.fromEntries(entries) as Record<number, ProductStock[]>
    },
    enabled: canView && products.length > 0,
  })

  const pageStockMap = pageStockQuery.data ?? {}

  const statsQuery = useQuery({
    queryKey: ['admin', 'inventory-stats'],
    queryFn: async () => {
      const [all, active, inactive] = await Promise.all([
        fetchProducts({ page: 1, per_page: 1 }),
        fetchProducts({ page: 1, per_page: 1, is_active: true }),
        fetchProducts({ page: 1, per_page: 1, is_active: false }),
      ])
      return {
        all: all.meta.total,
        active: active.meta.total,
        inactive: inactive.meta.total,
      }
    },
    enabled: canView,
  })

  const detailQuery = useQuery({
    queryKey: ['admin', 'products', selectedId],
    queryFn: () => fetchProduct(selectedId!),
    enabled: canView && selectedId != null,
  })

  const stockQuery = useQuery({
    queryKey: ['admin', 'product-stock', selectedId],
    queryFn: () => fetchProductStock(selectedId!),
    enabled: canView && selectedId != null,
  })

  const lowOnPage = useMemo(() => {
    return products.filter((p) => isLowStock(p, pageStockMap[p.id])).length
  }, [products, pageStockMap])

  const openCreate = () => {
    setEditing(null)
    setForm({ ...emptyProductForm, currency_code: defaultCurrency })
    setShowForm(true)
    setSelectedId(null)
    setError(null)
    setProductFieldErrors({})
  }

  const openEdit = (product: Product) => {
    setEditing(product)
    setForm({
      sku: product.sku,
      name: product.name,
      description: product.description ?? '',
      unit_price: String(product.unit_price),
      currency_code: product.currency_code || defaultCurrency,
      low_stock_threshold: String(product.low_stock_threshold ?? 5),
      is_active: product.is_active,
    })
    setShowForm(true)
    setError(null)
    setProductFieldErrors({})
  }

  const saveMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        sku: form.sku.trim().toUpperCase(),
        name: form.name.trim(),
        description: form.description.trim() || null,
        unit_price: toNum(form.unit_price),
        currency_code: form.currency_code.trim() || defaultCurrency,
        low_stock_threshold: Math.max(0, Math.floor(toNum(form.low_stock_threshold))),
        is_active: form.is_active,
      }
      if (editing) return updateProduct(editing.id, payload)
      return createProduct(payload)
    },
    onSuccess: async (row) => {
      showSuccess(editing ? `Product ${row.sku} updated.` : `Product ${row.sku} created.`)
      setShowForm(false)
      setEditing(null)
      setSelectedId(row.id)
      setError(null)
      await invalidate()
    },
    onError: (err) => setError(errMsg(err, 'Could not save product.')),
  })

  const deleteMutation = useMutation({
    mutationFn: (id: number) => deleteProduct(id),
    onSuccess: async () => {
      showSuccess('Product deleted.')
      setSelectedId(null)
      setShowForm(false)
      await invalidate()
    },
    onError: (err) => setError(errMsg(err, 'Could not delete product.')),
  })

  const stockMutation = useMutation({
    mutationFn: async () => {
      if (!selectedId) throw new Error('Select a product.')
      if (stockAction === 'receive') {
        const qty = Math.floor(toNum(stockQty))
        return receiveStock(selectedId, {
          branch_id: Number(stockBranch),
          quantity: qty,
          reason: stockReason.trim() || null,
        })
      }
      if (stockAction === 'damage') {
        const qty = Math.floor(toNum(stockQty))
        return damageStock(selectedId, {
          branch_id: Number(stockBranch),
          quantity: qty,
          reason: stockReason.trim() || null,
        })
      }
      if (stockMode === 'set') {
        return adjustStock(selectedId, {
          branch_id: Number(stockBranch),
          quantity: Math.max(0, Math.floor(toNum(stockQty))),
          reason: stockReason.trim() || null,
        })
      }
      return adjustStock(selectedId, {
        branch_id: Number(stockBranch),
        quantity_delta: Math.floor(toNum(stockDelta)),
        reason: stockReason.trim() || null,
      })
    },
    onSuccess: async (row) => {
      const label =
        stockAction === 'receive'
          ? 'Stock received'
          : stockAction === 'damage'
            ? 'Damage recorded'
            : 'Stock adjusted'
      showSuccess(`${label} · ${branchLabel(row.branch_id)} now ${row.quantity}.`)
      setStockQty('')
      setStockDelta('')
      setStockReason('')
      setError(null)
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'product-stock', selectedId] })
    },
    onError: (err) => setError(errMsg(err, 'Could not update stock.')),
  })

  const onSaveProduct = (e: FormEvent) => {
    e.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'sku', label: 'SKU', value: form.sku },
      { key: 'name', label: 'Name', value: form.name },
      { key: 'unit_price', label: 'Unit price', value: form.unit_price },
    ])
    if (Object.keys(errors).length > 0) {
      setProductFieldErrors(errors)
      return
    }
    setProductFieldErrors({})
    saveMutation.mutate()
  }

  const onStockSubmit = (e: FormEvent) => {
    e.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'branch_id', label: 'Branch', value: stockBranch },
    ])
    if (stockAction === 'adjust' && stockMode === 'delta') {
      Object.assign(
        errors,
        collectRequiredErrors([
          { key: 'stock_delta', label: 'Quantity change', value: stockDelta },
        ]),
      )
      if (stockDelta !== '' && toNum(stockDelta) === 0) {
        errors.stock_delta = 'Enter a non-zero quantity change.'
      }
    } else {
      Object.assign(
        errors,
        collectRequiredErrors([
          {
            key: 'quantity',
            label: stockAction === 'adjust' ? 'New quantity' : 'Quantity',
            value: stockQty,
          },
        ]),
      )
      if (
        (stockAction === 'receive' || stockAction === 'damage') &&
        stockQty !== '' &&
        Math.floor(toNum(stockQty)) < 1
      ) {
        errors.quantity = 'Quantity must be at least 1.'
      }
    }
    if (Object.keys(errors).length > 0) {
      setStockFieldErrors(errors)
      return
    }
    setStockFieldErrors({})
    stockMutation.mutate()
  }

  const onDelete = async (product: Product) => {
    const ok = await confirm({
      title: 'Delete product?',
      message: `Delete ${product.name} (${product.sku})? This cannot be undone.`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (ok) deleteMutation.mutate(product.id)
  }

  const branchLabel = (id: number) =>
    branches.find((b) => b.id === id)?.name ?? `Branch #${id}`

  const columns: Column<Product>[] = [
    {
      key: 'product',
      header: 'Product',
      cell: (row) => (
        <div>
          <p className="font-medium text-ink">{row.name}</p>
          <p className="font-mono text-xs text-muted">{row.sku}</p>
        </div>
      ),
    },
    {
      key: 'price',
      header: 'Price',
      cell: (row) => (
        <span className="text-sm text-ink">
          {formatMoney(row.unit_price, row.currency_code || defaultCurrency)}
        </span>
      ),
    },
    {
      key: 'stock',
      header: 'Stock',
      cell: (row) => {
        const stocks = pageStockMap[row.id]
        if (pageStockQuery.isLoading && !stocks) {
          return <span className="text-xs text-muted">…</span>
        }
        const total = totalStock(stocks)
        const low = isLowStock(row, stocks)
        return (
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-ink">{formatNumber(total)}</span>
            {low ? (
              <Badge tone="warning">
                <span className="inline-flex items-center gap-1">
                  <AlertTriangle className="h-3 w-3" />
                  Low
                </span>
              </Badge>
            ) : null}
          </div>
        )
      },
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.is_active ? 'success' : 'neutral'}>
          {row.is_active ? 'Active' : 'Inactive'}
        </Badge>
      ),
    },
    {
      key: 'threshold',
      header: 'Low at',
      cell: (row) => <span className="text-sm text-muted">{row.low_stock_threshold}</span>,
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button
          size="sm"
          variant="secondary"
          onClick={() => {
            setSelectedId(row.id)
            setShowForm(false)
            setStockBranch(branchId ?? '')
            setStockAction('receive')
            setStockQty('')
            setStockDelta('')
            setStockReason('')
            setError(null)
          }}
        >
          Manage
        </Button>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader title="Inventory" description="Stock and products." />
        <Alert tone="danger">You do not have permission to view inventory.</Alert>
      </div>
    )
  }

  const selected = detailQuery.data
  const stocks = stockQuery.data ?? []
  const stats = statsQuery.data

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Inventory"
        description="Stock and products — catalog, receive stock, adjust levels, and record damage."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">{defaultCurrency}</Badge>
            {canManage ? (
              <Button size="sm" onClick={openCreate}>
                <Plus className="h-4 w-4" />
                New product
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<Package className="h-4 w-4" />}
          label="Products"
          value={formatNumber(stats?.all ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<Package className="h-4 w-4" />}
          label="Active"
          value={formatNumber(stats?.active ?? 0)}
        />
        <SummaryChip
          icon={<Boxes className="h-4 w-4" />}
          label="Inactive"
          value={formatNumber(stats?.inactive ?? 0)}
        />
        <SummaryChip
          icon={<AlertTriangle className="h-4 w-4" />}
          label="Low stock (page)"
          value={formatNumber(lowOnPage)}
        />
      </div>

      {showForm && canManage ? (
        <Card className="border-accent/25">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <CardTitle>{editing ? `Edit ${editing.sku}` : 'Add product'}</CardTitle>
              <CardDescription>
                SKU must be unique. Active products appear in the POS checkout catalog.
              </CardDescription>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => {
                setShowForm(false)
                setEditing(null)
              }}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form noValidate onSubmit={onSaveProduct} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="SKU" htmlFor="product-sku" required error={productFieldErrors.sku}>
              <Input
                id="product-sku"
                required
                aria-invalid={Boolean(productFieldErrors.sku)}
                className="font-mono uppercase"
                value={form.sku}
                onChange={(e) => {
                  clearProductFieldError('sku')
                  setForm((f) => ({ ...f, sku: e.target.value.toUpperCase() }))
                }}
                placeholder="SKU-PROTEIN-01"
              />
            </Field>
            <Field
              label="Name"
              htmlFor="product-name"
              required
              error={productFieldErrors.name}
              className="sm:col-span-2 lg:col-span-2"
            >
              <Input
                id="product-name"
                required
                aria-invalid={Boolean(productFieldErrors.name)}
                value={form.name}
                onChange={(e) => {
                  clearProductFieldError('name')
                  setForm((f) => ({ ...f, name: e.target.value }))
                }}
                placeholder="Protein bar"
              />
            </Field>
            <Field
              label="Unit price"
              htmlFor="product-unit-price"
              required
              error={productFieldErrors.unit_price}
            >
              <Input
                id="product-unit-price"
                required
                aria-invalid={Boolean(productFieldErrors.unit_price)}
                type="number"
                min="0"
                step="0.01"
                value={form.unit_price}
                onChange={(e) => {
                  clearProductFieldError('unit_price')
                  setForm((f) => ({ ...f, unit_price: e.target.value }))
                }}
              />
            </Field>
            <Field label="Currency" htmlFor="product-currency">
              <Input
                id="product-currency"
                maxLength={3}
                className="uppercase"
                value={form.currency_code}
                onChange={(e) =>
                  setForm((f) => ({ ...f, currency_code: e.target.value.toUpperCase() }))
                }
                placeholder={defaultCurrency}
              />
            </Field>
            <Field label="Low stock threshold" htmlFor="product-threshold">
              <Input
                id="product-threshold"
                type="number"
                min="0"
                step="1"
                value={form.low_stock_threshold}
                onChange={(e) =>
                  setForm((f) => ({ ...f, low_stock_threshold: e.target.value }))
                }
              />
            </Field>
            <div className="flex items-end">
              <label className="flex items-center gap-2 text-sm text-ink">
                <input
                  type="checkbox"
                  checked={form.is_active}
                  onChange={(e) => setForm((f) => ({ ...f, is_active: e.target.checked }))}
                  className="h-4 w-4 rounded border-white/20"
                />
                Active in POS
              </label>
            </div>
            <Field
              label="Description"
              htmlFor="product-description"
              className="sm:col-span-2 lg:col-span-3"
            >
              <Textarea
                id="product-description"
                rows={2}
                value={form.description}
                onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                placeholder="Optional product notes"
              />
            </Field>
            <div className="flex justify-end gap-2 sm:col-span-2 lg:col-span-3">
              <Button
                type="button"
                variant="secondary"
                onClick={() => {
                  setShowForm(false)
                  setEditing(null)
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saveMutation.isPending}>
                {saveMutation.isPending ? 'Saving…' : editing ? 'Save changes' : 'Create product'}
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <Card>
        <div className="mb-4 flex flex-wrap items-end gap-3">
          <div className="min-w-[200px] flex-1">
            <Label>Search</Label>
            <div className="flex gap-2">
              <Input
                placeholder="Name or SKU…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    setAppliedSearch(search.trim())
                    setPage(1)
                  }
                }}
              />
              <Button
                size="sm"
                variant="secondary"
                onClick={() => {
                  setAppliedSearch(search.trim())
                  setPage(1)
                }}
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div>
            <Label>Status</Label>
            <Select
              value={activeFilter}
              onChange={(e) => {
                setActiveFilter(e.target.value as '' | '1' | '0')
                setPage(1)
              }}
            >
              <option value="">All</option>
              <option value="1">Active</option>
              <option value="0">Inactive</option>
            </Select>
          </div>
        </div>

        {listQuery.isLoading ? (
          <div className="flex justify-center py-12">
            <Spinner />
          </div>
        ) : listQuery.isError ? (
          <Alert tone="danger">
            {listQuery.error instanceof ApiError
              ? listQuery.error.message
              : 'Failed to load products.'}
          </Alert>
        ) : (
          <>
            <DataTable
              columns={columns}
              rows={products}
              rowKey={(r) => r.id}
              emptyTitle="No products"
              emptyDescription="Create a product, then receive stock for each branch."
            />
            <Pagination
              meta={listQuery.data?.meta}
              onPageChange={(p) => {
                setPage(p)
                setSelectedId(null)
              }}
            />
          </>
        )}
      </Card>

      {selectedId != null ? (
        <div className="grid gap-4 xl:grid-cols-[1.1fr_1fr]">
          <Card className="border-accent/20">
            <div className="mb-4 flex items-start justify-between gap-3">
              <div>
                <CardTitle>Product detail</CardTitle>
                <CardDescription>
                  {selected?.sku ?? `Product #${selectedId}`}
                </CardDescription>
              </div>
              <Button size="sm" variant="ghost" onClick={() => setSelectedId(null)}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            {detailQuery.isLoading ? (
              <div className="flex justify-center py-8">
                <Spinner />
              </div>
            ) : selected ? (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone={selected.is_active ? 'success' : 'neutral'}>
                    {selected.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                  {isLowStock(selected, stocks) ? (
                    <Badge tone="warning">Low stock</Badge>
                  ) : null}
                  <span className="text-sm font-medium text-ink">{selected.name}</span>
                </div>

                <div className="grid gap-3 sm:grid-cols-2">
                  <DetailStat
                    label="Unit price"
                    value={formatMoney(
                      selected.unit_price,
                      selected.currency_code || defaultCurrency,
                    )}
                  />
                  <DetailStat
                    label="Total stock"
                    value={formatNumber(totalStock(stocks))}
                  />
                  <DetailStat
                    label="Low stock at"
                    value={String(selected.low_stock_threshold)}
                  />
                  <DetailStat label="SKU" value={selected.sku} />
                </div>

                {selected.description ? (
                  <p className="text-sm text-muted">{selected.description}</p>
                ) : null}

                <div>
                  <h3 className="mb-2 text-sm font-semibold text-ink">Stock by branch</h3>
                  {stockQuery.isLoading ? (
                    <div className="flex justify-center py-6">
                      <Spinner />
                    </div>
                  ) : stocks.length === 0 ? (
                    <Alert tone="info">No stock recorded yet. Receive stock to get started.</Alert>
                  ) : (
                    <div className="overflow-x-auto rounded-xl border border-white/10">
                      <table className="w-full text-left text-sm">
                        <thead className="bg-white/[0.04] text-xs uppercase tracking-wide text-muted">
                          <tr>
                            <th className="px-3 py-2 font-medium">Branch</th>
                            <th className="px-3 py-2 font-medium text-right">Quantity</th>
                          </tr>
                        </thead>
                        <tbody>
                          {stocks.map((s) => (
                            <tr key={s.id} className="border-t border-white/8">
                              <td className="px-3 py-2 text-ink">
                                {s.branch?.name ?? branchLabel(s.branch_id)}
                                {s.branch?.code ? (
                                  <span className="ml-1 text-xs text-muted">
                                    ({s.branch.code})
                                  </span>
                                ) : null}
                              </td>
                              <td className="px-3 py-2 text-right font-semibold text-ink">
                                {s.quantity}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>

                {canManage ? (
                  <div className="flex flex-wrap gap-2">
                    <Button size="sm" variant="secondary" onClick={() => openEdit(selected)}>
                      Edit product
                    </Button>
                    <Button
                      size="sm"
                      variant="danger"
                      disabled={deleteMutation.isPending}
                      onClick={() => onDelete(selected)}
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete
                    </Button>
                  </div>
                ) : null}
              </div>
            ) : (
              <Alert tone="danger">Product not found.</Alert>
            )}
          </Card>

          {canManage && selected ? (
            <Card className="border-accent/20 h-fit">
              <div className="mb-4">
                <CardTitle>Stock movement</CardTitle>
                <CardDescription>
                  Receive deliveries, set or adjust quantities, or write off damaged units.
                </CardDescription>
              </div>

              <div className="mb-4 flex flex-wrap gap-2">
                {(
                  [
                    ['receive', 'Receive', PackagePlus],
                    ['adjust', 'Adjust', Boxes],
                    ['damage', 'Damage', AlertTriangle],
                  ] as const
                ).map(([key, label, Icon]) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => {
                      setStockAction(key)
                      setStockQty('')
                      setStockDelta('')
                      setError(null)
                      setStockFieldErrors({})
                    }}
                    className={cn(
                      'inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-semibold transition',
                      stockAction === key
                        ? 'bg-accent text-accent-ink'
                        : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                    )}
                  >
                    <Icon className="h-4 w-4" />
                    {label}
                  </button>
                ))}
              </div>

              <form noValidate onSubmit={onStockSubmit} className="space-y-3">
                <Field
                  label="Branch"
                  htmlFor="stock-branch"
                  required
                  error={stockFieldErrors.branch_id}
                >
                  <Select
                    id="stock-branch"
                    required
                    aria-invalid={Boolean(stockFieldErrors.branch_id)}
                    value={stockBranch === '' ? '' : String(stockBranch)}
                    onChange={(e) => {
                      clearStockFieldError('branch_id')
                      setStockBranch(e.target.value ? Number(e.target.value) : '')
                    }}
                  >
                    <option value="">Select branch</option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                        {stocks.find((s) => s.branch_id === b.id)
                          ? ` · ${stocks.find((s) => s.branch_id === b.id)?.quantity ?? 0} on hand`
                          : ''}
                      </option>
                    ))}
                  </Select>
                </Field>

                {stockAction === 'adjust' ? (
                  <Field label="Adjustment mode" htmlFor="stock-mode">
                    <Select
                      id="stock-mode"
                      value={stockMode}
                      onChange={(e) => {
                        setStockMode(e.target.value as 'set' | 'delta')
                        setStockFieldErrors({})
                      }}
                    >
                      <option value="set">Set exact quantity</option>
                      <option value="delta">Add / subtract delta</option>
                    </Select>
                  </Field>
                ) : null}

                {stockAction === 'adjust' && stockMode === 'delta' ? (
                  <Field
                    label="Quantity change"
                    htmlFor="stock-delta"
                    required
                    error={stockFieldErrors.stock_delta}
                    hint="Use a negative number to reduce stock without recording damage."
                  >
                    <Input
                      id="stock-delta"
                      required
                      aria-invalid={Boolean(stockFieldErrors.stock_delta)}
                      type="number"
                      step="1"
                      value={stockDelta}
                      onChange={(e) => {
                        clearStockFieldError('stock_delta')
                        setStockDelta(e.target.value)
                      }}
                      placeholder="e.g. +5 or -3"
                    />
                  </Field>
                ) : (
                  <Field
                    label={stockAction === 'adjust' ? 'New quantity' : 'Quantity'}
                    htmlFor="stock-quantity"
                    required
                    error={stockFieldErrors.quantity}
                  >
                    <Input
                      id="stock-quantity"
                      required
                      aria-invalid={Boolean(stockFieldErrors.quantity)}
                      type="number"
                      min={stockAction === 'adjust' ? 0 : 1}
                      step="1"
                      value={stockQty}
                      onChange={(e) => {
                        clearStockFieldError('quantity')
                        setStockQty(e.target.value)
                      }}
                    />
                  </Field>
                )}

                <Field label="Reason (optional)" htmlFor="stock-reason">
                  <Input
                    id="stock-reason"
                    value={stockReason}
                    onChange={(e) => setStockReason(e.target.value)}
                    placeholder={
                      stockAction === 'receive'
                        ? 'PO / supplier delivery'
                        : stockAction === 'damage'
                          ? 'Expired / broken'
                          : 'Cycle count correction'
                    }
                  />
                </Field>

                <Button type="submit" disabled={stockMutation.isPending} className="w-full">
                  {stockMutation.isPending
                    ? 'Saving…'
                    : stockAction === 'receive'
                      ? 'Receive stock'
                      : stockAction === 'damage'
                        ? 'Record damage'
                        : 'Adjust stock'}
                </Button>
              </form>
            </Card>
          ) : null}
        </div>
      ) : null}
    </div>
  )
}

function DetailStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-0.5 text-sm font-semibold text-ink">{value}</p>
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}
