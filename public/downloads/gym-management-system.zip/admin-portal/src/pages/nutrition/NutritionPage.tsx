import { useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { CheckCircle2, Plus, Salad, Search, Trash2, X } from 'lucide-react'
import {
  cancelMemberNutritionPlan,
  createMemberNutritionPlan,
  createNutritionPlan,
  deleteNutritionPlan,
  fetchMemberNutritionPlans,
  fetchNutritionPlan,
  fetchNutritionPlans,
  publishMemberNutritionPlan,
  updateNutritionPlan,
  type MemberNutritionPlan,
  type MemberNutritionPlanStatus,
  type NutritionPlan,
} from '@/api/nutrition'
import { fetchMembers, type Member } from '@/api/members'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'

type PageTab = 'plans' | 'assignments'

function todayIso() {
  return new Date().toISOString().slice(0, 10)
}

function memberLabel(m?: {
  first_name?: string
  last_name?: string
  member_code?: string
  full_name?: string
} | null) {
  if (!m) return '—'
  if (m.full_name) {
    return m.member_code ? `${m.full_name} (${m.member_code})` : m.full_name
  }
  const name = `${m.first_name ?? ''} ${m.last_name ?? ''}`.trim()
  return name ? `${name}${m.member_code ? ` (${m.member_code})` : ''}` : m.member_code || '—'
}

function formatMacros(plan?: Pick<
  NutritionPlan,
  'calorie_target' | 'protein_g' | 'carbs_g' | 'fat_g'
> | null) {
  if (!plan) return '—'
  const parts = [
    plan.calorie_target != null ? `${plan.calorie_target} kcal` : null,
    plan.protein_g != null ? `P ${plan.protein_g}g` : null,
    plan.carbs_g != null ? `C ${plan.carbs_g}g` : null,
    plan.fat_g != null ? `F ${plan.fat_g}g` : null,
  ].filter(Boolean)
  return parts.length > 0 ? parts.join(' · ') : 'No macros set'
}

function assignmentTone(
  status: MemberNutritionPlanStatus,
): 'success' | 'danger' | 'neutral' | 'accent' {
  switch (status) {
    case 'active':
      return 'success'
    case 'completed':
      return 'accent'
    case 'cancelled':
      return 'danger'
    default:
      return 'neutral'
  }
}

const emptyPlanForm = {
  name: '',
  description: '',
  calorie_target: '',
  protein_g: '',
  carbs_g: '',
  fat_g: '',
  file_path: '',
  is_active: true,
}

export function NutritionPage() {
  const { hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('nutrition.view')
  const canManage = hasPermission('nutrition.manage')

  const [tab, setTab] = useState<PageTab>('plans')
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }

  // Plans
  const [planPage, setPlanPage] = useState(1)
  const [planSearch, setPlanSearch] = useState('')
  const [appliedPlanSearch, setAppliedPlanSearch] = useState('')
  const [planActive, setPlanActive] = useState<'' | 'active' | 'inactive'>('active')
  const [selectedPlanId, setSelectedPlanId] = useState<number | null>(null)
  const [showPlanForm, setShowPlanForm] = useState(false)
  const [editingPlan, setEditingPlan] = useState<NutritionPlan | null>(null)
  const [planForm, setPlanForm] = useState(emptyPlanForm)

  // Assignments
  const [assignPage, setAssignPage] = useState(1)
  const [assignStatus, setAssignStatus] = useState<'' | MemberNutritionPlanStatus>('active')
  const [showAssignForm, setShowAssignForm] = useState(false)
  const [assignForm, setAssignForm] = useState({
    member_id: '' as number | '',
    nutrition_plan_id: '' as number | '',
    start_date: todayIso(),
    end_date: '',
    notes: '',
  })
  const [memberSearch, setMemberSearch] = useState('')
  const [appliedMemberSearch, setAppliedMemberSearch] = useState('')

  const plansQuery = useQuery({
    queryKey: ['admin', 'nutrition-plans', planPage, appliedPlanSearch, planActive],
    queryFn: () =>
      fetchNutritionPlans({
        page: planPage,
        per_page: DEFAULT_PAGE_SIZE,
        search: appliedPlanSearch,
        is_active: planActive === '' ? '' : planActive === 'active',
      }),
    enabled: canView && tab === 'plans',
  })

  const planOptionsQuery = useQuery({
    queryKey: ['admin', 'nutrition-plans', 'options'],
    queryFn: () => fetchNutritionPlans({ page: 1, per_page: 100, is_active: true }),
    enabled: canView && (tab === 'assignments' || showAssignForm),
  })

  const statsQuery = useQuery({
    queryKey: ['admin', 'nutrition', 'stats'],
    queryFn: async () => {
      const [all, active, assignments, published] = await Promise.all([
        fetchNutritionPlans({ page: 1, per_page: 1 }),
        fetchNutritionPlans({ page: 1, per_page: 1, is_active: true }),
        fetchMemberNutritionPlans({ page: 1, per_page: 1, status: 'active' }),
        fetchMemberNutritionPlans({ page: 1, per_page: 1, is_published: true, status: 'active' }),
      ])
      return {
        total: all.meta.total,
        active: active.meta.total,
        assignments: assignments.meta.total,
        published: published.meta.total,
      }
    },
    enabled: canView,
  })

  const selectedPlanQuery = useQuery({
    queryKey: ['admin', 'nutrition-plans', 'detail', selectedPlanId],
    queryFn: () => fetchNutritionPlan(selectedPlanId!),
    enabled: canView && selectedPlanId != null && tab === 'plans',
  })

  const assignmentsQuery = useQuery({
    queryKey: ['admin', 'member-nutrition-plans', assignPage, assignStatus],
    queryFn: () =>
      fetchMemberNutritionPlans({
        page: assignPage,
        per_page: DEFAULT_PAGE_SIZE,
        status: assignStatus,
      }),
    enabled: canView && tab === 'assignments',
  })

  const membersQuery = useQuery({
    queryKey: ['admin', 'members', 'nutrition-search', appliedMemberSearch],
    queryFn: () =>
      fetchMembers({
        page: 1,
        per_page: 20,
        search: appliedMemberSearch,
        status: 'active',
      }),
    enabled: canManage && showAssignForm && appliedMemberSearch.length > 0,
  })

  const planRows = plansQuery.data?.data ?? []
  const planOptions = planOptionsQuery.data?.data ?? []
  const selectedPlan = useMemo(() => {
    if (selectedPlanId == null) return null
    return selectedPlanQuery.data ?? planRows.find((p) => p.id === selectedPlanId) ?? null
  }, [selectedPlanId, selectedPlanQuery.data, planRows])

  const invalidate = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'nutrition-plans'] })
    await queryClient.invalidateQueries({ queryKey: ['admin', 'member-nutrition-plans'] })
    await queryClient.invalidateQueries({ queryKey: ['admin', 'nutrition'] })
  }

  const apiError = (err: unknown, fallback: string) =>
    err instanceof ApiError ? err.message : fallback

  const toPlanPayload = () => ({
    name: planForm.name.trim(),
    description: planForm.description.trim() || null,
    calorie_target: planForm.calorie_target ? Number(planForm.calorie_target) : null,
    protein_g: planForm.protein_g ? Number(planForm.protein_g) : null,
    carbs_g: planForm.carbs_g ? Number(planForm.carbs_g) : null,
    fat_g: planForm.fat_g ? Number(planForm.fat_g) : null,
    file_path: planForm.file_path.trim() || null,
    is_active: planForm.is_active,
  })

  const savePlanMutation = useMutation({
    mutationFn: async () => {
      const payload = toPlanPayload()
      if (editingPlan) return updateNutritionPlan(editingPlan.id, payload)
      return createNutritionPlan(payload)
    },
    onSuccess: async (plan) => {
      setError(null)
      showSuccess(
        editingPlan ? `Plan “${plan.name}” updated.` : `Plan “${plan.name}” created.`,
      )
      setShowPlanForm(false)
      setEditingPlan(null)
      setPlanForm(emptyPlanForm)
      await invalidate()
      setSelectedPlanId(plan.id)
    },
    onError: (err) => setError(apiError(err, 'Unable to save nutrition plan.')),
  })

  const deletePlanMutation = useMutation({
    mutationFn: deleteNutritionPlan,
    onSuccess: async () => {
      showSuccess('Nutrition plan deleted.')
      setSelectedPlanId(null)
      setEditingPlan(null)
      setShowPlanForm(false)
      await invalidate()
    },
    onError: (err) => {
      if (err instanceof ApiError && err.code === 'nutrition_plan_in_use') {
        setError('This plan has active assignments. Cancel them first, or deactivate the plan.')
        return
      }
      setError(apiError(err, 'Unable to delete nutrition plan.'))
    },
  })

  const assignMutation = useMutation({
    mutationFn: createMemberNutritionPlan,
    onSuccess: async (row) => {
      showSuccess(`Plan assigned to ${memberLabel(row.member)}.`)
      setShowAssignForm(false)
      setAssignForm({
        member_id: '',
        nutrition_plan_id: '',
        start_date: todayIso(),
        end_date: '',
        notes: '',
      })
      setMemberSearch('')
      setAppliedMemberSearch('')
      setAssignStatus('active')
      setTab('assignments')
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to assign nutrition plan.')),
  })

  const publishMutation = useMutation({
    mutationFn: publishMemberNutritionPlan,
    onSuccess: async () => {
      showSuccess('Plan published to member.')
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to publish plan.')),
  })

  const cancelMutation = useMutation({
    mutationFn: cancelMemberNutritionPlan,
    onSuccess: async () => {
      showSuccess('Assignment cancelled.')
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to cancel assignment.')),
  })

  const openCreatePlan = () => {
    setEditingPlan(null)
    setPlanForm(emptyPlanForm)
    setShowPlanForm(true)
    setError(null)
  }

  const openEditPlan = (plan: NutritionPlan) => {
    setEditingPlan(plan)
    setPlanForm({
      name: plan.name,
      description: plan.description ?? '',
      calorie_target: plan.calorie_target != null ? String(plan.calorie_target) : '',
      protein_g: plan.protein_g != null ? String(plan.protein_g) : '',
      carbs_g: plan.carbs_g != null ? String(plan.carbs_g) : '',
      fat_g: plan.fat_g != null ? String(plan.fat_g) : '',
      file_path: plan.file_path ?? '',
      is_active: plan.is_active,
    })
    setShowPlanForm(true)
    setSelectedPlanId(plan.id)
    setError(null)
  }

  const onSavePlan = (event: FormEvent) => {
    event.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'name', label: 'Name', value: planForm.name },
    ])
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    savePlanMutation.mutate()
  }

  const onDeletePlan = async (plan: NutritionPlan) => {
    const ok = await confirm({
      title: 'Delete nutrition plan?',
      message: `Delete “${plan.name}”? Plans with active assignments cannot be deleted.`,
      confirmLabel: 'Delete plan',
      tone: 'danger',
    })
    if (!ok) return
    deletePlanMutation.mutate(plan.id)
  }

  const onCancelAssignment = async (row: MemberNutritionPlan) => {
    const ok = await confirm({
      title: 'Cancel assignment?',
      message: `Cancel “${row.nutrition_plan?.name ?? 'plan'}” for ${memberLabel(row.member)}?`,
      confirmLabel: 'Cancel assignment',
      tone: 'danger',
    })
    if (!ok) return
    cancelMutation.mutate(row.id)
  }

  const planColumns: Column<NutritionPlan>[] = [
    {
      key: 'plan',
      header: 'Plan',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedPlanId(row.id)}
        >
          <p className="font-semibold text-ink">{row.name}</p>
          <p className="mt-0.5 line-clamp-1 text-xs text-muted">
            {row.description || 'No description'}
          </p>
        </button>
      ),
    },
    {
      key: 'macros',
      header: 'Macros',
      cell: (row) => <span className="text-sm text-ink">{formatMacros(row)}</span>,
    },
    {
      key: 'author',
      header: 'Created by',
      cell: (row) => (
        <span className="text-sm text-muted">{row.created_by_user?.name ?? '—'}</span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.is_active ? 'success' : 'danger'}>
          {row.is_active ? 'Active' : 'Inactive'}
        </Badge>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) =>
        canManage ? (
          <Button size="sm" variant="secondary" onClick={() => openEditPlan(row)}>
            Edit
          </Button>
        ) : (
          <Button size="sm" variant="secondary" onClick={() => setSelectedPlanId(row.id)}>
            View
          </Button>
        ),
    },
  ]

  const assignmentColumns: Column<MemberNutritionPlan>[] = [
    {
      key: 'member',
      header: 'Member',
      cell: (row) => (
        <div>
          <p className="font-semibold text-ink">{memberLabel(row.member)}</p>
          <p className="text-xs text-muted">{row.nutrition_plan?.name ?? '—'}</p>
        </div>
      ),
    },
    {
      key: 'macros',
      header: 'Macros',
      cell: (row) => (
        <span className="text-sm text-ink">{formatMacros(row.nutrition_plan)}</span>
      ),
    },
    {
      key: 'dates',
      header: 'Period',
      cell: (row) => (
        <span className="text-sm text-ink">
          {formatDate(row.start_date)} → {formatDate(row.end_date)}
        </span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <div className="flex flex-wrap gap-1.5">
          <Badge tone={assignmentTone(row.status)}>{row.status}</Badge>
          {row.is_published ? <Badge tone="accent">Published</Badge> : null}
        </div>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) =>
        canManage && row.status === 'active' ? (
          <div className="flex flex-wrap justify-end gap-1.5">
            {!row.is_published ? (
              <Button
                size="sm"
                variant="secondary"
                loading={publishMutation.isPending}
                onClick={() => publishMutation.mutate(row.id)}
              >
                Publish
              </Button>
            ) : null}
            <Button
              size="sm"
              variant="ghost"
              loading={cancelMutation.isPending}
              onClick={() => void onCancelAssignment(row)}
            >
              Cancel
            </Button>
          </div>
        ) : null,
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader title="Nutrition" description="Nutrition plans." />
        <Alert tone="danger">You do not have permission to view nutrition plans.</Alert>
      </div>
    )
  }

  const stats = statsQuery.data

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Nutrition"
        description="Nutrition plans — macro templates and member assignments."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">Gym</Badge>
            {canManage && tab === 'plans' ? (
              <Button size="sm" onClick={openCreatePlan}>
                <Plus className="h-4 w-4" />
                New plan
              </Button>
            ) : null}
            {canManage && tab === 'assignments' ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowAssignForm(true)
                  setError(null)
                }}
              >
                <Plus className="h-4 w-4" />
                Assign plan
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<Salad className="h-4 w-4" />}
          label="Total plans"
          value={formatNumber(stats?.total ?? 0)}
        />
        <SummaryChip
          icon={<CheckCircle2 className="h-4 w-4" />}
          label="Active plans"
          value={formatNumber(stats?.active ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<Salad className="h-4 w-4" />}
          label="Active assignments"
          value={formatNumber(stats?.assignments ?? 0)}
        />
        <SummaryChip
          icon={<CheckCircle2 className="h-4 w-4" />}
          label="Published"
          value={formatNumber(stats?.published ?? 0)}
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {(
          [
            { id: 'plans' as const, label: 'Plans' },
            { id: 'assignments' as const, label: 'Assignments' },
          ] as const
        ).map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => {
              setTab(item.id)
              setError(null)
              setShowPlanForm(false)
              setShowAssignForm(false)
              setSelectedPlanId(null)
            }}
            className={cn(
              'rounded-xl px-3 py-2 text-sm font-semibold transition',
              tab === item.id
                ? 'bg-accent text-accent-ink'
                : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
            )}
          >
            {item.label}
          </button>
        ))}
      </div>

      {tab === 'plans' ? (
        <>
          {showPlanForm && canManage ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>
                    {editingPlan ? 'Edit nutrition plan' : 'Create nutrition plan'}
                  </CardTitle>
                  <CardDescription>
                    Macro targets and notes members receive when this plan is assigned.
                  </CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setShowPlanForm(false)
                    setEditingPlan(null)
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form onSubmit={onSavePlan} noValidate className="grid gap-3 sm:grid-cols-2">
                <Field
                  label="Name"
                  htmlFor="plan-name"
                  required
                  error={fieldErrors.name}
                  className="sm:col-span-2"
                >
                  <Input
                    id="plan-name"
                    value={planForm.name}
                    onChange={(e) => {
                      setPlanForm((f) => ({ ...f, name: e.target.value }))
                      clearFieldError('name')
                    }}
                    aria-invalid={Boolean(fieldErrors.name)}
                  />
                </Field>
                <div className="sm:col-span-2">
                  <Label htmlFor="plan-description">Description</Label>
                  <Textarea
                    id="plan-description"
                    value={planForm.description}
                    onChange={(e) =>
                      setPlanForm((f) => ({ ...f, description: e.target.value }))
                    }
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="plan-calories">Calories (kcal)</Label>
                  <Input
                    id="plan-calories"
                    type="number"
                    min="0"
                    value={planForm.calorie_target}
                    onChange={(e) =>
                      setPlanForm((f) => ({ ...f, calorie_target: e.target.value }))
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="plan-protein">Protein (g)</Label>
                  <Input
                    id="plan-protein"
                    type="number"
                    min="0"
                    value={planForm.protein_g}
                    onChange={(e) =>
                      setPlanForm((f) => ({ ...f, protein_g: e.target.value }))
                    }
                  />
                </div>
                <div>
                  <Label htmlFor="plan-carbs">Carbs (g)</Label>
                  <Input
                    id="plan-carbs"
                    type="number"
                    min="0"
                    value={planForm.carbs_g}
                    onChange={(e) => setPlanForm((f) => ({ ...f, carbs_g: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="plan-fat">Fat (g)</Label>
                  <Input
                    id="plan-fat"
                    type="number"
                    min="0"
                    value={planForm.fat_g}
                    onChange={(e) => setPlanForm((f) => ({ ...f, fat_g: e.target.value }))}
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="plan-file">Reference file path (optional)</Label>
                  <Input
                    id="plan-file"
                    value={planForm.file_path}
                    onChange={(e) =>
                      setPlanForm((f) => ({ ...f, file_path: e.target.value }))
                    }
                    placeholder="/docs/cut-phase.pdf"
                    className="font-mono text-sm"
                  />
                </div>
                <label className="flex items-center gap-2 text-sm text-ink sm:col-span-2">
                  <input
                    type="checkbox"
                    checked={planForm.is_active}
                    onChange={(e) =>
                      setPlanForm((f) => ({ ...f, is_active: e.target.checked }))
                    }
                  />
                  Active (assignable)
                </label>
                <div className="flex flex-wrap gap-2 sm:col-span-2">
                  <Button type="submit" loading={savePlanMutation.isPending}>
                    {editingPlan ? 'Save plan' : 'Create plan'}
                  </Button>
                  {editingPlan ? (
                    <Button
                      type="button"
                      variant="ghost"
                      className="text-danger"
                      loading={deletePlanMutation.isPending}
                      onClick={() => void onDeletePlan(editingPlan)}
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete
                    </Button>
                  ) : null}
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={() => {
                      setShowPlanForm(false)
                      setEditingPlan(null)
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          <Card>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap gap-2">
                {(
                  [
                    { value: '' as const, label: 'All' },
                    { value: 'active' as const, label: 'Active' },
                    { value: 'inactive' as const, label: 'Inactive' },
                  ] as const
                ).map((filter) => (
                  <button
                    key={filter.label}
                    type="button"
                    onClick={() => {
                      setPlanActive(filter.value)
                      setPlanPage(1)
                      setSelectedPlanId(null)
                    }}
                    className={cn(
                      'rounded-xl px-3 py-2 text-sm font-semibold transition',
                      planActive === filter.value
                        ? 'bg-accent text-accent-ink'
                        : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                    )}
                  >
                    {filter.label}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <div className="relative min-w-[12rem] flex-1">
                  <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
                  <Input
                    value={planSearch}
                    onChange={(e) => setPlanSearch(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        setAppliedPlanSearch(planSearch.trim())
                        setPlanPage(1)
                      }
                    }}
                    placeholder="Search plans…"
                    className="pl-10"
                  />
                </div>
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    setAppliedPlanSearch(planSearch.trim())
                    setPlanPage(1)
                  }}
                >
                  Search
                </Button>
              </div>
            </div>
          </Card>

          <div
            className={cn(
              'grid gap-4',
              selectedPlanId != null && !showPlanForm ? 'xl:grid-cols-[1fr_24rem]' : '',
            )}
          >
            <div className="min-w-0">
              {plansQuery.isPending ? (
                <div className="flex justify-center py-20">
                  <Spinner label="Loading plans…" />
                </div>
              ) : plansQuery.isError ? (
                <Alert tone="danger">
                  {plansQuery.error instanceof ApiError
                    ? plansQuery.error.message
                    : 'Unable to load nutrition plans.'}
                </Alert>
              ) : (
                <>
                  <DataTable
                    columns={planColumns}
                    rows={planRows}
                    rowKey={(row) => row.id}
                    emptyTitle="No nutrition plans"
                    emptyDescription="Create a macro plan to assign to members."
                  />
                  <Pagination
                    meta={plansQuery.data?.meta}
                    onPageChange={(p) => {
                      setPlanPage(p)
                      setSelectedPlanId(null)
                    }}
                  />
                </>
              )}
            </div>

            {selectedPlan && !showPlanForm ? (
              <aside className="animate-slide-in">
                <Card className="sticky top-4 space-y-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                        <Salad className="h-5 w-5" />
                      </div>
                      <CardTitle className="text-base">{selectedPlan.name}</CardTitle>
                      <CardDescription>
                        {selectedPlan.created_by_user?.name
                          ? `By ${selectedPlan.created_by_user.name}`
                          : 'Nutrition plan'}
                      </CardDescription>
                    </div>
                    <Button size="sm" variant="ghost" onClick={() => setSelectedPlanId(null)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  <Badge tone={selectedPlan.is_active ? 'success' : 'danger'}>
                    {selectedPlan.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                  <p className="text-sm text-muted">
                    {selectedPlan.description || 'No description.'}
                  </p>
                  <dl className="space-y-2 text-sm">
                    <DetailRow label="Calories" value={selectedPlan.calorie_target != null ? `${selectedPlan.calorie_target} kcal` : '—'} />
                    <DetailRow label="Protein" value={selectedPlan.protein_g != null ? `${selectedPlan.protein_g} g` : '—'} />
                    <DetailRow label="Carbs" value={selectedPlan.carbs_g != null ? `${selectedPlan.carbs_g} g` : '—'} />
                    <DetailRow label="Fat" value={selectedPlan.fat_g != null ? `${selectedPlan.fat_g} g` : '—'} />
                    {selectedPlan.file_path ? (
                      <DetailRow label="File" value={selectedPlan.file_path} />
                    ) : null}
                  </dl>
                  {canManage ? (
                    <Button size="sm" variant="secondary" onClick={() => openEditPlan(selectedPlan)}>
                      Edit plan
                    </Button>
                  ) : null}
                </Card>
              </aside>
            ) : null}
          </div>
        </>
      ) : (
        <>
          {showAssignForm && canManage ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Assign nutrition plan</CardTitle>
                  <CardDescription>
                    Link an active plan to a member. Publish when ready for them to see it.
                  </CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setShowAssignForm(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  const errors = collectRequiredErrors([
                    { key: 'member_id', label: 'Member', value: assignForm.member_id },
                    {
                      key: 'nutrition_plan_id',
                      label: 'Nutrition plan',
                      value: assignForm.nutrition_plan_id,
                    },
                    { key: 'start_date', label: 'Start date', value: assignForm.start_date },
                  ])
                  if (Object.keys(errors).length > 0) {
                    setFieldErrors(errors)
                    return
                  }
                  setFieldErrors({})
                  assignMutation.mutate({
                    member_id: Number(assignForm.member_id),
                    nutrition_plan_id: Number(assignForm.nutrition_plan_id),
                    start_date: assignForm.start_date,
                    end_date: assignForm.end_date || null,
                    notes: assignForm.notes.trim() || null,
                  })
                }}
                noValidate
                className="grid gap-3 sm:grid-cols-2"
              >
                <div className="sm:col-span-2">
                  <Label>Find member</Label>
                  <div className="flex gap-2">
                    <Input
                      value={memberSearch}
                      onChange={(e) => setMemberSearch(e.target.value)}
                      placeholder="Name or code…"
                    />
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setAppliedMemberSearch(memberSearch.trim())}
                    >
                      <Search className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <Field label="Member" required error={fieldErrors.member_id}>
                  <Select
                    value={assignForm.member_id === '' ? '' : String(assignForm.member_id)}
                    onChange={(e) => {
                      setAssignForm((f) => ({
                        ...f,
                        member_id: e.target.value ? Number(e.target.value) : '',
                      }))
                      clearFieldError('member_id')
                    }}
                    aria-invalid={Boolean(fieldErrors.member_id)}
                  >
                    <option value="">Select…</option>
                    {(membersQuery.data?.data ?? []).map((m: Member) => (
                      <option key={m.id} value={m.id}>
                        {m.full_name} ({m.member_code})
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Nutrition plan" required error={fieldErrors.nutrition_plan_id}>
                  <Select
                    value={
                      assignForm.nutrition_plan_id === ''
                        ? ''
                        : String(assignForm.nutrition_plan_id)
                    }
                    onChange={(e) => {
                      setAssignForm((f) => ({
                        ...f,
                        nutrition_plan_id: e.target.value ? Number(e.target.value) : '',
                      }))
                      clearFieldError('nutrition_plan_id')
                    }}
                    aria-invalid={Boolean(fieldErrors.nutrition_plan_id)}
                  >
                    <option value="">Select…</option>
                    {planOptions.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                        {p.calorie_target != null ? ` · ${p.calorie_target} kcal` : ''}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Start date" required error={fieldErrors.start_date}>
                  <Input
                    type="date"
                    value={assignForm.start_date}
                    onChange={(e) => {
                      setAssignForm((f) => ({ ...f, start_date: e.target.value }))
                      clearFieldError('start_date')
                    }}
                    aria-invalid={Boolean(fieldErrors.start_date)}
                  />
                </Field>
                <div>
                  <Label>End date (optional)</Label>
                  <Input
                    type="date"
                    value={assignForm.end_date}
                    onChange={(e) =>
                      setAssignForm((f) => ({ ...f, end_date: e.target.value }))
                    }
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label>Notes</Label>
                  <Textarea
                    value={assignForm.notes}
                    onChange={(e) => setAssignForm((f) => ({ ...f, notes: e.target.value }))}
                    rows={2}
                  />
                </div>
                <div className="flex gap-2 sm:col-span-2">
                  <Button type="submit" loading={assignMutation.isPending}>
                    Assign plan
                  </Button>
                  <Button type="button" variant="ghost" onClick={() => setShowAssignForm(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          <Card>
            <div className="flex flex-wrap gap-2">
              {(
                [
                  { value: '' as const, label: 'All' },
                  { value: 'active' as const, label: 'Active' },
                  { value: 'completed' as const, label: 'Completed' },
                  { value: 'cancelled' as const, label: 'Cancelled' },
                ] as const
              ).map((filter) => (
                <button
                  key={filter.label}
                  type="button"
                  onClick={() => {
                    setAssignStatus(filter.value)
                    setAssignPage(1)
                  }}
                  className={cn(
                    'rounded-xl px-3 py-2 text-sm font-semibold transition',
                    assignStatus === filter.value
                      ? 'bg-accent text-accent-ink'
                      : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                  )}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </Card>

          {assignmentsQuery.isPending ? (
            <div className="flex justify-center py-20">
              <Spinner label="Loading assignments…" />
            </div>
          ) : assignmentsQuery.isError ? (
            <Alert tone="danger">
              {assignmentsQuery.error instanceof ApiError
                ? assignmentsQuery.error.message
                : 'Unable to load assignments.'}
            </Alert>
          ) : (
            <>
              <DataTable
                columns={assignmentColumns}
                rows={assignmentsQuery.data?.data ?? []}
                rowKey={(row) => row.id}
                emptyTitle="No assignments"
                emptyDescription="Assign a nutrition plan to a member to get started."
              />
              <Pagination meta={assignmentsQuery.data?.meta} onPageChange={setAssignPage} />
            </>
          )}
        </>
      )}
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="shrink-0 text-muted">{label}</dt>
      <dd className="break-all text-right font-semibold text-ink">{value}</dd>
    </div>
  )
}
