import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Plus, RefreshCw, Trash2 } from 'lucide-react'
import {
  createPlatformRole,
  deletePlatformRole,
  fetchPlatformPermissions,
  fetchPlatformRolePermissions,
  fetchPlatformRoles,
  seedPlatformRoles,
  syncPlatformRolePermissions,
  updatePlatformRole,
} from '@/api/platformRbac'
import {
  createTenantRole,
  deleteTenantRole,
  fetchTenantPermissionsCatalog,
  fetchTenantRolePermissions,
  fetchTenantRoles,
  seedTenantRoles,
  syncTenantRolePermissions,
  updateTenantRole,
} from '@/api/platformTenantRbac'
import { fetchPlatformTenants } from '@/api/platform'
import type { RoleRow } from '@/api/rbac'
import { platformMenuGroups } from '@/config/platformRbac'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Spinner } from '@/components/ui/Spinner'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { ApiError } from '@/api/client'
import { cn } from '@/lib/cn'

type Realm = 'platform' | 'tenant'

export function PlatformRbacSettingsPage() {
  const { hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()
  const canManage = hasPermission('platform.users.manage')
  const canViewTenants =
    hasPermission('platform.tenants.view') || hasPermission('platform.tenants.manage')

  const [realm, setRealm] = useState<Realm>('platform')
  const [tenantId, setTenantId] = useState<number | null>(null)
  const [selectedRoleId, setSelectedRoleId] = useState<number | null>(null)
  const [draftCodes, setDraftCodes] = useState<string[]>([])
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }
  const [showCreate, setShowCreate] = useState(false)
  const [createCode, setCreateCode] = useState('')
  const [createName, setCreateName] = useState('')
  const [editName, setEditName] = useState('')
  const [editCode, setEditCode] = useState('')

  const isTenantRealm = realm === 'tenant'
  const tenantReady = !isTenantRealm || tenantId != null

  const tenantsQuery = useQuery({
    queryKey: ['platform', 'tenants'],
    queryFn: () => fetchPlatformTenants(),
    enabled: canViewTenants || canManage,
  })

  useEffect(() => {
    if (tenantId != null) return
    const first = tenantsQuery.data?.[0]
    if (first) setTenantId(first.id)
  }, [tenantsQuery.data, tenantId])

  const rolesQuery = useQuery({
    queryKey: isTenantRealm
      ? ['platform', 'tenant-roles', tenantId]
      : ['platform', 'roles'],
    queryFn: () =>
      isTenantRealm ? fetchTenantRoles(tenantId!) : fetchPlatformRoles(),
    enabled: tenantReady,
  })

  const permissionsQuery = useQuery({
    queryKey: isTenantRealm
      ? ['platform', 'tenant-permissions']
      : ['platform', 'permissions'],
    queryFn: isTenantRealm ? fetchTenantPermissionsCatalog : fetchPlatformPermissions,
  })

  const activeRoleId = selectedRoleId ?? rolesQuery.data?.[0]?.id ?? null

  const rolePermsQuery = useQuery({
    queryKey: isTenantRealm
      ? ['platform', 'tenant-roles', tenantId, activeRoleId, 'permissions']
      : ['platform', 'roles', activeRoleId, 'permissions'],
    queryFn: () =>
      isTenantRealm
        ? fetchTenantRolePermissions(tenantId!, activeRoleId!)
        : fetchPlatformRolePermissions(activeRoleId!),
    enabled: tenantReady && activeRoleId != null,
  })

  useEffect(() => {
    setSelectedRoleId(null)
    setShowCreate(false)
    setError(null)
    setDraftCodes([])
  }, [realm, tenantId])

  useEffect(() => {
    if (selectedRoleId == null && rolesQuery.data?.[0]?.id != null) {
      setSelectedRoleId(rolesQuery.data[0].id)
    }
  }, [rolesQuery.data, selectedRoleId])

  useEffect(() => {
    if (rolePermsQuery.data && activeRoleId === rolePermsQuery.data.role.id) {
      setDraftCodes(rolePermsQuery.data.permissions.map((p) => p.code))
      setEditName(rolePermsQuery.data.role.name)
      setEditCode(rolePermsQuery.data.role.code)
    }
  }, [rolePermsQuery.data, activeRoleId])

  const codeToId = useMemo(() => {
    const map = new Map<string, number>()
    for (const perm of permissionsQuery.data ?? []) {
      map.set(perm.code, perm.id)
    }
    return map
  }, [permissionsQuery.data])

  const menuCodes = useMemo(() => {
    const set = new Set<string>()
    for (const group of platformMenuGroups) {
      for (const menu of group.menus) {
        for (const perm of menu.permissions) set.add(perm.code)
      }
    }
    return set
  }, [])

  const extraPermissions = useMemo(
    () => (permissionsQuery.data ?? []).filter((perm) => !menuCodes.has(perm.code)),
    [permissionsQuery.data, menuCodes],
  )

  const tenantGroupedPermissions = useMemo(() => {
    const map = new Map<string, NonNullable<typeof permissionsQuery.data>>()
    for (const perm of permissionsQuery.data ?? []) {
      const list = map.get(perm.module) ?? []
      list.push(perm)
      map.set(perm.module, list)
    }
    return [...map.entries()].sort(([a], [b]) => a.localeCompare(b))
  }, [permissionsQuery.data])

  const dirtyPermissions = useMemo(() => {
    const saved = new Set(rolePermsQuery.data?.permissions.map((p) => p.code) ?? [])
    const draft = new Set(draftCodes)
    if (saved.size !== draft.size) return true
    for (const code of draft) {
      if (!saved.has(code)) return true
    }
    return false
  }, [draftCodes, rolePermsQuery.data])

  const selectedRole: RoleRow | undefined =
    rolesQuery.data?.find((r) => r.id === activeRoleId) ?? rolePermsQuery.data?.role

  const dirtyMeta =
    selectedRole != null &&
    (editName.trim() !== selectedRole.name ||
      (!selectedRole.is_system && editCode.trim() !== selectedRole.code))

  const rolesQueryKey = isTenantRealm
    ? (['platform', 'tenant-roles', tenantId] as const)
    : (['platform', 'roles'] as const)

  const invalidateRoles = async () => {
    await queryClient.invalidateQueries({ queryKey: [...rolesQueryKey] })
  }

  const savePermissionsMutation = useMutation({
    mutationFn: () => {
      const ids = draftCodes
        .map((code) => codeToId.get(code))
        .filter((id): id is number => typeof id === 'number')
      return isTenantRealm
        ? syncTenantRolePermissions(tenantId!, activeRoleId!, ids)
        : syncPlatformRolePermissions(activeRoleId!, ids)
    },
    onSuccess: async () => {
      setError(null)
      showSuccess(
        isTenantRealm
          ? 'Gym role permissions saved.'
          : 'Platform role permissions saved. Sidebar menus follow these grants.',
      )
      await queryClient.invalidateQueries({
        queryKey: isTenantRealm
          ? ['platform', 'tenant-roles', tenantId, activeRoleId, 'permissions']
          : ['platform', 'roles', activeRoleId, 'permissions'],
      })
      if (!isTenantRealm) {
        await queryClient.invalidateQueries({ queryKey: ['admin', 'me'] })
      }
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to save permissions.')
    },
  })

  const createMutation = useMutation({
    mutationFn: () => {
      const payload = {
        code: createCode.trim().toLowerCase(),
        name: createName.trim(),
      }
      return isTenantRealm
        ? createTenantRole(tenantId!, payload)
        : createPlatformRole(payload)
    },
    onSuccess: async (role) => {
      setError(null)
      showSuccess(`Role “${role.name}” created.`)
      setShowCreate(false)
      setCreateCode('')
      setCreateName('')
      await invalidateRoles()
      setSelectedRoleId(role.id)
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to create role.')
    },
  })

  const updateMutation = useMutation({
    mutationFn: () => {
      const payload = {
        name: editName.trim(),
        ...(selectedRole && !selectedRole.is_system
          ? { code: editCode.trim().toLowerCase() }
          : {}),
      }
      return isTenantRealm
        ? updateTenantRole(tenantId!, activeRoleId!, payload)
        : updatePlatformRole(activeRoleId!, payload)
    },
    onSuccess: async (role) => {
      setError(null)
      showSuccess(`Role “${role.name}” updated.`)
      await invalidateRoles()
      await queryClient.invalidateQueries({
        queryKey: isTenantRealm
          ? ['platform', 'tenant-roles', tenantId, activeRoleId, 'permissions']
          : ['platform', 'roles', activeRoleId, 'permissions'],
      })
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update role.')
    },
  })

  const deleteMutation = useMutation({
    mutationFn: () =>
      isTenantRealm
        ? deleteTenantRole(tenantId!, activeRoleId!)
        : deletePlatformRole(activeRoleId!),
    onSuccess: async () => {
      setError(null)
      showSuccess('Role deleted.')
      setSelectedRoleId(null)
      await invalidateRoles()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to delete role.')
    },
  })

  const seedMutation = useMutation({
    mutationFn: () =>
      isTenantRealm ? seedTenantRoles(tenantId!) : seedPlatformRoles(),
    onSuccess: async () => {
      setError(null)
      showSuccess(
        isTenantRealm
          ? 'Default gym roles seeded with permissions.'
          : 'Default platform roles seeded.',
      )
      await invalidateRoles()
      if (!isTenantRealm) {
        await queryClient.invalidateQueries({ queryKey: ['admin', 'me'] })
      }
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to seed roles.')
    },
  })

  const loading =
    (isTenantRealm && tenantsQuery.isLoading) ||
    (tenantReady && (rolesQuery.isLoading || permissionsQuery.isLoading))

  const toggleCode = (code: string) => {
    if (!canManage) return
    setDraftCodes((current) =>
      current.includes(code) ? current.filter((c) => c !== code) : [...current, code],
    )
  }

  const setMenuEnabled = (codes: string[], enabled: boolean) => {
    if (!canManage) return
    setDraftCodes((current) => {
      const next = new Set(current)
      for (const code of codes) {
        if (enabled) next.add(code)
        else next.delete(code)
      }
      return [...next]
    })
  }

  const onDeleteRole = async () => {
    if (!selectedRole || selectedRole.is_system) return
    const ok = await confirm({
      title: 'Delete role?',
      message: `Permanently delete “${selectedRole.name}” (${selectedRole.code})? This cannot be undone.`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (!ok) return
    deleteMutation.mutate()
  }

  const onSeed = async () => {
    if (isTenantRealm && tenantId == null) return
    const ok = await confirm({
      title: 'Seed default roles?',
      message: isTenantRealm
        ? 'Ensure standard gym roles exist for this tenant and reset their default permission grants. Custom roles are kept.'
        : 'Ensure Super Admin and Platform Support exist and reset their default permission grants. Custom roles are not removed.',
      confirmLabel: 'Seed defaults',
      tone: 'primary',
    })
    if (!ok) return
    seedMutation.mutate()
  }

  const selectedTenant = tenantsQuery.data?.find((t) => t.id === tenantId)

  return (
    <div className="animate-fade-up space-y-4">
      <PageHeader
        title="Roles & permissions"
        description="Manage Super Admin console roles and each gym’s staff roles from one place. Menu access follows these grants."
        actions={
          canManage ? (
            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                variant="secondary"
                loading={seedMutation.isPending}
                disabled={isTenantRealm && tenantId == null}
                onClick={() => void onSeed()}
              >
                <RefreshCw className="h-4 w-4" />
                Seed defaults
              </Button>
              <Button
                type="button"
                variant="secondary"
                disabled={isTenantRealm && tenantId == null}
                onClick={() => {
                  setShowCreate((open) => !open)
                  setError(null)
                }}
              >
                <Plus className="h-4 w-4" />
                New role
              </Button>
              <Button
                disabled={
                  activeRoleId == null ||
                  !dirtyPermissions ||
                  savePermissionsMutation.isPending ||
                  (isTenantRealm && tenantId == null)
                }
                loading={savePermissionsMutation.isPending}
                onClick={() => savePermissionsMutation.mutate()}
              >
                Save permissions
              </Button>
            </div>
          ) : (
            <Badge tone="neutral">View only</Badge>
          )
        }
      />

      <Card>
        <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <CardTitle className="text-base">Scope</CardTitle>
            <CardDescription>
              Switch between platform operators and a specific gym tenant.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-end gap-3">
            <div className="flex flex-wrap gap-2">
              {(
                [
                  { value: 'platform' as Realm, label: 'Platform console' },
                  { value: 'tenant' as Realm, label: 'Gym tenant' },
                ] as const
              ).map((option) => {
                const active = realm === option.value
                return (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setRealm(option.value)}
                    className={cn(
                      'rounded-xl px-3 py-2 text-sm font-semibold transition',
                      active
                        ? 'bg-accent text-accent-ink'
                        : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                    )}
                  >
                    {option.label}
                  </button>
                )
              })}
            </div>
            {isTenantRealm ? (
              <div className="min-w-[14rem]">
                <Label htmlFor="rbac-tenant">Gym</Label>
                <Select
                  id="rbac-tenant"
                  value={tenantId == null ? '' : String(tenantId)}
                  onChange={(e) =>
                    setTenantId(e.target.value ? Number(e.target.value) : null)
                  }
                >
                  <option value="">Select a gym…</option>
                  {(tenantsQuery.data ?? []).map((tenant) => (
                    <option key={tenant.id} value={tenant.id}>
                      {tenant.name} ({tenant.slug})
                    </option>
                  ))}
                </Select>
              </div>
            ) : null}
          </div>
        </div>
      </Card>

      {error ? (
        <Alert tone="danger">{error}</Alert>
      ) : null}

      {rolesQuery.isError || permissionsQuery.isError ? (
        <Alert tone="danger">
          Unable to load{' '}
          {isTenantRealm ? 'gym tenant' : 'platform'} roles or permissions.
        </Alert>
      ) : null}

      {showCreate && canManage && tenantReady ? (
        <Card className="border-accent/25">
          <CardTitle>
            {isTenantRealm ? 'Create gym role' : 'Create platform role'}
          </CardTitle>
          <CardDescription>
            {isTenantRealm
              ? `Custom staff role for ${selectedTenant?.name ?? 'this gym'}.`
              : 'Custom roles can receive any platform permission set.'}
          </CardDescription>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              const errors = collectRequiredErrors([
                { key: 'code', label: 'Code', value: createCode },
                { key: 'name', label: 'Name', value: createName },
              ])
              if (Object.keys(errors).length > 0) {
                setFieldErrors(errors)
                return
              }
              setFieldErrors({})
              createMutation.mutate()
            }}
            noValidate
            className="mt-4 grid gap-3 sm:grid-cols-2"
          >
            <Field label="Code" htmlFor="role-code" required error={fieldErrors.code}>
              <Input
                id="role-code"
                value={createCode}
                onChange={(e) => {
                  setCreateCode(e.target.value)
                  clearFieldError('code')
                }}
                placeholder={isTenantRealm ? 'floor_lead' : 'platform_ops'}
                className="font-mono"
                aria-invalid={Boolean(fieldErrors.code)}
              />
            </Field>
            <Field label="Name" htmlFor="role-name" required error={fieldErrors.name}>
              <Input
                id="role-name"
                value={createName}
                onChange={(e) => {
                  setCreateName(e.target.value)
                  clearFieldError('name')
                }}
                placeholder={isTenantRealm ? 'Floor Lead' : 'Platform Operations'}
                aria-invalid={Boolean(fieldErrors.name)}
              />
            </Field>
            <div className="mt-4 flex flex-wrap gap-2 sm:col-span-2">
              <Button type="submit" loading={createMutation.isPending}>
                Create role
              </Button>
              <Button type="button" variant="ghost" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      {isTenantRealm && tenantId == null ? (
        <Alert tone="info">Select a gym tenant to manage its roles and permissions.</Alert>
      ) : null}

      {loading ? (
        <div className="flex justify-center py-20">
          <Spinner
            label={
              isTenantRealm ? 'Loading gym RBAC…' : 'Loading platform RBAC…'
            }
          />
        </div>
      ) : tenantReady ? (
        <div className="grid gap-4 xl:grid-cols-[16rem_1fr]">
          <Card>
            <CardTitle>All roles</CardTitle>
            <CardDescription>
              {rolesQuery.data?.length ?? 0}{' '}
              {isTenantRealm ? 'gym' : 'platform'} role(s)
              {isTenantRealm && selectedTenant ? ` · ${selectedTenant.name}` : ''}
            </CardDescription>
            <ul className="mt-4 max-h-[32rem] space-y-1 overflow-y-auto">
              {(rolesQuery.data ?? []).map((role) => (
                <li key={role.id}>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedRoleId(role.id)
                      setError(null)
                    }}
                    className={cn(
                      'flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-sm transition',
                      activeRoleId === role.id
                        ? 'bg-accent text-accent-ink'
                        : 'hover:bg-white/10',
                    )}
                  >
                    <span className="font-medium">{role.name}</span>
                    {role.is_system ? (
                      <span className="text-[10px] uppercase opacity-70">System</span>
                    ) : null}
                  </button>
                </li>
              ))}
            </ul>
          </Card>

          <div className="space-y-4">
            <Card>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <CardTitle>{selectedRole?.name ?? 'Role details'}</CardTitle>
                  <CardDescription>
                    {selectedRole
                      ? `${selectedRole.is_system ? 'System role' : 'Custom role'} · ${selectedRole.code}`
                      : 'Choose a role'}
                  </CardDescription>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Badge tone={isTenantRealm ? 'warning' : 'accent'}>
                    {isTenantRealm ? 'Gym' : 'Platform'}
                  </Badge>
                  {selectedRole?.is_system ? <Badge tone="neutral">Protected</Badge> : null}
                </div>
              </div>

              {canManage && selectedRole ? (
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div>
                    <Label htmlFor="edit-role-name">Display name</Label>
                    <Input
                      id="edit-role-name"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-role-code">Code</Label>
                    <Input
                      id="edit-role-code"
                      value={editCode}
                      onChange={(e) => setEditCode(e.target.value)}
                      disabled={selectedRole.is_system}
                      className="font-mono"
                    />
                  </div>
                  <div className="flex flex-wrap gap-2 sm:col-span-2">
                    <Button
                      type="button"
                      variant="secondary"
                      disabled={!dirtyMeta || updateMutation.isPending}
                      loading={updateMutation.isPending}
                      onClick={() => updateMutation.mutate()}
                    >
                      Save role details
                    </Button>
                    {!selectedRole.is_system ? (
                      <Button
                        type="button"
                        variant="danger"
                        disabled={deleteMutation.isPending}
                        loading={deleteMutation.isPending}
                        onClick={() => void onDeleteRole()}
                      >
                        <Trash2 className="h-4 w-4" />
                        Delete role
                      </Button>
                    ) : null}
                  </div>
                </div>
              ) : null}
            </Card>

            <Card>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <CardTitle>
                    {isTenantRealm ? 'Module permissions' : 'Menus & permissions'}
                  </CardTitle>
                  <CardDescription>
                    {selectedRole
                      ? `${draftCodes.length} permission(s) enabled${dirtyPermissions && canManage ? ' · unsaved changes' : ''}`
                      : 'Choose a role'}
                  </CardDescription>
                </div>
                <Badge tone="accent">
                  {isTenantRealm ? 'Gym admin portal' : 'Sidebar ↔ grants'}
                </Badge>
              </div>

              {rolePermsQuery.isLoading && activeRoleId != null ? (
                <div className="flex justify-center py-12">
                  <Spinner label="Loading role permissions…" />
                </div>
              ) : isTenantRealm ? (
                <div className="mt-4 space-y-5">
                  {tenantGroupedPermissions.map(([module, perms]) => (
                    <div key={module}>
                      <p className="mb-2 font-display text-xs font-bold uppercase tracking-[0.14em] text-accent">
                        {module.replaceAll('_', ' ')}
                      </p>
                      <ul className="grid gap-2 sm:grid-cols-2">
                        {(perms ?? []).map((perm) => {
                          const checked = draftCodes.includes(perm.code)
                          return (
                            <li key={perm.id}>
                              <label
                                className={cn(
                                  'flex cursor-pointer items-start gap-3 rounded-xl border border-white/12 px-3 py-2.5 text-sm transition',
                                  checked ? 'bg-white/10' : 'bg-white/4 hover:bg-white/8',
                                  !canManage && 'cursor-default',
                                )}
                              >
                                <input
                                  type="checkbox"
                                  className="mt-1"
                                  checked={checked}
                                  disabled={!canManage}
                                  onChange={() => toggleCode(perm.code)}
                                />
                                <span>
                                  <span className="block font-medium text-ink">{perm.name}</span>
                                  <span className="block text-xs text-muted">{perm.code}</span>
                                </span>
                              </label>
                            </li>
                          )
                        })}
                      </ul>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="mt-6 space-y-8">
                  {platformMenuGroups.map((group) => (
                    <section key={group.section}>
                      <h3 className="font-display text-xs font-bold uppercase tracking-[0.16em] text-accent">
                        {group.section}
                      </h3>
                      <ul className="mt-3 space-y-3">
                        {group.menus.map((menu) => {
                          const codes = menu.permissions.map((p) => p.code)
                          const anyOn = codes.some((c) => draftCodes.includes(c))

                          return (
                            <li
                              key={menu.label}
                              className="rounded-2xl border border-white/12 bg-white/[0.04] px-4 py-4"
                            >
                              <div className="flex flex-wrap items-start justify-between gap-3">
                                <div>
                                  <p className="font-semibold text-ink">{menu.label}</p>
                                  <p className="mt-0.5 text-xs text-muted">{menu.description}</p>
                                </div>
                                {canManage ? (
                                  <button
                                    type="button"
                                    onClick={() => setMenuEnabled(codes, !anyOn)}
                                    className={cn(
                                      'rounded-lg px-3 py-1.5 text-xs font-semibold uppercase tracking-wide transition',
                                      anyOn
                                        ? 'bg-accent/20 text-accent'
                                        : 'bg-white/10 text-muted hover:text-ink',
                                    )}
                                  >
                                    {anyOn ? 'Enabled' : 'Disabled'}
                                  </button>
                                ) : null}
                              </div>

                              <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                                {menu.permissions.map((perm) => {
                                  const checked = draftCodes.includes(perm.code)
                                  const known = codeToId.has(perm.code)
                                  return (
                                    <li key={perm.code}>
                                      <label
                                        className={cn(
                                          'flex items-start gap-3 rounded-xl border border-white/10 px-3 py-2.5 text-sm transition',
                                          checked ? 'bg-white/10' : 'bg-transparent hover:bg-white/6',
                                          canManage && known ? 'cursor-pointer' : 'cursor-default',
                                          !known && 'opacity-50',
                                        )}
                                      >
                                        <input
                                          type="checkbox"
                                          className="mt-1"
                                          checked={checked}
                                          disabled={!canManage || !known}
                                          onChange={() => toggleCode(perm.code)}
                                        />
                                        <span>
                                          <span className="block font-medium text-ink">
                                            {perm.label}
                                          </span>
                                          <span className="block text-xs text-muted">
                                            {perm.code}
                                          </span>
                                        </span>
                                      </label>
                                    </li>
                                  )
                                })}
                              </ul>
                            </li>
                          )
                        })}
                      </ul>
                    </section>
                  ))}

                  {extraPermissions.length > 0 ? (
                    <section>
                      <h3 className="font-display text-xs font-bold uppercase tracking-[0.16em] text-accent">
                        Other platform permissions
                      </h3>
                      <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                        {extraPermissions.map((perm) => {
                          const checked = draftCodes.includes(perm.code)
                          return (
                            <li key={perm.id}>
                              <label
                                className={cn(
                                  'flex items-start gap-3 rounded-xl border border-white/10 px-3 py-2.5 text-sm transition',
                                  checked ? 'bg-white/10' : 'bg-transparent hover:bg-white/6',
                                  canManage ? 'cursor-pointer' : 'cursor-default',
                                )}
                              >
                                <input
                                  type="checkbox"
                                  className="mt-1"
                                  checked={checked}
                                  disabled={!canManage}
                                  onChange={() => toggleCode(perm.code)}
                                />
                                <span>
                                  <span className="block font-medium text-ink">{perm.name}</span>
                                  <span className="block text-xs text-muted">{perm.code}</span>
                                </span>
                              </label>
                            </li>
                          )
                        })}
                      </ul>
                    </section>
                  ) : null}
                </div>
              )}
            </Card>
          </div>
        </div>
      ) : null}
    </div>
  )
}
