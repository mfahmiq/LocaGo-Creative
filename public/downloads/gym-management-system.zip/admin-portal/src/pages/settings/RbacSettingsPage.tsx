import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Plus, RefreshCw, Trash2 } from 'lucide-react'
import {
  createRole,
  deleteRole,
  fetchPermissions,
  fetchRolePermissions,
  fetchRoles,
  seedRoles,
  syncRolePermissions,
  updateRole,
} from '@/api/rbac'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Spinner } from '@/components/ui/Spinner'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { ApiError } from '@/api/client'
import { cn } from '@/lib/cn'

export function RbacSettingsPage() {
  const { hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canManageRoles = hasPermission('identity.roles.manage')
  const canManagePermissions = hasPermission('identity.permissions.manage')
  const canManage = canManageRoles || canManagePermissions

  const rolesQuery = useQuery({ queryKey: ['admin', 'roles'], queryFn: fetchRoles })
  const permissionsQuery = useQuery({
    queryKey: ['admin', 'permissions'],
    queryFn: fetchPermissions,
  })

  const [selectedRoleId, setSelectedRoleId] = useState<number | null>(null)
  const [draftIds, setDraftIds] = useState<number[]>([])
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }
  const [showCreate, setShowCreate] = useState(false)
  const [createCode, setCreateCode] = useState('')
  const [createName, setCreateName] = useState('')
  const [editName, setEditName] = useState('')
  const [editCode, setEditCode] = useState('')

  const activeRoleId = selectedRoleId ?? rolesQuery.data?.[0]?.id ?? null

  const rolePermsQuery = useQuery({
    queryKey: ['admin', 'roles', activeRoleId, 'permissions'],
    queryFn: () => fetchRolePermissions(activeRoleId!),
    enabled: activeRoleId != null,
  })

  useEffect(() => {
    if (selectedRoleId == null && rolesQuery.data?.[0]?.id != null) {
      setSelectedRoleId(rolesQuery.data[0].id)
    }
  }, [rolesQuery.data, selectedRoleId])

  useEffect(() => {
    if (rolePermsQuery.data && activeRoleId === rolePermsQuery.data.role.id) {
      setDraftIds(rolePermsQuery.data.permissions.map((p) => p.id))
      setEditName(rolePermsQuery.data.role.name)
      setEditCode(rolePermsQuery.data.role.code)
    }
  }, [rolePermsQuery.data, activeRoleId])

  const selectedRole =
    rolesQuery.data?.find((r) => r.id === activeRoleId) ?? rolePermsQuery.data?.role ?? null

  const grouped = useMemo(() => {
    const map = new Map<string, NonNullable<typeof permissionsQuery.data>>()
    for (const perm of permissionsQuery.data ?? []) {
      if (perm.module.startsWith('platform') || perm.module === 'member_portal') {
        continue
      }
      const list = map.get(perm.module) ?? []
      list.push(perm)
      map.set(perm.module, list)
    }
    return [...map.entries()].sort(([a], [b]) => a.localeCompare(b))
  }, [permissionsQuery.data])

  const savedIds = useMemo(
    () => new Set(rolePermsQuery.data?.permissions.map((p) => p.id) ?? []),
    [rolePermsQuery.data],
  )

  const dirtyPermissions = useMemo(() => {
    if (draftIds.length !== savedIds.size) return true
    return draftIds.some((id) => !savedIds.has(id))
  }, [draftIds, savedIds])

  const dirtyMeta = useMemo(() => {
    if (!selectedRole) return false
    if (editName.trim() !== selectedRole.name) return true
    if (!selectedRole.is_system && editCode.trim().toLowerCase() !== selectedRole.code) {
      return true
    }
    return false
  }, [selectedRole, editName, editCode])

  const invalidateRoles = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'roles'] })
  }

  const saveMutation = useMutation({
    mutationFn: () => syncRolePermissions(activeRoleId!, draftIds),
    onSuccess: () => {
      setError(null)
      showSuccess('Role permissions updated.')
      void queryClient.invalidateQueries({ queryKey: ['admin', 'roles', activeRoleId, 'permissions'] })
      void queryClient.invalidateQueries({ queryKey: ['admin', 'me'] })
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to save permissions.')
    },
  })

  const createMutation = useMutation({
    mutationFn: () =>
      createRole({
        code: createCode.trim().toLowerCase(),
        name: createName.trim(),
      }),
    onSuccess: async (role) => {
      setError(null)
      showSuccess(`Role “${role.name}” created.`)
      setShowCreate(false)
      setCreateCode('')
      setCreateName('')
      await invalidateRoles()
      setSelectedRoleId(role.id)
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to create role.')
    },
  })

  const updateMutation = useMutation({
    mutationFn: () =>
      updateRole(activeRoleId!, {
        name: editName.trim(),
        ...(selectedRole && !selectedRole.is_system
          ? { code: editCode.trim().toLowerCase() }
          : {}),
      }),
    onSuccess: async (role) => {
      setError(null)
      showSuccess(`Role “${role.name}” updated.`)
      await invalidateRoles()
      await queryClient.invalidateQueries({
        queryKey: ['admin', 'roles', activeRoleId, 'permissions'],
      })
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update role.')
    },
  })

  const deleteMutation = useMutation({
    mutationFn: () => deleteRole(activeRoleId!),
    onSuccess: async () => {
      setError(null)
      showSuccess('Role deleted.')
      setSelectedRoleId(null)
      await invalidateRoles()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to delete role.')
    },
  })

  const seedMutation = useMutation({
    mutationFn: seedRoles,
    onSuccess: async () => {
      setError(null)
      showSuccess('Default roles seeded with permissions.')
      await invalidateRoles()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'me'] })
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to seed roles.')
    },
  })

  const loading = rolesQuery.isLoading || permissionsQuery.isLoading

  const selectRole = (id: number) => {
    setSelectedRoleId(id)
    setError(null)
  }

  const togglePermission = (id: number) => {
    if (!canManagePermissions) return
    setDraftIds((current) =>
      current.includes(id) ? current.filter((x) => x !== id) : [...current, id],
    )
  }

  const onDeleteRole = async () => {
    if (!selectedRole || selectedRole.is_system) return
    const ok = await confirm({
      title: 'Delete role?',
      message: `Delete “${selectedRole.name}”? Staff with only this role may lose access.`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (ok) deleteMutation.mutate()
  }

  const onSeed = async () => {
    const ok = await confirm({
      title: 'Seed default roles?',
      message: 'Creates missing system roles and restores their default permission sets.',
      confirmLabel: 'Seed defaults',
      tone: 'primary',
    })
    if (ok) seedMutation.mutate()
  }

  return (
    <div className="animate-fade-up space-y-4">
      <PageHeader
        title="Roles & permissions"
        description="Manage gym staff roles and module permissions. Sidebar menus follow these grants."
        actions={
          canManage ? (
            <div className="flex flex-wrap gap-2">
              {canManageRoles ? (
                <>
                  <Button
                    type="button"
                    variant="secondary"
                    loading={seedMutation.isPending}
                    onClick={() => void onSeed()}
                  >
                    <RefreshCw className="h-4 w-4" />
                    Seed defaults
                  </Button>
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => {
                      setShowCreate((open) => !open)
                      setError(null)
                    }}
                  >
                    <Plus className="h-4 w-4" />
                    New role
                  </Button>
                </>
              ) : null}
              {canManagePermissions ? (
                <Button
                  disabled={
                    activeRoleId == null || !dirtyPermissions || saveMutation.isPending
                  }
                  loading={saveMutation.isPending}
                  onClick={() => saveMutation.mutate()}
                >
                  Save permissions
                </Button>
              ) : null}
            </div>
          ) : (
            <Badge tone="neutral">View only</Badge>
          )
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      {rolesQuery.isError || permissionsQuery.isError ? (
        <Alert tone="danger">Unable to load roles or permissions.</Alert>
      ) : null}

      {showCreate && canManageRoles ? (
        <Card className="border-accent/25">
          <CardTitle>Create role</CardTitle>
          <CardDescription>Custom staff role for this gym.</CardDescription>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              const errors = collectRequiredErrors([
                { key: 'code', label: 'Code', value: createCode },
                { key: 'name', label: 'Name', value: createName },
              ])
              if (Object.keys(errors).length > 0) {
                setFieldErrors(errors)
                return
              }
              setFieldErrors({})
              createMutation.mutate()
            }}
            noValidate
            className="mt-4 grid gap-3 sm:grid-cols-2"
          >
            <Field label="Code" htmlFor="role-code" required error={fieldErrors.code}>
              <Input
                id="role-code"
                value={createCode}
                onChange={(e) => {
                  setCreateCode(e.target.value)
                  clearFieldError('code')
                }}
                placeholder="floor_lead"
                className="font-mono"
                aria-invalid={Boolean(fieldErrors.code)}
              />
            </Field>
            <Field label="Name" htmlFor="role-name" required error={fieldErrors.name}>
              <Input
                id="role-name"
                value={createName}
                onChange={(e) => {
                  setCreateName(e.target.value)
                  clearFieldError('name')
                }}
                placeholder="Floor Lead"
                aria-invalid={Boolean(fieldErrors.name)}
              />
            </Field>
            <div className="mt-4 flex flex-wrap gap-2 sm:col-span-2">
              <Button type="submit" loading={createMutation.isPending}>
                Create role
              </Button>
              <Button type="button" variant="ghost" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      {loading ? (
        <div className="flex justify-center py-20">
          <Spinner label="Loading roles & permissions…" />
        </div>
      ) : (
        <div className="grid gap-4 xl:grid-cols-[16rem_1fr]">
          <Card>
            <CardTitle>All roles</CardTitle>
            <CardDescription>{rolesQuery.data?.length ?? 0} role(s)</CardDescription>
            <ul className="mt-4 max-h-[32rem] space-y-1 overflow-y-auto">
              {(rolesQuery.data ?? []).map((role) => (
                <li key={role.id}>
                  <button
                    type="button"
                    onClick={() => selectRole(role.id)}
                    className={cn(
                      'flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-sm transition',
                      activeRoleId === role.id
                        ? 'bg-accent text-accent-ink'
                        : 'hover:bg-white/10',
                    )}
                  >
                    <span className="font-medium">{role.name}</span>
                    {role.is_system ? (
                      <span className="text-[10px] uppercase opacity-70">System</span>
                    ) : null}
                  </button>
                </li>
              ))}
            </ul>
          </Card>

          <div className="space-y-4">
            <Card>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <CardTitle>{selectedRole?.name ?? 'Role details'}</CardTitle>
                  <CardDescription>
                    {selectedRole
                      ? `${selectedRole.is_system ? 'System role' : 'Custom role'} · ${selectedRole.code}`
                      : 'Choose a role'}
                  </CardDescription>
                </div>
                {selectedRole?.is_system ? <Badge tone="neutral">Protected</Badge> : null}
              </div>

              {canManageRoles && selectedRole ? (
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div>
                    <Label htmlFor="edit-role-name">Display name</Label>
                    <Input
                      id="edit-role-name"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-role-code">Code</Label>
                    <Input
                      id="edit-role-code"
                      value={editCode}
                      onChange={(e) => setEditCode(e.target.value)}
                      disabled={selectedRole.is_system}
                      className="font-mono"
                    />
                  </div>
                  <div className="flex flex-wrap gap-2 sm:col-span-2">
                    <Button
                      type="button"
                      variant="secondary"
                      disabled={!dirtyMeta || updateMutation.isPending}
                      loading={updateMutation.isPending}
                      onClick={() => updateMutation.mutate()}
                    >
                      Save role details
                    </Button>
                    {!selectedRole.is_system ? (
                      <Button
                        type="button"
                        variant="danger"
                        disabled={deleteMutation.isPending}
                        loading={deleteMutation.isPending}
                        onClick={() => void onDeleteRole()}
                      >
                        <Trash2 className="h-4 w-4" />
                        Delete role
                      </Button>
                    ) : null}
                  </div>
                </div>
              ) : null}
            </Card>

            <Card>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <CardTitle>Module permissions</CardTitle>
                  <CardDescription>
                    {selectedRole
                      ? `${draftIds.length} permission(s) enabled${dirtyPermissions && canManagePermissions ? ' · unsaved changes' : ''}`
                      : 'Choose a role'}
                  </CardDescription>
                </div>
                <Badge tone="accent">Sidebar ↔ grants</Badge>
              </div>

              {rolePermsQuery.isLoading && activeRoleId != null ? (
                <div className="flex justify-center py-12">
                  <Spinner label="Loading role permissions…" />
                </div>
              ) : (
                <div className="mt-4 space-y-5">
                  {grouped.map(([module, perms]) => (
                    <div key={module}>
                      <p className="mb-2 font-display text-xs font-bold uppercase tracking-[0.14em] text-accent">
                        {module.replaceAll('_', ' ')}
                      </p>
                      <ul className="grid gap-2 sm:grid-cols-2">
                        {(perms ?? []).map((perm) => {
                          const checked = draftIds.includes(perm.id)
                          return (
                            <li key={perm.id}>
                              <label
                                className={cn(
                                  'flex cursor-pointer items-start gap-3 rounded-xl border border-white/12 px-3 py-2.5 text-sm transition',
                                  checked ? 'bg-white/10' : 'bg-white/4 hover:bg-white/8',
                                  !canManagePermissions && 'cursor-default',
                                )}
                              >
                                <input
                                  type="checkbox"
                                  className="mt-1"
                                  checked={checked}
                                  disabled={!canManagePermissions}
                                  onChange={() => togglePermission(perm.id)}
                                />
                                <span>
                                  <span className="block font-medium text-ink">{perm.name}</span>
                                  <span className="block text-xs text-muted">{perm.code}</span>
                                </span>
                              </label>
                            </li>
                          )
                        })}
                      </ul>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}
