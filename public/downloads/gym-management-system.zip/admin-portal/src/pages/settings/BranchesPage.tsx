import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Building2,
  MapPin,
  Plus,
  Power,
  RefreshCw,
  Search,
  Trash2,
  Users,
  X,
} from 'lucide-react'
import {
  changeBranchStatus,
  createBranch,
  deleteBranch,
  fetchBranch,
  fetchBranches,
  fetchEntitlements,
  syncBranchStaff,
  updateBranch,
  type Branch,
  type BranchPayload,
} from '@/api/branches'
import { fetchStaff } from '@/api/staff'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'

type ActiveFilter = '' | 'active' | 'inactive'

const emptyForm: BranchPayload = {
  code: '',
  name: '',
  phone: '',
  email: '',
  address_line1: '',
  address_line2: '',
  city: '',
  state: '',
  postal_code: '',
  country_code: 'IN',
  timezone: 'Asia/Kolkata',
  capacity: null,
  is_active: true,
}

function branchToForm(branch: Branch): BranchPayload {
  return {
    code: branch.code,
    name: branch.name,
    phone: branch.phone ?? '',
    email: branch.email ?? '',
    address_line1: branch.address_line1 ?? '',
    address_line2: branch.address_line2 ?? '',
    city: branch.city ?? '',
    state: branch.state ?? '',
    postal_code: branch.postal_code ?? '',
    country_code: branch.country_code || 'IN',
    timezone: branch.timezone ?? '',
    capacity: branch.capacity,
    is_active: branch.is_active,
  }
}

function cleanPayload(form: BranchPayload): BranchPayload {
  const blank = (v: string | null | undefined) => {
    const t = (v ?? '').trim()
    return t === '' ? null : t
  }
  return {
    code: form.code.trim().toUpperCase(),
    name: form.name.trim(),
    phone: blank(form.phone),
    email: blank(form.email),
    address_line1: blank(form.address_line1),
    address_line2: blank(form.address_line2),
    city: blank(form.city),
    state: blank(form.state),
    postal_code: blank(form.postal_code),
    country_code: (form.country_code || 'IN').trim().toUpperCase(),
    timezone: blank(form.timezone),
    capacity: form.capacity != null && Number(form.capacity) > 0 ? Number(form.capacity) : null,
    is_active: form.is_active ?? true,
  }
}

function locationLabel(branch: Branch) {
  return [branch.city, branch.state, branch.country_code].filter(Boolean).join(', ') || '—'
}

export function BranchesPage() {
  const { tenant, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('organization.branches.view')
  const canManage = hasPermission('organization.branches.manage')
  const canViewStaff = hasPermission('identity.staff.view') || hasPermission('identity.staff.manage')
  const canViewEntitlements = hasPermission('entitlements.view')

  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [activeFilter, setActiveFilter] = useState<ActiveFilter>('')
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  const [createForm, setCreateForm] = useState<BranchPayload>({
    ...emptyForm,
    country_code: tenant?.primary_country || 'IN',
    timezone: tenant?.timezone || 'Asia/Kolkata',
  })
  const [editForm, setEditForm] = useState<BranchPayload>(emptyForm)
  const [staffIds, setStaffIds] = useState<number[]>([])
  const [error, setError] = useState<string | null>(null)
  const [createFieldErrors, setCreateFieldErrors] = useState<FieldErrors>({})
  const [editFieldErrors, setEditFieldErrors] = useState<FieldErrors>({})

  const errMsg = (err: unknown, fallback: string) => {
    if (err instanceof ApiError) return err.message
    if (err instanceof Error && err.message) return err.message
    return fallback
  }

  const listQuery = useQuery({
    queryKey: ['admin', 'branches', page, appliedSearch, activeFilter],
    queryFn: () =>
      fetchBranches({
        page,
        per_page: DEFAULT_PAGE_SIZE,
        search: appliedSearch,
        is_active:
          activeFilter === 'active' ? true : activeFilter === 'inactive' ? false : '',
      }),
    enabled: canView,
  })

  const detailQuery = useQuery({
    queryKey: ['admin', 'branches', 'detail', selectedId],
    queryFn: () => fetchBranch(selectedId!),
    enabled: canView && selectedId != null,
  })

  const staffQuery = useQuery({
    queryKey: ['admin', 'staff', 'branch-assign'],
    queryFn: () => fetchStaff({ page: 1, per_page: 100, is_active: true }),
    enabled: canView && canViewStaff && selectedId != null,
  })

  const entitlementsQuery = useQuery({
    queryKey: ['admin', 'entitlements'],
    queryFn: fetchEntitlements,
    enabled: canView && canViewEntitlements,
  })

  const selected = detailQuery.data ?? null

  useEffect(() => {
    if (selected) {
      setEditForm(branchToForm(selected))
      setStaffIds((selected.staff ?? []).map((s) => s.id))
    }
  }, [selected])

  const invalidate = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['admin', 'branches'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'me'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'entitlements'] }),
    ])
  }

  const createMutation = useMutation({
    mutationFn: () => createBranch(cleanPayload(createForm)),
    onSuccess: async (row) => {
      setError(null)
      showSuccess(`Branch “${row.name}” created.`)
      setShowCreate(false)
      setCreateForm({
        ...emptyForm,
        country_code: tenant?.primary_country || 'IN',
        timezone: tenant?.timezone || 'Asia/Kolkata',
      })
      await invalidate()
      setSelectedId(row.id)
      setPage(1)
    },
    onError: (err) => setError(errMsg(err, 'Unable to create branch.')),
  })

  const updateMutation = useMutation({
    mutationFn: () => updateBranch(selectedId!, cleanPayload(editForm)),
    onSuccess: async (row) => {
      setError(null)
      showSuccess(`Branch “${row.name}” updated.`)
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'branches', 'detail', selectedId] })
    },
    onError: (err) => setError(errMsg(err, 'Unable to update branch.')),
  })

  const statusMutation = useMutation({
    mutationFn: (isActive: boolean) => changeBranchStatus(selectedId!, isActive),
    onSuccess: async (row) => {
      setError(null)
      showSuccess(row.is_active ? 'Branch activated.' : 'Branch deactivated.')
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'branches', 'detail', selectedId] })
    },
    onError: (err) => setError(errMsg(err, 'Unable to change branch status.')),
  })

  const deleteMutation = useMutation({
    mutationFn: () => deleteBranch(selectedId!),
    onSuccess: async () => {
      setError(null)
      showSuccess('Branch deleted.')
      setSelectedId(null)
      await invalidate()
    },
    onError: (err) => setError(errMsg(err, 'Unable to delete branch.')),
  })

  const staffMutation = useMutation({
    mutationFn: () => syncBranchStaff(selectedId!, staffIds),
    onSuccess: async () => {
      setError(null)
      showSuccess('Staff assignments saved.')
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'branches', 'detail', selectedId] })
      await queryClient.invalidateQueries({ queryKey: ['admin', 'staff'] })
    },
    onError: (err) => setError(errMsg(err, 'Unable to save staff assignments.')),
  })

  const rows = listQuery.data?.data ?? []
  const meta = listQuery.data?.meta
  const summary = listQuery.data?.summary
  const usage = entitlementsQuery.data?.usage.branches
  const limit = entitlementsQuery.data?.limits?.max_branches

  const staffDirty = useMemo(() => {
    if (!selected) return false
    const current = new Set((selected.staff ?? []).map((s) => s.id))
    if (current.size !== staffIds.length) return true
    return staffIds.some((id) => !current.has(id))
  }, [selected, staffIds])

  const editDirty = useMemo(() => {
    if (!selected) return false
    const cleaned = cleanPayload(editForm)
    const original = cleanPayload(branchToForm(selected))
    return JSON.stringify(cleaned) !== JSON.stringify(original)
  }, [selected, editForm])

  const onCreate = (e: FormEvent) => {
    e.preventDefault()
    const next = collectRequiredErrors([
      { key: 'code', label: 'Code', value: createForm.code },
      { key: 'name', label: 'Name', value: createForm.name },
    ])
    setCreateFieldErrors(next)
    if (Object.keys(next).length) return
    createMutation.mutate()
  }

  const onDelete = async () => {
    if (!selected) return
    const ok = await confirm({
      title: 'Delete branch?',
      message: `Delete “${selected.name}” (${selected.code})? Staff assignments for this branch will be cleared.`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (ok) deleteMutation.mutate()
  }

  const onToggleStatus = async () => {
    if (!selected) return
    const next = !selected.is_active
    const ok = await confirm({
      title: next ? 'Activate branch?' : 'Deactivate branch?',
      message: next
        ? `Activate “${selected.name}” for operations?`
        : `Deactivate “${selected.name}”? New check-ins and schedules should use another branch.`,
      confirmLabel: next ? 'Activate' : 'Deactivate',
      tone: next ? 'primary' : 'danger',
    })
    if (ok) statusMutation.mutate(next)
  }

  const columns: Column<Branch>[] = [
    {
      key: 'branch',
      header: 'Branch',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">{row.name}</p>
          <p className="mt-0.5 font-mono text-xs text-muted">{row.code}</p>
        </button>
      ),
    },
    {
      key: 'location',
      header: 'Location',
      cell: (row) => (
        <div className="flex items-start gap-2">
          <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted" />
          <span className="text-sm text-muted">{locationLabel(row)}</span>
        </div>
      ),
    },
    {
      key: 'contact',
      header: 'Contact',
      cell: (row) => (
        <div className="text-sm">
          <p className="text-ink">{row.phone || '—'}</p>
          <p className="text-xs text-muted">{row.email || '—'}</p>
        </div>
      ),
    },
    {
      key: 'staff',
      header: 'Staff',
      cell: (row) => (
        <span className="tabular-nums text-sm font-medium">
          {formatNumber(row.staff_count ?? 0)}
        </span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.is_active ? 'success' : 'neutral'}>
          {row.is_active ? 'Active' : 'Inactive'}
        </Badge>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedId(row.id)}>
          Manage
        </Button>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader
          title="Branches"
          description="Branch directory and staff assignment."
        />
        <Alert tone="danger">
          Your role needs <code>organization.branches.view</code> to open branches.
        </Alert>
      </div>
    )
  }

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Branches"
        description="Manage gym locations, capacity, and which staff can work at each branch."
        actions={
          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              variant="secondary"
              loading={listQuery.isFetching}
              onClick={() => void listQuery.refetch()}
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
            {canManage ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowCreate((v) => !v)
                  setError(null)
                  setCreateFieldErrors({})
                }}
              >
                <Plus className="h-4 w-4" />
                New branch
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}
      {listQuery.isError ? (
        <Alert tone="danger">{errMsg(listQuery.error, 'Unable to load branches.')}</Alert>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<Building2 className="h-4 w-4" />}
          label="Total branches"
          value={formatNumber(summary?.total ?? 0)}
        />
        <SummaryChip
          icon={<Power className="h-4 w-4" />}
          label="Active"
          value={formatNumber(summary?.active ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<Power className="h-4 w-4" />}
          label="Inactive"
          value={formatNumber(summary?.inactive ?? 0)}
        />
        <SummaryChip
          icon={<Users className="h-4 w-4" />}
          label="Plan usage"
          value={
            limit != null && usage != null
              ? `${formatNumber(usage)} / ${formatNumber(limit)}`
              : '—'
          }
        />
      </div>

      {showCreate && canManage ? (
        <Card className="border-accent/25">
          <CardTitle>Create branch</CardTitle>
          <CardDescription>
            New locations count toward your SaaS branch limit
            {limit != null ? ` (${usage ?? 0}/${limit})` : ''}.
          </CardDescription>
          <form noValidate className="mt-4 grid gap-3 sm:grid-cols-2" onSubmit={onCreate}>
            <BranchFields
              form={createForm}
              onChange={setCreateForm}
              idPrefix="create"
              fieldErrors={createFieldErrors}
              onClearError={(key) =>
                setCreateFieldErrors((errs) => {
                  const n = { ...errs }
                  delete n[key]
                  return n
                })
              }
            />
            <div className="flex flex-wrap gap-2 sm:col-span-2">
              <Button type="submit" loading={createMutation.isPending}>
                Create branch
              </Button>
              <Button type="button" variant="ghost" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <Card>
        <div className="mb-4 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2">
            {(
              [
                { value: '' as ActiveFilter, label: 'All' },
                { value: 'active' as ActiveFilter, label: 'Active' },
                { value: 'inactive' as ActiveFilter, label: 'Inactive' },
              ] as const
            ).map((filter) => {
              const active = activeFilter === filter.value
              return (
                <button
                  key={filter.label}
                  type="button"
                  onClick={() => {
                    setActiveFilter(filter.value)
                    setPage(1)
                    setSelectedId(null)
                  }}
                  className={cn(
                    'rounded-xl px-3 py-2 text-sm font-semibold transition',
                    active
                      ? 'bg-accent text-accent-ink'
                      : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                  )}
                >
                  {filter.label}
                </button>
              )
            })}
          </div>
          <div className="relative min-w-[16rem]">
            <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  setAppliedSearch(search.trim())
                  setPage(1)
                }
              }}
              placeholder="Search name, code, city…"
              className="pl-10"
            />
          </div>
        </div>

        <div className={cn('grid gap-4', selected ? 'xl:grid-cols-[1fr_26rem]' : '')}>
          <div className="min-w-0">
            {listQuery.isPending ? (
              <div className="flex justify-center py-16">
                <Spinner label="Loading branches…" />
              </div>
            ) : (
              <>
                <DataTable
                  columns={columns}
                  rows={rows}
                  rowKey={(row) => row.id}
                  emptyTitle="No branches found"
                  emptyDescription="Create a branch to start multi-location operations."
                />
                <Pagination
                  meta={meta}
                  onPageChange={(next) => {
                    setPage(next)
                    setSelectedId(null)
                  }}
                />
              </>
            )}
          </div>

          {selectedId != null ? (
            <aside className="animate-slide-in">
              <Card className="sticky top-4 space-y-4">
                {detailQuery.isPending && !selected ? (
                  <div className="flex justify-center py-10">
                    <Spinner label="Loading branch…" />
                  </div>
                ) : selected ? (
                  <>
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                          <Building2 className="h-5 w-5" />
                        </div>
                        <CardTitle className="text-base">{selected.name}</CardTitle>
                        <CardDescription className="font-mono">{selected.code}</CardDescription>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setSelectedId(null)}
                        aria-label="Close details"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Badge tone={selected.is_active ? 'success' : 'neutral'}>
                        {selected.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                      <Badge tone="accent">
                        {formatNumber(selected.staff_count ?? selected.staff?.length ?? 0)} staff
                      </Badge>
                    </div>

                    {canManage ? (
                      <form
                        noValidate
                        className="space-y-3 border-t border-white/12 pt-4"
                        onSubmit={(e) => {
                          e.preventDefault()
                          const next = collectRequiredErrors([
                            { key: 'code', label: 'Code', value: editForm.code },
                            { key: 'name', label: 'Name', value: editForm.name },
                          ])
                          setEditFieldErrors(next)
                          if (Object.keys(next).length) return
                          updateMutation.mutate()
                        }}
                      >
                        <p className="text-sm font-semibold text-ink">Branch details</p>
                        <div className="grid gap-3">
                          <BranchFields
                            form={editForm}
                            onChange={setEditForm}
                            idPrefix="edit"
                            compact
                            fieldErrors={editFieldErrors}
                            onClearError={(key) =>
                              setEditFieldErrors((errs) => {
                                const n = { ...errs }
                                delete n[key]
                                return n
                              })
                            }
                          />
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <Button
                            type="submit"
                            size="sm"
                            disabled={!editDirty}
                            loading={updateMutation.isPending}
                          >
                            Save details
                          </Button>
                          <Button
                            type="button"
                            size="sm"
                            variant="secondary"
                            loading={statusMutation.isPending}
                            onClick={() => void onToggleStatus()}
                          >
                            <Power className="h-4 w-4" />
                            {selected.is_active ? 'Deactivate' : 'Activate'}
                          </Button>
                          <Button
                            type="button"
                            size="sm"
                            variant="danger"
                            loading={deleteMutation.isPending}
                            onClick={() => void onDelete()}
                          >
                            <Trash2 className="h-4 w-4" />
                            Delete
                          </Button>
                        </div>
                      </form>
                    ) : (
                      <dl className="space-y-2 border-t border-white/12 pt-4 text-sm">
                        <DetailRow label="Phone" value={selected.phone ?? '—'} />
                        <DetailRow label="Email" value={selected.email ?? '—'} />
                        <DetailRow label="Location" value={locationLabel(selected)} />
                        <DetailRow
                          label="Address"
                          value={
                            [selected.address_line1, selected.address_line2]
                              .filter(Boolean)
                              .join(', ') || '—'
                          }
                        />
                        <DetailRow label="Timezone" value={selected.timezone ?? '—'} />
                        <DetailRow
                          label="Capacity"
                          value={
                            selected.capacity != null
                              ? formatNumber(selected.capacity)
                              : '—'
                          }
                        />
                      </dl>
                    )}

                    {canManage && canViewStaff ? (
                      <div className="space-y-3 border-t border-white/12 pt-4">
                        <div>
                          <p className="text-sm font-semibold text-ink">Staff assignment</p>
                          <p className="text-xs text-muted">
                            Choose who can operate at this branch. Tenant-wide roles still see all
                            branches.
                          </p>
                        </div>
                        {!selected.is_active ? (
                          <Alert tone="info">Activate the branch before assigning staff.</Alert>
                        ) : (
                          <>
                            <Checklist
                              items={(staffQuery.data?.data ?? []).map((u) => ({
                                id: u.id,
                                title: u.name,
                                subtitle: u.email,
                              }))}
                              selectedIds={staffIds}
                              onToggle={(id) =>
                                setStaffIds((current) =>
                                  current.includes(id)
                                    ? current.filter((x) => x !== id)
                                    : [...current, id],
                                )
                              }
                              loading={staffQuery.isPending}
                              empty="No active staff found."
                            />
                            <Button
                              size="sm"
                              disabled={!staffDirty}
                              loading={staffMutation.isPending}
                              onClick={() => staffMutation.mutate()}
                            >
                              <Users className="h-4 w-4" />
                              Save assignments
                            </Button>
                          </>
                        )}
                      </div>
                    ) : null}
                  </>
                ) : detailQuery.isError ? (
                  <Alert tone="danger">
                    {errMsg(detailQuery.error, 'Unable to load this branch.')}
                  </Alert>
                ) : null}
              </Card>
            </aside>
          ) : null}
        </div>
      </Card>
    </div>
  )
}

function BranchFields({
  form,
  onChange,
  idPrefix,
  compact = false,
  fieldErrors = {},
  onClearError,
}: {
  form: BranchPayload
  onChange: (next: BranchPayload) => void
  idPrefix: string
  compact?: boolean
  fieldErrors?: FieldErrors
  onClearError?: (key: string) => void
}) {
  const set = <K extends keyof BranchPayload>(key: K, value: BranchPayload[K]) =>
    onChange({ ...form, [key]: value })

  const clear = (key: string) => onClearError?.(key)

  return (
    <>
      <Field label="Code" htmlFor={`${idPrefix}-code`} required error={fieldErrors.code}>
        <Input
          id={`${idPrefix}-code`}
          value={form.code}
          aria-invalid={Boolean(fieldErrors.code)}
          onChange={(e) => {
            clear('code')
            set('code', e.target.value.toUpperCase())
          }}
          className="font-mono"
          placeholder="MAIN"
        />
      </Field>
      <Field label="Name" htmlFor={`${idPrefix}-name`} required error={fieldErrors.name}>
        <Input
          id={`${idPrefix}-name`}
          value={form.name}
          aria-invalid={Boolean(fieldErrors.name)}
          onChange={(e) => {
            clear('name')
            set('name', e.target.value)
          }}
          placeholder="Main Branch"
        />
      </Field>
      <div>
        <Label htmlFor={`${idPrefix}-phone`}>Phone</Label>
        <Input
          id={`${idPrefix}-phone`}
          value={form.phone ?? ''}
          onChange={(e) => set('phone', e.target.value)}
        />
      </div>
      <div>
        <Label htmlFor={`${idPrefix}-email`}>Email</Label>
        <Input
          id={`${idPrefix}-email`}
          type="email"
          value={form.email ?? ''}
          onChange={(e) => set('email', e.target.value)}
        />
      </div>
      {!compact ? (
        <>
          <div className="sm:col-span-2">
            <Label htmlFor={`${idPrefix}-address1`}>Address line 1</Label>
            <Input
              id={`${idPrefix}-address1`}
              value={form.address_line1 ?? ''}
              onChange={(e) => set('address_line1', e.target.value)}
            />
          </div>
          <div className="sm:col-span-2">
            <Label htmlFor={`${idPrefix}-address2`}>Address line 2</Label>
            <Input
              id={`${idPrefix}-address2`}
              value={form.address_line2 ?? ''}
              onChange={(e) => set('address_line2', e.target.value)}
            />
          </div>
        </>
      ) : (
        <div>
          <Label htmlFor={`${idPrefix}-address1`}>Address</Label>
          <Input
            id={`${idPrefix}-address1`}
            value={form.address_line1 ?? ''}
            onChange={(e) => set('address_line1', e.target.value)}
          />
        </div>
      )}
      <div>
        <Label htmlFor={`${idPrefix}-city`}>City</Label>
        <Input
          id={`${idPrefix}-city`}
          value={form.city ?? ''}
          onChange={(e) => set('city', e.target.value)}
        />
      </div>
      <div>
        <Label htmlFor={`${idPrefix}-state`}>State</Label>
        <Input
          id={`${idPrefix}-state`}
          value={form.state ?? ''}
          onChange={(e) => set('state', e.target.value)}
        />
      </div>
      <div>
        <Label htmlFor={`${idPrefix}-postal`}>Postal code</Label>
        <Input
          id={`${idPrefix}-postal`}
          value={form.postal_code ?? ''}
          onChange={(e) => set('postal_code', e.target.value)}
        />
      </div>
      <div>
        <Label htmlFor={`${idPrefix}-country`}>Country</Label>
        <Input
          id={`${idPrefix}-country`}
          value={form.country_code ?? ''}
          onChange={(e) => set('country_code', e.target.value.toUpperCase())}
          maxLength={2}
          className="font-mono"
        />
      </div>
      <div>
        <Label htmlFor={`${idPrefix}-tz`}>Timezone</Label>
        <Input
          id={`${idPrefix}-tz`}
          value={form.timezone ?? ''}
          onChange={(e) => set('timezone', e.target.value)}
          placeholder="Asia/Kolkata"
        />
      </div>
      <div>
        <Label htmlFor={`${idPrefix}-capacity`}>Capacity</Label>
        <Input
          id={`${idPrefix}-capacity`}
          type="number"
          min={1}
          value={form.capacity ?? ''}
          onChange={(e) =>
            set('capacity', e.target.value ? Number(e.target.value) : null)
          }
        />
      </div>
    </>
  )
}

function Checklist({
  items,
  selectedIds,
  onToggle,
  loading,
  empty,
}: {
  items: Array<{ id: number; title: string; subtitle?: string }>
  selectedIds: number[]
  onToggle: (id: number) => void
  loading?: boolean
  empty?: string
}) {
  if (loading) {
    return (
      <div className="flex justify-center py-4">
        <Spinner label="Loading…" />
      </div>
    )
  }

  if (items.length === 0) {
    return (
      <p className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-sm text-muted">
        {empty ?? 'Nothing to show.'}
      </p>
    )
  }

  return (
    <div className="max-h-52 space-y-1.5 overflow-y-auto rounded-xl border border-white/10 bg-white/[0.03] p-2">
      {items.map((item) => {
        const checked = selectedIds.includes(item.id)
        return (
          <label
            key={item.id}
            className={cn(
              'flex cursor-pointer items-start gap-2.5 rounded-lg px-2.5 py-2 transition',
              checked ? 'bg-accent/15' : 'hover:bg-white/8',
            )}
          >
            <input
              type="checkbox"
              className="mt-1"
              checked={checked}
              onChange={() => onToggle(item.id)}
            />
            <span className="min-w-0">
              <span className="block text-sm font-semibold text-ink">{item.title}</span>
              {item.subtitle ? (
                <span className="block text-xs text-muted">{item.subtitle}</span>
              ) : null}
            </span>
          </label>
        )
      })}
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="shrink-0 text-muted">{label}</dt>
      <dd className="text-right font-semibold text-ink">{value}</dd>
    </div>
  )
}
