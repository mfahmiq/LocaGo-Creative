import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  CheckCircle2,
  PauseCircle,
  PlayCircle,
  Plus,
  Search,
  Shield,
  UserCog,
  Users,
  X,
} from 'lucide-react'
import {
  createPlatformUser,
  fetchPlatformUsers,
  syncPlatformUserRoles,
  updatePlatformUser,
  type PlatformUser,
} from '@/api/platformUsers'
import { fetchPlatformRoles } from '@/api/platformRbac'
import type { RoleRow } from '@/api/rbac'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { useClientPagination } from '@/hooks/useClientPagination'
import { formatDate, formatNumber } from '@/lib/format'
import { cn } from '@/lib/cn'

const emptyCreate = {
  name: '',
  email: '',
  phone: '',
  password: '',
  password_confirmation: '',
  role_ids: [] as number[],
}

type StatusFilter = 'all' | 'active' | 'inactive'

export function PlatformUsersPage() {
  const { user: me, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canManage = hasPermission('platform.users.manage')

  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all')
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }
  const [createForm, setCreateForm] = useState(emptyCreate)
  const [editName, setEditName] = useState('')
  const [editEmail, setEditEmail] = useState('')
  const [editPhone, setEditPhone] = useState('')
  const [editPassword, setEditPassword] = useState('')
  const [editPasswordConfirm, setEditPasswordConfirm] = useState('')
  const [editRoleIds, setEditRoleIds] = useState<number[]>([])

  const usersQuery = useQuery({
    queryKey: ['platform', 'users'],
    queryFn: fetchPlatformUsers,
    enabled: canManage,
  })

  const rolesQuery = useQuery({
    queryKey: ['platform', 'roles'],
    queryFn: fetchPlatformRoles,
    enabled: canManage,
  })

  const users = usersQuery.data ?? []
  const roles = rolesQuery.data ?? []
  const selected = useMemo(
    () => users.find((row) => row.id === selectedId) ?? null,
    [users, selectedId],
  )

  useEffect(() => {
    if (!selected) return
    setEditName(selected.name)
    setEditEmail(selected.email)
    setEditPhone(selected.phone ?? '')
    setEditPassword('')
    setEditPasswordConfirm('')
    setEditRoleIds((selected.roles ?? []).map((role) => role.id))
  }, [selected])

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return users
      .filter((row) => {
        if (statusFilter === 'active') return row.is_active
        if (statusFilter === 'inactive') return !row.is_active
        return true
      })
      .filter((row) => {
        if (!q) return true
        const roleText = (row.roles ?? []).map((r) => `${r.name} ${r.code}`).join(' ')
        return (
          row.name.toLowerCase().includes(q) ||
          row.email.toLowerCase().includes(q) ||
          (row.phone ?? '').toLowerCase().includes(q) ||
          roleText.toLowerCase().includes(q)
        )
      })
      .sort((a, b) => a.name.localeCompare(b.name))
  }, [users, search, statusFilter])

  const {
    rows: pageRows,
    meta,
    setPage,
  } = useClientPagination(filtered, `${search}|${statusFilter}|${filtered.length}`)

  const stats = useMemo(
    () => ({
      total: users.length,
      active: users.filter((u) => u.is_active).length,
      inactive: users.filter((u) => !u.is_active).length,
    }),
    [users],
  )

  const invalidate = async () => {
    await queryClient.invalidateQueries({ queryKey: ['platform', 'users'] })
  }

  const createMutation = useMutation({
    mutationFn: createPlatformUser,
    onSuccess: async (user) => {
      setError(null)
      showSuccess(`Operator “${user.name}” created.`)
      setShowCreate(false)
      setCreateForm(emptyCreate)
      await invalidate()
      setSelectedId(user.id)
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to create platform user.')
    },
  })

  const updateMutation = useMutation({
    mutationFn: (payload: Parameters<typeof updatePlatformUser>[1]) =>
      updatePlatformUser(selectedId!, payload),
    onSuccess: async (user) => {
      setError(null)
      showSuccess(`Operator “${user.name}” updated.`)
      setEditPassword('')
      setEditPasswordConfirm('')
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update platform user.')
    },
  })

  const rolesMutation = useMutation({
    mutationFn: (roleIds: number[]) => syncPlatformUserRoles(selectedId!, roleIds),
    onSuccess: async (user) => {
      setError(null)
      showSuccess(`Roles updated for “${user.name}”.`)
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update roles.')
    },
  })

  const toggleActiveMutation = useMutation({
    mutationFn: ({ userId, isActive }: { userId: number; isActive: boolean }) =>
      updatePlatformUser(userId, { is_active: isActive }),
    onSuccess: async (user) => {
      setError(null)
      showSuccess(
        user.is_active
          ? `“${user.name}” activated.`
          : `“${user.name}” deactivated.`,
      )
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update status.')
    },
  })

  const onCreate = (event: FormEvent) => {
    event.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'name', label: 'Full name', value: createForm.name },
      { key: 'email', label: 'Email', value: createForm.email },
      { key: 'password', label: 'Password', value: createForm.password },
      {
        key: 'password_confirmation',
        label: 'Confirm password',
        value: createForm.password_confirmation,
      },
    ])
    if (createForm.password && createForm.password.length < 8) {
      errors.password = 'Password must be at least 8 characters.'
    }
    if (
      createForm.password &&
      createForm.password_confirmation &&
      createForm.password !== createForm.password_confirmation
    ) {
      errors.password_confirmation = 'Password confirmation does not match.'
    }
    if (createForm.role_ids.length === 0) {
      errors.role_ids = 'Assign at least one platform role.'
    }
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    createMutation.mutate({
      name: createForm.name.trim(),
      email: createForm.email.trim(),
      phone: createForm.phone.trim() || null,
      password: createForm.password,
      password_confirmation: createForm.password_confirmation,
      role_ids: createForm.role_ids,
      is_active: true,
    })
  }

  const onSaveProfile = (event: FormEvent) => {
    event.preventDefault()
    if (!selected) return
    const errors = collectRequiredErrors([
      { key: 'editName', label: 'Full name', value: editName },
      { key: 'editEmail', label: 'Email', value: editEmail },
    ])
    if (editPassword && editPassword !== editPasswordConfirm) {
      errors.editPasswordConfirm = 'Password confirmation does not match.'
    }
    if (editPassword && editPassword.length < 8) {
      errors.editPassword = 'Password must be at least 8 characters.'
    }
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    updateMutation.mutate({
      name: editName.trim(),
      email: editEmail.trim(),
      phone: editPhone.trim() || null,
      ...(editPassword
        ? { password: editPassword, password_confirmation: editPasswordConfirm }
        : {}),
    })
  }

  const onSaveRoles = async () => {
    if (!selected) return
    if (editRoleIds.length === 0) {
      setError('Assign at least one platform role.')
      return
    }
    const ok = await confirm({
      title: 'Update roles?',
      message: `Change platform roles for “${selected.name}”? This immediately affects console access.`,
      confirmLabel: 'Save roles',
      tone: 'primary',
    })
    if (!ok) return
    rolesMutation.mutate(editRoleIds)
  }

  const onToggleActive = async (row: PlatformUser) => {
    if (me?.id === row.id && row.is_active) {
      setError('You cannot deactivate your own account.')
      return
    }
    const next = !row.is_active
    const ok = await confirm({
      title: next ? 'Activate operator?' : 'Deactivate operator?',
      message: next
        ? `Allow “${row.name}” to sign in to the Super Admin console again?`
        : `Prevent “${row.name}” from signing in? Their roles are kept.`,
      confirmLabel: next ? 'Activate' : 'Deactivate',
      tone: next ? 'primary' : 'danger',
    })
    if (!ok) return
    toggleActiveMutation.mutate({ userId: row.id, isActive: next })
  }

  const toggleCreateRole = (roleId: number) => {
    setCreateForm((current) => ({
      ...current,
      role_ids: current.role_ids.includes(roleId)
        ? current.role_ids.filter((id) => id !== roleId)
        : [...current.role_ids, roleId],
    }))
  }

  const toggleEditRole = (roleId: number) => {
    setEditRoleIds((current) =>
      current.includes(roleId) ? current.filter((id) => id !== roleId) : [...current, roleId],
    )
  }

  const profileDirty =
    selected != null &&
    (editName.trim() !== selected.name ||
      editEmail.trim() !== selected.email ||
      (editPhone.trim() || '') !== (selected.phone ?? '') ||
      editPassword.length > 0)

  const rolesDirty =
    selected != null &&
    (() => {
      const current = new Set((selected.roles ?? []).map((r) => r.id))
      if (current.size !== editRoleIds.length) return true
      return editRoleIds.some((id) => !current.has(id))
    })()

  const columns: Column<PlatformUser>[] = [
    {
      key: 'operator',
      header: 'Operator',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">
            {row.name}
            {me?.id === row.id ? (
              <span className="ml-2 text-xs font-medium text-muted">(you)</span>
            ) : null}
          </p>
          <p className="mt-0.5 text-xs text-muted">{row.email}</p>
        </button>
      ),
    },
    {
      key: 'roles',
      header: 'Roles',
      cell: (row) => {
        const list = row.roles ?? []
        if (list.length === 0) {
          return <span className="text-sm text-muted">No roles</span>
        }
        return (
          <div className="flex flex-wrap gap-1.5">
            {list.slice(0, 3).map((role) => (
              <Badge key={role.id} tone="neutral">
                {role.name}
              </Badge>
            ))}
            {list.length > 3 ? (
              <Badge tone="accent">+{list.length - 3}</Badge>
            ) : null}
          </div>
        )
      },
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.is_active ? 'success' : 'danger'}>
          {row.is_active ? 'Active' : 'Inactive'}
        </Badge>
      ),
    },
    {
      key: 'last_login',
      header: 'Last login',
      cell: (row) => (
        <span className="text-sm text-muted">{formatDate(row.last_login_at)}</span>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <div className="flex flex-wrap justify-end gap-1.5">
          <Button size="sm" variant="secondary" onClick={() => setSelectedId(row.id)}>
            Manage
          </Button>
          {canManage ? (
            <Button
              size="sm"
              variant={row.is_active ? 'ghost' : 'secondary'}
              loading={toggleActiveMutation.isPending}
              disabled={me?.id === row.id && row.is_active}
              onClick={() => void onToggleActive(row)}
            >
              {row.is_active ? (
                <>
                  <PauseCircle className="h-4 w-4" />
                  Deactivate
                </>
              ) : (
                <>
                  <PlayCircle className="h-4 w-4" />
                  Activate
                </>
              )}
            </Button>
          ) : null}
        </div>
      ),
    },
  ]

  if (!canManage) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader
          title="Platform operators"
          description="People who can access the Super Admin console."
        />
        <Alert tone="danger">You do not have permission to manage platform users.</Alert>
      </div>
    )
  }

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Platform operators"
        description="People who can access the Super Admin console."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="accent">Platform</Badge>
            <Button
              size="sm"
              onClick={() => {
                setShowCreate(true)
                setError(null)
              }}
            >
              <Plus className="h-4 w-4" />
              New operator
            </Button>
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      {usersQuery.isError ? (
        <Alert tone="danger">
          {usersQuery.error instanceof ApiError
            ? usersQuery.error.message
            : 'Unable to load platform operators.'}
          <div className="mt-3">
            <Button size="sm" variant="secondary" onClick={() => void usersQuery.refetch()}>
              Try again
            </Button>
          </div>
        </Alert>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <SummaryChip
          icon={<Users className="h-4 w-4" />}
          label="Total operators"
          value={formatNumber(stats.total)}
        />
        <SummaryChip
          icon={<CheckCircle2 className="h-4 w-4" />}
          label="Active"
          value={formatNumber(stats.active)}
          tone="accent"
        />
        <SummaryChip
          icon={<PauseCircle className="h-4 w-4" />}
          label="Inactive"
          value={formatNumber(stats.inactive)}
        />
      </div>

      {showCreate ? (
        <Card className="border-accent/25">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <CardTitle>Create operator</CardTitle>
              <CardDescription>
                Invite a platform operator with console roles and a temporary password.
              </CardDescription>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowCreate(false)}
              aria-label="Close create form"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form onSubmit={onCreate} noValidate className="grid gap-3 sm:grid-cols-2">
            <Field label="Full name" htmlFor="new-op-name" required error={fieldErrors.name}>
              <Input
                id="new-op-name"
                value={createForm.name}
                onChange={(e) => {
                  setCreateForm((c) => ({ ...c, name: e.target.value }))
                  clearFieldError('name')
                }}
                placeholder="Alex Morgan"
                aria-invalid={Boolean(fieldErrors.name)}
              />
            </Field>
            <Field label="Email" htmlFor="new-op-email" required error={fieldErrors.email}>
              <Input
                id="new-op-email"
                type="email"
                value={createForm.email}
                onChange={(e) => {
                  setCreateForm((c) => ({ ...c, email: e.target.value }))
                  clearFieldError('email')
                }}
                placeholder="ops@yourcompany.com"
                aria-invalid={Boolean(fieldErrors.email)}
              />
            </Field>
            <div>
              <Label htmlFor="new-op-phone">Phone (optional)</Label>
              <Input
                id="new-op-phone"
                value={createForm.phone}
                onChange={(e) => setCreateForm((c) => ({ ...c, phone: e.target.value }))}
                placeholder="+91…"
              />
            </div>
            <div className="hidden sm:block" />
            <Field label="Password" htmlFor="new-op-password" required error={fieldErrors.password}>
              <Input
                id="new-op-password"
                type="password"
                value={createForm.password}
                onChange={(e) => {
                  setCreateForm((c) => ({ ...c, password: e.target.value }))
                  clearFieldError('password')
                }}
                autoComplete="new-password"
                aria-invalid={Boolean(fieldErrors.password)}
              />
            </Field>
            <Field
              label="Confirm password"
              htmlFor="new-op-password-confirm"
              required
              error={fieldErrors.password_confirmation}
            >
              <Input
                id="new-op-password-confirm"
                type="password"
                value={createForm.password_confirmation}
                onChange={(e) => {
                  setCreateForm((c) => ({ ...c, password_confirmation: e.target.value }))
                  clearFieldError('password_confirmation')
                }}
                autoComplete="new-password"
                aria-invalid={Boolean(fieldErrors.password_confirmation)}
              />
            </Field>
            <div className="sm:col-span-2">
              <Field label="Platform roles" required error={fieldErrors.role_ids}>
                <RoleChecklist
                  roles={roles}
                  selectedIds={createForm.role_ids}
                  onToggle={(roleId) => {
                    toggleCreateRole(roleId)
                    clearFieldError('role_ids')
                  }}
                  loading={rolesQuery.isPending}
                />
              </Field>
            </div>
            <div className="flex flex-wrap gap-2 sm:col-span-2">
              <Button type="submit" loading={createMutation.isPending}>
                Create operator
              </Button>
              <Button type="button" variant="ghost" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <Card>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap gap-2">
            {(
              [
                { value: 'all', label: 'All' },
                { value: 'active', label: 'Active' },
                { value: 'inactive', label: 'Inactive' },
              ] as const
            ).map((filter) => {
              const active = statusFilter === filter.value
              return (
                <button
                  key={filter.value}
                  type="button"
                  onClick={() => setStatusFilter(filter.value)}
                  className={cn(
                    'rounded-xl px-3 py-2 text-sm font-semibold transition',
                    active
                      ? 'bg-accent text-accent-ink'
                      : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                  )}
                >
                  {filter.label}
                </button>
              )
            })}
          </div>
          <div className="relative min-w-[14rem] flex-1 sm:max-w-xs">
            <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search operators…"
              className="pl-10"
              aria-label="Search operators"
            />
          </div>
        </div>
      </Card>

      <div className={cn('grid gap-4', selected ? 'xl:grid-cols-[1fr_24rem]' : '')}>
        <div className="min-w-0">
          {usersQuery.isPending ? (
            <div className="flex justify-center py-20">
              <Spinner label="Loading operators…" />
            </div>
          ) : (
            <>
              <DataTable
                columns={columns}
                rows={pageRows}
                rowKey={(row) => row.id}
                emptyTitle="No operators match"
                emptyDescription={
                  users.length === 0
                    ? 'Create the first platform operator to share console access.'
                    : 'Try another filter or clear the search.'
                }
              />
              <Pagination meta={meta} onPageChange={setPage} />
            </>
          )}
        </div>

        {selected ? (
          <aside className="animate-slide-in">
            <Card className="sticky top-4 space-y-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                    <UserCog className="h-5 w-5" />
                  </div>
                  <CardTitle className="truncate text-base">{selected.name}</CardTitle>
                  <CardDescription className="truncate">{selected.email}</CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedId(null)}
                  aria-label="Close details"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="flex flex-wrap gap-2">
                <Badge tone={selected.is_active ? 'success' : 'danger'}>
                  {selected.is_active ? 'Active' : 'Inactive'}
                </Badge>
                {me?.id === selected.id ? <Badge tone="accent">You</Badge> : null}
              </div>

              <dl className="space-y-2 text-sm">
                <div className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                  <dt className="text-muted">Last login</dt>
                  <dd className="font-semibold text-ink">{formatDate(selected.last_login_at)}</dd>
                </div>
                <div className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                  <dt className="text-muted">Roles</dt>
                  <dd className="font-semibold text-ink">
                    {formatNumber((selected.roles ?? []).length)}
                  </dd>
                </div>
              </dl>

              <form
                onSubmit={onSaveProfile}
                noValidate
                className="space-y-3 border-t border-white/12 pt-4"
              >
                <p className="text-sm font-semibold text-ink">Profile</p>
                <Field label="Full name" htmlFor="edit-op-name" required error={fieldErrors.editName}>
                  <Input
                    id="edit-op-name"
                    value={editName}
                    onChange={(e) => {
                      setEditName(e.target.value)
                      clearFieldError('editName')
                    }}
                    aria-invalid={Boolean(fieldErrors.editName)}
                  />
                </Field>
                <Field label="Email" htmlFor="edit-op-email" required error={fieldErrors.editEmail}>
                  <Input
                    id="edit-op-email"
                    type="email"
                    value={editEmail}
                    onChange={(e) => {
                      setEditEmail(e.target.value)
                      clearFieldError('editEmail')
                    }}
                    aria-invalid={Boolean(fieldErrors.editEmail)}
                  />
                </Field>
                <div>
                  <Label htmlFor="edit-op-phone">Phone</Label>
                  <Input
                    id="edit-op-phone"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                  />
                </div>
                <Field
                  label="Reset password"
                  htmlFor="edit-op-password"
                  error={fieldErrors.editPassword}
                >
                  <Input
                    id="edit-op-password"
                    type="password"
                    value={editPassword}
                    onChange={(e) => {
                      setEditPassword(e.target.value)
                      clearFieldError('editPassword')
                    }}
                    placeholder="Leave blank to keep"
                    autoComplete="new-password"
                    aria-invalid={Boolean(fieldErrors.editPassword)}
                  />
                </Field>
                {editPassword ? (
                  <Field
                    label="Confirm new password"
                    htmlFor="edit-op-password-confirm"
                    error={fieldErrors.editPasswordConfirm}
                  >
                    <Input
                      id="edit-op-password-confirm"
                      type="password"
                      value={editPasswordConfirm}
                      onChange={(e) => {
                        setEditPasswordConfirm(e.target.value)
                        clearFieldError('editPasswordConfirm')
                      }}
                      autoComplete="new-password"
                      aria-invalid={Boolean(fieldErrors.editPasswordConfirm)}
                    />
                  </Field>
                ) : null}
                <Button
                  type="submit"
                  size="sm"
                  loading={updateMutation.isPending}
                  disabled={!profileDirty}
                >
                  Save profile
                </Button>
              </form>

              <div className="space-y-3 border-t border-white/12 pt-4">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-semibold text-ink">Roles</p>
                  <Link
                    to="/platform/settings/rbac"
                    className="inline-flex items-center gap-1 text-xs font-semibold text-accent hover:underline"
                  >
                    <Shield className="h-3.5 w-3.5" />
                    RBAC
                  </Link>
                </div>
                <RoleChecklist
                  roles={roles}
                  selectedIds={editRoleIds}
                  onToggle={toggleEditRole}
                  loading={rolesQuery.isPending}
                />
                <Button
                  size="sm"
                  loading={rolesMutation.isPending}
                  disabled={!rolesDirty}
                  onClick={() => void onSaveRoles()}
                >
                  Save roles
                </Button>
              </div>

              <div className="border-t border-white/12 pt-4">
                <Button
                  size="sm"
                  variant={selected.is_active ? 'danger' : 'secondary'}
                  loading={toggleActiveMutation.isPending}
                  disabled={me?.id === selected.id && selected.is_active}
                  onClick={() => void onToggleActive(selected)}
                  className="w-full"
                >
                  {selected.is_active ? (
                    <>
                      <PauseCircle className="h-4 w-4" />
                      Deactivate operator
                    </>
                  ) : (
                    <>
                      <PlayCircle className="h-4 w-4" />
                      Activate operator
                    </>
                  )}
                </Button>
              </div>
            </Card>
          </aside>
        ) : null}
      </div>
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}

function RoleChecklist({
  roles,
  selectedIds,
  onToggle,
  loading,
}: {
  roles: RoleRow[]
  selectedIds: number[]
  onToggle: (roleId: number) => void
  loading?: boolean
}) {
  if (loading) {
    return (
      <div className="flex justify-center py-4">
        <Spinner label="Loading roles…" />
      </div>
    )
  }

  if (roles.length === 0) {
    return (
      <p className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-sm text-muted">
        No platform roles found. Seed defaults from{' '}
        <Link to="/platform/settings/rbac" className="font-semibold text-accent hover:underline">
          Roles & permissions
        </Link>
        .
      </p>
    )
  }

  return (
    <div className="mt-1.5 max-h-48 space-y-1.5 overflow-y-auto rounded-xl border border-white/10 bg-white/[0.03] p-2">
      {roles.map((role) => {
        const checked = selectedIds.includes(role.id)
        return (
          <label
            key={role.id}
            className={cn(
              'flex cursor-pointer items-start gap-2.5 rounded-lg px-2.5 py-2 transition',
              checked ? 'bg-accent/15' : 'hover:bg-white/8',
            )}
          >
            <input
              type="checkbox"
              className="mt-1"
              checked={checked}
              onChange={() => onToggle(role.id)}
            />
            <span className="min-w-0">
              <span className="block text-sm font-semibold text-ink">{role.name}</span>
              <span className="block font-mono text-xs text-muted">{role.code}</span>
            </span>
          </label>
        )
      })}
    </div>
  )
}
