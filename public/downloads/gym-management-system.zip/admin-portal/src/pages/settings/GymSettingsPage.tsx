import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Building2,
  CreditCard,
  Globe2,
  Palette,
  RefreshCw,
  Save,
  Users,
} from 'lucide-react'
import {
  fetchOrganization,
  updateOrganization,
  type Organization,
  type OrganizationUpdatePayload,
} from '@/api/organization'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { formatDate, formatNumber } from '@/lib/format'
import { cn } from '@/lib/cn'

const TIMEZONES = [
  'Asia/Kolkata',
  'Asia/Dubai',
  'Asia/Singapore',
  'Europe/London',
  'Europe/Berlin',
  'America/New_York',
  'America/Los_Angeles',
  'America/Chicago',
  'Australia/Sydney',
  'UTC',
]

const CURRENCIES = ['INR', 'USD', 'EUR', 'GBP', 'AED', 'SGD', 'AUD', 'CAD']

const COUNTRIES = [
  { code: 'IN', label: 'India' },
  { code: 'AE', label: 'United Arab Emirates' },
  { code: 'US', label: 'United States' },
  { code: 'GB', label: 'United Kingdom' },
  { code: 'SG', label: 'Singapore' },
  { code: 'AU', label: 'Australia' },
  { code: 'CA', label: 'Canada' },
  { code: 'DE', label: 'Germany' },
]

type FormState = {
  name: string
  legal_name: string
  email: string
  phone: string
  logo_path: string
  primary_country: string
  base_currency: string
  timezone: string
  website: string
  tagline: string
  primary_color: string
  accent_color: string
  support_email: string
}

function orgToForm(org: Organization): FormState {
  return {
    name: org.name ?? '',
    legal_name: org.legal_name ?? '',
    email: org.email ?? '',
    phone: org.phone ?? '',
    logo_path: org.logo_path ?? '',
    primary_country: org.primary_country || 'IN',
    base_currency: org.base_currency || 'INR',
    timezone: org.timezone || 'Asia/Kolkata',
    website: org.settings?.website ?? '',
    tagline: org.settings?.tagline ?? '',
    primary_color: org.settings?.branding?.primary_color ?? '',
    accent_color: org.settings?.branding?.accent_color ?? '',
    support_email: org.settings?.branding?.support_email ?? '',
  }
}

function blank(value: string) {
  const t = value.trim()
  return t === '' ? null : t
}

function toPayload(form: FormState): OrganizationUpdatePayload {
  return {
    name: form.name.trim(),
    legal_name: blank(form.legal_name),
    email: blank(form.email),
    phone: blank(form.phone),
    logo_path: blank(form.logo_path),
    primary_country: form.primary_country.trim().toUpperCase(),
    base_currency: form.base_currency.trim().toUpperCase(),
    timezone: form.timezone.trim(),
    settings: {
      website: blank(form.website),
      tagline: blank(form.tagline),
      branding: {
        primary_color: blank(form.primary_color),
        accent_color: blank(form.accent_color),
        support_email: blank(form.support_email),
      },
    },
  }
}

function statusTone(status: string): 'success' | 'warning' | 'danger' | 'accent' | 'neutral' {
  switch (status) {
    case 'active':
      return 'success'
    case 'trial':
      return 'accent'
    case 'suspended':
      return 'danger'
    case 'cancelled':
      return 'warning'
    default:
      return 'neutral'
  }
}

function usagePct(used: number, max: number) {
  if (max <= 0) return 0
  return Math.min(100, Math.round((used / max) * 100))
}

export function GymSettingsPage() {
  const { hasPermission } = useAuth()
  const { showSuccess } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('organization.settings.view')
  const canManage = hasPermission('organization.settings.manage')

  const [form, setForm] = useState<FormState | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const errMsg = (err: unknown, fallback: string) => {
    if (err instanceof ApiError) return err.message
    if (err instanceof Error && err.message) return err.message
    return fallback
  }

  const orgQuery = useQuery({
    queryKey: ['admin', 'organization'],
    queryFn: fetchOrganization,
    enabled: canView,
  })

  useEffect(() => {
    if (orgQuery.data) {
      setForm(orgToForm(orgQuery.data))
    }
  }, [orgQuery.data])

  const dirty = useMemo(() => {
    if (!orgQuery.data || !form) return false
    return JSON.stringify(toPayload(form)) !== JSON.stringify(toPayload(orgToForm(orgQuery.data)))
  }, [form, orgQuery.data])

  const saveMutation = useMutation({
    mutationFn: () => updateOrganization(toPayload(form!)),
    onSuccess: async (org) => {
      setError(null)
      showSuccess('Organization settings saved.')
      setForm(orgToForm(org))
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['admin', 'organization'] }),
        queryClient.invalidateQueries({ queryKey: ['admin', 'me'] }),
        queryClient.invalidateQueries({ queryKey: ['admin', 'entitlements'] }),
      ])
    },
    onError: (err) => setError(errMsg(err, 'Unable to save organization settings.')),
  })

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((current) => (current ? { ...current, [key]: value } : current))
  }

  const onSubmit = (e: FormEvent) => {
    e.preventDefault()
    if (!form || !canManage) return
    const next = collectRequiredErrors([
      { key: 'name', label: 'Display name', value: form.name },
    ])
    setFieldErrors(next)
    if (Object.keys(next).length) return
    saveMutation.mutate()
  }

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader
          title="Gym settings"
          description="Tenant organization profile and branding."
        />
        <Alert tone="danger">
          Your role needs <code>organization.settings.view</code> to open gym settings.
        </Alert>
      </div>
    )
  }

  const org = orgQuery.data

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Gym settings"
        description="Organization profile, regional defaults, branding, and plan usage for this gym."
        actions={
          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              variant="secondary"
              loading={orgQuery.isFetching}
              onClick={() => void orgQuery.refetch()}
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
            {canManage ? (
              <Button
                size="sm"
                disabled={!dirty || !form}
                loading={saveMutation.isPending}
                onClick={() => form && saveMutation.mutate()}
              >
                <Save className="h-4 w-4" />
                Save changes
              </Button>
            ) : (
              <Badge tone="neutral">View only</Badge>
            )}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}
      {orgQuery.isError ? (
        <Alert tone="danger">{errMsg(orgQuery.error, 'Unable to load organization settings.')}</Alert>
      ) : null}

      {orgQuery.isPending || !form || !org ? (
        <div className="flex justify-center py-20">
          <Spinner label="Loading gym settings…" />
        </div>
      ) : (
        <>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            <SummaryChip
              icon={<Building2 className="h-4 w-4" />}
              label="Status"
              value={org.status}
              badge={<Badge tone={statusTone(org.status)}>{org.status}</Badge>}
            />
            <SummaryChip
              icon={<CreditCard className="h-4 w-4" />}
              label="Plan"
              value={org.plan?.name ?? '—'}
            />
            <SummaryChip
              icon={<Users className="h-4 w-4" />}
              label="Staff seats"
              value={
                org.limits
                  ? `${formatNumber(org.usage.seats)} / ${formatNumber(org.limits.max_seats)}`
                  : formatNumber(org.usage.seats)
              }
            />
            <SummaryChip
              icon={<Globe2 className="h-4 w-4" />}
              label="Branches"
              value={
                org.limits
                  ? `${formatNumber(org.usage.branches)} / ${formatNumber(org.limits.max_branches)}`
                  : formatNumber(org.usage.branches)
              }
            />
          </div>

          <Card>
            <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
              <div>
                <CardTitle className="text-base">Subscription usage</CardTitle>
                <CardDescription>
                  Limits come from your SaaS plan. Changing currency does not rewrite past invoices.
                </CardDescription>
              </div>
              <div className="flex flex-wrap gap-2">
                {Object.entries(org.modules).map(([key, enabled]) => (
                  <Badge key={key} tone={enabled ? 'success' : 'neutral'}>
                    {key}
                    {enabled ? '' : ' off'}
                  </Badge>
                ))}
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              <UsageBar
                label="Members"
                used={org.usage.members}
                max={org.limits?.max_members ?? 0}
              />
              <UsageBar
                label="Staff seats"
                used={org.usage.seats}
                max={org.limits?.max_seats ?? 0}
              />
              <UsageBar
                label="Branches"
                used={org.usage.branches}
                max={org.limits?.max_branches ?? 0}
              />
            </div>
            <dl className="mt-4 grid gap-2 text-sm sm:grid-cols-2">
              <MetaRow label="Tenant slug" value={org.slug} mono />
              <MetaRow
                label="Trial ends"
                value={org.trial_ends_at ? formatDate(org.trial_ends_at) : '—'}
              />
            </dl>
          </Card>

          <form noValidate className="space-y-5" onSubmit={onSubmit}>
            <Card className="space-y-4">
              <div>
                <CardTitle className="text-base">Organization profile</CardTitle>
                <CardDescription>
                  Legal and contact details used on invoices, receipts, and portals.
                </CardDescription>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <Field
                  label="Display name"
                  htmlFor="gym-name"
                  required
                  error={fieldErrors.name}
                >
                  <Input
                    id="gym-name"
                    value={form.name}
                    disabled={!canManage}
                    aria-invalid={Boolean(fieldErrors.name)}
                    onChange={(e) => {
                      setFieldErrors((errs) => {
                        const n = { ...errs }
                        delete n.name
                        return n
                      })
                      set('name', e.target.value)
                    }}
                  />
                </Field>
                <div>
                  <Label htmlFor="gym-legal">Legal name</Label>
                  <Input
                    id="gym-legal"
                    value={form.legal_name}
                    disabled={!canManage}
                    onChange={(e) => set('legal_name', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="gym-email">Email</Label>
                  <Input
                    id="gym-email"
                    type="email"
                    value={form.email}
                    disabled={!canManage}
                    onChange={(e) => set('email', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="gym-phone">Phone</Label>
                  <Input
                    id="gym-phone"
                    value={form.phone}
                    disabled={!canManage}
                    onChange={(e) => set('phone', e.target.value)}
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label htmlFor="gym-logo">Logo path / URL</Label>
                  <Input
                    id="gym-logo"
                    value={form.logo_path}
                    disabled={!canManage}
                    onChange={(e) => set('logo_path', e.target.value)}
                    placeholder="https://… or storage path"
                  />
                </div>
                <div>
                  <Label htmlFor="gym-website">Website</Label>
                  <Input
                    id="gym-website"
                    value={form.website}
                    disabled={!canManage}
                    onChange={(e) => set('website', e.target.value)}
                    placeholder="https://yourgym.com"
                  />
                </div>
                <div>
                  <Label htmlFor="gym-tagline">Tagline</Label>
                  <Input
                    id="gym-tagline"
                    value={form.tagline}
                    disabled={!canManage}
                    onChange={(e) => set('tagline', e.target.value)}
                    placeholder="Train stronger every day"
                  />
                </div>
              </div>
            </Card>

            <Card className="space-y-4">
              <div>
                <CardTitle className="text-base">Regional defaults</CardTitle>
                <CardDescription>
                  Applied to new branches and documents unless a branch overrides them.
                </CardDescription>
              </div>
              <div className="grid gap-3 sm:grid-cols-3">
                <div>
                  <Label htmlFor="gym-country">Primary country</Label>
                  <Select
                    id="gym-country"
                    value={form.primary_country}
                    disabled={!canManage}
                    onChange={(e) => set('primary_country', e.target.value)}
                  >
                    {COUNTRIES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.label} ({c.code})
                      </option>
                    ))}
                    {!COUNTRIES.some((c) => c.code === form.primary_country) ? (
                      <option value={form.primary_country}>{form.primary_country}</option>
                    ) : null}
                  </Select>
                </div>
                <div>
                  <Label htmlFor="gym-currency">Base currency</Label>
                  <Select
                    id="gym-currency"
                    value={form.base_currency}
                    disabled={!canManage}
                    onChange={(e) => set('base_currency', e.target.value)}
                  >
                    {CURRENCIES.map((code) => (
                      <option key={code} value={code}>
                        {code}
                      </option>
                    ))}
                    {!CURRENCIES.includes(form.base_currency) ? (
                      <option value={form.base_currency}>{form.base_currency}</option>
                    ) : null}
                  </Select>
                </div>
                <div>
                  <Label htmlFor="gym-tz">Timezone</Label>
                  <Select
                    id="gym-tz"
                    value={form.timezone}
                    disabled={!canManage}
                    onChange={(e) => set('timezone', e.target.value)}
                  >
                    {TIMEZONES.map((tz) => (
                      <option key={tz} value={tz}>
                        {tz}
                      </option>
                    ))}
                    {!TIMEZONES.includes(form.timezone) ? (
                      <option value={form.timezone}>{form.timezone}</option>
                    ) : null}
                  </Select>
                </div>
              </div>
            </Card>

            <Card className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                  <Palette className="h-5 w-5" />
                </div>
                <div>
                  <CardTitle className="text-base">Branding</CardTitle>
                  <CardDescription>
                    Colors and support contact for portals and member-facing communications.
                  </CardDescription>
                </div>
              </div>
              <div className="grid gap-3 sm:grid-cols-3">
                <div>
                  <Label htmlFor="gym-primary">Primary color</Label>
                  <div className="flex gap-2">
                    <Input
                      id="gym-primary"
                      value={form.primary_color}
                      disabled={!canManage}
                      onChange={(e) => set('primary_color', e.target.value)}
                      placeholder="#0F172A"
                      className="font-mono"
                    />
                    <input
                      type="color"
                      aria-label="Primary color picker"
                      className="h-11 w-12 cursor-pointer rounded-xl border border-white/18 bg-transparent p-1"
                      disabled={!canManage}
                      value={
                        /^#[0-9A-Fa-f]{6}$/.test(form.primary_color)
                          ? form.primary_color
                          : '#0F172A'
                      }
                      onChange={(e) => set('primary_color', e.target.value.toUpperCase())}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="gym-accent">Accent color</Label>
                  <div className="flex gap-2">
                    <Input
                      id="gym-accent"
                      value={form.accent_color}
                      disabled={!canManage}
                      onChange={(e) => set('accent_color', e.target.value)}
                      placeholder="#C6FF1A"
                      className="font-mono"
                    />
                    <input
                      type="color"
                      aria-label="Accent color picker"
                      className="h-11 w-12 cursor-pointer rounded-xl border border-white/18 bg-transparent p-1"
                      disabled={!canManage}
                      value={
                        /^#[0-9A-Fa-f]{6}$/.test(form.accent_color)
                          ? form.accent_color
                          : '#C6FF1A'
                      }
                      onChange={(e) => set('accent_color', e.target.value.toUpperCase())}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="gym-support">Support email</Label>
                  <Input
                    id="gym-support"
                    type="email"
                    value={form.support_email}
                    disabled={!canManage}
                    onChange={(e) => set('support_email', e.target.value)}
                  />
                </div>
              </div>
              {(form.primary_color || form.accent_color) && (
                <div
                  className="overflow-hidden rounded-2xl border border-white/12"
                  style={{
                    background: `linear-gradient(135deg, ${form.primary_color || '#0F172A'}, ${form.accent_color || '#C6FF1A'})`,
                  }}
                >
                  <div className="bg-black/35 px-5 py-8 text-white">
                    <p className="text-xs font-semibold tracking-[0.16em] uppercase opacity-80">
                      Preview
                    </p>
                    <p className="mt-2 font-display text-2xl font-bold">{form.name || 'Your gym'}</p>
                    <p className="mt-1 text-sm opacity-90">
                      {form.tagline || 'Brand preview for portals and emails'}
                    </p>
                  </div>
                </div>
              )}
            </Card>

            {canManage ? (
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="text-sm text-muted">
                  {dirty ? 'You have unsaved changes.' : 'All changes saved.'}
                </p>
                <Button type="submit" disabled={!dirty} loading={saveMutation.isPending}>
                  <Save className="h-4 w-4" />
                  Save settings
                </Button>
              </div>
            ) : null}
          </form>
        </>
      )}
    </div>
  )
}

function UsageBar({ label, used, max }: { label: string; used: number; max: number }) {
  const pct = usagePct(used, max)
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3">
      <div className="mb-2 flex items-center justify-between text-sm">
        <span className="font-medium text-ink">{label}</span>
        <span className="tabular-nums text-muted">
          {formatNumber(used)}
          {max > 0 ? ` / ${formatNumber(max)}` : ''}
        </span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-white/10">
        <div
          className={cn(
            'h-full rounded-full transition-all',
            pct >= 90 ? 'bg-danger' : pct >= 70 ? 'bg-warning' : 'bg-accent',
          )}
          style={{ width: `${max > 0 ? pct : 0}%` }}
        />
      </div>
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  badge,
}: {
  icon: ReactNode
  label: string
  value: string
  badge?: ReactNode
}) {
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-white/12 bg-white/[0.04] px-4 py-3">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/10 text-muted">
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-xs font-medium text-muted">{label}</p>
        {badge ? (
          <div className="mt-1">{badge}</div>
        ) : (
          <p className="truncate text-lg font-semibold text-ink">{value}</p>
        )}
      </div>
    </div>
  )
}

function MetaRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="text-muted">{label}</dt>
      <dd className={cn('font-semibold text-ink', mono && 'font-mono text-xs')}>{value}</dd>
    </div>
  )
}
