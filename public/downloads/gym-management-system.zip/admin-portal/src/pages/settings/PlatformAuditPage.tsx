import { useMemo, useState, type ReactNode } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  Activity,
  Clock3,
  FileSearch,
  RefreshCw,
  Search,
  Shield,
  Users,
  X,
} from 'lucide-react'
import {
  fetchPlatformAuditLogs,
  type PlatformAuditLog,
} from '@/api/platformAudit'
import { fetchPlatformTenants } from '@/api/platform'
import { fetchPlatformUsers } from '@/api/platformUsers'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatNumber } from '@/lib/format'
import { cn } from '@/lib/cn'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

type ScopeFilter = '' | 'platform' | 'tenant'

function formatDateTime(value?: string | null): string {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return new Intl.DateTimeFormat(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date)
}

function actionTone(action: string): 'accent' | 'success' | 'warning' | 'danger' | 'neutral' {
  if (action.includes('suspend') || action.includes('delete') || action.includes('void')) {
    return 'danger'
  }
  if (action.includes('activat') || action.includes('created') || action.includes('provision')) {
    return 'success'
  }
  if (action.includes('extend') || action.includes('updated') || action.includes('sync')) {
    return 'accent'
  }
  if (action.startsWith('tenant.')) return 'warning'
  return 'neutral'
}

function prettyAction(action: string): string {
  return action.replace(/\./g, ' · ')
}

function JsonBlock({ value }: { value: Record<string, unknown> | null | undefined }) {
  if (!value || Object.keys(value).length === 0) {
    return <p className="text-sm text-muted">No changes recorded.</p>
  }

  return (
    <pre className="max-h-56 overflow-auto rounded-xl border border-white/10 bg-black/25 p-3 text-xs leading-relaxed text-ink/90">
      {JSON.stringify(value, null, 2)}
    </pre>
  )
}

export function PlatformAuditPage() {
  const { hasPermission } = useAuth()
  const canView = hasPermission('platform.audit.view')
  const canViewTenants = hasPermission('platform.tenants.view') || hasPermission('platform.tenants.manage')
  const canViewUsers = hasPermission('platform.users.manage')

  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [scope, setScope] = useState<ScopeFilter>('')
  const [entityType, setEntityType] = useState('')
  const [tenantId, setTenantId] = useState<number | ''>('')
  const [actorId, setActorId] = useState<number | ''>('')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const [selectedId, setSelectedId] = useState<number | null>(null)

  const logsQuery = useQuery({
    queryKey: [
      'platform',
      'audit-logs',
      page,
      appliedSearch,
      scope,
      entityType,
      tenantId,
      actorId,
      from,
      to,
    ],
    queryFn: () =>
      fetchPlatformAuditLogs({
        page,
        per_page: DEFAULT_PAGE_SIZE,
        q: appliedSearch,
        scope,
        entity_type: entityType,
        tenant_id: tenantId,
        actor_user_id: actorId,
        from: from ? `${from}T00:00:00` : undefined,
        to: to ? `${to}T23:59:59` : undefined,
      }),
    enabled: canView,
  })

  const tenantsQuery = useQuery({
    queryKey: ['platform', 'tenants'],
    queryFn: () => fetchPlatformTenants(),
    enabled: canView && canViewTenants,
  })

  const usersQuery = useQuery({
    queryKey: ['platform', 'users'],
    queryFn: fetchPlatformUsers,
    enabled: canView && canViewUsers,
  })

  const rows = logsQuery.data?.data ?? []
  const meta = logsQuery.data?.meta
  const summary = logsQuery.data?.summary

  const selected = useMemo(
    () => rows.find((row) => row.id === selectedId) ?? null,
    [rows, selectedId],
  )

  const entityTypes = useMemo(() => {
    const set = new Set<string>()
    for (const row of rows) {
      if (row.entity_type) set.add(row.entity_type)
    }
    // Keep common platform entities even if not on current page
    ;['tenant', 'user', 'role'].forEach((type) => set.add(type))
    return Array.from(set).sort()
  }, [rows])

  const applySearch = () => {
    setPage(1)
    setAppliedSearch(search.trim())
  }

  const clearFilters = () => {
    setSearch('')
    setAppliedSearch('')
    setScope('')
    setEntityType('')
    setTenantId('')
    setActorId('')
    setFrom('')
    setTo('')
    setPage(1)
    setSelectedId(null)
  }

  const columns: Column<PlatformAuditLog>[] = [
    {
      key: 'when',
      header: 'When',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">{formatDateTime(row.created_at)}</p>
          <p className="mt-0.5 font-mono text-xs text-muted">#{row.id}</p>
        </button>
      ),
    },
    {
      key: 'action',
      header: 'Action',
      cell: (row) => (
        <div>
          <Badge tone={actionTone(row.action)}>{prettyAction(row.action)}</Badge>
          <p className="mt-1 text-xs text-muted">
            {row.entity_type}
            {row.entity_id != null ? ` #${row.entity_id}` : ''}
          </p>
        </div>
      ),
    },
    {
      key: 'actor',
      header: 'Actor',
      cell: (row) =>
        row.actor ? (
          <div>
            <p className="font-medium text-ink">{row.actor.name}</p>
            <p className="text-xs text-muted">{row.actor.email}</p>
          </div>
        ) : (
          <span className="text-sm text-muted">System</span>
        ),
    },
    {
      key: 'tenant',
      header: 'Tenant',
      cell: (row) =>
        row.tenant ? (
          <div>
            <p className="font-medium text-ink">{row.tenant.name}</p>
            <p className="font-mono text-xs text-muted">{row.tenant.slug}</p>
          </div>
        ) : (
          <Badge tone="neutral">Platform</Badge>
        ),
    },
    {
      key: 'ip',
      header: 'IP',
      cell: (row) => <span className="font-mono text-xs text-muted">{row.ip_address ?? '—'}</span>,
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedId(row.id)}>
          Details
        </Button>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader
          title="Platform audit logs"
          description="Security and change history for the Super Admin console."
        />
        <Alert tone="danger">You do not have permission to view platform audit logs.</Alert>
      </div>
    )
  }

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Platform audit logs"
        description="Security and change history for the Super Admin console."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="accent">Platform</Badge>
            <Button
              size="sm"
              variant="secondary"
              loading={logsQuery.isFetching}
              onClick={() => void logsQuery.refetch()}
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </Button>
          </div>
        }
      />

      {logsQuery.isError ? (
        <Alert tone="danger">
          {logsQuery.error instanceof ApiError
            ? logsQuery.error.message
            : 'Unable to load audit logs.'}
          <div className="mt-3">
            <Button size="sm" variant="secondary" onClick={() => void logsQuery.refetch()}>
              Try again
            </Button>
          </div>
        </Alert>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<Activity className="h-4 w-4" />}
          label="Total events"
          value={formatNumber(summary?.total ?? 0)}
        />
        <SummaryChip
          icon={<Clock3 className="h-4 w-4" />}
          label="Last 24 hours"
          value={formatNumber(summary?.last_24h ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<Shield className="h-4 w-4" />}
          label="Action types"
          value={formatNumber(summary?.unique_actions ?? 0)}
        />
        <SummaryChip
          icon={<Users className="h-4 w-4" />}
          label="Actors"
          value={formatNumber(summary?.unique_actors ?? 0)}
        />
      </div>

      <Card>
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <CardTitle className="text-base">Filters</CardTitle>
            <CardDescription>Narrow by scope, tenant, actor, or date range.</CardDescription>
          </div>
          <Button size="sm" variant="ghost" onClick={clearFilters}>
            Clear
          </Button>
        </div>

        <div className="mb-4 flex flex-wrap gap-2">
          {(
            [
              { value: '' as ScopeFilter, label: 'All events' },
              { value: 'platform' as ScopeFilter, label: 'Platform ops' },
              { value: 'tenant' as ScopeFilter, label: 'Tenant lifecycle' },
            ] as const
          ).map((filter) => {
            const active = scope === filter.value
            return (
              <button
                key={filter.label}
                type="button"
                onClick={() => {
                  setScope(filter.value)
                  setPage(1)
                  setSelectedId(null)
                }}
                className={cn(
                  'rounded-xl px-3 py-2 text-sm font-semibold transition',
                  active
                    ? 'bg-accent text-accent-ink'
                    : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                )}
              >
                {filter.label}
              </button>
            )
          })}
        </div>

        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          <div className="md:col-span-2 xl:col-span-1">
            <Label htmlFor="audit-search">Search</Label>
            <div className="relative">
              <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
              <Input
                id="audit-search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') applySearch()
                }}
                placeholder="Action, entity, IP…"
                className="pl-10"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="audit-entity">Entity type</Label>
            <Select
              id="audit-entity"
              value={entityType}
              onChange={(e) => {
                setEntityType(e.target.value)
                setPage(1)
              }}
            >
              <option value="">All entities</option>
              {entityTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </Select>
          </div>
          {canViewTenants ? (
            <div>
              <Label htmlFor="audit-tenant">Tenant</Label>
              <Select
                id="audit-tenant"
                value={tenantId === '' ? '' : String(tenantId)}
                onChange={(e) => {
                  setTenantId(e.target.value ? Number(e.target.value) : '')
                  setPage(1)
                }}
              >
                <option value="">All tenants</option>
                {(tenantsQuery.data ?? []).map((tenant) => (
                  <option key={tenant.id} value={tenant.id}>
                    {tenant.name}
                  </option>
                ))}
              </Select>
            </div>
          ) : null}
          {canViewUsers ? (
            <div>
              <Label htmlFor="audit-actor">Actor</Label>
              <Select
                id="audit-actor"
                value={actorId === '' ? '' : String(actorId)}
                onChange={(e) => {
                  setActorId(e.target.value ? Number(e.target.value) : '')
                  setPage(1)
                }}
              >
                <option value="">All actors</option>
                {(usersQuery.data ?? []).map((user) => (
                  <option key={user.id} value={user.id}>
                    {user.name}
                  </option>
                ))}
              </Select>
            </div>
          ) : null}
          <div>
            <Label htmlFor="audit-from">From</Label>
            <Input
              id="audit-from"
              type="date"
              value={from}
              onChange={(e) => {
                setFrom(e.target.value)
                setPage(1)
              }}
            />
          </div>
          <div>
            <Label htmlFor="audit-to">To</Label>
            <Input
              id="audit-to"
              type="date"
              value={to}
              onChange={(e) => {
                setTo(e.target.value)
                setPage(1)
              }}
            />
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <Button size="sm" onClick={applySearch}>
            <FileSearch className="h-4 w-4" />
            Apply search
          </Button>
        </div>
      </Card>

      <div className={cn('grid gap-4', selected ? 'xl:grid-cols-[1fr_24rem]' : '')}>
        <div className="min-w-0">
          {logsQuery.isPending ? (
            <div className="flex justify-center py-20">
              <Spinner label="Loading audit logs…" />
            </div>
          ) : (
            <>
              <DataTable
                columns={columns}
                rows={rows}
                rowKey={(row) => row.id}
                emptyTitle="No audit events match"
                emptyDescription="Try clearing filters or broaden the date range."
              />
              <Pagination
                meta={meta}
                onPageChange={(next) => {
                  setPage(next)
                  setSelectedId(null)
                }}
              />
            </>
          )}
        </div>

        {selected ? (
          <aside className="animate-slide-in">
            <Card className="sticky top-4 space-y-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                    <Shield className="h-5 w-5" />
                  </div>
                  <CardTitle className="text-base">Event #{selected.id}</CardTitle>
                  <CardDescription>{formatDateTime(selected.created_at)}</CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedId(null)}
                  aria-label="Close details"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <Badge tone={actionTone(selected.action)}>{prettyAction(selected.action)}</Badge>

              <dl className="space-y-2 text-sm">
                <DetailRow label="Actor" value={selected.actor?.name ?? 'System'} />
                <DetailRow label="Email" value={selected.actor?.email ?? '—'} />
                <DetailRow
                  label="Tenant"
                  value={
                    selected.tenant
                      ? `${selected.tenant.name} (${selected.tenant.slug})`
                      : 'Platform'
                  }
                />
                <DetailRow
                  label="Entity"
                  value={`${selected.entity_type}${selected.entity_id != null ? ` #${selected.entity_id}` : ''}`}
                />
                <DetailRow label="IP address" value={selected.ip_address ?? '—'} mono />
              </dl>

              <div className="space-y-2 border-t border-white/12 pt-4">
                <p className="text-sm font-semibold text-ink">Before</p>
                <JsonBlock value={selected.old_values} />
              </div>

              <div className="space-y-2 border-t border-white/12 pt-4">
                <p className="text-sm font-semibold text-ink">After</p>
                <JsonBlock value={selected.new_values} />
              </div>

              {selected.user_agent ? (
                <div className="space-y-2 border-t border-white/12 pt-4">
                  <p className="text-sm font-semibold text-ink">User agent</p>
                  <p className="break-all text-xs text-muted">{selected.user_agent}</p>
                </div>
              ) : null}
            </Card>
          </aside>
        ) : null}
      </div>
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}

function DetailRow({
  label,
  value,
  mono = false,
}: {
  label: string
  value: string
  mono?: boolean
}) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="shrink-0 text-muted">{label}</dt>
      <dd className={cn('text-right font-semibold text-ink', mono && 'font-mono text-xs')}>
        {value}
      </dd>
    </div>
  )
}
