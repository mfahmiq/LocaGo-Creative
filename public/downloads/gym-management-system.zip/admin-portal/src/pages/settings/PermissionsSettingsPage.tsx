import { useMemo, useState, type ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { Check, Copy, KeyRound, Layers, Search, Shield, X } from 'lucide-react'
import { fetchPermissions, type PermissionRow } from '@/api/rbac'
import { fetchPlatformPermissions } from '@/api/platformRbac'
import { fetchTenantPermissionsCatalog } from '@/api/platformTenantRbac'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { useClientPagination } from '@/hooks/useClientPagination'
import { formatNumber } from '@/lib/format'
import { cn } from '@/lib/cn'

type Props = {
  scope: 'admin' | 'platform'
}

type Catalog = 'platform' | 'tenant'

type ActionKind = 'all' | 'view' | 'manage' | 'export' | 'other'

function permissionAction(code: string): Exclude<ActionKind, 'all'> {
  if (code.endsWith('.view')) return 'view'
  if (code.endsWith('.manage')) return 'manage'
  if (code.endsWith('.export')) return 'export'
  return 'other'
}

function actionTone(kind: Exclude<ActionKind, 'all'>): 'accent' | 'success' | 'warning' | 'neutral' {
  switch (kind) {
    case 'view':
      return 'accent'
    case 'manage':
      return 'success'
    case 'export':
      return 'warning'
    default:
      return 'neutral'
  }
}

function moduleLabel(module: string): string {
  return module.replaceAll('_', ' ')
}

export function PermissionsSettingsPage({ scope }: Props) {
  const { portal } = useAuth()
  const isPlatform = scope === 'platform' || portal === 'platform'
  const rbacPath = isPlatform ? '/platform/settings/rbac' : '/settings/rbac'

  const [catalog, setCatalog] = useState<Catalog>('platform')
  const isTenantCatalog = isPlatform && catalog === 'tenant'

  const permissionsQueryKey = isPlatform
    ? isTenantCatalog
      ? (['platform', 'tenant-permissions'] as const)
      : (['platform', 'permissions'] as const)
    : (['admin', 'permissions'] as const)

  const [search, setSearch] = useState('')
  const [moduleFilter, setModuleFilter] = useState('all')
  const [actionFilter, setActionFilter] = useState<ActionKind>('all')
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [copiedId, setCopiedId] = useState<number | null>(null)

  const permissionsQuery = useQuery({
    queryKey: permissionsQueryKey,
    queryFn: () => {
      if (!isPlatform) return fetchPermissions()
      return isTenantCatalog ? fetchTenantPermissionsCatalog() : fetchPlatformPermissions()
    },
  })

  const permissions = useMemo(() => {
    const rows = permissionsQuery.data ?? []
    if (isPlatform) return rows
    return rows.filter(
      (perm) => !perm.module.startsWith('platform') && perm.module !== 'member_portal',
    )
  }, [permissionsQuery.data, isPlatform])

  const modules = useMemo(
    () =>
      [...new Set(permissions.map((perm) => perm.module))].sort((a, b) =>
        a.localeCompare(b),
      ),
    [permissions],
  )

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return permissions
      .filter((perm) => (moduleFilter === 'all' ? true : perm.module === moduleFilter))
      .filter((perm) => {
        if (actionFilter === 'all') return true
        return permissionAction(perm.code) === actionFilter
      })
      .filter((perm) => {
        if (!q) return true
        return (
          perm.name.toLowerCase().includes(q) ||
          perm.code.toLowerCase().includes(q) ||
          perm.module.toLowerCase().includes(q)
        )
      })
      .sort((a, b) => a.code.localeCompare(b.code))
  }, [permissions, search, moduleFilter, actionFilter])

  const {
    rows: pageRows,
    meta,
    setPage,
  } = useClientPagination(
    filtered,
    `${search}|${moduleFilter}|${actionFilter}|${filtered.length}`,
  )

  const selected = useMemo(
    () => permissions.find((perm) => perm.id === selectedId) ?? null,
    [permissions, selectedId],
  )

  const stats = useMemo(() => {
    const byAction = { view: 0, manage: 0, export: 0, other: 0 }
    for (const perm of permissions) {
      byAction[permissionAction(perm.code)] += 1
    }
    return {
      total: permissions.length,
      modules: modules.length,
      ...byAction,
    }
  }, [permissions, modules.length])

  const catalogBadgeLabel = isPlatform
    ? isTenantCatalog
      ? 'Gym modules'
      : 'Platform'
    : 'Gym'

  const pageDescription = isPlatform
    ? 'Permission codes for the Super Admin console and gym admin modules.'
    : 'Permission codes that control access across this gym’s admin portal.'

  const copyCode = async (perm: PermissionRow) => {
    try {
      await navigator.clipboard.writeText(perm.code)
      setCopiedId(perm.id)
      window.setTimeout(() => setCopiedId((current) => (current === perm.id ? null : current)), 1500)
    } catch {
      setCopiedId(null)
    }
  }

  const columns: Column<PermissionRow>[] = [
    {
      key: 'permission',
      header: 'Permission',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">{row.name}</p>
          <p className="mt-0.5 font-mono text-xs text-muted">{row.code}</p>
        </button>
      ),
    },
    {
      key: 'module',
      header: 'Module',
      cell: (row) => (
        <span className="capitalize text-sm text-ink">{moduleLabel(row.module)}</span>
      ),
    },
    {
      key: 'action',
      header: 'Action',
      cell: (row) => {
        const kind = permissionAction(row.code)
        return <Badge tone={actionTone(kind)}>{kind}</Badge>
      },
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <div className="flex flex-wrap justify-end gap-1.5">
          <Button size="sm" variant="secondary" onClick={() => setSelectedId(row.id)}>
            View
          </Button>
          <Button size="sm" variant="ghost" onClick={() => void copyCode(row)} aria-label="Copy code">
            {copiedId === row.id ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
          </Button>
        </div>
      ),
    },
  ]

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Permissions"
        description={pageDescription}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone={isPlatform ? (isTenantCatalog ? 'warning' : 'accent') : 'neutral'}>
              {catalogBadgeLabel}
            </Badge>
            <Link
              to={rbacPath}
              className="inline-flex h-9 items-center justify-center rounded-xl border border-white/15 bg-white/10 px-3 text-sm font-semibold text-ink transition hover:bg-white/15"
            >
              Open RBAC
            </Link>
          </div>
        }
      />

      {isPlatform ? (
        <Card>
          <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <CardTitle className="text-base">Catalog</CardTitle>
              <CardDescription>
                Browse platform console permissions or gym admin module permissions.
              </CardDescription>
            </div>
            <div className="flex flex-wrap gap-2">
              {(
                [
                  { value: 'platform' as Catalog, label: 'Platform console' },
                  { value: 'tenant' as Catalog, label: 'Gym modules' },
                ] as const
              ).map((option) => {
                const active = catalog === option.value
                return (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => {
                      setCatalog(option.value)
                      setSelectedId(null)
                      setModuleFilter('all')
                    }}
                    className={cn(
                      'rounded-xl px-3 py-2 text-sm font-semibold transition',
                      active
                        ? 'bg-accent text-accent-ink'
                        : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                    )}
                  >
                    {option.label}
                  </button>
                )
              })}
            </div>
          </div>
        </Card>
      ) : null}

      {permissionsQuery.isError ? (
        <Alert tone="danger">
          {permissionsQuery.error instanceof ApiError
            ? permissionsQuery.error.message
            : 'Unable to load permissions.'}
          <div className="mt-3">
            <Button size="sm" variant="secondary" onClick={() => void permissionsQuery.refetch()}>
              Try again
            </Button>
          </div>
        </Alert>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<KeyRound className="h-4 w-4" />}
          label="Total permissions"
          value={formatNumber(stats.total)}
        />
        <SummaryChip
          icon={<Layers className="h-4 w-4" />}
          label="Modules"
          value={formatNumber(stats.modules)}
        />
        <SummaryChip
          icon={<Shield className="h-4 w-4" />}
          label="View grants"
          value={formatNumber(stats.view)}
          tone="accent"
        />
        <SummaryChip
          icon={<Shield className="h-4 w-4" />}
          label="Manage grants"
          value={formatNumber(stats.manage)}
        />
      </div>

      <Card>
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2">
            {(
              [
                { value: 'all', label: 'All actions' },
                { value: 'view', label: 'View' },
                { value: 'manage', label: 'Manage' },
                { value: 'export', label: 'Export' },
                { value: 'other', label: 'Other' },
              ] as const
            ).map((filter) => {
              const active = actionFilter === filter.value
              const count =
                filter.value === 'all'
                  ? stats.total
                  : stats[filter.value as keyof typeof stats]
              return (
                <button
                  key={filter.value}
                  type="button"
                  onClick={() => setActionFilter(filter.value)}
                  className={cn(
                    'rounded-xl px-3 py-2 text-sm font-semibold transition',
                    active
                      ? 'bg-accent text-accent-ink'
                      : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                  )}
                >
                  {filter.label}
                  <span className={cn('ml-1.5 text-xs', active ? 'opacity-80' : 'opacity-70')}>
                    {formatNumber(Number(count))}
                  </span>
                </button>
              )
            })}
          </div>

          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <Select
              aria-label="Filter by module"
              className="h-10 min-w-[10rem] sm:w-44"
              value={moduleFilter}
              onChange={(e) => setModuleFilter(e.target.value)}
            >
              <option value="all">All modules</option>
              {modules.map((module) => (
                <option key={module} value={module}>
                  {moduleLabel(module)}
                </option>
              ))}
            </Select>
            <div className="relative min-w-[14rem] flex-1 sm:max-w-xs">
              <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search permissions…"
                className="pl-10"
                aria-label="Search permissions"
              />
            </div>
          </div>
        </div>
      </Card>

      <div className={cn('grid gap-4', selected ? 'xl:grid-cols-[1fr_22rem]' : '')}>
        <div className="min-w-0">
          {permissionsQuery.isPending ? (
            <div className="flex justify-center py-20">
              <Spinner label="Loading permissions…" />
            </div>
          ) : (
            <>
              <DataTable
                columns={columns}
                rows={pageRows}
                rowKey={(row) => row.id}
                emptyTitle="No permissions match"
                emptyDescription={
                  permissions.length === 0
                    ? 'No permission catalog was returned for this scope.'
                    : 'Try another module, action filter, or clear the search.'
                }
              />
              <Pagination meta={meta} onPageChange={setPage} />
            </>
          )}
        </div>

        {selected ? (
          <aside className="animate-slide-in">
            <Card className="sticky top-4">
              <div className="mb-4 flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                    <KeyRound className="h-5 w-5" />
                  </div>
                  <CardTitle className="truncate text-base">{selected.name}</CardTitle>
                  <CardDescription className="break-all font-mono">{selected.code}</CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedId(null)}
                  aria-label="Close details"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="mb-4 flex flex-wrap gap-2">
                <Badge tone="neutral" className="capitalize">
                  {moduleLabel(selected.module)}
                </Badge>
                <Badge tone={actionTone(permissionAction(selected.code))}>
                  {permissionAction(selected.code)}
                </Badge>
                <Badge tone={isPlatform ? (isTenantCatalog ? 'warning' : 'accent') : 'neutral'}>
                  {catalogBadgeLabel}
                </Badge>
              </div>

              <dl className="space-y-2 text-sm">
                <DetailRow label="Permission ID" value={String(selected.id)} />
                <DetailRow label="Module" value={moduleLabel(selected.module)} />
                <DetailRow label="Action type" value={permissionAction(selected.code)} />
                <DetailRow
                  label="Used for"
                  value={
                    isPlatform
                      ? isTenantCatalog
                        ? 'Gym admin portal menus and actions'
                        : 'Super Admin console menus and actions'
                      : 'Gym admin portal menus and actions'
                  }
                />
              </dl>

              <div className="mt-4 flex flex-col gap-2 border-t border-white/12 pt-4">
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() => void copyCode(selected)}
                >
                  {copiedId === selected.id ? (
                    <Check className="h-4 w-4" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                  Copy permission code
                </Button>
                <Link
                  to={rbacPath}
                  className="inline-flex h-10 w-full items-center justify-center rounded-xl border border-white/15 bg-white/10 px-4 text-sm font-semibold text-ink transition hover:bg-white/15"
                >
                  Assign in RBAC
                </Link>
              </div>
            </Card>
          </aside>
        ) : null}
      </div>
    </div>
  )
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="text-muted">{label}</dt>
      <dd className="max-w-[60%] text-right font-medium capitalize text-ink">{value}</dd>
    </div>
  )
}

function SummaryChip({
  label,
  value,
  icon,
  tone = 'neutral',
}: {
  label: string
  value: string
  icon: ReactNode
  tone?: 'neutral' | 'accent'
}) {
  return (
    <Card className={cn(tone === 'accent' ? 'border-accent/20' : '')}>
      <div className="flex items-center gap-3">
        <div
          className={cn(
            'flex h-10 w-10 items-center justify-center rounded-xl',
            tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-ink',
          )}
        >
          {icon}
        </div>
        <div>
          <p className="text-xs font-semibold tracking-wide text-muted uppercase">{label}</p>
          <p className="font-display text-2xl font-bold text-ink">{value}</p>
        </div>
      </div>
    </Card>
  )
}
