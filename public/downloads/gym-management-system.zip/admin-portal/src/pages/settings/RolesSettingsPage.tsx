import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Plus, RefreshCw, Search, Shield, Trash2, UserCog, X } from 'lucide-react'
import {
  createRole,
  deleteRole,
  fetchRolePermissions,
  fetchRoles,
  seedRoles,
  updateRole,
  type RoleRow,
} from '@/api/rbac'
import {
  createPlatformRole,
  deletePlatformRole,
  fetchPlatformRolePermissions,
  fetchPlatformRoles,
  seedPlatformRoles,
  updatePlatformRole,
} from '@/api/platformRbac'
import {
  createTenantRole,
  deleteTenantRole,
  fetchTenantRolePermissions,
  fetchTenantRoles,
  seedTenantRoles,
  updateTenantRole,
} from '@/api/platformTenantRbac'
import { fetchPlatformTenants } from '@/api/platform'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { useClientPagination } from '@/hooks/useClientPagination'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { formatNumber } from '@/lib/format'
import { cn } from '@/lib/cn'

type Props = {
  scope: 'admin' | 'platform'
}

type Realm = 'platform' | 'tenant'

export function RolesSettingsPage({ scope }: Props) {
  const { portal, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const isPlatform = scope === 'platform' || portal === 'platform'
  const canManage = isPlatform
    ? hasPermission('platform.users.manage')
    : hasPermission('identity.roles.manage')
  const canViewPermissions = isPlatform
    ? hasPermission('platform.users.manage') ||
      hasPermission('platform.tenants.view') ||
      hasPermission('platform.reports.view')
    : hasPermission('identity.permissions.view') || hasPermission('identity.roles.view')
  const canViewTenants =
    hasPermission('platform.tenants.view') || hasPermission('platform.tenants.manage')

  const [realm, setRealm] = useState<Realm>('platform')
  const [tenantId, setTenantId] = useState<number | null>(null)
  const isTenantRealm = isPlatform && realm === 'tenant'
  const tenantReady = !isTenantRealm || tenantId != null

  const rbacPath = isPlatform ? '/platform/settings/rbac' : '/settings/rbac'
  const rolesQueryKey = isPlatform
    ? isTenantRealm
      ? (['platform', 'tenant-roles', tenantId] as const)
      : (['platform', 'roles'] as const)
    : (['admin', 'roles'] as const)

  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState<'all' | 'system' | 'custom'>('all')
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})
  const [createCode, setCreateCode] = useState('')
  const [createName, setCreateName] = useState('')
  const [editName, setEditName] = useState('')
  const [editCode, setEditCode] = useState('')

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }

  const tenantsQuery = useQuery({
    queryKey: ['platform', 'tenants'],
    queryFn: () => fetchPlatformTenants(),
    enabled: isPlatform && (canViewTenants || canManage),
  })

  useEffect(() => {
    if (!isPlatform || tenantId != null) return
    const first = tenantsQuery.data?.[0]
    if (first) setTenantId(first.id)
  }, [isPlatform, tenantsQuery.data, tenantId])

  useEffect(() => {
    setSelectedId(null)
    setShowCreate(false)
    setError(null)
    setFieldErrors({})
  }, [realm, tenantId])

  const rolesQuery = useQuery({
    queryKey: rolesQueryKey,
    queryFn: () => {
      if (!isPlatform) return fetchRoles()
      return isTenantRealm ? fetchTenantRoles(tenantId!) : fetchPlatformRoles()
    },
    enabled: !isPlatform || tenantReady,
  })

  const roles = rolesQuery.data ?? []
  const selected = useMemo(
    () => roles.find((role) => role.id === selectedId) ?? null,
    [roles, selectedId],
  )

  const rolePermsQuery = useQuery({
    queryKey: [...rolesQueryKey, selectedId, 'permissions'],
    queryFn: () => {
      if (!isPlatform) return fetchRolePermissions(selectedId!)
      return isTenantRealm
        ? fetchTenantRolePermissions(tenantId!, selectedId!)
        : fetchPlatformRolePermissions(selectedId!)
    },
    enabled: selectedId != null && canViewPermissions && (!isPlatform || tenantReady),
  })

  useEffect(() => {
    if (selected) {
      setEditName(selected.name)
      setEditCode(selected.code)
      setFieldErrors({})
    }
  }, [selected])

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return roles
      .filter((role) => {
        if (typeFilter === 'system') return role.is_system
        if (typeFilter === 'custom') return !role.is_system
        return true
      })
      .filter((role) => {
        if (!q) return true
        return (
          role.name.toLowerCase().includes(q) ||
          role.code.toLowerCase().includes(q)
        )
      })
      .sort((a, b) => {
        if (a.is_system !== b.is_system) return a.is_system ? -1 : 1
        return a.name.localeCompare(b.name)
      })
  }, [roles, search, typeFilter])

  const {
    rows: pageRows,
    meta,
    setPage,
  } = useClientPagination(filtered, `${search}|${typeFilter}|${filtered.length}`)

  const stats = useMemo(
    () => ({
      total: roles.length,
      system: roles.filter((r) => r.is_system).length,
      custom: roles.filter((r) => !r.is_system).length,
    }),
    [roles],
  )

  const invalidate = async () => {
    await queryClient.invalidateQueries({ queryKey: [...rolesQueryKey] })
  }

  const createMutation = useMutation({
    mutationFn: (payload: { code: string; name: string }) => {
      if (!isPlatform) return createRole(payload)
      return isTenantRealm
        ? createTenantRole(tenantId!, payload)
        : createPlatformRole(payload)
    },
    onSuccess: async (role) => {
      setError(null)
      setFieldErrors({})
      showSuccess(`Role “${role.name}” created.`)
      setShowCreate(false)
      setCreateCode('')
      setCreateName('')
      await invalidate()
      setSelectedId(role.id)
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to create role.')
    },
  })

  const updateMutation = useMutation({
    mutationFn: () => {
      const payload = {
        name: editName.trim(),
        ...(selected && !selected.is_system ? { code: editCode.trim().toLowerCase() } : {}),
      }
      if (!isPlatform) return updateRole(selectedId!, payload)
      return isTenantRealm
        ? updateTenantRole(tenantId!, selectedId!, payload)
        : updatePlatformRole(selectedId!, payload)
    },
    onSuccess: async (role) => {
      setError(null)
      showSuccess(`Role “${role.name}” updated.`)
      await invalidate()
      if (selectedId != null) {
        await queryClient.invalidateQueries({
          queryKey: [...rolesQueryKey, selectedId, 'permissions'],
        })
      }
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update role.')
    },
  })

  const deleteMutation = useMutation({
    mutationFn: (roleId: number) => {
      if (!isPlatform) return deleteRole(roleId)
      return isTenantRealm
        ? deleteTenantRole(tenantId!, roleId)
        : deletePlatformRole(roleId)
    },
    onSuccess: async () => {
      setError(null)
      showSuccess('Role deleted.')
      setSelectedId(null)
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to delete role.')
    },
  })

  const seedMutation = useMutation({
    mutationFn: () => {
      if (!isPlatform) return seedRoles()
      return isTenantRealm ? seedTenantRoles(tenantId!) : seedPlatformRoles()
    },
    onSuccess: async () => {
      setError(null)
      showSuccess(
        isPlatform
          ? isTenantRealm
            ? 'Default gym roles seeded.'
            : 'Default platform roles seeded.'
          : 'Default gym roles seeded.',
      )
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to seed roles.')
    },
  })

  const onCreate = (event: FormEvent) => {
    event.preventDefault()
    const next = collectRequiredErrors([
      { key: 'code', label: 'Code', value: createCode },
      { key: 'name', label: 'Display name', value: createName },
    ])
    setFieldErrors(next)
    if (Object.keys(next).length) return
    createMutation.mutate({
      code: createCode.trim().toLowerCase(),
      name: createName.trim(),
    })
  }

  const onSaveEdit = () => {
    if (!selected) return
    const next = collectRequiredErrors([
      { key: 'editName', label: 'Display name', value: editName },
      ...(selected.is_system
        ? []
        : [{ key: 'editCode', label: 'Code', value: editCode }]),
    ])
    setFieldErrors(next)
    if (Object.keys(next).length) return
    updateMutation.mutate()
  }

  const onDelete = async (role: RoleRow) => {
    if (role.is_system) return
    const ok = await confirm({
      title: 'Delete role?',
      message: `Permanently delete “${role.name}” (${role.code})? Users must be unassigned first.`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (!ok) return
    deleteMutation.mutate(role.id)
  }

  const onSeed = async () => {
    const ok = await confirm({
      title: 'Seed default roles?',
      message: isPlatform
        ? isTenantRealm
          ? 'Ensure standard gym roles exist for this tenant and reset their default permission grants. Custom roles are kept.'
          : 'Ensure Super Admin and Platform Support exist and reset their default permission grants. Custom roles are kept.'
        : 'Ensure standard gym staff roles exist. Existing custom roles are kept.',
      confirmLabel: 'Seed defaults',
      tone: 'primary',
    })
    if (!ok) return
    seedMutation.mutate()
  }

  const dirtyMeta =
    selected != null &&
    (editName.trim() !== selected.name ||
      (!selected.is_system && editCode.trim().toLowerCase() !== selected.code))

  const permissionCount = rolePermsQuery.data?.permissions.length ?? 0

  const scopeBadgeLabel = isPlatform
    ? isTenantRealm
      ? 'Gym tenant'
      : 'Platform'
    : 'Gym'

  const scopeColumnLabel = isPlatform
    ? isTenantRealm
      ? 'Gym staff'
      : 'Platform console'
    : 'Gym staff'

  const pageDescription = isPlatform
    ? 'Directory of Super Admin console roles and gym staff roles for any tenant.'
    : 'Staff roles used across this gym’s admin portal.'

  const seedCreateDisabled = isTenantRealm && tenantId == null
  const selectedTenant = tenantsQuery.data?.find((t) => t.id === tenantId)

  const columns: Column<RoleRow>[] = [
    {
      key: 'role',
      header: 'Role',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">{row.name}</p>
          <p className="mt-0.5 font-mono text-xs text-muted">{row.code}</p>
        </button>
      ),
    },
    {
      key: 'type',
      header: 'Type',
      cell: (row) => (
        <Badge tone={row.is_system ? 'neutral' : 'accent'}>
          {row.is_system ? 'System' : 'Custom'}
        </Badge>
      ),
    },
    {
      key: 'scope',
      header: 'Scope',
      cell: () => scopeColumnLabel,
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <div className="flex flex-wrap justify-end gap-1.5">
          <Button size="sm" variant="secondary" onClick={() => setSelectedId(row.id)}>
            View
          </Button>
          <Link
            to={rbacPath}
            className="inline-flex h-9 items-center justify-center gap-2 rounded-xl bg-transparent px-3 text-sm font-semibold text-ink transition hover:bg-white/10"
          >
            Permissions
          </Link>
        </div>
      ),
    },
  ]

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Roles"
        description={pageDescription}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone={isPlatform ? (isTenantRealm ? 'warning' : 'accent') : 'neutral'}>
              {scopeBadgeLabel}
            </Badge>
            {canManage ? (
              <>
                <Button
                  size="sm"
                  variant="secondary"
                  loading={seedMutation.isPending}
                  disabled={seedCreateDisabled}
                  onClick={() => void onSeed()}
                >
                  <RefreshCw className="h-4 w-4" />
                  Seed defaults
                </Button>
                <Button
                  size="sm"
                  disabled={seedCreateDisabled}
                  onClick={() => {
                    setShowCreate(true)
                    setError(null)
                    setFieldErrors({})
                    setCreateCode('')
                    setCreateName('')
                  }}
                >
                  <Plus className="h-4 w-4" />
                  New role
                </Button>
              </>
            ) : null}
          </div>
        }
      />

      {isPlatform ? (
        <Card>
          <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <CardTitle className="text-base">Scope</CardTitle>
              <CardDescription>
                Switch between platform console roles and a specific gym tenant.
              </CardDescription>
            </div>
            <div className="flex flex-wrap items-end gap-3">
              <div className="flex flex-wrap gap-2">
                {(
                  [
                    { value: 'platform' as Realm, label: 'Platform console' },
                    { value: 'tenant' as Realm, label: 'Gym tenant' },
                  ] as const
                ).map((option) => {
                  const active = realm === option.value
                  return (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() => setRealm(option.value)}
                      className={cn(
                        'rounded-xl px-3 py-2 text-sm font-semibold transition',
                        active
                          ? 'bg-accent text-accent-ink'
                          : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                      )}
                    >
                      {option.label}
                    </button>
                  )
                })}
              </div>
              {isTenantRealm ? (
                <div className="min-w-[14rem]">
                  <Label htmlFor="roles-tenant">Gym</Label>
                  <Select
                    id="roles-tenant"
                    value={tenantId == null ? '' : String(tenantId)}
                    onChange={(e) =>
                      setTenantId(e.target.value ? Number(e.target.value) : null)
                    }
                  >
                    <option value="">Select a gym…</option>
                    {(tenantsQuery.data ?? []).map((tenant) => (
                      <option key={tenant.id} value={tenant.id}>
                        {tenant.name} ({tenant.slug})
                      </option>
                    ))}
                  </Select>
                </div>
              ) : null}
            </div>
          </div>
        </Card>
      ) : null}

      {isTenantRealm && tenantId == null ? (
        <Alert tone="info">Select a gym tenant to view and manage its roles.</Alert>
      ) : null}

      {error ? (
        <Alert tone="danger">
          {error}
        </Alert>
      ) : null}

      {rolesQuery.isError ? (
        <Alert tone="danger">
          {rolesQuery.error instanceof ApiError
            ? rolesQuery.error.message
            : 'Unable to load roles.'}
          <div className="mt-3">
            <Button size="sm" variant="secondary" onClick={() => void rolesQuery.refetch()}>
              Try again
            </Button>
          </div>
        </Alert>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <SummaryChip
          icon={<UserCog className="h-4 w-4" />}
          label="Total roles"
          value={formatNumber(stats.total)}
        />
        <SummaryChip
          icon={<Shield className="h-4 w-4" />}
          label="System"
          value={formatNumber(stats.system)}
        />
        <SummaryChip
          icon={<Plus className="h-4 w-4" />}
          label="Custom"
          value={formatNumber(stats.custom)}
          tone="accent"
        />
      </div>

      {showCreate && canManage && !seedCreateDisabled ? (
        <Card className="border-accent/25">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <CardTitle>Create role</CardTitle>
              <CardDescription>
                {isTenantRealm && selectedTenant
                  ? `Custom staff role for ${selectedTenant.name}. Code must start with a letter and use lowercase letters, numbers, and underscores.`
                  : 'Code must start with a letter and use lowercase letters, numbers, and underscores.'}
              </CardDescription>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowCreate(false)}
              aria-label="Close create form"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form noValidate onSubmit={onCreate} className="grid gap-3 sm:grid-cols-2">
            <Field
              label="Code"
              htmlFor="new-role-code"
              required
              error={fieldErrors.code}
            >
              <Input
                id="new-role-code"
                value={createCode}
                aria-invalid={Boolean(fieldErrors.code)}
                onChange={(e) => {
                  clearFieldError('code')
                  setCreateCode(e.target.value)
                }}
                placeholder={isPlatform && !isTenantRealm ? 'platform_ops' : 'floor_lead'}
                className="font-mono"
              />
            </Field>
            <Field
              label="Display name"
              htmlFor="new-role-name"
              required
              error={fieldErrors.name}
            >
              <Input
                id="new-role-name"
                value={createName}
                aria-invalid={Boolean(fieldErrors.name)}
                onChange={(e) => {
                  clearFieldError('name')
                  setCreateName(e.target.value)
                }}
                placeholder={
                  isPlatform && !isTenantRealm ? 'Platform Operations' : 'Floor Lead'
                }
              />
            </Field>
            <div className="flex flex-wrap gap-2 sm:col-span-2">
              <Button type="submit" loading={createMutation.isPending}>
                Create role
              </Button>
              <Button type="button" variant="ghost" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <Card>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap gap-2">
            {(
              [
                { value: 'all', label: 'All' },
                { value: 'system', label: 'System' },
                { value: 'custom', label: 'Custom' },
              ] as const
            ).map((filter) => {
              const active = typeFilter === filter.value
              return (
                <button
                  key={filter.value}
                  type="button"
                  onClick={() => setTypeFilter(filter.value)}
                  className={cn(
                    'rounded-xl px-3 py-2 text-sm font-semibold transition',
                    active
                      ? 'bg-accent text-accent-ink'
                      : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                  )}
                >
                  {filter.label}
                </button>
              )
            })}
          </div>
          <div className="relative min-w-[14rem] flex-1 sm:max-w-xs">
            <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search roles…"
              className="pl-10"
              aria-label="Search roles"
            />
          </div>
        </div>
      </Card>

      <div className={cn('grid gap-4', selected ? 'xl:grid-cols-[1fr_22rem]' : '')}>
        <div className="min-w-0">
          {rolesQuery.isPending ? (
            <div className="flex justify-center py-20">
              <Spinner label="Loading roles…" />
            </div>
          ) : (
            <>
              <DataTable
                columns={columns}
                rows={pageRows}
                rowKey={(row) => row.id}
                emptyTitle="No roles match"
                emptyDescription={
                  roles.length === 0
                    ? 'Seed default roles or create a custom role to get started.'
                    : 'Try another filter or clear the search.'
                }
              />
              <Pagination meta={meta} onPageChange={setPage} />
            </>
          )}
        </div>

        {selected ? (
          <aside className="animate-slide-in">
            <Card className="sticky top-4">
              <div className="mb-4 flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                    <UserCog className="h-5 w-5" />
                  </div>
                  <CardTitle className="truncate text-base">{selected.name}</CardTitle>
                  <CardDescription className="font-mono">{selected.code}</CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedId(null)}
                  aria-label="Close details"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="mb-4 flex flex-wrap gap-2">
                <Badge tone={selected.is_system ? 'neutral' : 'accent'}>
                  {selected.is_system ? 'System' : 'Custom'}
                </Badge>
                <Badge tone={isPlatform ? (isTenantRealm ? 'warning' : 'accent') : 'neutral'}>
                  {scopeBadgeLabel}
                </Badge>
              </div>

              <dl className="space-y-2 text-sm">
                <div className="flex items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                  <dt className="text-muted">Permissions</dt>
                  <dd className="font-semibold text-ink">
                    {rolePermsQuery.isLoading ? '…' : formatNumber(permissionCount)}
                  </dd>
                </div>
              </dl>

              {canManage ? (
                <div className="mt-4 space-y-3 border-t border-white/12 pt-4">
                  <Field
                    label="Display name"
                    htmlFor="edit-role-name"
                    required
                    error={fieldErrors.editName}
                  >
                    <Input
                      id="edit-role-name"
                      value={editName}
                      aria-invalid={Boolean(fieldErrors.editName)}
                      onChange={(e) => {
                        clearFieldError('editName')
                        setEditName(e.target.value)
                      }}
                    />
                  </Field>
                  <Field
                    label="Code"
                    htmlFor="edit-role-code"
                    required={!selected.is_system}
                    error={fieldErrors.editCode}
                  >
                    <Input
                      id="edit-role-code"
                      value={editCode}
                      aria-invalid={Boolean(fieldErrors.editCode)}
                      onChange={(e) => {
                        clearFieldError('editCode')
                        setEditCode(e.target.value)
                      }}
                      disabled={selected.is_system}
                      className="font-mono"
                    />
                  </Field>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      type="button"
                      disabled={!dirtyMeta || updateMutation.isPending}
                      loading={updateMutation.isPending}
                      onClick={onSaveEdit}
                    >
                      Save changes
                    </Button>
                    {!selected.is_system ? (
                      <Button
                        type="button"
                        variant="danger"
                        disabled={deleteMutation.isPending}
                        loading={deleteMutation.isPending}
                        onClick={() => void onDelete(selected)}
                      >
                        <Trash2 className="h-4 w-4" />
                        Delete
                      </Button>
                    ) : null}
                  </div>
                </div>
              ) : (
                <p className="mt-4 border-t border-white/12 pt-4 text-sm text-muted">
                  View only. Role edits require manage permission.
                </p>
              )}

              <div className="mt-4 border-t border-white/12 pt-4">
                <Link
                  to={rbacPath}
                  className="inline-flex h-10 w-full items-center justify-center rounded-xl border border-white/15 bg-white/10 px-4 text-sm font-semibold text-ink transition hover:bg-white/15"
                >
                  Manage permissions in RBAC
                </Link>
              </div>
            </Card>
          </aside>
        ) : null}
      </div>
    </div>
  )
}

function SummaryChip({
  label,
  value,
  icon,
  tone = 'neutral',
}: {
  label: string
  value: string
  icon: ReactNode
  tone?: 'neutral' | 'accent'
}) {
  return (
    <Card className={cn(tone === 'accent' ? 'border-accent/20' : '')}>
      <div className="flex items-center gap-3">
        <div
          className={cn(
            'flex h-10 w-10 items-center justify-center rounded-xl',
            tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-ink',
          )}
        >
          {icon}
        </div>
        <div>
          <p className="text-xs font-semibold tracking-wide text-muted uppercase">{label}</p>
          <p className="font-display text-2xl font-bold text-ink">{value}</p>
        </div>
      </div>
    </Card>
  )
}
