import { useMemo, useState } from 'react'
import { useForm, FormProvider, useFormContext, type FieldPath, type FieldValues } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useMutation } from '@tanstack/react-query'
import { Eye, EyeOff, KeyRound, Lock, ShieldCheck } from 'lucide-react'
import { changePassword } from '@/api/auth'
import { useAuth } from '@/auth/AuthContext'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { FormField } from '@/components/form/FormField'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { ApiError } from '@/api/client'
import { cn } from '@/lib/cn'

const schema = z
  .object({
    current_password: z.string().min(1, 'Current password is required'),
    password: z
      .string()
      .min(8, 'New password must be at least 8 characters')
      .refine((value) => /[A-Za-z]/.test(value) && /\d/.test(value), {
        message: 'Use letters and at least one number',
      }),
    password_confirmation: z.string().min(1, 'Please confirm the new password'),
  })
  .refine((values) => values.password === values.password_confirmation, {
    message: 'Passwords do not match',
    path: ['password_confirmation'],
  })
  .refine((values) => values.password !== values.current_password, {
    message: 'New password must be different from the current password',
    path: ['password'],
  })

type FormValues = z.infer<typeof schema>

function passwordStrength(password: string): {
  score: number
  label: string
  tone: 'danger' | 'warning' | 'accent' | 'success'
} {
  let score = 0
  if (password.length >= 8) score += 1
  if (password.length >= 12) score += 1
  if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score += 1
  if (/\d/.test(password)) score += 1
  if (/[^A-Za-z0-9]/.test(password)) score += 1

  if (!password) return { score: 0, label: 'Enter a new password', tone: 'warning' }
  if (score <= 2) return { score, label: 'Weak', tone: 'danger' }
  if (score === 3) return { score, label: 'Fair', tone: 'warning' }
  if (score === 4) return { score, label: 'Good', tone: 'accent' }
  return { score, label: 'Strong', tone: 'success' }
}

function PasswordField<T extends FieldValues>({
  name,
  label,
  hint,
  autoComplete,
}: {
  name: FieldPath<T>
  label: string
  hint?: string
  autoComplete?: string
}) {
  const [visible, setVisible] = useState(false)
  const {
    register,
    formState: { errors },
  } = useFormContext<T>()
  const error = errors[name]?.message
  const message = typeof error === 'string' ? error : undefined

  return (
    <FormField label={label} htmlFor={name} error={message} hint={hint} required>
      <div className="relative">
        <Input
          id={name}
          type={visible ? 'text' : 'password'}
          autoComplete={autoComplete}
          aria-invalid={Boolean(message)}
          aria-required
          required
          className="pr-11"
          {...register(name)}
        />
        <button
          type="button"
          className="absolute top-1/2 right-2 inline-flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-lg text-muted transition hover:bg-white/10 hover:text-ink"
          onClick={() => setVisible((value) => !value)}
          aria-label={visible ? 'Hide password' : 'Show password'}
        >
          {visible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
    </FormField>
  )
}

export function ChangePasswordPage() {
  const { user, portal } = useAuth()
  const { showSuccess } = useFeedback()
  const [error, setError] = useState<string | null>(null)

  const methods = useForm<FormValues>({
    resolver: zodResolver(schema),
    mode: 'onBlur',
    defaultValues: {
      current_password: '',
      password: '',
      password_confirmation: '',
    },
  })

  const newPassword = methods.watch('password')
  const strength = useMemo(() => passwordStrength(newPassword ?? ''), [newPassword])

  const mutation = useMutation({
    mutationFn: changePassword,
    onSuccess: (message) => {
      setError(null)
      showSuccess(message || 'Password updated successfully.')
      methods.reset()
    },
    onError: (err) => {
      if (err instanceof ApiError) {
        const fieldErrors = err.errors
        if (fieldErrors) {
          for (const [field, messages] of Object.entries(fieldErrors)) {
            if (field === 'current_password' || field === 'password' || field === 'password_confirmation') {
              methods.setError(field, { message: messages[0] })
            }
          }
        }
        setError(err.message)
        return
      }
      setError('Unable to change password.')
    },
  })

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Change password"
        description={
          portal === 'platform'
            ? 'Update the password for your Super Admin console account.'
            : 'Update the password for your gym admin account.'
        }
        actions={<Badge tone={portal === 'platform' ? 'accent' : 'neutral'}>Account security</Badge>}
      />

      <div className="grid gap-4 xl:grid-cols-[1fr_18rem]">
        <Card className="min-w-0">
          <div className="mb-5 flex items-start gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-accent/20 text-accent">
              <Lock className="h-5 w-5" />
            </div>
            <div>
              <CardTitle>Account security</CardTitle>
              <CardDescription>
                Enter your current password, then choose a strong new password you have not used
                before.
              </CardDescription>
            </div>
          </div>

          <FormProvider {...methods}>
            <form
              className="space-y-4"
              onSubmit={methods.handleSubmit((values) => mutation.mutate(values))}
              noValidate
            >
              {error ? <Alert tone="danger">{error}</Alert> : null}

              <PasswordField<FormValues>
                name="current_password"
                label="Current password"
                autoComplete="current-password"
              />

              <div className="space-y-2">
                <PasswordField<FormValues>
                  name="password"
                  label="New password"
                  autoComplete="new-password"
                  hint="At least 8 characters, with letters and a number"
                />
                <div className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-3">
                  <div className="mb-2 flex items-center justify-between gap-3 text-xs">
                    <span className="font-semibold tracking-wide text-muted uppercase">
                      Strength
                    </span>
                    <span
                      className={cn(
                        'font-semibold',
                        strength.tone === 'danger' && 'text-danger',
                        strength.tone === 'warning' && 'text-warning',
                        strength.tone === 'accent' && 'text-accent',
                        strength.tone === 'success' && 'text-success',
                      )}
                    >
                      {strength.label}
                    </span>
                  </div>
                  <div className="grid grid-cols-5 gap-1.5">
                    {Array.from({ length: 5 }).map((_, index) => (
                      <div
                        key={index}
                        className={cn(
                          'h-1.5 rounded-full transition',
                          index < strength.score
                            ? strength.tone === 'danger'
                              ? 'bg-danger'
                              : strength.tone === 'warning'
                                ? 'bg-warning'
                                : strength.tone === 'accent'
                                  ? 'bg-accent'
                                  : 'bg-success'
                            : 'bg-white/10',
                        )}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <PasswordField<FormValues>
                name="password_confirmation"
                label="Confirm new password"
                autoComplete="new-password"
              />

              <div className="flex flex-wrap gap-2 pt-2">
                <Button type="submit" loading={mutation.isPending}>
                  <KeyRound className="h-4 w-4" />
                  Update password
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  disabled={mutation.isPending}
                  onClick={() => {
                    methods.reset()
                    setError(null)
                  }}
                >
                  Clear
                </Button>
              </div>
            </form>
          </FormProvider>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardTitle className="text-base">Signed-in account</CardTitle>
            <CardDescription>Password changes apply to this account only.</CardDescription>
            <dl className="mt-4 space-y-2 text-sm">
              <div className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                <dt className="text-xs text-muted">Name</dt>
                <dd className="mt-0.5 font-medium text-ink">{user?.name ?? '—'}</dd>
              </div>
              <div className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                <dt className="text-xs text-muted">Email</dt>
                <dd className="mt-0.5 break-all font-medium text-ink">{user?.email ?? '—'}</dd>
              </div>
              <div className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                <dt className="text-xs text-muted">Portal</dt>
                <dd className="mt-0.5 font-medium capitalize text-ink">
                  {portal === 'platform' ? 'Super Admin console' : 'Gym admin portal'}
                </dd>
              </div>
            </dl>
          </Card>

          <Card>
            <div className="mb-3 flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-accent" />
              <CardTitle className="text-base">Password tips</CardTitle>
            </div>
            <ul className="space-y-2 text-sm text-muted">
              <li className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                Use at least 8 characters with letters and numbers.
              </li>
              <li className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                Prefer a unique password you do not reuse elsewhere.
              </li>
              <li className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                Avoid names, birthdays, or easy keyboard patterns.
              </li>
              <li className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
                After updating, keep your new password stored securely.
              </li>
            </ul>
          </Card>
        </div>
      </div>
    </div>
  )
}
