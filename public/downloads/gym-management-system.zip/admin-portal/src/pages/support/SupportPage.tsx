import { useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  CheckCircle2,
  CircleDot,
  MessageSquare,
  Plus,
  Search,
  Ticket,
  X,
} from 'lucide-react'
import {
  assignSupportTicket,
  closeSupportTicket,
  createSupportTicket,
  fetchSupportTicket,
  fetchSupportTickets,
  replySupportTicket,
  resolveSupportTicket,
  startSupportTicket,
  type SupportTicket,
  type TicketPriority,
  type TicketStatus,
} from '@/api/support'
import { fetchMembers } from '@/api/members'
import { fetchStaff } from '@/api/staff'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'

const CATEGORY_SUGGESTIONS = [
  'billing',
  'membership',
  'facilities',
  'classes',
  'training',
  'technical',
  'general',
]

function memberLabel(m?: {
  first_name?: string
  last_name?: string
  member_code?: string
  full_name?: string
  email?: string | null
} | null) {
  if (!m) return '—'
  if (m.full_name) {
    return m.member_code ? `${m.full_name} (${m.member_code})` : m.full_name
  }
  const name = `${m.first_name ?? ''} ${m.last_name ?? ''}`.trim()
  return name ? `${name}${m.member_code ? ` (${m.member_code})` : ''}` : m.member_code || '—'
}

function statusTone(
  status: TicketStatus,
): 'accent' | 'warning' | 'success' | 'neutral' | 'danger' {
  switch (status) {
    case 'open':
      return 'accent'
    case 'in_progress':
      return 'warning'
    case 'resolved':
      return 'success'
    case 'closed':
      return 'neutral'
    default:
      return 'neutral'
  }
}

function priorityTone(
  priority: TicketPriority,
): 'neutral' | 'accent' | 'warning' | 'danger' {
  switch (priority) {
    case 'low':
      return 'neutral'
    case 'medium':
      return 'accent'
    case 'high':
      return 'warning'
    case 'urgent':
      return 'danger'
    default:
      return 'neutral'
  }
}

function statusLabel(status: TicketStatus) {
  return status.replace(/_/g, ' ')
}

export function SupportPage() {
  const { user, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('support.tickets.view')
  const canManage = hasPermission('support.tickets.manage')
  const canViewMembers = hasPermission('members.view')
  const canViewStaff = hasPermission('identity.staff.view')

  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }
  const [page, setPage] = useState(1)
  const [status, setStatus] = useState<'' | TicketStatus>('open')
  const [priority, setPriority] = useState<'' | TicketPriority>('')
  const [assignedFilter, setAssignedFilter] = useState<number | '' | 'unassigned'>('')
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [selectedId, setSelectedId] = useState<number | null>(null)

  const [showCreate, setShowCreate] = useState(false)
  const [memberSearch, setMemberSearch] = useState('')
  const [createForm, setCreateForm] = useState({
    member_id: '' as number | '',
    category: 'general',
    subject: '',
    priority: 'medium' as TicketPriority,
    message: '',
  })

  const [assignUserId, setAssignUserId] = useState<number | ''>('')
  const [replyText, setReplyText] = useState('')
  const [staffSearch, setStaffSearch] = useState('')

  const errMsg = (err: unknown, fallback: string) => {
    if (err instanceof ApiError) return err.message
    if (err instanceof Error && err.message) return err.message
    return fallback
  }

  const invalidate = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['admin', 'support-tickets'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'support-stats'] }),
    ])
  }

  const listQuery = useQuery({
    queryKey: [
      'admin',
      'support-tickets',
      page,
      status,
      priority,
      assignedFilter,
      appliedSearch,
    ],
    queryFn: () =>
      fetchSupportTickets({
        page,
        per_page: DEFAULT_PAGE_SIZE,
        status,
        priority,
        assigned_user_id:
          assignedFilter === '' || assignedFilter === 'unassigned'
            ? ''
            : assignedFilter,
        search: appliedSearch,
      }),
    enabled: canView,
  })

  const statsQuery = useQuery({
    queryKey: ['admin', 'support-stats'],
    queryFn: async () => {
      const [open, progress, resolved, closed, urgent] = await Promise.all([
        fetchSupportTickets({ page: 1, per_page: 1, status: 'open' }),
        fetchSupportTickets({ page: 1, per_page: 1, status: 'in_progress' }),
        fetchSupportTickets({ page: 1, per_page: 1, status: 'resolved' }),
        fetchSupportTickets({ page: 1, per_page: 1, status: 'closed' }),
        fetchSupportTickets({ page: 1, per_page: 1, priority: 'urgent', status: 'open' }),
      ])
      return {
        open: open.meta.total,
        progress: progress.meta.total,
        resolved: resolved.meta.total,
        closed: closed.meta.total,
        urgentOpen: urgent.meta.total,
      }
    },
    enabled: canView,
  })

  const detailQuery = useQuery({
    queryKey: ['admin', 'support-tickets', selectedId],
    queryFn: () => fetchSupportTicket(selectedId!),
    enabled: canView && selectedId != null,
  })

  const membersQuery = useQuery({
    queryKey: ['admin', 'members', 'support-picker', memberSearch],
    queryFn: () =>
      fetchMembers({
        page: 1,
        per_page: 25,
        search: memberSearch || undefined,
        status: 'active',
      }),
    enabled: canViewMembers && showCreate,
  })

  const staffQuery = useQuery({
    queryKey: ['admin', 'staff', 'support-picker', staffSearch],
    queryFn: () =>
      fetchStaff({
        page: 1,
        per_page: 40,
        search: staffSearch || undefined,
        is_active: true,
      }),
    enabled: canViewStaff,
  })

  const tickets = listQuery.data?.data ?? []
  const filteredTickets =
    assignedFilter === 'unassigned'
      ? tickets.filter((t) => t.assigned_user_id == null)
      : tickets

  const openCreate = () => {
    setCreateForm({
      member_id: '',
      category: 'general',
      subject: '',
      priority: 'medium',
      message: '',
    })
    setMemberSearch('')
    setShowCreate(true)
    setSelectedId(null)
    setError(null)
    setFieldErrors({})
  }

  const createMutation = useMutation({
    mutationFn: async () => {
      if (!createForm.member_id) throw new Error('Select a member.')
      if (!createForm.subject.trim() || !createForm.message.trim()) {
        throw new Error('Subject and message are required.')
      }
      return createSupportTicket({
        member_id: Number(createForm.member_id),
        category: createForm.category.trim() || 'general',
        subject: createForm.subject.trim(),
        priority: createForm.priority,
        message: createForm.message.trim(),
      })
    },
    onSuccess: async (row) => {
      showSuccess(`Ticket ${row.ticket_number} created.`)
      setShowCreate(false)
      setSelectedId(row.id)
      setError(null)
      await invalidate()
    },
    onError: (err) => setError(errMsg(err, 'Could not create ticket.')),
  })

  const assignMutation = useMutation({
    mutationFn: (userId: number) => {
      if (!selectedId) throw new Error('Select a ticket.')
      return assignSupportTicket(selectedId, userId)
    },
    onSuccess: async (row) => {
      showSuccess(`Ticket ${row.ticket_number} assigned.`)
      setAssignUserId(row.assigned_user_id ?? '')
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'support-tickets', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not assign ticket.')),
  })

  const replyMutation = useMutation({
    mutationFn: () => {
      if (!selectedId) throw new Error('Select a ticket.')
      if (!replyText.trim()) throw new Error('Reply message is required.')
      return replySupportTicket(selectedId, { message: replyText.trim() })
    },
    onSuccess: async (row) => {
      showSuccess('Reply added.')
      setReplyText('')
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'support-tickets', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not send reply.')),
  })

  const startMutation = useMutation({
    mutationFn: (id: number) => startSupportTicket(id),
    onSuccess: async (row) => {
      showSuccess(`Ticket ${row.ticket_number} marked in progress.`)
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'support-tickets', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not start ticket.')),
  })

  const resolveMutation = useMutation({
    mutationFn: (id: number) => resolveSupportTicket(id),
    onSuccess: async (row) => {
      showSuccess(`Ticket ${row.ticket_number} resolved.`)
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'support-tickets', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not resolve ticket.')),
  })

  const closeMutation = useMutation({
    mutationFn: (id: number) => closeSupportTicket(id),
    onSuccess: async (row) => {
      showSuccess(`Ticket ${row.ticket_number} closed.`)
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'support-tickets', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not close ticket.')),
  })

  const onResolve = async (ticket: SupportTicket) => {
    const ok = await confirm({
      title: 'Resolve ticket?',
      message: `Mark ${ticket.ticket_number} as resolved?`,
      confirmLabel: 'Resolve',
      tone: 'primary',
    })
    if (ok) resolveMutation.mutate(ticket.id)
  }

  const onClose = async (ticket: SupportTicket) => {
    const ok = await confirm({
      title: 'Close ticket?',
      message: `Close ${ticket.ticket_number}? Replies will no longer be allowed.`,
      confirmLabel: 'Close',
      tone: 'danger',
    })
    if (ok) closeMutation.mutate(ticket.id)
  }

  const columns: Column<SupportTicket>[] = [
    {
      key: 'ticket',
      header: 'Ticket',
      cell: (row) => (
        <div>
          <p className="font-mono text-sm font-semibold text-ink">{row.ticket_number}</p>
          <p className="line-clamp-1 text-xs text-muted">{row.subject}</p>
        </div>
      ),
    },
    {
      key: 'member',
      header: 'Member',
      cell: (row) => (
        <span className="text-sm text-ink">{memberLabel(row.member)}</span>
      ),
    },
    {
      key: 'priority',
      header: 'Priority',
      cell: (row) => <Badge tone={priorityTone(row.priority)}>{row.priority}</Badge>,
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={statusTone(row.status)}>{statusLabel(row.status)}</Badge>
      ),
    },
    {
      key: 'assignee',
      header: 'Assignee',
      cell: (row) => (
        <span className="text-sm text-muted">
          {row.assigned_user?.name ?? 'Unassigned'}
        </span>
      ),
    },
    {
      key: 'updated',
      header: 'Updated',
      cell: (row) => (
        <span className="text-sm text-muted">{formatDate(row.updated_at)}</span>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button
          size="sm"
          variant="secondary"
          onClick={() => {
            setSelectedId(row.id)
            setShowCreate(false)
            setReplyText('')
            setAssignUserId(row.assigned_user_id ?? '')
            setError(null)
          }}
        >
          Open
        </Button>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader title="Support" description="Ticket queue." />
        <Alert tone="danger">You do not have permission to view support tickets.</Alert>
      </div>
    )
  }

  const selected = detailQuery.data
  const stats = statsQuery.data
  const members = membersQuery.data?.data ?? []
  const staff = staffQuery.data?.data ?? []
  const messages = selected?.messages ?? []

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Support"
        description="Ticket queue — create, assign, reply, and resolve member support requests."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">Staff desk</Badge>
            {canManage ? (
              <Button size="sm" onClick={openCreate}>
                <Plus className="h-4 w-4" />
                New ticket
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<CircleDot className="h-4 w-4" />}
          label="Open"
          value={formatNumber(stats?.open ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<MessageSquare className="h-4 w-4" />}
          label="In progress"
          value={formatNumber(stats?.progress ?? 0)}
        />
        <SummaryChip
          icon={<CheckCircle2 className="h-4 w-4" />}
          label="Resolved"
          value={formatNumber(stats?.resolved ?? 0)}
        />
        <SummaryChip
          icon={<Ticket className="h-4 w-4" />}
          label="Urgent open"
          value={formatNumber(stats?.urgentOpen ?? 0)}
        />
      </div>

      {showCreate && canManage ? (
        <Card className="border-accent/25">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <CardTitle>Create support ticket</CardTitle>
              <CardDescription>
                Open a ticket on behalf of a member with an initial message.
              </CardDescription>
            </div>
            <Button size="sm" variant="ghost" onClick={() => setShowCreate(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form
            onSubmit={(e: FormEvent) => {
              e.preventDefault()
              const errors = collectRequiredErrors([
                { key: 'member_id', label: 'Member', value: createForm.member_id },
                { key: 'category', label: 'Category', value: createForm.category },
                { key: 'subject', label: 'Subject', value: createForm.subject },
                { key: 'message', label: 'Initial message', value: createForm.message },
              ])
              if (Object.keys(errors).length > 0) {
                setFieldErrors(errors)
                return
              }
              setFieldErrors({})
              createMutation.mutate()
            }}
            noValidate
            className="grid gap-3 sm:grid-cols-2"
          >
            <Field
              label="Member"
              required
              error={fieldErrors.member_id}
              className="sm:col-span-2"
            >
              {canViewMembers ? (
                <>
                  <Input
                    className="mb-2"
                    placeholder="Search members…"
                    value={memberSearch}
                    onChange={(e) => setMemberSearch(e.target.value)}
                  />
                  <Select
                    value={createForm.member_id === '' ? '' : String(createForm.member_id)}
                    onChange={(e) => {
                      setCreateForm((f) => ({
                        ...f,
                        member_id: e.target.value ? Number(e.target.value) : '',
                      }))
                      clearFieldError('member_id')
                    }}
                    aria-invalid={Boolean(fieldErrors.member_id)}
                  >
                    <option value="">Select member</option>
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {memberLabel(m)}
                      </option>
                    ))}
                  </Select>
                </>
              ) : (
                <Input
                  type="number"
                  placeholder="Member ID"
                  value={createForm.member_id === '' ? '' : createForm.member_id}
                  onChange={(e) => {
                    setCreateForm((f) => ({
                      ...f,
                      member_id: e.target.value ? Number(e.target.value) : '',
                    }))
                    clearFieldError('member_id')
                  }}
                  aria-invalid={Boolean(fieldErrors.member_id)}
                />
              )}
            </Field>
            <Field label="Category" required error={fieldErrors.category}>
              <Input
                list="support-categories"
                value={createForm.category}
                onChange={(e) => {
                  setCreateForm((f) => ({ ...f, category: e.target.value }))
                  clearFieldError('category')
                }}
                aria-invalid={Boolean(fieldErrors.category)}
              />
              <datalist id="support-categories">
                {CATEGORY_SUGGESTIONS.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
            </Field>
            <div>
              <Label>Priority</Label>
              <Select
                value={createForm.priority}
                onChange={(e) =>
                  setCreateForm((f) => ({
                    ...f,
                    priority: e.target.value as TicketPriority,
                  }))
                }
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </Select>
            </div>
            <Field label="Subject" required error={fieldErrors.subject} className="sm:col-span-2">
              <Input
                value={createForm.subject}
                onChange={(e) => {
                  setCreateForm((f) => ({ ...f, subject: e.target.value }))
                  clearFieldError('subject')
                }}
                placeholder="Brief summary"
                aria-invalid={Boolean(fieldErrors.subject)}
              />
            </Field>
            <Field
              label="Initial message"
              required
              error={fieldErrors.message}
              className="sm:col-span-2"
            >
              <Textarea
                rows={4}
                value={createForm.message}
                onChange={(e) => {
                  setCreateForm((f) => ({ ...f, message: e.target.value }))
                  clearFieldError('message')
                }}
                placeholder="Describe the issue…"
                aria-invalid={Boolean(fieldErrors.message)}
              />
            </Field>
            <div className="flex justify-end gap-2 sm:col-span-2">
              <Button type="button" variant="secondary" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={createMutation.isPending}>
                {createMutation.isPending ? 'Creating…' : 'Create ticket'}
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <Card>
        <div className="mb-4 flex flex-wrap items-end gap-3">
          <div className="min-w-[180px] flex-1">
            <Label>Search</Label>
            <div className="flex gap-2">
              <Input
                placeholder="Ticket #, subject…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    setAppliedSearch(search.trim())
                    setPage(1)
                  }
                }}
              />
              <Button
                size="sm"
                variant="secondary"
                onClick={() => {
                  setAppliedSearch(search.trim())
                  setPage(1)
                }}
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div>
            <Label>Status</Label>
            <Select
              value={status}
              onChange={(e) => {
                setStatus(e.target.value as '' | TicketStatus)
                setPage(1)
              }}
            >
              <option value="">All</option>
              <option value="open">Open</option>
              <option value="in_progress">In progress</option>
              <option value="resolved">Resolved</option>
              <option value="closed">Closed</option>
            </Select>
          </div>
          <div>
            <Label>Priority</Label>
            <Select
              value={priority}
              onChange={(e) => {
                setPriority(e.target.value as '' | TicketPriority)
                setPage(1)
              }}
            >
              <option value="">All</option>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="urgent">Urgent</option>
            </Select>
          </div>
          <div>
            <Label>Assignee</Label>
            <Select
              value={
                assignedFilter === ''
                  ? ''
                  : assignedFilter === 'unassigned'
                    ? 'unassigned'
                    : String(assignedFilter)
              }
              onChange={(e) => {
                const v = e.target.value
                if (v === '') setAssignedFilter('')
                else if (v === 'unassigned') setAssignedFilter('unassigned')
                else setAssignedFilter(Number(v))
                setPage(1)
              }}
            >
              <option value="">Anyone</option>
              <option value="unassigned">Unassigned</option>
              {user ? <option value={String(user.id)}>Assigned to me</option> : null}
              {staff
                .filter((s) => s.id !== user?.id)
                .map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
            </Select>
          </div>
        </div>

        {listQuery.isLoading ? (
          <div className="flex justify-center py-12">
            <Spinner />
          </div>
        ) : listQuery.isError ? (
          <Alert tone="danger">
            {listQuery.error instanceof ApiError
              ? listQuery.error.message
              : 'Failed to load tickets.'}
          </Alert>
        ) : (
          <>
            <DataTable
              columns={columns}
              rows={filteredTickets}
              rowKey={(r) => r.id}
              emptyTitle="No tickets"
              emptyDescription="Create a ticket or clear filters to see the queue."
            />
            <Pagination
              meta={listQuery.data?.meta}
              onPageChange={(p) => {
                setPage(p)
                setSelectedId(null)
              }}
            />
          </>
        )}
      </Card>

      {selectedId != null ? (
        <div className="grid gap-4 xl:grid-cols-[1.15fr_0.95fr]">
          <Card className="border-accent/20">
            <div className="mb-4 flex items-start justify-between gap-3">
              <div>
                <CardTitle>Ticket detail</CardTitle>
                <CardDescription>
                  {selected?.ticket_number ?? `#${selectedId}`}
                </CardDescription>
              </div>
              <Button size="sm" variant="ghost" onClick={() => setSelectedId(null)}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            {detailQuery.isLoading ? (
              <div className="flex justify-center py-8">
                <Spinner />
              </div>
            ) : selected ? (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone={statusTone(selected.status)}>
                    {statusLabel(selected.status)}
                  </Badge>
                  <Badge tone={priorityTone(selected.priority)}>{selected.priority}</Badge>
                  <Badge tone="neutral">{selected.category}</Badge>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-ink">{selected.subject}</h3>
                  <p className="mt-1 text-sm text-muted">
                    {memberLabel(selected.member)}
                    {selected.assigned_user
                      ? ` · Assigned to ${selected.assigned_user.name}`
                      : ' · Unassigned'}
                  </p>
                </div>

                <div>
                  <h4 className="mb-2 text-sm font-semibold text-ink">Conversation</h4>
                  <div className="max-h-[420px] space-y-3 overflow-y-auto rounded-xl border border-white/10 bg-white/[0.02] p-3">
                    {messages.length === 0 ? (
                      <p className="text-sm text-muted">No messages yet.</p>
                    ) : (
                      messages.map((msg) => {
                        const fromStaff = msg.sender_user_id != null
                        const author = fromStaff
                          ? msg.sender_user?.name || 'Staff'
                          : memberLabel(msg.sender_member)
                        return (
                          <div
                            key={msg.id}
                            className={cn(
                              'rounded-xl border px-3 py-2',
                              fromStaff
                                ? 'border-accent/20 bg-accent/10'
                                : 'border-white/10 bg-white/[0.04]',
                            )}
                          >
                            <div className="mb-1 flex flex-wrap items-center justify-between gap-2">
                              <span className="text-xs font-semibold text-ink">{author}</span>
                              <span className="text-xs text-muted">
                                {formatDate(msg.created_at)}
                              </span>
                            </div>
                            <p className="whitespace-pre-wrap text-sm text-ink">{msg.message}</p>
                            {msg.attachment_path ? (
                              <p className="mt-1 text-xs text-muted">
                                Attachment: {msg.attachment_path}
                              </p>
                            ) : null}
                          </div>
                        )
                      })
                    )}
                  </div>
                </div>

                {canManage && selected.status !== 'closed' ? (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault()
                      const errors = collectRequiredErrors([
                        { key: 'replyText', label: 'Reply', value: replyText },
                      ])
                      if (Object.keys(errors).length > 0) {
                        setFieldErrors(errors)
                        return
                      }
                      setFieldErrors({})
                      replyMutation.mutate()
                    }}
                    noValidate
                    className="space-y-2"
                  >
                    <Field label="Reply" required error={fieldErrors.replyText}>
                      <Textarea
                        rows={3}
                        value={replyText}
                        onChange={(e) => {
                          setReplyText(e.target.value)
                          clearFieldError('replyText')
                        }}
                        placeholder="Write a reply to the member…"
                        aria-invalid={Boolean(fieldErrors.replyText)}
                      />
                    </Field>
                    <div className="flex justify-end">
                      <Button type="submit" size="sm" disabled={replyMutation.isPending}>
                        {replyMutation.isPending ? 'Sending…' : 'Send reply'}
                      </Button>
                    </div>
                  </form>
                ) : null}
              </div>
            ) : (
              <Alert tone="danger">Ticket not found.</Alert>
            )}
          </Card>

          {selected && canManage ? (
            <Card className="h-fit border-accent/20">
              <CardTitle className="mb-1">Workflow</CardTitle>
              <CardDescription className="mb-4">
                Assign staff and move the ticket through the queue.
              </CardDescription>

              <div className="space-y-4">
                {selected.status !== 'closed' ? (
                  <div className="space-y-2">
                    <Label>Assign to</Label>
                    {canViewStaff ? (
                      <>
                        <Input
                          className="mb-2"
                          placeholder="Search staff…"
                          value={staffSearch}
                          onChange={(e) => setStaffSearch(e.target.value)}
                        />
                        <Select
                          value={assignUserId === '' ? '' : String(assignUserId)}
                          onChange={(e) =>
                            setAssignUserId(e.target.value ? Number(e.target.value) : '')
                          }
                        >
                          <option value="">Select staff</option>
                          {staff.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.name}
                            </option>
                          ))}
                        </Select>
                      </>
                    ) : (
                      <Input
                        type="number"
                        placeholder="Staff user ID"
                        value={assignUserId === '' ? '' : assignUserId}
                        onChange={(e) =>
                          setAssignUserId(e.target.value ? Number(e.target.value) : '')
                        }
                      />
                    )}
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="secondary"
                        disabled={assignMutation.isPending || assignUserId === ''}
                        onClick={() => assignMutation.mutate(Number(assignUserId))}
                      >
                        Assign
                      </Button>
                      {user ? (
                        <Button
                          size="sm"
                          variant="ghost"
                          disabled={assignMutation.isPending}
                          onClick={() => assignMutation.mutate(user.id)}
                        >
                          Assign to me
                        </Button>
                      ) : null}
                    </div>
                  </div>
                ) : null}

                <div className="flex flex-wrap gap-2">
                  {selected.status === 'open' ? (
                    <Button
                      size="sm"
                      disabled={startMutation.isPending}
                      onClick={() => startMutation.mutate(selected.id)}
                    >
                      Start
                    </Button>
                  ) : null}
                  {selected.status === 'open' || selected.status === 'in_progress' ? (
                    <Button
                      size="sm"
                      variant="secondary"
                      disabled={resolveMutation.isPending}
                      onClick={() => onResolve(selected)}
                    >
                      Resolve
                    </Button>
                  ) : null}
                  {selected.status === 'resolved' ? (
                    <Button
                      size="sm"
                      variant="danger"
                      disabled={closeMutation.isPending}
                      onClick={() => onClose(selected)}
                    >
                      Close
                    </Button>
                  ) : null}
                </div>

                {selected.status === 'closed' ? (
                  <Alert tone="info">This ticket is closed. No further replies or changes.</Alert>
                ) : null}
              </div>
            </Card>
          ) : null}
        </div>
      ) : null}
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}
