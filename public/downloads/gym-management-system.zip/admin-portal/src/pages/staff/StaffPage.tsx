import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  CheckCircle2,
  PauseCircle,
  PlayCircle,
  Plus,
  Search,
  UserCog,
  Users,
  X,
} from 'lucide-react'
import {
  createStaff,
  fetchStaff,
  fetchStaffUser,
  syncStaffBranches,
  syncStaffRoles,
  updateStaff,
  type StaffUser,
} from '@/api/staff'
import { fetchRoles, type RoleRow } from '@/api/rbac'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'

const emptyCreate = {
  name: '',
  email: '',
  phone: '',
  password: '',
  password_confirmation: '',
  role_ids: [] as number[],
  branch_ids: [] as number[],
}

type ActiveFilter = '' | 'active' | 'inactive'

export function StaffPage() {
  const { user: me, branches, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('identity.staff.view')
  const canManage = hasPermission('identity.staff.manage')
  const canAssignRoles = hasPermission('identity.staff.assign_roles')

  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [activeFilter, setActiveFilter] = useState<ActiveFilter>('')
  const [roleFilter, setRoleFilter] = useState<number | ''>('')
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [createForm, setCreateForm] = useState(emptyCreate)
  const [createFieldErrors, setCreateFieldErrors] = useState<FieldErrors>({})
  const [editFieldErrors, setEditFieldErrors] = useState<FieldErrors>({})

  const [editName, setEditName] = useState('')
  const [editEmail, setEditEmail] = useState('')
  const [editPhone, setEditPhone] = useState('')
  const [editPassword, setEditPassword] = useState('')
  const [editPasswordConfirm, setEditPasswordConfirm] = useState('')
  const [editRoleIds, setEditRoleIds] = useState<number[]>([])
  const [editBranchIds, setEditBranchIds] = useState<number[]>([])

  const clearEditFieldError = (key: string) => {
    setEditFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }

  const staffQuery = useQuery({
    queryKey: ['admin', 'staff', page, appliedSearch, activeFilter, roleFilter],
    queryFn: () =>
      fetchStaff({
        page,
        per_page: DEFAULT_PAGE_SIZE,
        search: appliedSearch,
        is_active: activeFilter === '' ? '' : activeFilter === 'active',
        role_id: roleFilter,
      }),
    enabled: canView,
  })

  const rolesQuery = useQuery({
    queryKey: ['admin', 'roles'],
    queryFn: fetchRoles,
    enabled: canView,
  })

  const statsQuery = useQuery({
    queryKey: ['admin', 'staff', 'stats'],
    queryFn: async () => {
      const [all, active, inactive] = await Promise.all([
        fetchStaff({ page: 1, per_page: 1 }),
        fetchStaff({ page: 1, per_page: 1, is_active: true }),
        fetchStaff({ page: 1, per_page: 1, is_active: false }),
      ])
      return {
        total: all.meta.total,
        active: active.meta.total,
        inactive: inactive.meta.total,
      }
    },
    enabled: canView,
  })

  const selectedQuery = useQuery({
    queryKey: ['admin', 'staff', 'detail', selectedId],
    queryFn: () => fetchStaffUser(selectedId!),
    enabled: canView && selectedId != null,
  })

  const rows = staffQuery.data?.data ?? []
  const meta = staffQuery.data?.meta
  const roles = rolesQuery.data ?? []
  const selected = useMemo(() => {
    if (selectedId == null) return null
    return selectedQuery.data ?? rows.find((row) => row.id === selectedId) ?? null
  }, [selectedId, selectedQuery.data, rows])

  const rolesGrouped = useMemo(() => {
    const sorted = [...roles].sort((a, b) => a.name.localeCompare(b.name))
    return {
      system: sorted.filter((role) => role.is_system),
      custom: sorted.filter((role) => !role.is_system),
    }
  }, [roles])

  const staffGroupedByRole = useMemo(() => {
    if (roleFilter !== '') {
      const role = roles.find((r) => r.id === roleFilter)
      return [
        {
          key: String(roleFilter),
          label: role?.name ?? 'Selected role',
          rows,
        },
      ]
    }

    const groups = new Map<string, { key: string; label: string; rows: StaffUser[] }>()
    for (const row of rows) {
      const list = [...(row.roles ?? [])].sort((a, b) => a.name.localeCompare(b.name))
      const primary = list[0]
      const key = primary ? `role-${primary.id}` : 'none'
      const label = primary ? primary.name : 'No role'
      const existing = groups.get(key)
      if (existing) {
        existing.rows.push(row)
      } else {
        groups.set(key, { key, label, rows: [row] })
      }
    }

    return [...groups.values()].sort((a, b) => {
      if (a.key === 'none') return 1
      if (b.key === 'none') return -1
      return a.label.localeCompare(b.label)
    })
  }, [rows, roleFilter, roles])

  useEffect(() => {
    if (!selected) return
    setEditName(selected.name)
    setEditEmail(selected.email)
    setEditPhone(selected.phone ?? '')
    setEditPassword('')
    setEditPasswordConfirm('')
    setEditRoleIds((selected.roles ?? []).map((r) => r.id))
    setEditBranchIds((selected.branches ?? []).map((b) => b.id))
    setEditFieldErrors({})
    // Hydrate only when switching staff; avoid wiping in-progress edits on refetch.
    // eslint-disable-next-line react-hooks/exhaustive-deps -- selected?.id
  }, [selected?.id])

  const invalidate = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'staff'] })
  }

  const syncEditorFromUser = (user: StaffUser) => {
    setEditName(user.name)
    setEditEmail(user.email)
    setEditPhone(user.phone ?? '')
    setEditPassword('')
    setEditPasswordConfirm('')
    setEditRoleIds((user.roles ?? []).map((r) => r.id))
    setEditBranchIds((user.branches ?? []).map((b) => b.id))
  }

  const createMutation = useMutation({
    mutationFn: createStaff,
    onSuccess: async (user) => {
      setError(null)
      showSuccess(`Staff “${user.name}” created.`)
      setShowCreate(false)
      setCreateForm(emptyCreate)
      setSearch('')
      setAppliedSearch('')
      setActiveFilter('')
      setRoleFilter('')
      setPage(1)
      await invalidate()
      setSelectedId(user.id)
      syncEditorFromUser(user)
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to create staff user.')
    },
  })

  const updateMutation = useMutation({
    mutationFn: (payload: Parameters<typeof updateStaff>[1]) =>
      updateStaff(selectedId!, payload),
    onSuccess: async (user) => {
      setError(null)
      showSuccess(`Staff “${user.name}” updated.`)
      syncEditorFromUser(user)
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update staff user.')
    },
  })

  const rolesMutation = useMutation({
    mutationFn: (roleIds: number[]) => syncStaffRoles(selectedId!, roleIds),
    onSuccess: async (user) => {
      setError(null)
      showSuccess(`Roles updated for “${user.name}”.`)
      syncEditorFromUser(user)
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update roles.')
    },
  })

  const branchesMutation = useMutation({
    mutationFn: (branchIds: number[]) => syncStaffBranches(selectedId!, branchIds),
    onSuccess: async (user) => {
      setError(null)
      showSuccess(`Branches updated for “${user.name}”.`)
      syncEditorFromUser(user)
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update branches.')
    },
  })

  const toggleActiveMutation = useMutation({
    mutationFn: ({ userId, isActive }: { userId: number; isActive: boolean }) =>
      updateStaff(userId, { is_active: isActive }),
    onSuccess: async (user) => {
      setError(null)
      showSuccess(user.is_active ? `“${user.name}” activated.` : `“${user.name}” deactivated.`)
      if (selectedId === user.id) {
        syncEditorFromUser(user)
      }
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update status.')
    },
  })

  const applySearch = () => {
    setPage(1)
    setSelectedId(null)
    setAppliedSearch(search.trim())
  }

  const onCreate = (event: FormEvent) => {
    event.preventDefault()
    const next = collectRequiredErrors([
      { key: 'name', label: 'Full name', value: createForm.name },
      { key: 'email', label: 'Email', value: createForm.email },
      { key: 'password', label: 'Password', value: createForm.password },
      {
        key: 'password_confirmation',
        label: 'Confirm password',
        value: createForm.password_confirmation,
      },
      { key: 'role_ids', label: 'Roles', value: createForm.role_ids },
    ])
    if (!next.password && createForm.password && createForm.password.length < 8) {
      next.password = 'Password must be at least 8 characters.'
    }
    if (
      !next.password_confirmation &&
      createForm.password_confirmation &&
      createForm.password !== createForm.password_confirmation
    ) {
      next.password_confirmation = 'Password confirmation does not match.'
    }
    setCreateFieldErrors(next)
    if (Object.keys(next).length) return
    createMutation.mutate({
      name: createForm.name.trim(),
      email: createForm.email.trim(),
      phone: createForm.phone.trim() || null,
      password: createForm.password,
      password_confirmation: createForm.password_confirmation,
      role_ids: createForm.role_ids,
      branch_ids: createForm.branch_ids,
      is_active: true,
    })
  }

  const profileDirty =
    selected != null &&
    (editName.trim() !== selected.name ||
      editEmail.trim() !== selected.email ||
      (editPhone.trim() || '') !== (selected.phone ?? '') ||
      editPassword.length > 0)

  const rolesDirty =
    selected != null &&
    (() => {
      const current = new Set((selected.roles ?? []).map((r) => r.id))
      if (current.size !== editRoleIds.length) return true
      return editRoleIds.some((id) => !current.has(id))
    })()

  const branchesDirty =
    selected != null &&
    (() => {
      const current = new Set((selected.branches ?? []).map((b) => b.id))
      if (current.size !== editBranchIds.length) return true
      return editBranchIds.some((id) => !current.has(id))
    })()

  const onSaveProfile = (event: FormEvent) => {
    event.preventDefault()
    if (!selected) return
    const next = collectRequiredErrors([
      { key: 'name', label: 'Full name', value: editName },
      { key: 'email', label: 'Email', value: editEmail },
      ...(editPassword
        ? [{ key: 'password_confirmation', label: 'Confirm new password', value: editPasswordConfirm }]
        : []),
    ])
    if (editPassword && editPassword.length < 8) {
      next.password = 'Password must be at least 8 characters.'
    }
    if (editPassword && editPasswordConfirm && editPassword !== editPasswordConfirm) {
      next.password_confirmation = 'Password confirmation does not match.'
    }
    setEditFieldErrors(next)
    if (Object.keys(next).length) return
    updateMutation.mutate({
      name: editName.trim(),
      email: editEmail.trim(),
      phone: editPhone.trim() || null,
      ...(editPassword
        ? { password: editPassword, password_confirmation: editPasswordConfirm }
        : {}),
    })
  }

  const onSaveRoles = async () => {
    if (!selected) return
    const roleErrors = collectRequiredErrors([
      { key: 'role_ids', label: 'Roles', value: editRoleIds },
    ])
    setEditFieldErrors((prev) => ({ ...prev, ...roleErrors }))
    if (Object.keys(roleErrors).length) return
    const ok = await confirm({
      title: 'Update roles?',
      message: `Change roles for “${selected.name}”? This immediately affects portal access.`,
      confirmLabel: 'Save roles',
      tone: 'primary',
    })
    if (!ok) return
    rolesMutation.mutate(editRoleIds)
  }

  const onSaveBranches = async () => {
    if (!selected) return
    const ok = await confirm({
      title: 'Update branches?',
      message: `Change branch assignments for “${selected.name}”? Tenant-wide roles still see all branches.`,
      confirmLabel: 'Save branches',
      tone: 'primary',
    })
    if (!ok) return
    branchesMutation.mutate(editBranchIds)
  }

  const onToggleActive = async (row: StaffUser) => {
    if (me?.id === row.id && row.is_active) {
      setError('You cannot deactivate your own account.')
      return
    }
    const next = !row.is_active
    const ok = await confirm({
      title: next ? 'Activate staff?' : 'Deactivate staff?',
      message: next
        ? `Allow “${row.name}” to sign in again?`
        : `Prevent “${row.name}” from signing in? Roles and branches are kept.`,
      confirmLabel: next ? 'Activate' : 'Deactivate',
      tone: next ? 'primary' : 'danger',
    })
    if (!ok) return
    toggleActiveMutation.mutate({ userId: row.id, isActive: next })
  }

  const toggleCreateRole = (roleId: number) => {
    setCreateFieldErrors((errs) => {
      const n = { ...errs }
      delete n.role_ids
      return n
    })
    setCreateForm((c) => ({
      ...c,
      role_ids: c.role_ids.includes(roleId)
        ? c.role_ids.filter((id) => id !== roleId)
        : [...c.role_ids, roleId],
    }))
  }

  const toggleCreateBranch = (branchId: number) => {
    setCreateForm((c) => ({
      ...c,
      branch_ids: c.branch_ids.includes(branchId)
        ? c.branch_ids.filter((id) => id !== branchId)
        : [...c.branch_ids, branchId],
    }))
  }

  const columns: Column<StaffUser>[] = [
    {
      key: 'staff',
      header: 'Staff',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">
            {row.name}
            {me?.id === row.id ? (
              <span className="ml-2 text-xs font-medium text-muted">(you)</span>
            ) : null}
          </p>
          <p className="mt-0.5 text-xs text-muted">{row.email}</p>
        </button>
      ),
    },
    {
      key: 'roles',
      header: 'Roles',
      cell: (row) => {
        const list = row.roles ?? []
        if (list.length === 0) return <span className="text-sm text-muted">No roles</span>
        return (
          <div className="flex flex-wrap gap-1.5">
            {list.slice(0, 2).map((role) => (
              <Badge key={role.id} tone="neutral">
                {role.name}
              </Badge>
            ))}
            {list.length > 2 ? <Badge tone="accent">+{list.length - 2}</Badge> : null}
          </div>
        )
      },
    },
    {
      key: 'branches',
      header: 'Branches',
      cell: (row) => {
        const list = row.branches ?? []
        if (list.length === 0) {
          return <span className="text-sm text-muted">Tenant-wide / unassigned</span>
        }
        return (
          <span className="text-sm text-ink">
            {list
              .slice(0, 2)
              .map((b) => b.name)
              .join(', ')}
            {list.length > 2 ? ` +${list.length - 2}` : ''}
          </span>
        )
      },
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.is_active ? 'success' : 'danger'}>
          {row.is_active ? 'Active' : 'Inactive'}
        </Badge>
      ),
    },
    {
      key: 'last_login',
      header: 'Last login',
      cell: (row) => (
        <span className="text-sm text-muted">{formatDate(row.last_login_at)}</span>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'w-[1%] whitespace-nowrap text-right',
      cell: (row) => (
        <div className="inline-flex items-center justify-end gap-1.5">
          <Button
            size="sm"
            variant="secondary"
            className="shrink-0"
            onClick={() => setSelectedId(row.id)}
          >
            Manage
          </Button>
          {canManage ? (
            <Button
              size="sm"
              variant={row.is_active ? 'ghost' : 'secondary'}
              className="min-w-[7.75rem] shrink-0 justify-center"
              loading={toggleActiveMutation.isPending}
              disabled={me?.id === row.id && row.is_active}
              onClick={() => void onToggleActive(row)}
            >
              {row.is_active ? (
                <>
                  <PauseCircle className="h-4 w-4" />
                  Deactivate
                </>
              ) : (
                <>
                  <PlayCircle className="h-4 w-4" />
                  Activate
                </>
              )}
            </Button>
          ) : null}
        </div>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader
          title="Staff"
          description="Staff roster and role assignment for this gym."
        />
        <Alert tone="danger">You do not have permission to view staff.</Alert>
      </div>
    )
  }

  const stats = statsQuery.data

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Staff"
        description="Staff roster and role assignment for this gym."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">Gym</Badge>
            {canManage ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowCreate(true)
                  setError(null)
                  setCreateFieldErrors({})
                }}
              >
                <Plus className="h-4 w-4" />
                New staff
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      {staffQuery.isError ? (
        <Alert tone="danger">
          {staffQuery.error instanceof ApiError
            ? staffQuery.error.message
            : 'Unable to load staff.'}
          <div className="mt-3">
            <Button size="sm" variant="secondary" onClick={() => void staffQuery.refetch()}>
              Try again
            </Button>
          </div>
        </Alert>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <SummaryChip
          icon={<Users className="h-4 w-4" />}
          label="Total staff"
          value={formatNumber(stats?.total ?? meta?.total ?? 0)}
        />
        <SummaryChip
          icon={<CheckCircle2 className="h-4 w-4" />}
          label="Active"
          value={formatNumber(stats?.active ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<PauseCircle className="h-4 w-4" />}
          label="Inactive"
          value={formatNumber(stats?.inactive ?? 0)}
        />
      </div>

      {showCreate && canManage ? (
        <Card className="border-accent/25">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <CardTitle>Create staff user</CardTitle>
              <CardDescription>
                Invite a team member with roles and optional branch assignments.
              </CardDescription>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowCreate(false)}
              aria-label="Close create form"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form noValidate onSubmit={onCreate} className="grid gap-3 sm:grid-cols-2">
            <Field
              label="Full name"
              htmlFor="new-staff-name"
              required
              error={createFieldErrors.name}
            >
              <Input
                id="new-staff-name"
                value={createForm.name}
                aria-invalid={Boolean(createFieldErrors.name)}
                onChange={(e) => {
                  setCreateFieldErrors((errs) => {
                    const n = { ...errs }
                    delete n.name
                    return n
                  })
                  setCreateForm((c) => ({ ...c, name: e.target.value }))
                }}
              />
            </Field>
            <Field
              label="Email"
              htmlFor="new-staff-email"
              required
              error={createFieldErrors.email}
            >
              <Input
                id="new-staff-email"
                type="email"
                value={createForm.email}
                aria-invalid={Boolean(createFieldErrors.email)}
                onChange={(e) => {
                  setCreateFieldErrors((errs) => {
                    const n = { ...errs }
                    delete n.email
                    return n
                  })
                  setCreateForm((c) => ({ ...c, email: e.target.value }))
                }}
              />
            </Field>
            <div>
              <Label htmlFor="new-staff-phone">Phone</Label>
              <Input
                id="new-staff-phone"
                value={createForm.phone}
                onChange={(e) => setCreateForm((c) => ({ ...c, phone: e.target.value }))}
              />
            </div>
            <div className="hidden sm:block" />
            <Field
              label="Password"
              htmlFor="new-staff-password"
              required
              error={createFieldErrors.password}
            >
              <Input
                id="new-staff-password"
                type="password"
                value={createForm.password}
                aria-invalid={Boolean(createFieldErrors.password)}
                onChange={(e) => {
                  setCreateFieldErrors((errs) => {
                    const n = { ...errs }
                    delete n.password
                    return n
                  })
                  setCreateForm((c) => ({ ...c, password: e.target.value }))
                }}
                autoComplete="new-password"
              />
            </Field>
            <Field
              label="Confirm password"
              htmlFor="new-staff-password-confirm"
              required
              error={createFieldErrors.password_confirmation}
            >
              <Input
                id="new-staff-password-confirm"
                type="password"
                value={createForm.password_confirmation}
                aria-invalid={Boolean(createFieldErrors.password_confirmation)}
                onChange={(e) => {
                  setCreateFieldErrors((errs) => {
                    const n = { ...errs }
                    delete n.password_confirmation
                    return n
                  })
                  setCreateForm((c) => ({ ...c, password_confirmation: e.target.value }))
                }}
                autoComplete="new-password"
              />
            </Field>
            <Field
              label="Roles"
              required
              error={createFieldErrors.role_ids}
              className="sm:col-span-2"
            >
              <Checklist
                items={roles.map((r) => ({ id: r.id, title: r.name, subtitle: r.code }))}
                selectedIds={createForm.role_ids}
                onToggle={toggleCreateRole}
                loading={rolesQuery.isPending}
                empty="No roles found. Seed roles in Settings → Roles."
              />
            </Field>
            <div className="sm:col-span-2">
              <Label>Branches (optional)</Label>
              <Checklist
                items={branches.map((b) => ({ id: b.id, title: b.name, subtitle: b.code }))}
                selectedIds={createForm.branch_ids}
                onToggle={toggleCreateBranch}
                empty="No branches available."
              />
            </div>
            <div className="flex flex-wrap gap-2 sm:col-span-2">
              <Button type="submit" loading={createMutation.isPending}>
                Create staff
              </Button>
              <Button type="button" variant="ghost" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <Card>
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2">
            {(
              [
                { value: '' as ActiveFilter, label: 'All' },
                { value: 'active' as ActiveFilter, label: 'Active' },
                { value: 'inactive' as ActiveFilter, label: 'Inactive' },
              ] as const
            ).map((filter) => {
              const active = activeFilter === filter.value
              return (
                <button
                  key={filter.label}
                  type="button"
                  onClick={() => {
                    setActiveFilter(filter.value)
                    setPage(1)
                    setSelectedId(null)
                  }}
                  className={cn(
                    'rounded-xl px-3 py-2 text-sm font-semibold transition',
                    active
                      ? 'bg-accent text-accent-ink'
                      : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                  )}
                >
                  {filter.label}
                </button>
              )
            })}
          </div>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
            <div>
              <Label htmlFor="staff-role-filter">Roles</Label>
              <Select
                id="staff-role-filter"
                value={roleFilter === '' ? '' : String(roleFilter)}
                onChange={(e) => {
                  setRoleFilter(e.target.value ? Number(e.target.value) : '')
                  setPage(1)
                  setSelectedId(null)
                }}
                aria-label="Filter by role"
                className="sm:w-56"
              >
                <option value="">All Roles</option>
                {rolesGrouped.system.length > 0 ? (
                  <optgroup label="System roles">
                    {rolesGrouped.system.map((role) => (
                      <option key={role.id} value={role.id}>
                        {role.name}
                      </option>
                    ))}
                  </optgroup>
                ) : null}
                {rolesGrouped.custom.length > 0 ? (
                  <optgroup label="Custom roles">
                    {rolesGrouped.custom.map((role) => (
                      <option key={role.id} value={role.id}>
                        {role.name}
                        {rolesGrouped.custom.filter((r) => r.name === role.name).length > 1
                          ? ` (${role.code})`
                          : ''}
                      </option>
                    ))}
                  </optgroup>
                ) : null}
              </Select>
            </div>
            <div className="relative min-w-[14rem] flex-1 sm:max-w-xs">
              <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') applySearch()
                }}
                placeholder="Search name, email…"
                className="pl-10"
                aria-label="Search staff"
              />
            </div>
            <Button size="sm" variant="secondary" onClick={applySearch}>
              Search
            </Button>
          </div>
        </div>
      </Card>

      <div className={cn('grid gap-4', selected ? 'xl:grid-cols-[1fr_24rem]' : '')}>
        <div className="min-w-0">
          {staffQuery.isPending ? (
            <div className="flex justify-center py-20">
              <Spinner label="Loading staff…" />
            </div>
          ) : staffQuery.isError ? (
            <Alert tone="danger">
              {staffQuery.error instanceof ApiError
                ? staffQuery.error.message
                : 'Unable to load staff.'}
              <div className="mt-3">
                <Button size="sm" variant="secondary" onClick={() => void staffQuery.refetch()}>
                  Try again
                </Button>
              </div>
            </Alert>
          ) : rows.length === 0 ? (
            <DataTable
              columns={columns}
              rows={[]}
              rowKey={(row) => row.id}
              emptyTitle="No staff match"
              emptyDescription={
                (meta?.total ?? 0) === 0 && !appliedSearch && !activeFilter && !roleFilter
                  ? 'Create the first staff user for this gym.'
                  : roleFilter
                    ? 'No staff assigned to this role. Try another role or clear the filter.'
                    : 'Try another filter or clear the search.'
              }
            />
          ) : (
            <>
              <div className="space-y-4">
                {staffGroupedByRole.map((group) => (
                  <div key={group.key} className="space-y-2">
                    <div className="flex items-center justify-between gap-2 px-1">
                      <p className="text-sm font-semibold text-ink">{group.label}</p>
                      <Badge tone="neutral">{formatNumber(group.rows.length)}</Badge>
                    </div>
                    <DataTable
                      columns={columns}
                      rows={group.rows}
                      rowKey={(row) => row.id}
                    />
                  </div>
                ))}
              </div>
              <Pagination
                meta={meta}
                onPageChange={(next) => {
                  setPage(next)
                  setSelectedId(null)
                }}
              />
            </>
          )}
        </div>

        {selectedId != null && !selected && selectedQuery.isPending ? (
          <aside className="animate-slide-in">
            <Card className="sticky top-4">
              <div className="flex justify-center py-12">
                <Spinner label="Loading staff…" />
              </div>
            </Card>
          </aside>
        ) : null}

        {selected ? (
          <aside className="animate-slide-in">
            <Card className="sticky top-4 space-y-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                    <UserCog className="h-5 w-5" />
                  </div>
                  <CardTitle className="truncate text-base">{selected.name}</CardTitle>
                  <CardDescription className="truncate">{selected.email}</CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedId(null)}
                  aria-label="Close details"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="flex flex-wrap gap-2">
                <Badge tone={selected.is_active ? 'success' : 'danger'}>
                  {selected.is_active ? 'Active' : 'Inactive'}
                </Badge>
                {me?.id === selected.id ? <Badge tone="accent">You</Badge> : null}
              </div>

              <dl className="space-y-2 text-sm">
                <DetailRow label="Last login" value={formatDate(selected.last_login_at)} />
                <DetailRow
                  label="Roles"
                  value={formatNumber((selected.roles ?? []).length)}
                />
                <DetailRow
                  label="Branches"
                  value={formatNumber((selected.branches ?? []).length)}
                />
              </dl>

              {canManage ? (
                <form
                  noValidate
                  onSubmit={onSaveProfile}
                  className="space-y-3 border-t border-white/12 pt-4"
                >
                  <p className="text-sm font-semibold text-ink">Profile</p>
                  <Field
                    label="Full name"
                    htmlFor="edit-staff-name"
                    required
                    error={editFieldErrors.name}
                  >
                    <Input
                      id="edit-staff-name"
                      value={editName}
                      aria-invalid={Boolean(editFieldErrors.name)}
                      onChange={(e) => {
                        clearEditFieldError('name')
                        setEditName(e.target.value)
                      }}
                    />
                  </Field>
                  <Field
                    label="Email"
                    htmlFor="edit-staff-email"
                    required
                    error={editFieldErrors.email}
                  >
                    <Input
                      id="edit-staff-email"
                      type="email"
                      value={editEmail}
                      aria-invalid={Boolean(editFieldErrors.email)}
                      onChange={(e) => {
                        clearEditFieldError('email')
                        setEditEmail(e.target.value)
                      }}
                    />
                  </Field>
                  <div>
                    <Label htmlFor="edit-staff-phone">Phone</Label>
                    <Input
                      id="edit-staff-phone"
                      value={editPhone}
                      onChange={(e) => setEditPhone(e.target.value)}
                    />
                  </div>
                  <Field
                    label="Reset password"
                    htmlFor="edit-staff-password"
                    error={editFieldErrors.password}
                    hint="Leave blank to keep the current password."
                  >
                    <Input
                      id="edit-staff-password"
                      type="password"
                      value={editPassword}
                      aria-invalid={Boolean(editFieldErrors.password)}
                      onChange={(e) => {
                        clearEditFieldError('password')
                        clearEditFieldError('password_confirmation')
                        setEditPassword(e.target.value)
                      }}
                      placeholder="Leave blank to keep"
                      autoComplete="new-password"
                    />
                  </Field>
                  {editPassword ? (
                    <Field
                      label="Confirm new password"
                      htmlFor="edit-staff-password-confirm"
                      required
                      error={editFieldErrors.password_confirmation}
                    >
                      <Input
                        id="edit-staff-password-confirm"
                        type="password"
                        value={editPasswordConfirm}
                        aria-invalid={Boolean(editFieldErrors.password_confirmation)}
                        onChange={(e) => {
                          clearEditFieldError('password_confirmation')
                          setEditPasswordConfirm(e.target.value)
                        }}
                        autoComplete="new-password"
                      />
                    </Field>
                  ) : null}
                  <Button
                    type="submit"
                    size="sm"
                    loading={updateMutation.isPending}
                    disabled={!profileDirty}
                  >
                    Save profile
                  </Button>
                </form>
              ) : null}

              {canAssignRoles ? (
                <div className="space-y-3 border-t border-white/12 pt-4">
                  <Field label="Roles" required error={editFieldErrors.role_ids}>
                    <Checklist
                      items={roles.map((r: RoleRow) => ({
                        id: r.id,
                        title: r.name,
                        subtitle: r.code,
                      }))}
                      selectedIds={editRoleIds}
                      onToggle={(id) => {
                        clearEditFieldError('role_ids')
                        setEditRoleIds((current) =>
                          current.includes(id)
                            ? current.filter((x) => x !== id)
                            : [...current, id],
                        )
                      }}
                      loading={rolesQuery.isPending}
                    />
                  </Field>
                  <Button
                    size="sm"
                    loading={rolesMutation.isPending}
                    disabled={!rolesDirty}
                    onClick={() => void onSaveRoles()}
                  >
                    Save roles
                  </Button>
                </div>
              ) : null}

              {canManage ? (
                <div className="space-y-3 border-t border-white/12 pt-4">
                  <p className="text-sm font-semibold text-ink">Branches</p>
                  <Checklist
                    items={branches.map((b) => ({
                      id: b.id,
                      title: b.name,
                      subtitle: b.code,
                    }))}
                    selectedIds={editBranchIds}
                    onToggle={(id) =>
                      setEditBranchIds((current) =>
                        current.includes(id)
                          ? current.filter((x) => x !== id)
                          : [...current, id],
                      )
                    }
                  />
                  <Button
                    size="sm"
                    variant="secondary"
                    loading={branchesMutation.isPending}
                    disabled={!branchesDirty}
                    onClick={() => void onSaveBranches()}
                  >
                    Save branches
                  </Button>
                </div>
              ) : null}

              {canManage ? (
                <div className="border-t border-white/12 pt-4">
                  <Button
                    size="sm"
                    variant={selected.is_active ? 'danger' : 'secondary'}
                    loading={toggleActiveMutation.isPending}
                    disabled={me?.id === selected.id && selected.is_active}
                    onClick={() => void onToggleActive(selected)}
                    className="w-full"
                  >
                    {selected.is_active ? (
                      <>
                        <PauseCircle className="h-4 w-4" />
                        Deactivate staff
                      </>
                    ) : (
                      <>
                        <PlayCircle className="h-4 w-4" />
                        Activate staff
                      </>
                    )}
                  </Button>
                </div>
              ) : null}
            </Card>
          </aside>
        ) : null}
      </div>
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="shrink-0 text-muted">{label}</dt>
      <dd className="text-right font-semibold text-ink">{value}</dd>
    </div>
  )
}

function Checklist({
  items,
  selectedIds,
  onToggle,
  loading,
  empty,
}: {
  items: Array<{ id: number; title: string; subtitle?: string }>
  selectedIds: number[]
  onToggle: (id: number) => void
  loading?: boolean
  empty?: string
}) {
  if (loading) {
    return (
      <div className="flex justify-center py-4">
        <Spinner label="Loading…" />
      </div>
    )
  }

  if (items.length === 0) {
    return (
      <p className="mt-1.5 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-sm text-muted">
        {empty ?? 'Nothing to show.'}
      </p>
    )
  }

  return (
    <div className="mt-1.5 max-h-44 space-y-1.5 overflow-y-auto rounded-xl border border-white/10 bg-white/[0.03] p-2">
      {items.map((item) => {
        const checked = selectedIds.includes(item.id)
        return (
          <label
            key={item.id}
            className={cn(
              'flex cursor-pointer items-start gap-2.5 rounded-lg px-2.5 py-2 transition',
              checked ? 'bg-accent/15' : 'hover:bg-white/8',
            )}
          >
            <input
              type="checkbox"
              className="mt-1"
              checked={checked}
              onChange={() => onToggle(item.id)}
            />
            <span className="min-w-0">
              <span className="block text-sm font-semibold text-ink">{item.title}</span>
              {item.subtitle ? (
                <span className="block font-mono text-xs text-muted">{item.subtitle}</span>
              ) : null}
            </span>
          </label>
        )
      })}
    </div>
  )
}
