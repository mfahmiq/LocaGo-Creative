import { PageHeader } from '@/components/ui/PageHeader'
import { EmptyState } from '@/components/ui/EmptyState'
import { Link } from 'react-router-dom'

export function PlaceholderPage({
  title,
  description,
}: {
  title: string
  description: string
}) {
  return (
    <div className="animate-fade-up">
      <PageHeader title={title} description={description} />
      <EmptyState
        title={`${title} is warming up`}
        description="This module is next on the build list. Auth, layout, forms, tables, and charts are already in place."
        action={
          <Link
            to="/"
            className="inline-flex h-11 items-center justify-center rounded-xl bg-accent px-4 text-sm font-semibold text-accent-ink shadow-[0_10px_24px_-12px_rgba(198,255,26,0.85)] transition hover:brightness-110"
          >
            Back to dashboard
          </Link>
        }
      />
    </div>
  )
}
