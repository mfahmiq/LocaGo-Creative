import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  AlertTriangle,
  ClipboardList,
  MessageSquarePlus,
  Plus,
  Search,
  UserCheck,
  Users,
  X,
} from 'lucide-react'
import {
  addLeadNote,
  convertLead,
  createLead,
  fetchLeadNotes,
  fetchLeads,
  updateLead,
  type Lead,
} from '@/api/leads'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useBranchFilter } from '@/hooks/useBranchFilter'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'

const emptyCreate = {
  first_name: '',
  last_name: '',
  email: '',
  phone: '',
  home_branch_id: '',
  gender: '',
  date_of_birth: '',
  emergency_name: '',
  emergency_phone: '',
}

function formatDateTime(value?: string | null): string {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return new Intl.DateTimeFormat(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date)
}

export function LeadsPage() {
  const { branches, branchId, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('sales.leads.view')
  const canManage = hasPermission('sales.leads.manage')

  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [branchFilter, setBranchFilter] = useBranchFilter()
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [createForm, setCreateForm] = useState(emptyCreate)
  const [createFieldErrors, setCreateFieldErrors] = useState<FieldErrors>({})
  const [editFieldErrors, setEditFieldErrors] = useState<FieldErrors>({})
  const [noteFieldErrors, setNoteFieldErrors] = useState<FieldErrors>({})
  const [noteText, setNoteText] = useState('')
  const [noteAlert, setNoteAlert] = useState(false)
  const [convertedMemberId, setConvertedMemberId] = useState<number | null>(null)

  const [editFirstName, setEditFirstName] = useState('')
  const [editLastName, setEditLastName] = useState('')
  const [editEmail, setEditEmail] = useState('')
  const [editPhone, setEditPhone] = useState('')
  const [editBranchId, setEditBranchId] = useState<number | ''>('')
  const [editGender, setEditGender] = useState('')
  const [editDob, setEditDob] = useState('')
  const [editEmergencyName, setEditEmergencyName] = useState('')
  const [editEmergencyPhone, setEditEmergencyPhone] = useState('')

  const clearEditFieldError = (key: string) => {
    setEditFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }

  const leadsQuery = useQuery({
    queryKey: ['admin', 'leads', page, appliedSearch, branchFilter],
    queryFn: () =>
      fetchLeads({
        page,
        per_page: DEFAULT_PAGE_SIZE,
        search: appliedSearch,
        branch_id: branchFilter,
      }),
    enabled: canView,
  })

  const notesQuery = useQuery({
    queryKey: ['admin', 'leads', selectedId, 'notes'],
    queryFn: () => fetchLeadNotes(selectedId!),
    enabled: canView && selectedId != null,
  })

  const rows = leadsQuery.data?.data ?? []
  const meta = leadsQuery.data?.meta
  const selected = useMemo(
    () => rows.find((row) => row.id === selectedId) ?? null,
    [rows, selectedId],
  )
  const notes = notesQuery.data ?? []
  const alertNotes = notes.filter((n) => n.is_alert).length

  useEffect(() => {
    if (!showCreate) return
    if (createForm.home_branch_id) return
    const preferred =
      (branchId != null && branches.some((b) => b.id === branchId) ? branchId : null) ??
      branches[0]?.id
    if (preferred != null) {
      setCreateForm((current) => ({ ...current, home_branch_id: String(preferred) }))
    }
  }, [showCreate, createForm.home_branch_id, branchId, branches])

  useEffect(() => {
    if (!selected) return
    setEditFirstName(selected.first_name)
    setEditLastName(selected.last_name)
    setEditEmail(selected.email ?? '')
    setEditPhone(selected.phone ?? '')
    setEditBranchId(selected.home_branch_id ?? '')
    setEditGender(selected.gender ?? '')
    setEditDob(selected.date_of_birth ?? '')
    setEditEmergencyName(selected.emergency_name ?? '')
    setEditEmergencyPhone(selected.emergency_phone ?? '')
    setNoteText('')
    setNoteAlert(false)
    setConvertedMemberId(null)
    setEditFieldErrors({})
    setNoteFieldErrors({})
  }, [selected])

  const invalidate = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'leads'] })
    await queryClient.invalidateQueries({ queryKey: ['admin', 'members'] })
  }

  const createMutation = useMutation({
    mutationFn: createLead,
    onSuccess: async (lead) => {
      setError(null)
      showSuccess(`Lead “${lead.full_name}” added to the pipeline.`)
      setShowCreate(false)
      setCreateForm(emptyCreate)
      await invalidate()
      setSelectedId(lead.id)
      setPage(1)
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to create lead.')
    },
  })

  const updateMutation = useMutation({
    mutationFn: (payload: Parameters<typeof updateLead>[1]) =>
      updateLead(selectedId!, payload),
    onSuccess: async (lead) => {
      setError(null)
      showSuccess(`Lead “${lead.full_name}” updated.`)
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update lead.')
    },
  })

  const noteMutation = useMutation({
    mutationFn: () =>
      addLeadNote(selectedId!, {
        note: noteText.trim(),
        is_alert: noteAlert,
      }),
    onSuccess: async () => {
      setError(null)
      showSuccess('Note added.')
      setNoteText('')
      setNoteAlert(false)
      await queryClient.invalidateQueries({
        queryKey: ['admin', 'leads', selectedId, 'notes'],
      })
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to add note.')
    },
  })

  const convertMutation = useMutation({
    mutationFn: (leadId: number) => convertLead(leadId),
    onSuccess: async (member) => {
      setError(null)
      showSuccess(`“${member.full_name}” converted to an active member.`)
      setConvertedMemberId(member.id)
      setSelectedId(null)
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to convert lead.')
    },
  })

  const applySearch = () => {
    setPage(1)
    setSelectedId(null)
    setAppliedSearch(search.trim())
  }

  const onCreate = (event: FormEvent) => {
    event.preventDefault()
    const next = collectRequiredErrors([
      { key: 'first_name', label: 'First name', value: createForm.first_name },
      { key: 'last_name', label: 'Last name', value: createForm.last_name },
      { key: 'home_branch_id', label: 'Home branch', value: createForm.home_branch_id },
    ])
    setCreateFieldErrors(next)
    if (Object.keys(next).length) return
    createMutation.mutate({
      first_name: createForm.first_name.trim(),
      last_name: createForm.last_name.trim(),
      home_branch_id: Number(createForm.home_branch_id),
      email: createForm.email.trim() || null,
      phone: createForm.phone.trim() || null,
      gender: createForm.gender || null,
      date_of_birth: createForm.date_of_birth || null,
      emergency_name: createForm.emergency_name.trim() || null,
      emergency_phone: createForm.emergency_phone.trim() || null,
    })
  }

  const profileDirty =
    selected != null &&
    (editFirstName.trim() !== selected.first_name ||
      editLastName.trim() !== selected.last_name ||
      (editEmail.trim() || '') !== (selected.email ?? '') ||
      (editPhone.trim() || '') !== (selected.phone ?? '') ||
      editBranchId !== (selected.home_branch_id ?? '') ||
      (editGender || '') !== (selected.gender ?? '') ||
      (editDob || '') !== (selected.date_of_birth ?? '') ||
      (editEmergencyName.trim() || '') !== (selected.emergency_name ?? '') ||
      (editEmergencyPhone.trim() || '') !== (selected.emergency_phone ?? ''))

  const onSaveProfile = (event: FormEvent) => {
    event.preventDefault()
    if (!selected) return
    const next = collectRequiredErrors([
      { key: 'first_name', label: 'First name', value: editFirstName },
      { key: 'last_name', label: 'Last name', value: editLastName },
      { key: 'home_branch_id', label: 'Home branch', value: editBranchId },
    ])
    setEditFieldErrors(next)
    if (Object.keys(next).length) return
    updateMutation.mutate({
      first_name: editFirstName.trim(),
      last_name: editLastName.trim(),
      home_branch_id: Number(editBranchId),
      email: editEmail.trim() || null,
      phone: editPhone.trim() || null,
      gender: editGender || null,
      date_of_birth: editDob || null,
      emergency_name: editEmergencyName.trim() || null,
      emergency_phone: editEmergencyPhone.trim() || null,
    })
  }

  const onAddNote = (event: FormEvent) => {
    event.preventDefault()
    const next = collectRequiredErrors([{ key: 'note', label: 'Note', value: noteText }])
    setNoteFieldErrors(next)
    if (Object.keys(next).length) return
    noteMutation.mutate()
  }

  const onConvert = async (row: Lead) => {
    const ok = await confirm({
      title: 'Convert lead to member?',
      message: `Activate “${row.full_name}” as a gym member? They will leave the leads pipeline and appear in Members.`,
      confirmLabel: 'Convert',
      tone: 'primary',
    })
    if (!ok) return
    convertMutation.mutate(row.id)
  }

  const columns: Column<Lead>[] = [
    {
      key: 'lead',
      header: 'Lead',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">{row.full_name}</p>
          <p className="mt-0.5 font-mono text-xs text-muted">{row.member_code}</p>
        </button>
      ),
    },
    {
      key: 'contact',
      header: 'Contact',
      cell: (row) => (
        <div className="text-sm">
          <p className="text-ink">{row.email || '—'}</p>
          <p className="text-muted">{row.phone || '—'}</p>
        </div>
      ),
    },
    {
      key: 'branch',
      header: 'Branch',
      cell: (row) => (
        <span className="text-sm text-ink">{row.home_branch?.name ?? '—'}</span>
      ),
    },
    {
      key: 'created',
      header: 'Captured',
      cell: (row) => (
        <span className="text-sm text-muted">{formatDateTime(row.created_at)}</span>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <div className="flex flex-wrap justify-end gap-1.5">
          <Button size="sm" variant="secondary" onClick={() => setSelectedId(row.id)}>
            Open
          </Button>
          {canManage ? (
            <Button
              size="sm"
              variant="ghost"
              loading={convertMutation.isPending}
              onClick={() => void onConvert(row)}
            >
              <UserCheck className="h-4 w-4" />
              Convert
            </Button>
          ) : null}
        </div>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader
          title="Leads"
          description="Sales lead pipeline — capture prospects and convert them to members."
        />
        <Alert tone="danger">You do not have permission to view leads.</Alert>
      </div>
    )
  }

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Leads"
        description="Sales lead pipeline — capture prospects and convert them to members."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="accent">Pipeline</Badge>
            {canManage ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowCreate(true)
                  setError(null)
                  setCreateFieldErrors({})
                }}
              >
                <Plus className="h-4 w-4" />
                New lead
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      {convertedMemberId != null ? (
        <Alert tone="success">
          Lead converted successfully.{' '}
          <Link to="/members" className="font-semibold underline underline-offset-2">
            Open Members directory
          </Link>
        </Alert>
      ) : null}

      {leadsQuery.isError ? (
        <Alert tone="danger">
          {leadsQuery.error instanceof ApiError
            ? leadsQuery.error.message
            : 'Unable to load leads.'}
          <div className="mt-3">
            <Button size="sm" variant="secondary" onClick={() => void leadsQuery.refetch()}>
              Try again
            </Button>
          </div>
        </Alert>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <SummaryChip
          icon={<ClipboardList className="h-4 w-4" />}
          label="Open leads"
          value={formatNumber(meta?.total ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<Users className="h-4 w-4" />}
          label="On this page"
          value={formatNumber(rows.length)}
        />
        <SummaryChip
          icon={<AlertTriangle className="h-4 w-4" />}
          label="Alert notes (selected)"
          value={formatNumber(selectedId != null ? alertNotes : 0)}
        />
      </div>

      {showCreate && canManage ? (
        <Card className="border-accent/25">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <CardTitle>Capture lead</CardTitle>
              <CardDescription>
                Add a prospect to the pipeline. Convert later when they join as a member.
              </CardDescription>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowCreate(false)}
              aria-label="Close create form"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form noValidate onSubmit={onCreate} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field
              label="First name"
              htmlFor="new-lead-first"
              required
              error={createFieldErrors.first_name}
            >
              <Input
                id="new-lead-first"
                value={createForm.first_name}
                aria-invalid={Boolean(createFieldErrors.first_name)}
                onChange={(e) => {
                  setCreateFieldErrors((errs) => {
                    const n = { ...errs }
                    delete n.first_name
                    return n
                  })
                  setCreateForm((c) => ({ ...c, first_name: e.target.value }))
                }}
              />
            </Field>
            <Field
              label="Last name"
              htmlFor="new-lead-last"
              required
              error={createFieldErrors.last_name}
            >
              <Input
                id="new-lead-last"
                value={createForm.last_name}
                aria-invalid={Boolean(createFieldErrors.last_name)}
                onChange={(e) => {
                  setCreateFieldErrors((errs) => {
                    const n = { ...errs }
                    delete n.last_name
                    return n
                  })
                  setCreateForm((c) => ({ ...c, last_name: e.target.value }))
                }}
              />
            </Field>
            <Field
              label="Home branch"
              htmlFor="new-lead-branch"
              required
              error={createFieldErrors.home_branch_id}
            >
              <Select
                id="new-lead-branch"
                value={createForm.home_branch_id}
                aria-invalid={Boolean(createFieldErrors.home_branch_id)}
                onChange={(e) => {
                  setCreateFieldErrors((errs) => {
                    const n = { ...errs }
                    delete n.home_branch_id
                    return n
                  })
                  setCreateForm((c) => ({ ...c, home_branch_id: e.target.value }))
                }}
              >
                <option value="">Select branch…</option>
                {branches.map((branch) => (
                  <option key={branch.id} value={branch.id}>
                    {branch.name}
                  </option>
                ))}
              </Select>
            </Field>
            <div>
              <Label htmlFor="new-lead-email">Email</Label>
              <Input
                id="new-lead-email"
                type="email"
                value={createForm.email}
                onChange={(e) => setCreateForm((c) => ({ ...c, email: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="new-lead-phone">Phone</Label>
              <Input
                id="new-lead-phone"
                value={createForm.phone}
                onChange={(e) => setCreateForm((c) => ({ ...c, phone: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="new-lead-gender">Gender</Label>
              <Select
                id="new-lead-gender"
                value={createForm.gender}
                onChange={(e) => setCreateForm((c) => ({ ...c, gender: e.target.value }))}
              >
                <option value="">Not specified</option>
                <option value="female">Female</option>
                <option value="male">Male</option>
                <option value="other">Other</option>
              </Select>
            </div>
            <div>
              <Label htmlFor="new-lead-dob">Date of birth</Label>
              <Input
                id="new-lead-dob"
                type="date"
                value={createForm.date_of_birth}
                onChange={(e) =>
                  setCreateForm((c) => ({ ...c, date_of_birth: e.target.value }))
                }
              />
            </div>
            <div>
              <Label htmlFor="new-lead-emergency-name">Emergency contact</Label>
              <Input
                id="new-lead-emergency-name"
                value={createForm.emergency_name}
                onChange={(e) =>
                  setCreateForm((c) => ({ ...c, emergency_name: e.target.value }))
                }
              />
            </div>
            <div>
              <Label htmlFor="new-lead-emergency-phone">Emergency phone</Label>
              <Input
                id="new-lead-emergency-phone"
                value={createForm.emergency_phone}
                onChange={(e) =>
                  setCreateForm((c) => ({ ...c, emergency_phone: e.target.value }))
                }
              />
            </div>
            <div className="flex flex-wrap items-end gap-2 sm:col-span-2 lg:col-span-3">
              <Button type="submit" loading={createMutation.isPending}>
                Add to pipeline
              </Button>
              <Button type="button" variant="ghost" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <Card>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-muted">
            Showing open leads only. Converted prospects move to{' '}
            <Link to="/members" className="font-semibold text-accent hover:underline">
              Members
            </Link>
            .
          </p>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            {branches.length > 0 ? (
              <Select
                value={branchFilter === '' ? '' : String(branchFilter)}
                onChange={(e) => {
                  setBranchFilter(e.target.value ? Number(e.target.value) : '')
                  setPage(1)
                  setSelectedId(null)
                }}
                aria-label="Filter by branch"
                className="sm:w-44"
              >
                <option value="">All branches</option>
                {branches.map((branch) => (
                  <option key={branch.id} value={branch.id}>
                    {branch.name}
                  </option>
                ))}
              </Select>
            ) : null}
            <div className="relative min-w-[14rem] flex-1 sm:max-w-xs">
              <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') applySearch()
                }}
                placeholder="Search name, email, phone…"
                className="pl-10"
                aria-label="Search leads"
              />
            </div>
            <Button size="sm" variant="secondary" onClick={applySearch}>
              Search
            </Button>
          </div>
        </div>
      </Card>

      <div className={cn('grid gap-4', selected ? 'xl:grid-cols-[1fr_26rem]' : '')}>
        <div className="min-w-0">
          {leadsQuery.isPending ? (
            <div className="flex justify-center py-20">
              <Spinner label="Loading leads…" />
            </div>
          ) : (
            <>
              <DataTable
                columns={columns}
                rows={rows}
                rowKey={(row) => row.id}
                emptyTitle="No leads in the pipeline"
                emptyDescription={
                  (meta?.total ?? 0) === 0 && !appliedSearch && !branchFilter
                    ? 'Capture the first prospect to start your sales pipeline.'
                    : 'Try another branch filter or clear the search.'
                }
              />
              <Pagination
                meta={meta}
                onPageChange={(next) => {
                  setPage(next)
                  setSelectedId(null)
                }}
              />
            </>
          )}
        </div>

        {selected ? (
          <aside className="animate-slide-in">
            <Card className="sticky top-4 space-y-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                    <ClipboardList className="h-5 w-5" />
                  </div>
                  <CardTitle className="truncate text-base">{selected.full_name}</CardTitle>
                  <CardDescription className="font-mono">{selected.member_code}</CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedId(null)}
                  aria-label="Close details"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="flex flex-wrap gap-2">
                <Badge tone="accent">Lead</Badge>
                {selected.home_branch ? (
                  <Badge tone="neutral">{selected.home_branch.name}</Badge>
                ) : null}
              </div>

              <dl className="space-y-2 text-sm">
                <DetailRow label="Captured" value={formatDateTime(selected.created_at)} />
                <DetailRow label="Email" value={selected.email ?? '—'} />
                <DetailRow label="Phone" value={selected.phone ?? '—'} />
              </dl>

              {canManage ? (
                <Button
                  size="sm"
                  loading={convertMutation.isPending}
                  onClick={() => void onConvert(selected)}
                  className="w-full"
                >
                  <UserCheck className="h-4 w-4" />
                  Convert to member
                </Button>
              ) : null}

              {canManage ? (
                <form
                  noValidate
                  onSubmit={onSaveProfile}
                  className="space-y-3 border-t border-white/12 pt-4"
                >
                  <p className="text-sm font-semibold text-ink">Profile</p>
                  <div className="grid grid-cols-2 gap-2">
                    <Field
                      label="First name"
                      htmlFor="edit-lead-first"
                      required
                      error={editFieldErrors.first_name}
                    >
                      <Input
                        id="edit-lead-first"
                        value={editFirstName}
                        aria-invalid={Boolean(editFieldErrors.first_name)}
                        onChange={(e) => {
                          clearEditFieldError('first_name')
                          setEditFirstName(e.target.value)
                        }}
                      />
                    </Field>
                    <Field
                      label="Last name"
                      htmlFor="edit-lead-last"
                      required
                      error={editFieldErrors.last_name}
                    >
                      <Input
                        id="edit-lead-last"
                        value={editLastName}
                        aria-invalid={Boolean(editFieldErrors.last_name)}
                        onChange={(e) => {
                          clearEditFieldError('last_name')
                          setEditLastName(e.target.value)
                        }}
                      />
                    </Field>
                  </div>
                  <div>
                    <Label htmlFor="edit-lead-email">Email</Label>
                    <Input
                      id="edit-lead-email"
                      type="email"
                      value={editEmail}
                      onChange={(e) => setEditEmail(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-lead-phone">Phone</Label>
                    <Input
                      id="edit-lead-phone"
                      value={editPhone}
                      onChange={(e) => setEditPhone(e.target.value)}
                    />
                  </div>
                  <Field
                    label="Home branch"
                    htmlFor="edit-lead-branch"
                    required
                    error={editFieldErrors.home_branch_id}
                  >
                    <Select
                      id="edit-lead-branch"
                      value={editBranchId === '' ? '' : String(editBranchId)}
                      aria-invalid={Boolean(editFieldErrors.home_branch_id)}
                      onChange={(e) => {
                        clearEditFieldError('home_branch_id')
                        setEditBranchId(e.target.value ? Number(e.target.value) : '')
                      }}
                    >
                      <option value="">Select branch…</option>
                      {branches.map((branch) => (
                        <option key={branch.id} value={branch.id}>
                          {branch.name}
                        </option>
                      ))}
                    </Select>
                  </Field>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label htmlFor="edit-lead-gender">Gender</Label>
                      <Select
                        id="edit-lead-gender"
                        value={editGender}
                        onChange={(e) => setEditGender(e.target.value)}
                      >
                        <option value="">Not specified</option>
                        <option value="female">Female</option>
                        <option value="male">Male</option>
                        <option value="other">Other</option>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="edit-lead-dob">Date of birth</Label>
                      <Input
                        id="edit-lead-dob"
                        type="date"
                        value={editDob}
                        onChange={(e) => setEditDob(e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="edit-lead-emergency-name">Emergency contact</Label>
                    <Input
                      id="edit-lead-emergency-name"
                      value={editEmergencyName}
                      onChange={(e) => setEditEmergencyName(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-lead-emergency-phone">Emergency phone</Label>
                    <Input
                      id="edit-lead-emergency-phone"
                      value={editEmergencyPhone}
                      onChange={(e) => setEditEmergencyPhone(e.target.value)}
                    />
                  </div>
                  <Button
                    type="submit"
                    size="sm"
                    loading={updateMutation.isPending}
                    disabled={!profileDirty}
                  >
                    Save profile
                  </Button>
                </form>
              ) : null}

              <div className="space-y-3 border-t border-white/12 pt-4">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-semibold text-ink">Follow-up notes</p>
                  <Badge tone="neutral">{formatNumber(notes.length)}</Badge>
                </div>

                {canManage ? (
                  <form noValidate onSubmit={onAddNote} className="space-y-2">
                    <Field
                      label="Add note"
                      htmlFor="lead-note"
                      required
                      error={noteFieldErrors.note}
                    >
                      <Textarea
                        id="lead-note"
                        value={noteText}
                        rows={3}
                        placeholder="Call outcome, interest level, next step…"
                        aria-invalid={Boolean(noteFieldErrors.note)}
                        onChange={(e) => {
                          setNoteFieldErrors({})
                          setNoteText(e.target.value)
                        }}
                      />
                    </Field>
                    <label className="flex items-center gap-2 text-sm text-muted">
                      <input
                        type="checkbox"
                        checked={noteAlert}
                        onChange={(e) => setNoteAlert(e.target.checked)}
                      />
                      Mark as alert
                    </label>
                    <Button
                      type="submit"
                      size="sm"
                      variant="secondary"
                      loading={noteMutation.isPending}
                    >
                      <MessageSquarePlus className="h-4 w-4" />
                      Add note
                    </Button>
                  </form>
                ) : null}

                {notesQuery.isPending ? (
                  <div className="flex justify-center py-6">
                    <Spinner label="Loading notes…" />
                  </div>
                ) : notes.length === 0 ? (
                  <p className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-sm text-muted">
                    No notes yet.
                  </p>
                ) : (
                  <ul className="max-h-64 space-y-2 overflow-y-auto">
                    {notes.map((note) => (
                      <li
                        key={note.id}
                        className={cn(
                          'rounded-xl border px-3 py-2.5 text-sm',
                          note.is_alert
                            ? 'border-warning/30 bg-warning/10'
                            : 'border-white/10 bg-white/[0.04]',
                        )}
                      >
                        <div className="mb-1 flex items-center justify-between gap-2">
                          <span className="text-xs text-muted">
                            {formatDateTime(note.created_at)}
                          </span>
                          {note.is_alert ? (
                            <Badge tone="warning">Alert</Badge>
                          ) : null}
                        </div>
                        <p className="whitespace-pre-wrap text-ink">{note.note}</p>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </Card>
          </aside>
        ) : null}
      </div>
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="shrink-0 text-muted">{label}</dt>
      <dd className="text-right font-semibold text-ink">{value}</dd>
    </div>
  )
}
