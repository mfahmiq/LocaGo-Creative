import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { api } from '@/api/client'
import type { ApiSuccess } from '@/api/types'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Spinner } from '@/components/ui/Spinner'

type LoyaltySettings = {
  id: number
  is_enabled: boolean
  points_per_check_in: number
  points_per_100_currency: number
  points_per_referral: number
  redeem_value_per_100_points: number
}

export function LoyaltyPanel() {
  const { hasPermission } = useAuth()
  const canView = hasPermission('marketing.loyalty.view')
  const canManage = hasPermission('marketing.loyalty.manage')
  const { showSuccess } = useFeedback()
  const queryClient = useQueryClient()
  const [error, setError] = useState<string | null>(null)
  const [memberId, setMemberId] = useState('')
  const [adjustPoints, setAdjustPoints] = useState(10)
  const [adjustNotes, setAdjustNotes] = useState('')

  const settingsQuery = useQuery({
    queryKey: ['admin', 'loyalty', 'settings'],
    queryFn: async () => {
      const { data } = await api.get<ApiSuccess<LoyaltySettings>>('/admin/loyalty/settings')
      return data.data
    },
    enabled: canView,
  })

  const [draft, setDraft] = useState<Partial<LoyaltySettings>>({})
  const settings = { ...settingsQuery.data, ...draft }

  const saveMutation = useMutation({
    mutationFn: async () => {
      const { data } = await api.put<ApiSuccess<LoyaltySettings>>('/admin/loyalty/settings', {
        is_enabled: Boolean(settings.is_enabled),
        points_per_check_in: Number(settings.points_per_check_in ?? 0),
        points_per_100_currency: Number(settings.points_per_100_currency ?? 0),
        points_per_referral: Number(settings.points_per_referral ?? 0),
        redeem_value_per_100_points: Number(settings.redeem_value_per_100_points ?? 0),
      })
      return data.data
    },
    onSuccess: async () => {
      setError(null)
      setDraft({})
      showSuccess('Loyalty settings saved.')
      await queryClient.invalidateQueries({ queryKey: ['admin', 'loyalty', 'settings'] })
    },
    onError: (err) => setError(err instanceof ApiError ? err.message : 'Unable to save settings.'),
  })

  const adjustMutation = useMutation({
    mutationFn: async () => {
      const { data } = await api.post<ApiSuccess<unknown>>(
        `/admin/loyalty/accounts/${Number(memberId)}/adjust`,
        { points: Number(adjustPoints), notes: adjustNotes || null },
      )
      return data.data
    },
    onSuccess: () => {
      setError(null)
      showSuccess('Loyalty points adjusted.')
      setAdjustNotes('')
    },
    onError: (err) => setError(err instanceof ApiError ? err.message : 'Unable to adjust points.'),
  })

  if (!canView) {
    return <Alert tone="danger">You do not have permission to view loyalty.</Alert>
  }

  if (settingsQuery.isLoading) {
    return <Spinner label="Loading loyalty settings…" />
  }

  return (
    <div className="space-y-4">
      {error ? <Alert tone="danger">{error}</Alert> : null}

      <Card>
        <CardTitle className="mb-1">Loyalty program</CardTitle>
        <CardDescription className="mb-4">
          Award points on check-in and POS purchases. Members can view balances in the portal.
        </CardDescription>

        <div className="grid gap-3 sm:grid-cols-2">
          <label className="flex items-center gap-2 text-sm text-ink sm:col-span-2">
            <input
              type="checkbox"
              checked={Boolean(settings.is_enabled)}
              disabled={!canManage}
              onChange={(e) => setDraft((d) => ({ ...d, is_enabled: e.target.checked }))}
              className="h-4 w-4 rounded border-white/20"
            />
            Enable loyalty program
          </label>
          <Field label="Points per check-in" htmlFor="pts-checkin">
            <Input
              id="pts-checkin"
              type="number"
              min={0}
              disabled={!canManage}
              value={settings.points_per_check_in ?? 0}
              onChange={(e) =>
                setDraft((d) => ({ ...d, points_per_check_in: Number(e.target.value) }))
              }
            />
          </Field>
          <Field label="Points per 100 spent" htmlFor="pts-spend">
            <Input
              id="pts-spend"
              type="number"
              min={0}
              disabled={!canManage}
              value={settings.points_per_100_currency ?? 0}
              onChange={(e) =>
                setDraft((d) => ({ ...d, points_per_100_currency: Number(e.target.value) }))
              }
            />
          </Field>
          <Field label="Points per referral" htmlFor="pts-ref">
            <Input
              id="pts-ref"
              type="number"
              min={0}
              disabled={!canManage}
              value={settings.points_per_referral ?? 0}
              onChange={(e) =>
                setDraft((d) => ({ ...d, points_per_referral: Number(e.target.value) }))
              }
            />
          </Field>
          <Field label="Redeem value per 100 pts" htmlFor="pts-redeem">
            <Input
              id="pts-redeem"
              type="number"
              min={0}
              disabled={!canManage}
              value={settings.redeem_value_per_100_points ?? 0}
              onChange={(e) =>
                setDraft((d) => ({ ...d, redeem_value_per_100_points: Number(e.target.value) }))
              }
            />
          </Field>
        </div>

        {canManage ? (
          <Button className="mt-4" loading={saveMutation.isPending} onClick={() => saveMutation.mutate()}>
            Save settings
          </Button>
        ) : null}
      </Card>

      {canManage ? (
        <Card>
          <CardTitle className="mb-1">Manual adjustment</CardTitle>
          <CardDescription className="mb-4">
            Use positive points to award, negative to redeem.
          </CardDescription>
          <div className="grid gap-3 sm:grid-cols-3">
            <Field label="Member ID" htmlFor="loy-member">
              <Input
                id="loy-member"
                type="number"
                value={memberId}
                onChange={(e) => setMemberId(e.target.value)}
              />
            </Field>
            <Field label="Points (+/-)" htmlFor="loy-points">
              <Input
                id="loy-points"
                type="number"
                value={adjustPoints}
                onChange={(e) => setAdjustPoints(Number(e.target.value))}
              />
            </Field>
            <Field label="Notes" htmlFor="loy-notes">
              <Input
                id="loy-notes"
                value={adjustNotes}
                onChange={(e) => setAdjustNotes(e.target.value)}
              />
            </Field>
          </div>
          <Button
            className="mt-4"
            loading={adjustMutation.isPending}
            disabled={!memberId}
            onClick={() => adjustMutation.mutate()}
          >
            Apply adjustment
          </Button>
        </Card>
      ) : null}
    </div>
  )
}
