import { useEffect, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Gift,
  Percent,
  Plus,
  Search,
  Ticket,
  Trash2,
  Users,
  X,
} from 'lucide-react'
import {
  createCoupon,
  createOffer,
  createReferral,
  deleteCoupon,
  deleteOffer,
  disqualifyReferral,
  fetchCoupon,
  fetchCoupons,
  fetchOffer,
  fetchOffers,
  fetchReferral,
  fetchReferrals,
  qualifyReferral,
  redeemCoupon,
  rewardReferral,
  updateCoupon,
  updateOffer,
  type Coupon,
  type DiscountType,
  type Offer,
  type Referral,
  type ReferralStatus,
} from '@/api/marketing'
import { fetchMembers } from '@/api/members'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Spinner } from '@/components/ui/Spinner'
import { LoyaltyPanel } from '@/pages/marketing/LoyaltyPanel'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatMoney, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'

type PageTab = 'offers' | 'coupons' | 'referrals' | 'loyalty'

function pad(n: number) {
  return String(n).padStart(2, '0')
}

function toLocalInput(iso?: string | null) {
  if (!iso) return ''
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return ''
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`
}

function defaultWindow() {
  const start = new Date()
  const end = new Date()
  end.setDate(end.getDate() + 30)
  return {
    starts_at: toLocalInput(start.toISOString()),
    ends_at: toLocalInput(end.toISOString()),
  }
}

function toNum(value: string | number | null | undefined) {
  const n = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(n) ? n : 0
}

function memberLabel(m?: {
  first_name?: string
  last_name?: string
  member_code?: string
  full_name?: string
} | null) {
  if (!m) return '—'
  if (m.full_name) {
    return m.member_code ? `${m.full_name} (${m.member_code})` : m.full_name
  }
  const name = `${m.first_name ?? ''} ${m.last_name ?? ''}`.trim()
  return name ? `${name}${m.member_code ? ` (${m.member_code})` : ''}` : m.member_code || '—'
}

function discountLabel(type: DiscountType, value: string | number, currency = 'INR') {
  return type === 'percent' ? `${toNum(value)}%` : formatMoney(value, currency)
}

function referralTone(
  status: ReferralStatus,
): 'accent' | 'warning' | 'success' | 'danger' | 'neutral' {
  switch (status) {
    case 'pending':
      return 'accent'
    case 'qualified':
      return 'warning'
    case 'rewarded':
      return 'success'
    case 'disqualified':
      return 'danger'
    default:
      return 'neutral'
  }
}

export function MarketingPage() {
  const { tenant, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canViewOffers = hasPermission('marketing.offers.view')
  const canManageOffers = hasPermission('marketing.offers.manage')
  const canViewCoupons = hasPermission('marketing.coupons.view')
  const canManageCoupons = hasPermission('marketing.coupons.manage')
  const canViewReferrals = hasPermission('marketing.referrals.view')
  const canManageReferrals = hasPermission('marketing.referrals.manage')
  const canViewLoyalty = hasPermission('marketing.loyalty.view')
  const canManageLoyalty = hasPermission('marketing.loyalty.manage')
  void canManageLoyalty
  const canViewMembers = hasPermission('members.view')
  const canView = canViewOffers || canViewCoupons || canViewReferrals

  const defaultCurrency = tenant?.base_currency || 'INR'

  const [tab, setTab] = useState<PageTab>('offers')
  const [error, setError] = useState<string | null>(null)
  const [offerFieldErrors, setOfferFieldErrors] = useState<FieldErrors>({})
  const [couponFieldErrors, setCouponFieldErrors] = useState<FieldErrors>({})
  const [referralFieldErrors, setReferralFieldErrors] = useState<FieldErrors>({})

  const clearOfferFieldError = (key: string) => {
    setOfferFieldErrors((prev) => {
      if (!prev[key]) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  const clearCouponFieldError = (key: string) => {
    setCouponFieldErrors((prev) => {
      if (!prev[key]) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  const clearReferralFieldError = (key: string) => {
    setReferralFieldErrors((prev) => {
      if (!prev[key]) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  useEffect(() => {
    const allowed: PageTab[] = []
    if (canViewOffers) allowed.push('offers')
    if (canViewCoupons) allowed.push('coupons')
    if (canViewReferrals) allowed.push('referrals')
    if (canViewLoyalty) allowed.push('loyalty')
    if (allowed.length > 0 && !allowed.includes(tab)) setTab(allowed[0])
  }, [canViewOffers, canViewCoupons, canViewReferrals, tab])

  // Offers
  const [offerPage, setOfferPage] = useState(1)
  const [offerSearch, setOfferSearch] = useState('')
  const [appliedOfferSearch, setAppliedOfferSearch] = useState('')
  const [offerActive, setOfferActive] = useState<'' | '1' | '0'>('')
  const [selectedOfferId, setSelectedOfferId] = useState<number | null>(null)
  const [showOfferForm, setShowOfferForm] = useState(false)
  const [editingOffer, setEditingOffer] = useState<Offer | null>(null)
  const [offerForm, setOfferForm] = useState({
    code: '',
    name: '',
    discount_type: 'percent' as DiscountType,
    discount_value: '',
    starts_at: '',
    ends_at: '',
    is_active: true,
    stackable_with_coupon: false,
  })

  // Coupons
  const [couponPage, setCouponPage] = useState(1)
  const [couponSearch, setCouponSearch] = useState('')
  const [appliedCouponSearch, setAppliedCouponSearch] = useState('')
  const [couponActive, setCouponActive] = useState<'' | '1' | '0'>('')
  const [selectedCouponId, setSelectedCouponId] = useState<number | null>(null)
  const [showCouponForm, setShowCouponForm] = useState(false)
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null)
  const [couponForm, setCouponForm] = useState({
    code: '',
    discount_type: 'fixed' as DiscountType,
    discount_value: '',
    max_redemptions: '10',
    per_member_limit: '1',
    starts_at: '',
    ends_at: '',
    is_active: true,
  })
  const [redeemMemberId, setRedeemMemberId] = useState<number | ''>('')
  const [redeemInvoiceId, setRedeemInvoiceId] = useState('')
  const [memberSearch, setMemberSearch] = useState('')

  // Referrals
  const [refPage, setRefPage] = useState(1)
  const [refStatus, setRefStatus] = useState<'' | ReferralStatus>('')
  const [selectedRefId, setSelectedRefId] = useState<number | null>(null)
  const [showRefForm, setShowRefForm] = useState(false)
  const [referrerId, setReferrerId] = useState<number | ''>('')
  const [refereeId, setRefereeId] = useState<number | ''>('')
  const [refMemberSearch, setRefMemberSearch] = useState('')
  const [rewardType, setRewardType] = useState('')
  const [rewardReference, setRewardReference] = useState('')

  const errMsg = (err: unknown, fallback: string) => {
    if (err instanceof ApiError) return err.message
    if (err instanceof Error && err.message) return err.message
    return fallback
  }

  const invalidate = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['admin', 'offers'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'coupons'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'referrals'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'marketing-stats'] }),
    ])
  }

  const statsQuery = useQuery({
    queryKey: ['admin', 'marketing-stats'],
    queryFn: async () => {
      const [offers, coupons, pending, qualified] = await Promise.all([
        canViewOffers
          ? fetchOffers({ page: 1, per_page: 1, is_active: true })
          : Promise.resolve(null),
        canViewCoupons
          ? fetchCoupons({ page: 1, per_page: 1, is_active: true })
          : Promise.resolve(null),
        canViewReferrals
          ? fetchReferrals({ page: 1, per_page: 1, status: 'pending' })
          : Promise.resolve(null),
        canViewReferrals
          ? fetchReferrals({ page: 1, per_page: 1, status: 'qualified' })
          : Promise.resolve(null),
      ])
      return {
        offers: offers?.meta.total ?? 0,
        coupons: coupons?.meta.total ?? 0,
        pending: pending?.meta.total ?? 0,
        qualified: qualified?.meta.total ?? 0,
      }
    },
    enabled: canView,
  })

  const offersQuery = useQuery({
    queryKey: ['admin', 'offers', offerPage, appliedOfferSearch, offerActive],
    queryFn: () =>
      fetchOffers({
        page: offerPage,
        per_page: DEFAULT_PAGE_SIZE,
        search: appliedOfferSearch,
        is_active: offerActive === '' ? '' : offerActive === '1',
      }),
    enabled: canViewOffers && tab === 'offers',
  })

  const offerDetailQuery = useQuery({
    queryKey: ['admin', 'offers', selectedOfferId],
    queryFn: () => fetchOffer(selectedOfferId!),
    enabled: canViewOffers && selectedOfferId != null && tab === 'offers',
  })

  const couponsQuery = useQuery({
    queryKey: ['admin', 'coupons', couponPage, appliedCouponSearch, couponActive],
    queryFn: () =>
      fetchCoupons({
        page: couponPage,
        per_page: DEFAULT_PAGE_SIZE,
        search: appliedCouponSearch,
        is_active: couponActive === '' ? '' : couponActive === '1',
      }),
    enabled: canViewCoupons && tab === 'coupons',
  })

  const couponDetailQuery = useQuery({
    queryKey: ['admin', 'coupons', selectedCouponId],
    queryFn: () => fetchCoupon(selectedCouponId!),
    enabled: canViewCoupons && selectedCouponId != null && tab === 'coupons',
  })

  const referralsQuery = useQuery({
    queryKey: ['admin', 'referrals', refPage, refStatus],
    queryFn: () =>
      fetchReferrals({
        page: refPage,
        per_page: DEFAULT_PAGE_SIZE,
        status: refStatus,
      }),
    enabled: canViewReferrals && tab === 'referrals',
  })

  const referralDetailQuery = useQuery({
    queryKey: ['admin', 'referrals', selectedRefId],
    queryFn: () => fetchReferral(selectedRefId!),
    enabled: canViewReferrals && selectedRefId != null && tab === 'referrals',
  })

  const membersQuery = useQuery({
    queryKey: ['admin', 'members', 'marketing-picker', memberSearch || refMemberSearch],
    queryFn: () =>
      fetchMembers({
        page: 1,
        per_page: 25,
        search: memberSearch || refMemberSearch || undefined,
        status: 'active',
      }),
    enabled:
      canViewMembers &&
      ((tab === 'coupons' && (showCouponForm || selectedCouponId != null)) ||
        (tab === 'referrals' && showRefForm)),
  })

  const openCreateOffer = () => {
    const win = defaultWindow()
    setEditingOffer(null)
    setOfferForm({
      code: '',
      name: '',
      discount_type: 'percent',
      discount_value: '10',
      starts_at: win.starts_at,
      ends_at: win.ends_at,
      is_active: true,
      stackable_with_coupon: false,
    })
    setShowOfferForm(true)
    setSelectedOfferId(null)
    setError(null)
    setOfferFieldErrors({})
  }

  const openEditOffer = (offer: Offer) => {
    setEditingOffer(offer)
    setOfferForm({
      code: offer.code,
      name: offer.name,
      discount_type: offer.discount_type,
      discount_value: String(offer.discount_value),
      starts_at: toLocalInput(offer.starts_at),
      ends_at: toLocalInput(offer.ends_at),
      is_active: offer.is_active,
      stackable_with_coupon: offer.stackable_with_coupon,
    })
    setShowOfferForm(true)
    setError(null)
    setOfferFieldErrors({})
  }

  const openCreateCoupon = () => {
    const win = defaultWindow()
    setEditingCoupon(null)
    setCouponForm({
      code: '',
      discount_type: 'fixed',
      discount_value: '100',
      max_redemptions: '10',
      per_member_limit: '1',
      starts_at: win.starts_at,
      ends_at: win.ends_at,
      is_active: true,
    })
    setShowCouponForm(true)
    setSelectedCouponId(null)
    setError(null)
    setCouponFieldErrors({})
  }

  const openEditCoupon = (coupon: Coupon) => {
    setEditingCoupon(coupon)
    setCouponForm({
      code: coupon.code,
      discount_type: coupon.discount_type,
      discount_value: String(coupon.discount_value),
      max_redemptions: coupon.max_redemptions != null ? String(coupon.max_redemptions) : '',
      per_member_limit: coupon.per_member_limit != null ? String(coupon.per_member_limit) : '1',
      starts_at: toLocalInput(coupon.starts_at),
      ends_at: toLocalInput(coupon.ends_at),
      is_active: coupon.is_active,
    })
    setShowCouponForm(true)
    setError(null)
    setCouponFieldErrors({})
  }

  const saveOfferMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        code: offerForm.code.trim().toUpperCase(),
        name: offerForm.name.trim(),
        discount_type: offerForm.discount_type,
        discount_value: toNum(offerForm.discount_value),
        starts_at: offerForm.starts_at,
        ends_at: offerForm.ends_at,
        is_active: offerForm.is_active,
        stackable_with_coupon: offerForm.stackable_with_coupon,
      }
      if (editingOffer) return updateOffer(editingOffer.id, payload)
      return createOffer(payload)
    },
    onSuccess: async (row) => {
      showSuccess(editingOffer ? `Offer ${row.code} updated.` : `Offer ${row.code} created.`)
      setShowOfferForm(false)
      setEditingOffer(null)
      setSelectedOfferId(row.id)
      setError(null)
      await invalidate()
    },
    onError: (err) => setError(errMsg(err, 'Could not save offer.')),
  })

  const deleteOfferMutation = useMutation({
    mutationFn: (id: number) => deleteOffer(id),
    onSuccess: async () => {
      showSuccess('Offer deleted.')
      setSelectedOfferId(null)
      await invalidate()
    },
    onError: (err) => setError(errMsg(err, 'Could not delete offer.')),
  })

  const saveCouponMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        code: couponForm.code.trim().toUpperCase(),
        discount_type: couponForm.discount_type,
        discount_value: toNum(couponForm.discount_value),
        max_redemptions:
          couponForm.max_redemptions === ''
            ? null
            : Math.max(1, Math.floor(toNum(couponForm.max_redemptions))),
        per_member_limit:
          couponForm.per_member_limit === ''
            ? 1
            : Math.max(1, Math.floor(toNum(couponForm.per_member_limit))),
        starts_at: couponForm.starts_at,
        ends_at: couponForm.ends_at,
        is_active: couponForm.is_active,
      }
      if (editingCoupon) return updateCoupon(editingCoupon.id, payload)
      return createCoupon(payload)
    },
    onSuccess: async (row) => {
      showSuccess(editingCoupon ? `Coupon ${row.code} updated.` : `Coupon ${row.code} created.`)
      setShowCouponForm(false)
      setEditingCoupon(null)
      setSelectedCouponId(row.id)
      setError(null)
      await invalidate()
    },
    onError: (err) => setError(errMsg(err, 'Could not save coupon.')),
  })

  const deleteCouponMutation = useMutation({
    mutationFn: (id: number) => deleteCoupon(id),
    onSuccess: async () => {
      showSuccess('Coupon deleted.')
      setSelectedCouponId(null)
      await invalidate()
    },
    onError: (err) => setError(errMsg(err, 'Could not delete coupon.')),
  })

  const redeemMutation = useMutation({
    mutationFn: () =>
      redeemCoupon(selectedCouponId!, {
        member_id: redeemMemberId === '' ? null : Number(redeemMemberId),
        invoice_id: redeemInvoiceId === '' ? null : Number(redeemInvoiceId),
      }),
    onSuccess: async (row) => {
      showSuccess(`Coupon redeemed (#${row.id}).`)
      setRedeemMemberId('')
      setRedeemInvoiceId('')
      setError(null)
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'coupons', selectedCouponId] })
    },
    onError: (err) => setError(errMsg(err, 'Could not redeem coupon.')),
  })

  const createRefMutation = useMutation({
    mutationFn: async () => {
      return createReferral({
        referrer_member_id: Number(referrerId),
        referee_member_id: Number(refereeId),
      })
    },
    onSuccess: async (row) => {
      showSuccess(`Referral #${row.id} created.`)
      setShowRefForm(false)
      setReferrerId('')
      setRefereeId('')
      setSelectedRefId(row.id)
      setError(null)
      await invalidate()
    },
    onError: (err) => setError(errMsg(err, 'Could not create referral.')),
  })

  const qualifyMutation = useMutation({
    mutationFn: (id: number) => qualifyReferral(id),
    onSuccess: async (row) => {
      showSuccess(`Referral #${row.id} qualified.`)
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'referrals', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not qualify referral.')),
  })

  const rewardMutation = useMutation({
    mutationFn: (id: number) =>
      rewardReferral(id, {
        reward_type: rewardType.trim() || null,
        reward_reference: rewardReference.trim() || null,
      }),
    onSuccess: async (row) => {
      showSuccess(`Referral #${row.id} rewarded.`)
      setRewardType('')
      setRewardReference('')
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'referrals', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not reward referral.')),
  })

  const disqualifyMutation = useMutation({
    mutationFn: (id: number) => disqualifyReferral(id),
    onSuccess: async (row) => {
      showSuccess(`Referral #${row.id} disqualified.`)
      await invalidate()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'referrals', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not disqualify referral.')),
  })

  const onSaveOffer = (e: FormEvent) => {
    e.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'code', label: 'Code', value: offerForm.code },
      { key: 'name', label: 'Name', value: offerForm.name },
      { key: 'discount_value', label: 'Discount value', value: offerForm.discount_value },
      { key: 'starts_at', label: 'Starts', value: offerForm.starts_at },
      { key: 'ends_at', label: 'Ends', value: offerForm.ends_at },
    ])
    if (Object.keys(errors).length > 0) {
      setOfferFieldErrors(errors)
      return
    }
    setOfferFieldErrors({})
    saveOfferMutation.mutate()
  }

  const onSaveCoupon = (e: FormEvent) => {
    e.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'code', label: 'Code', value: couponForm.code },
      { key: 'discount_value', label: 'Discount value', value: couponForm.discount_value },
      { key: 'starts_at', label: 'Starts', value: couponForm.starts_at },
      { key: 'ends_at', label: 'Ends', value: couponForm.ends_at },
    ])
    if (Object.keys(errors).length > 0) {
      setCouponFieldErrors(errors)
      return
    }
    setCouponFieldErrors({})
    saveCouponMutation.mutate()
  }

  const onCreateReferral = (e: FormEvent) => {
    e.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'referrer_id', label: 'Referrer', value: referrerId },
      { key: 'referee_id', label: 'Referee', value: refereeId },
    ])
    if (referrerId && refereeId && referrerId === refereeId) {
      errors.referee_id = 'Referrer and referee must be different.'
    }
    if (Object.keys(errors).length > 0) {
      setReferralFieldErrors(errors)
      return
    }
    setReferralFieldErrors({})
    createRefMutation.mutate()
  }

  const onDeleteOffer = async (offer: Offer) => {
    const ok = await confirm({
      title: 'Delete offer?',
      message: `Delete offer ${offer.code} (${offer.name})?`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (ok) deleteOfferMutation.mutate(offer.id)
  }

  const onDeleteCoupon = async (coupon: Coupon) => {
    const ok = await confirm({
      title: 'Delete coupon?',
      message: `Delete coupon ${coupon.code}?`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (ok) deleteCouponMutation.mutate(coupon.id)
  }

  const offerColumns: Column<Offer>[] = [
    {
      key: 'code',
      header: 'Offer',
      cell: (row) => (
        <div>
          <p className="font-mono font-semibold text-ink">{row.code}</p>
          <p className="text-xs text-muted">{row.name}</p>
        </div>
      ),
    },
    {
      key: 'discount',
      header: 'Discount',
      cell: (row) => (
        <span className="text-sm text-ink">
          {discountLabel(row.discount_type, row.discount_value, defaultCurrency)}
        </span>
      ),
    },
    {
      key: 'window',
      header: 'Window',
      cell: (row) => (
        <div className="text-xs text-muted">
          <div>{formatDate(row.starts_at)}</div>
          <div>→ {formatDate(row.ends_at)}</div>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <div className="flex flex-wrap gap-1">
          <Badge tone={row.is_active ? 'success' : 'neutral'}>
            {row.is_active ? 'Active' : 'Inactive'}
          </Badge>
          {row.stackable_with_coupon ? <Badge tone="accent">Stackable</Badge> : null}
        </div>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedOfferId(row.id)}>
          Open
        </Button>
      ),
    },
  ]

  const couponColumns: Column<Coupon>[] = [
    {
      key: 'code',
      header: 'Coupon',
      cell: (row) => <p className="font-mono font-semibold text-ink">{row.code}</p>,
    },
    {
      key: 'discount',
      header: 'Discount',
      cell: (row) => (
        <span className="text-sm text-ink">
          {discountLabel(row.discount_type, row.discount_value, defaultCurrency)}
        </span>
      ),
    },
    {
      key: 'usage',
      header: 'Usage',
      cell: (row) => (
        <span className="text-sm text-ink">
          {row.redeemed_count}
          {row.max_redemptions != null ? ` / ${row.max_redemptions}` : ' used'}
        </span>
      ),
    },
    {
      key: 'window',
      header: 'Window',
      cell: (row) => (
        <div className="text-xs text-muted">
          <div>{formatDate(row.starts_at)}</div>
          <div>→ {formatDate(row.ends_at)}</div>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.is_active ? 'success' : 'neutral'}>
          {row.is_active ? 'Active' : 'Inactive'}
        </Badge>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button
          size="sm"
          variant="secondary"
          onClick={() => {
            setSelectedCouponId(row.id)
            setRedeemMemberId('')
            setRedeemInvoiceId('')
          }}
        >
          Open
        </Button>
      ),
    },
  ]

  const referralColumns: Column<Referral>[] = [
    {
      key: 'id',
      header: 'Referral',
      cell: (row) => (
        <div>
          <p className="font-medium text-ink">#{row.id}</p>
          <p className="text-xs text-muted">{formatDate(row.created_at)}</p>
        </div>
      ),
    },
    {
      key: 'referrer',
      header: 'Referrer',
      cell: (row) => <span className="text-sm text-ink">{memberLabel(row.referrer)}</span>,
    },
    {
      key: 'referee',
      header: 'Referee',
      cell: (row) => <span className="text-sm text-ink">{memberLabel(row.referee)}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => <Badge tone={referralTone(row.status)}>{row.status}</Badge>,
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedRefId(row.id)}>
          Open
        </Button>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader title="Marketing" description="Offers, coupons, referrals." />
        <Alert tone="danger">You do not have permission to view marketing.</Alert>
      </div>
    )
  }

  const stats = statsQuery.data
  const selectedOffer = offerDetailQuery.data
  const selectedCoupon = couponDetailQuery.data
  const selectedRef = referralDetailQuery.data
  const members = membersQuery.data?.data ?? []

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Marketing"
        description="Offers, coupons, and referrals — grow memberships with promotions and rewards."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">{defaultCurrency}</Badge>
            {canManageOffers && tab === 'offers' ? (
              <Button size="sm" onClick={openCreateOffer}>
                <Plus className="h-4 w-4" />
                New offer
              </Button>
            ) : null}
            {canManageCoupons && tab === 'coupons' ? (
              <Button size="sm" onClick={openCreateCoupon}>
                <Plus className="h-4 w-4" />
                New coupon
              </Button>
            ) : null}
            {canManageReferrals && tab === 'referrals' ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowRefForm(true)
                  setSelectedRefId(null)
                  setReferrerId('')
                  setRefereeId('')
                  setError(null)
                  setReferralFieldErrors({})
                }}
              >
                <Plus className="h-4 w-4" />
                New referral
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<Percent className="h-4 w-4" />}
          label="Active offers"
          value={formatNumber(stats?.offers ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<Ticket className="h-4 w-4" />}
          label="Active coupons"
          value={formatNumber(stats?.coupons ?? 0)}
        />
        <SummaryChip
          icon={<Users className="h-4 w-4" />}
          label="Pending referrals"
          value={formatNumber(stats?.pending ?? 0)}
        />
        <SummaryChip
          icon={<Gift className="h-4 w-4" />}
          label="Qualified"
          value={formatNumber(stats?.qualified ?? 0)}
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {canViewOffers ? (
          <TabButton
            active={tab === 'offers'}
            onClick={() => {
              setTab('offers')
              setError(null)
              setShowCouponForm(false)
              setShowRefForm(false)
              setSelectedCouponId(null)
              setSelectedRefId(null)
            }}
          >
            Offers
          </TabButton>
        ) : null}
        {canViewCoupons ? (
          <TabButton
            active={tab === 'coupons'}
            onClick={() => {
              setTab('coupons')
              setError(null)
              setShowOfferForm(false)
              setShowRefForm(false)
              setSelectedOfferId(null)
              setSelectedRefId(null)
            }}
          >
            Coupons
          </TabButton>
        ) : null}
        {canViewReferrals ? (
          <TabButton
            active={tab === 'referrals'}
            onClick={() => {
              setTab('referrals')
              setError(null)
              setShowOfferForm(false)
              setShowCouponForm(false)
              setSelectedOfferId(null)
              setSelectedCouponId(null)
            }}
          >
            Referrals
          </TabButton>
        ) : null}
        {canViewLoyalty ? (
          <TabButton
            active={tab === 'loyalty'}
            onClick={() => {
              setTab('loyalty')
              setError(null)
              setShowOfferForm(false)
              setShowCouponForm(false)
              setShowRefForm(false)
              setSelectedOfferId(null)
              setSelectedCouponId(null)
              setSelectedRefId(null)
            }}
          >
            Loyalty
          </TabButton>
        ) : null}
      </div>

      {tab === 'offers' && canViewOffers ? (
        <>
          {showOfferForm && canManageOffers ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>{editingOffer ? `Edit ${editingOffer.code}` : 'Create offer'}</CardTitle>
                  <CardDescription>
                    Promotional discounts with an active window. Codes are stored uppercase.
                  </CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setShowOfferForm(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form noValidate onSubmit={onSaveOffer} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                <Field label="Code" htmlFor="offer-code" required error={offerFieldErrors.code}>
                  <Input
                    id="offer-code"
                    required
                    aria-invalid={Boolean(offerFieldErrors.code)}
                    className="font-mono uppercase"
                    value={offerForm.code}
                    onChange={(e) => {
                      clearOfferFieldError('code')
                      setOfferForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))
                    }}
                  />
                </Field>
                <Field
                  label="Name"
                  htmlFor="offer-name"
                  required
                  error={offerFieldErrors.name}
                  className="sm:col-span-2 lg:col-span-2"
                >
                  <Input
                    id="offer-name"
                    required
                    aria-invalid={Boolean(offerFieldErrors.name)}
                    value={offerForm.name}
                    onChange={(e) => {
                      clearOfferFieldError('name')
                      setOfferForm((f) => ({ ...f, name: e.target.value }))
                    }}
                  />
                </Field>
                <Field label="Discount type" htmlFor="offer-discount-type">
                  <Select
                    id="offer-discount-type"
                    value={offerForm.discount_type}
                    onChange={(e) =>
                      setOfferForm((f) => ({
                        ...f,
                        discount_type: e.target.value as DiscountType,
                      }))
                    }
                  >
                    <option value="percent">Percent</option>
                    <option value="fixed">Fixed amount</option>
                  </Select>
                </Field>
                <Field
                  label="Discount value"
                  htmlFor="offer-discount-value"
                  required
                  error={offerFieldErrors.discount_value}
                >
                  <Input
                    id="offer-discount-value"
                    required
                    aria-invalid={Boolean(offerFieldErrors.discount_value)}
                    type="number"
                    min="0.01"
                    step="0.01"
                    value={offerForm.discount_value}
                    onChange={(e) => {
                      clearOfferFieldError('discount_value')
                      setOfferForm((f) => ({ ...f, discount_value: e.target.value }))
                    }}
                  />
                </Field>
                <Field
                  label="Starts"
                  htmlFor="offer-starts"
                  required
                  error={offerFieldErrors.starts_at}
                >
                  <Input
                    id="offer-starts"
                    required
                    aria-invalid={Boolean(offerFieldErrors.starts_at)}
                    type="datetime-local"
                    value={offerForm.starts_at}
                    onChange={(e) => {
                      clearOfferFieldError('starts_at')
                      setOfferForm((f) => ({ ...f, starts_at: e.target.value }))
                    }}
                  />
                </Field>
                <Field label="Ends" htmlFor="offer-ends" required error={offerFieldErrors.ends_at}>
                  <Input
                    id="offer-ends"
                    required
                    aria-invalid={Boolean(offerFieldErrors.ends_at)}
                    type="datetime-local"
                    value={offerForm.ends_at}
                    onChange={(e) => {
                      clearOfferFieldError('ends_at')
                      setOfferForm((f) => ({ ...f, ends_at: e.target.value }))
                    }}
                  />
                </Field>
                <div className="flex flex-col justify-end gap-2">
                  <label className="flex items-center gap-2 text-sm text-ink">
                    <input
                      type="checkbox"
                      checked={offerForm.is_active}
                      onChange={(e) =>
                        setOfferForm((f) => ({ ...f, is_active: e.target.checked }))
                      }
                      className="h-4 w-4 rounded border-white/20"
                    />
                    Active
                  </label>
                  <label className="flex items-center gap-2 text-sm text-ink">
                    <input
                      type="checkbox"
                      checked={offerForm.stackable_with_coupon}
                      onChange={(e) =>
                        setOfferForm((f) => ({
                          ...f,
                          stackable_with_coupon: e.target.checked,
                        }))
                      }
                      className="h-4 w-4 rounded border-white/20"
                    />
                    Stackable with coupon
                  </label>
                </div>
                <div className="flex justify-end gap-2 sm:col-span-2 lg:col-span-3">
                  <Button type="button" variant="secondary" onClick={() => setShowOfferForm(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={saveOfferMutation.isPending}>
                    {saveOfferMutation.isPending
                      ? 'Saving…'
                      : editingOffer
                        ? 'Save changes'
                        : 'Create offer'}
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          <Card>
            <div className="mb-4 flex flex-wrap items-end gap-3">
              <div className="min-w-[200px] flex-1">
                <Label>Search</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Code or name…"
                    value={offerSearch}
                    onChange={(e) => setOfferSearch(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        setAppliedOfferSearch(offerSearch.trim())
                        setOfferPage(1)
                      }
                    }}
                  />
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => {
                      setAppliedOfferSearch(offerSearch.trim())
                      setOfferPage(1)
                    }}
                  >
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div>
                <Label>Status</Label>
                <Select
                  value={offerActive}
                  onChange={(e) => {
                    setOfferActive(e.target.value as '' | '1' | '0')
                    setOfferPage(1)
                  }}
                >
                  <option value="">All</option>
                  <option value="1">Active</option>
                  <option value="0">Inactive</option>
                </Select>
              </div>
            </div>
            {offersQuery.isLoading ? (
              <div className="flex justify-center py-12">
                <Spinner />
              </div>
            ) : offersQuery.isError ? (
              <Alert tone="danger">
                {offersQuery.error instanceof ApiError
                  ? offersQuery.error.message
                  : 'Failed to load offers.'}
              </Alert>
            ) : (
              <>
                <DataTable
                  columns={offerColumns}
                  rows={offersQuery.data?.data ?? []}
                  rowKey={(r) => r.id}
                  emptyTitle="No offers"
                  emptyDescription="Create a promotional offer to get started."
                />
                <Pagination
                  meta={offersQuery.data?.meta}
                  onPageChange={(p) => {
                    setOfferPage(p)
                    setSelectedOfferId(null)
                  }}
                />
              </>
            )}
          </Card>

          {selectedOfferId != null ? (
            <Card className="border-accent/20">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Offer detail</CardTitle>
                  <CardDescription>{selectedOffer?.code ?? `#${selectedOfferId}`}</CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setSelectedOfferId(null)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              {offerDetailQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Spinner />
                </div>
              ) : selectedOffer ? (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone={selectedOffer.is_active ? 'success' : 'neutral'}>
                      {selectedOffer.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                    {selectedOffer.stackable_with_coupon ? (
                      <Badge tone="accent">Stackable</Badge>
                    ) : null}
                    <span className="text-sm font-medium text-ink">{selectedOffer.name}</span>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-3">
                    <DetailStat
                      label="Discount"
                      value={discountLabel(
                        selectedOffer.discount_type,
                        selectedOffer.discount_value,
                        defaultCurrency,
                      )}
                    />
                    <DetailStat label="Starts" value={formatDate(selectedOffer.starts_at)} />
                    <DetailStat label="Ends" value={formatDate(selectedOffer.ends_at)} />
                  </div>
                  {canManageOffers ? (
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => openEditOffer(selectedOffer)}
                      >
                        Edit
                      </Button>
                      <Button
                        size="sm"
                        variant="danger"
                        disabled={deleteOfferMutation.isPending}
                        onClick={() => onDeleteOffer(selectedOffer)}
                      >
                        <Trash2 className="h-4 w-4" />
                        Delete
                      </Button>
                    </div>
                  ) : null}
                </div>
              ) : (
                <Alert tone="danger">Offer not found.</Alert>
              )}
            </Card>
          ) : null}
        </>
      ) : null}

      {tab === 'coupons' && canViewCoupons ? (
        <>
          {showCouponForm && canManageCoupons ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>
                    {editingCoupon ? `Edit ${editingCoupon.code}` : 'Create coupon'}
                  </CardTitle>
                  <CardDescription>
                    Redeemable codes with optional max redemptions and per-member limits.
                  </CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setShowCouponForm(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form noValidate onSubmit={onSaveCoupon} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                <Field label="Code" htmlFor="coupon-code" required error={couponFieldErrors.code}>
                  <Input
                    id="coupon-code"
                    required
                    aria-invalid={Boolean(couponFieldErrors.code)}
                    className="font-mono uppercase"
                    value={couponForm.code}
                    onChange={(e) => {
                      clearCouponFieldError('code')
                      setCouponForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))
                    }}
                  />
                </Field>
                <Field label="Discount type" htmlFor="coupon-discount-type">
                  <Select
                    id="coupon-discount-type"
                    value={couponForm.discount_type}
                    onChange={(e) =>
                      setCouponForm((f) => ({
                        ...f,
                        discount_type: e.target.value as DiscountType,
                      }))
                    }
                  >
                    <option value="percent">Percent</option>
                    <option value="fixed">Fixed amount</option>
                  </Select>
                </Field>
                <Field
                  label="Discount value"
                  htmlFor="coupon-discount-value"
                  required
                  error={couponFieldErrors.discount_value}
                >
                  <Input
                    id="coupon-discount-value"
                    required
                    aria-invalid={Boolean(couponFieldErrors.discount_value)}
                    type="number"
                    min="0.01"
                    step="0.01"
                    value={couponForm.discount_value}
                    onChange={(e) => {
                      clearCouponFieldError('discount_value')
                      setCouponForm((f) => ({ ...f, discount_value: e.target.value }))
                    }}
                  />
                </Field>
                <Field label="Max redemptions" htmlFor="coupon-max-redemptions">
                  <Input
                    id="coupon-max-redemptions"
                    type="number"
                    min="1"
                    step="1"
                    value={couponForm.max_redemptions}
                    onChange={(e) =>
                      setCouponForm((f) => ({ ...f, max_redemptions: e.target.value }))
                    }
                    placeholder="Unlimited if empty"
                  />
                </Field>
                <Field label="Per-member limit" htmlFor="coupon-per-member">
                  <Input
                    id="coupon-per-member"
                    type="number"
                    min="1"
                    step="1"
                    value={couponForm.per_member_limit}
                    onChange={(e) =>
                      setCouponForm((f) => ({ ...f, per_member_limit: e.target.value }))
                    }
                  />
                </Field>
                <Field
                  label="Starts"
                  htmlFor="coupon-starts"
                  required
                  error={couponFieldErrors.starts_at}
                >
                  <Input
                    id="coupon-starts"
                    required
                    aria-invalid={Boolean(couponFieldErrors.starts_at)}
                    type="datetime-local"
                    value={couponForm.starts_at}
                    onChange={(e) => {
                      clearCouponFieldError('starts_at')
                      setCouponForm((f) => ({ ...f, starts_at: e.target.value }))
                    }}
                  />
                </Field>
                <Field
                  label="Ends"
                  htmlFor="coupon-ends"
                  required
                  error={couponFieldErrors.ends_at}
                >
                  <Input
                    id="coupon-ends"
                    required
                    aria-invalid={Boolean(couponFieldErrors.ends_at)}
                    type="datetime-local"
                    value={couponForm.ends_at}
                    onChange={(e) => {
                      clearCouponFieldError('ends_at')
                      setCouponForm((f) => ({ ...f, ends_at: e.target.value }))
                    }}
                  />
                </Field>
                <div className="flex items-end">
                  <label className="flex items-center gap-2 text-sm text-ink">
                    <input
                      type="checkbox"
                      checked={couponForm.is_active}
                      onChange={(e) =>
                        setCouponForm((f) => ({ ...f, is_active: e.target.checked }))
                      }
                      className="h-4 w-4 rounded border-white/20"
                    />
                    Active
                  </label>
                </div>
                <div className="flex justify-end gap-2 sm:col-span-2 lg:col-span-3">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => setShowCouponForm(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={saveCouponMutation.isPending}>
                    {saveCouponMutation.isPending
                      ? 'Saving…'
                      : editingCoupon
                        ? 'Save changes'
                        : 'Create coupon'}
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          <Card>
            <div className="mb-4 flex flex-wrap items-end gap-3">
              <div className="min-w-[200px] flex-1">
                <Label>Search</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Coupon code…"
                    value={couponSearch}
                    onChange={(e) => setCouponSearch(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        setAppliedCouponSearch(couponSearch.trim())
                        setCouponPage(1)
                      }
                    }}
                  />
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => {
                      setAppliedCouponSearch(couponSearch.trim())
                      setCouponPage(1)
                    }}
                  >
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div>
                <Label>Status</Label>
                <Select
                  value={couponActive}
                  onChange={(e) => {
                    setCouponActive(e.target.value as '' | '1' | '0')
                    setCouponPage(1)
                  }}
                >
                  <option value="">All</option>
                  <option value="1">Active</option>
                  <option value="0">Inactive</option>
                </Select>
              </div>
            </div>
            {couponsQuery.isLoading ? (
              <div className="flex justify-center py-12">
                <Spinner />
              </div>
            ) : couponsQuery.isError ? (
              <Alert tone="danger">
                {couponsQuery.error instanceof ApiError
                  ? couponsQuery.error.message
                  : 'Failed to load coupons.'}
              </Alert>
            ) : (
              <>
                <DataTable
                  columns={couponColumns}
                  rows={couponsQuery.data?.data ?? []}
                  rowKey={(r) => r.id}
                  emptyTitle="No coupons"
                  emptyDescription="Create a coupon code members can redeem."
                />
                <Pagination
                  meta={couponsQuery.data?.meta}
                  onPageChange={(p) => {
                    setCouponPage(p)
                    setSelectedCouponId(null)
                  }}
                />
              </>
            )}
          </Card>

          {selectedCouponId != null ? (
            <div className="grid gap-4 xl:grid-cols-[1.1fr_1fr]">
              <Card className="border-accent/20">
                <div className="mb-4 flex items-start justify-between gap-3">
                  <div>
                    <CardTitle>Coupon detail</CardTitle>
                    <CardDescription>
                      {selectedCoupon?.code ?? `#${selectedCouponId}`}
                    </CardDescription>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => setSelectedCouponId(null)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                {couponDetailQuery.isLoading ? (
                  <div className="flex justify-center py-8">
                    <Spinner />
                  </div>
                ) : selectedCoupon ? (
                  <div className="space-y-4">
                    <Badge tone={selectedCoupon.is_active ? 'success' : 'neutral'}>
                      {selectedCoupon.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <DetailStat
                        label="Discount"
                        value={discountLabel(
                          selectedCoupon.discount_type,
                          selectedCoupon.discount_value,
                          defaultCurrency,
                        )}
                      />
                      <DetailStat
                        label="Redeemed"
                        value={`${selectedCoupon.redeemed_count}${
                          selectedCoupon.max_redemptions != null
                            ? ` / ${selectedCoupon.max_redemptions}`
                            : ''
                        }`}
                      />
                      <DetailStat
                        label="Per member"
                        value={String(selectedCoupon.per_member_limit ?? '—')}
                      />
                      <DetailStat
                        label="Window"
                        value={`${formatDate(selectedCoupon.starts_at)} → ${formatDate(selectedCoupon.ends_at)}`}
                      />
                    </div>
                    {canManageCoupons ? (
                      <div className="flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => openEditCoupon(selectedCoupon)}
                        >
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="danger"
                          disabled={deleteCouponMutation.isPending}
                          onClick={() => onDeleteCoupon(selectedCoupon)}
                        >
                          <Trash2 className="h-4 w-4" />
                          Delete
                        </Button>
                      </div>
                    ) : null}
                  </div>
                ) : (
                  <Alert tone="danger">Coupon not found.</Alert>
                )}
              </Card>

              {canManageCoupons && selectedCoupon ? (
                <Card className="border-accent/20 h-fit">
                  <CardTitle className="mb-1">Redeem coupon</CardTitle>
                  <CardDescription className="mb-4">
                    Record a redemption against an optional member and invoice.
                  </CardDescription>
                  <form
                    onSubmit={(e: FormEvent) => {
                      e.preventDefault()
                      redeemMutation.mutate()
                    }}
                    className="space-y-3"
                  >
                    <div>
                      <Label>Member (optional)</Label>
                      {canViewMembers ? (
                        <>
                          <Input
                            className="mb-2"
                            placeholder="Search members…"
                            value={memberSearch}
                            onChange={(e) => setMemberSearch(e.target.value)}
                          />
                          <Select
                            value={redeemMemberId === '' ? '' : String(redeemMemberId)}
                            onChange={(e) =>
                              setRedeemMemberId(e.target.value ? Number(e.target.value) : '')
                            }
                          >
                            <option value="">No member</option>
                            {members.map((m) => (
                              <option key={m.id} value={m.id}>
                                {memberLabel(m)}
                              </option>
                            ))}
                          </Select>
                        </>
                      ) : (
                        <Input
                          type="number"
                          placeholder="Member ID"
                          value={redeemMemberId === '' ? '' : redeemMemberId}
                          onChange={(e) =>
                            setRedeemMemberId(e.target.value ? Number(e.target.value) : '')
                          }
                        />
                      )}
                    </div>
                    <div>
                      <Label>Invoice ID (optional)</Label>
                      <Input
                        type="number"
                        value={redeemInvoiceId}
                        onChange={(e) => setRedeemInvoiceId(e.target.value)}
                        placeholder="Link to invoice"
                      />
                    </div>
                    <Button
                      type="submit"
                      className="w-full"
                      disabled={redeemMutation.isPending || !selectedCoupon.is_active}
                    >
                      {redeemMutation.isPending ? 'Redeeming…' : 'Redeem now'}
                    </Button>
                  </form>
                </Card>
              ) : null}
            </div>
          ) : null}
        </>
      ) : null}

      {tab === 'referrals' && canViewReferrals ? (
        <>
          {showRefForm && canManageReferrals ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Create referral</CardTitle>
                  <CardDescription>
                    Link a referrer member to a new referee. Referee cannot already have a referral.
                  </CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setShowRefForm(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form noValidate onSubmit={onCreateReferral} className="grid gap-3 sm:grid-cols-2">
                {canViewMembers ? (
                  <Field
                    label="Search members"
                    htmlFor="referral-member-search"
                    className="sm:col-span-2"
                  >
                    <Input
                      id="referral-member-search"
                      placeholder="Search to populate pickers…"
                      value={refMemberSearch}
                      onChange={(e) => setRefMemberSearch(e.target.value)}
                    />
                  </Field>
                ) : null}
                <Field
                  label="Referrer"
                  htmlFor="referral-referrer"
                  required
                  error={referralFieldErrors.referrer_id}
                >
                  {canViewMembers ? (
                    <Select
                      id="referral-referrer"
                      required
                      aria-invalid={Boolean(referralFieldErrors.referrer_id)}
                      value={referrerId === '' ? '' : String(referrerId)}
                      onChange={(e) => {
                        clearReferralFieldError('referrer_id')
                        setReferrerId(e.target.value ? Number(e.target.value) : '')
                      }}
                    >
                      <option value="">Select referrer</option>
                      {members.map((m) => (
                        <option key={m.id} value={m.id}>
                          {memberLabel(m)}
                        </option>
                      ))}
                    </Select>
                  ) : (
                    <Input
                      id="referral-referrer"
                      required
                      aria-invalid={Boolean(referralFieldErrors.referrer_id)}
                      type="number"
                      value={referrerId === '' ? '' : referrerId}
                      onChange={(e) => {
                        clearReferralFieldError('referrer_id')
                        setReferrerId(e.target.value ? Number(e.target.value) : '')
                      }}
                    />
                  )}
                </Field>
                <Field
                  label="Referee"
                  htmlFor="referral-referee"
                  required
                  error={referralFieldErrors.referee_id}
                >
                  {canViewMembers ? (
                    <Select
                      id="referral-referee"
                      required
                      aria-invalid={Boolean(referralFieldErrors.referee_id)}
                      value={refereeId === '' ? '' : String(refereeId)}
                      onChange={(e) => {
                        clearReferralFieldError('referee_id')
                        setRefereeId(e.target.value ? Number(e.target.value) : '')
                      }}
                    >
                      <option value="">Select referee</option>
                      {members.map((m) => (
                        <option key={m.id} value={m.id}>
                          {memberLabel(m)}
                        </option>
                      ))}
                    </Select>
                  ) : (
                    <Input
                      id="referral-referee"
                      required
                      aria-invalid={Boolean(referralFieldErrors.referee_id)}
                      type="number"
                      value={refereeId === '' ? '' : refereeId}
                      onChange={(e) => {
                        clearReferralFieldError('referee_id')
                        setRefereeId(e.target.value ? Number(e.target.value) : '')
                      }}
                    />
                  )}
                </Field>
                <div className="flex justify-end gap-2 sm:col-span-2">
                  <Button type="button" variant="secondary" onClick={() => setShowRefForm(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createRefMutation.isPending}>
                    {createRefMutation.isPending ? 'Creating…' : 'Create referral'}
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          <Card>
            <div className="mb-4 flex flex-wrap items-end gap-3">
              <div>
                <Label>Status</Label>
                <Select
                  value={refStatus}
                  onChange={(e) => {
                    setRefStatus(e.target.value as '' | ReferralStatus)
                    setRefPage(1)
                  }}
                >
                  <option value="">All</option>
                  <option value="pending">Pending</option>
                  <option value="qualified">Qualified</option>
                  <option value="rewarded">Rewarded</option>
                  <option value="disqualified">Disqualified</option>
                </Select>
              </div>
            </div>
            {referralsQuery.isLoading ? (
              <div className="flex justify-center py-12">
                <Spinner />
              </div>
            ) : referralsQuery.isError ? (
              <Alert tone="danger">
                {referralsQuery.error instanceof ApiError
                  ? referralsQuery.error.message
                  : 'Failed to load referrals.'}
              </Alert>
            ) : (
              <>
                <DataTable
                  columns={referralColumns}
                  rows={referralsQuery.data?.data ?? []}
                  rowKey={(r) => r.id}
                  emptyTitle="No referrals"
                  emptyDescription="Create a referral when a member brings a friend."
                />
                <Pagination
                  meta={referralsQuery.data?.meta}
                  onPageChange={(p) => {
                    setRefPage(p)
                    setSelectedRefId(null)
                  }}
                />
              </>
            )}
          </Card>

          {selectedRefId != null ? (
            <Card className="border-accent/20">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Referral detail</CardTitle>
                  <CardDescription>Referral #{selectedRefId}</CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setSelectedRefId(null)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              {referralDetailQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Spinner />
                </div>
              ) : selectedRef ? (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone={referralTone(selectedRef.status)}>{selectedRef.status}</Badge>
                    <span className="text-sm text-muted">
                      Created {formatDate(selectedRef.created_at)}
                    </span>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <DetailStat label="Referrer" value={memberLabel(selectedRef.referrer)} />
                    <DetailStat label="Referee" value={memberLabel(selectedRef.referee)} />
                    <DetailStat
                      label="Qualified"
                      value={formatDate(selectedRef.qualified_at)}
                    />
                    <DetailStat
                      label="Rewarded"
                      value={formatDate(selectedRef.rewarded_at)}
                    />
                  </div>
                  {selectedRef.reward_type || selectedRef.reward_reference ? (
                    <p className="text-sm text-muted">
                      Reward: {selectedRef.reward_type || '—'}
                      {selectedRef.reward_reference
                        ? ` · ${selectedRef.reward_reference}`
                        : ''}
                    </p>
                  ) : null}

                  {canManageReferrals ? (
                    <div className="space-y-3">
                      {selectedRef.status === 'pending' ? (
                        <div className="flex flex-wrap gap-2">
                          <Button
                            size="sm"
                            disabled={qualifyMutation.isPending}
                            onClick={() => qualifyMutation.mutate(selectedRef.id)}
                          >
                            Qualify
                          </Button>
                          <Button
                            size="sm"
                            variant="danger"
                            disabled={disqualifyMutation.isPending}
                            onClick={() => disqualifyMutation.mutate(selectedRef.id)}
                          >
                            Disqualify
                          </Button>
                        </div>
                      ) : null}
                      {selectedRef.status === 'qualified' ? (
                        <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3 space-y-3">
                          <p className="text-sm text-muted">
                            Mark as rewarded and optionally record reward details.
                          </p>
                          <div className="grid gap-3 sm:grid-cols-2">
                            <div>
                              <Label>Reward type</Label>
                              <Input
                                value={rewardType}
                                onChange={(e) => setRewardType(e.target.value)}
                                placeholder="credit, free_month…"
                              />
                            </div>
                            <div>
                              <Label>Reward reference</Label>
                              <Input
                                value={rewardReference}
                                onChange={(e) => setRewardReference(e.target.value)}
                                placeholder="Optional reference"
                              />
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            <Button
                              size="sm"
                              disabled={rewardMutation.isPending}
                              onClick={() => rewardMutation.mutate(selectedRef.id)}
                            >
                              <Gift className="h-4 w-4" />
                              Reward
                            </Button>
                            <Button
                              size="sm"
                              variant="danger"
                              disabled={disqualifyMutation.isPending}
                              onClick={() => disqualifyMutation.mutate(selectedRef.id)}
                            >
                              Disqualify
                            </Button>
                          </div>
                        </div>
                      ) : null}
                    </div>
                  ) : null}
                </div>
              ) : (
                <Alert tone="danger">Referral not found.</Alert>
              )}
            </Card>
          ) : null}
        </>
      ) : null}

      {tab === 'loyalty' && canViewLoyalty ? <LoyaltyPanel /> : null}
    </div>
  )
}

function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean
  onClick: () => void
  children: ReactNode
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'rounded-xl px-3 py-2 text-sm font-semibold transition',
        active
          ? 'bg-accent text-accent-ink'
          : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
      )}
    >
      {children}
    </button>
  )
}

function DetailStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-0.5 text-sm font-semibold text-ink">{value}</p>
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}
