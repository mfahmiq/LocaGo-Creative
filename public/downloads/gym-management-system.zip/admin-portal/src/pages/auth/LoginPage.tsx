import { useState } from 'react'
import { useForm, FormProvider } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useNavigate, useLocation } from 'react-router-dom'
import { AuthLayout } from '@/layouts/AuthLayout'
import { TextField } from '@/components/form/TextField'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { useAuth } from '@/auth/AuthContext'
import { ApiError } from '@/api/client'

const loginSchema = z.object({
  email: z.email('Enter a valid email'),
  password: z.string().min(1, 'Password is required'),
})

type LoginValues = z.infer<typeof loginSchema>

type AmbiguousTenant = {
  id?: number
  slug: string
  name?: string
}

export function LoginPage() {
  const { login } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [error, setError] = useState<string | null>(null)
  const [ambiguousTenants, setAmbiguousTenants] = useState<AmbiguousTenant[]>([])
  const [selectedTenantSlug, setSelectedTenantSlug] = useState('')

  const methods = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: 'admin@demo-gym.test',
      password: '',
    },
  })

  const redirectAfterLogin = () => {
    const redirectTo =
      typeof location.state === 'object' &&
      location.state &&
      'from' in location.state &&
      typeof location.state.from === 'string'
        ? location.state.from
        : '/'
    navigate(redirectTo, { replace: true })
  }

  const onSubmit = methods.handleSubmit(async (values) => {
    setError(null)
    try {
      await login({
        email: values.email,
        password: values.password,
        tenantSlug: selectedTenantSlug || undefined,
      })
      setAmbiguousTenants([])
      setSelectedTenantSlug('')
      redirectAfterLogin()
    } catch (err) {
      if (err instanceof ApiError && err.code === 'ambiguous_tenant') {
        const tenants = Array.isArray(err.data?.tenants)
          ? (err.data.tenants as AmbiguousTenant[]).filter(
              (t): t is AmbiguousTenant => typeof t?.slug === 'string',
            )
          : []
        setAmbiguousTenants(tenants)
        setSelectedTenantSlug(tenants[0]?.slug ?? '')
        setError('This email belongs to more than one gym. Select which gym to open.')
        return
      }

      const message =
        err instanceof ApiError ? err.message : 'Unable to sign in. Check your credentials.'
      setError(message)
    }
  })

  return (
    <AuthLayout
      title="Sign in"
      subtitle="One panel for Super Admin and gym staff. Your access is limited to your tenant and branch after login."
    >
      <FormProvider {...methods}>
        <form className="space-y-4" onSubmit={onSubmit} noValidate>
          {error ? <Alert tone="danger">{error}</Alert> : null}

          <TextField<LoginValues>
            name="email"
            label="Email"
            type="email"
            autoComplete="username"
            required
          />
          <TextField<LoginValues>
            name="password"
            label="Password"
            type="password"
            autoComplete="current-password"
            required
          />

          {ambiguousTenants.length > 0 ? (
            <div className="space-y-1.5">
              <Label htmlFor="tenant-pick" required>
                Gym / tenant
              </Label>
              <Select
                id="tenant-pick"
                value={selectedTenantSlug}
                onChange={(e) => setSelectedTenantSlug(e.target.value)}
                required
                aria-invalid={!selectedTenantSlug}
              >
                {ambiguousTenants.map((tenant) => (
                  <option key={tenant.slug} value={tenant.slug}>
                    {tenant.name ?? tenant.slug}
                  </option>
                ))}
              </Select>
            </div>
          ) : null}

          <Button type="submit" className="w-full" loading={methods.formState.isSubmitting}>
            Enter console
          </Button>

          <div className="rounded-xl border border-white/15 bg-white/8 px-3 py-3 text-center text-xs leading-relaxed text-muted">
            <p>
              Demo staff:{' '}
              <span className="font-semibold text-ink">admin@demo-gym.test</span> / Password1!
            </p>
            <p className="mt-1">
              Super Admin:{' '}
              <span className="font-semibold text-ink">superadmin@gms.test</span> / Password1!
            </p>
          </div>
        </form>
      </FormProvider>
    </AuthLayout>
  )
}
