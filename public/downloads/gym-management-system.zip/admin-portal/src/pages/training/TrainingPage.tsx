import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  CalendarDays,
  CheckCircle2,
  Dumbbell,
  Plus,
  Search,
  Trash2,
  UserRound,
  X,
  XCircle,
} from 'lucide-react'
import {
  assignTrainerMember,
  cancelMemberWorkoutPlan,
  cancelPtSession,
  completePtSession,
  createMemberWorkoutPlan,
  createPtSession,
  createTrainer,
  createWorkoutProgram,
  deleteTrainer,
  deleteWorkoutProgram,
  fetchMemberWorkoutPlans,
  fetchPtSession,
  fetchPtSessions,
  fetchTrainerMembers,
  fetchTrainers,
  fetchWorkoutProgram,
  fetchWorkoutPrograms,
  noShowPtSession,
  publishMemberWorkoutPlan,
  unassignTrainerMember,
  updatePtSession,
  updateTrainer,
  updateWorkoutProgram,
  type ExerciseInput,
  type MemberWorkoutPlan,
  type MemberWorkoutPlanStatus,
  type PtSession,
  type PtSessionStatus,
  type Trainer,
  type WorkoutProgram,
} from '@/api/training'
import { fetchMembers, type Member } from '@/api/members'
import { fetchStaff } from '@/api/staff'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useBranchFilter } from '@/hooks/useBranchFilter'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'
import { PtPackagesPanel } from '@/pages/training/PtPackagesPanel'

type PageTab = 'sessions' | 'packages' | 'programs' | 'plans' | 'trainers'

function todayIso() {
  return new Date().toISOString().slice(0, 10)
}

function toLocalInputValue(date = new Date()) {
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`
}

function tomorrowAt(hour: number, minute = 0) {
  const d = new Date()
  d.setDate(d.getDate() + 1)
  d.setHours(hour, minute, 0, 0)
  return toLocalInputValue(d)
}

function localInputToApi(value: string) {
  if (!value) return value
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:00`
}

function formatDateTime(value?: string | null): string {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return new Intl.DateTimeFormat(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date)
}

function memberLabel(m?: {
  first_name?: string
  last_name?: string
  member_code?: string
  full_name?: string
} | null) {
  if (!m) return '—'
  if (m.full_name) {
    return m.member_code ? `${m.full_name} (${m.member_code})` : m.full_name
  }
  const name = `${m.first_name ?? ''} ${m.last_name ?? ''}`.trim()
  return name ? `${name}${m.member_code ? ` (${m.member_code})` : ''}` : m.member_code || '—'
}

function trainerLabel(t?: Trainer | PtSession['trainer'] | null) {
  if (!t) return '—'
  const name = t.user?.name
  if (name) return t.specialty ? `${name} · ${t.specialty}` : name
  return t.specialty || `Trainer #${t.id}`
}

function sessionTone(
  status: PtSessionStatus,
): 'success' | 'danger' | 'neutral' | 'warning' | 'accent' {
  switch (status) {
    case 'scheduled':
      return 'accent'
    case 'completed':
      return 'success'
    case 'cancelled':
      return 'danger'
    case 'no_show':
      return 'warning'
    default:
      return 'neutral'
  }
}

function planTone(
  status: MemberWorkoutPlanStatus,
): 'success' | 'danger' | 'neutral' | 'accent' {
  switch (status) {
    case 'active':
      return 'success'
    case 'completed':
      return 'accent'
    case 'cancelled':
      return 'danger'
    default:
      return 'neutral'
  }
}

type ExerciseDraft = {
  key: string
  name: string
  day_number: string
  sets: string
  reps: string
  rest_seconds: string
  notes: string
}

function emptyExercise(): ExerciseDraft {
  return {
    key: `${Date.now()}-${Math.random()}`,
    name: '',
    day_number: '1',
    sets: '',
    reps: '',
    rest_seconds: '',
    notes: '',
  }
}

function exercisesToPayload(items: ExerciseDraft[]): ExerciseInput[] {
  return items
    .filter((e) => e.name.trim())
    .map((e, index) => ({
      name: e.name.trim(),
      day_number: e.day_number ? Number(e.day_number) : 1,
      sort_order: index + 1,
      sets: e.sets ? Number(e.sets) : null,
      reps: e.reps.trim() || null,
      rest_seconds: e.rest_seconds ? Number(e.rest_seconds) : null,
      notes: e.notes.trim() || null,
    }))
}

export function TrainingPage() {
  const { branches, branchId, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('training.view')
  const canManage = hasPermission('training.manage')
  const canStaff = hasPermission('identity.staff.view')

  const [tab, setTab] = useState<PageTab>('sessions')
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }

  // PT sessions
  const [sessionPage, setSessionPage] = useState(1)
  const [sessionStatus, setSessionStatus] = useState<'' | PtSessionStatus>('scheduled')
  const [sessionDate, setSessionDate] = useState(todayIso())
  const [sessionBranch, setSessionBranch] = useBranchFilter()
  const [sessionTrainer, setSessionTrainer] = useState<number | ''>('')
  const [selectedSessionId, setSelectedSessionId] = useState<number | null>(null)
  const [showCreateSession, setShowCreateSession] = useState(false)
  const [sessionForm, setSessionForm] = useState({
    branch_id: '' as number | '',
    trainer_id: '' as number | '',
    member_id: '' as number | '',
    starts_at: tomorrowAt(9),
    ends_at: '',
    notes: '',
  })
  const [memberSearch, setMemberSearch] = useState('')
  const [appliedMemberSearch, setAppliedMemberSearch] = useState('')
  const [editStartsAt, setEditStartsAt] = useState('')
  const [editEndsAt, setEditEndsAt] = useState('')
  const [editNotes, setEditNotes] = useState('')

  // Programs
  const [programPage, setProgramPage] = useState(1)
  const [programSearch, setProgramSearch] = useState('')
  const [appliedProgramSearch, setAppliedProgramSearch] = useState('')
  const [programActive, setProgramActive] = useState<'' | 'active' | 'inactive'>('active')
  const [selectedProgramId, setSelectedProgramId] = useState<number | null>(null)
  const [showProgramForm, setShowProgramForm] = useState(false)
  const [editingProgram, setEditingProgram] = useState<WorkoutProgram | null>(null)
  const [programForm, setProgramForm] = useState({
    name: '',
    goal: '',
    duration_weeks: '4',
    description: '',
    created_by_trainer_id: '' as number | '',
    is_active: true,
  })
  const [exercises, setExercises] = useState<ExerciseDraft[]>([emptyExercise()])

  // Plans
  const [planPage, setPlanPage] = useState(1)
  const [planStatus, setPlanStatus] = useState<'' | MemberWorkoutPlanStatus>('active')
  const [showAssignPlan, setShowAssignPlan] = useState(false)
  const [planForm, setPlanForm] = useState({
    member_id: '' as number | '',
    workout_program_id: '' as number | '',
    trainer_id: '' as number | '',
    start_date: todayIso(),
    end_date: '',
  })
  const [planMemberSearch, setPlanMemberSearch] = useState('')
  const [appliedPlanMemberSearch, setAppliedPlanMemberSearch] = useState('')

  // Trainers
  const [trainerPage, setTrainerPage] = useState(1)
  const [trainerActive, setTrainerActive] = useState<'' | 'active' | 'inactive'>('active')
  const [selectedTrainerId, setSelectedTrainerId] = useState<number | null>(null)
  const [showCreateTrainer, setShowCreateTrainer] = useState(false)
  const [trainerForm, setTrainerForm] = useState({
    user_id: '' as number | '',
    specialty: '',
    bio: '',
    is_active: true,
  })
  const [assignMemberId, setAssignMemberId] = useState<number | ''>('')
  const [assignMemberSearch, setAssignMemberSearch] = useState('')
  const [appliedAssignMemberSearch, setAppliedAssignMemberSearch] = useState('')

  useEffect(() => {
    setSessionForm((f) => ({
      ...f,
      branch_id: branchId ?? '',
    }))
  }, [branchId])

  const trainersOptionsQuery = useQuery({
    queryKey: ['admin', 'trainers', 'options'],
    queryFn: () => fetchTrainers({ page: 1, per_page: 100, is_active: true }),
    enabled: canView,
  })

  const programsOptionsQuery = useQuery({
    queryKey: ['admin', 'workout-programs', 'options'],
    queryFn: () => fetchWorkoutPrograms({ page: 1, per_page: 100, is_active: true }),
    enabled: canView && (tab === 'plans' || showAssignPlan),
  })

  const sessionsQuery = useQuery({
    queryKey: [
      'admin',
      'pt-sessions',
      sessionPage,
      sessionStatus,
      sessionDate,
      sessionBranch,
      sessionTrainer,
    ],
    queryFn: () =>
      fetchPtSessions({
        page: sessionPage,
        per_page: DEFAULT_PAGE_SIZE,
        status: sessionStatus,
        date: sessionDate || undefined,
        branch_id: sessionBranch,
        trainer_id: sessionTrainer,
      }),
    enabled: canView && tab === 'sessions',
  })

  const sessionStatsQuery = useQuery({
    queryKey: ['admin', 'pt-sessions', 'stats', sessionDate, sessionBranch],
    queryFn: async () => {
      const [scheduled, completed, cancelled] = await Promise.all([
        fetchPtSessions({
          page: 1,
          per_page: 1,
          status: 'scheduled',
          date: sessionDate || undefined,
          branch_id: sessionBranch,
        }),
        fetchPtSessions({
          page: 1,
          per_page: 1,
          status: 'completed',
          date: sessionDate || undefined,
          branch_id: sessionBranch,
        }),
        fetchPtSessions({
          page: 1,
          per_page: 1,
          status: 'cancelled',
          date: sessionDate || undefined,
          branch_id: sessionBranch,
        }),
      ])
      return {
        scheduled: scheduled.meta.total,
        completed: completed.meta.total,
        cancelled: cancelled.meta.total,
      }
    },
    enabled: canView,
  })

  const selectedSessionQuery = useQuery({
    queryKey: ['admin', 'pt-sessions', 'detail', selectedSessionId],
    queryFn: () => fetchPtSession(selectedSessionId!),
    enabled: canView && selectedSessionId != null,
  })

  const sessionMembersQuery = useQuery({
    queryKey: ['admin', 'members', 'pt-search', appliedMemberSearch],
    queryFn: () =>
      fetchMembers({
        page: 1,
        per_page: 20,
        search: appliedMemberSearch,
        status: 'active',
      }),
    enabled: canManage && showCreateSession && appliedMemberSearch.length > 0,
  })

  const programsQuery = useQuery({
    queryKey: [
      'admin',
      'workout-programs',
      programPage,
      appliedProgramSearch,
      programActive,
    ],
    queryFn: () =>
      fetchWorkoutPrograms({
        page: programPage,
        per_page: DEFAULT_PAGE_SIZE,
        search: appliedProgramSearch,
        is_active: programActive === '' ? '' : programActive === 'active',
      }),
    enabled: canView && tab === 'programs',
  })

  const selectedProgramQuery = useQuery({
    queryKey: ['admin', 'workout-programs', 'detail', selectedProgramId],
    queryFn: () => fetchWorkoutProgram(selectedProgramId!),
    enabled: canView && selectedProgramId != null && tab === 'programs',
  })

  const plansQuery = useQuery({
    queryKey: ['admin', 'member-workout-plans', planPage, planStatus],
    queryFn: () =>
      fetchMemberWorkoutPlans({
        page: planPage,
        per_page: DEFAULT_PAGE_SIZE,
        status: planStatus,
      }),
    enabled: canView && tab === 'plans',
  })

  const planMembersQuery = useQuery({
    queryKey: ['admin', 'members', 'plan-search', appliedPlanMemberSearch],
    queryFn: () =>
      fetchMembers({
        page: 1,
        per_page: 20,
        search: appliedPlanMemberSearch,
        status: 'active',
      }),
    enabled: canManage && showAssignPlan && appliedPlanMemberSearch.length > 0,
  })

  const trainersQuery = useQuery({
    queryKey: ['admin', 'trainers', trainerPage, trainerActive],
    queryFn: () =>
      fetchTrainers({
        page: trainerPage,
        per_page: DEFAULT_PAGE_SIZE,
        is_active: trainerActive === '' ? '' : trainerActive === 'active',
      }),
    enabled: canView && tab === 'trainers',
  })

  const trainerMembersQuery = useQuery({
    queryKey: ['admin', 'trainers', 'members', selectedTrainerId],
    queryFn: () => fetchTrainerMembers(selectedTrainerId!),
    enabled: canView && selectedTrainerId != null && tab === 'trainers',
  })

  const staffQuery = useQuery({
    queryKey: ['admin', 'staff', 'trainer-picker'],
    queryFn: () => fetchStaff({ page: 1, per_page: 100, is_active: true }),
    enabled: canManage && canStaff && showCreateTrainer,
  })

  const assignMembersQuery = useQuery({
    queryKey: ['admin', 'members', 'trainer-assign', appliedAssignMemberSearch],
    queryFn: () =>
      fetchMembers({
        page: 1,
        per_page: 20,
        search: appliedAssignMemberSearch,
        status: 'active',
      }),
    enabled: canManage && selectedTrainerId != null && appliedAssignMemberSearch.length > 0,
  })

  const trainers = trainersOptionsQuery.data?.data ?? []
  const programs = programsOptionsQuery.data?.data ?? []
  const sessions = sessionsQuery.data?.data ?? []
  const selectedSession = useMemo(() => {
    if (selectedSessionId == null) return null
    return (
      selectedSessionQuery.data ??
      sessions.find((row) => row.id === selectedSessionId) ??
      null
    )
  }, [selectedSessionId, selectedSessionQuery.data, sessions])

  const selectedProgram = useMemo(() => {
    if (selectedProgramId == null) return null
    return selectedProgramQuery.data ?? null
  }, [selectedProgramId, selectedProgramQuery.data])

  const selectedTrainer = useMemo(() => {
    if (selectedTrainerId == null) return null
    return trainersQuery.data?.data.find((t) => t.id === selectedTrainerId) ?? null
  }, [selectedTrainerId, trainersQuery.data])

  useEffect(() => {
    if (!selectedSession) return
    setEditNotes(selectedSession.notes ?? '')
    if (selectedSession.starts_at) {
      const d = new Date(selectedSession.starts_at)
      if (!Number.isNaN(d.getTime())) setEditStartsAt(toLocalInputValue(d))
    }
    if (selectedSession.ends_at) {
      const d = new Date(selectedSession.ends_at)
      if (!Number.isNaN(d.getTime())) setEditEndsAt(toLocalInputValue(d))
    } else {
      setEditEndsAt('')
    }
  }, [selectedSession?.id])

  const invalidate = async (keys: string[]) => {
    await Promise.all(keys.map((key) => queryClient.invalidateQueries({ queryKey: ['admin', key] })))
  }

  const apiError = (err: unknown, fallback: string) =>
    err instanceof ApiError ? err.message : fallback

  // Mutations
  const createSessionMutation = useMutation({
    mutationFn: createPtSession,
    onSuccess: async (row) => {
      setError(null)
      showSuccess(`PT session #${row.id} scheduled.`)
      setShowCreateSession(false)
      setSessionForm({
        branch_id: branchId ?? '',
        trainer_id: '',
        member_id: '',
        starts_at: tomorrowAt(9),
        ends_at: '',
        notes: '',
      })
      setMemberSearch('')
      setAppliedMemberSearch('')
      setSessionDate(row.starts_at?.slice(0, 10) || sessionDate)
      setSessionStatus('scheduled')
      await invalidate(['pt-sessions'])
      setSelectedSessionId(row.id)
    },
    onError: (err) => setError(apiError(err, 'Unable to schedule PT session.')),
  })

  const updateSessionMutation = useMutation({
    mutationFn: () =>
      updatePtSession(selectedSessionId!, {
        starts_at: localInputToApi(editStartsAt),
        ends_at: editEndsAt ? localInputToApi(editEndsAt) : null,
        notes: editNotes.trim() || null,
      }),
    onSuccess: async () => {
      setError(null)
      showSuccess('Session updated.')
      await invalidate(['pt-sessions'])
    },
    onError: (err) => setError(apiError(err, 'Unable to update session.')),
  })

  const completeSessionMutation = useMutation({
    mutationFn: () => completePtSession(selectedSessionId!, editNotes.trim() || null),
    onSuccess: async () => {
      showSuccess('Session marked completed.')
      await invalidate(['pt-sessions'])
    },
    onError: (err) => setError(apiError(err, 'Unable to complete session.')),
  })

  const cancelSessionMutation = useMutation({
    mutationFn: () => cancelPtSession(selectedSessionId!, editNotes.trim() || null),
    onSuccess: async () => {
      showSuccess('Session cancelled.')
      await invalidate(['pt-sessions'])
    },
    onError: (err) => setError(apiError(err, 'Unable to cancel session.')),
  })

  const noShowSessionMutation = useMutation({
    mutationFn: () => noShowPtSession(selectedSessionId!, editNotes.trim() || null),
    onSuccess: async () => {
      showSuccess('Session marked no-show.')
      await invalidate(['pt-sessions'])
    },
    onError: (err) => setError(apiError(err, 'Unable to mark no-show.')),
  })

  const saveProgramMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        name: programForm.name.trim(),
        goal: programForm.goal.trim() || null,
        duration_weeks: programForm.duration_weeks
          ? Number(programForm.duration_weeks)
          : null,
        description: programForm.description.trim() || null,
        created_by_trainer_id: programForm.created_by_trainer_id
          ? Number(programForm.created_by_trainer_id)
          : null,
        is_active: programForm.is_active,
        exercises: exercisesToPayload(exercises),
      }
      if (editingProgram) return updateWorkoutProgram(editingProgram.id, payload)
      return createWorkoutProgram(payload)
    },
    onSuccess: async (program) => {
      setError(null)
      showSuccess(
        editingProgram
          ? `Program “${program.name}” updated.`
          : `Program “${program.name}” created.`,
      )
      setShowProgramForm(false)
      setEditingProgram(null)
      await invalidate(['workout-programs'])
      setSelectedProgramId(program.id)
    },
    onError: (err) => setError(apiError(err, 'Unable to save program.')),
  })

  const deleteProgramMutation = useMutation({
    mutationFn: deleteWorkoutProgram,
    onSuccess: async () => {
      showSuccess('Program deleted.')
      setSelectedProgramId(null)
      setEditingProgram(null)
      setShowProgramForm(false)
      await invalidate(['workout-programs'])
    },
    onError: (err) => setError(apiError(err, 'Unable to delete program.')),
  })

  const assignPlanMutation = useMutation({
    mutationFn: createMemberWorkoutPlan,
    onSuccess: async (plan) => {
      showSuccess(`Plan #${plan.id} assigned.`)
      setShowAssignPlan(false)
      setPlanForm({
        member_id: '',
        workout_program_id: '',
        trainer_id: '',
        start_date: todayIso(),
        end_date: '',
      })
      setPlanStatus('active')
      await invalidate(['member-workout-plans'])
    },
    onError: (err) => setError(apiError(err, 'Unable to assign plan.')),
  })

  const publishPlanMutation = useMutation({
    mutationFn: publishMemberWorkoutPlan,
    onSuccess: async () => {
      showSuccess('Plan published to member.')
      await invalidate(['member-workout-plans'])
    },
    onError: (err) => setError(apiError(err, 'Unable to publish plan.')),
  })

  const cancelPlanMutation = useMutation({
    mutationFn: cancelMemberWorkoutPlan,
    onSuccess: async () => {
      showSuccess('Plan cancelled.')
      await invalidate(['member-workout-plans'])
    },
    onError: (err) => setError(apiError(err, 'Unable to cancel plan.')),
  })

  const createTrainerMutation = useMutation({
    mutationFn: createTrainer,
    onSuccess: async (trainer) => {
      showSuccess(`Trainer “${trainerLabel(trainer)}” created.`)
      setShowCreateTrainer(false)
      setTrainerForm({ user_id: '', specialty: '', bio: '', is_active: true })
      await invalidate(['trainers'])
      setSelectedTrainerId(trainer.id)
    },
    onError: (err) => setError(apiError(err, 'Unable to create trainer.')),
  })

  const toggleTrainerMutation = useMutation({
    mutationFn: ({ id, is_active }: { id: number; is_active: boolean }) =>
      updateTrainer(id, { is_active }),
    onSuccess: async (trainer) => {
      showSuccess(trainer.is_active ? 'Trainer activated.' : 'Trainer deactivated.')
      await invalidate(['trainers'])
    },
    onError: (err) => setError(apiError(err, 'Unable to update trainer.')),
  })

  const deleteTrainerMutation = useMutation({
    mutationFn: deleteTrainer,
    onSuccess: async () => {
      showSuccess('Trainer removed.')
      setSelectedTrainerId(null)
      await invalidate(['trainers'])
    },
    onError: (err) => setError(apiError(err, 'Unable to delete trainer.')),
  })

  const assignMemberMutation = useMutation({
    mutationFn: () =>
      assignTrainerMember(selectedTrainerId!, {
        member_id: Number(assignMemberId),
        is_primary: false,
      }),
    onSuccess: async () => {
      showSuccess('Member assigned to trainer.')
      setAssignMemberId('')
      await queryClient.invalidateQueries({
        queryKey: ['admin', 'trainers', 'members', selectedTrainerId],
      })
    },
    onError: (err) => setError(apiError(err, 'Unable to assign member.')),
  })

  const unassignMemberMutation = useMutation({
    mutationFn: (memberId: number) => unassignTrainerMember(selectedTrainerId!, memberId),
    onSuccess: async () => {
      showSuccess('Member unassigned.')
      await queryClient.invalidateQueries({
        queryKey: ['admin', 'trainers', 'members', selectedTrainerId],
      })
    },
    onError: (err) => setError(apiError(err, 'Unable to unassign member.')),
  })

  const onCreateSession = (event: FormEvent) => {
    event.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'branch_id', label: 'Branch', value: sessionForm.branch_id },
      { key: 'trainer_id', label: 'Trainer', value: sessionForm.trainer_id },
      { key: 'member_id', label: 'Member', value: sessionForm.member_id },
      { key: 'starts_at', label: 'Starts at', value: sessionForm.starts_at },
    ])
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    createSessionMutation.mutate({
      branch_id: Number(sessionForm.branch_id),
      trainer_id: Number(sessionForm.trainer_id),
      member_id: Number(sessionForm.member_id),
      starts_at: localInputToApi(sessionForm.starts_at),
      ends_at: sessionForm.ends_at ? localInputToApi(sessionForm.ends_at) : null,
      notes: sessionForm.notes.trim() || null,
    })
  }

  const openProgramCreate = () => {
    setEditingProgram(null)
    setProgramForm({
      name: '',
      goal: '',
      duration_weeks: '4',
      description: '',
      created_by_trainer_id: '',
      is_active: true,
    })
    setExercises([emptyExercise()])
    setShowProgramForm(true)
    setError(null)
  }

  const openProgramEdit = async (program: WorkoutProgram) => {
    setError(null)
    try {
      const full = await fetchWorkoutProgram(program.id)
      setEditingProgram(full)
      setProgramForm({
        name: full.name,
        goal: full.goal ?? '',
        duration_weeks: full.duration_weeks != null ? String(full.duration_weeks) : '',
        description: full.description ?? '',
        created_by_trainer_id: full.created_by_trainer_id ?? '',
        is_active: full.is_active,
      })
      setExercises(
        (full.exercises?.length
          ? full.exercises.map((e) => ({
              key: String(e.id ?? Math.random()),
              name: e.name,
              day_number: e.day_number != null ? String(e.day_number) : '1',
              sets: e.sets != null ? String(e.sets) : '',
              reps: e.reps ?? '',
              rest_seconds: e.rest_seconds != null ? String(e.rest_seconds) : '',
              notes: e.notes ?? '',
            }))
          : [emptyExercise()]),
      )
      setShowProgramForm(true)
      setSelectedProgramId(full.id)
    } catch (err) {
      setError(apiError(err, 'Unable to load program.'))
    }
  }

  const sessionColumns: Column<PtSession>[] = [
    {
      key: 'when',
      header: 'When',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedSessionId(row.id)}
        >
          <p className="font-semibold text-ink">{formatDateTime(row.starts_at)}</p>
          <p className="mt-0.5 text-xs text-muted">#{row.id}</p>
        </button>
      ),
    },
    {
      key: 'member',
      header: 'Member',
      cell: (row) => <span className="text-sm text-ink">{memberLabel(row.member)}</span>,
    },
    {
      key: 'trainer',
      header: 'Trainer',
      cell: (row) => <span className="text-sm text-muted">{trainerLabel(row.trainer)}</span>,
    },
    {
      key: 'branch',
      header: 'Branch',
      cell: (row) => <span className="text-sm text-ink">{row.branch?.name ?? '—'}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={sessionTone(row.status)}>
          {row.status === 'no_show' ? 'No-show' : row.status}
        </Badge>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedSessionId(row.id)}>
          Manage
        </Button>
      ),
    },
  ]

  const programColumns: Column<WorkoutProgram>[] = [
    {
      key: 'program',
      header: 'Program',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedProgramId(row.id)}
        >
          <p className="font-semibold text-ink">{row.name}</p>
          <p className="mt-0.5 text-xs text-muted">{row.goal || 'No goal set'}</p>
        </button>
      ),
    },
    {
      key: 'duration',
      header: 'Duration',
      cell: (row) => (
        <span className="text-sm text-ink">
          {row.duration_weeks != null ? `${row.duration_weeks} weeks` : '—'}
        </span>
      ),
    },
    {
      key: 'trainer',
      header: 'Author',
      cell: (row) => (
        <span className="text-sm text-muted">
          {trainerLabel(row.created_by_trainer)}
        </span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.is_active ? 'success' : 'danger'}>
          {row.is_active ? 'Active' : 'Inactive'}
        </Badge>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) =>
        canManage ? (
          <Button size="sm" variant="secondary" onClick={() => void openProgramEdit(row)}>
            Edit
          </Button>
        ) : (
          <Button size="sm" variant="secondary" onClick={() => setSelectedProgramId(row.id)}>
            View
          </Button>
        ),
    },
  ]

  const planColumns: Column<MemberWorkoutPlan>[] = [
    {
      key: 'member',
      header: 'Member',
      cell: (row) => (
        <div>
          <p className="font-semibold text-ink">{memberLabel(row.member)}</p>
          <p className="text-xs text-muted">{row.workout_program?.name ?? '—'}</p>
        </div>
      ),
    },
    {
      key: 'dates',
      header: 'Period',
      cell: (row) => (
        <span className="text-sm text-ink">
          {formatDate(row.start_date)} → {formatDate(row.end_date)}
        </span>
      ),
    },
    {
      key: 'trainer',
      header: 'Trainer',
      cell: (row) => <span className="text-sm text-muted">{trainerLabel(row.trainer)}</span>,
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <div className="flex flex-wrap gap-1.5">
          <Badge tone={planTone(row.status)}>{row.status}</Badge>
          {row.is_published ? <Badge tone="accent">Published</Badge> : null}
        </div>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) =>
        canManage && row.status === 'active' ? (
          <div className="flex flex-wrap justify-end gap-1.5">
            {!row.is_published ? (
              <Button
                size="sm"
                variant="secondary"
                loading={publishPlanMutation.isPending}
                onClick={() => publishPlanMutation.mutate(row.id)}
              >
                Publish
              </Button>
            ) : null}
            <Button
              size="sm"
              variant="ghost"
              loading={cancelPlanMutation.isPending}
              onClick={() => void onCancelPlan(row)}
            >
              Cancel
            </Button>
          </div>
        ) : null,
    },
  ]

  const trainerColumns: Column<Trainer>[] = [
    {
      key: 'trainer',
      header: 'Trainer',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedTrainerId(row.id)}
        >
          <p className="font-semibold text-ink">{row.user?.name ?? `Trainer #${row.id}`}</p>
          <p className="mt-0.5 text-xs text-muted">{row.specialty || row.user?.email}</p>
        </button>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.is_active ? 'success' : 'danger'}>
          {row.is_active ? 'Active' : 'Inactive'}
        </Badge>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedTrainerId(row.id)}>
          Manage
        </Button>
      ),
    },
  ]

  const onCancelPlan = async (plan: MemberWorkoutPlan) => {
    const ok = await confirm({
      title: 'Cancel plan?',
      message: `Cancel “${plan.workout_program?.name ?? 'plan'}” for ${memberLabel(plan.member)}?`,
      confirmLabel: 'Cancel plan',
      tone: 'danger',
    })
    if (!ok) return
    cancelPlanMutation.mutate(plan.id)
  }

  const onDeleteProgram = async (program: WorkoutProgram) => {
    const ok = await confirm({
      title: 'Delete program?',
      message: `Delete “${program.name}”? Programs with active assignments cannot be deleted.`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (!ok) return
    deleteProgramMutation.mutate(program.id)
  }

  const onDeleteTrainer = async (trainer: Trainer) => {
    const ok = await confirm({
      title: 'Delete trainer?',
      message: `Remove trainer profile for ${trainerLabel(trainer)}?`,
      confirmLabel: 'Delete',
      tone: 'danger',
    })
    if (!ok) return
    deleteTrainerMutation.mutate(trainer.id)
  }

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader title="Training" description="Programs and PT sessions." />
        <Alert tone="danger">You do not have permission to view training.</Alert>
      </div>
    )
  }

  const stats = sessionStatsQuery.data

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Training"
        description="Programs and PT sessions — trainers, workout plans, and 1:1 coaching."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">Gym</Badge>
            {canManage && tab === 'sessions' ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowCreateSession(true)
                  setError(null)
                }}
              >
                <Plus className="h-4 w-4" />
                Schedule PT
              </Button>
            ) : null}
            {canManage && tab === 'programs' ? (
              <Button size="sm" onClick={openProgramCreate}>
                <Plus className="h-4 w-4" />
                New program
              </Button>
            ) : null}
            {canManage && tab === 'plans' ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowAssignPlan(true)
                  setError(null)
                }}
              >
                <Plus className="h-4 w-4" />
                Assign plan
              </Button>
            ) : null}
            {canManage && tab === 'trainers' ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowCreateTrainer(true)
                  setError(null)
                }}
              >
                <Plus className="h-4 w-4" />
                Add trainer
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <SummaryChip
          icon={<CalendarDays className="h-4 w-4" />}
          label="PT scheduled"
          value={formatNumber(stats?.scheduled ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<CheckCircle2 className="h-4 w-4" />}
          label="Completed"
          value={formatNumber(stats?.completed ?? 0)}
        />
        <SummaryChip
          icon={<XCircle className="h-4 w-4" />}
          label="Cancelled"
          value={formatNumber(stats?.cancelled ?? 0)}
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {(
          [
            { id: 'sessions' as const, label: 'PT sessions' },
            { id: 'packages' as const, label: 'PT packages' },
            { id: 'programs' as const, label: 'Programs' },
            { id: 'plans' as const, label: 'Assignments' },
            { id: 'trainers' as const, label: 'Trainers' },
          ] as const
        ).map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => {
              setTab(item.id)
              setError(null)
              setSelectedSessionId(null)
              setSelectedProgramId(null)
              setSelectedTrainerId(null)
              setShowCreateSession(false)
              setShowProgramForm(false)
              setShowAssignPlan(false)
              setShowCreateTrainer(false)
            }}
            className={cn(
              'rounded-xl px-3 py-2 text-sm font-semibold transition',
              tab === item.id
                ? 'bg-accent text-accent-ink'
                : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
            )}
          >
            {item.label}
          </button>
        ))}
      </div>

      {tab === 'packages' ? <PtPackagesPanel /> : null}

      {tab === 'sessions' ? (
        <>
          {showCreateSession && canManage ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Schedule PT session</CardTitle>
                  <CardDescription>
                    Book a 1:1 session between a trainer and member.
                  </CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setShowCreateSession(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form onSubmit={onCreateSession} noValidate className="grid gap-3 sm:grid-cols-2">
                <Field label="Branch" required error={fieldErrors.branch_id}>
                  <Select
                    value={sessionForm.branch_id === '' ? '' : String(sessionForm.branch_id)}
                    onChange={(e) => {
                      setSessionForm((f) => ({
                        ...f,
                        branch_id: e.target.value ? Number(e.target.value) : '',
                      }))
                      clearFieldError('branch_id')
                    }}
                    aria-invalid={Boolean(fieldErrors.branch_id)}
                  >
                    <option value="">Select…</option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Trainer" required error={fieldErrors.trainer_id}>
                  <Select
                    value={sessionForm.trainer_id === '' ? '' : String(sessionForm.trainer_id)}
                    onChange={(e) => {
                      setSessionForm((f) => ({
                        ...f,
                        trainer_id: e.target.value ? Number(e.target.value) : '',
                      }))
                      clearFieldError('trainer_id')
                    }}
                    aria-invalid={Boolean(fieldErrors.trainer_id)}
                  >
                    <option value="">Select…</option>
                    {trainers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {trainerLabel(t)}
                      </option>
                    ))}
                  </Select>
                </Field>
                <div className="sm:col-span-2">
                  <Label>Find member</Label>
                  <div className="flex gap-2">
                    <Input
                      value={memberSearch}
                      onChange={(e) => setMemberSearch(e.target.value)}
                      placeholder="Name or code…"
                    />
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setAppliedMemberSearch(memberSearch.trim())}
                    >
                      <Search className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <Field label="Member" required error={fieldErrors.member_id} className="sm:col-span-2">
                  <Select
                    value={sessionForm.member_id === '' ? '' : String(sessionForm.member_id)}
                    onChange={(e) => {
                      setSessionForm((f) => ({
                        ...f,
                        member_id: e.target.value ? Number(e.target.value) : '',
                      }))
                      clearFieldError('member_id')
                    }}
                    aria-invalid={Boolean(fieldErrors.member_id)}
                  >
                    <option value="">Select…</option>
                    {(sessionMembersQuery.data?.data ?? []).map((m: Member) => (
                      <option key={m.id} value={m.id}>
                        {m.full_name} ({m.member_code})
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Starts at" required error={fieldErrors.starts_at}>
                  <Input
                    type="datetime-local"
                    value={sessionForm.starts_at}
                    onChange={(e) => {
                      setSessionForm((f) => ({ ...f, starts_at: e.target.value }))
                      clearFieldError('starts_at')
                    }}
                    aria-invalid={Boolean(fieldErrors.starts_at)}
                  />
                </Field>
                <div>
                  <Label>Ends at (optional)</Label>
                  <Input
                    type="datetime-local"
                    value={sessionForm.ends_at}
                    onChange={(e) =>
                      setSessionForm((f) => ({ ...f, ends_at: e.target.value }))
                    }
                  />
                </div>
                <div className="sm:col-span-2">
                  <Label>Notes</Label>
                  <Textarea
                    value={sessionForm.notes}
                    onChange={(e) => setSessionForm((f) => ({ ...f, notes: e.target.value }))}
                    rows={2}
                  />
                </div>
                <div className="flex gap-2 sm:col-span-2">
                  <Button type="submit" loading={createSessionMutation.isPending}>
                    Schedule session
                  </Button>
                  <Button type="button" variant="ghost" onClick={() => setShowCreateSession(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          <Card>
            <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
              <div className="flex flex-wrap gap-2">
                {(
                  [
                    { value: '' as const, label: 'All' },
                    { value: 'scheduled' as const, label: 'Scheduled' },
                    { value: 'completed' as const, label: 'Completed' },
                    { value: 'cancelled' as const, label: 'Cancelled' },
                    { value: 'no_show' as const, label: 'No-show' },
                  ] as const
                ).map((filter) => (
                  <button
                    key={filter.label}
                    type="button"
                    onClick={() => {
                      setSessionStatus(filter.value)
                      setSessionPage(1)
                      setSelectedSessionId(null)
                    }}
                    className={cn(
                      'rounded-xl px-3 py-2 text-sm font-semibold transition',
                      sessionStatus === filter.value
                        ? 'bg-accent text-accent-ink'
                        : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                    )}
                  >
                    {filter.label}
                  </button>
                ))}
              </div>
              <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
                <div>
                  <Label>Date</Label>
                  <Input
                    type="date"
                    value={sessionDate}
                    onChange={(e) => {
                      setSessionDate(e.target.value)
                      setSessionPage(1)
                    }}
                  />
                </div>
                <div>
                  <Label>Branch</Label>
                  <Select
                    value={sessionBranch === '' ? '' : String(sessionBranch)}
                    onChange={(e) => {
                      setSessionBranch(e.target.value ? Number(e.target.value) : '')
                      setSessionPage(1)
                    }}
                    className="sm:w-40"
                  >
                    <option value="">All</option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </Select>
                </div>
                <div>
                  <Label>Trainer</Label>
                  <Select
                    value={sessionTrainer === '' ? '' : String(sessionTrainer)}
                    onChange={(e) => {
                      setSessionTrainer(e.target.value ? Number(e.target.value) : '')
                      setSessionPage(1)
                    }}
                    className="sm:w-44"
                  >
                    <option value="">All</option>
                    {trainers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.user?.name ?? `Trainer #${t.id}`}
                      </option>
                    ))}
                  </Select>
                </div>
              </div>
            </div>
          </Card>

          <div
            className={cn(
              'grid gap-4',
              selectedSessionId != null ? 'xl:grid-cols-[1fr_26rem]' : '',
            )}
          >
            <div className="min-w-0">
              {sessionsQuery.isPending ? (
                <div className="flex justify-center py-20">
                  <Spinner label="Loading sessions…" />
                </div>
              ) : (
                <>
                  <DataTable
                    columns={sessionColumns}
                    rows={sessions}
                    rowKey={(row) => row.id}
                    emptyTitle="No PT sessions"
                    emptyDescription="Schedule a session or change the date filter."
                  />
                  <Pagination
                    meta={sessionsQuery.data?.meta}
                    onPageChange={(p) => {
                      setSessionPage(p)
                      setSelectedSessionId(null)
                    }}
                  />
                </>
              )}
            </div>

            {selectedSession ? (
              <aside className="animate-slide-in">
                <Card className="sticky top-4 space-y-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                        <Dumbbell className="h-5 w-5" />
                      </div>
                      <CardTitle className="text-base">
                        {memberLabel(selectedSession.member)}
                      </CardTitle>
                      <CardDescription>
                        with {trainerLabel(selectedSession.trainer)}
                      </CardDescription>
                    </div>
                    <Button size="sm" variant="ghost" onClick={() => setSelectedSessionId(null)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  <Badge tone={sessionTone(selectedSession.status)}>
                    {selectedSession.status}
                  </Badge>
                  <dl className="space-y-2 text-sm">
                    <DetailRow label="Starts" value={formatDateTime(selectedSession.starts_at)} />
                    <DetailRow label="Ends" value={formatDateTime(selectedSession.ends_at)} />
                    <DetailRow label="Branch" value={selectedSession.branch?.name ?? '—'} />
                  </dl>

                  {canManage && selectedSession.status === 'scheduled' ? (
                    <div className="space-y-3 border-t border-white/12 pt-4">
                      <div>
                        <Label>Starts at</Label>
                        <Input
                          type="datetime-local"
                          value={editStartsAt}
                          onChange={(e) => setEditStartsAt(e.target.value)}
                        />
                      </div>
                      <div>
                        <Label>Ends at</Label>
                        <Input
                          type="datetime-local"
                          value={editEndsAt}
                          onChange={(e) => setEditEndsAt(e.target.value)}
                        />
                      </div>
                      <div>
                        <Label>Notes</Label>
                        <Textarea
                          value={editNotes}
                          onChange={(e) => setEditNotes(e.target.value)}
                          rows={2}
                        />
                      </div>
                      <Button
                        size="sm"
                        variant="secondary"
                        loading={updateSessionMutation.isPending}
                        onClick={() => updateSessionMutation.mutate()}
                      >
                        Save changes
                      </Button>
                      <div className="flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          loading={completeSessionMutation.isPending}
                          onClick={() => completeSessionMutation.mutate()}
                        >
                          Complete
                        </Button>
                        <Button
                          size="sm"
                          variant="secondary"
                          loading={noShowSessionMutation.isPending}
                          onClick={() => noShowSessionMutation.mutate()}
                        >
                          No-show
                        </Button>
                        <Button
                          size="sm"
                          variant="danger"
                          loading={cancelSessionMutation.isPending}
                          onClick={() => cancelSessionMutation.mutate()}
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : selectedSession.notes ? (
                    <p className="text-sm text-muted">{selectedSession.notes}</p>
                  ) : null}
                </Card>
              </aside>
            ) : null}
          </div>
        </>
      ) : null}

      {tab === 'programs' ? (
        <>
          {showProgramForm && canManage ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>
                    {editingProgram ? 'Edit program' : 'Create workout program'}
                  </CardTitle>
                  <CardDescription>
                    Define goals and day-by-day exercises for member assignments.
                  </CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setShowProgramForm(false)
                    setEditingProgram(null)
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  const errors = collectRequiredErrors([
                    { key: 'name', label: 'Name', value: programForm.name },
                  ])
                  if (Object.keys(errors).length > 0) {
                    setFieldErrors(errors)
                    return
                  }
                  setFieldErrors({})
                  saveProgramMutation.mutate()
                }}
                noValidate
                className="space-y-4"
              >
                <div className="grid gap-3 sm:grid-cols-2">
                  <Field label="Name" required error={fieldErrors.name}>
                    <Input
                      value={programForm.name}
                      onChange={(e) => {
                        setProgramForm((f) => ({ ...f, name: e.target.value }))
                        clearFieldError('name')
                      }}
                      aria-invalid={Boolean(fieldErrors.name)}
                    />
                  </Field>
                  <div>
                    <Label>Goal</Label>
                    <Input
                      value={programForm.goal}
                      onChange={(e) =>
                        setProgramForm((f) => ({ ...f, goal: e.target.value }))
                      }
                      placeholder="Strength, fat loss…"
                    />
                  </div>
                  <div>
                    <Label>Duration (weeks)</Label>
                    <Input
                      type="number"
                      min="1"
                      value={programForm.duration_weeks}
                      onChange={(e) =>
                        setProgramForm((f) => ({ ...f, duration_weeks: e.target.value }))
                      }
                    />
                  </div>
                  <div>
                    <Label>Created by trainer</Label>
                    <Select
                      value={
                        programForm.created_by_trainer_id === ''
                          ? ''
                          : String(programForm.created_by_trainer_id)
                      }
                      onChange={(e) =>
                        setProgramForm((f) => ({
                          ...f,
                          created_by_trainer_id: e.target.value
                            ? Number(e.target.value)
                            : '',
                        }))
                      }
                    >
                      <option value="">None</option>
                      {trainers.map((t) => (
                        <option key={t.id} value={t.id}>
                          {trainerLabel(t)}
                        </option>
                      ))}
                    </Select>
                  </div>
                  <div className="sm:col-span-2">
                    <Label>Description</Label>
                    <Textarea
                      value={programForm.description}
                      onChange={(e) =>
                        setProgramForm((f) => ({ ...f, description: e.target.value }))
                      }
                      rows={2}
                    />
                  </div>
                  <label className="flex items-center gap-2 text-sm text-ink sm:col-span-2">
                    <input
                      type="checkbox"
                      checked={programForm.is_active}
                      onChange={(e) =>
                        setProgramForm((f) => ({ ...f, is_active: e.target.checked }))
                      }
                    />
                    Active
                  </label>
                </div>

                <div>
                  <div className="mb-2 flex items-center justify-between">
                    <p className="text-sm font-semibold text-ink">Exercises</p>
                    <Button
                      type="button"
                      size="sm"
                      variant="secondary"
                      onClick={() => setExercises((list) => [...list, emptyExercise()])}
                    >
                      <Plus className="h-4 w-4" />
                      Add
                    </Button>
                  </div>
                  <div className="space-y-3">
                    {exercises.map((ex, index) => (
                      <div
                        key={ex.key}
                        className="grid gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-3 sm:grid-cols-6"
                      >
                        <div className="sm:col-span-2">
                          <Label>Name</Label>
                          <Input
                            value={ex.name}
                            onChange={(e) =>
                              setExercises((list) =>
                                list.map((item, i) =>
                                  i === index ? { ...item, name: e.target.value } : item,
                                ),
                              )
                            }
                            placeholder="Back squat"
                          />
                        </div>
                        <div>
                          <Label>Day</Label>
                          <Input
                            type="number"
                            min="1"
                            value={ex.day_number}
                            onChange={(e) =>
                              setExercises((list) =>
                                list.map((item, i) =>
                                  i === index
                                    ? { ...item, day_number: e.target.value }
                                    : item,
                                ),
                              )
                            }
                          />
                        </div>
                        <div>
                          <Label>Sets</Label>
                          <Input
                            type="number"
                            min="1"
                            value={ex.sets}
                            onChange={(e) =>
                              setExercises((list) =>
                                list.map((item, i) =>
                                  i === index ? { ...item, sets: e.target.value } : item,
                                ),
                              )
                            }
                          />
                        </div>
                        <div>
                          <Label>Reps</Label>
                          <Input
                            value={ex.reps}
                            onChange={(e) =>
                              setExercises((list) =>
                                list.map((item, i) =>
                                  i === index ? { ...item, reps: e.target.value } : item,
                                ),
                              )
                            }
                            placeholder="8-10"
                          />
                        </div>
                        <div className="flex items-end gap-2">
                          <div className="flex-1">
                            <Label>Rest (s)</Label>
                            <Input
                              type="number"
                              min="0"
                              value={ex.rest_seconds}
                              onChange={(e) =>
                                setExercises((list) =>
                                  list.map((item, i) =>
                                    i === index
                                      ? { ...item, rest_seconds: e.target.value }
                                      : item,
                                  ),
                                )
                              }
                            />
                          </div>
                          {exercises.length > 1 ? (
                            <Button
                              type="button"
                              size="sm"
                              variant="ghost"
                              onClick={() =>
                                setExercises((list) => list.filter((_, i) => i !== index))
                              }
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          ) : null}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <Button type="submit" loading={saveProgramMutation.isPending}>
                    {editingProgram ? 'Save program' : 'Create program'}
                  </Button>
                  {editingProgram ? (
                    <Button
                      type="button"
                      variant="ghost"
                      className="text-danger"
                      loading={deleteProgramMutation.isPending}
                      onClick={() => void onDeleteProgram(editingProgram)}
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete
                    </Button>
                  ) : null}
                </div>
              </form>
            </Card>
          ) : null}

          <Card>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap gap-2">
                {(
                  [
                    { value: '' as const, label: 'All' },
                    { value: 'active' as const, label: 'Active' },
                    { value: 'inactive' as const, label: 'Inactive' },
                  ] as const
                ).map((filter) => (
                  <button
                    key={filter.label}
                    type="button"
                    onClick={() => {
                      setProgramActive(filter.value)
                      setProgramPage(1)
                    }}
                    className={cn(
                      'rounded-xl px-3 py-2 text-sm font-semibold transition',
                      programActive === filter.value
                        ? 'bg-accent text-accent-ink'
                        : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                    )}
                  >
                    {filter.label}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <div className="relative min-w-[12rem] flex-1">
                  <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
                  <Input
                    value={programSearch}
                    onChange={(e) => setProgramSearch(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        setAppliedProgramSearch(programSearch.trim())
                        setProgramPage(1)
                      }
                    }}
                    placeholder="Search programs…"
                    className="pl-10"
                  />
                </div>
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    setAppliedProgramSearch(programSearch.trim())
                    setProgramPage(1)
                  }}
                >
                  Search
                </Button>
              </div>
            </div>
          </Card>

          <div
            className={cn(
              'grid gap-4',
              selectedProgramId != null && !showProgramForm
                ? 'xl:grid-cols-[1fr_24rem]'
                : '',
            )}
          >
            <div className="min-w-0">
              {programsQuery.isPending ? (
                <div className="flex justify-center py-20">
                  <Spinner label="Loading programs…" />
                </div>
              ) : (
                <>
                  <DataTable
                    columns={programColumns}
                    rows={programsQuery.data?.data ?? []}
                    rowKey={(row) => row.id}
                    emptyTitle="No programs"
                    emptyDescription="Create a workout program to assign to members."
                  />
                  <Pagination meta={programsQuery.data?.meta} onPageChange={setProgramPage} />
                </>
              )}
            </div>

            {selectedProgram && !showProgramForm ? (
              <aside className="animate-slide-in">
                <Card className="sticky top-4 space-y-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <CardTitle className="text-base">{selectedProgram.name}</CardTitle>
                      <CardDescription>{selectedProgram.goal || 'No goal'}</CardDescription>
                    </div>
                    <Button size="sm" variant="ghost" onClick={() => setSelectedProgramId(null)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  {selectedProgramQuery.isPending ? (
                    <Spinner label="Loading…" />
                  ) : (
                    <div className="max-h-80 space-y-2 overflow-y-auto">
                      {(selectedProgram.exercises ?? []).length === 0 ? (
                        <p className="text-sm text-muted">No exercises yet.</p>
                      ) : (
                        (selectedProgram.exercises ?? []).map((ex) => (
                          <div
                            key={ex.id}
                            className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-sm"
                          >
                            <p className="font-semibold text-ink">
                              Day {ex.day_number ?? '—'} · {ex.name}
                            </p>
                            <p className="text-xs text-muted">
                              {[
                                ex.sets != null ? `${ex.sets} sets` : null,
                                ex.reps ? `${ex.reps} reps` : null,
                                ex.rest_seconds != null ? `${ex.rest_seconds}s rest` : null,
                              ]
                                .filter(Boolean)
                                .join(' · ') || '—'}
                            </p>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                  {canManage ? (
                    <Button size="sm" variant="secondary" onClick={() => void openProgramEdit(selectedProgram)}>
                      Edit program
                    </Button>
                  ) : null}
                </Card>
              </aside>
            ) : null}
          </div>
        </>
      ) : null}

      {tab === 'plans' ? (
        <>
          {showAssignPlan && canManage ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Assign workout plan</CardTitle>
                  <CardDescription>
                    Link an active program to a member. Publish when ready.
                  </CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setShowAssignPlan(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  const errors = collectRequiredErrors([
                    { key: 'member_id', label: 'Member', value: planForm.member_id },
                    {
                      key: 'workout_program_id',
                      label: 'Program',
                      value: planForm.workout_program_id,
                    },
                    { key: 'start_date', label: 'Start date', value: planForm.start_date },
                  ])
                  if (Object.keys(errors).length > 0) {
                    setFieldErrors(errors)
                    return
                  }
                  setFieldErrors({})
                  assignPlanMutation.mutate({
                    member_id: Number(planForm.member_id),
                    workout_program_id: Number(planForm.workout_program_id),
                    trainer_id: planForm.trainer_id ? Number(planForm.trainer_id) : null,
                    start_date: planForm.start_date,
                    end_date: planForm.end_date || null,
                  })
                }}
                noValidate
                className="grid gap-3 sm:grid-cols-2"
              >
                <div className="sm:col-span-2">
                  <Label>Find member</Label>
                  <div className="flex gap-2">
                    <Input
                      value={planMemberSearch}
                      onChange={(e) => setPlanMemberSearch(e.target.value)}
                      placeholder="Name or code…"
                    />
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => setAppliedPlanMemberSearch(planMemberSearch.trim())}
                    >
                      <Search className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <Field label="Member" required error={fieldErrors.member_id}>
                  <Select
                    value={planForm.member_id === '' ? '' : String(planForm.member_id)}
                    onChange={(e) => {
                      setPlanForm((f) => ({
                        ...f,
                        member_id: e.target.value ? Number(e.target.value) : '',
                      }))
                      clearFieldError('member_id')
                    }}
                    aria-invalid={Boolean(fieldErrors.member_id)}
                  >
                    <option value="">Select…</option>
                    {(planMembersQuery.data?.data ?? []).map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.full_name} ({m.member_code})
                      </option>
                    ))}
                  </Select>
                </Field>
                <Field label="Program" required error={fieldErrors.workout_program_id}>
                  <Select
                    value={
                      planForm.workout_program_id === ''
                        ? ''
                        : String(planForm.workout_program_id)
                    }
                    onChange={(e) => {
                      setPlanForm((f) => ({
                        ...f,
                        workout_program_id: e.target.value ? Number(e.target.value) : '',
                      }))
                      clearFieldError('workout_program_id')
                    }}
                    aria-invalid={Boolean(fieldErrors.workout_program_id)}
                  >
                    <option value="">Select…</option>
                    {programs.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </Select>
                </Field>
                <div>
                  <Label>Trainer (optional)</Label>
                  <Select
                    value={planForm.trainer_id === '' ? '' : String(planForm.trainer_id)}
                    onChange={(e) =>
                      setPlanForm((f) => ({
                        ...f,
                        trainer_id: e.target.value ? Number(e.target.value) : '',
                      }))
                    }
                  >
                    <option value="">None</option>
                    {trainers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {trainerLabel(t)}
                      </option>
                    ))}
                  </Select>
                </div>
                <Field label="Start date" required error={fieldErrors.start_date}>
                  <Input
                    type="date"
                    value={planForm.start_date}
                    onChange={(e) => {
                      setPlanForm((f) => ({ ...f, start_date: e.target.value }))
                      clearFieldError('start_date')
                    }}
                    aria-invalid={Boolean(fieldErrors.start_date)}
                  />
                </Field>
                <div>
                  <Label>End date (optional)</Label>
                  <Input
                    type="date"
                    value={planForm.end_date}
                    onChange={(e) =>
                      setPlanForm((f) => ({ ...f, end_date: e.target.value }))
                    }
                  />
                </div>
                <div className="flex gap-2 sm:col-span-2">
                  <Button type="submit" loading={assignPlanMutation.isPending}>
                    Assign plan
                  </Button>
                  <Button type="button" variant="ghost" onClick={() => setShowAssignPlan(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          <Card>
            <div className="flex flex-wrap gap-2">
              {(
                [
                  { value: '' as const, label: 'All' },
                  { value: 'active' as const, label: 'Active' },
                  { value: 'completed' as const, label: 'Completed' },
                  { value: 'cancelled' as const, label: 'Cancelled' },
                ] as const
              ).map((filter) => (
                <button
                  key={filter.label}
                  type="button"
                  onClick={() => {
                    setPlanStatus(filter.value)
                    setPlanPage(1)
                  }}
                  className={cn(
                    'rounded-xl px-3 py-2 text-sm font-semibold transition',
                    planStatus === filter.value
                      ? 'bg-accent text-accent-ink'
                      : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                  )}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </Card>

          {plansQuery.isPending ? (
            <div className="flex justify-center py-20">
              <Spinner label="Loading assignments…" />
            </div>
          ) : (
            <>
              <DataTable
                columns={planColumns}
                rows={plansQuery.data?.data ?? []}
                rowKey={(row) => row.id}
                emptyTitle="No plan assignments"
                emptyDescription="Assign a program to a member to get started."
              />
              <Pagination meta={plansQuery.data?.meta} onPageChange={setPlanPage} />
            </>
          )}
        </>
      ) : null}

      {tab === 'trainers' ? (
        <>
          {showCreateTrainer && canManage ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Add trainer</CardTitle>
                  <CardDescription>
                    Link an active staff user as a personal trainer profile.
                  </CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setShowCreateTrainer(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              {!canStaff ? (
                <Alert tone="danger">
                  You need staff view permission to pick a staff user for a trainer profile.
                </Alert>
              ) : (
                <form
                  onSubmit={(e) => {
                    e.preventDefault()
                    const errors = collectRequiredErrors([
                      { key: 'user_id', label: 'Staff user', value: trainerForm.user_id },
                    ])
                    if (Object.keys(errors).length > 0) {
                      setFieldErrors(errors)
                      return
                    }
                    setFieldErrors({})
                    createTrainerMutation.mutate({
                      user_id: Number(trainerForm.user_id),
                      specialty: trainerForm.specialty.trim() || null,
                      bio: trainerForm.bio.trim() || null,
                      is_active: trainerForm.is_active,
                    })
                  }}
                  noValidate
                  className="grid gap-3 sm:grid-cols-2"
                >
                  <Field
                    label="Staff user"
                    required
                    error={fieldErrors.user_id}
                    className="sm:col-span-2"
                  >
                    <Select
                      value={trainerForm.user_id === '' ? '' : String(trainerForm.user_id)}
                      onChange={(e) => {
                        setTrainerForm((f) => ({
                          ...f,
                          user_id: e.target.value ? Number(e.target.value) : '',
                        }))
                        clearFieldError('user_id')
                      }}
                      aria-invalid={Boolean(fieldErrors.user_id)}
                    >
                      <option value="">Select staff…</option>
                      {(staffQuery.data?.data ?? []).map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name} ({s.email})
                        </option>
                      ))}
                    </Select>
                  </Field>
                  <div>
                    <Label>Specialty</Label>
                    <Input
                      value={trainerForm.specialty}
                      onChange={(e) =>
                        setTrainerForm((f) => ({ ...f, specialty: e.target.value }))
                      }
                      placeholder="Strength, mobility…"
                    />
                  </div>
                  <div className="flex items-end">
                    <label className="flex items-center gap-2 pb-2 text-sm text-ink">
                      <input
                        type="checkbox"
                        checked={trainerForm.is_active}
                        onChange={(e) =>
                          setTrainerForm((f) => ({ ...f, is_active: e.target.checked }))
                        }
                      />
                      Active
                    </label>
                  </div>
                  <div className="sm:col-span-2">
                    <Label>Bio</Label>
                    <Textarea
                      value={trainerForm.bio}
                      onChange={(e) =>
                        setTrainerForm((f) => ({ ...f, bio: e.target.value }))
                      }
                      rows={2}
                    />
                  </div>
                  <div className="flex gap-2 sm:col-span-2">
                    <Button type="submit" loading={createTrainerMutation.isPending}>
                      Create trainer
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      onClick={() => setShowCreateTrainer(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              )}
            </Card>
          ) : null}

          <Card>
            <div className="flex flex-wrap gap-2">
              {(
                [
                  { value: '' as const, label: 'All' },
                  { value: 'active' as const, label: 'Active' },
                  { value: 'inactive' as const, label: 'Inactive' },
                ] as const
              ).map((filter) => (
                <button
                  key={filter.label}
                  type="button"
                  onClick={() => {
                    setTrainerActive(filter.value)
                    setTrainerPage(1)
                  }}
                  className={cn(
                    'rounded-xl px-3 py-2 text-sm font-semibold transition',
                    trainerActive === filter.value
                      ? 'bg-accent text-accent-ink'
                      : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                  )}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </Card>

          <div
            className={cn(
              'grid gap-4',
              selectedTrainerId != null ? 'xl:grid-cols-[1fr_26rem]' : '',
            )}
          >
            <div className="min-w-0">
              {trainersQuery.isPending ? (
                <div className="flex justify-center py-20">
                  <Spinner label="Loading trainers…" />
                </div>
              ) : (
                <>
                  <DataTable
                    columns={trainerColumns}
                    rows={trainersQuery.data?.data ?? []}
                    rowKey={(row) => row.id}
                    emptyTitle="No trainers"
                    emptyDescription="Add a trainer profile from an active staff user."
                  />
                  <Pagination
                    meta={trainersQuery.data?.meta}
                    onPageChange={(p) => {
                      setTrainerPage(p)
                      setSelectedTrainerId(null)
                    }}
                  />
                </>
              )}
            </div>

            {selectedTrainer ? (
              <aside className="animate-slide-in">
                <Card className="sticky top-4 space-y-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                        <UserRound className="h-5 w-5" />
                      </div>
                      <CardTitle className="text-base">
                        {selectedTrainer.user?.name ?? `Trainer #${selectedTrainer.id}`}
                      </CardTitle>
                      <CardDescription>
                        {selectedTrainer.specialty || selectedTrainer.user?.email || '—'}
                      </CardDescription>
                    </div>
                    <Button size="sm" variant="ghost" onClick={() => setSelectedTrainerId(null)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                  <Badge tone={selectedTrainer.is_active ? 'success' : 'danger'}>
                    {selectedTrainer.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                  {selectedTrainer.bio ? (
                    <p className="text-sm text-muted">{selectedTrainer.bio}</p>
                  ) : null}

                  {canManage ? (
                    <div className="flex flex-wrap gap-2 border-t border-white/12 pt-4">
                      <Button
                        size="sm"
                        variant="secondary"
                        loading={toggleTrainerMutation.isPending}
                        onClick={() =>
                          toggleTrainerMutation.mutate({
                            id: selectedTrainer.id,
                            is_active: !selectedTrainer.is_active,
                          })
                        }
                      >
                        {selectedTrainer.is_active ? 'Deactivate' : 'Activate'}
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-danger"
                        loading={deleteTrainerMutation.isPending}
                        onClick={() => void onDeleteTrainer(selectedTrainer)}
                      >
                        <Trash2 className="h-4 w-4" />
                        Delete
                      </Button>
                    </div>
                  ) : null}

                  <div className="space-y-3 border-t border-white/12 pt-4">
                    <p className="text-sm font-semibold text-ink">Assigned members</p>
                    {trainerMembersQuery.isPending ? (
                      <Spinner label="Loading…" />
                    ) : (trainerMembersQuery.data ?? []).length === 0 ? (
                      <p className="text-sm text-muted">No members assigned.</p>
                    ) : (
                      <div className="max-h-40 space-y-2 overflow-y-auto">
                        {(trainerMembersQuery.data ?? []).map((link) => (
                          <div
                            key={link.id}
                            className="flex items-center justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2"
                          >
                            <span className="truncate text-sm text-ink">
                              {memberLabel(link.member)}
                            </span>
                            {canManage ? (
                              <Button
                                size="sm"
                                variant="ghost"
                                loading={unassignMemberMutation.isPending}
                                onClick={() => unassignMemberMutation.mutate(link.member_id)}
                              >
                                Remove
                              </Button>
                            ) : null}
                          </div>
                        ))}
                      </div>
                    )}

                    {canManage ? (
                      <div className="space-y-2">
                        <Label>Assign member</Label>
                        <div className="flex gap-2">
                          <Input
                            value={assignMemberSearch}
                            onChange={(e) => setAssignMemberSearch(e.target.value)}
                            placeholder="Search…"
                          />
                          <Button
                            type="button"
                            size="sm"
                            variant="secondary"
                            onClick={() =>
                              setAppliedAssignMemberSearch(assignMemberSearch.trim())
                            }
                          >
                            <Search className="h-4 w-4" />
                          </Button>
                        </div>
                        <Select
                          value={assignMemberId === '' ? '' : String(assignMemberId)}
                          onChange={(e) =>
                            setAssignMemberId(e.target.value ? Number(e.target.value) : '')
                          }
                        >
                          <option value="">Select member…</option>
                          {(assignMembersQuery.data?.data ?? []).map((m) => (
                            <option key={m.id} value={m.id}>
                              {m.full_name} ({m.member_code})
                            </option>
                          ))}
                        </Select>
                        <Button
                          size="sm"
                          disabled={!assignMemberId}
                          loading={assignMemberMutation.isPending}
                          onClick={() => assignMemberMutation.mutate()}
                        >
                          Assign
                        </Button>
                      </div>
                    ) : null}
                  </div>
                </Card>
              </aside>
            ) : null}
          </div>
        </>
      ) : null}
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="shrink-0 text-muted">{label}</dt>
      <dd className="text-right font-semibold text-ink">{value}</dd>
    </div>
  )
}
