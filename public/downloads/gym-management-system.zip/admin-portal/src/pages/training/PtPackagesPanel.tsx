import { useState, type FormEvent } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Package, Plus, X } from 'lucide-react'
import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { formatMoney, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { fetchMembers } from '@/api/members'
import { fetchTrainers } from '@/api/training'

type PtPackage = {
  id: number
  name: string
  code?: string | null
  sessions_count: number
  price: string | number
  currency_code: string
  validity_days?: number | null
  is_active: boolean
}

type MemberPtPackage = {
  id: number
  status: string
  sessions_total: number
  sessions_remaining: number
  starts_on?: string | null
  ends_on?: string | null
  package?: PtPackage | null
  member?: { id: number; first_name?: string; last_name?: string; member_code?: string; full_name?: string }
  trainer?: { id: number; user?: { name?: string } | null } | null
}

async function fetchPtPackages() {
  const { data } = await api.get<ApiSuccess<PtPackage[]> & { meta: PaginationMeta }>(
    '/admin/pt-packages',
    { params: { per_page: 50, is_active: true } },
  )
  return data
}

async function fetchMemberPtPackages() {
  const { data } = await api.get<ApiSuccess<MemberPtPackage[]> & { meta: PaginationMeta }>(
    '/admin/member-pt-packages',
    { params: { per_page: DEFAULT_PAGE_SIZE } },
  )
  return data
}

export function PtPackagesPanel() {
  const { hasPermission } = useAuth()
  const { showSuccess } = useFeedback()
  const queryClient = useQueryClient()
  const canManage = hasPermission('training.manage')
  const [error, setError] = useState<string | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  const [showAssign, setShowAssign] = useState(false)
  const [form, setForm] = useState({
    name: '',
    sessions_count: 10,
    price: 0,
    validity_days: 90,
  })
  const [assign, setAssign] = useState({
    member_id: '' as number | '',
    pt_package_id: '' as number | '',
    trainer_id: '' as number | '',
  })

  const packagesQuery = useQuery({
    queryKey: ['admin', 'pt-packages'],
    queryFn: fetchPtPackages,
  })
  const assignmentsQuery = useQuery({
    queryKey: ['admin', 'member-pt-packages'],
    queryFn: fetchMemberPtPackages,
  })
  const membersQuery = useQuery({
    queryKey: ['admin', 'members', 'pt-assign'],
    queryFn: () => fetchMembers({ per_page: 100, status: 'active' }),
    enabled: showAssign,
  })
  const trainersQuery = useQuery({
    queryKey: ['admin', 'trainers', 'pt-assign'],
    queryFn: () => fetchTrainers({ per_page: 100 }),
    enabled: showAssign,
  })

  const createMutation = useMutation({
    mutationFn: async () => {
      const { data } = await api.post<ApiSuccess<PtPackage>>('/admin/pt-packages', {
        name: form.name,
        sessions_count: Number(form.sessions_count),
        price: Number(form.price),
        validity_days: Number(form.validity_days) || null,
        is_active: true,
      })
      return data.data
    },
    onSuccess: async () => {
      setError(null)
      showSuccess('PT package created.')
      setShowCreate(false)
      setForm({ name: '', sessions_count: 10, price: 0, validity_days: 90 })
      await queryClient.invalidateQueries({ queryKey: ['admin', 'pt-packages'] })
    },
    onError: (err) => setError(err instanceof ApiError ? err.message : 'Unable to create package.'),
  })

  const assignMutation = useMutation({
    mutationFn: async () => {
      const { data } = await api.post<ApiSuccess<MemberPtPackage>>('/admin/member-pt-packages', {
        member_id: Number(assign.member_id),
        pt_package_id: Number(assign.pt_package_id),
        trainer_id: assign.trainer_id === '' ? null : Number(assign.trainer_id),
      })
      return data.data
    },
    onSuccess: async () => {
      setError(null)
      showSuccess('PT package assigned to member.')
      setShowAssign(false)
      await queryClient.invalidateQueries({ queryKey: ['admin', 'member-pt-packages'] })
    },
    onError: (err) => setError(err instanceof ApiError ? err.message : 'Unable to assign package.'),
  })

  const packageColumns: Column<PtPackage>[] = [
    { key: 'name', header: 'Package', cell: (r) => <span className="font-medium">{r.name}</span> },
    {
      key: 'sessions',
      header: 'Sessions',
      cell: (r) => formatNumber(r.sessions_count),
    },
    {
      key: 'price',
      header: 'Price',
      cell: (r) => formatMoney(r.price, r.currency_code),
    },
    {
      key: 'validity',
      header: 'Validity',
      cell: (r) => (r.validity_days ? `${r.validity_days} days` : '—'),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (r) => <Badge tone={r.is_active ? 'success' : 'neutral'}>{r.is_active ? 'Active' : 'Off'}</Badge>,
    },
  ]

  const assignmentColumns: Column<MemberPtPackage>[] = [
    {
      key: 'member',
      header: 'Member',
      cell: (r) =>
        r.member?.full_name ||
        `${r.member?.first_name ?? ''} ${r.member?.last_name ?? ''}`.trim() ||
        r.member?.member_code ||
        '—',
    },
    { key: 'package', header: 'Package', cell: (r) => r.package?.name ?? '—' },
    {
      key: 'credits',
      header: 'Credits',
      cell: (r) => `${r.sessions_remaining}/${r.sessions_total}`,
    },
    {
      key: 'status',
      header: 'Status',
      cell: (r) => <Badge tone={r.status === 'active' ? 'success' : 'warning'}>{r.status}</Badge>,
    },
  ]

  return (
    <div className="space-y-4">
      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="flex flex-wrap gap-2">
        {canManage ? (
          <>
            <Button type="button" onClick={() => setShowCreate(true)}>
              <Plus className="mr-1.5 h-4 w-4" /> New package
            </Button>
            <Button type="button" variant="secondary" onClick={() => setShowAssign(true)}>
              Assign to member
            </Button>
          </>
        ) : null}
      </div>

      {showCreate ? (
        <Card>
          <div className="mb-3 flex items-center justify-between">
            <CardTitle>Create PT package</CardTitle>
            <Button type="button" size="sm" variant="ghost" onClick={() => setShowCreate(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form
            className="grid gap-3 sm:grid-cols-2"
            onSubmit={(e: FormEvent) => {
              e.preventDefault()
              createMutation.mutate()
            }}
          >
            <Field label="Name" htmlFor="pkg-name">
              <Input
                id="pkg-name"
                required
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              />
            </Field>
            <Field label="Sessions" htmlFor="pkg-sessions">
              <Input
                id="pkg-sessions"
                type="number"
                min={1}
                required
                value={form.sessions_count}
                onChange={(e) => setForm((f) => ({ ...f, sessions_count: Number(e.target.value) }))}
              />
            </Field>
            <Field label="Price" htmlFor="pkg-price">
              <Input
                id="pkg-price"
                type="number"
                min={0}
                step="0.01"
                required
                value={form.price}
                onChange={(e) => setForm((f) => ({ ...f, price: Number(e.target.value) }))}
              />
            </Field>
            <Field label="Validity (days)" htmlFor="pkg-validity">
              <Input
                id="pkg-validity"
                type="number"
                min={1}
                value={form.validity_days}
                onChange={(e) => setForm((f) => ({ ...f, validity_days: Number(e.target.value) }))}
              />
            </Field>
            <div className="sm:col-span-2">
              <Button type="submit" loading={createMutation.isPending}>
                Save package
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      {showAssign ? (
        <Card>
          <div className="mb-3 flex items-center justify-between">
            <CardTitle>Assign package</CardTitle>
            <Button type="button" size="sm" variant="ghost" onClick={() => setShowAssign(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form
            className="grid gap-3 sm:grid-cols-3"
            onSubmit={(e: FormEvent) => {
              e.preventDefault()
              assignMutation.mutate()
            }}
          >
            <Field label="Member" htmlFor="assign-member">
              <Select
                id="assign-member"
                required
                value={assign.member_id === '' ? '' : String(assign.member_id)}
                onChange={(e) =>
                  setAssign((a) => ({
                    ...a,
                    member_id: e.target.value ? Number(e.target.value) : '',
                  }))
                }
              >
                <option value="">Select member</option>
                {(membersQuery.data?.data ?? []).map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.full_name} ({m.member_code})
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Package" htmlFor="assign-package">
              <Select
                id="assign-package"
                required
                value={assign.pt_package_id === '' ? '' : String(assign.pt_package_id)}
                onChange={(e) =>
                  setAssign((a) => ({
                    ...a,
                    pt_package_id: e.target.value ? Number(e.target.value) : '',
                  }))
                }
              >
                <option value="">Select package</option>
                {(packagesQuery.data?.data ?? []).map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.sessions_count} sessions)
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Trainer (optional)" htmlFor="assign-trainer">
              <Select
                id="assign-trainer"
                value={assign.trainer_id === '' ? '' : String(assign.trainer_id)}
                onChange={(e) =>
                  setAssign((a) => ({
                    ...a,
                    trainer_id: e.target.value ? Number(e.target.value) : '',
                  }))
                }
              >
                <option value="">Any trainer</option>
                {(trainersQuery.data?.data ?? []).map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.user?.name ?? `Trainer #${t.id}`}
                  </option>
                ))}
              </Select>
            </Field>
            <div className="sm:col-span-3">
              <Button type="submit" loading={assignMutation.isPending}>
                Assign credits
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-2">
        <Card>
          <CardTitle className="mb-1 flex items-center gap-2">
            <Package className="h-4 w-4" /> Sellable packages
          </CardTitle>
          <CardDescription className="mb-4">Session packs with credit balances</CardDescription>
          {packagesQuery.isLoading ? (
            <Spinner label="Loading packages…" />
          ) : (
            <DataTable
              columns={packageColumns}
              rows={packagesQuery.data?.data ?? []}
              rowKey={(r) => r.id}
              emptyTitle="No PT packages"
              emptyDescription="Create a package of personal training credits."
            />
          )}
        </Card>
        <Card>
          <CardTitle className="mb-1">Assigned credits</CardTitle>
          <CardDescription className="mb-4">
            Completing a PT session automatically consumes one credit
          </CardDescription>
          {assignmentsQuery.isLoading ? (
            <Spinner label="Loading assignments…" />
          ) : (
            <DataTable
              columns={assignmentColumns}
              rows={assignmentsQuery.data?.data ?? []}
              rowKey={(r) => r.id}
              emptyTitle="No assignments"
              emptyDescription="Assign a package to a member to start tracking credits."
            />
          )}
        </Card>
      </div>
    </div>
  )
}
