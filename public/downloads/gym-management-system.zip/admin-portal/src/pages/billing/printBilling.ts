import type { Invoice, Payment } from '@/api/billing'
import { formatDate, formatMoney } from '@/lib/format'

function escapeHtml(value: string | number | null | undefined): string {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

function memberName(member?: Invoice['member'] | null) {
  if (!member) return 'Walk-in / Unassigned'
  const name = `${member.first_name ?? ''} ${member.last_name ?? ''}`.trim()
  return name || member.member_code || 'Member'
}

function methodLabel(method: string) {
  switch (method) {
    case 'cash':
      return 'Cash'
    case 'card':
      return 'Card'
    case 'upi':
      return 'UPI'
    case 'bank_transfer':
      return 'Bank transfer'
    case 'other':
      return 'Other'
    default:
      return method
  }
}

function statusLabel(status: string) {
  return status.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())
}

function openPrintWindow(html: string, title: string) {
  const blob = new Blob([html], { type: 'text/html;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const popup = window.open(url, '_blank', 'noopener,noreferrer,width=900,height=1100')
  if (!popup) {
    const frame = document.createElement('iframe')
    frame.title = title
    frame.style.position = 'fixed'
    frame.style.right = '0'
    frame.style.bottom = '0'
    frame.style.width = '0'
    frame.style.height = '0'
    frame.style.border = '0'
    document.body.appendChild(frame)
    frame.srcdoc = html
    frame.onload = () => {
      frame.contentWindow?.focus()
      frame.contentWindow?.print()
      setTimeout(() => {
        document.body.removeChild(frame)
        URL.revokeObjectURL(url)
      }, 1000)
    }
  } else {
    setTimeout(() => URL.revokeObjectURL(url), 60_000)
  }
}

const documentStyles = `
  @page { margin: 14mm; size: A4; }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    padding: 28px 32px;
    font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif;
    color: #152033;
    background: #fff;
    font-size: 13px;
    line-height: 1.45;
  }
  .sheet { max-width: 780px; margin: 0 auto; }
  .top {
    display: flex;
    justify-content: space-between;
    gap: 24px;
    align-items: flex-start;
    border-bottom: 2px solid #152033;
    padding-bottom: 18px;
    margin-bottom: 22px;
  }
  .brand-name {
    font-family: Georgia, "Times New Roman", serif;
    font-size: 26px;
    font-weight: 700;
    letter-spacing: -0.02em;
    margin: 0 0 4px;
  }
  .brand-sub { color: #5b6578; font-size: 12px; margin: 0; }
  .doc-type {
    text-align: right;
  }
  .doc-type h2 {
    margin: 0;
    font-size: 22px;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: #1f4e79;
  }
  .doc-type .num {
    margin-top: 6px;
    font-size: 14px;
    font-weight: 700;
  }
  .meta-grid {
    display: grid;
    grid-template-columns: 1.2fr 1fr;
    gap: 18px;
    margin-bottom: 22px;
  }
  .box {
    border: 1px solid #d7dde8;
    border-radius: 8px;
    padding: 14px 16px;
    background: #f8fafc;
  }
  .box h3 {
    margin: 0 0 8px;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: #5b6578;
  }
  .box p { margin: 0 0 4px; }
  .box .strong { font-weight: 700; font-size: 14px; }
  table {
    width: 100%;
    border-collapse: collapse;
    margin: 8px 0 18px;
  }
  th, td {
    padding: 10px 12px;
    border-bottom: 1px solid #e4e9f2;
    text-align: left;
    vertical-align: top;
  }
  th {
    background: #eef3f8;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: #3d4a5f;
  }
  td.num, th.num { text-align: right; white-space: nowrap; }
  .totals {
    width: 280px;
    margin-left: auto;
    border: 1px solid #d7dde8;
    border-radius: 8px;
    overflow: hidden;
  }
  .totals .row {
    display: flex;
    justify-content: space-between;
    padding: 8px 14px;
    border-bottom: 1px solid #e8edf5;
  }
  .totals .row:last-child { border-bottom: 0; }
  .totals .grand {
    background: #1f4e79;
    color: #fff;
    font-weight: 700;
    font-size: 15px;
  }
  .notes {
    margin-top: 22px;
    padding-top: 14px;
    border-top: 1px dashed #c9d2e0;
  }
  .notes h3 {
    margin: 0 0 6px;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: #5b6578;
  }
  .footer {
    margin-top: 28px;
    font-size: 11px;
    color: #6b7587;
    display: flex;
    justify-content: space-between;
    gap: 12px;
  }
  .badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 600;
    background: #e8f0f8;
    color: #1f4e79;
  }
  .amount-hero {
    text-align: center;
    padding: 22px;
    margin: 8px 0 20px;
    border: 1px solid #d7dde8;
    border-radius: 10px;
    background: linear-gradient(180deg, #f4f8fc 0%, #ffffff 100%);
  }
  .amount-hero .label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: #5b6578;
  }
  .amount-hero .value {
    margin-top: 6px;
    font-size: 32px;
    font-weight: 700;
    color: #1f4e79;
    letter-spacing: -0.02em;
  }
`

export function printInvoiceDocument(
  invoice: Invoice,
  opts: { gymName: string; gymSlug?: string | null },
) {
  const currency = invoice.currency_code || 'INR'
  const rows = (invoice.items ?? [])
    .map(
      (item) => `
      <tr>
        <td>${escapeHtml(item.description)}</td>
        <td class="num">${escapeHtml(item.quantity)}</td>
        <td class="num">${escapeHtml(formatMoney(item.unit_price, currency))}</td>
        <td class="num">${escapeHtml(formatMoney(item.discount_amount, currency))}</td>
        <td class="num">${item.tax_rate_percent != null ? `${escapeHtml(item.tax_rate_percent)}%` : '—'}</td>
        <td class="num">${escapeHtml(formatMoney(item.line_total, currency))}</td>
      </tr>`,
    )
    .join('')

  const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Invoice ${escapeHtml(invoice.invoice_number)}</title>
  <style>${documentStyles}</style>
</head>
<body>
  <div class="sheet">
    <div class="top">
      <div>
        <p class="brand-name">${escapeHtml(opts.gymName)}</p>
        <p class="brand-sub">${opts.gymSlug ? escapeHtml(opts.gymSlug) : 'Gym management'} · Tax invoice</p>
      </div>
      <div class="doc-type">
        <h2>Invoice</h2>
        <div class="num">${escapeHtml(invoice.invoice_number)}</div>
        <div style="margin-top:8px"><span class="badge">${escapeHtml(statusLabel(invoice.status))}</span></div>
      </div>
    </div>

    <div class="meta-grid">
      <div class="box">
        <h3>Bill to</h3>
        <p class="strong">${escapeHtml(memberName(invoice.member))}</p>
        ${
          invoice.member?.member_code
            ? `<p>Member ID: ${escapeHtml(invoice.member.member_code)}</p>`
            : ''
        }
        ${
          invoice.branch
            ? `<p>Branch: ${escapeHtml(invoice.branch.name)} (${escapeHtml(invoice.branch.code)})</p>`
            : ''
        }
      </div>
      <div class="box">
        <h3>Invoice details</h3>
        <p>Issue date: <strong>${escapeHtml(formatDate(invoice.issue_date))}</strong></p>
        <p>Due date: <strong>${escapeHtml(formatDate(invoice.due_date))}</strong></p>
        <p>Currency: <strong>${escapeHtml(currency)}</strong></p>
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th>Description</th>
          <th class="num">Qty</th>
          <th class="num">Unit</th>
          <th class="num">Discount</th>
          <th class="num">Tax</th>
          <th class="num">Amount</th>
        </tr>
      </thead>
      <tbody>
        ${rows || `<tr><td colspan="6">No line items</td></tr>`}
      </tbody>
    </table>

    <div class="totals">
      <div class="row"><span>Subtotal</span><span>${escapeHtml(formatMoney(invoice.subtotal, currency))}</span></div>
      <div class="row"><span>Discount</span><span>${escapeHtml(formatMoney(invoice.discount_total, currency))}</span></div>
      <div class="row"><span>Tax</span><span>${escapeHtml(formatMoney(invoice.tax_total, currency))}</span></div>
      <div class="row"><span>Amount paid</span><span>${escapeHtml(formatMoney(invoice.amount_paid, currency))}</span></div>
      <div class="row grand"><span>Balance due</span><span>${escapeHtml(formatMoney(invoice.balance_due, currency))}</span></div>
      <div class="row" style="font-weight:700"><span>Grand total</span><span>${escapeHtml(formatMoney(invoice.grand_total, currency))}</span></div>
    </div>

    ${
      invoice.notes
        ? `<div class="notes"><h3>Notes</h3><p>${escapeHtml(invoice.notes)}</p></div>`
        : ''
    }

    <div class="footer">
      <span>Generated ${escapeHtml(formatDate(new Date().toISOString()))}</span>
      <span>Thank you for your business</span>
    </div>
  </div>
  <script>window.onload = function () { window.print(); }</script>
</body>
</html>`

  openPrintWindow(html, `Invoice ${invoice.invoice_number}`)
}

export function printPaymentReceipt(
  payment: Payment,
  opts: { gymName: string; gymSlug?: string | null },
) {
  const currency = payment.currency_code || 'INR'
  const allocRows = (payment.allocations ?? [])
    .map(
      (a) => `
      <tr>
        <td>${escapeHtml(a.invoice?.invoice_number ?? `#${a.invoice_id}`)}</td>
        <td>${escapeHtml(a.invoice?.status ? statusLabel(a.invoice.status) : '—')}</td>
        <td class="num">${escapeHtml(formatMoney(a.amount, currency))}</td>
      </tr>`,
    )
    .join('')

  const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Receipt ${escapeHtml(payment.payment_number)}</title>
  <style>${documentStyles}</style>
</head>
<body>
  <div class="sheet">
    <div class="top">
      <div>
        <p class="brand-name">${escapeHtml(opts.gymName)}</p>
        <p class="brand-sub">${opts.gymSlug ? escapeHtml(opts.gymSlug) : 'Gym management'} · Payment receipt</p>
      </div>
      <div class="doc-type">
        <h2>Receipt</h2>
        <div class="num">${escapeHtml(payment.payment_number)}</div>
        <div style="margin-top:8px"><span class="badge">${escapeHtml(statusLabel(payment.status))}</span></div>
      </div>
    </div>

    <div class="amount-hero">
      <div class="label">Amount received</div>
      <div class="value">${escapeHtml(formatMoney(payment.amount, currency))}</div>
    </div>

    <div class="meta-grid">
      <div class="box">
        <h3>Received from</h3>
        <p class="strong">${escapeHtml(memberName(payment.member))}</p>
        ${
          payment.member?.member_code
            ? `<p>Member ID: ${escapeHtml(payment.member.member_code)}</p>`
            : ''
        }
      </div>
      <div class="box">
        <h3>Payment details</h3>
        <p>Date: <strong>${escapeHtml(formatDate(payment.paid_at))}</strong></p>
        <p>Method: <strong>${escapeHtml(methodLabel(payment.method))}</strong></p>
        ${
          payment.reference
            ? `<p>Reference: <strong>${escapeHtml(payment.reference)}</strong></p>`
            : ''
        }
      </div>
    </div>

    <h3 style="margin:0 0 8px;font-size:11px;text-transform:uppercase;letter-spacing:0.06em;color:#5b6578">
      Applied to invoices
    </h3>
    <table>
      <thead>
        <tr>
          <th>Invoice</th>
          <th>Status</th>
          <th class="num">Allocated</th>
        </tr>
      </thead>
      <tbody>
        ${allocRows || `<tr><td colspan="3">No allocations</td></tr>`}
      </tbody>
    </table>

    ${
      payment.notes
        ? `<div class="notes"><h3>Notes</h3><p>${escapeHtml(payment.notes)}</p></div>`
        : ''
    }

    <div class="footer">
      <span>Generated ${escapeHtml(formatDate(new Date().toISOString()))}</span>
      <span>This is a computer-generated receipt</span>
    </div>
  </div>
  <script>window.onload = function () { window.print(); }</script>
</body>
</html>`

  openPrintWindow(html, `Receipt ${payment.payment_number}`)
}
