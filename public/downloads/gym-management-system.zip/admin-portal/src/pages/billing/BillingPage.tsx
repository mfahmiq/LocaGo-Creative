import { useEffect, useMemo, useState, type Dispatch, type FormEvent, type ReactNode, type SetStateAction } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Banknote,
  FileText,
  Plus,
  Printer,
  Receipt,
  Search,
  Trash2,
  X,
} from 'lucide-react'
import {
  createInvoice,
  createPayment,
  fetchInvoice,
  fetchInvoices,
  fetchPayment,
  fetchPayments,
  isOpenInvoiceStatus,
  issueInvoice,
  updateInvoice,
  voidInvoice,
  voidPayment,
  type CreateInvoicePayload,
  type Invoice,
  type InvoiceItemPayload,
  type InvoiceStatus,
  type Payment,
  type PaymentMethod,
  type PaymentStatus,
} from '@/api/billing'
import { fetchMembers } from '@/api/members'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useBranchFilter } from '@/hooks/useBranchFilter'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field, FieldError } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatMoney, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { printInvoiceDocument, printPaymentReceipt } from '@/pages/billing/printBilling'

type PageTab = 'invoices' | 'payments'

type LineForm = {
  description: string
  quantity: string
  unit_price: string
  discount_amount: string
  tax_rate_percent: string
}

const emptyLine = (): LineForm => ({
  description: '',
  quantity: '1',
  unit_price: '',
  discount_amount: '0',
  tax_rate_percent: '',
})

function memberLabel(m?: {
  first_name?: string
  last_name?: string
  member_code?: string
  full_name?: string
} | null) {
  if (!m) return '—'
  if (m.full_name) {
    return m.member_code ? `${m.full_name} (${m.member_code})` : m.full_name
  }
  const name = `${m.first_name ?? ''} ${m.last_name ?? ''}`.trim()
  return name ? `${name}${m.member_code ? ` (${m.member_code})` : ''}` : m.member_code || '—'
}

function invoiceStatusTone(
  status: InvoiceStatus,
): 'neutral' | 'accent' | 'warning' | 'success' | 'danger' {
  switch (status) {
    case 'draft':
      return 'neutral'
    case 'issued':
      return 'accent'
    case 'partially_paid':
    case 'overdue':
      return 'warning'
    case 'paid':
      return 'success'
    case 'void':
      return 'danger'
    default:
      return 'neutral'
  }
}

function paymentStatusTone(status: PaymentStatus): 'success' | 'danger' | 'neutral' {
  return status === 'completed' ? 'success' : status === 'reversed' ? 'danger' : 'neutral'
}

function methodLabel(method: PaymentMethod) {
  switch (method) {
    case 'cash':
      return 'Cash'
    case 'card':
      return 'Card'
    case 'upi':
      return 'UPI'
    case 'bank_transfer':
      return 'Bank transfer'
    case 'other':
      return 'Other'
    default:
      return method
  }
}

function statusLabel(status: string) {
  return status.replace(/_/g, ' ')
}

function toNum(value: string | number | null | undefined) {
  const n = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(n) ? n : 0
}

function linesToPayload(lines: LineForm[]): InvoiceItemPayload[] {
  return lines
    .filter((l) => l.description.trim() && l.unit_price !== '')
    .map((l) => ({
      description: l.description.trim(),
      quantity: Math.max(0.01, toNum(l.quantity) || 1),
      unit_price: toNum(l.unit_price),
      discount_amount: toNum(l.discount_amount),
      tax_rate_percent: l.tax_rate_percent === '' ? null : toNum(l.tax_rate_percent),
    }))
}

export function BillingPage() {
  const { branches, branchId, tenant, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canViewInvoices = hasPermission('billing.invoices.view')
  const canCreateInvoices = hasPermission('billing.invoices.create')
  const canVoidInvoices = hasPermission('billing.invoices.void')
  const canViewPayments = hasPermission('billing.payments.view')
  const canRecordPayments = hasPermission('billing.payments.record')
  const canVoidPayments = hasPermission('billing.payments.void')
  const canViewMembers = hasPermission('members.view')
  const canView = canViewInvoices || canViewPayments

  const defaultCurrency = tenant?.base_currency || 'INR'
  const gymName = tenant?.name || 'Gym'
  const gymSlug = tenant?.slug

  const [tab, setTab] = useState<PageTab>('invoices')
  const [error, setError] = useState<string | null>(null)
  const [invoiceFieldErrors, setInvoiceFieldErrors] = useState<FieldErrors>({})
  const [paymentFieldErrors, setPaymentFieldErrors] = useState<FieldErrors>({})

  const clearInvoiceFieldError = (key: string) => {
    setInvoiceFieldErrors((prev) => {
      if (!prev[key]) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  const clearPaymentFieldError = (key: string) => {
    setPaymentFieldErrors((prev) => {
      if (!prev[key]) return prev
      const next = { ...prev }
      delete next[key]
      return next
    })
  }

  useEffect(() => {
    if (!canViewInvoices && canViewPayments) setTab('payments')
    else if (canViewInvoices && !canViewPayments) setTab('invoices')
  }, [canViewInvoices, canViewPayments])

  // Invoices
  const [invPage, setInvPage] = useState(1)
  const [invStatus, setInvStatus] = useState<'' | InvoiceStatus>('')
  const [invBranch, setInvBranch] = useBranchFilter()
  const [invSearch, setInvSearch] = useState('')
  const [appliedInvSearch, setAppliedInvSearch] = useState('')
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<number | null>(null)
  const [showInvoiceForm, setShowInvoiceForm] = useState(false)
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null)
  const [invoiceMemberId, setInvoiceMemberId] = useState<number | ''>('')
  const [invoiceBranchId, setInvoiceBranchId] = useState<number | ''>(branchId ?? '')
  const [invoiceDueDate, setInvoiceDueDate] = useState('')
  const [invoiceNotes, setInvoiceNotes] = useState('')
  const [invoiceIssueNow, setInvoiceIssueNow] = useState(false)
  const [invoiceLines, setInvoiceLines] = useState<LineForm[]>([emptyLine()])
  const [memberSearch, setMemberSearch] = useState('')

  // Payments
  const [payPage, setPayPage] = useState(1)
  const [payStatus, setPayStatus] = useState<'' | PaymentStatus>('')
  const [payMethod, setPayMethod] = useState<'' | PaymentMethod>('')
  const [payBranch, setPayBranch] = useBranchFilter()
  const [paySearch, setPaySearch] = useState('')
  const [appliedPaySearch, setAppliedPaySearch] = useState('')
  const [selectedPaymentId, setSelectedPaymentId] = useState<number | null>(null)
  const [showPaymentForm, setShowPaymentForm] = useState(false)
  const [payMemberId, setPayMemberId] = useState<number | ''>('')
  const [payBranchId, setPayBranchId] = useState<number | ''>(branchId ?? '')

  useEffect(() => {
    setInvoiceBranchId(branchId ?? '')
    setPayBranchId(branchId ?? '')
  }, [branchId])
  const [payAmount, setPayAmount] = useState('')
  const [payMethodForm, setPayMethodForm] = useState<PaymentMethod>('cash')
  const [payReference, setPayReference] = useState('')
  const [payNotes, setPayNotes] = useState('')
  const [payAllocations, setPayAllocations] = useState<
    Array<{ invoice_id: number; amount: string; label: string; balance: number }>
  >([])
  const [payMemberSearch, setPayMemberSearch] = useState('')

  const errMsg = (err: unknown, fallback: string) => {
    if (err instanceof ApiError) return err.message
    if (err instanceof Error && err.message) return err.message
    return fallback
  }

  const invalidateBilling = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ['admin', 'invoices'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'payments'] }),
      queryClient.invalidateQueries({ queryKey: ['admin', 'billing-stats'] }),
    ])
  }

  const statsQuery = useQuery({
    queryKey: ['admin', 'billing-stats'],
    queryFn: async () => {
      const [issued, partial, overdue, drafts, paid, completed, reversed] = await Promise.all([
        canViewInvoices
          ? fetchInvoices({ page: 1, per_page: 1, status: 'issued' })
          : Promise.resolve(null),
        canViewInvoices
          ? fetchInvoices({ page: 1, per_page: 1, status: 'partially_paid' })
          : Promise.resolve(null),
        canViewInvoices
          ? fetchInvoices({ page: 1, per_page: 1, status: 'overdue' })
          : Promise.resolve(null),
        canViewInvoices
          ? fetchInvoices({ page: 1, per_page: 1, status: 'draft' })
          : Promise.resolve(null),
        canViewInvoices
          ? fetchInvoices({ page: 1, per_page: 1, status: 'paid' })
          : Promise.resolve(null),
        canViewPayments
          ? fetchPayments({ page: 1, per_page: 1, status: 'completed' })
          : Promise.resolve(null),
        canViewPayments
          ? fetchPayments({ page: 1, per_page: 1, status: 'reversed' })
          : Promise.resolve(null),
      ])
      return {
        open:
          (issued?.meta.total ?? 0) + (partial?.meta.total ?? 0) + (overdue?.meta.total ?? 0),
        drafts: drafts?.meta.total ?? 0,
        paid: paid?.meta.total ?? 0,
        payments: completed?.meta.total ?? 0,
        reversed: reversed?.meta.total ?? 0,
      }
    },
    enabled: canView,
  })

  const invoicesQuery = useQuery({
    queryKey: [
      'admin',
      'invoices',
      invPage,
      invStatus,
      invBranch,
      appliedInvSearch,
    ],
    queryFn: () =>
      fetchInvoices({
        page: invPage,
        per_page: DEFAULT_PAGE_SIZE,
        status: invStatus,
        branch_id: invBranch,
        search: appliedInvSearch,
      }),
    enabled: canViewInvoices && tab === 'invoices',
  })

  const invoiceDetailQuery = useQuery({
    queryKey: ['admin', 'invoices', selectedInvoiceId],
    queryFn: () => fetchInvoice(selectedInvoiceId!),
    enabled: canViewInvoices && selectedInvoiceId != null && tab === 'invoices',
  })

  const paymentsQuery = useQuery({
    queryKey: [
      'admin',
      'payments',
      payPage,
      payStatus,
      payMethod,
      payBranch,
      appliedPaySearch,
    ],
    queryFn: () =>
      fetchPayments({
        page: payPage,
        per_page: DEFAULT_PAGE_SIZE,
        status: payStatus,
        method: payMethod,
        branch_id: payBranch,
        search: appliedPaySearch,
      }),
    enabled: canViewPayments && tab === 'payments',
  })

  const paymentDetailQuery = useQuery({
    queryKey: ['admin', 'payments', selectedPaymentId],
    queryFn: () => fetchPayment(selectedPaymentId!),
    enabled: canViewPayments && selectedPaymentId != null && tab === 'payments',
  })

  const membersQuery = useQuery({
    queryKey: ['admin', 'members', 'billing-picker', memberSearch || payMemberSearch],
    queryFn: () =>
      fetchMembers({
        page: 1,
        per_page: 20,
        search: memberSearch || payMemberSearch || undefined,
        status: 'active',
      }),
    enabled:
      canViewMembers &&
      (showInvoiceForm || showPaymentForm || memberSearch.length > 0 || payMemberSearch.length > 0),
  })

  const openInvoicesQuery = useQuery({
    queryKey: ['admin', 'invoices', 'open-for-member', payMemberId],
    queryFn: async () => {
      const [issued, partial, overdue] = await Promise.all([
        fetchInvoices({
          page: 1,
          per_page: 50,
          member_id: Number(payMemberId),
          status: 'issued',
        }),
        fetchInvoices({
          page: 1,
          per_page: 50,
          member_id: Number(payMemberId),
          status: 'partially_paid',
        }),
        fetchInvoices({
          page: 1,
          per_page: 50,
          member_id: Number(payMemberId),
          status: 'overdue',
        }),
      ])
      const map = new Map<number, Invoice>()
      for (const inv of [...issued.data, ...partial.data, ...overdue.data]) {
        if (toNum(inv.balance_due) > 0) map.set(inv.id, inv)
      }
      return Array.from(map.values())
    },
    enabled: canViewInvoices && showPaymentForm && payMemberId !== '',
  })

  const saveInvoiceMutation = useMutation({
    mutationFn: async () => {
      const items = linesToPayload(invoiceLines)
      if (editingInvoice) {
        return updateInvoice(editingInvoice.id, {
          due_date: invoiceDueDate || null,
          notes: invoiceNotes || null,
          items,
        })
      }
      const payload: CreateInvoicePayload = {
        member_id: Number(invoiceMemberId),
        branch_id: invoiceBranchId === '' ? null : Number(invoiceBranchId),
        currency_code: defaultCurrency,
        due_date: invoiceDueDate || null,
        notes: invoiceNotes || null,
        issue_now: invoiceIssueNow,
        items,
      }
      return createInvoice(payload)
    },
    onSuccess: async (row) => {
      showSuccess(
        editingInvoice
          ? `Invoice ${row.invoice_number} updated.`
          : `Invoice ${row.invoice_number} created.`,
      )
      setShowInvoiceForm(false)
      setEditingInvoice(null)
      setSelectedInvoiceId(row.id)
      setError(null)
      await invalidateBilling()
    },
    onError: (err) => setError(errMsg(err, 'Could not save invoice.')),
  })

  const issueMutation = useMutation({
    mutationFn: (id: number) => issueInvoice(id),
    onSuccess: async (row) => {
      showSuccess(`Invoice ${row.invoice_number} issued.`)
      await invalidateBilling()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'invoices', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not issue invoice.')),
  })

  const voidInvoiceMutation = useMutation({
    mutationFn: ({ id, reason }: { id: number; reason?: string }) => voidInvoice(id, reason),
    onSuccess: async (row) => {
      showSuccess(`Invoice ${row.invoice_number} voided.`)
      await invalidateBilling()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'invoices', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not void invoice.')),
  })

  const savePaymentMutation = useMutation({
    mutationFn: async () => {
      const allocations = payAllocations
        .map((a) => ({ invoice_id: a.invoice_id, amount: toNum(a.amount) }))
        .filter((a) => a.amount > 0)
      const amount = payAmount !== '' ? toNum(payAmount) : allocations.reduce((s, a) => s + a.amount, 0)
      const allocSum = allocations.reduce((s, a) => s + a.amount, 0)
      if (Math.abs(amount - allocSum) > 0.009) {
        throw new Error(`Allocation total (${allocSum}) must equal payment amount (${amount}).`)
      }
      return createPayment({
        member_id: Number(payMemberId),
        branch_id: payBranchId === '' ? null : Number(payBranchId),
        amount,
        currency_code: defaultCurrency,
        method: payMethodForm,
        reference: payReference || null,
        notes: payNotes || null,
        allocations,
      })
    },
    onSuccess: async (row) => {
      showSuccess(`Payment ${row.payment_number} recorded.`)
      setShowPaymentForm(false)
      setSelectedPaymentId(row.id)
      setTab('payments')
      setError(null)
      await invalidateBilling()
    },
    onError: (err) => setError(errMsg(err, 'Could not record payment.')),
  })

  const voidPaymentMutation = useMutation({
    mutationFn: ({ id, reason }: { id: number; reason?: string }) => voidPayment(id, reason),
    onSuccess: async (row) => {
      showSuccess(`Payment ${row.payment_number} reversed.`)
      await invalidateBilling()
      await queryClient.invalidateQueries({ queryKey: ['admin', 'payments', row.id] })
    },
    onError: (err) => setError(errMsg(err, 'Could not reverse payment.')),
  })

  const openCreateInvoice = () => {
    setEditingInvoice(null)
    setInvoiceMemberId('')
    setInvoiceBranchId(branchId ?? '')
    setInvoiceDueDate('')
    setInvoiceNotes('')
    setInvoiceIssueNow(false)
    setInvoiceLines([emptyLine()])
    setMemberSearch('')
    setShowInvoiceForm(true)
    setSelectedInvoiceId(null)
    setError(null)
    setInvoiceFieldErrors({})
  }

  const openEditInvoice = (inv: Invoice) => {
    setEditingInvoice(inv)
    setInvoiceMemberId(inv.member_id ?? '')
    setInvoiceBranchId(inv.branch_id ?? '')
    setInvoiceDueDate(inv.due_date?.slice(0, 10) ?? '')
    setInvoiceNotes(inv.notes ?? '')
    setInvoiceIssueNow(false)
    const lines = (inv.items ?? []).map((item) => ({
      description: item.description,
      quantity: String(item.quantity),
      unit_price: String(item.unit_price),
      discount_amount: String(item.discount_amount ?? 0),
      tax_rate_percent: item.tax_rate_percent == null ? '' : String(item.tax_rate_percent),
    }))
    setInvoiceLines(lines.length > 0 ? lines : [emptyLine()])
    setShowInvoiceForm(true)
    setError(null)
    setInvoiceFieldErrors({})
  }

  const openRecordPayment = (prefill?: Invoice) => {
    setShowPaymentForm(true)
    setSelectedPaymentId(null)
    setPayMemberSearch('')
    setPayReference('')
    setPayNotes('')
    setPayMethodForm('cash')
    setPayBranchId(prefill?.branch_id ?? branchId ?? '')
    if (prefill?.member_id) {
      setPayMemberId(prefill.member_id)
      const balance = toNum(prefill.balance_due)
      setPayAmount(String(balance))
      setPayAllocations([
        {
          invoice_id: prefill.id,
          amount: String(balance),
          label: prefill.invoice_number,
          balance,
        },
      ])
    } else {
      setPayMemberId('')
      setPayAmount('')
      setPayAllocations([])
    }
    setError(null)
    setPaymentFieldErrors({})
  }

  useEffect(() => {
    if (!showPaymentForm || !payMemberId || !openInvoicesQuery.data) return
    if (payAllocations.length > 0) return
    const open = openInvoicesQuery.data
    if (open.length === 0) return
    setPayAllocations(
      open.map((inv) => ({
        invoice_id: inv.id,
        amount: '',
        label: inv.invoice_number,
        balance: toNum(inv.balance_due),
      })),
    )
  }, [showPaymentForm, payMemberId, openInvoicesQuery.data, payAllocations.length])

  const onSaveInvoice = (e: FormEvent) => {
    e.preventDefault()
    const errors: FieldErrors = {}
    if (!editingInvoice) {
      Object.assign(
        errors,
        collectRequiredErrors([
          { key: 'member_id', label: 'Member', value: invoiceMemberId },
        ]),
      )
    }
    const items = linesToPayload(invoiceLines)
    if (items.length === 0) {
      errors.line_items = 'Add at least one line item with description and unit price.'
      invoiceLines.forEach((line, idx) => {
        Object.assign(
          errors,
          collectRequiredErrors([
            {
              key: `line_${idx}_description`,
              label: 'Description',
              value: line.description,
            },
            {
              key: `line_${idx}_unit_price`,
              label: 'Unit price',
              value: line.unit_price,
            },
          ]),
        )
      })
    }
    if (Object.keys(errors).length > 0) {
      setInvoiceFieldErrors(errors)
      return
    }
    setInvoiceFieldErrors({})
    saveInvoiceMutation.mutate()
  }

  const onSavePayment = (e: FormEvent) => {
    e.preventDefault()
    const errors = collectRequiredErrors([
      { key: 'member_id', label: 'Member', value: payMemberId },
      { key: 'amount', label: 'Amount', value: payAmount },
    ])
    const allocations = payAllocations
      .map((a) => ({ invoice_id: a.invoice_id, amount: toNum(a.amount) }))
      .filter((a) => a.amount > 0)
    if (payAllocations.length === 0) {
      errors.allocations = 'Allocate the payment to at least one invoice.'
    } else if (allocations.length === 0) {
      errors.allocations = 'Enter allocation amounts.'
    }
    if (Object.keys(errors).length > 0) {
      setPaymentFieldErrors(errors)
      return
    }
    setPaymentFieldErrors({})
    savePaymentMutation.mutate()
  }

  const onIssue = async (inv: Invoice) => {
    const ok = await confirm({
      title: 'Issue invoice?',
      message: `Issue ${inv.invoice_number}? It will become payable and can no longer be edited as a draft.`,
      confirmLabel: 'Issue',
    })
    if (ok) issueMutation.mutate(inv.id)
  }

  const onVoidInvoice = async (inv: Invoice) => {
    const ok = await confirm({
      title: 'Void invoice?',
      message: `Void ${inv.invoice_number}? This cannot be undone.`,
      confirmLabel: 'Void',
      tone: 'danger',
    })
    if (!ok) return
    const reason = window.prompt('Void reason (optional):') ?? undefined
    voidInvoiceMutation.mutate({ id: inv.id, reason: reason || undefined })
  }

  const onVoidPayment = async (pay: Payment) => {
    const ok = await confirm({
      title: 'Reverse payment?',
      message: `Reverse ${pay.payment_number}? Invoice balances will be recalculated.`,
      confirmLabel: 'Reverse',
      tone: 'danger',
    })
    if (!ok) return
    const reason = window.prompt('Reversal reason (optional):') ?? undefined
    voidPaymentMutation.mutate({ id: pay.id, reason: reason || undefined })
  }

  const printInvoice = (inv: Invoice) => {
    printInvoiceDocument(inv, { gymName, gymSlug })
  }

  const printReceipt = (pay: Payment) => {
    printPaymentReceipt(pay, { gymName, gymSlug })
  }

  const invoiceColumns: Column<Invoice>[] = [
    {
      key: 'number',
      header: 'Invoice',
      cell: (row) => (
        <div>
          <p className="font-medium text-ink">{row.invoice_number}</p>
          <p className="text-xs text-muted">{memberLabel(row.member)}</p>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={invoiceStatusTone(row.status)}>{statusLabel(row.status)}</Badge>
      ),
    },
    {
      key: 'total',
      header: 'Total',
      cell: (row) => (
        <span className="text-sm text-ink">
          {formatMoney(row.grand_total, row.currency_code)}
        </span>
      ),
    },
    {
      key: 'balance',
      header: 'Balance',
      cell: (row) => (
        <span className="text-sm text-ink">
          {formatMoney(row.balance_due, row.currency_code)}
        </span>
      ),
    },
    {
      key: 'dates',
      header: 'Dates',
      cell: (row) => (
        <div className="text-xs text-muted">
          <div>Issued {formatDate(row.issue_date)}</div>
          <div>Due {formatDate(row.due_date)}</div>
        </div>
      ),
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <div className="flex justify-end gap-2">
          <Button
            size="sm"
            variant="ghost"
            title="Print invoice"
            onClick={(e) => {
              e.stopPropagation()
              printInvoice(row)
            }}
          >
            <Printer className="h-4 w-4" />
          </Button>
          <Button size="sm" variant="secondary" onClick={() => setSelectedInvoiceId(row.id)}>
            Open
          </Button>
        </div>
      ),
    },
  ]

  const paymentColumns: Column<Payment>[] = [
    {
      key: 'number',
      header: 'Payment',
      cell: (row) => (
        <div>
          <p className="font-medium text-ink">{row.payment_number}</p>
          <p className="text-xs text-muted">{memberLabel(row.member)}</p>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={paymentStatusTone(row.status)}>{statusLabel(row.status)}</Badge>
      ),
    },
    {
      key: 'amount',
      header: 'Amount',
      cell: (row) => (
        <span className="text-sm font-medium text-ink">
          {formatMoney(row.amount, row.currency_code)}
        </span>
      ),
    },
    {
      key: 'method',
      header: 'Method',
      cell: (row) => <span className="text-sm text-ink">{methodLabel(row.method)}</span>,
    },
    {
      key: 'paid',
      header: 'Paid',
      cell: (row) => <span className="text-sm text-muted">{formatDate(row.paid_at)}</span>,
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <div className="flex justify-end gap-2">
          <Button
            size="sm"
            variant="ghost"
            title="Print receipt"
            onClick={(e) => {
              e.stopPropagation()
              printReceipt(row)
            }}
          >
            <Printer className="h-4 w-4" />
          </Button>
          <Button size="sm" variant="secondary" onClick={() => setSelectedPaymentId(row.id)}>
            Open
          </Button>
        </div>
      ),
    },
  ]

  const selectedInvoice = invoiceDetailQuery.data
  const selectedPayment = paymentDetailQuery.data
  const members = membersQuery.data?.data ?? []
  const openInvoices = openInvoicesQuery.data ?? []

  const allocationSum = useMemo(
    () => payAllocations.reduce((s, a) => s + toNum(a.amount), 0),
    [payAllocations],
  )

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader title="Billing" description="Invoices and payments." />
        <Alert tone="danger">You do not have permission to view billing.</Alert>
      </div>
    )
  }

  const stats = statsQuery.data

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Billing"
        description="Invoices and payments — create, collect, void, and print documents."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">{defaultCurrency}</Badge>
            {canCreateInvoices && tab === 'invoices' ? (
              <Button size="sm" onClick={openCreateInvoice}>
                <Plus className="h-4 w-4" />
                New invoice
              </Button>
            ) : null}
            {canRecordPayments && (tab === 'payments' || tab === 'invoices') ? (
              <Button
                size="sm"
                variant={tab === 'payments' ? 'primary' : 'secondary'}
                onClick={() => openRecordPayment()}
              >
                <Banknote className="h-4 w-4" />
                Record payment
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<FileText className="h-4 w-4" />}
          label="Open invoices"
          value={formatNumber(stats?.open ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<FileText className="h-4 w-4" />}
          label="Drafts"
          value={formatNumber(stats?.drafts ?? 0)}
        />
        <SummaryChip
          icon={<Receipt className="h-4 w-4" />}
          label="Payments"
          value={formatNumber(stats?.payments ?? 0)}
        />
        <SummaryChip
          icon={<Banknote className="h-4 w-4" />}
          label="Paid invoices"
          value={formatNumber(stats?.paid ?? 0)}
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {canViewInvoices ? (
          <button
            type="button"
            onClick={() => {
              setTab('invoices')
              setError(null)
              setShowPaymentForm(false)
              setSelectedPaymentId(null)
            }}
            className={cn(
              'rounded-xl px-3 py-2 text-sm font-semibold transition',
              tab === 'invoices'
                ? 'bg-accent text-accent-ink'
                : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
            )}
          >
            Invoices
          </button>
        ) : null}
        {canViewPayments ? (
          <button
            type="button"
            onClick={() => {
              setTab('payments')
              setError(null)
              setShowInvoiceForm(false)
              setSelectedInvoiceId(null)
            }}
            className={cn(
              'rounded-xl px-3 py-2 text-sm font-semibold transition',
              tab === 'payments'
                ? 'bg-accent text-accent-ink'
                : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
            )}
          >
            Payments
          </button>
        ) : null}
      </div>

      {tab === 'invoices' && canViewInvoices ? (
        <>
          {showInvoiceForm && canCreateInvoices ? (
            <Card className="border-accent/25">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>
                    {editingInvoice ? `Edit ${editingInvoice.invoice_number}` : 'Create invoice'}
                  </CardTitle>
                  <CardDescription>
                    Add line items with quantity, price, discount, and tax. Issue now or save as
                    draft.
                  </CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setShowInvoiceForm(false)
                    setEditingInvoice(null)
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <form noValidate onSubmit={onSaveInvoice} className="space-y-4">
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {!editingInvoice ? (
                    <Field
                      label="Member"
                      htmlFor="invoice-member"
                      required
                      error={invoiceFieldErrors.member_id}
                      className="sm:col-span-2 lg:col-span-1"
                    >
                      {canViewMembers ? (
                        <>
                          <Input
                            className="mb-2"
                            placeholder="Search members…"
                            value={memberSearch}
                            onChange={(e) => setMemberSearch(e.target.value)}
                          />
                          <Select
                            id="invoice-member"
                            required
                            aria-invalid={Boolean(invoiceFieldErrors.member_id)}
                            value={invoiceMemberId === '' ? '' : String(invoiceMemberId)}
                            onChange={(e) => {
                              clearInvoiceFieldError('member_id')
                              setInvoiceMemberId(e.target.value ? Number(e.target.value) : '')
                            }}
                          >
                            <option value="">Select member</option>
                            {members.map((m) => (
                              <option key={m.id} value={m.id}>
                                {memberLabel(m)}
                              </option>
                            ))}
                          </Select>
                        </>
                      ) : (
                        <Input
                          id="invoice-member"
                          required
                          aria-invalid={Boolean(invoiceFieldErrors.member_id)}
                          type="number"
                          placeholder="Member ID"
                          value={invoiceMemberId === '' ? '' : invoiceMemberId}
                          onChange={(e) => {
                            clearInvoiceFieldError('member_id')
                            setInvoiceMemberId(e.target.value ? Number(e.target.value) : '')
                          }}
                        />
                      )}
                    </Field>
                  ) : null}
                  {!editingInvoice ? (
                    <Field label="Branch" htmlFor="invoice-branch">
                      <Select
                        id="invoice-branch"
                        value={invoiceBranchId === '' ? '' : String(invoiceBranchId)}
                        onChange={(e) =>
                          setInvoiceBranchId(e.target.value ? Number(e.target.value) : '')
                        }
                      >
                        <option value="">No branch</option>
                        {branches.map((b) => (
                          <option key={b.id} value={b.id}>
                            {b.name}
                          </option>
                        ))}
                      </Select>
                    </Field>
                  ) : null}
                  <Field label="Due date" htmlFor="invoice-due-date">
                    <Input
                      id="invoice-due-date"
                      type="date"
                      value={invoiceDueDate}
                      onChange={(e) => setInvoiceDueDate(e.target.value)}
                    />
                  </Field>
                  {!editingInvoice ? (
                    <div className="flex items-end">
                      <label className="flex items-center gap-2 text-sm text-ink">
                        <input
                          type="checkbox"
                          checked={invoiceIssueNow}
                          onChange={(e) => setInvoiceIssueNow(e.target.checked)}
                          className="h-4 w-4 rounded border-white/20"
                        />
                        Issue immediately
                      </label>
                    </div>
                  ) : null}
                </div>

                <div>
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <div>
                      <Label required>Line items</Label>
                      <FieldError error={invoiceFieldErrors.line_items} />
                    </div>
                    <Button
                      type="button"
                      size="sm"
                      variant="secondary"
                      onClick={() => setInvoiceLines((rows) => [...rows, emptyLine()])}
                    >
                      <Plus className="h-4 w-4" />
                      Add line
                    </Button>
                  </div>
                  <div className="space-y-2">
                    {invoiceLines.map((line, idx) => (
                      <div
                        key={idx}
                        className="grid gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-3 sm:grid-cols-12"
                      >
                        <div className="sm:col-span-4">
                          <Input
                            required
                            aria-invalid={Boolean(invoiceFieldErrors[`line_${idx}_description`])}
                            placeholder="Description"
                            value={line.description}
                            onChange={(e) => {
                              clearInvoiceFieldError(`line_${idx}_description`)
                              clearInvoiceFieldError('line_items')
                              setInvoiceLines((rows) =>
                                rows.map((r, i) =>
                                  i === idx ? { ...r, description: e.target.value } : r,
                                ),
                              )
                            }}
                          />
                          {invoiceFieldErrors[`line_${idx}_description`] ? (
                            <p className="mt-1 text-xs font-medium text-danger" role="alert">
                              {invoiceFieldErrors[`line_${idx}_description`]}
                            </p>
                          ) : null}
                        </div>
                        <div className="sm:col-span-1">
                          <Input
                            type="number"
                            min="0.01"
                            step="0.01"
                            placeholder="Qty"
                            value={line.quantity}
                            onChange={(e) =>
                              setInvoiceLines((rows) =>
                                rows.map((r, i) =>
                                  i === idx ? { ...r, quantity: e.target.value } : r,
                                ),
                              )
                            }
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <Input
                            required
                            aria-invalid={Boolean(invoiceFieldErrors[`line_${idx}_unit_price`])}
                            type="number"
                            min="0"
                            step="0.01"
                            placeholder="Unit price"
                            value={line.unit_price}
                            onChange={(e) => {
                              clearInvoiceFieldError(`line_${idx}_unit_price`)
                              clearInvoiceFieldError('line_items')
                              setInvoiceLines((rows) =>
                                rows.map((r, i) =>
                                  i === idx ? { ...r, unit_price: e.target.value } : r,
                                ),
                              )
                            }}
                          />
                          {invoiceFieldErrors[`line_${idx}_unit_price`] ? (
                            <p className="mt-1 text-xs font-medium text-danger" role="alert">
                              {invoiceFieldErrors[`line_${idx}_unit_price`]}
                            </p>
                          ) : null}
                        </div>
                        <div className="sm:col-span-2">
                          <Input
                            type="number"
                            min="0"
                            step="0.01"
                            placeholder="Discount"
                            value={line.discount_amount}
                            onChange={(e) =>
                              setInvoiceLines((rows) =>
                                rows.map((r, i) =>
                                  i === idx ? { ...r, discount_amount: e.target.value } : r,
                                ),
                              )
                            }
                          />
                        </div>
                        <div className="sm:col-span-2">
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            step="0.01"
                            placeholder="Tax %"
                            value={line.tax_rate_percent}
                            onChange={(e) =>
                              setInvoiceLines((rows) =>
                                rows.map((r, i) =>
                                  i === idx ? { ...r, tax_rate_percent: e.target.value } : r,
                                ),
                              )
                            }
                          />
                        </div>
                        <div className="flex items-center sm:col-span-1">
                          <Button
                            type="button"
                            size="sm"
                            variant="ghost"
                            disabled={invoiceLines.length <= 1}
                            onClick={() =>
                              setInvoiceLines((rows) => rows.filter((_, i) => i !== idx))
                            }
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <Field label="Notes" htmlFor="invoice-notes">
                  <Textarea
                    id="invoice-notes"
                    rows={2}
                    value={invoiceNotes}
                    onChange={(e) => setInvoiceNotes(e.target.value)}
                    placeholder="Optional notes shown on the invoice"
                  />
                </Field>

                <div className="flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => {
                      setShowInvoiceForm(false)
                      setEditingInvoice(null)
                    }}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={saveInvoiceMutation.isPending}>
                    {saveInvoiceMutation.isPending
                      ? 'Saving…'
                      : editingInvoice
                        ? 'Save changes'
                        : invoiceIssueNow
                          ? 'Create & issue'
                          : 'Save draft'}
                  </Button>
                </div>
              </form>
            </Card>
          ) : null}

          {showPaymentForm && canRecordPayments ? (
            <PaymentFormCard
              branches={branches}
              canViewMembers={canViewMembers}
              members={members}
              payMemberSearch={payMemberSearch}
              setPayMemberSearch={setPayMemberSearch}
              payMemberId={payMemberId}
              setPayMemberId={(id) => {
                setPayMemberId(id)
                setPayAllocations([])
                setPayAmount('')
              }}
              payBranchId={payBranchId}
              setPayBranchId={setPayBranchId}
              payAmount={payAmount}
              setPayAmount={setPayAmount}
              payMethodForm={payMethodForm}
              setPayMethodForm={setPayMethodForm}
              payReference={payReference}
              setPayReference={setPayReference}
              payNotes={payNotes}
              setPayNotes={setPayNotes}
              payAllocations={payAllocations}
              setPayAllocations={setPayAllocations}
              openInvoices={openInvoices}
              openLoading={openInvoicesQuery.isLoading}
              allocationSum={allocationSum}
              currency={defaultCurrency}
              saving={savePaymentMutation.isPending}
              fieldErrors={paymentFieldErrors}
              clearFieldError={clearPaymentFieldError}
              onClose={() => setShowPaymentForm(false)}
              onSubmit={onSavePayment}
            />
          ) : null}

          <Card>
            <div className="mb-4 flex flex-wrap items-end gap-3">
              <div className="min-w-[180px] flex-1">
                <Label>Search</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Invoice number…"
                    value={invSearch}
                    onChange={(e) => setInvSearch(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        setAppliedInvSearch(invSearch.trim())
                        setInvPage(1)
                      }
                    }}
                  />
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => {
                      setAppliedInvSearch(invSearch.trim())
                      setInvPage(1)
                    }}
                  >
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div>
                <Label>Status</Label>
                <Select
                  value={invStatus}
                  onChange={(e) => {
                    setInvStatus(e.target.value as '' | InvoiceStatus)
                    setInvPage(1)
                  }}
                >
                  <option value="">All</option>
                  <option value="draft">Draft</option>
                  <option value="issued">Issued</option>
                  <option value="partially_paid">Partially paid</option>
                  <option value="paid">Paid</option>
                  <option value="overdue">Overdue</option>
                  <option value="void">Void</option>
                </Select>
              </div>
              <div>
                <Label>Branch</Label>
                <Select
                  value={invBranch === '' ? '' : String(invBranch)}
                  onChange={(e) => {
                    setInvBranch(e.target.value ? Number(e.target.value) : '')
                    setInvPage(1)
                  }}
                >
                  <option value="">All branches</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </Select>
              </div>
            </div>

            {invoicesQuery.isLoading ? (
              <div className="flex justify-center py-12">
                <Spinner />
              </div>
            ) : invoicesQuery.isError ? (
              <Alert tone="danger">
                {invoicesQuery.error instanceof ApiError
                  ? invoicesQuery.error.message
                  : 'Failed to load invoices.'}
              </Alert>
            ) : (
              <>
                <DataTable
                  columns={invoiceColumns}
                  rows={invoicesQuery.data?.data ?? []}
                  rowKey={(r) => r.id}
                  emptyTitle="No invoices"
                  emptyDescription="Create an invoice to start collecting payments."
                />
                <Pagination
                  meta={invoicesQuery.data?.meta}
                  onPageChange={(p) => {
                    setInvPage(p)
                    setSelectedInvoiceId(null)
                  }}
                />
              </>
            )}
          </Card>

          {selectedInvoiceId != null ? (
            <Card className="border-accent/20">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Invoice detail</CardTitle>
                  <CardDescription>
                    {selectedInvoice?.invoice_number ?? `Invoice #${selectedInvoiceId}`}
                  </CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setSelectedInvoiceId(null)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>

              {invoiceDetailQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Spinner />
                </div>
              ) : selectedInvoice ? (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone={invoiceStatusTone(selectedInvoice.status)}>
                      {statusLabel(selectedInvoice.status)}
                    </Badge>
                    <span className="text-sm text-muted">
                      {memberLabel(selectedInvoice.member)}
                    </span>
                    {selectedInvoice.branch ? (
                      <span className="text-sm text-muted">· {selectedInvoice.branch.name}</span>
                    ) : null}
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <DetailStat
                      label="Grand total"
                      value={formatMoney(
                        selectedInvoice.grand_total,
                        selectedInvoice.currency_code,
                      )}
                    />
                    <DetailStat
                      label="Paid"
                      value={formatMoney(
                        selectedInvoice.amount_paid,
                        selectedInvoice.currency_code,
                      )}
                    />
                    <DetailStat
                      label="Balance due"
                      value={formatMoney(
                        selectedInvoice.balance_due,
                        selectedInvoice.currency_code,
                      )}
                    />
                    <DetailStat label="Due date" value={formatDate(selectedInvoice.due_date)} />
                  </div>

                  <div className="overflow-x-auto rounded-xl border border-white/10">
                    <table className="w-full text-left text-sm">
                      <thead className="bg-white/[0.04] text-xs uppercase tracking-wide text-muted">
                        <tr>
                          <th className="px-3 py-2 font-medium">Description</th>
                          <th className="px-3 py-2 font-medium">Qty</th>
                          <th className="px-3 py-2 font-medium">Unit</th>
                          <th className="px-3 py-2 font-medium">Tax</th>
                          <th className="px-3 py-2 font-medium text-right">Line total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(selectedInvoice.items ?? []).map((item) => (
                          <tr key={item.id} className="border-t border-white/8">
                            <td className="px-3 py-2 text-ink">{item.description}</td>
                            <td className="px-3 py-2 text-muted">{item.quantity}</td>
                            <td className="px-3 py-2 text-muted">
                              {formatMoney(item.unit_price, selectedInvoice.currency_code)}
                            </td>
                            <td className="px-3 py-2 text-muted">
                              {item.tax_rate_percent != null ? `${item.tax_rate_percent}%` : '—'}
                            </td>
                            <td className="px-3 py-2 text-right text-ink">
                              {formatMoney(item.line_total, selectedInvoice.currency_code)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {selectedInvoice.notes ? (
                    <p className="text-sm text-muted">
                      <span className="font-medium text-ink">Notes: </span>
                      {selectedInvoice.notes}
                    </p>
                  ) : null}

                  <div className="flex flex-wrap gap-2">
                    <Button size="sm" onClick={() => printInvoice(selectedInvoice)}>
                      <Printer className="h-4 w-4" />
                      Print invoice
                    </Button>
                    {canCreateInvoices && selectedInvoice.status === 'draft' ? (
                      <>
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => openEditInvoice(selectedInvoice)}
                        >
                          Edit draft
                        </Button>
                        <Button
                          size="sm"
                          variant="secondary"
                          disabled={issueMutation.isPending}
                          onClick={() => onIssue(selectedInvoice)}
                        >
                          Issue
                        </Button>
                      </>
                    ) : null}
                    {canRecordPayments && isOpenInvoiceStatus(selectedInvoice.status) ? (
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => openRecordPayment(selectedInvoice)}
                      >
                        <Banknote className="h-4 w-4" />
                        Record payment
                      </Button>
                    ) : null}
                    {canVoidInvoices &&
                    selectedInvoice.status !== 'void' &&
                    selectedInvoice.status !== 'paid' ? (
                      <Button
                        size="sm"
                        variant="danger"
                        disabled={voidInvoiceMutation.isPending}
                        onClick={() => onVoidInvoice(selectedInvoice)}
                      >
                        Void
                      </Button>
                    ) : null}
                  </div>
                </div>
              ) : (
                <Alert tone="danger">Invoice not found.</Alert>
              )}
            </Card>
          ) : null}
        </>
      ) : null}

      {tab === 'payments' && canViewPayments ? (
        <>
          {showPaymentForm && canRecordPayments ? (
            <PaymentFormCard
              branches={branches}
              canViewMembers={canViewMembers}
              members={members}
              payMemberSearch={payMemberSearch}
              setPayMemberSearch={setPayMemberSearch}
              payMemberId={payMemberId}
              setPayMemberId={(id) => {
                setPayMemberId(id)
                setPayAllocations([])
                setPayAmount('')
              }}
              payBranchId={payBranchId}
              setPayBranchId={setPayBranchId}
              payAmount={payAmount}
              setPayAmount={setPayAmount}
              payMethodForm={payMethodForm}
              setPayMethodForm={setPayMethodForm}
              payReference={payReference}
              setPayReference={setPayReference}
              payNotes={payNotes}
              setPayNotes={setPayNotes}
              payAllocations={payAllocations}
              setPayAllocations={setPayAllocations}
              openInvoices={openInvoices}
              openLoading={openInvoicesQuery.isLoading}
              allocationSum={allocationSum}
              currency={defaultCurrency}
              saving={savePaymentMutation.isPending}
              fieldErrors={paymentFieldErrors}
              clearFieldError={clearPaymentFieldError}
              onClose={() => setShowPaymentForm(false)}
              onSubmit={onSavePayment}
            />
          ) : null}

          <Card>
            <div className="mb-4 flex flex-wrap items-end gap-3">
              <div className="min-w-[180px] flex-1">
                <Label>Search</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Payment number or reference…"
                    value={paySearch}
                    onChange={(e) => setPaySearch(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        setAppliedPaySearch(paySearch.trim())
                        setPayPage(1)
                      }
                    }}
                  />
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => {
                      setAppliedPaySearch(paySearch.trim())
                      setPayPage(1)
                    }}
                  >
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div>
                <Label>Status</Label>
                <Select
                  value={payStatus}
                  onChange={(e) => {
                    setPayStatus(e.target.value as '' | PaymentStatus)
                    setPayPage(1)
                  }}
                >
                  <option value="">All</option>
                  <option value="completed">Completed</option>
                  <option value="reversed">Reversed</option>
                </Select>
              </div>
              <div>
                <Label>Method</Label>
                <Select
                  value={payMethod}
                  onChange={(e) => {
                    setPayMethod(e.target.value as '' | PaymentMethod)
                    setPayPage(1)
                  }}
                >
                  <option value="">All</option>
                  <option value="cash">Cash</option>
                  <option value="card">Card</option>
                  <option value="upi">UPI</option>
                  <option value="bank_transfer">Bank transfer</option>
                  <option value="other">Other</option>
                </Select>
              </div>
              <div>
                <Label>Branch</Label>
                <Select
                  value={payBranch === '' ? '' : String(payBranch)}
                  onChange={(e) => {
                    setPayBranch(e.target.value ? Number(e.target.value) : '')
                    setPayPage(1)
                  }}
                >
                  <option value="">All branches</option>
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </Select>
              </div>
            </div>

            {paymentsQuery.isLoading ? (
              <div className="flex justify-center py-12">
                <Spinner />
              </div>
            ) : paymentsQuery.isError ? (
              <Alert tone="danger">
                {paymentsQuery.error instanceof ApiError
                  ? paymentsQuery.error.message
                  : 'Failed to load payments.'}
              </Alert>
            ) : (
              <>
                <DataTable
                  columns={paymentColumns}
                  rows={paymentsQuery.data?.data ?? []}
                  rowKey={(r) => r.id}
                  emptyTitle="No payments"
                  emptyDescription="Record a payment against an open invoice."
                />
                <Pagination
                  meta={paymentsQuery.data?.meta}
                  onPageChange={(p) => {
                    setPayPage(p)
                    setSelectedPaymentId(null)
                  }}
                />
              </>
            )}
          </Card>

          {selectedPaymentId != null ? (
            <Card className="border-accent/20">
              <div className="mb-4 flex items-start justify-between gap-3">
                <div>
                  <CardTitle>Payment detail</CardTitle>
                  <CardDescription>
                    {selectedPayment?.payment_number ?? `Payment #${selectedPaymentId}`}
                  </CardDescription>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setSelectedPaymentId(null)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>

              {paymentDetailQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Spinner />
                </div>
              ) : selectedPayment ? (
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone={paymentStatusTone(selectedPayment.status)}>
                      {statusLabel(selectedPayment.status)}
                    </Badge>
                    <span className="text-sm text-muted">
                      {memberLabel(selectedPayment.member)}
                    </span>
                    <span className="text-sm text-muted">
                      · {methodLabel(selectedPayment.method)}
                    </span>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                    <DetailStat
                      label="Amount"
                      value={formatMoney(
                        selectedPayment.amount,
                        selectedPayment.currency_code,
                      )}
                    />
                    <DetailStat label="Paid at" value={formatDate(selectedPayment.paid_at)} />
                    <DetailStat
                      label="Reference"
                      value={selectedPayment.reference || '—'}
                    />
                  </div>

                  <div className="overflow-x-auto rounded-xl border border-white/10">
                    <table className="w-full text-left text-sm">
                      <thead className="bg-white/[0.04] text-xs uppercase tracking-wide text-muted">
                        <tr>
                          <th className="px-3 py-2 font-medium">Invoice</th>
                          <th className="px-3 py-2 font-medium">Status</th>
                          <th className="px-3 py-2 font-medium text-right">Allocated</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(selectedPayment.allocations ?? []).map((a) => (
                          <tr key={a.id} className="border-t border-white/8">
                            <td className="px-3 py-2 text-ink">
                              {a.invoice?.invoice_number ?? `#${a.invoice_id}`}
                            </td>
                            <td className="px-3 py-2 text-muted">
                              {a.invoice?.status ? statusLabel(a.invoice.status) : '—'}
                            </td>
                            <td className="px-3 py-2 text-right text-ink">
                              {formatMoney(a.amount, selectedPayment.currency_code)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {selectedPayment.notes ? (
                    <p className="text-sm text-muted">
                      <span className="font-medium text-ink">Notes: </span>
                      {selectedPayment.notes}
                    </p>
                  ) : null}

                  <div className="flex flex-wrap gap-2">
                    <Button size="sm" onClick={() => printReceipt(selectedPayment)}>
                      <Printer className="h-4 w-4" />
                      Print receipt
                    </Button>
                    {canVoidPayments && selectedPayment.status === 'completed' ? (
                      <Button
                        size="sm"
                        variant="danger"
                        disabled={voidPaymentMutation.isPending}
                        onClick={() => onVoidPayment(selectedPayment)}
                      >
                        Reverse payment
                      </Button>
                    ) : null}
                  </div>
                </div>
              ) : (
                <Alert tone="danger">Payment not found.</Alert>
              )}
            </Card>
          ) : null}
        </>
      ) : null}
    </div>
  )
}

function PaymentFormCard({
  branches,
  canViewMembers,
  members,
  payMemberSearch,
  setPayMemberSearch,
  payMemberId,
  setPayMemberId,
  payBranchId,
  setPayBranchId,
  payAmount,
  setPayAmount,
  payMethodForm,
  setPayMethodForm,
  payReference,
  setPayReference,
  payNotes,
  setPayNotes,
  payAllocations,
  setPayAllocations,
  openInvoices,
  openLoading,
  allocationSum,
  currency,
  saving,
  fieldErrors,
  clearFieldError,
  onClose,
  onSubmit,
}: {
  branches: Array<{ id: number; name: string }>
  canViewMembers: boolean
  members: Array<{
    id: number
    first_name: string
    last_name: string
    member_code: string
    full_name: string
  }>
  payMemberSearch: string
  setPayMemberSearch: (v: string) => void
  payMemberId: number | ''
  setPayMemberId: (v: number | '') => void
  payBranchId: number | ''
  setPayBranchId: (v: number | '') => void
  payAmount: string
  setPayAmount: (v: string) => void
  payMethodForm: PaymentMethod
  setPayMethodForm: (v: PaymentMethod) => void
  payReference: string
  setPayReference: (v: string) => void
  payNotes: string
  setPayNotes: (v: string) => void
  payAllocations: Array<{
    invoice_id: number
    amount: string
    label: string
    balance: number
  }>
  setPayAllocations: Dispatch<
    SetStateAction<
      Array<{ invoice_id: number; amount: string; label: string; balance: number }>
    >
  >
  openInvoices: Invoice[]
  openLoading: boolean
  allocationSum: number
  currency: string
  saving: boolean
  fieldErrors: FieldErrors
  clearFieldError: (key: string) => void
  onClose: () => void
  onSubmit: (e: FormEvent) => void
}) {
  return (
    <Card className="border-accent/25">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <CardTitle>Record payment</CardTitle>
          <CardDescription>
            Allocate the full amount across one or more open invoices for the member.
          </CardDescription>
        </div>
        <Button size="sm" variant="ghost" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>
      <form noValidate onSubmit={onSubmit} className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <Field
            label="Member"
            htmlFor="payment-member"
            required
            error={fieldErrors.member_id}
          >
            {canViewMembers ? (
              <>
                <Input
                  className="mb-2"
                  placeholder="Search members…"
                  value={payMemberSearch}
                  onChange={(e) => setPayMemberSearch(e.target.value)}
                />
                <Select
                  id="payment-member"
                  required
                  aria-invalid={Boolean(fieldErrors.member_id)}
                  value={payMemberId === '' ? '' : String(payMemberId)}
                  onChange={(e) => {
                    clearFieldError('member_id')
                    setPayMemberId(e.target.value ? Number(e.target.value) : '')
                  }}
                >
                  <option value="">Select member</option>
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {memberLabel(m)}
                    </option>
                  ))}
                </Select>
              </>
            ) : (
              <Input
                id="payment-member"
                required
                aria-invalid={Boolean(fieldErrors.member_id)}
                type="number"
                placeholder="Member ID"
                value={payMemberId === '' ? '' : payMemberId}
                onChange={(e) => {
                  clearFieldError('member_id')
                  setPayMemberId(e.target.value ? Number(e.target.value) : '')
                }}
              />
            )}
          </Field>
          <Field label="Branch" htmlFor="payment-branch">
            <Select
              id="payment-branch"
              value={payBranchId === '' ? '' : String(payBranchId)}
              onChange={(e) =>
                setPayBranchId(e.target.value ? Number(e.target.value) : '')
              }
            >
              <option value="">No branch</option>
              {branches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Method" htmlFor="payment-method">
            <Select
              id="payment-method"
              value={payMethodForm}
              onChange={(e) => setPayMethodForm(e.target.value as PaymentMethod)}
            >
              <option value="cash">Cash</option>
              <option value="card">Card</option>
              <option value="upi">UPI</option>
              <option value="bank_transfer">Bank transfer</option>
              <option value="other">Other</option>
            </Select>
          </Field>
          <Field label="Amount" htmlFor="payment-amount" required error={fieldErrors.amount}>
            <Input
              id="payment-amount"
              type="number"
              min="0.01"
              step="0.01"
              required
              aria-invalid={Boolean(fieldErrors.amount)}
              value={payAmount}
              onChange={(e) => {
                clearFieldError('amount')
                setPayAmount(e.target.value)
              }}
              placeholder="Must equal allocations"
            />
          </Field>
          <Field label="Reference" htmlFor="payment-reference">
            <Input
              id="payment-reference"
              value={payReference}
              onChange={(e) => setPayReference(e.target.value)}
              placeholder="Txn ID / cheque no."
            />
          </Field>
        </div>

        <div>
          <div className="mb-2 flex items-center justify-between gap-2">
            <div>
              <Label required>Allocations</Label>
              <FieldError error={fieldErrors.allocations} />
            </div>
            <span className="text-xs text-muted">
              Allocated {formatMoney(allocationSum, currency)}
            </span>
          </div>
          {!payMemberId ? (
            <p className="text-sm text-muted">Select a member to load open invoices.</p>
          ) : openLoading ? (
            <div className="flex justify-center py-6">
              <Spinner />
            </div>
          ) : payAllocations.length === 0 && openInvoices.length === 0 ? (
            <Alert tone="info">This member has no open invoices with a balance due.</Alert>
          ) : (
            <div className="space-y-2">
              {(payAllocations.length > 0 ? payAllocations : []).map((row) => (
                <div
                  key={row.invoice_id}
                  className="flex flex-wrap items-center gap-3 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2"
                >
                  <div className="min-w-[140px] flex-1">
                    <p className="text-sm font-medium text-ink">{row.label}</p>
                    <p className="text-xs text-muted">
                      Balance {formatMoney(row.balance, currency)}
                    </p>
                  </div>
                  <Input
                    className="w-36"
                    type="number"
                    min="0"
                    step="0.01"
                    max={row.balance}
                    placeholder="0.00"
                    value={row.amount}
                    onChange={(e) => {
                      clearFieldError('allocations')
                      setPayAllocations((rows) =>
                        rows.map((r) =>
                          r.invoice_id === row.invoice_id
                            ? { ...r, amount: e.target.value }
                            : r,
                        ),
                      )
                    }}
                  />
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() =>
                      setPayAllocations((rows) =>
                        rows.map((r) =>
                          r.invoice_id === row.invoice_id
                            ? { ...r, amount: String(r.balance) }
                            : r,
                        ),
                      )
                    }
                  >
                    Full
                  </Button>
                </div>
              ))}
              {openInvoices
                .filter((inv) => !payAllocations.some((a) => a.invoice_id === inv.id))
                .map((inv) => (
                  <Button
                    key={inv.id}
                    type="button"
                    size="sm"
                    variant="secondary"
                    onClick={() =>
                      setPayAllocations((rows) => [
                        ...rows,
                        {
                          invoice_id: inv.id,
                          amount: '',
                          label: inv.invoice_number,
                          balance: toNum(inv.balance_due),
                        },
                      ])
                    }
                  >
                    <Plus className="h-4 w-4" />
                    Add {inv.invoice_number}
                  </Button>
                ))}
            </div>
          )}
        </div>

        <Field label="Notes" htmlFor="payment-notes">
          <Textarea
            id="payment-notes"
            rows={2}
            value={payNotes}
            onChange={(e) => setPayNotes(e.target.value)}
            placeholder="Optional notes"
          />
        </Field>

        <div className="flex justify-end gap-2">
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" disabled={saving}>
            {saving ? 'Recording…' : 'Record payment'}
          </Button>
        </div>
      </form>
    </Card>
  )
}

function DetailStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-0.5 text-sm font-semibold text-ink">{value}</p>
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}
