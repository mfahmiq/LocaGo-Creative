import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Ban,
  PauseCircle,
  PlayCircle,
  Plus,
  Search,
  Trash2,
  UserPlus,
  Users,
  UserCheck,
  X,
} from 'lucide-react'
import {
  changeMemberStatus,
  createMember,
  deleteMember,
  fetchMembers,
  updateMember,
  type Member,
  type MemberStatus,
} from '@/api/members'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useBranchFilter } from '@/hooks/useBranchFilter'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'

const STATUS_FILTERS: Array<{ value: '' | MemberStatus; label: string }> = [
  { value: '', label: 'All' },
  { value: 'active', label: 'Active' },
  { value: 'lead', label: 'Lead' },
  { value: 'inactive', label: 'Inactive' },
  { value: 'blacklisted', label: 'Blacklisted' },
]

const emptyCreate = {
  first_name: '',
  last_name: '',
  email: '',
  phone: '',
  home_branch_id: '',
  gender: '',
  date_of_birth: '',
  emergency_name: '',
  emergency_phone: '',
  status: 'active' as MemberStatus,
  joined_at: '',
}

function statusTone(status: MemberStatus): 'success' | 'accent' | 'warning' | 'danger' | 'neutral' {
  switch (status) {
    case 'active':
      return 'success'
    case 'lead':
      return 'accent'
    case 'inactive':
      return 'warning'
    case 'blacklisted':
      return 'danger'
    default:
      return 'neutral'
  }
}

function statusLabel(status: MemberStatus): string {
  switch (status) {
    case 'lead':
      return 'Lead'
    case 'active':
      return 'Active'
    case 'inactive':
      return 'Inactive'
    case 'blacklisted':
      return 'Blacklisted'
    default:
      return status
  }
}

export function MembersPage() {
  const { branches, branchId, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('members.view')
  const canCreate = hasPermission('members.create')
  const canUpdate = hasPermission('members.update')

  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [appliedSearch, setAppliedSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<'' | MemberStatus>('')
  const [branchFilter, setBranchFilter] = useBranchFilter()
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [createForm, setCreateForm] = useState(emptyCreate)
  const [createFieldErrors, setCreateFieldErrors] = useState<FieldErrors>({})
  const [editFieldErrors, setEditFieldErrors] = useState<FieldErrors>({})

  const [editFirstName, setEditFirstName] = useState('')
  const [editLastName, setEditLastName] = useState('')
  const [editEmail, setEditEmail] = useState('')
  const [editPhone, setEditPhone] = useState('')
  const [editBranchId, setEditBranchId] = useState<number | ''>('')
  const [editGender, setEditGender] = useState('')
  const [editDob, setEditDob] = useState('')
  const [editEmergencyName, setEditEmergencyName] = useState('')
  const [editEmergencyPhone, setEditEmergencyPhone] = useState('')
  const [editJoinedAt, setEditJoinedAt] = useState('')

  const membersQuery = useQuery({
    queryKey: ['admin', 'members', page, appliedSearch, statusFilter, branchFilter],
    queryFn: () =>
      fetchMembers({
        page,
        per_page: DEFAULT_PAGE_SIZE,
        search: appliedSearch,
        status: statusFilter,
        home_branch_id: branchFilter,
      }),
    enabled: canView,
  })

  const statsQuery = useQuery({
    queryKey: ['admin', 'members', 'stats'],
    queryFn: async () => {
      const [all, active, lead, inactive, blacklisted] = await Promise.all([
        fetchMembers({ page: 1, per_page: 1 }),
        fetchMembers({ page: 1, per_page: 1, status: 'active' }),
        fetchMembers({ page: 1, per_page: 1, status: 'lead' }),
        fetchMembers({ page: 1, per_page: 1, status: 'inactive' }),
        fetchMembers({ page: 1, per_page: 1, status: 'blacklisted' }),
      ])
      return {
        total: all.meta.total,
        active: active.meta.total,
        lead: lead.meta.total,
        inactive: inactive.meta.total,
        blacklisted: blacklisted.meta.total,
      }
    },
    enabled: canView,
  })

  const rows = membersQuery.data?.data ?? []
  const meta = membersQuery.data?.meta
  const selected = useMemo(
    () => rows.find((row) => row.id === selectedId) ?? null,
    [rows, selectedId],
  )

  useEffect(() => {
    if (!showCreate) return
    if (createForm.home_branch_id) return
    const preferred =
      (branchId != null && branches.some((b) => b.id === branchId) ? branchId : null) ??
      branches[0]?.id
    if (preferred != null) {
      setCreateForm((current) => ({ ...current, home_branch_id: String(preferred) }))
    }
  }, [showCreate, createForm.home_branch_id, branchId, branches])

  useEffect(() => {
    if (!selected) return
    setEditFirstName(selected.first_name)
    setEditLastName(selected.last_name)
    setEditEmail(selected.email ?? '')
    setEditPhone(selected.phone ?? '')
    setEditBranchId(selected.home_branch_id ?? '')
    setEditGender(selected.gender ?? '')
    setEditDob(selected.date_of_birth ?? '')
    setEditEmergencyName(selected.emergency_name ?? '')
    setEditEmergencyPhone(selected.emergency_phone ?? '')
    setEditJoinedAt(selected.joined_at ?? '')
  }, [selected])

  const invalidate = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'members'] })
  }

  const createMutation = useMutation({
    mutationFn: createMember,
    onSuccess: async (member) => {
      setError(null)
      showSuccess(`Member “${member.full_name}” created (${member.member_code}).`)
      setShowCreate(false)
      setCreateForm(emptyCreate)
      await invalidate()
      setSelectedId(member.id)
      setPage(1)
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to create member.')
    },
  })

  const updateMutation = useMutation({
    mutationFn: (payload: Parameters<typeof updateMember>[1]) =>
      updateMember(selectedId!, payload),
    onSuccess: async (member) => {
      setError(null)
      showSuccess(`Member “${member.full_name}” updated.`)
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update member.')
    },
  })

  const statusMutation = useMutation({
    mutationFn: ({ memberId, status }: { memberId: number; status: MemberStatus }) =>
      changeMemberStatus(memberId, status),
    onSuccess: async (member) => {
      setError(null)
      showSuccess(`“${member.full_name}” is now ${statusLabel(member.status).toLowerCase()}.`)
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to update status.')
    },
  })

  const deleteMutation = useMutation({
    mutationFn: (memberId: number) => deleteMember(memberId),
    onSuccess: async () => {
      setError(null)
      showSuccess('Member removed from the directory.')
      setSelectedId(null)
      await invalidate()
    },
    onError: (err) => {
      setError(err instanceof ApiError ? err.message : 'Unable to delete member.')
    },
  })

  const applySearch = () => {
    setPage(1)
    setSelectedId(null)
    setAppliedSearch(search.trim())
  }

  const onCreate = (event: FormEvent) => {
    event.preventDefault()
    const next = collectRequiredErrors([
      { key: 'first_name', label: 'First name', value: createForm.first_name },
      { key: 'last_name', label: 'Last name', value: createForm.last_name },
      { key: 'home_branch_id', label: 'Home branch', value: createForm.home_branch_id },
    ])
    setCreateFieldErrors(next)
    if (Object.keys(next).length) return
    createMutation.mutate({
      first_name: createForm.first_name.trim(),
      last_name: createForm.last_name.trim(),
      home_branch_id: Number(createForm.home_branch_id),
      email: createForm.email.trim() || null,
      phone: createForm.phone.trim() || null,
      gender: createForm.gender || null,
      date_of_birth: createForm.date_of_birth || null,
      emergency_name: createForm.emergency_name.trim() || null,
      emergency_phone: createForm.emergency_phone.trim() || null,
      status: createForm.status,
      joined_at: createForm.joined_at || null,
    })
  }

  const profileDirty =
    selected != null &&
    (editFirstName.trim() !== selected.first_name ||
      editLastName.trim() !== selected.last_name ||
      (editEmail.trim() || '') !== (selected.email ?? '') ||
      (editPhone.trim() || '') !== (selected.phone ?? '') ||
      editBranchId !== (selected.home_branch_id ?? '') ||
      (editGender || '') !== (selected.gender ?? '') ||
      (editDob || '') !== (selected.date_of_birth ?? '') ||
      (editEmergencyName.trim() || '') !== (selected.emergency_name ?? '') ||
      (editEmergencyPhone.trim() || '') !== (selected.emergency_phone ?? '') ||
      (editJoinedAt || '') !== (selected.joined_at ?? ''))

  const onSaveProfile = (event: FormEvent) => {
    event.preventDefault()
    if (!selected) return
    const next = collectRequiredErrors([
      { key: 'first_name', label: 'First name', value: editFirstName },
      { key: 'last_name', label: 'Last name', value: editLastName },
      { key: 'home_branch_id', label: 'Home branch', value: editBranchId },
    ])
    setEditFieldErrors(next)
    if (Object.keys(next).length) return
    updateMutation.mutate({
      first_name: editFirstName.trim(),
      last_name: editLastName.trim(),
      home_branch_id: Number(editBranchId),
      email: editEmail.trim() || null,
      phone: editPhone.trim() || null,
      gender: editGender || null,
      date_of_birth: editDob || null,
      emergency_name: editEmergencyName.trim() || null,
      emergency_phone: editEmergencyPhone.trim() || null,
      joined_at: editJoinedAt || null,
    })
  }

  const onChangeStatus = async (row: Member, next: MemberStatus) => {
    if (row.status === next) return
    const ok = await confirm({
      title: `Mark as ${statusLabel(next).toLowerCase()}?`,
      message: `Update “${row.full_name}” from ${statusLabel(row.status)} to ${statusLabel(next)}?`,
      confirmLabel: 'Confirm',
      tone: next === 'blacklisted' ? 'danger' : 'primary',
    })
    if (!ok) return
    statusMutation.mutate({ memberId: row.id, status: next })
  }

  const onDelete = async (row: Member) => {
    const ok = await confirm({
      title: 'Remove member?',
      message: `Remove “${row.full_name}” (${row.member_code}) from the directory? This can affect linked memberships.`,
      confirmLabel: 'Remove',
      tone: 'danger',
    })
    if (!ok) return
    deleteMutation.mutate(row.id)
  }

  const columns: Column<Member>[] = [
    {
      key: 'member',
      header: 'Member',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">{row.full_name}</p>
          <p className="mt-0.5 font-mono text-xs text-muted">{row.member_code}</p>
        </button>
      ),
    },
    {
      key: 'contact',
      header: 'Contact',
      cell: (row) => (
        <div className="text-sm">
          <p className="text-ink">{row.email || '—'}</p>
          <p className="text-muted">{row.phone || '—'}</p>
        </div>
      ),
    },
    {
      key: 'branch',
      header: 'Home branch',
      cell: (row) => (
        <span className="text-sm text-ink">{row.home_branch?.name ?? '—'}</span>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => <Badge tone={statusTone(row.status)}>{statusLabel(row.status)}</Badge>,
    },
    {
      key: 'joined',
      header: 'Joined',
      cell: (row) => <span className="text-sm text-muted">{formatDate(row.joined_at)}</span>,
    },
    {
      key: 'actions',
      header: '',
      className: 'w-[1%] whitespace-nowrap text-right',
      cell: (row) => (
        <div className="inline-flex items-center justify-end gap-1.5">
          <Button
            size="sm"
            variant="secondary"
            className="shrink-0"
            onClick={() => setSelectedId(row.id)}
          >
            Manage
          </Button>
          {canUpdate && row.status !== 'active' ? (
            <Button
              size="sm"
              variant="ghost"
              className="min-w-[7.75rem] shrink-0 justify-center"
              loading={statusMutation.isPending}
              onClick={() => void onChangeStatus(row, 'active')}
            >
              <PlayCircle className="h-4 w-4" />
              Activate
            </Button>
          ) : null}
          {canUpdate && row.status === 'active' ? (
            <Button
              size="sm"
              variant="ghost"
              className="min-w-[7.75rem] shrink-0 justify-center"
              loading={statusMutation.isPending}
              onClick={() => void onChangeStatus(row, 'inactive')}
            >
              <PauseCircle className="h-4 w-4" />
              Deactivate
            </Button>
          ) : null}
        </div>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader
          title="Members"
          description="Member directory and intake for this gym."
        />
        <Alert tone="danger">You do not have permission to view members.</Alert>
      </div>
    )
  }

  const stats = statsQuery.data

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Members"
        description="Member directory and intake for this gym."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge tone="neutral">Gym</Badge>
            {canCreate ? (
              <Button
                size="sm"
                onClick={() => {
                  setShowCreate(true)
                  setError(null)
                  setCreateFieldErrors({})
                }}
              >
                <Plus className="h-4 w-4" />
                New member
              </Button>
            ) : null}
          </div>
        }
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      {membersQuery.isError ? (
        <Alert tone="danger">
          {membersQuery.error instanceof ApiError
            ? membersQuery.error.message
            : 'Unable to load members.'}
          <div className="mt-3">
            <Button size="sm" variant="secondary" onClick={() => void membersQuery.refetch()}>
              Try again
            </Button>
          </div>
        </Alert>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryChip
          icon={<Users className="h-4 w-4" />}
          label="Total members"
          value={formatNumber(stats?.total ?? meta?.total ?? 0)}
        />
        <SummaryChip
          icon={<UserCheck className="h-4 w-4" />}
          label="Active"
          value={formatNumber(stats?.active ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<UserPlus className="h-4 w-4" />}
          label="Leads"
          value={formatNumber(stats?.lead ?? 0)}
        />
        <SummaryChip
          icon={<Ban className="h-4 w-4" />}
          label="Inactive / blocked"
          value={formatNumber((stats?.inactive ?? 0) + (stats?.blacklisted ?? 0))}
        />
      </div>

      {showCreate && canCreate ? (
        <Card className="border-accent/25">
          <div className="mb-4 flex items-start justify-between gap-3">
            <div>
              <CardTitle>Member intake</CardTitle>
              <CardDescription>
                Create a directory profile. Membership plans can be assigned separately.
              </CardDescription>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowCreate(false)}
              aria-label="Close create form"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <form noValidate onSubmit={onCreate} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field
              label="First name"
              htmlFor="new-first-name"
              required
              error={createFieldErrors.first_name}
            >
              <Input
                id="new-first-name"
                value={createForm.first_name}
                aria-invalid={Boolean(createFieldErrors.first_name)}
                onChange={(e) => {
                  setCreateFieldErrors((errs) => {
                    const n = { ...errs }
                    delete n.first_name
                    return n
                  })
                  setCreateForm((c) => ({ ...c, first_name: e.target.value }))
                }}
              />
            </Field>
            <Field
              label="Last name"
              htmlFor="new-last-name"
              required
              error={createFieldErrors.last_name}
            >
              <Input
                id="new-last-name"
                value={createForm.last_name}
                aria-invalid={Boolean(createFieldErrors.last_name)}
                onChange={(e) => {
                  setCreateFieldErrors((errs) => {
                    const n = { ...errs }
                    delete n.last_name
                    return n
                  })
                  setCreateForm((c) => ({ ...c, last_name: e.target.value }))
                }}
              />
            </Field>
            <Field
              label="Home branch"
              htmlFor="new-branch"
              required
              error={createFieldErrors.home_branch_id}
            >
              <Select
                id="new-branch"
                value={createForm.home_branch_id}
                aria-invalid={Boolean(createFieldErrors.home_branch_id)}
                onChange={(e) => {
                  setCreateFieldErrors((errs) => {
                    const n = { ...errs }
                    delete n.home_branch_id
                    return n
                  })
                  setCreateForm((c) => ({ ...c, home_branch_id: e.target.value }))
                }}
              >
                <option value="">Select branch…</option>
                {branches.map((branch) => (
                  <option key={branch.id} value={branch.id}>
                    {branch.name}
                  </option>
                ))}
              </Select>
            </Field>
            <div>
              <Label htmlFor="new-email">Email</Label>
              <Input
                id="new-email"
                type="email"
                value={createForm.email}
                onChange={(e) => setCreateForm((c) => ({ ...c, email: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="new-phone">Phone</Label>
              <Input
                id="new-phone"
                value={createForm.phone}
                onChange={(e) => setCreateForm((c) => ({ ...c, phone: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="new-status">Initial status</Label>
              <Select
                id="new-status"
                value={createForm.status}
                onChange={(e) =>
                  setCreateForm((c) => ({
                    ...c,
                    status: e.target.value as MemberStatus,
                  }))
                }
              >
                <option value="active">Active</option>
                <option value="lead">Lead</option>
                <option value="inactive">Inactive</option>
              </Select>
            </div>
            <div>
              <Label htmlFor="new-gender">Gender</Label>
              <Select
                id="new-gender"
                value={createForm.gender}
                onChange={(e) => setCreateForm((c) => ({ ...c, gender: e.target.value }))}
              >
                <option value="">Not specified</option>
                <option value="female">Female</option>
                <option value="male">Male</option>
                <option value="other">Other</option>
              </Select>
            </div>
            <div>
              <Label htmlFor="new-dob">Date of birth</Label>
              <Input
                id="new-dob"
                type="date"
                value={createForm.date_of_birth}
                onChange={(e) =>
                  setCreateForm((c) => ({ ...c, date_of_birth: e.target.value }))
                }
              />
            </div>
            <div>
              <Label htmlFor="new-joined">Joined on</Label>
              <Input
                id="new-joined"
                type="date"
                value={createForm.joined_at}
                onChange={(e) => setCreateForm((c) => ({ ...c, joined_at: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="new-emergency-name">Emergency contact</Label>
              <Input
                id="new-emergency-name"
                value={createForm.emergency_name}
                onChange={(e) =>
                  setCreateForm((c) => ({ ...c, emergency_name: e.target.value }))
                }
                placeholder="Name"
              />
            </div>
            <div>
              <Label htmlFor="new-emergency-phone">Emergency phone</Label>
              <Input
                id="new-emergency-phone"
                value={createForm.emergency_phone}
                onChange={(e) =>
                  setCreateForm((c) => ({ ...c, emergency_phone: e.target.value }))
                }
              />
            </div>
            <div className="flex flex-wrap items-end gap-2 sm:col-span-2 lg:col-span-3">
              <Button type="submit" loading={createMutation.isPending}>
                Create member
              </Button>
              <Button type="button" variant="ghost" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
            </div>
          </form>
        </Card>
      ) : null}

      <Card>
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2">
            {STATUS_FILTERS.map((filter) => {
              const active = statusFilter === filter.value
              return (
                <button
                  key={filter.label}
                  type="button"
                  onClick={() => {
                    setStatusFilter(filter.value)
                    setPage(1)
                    setSelectedId(null)
                  }}
                  className={cn(
                    'rounded-xl px-3 py-2 text-sm font-semibold transition',
                    active
                      ? 'bg-accent text-accent-ink'
                      : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                  )}
                >
                  {filter.label}
                </button>
              )
            })}
          </div>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            {branches.length > 0 ? (
              <Select
                value={branchFilter === '' ? '' : String(branchFilter)}
                onChange={(e) => {
                  setBranchFilter(e.target.value ? Number(e.target.value) : '')
                  setPage(1)
                  setSelectedId(null)
                }}
                aria-label="Filter by branch"
                className="sm:w-44"
              >
                <option value="">All branches</option>
                {branches.map((branch) => (
                  <option key={branch.id} value={branch.id}>
                    {branch.name}
                  </option>
                ))}
              </Select>
            ) : null}
            <div className="relative min-w-[14rem] flex-1 sm:max-w-xs">
              <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') applySearch()
                }}
                placeholder="Search name, email, code…"
                className="pl-10"
                aria-label="Search members"
              />
            </div>
            <Button size="sm" variant="secondary" onClick={applySearch}>
              Search
            </Button>
          </div>
        </div>
      </Card>

      <div className={cn('grid gap-4', selected ? 'xl:grid-cols-[1fr_24rem]' : '')}>
        <div className="min-w-0">
          {membersQuery.isPending ? (
            <div className="flex justify-center py-20">
              <Spinner label="Loading members…" />
            </div>
          ) : (
            <>
              <DataTable
                columns={columns}
                rows={rows}
                rowKey={(row) => row.id}
                emptyTitle="No members match"
                emptyDescription={
                  (meta?.total ?? 0) === 0 && !appliedSearch && !statusFilter && !branchFilter
                    ? 'Create the first member to start the directory.'
                    : 'Try another filter or clear the search.'
                }
              />
              <Pagination
                meta={meta}
                onPageChange={(next) => {
                  setPage(next)
                  setSelectedId(null)
                }}
              />
            </>
          )}
        </div>

        {selected ? (
          <aside className="animate-slide-in">
            <Card className="sticky top-4 space-y-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                    <Users className="h-5 w-5" />
                  </div>
                  <CardTitle className="truncate text-base">{selected.full_name}</CardTitle>
                  <CardDescription className="font-mono">{selected.member_code}</CardDescription>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedId(null)}
                  aria-label="Close details"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="flex flex-wrap gap-2">
                <Badge tone={statusTone(selected.status)}>{statusLabel(selected.status)}</Badge>
                {selected.home_branch ? (
                  <Badge tone="neutral">{selected.home_branch.name}</Badge>
                ) : null}
              </div>

              <dl className="space-y-2 text-sm">
                <DetailRow label="Joined" value={formatDate(selected.joined_at)} />
                <DetailRow label="Referral code" value={selected.referral_code ?? '—'} mono />
              </dl>

              {canUpdate ? (
                <form
                  noValidate
                  onSubmit={onSaveProfile}
                  className="space-y-3 border-t border-white/12 pt-4"
                >
                  <p className="text-sm font-semibold text-ink">Profile</p>
                  <div className="grid grid-cols-2 gap-2">
                    <Field
                      label="First name"
                      htmlFor="edit-first-name"
                      required
                      error={editFieldErrors.first_name}
                    >
                      <Input
                        id="edit-first-name"
                        value={editFirstName}
                        aria-invalid={Boolean(editFieldErrors.first_name)}
                        onChange={(e) => {
                          setEditFieldErrors((errs) => {
                            const n = { ...errs }
                            delete n.first_name
                            return n
                          })
                          setEditFirstName(e.target.value)
                        }}
                      />
                    </Field>
                    <Field
                      label="Last name"
                      htmlFor="edit-last-name"
                      required
                      error={editFieldErrors.last_name}
                    >
                      <Input
                        id="edit-last-name"
                        value={editLastName}
                        aria-invalid={Boolean(editFieldErrors.last_name)}
                        onChange={(e) => {
                          setEditFieldErrors((errs) => {
                            const n = { ...errs }
                            delete n.last_name
                            return n
                          })
                          setEditLastName(e.target.value)
                        }}
                      />
                    </Field>
                  </div>
                  <div>
                    <Label htmlFor="edit-email">Email</Label>
                    <Input
                      id="edit-email"
                      type="email"
                      value={editEmail}
                      onChange={(e) => setEditEmail(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-phone">Phone</Label>
                    <Input
                      id="edit-phone"
                      value={editPhone}
                      onChange={(e) => setEditPhone(e.target.value)}
                    />
                  </div>
                  <Field
                    label="Home branch"
                    htmlFor="edit-branch"
                    required
                    error={editFieldErrors.home_branch_id}
                  >
                    <Select
                      id="edit-branch"
                      value={editBranchId === '' ? '' : String(editBranchId)}
                      aria-invalid={Boolean(editFieldErrors.home_branch_id)}
                      onChange={(e) => {
                        setEditFieldErrors((errs) => {
                          const n = { ...errs }
                          delete n.home_branch_id
                          return n
                        })
                        setEditBranchId(e.target.value ? Number(e.target.value) : '')
                      }}
                    >
                      <option value="">Select branch…</option>
                      {branches.map((branch) => (
                        <option key={branch.id} value={branch.id}>
                          {branch.name}
                        </option>
                      ))}
                    </Select>
                  </Field>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label htmlFor="edit-gender">Gender</Label>
                      <Select
                        id="edit-gender"
                        value={editGender}
                        onChange={(e) => setEditGender(e.target.value)}
                      >
                        <option value="">Not specified</option>
                        <option value="female">Female</option>
                        <option value="male">Male</option>
                        <option value="other">Other</option>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="edit-dob">Date of birth</Label>
                      <Input
                        id="edit-dob"
                        type="date"
                        value={editDob}
                        onChange={(e) => setEditDob(e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="edit-joined">Joined on</Label>
                    <Input
                      id="edit-joined"
                      type="date"
                      value={editJoinedAt}
                      onChange={(e) => setEditJoinedAt(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-emergency-name">Emergency contact</Label>
                    <Input
                      id="edit-emergency-name"
                      value={editEmergencyName}
                      onChange={(e) => setEditEmergencyName(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="edit-emergency-phone">Emergency phone</Label>
                    <Input
                      id="edit-emergency-phone"
                      value={editEmergencyPhone}
                      onChange={(e) => setEditEmergencyPhone(e.target.value)}
                    />
                  </div>
                  <Button
                    type="submit"
                    size="sm"
                    loading={updateMutation.isPending}
                    disabled={!profileDirty}
                  >
                    Save profile
                  </Button>
                </form>
              ) : null}

              {canUpdate ? (
                <div className="space-y-2 border-t border-white/12 pt-4">
                  <p className="text-sm font-semibold text-ink">Status</p>
                  <div className="grid grid-cols-2 gap-2">
                    {(
                      [
                        { status: 'active' as const, label: 'Activate', icon: PlayCircle },
                        { status: 'lead' as const, label: 'Mark lead', icon: UserPlus },
                        { status: 'inactive' as const, label: 'Deactivate', icon: PauseCircle },
                        { status: 'blacklisted' as const, label: 'Blacklist', icon: Ban },
                      ] as const
                    ).map((action) => (
                      <Button
                        key={action.status}
                        size="sm"
                        variant={
                          action.status === 'blacklisted'
                            ? 'danger'
                            : selected.status === action.status
                              ? 'secondary'
                              : 'ghost'
                        }
                        disabled={selected.status === action.status || statusMutation.isPending}
                        loading={statusMutation.isPending}
                        onClick={() => void onChangeStatus(selected, action.status)}
                      >
                        <action.icon className="h-4 w-4" />
                        {action.label}
                      </Button>
                    ))}
                  </div>
                </div>
              ) : null}

              {canUpdate ? (
                <div className="border-t border-white/12 pt-4">
                  <Button
                    size="sm"
                    variant="danger"
                    loading={deleteMutation.isPending}
                    onClick={() => void onDelete(selected)}
                    className="w-full"
                  >
                    <Trash2 className="h-4 w-4" />
                    Remove member
                  </Button>
                </div>
              ) : null}
            </Card>
          </aside>
        ) : null}
      </div>
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}

function DetailRow({
  label,
  value,
  mono = false,
}: {
  label: string
  value: string
  mono?: boolean
}) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="shrink-0 text-muted">{label}</dt>
      <dd className={cn('text-right font-semibold text-ink', mono && 'font-mono text-xs')}>
        {value}
      </dd>
    </div>
  )
}
