import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Activity,
  CheckCircle2,
  ClipboardList,
  Scan,
  Search,
  ShieldAlert,
  UserCheck,
  X,
  XCircle,
} from 'lucide-react'
import {
  checkInMember,
  fetchAttendance,
  fetchAttendanceRecord,
  fetchCheckInEligibility,
  voidAttendance,
  type AttendanceRecord,
  type AttendanceStatus,
} from '@/api/attendance'
import { fetchMembers, type Member } from '@/api/members'
import { ApiError } from '@/api/client'
import { useAuth } from '@/auth/AuthContext'
import { useBranchFilter } from '@/hooks/useBranchFilter'
import { useFeedback } from '@/feedback/FeedbackProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Alert } from '@/components/ui/Alert'
import { Field } from '@/components/form/Field'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Select } from '@/components/ui/Select'
import { Textarea } from '@/components/ui/Textarea'
import { collectRequiredErrors, type FieldErrors } from '@/lib/formErrors'
import { Spinner } from '@/components/ui/Spinner'
import { DataTable, type Column } from '@/components/table/DataTable'
import { Pagination } from '@/components/table/Pagination'
import { formatDate, formatNumber } from '@/lib/format'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'
import { cn } from '@/lib/cn'

type PageTab = 'desk' | 'scan' | 'history'
type StatusFilter = '' | AttendanceStatus

function todayIso() {
  return new Date().toISOString().slice(0, 10)
}

function formatDateTime(value?: string | null): string {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return new Intl.DateTimeFormat(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date)
}

function memberLabel(m?: {
  first_name?: string
  last_name?: string
  member_code?: string
  full_name?: string
} | null) {
  if (!m) return '—'
  if (m.full_name) {
    return m.member_code ? `${m.full_name} (${m.member_code})` : m.full_name
  }
  const name = `${m.first_name ?? ''} ${m.last_name ?? ''}`.trim()
  return name ? `${name}${m.member_code ? ` (${m.member_code})` : ''}` : m.member_code || '—'
}

function methodLabel(method?: string | null) {
  switch (method) {
    case 'staff':
      return 'Staff'
    case 'qr':
      return 'QR'
    case 'code':
      return 'Code'
    default:
      return method || '—'
  }
}

export function AttendancePage() {
  const { branches, branchId, setBranchId, hasPermission } = useAuth()
  const { showSuccess, confirm } = useFeedback()
  const queryClient = useQueryClient()

  const canView = hasPermission('attendance.view')
  const canCheckIn = hasPermission('attendance.check_in')
  const canVoid = hasPermission('attendance.void')

  const [tab, setTab] = useState<PageTab>(canCheckIn ? 'desk' : 'history')
  const [deskBranchId, setDeskBranchId] = useBranchFilter()
  const [scanCode, setScanCode] = useState('')
  const [scanMethod, setScanMethod] = useState<'qr' | 'code'>('qr')
  const [scanBusy, setScanBusy] = useState(false)
  const [memberSearch, setMemberSearch] = useState('')
  const [appliedMemberSearch, setAppliedMemberSearch] = useState('')
  const [selectedMember, setSelectedMember] = useState<Member | null>(null)
  const [checkInNotes, setCheckInNotes] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})

  const clearFieldError = (key: string) => {
    setFieldErrors((prev) => {
      if (!prev[key]) return prev
      const { [key]: _, ...rest } = prev
      return rest
    })
  }
  const [lastCheckIn, setLastCheckIn] = useState<AttendanceRecord | null>(null)

  const [page, setPage] = useState(1)
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('valid')
  const [historyBranchId, setHistoryBranchId] = useBranchFilter()
  const [historyDate, setHistoryDate] = useState(todayIso())
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [voidReason, setVoidReason] = useState('')
  const [showVoidForm, setShowVoidForm] = useState(false)

  const effectiveDeskBranch =
    deskBranchId !== '' ? Number(deskBranchId) : branchId ?? branches[0]?.id ?? null

  const membersQuery = useQuery({
    queryKey: ['admin', 'members', 'attendance-search', appliedMemberSearch],
    queryFn: () =>
      fetchMembers({
        page: 1,
        per_page: 12,
        search: appliedMemberSearch,
        status: 'active',
      }),
    enabled: canCheckIn && (tab === 'desk' || tab === 'scan') && appliedMemberSearch.length > 0,
  })

  const eligibilityQuery = useQuery({
    queryKey: ['admin', 'attendance', 'eligibility', selectedMember?.id, effectiveDeskBranch],
    queryFn: () => fetchCheckInEligibility(selectedMember!.id, effectiveDeskBranch!),
    enabled: canCheckIn && selectedMember != null && effectiveDeskBranch != null,
    retry: false,
  })

  const historyQuery = useQuery({
    queryKey: [
      'admin',
      'attendance',
      'history',
      page,
      statusFilter,
      historyBranchId,
      historyDate,
    ],
    queryFn: () =>
      fetchAttendance({
        page,
        per_page: DEFAULT_PAGE_SIZE,
        status: statusFilter,
        branch_id: historyBranchId,
        date: historyDate || undefined,
      }),
    enabled: canView && tab === 'history',
  })

  const todayStatsQuery = useQuery({
    queryKey: ['admin', 'attendance', 'today-stats', effectiveDeskBranch],
    queryFn: async () => {
      const [all, valid, voided] = await Promise.all([
        fetchAttendance({
          page: 1,
          per_page: 1,
          date: todayIso(),
          branch_id: effectiveDeskBranch ?? '',
        }),
        fetchAttendance({
          page: 1,
          per_page: 1,
          date: todayIso(),
          status: 'valid',
          branch_id: effectiveDeskBranch ?? '',
        }),
        fetchAttendance({
          page: 1,
          per_page: 1,
          date: todayIso(),
          status: 'voided',
          branch_id: effectiveDeskBranch ?? '',
        }),
      ])
      return {
        total: all.meta.total,
        valid: valid.meta.total,
        voided: voided.meta.total,
      }
    },
    enabled: canView,
  })

  const selectedQuery = useQuery({
    queryKey: ['admin', 'attendance', 'detail', selectedId],
    queryFn: () => fetchAttendanceRecord(selectedId!),
    enabled: canView && selectedId != null && tab === 'history',
  })

  const rows = historyQuery.data?.data ?? []
  const meta = historyQuery.data?.meta
  const eligibility = eligibilityQuery.data
  const selected = useMemo(() => {
    if (selectedId == null) return null
    return selectedQuery.data ?? rows.find((row) => row.id === selectedId) ?? null
  }, [selectedId, selectedQuery.data, rows])

  useEffect(() => {
    setShowVoidForm(false)
    setVoidReason('')
  }, [selected?.id])

  const invalidate = async () => {
    await queryClient.invalidateQueries({ queryKey: ['admin', 'attendance'] })
  }

  const apiError = (err: unknown, fallback: string) =>
    err instanceof ApiError ? err.message : fallback

  const checkInMutation = useMutation({
    mutationFn: checkInMember,
    onSuccess: async (record) => {
      setError(null)
      showSuccess(`${memberLabel(record.member)} checked in.`)
      setLastCheckIn(record)
      setCheckInNotes('')
      await invalidate()
      await eligibilityQuery.refetch()
    },
    onError: (err) => setError(apiError(err, 'Unable to check in member.')),
  })

  const voidMutation = useMutation({
    mutationFn: (reason: string) => voidAttendance(selectedId!, reason || null),
    onSuccess: async (record) => {
      setError(null)
      showSuccess(`Attendance #${record.id} voided.`)
      setShowVoidForm(false)
      setVoidReason('')
      await invalidate()
    },
    onError: (err) => setError(apiError(err, 'Unable to void attendance.')),
  })

  const onSearchMembers = (event?: FormEvent) => {
    event?.preventDefault()
    setSelectedMember(null)
    setLastCheckIn(null)
    setError(null)
    setAppliedMemberSearch(memberSearch.trim())
  }

  const onSelectMember = (member: Member) => {
    setSelectedMember(member)
    setLastCheckIn(null)
    setError(null)
    setCheckInNotes('')
  }

  const onCheckIn = async (method: 'staff' | 'qr' | 'code' = 'staff') => {
    const errors = collectRequiredErrors([
      { key: 'selectedMember', label: 'Member', value: selectedMember?.id },
      { key: 'deskBranch', label: 'Branch', value: effectiveDeskBranch },
    ])
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors)
      return
    }
    setFieldErrors({})
    if (!selectedMember) return
    if (eligibility && !eligibility.allowed) {
      setError(eligibility.message || 'Member is not eligible to check in.')
      return
    }
    const ok = await confirm({
      title: 'Confirm check-in?',
      message: `Check in ${memberLabel(selectedMember)} at the selected branch?`,
      confirmLabel: 'Check in',
      tone: 'primary',
    })
    if (!ok) return
    checkInMutation.mutate({
      member_id: selectedMember.id,
      branch_id: effectiveDeskBranch,
      method,
      notes: checkInNotes.trim() || null,
    })
  }

  const parseCheckInPayload = (raw: string): string => {
    const value = raw.trim()
    if (!value) return ''
    // Expected QR payload: GMS|{tenantSlug}|{memberCode}
    if (value.toUpperCase().startsWith('GMS|')) {
      const parts = value.split('|')
      return (parts[2] ?? '').trim()
    }
    return value
  }

  const onScanSubmit = async (event?: FormEvent) => {
    event?.preventDefault()
    const code = parseCheckInPayload(scanCode)
    if (!code) {
      setError('Enter or scan a member QR / barcode / member code.')
      return
    }
    if (!effectiveDeskBranch) {
      setFieldErrors({ deskBranch: 'Branch is required' })
      return
    }
    setScanBusy(true)
    setError(null)
    try {
      const result = await fetchMembers({ search: code, per_page: 10, status: 'active' })
      const exact =
        result.data.find((m) => m.member_code?.toLowerCase() === code.toLowerCase()) ??
        result.data[0]
      if (!exact) {
        setError(`No active member found for “${code}”.`)
        return
      }
      setSelectedMember(exact)
      setAppliedMemberSearch(code)
      setScanCode('')
      const eligibilityResult = await fetchCheckInEligibility(
        exact.id,
        Number(effectiveDeskBranch),
      )
      if (!eligibilityResult.allowed) {
        setError(eligibilityResult.message || 'Member is not eligible to check in.')
        return
      }
      checkInMutation.mutate({
        member_id: exact.id,
        branch_id: Number(effectiveDeskBranch),
        method: scanMethod,
        notes: checkInNotes.trim() || null,
      })
    } catch (err) {
      setError(apiError(err, 'Unable to resolve scanned member.'))
    } finally {
      setScanBusy(false)
    }
  }

  const onVoid = async () => {
    if (!selected) return
    const ok = await confirm({
      title: 'Void attendance?',
      message: `Void check-in #${selected.id} for ${memberLabel(selected.member)}? Visit credits are restored when applicable.`,
      confirmLabel: 'Void check-in',
      tone: 'danger',
    })
    if (!ok) return
    voidMutation.mutate(voidReason.trim())
  }

  const columns: Column<AttendanceRecord>[] = [
    {
      key: 'time',
      header: 'Checked in',
      cell: (row) => (
        <button
          type="button"
          className="text-left transition hover:text-accent"
          onClick={() => setSelectedId(row.id)}
        >
          <p className="font-semibold text-ink">{formatDateTime(row.checked_in_at)}</p>
          <p className="mt-0.5 text-xs text-muted">#{row.id}</p>
        </button>
      ),
    },
    {
      key: 'member',
      header: 'Member',
      cell: (row) => (
        <div>
          <p className="text-sm font-medium text-ink">{memberLabel(row.member)}</p>
          <p className="text-xs text-muted">{row.membership?.plan?.name ?? '—'}</p>
        </div>
      ),
    },
    {
      key: 'branch',
      header: 'Branch',
      cell: (row) => <span className="text-sm text-ink">{row.branch?.name ?? '—'}</span>,
    },
    {
      key: 'method',
      header: 'Method',
      cell: (row) => <Badge tone="neutral">{methodLabel(row.method)}</Badge>,
    },
    {
      key: 'status',
      header: 'Status',
      cell: (row) => (
        <Badge tone={row.status === 'valid' ? 'success' : 'danger'}>
          {row.status === 'valid' ? 'Valid' : 'Voided'}
        </Badge>
      ),
    },
    {
      key: 'staff',
      header: 'Staff',
      cell: (row) => <span className="text-sm text-muted">{row.staff_user?.name ?? '—'}</span>,
    },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      cell: (row) => (
        <Button size="sm" variant="secondary" onClick={() => setSelectedId(row.id)}>
          Details
        </Button>
      ),
    },
  ]

  if (!canView) {
    return (
      <div className="animate-fade-up space-y-5">
        <PageHeader title="Attendance" description="Check-in desk and history." />
        <Alert tone="danger">You do not have permission to view attendance.</Alert>
      </div>
    )
  }

  const stats = todayStatsQuery.data
  const memberResults = membersQuery.data?.data ?? []

  return (
    <div className="animate-fade-up space-y-5">
      <PageHeader
        title="Attendance"
        description="Check-in desk and history for walk-in facility access."
        actions={<Badge tone="neutral">Gym</Badge>}
      />

      {error ? <Alert tone="danger">{error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-3">
        <SummaryChip
          icon={<Activity className="h-4 w-4" />}
          label="Today’s check-ins"
          value={formatNumber(stats?.total ?? 0)}
        />
        <SummaryChip
          icon={<CheckCircle2 className="h-4 w-4" />}
          label="Valid today"
          value={formatNumber(stats?.valid ?? 0)}
          tone="accent"
        />
        <SummaryChip
          icon={<XCircle className="h-4 w-4" />}
          label="Voided today"
          value={formatNumber(stats?.voided ?? 0)}
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {canCheckIn ? (
          <button
            type="button"
            onClick={() => {
              setTab('desk')
              setSelectedId(null)
              setError(null)
            }}
            className={cn(
              'rounded-xl px-3 py-2 text-sm font-semibold transition',
              tab === 'desk'
                ? 'bg-accent text-accent-ink'
                : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
            )}
          >
            Check-in desk
          </button>
        ) : null}
        {canCheckIn ? (
          <button
            type="button"
            onClick={() => {
              setTab('scan')
              setSelectedId(null)
              setError(null)
            }}
            className={cn(
              'rounded-xl px-3 py-2 text-sm font-semibold transition',
              tab === 'scan'
                ? 'bg-accent text-accent-ink'
                : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
            )}
          >
            QR / barcode
          </button>
        ) : null}
        <button
          type="button"
          onClick={() => {
            setTab('history')
            setError(null)
          }}
          className={cn(
            'rounded-xl px-3 py-2 text-sm font-semibold transition',
            tab === 'history'
              ? 'bg-accent text-accent-ink'
              : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
          )}
        >
          History
        </button>
      </div>

      {tab === 'scan' && canCheckIn ? (
        <div className="grid gap-4 xl:grid-cols-[1.1fr_0.9fr]">
          <Card className="border-accent/20">
            <CardTitle className="mb-1 flex items-center gap-2">
              <Scan className="h-4 w-4" /> QR / barcode check-in
            </CardTitle>
            <CardDescription className="mb-4">
              Scan the member QR card or type the member code / barcode. Payload format:{' '}
              <code className="rounded bg-white/10 px-1">GMS|tenant|MEM-CODE</code>
            </CardDescription>

            <Field label="Branch" htmlFor="scan-branch" error={fieldErrors.deskBranch}>
              <Select
                id="scan-branch"
                value={deskBranchId === '' ? '' : String(deskBranchId)}
                onChange={(e) => {
                  setDeskBranchId(e.target.value ? Number(e.target.value) : '')
                  clearFieldError('deskBranch')
                }}
              >
                <option value="">Select branch</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </Select>
            </Field>

            <form className="mt-4 space-y-4" onSubmit={(e) => void onScanSubmit(e)}>
              <Field label="Scan or enter code" htmlFor="scan-code">
                <Input
                  id="scan-code"
                  autoFocus
                  value={scanCode}
                  onChange={(e) => setScanCode(e.target.value)}
                  placeholder="Scan QR / barcode or type MEM-XXXXXXXX"
                />
              </Field>
              <Field label="Method" htmlFor="scan-method">
                <Select
                  id="scan-method"
                  value={scanMethod}
                  onChange={(e) => setScanMethod(e.target.value as 'qr' | 'code')}
                >
                  <option value="qr">QR</option>
                  <option value="code">Barcode / code</option>
                </Select>
              </Field>
              <Field label="Notes (optional)" htmlFor="scan-notes">
                <Textarea
                  id="scan-notes"
                  value={checkInNotes}
                  onChange={(e) => setCheckInNotes(e.target.value)}
                  rows={2}
                  placeholder="Optional note"
                />
              </Field>
              <Button type="submit" loading={scanBusy || checkInMutation.isPending}>
                Check in from scan
              </Button>
            </form>
          </Card>

          <Card>
            <CardTitle className="mb-1">Last check-in</CardTitle>
            <CardDescription className="mb-4">Result of the most recent scan</CardDescription>
            {lastCheckIn ? (
              <div className="space-y-2 text-sm">
                <p className="font-semibold text-ink">{memberLabel(lastCheckIn.member)}</p>
                <p className="text-muted">{formatDateTime(lastCheckIn.checked_in_at)}</p>
                <Badge tone="accent">{methodLabel(lastCheckIn.method)}</Badge>
              </div>
            ) : (
              <p className="text-sm text-muted">No scan check-in yet in this session.</p>
            )}
          </Card>
        </div>
      ) : null}

      {tab === 'desk' && canCheckIn ? (
        <div className="grid gap-4 xl:grid-cols-[1.1fr_0.9fr]">
          <Card className="border-accent/20">
            <CardTitle className="mb-1">Find member</CardTitle>
            <CardDescription className="mb-4">
              Search by name, member code, email, or phone, then verify eligibility before
              check-in.
            </CardDescription>

            <div className="mb-4 grid gap-3 sm:grid-cols-2">
              <Field
                label="Branch"
                htmlFor="desk-branch"
                required
                error={fieldErrors.deskBranch}
              >
                <Select
                  id="desk-branch"
                  value={effectiveDeskBranch != null ? String(effectiveDeskBranch) : ''}
                  onChange={(e) => {
                    const next = e.target.value ? Number(e.target.value) : ''
                    setDeskBranchId(next)
                    if (typeof next === 'number') setBranchId(next)
                    setLastCheckIn(null)
                    clearFieldError('deskBranch')
                  }}
                  aria-invalid={Boolean(fieldErrors.deskBranch)}
                >
                  {branches.length === 0 ? <option value="">No branches</option> : null}
                  {branches.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.name}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
            {fieldErrors.selectedMember ? (
              <p className="mb-4 text-xs font-medium text-danger" role="alert">
                {fieldErrors.selectedMember}
              </p>
            ) : null}

            <form onSubmit={onSearchMembers} className="mb-4 flex flex-col gap-2 sm:flex-row">
              <div className="relative min-w-0 flex-1">
                <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
                <Input
                  value={memberSearch}
                  onChange={(e) => setMemberSearch(e.target.value)}
                  placeholder="Name, code, email, phone…"
                  className="pl-10"
                  aria-label="Search members"
                />
              </div>
              <Button type="submit" variant="secondary">
                Search
              </Button>
            </form>

            {appliedMemberSearch && membersQuery.isPending ? (
              <div className="flex justify-center py-10">
                <Spinner label="Searching members…" />
              </div>
            ) : null}

            {appliedMemberSearch && !membersQuery.isPending ? (
              memberResults.length === 0 ? (
                <p className="rounded-xl border border-white/10 bg-white/[0.04] px-4 py-6 text-center text-sm text-muted">
                  No active members match “{appliedMemberSearch}”.
                </p>
              ) : (
                <div className="max-h-80 space-y-2 overflow-y-auto">
                  {memberResults.map((member) => {
                    const active = selectedMember?.id === member.id
                    return (
                      <button
                        key={member.id}
                        type="button"
                        onClick={() => {
                          onSelectMember(member)
                          clearFieldError('selectedMember')
                        }}
                        className={cn(
                          'w-full rounded-xl border px-3 py-3 text-left transition',
                          active
                            ? 'border-accent/40 bg-accent/15'
                            : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.07]',
                        )}
                      >
                        <p className="font-semibold text-ink">{member.full_name}</p>
                        <p className="mt-0.5 text-xs text-muted">
                          {member.member_code}
                          {member.phone ? ` · ${member.phone}` : ''}
                          {member.email ? ` · ${member.email}` : ''}
                        </p>
                      </button>
                    )
                  })}
                </div>
              )
            ) : null}

            {!appliedMemberSearch ? (
              <div className="rounded-xl border border-dashed border-white/15 px-4 py-10 text-center">
                <UserCheck className="mx-auto mb-3 h-8 w-8 text-muted" />
                <p className="text-sm text-muted">
                  Start typing a member name or code to open the check-in desk.
                </p>
              </div>
            ) : null}
          </Card>

          <Card className="sticky top-4 h-fit space-y-4">
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                <ClipboardList className="h-5 w-5" />
              </div>
              <div>
                <CardTitle className="text-base">Eligibility</CardTitle>
                <CardDescription>
                  {selectedMember
                    ? memberLabel(selectedMember)
                    : 'Select a member to verify access.'}
                </CardDescription>
              </div>
            </div>

            {!selectedMember ? (
              <p className="rounded-xl border border-white/10 bg-white/[0.04] px-3 py-4 text-sm text-muted">
                Choose a member from search results to see membership and walk-in rules.
              </p>
            ) : eligibilityQuery.isPending ? (
              <div className="flex justify-center py-8">
                <Spinner label="Checking eligibility…" />
              </div>
            ) : eligibilityQuery.isError ? (
              <Alert tone="danger">
                {eligibilityQuery.error instanceof ApiError
                  ? eligibilityQuery.error.message
                  : 'Unable to check eligibility.'}
              </Alert>
            ) : eligibility ? (
              <>
                <div
                  className={cn(
                    'rounded-xl border px-3 py-3',
                    eligibility.allowed
                      ? 'border-success/30 bg-success/10'
                      : 'border-danger/30 bg-danger/10',
                  )}
                >
                  <div className="mb-1 flex items-center gap-2">
                    {eligibility.allowed ? (
                      <CheckCircle2 className="h-4 w-4 text-success" />
                    ) : (
                      <ShieldAlert className="h-4 w-4 text-danger" />
                    )}
                    <p className="text-sm font-semibold text-ink">
                      {eligibility.allowed ? 'Eligible to check in' : 'Not eligible'}
                    </p>
                  </div>
                  <p className="text-sm text-muted">{eligibility.message}</p>
                  {eligibility.code ? (
                    <p className="mt-1 font-mono text-xs text-muted">{eligibility.code}</p>
                  ) : null}
                </div>

                <dl className="space-y-2 text-sm">
                  <DetailRow
                    label="Membership"
                    value={
                      eligibility.membership
                        ? `${eligibility.membership.plan?.name ?? 'Plan'} (${eligibility.membership.status})`
                        : '—'
                    }
                  />
                  <DetailRow
                    label="Period"
                    value={
                      eligibility.membership
                        ? `${formatDate(eligibility.membership.start_date)} → ${formatDate(eligibility.membership.end_date)}`
                        : '—'
                    }
                  />
                  <DetailRow
                    label="Visits left"
                    value={
                      eligibility.visits_remaining != null
                        ? formatNumber(eligibility.visits_remaining)
                        : eligibility.membership?.visits_remaining != null
                          ? formatNumber(eligibility.membership.visits_remaining)
                          : 'Unlimited / n/a'
                    }
                  />
                  <DetailRow
                    label="Walk-in"
                    value={
                      eligibility.membership?.plan?.allows_walkin === false ? 'Not allowed' : 'Allowed'
                    }
                  />
                </dl>

                <div>
                  <Label htmlFor="checkin-notes">Notes (optional)</Label>
                  <Textarea
                    id="checkin-notes"
                    value={checkInNotes}
                    onChange={(e) => setCheckInNotes(e.target.value)}
                    rows={2}
                    placeholder="Front desk note…"
                  />
                </div>

                <Button
                  className="w-full"
                  loading={checkInMutation.isPending}
                  disabled={!eligibility.allowed || effectiveDeskBranch == null}
                  onClick={() => void onCheckIn()}
                >
                  <UserCheck className="h-4 w-4" />
                  Check in
                </Button>
              </>
            ) : null}

            {lastCheckIn ? (
              <div className="rounded-xl border border-accent/25 bg-accent/10 px-3 py-3">
                <p className="text-sm font-semibold text-ink">Last check-in</p>
                <p className="mt-1 text-sm text-muted">
                  #{lastCheckIn.id} · {formatDateTime(lastCheckIn.checked_in_at)} ·{' '}
                  {lastCheckIn.branch?.name}
                </p>
                <Button
                  size="sm"
                  variant="secondary"
                  className="mt-3"
                  onClick={() => {
                    setTab('history')
                    setHistoryDate(todayIso())
                    setStatusFilter('valid')
                    setSelectedId(lastCheckIn.id)
                  }}
                >
                  View in history
                </Button>
              </div>
            ) : null}
          </Card>
        </div>
      ) : null}

      {tab === 'history' ? (
        <>
          <Card>
            <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
              <div className="flex flex-wrap gap-2">
                {(
                  [
                    { value: '' as StatusFilter, label: 'All' },
                    { value: 'valid' as StatusFilter, label: 'Valid' },
                    { value: 'voided' as StatusFilter, label: 'Voided' },
                  ] as const
                ).map((filter) => {
                  const active = statusFilter === filter.value
                  return (
                    <button
                      key={filter.label}
                      type="button"
                      onClick={() => {
                        setStatusFilter(filter.value)
                        setPage(1)
                        setSelectedId(null)
                      }}
                      className={cn(
                        'rounded-xl px-3 py-2 text-sm font-semibold transition',
                        active
                          ? 'bg-accent text-accent-ink'
                          : 'bg-white/8 text-muted hover:bg-white/12 hover:text-ink',
                      )}
                    >
                      {filter.label}
                    </button>
                  )
                })}
              </div>
              <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
                <div>
                  <Label htmlFor="history-date">Date</Label>
                  <Input
                    id="history-date"
                    type="date"
                    value={historyDate}
                    onChange={(e) => {
                      setHistoryDate(e.target.value)
                      setPage(1)
                      setSelectedId(null)
                    }}
                  />
                </div>
                <div>
                  <Label htmlFor="history-branch">Branch</Label>
                  <Select
                    id="history-branch"
                    value={historyBranchId === '' ? '' : String(historyBranchId)}
                    onChange={(e) => {
                      setHistoryBranchId(e.target.value ? Number(e.target.value) : '')
                      setPage(1)
                      setSelectedId(null)
                    }}
                    className="sm:w-48"
                  >
                    <option value="">All branches</option>
                    {branches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                  </Select>
                </div>
              </div>
            </div>
          </Card>

          <div className={cn('grid gap-4', selectedId != null ? 'xl:grid-cols-[1fr_24rem]' : '')}>
            <div className="min-w-0">
              {historyQuery.isPending ? (
                <div className="flex justify-center py-20">
                  <Spinner label="Loading attendance…" />
                </div>
              ) : historyQuery.isError ? (
                <Alert tone="danger">
                  {historyQuery.error instanceof ApiError
                    ? historyQuery.error.message
                    : 'Unable to load attendance history.'}
                  <div className="mt-3">
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => void historyQuery.refetch()}
                    >
                      Try again
                    </Button>
                  </div>
                </Alert>
              ) : (
                <>
                  <DataTable
                    columns={columns}
                    rows={rows}
                    rowKey={(row) => row.id}
                    emptyTitle="No attendance records"
                    emptyDescription="No check-ins match these filters. Try another date or branch."
                  />
                  <Pagination
                    meta={meta}
                    onPageChange={(next) => {
                      setPage(next)
                      setSelectedId(null)
                    }}
                  />
                </>
              )}
            </div>

            {selectedId != null && !selected && selectedQuery.isPending ? (
              <aside className="animate-slide-in">
                <Card className="sticky top-4">
                  <div className="flex justify-center py-12">
                    <Spinner label="Loading record…" />
                  </div>
                </Card>
              </aside>
            ) : null}

            {selected ? (
              <aside className="animate-slide-in">
                <Card className="sticky top-4 space-y-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/20 text-accent">
                        <Activity className="h-5 w-5" />
                      </div>
                      <CardTitle className="truncate text-base">
                        {memberLabel(selected.member)}
                      </CardTitle>
                      <CardDescription>Attendance #{selected.id}</CardDescription>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setSelectedId(null)}
                      aria-label="Close details"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Badge tone={selected.status === 'valid' ? 'success' : 'danger'}>
                      {selected.status === 'valid' ? 'Valid' : 'Voided'}
                    </Badge>
                    <Badge tone="neutral">{methodLabel(selected.method)}</Badge>
                  </div>

                  <dl className="space-y-2 text-sm">
                    <DetailRow label="Checked in" value={formatDateTime(selected.checked_in_at)} />
                    <DetailRow label="Branch" value={selected.branch?.name ?? '—'} />
                    <DetailRow
                      label="Plan"
                      value={selected.membership?.plan?.name ?? '—'}
                    />
                    <DetailRow
                      label="Visits left"
                      value={
                        selected.membership?.visits_remaining != null
                          ? formatNumber(selected.membership.visits_remaining)
                          : '—'
                      }
                    />
                    <DetailRow label="Staff" value={selected.staff_user?.name ?? '—'} />
                    {selected.notes ? <DetailRow label="Notes" value={selected.notes} /> : null}
                    {selected.void_reason ? (
                      <DetailRow label="Void reason" value={selected.void_reason} />
                    ) : null}
                  </dl>

                  {canVoid && selected.status === 'valid' ? (
                    <div className="space-y-3 border-t border-white/12 pt-4">
                      {!showVoidForm ? (
                        <Button
                          size="sm"
                          variant="danger"
                          className="w-full"
                          onClick={() => setShowVoidForm(true)}
                        >
                          Void check-in
                        </Button>
                      ) : (
                        <>
                          <div>
                            <Label htmlFor="void-reason">Reason (optional)</Label>
                            <Textarea
                              id="void-reason"
                              value={voidReason}
                              onChange={(e) => setVoidReason(e.target.value)}
                              rows={2}
                            />
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="danger"
                              loading={voidMutation.isPending}
                              onClick={() => void onVoid()}
                            >
                              Confirm void
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setShowVoidForm(false)}
                            >
                              Cancel
                            </Button>
                          </div>
                        </>
                      )}
                    </div>
                  ) : null}
                </Card>
              </aside>
            ) : null}
          </div>
        </>
      ) : null}
    </div>
  )
}

function SummaryChip({
  icon,
  label,
  value,
  tone = 'neutral',
}: {
  icon: ReactNode
  label: string
  value: string
  tone?: 'neutral' | 'accent'
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-3 rounded-2xl border px-4 py-3',
        tone === 'accent'
          ? 'border-accent/25 bg-accent/10'
          : 'border-white/12 bg-white/[0.04]',
      )}
    >
      <div
        className={cn(
          'flex h-9 w-9 items-center justify-center rounded-xl',
          tone === 'accent' ? 'bg-accent/20 text-accent' : 'bg-white/10 text-muted',
        )}
      >
        {icon}
      </div>
      <div>
        <p className="text-xs font-medium text-muted">{label}</p>
        <p className="text-lg font-semibold text-ink">{value}</p>
      </div>
    </div>
  )
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2">
      <dt className="shrink-0 text-muted">{label}</dt>
      <dd className="text-right font-semibold text-ink">{value}</dd>
    </div>
  )
}
