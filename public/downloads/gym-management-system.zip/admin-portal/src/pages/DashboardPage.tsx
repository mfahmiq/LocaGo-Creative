import { useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  Activity,
  CreditCard,
  UserRound,
  Users,
} from 'lucide-react'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { DataTable, type Column } from '@/components/table/DataTable'
import { SimpleBarChart } from '@/components/charts/SimpleBarChart'
import { SimpleLineChart } from '@/components/charts/SimpleLineChart'
import { Alert } from '@/components/ui/Alert'
import { Spinner } from '@/components/ui/Spinner'
import { useAuth } from '@/auth/AuthContext'
import { fetchReportCatalog, runReport } from '@/api/reports'
import { fetchMembershipDashboardAlerts } from '@/api/memberships'
import { formatNumber } from '@/lib/format'
import { cn } from '@/lib/cn'
import { PlatformDashboardPage } from '@/pages/platform/PlatformDashboardPage'

type SnapshotRow = {
  id: string
  label: string
  value: string
}

export function DashboardPage() {
  const { user, tenant, portal, branchId, hasPermission } = useAuth()

  if (portal === 'platform') {
    return <PlatformDashboardPage />
  }

  const canViewReports = hasPermission('reports.view')
  const canViewMemberships = hasPermission('memberships.instances.view')
  const reportBranch = branchId ?? undefined

  const catalogQuery = useQuery({
    queryKey: ['reports', 'catalog'],
    queryFn: fetchReportCatalog,
    enabled: canViewReports,
  })

  const membersQuery = useQuery({
    queryKey: ['reports', 'run', 'members_summary', branchId],
    queryFn: () => runReport('members_summary', { branch_id: reportBranch }),
    enabled: canViewReports,
  })

  const membershipsQuery = useQuery({
    queryKey: ['reports', 'run', 'memberships_summary', branchId],
    queryFn: () => runReport('memberships_summary', { branch_id: reportBranch }),
    enabled: canViewReports,
  })

  const attendanceQuery = useQuery({
    queryKey: ['reports', 'run', 'attendance_summary', branchId],
    queryFn: () => runReport('attendance_summary', { branch_id: reportBranch }),
    enabled: canViewReports,
  })

  const invoicesQuery = useQuery({
    queryKey: ['reports', 'run', 'invoices_summary', branchId],
    queryFn: () => runReport('invoices_summary', { branch_id: reportBranch }),
    enabled: canViewReports,
  })

  const alertsQuery = useQuery({
    queryKey: ['memberships', 'dashboard-alerts', branchId],
    queryFn: fetchMembershipDashboardAlerts,
    enabled: canViewMemberships,
  })

  const loading =
    canViewReports &&
    (catalogQuery.isLoading ||
      membersQuery.isLoading ||
      membershipsQuery.isLoading ||
      attendanceQuery.isLoading ||
      invoicesQuery.isLoading)

  const summary = useMemo(() => {
    const members = membersQuery.data?.summary ?? {}
    const memberships = membershipsQuery.data?.summary ?? {}
    const attendance = attendanceQuery.data?.summary ?? {}
    const invoices = invoicesQuery.data?.summary ?? {}

    const num = (value: unknown) => {
      const n = typeof value === 'number' ? value : Number(value)
      return Number.isFinite(n) ? n : 0
    }

    const byStatus = members.by_status as unknown as Record<string, number> | undefined

    return {
      members: num(members.total),
      activeMembers: num(byStatus?.active ?? members.active),
      memberships: num(memberships.total),
      checkIns: num(attendance.total ?? attendance.check_ins),
      invoices: num(invoices.total),
      collected: num(invoices.amount_paid ?? invoices.paid_total),
    }
  }, [membersQuery.data, membershipsQuery.data, attendanceQuery.data, invoicesQuery.data])

  const barData = [
    { label: 'Members', value: summary.members },
    { label: 'Active', value: summary.activeMembers },
    { label: 'Plans', value: summary.memberships },
    { label: 'Check-ins', value: summary.checkIns },
  ]

  const lineData = [
    { label: 'Mon', value: Math.max(2, Math.round(summary.checkIns * 0.12)) },
    { label: 'Tue', value: Math.max(3, Math.round(summary.checkIns * 0.18)) },
    { label: 'Wed', value: Math.max(4, Math.round(summary.checkIns * 0.22)) },
    { label: 'Thu', value: Math.max(3, Math.round(summary.checkIns * 0.16)) },
    { label: 'Fri', value: Math.max(5, Math.round(summary.checkIns * 0.2)) },
    { label: 'Sat', value: Math.max(4, Math.round(summary.checkIns * 0.08)) },
    { label: 'Sun', value: Math.max(2, Math.round(summary.checkIns * 0.04)) },
  ]

  const snapshotRows: SnapshotRow[] = [
    { id: '1', label: 'Total members', value: formatNumber(summary.members) },
    { id: '2', label: 'Active members', value: formatNumber(summary.activeMembers) },
    { id: '3', label: 'Memberships', value: formatNumber(summary.memberships) },
    { id: '4', label: 'Attendance records', value: formatNumber(summary.checkIns) },
    { id: '5', label: 'Invoices tracked', value: formatNumber(summary.invoices) },
  ]

  const columns: Column<SnapshotRow>[] = [
    { key: 'label', header: 'Metric', cell: (row) => row.label },
    {
      key: 'value',
      header: 'Value',
      className: 'text-right font-semibold',
      cell: (row) => row.value,
    },
  ]

  const alerts = alertsQuery.data
  const showAlerts =
    canViewMemberships &&
    alerts &&
    (alerts.expiring_soon.count > 0 ||
      alerts.grace.count > 0 ||
      alerts.escalations.open_count > 0)

  return (
    <div className="animate-fade-up">
      <PageHeader
        title={`Welcome back, ${user?.name?.split(' ')[0] ?? 'team'}`}
        description={`${tenant?.name ?? 'Your gym'} — today’s operations snapshot.`}
        actions={<Badge tone="accent">Live floor</Badge>}
      />

      {!canViewReports ? (
        <Alert tone="info" className="mb-6">
          Your role can sign in, but does not include reports.view. Dashboard charts stay empty until
          that permission is granted.
        </Alert>
      ) : null}

      {showAlerts ? (
        <div className="mb-6 grid gap-3 lg:grid-cols-3">
          {alerts.expiring_soon.count > 0 ? (
            <Alert tone="info">
              <p className="font-semibold">
                {formatNumber(alerts.expiring_soon.count)} expiring within{' '}
                {alerts.expiring_soon.within_days} days
              </p>
              <p className="mt-1 text-xs opacity-80">
                {alerts.expiring_soon.sample
                  .slice(0, 2)
                  .map((row) => `${row.member_name || 'Member'} (${row.end_date ?? '—'})`)
                  .join(' · ') || 'Open memberships list to renew.'}
              </p>
            </Alert>
          ) : null}
          {alerts.grace.count > 0 ? (
            <Alert tone="info">
              <p className="font-semibold">{formatNumber(alerts.grace.count)} in grace</p>
              <p className="mt-1 text-xs opacity-80">Follow up before they expire fully.</p>
            </Alert>
          ) : null}
          {alerts.escalations.open_count > 0 ? (
            <Alert tone="danger">
              <p className="font-semibold">
                {formatNumber(alerts.escalations.open_count)} open escalations
              </p>
              <p className="mt-1 text-xs opacity-80">
                {Object.entries(alerts.escalations.by_tier)
                  .filter(([, count]) => count > 0)
                  .map(([tier, count]) => `${tier}: ${count}`)
                  .join(' · ')}
              </p>
            </Alert>
          ) : null}
        </div>
      ) : null}

      {loading ? (
        <div className="flex justify-center py-20">
          <Spinner label="Loading dashboard…" />
        </div>
      ) : (
        <>
          <div className="mb-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard
              label="Members"
              value={formatNumber(summary.members)}
              hint="All statuses"
              icon={Users}
            />
            <StatCard
              label="Active members"
              value={formatNumber(summary.activeMembers)}
              hint="Ready to train"
              icon={UserRound}
              accent
            />
            <StatCard
              label="Memberships"
              value={formatNumber(summary.memberships)}
              hint="Plan instances"
              icon={CreditCard}
            />
            <StatCard
              label="Check-ins"
              value={formatNumber(summary.checkIns)}
              hint="Attendance rows"
              icon={Activity}
            />
          </div>

          <div className="mb-6 grid gap-4 xl:grid-cols-2">
            <SimpleBarChart
              title="Operations mix"
              description="Live counts from report summaries"
              data={barData}
            />
            <SimpleLineChart
              title="Attendance pulse"
              description="Weekly shape from current check-in volume"
              data={lineData}
            />
          </div>

          <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
            <DataTable
              columns={columns}
              rows={snapshotRows}
              rowKey={(row) => row.id}
              emptyTitle="No metrics yet"
              emptyDescription="Run reports once data exists in this tenant."
            />
            <Card>
              <CardTitle>Available reports</CardTitle>
              <CardDescription>Catalog from the reporting API</CardDescription>
              <ul className="mt-4 space-y-2.5">
                {(catalogQuery.data ?? []).slice(0, 6).map((report) => (
                  <li
                    key={report.key}
                    className="rounded-xl border border-white/12 bg-white/6 px-3 py-2.5 transition hover:border-accent/35 hover:bg-accent-soft/50"
                  >
                    <p className="text-sm font-semibold text-ink">{report.name}</p>
                    <p className="text-xs text-muted">{report.key}</p>
                  </li>
                ))}
                {!catalogQuery.data?.length ? (
                  <li className="text-sm text-muted">No report keys returned.</li>
                ) : null}
              </ul>
            </Card>
          </div>
        </>
      )}
    </div>
  )
}

function StatCard({
  label,
  value,
  hint,
  icon: Icon,
  accent = false,
}: {
  label: string
  value: string
  hint: string
  icon: typeof Users
  accent?: boolean
}) {
  return (
    <Card className={cn('relative overflow-hidden', accent && 'border-accent/35')}>
      <div
        className={cn(
          'absolute -right-6 -top-6 h-24 w-24 rounded-full opacity-70',
          accent ? 'bg-accent/20' : 'bg-white/10',
        )}
      />
      <div className="relative flex items-start justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-muted">{label}</p>
          <p className="mt-2 font-display text-4xl font-bold tracking-wide text-ink">{value}</p>
          <p className="mt-1 text-xs text-muted">{hint}</p>
        </div>
        <div
          className={cn(
            'flex h-10 w-10 items-center justify-center rounded-xl',
            accent ? 'bg-accent text-accent-ink' : 'bg-white/12 text-ink',
          )}
        >
          <Icon className="h-4 w-4" />
        </div>
      </div>
    </Card>
  )
}
