import type { PaginationMeta } from '@/api/types'

/** Default page size for all list UIs and API requests. */
export const DEFAULT_PAGE_SIZE = 10

export function paginateItems<T>(
  items: T[],
  page: number,
  perPage: number = DEFAULT_PAGE_SIZE,
): { rows: T[]; meta: PaginationMeta } {
  const total = items.length
  const lastPage = Math.max(1, Math.ceil(total / Math.max(perPage, 1)))
  const currentPage = Math.min(Math.max(1, page), lastPage)
  const start = (currentPage - 1) * perPage

  return {
    rows: items.slice(start, start + perPage),
    meta: {
      current_page: currentPage,
      per_page: perPage,
      total,
      last_page: lastPage,
    },
  }
}

export function emptyPaginationMeta(perPage: number = DEFAULT_PAGE_SIZE): PaginationMeta {
  return {
    current_page: 1,
    per_page: perPage,
    total: 0,
    last_page: 1,
  }
}
