export type FieldErrors = Record<string, string>

export function isBlank(value: unknown): boolean {
  if (value == null) return true
  if (typeof value === 'string') return value.trim() === ''
  if (typeof value === 'number') return Number.isNaN(value)
  if (Array.isArray(value)) return value.length === 0
  return false
}

export function requiredError(label: string): string {
  return `${label} is required.`
}

/**
 * Build inline field errors for mandatory values.
 * Only includes keys that fail the blank check.
 */
export function collectRequiredErrors(
  fields: Array<{
    key: string
    label: string
    value: unknown
    /** Defaults to true */
    required?: boolean
  }>,
): FieldErrors {
  const errors: FieldErrors = {}
  for (const field of fields) {
    if (field.required === false) continue
    if (isBlank(field.value)) {
      errors[field.key] = requiredError(field.label)
    }
  }
  return errors
}

export function firstFieldError(errors: FieldErrors): string | null {
  const key = Object.keys(errors)[0]
  return key ? errors[key] : null
}
