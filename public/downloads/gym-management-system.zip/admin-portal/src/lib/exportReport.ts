import { jsPDF } from 'jspdf'
import autoTable from 'jspdf-autotable'
import { env } from '@/config/env'

export type ExportColumn<T> = {
  key: string
  header: string
  value: (row: T) => string | number | null | undefined
}

export type ExportHistoryEntry = {
  id: string
  reportKey: string
  reportName: string
  format: 'excel' | 'pdf'
  createdAt: string
  rowCount: number
  fileName: string
}

const EXPORT_HISTORY_KEY = 'gms.platform.reportExports'

function escapeCsv(value: string | number | null | undefined): string {
  const raw = value == null ? '' : String(value)
  if (/[",\n\r]/.test(raw)) {
    return `"${raw.replace(/"/g, '""')}"`
  }
  return raw
}

function stamp(): string {
  const d = new Date()
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}`
}

function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = fileName
  anchor.click()
  URL.revokeObjectURL(url)
}

function rememberExport(entry: Omit<ExportHistoryEntry, 'id' | 'createdAt'>) {
  const next: ExportHistoryEntry = {
    ...entry,
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: new Date().toISOString(),
  }
  const current = readExportHistory()
  const merged = [next, ...current].slice(0, 40)
  localStorage.setItem(EXPORT_HISTORY_KEY, JSON.stringify(merged))
  return next
}

export function readExportHistory(): ExportHistoryEntry[] {
  try {
    const raw = localStorage.getItem(EXPORT_HISTORY_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw) as ExportHistoryEntry[]
    return Array.isArray(parsed) ? parsed : []
  } catch {
    return []
  }
}

export function clearExportHistory() {
  localStorage.removeItem(EXPORT_HISTORY_KEY)
}

export function exportRowsToExcel<T>(
  reportKey: string,
  reportName: string,
  columns: ExportColumn<T>[],
  rows: T[],
) {
  const header = columns.map((c) => escapeCsv(c.header)).join(',')
  const body = rows
    .map((row) => columns.map((c) => escapeCsv(c.value(row))).join(','))
    .join('\r\n')
  const csv = `\uFEFF${header}\r\n${body}`
  const fileName = `${reportKey}-${stamp()}.csv`
  downloadBlob(new Blob([csv], { type: 'text/csv;charset=utf-8' }), fileName)
  rememberExport({
    reportKey,
    reportName,
    format: 'excel',
    rowCount: rows.length,
    fileName,
  })
  return fileName
}

function cellText(value: string | number | null | undefined): string {
  if (value == null) return ''
  return String(value)
}

export function exportRowsToPdf<T>(
  reportKey: string,
  reportName: string,
  columns: ExportColumn<T>[],
  rows: T[],
  subtitle?: string,
) {
  const fileName = `${reportKey}-${stamp()}.pdf`
  const generatedAt = new Date().toLocaleString()
  const landscape = columns.length > 5
  const doc = new jsPDF({
    orientation: landscape ? 'landscape' : 'portrait',
    unit: 'pt',
    format: 'a4',
  })

  const marginX = 40
  let cursorY = 44

  doc.setFont('helvetica', 'bold')
  doc.setFontSize(16)
  doc.setTextColor(17, 17, 17)
  doc.text(reportName, marginX, cursorY)
  cursorY += 18

  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9)
  doc.setTextColor(85, 85, 85)
  const metaParts = [
    env.appName,
    'Reports',
    subtitle || null,
    `Generated ${generatedAt}`,
    `${rows.length} row(s)`,
  ].filter(Boolean)
  const metaLines = doc.splitTextToSize(metaParts.join(' · '), doc.internal.pageSize.getWidth() - marginX * 2)
  doc.text(metaLines, marginX, cursorY)
  cursorY += metaLines.length * 12 + 10

  autoTable(doc, {
    startY: cursorY,
    head: [columns.map((c) => c.header)],
    body:
      rows.length > 0
        ? rows.map((row) => columns.map((c) => cellText(c.value(row))))
        : [columns.map((_, index) => (index === 0 ? 'No rows' : ''))],
    margin: { left: marginX, right: marginX, top: 36, bottom: 40 },
    styles: {
      font: 'helvetica',
      fontSize: 8,
      cellPadding: 5,
      textColor: [17, 17, 17],
      lineColor: [208, 213, 221],
      lineWidth: 0.5,
      overflow: 'linebreak',
      valign: 'top',
    },
    headStyles: {
      fillColor: [242, 244, 247],
      textColor: [17, 17, 17],
      fontStyle: 'bold',
      lineColor: [208, 213, 221],
    },
    alternateRowStyles: {
      fillColor: [250, 250, 250],
    },
    didDrawPage: (data) => {
      const pageWidth = doc.internal.pageSize.getWidth()
      const pageHeight = doc.internal.pageSize.getHeight()
      const pageNumber = doc.getNumberOfPages()
      doc.setFont('helvetica', 'normal')
      doc.setFontSize(8)
      doc.setTextColor(102, 112, 133)
      doc.text(
        `${env.appName} · ${reportName}`,
        data.settings.margin.left,
        pageHeight - 18,
      )
      doc.text(`Page ${pageNumber}`, pageWidth - data.settings.margin.right, pageHeight - 18, {
        align: 'right',
      })
    },
  })

  doc.save(fileName)

  rememberExport({
    reportKey,
    reportName,
    format: 'pdf',
    rowCount: rows.length,
    fileName,
  })
  return fileName
}
