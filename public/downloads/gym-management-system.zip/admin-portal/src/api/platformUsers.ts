import { api } from '@/api/client'
import type { AdminUser, ApiSuccess } from '@/api/types'

export type PlatformUser = AdminUser

export type CreatePlatformUserPayload = {
  name: string
  email: string
  password: string
  password_confirmation: string
  phone?: string | null
  is_active?: boolean
  role_ids?: number[]
}

export type UpdatePlatformUserPayload = {
  name?: string
  email?: string
  phone?: string | null
  is_active?: boolean
  password?: string
  password_confirmation?: string
}

export async function fetchPlatformUsers() {
  const { data } = await api.get<ApiSuccess<PlatformUser[]>>('/platform/users')
  return data.data
}

export async function fetchPlatformUser(userId: number) {
  const { data } = await api.get<ApiSuccess<PlatformUser>>(`/platform/users/${userId}`)
  return data.data
}

export async function createPlatformUser(payload: CreatePlatformUserPayload) {
  const { data } = await api.post<ApiSuccess<PlatformUser>>('/platform/users', payload)
  return data.data
}

export async function updatePlatformUser(userId: number, payload: UpdatePlatformUserPayload) {
  const { data } = await api.put<ApiSuccess<PlatformUser>>(`/platform/users/${userId}`, payload)
  return data.data
}

export async function syncPlatformUserRoles(userId: number, roleIds: number[]) {
  const { data } = await api.put<ApiSuccess<PlatformUser>>(`/platform/users/${userId}/roles`, {
    role_ids: roleIds,
  })
  return data.data
}
