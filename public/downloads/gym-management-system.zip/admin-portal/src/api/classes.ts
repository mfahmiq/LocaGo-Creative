import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type ClassType = {
  id: number
  tenant_id: number
  code: string
  name: string
  category: string | null
  default_duration_minutes: number
  default_capacity: number
  waitlist_enabled: boolean
  is_active: boolean
  created_at?: string | null
  updated_at?: string | null
}

export type ClassScheduleStatus = 'scheduled' | 'cancelled' | 'completed'
export type WaitlistMode = 'auto' | 'manual' | 'both'
export type BookingStatus = 'booked' | 'cancelled' | 'attended' | 'no_show'
export type WaitlistStatus = 'waiting' | 'offered' | 'promoted' | 'expired' | 'cancelled'
export type ClassAttendanceStatus = 'attended' | 'no_show'

export type ClassSchedule = {
  id: number
  tenant_id: number
  branch_id: number
  branch?: { id: number; code: string; name: string }
  class_type_id: number
  class_type?: {
    id: number
    code: string
    name: string
    waitlist_enabled: boolean
  }
  instructor_user_id: number | null
  instructor?: { id: number; name: string; email: string } | null
  room_id: number | null
  room?: { id: number; name: string } | null
  starts_at: string | null
  ends_at: string | null
  capacity: number
  booked_count: number
  waitlist_count: number
  waitlist_mode: WaitlistMode | string
  status: ClassScheduleStatus
  recurrence_group_id: string | number | null
  created_at?: string | null
  updated_at?: string | null
}

export type ClassBooking = {
  id: number
  tenant_id: number
  class_schedule_id: number
  member_id: number
  member?: {
    id: number
    member_code: string
    first_name: string
    last_name: string
  }
  membership_id: number | null
  status: BookingStatus
  booked_at: string | null
  cancelled_at: string | null
  cancel_reason: string | null
  source: string
  created_at?: string | null
}

export type ClassWaitlistEntry = {
  id: number
  tenant_id: number
  class_schedule_id: number
  member_id: number
  member?: {
    id: number
    member_code: string
    first_name: string
    last_name: string
  }
  position: number
  status: WaitlistStatus
  promoted_booking_id: number | null
  created_at?: string | null
}

export type BookClassResult =
  | { type: 'booking'; booking: ClassBooking }
  | { type: 'waitlist'; waitlist: ClassWaitlistEntry }

export type ClassAttendanceMark = {
  id: number
  class_schedule_id: number
  class_booking_id: number
  member_id: number
  status: ClassAttendanceStatus
  marked_at: string | null
}

export type ClassTypeListParams = {
  page?: number
  per_page?: number
  search?: string
  is_active?: boolean | ''
}

export type ClassScheduleListParams = {
  page?: number
  per_page?: number
  branch_id?: number | ''
  class_type_id?: number | ''
  status?: ClassScheduleStatus | ''
  date?: string
  from?: string
  to?: string
}

export type CreateClassTypePayload = {
  code: string
  name: string
  category?: string | null
  default_duration_minutes?: number | null
  default_capacity?: number | null
  waitlist_enabled?: boolean
  is_active?: boolean
}

export type UpdateClassTypePayload = Partial<CreateClassTypePayload>

export type CreateClassSchedulePayload = {
  branch_id: number
  class_type_id: number
  instructor_user_id?: number | null
  room_id?: number | null
  starts_at: string
  ends_at?: string | null
  capacity?: number | null
  waitlist_mode?: WaitlistMode
  recurrence?: { frequency: 'weekly'; count?: number } | null
}

async function listMeta<T>(
  path: string,
  params: Record<string, unknown>,
): Promise<{ data: T[]; meta: PaginationMeta }> {
  const { data } = await api.get<ApiSuccess<T[]> & { meta: PaginationMeta }>(path, { params })
  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchClassTypes(params: ClassTypeListParams = {}) {
  return listMeta<ClassType>('/admin/class-types', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    search: params.search || undefined,
    is_active:
      params.is_active === '' || params.is_active === undefined
        ? undefined
        : params.is_active
          ? 1
          : 0,
  })
}

export async function createClassType(payload: CreateClassTypePayload) {
  const { data } = await api.post<ApiSuccess<ClassType>>('/admin/class-types', payload)
  return data.data
}

export async function updateClassType(typeId: number, payload: UpdateClassTypePayload) {
  const { data } = await api.put<ApiSuccess<ClassType>>(`/admin/class-types/${typeId}`, payload)
  return data.data
}

export async function deleteClassType(typeId: number) {
  const { data } = await api.delete<ApiSuccess<null>>(`/admin/class-types/${typeId}`)
  return data.message
}

export async function fetchClassSchedules(params: ClassScheduleListParams = {}) {
  return listMeta<ClassSchedule>('/admin/class-schedules', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    branch_id: params.branch_id || undefined,
    class_type_id: params.class_type_id || undefined,
    status: params.status || undefined,
    date: params.date || undefined,
    from: params.from || undefined,
    to: params.to || undefined,
  })
}

export async function fetchClassSchedule(scheduleId: number) {
  const { data } = await api.get<ApiSuccess<ClassSchedule>>(`/admin/class-schedules/${scheduleId}`)
  return data.data
}

export async function createClassSchedules(payload: CreateClassSchedulePayload) {
  const { data } = await api.post<ApiSuccess<ClassSchedule | ClassSchedule[]>>(
    '/admin/class-schedules',
    payload,
  )
  return Array.isArray(data.data) ? data.data : [data.data]
}

export async function cancelClassSchedule(scheduleId: number) {
  const { data } = await api.post<ApiSuccess<ClassSchedule>>(
    `/admin/class-schedules/${scheduleId}/cancel`,
  )
  return data.data
}

export async function fetchClassRoster(scheduleId: number) {
  const { data } = await api.get<ApiSuccess<ClassBooking[]>>(
    `/admin/class-schedules/${scheduleId}/roster`,
  )
  return data.data
}

export async function fetchClassWaitlist(scheduleId: number) {
  const { data } = await api.get<ApiSuccess<ClassWaitlistEntry[]>>(
    `/admin/class-schedules/${scheduleId}/waitlist`,
  )
  return data.data
}

export async function bookClassForMember(payload: {
  class_schedule_id: number
  member_id: number
  waitlist_if_full?: boolean
}) {
  const { data } = await api.post<ApiSuccess<BookClassResult>>('/admin/bookings', payload)
  return data.data
}

export async function cancelClassBooking(bookingId: number, reason?: string | null) {
  const { data } = await api.post<ApiSuccess<ClassBooking>>(`/admin/bookings/${bookingId}/cancel`, {
    reason: reason || undefined,
  })
  return data.data
}

export async function markClassAttendance(
  bookingId: number,
  status: ClassAttendanceStatus,
) {
  const { data } = await api.post<ApiSuccess<ClassAttendanceMark>>(
    `/admin/bookings/${bookingId}/attendance`,
    { status },
  )
  return data.data
}

export async function promoteWaitlistEntry(waitlistId: number) {
  const { data } = await api.post<ApiSuccess<ClassBooking>>(
    `/admin/waitlist/${waitlistId}/promote`,
  )
  return data.data
}
