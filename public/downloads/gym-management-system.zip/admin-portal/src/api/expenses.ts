import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type ExpenseStatus = 'recorded' | 'approved' | 'rejected' | 'void'

export type Expense = {
  id: number
  tenant_id: number
  branch_id: number | null
  branch?: { id: number; name: string; code: string } | null
  category: string
  vendor_name: string | null
  amount: string | number
  tax_amount: string | number
  currency_code: string
  expense_date: string
  status: ExpenseStatus
  receipt_path: string | null
  maintenance_order_id: number | null
  notes: string | null
  created_at?: string | null
  updated_at?: string | null
}

export type ExpensePayload = {
  branch_id?: number | null
  category: string
  vendor_name?: string | null
  amount: number
  tax_amount?: number | null
  currency_code?: string
  expense_date: string
  receipt_path?: string | null
  maintenance_order_id?: number | null
  notes?: string | null
}

async function listMeta<T>(
  path: string,
  params: Record<string, unknown>,
): Promise<{ data: T[]; meta: PaginationMeta }> {
  const { data } = await api.get<ApiSuccess<T[]> & { meta: PaginationMeta }>(path, { params })
  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchExpenses(params: {
  page?: number
  per_page?: number
  status?: ExpenseStatus | ''
  category?: string
  branch_id?: number | ''
  from?: string
  to?: string
  search?: string
} = {}) {
  return listMeta<Expense>('/admin/expenses', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    status: params.status || undefined,
    category: params.category || undefined,
    branch_id: params.branch_id || undefined,
    from: params.from || undefined,
    to: params.to || undefined,
    search: params.search || undefined,
  })
}

export async function fetchExpense(expenseId: number) {
  const { data } = await api.get<ApiSuccess<Expense>>(`/admin/expenses/${expenseId}`)
  return data.data
}

export async function createExpense(payload: ExpensePayload) {
  const { data } = await api.post<ApiSuccess<Expense>>('/admin/expenses', payload)
  return data.data
}

export async function updateExpense(expenseId: number, payload: Partial<ExpensePayload>) {
  const { data } = await api.put<ApiSuccess<Expense>>(`/admin/expenses/${expenseId}`, payload)
  return data.data
}

export async function deleteExpense(expenseId: number) {
  await api.delete(`/admin/expenses/${expenseId}`)
}

export async function approveExpense(expenseId: number) {
  const { data } = await api.post<ApiSuccess<Expense>>(`/admin/expenses/${expenseId}/approve`)
  return data.data
}

export async function rejectExpense(expenseId: number) {
  const { data } = await api.post<ApiSuccess<Expense>>(`/admin/expenses/${expenseId}/reject`)
  return data.data
}

export async function voidExpense(expenseId: number) {
  const { data } = await api.post<ApiSuccess<Expense>>(`/admin/expenses/${expenseId}/void`)
  return data.data
}
