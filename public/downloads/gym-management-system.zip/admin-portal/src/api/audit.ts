import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type AuditActor = {
  id: number
  name: string
  email: string
}

export type AuditLog = {
  id: number
  tenant_id: number | null
  actor_user_id: number | null
  branch_id: number | null
  action: string
  entity_type: string
  entity_id: number | null
  old_values: Record<string, unknown> | null
  new_values: Record<string, unknown> | null
  ip_address: string | null
  user_agent: string | null
  created_at: string | null
  actor?: AuditActor | null
}

export type AuditSummary = {
  total: number
  last_24h: number
  unique_actions: number
  unique_actors: number
}

export type AuditListParams = {
  page?: number
  per_page?: number
  q?: string
  action?: string
  entity_type?: string
  actor_user_id?: number | ''
  from?: string
  to?: string
}

export type AuditListResult = {
  data: AuditLog[]
  meta: PaginationMeta
  summary: AuditSummary
}

export async function fetchAuditLogs(params: AuditListParams = {}): Promise<AuditListResult> {
  const { data } = await api.get<
    ApiSuccess<AuditLog[]> & {
      meta: PaginationMeta
      summary: AuditSummary
    }
  >('/admin/audit-logs', {
    params: {
      page: params.page ?? 1,
      per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
      q: params.q || undefined,
      action: params.action || undefined,
      entity_type: params.entity_type || undefined,
      actor_user_id: params.actor_user_id || undefined,
      from: params.from || undefined,
      to: params.to || undefined,
    },
  })

  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
    summary: data.summary ?? {
      total: 0,
      last_24h: 0,
      unique_actions: 0,
      unique_actors: 0,
    },
  }
}

export async function fetchAuditLog(id: number) {
  const { data } = await api.get<ApiSuccess<AuditLog>>(`/admin/audit-logs/${id}`)
  return data.data
}
