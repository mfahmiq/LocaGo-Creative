import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type BranchStaffMember = {
  id: number
  name: string
  email: string
  is_active: boolean
}

export type Branch = {
  id: number
  tenant_id: number
  code: string
  name: string
  phone: string | null
  email: string | null
  address_line1: string | null
  address_line2: string | null
  city: string | null
  state: string | null
  postal_code: string | null
  country_code: string
  timezone: string | null
  capacity: number | null
  is_active: boolean
  staff_count?: number
  staff?: BranchStaffMember[]
  created_at?: string | null
  updated_at?: string | null
}

export type BranchSummary = {
  total: number
  active: number
  inactive: number
}

export type BranchPayload = {
  code: string
  name: string
  phone?: string | null
  email?: string | null
  address_line1?: string | null
  address_line2?: string | null
  city?: string | null
  state?: string | null
  postal_code?: string | null
  country_code?: string
  timezone?: string | null
  capacity?: number | null
  is_active?: boolean
}

export type BranchListResult = {
  data: Branch[]
  meta: PaginationMeta
  summary: BranchSummary
}

export async function fetchBranches(params: {
  page?: number
  per_page?: number
  search?: string
  is_active?: boolean | ''
} = {}): Promise<BranchListResult> {
  const { data } = await api.get<
    ApiSuccess<Branch[]> & { meta: PaginationMeta; summary: BranchSummary }
  >('/admin/branches', {
    params: {
      page: params.page ?? 1,
      per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
      search: params.search || undefined,
      is_active:
        params.is_active === '' || params.is_active === undefined
          ? undefined
          : params.is_active
            ? 1
            : 0,
    },
  })

  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
    summary: data.summary ?? { total: 0, active: 0, inactive: 0 },
  }
}

export async function fetchBranch(branchId: number) {
  const { data } = await api.get<ApiSuccess<Branch>>(`/admin/branches/${branchId}`)
  return data.data
}

export async function createBranch(payload: BranchPayload) {
  const { data } = await api.post<ApiSuccess<Branch>>('/admin/branches', payload)
  return data.data
}

export async function updateBranch(branchId: number, payload: Partial<BranchPayload>) {
  const { data } = await api.put<ApiSuccess<Branch>>(`/admin/branches/${branchId}`, payload)
  return data.data
}

export async function deleteBranch(branchId: number) {
  const { data } = await api.delete<ApiSuccess<null>>(`/admin/branches/${branchId}`)
  return data.message
}

export async function changeBranchStatus(branchId: number, isActive: boolean) {
  const { data } = await api.patch<ApiSuccess<Branch>>(`/admin/branches/${branchId}/status`, {
    is_active: isActive,
  })
  return data.data
}

export async function fetchBranchStaff(branchId: number) {
  const { data } = await api.get<ApiSuccess<BranchStaffMember[]>>(
    `/admin/branches/${branchId}/staff`,
  )
  return data.data
}

export async function syncBranchStaff(branchId: number, userIds: number[]) {
  const { data } = await api.put<
    ApiSuccess<{ branch: Branch; staff: BranchStaffMember[] }>
  >(`/admin/branches/${branchId}/staff`, { user_ids: userIds })
  return data.data
}

export async function fetchEntitlements() {
  const { data } = await api.get<
    ApiSuccess<{
      plan: { id: number; code: string; name: string } | null
      limits: {
        max_seats: number
        max_branches: number
        max_members: number
        storage_mb: number
      } | null
      usage: { seats: number; branches: number; members: number }
      modules: Record<string, boolean>
    }>
  >('/admin/entitlements')
  return data.data
}
