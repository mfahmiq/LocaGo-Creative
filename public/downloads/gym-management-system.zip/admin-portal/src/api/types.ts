export type ApiSuccess<T> = {
  success: true
  message: string
  data: T
  meta?: PaginationMeta
}

export type ApiErrorBody = {
  success?: false
  message?: string
  code?: string
  errors?: Record<string, string[]>
  data?: Record<string, unknown>
}

export type PaginationMeta = {
  current_page: number
  per_page: number
  total: number
  last_page: number
}

export type AdminRole = {
  id: number
  code: string
  name: string
}

export type AdminUser = {
  id: number
  tenant_id: number | null
  name: string
  email: string
  phone?: string | null
  user_type: string
  is_active: boolean
  email_verified_at?: string | null
  last_login_at?: string | null
  roles?: AdminRole[]
  permissions?: string[]
}

export type TenantSummary = {
  id: number
  name: string
  slug: string
  status?: string
  base_currency?: string
  primary_country?: string
  timezone?: string
}

export type BranchSummary = {
  id: number
  code: string
  name: string
}

export type PortalKind = 'admin' | 'platform'

export type LoginResponse = {
  token: string
  token_type: string
  portal: PortalKind
  user: AdminUser
  tenant: TenantSummary | null
  branches: BranchSummary[]
  is_tenant_wide: boolean
}

export type ReportRunResult = {
  report_key: string
  report_name?: string
  name?: string
  generated_at?: string
  filters?: {
    from?: string | null
    to?: string | null
    branch_id?: number | null
  }
  summary?: Record<string, unknown>
  rows?: Array<Record<string, unknown>>
}
