import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type MembershipStatus =
  | 'pending'
  | 'active'
  | 'grace'
  | 'frozen'
  | 'expired'
  | 'cancelled'

export type MembershipDisplayStatus = MembershipStatus | 'expiring_soon'

export type MembershipMemberSummary = {
  id: number
  member_code: string
  first_name: string
  last_name: string
  email: string | null
}

export type MembershipPlanSummary = {
  id: number
  code: string
  name: string
  plan_type: string
}

export type MembershipBranchSummary = {
  id: number
  code: string
  name: string
}

export type Membership = {
  id: number
  tenant_id: number
  member_id: number
  member?: MembershipMemberSummary
  membership_plan_id: number
  plan?: MembershipPlanSummary
  branch_id: number | null
  branch?: MembershipBranchSummary | null
  status: MembershipStatus
  display_status: MembershipDisplayStatus
  days_until_end: number | null
  is_expiring_soon: boolean
  start_date: string | null
  end_date: string | null
  visits_remaining: number | null
  price_snapshot: string | number
  currency_code: string
  activated_at: string | null
  cancelled_at: string | null
  cancel_reason: string | null
  notes: string | null
  created_at?: string | null
  updated_at?: string | null
}

export type MembershipListParams = {
  page?: number
  per_page?: number
  status?: MembershipDisplayStatus | ''
  member_id?: number | ''
  membership_plan_id?: number | ''
  expiring_days?: number | ''
}

export type MembershipListResult = {
  data: Membership[]
  meta: PaginationMeta
}

export type CreateMembershipPayload = {
  member_id: number
  membership_plan_id: number
  branch_id?: number | null
  start_date?: string | null
  end_date?: string | null
  activate_now?: boolean
  notes?: string | null
}

export type FreezeMembershipPayload = {
  start_date: string
  end_date: string
  extends_end_date?: boolean
  reason?: string | null
}

export type RenewMembershipPayload = {
  membership_plan_id?: number | null
  start_mode?: 'from_end_date' | 'today'
  start_date?: string | null
  notes?: string | null
}

export type ChangePlanPayload = {
  membership_plan_id: number
  start_mode?: 'from_end_date' | 'today'
  start_date?: string | null
  notes?: string | null
}

export type MembershipEscalation = {
  id: number
  tenant_id: number
  membership_id: number
  member_id: number
  member?: MembershipMemberSummary
  membership?: {
    id: number
    status: MembershipStatus
    end_date: string | null
    plan?: { id: number; name: string; code: string } | null
  }
  tier: string
  status: 'open' | 'acked' | 'resolved'
  assigned_user_id: number | null
  assigned_user?: { id: number; name: string; email: string } | null
  reason: string | null
  opened_at: string | null
  acked_at: string | null
  resolved_at: string | null
  created_at?: string | null
  updated_at?: string | null
}

export type MembershipAlertSample = {
  id: number
  member_id: number
  member_name: string
  end_date: string | null
  plan: string | null
  display_status: string
}

export type MembershipDashboardAlerts = {
  expiring_soon: {
    count: number
    within_days: number
    sample: MembershipAlertSample[]
  }
  grace: { count: number }
  expired: { count: number }
  escalations: {
    open_count: number
    by_tier: Record<string, number>
  }
}

export async function fetchMembershipDashboardAlerts() {
  const { data } = await api.get<ApiSuccess<MembershipDashboardAlerts>>(
    '/admin/memberships/dashboard-alerts',
  )
  return data.data
}

export async function fetchMemberships(
  params: MembershipListParams = {},
): Promise<MembershipListResult> {
  const { data } = await api.get<ApiSuccess<Membership[]> & { meta: PaginationMeta }>(
    '/admin/memberships',
    {
      params: {
        page: params.page ?? 1,
        per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
        status: params.status || undefined,
        member_id: params.member_id || undefined,
        membership_plan_id: params.membership_plan_id || undefined,
        expiring_days: params.expiring_days || undefined,
      },
    },
  )

  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchMembership(membershipId: number) {
  const { data } = await api.get<ApiSuccess<Membership>>(`/admin/memberships/${membershipId}`)
  return data.data
}

export async function createMembership(payload: CreateMembershipPayload) {
  const { data } = await api.post<ApiSuccess<Membership>>('/admin/memberships', payload)
  return data.data
}

export async function activateMembership(membershipId: number) {
  const { data } = await api.post<ApiSuccess<Membership>>(
    `/admin/memberships/${membershipId}/activate`,
  )
  return data.data
}

export async function cancelMembership(membershipId: number, reason?: string | null) {
  const { data } = await api.post<ApiSuccess<Membership>>(
    `/admin/memberships/${membershipId}/cancel`,
    { reason: reason || undefined },
  )
  return data.data
}

export async function freezeMembership(membershipId: number, payload: FreezeMembershipPayload) {
  const { data } = await api.post<ApiSuccess<Membership>>(
    `/admin/memberships/${membershipId}/freeze`,
    payload,
  )
  return data.data
}

export async function unfreezeMembership(membershipId: number) {
  const { data } = await api.post<ApiSuccess<Membership>>(
    `/admin/memberships/${membershipId}/unfreeze`,
  )
  return data.data
}

export async function renewMembership(membershipId: number, payload: RenewMembershipPayload = {}) {
  const { data } = await api.post<ApiSuccess<Membership>>(
    `/admin/memberships/${membershipId}/renew`,
    payload,
  )
  return data.data
}

export async function upgradeMembership(membershipId: number, payload: ChangePlanPayload) {
  const { data } = await api.post<ApiSuccess<Membership>>(
    `/admin/memberships/${membershipId}/upgrade`,
    payload,
  )
  return data.data
}

export async function downgradeMembership(membershipId: number, payload: ChangePlanPayload) {
  const { data } = await api.post<ApiSuccess<Membership>>(
    `/admin/memberships/${membershipId}/downgrade`,
    payload,
  )
  return data.data
}

export async function fetchMembershipEscalations(params: {
  page?: number
  per_page?: number
  status?: string
  tier?: string
  membership_id?: number
} = {}) {
  const { data } = await api.get<
    ApiSuccess<MembershipEscalation[]> & { meta: PaginationMeta }
  >('/admin/memberships/escalations', {
    params: {
      page: params.page ?? 1,
      per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
      status: params.status || undefined,
      tier: params.tier || undefined,
      membership_id: params.membership_id || undefined,
    },
  })

  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function ackMembershipEscalation(escalationId: number) {
  const { data } = await api.post<ApiSuccess<MembershipEscalation>>(
    `/admin/memberships/escalations/${escalationId}/ack`,
  )
  return data.data
}

export async function resolveMembershipEscalation(escalationId: number) {
  const { data } = await api.post<ApiSuccess<MembershipEscalation>>(
    `/admin/memberships/escalations/${escalationId}/resolve`,
  )
  return data.data
}
