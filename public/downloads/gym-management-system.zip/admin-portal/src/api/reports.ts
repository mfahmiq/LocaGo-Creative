import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta, ReportRunResult } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type ReportCatalogItem = {
  key: string
  name: string
  description?: string
}

export type ReportFilters = {
  from?: string | null
  to?: string | null
  branch_id?: number | null
}

export type ReportExportStatus = 'queued' | 'processing' | 'completed' | 'failed'

export type ReportExport = {
  id: number
  tenant_id: number
  requested_by: number
  requester?: { id: number; name: string; email: string } | null
  report_key: string
  filters: ReportFilters
  status: ReportExportStatus
  file_path: string | null
  error_message: string | null
  started_at: string | null
  finished_at: string | null
  created_at?: string | null
  updated_at?: string | null
}

export type ReportRunParams = {
  from?: string
  to?: string
  branch_id?: number | ''
}

function cleanParams(params?: ReportRunParams): Record<string, string | number> | undefined {
  if (!params) return undefined
  const next: Record<string, string | number> = {}
  if (params.from) next.from = params.from
  if (params.to) next.to = params.to
  if (params.branch_id) next.branch_id = params.branch_id
  return Object.keys(next).length ? next : undefined
}

export async function fetchReportCatalog() {
  const { data } = await api.get<ApiSuccess<ReportCatalogItem[]>>('/admin/reports')
  return data.data
}

export async function runReport(reportKey: string, params?: ReportRunParams) {
  const { data } = await api.get<ApiSuccess<ReportRunResult>>(
    `/admin/reports/run/${reportKey}`,
    { params: cleanParams(params) },
  )
  return data.data
}

export async function fetchReportExports(params: { page?: number; per_page?: number } = {}) {
  const { data } = await api.get<ApiSuccess<ReportExport[]> & { meta: PaginationMeta }>(
    '/admin/report-exports',
    {
      params: {
        page: params.page ?? 1,
        per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
      },
    },
  )
  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchReportExport(exportId: number) {
  const { data } = await api.get<ApiSuccess<ReportExport>>(`/admin/report-exports/${exportId}`)
  return data.data
}

export async function createReportExport(payload: {
  report_key: string
  filters?: ReportFilters
}) {
  const { data } = await api.post<ApiSuccess<ReportExport>>('/admin/report-exports', {
    report_key: payload.report_key,
    filters: {
      from: payload.filters?.from || undefined,
      to: payload.filters?.to || undefined,
      branch_id: payload.filters?.branch_id || undefined,
    },
  })
  return data.data
}

export async function downloadReportExport(exportId: number) {
  const response = await api.get(`/admin/report-exports/${exportId}/download`, {
    responseType: 'blob',
  })
  const disposition = response.headers['content-disposition'] as string | undefined
  const match = disposition?.match(/filename="?([^"]+)"?/i)
  const fileName = match?.[1] || `report-export-${exportId}.csv`
  const blob = response.data as Blob
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = fileName
  anchor.click()
  URL.revokeObjectURL(url)
  return fileName
}
