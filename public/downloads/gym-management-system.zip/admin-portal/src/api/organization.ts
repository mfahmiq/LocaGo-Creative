import { api } from '@/api/client'
import type { ApiSuccess } from '@/api/types'

export type OrganizationBranding = {
  primary_color: string | null
  accent_color: string | null
  support_email: string | null
}

export type OrganizationSettings = {
  website: string | null
  tagline: string | null
  branding: OrganizationBranding
}

export type Organization = {
  id: number
  slug: string
  name: string
  legal_name: string | null
  status: string
  primary_country: string
  base_currency: string
  timezone: string
  logo_path: string | null
  phone: string | null
  email: string | null
  trial_ends_at: string | null
  suspended_at: string | null
  created_at?: string | null
  updated_at?: string | null
  settings: OrganizationSettings
  plan: { id: number; code: string; name: string } | null
  limits: {
    max_seats: number
    max_branches: number
    max_members: number
    storage_mb: number
  } | null
  usage: { seats: number; branches: number; members: number }
  modules: Record<string, boolean>
}

export type OrganizationUpdatePayload = {
  name?: string
  legal_name?: string | null
  email?: string | null
  phone?: string | null
  logo_path?: string | null
  primary_country?: string
  base_currency?: string
  timezone?: string
  settings?: {
    website?: string | null
    tagline?: string | null
    branding?: {
      primary_color?: string | null
      accent_color?: string | null
      support_email?: string | null
    }
  }
}

export async function fetchOrganization() {
  const { data } = await api.get<ApiSuccess<Organization>>('/admin/organization')
  return data.data
}

export async function updateOrganization(payload: OrganizationUpdatePayload) {
  const { data } = await api.put<ApiSuccess<Organization>>('/admin/organization', payload)
  return data.data
}
