import { api } from '@/api/client'
import type {
  ApiSuccess,
  AdminUser,
  BranchSummary,
  LoginResponse,
  PortalKind,
  TenantSummary,
} from '@/api/types'
import { authStorage } from '@/auth/storage'

export type LoginPayload = {
  email: string
  password: string
  device_name?: string
  /** Optional — only for disambiguating the same email across tenants. */
  tenantSlug?: string
}

type MePayload = {
  portal?: PortalKind
  user: AdminUser
  tenant:
    | TenantSummary
    | {
        id: number
        slug: string
        attributes?: Record<string, unknown> | null
      }
    | null
  branches?: BranchSummary[]
  is_tenant_wide?: boolean
}

function normalizeTenant(tenant: MePayload['tenant']): TenantSummary | null {
  if (!tenant) return null
  if ('name' in tenant && typeof tenant.name === 'string') {
    return tenant
  }

  const attributes = 'attributes' in tenant ? tenant.attributes : undefined
  return {
    id: tenant.id,
    slug: tenant.slug,
    name:
      typeof attributes?.name === 'string'
        ? attributes.name
        : tenant.slug,
    status: typeof attributes?.status === 'string' ? attributes.status : undefined,
    base_currency:
      typeof attributes?.base_currency === 'string' ? attributes.base_currency : undefined,
    primary_country:
      typeof attributes?.primary_country === 'string' ? attributes.primary_country : undefined,
    timezone: typeof attributes?.timezone === 'string' ? attributes.timezone : undefined,
  }
}

export async function loginAdmin(payload: LoginPayload): Promise<LoginResponse> {
  const headers: Record<string, string> = {}
  if (payload.tenantSlug) {
    headers['X-Tenant-Slug'] = payload.tenantSlug
  }

  const { data } = await api.post<ApiSuccess<LoginResponse>>(
    '/admin/auth/login',
    {
      email: payload.email,
      password: payload.password,
      device_name: payload.device_name ?? 'admin-portal',
    },
    { headers },
  )
  return data.data
}

export async function fetchSessionMe() {
  const portal = authStorage.getPortal()
  const path = portal === 'platform' ? '/platform/auth/me' : '/admin/auth/me'
  const { data } = await api.get<ApiSuccess<MePayload>>(path)
  return {
    portal: data.data.portal ?? portal ?? 'admin',
    user: data.data.user,
    tenant: normalizeTenant(data.data.tenant),
    branches: data.data.branches ?? [],
    isTenantWide: Boolean(data.data.is_tenant_wide),
  }
}

export async function logoutSession() {
  const portal = authStorage.getPortal()
  const path = portal === 'platform' ? '/platform/auth/logout' : '/admin/auth/logout'
  await api.post(path)
}

export type ChangePasswordPayload = {
  current_password: string
  password: string
  password_confirmation: string
}

export async function changePassword(payload: ChangePasswordPayload) {
  const portal = authStorage.getPortal()
  const path =
    portal === 'platform' ? '/platform/auth/change-password' : '/admin/auth/change-password'
  const { data } = await api.post<ApiSuccess<null>>(path, payload)
  return data.message
}
