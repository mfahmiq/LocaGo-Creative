import { api } from '@/api/client'
import type { AdminRole, AdminUser, ApiSuccess, BranchSummary, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type StaffUser = AdminUser & {
  roles?: AdminRole[]
  branches?: BranchSummary[]
}

export type StaffListParams = {
  page?: number
  per_page?: number
  search?: string
  is_active?: boolean | ''
  role_id?: number | ''
}

export type StaffListResult = {
  data: StaffUser[]
  meta: PaginationMeta
}

export type CreateStaffPayload = {
  name: string
  email: string
  password: string
  password_confirmation: string
  phone?: string | null
  is_active?: boolean
  role_ids?: number[]
  branch_ids?: number[]
}

export type UpdateStaffPayload = {
  name?: string
  email?: string
  phone?: string | null
  is_active?: boolean
  password?: string
  password_confirmation?: string
}

export async function fetchStaff(params: StaffListParams = {}): Promise<StaffListResult> {
  const { data } = await api.get<ApiSuccess<StaffUser[]> & { meta: PaginationMeta }>(
    '/admin/staff',
    {
      params: {
        page: params.page ?? 1,
        per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
        search: params.search || undefined,
        is_active:
          params.is_active === '' || params.is_active === undefined
            ? undefined
            : params.is_active
              ? 1
              : 0,
        role_id: params.role_id || undefined,
      },
    },
  )

  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchStaffUser(userId: number) {
  const { data } = await api.get<ApiSuccess<StaffUser>>(`/admin/staff/${userId}`)
  return data.data
}

export async function createStaff(payload: CreateStaffPayload) {
  const { data } = await api.post<ApiSuccess<StaffUser>>('/admin/staff', payload)
  return data.data
}

export async function updateStaff(userId: number, payload: UpdateStaffPayload) {
  const { data } = await api.put<ApiSuccess<StaffUser>>(`/admin/staff/${userId}`, payload)
  return data.data
}

export async function syncStaffRoles(userId: number, roleIds: number[]) {
  const { data } = await api.put<ApiSuccess<StaffUser>>(`/admin/staff/${userId}/roles`, {
    role_ids: roleIds,
  })
  return data.data
}

export async function syncStaffBranches(userId: number, branchIds: number[]) {
  const { data } = await api.put<ApiSuccess<StaffUser>>(`/admin/staff/${userId}/branches`, {
    branch_ids: branchIds,
  })
  return data.data
}
