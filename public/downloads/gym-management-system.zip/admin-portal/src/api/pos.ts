import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type SaleStatus = 'completed' | 'void'

export type Product = {
  id: number
  tenant_id: number
  sku: string
  name: string
  description: string | null
  unit_price: string | number
  currency_code: string
  tax_rate_id: number | null
  low_stock_threshold: number
  is_active: boolean
  stocks?: ProductStock[]
  created_at?: string | null
  updated_at?: string | null
}

export type ProductStock = {
  id: number
  product_id: number
  branch_id: number
  branch?: { id: number; code: string; name: string } | null
  quantity: number
  updated_at?: string | null
}

export type SaleItem = {
  id: number
  product_id: number | null
  description: string
  quantity: number | string
  unit_price: string | number
  discount_amount: string | number
  tax_amount: string | number
  line_total: string | number
  product?: { id: number; sku: string; name: string } | null
}

export type Sale = {
  id: number
  tenant_id: number
  branch_id: number
  member_id: number | null
  invoice_id: number | null
  cashier_user_id: number | null
  status: SaleStatus
  currency_code: string
  subtotal: string | number
  discount_total: string | number
  tax_total: string | number
  grand_total: string | number
  sold_at: string | null
  items: SaleItem[]
  created_at?: string | null
  updated_at?: string | null
}

export type CreateSaleItemPayload = {
  product_id?: number | null
  description?: string | null
  quantity: number
  unit_price?: number | null
  discount_amount?: number
  tax_amount?: number
}

export type CreateSalePayload = {
  branch_id: number
  member_id?: number | null
  currency_code?: string
  create_invoice?: boolean
  coupon_code?: string | null
  sold_at?: string | null
  items: CreateSaleItemPayload[]
}

async function listMeta<T>(
  path: string,
  params: Record<string, unknown>,
): Promise<{ data: T[]; meta: PaginationMeta }> {
  const { data } = await api.get<ApiSuccess<T[]> & { meta: PaginationMeta }>(path, { params })
  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchProducts(params: {
  page?: number
  per_page?: number
  search?: string
  is_active?: boolean | ''
} = {}) {
  return listMeta<Product>('/admin/products', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    search: params.search || undefined,
    is_active:
      params.is_active === '' || params.is_active === undefined
        ? undefined
        : params.is_active
          ? 1
          : 0,
  })
}

export async function fetchProduct(productId: number) {
  const { data } = await api.get<ApiSuccess<Product>>(`/admin/products/${productId}`)
  return data.data
}

export async function fetchProductStock(productId: number) {
  const { data } = await api.get<ApiSuccess<ProductStock[]>>(
    `/admin/products/${productId}/stock`,
  )
  return data.data
}

export type ProductPayload = {
  sku: string
  name: string
  description?: string | null
  unit_price: number
  currency_code?: string
  tax_rate_id?: number | null
  low_stock_threshold?: number
  is_active?: boolean
}

export async function createProduct(payload: ProductPayload) {
  const { data } = await api.post<ApiSuccess<Product>>('/admin/products', payload)
  return data.data
}

export async function updateProduct(productId: number, payload: Partial<ProductPayload>) {
  const { data } = await api.put<ApiSuccess<Product>>(`/admin/products/${productId}`, payload)
  return data.data
}

export async function deleteProduct(productId: number) {
  await api.delete(`/admin/products/${productId}`)
}

export type ReceiveStockPayload = {
  branch_id: number
  quantity: number
  reason?: string | null
}

export type AdjustStockPayload = {
  branch_id: number
  quantity?: number
  quantity_delta?: number
  reason?: string | null
}

export type DamageStockPayload = {
  branch_id: number
  quantity: number
  reason?: string | null
}

export async function receiveStock(productId: number, payload: ReceiveStockPayload) {
  const { data } = await api.post<ApiSuccess<ProductStock>>(
    `/admin/products/${productId}/stock/receive`,
    payload,
  )
  return data.data
}

export async function adjustStock(productId: number, payload: AdjustStockPayload) {
  const { data } = await api.post<ApiSuccess<ProductStock>>(
    `/admin/products/${productId}/stock/adjust`,
    payload,
  )
  return data.data
}

export async function damageStock(productId: number, payload: DamageStockPayload) {
  const { data } = await api.post<ApiSuccess<ProductStock>>(
    `/admin/products/${productId}/stock/damage`,
    payload,
  )
  return data.data
}

export async function fetchSales(params: {
  page?: number
  per_page?: number
  status?: SaleStatus | ''
  branch_id?: number | ''
  member_id?: number | ''
} = {}) {
  return listMeta<Sale>('/admin/sales', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    status: params.status || undefined,
    branch_id: params.branch_id || undefined,
    member_id: params.member_id || undefined,
  })
}

export async function fetchSale(saleId: number) {
  const { data } = await api.get<ApiSuccess<Sale>>(`/admin/sales/${saleId}`)
  return data.data
}

export async function createSale(payload: CreateSalePayload) {
  const { data } = await api.post<ApiSuccess<Sale>>('/admin/sales', payload)
  return data.data
}

export async function voidSale(saleId: number, reason?: string | null) {
  const { data } = await api.post<ApiSuccess<Sale>>(`/admin/sales/${saleId}/void`, {
    reason: reason || undefined,
  })
  return data.data
}
