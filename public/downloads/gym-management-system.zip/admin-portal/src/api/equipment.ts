import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type EquipmentStatus = 'in_service' | 'under_maintenance' | 'retired'

export type EquipmentAsset = {
  id: number
  tenant_id: number
  branch_id: number
  branch?: { id: number; name: string; code: string }
  room_id: number | null
  room?: { id: number; name: string } | null
  asset_tag: string
  name: string
  category: string | null
  status: EquipmentStatus
  purchase_date: string | null
  warranty_ends_on: string | null
  vendor_name: string | null
  created_at?: string | null
  updated_at?: string | null
}

export type MaintenancePriority = 'low' | 'medium' | 'high' | 'urgent'
export type MaintenanceStatus = 'open' | 'in_progress' | 'done' | 'cancelled'

export type MaintenanceOrder = {
  id: number
  tenant_id: number
  branch_id: number
  branch?: { id: number; name: string; code: string }
  equipment_asset_id: number | null
  title: string
  priority: MaintenancePriority
  status: MaintenanceStatus
  assigned_user_id: number | null
  assigned_user?: { id: number; name: string; email: string } | null
  due_date: string | null
  cost_amount: string | number | null
  currency_code: string | null
  completed_at: string | null
  notes: string | null
  created_at?: string | null
  updated_at?: string | null
}

export type EquipmentPayload = {
  branch_id: number
  room_id?: number | null
  asset_tag: string
  name: string
  category?: string | null
  purchase_date?: string | null
  warranty_ends_on?: string | null
  vendor_name?: string | null
}

export type MaintenancePayload = {
  branch_id: number
  equipment_asset_id?: number | null
  title: string
  priority?: MaintenancePriority
  assigned_user_id?: number | null
  due_date?: string | null
  cost_amount?: number | null
  currency_code?: string | null
  notes?: string | null
}

async function listMeta<T>(
  path: string,
  params: Record<string, unknown>,
): Promise<{ data: T[]; meta: PaginationMeta }> {
  const { data } = await api.get<ApiSuccess<T[]> & { meta: PaginationMeta }>(path, { params })
  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchEquipmentAssets(params: {
  page?: number
  per_page?: number
  status?: EquipmentStatus | ''
  category?: string
  branch_id?: number | ''
  search?: string
} = {}) {
  return listMeta<EquipmentAsset>('/admin/equipment', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    status: params.status || undefined,
    category: params.category || undefined,
    branch_id: params.branch_id || undefined,
    search: params.search || undefined,
  })
}

export async function fetchEquipmentAsset(assetId: number) {
  const { data } = await api.get<ApiSuccess<EquipmentAsset>>(`/admin/equipment/${assetId}`)
  return data.data
}

export async function createEquipmentAsset(payload: EquipmentPayload) {
  const { data } = await api.post<ApiSuccess<EquipmentAsset>>('/admin/equipment', payload)
  return data.data
}

export async function updateEquipmentAsset(
  assetId: number,
  payload: Partial<EquipmentPayload>,
) {
  const { data } = await api.put<ApiSuccess<EquipmentAsset>>(
    `/admin/equipment/${assetId}`,
    payload,
  )
  return data.data
}

export async function deleteEquipmentAsset(assetId: number) {
  const { data } = await api.delete<ApiSuccess<null>>(`/admin/equipment/${assetId}`)
  return data.message
}

export async function changeEquipmentStatus(assetId: number, status: EquipmentStatus) {
  const { data } = await api.patch<ApiSuccess<EquipmentAsset>>(
    `/admin/equipment/${assetId}/status`,
    { status },
  )
  return data.data
}

export async function fetchMaintenanceOrders(params: {
  page?: number
  per_page?: number
  status?: MaintenanceStatus | ''
  priority?: MaintenancePriority | ''
  branch_id?: number | ''
  assigned_user_id?: number | ''
  equipment_asset_id?: number | ''
  search?: string
  from?: string
  to?: string
} = {}) {
  return listMeta<MaintenanceOrder>('/admin/facilities/maintenance-orders', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    status: params.status || undefined,
    priority: params.priority || undefined,
    branch_id: params.branch_id || undefined,
    assigned_user_id: params.assigned_user_id || undefined,
    equipment_asset_id: params.equipment_asset_id || undefined,
    search: params.search || undefined,
    from: params.from || undefined,
    to: params.to || undefined,
  })
}

export async function fetchMaintenanceOrder(orderId: number) {
  const { data } = await api.get<ApiSuccess<MaintenanceOrder>>(
    `/admin/facilities/maintenance-orders/${orderId}`,
  )
  return data.data
}

export async function createMaintenanceOrder(payload: MaintenancePayload) {
  const { data } = await api.post<ApiSuccess<MaintenanceOrder>>(
    '/admin/facilities/maintenance-orders',
    payload,
  )
  return data.data
}

export async function updateMaintenanceOrder(
  orderId: number,
  payload: Partial<MaintenancePayload>,
) {
  const { data } = await api.put<ApiSuccess<MaintenanceOrder>>(
    `/admin/facilities/maintenance-orders/${orderId}`,
    payload,
  )
  return data.data
}

export async function deleteMaintenanceOrder(orderId: number) {
  const { data } = await api.delete<ApiSuccess<null>>(
    `/admin/facilities/maintenance-orders/${orderId}`,
  )
  return data.message
}

export async function assignMaintenanceOrder(
  orderId: number,
  assignedUserId: number | null,
) {
  const { data } = await api.post<ApiSuccess<MaintenanceOrder>>(
    `/admin/facilities/maintenance-orders/${orderId}/assign`,
    { assigned_user_id: assignedUserId },
  )
  return data.data
}

export async function startMaintenanceOrder(orderId: number) {
  const { data } = await api.post<ApiSuccess<MaintenanceOrder>>(
    `/admin/facilities/maintenance-orders/${orderId}/start`,
  )
  return data.data
}

export async function completeMaintenanceOrder(orderId: number) {
  const { data } = await api.post<ApiSuccess<MaintenanceOrder>>(
    `/admin/facilities/maintenance-orders/${orderId}/complete`,
  )
  return data.data
}

export async function cancelMaintenanceOrder(orderId: number) {
  const { data } = await api.post<ApiSuccess<MaintenanceOrder>>(
    `/admin/facilities/maintenance-orders/${orderId}/cancel`,
  )
  return data.data
}

export async function updateOwnMaintenanceOrder(
  orderId: number,
  payload: { status?: 'in_progress' | 'done'; notes?: string | null },
) {
  const { data } = await api.put<ApiSuccess<MaintenanceOrder>>(
    `/admin/facilities/maintenance-orders/${orderId}/own`,
    payload,
  )
  return data.data
}
