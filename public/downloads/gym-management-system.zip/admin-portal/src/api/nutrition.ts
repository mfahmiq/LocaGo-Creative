import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type NutritionPlan = {
  id: number
  tenant_id: number
  name: string
  description: string | null
  calorie_target: number | null
  protein_g: number | null
  carbs_g: number | null
  fat_g: number | null
  file_path: string | null
  created_by_user_id: number | null
  created_by_user?: { id: number; name: string; email: string } | null
  is_active: boolean
  created_at?: string | null
  updated_at?: string | null
}

export type MemberNutritionPlanStatus = 'active' | 'completed' | 'cancelled'

export type MemberNutritionPlan = {
  id: number
  tenant_id: number
  member_id: number
  member?: {
    id: number
    member_code: string
    first_name: string
    last_name: string
  }
  nutrition_plan_id: number
  nutrition_plan?: NutritionPlan
  assigned_by: number | null
  assigned_by_user?: { id: number; name: string; email: string } | null
  start_date: string | null
  end_date: string | null
  status: MemberNutritionPlanStatus
  is_published: boolean
  notes: string | null
  created_at?: string | null
  updated_at?: string | null
}

export type NutritionPlanPayload = {
  name: string
  description?: string | null
  calorie_target?: number | null
  protein_g?: number | null
  carbs_g?: number | null
  fat_g?: number | null
  file_path?: string | null
  is_active?: boolean
}

async function listMeta<T>(
  path: string,
  params: Record<string, unknown>,
): Promise<{ data: T[]; meta: PaginationMeta }> {
  const { data } = await api.get<ApiSuccess<T[]> & { meta: PaginationMeta }>(path, { params })
  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchNutritionPlans(params: {
  page?: number
  per_page?: number
  search?: string
  is_active?: boolean | ''
} = {}) {
  return listMeta<NutritionPlan>('/admin/nutrition-plans', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    search: params.search || undefined,
    is_active:
      params.is_active === '' || params.is_active === undefined
        ? undefined
        : params.is_active
          ? 1
          : 0,
  })
}

export async function fetchNutritionPlan(planId: number) {
  const { data } = await api.get<ApiSuccess<NutritionPlan>>(`/admin/nutrition-plans/${planId}`)
  return data.data
}

export async function createNutritionPlan(payload: NutritionPlanPayload) {
  const { data } = await api.post<ApiSuccess<NutritionPlan>>('/admin/nutrition-plans', payload)
  return data.data
}

export async function updateNutritionPlan(planId: number, payload: Partial<NutritionPlanPayload>) {
  const { data } = await api.put<ApiSuccess<NutritionPlan>>(
    `/admin/nutrition-plans/${planId}`,
    payload,
  )
  return data.data
}

export async function deleteNutritionPlan(planId: number) {
  const { data } = await api.delete<ApiSuccess<null>>(`/admin/nutrition-plans/${planId}`)
  return data.message
}

export async function fetchMemberNutritionPlans(params: {
  page?: number
  per_page?: number
  member_id?: number | ''
  nutrition_plan_id?: number | ''
  status?: MemberNutritionPlanStatus | ''
  is_published?: boolean | ''
} = {}) {
  return listMeta<MemberNutritionPlan>('/admin/member-nutrition-plans', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    member_id: params.member_id || undefined,
    nutrition_plan_id: params.nutrition_plan_id || undefined,
    status: params.status || undefined,
    is_published:
      params.is_published === '' || params.is_published === undefined
        ? undefined
        : params.is_published
          ? 1
          : 0,
  })
}

export async function createMemberNutritionPlan(payload: {
  member_id: number
  nutrition_plan_id: number
  start_date: string
  end_date?: string | null
  notes?: string | null
}) {
  const { data } = await api.post<ApiSuccess<MemberNutritionPlan>>(
    '/admin/member-nutrition-plans',
    payload,
  )
  return data.data
}

export async function publishMemberNutritionPlan(assignmentId: number) {
  const { data } = await api.post<ApiSuccess<MemberNutritionPlan>>(
    `/admin/member-nutrition-plans/${assignmentId}/publish`,
  )
  return data.data
}

export async function cancelMemberNutritionPlan(assignmentId: number) {
  const { data } = await api.post<ApiSuccess<MemberNutritionPlan>>(
    `/admin/member-nutrition-plans/${assignmentId}/cancel`,
  )
  return data.data
}
