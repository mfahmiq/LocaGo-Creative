import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type DiscountType = 'percent' | 'fixed'
export type ReferralStatus = 'pending' | 'qualified' | 'rewarded' | 'disqualified'

export type Offer = {
  id: number
  tenant_id: number
  code: string
  name: string
  discount_type: DiscountType
  discount_value: string | number
  starts_at: string
  ends_at: string
  is_active: boolean
  stackable_with_coupon: boolean
  created_at?: string | null
  updated_at?: string | null
}

export type Coupon = {
  id: number
  tenant_id: number
  code: string
  discount_type: DiscountType
  discount_value: string | number
  max_redemptions: number | null
  per_member_limit: number | null
  redeemed_count: number
  starts_at: string
  ends_at: string
  is_active: boolean
  created_at?: string | null
  updated_at?: string | null
}

export type CouponRedemption = {
  id: number
  tenant_id: number
  coupon_id: number
  member_id: number | null
  invoice_id: number | null
  redeemed_at: string | null
  created_at?: string | null
}

export type ReferralMember = {
  id: number
  first_name: string
  last_name: string
  member_code: string
}

export type Referral = {
  id: number
  tenant_id: number
  referrer_member_id: number
  referee_member_id: number
  referrer?: ReferralMember | null
  referee?: ReferralMember | null
  status: ReferralStatus
  qualified_at: string | null
  rewarded_at: string | null
  reward_type: string | null
  reward_reference: string | null
  created_at?: string | null
  updated_at?: string | null
}

export type OfferPayload = {
  code: string
  name: string
  discount_type: DiscountType
  discount_value: number
  starts_at: string
  ends_at: string
  is_active?: boolean
  stackable_with_coupon?: boolean
}

export type CouponPayload = {
  code: string
  discount_type: DiscountType
  discount_value: number
  max_redemptions?: number | null
  per_member_limit?: number | null
  starts_at: string
  ends_at: string
  is_active?: boolean
}

async function listMeta<T>(
  path: string,
  params: Record<string, unknown>,
): Promise<{ data: T[]; meta: PaginationMeta }> {
  const { data } = await api.get<ApiSuccess<T[]> & { meta: PaginationMeta }>(path, { params })
  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchOffers(params: {
  page?: number
  per_page?: number
  search?: string
  is_active?: boolean | ''
} = {}) {
  return listMeta<Offer>('/admin/offers', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    search: params.search || undefined,
    is_active:
      params.is_active === '' || params.is_active === undefined
        ? undefined
        : params.is_active
          ? 1
          : 0,
  })
}

export async function fetchOffer(offerId: number) {
  const { data } = await api.get<ApiSuccess<Offer>>(`/admin/offers/${offerId}`)
  return data.data
}

export async function createOffer(payload: OfferPayload) {
  const { data } = await api.post<ApiSuccess<Offer>>('/admin/offers', payload)
  return data.data
}

export async function updateOffer(offerId: number, payload: Partial<OfferPayload>) {
  const { data } = await api.put<ApiSuccess<Offer>>(`/admin/offers/${offerId}`, payload)
  return data.data
}

export async function deleteOffer(offerId: number) {
  await api.delete(`/admin/offers/${offerId}`)
}

export async function fetchCoupons(params: {
  page?: number
  per_page?: number
  search?: string
  is_active?: boolean | ''
} = {}) {
  return listMeta<Coupon>('/admin/coupons', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    search: params.search || undefined,
    is_active:
      params.is_active === '' || params.is_active === undefined
        ? undefined
        : params.is_active
          ? 1
          : 0,
  })
}

export async function fetchCoupon(couponId: number) {
  const { data } = await api.get<ApiSuccess<Coupon>>(`/admin/coupons/${couponId}`)
  return data.data
}

export async function createCoupon(payload: CouponPayload) {
  const { data } = await api.post<ApiSuccess<Coupon>>('/admin/coupons', payload)
  return data.data
}

export async function updateCoupon(couponId: number, payload: Partial<CouponPayload>) {
  const { data } = await api.put<ApiSuccess<Coupon>>(`/admin/coupons/${couponId}`, payload)
  return data.data
}

export async function deleteCoupon(couponId: number) {
  await api.delete(`/admin/coupons/${couponId}`)
}

export async function redeemCoupon(
  couponId: number,
  payload: { member_id?: number | null; invoice_id?: number | null } = {},
) {
  const { data } = await api.post<ApiSuccess<CouponRedemption>>(
    `/admin/coupons/${couponId}/redeem`,
    payload,
  )
  return data.data
}

export async function fetchReferrals(params: {
  page?: number
  per_page?: number
  status?: ReferralStatus | ''
  referrer_member_id?: number | ''
} = {}) {
  return listMeta<Referral>('/admin/referrals', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    status: params.status || undefined,
    referrer_member_id: params.referrer_member_id || undefined,
  })
}

export async function fetchReferral(referralId: number) {
  const { data } = await api.get<ApiSuccess<Referral>>(`/admin/referrals/${referralId}`)
  return data.data
}

export async function createReferral(payload: {
  referrer_member_id: number
  referee_member_id: number
}) {
  const { data } = await api.post<ApiSuccess<Referral>>('/admin/referrals', payload)
  return data.data
}

export async function qualifyReferral(referralId: number) {
  const { data } = await api.post<ApiSuccess<Referral>>(
    `/admin/referrals/${referralId}/qualify`,
  )
  return data.data
}

export async function rewardReferral(
  referralId: number,
  payload: { reward_type?: string | null; reward_reference?: string | null } = {},
) {
  const { data } = await api.post<ApiSuccess<Referral>>(
    `/admin/referrals/${referralId}/reward`,
    payload,
  )
  return data.data
}

export async function disqualifyReferral(referralId: number) {
  const { data } = await api.post<ApiSuccess<Referral>>(
    `/admin/referrals/${referralId}/disqualify`,
  )
  return data.data
}
