import axios, { type AxiosError, type InternalAxiosRequestConfig } from 'axios'
import { env } from '@/config/env'
import { authStorage } from '@/auth/storage'
import type { ApiErrorBody } from '@/api/types'

export class ApiError extends Error {
  status: number
  code?: string
  errors?: Record<string, string[]>
  data?: Record<string, unknown>

  constructor(
    message: string,
    status: number,
    code?: string,
    errors?: Record<string, string[]>,
    data?: Record<string, unknown>,
  ) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.code = code
    this.errors = errors
    this.data = data
  }
}

export const api = axios.create({
  baseURL: env.apiBaseUrl,
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json',
  },
})

api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = authStorage.getToken()
  const tenant = authStorage.getTenantSlug()
  const branchId = authStorage.getBranchId()
  const portal = authStorage.getPortal()

  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }

  // Tenant slug is session-derived after login — never required on the login form.
  if (portal === 'admin' && tenant) {
    config.headers['X-Tenant-Slug'] = tenant
  }

  if (portal === 'admin' && branchId != null) {
    config.headers['X-Branch-Id'] = String(branchId)
  }

  return config
})

api.interceptors.response.use(
  (response) => response,
  (error: AxiosError<ApiErrorBody>) => {
    const status = error.response?.status ?? 0
    const body = error.response?.data
    const message = body?.message || error.message || 'Request failed'

    if (status === 401 && !error.config?.url?.includes('/auth/login')) {
      authStorage.clearAll()
      if (window.location.pathname !== '/login') {
        window.location.assign('/login')
      }
    }

    return Promise.reject(
      new ApiError(message, status, body?.code, body?.errors, body?.data),
    )
  },
)
