import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'

export type PlatformAuditActor = {
  id: number
  name: string
  email: string
}

export type PlatformAuditTenant = {
  id: number
  name: string
  slug: string
}

export type PlatformAuditLog = {
  id: number
  tenant_id: number | null
  actor_user_id: number | null
  branch_id: number | null
  action: string
  entity_type: string
  entity_id: number | null
  old_values: Record<string, unknown> | null
  new_values: Record<string, unknown> | null
  ip_address: string | null
  user_agent: string | null
  created_at: string | null
  actor?: PlatformAuditActor | null
  tenant?: PlatformAuditTenant | null
}

export type PlatformAuditSummary = {
  total: number
  last_24h: number
  unique_actions: number
  unique_actors: number
}

export type PlatformAuditListParams = {
  page?: number
  per_page?: number
  q?: string
  scope?: '' | 'platform' | 'tenant'
  action?: string
  entity_type?: string
  tenant_id?: number | ''
  actor_user_id?: number | ''
  from?: string
  to?: string
}

export type PlatformAuditListResult = {
  data: PlatformAuditLog[]
  meta: PaginationMeta
  summary: PlatformAuditSummary
}

export async function fetchPlatformAuditLogs(
  params: PlatformAuditListParams = {},
): Promise<PlatformAuditListResult> {
  const { data } = await api.get<
    ApiSuccess<PlatformAuditLog[]> & {
      meta: PaginationMeta
      summary: PlatformAuditSummary
    }
  >('/platform/audit-logs', {
    params: {
      page: params.page ?? 1,
      per_page: params.per_page ?? 10,
      q: params.q || undefined,
      scope: params.scope || undefined,
      action: params.action || undefined,
      entity_type: params.entity_type || undefined,
      tenant_id: params.tenant_id || undefined,
      actor_user_id: params.actor_user_id || undefined,
      from: params.from || undefined,
      to: params.to || undefined,
    },
  })

  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: 10,
      total: 0,
      last_page: 1,
    },
    summary: data.summary ?? {
      total: 0,
      last_24h: 0,
      unique_actions: 0,
      unique_actors: 0,
    },
  }
}

export async function fetchPlatformAuditLog(id: number) {
  const { data } = await api.get<ApiSuccess<PlatformAuditLog>>(`/platform/audit-logs/${id}`)
  return data.data
}
