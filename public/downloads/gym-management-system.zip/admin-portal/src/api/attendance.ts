import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type AttendanceStatus = 'valid' | 'voided'
export type AttendanceMethod = 'staff' | 'qr' | 'code'

export type AttendanceMember = {
  id: number
  member_code: string
  first_name: string
  last_name: string
  email?: string | null
  status?: string
}

export type AttendanceBranch = {
  id: number
  code: string
  name: string
}

export type AttendanceMembership = {
  id: number
  status: string
  visits_remaining: number | null
  plan?: {
    id: number
    code: string
    name: string
    allows_walkin?: boolean
    allows_all_branches?: boolean
  } | null
  start_date?: string | null
  end_date?: string | null
}

export type AttendanceStaff = {
  id: number
  name: string
  email: string
}

export type AttendanceRecord = {
  id: number
  tenant_id: number
  branch_id: number
  branch?: AttendanceBranch
  member_id: number
  member?: AttendanceMember
  membership_id: number | null
  membership?: AttendanceMembership | null
  checked_in_at: string | null
  method: AttendanceMethod | string
  staff_user_id: number | null
  staff_user?: AttendanceStaff | null
  status: AttendanceStatus
  void_reason: string | null
  notes: string | null
  created_at?: string | null
  updated_at?: string | null
}

export type AttendanceListParams = {
  page?: number
  per_page?: number
  branch_id?: number | ''
  member_id?: number | ''
  status?: AttendanceStatus | ''
  date?: string
  from?: string
  to?: string
}

export type AttendanceListResult = {
  data: AttendanceRecord[]
  meta: PaginationMeta
}

export type CheckInEligibility = {
  allowed: boolean
  code: string | null
  message: string
  recent_attendance_id: number | null
  visits_remaining: number | null
  member: AttendanceMember | null
  membership: AttendanceMembership | null
}

export type CheckInPayload = {
  member_id: number
  branch_id: number
  method?: AttendanceMethod
  notes?: string | null
}

export async function fetchAttendance(
  params: AttendanceListParams = {},
): Promise<AttendanceListResult> {
  const { data } = await api.get<ApiSuccess<AttendanceRecord[]> & { meta: PaginationMeta }>(
    '/admin/attendance',
    {
      params: {
        page: params.page ?? 1,
        per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
        branch_id: params.branch_id || undefined,
        member_id: params.member_id || undefined,
        status: params.status || undefined,
        date: params.date || undefined,
        from: params.from || undefined,
        to: params.to || undefined,
      },
    },
  )

  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchAttendanceRecord(attendanceId: number) {
  const { data } = await api.get<ApiSuccess<AttendanceRecord>>(`/admin/attendance/${attendanceId}`)
  return data.data
}

export async function fetchCheckInEligibility(memberId: number, branchId: number) {
  const { data } = await api.get<ApiSuccess<CheckInEligibility>>('/admin/attendance/eligibility', {
    params: { member_id: memberId, branch_id: branchId },
  })
  return data.data
}

export async function checkInMember(payload: CheckInPayload) {
  const { data } = await api.post<ApiSuccess<AttendanceRecord>>(
    '/admin/attendance/check-in',
    payload,
  )
  return data.data
}

export async function voidAttendance(attendanceId: number, reason?: string | null) {
  const { data } = await api.post<ApiSuccess<AttendanceRecord>>(
    `/admin/attendance/${attendanceId}/void`,
    { reason: reason || undefined },
  )
  return data.data
}
