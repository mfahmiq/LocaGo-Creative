import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type MemberStatus = 'lead' | 'active' | 'inactive' | 'blacklisted'

export type MemberBranch = {
  id: number
  code: string
  name: string
}

export type Member = {
  id: number
  tenant_id: number
  user_id: number | null
  home_branch_id: number | null
  home_branch?: MemberBranch | null
  member_code: string
  first_name: string
  last_name: string
  full_name: string
  email: string | null
  phone: string | null
  gender: string | null
  date_of_birth: string | null
  emergency_name: string | null
  emergency_phone: string | null
  status: MemberStatus
  joined_at: string | null
  referral_code: string | null
  referred_by_member_id: number | null
  created_at?: string | null
  updated_at?: string | null
}

export type MemberListParams = {
  page?: number
  per_page?: number
  search?: string
  status?: MemberStatus | ''
  home_branch_id?: number | ''
}

export type MemberListResult = {
  data: Member[]
  meta: PaginationMeta
}

export type CreateMemberPayload = {
  home_branch_id: number
  first_name: string
  last_name: string
  email?: string | null
  phone?: string | null
  gender?: string | null
  date_of_birth?: string | null
  emergency_name?: string | null
  emergency_phone?: string | null
  status?: MemberStatus
  joined_at?: string | null
  referred_by_member_id?: number | null
}

export type UpdateMemberPayload = Partial<CreateMemberPayload>

export async function fetchMembers(params: MemberListParams = {}): Promise<MemberListResult> {
  const { data } = await api.get<ApiSuccess<Member[]> & { meta: PaginationMeta }>(
    '/admin/members',
    {
      params: {
        page: params.page ?? 1,
        per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
        search: params.search || undefined,
        status: params.status || undefined,
        home_branch_id: params.home_branch_id || undefined,
      },
    },
  )

  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchMember(memberId: number) {
  const { data } = await api.get<ApiSuccess<Member>>(`/admin/members/${memberId}`)
  return data.data
}

export async function createMember(payload: CreateMemberPayload) {
  const { data } = await api.post<ApiSuccess<Member>>('/admin/members', payload)
  return data.data
}

export async function updateMember(memberId: number, payload: UpdateMemberPayload) {
  const { data } = await api.put<ApiSuccess<Member>>(`/admin/members/${memberId}`, payload)
  return data.data
}

export async function deleteMember(memberId: number) {
  const { data } = await api.delete<ApiSuccess<null>>(`/admin/members/${memberId}`)
  return data.message
}

export async function changeMemberStatus(memberId: number, status: MemberStatus) {
  const { data } = await api.patch<ApiSuccess<Member>>(`/admin/members/${memberId}/status`, {
    status,
  })
  return data.data
}
