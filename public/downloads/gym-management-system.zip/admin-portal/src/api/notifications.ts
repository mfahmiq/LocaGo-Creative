import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type NotificationChannel = 'in_app' | 'email' | 'whatsapp' | 'push'
export type DeliveryStatus = 'queued' | 'sent' | 'failed'

export type NotificationTemplate = {
  id: number
  tenant_id: number | null
  is_system_default: boolean
  event_key: string
  channel: NotificationChannel
  subject: string | null
  body: string
  is_active: boolean
  created_at?: string | null
  updated_at?: string | null
}

export type InAppNotification = {
  id: number
  tenant_id: number
  user_id: number
  event_key: string
  title: string
  body: string
  data_json: Record<string, unknown> | null
  read_at: string | null
  is_read: boolean
  created_at?: string | null
  updated_at?: string | null
}

export type NotificationDelivery = {
  id: number
  tenant_id: number
  notification_id: number | null
  user_id: number | null
  channel: NotificationChannel
  recipient: string | null
  event_key: string
  status: DeliveryStatus
  provider_message_id: string | null
  error_message: string | null
  sent_at: string | null
  created_at?: string | null
  updated_at?: string | null
}

export type TemplatePayload = {
  event_key: string
  channel: NotificationChannel
  subject?: string | null
  body: string
  is_active?: boolean
}

export type SendNotificationPayload = {
  event_key: string
  title: string
  body: string
  data_json?: Record<string, unknown> | null
  user_ids?: number[]
  member_ids?: number[]
  channels?: Array<'in_app' | 'email' | 'whatsapp'>
}

export type SendNotificationResult = {
  notifications: InAppNotification[]
  deliveries: NotificationDelivery[]
}

export const NOTIFICATION_EVENTS: Array<{
  key: string
  label: string
  description: string
}> = [
  {
    key: 'member.registered',
    label: 'New Registration',
    description: 'Triggered when a member account is created.',
  },
  {
    key: 'membership.activated',
    label: 'Membership Activated',
    description: 'Triggered when a membership becomes active.',
  },
  {
    key: 'membership.expiring',
    label: 'Membership Expiring',
    description: 'Scheduled reminder before membership end date.',
  },
  {
    key: 'membership.expired',
    label: 'Membership Expired',
    description: 'Triggered on/after membership expiry.',
  },
  {
    key: 'payment.successful',
    label: 'Payment Successful',
    description: 'Triggered when a payment is captured.',
  },
  {
    key: 'payment.failed',
    label: 'Payment Failed',
    description: 'Triggered when a payment attempt fails.',
  },
  {
    key: 'class.reminder',
    label: 'Class Reminder',
    description: 'Reminder before a booked class starts.',
  },
  {
    key: 'member.birthday',
    label: 'Birthday Greeting',
    description: 'Member birthday greeting.',
  },
  {
    key: 'training.pt_reminder',
    label: 'Personal Training Reminder',
    description: 'Reminder before a PT session.',
  },
]

async function listMeta<T>(
  path: string,
  params: Record<string, unknown>,
): Promise<{ data: T[]; meta: PaginationMeta }> {
  const { data } = await api.get<ApiSuccess<T[]> & { meta: PaginationMeta }>(path, { params })
  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchNotificationTemplates(params: {
  page?: number
  per_page?: number
  event_key?: string
  channel?: NotificationChannel | ''
  is_active?: boolean | ''
} = {}) {
  return listMeta<NotificationTemplate>('/admin/notification-templates', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    event_key: params.event_key || undefined,
    channel: params.channel || undefined,
    is_active:
      params.is_active === '' || params.is_active === undefined
        ? undefined
        : params.is_active
          ? 1
          : 0,
  })
}

export async function fetchNotificationTemplate(templateId: number) {
  const { data } = await api.get<ApiSuccess<NotificationTemplate>>(
    `/admin/notification-templates/${templateId}`,
  )
  return data.data
}

export async function createNotificationTemplate(payload: TemplatePayload) {
  const { data } = await api.post<ApiSuccess<NotificationTemplate>>(
    '/admin/notification-templates',
    payload,
  )
  return data.data
}

export async function updateNotificationTemplate(
  templateId: number,
  payload: Partial<TemplatePayload>,
) {
  const { data } = await api.put<ApiSuccess<NotificationTemplate>>(
    `/admin/notification-templates/${templateId}`,
    payload,
  )
  return data.data
}

export async function deleteNotificationTemplate(templateId: number) {
  await api.delete(`/admin/notification-templates/${templateId}`)
}

export async function fetchInboxNotifications(params: {
  page?: number
  per_page?: number
  unread?: boolean | ''
  event_key?: string
} = {}) {
  return listMeta<InAppNotification>('/admin/notifications', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    unread:
      params.unread === '' || params.unread === undefined
        ? undefined
        : params.unread
          ? 1
          : 0,
    event_key: params.event_key || undefined,
  })
}

export async function fetchUnreadNotificationCount() {
  const { data } = await api.get<ApiSuccess<{ unread_count: number }>>(
    '/admin/notifications/unread-count',
  )
  return data.data.unread_count
}

export async function fetchInboxNotification(notificationId: number) {
  const { data } = await api.get<ApiSuccess<InAppNotification>>(
    `/admin/notifications/${notificationId}`,
  )
  return data.data
}

export async function markNotificationRead(notificationId: number) {
  const { data } = await api.post<ApiSuccess<InAppNotification>>(
    `/admin/notifications/${notificationId}/read`,
  )
  return data.data
}

export async function sendNotification(payload: SendNotificationPayload) {
  const { data } = await api.post<ApiSuccess<SendNotificationResult>>(
    '/admin/notifications/send',
    payload,
  )
  return data.data
}

export async function fetchNotificationDeliveries(params: {
  page?: number
  per_page?: number
  status?: DeliveryStatus | ''
  channel?: NotificationChannel | ''
  event_key?: string
  user_id?: number | ''
} = {}) {
  return listMeta<NotificationDelivery>('/admin/notification-deliveries', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    status: params.status || undefined,
    channel: params.channel || undefined,
    event_key: params.event_key || undefined,
    user_id: params.user_id || undefined,
  })
}

export function eventLabel(eventKey: string) {
  return NOTIFICATION_EVENTS.find((e) => e.key === eventKey)?.label ?? eventKey
}
