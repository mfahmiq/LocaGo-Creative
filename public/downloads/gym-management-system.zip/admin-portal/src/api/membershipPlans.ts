import { api } from '@/api/client'
import type { ApiSuccess, BranchSummary, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type PlanType = 'time' | 'visit' | 'hybrid'

export type MembershipPlan = {
  id: number
  tenant_id: number
  code: string
  name: string
  description: string | null
  plan_type: PlanType
  duration_days: number | null
  visit_limit: number | null
  price: string | number
  currency_code: string
  allows_walkin: boolean
  allows_all_branches: boolean
  freeze_allowed: boolean
  max_freeze_days: number | null
  tax_rate_id: number | null
  is_active: boolean
  branches?: BranchSummary[]
  created_at?: string | null
  updated_at?: string | null
}

export type MembershipPlanListParams = {
  page?: number
  per_page?: number
  search?: string
  plan_type?: PlanType | ''
  is_active?: boolean | ''
}

export type MembershipPlanListResult = {
  data: MembershipPlan[]
  meta: PaginationMeta
}

export type CreateMembershipPlanPayload = {
  code: string
  name: string
  description?: string | null
  plan_type: PlanType
  duration_days?: number | null
  visit_limit?: number | null
  price: number
  currency_code?: string | null
  allows_walkin?: boolean
  allows_all_branches?: boolean
  branch_ids?: number[]
  freeze_allowed?: boolean
  max_freeze_days?: number | null
  tax_rate_id?: number | null
  is_active?: boolean
}

export type UpdateMembershipPlanPayload = Partial<CreateMembershipPlanPayload>

export async function fetchMembershipPlans(
  params: MembershipPlanListParams = {},
): Promise<MembershipPlanListResult> {
  const { data } = await api.get<ApiSuccess<MembershipPlan[]> & { meta: PaginationMeta }>(
    '/admin/membership-plans',
    {
      params: {
        page: params.page ?? 1,
        per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
        search: params.search || undefined,
        plan_type: params.plan_type || undefined,
        is_active:
          params.is_active === '' || params.is_active === undefined
            ? undefined
            : params.is_active
              ? 1
              : 0,
      },
    },
  )

  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchMembershipPlan(planId: number) {
  const { data } = await api.get<ApiSuccess<MembershipPlan>>(`/admin/membership-plans/${planId}`)
  return data.data
}

export async function createMembershipPlan(payload: CreateMembershipPlanPayload) {
  const { data } = await api.post<ApiSuccess<MembershipPlan>>('/admin/membership-plans', payload)
  return data.data
}

export async function updateMembershipPlan(planId: number, payload: UpdateMembershipPlanPayload) {
  const { data } = await api.put<ApiSuccess<MembershipPlan>>(
    `/admin/membership-plans/${planId}`,
    payload,
  )
  return data.data
}

export async function deleteMembershipPlan(planId: number) {
  const { data } = await api.delete<ApiSuccess<null>>(`/admin/membership-plans/${planId}`)
  return data.message
}
