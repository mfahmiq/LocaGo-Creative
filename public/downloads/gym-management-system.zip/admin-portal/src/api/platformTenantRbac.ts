import { api } from '@/api/client'
import type { ApiSuccess } from '@/api/types'
import type { PermissionRow, RoleRow } from '@/api/rbac'

export async function fetchTenantPermissionsCatalog() {
  const { data } = await api.get<ApiSuccess<PermissionRow[]>>('/platform/tenant-permissions')
  return data.data
}

export async function fetchTenantRoles(tenantId: number) {
  const { data } = await api.get<ApiSuccess<RoleRow[]>>(`/platform/tenants/${tenantId}/roles`)
  return data.data
}

export async function createTenantRole(
  tenantId: number,
  payload: { code: string; name: string },
) {
  const { data } = await api.post<ApiSuccess<RoleRow>>(
    `/platform/tenants/${tenantId}/roles`,
    payload,
  )
  return data.data
}

export async function updateTenantRole(
  tenantId: number,
  roleId: number,
  payload: { code?: string; name?: string },
) {
  const { data } = await api.put<ApiSuccess<RoleRow>>(
    `/platform/tenants/${tenantId}/roles/${roleId}`,
    payload,
  )
  return data.data
}

export async function deleteTenantRole(tenantId: number, roleId: number) {
  const { data } = await api.delete<ApiSuccess<null>>(
    `/platform/tenants/${tenantId}/roles/${roleId}`,
  )
  return data.message
}

export async function seedTenantRoles(tenantId: number) {
  const { data } = await api.post<ApiSuccess<RoleRow[]>>(
    `/platform/tenants/${tenantId}/roles/seed`,
  )
  return data.data
}

export async function fetchTenantRolePermissions(tenantId: number, roleId: number) {
  const { data } = await api.get<
    ApiSuccess<{ role: RoleRow; permissions: PermissionRow[] }>
  >(`/platform/tenants/${tenantId}/roles/${roleId}/permissions`)
  return data.data
}

export async function syncTenantRolePermissions(
  tenantId: number,
  roleId: number,
  permissionIds: number[],
) {
  const { data } = await api.put<
    ApiSuccess<{ role: RoleRow; permissions: PermissionRow[] }>
  >(`/platform/tenants/${tenantId}/roles/${roleId}/permissions`, {
    permission_ids: permissionIds,
  })
  return data.data
}
