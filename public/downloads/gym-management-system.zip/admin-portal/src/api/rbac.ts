import { api } from '@/api/client'
import type { ApiSuccess } from '@/api/types'

export type RoleRow = {
  id: number
  tenant_id: number | null
  code: string
  name: string
  is_system: boolean
}

export type PermissionRow = {
  id: number
  code: string
  name: string
  module: string
}

export async function fetchRoles() {
  const { data } = await api.get<ApiSuccess<RoleRow[]>>('/admin/roles')
  return data.data
}

export async function createRole(payload: { code: string; name: string }) {
  const { data } = await api.post<ApiSuccess<RoleRow>>('/admin/roles', payload)
  return data.data
}

export async function updateRole(roleId: number, payload: { code?: string; name?: string }) {
  const { data } = await api.put<ApiSuccess<RoleRow>>(`/admin/roles/${roleId}`, payload)
  return data.data
}

export async function deleteRole(roleId: number) {
  const { data } = await api.delete<ApiSuccess<null>>(`/admin/roles/${roleId}`)
  return data.message
}

export async function seedRoles() {
  const { data } = await api.post<ApiSuccess<RoleRow[]>>('/admin/roles/seed')
  return data.data
}

export async function fetchPermissions() {
  const { data } = await api.get<ApiSuccess<PermissionRow[]>>('/admin/permissions')
  return data.data
}

export async function fetchRolePermissions(roleId: number) {
  const { data } = await api.get<
    ApiSuccess<{ role: RoleRow; permissions: PermissionRow[] }>
  >(`/admin/roles/${roleId}/permissions`)
  return data.data
}

export async function syncRolePermissions(roleId: number, permissionIds: number[]) {
  const { data } = await api.put<
    ApiSuccess<{ role: RoleRow; permissions: PermissionRow[] }>
  >(`/admin/roles/${roleId}/permissions`, { permission_ids: permissionIds })
  return data.data
}
