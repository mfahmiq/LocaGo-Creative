import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type InvoiceStatus =
  | 'draft'
  | 'issued'
  | 'partially_paid'
  | 'paid'
  | 'void'
  | 'overdue'

export type PaymentStatus = 'completed' | 'reversed'
export type PaymentMethod = 'cash' | 'card' | 'upi' | 'bank_transfer' | 'other'

export type InvoiceMember = {
  id: number
  member_code: string
  first_name: string
  last_name: string
}

export type InvoiceBranch = {
  id: number
  code: string
  name: string
}

export type InvoiceItem = {
  id: number
  description: string
  quantity: string | number
  unit_price: string | number
  discount_amount: string | number
  tax_rate_percent: string | number | null
  tax_amount: string | number
  line_total: string | number
  item_type: string | null
  item_id: number | null
}

export type Invoice = {
  id: number
  tenant_id: number
  branch_id: number | null
  branch?: InvoiceBranch | null
  member_id: number | null
  member?: InvoiceMember | null
  invoice_number: string
  status: InvoiceStatus
  currency_code: string
  subtotal: string | number
  discount_total: string | number
  tax_total: string | number
  grand_total: string | number
  amount_paid: string | number
  balance_due: string | number
  issue_date: string | null
  due_date: string | null
  notes: string | null
  source_type: string | null
  source_id: number | null
  items: InvoiceItem[]
  created_at?: string | null
  updated_at?: string | null
}

export type PaymentAllocation = {
  id: number
  invoice_id: number
  amount: string | number
  invoice?: {
    id: number
    invoice_number: string
    status: InvoiceStatus
    balance_due: string | number
  } | null
}

export type Payment = {
  id: number
  tenant_id: number
  branch_id: number | null
  member_id: number | null
  member?: InvoiceMember | null
  payment_number: string
  amount: string | number
  currency_code: string
  method: PaymentMethod
  reference: string | null
  status: PaymentStatus
  paid_at: string | null
  received_by: number | null
  notes: string | null
  allocations: PaymentAllocation[]
  created_at?: string | null
}

export type InvoiceItemPayload = {
  description: string
  quantity?: number
  unit_price: number
  discount_amount?: number
  tax_rate_percent?: number | null
  item_type?: string | null
  item_id?: number | null
}

export type CreateInvoicePayload = {
  member_id?: number | null
  branch_id?: number | null
  currency_code?: string
  due_date?: string | null
  notes?: string | null
  source_type?: string
  source_id?: number | null
  issue_now?: boolean
  items: InvoiceItemPayload[]
}

export type UpdateInvoicePayload = {
  due_date?: string | null
  notes?: string | null
  source_type?: string | null
  source_id?: number | null
  items?: InvoiceItemPayload[]
}

export type CreatePaymentPayload = {
  member_id?: number | null
  branch_id?: number | null
  amount: number
  currency_code?: string
  method: PaymentMethod
  reference?: string | null
  paid_at?: string | null
  notes?: string | null
  allocations: Array<{ invoice_id: number; amount: number }>
}

async function listMeta<T>(
  path: string,
  params: Record<string, unknown>,
): Promise<{ data: T[]; meta: PaginationMeta }> {
  const { data } = await api.get<ApiSuccess<T[]> & { meta: PaginationMeta }>(path, { params })
  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchInvoices(params: {
  page?: number
  per_page?: number
  status?: InvoiceStatus | ''
  member_id?: number | ''
  branch_id?: number | ''
  search?: string
} = {}) {
  return listMeta<Invoice>('/admin/invoices', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    status: params.status || undefined,
    member_id: params.member_id || undefined,
    branch_id: params.branch_id || undefined,
    search: params.search || undefined,
  })
}

export async function fetchInvoice(invoiceId: number) {
  const { data } = await api.get<ApiSuccess<Invoice>>(`/admin/invoices/${invoiceId}`)
  return data.data
}

export async function createInvoice(payload: CreateInvoicePayload) {
  const { data } = await api.post<ApiSuccess<Invoice>>('/admin/invoices', payload)
  return data.data
}

export async function updateInvoice(invoiceId: number, payload: UpdateInvoicePayload) {
  const { data } = await api.put<ApiSuccess<Invoice>>(`/admin/invoices/${invoiceId}`, payload)
  return data.data
}

export async function issueInvoice(invoiceId: number) {
  const { data } = await api.post<ApiSuccess<Invoice>>(`/admin/invoices/${invoiceId}/issue`)
  return data.data
}

export async function voidInvoice(invoiceId: number, reason?: string | null) {
  const { data } = await api.post<ApiSuccess<Invoice>>(`/admin/invoices/${invoiceId}/void`, {
    reason: reason || undefined,
  })
  return data.data
}

export async function fetchPayments(params: {
  page?: number
  per_page?: number
  status?: PaymentStatus | ''
  member_id?: number | ''
  branch_id?: number | ''
  method?: PaymentMethod | ''
  search?: string
} = {}) {
  return listMeta<Payment>('/admin/payments', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    status: params.status || undefined,
    member_id: params.member_id || undefined,
    branch_id: params.branch_id || undefined,
    method: params.method || undefined,
    search: params.search || undefined,
  })
}

export async function fetchPayment(paymentId: number) {
  const { data } = await api.get<ApiSuccess<Payment>>(`/admin/payments/${paymentId}`)
  return data.data
}

export async function createPayment(payload: CreatePaymentPayload) {
  const { data } = await api.post<ApiSuccess<Payment>>('/admin/payments', payload)
  return data.data
}

export async function voidPayment(paymentId: number, reason?: string | null) {
  const { data } = await api.post<ApiSuccess<Payment>>(`/admin/payments/${paymentId}/void`, {
    reason: reason || undefined,
  })
  return data.data
}

export const OPEN_INVOICE_STATUSES: InvoiceStatus[] = [
  'issued',
  'partially_paid',
  'overdue',
]

export function isOpenInvoiceStatus(status: InvoiceStatus) {
  return OPEN_INVOICE_STATUSES.includes(status)
}
