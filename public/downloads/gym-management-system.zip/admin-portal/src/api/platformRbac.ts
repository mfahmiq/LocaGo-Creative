import { api } from '@/api/client'
import type { ApiSuccess } from '@/api/types'
import type { PermissionRow, RoleRow } from '@/api/rbac'

export async function fetchPlatformRoles() {
  const { data } = await api.get<ApiSuccess<RoleRow[]>>('/platform/roles')
  return data.data
}

export async function createPlatformRole(payload: { code: string; name: string }) {
  const { data } = await api.post<ApiSuccess<RoleRow>>('/platform/roles', payload)
  return data.data
}

export async function updatePlatformRole(
  roleId: number,
  payload: { code?: string; name?: string },
) {
  const { data } = await api.put<ApiSuccess<RoleRow>>(`/platform/roles/${roleId}`, payload)
  return data.data
}

export async function deletePlatformRole(roleId: number) {
  const { data } = await api.delete<ApiSuccess<null>>(`/platform/roles/${roleId}`)
  return data.message
}

export async function seedPlatformRoles() {
  const { data } = await api.post<ApiSuccess<RoleRow[]>>('/platform/roles/seed')
  return data.data
}

export async function fetchPlatformPermissions() {
  const { data } = await api.get<ApiSuccess<PermissionRow[]>>('/platform/permissions')
  return data.data
}

export async function fetchPlatformRolePermissions(roleId: number) {
  const { data } = await api.get<
    ApiSuccess<{ role: RoleRow; permissions: PermissionRow[] }>
  >(`/platform/roles/${roleId}/permissions`)
  return data.data
}

export async function syncPlatformRolePermissions(roleId: number, permissionIds: number[]) {
  const { data } = await api.put<
    ApiSuccess<{ role: RoleRow; permissions: PermissionRow[] }>
  >(`/platform/roles/${roleId}/permissions`, { permission_ids: permissionIds })
  return data.data
}
