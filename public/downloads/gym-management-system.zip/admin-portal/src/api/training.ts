import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type Trainer = {
  id: number
  tenant_id: number
  user_id: number
  user?: { id: number; name: string; email: string } | null
  specialty: string | null
  bio: string | null
  is_active: boolean
  created_at?: string | null
  updated_at?: string | null
}

export type TrainerMember = {
  id: number
  trainer_id: number
  member_id: number
  member?: {
    id: number
    member_code: string
    first_name: string
    last_name: string
    email?: string | null
  }
  is_primary: boolean
  created_at?: string | null
}

export type PtSessionStatus = 'scheduled' | 'completed' | 'cancelled' | 'no_show'

export type PtSession = {
  id: number
  tenant_id: number
  branch_id: number
  branch?: { id: number; code: string; name: string }
  trainer_id: number
  trainer?: {
    id: number
    specialty: string | null
    user?: { id: number; name: string; email: string } | null
  }
  member_id: number
  member?: {
    id: number
    member_code: string
    first_name: string
    last_name: string
  }
  starts_at: string | null
  ends_at: string | null
  status: PtSessionStatus
  notes: string | null
  invoice_id: number | null
  created_at?: string | null
  updated_at?: string | null
}

export type WorkoutExercise = {
  id?: number
  workout_program_id?: number
  day_number: number | null
  sort_order: number | null
  name: string
  sets: number | null
  reps: string | null
  rest_seconds: number | null
  notes: string | null
  created_at?: string | null
  updated_at?: string | null
}

export type WorkoutProgram = {
  id: number
  tenant_id: number
  name: string
  goal: string | null
  duration_weeks: number | null
  description: string | null
  created_by_trainer_id: number | null
  created_by_trainer?: {
    id: number
    specialty: string | null
    user?: { id: number; name: string; email: string } | null
  } | null
  is_active: boolean
  exercises?: WorkoutExercise[]
  created_at?: string | null
  updated_at?: string | null
}

export type MemberWorkoutPlanStatus = 'active' | 'completed' | 'cancelled'

export type MemberWorkoutPlan = {
  id: number
  tenant_id: number
  member_id: number
  member?: {
    id: number
    member_code: string
    first_name: string
    last_name: string
  }
  workout_program_id: number
  workout_program?: WorkoutProgram
  trainer_id: number | null
  trainer?: {
    id: number
    specialty: string | null
    user?: { id: number; name: string; email: string } | null
  } | null
  start_date: string | null
  end_date: string | null
  status: MemberWorkoutPlanStatus
  is_published: boolean
  created_at?: string | null
  updated_at?: string | null
}

export type ExerciseInput = {
  day_number?: number | null
  sort_order?: number | null
  name: string
  sets?: number | null
  reps?: string | null
  rest_seconds?: number | null
  notes?: string | null
}

async function listMeta<T>(
  path: string,
  params: Record<string, unknown>,
): Promise<{ data: T[]; meta: PaginationMeta }> {
  const { data } = await api.get<ApiSuccess<T[]> & { meta: PaginationMeta }>(path, { params })
  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchTrainers(params: {
  page?: number
  per_page?: number
  search?: string
  is_active?: boolean | ''
} = {}) {
  return listMeta<Trainer>('/admin/trainers', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    search: params.search || undefined,
    is_active:
      params.is_active === '' || params.is_active === undefined
        ? undefined
        : params.is_active
          ? 1
          : 0,
  })
}

export async function createTrainer(payload: {
  user_id: number
  specialty?: string | null
  bio?: string | null
  is_active?: boolean
}) {
  const { data } = await api.post<ApiSuccess<Trainer>>('/admin/trainers', payload)
  return data.data
}

export async function updateTrainer(
  trainerId: number,
  payload: { specialty?: string | null; bio?: string | null; is_active?: boolean },
) {
  const { data } = await api.put<ApiSuccess<Trainer>>(`/admin/trainers/${trainerId}`, payload)
  return data.data
}

export async function deleteTrainer(trainerId: number) {
  const { data } = await api.delete<ApiSuccess<null>>(`/admin/trainers/${trainerId}`)
  return data.message
}

export async function fetchTrainerMembers(trainerId: number) {
  const { data } = await api.get<ApiSuccess<TrainerMember[]>>(
    `/admin/trainers/${trainerId}/members`,
  )
  return data.data
}

export async function assignTrainerMember(
  trainerId: number,
  payload: { member_id: number; is_primary?: boolean },
) {
  const { data } = await api.post<ApiSuccess<TrainerMember>>(
    `/admin/trainers/${trainerId}/members`,
    payload,
  )
  return data.data
}

export async function unassignTrainerMember(trainerId: number, memberId: number) {
  const { data } = await api.delete<ApiSuccess<null>>(
    `/admin/trainers/${trainerId}/members/${memberId}`,
  )
  return data.message
}

export async function fetchPtSessions(params: {
  page?: number
  per_page?: number
  trainer_id?: number | ''
  member_id?: number | ''
  branch_id?: number | ''
  status?: PtSessionStatus | ''
  date?: string
  from?: string
  to?: string
} = {}) {
  return listMeta<PtSession>('/admin/pt-sessions', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    trainer_id: params.trainer_id || undefined,
    member_id: params.member_id || undefined,
    branch_id: params.branch_id || undefined,
    status: params.status || undefined,
    date: params.date || undefined,
    from: params.from || undefined,
    to: params.to || undefined,
  })
}

export async function fetchPtSession(sessionId: number) {
  const { data } = await api.get<ApiSuccess<PtSession>>(`/admin/pt-sessions/${sessionId}`)
  return data.data
}

export async function createPtSession(payload: {
  branch_id: number
  trainer_id: number
  member_id: number
  starts_at: string
  ends_at?: string | null
  notes?: string | null
}) {
  const { data } = await api.post<ApiSuccess<PtSession>>('/admin/pt-sessions', payload)
  return data.data
}

export async function updatePtSession(
  sessionId: number,
  payload: { starts_at?: string; ends_at?: string | null; notes?: string | null },
) {
  const { data } = await api.put<ApiSuccess<PtSession>>(`/admin/pt-sessions/${sessionId}`, payload)
  return data.data
}

export async function completePtSession(sessionId: number, notes?: string | null) {
  const { data } = await api.post<ApiSuccess<PtSession>>(
    `/admin/pt-sessions/${sessionId}/complete`,
    { notes: notes || undefined },
  )
  return data.data
}

export async function cancelPtSession(sessionId: number, notes?: string | null) {
  const { data } = await api.post<ApiSuccess<PtSession>>(
    `/admin/pt-sessions/${sessionId}/cancel`,
    { notes: notes || undefined },
  )
  return data.data
}

export async function noShowPtSession(sessionId: number, notes?: string | null) {
  const { data } = await api.post<ApiSuccess<PtSession>>(
    `/admin/pt-sessions/${sessionId}/no-show`,
    { notes: notes || undefined },
  )
  return data.data
}

export async function fetchWorkoutPrograms(params: {
  page?: number
  per_page?: number
  search?: string
  is_active?: boolean | ''
} = {}) {
  return listMeta<WorkoutProgram>('/admin/workout-programs', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    search: params.search || undefined,
    is_active:
      params.is_active === '' || params.is_active === undefined
        ? undefined
        : params.is_active
          ? 1
          : 0,
  })
}

export async function fetchWorkoutProgram(programId: number) {
  const { data } = await api.get<ApiSuccess<WorkoutProgram>>(
    `/admin/workout-programs/${programId}`,
  )
  return data.data
}

export async function createWorkoutProgram(payload: {
  name: string
  goal?: string | null
  duration_weeks?: number | null
  description?: string | null
  created_by_trainer_id?: number | null
  is_active?: boolean
  exercises?: ExerciseInput[]
}) {
  const { data } = await api.post<ApiSuccess<WorkoutProgram>>('/admin/workout-programs', payload)
  return data.data
}

export async function updateWorkoutProgram(
  programId: number,
  payload: {
    name?: string
    goal?: string | null
    duration_weeks?: number | null
    description?: string | null
    created_by_trainer_id?: number | null
    is_active?: boolean
    exercises?: ExerciseInput[]
  },
) {
  const { data } = await api.put<ApiSuccess<WorkoutProgram>>(
    `/admin/workout-programs/${programId}`,
    payload,
  )
  return data.data
}

export async function deleteWorkoutProgram(programId: number) {
  const { data } = await api.delete<ApiSuccess<null>>(`/admin/workout-programs/${programId}`)
  return data.message
}

export async function fetchMemberWorkoutPlans(params: {
  page?: number
  per_page?: number
  member_id?: number | ''
  trainer_id?: number | ''
  workout_program_id?: number | ''
  status?: MemberWorkoutPlanStatus | ''
  is_published?: boolean | ''
} = {}) {
  return listMeta<MemberWorkoutPlan>('/admin/member-workout-plans', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    member_id: params.member_id || undefined,
    trainer_id: params.trainer_id || undefined,
    workout_program_id: params.workout_program_id || undefined,
    status: params.status || undefined,
    is_published:
      params.is_published === '' || params.is_published === undefined
        ? undefined
        : params.is_published
          ? 1
          : 0,
  })
}

export async function createMemberWorkoutPlan(payload: {
  member_id: number
  workout_program_id: number
  start_date: string
  end_date?: string | null
  trainer_id?: number | null
}) {
  const { data } = await api.post<ApiSuccess<MemberWorkoutPlan>>(
    '/admin/member-workout-plans',
    payload,
  )
  return data.data
}

export async function publishMemberWorkoutPlan(planId: number) {
  const { data } = await api.post<ApiSuccess<MemberWorkoutPlan>>(
    `/admin/member-workout-plans/${planId}/publish`,
  )
  return data.data
}

export async function cancelMemberWorkoutPlan(planId: number) {
  const { data } = await api.post<ApiSuccess<MemberWorkoutPlan>>(
    `/admin/member-workout-plans/${planId}/cancel`,
  )
  return data.data
}
