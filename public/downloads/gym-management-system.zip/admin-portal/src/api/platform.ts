import { api } from '@/api/client'
import type { ApiSuccess } from '@/api/types'

export type PlatformTenantStatus = 'trial' | 'active' | 'suspended' | 'cancelled' | string

export type PlatformTenant = {
  id: number
  saas_plan_id: number | null
  slug: string
  name: string
  legal_name?: string | null
  status: PlatformTenantStatus
  primary_country?: string | null
  base_currency?: string | null
  timezone?: string | null
  email?: string | null
  phone?: string | null
  trial_ends_at?: string | null
  suspended_at?: string | null
  created_at?: string | null
  saas_plan?: {
    id: number
    code: string
    name: string
  } | null
}

export type SaasPlanLimits = {
  max_seats?: number | null
  max_branches?: number | null
  max_members?: number | null
  module_pos?: boolean
  module_nutrition?: boolean
  module_waitlist?: boolean
  module_referral?: boolean
  module_equipment?: boolean
  storage_mb?: number | null
}

export type SaasPlan = {
  id: number
  code: string
  name: string
  description?: string | null
  price: string | number
  currency_code: string
  billing_interval: string
  is_active: boolean
  limits?: SaasPlanLimits | null
  created_at?: string | null
  updated_at?: string | null
}

export type ProvisionTenantPayload = {
  saas_plan_id: number
  slug: string
  name: string
  legal_name?: string
  primary_country?: string
  base_currency?: string
  timezone?: string
  email?: string
  phone?: string
  trial_days?: number
}

export type CreateSaasPlanPayload = {
  code: string
  name: string
  description?: string
  price?: number
  currency_code?: string
  billing_interval?: 'monthly' | 'yearly'
  is_active?: boolean
  limits?: SaasPlanLimits
}

export async function fetchPlatformTenants(status?: string) {
  const { data } = await api.get<ApiSuccess<PlatformTenant[]>>('/platform/tenants', {
    params: status ? { status } : undefined,
  })
  return data.data
}

export async function provisionPlatformTenant(payload: ProvisionTenantPayload) {
  const { data } = await api.post<ApiSuccess<PlatformTenant>>('/platform/tenants', payload)
  return data.data
}

export async function activatePlatformTenant(id: number) {
  const { data } = await api.post<ApiSuccess<PlatformTenant>>(`/platform/tenants/${id}/activate`)
  return data.data
}

export async function suspendPlatformTenant(id: number, reason?: string) {
  const { data } = await api.post<ApiSuccess<PlatformTenant>>(`/platform/tenants/${id}/suspend`, {
    reason: reason ?? 'manual',
  })
  return data.data
}

export async function reactivatePlatformTenant(id: number) {
  const { data } = await api.post<ApiSuccess<PlatformTenant>>(
    `/platform/tenants/${id}/reactivate`,
  )
  return data.data
}

export async function extendPlatformTenantTrial(id: number, days: number) {
  const { data } = await api.post<ApiSuccess<PlatformTenant>>(
    `/platform/tenants/${id}/extend-trial`,
    { days },
  )
  return data.data
}

export async function assignPlatformTenantPlan(id: number, saas_plan_id: number) {
  const { data } = await api.put<ApiSuccess<PlatformTenant>>(`/platform/tenants/${id}/plan`, {
    saas_plan_id,
  })
  return data.data
}

export async function fetchSaasPlans() {
  const { data } = await api.get<ApiSuccess<SaasPlan[]>>('/platform/saas-plans')
  return data.data
}

export async function createSaasPlan(payload: CreateSaasPlanPayload) {
  const { data } = await api.post<ApiSuccess<SaasPlan>>('/platform/saas-plans', payload)
  return data.data
}

export type UpdateSaasPlanPayload = {
  code?: string
  name?: string
  description?: string | null
  price?: number
  currency_code?: string
  billing_interval?: 'monthly' | 'yearly'
  is_active?: boolean
}

export async function updateSaasPlan(id: number, payload: UpdateSaasPlanPayload) {
  const { data } = await api.put<ApiSuccess<SaasPlan>>(`/platform/saas-plans/${id}`, payload)
  return data.data
}

export async function updateSaasPlanLimits(id: number, limits: SaasPlanLimits) {
  const { data } = await api.put<ApiSuccess<SaasPlan>>(
    `/platform/saas-plans/${id}/limits`,
    limits,
  )
  return data.data
}

export async function deleteSaasPlan(id: number) {
  const { data } = await api.delete<ApiSuccess<null>>(`/platform/saas-plans/${id}`)
  return data
}

export type PlatformBillingSummary = {
  mrr: number
  currency_code: string
  outstanding: number
  collected_this_month: number
  open_invoices: number
  paid_invoices: number
  billable_tenants: number
  trial_tenants: number
}

export type PlatformSubscriptionRow = {
  tenant_id: number
  tenant_name: string
  tenant_slug: string
  tenant_status: string
  plan_id: number | null
  plan_name?: string | null
  plan_code?: string | null
  price: number
  currency_code: string
  billing_interval: string
  monthly_amount: number
  billable: boolean
  open_balance: number
  trial_ends_at?: string | null
}

export type PlatformInvoice = {
  id: number
  tenant_id: number
  invoice_number: string
  status: string
  currency_code: string
  subtotal: string | number
  tax_total: string | number
  grand_total: string | number
  due_date?: string | null
  issued_at?: string | null
  paid_at?: string | null
  billing_mode: string
  tenant?: {
    id: number
    name: string
    slug: string
    status: string
    saas_plan?: {
      id: number
      name: string
      code: string
      price: string | number
      currency_code: string
      billing_interval: string
    } | null
  } | null
}

export type PlatformPayment = {
  id: number
  tenant_id: number
  platform_invoice_id: number | null
  amount: string | number
  currency_code: string
  method: string
  reference?: string | null
  paid_at?: string | null
  tenant?: { id: number; name: string; slug: string } | null
  invoice?: { id: number; invoice_number: string; status: string } | null
}

export type PlatformBillingOverview = {
  summary: PlatformBillingSummary
  subscriptions: PlatformSubscriptionRow[]
  invoices: PlatformInvoice[]
  payments: PlatformPayment[]
}

export async function fetchPlatformBillingOverview(status?: string) {
  const { data } = await api.get<ApiSuccess<PlatformBillingOverview>>('/platform/billing/overview', {
    params: status ? { status } : undefined,
  })
  return data.data
}

export async function issuePlatformInvoice(payload: {
  tenant_id: number
  subtotal?: number
  tax_total?: number
  currency_code?: string
  due_date?: string
  billing_mode?: 'manual' | 'automated'
}) {
  const { data } = await api.post<ApiSuccess<PlatformInvoice>>('/platform/billing/invoices', payload)
  return data.data
}

export async function recordPlatformInvoicePayment(
  invoiceId: number,
  payload: { amount: number; method?: string; reference?: string; paid_at?: string },
) {
  const { data } = await api.post<ApiSuccess<PlatformPayment>>(
    `/platform/billing/invoices/${invoiceId}/payments`,
    payload,
  )
  return data.data
}

export async function voidPlatformInvoice(invoiceId: number) {
  const { data } = await api.post<ApiSuccess<PlatformInvoice>>(
    `/platform/billing/invoices/${invoiceId}/void`,
  )
  return data.data
}
