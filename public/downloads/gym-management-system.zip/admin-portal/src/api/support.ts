import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type TicketStatus = 'open' | 'in_progress' | 'resolved' | 'closed'
export type TicketPriority = 'low' | 'medium' | 'high' | 'urgent'

export type TicketMember = {
  id: number
  first_name: string
  last_name: string
  email: string | null
  member_code: string
}

export type TicketUser = {
  id: number
  name: string
  email: string
}

export type SupportTicketMessage = {
  id: number
  support_ticket_id: number
  sender_user_id: number | null
  sender_member_id: number | null
  sender_user?: TicketUser | null
  sender_member?: {
    id: number
    first_name: string
    last_name: string
    email: string | null
  } | null
  message: string
  attachment_path: string | null
  created_at?: string | null
  updated_at?: string | null
}

export type SupportTicket = {
  id: number
  tenant_id: number
  member_id: number
  member?: TicketMember | null
  assigned_user_id: number | null
  assigned_user?: TicketUser | null
  ticket_number: string
  category: string
  subject: string
  status: TicketStatus
  priority: TicketPriority
  messages?: SupportTicketMessage[]
  created_at?: string | null
  updated_at?: string | null
}

export type CreateTicketPayload = {
  member_id: number
  category: string
  subject: string
  priority?: TicketPriority
  message: string
  attachment_path?: string | null
}

async function listMeta<T>(
  path: string,
  params: Record<string, unknown>,
): Promise<{ data: T[]; meta: PaginationMeta }> {
  const { data } = await api.get<ApiSuccess<T[]> & { meta: PaginationMeta }>(path, { params })
  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchSupportTickets(params: {
  page?: number
  per_page?: number
  status?: TicketStatus | ''
  priority?: TicketPriority | ''
  member_id?: number | ''
  assigned_user_id?: number | ''
  search?: string
} = {}) {
  return listMeta<SupportTicket>('/admin/support-tickets', {
    page: params.page ?? 1,
    per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
    status: params.status || undefined,
    priority: params.priority || undefined,
    member_id: params.member_id || undefined,
    assigned_user_id: params.assigned_user_id || undefined,
    search: params.search || undefined,
  })
}

export async function fetchSupportTicket(ticketId: number) {
  const { data } = await api.get<ApiSuccess<SupportTicket>>(
    `/admin/support-tickets/${ticketId}`,
  )
  return data.data
}

export async function createSupportTicket(payload: CreateTicketPayload) {
  const { data } = await api.post<ApiSuccess<SupportTicket>>(
    '/admin/support-tickets',
    payload,
  )
  return data.data
}

export async function assignSupportTicket(ticketId: number, assignedUserId: number) {
  const { data } = await api.post<ApiSuccess<SupportTicket>>(
    `/admin/support-tickets/${ticketId}/assign`,
    { assigned_user_id: assignedUserId },
  )
  return data.data
}

export async function replySupportTicket(
  ticketId: number,
  payload: { message: string; attachment_path?: string | null },
) {
  const { data } = await api.post<ApiSuccess<SupportTicket>>(
    `/admin/support-tickets/${ticketId}/reply`,
    payload,
  )
  return data.data
}

export async function startSupportTicket(ticketId: number) {
  const { data } = await api.post<ApiSuccess<SupportTicket>>(
    `/admin/support-tickets/${ticketId}/start`,
  )
  return data.data
}

export async function resolveSupportTicket(ticketId: number) {
  const { data } = await api.post<ApiSuccess<SupportTicket>>(
    `/admin/support-tickets/${ticketId}/resolve`,
  )
  return data.data
}

export async function closeSupportTicket(ticketId: number) {
  const { data } = await api.post<ApiSuccess<SupportTicket>>(
    `/admin/support-tickets/${ticketId}/close`,
  )
  return data.data
}
