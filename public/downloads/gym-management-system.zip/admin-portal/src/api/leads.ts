import { api } from '@/api/client'
import type { ApiSuccess, PaginationMeta } from '@/api/types'
import { DEFAULT_PAGE_SIZE } from '@/lib/pagination'

export type LeadBranch = {
  id: number
  code: string
  name: string
}

export type Lead = {
  id: number
  tenant_id: number
  home_branch_id: number | null
  home_branch?: LeadBranch | null
  member_code: string
  first_name: string
  last_name: string
  full_name: string
  email: string | null
  phone: string | null
  gender: string | null
  date_of_birth: string | null
  emergency_name: string | null
  emergency_phone: string | null
  status: string
  joined_at: string | null
  referral_code: string | null
  referred_by_member_id: number | null
  created_at?: string | null
  updated_at?: string | null
}

export type LeadNote = {
  id: number
  member_id: number
  note: string
  is_alert: boolean
  created_at: string | null
  updated_at?: string | null
}

export type LeadListParams = {
  page?: number
  per_page?: number
  search?: string
  branch_id?: number | ''
}

export type LeadListResult = {
  data: Lead[]
  meta: PaginationMeta
}

export type CreateLeadPayload = {
  home_branch_id: number
  first_name: string
  last_name: string
  email?: string | null
  phone?: string | null
  gender?: string | null
  date_of_birth?: string | null
  emergency_name?: string | null
  emergency_phone?: string | null
  joined_at?: string | null
  referred_by_member_id?: number | null
}

export type UpdateLeadPayload = Partial<
  Omit<CreateLeadPayload, 'joined_at' | 'referred_by_member_id'>
>

export async function fetchLeads(params: LeadListParams = {}): Promise<LeadListResult> {
  const { data } = await api.get<ApiSuccess<Lead[]> & { meta: PaginationMeta }>('/admin/leads', {
    params: {
      page: params.page ?? 1,
      per_page: params.per_page ?? DEFAULT_PAGE_SIZE,
      search: params.search || undefined,
      branch_id: params.branch_id || undefined,
    },
  })

  return {
    data: data.data,
    meta: data.meta ?? {
      current_page: 1,
      per_page: DEFAULT_PAGE_SIZE,
      total: 0,
      last_page: 1,
    },
  }
}

export async function fetchLead(leadId: number) {
  const { data } = await api.get<ApiSuccess<Lead>>(`/admin/leads/${leadId}`)
  return data.data
}

export async function createLead(payload: CreateLeadPayload) {
  const { data } = await api.post<ApiSuccess<Lead>>('/admin/leads', payload)
  return data.data
}

export async function updateLead(leadId: number, payload: UpdateLeadPayload) {
  const { data } = await api.put<ApiSuccess<Lead>>(`/admin/leads/${leadId}`, payload)
  return data.data
}

export async function convertLead(leadId: number) {
  const { data } = await api.post<ApiSuccess<Lead>>(`/admin/leads/${leadId}/convert`)
  return data.data
}

export async function fetchLeadNotes(leadId: number) {
  const { data } = await api.get<ApiSuccess<LeadNote[]>>(`/admin/leads/${leadId}/notes`)
  return data.data
}

export async function addLeadNote(
  leadId: number,
  payload: { note: string; is_alert?: boolean },
) {
  const { data } = await api.post<ApiSuccess<LeadNote>>(`/admin/leads/${leadId}/notes`, payload)
  return data.data
}
