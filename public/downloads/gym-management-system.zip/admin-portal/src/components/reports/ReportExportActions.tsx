import { Download, FileSpreadsheet, FileText } from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { useFeedback } from '@/feedback/FeedbackProvider'
import {
  exportRowsToExcel,
  exportRowsToPdf,
  type ExportColumn,
} from '@/lib/exportReport'

export function ReportExportActions<T>({
  reportKey,
  reportName,
  columns,
  rows,
  subtitle,
  disabled,
}: {
  reportKey: string
  reportName: string
  columns: ExportColumn<T>[]
  rows: T[]
  subtitle?: string
  disabled?: boolean
}) {
  const { showSuccess } = useFeedback()
  const empty = rows.length === 0

  return (
    <div className="flex flex-wrap gap-2">
      <Button
        size="sm"
        variant="secondary"
        disabled={disabled || empty}
        onClick={() => {
          const file = exportRowsToExcel(reportKey, reportName, columns, rows)
          showSuccess(`Excel export ready: ${file}`)
        }}
      >
        <FileSpreadsheet className="h-4 w-4" />
        Export Excel
      </Button>
      <Button
        size="sm"
        variant="secondary"
        disabled={disabled || empty}
        onClick={() => {
          const file = exportRowsToPdf(reportKey, reportName, columns, rows, subtitle)
          showSuccess(`PDF downloaded: ${file}`)
        }}
      >
        <FileText className="h-4 w-4" />
        Export PDF
      </Button>
      <span className="inline-flex items-center gap-1.5 self-center text-xs text-muted">
        <Download className="h-3.5 w-3.5" />
        {empty ? 'No rows to export' : `${rows.length} row(s)`}
      </span>
    </div>
  )
}
