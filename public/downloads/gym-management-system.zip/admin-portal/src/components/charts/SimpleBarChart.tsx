import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'

export type ChartPoint = {
  label: string
  value: number
}

export function SimpleBarChart({
  title,
  description,
  data,
}: {
  title: string
  description?: string
  data: ChartPoint[]
}) {
  return (
    <Card className="h-full">
      <CardTitle>{title}</CardTitle>
      {description ? <CardDescription>{description}</CardDescription> : null}
      <div className="mt-5 h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
            <CartesianGrid stroke="rgba(255,255,255,0.12)" vertical={false} />
            <XAxis
              dataKey="label"
              tickLine={false}
              axisLine={false}
              tick={{ fill: '#b4becb', fontSize: 12 }}
            />
            <YAxis tickLine={false} axisLine={false} tick={{ fill: '#b4becb', fontSize: 12 }} />
            <Tooltip
              cursor={{ fill: 'rgba(198,255,26,0.08)' }}
              contentStyle={{
                borderRadius: 12,
                border: '1px solid rgba(255,255,255,0.16)',
                background: 'rgba(12,16,22,0.92)',
                color: '#f3f6f9',
                boxShadow: 'none',
              }}
            />
            <Bar dataKey="value" fill="#c6ff1a" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}
