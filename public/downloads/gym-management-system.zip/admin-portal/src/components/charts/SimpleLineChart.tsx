import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { Card, CardDescription, CardTitle } from '@/components/ui/Card'
import type { ChartPoint } from '@/components/charts/SimpleBarChart'

export function SimpleLineChart({
  title,
  description,
  data,
}: {
  title: string
  description?: string
  data: ChartPoint[]
}) {
  return (
    <Card className="h-full">
      <CardTitle>{title}</CardTitle>
      {description ? <CardDescription>{description}</CardDescription> : null}
      <div className="mt-5 h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
            <CartesianGrid stroke="rgba(255,255,255,0.12)" vertical={false} />
            <XAxis
              dataKey="label"
              tickLine={false}
              axisLine={false}
              tick={{ fill: '#b4becb', fontSize: 12 }}
            />
            <YAxis tickLine={false} axisLine={false} tick={{ fill: '#b4becb', fontSize: 12 }} />
            <Tooltip
              contentStyle={{
                borderRadius: 12,
                border: '1px solid rgba(255,255,255,0.16)',
                background: 'rgba(12,16,22,0.92)',
                color: '#f3f6f9',
                boxShadow: 'none',
              }}
            />
            <Line
              type="monotone"
              dataKey="value"
              stroke="#c6ff1a"
              strokeWidth={3}
              dot={{ r: 4, fill: '#f3f6f9', strokeWidth: 0 }}
              activeDot={{ r: 5, fill: '#c6ff1a' }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}
