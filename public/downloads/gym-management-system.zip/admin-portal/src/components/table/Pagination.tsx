import { ChevronLeft, ChevronRight } from 'lucide-react'
import type { PaginationMeta } from '@/api/types'
import { Button } from '@/components/ui/Button'
import { cn } from '@/lib/cn'

type Props = {
  meta?: PaginationMeta | null
  onPageChange: (page: number) => void
  className?: string
  /** Hide entirely when there is nothing to show */
  hideWhenEmpty?: boolean
}

export function Pagination({
  meta,
  onPageChange,
  className,
  hideWhenEmpty = true,
}: Props) {
  if (!meta || (hideWhenEmpty && meta.total === 0)) {
    return null
  }

  const from = meta.total === 0 ? 0 : (meta.current_page - 1) * meta.per_page + 1
  const to = Math.min(meta.current_page * meta.per_page, meta.total)
  const canPrev = meta.current_page > 1
  const canNext = meta.current_page < meta.last_page

  return (
    <div
      className={cn(
        'mt-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3',
        className,
      )}
    >
      <p className="text-sm text-muted">
        Showing{' '}
        <span className="font-medium text-ink">
          {from}–{to}
        </span>{' '}
        of <span className="font-medium text-ink">{meta.total}</span>
        <span className="text-muted"> · {meta.per_page} per page</span>
      </p>

      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="secondary"
          size="sm"
          disabled={!canPrev}
          onClick={() => onPageChange(meta.current_page - 1)}
          aria-label="Previous page"
        >
          <ChevronLeft className="h-4 w-4" />
          Prev
        </Button>
        <span className="min-w-[5.5rem] text-center text-sm font-medium text-ink">
          {meta.current_page} / {meta.last_page}
        </span>
        <Button
          type="button"
          variant="secondary"
          size="sm"
          disabled={!canNext}
          onClick={() => onPageChange(meta.current_page + 1)}
          aria-label="Next page"
        >
          Next
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
