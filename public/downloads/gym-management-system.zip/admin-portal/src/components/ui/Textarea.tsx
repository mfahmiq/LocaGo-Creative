import { cn } from '@/lib/cn'
import type { TextareaHTMLAttributes } from 'react'

export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      className={cn(
        'min-h-28 w-full rounded-xl border border-white/18 bg-white/12 px-3.5 py-2.5 text-ink outline-none transition placeholder:text-muted/80 focus:border-accent focus:bg-white/16 focus:ring-2 focus:ring-accent/25',
        'aria-[invalid=true]:border-danger/60 aria-[invalid=true]:focus:border-danger aria-[invalid=true]:focus:ring-danger/25',
        className,
      )}
      {...props}
    />
  )
}
