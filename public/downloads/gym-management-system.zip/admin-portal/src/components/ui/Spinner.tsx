import { cn } from '@/lib/cn'

export function Spinner({
  label = 'Loading…',
  className,
}: {
  label?: string
  className?: string
}) {
  return (
    <div className={cn('flex flex-col items-center gap-3 text-muted', className)}>
      <div className="h-9 w-9 animate-spin rounded-full border-2 border-white/20 border-t-accent" />
      <p className="text-sm font-medium">{label}</p>
    </div>
  )
}
