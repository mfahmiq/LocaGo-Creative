import type { ReactNode } from 'react'
import { Dumbbell } from 'lucide-react'
import { cn } from '@/lib/cn'

export function EmptyState({
  title,
  description,
  action,
  className,
}: {
  title: string
  description?: string
  action?: ReactNode
  className?: string
}) {
  return (
    <div
      className={cn(
        'glass-panel flex flex-col items-center justify-center rounded-2xl border-dashed px-6 py-14 text-center',
        className,
      )}
    >
      <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-accent-soft text-accent">
        <Dumbbell className="h-5 w-5" />
      </div>
      <h3 className="font-display text-xl font-bold uppercase tracking-wide text-ink">{title}</h3>
      {description ? <p className="mt-2 max-w-md text-sm leading-relaxed text-muted">{description}</p> : null}
      {action ? <div className="mt-5">{action}</div> : null}
    </div>
  )
}
