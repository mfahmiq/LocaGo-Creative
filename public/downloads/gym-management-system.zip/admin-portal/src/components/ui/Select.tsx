import { cn } from '@/lib/cn'
import type { SelectHTMLAttributes } from 'react'

export function Select({ className, children, ...props }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      className={cn(
        'h-11 w-full rounded-xl border border-white/18 bg-slate-panel px-3.5 text-ink outline-none transition [color-scheme:dark] focus:border-accent focus:bg-steel focus:ring-2 focus:ring-accent/25',
        'aria-[invalid=true]:border-danger/60 aria-[invalid=true]:focus:border-danger aria-[invalid=true]:focus:ring-danger/25',
        className,
      )}
      {...props}
    >
      {children}
    </select>
  )
}
