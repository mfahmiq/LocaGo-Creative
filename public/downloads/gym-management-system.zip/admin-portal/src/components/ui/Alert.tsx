import { cn } from '@/lib/cn'
import type { HTMLAttributes } from 'react'

type Tone = 'info' | 'danger' | 'success'

const tones: Record<Tone, string> = {
  info: 'border-white/15 bg-white/10 text-ink backdrop-blur-md',
  danger: 'border-danger/30 bg-danger/15 text-danger backdrop-blur-md',
  success: 'border-success/30 bg-success/15 text-success backdrop-blur-md',
}

export function Alert({
  className,
  tone = 'info',
  ...props
}: HTMLAttributes<HTMLDivElement> & { tone?: Tone }) {
  return (
    <div
      role="alert"
      className={cn('rounded-xl border px-4 py-3 text-sm leading-relaxed', tones[tone], className)}
      {...props}
    />
  )
}
