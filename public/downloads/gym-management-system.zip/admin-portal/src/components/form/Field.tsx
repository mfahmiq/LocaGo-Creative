import type { ReactElement, ReactNode } from 'react'
import { FormField } from '@/components/form/FormField'
import { cn } from '@/lib/cn'

/**
 * Label + control + optional inline error for non-react-hook-form screens.
 * Pass `required` to show a mandatory asterisk on the label.
 */
export function Field({
  label,
  htmlFor,
  error,
  hint,
  required,
  children,
  className,
}: {
  label: string
  htmlFor?: string
  error?: string
  hint?: string
  required?: boolean
  children: ReactNode
  className?: string
}) {
  return (
    <FormField
      label={label}
      htmlFor={htmlFor}
      error={error}
      hint={hint}
      required={required}
      className={className}
    >
      {children}
    </FormField>
  )
}

export function FieldError({ error, className }: { error?: string; className?: string }) {
  if (!error) return null
  return (
    <p className={cn('text-xs font-medium text-danger', className)} role="alert">
      {error}
    </p>
  )
}

/** Clone helper type for pages that prefer keeping Label/Input separate */
export type FieldControl = ReactElement
