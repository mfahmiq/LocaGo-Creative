import { useFormContext, type FieldPath, type FieldValues } from 'react-hook-form'
import { FormField } from '@/components/form/FormField'
import { Input, type InputProps } from '@/components/ui/Input'

type Props<T extends FieldValues> = InputProps & {
  name: FieldPath<T>
  label: string
  hint?: string
}

export function TextField<T extends FieldValues>({
  name,
  label,
  hint,
  required,
  ...inputProps
}: Props<T>) {
  const {
    register,
    formState: { errors },
  } = useFormContext<T>()

  const error = errors[name]?.message
  const message = typeof error === 'string' ? error : undefined
  const isRequired = Boolean(required)

  return (
    <FormField label={label} htmlFor={name} error={message} hint={hint} required={isRequired}>
      <Input
        id={name}
        aria-invalid={Boolean(message)}
        aria-required={isRequired || undefined}
        {...register(name)}
        {...inputProps}
        required={required}
      />
    </FormField>
  )
}
