import { useEffect, useState } from 'react'
import { BACKGROUND_ROTATE_MS, gymBackgroundImages } from '@/config/backgrounds'
import { cn } from '@/lib/cn'

/**
 * Full-viewport gym photo slideshow. Pages stay transparent so imagery shows through.
 */
export function BackgroundSlideshow() {
  const [index, setIndex] = useState(0)
  const images = gymBackgroundImages

  useEffect(() => {
    if (images.length <= 1) return

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduced) return

    const id = window.setInterval(() => {
      setIndex((current) => (current + 1) % images.length)
    }, BACKGROUND_ROTATE_MS)

    return () => window.clearInterval(id)
  }, [images.length])

  useEffect(() => {
    const next = images[(index + 1) % images.length]
    if (!next) return
    const preload = new Image()
    preload.src = next
  }, [index, images])

  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden>
      {images.map((src, i) => (
        <div
          key={src}
          className={cn(
            'absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-[1600ms] ease-in-out',
            i === index ? 'opacity-100' : 'opacity-0',
          )}
          style={{ backgroundImage: `url(${src})` }}
        />
      ))}

      {/* Readable gym wash — keeps UI legible without hiding the photo */}
      <div className="absolute inset-0 bg-[linear-gradient(120deg,rgba(6,10,14,0.84)_0%,rgba(8,12,18,0.72)_42%,rgba(6,10,14,0.8)_100%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(198,255,26,0.08),transparent_45%)]" />
      <div className="absolute inset-0 gym-mesh opacity-20" />
    </div>
  )
}
