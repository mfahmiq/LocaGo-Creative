const TOKEN_KEY = 'gms.admin.token'
const TENANT_KEY = 'gms.admin.tenant'
const PORTAL_KEY = 'gms.admin.portal'
const BRANCH_KEY = 'gms.admin.branch'

export type PortalKind = 'admin' | 'platform'

export const authStorage = {
  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY)
  },
  setToken(token: string) {
    localStorage.setItem(TOKEN_KEY, token)
  },
  clearToken() {
    localStorage.removeItem(TOKEN_KEY)
  },
  getTenantSlug(): string | null {
    return localStorage.getItem(TENANT_KEY)
  },
  setTenantSlug(slug: string) {
    localStorage.setItem(TENANT_KEY, slug)
  },
  clearTenantSlug() {
    localStorage.removeItem(TENANT_KEY)
  },
  getPortal(): PortalKind | null {
    const value = localStorage.getItem(PORTAL_KEY)
    return value === 'admin' || value === 'platform' ? value : null
  },
  setPortal(portal: PortalKind) {
    localStorage.setItem(PORTAL_KEY, portal)
  },
  clearPortal() {
    localStorage.removeItem(PORTAL_KEY)
  },
  getBranchId(): number | null {
    const raw = localStorage.getItem(BRANCH_KEY)
    if (!raw) return null
    const id = Number(raw)
    return Number.isFinite(id) ? id : null
  },
  setBranchId(branchId: number) {
    localStorage.setItem(BRANCH_KEY, String(branchId))
  },
  clearBranchId() {
    localStorage.removeItem(BRANCH_KEY)
  },
  clearAll() {
    this.clearToken()
    this.clearTenantSlug()
    this.clearPortal()
    this.clearBranchId()
  },
}
