import { Navigate } from 'react-router-dom'
import { useAuth } from '@/auth/AuthContext'
import { Spinner } from '@/components/ui/Spinner'
import type { ReactNode } from 'react'

export function RequirePermission({
  permission,
  anyOf,
  children,
}: {
  permission?: string
  anyOf?: string[]
  children: ReactNode
}) {
  const { hasPermission, hasAnyPermission, isBootstrapping, isAuthenticated } = useAuth()

  if (isBootstrapping) {
    return (
      <div className="flex justify-center py-20">
        <Spinner label="Checking access…" />
      </div>
    )
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />
  }

  const allowed = anyOf?.length
    ? hasAnyPermission(anyOf)
    : permission
      ? hasPermission(permission)
      : true

  if (!allowed) {
    return <Navigate to="/" replace />
  }

  return children
}
