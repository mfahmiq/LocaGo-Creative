import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { fetchSessionMe, loginAdmin, logoutSession } from '@/api/auth'
import type { AdminUser, BranchSummary, PortalKind, TenantSummary } from '@/api/types'
import { authStorage } from '@/auth/storage'

type AuthContextValue = {
  user: AdminUser | null
  tenant: TenantSummary | null
  portal: PortalKind | null
  branches: BranchSummary[]
  branchId: number | null
  isTenantWide: boolean
  token: string | null
  isBootstrapping: boolean
  isAuthenticated: boolean
  login: (input: {
    email: string
    password: string
    tenantSlug?: string
  }) => Promise<void>
  logout: () => Promise<void>
  setBranchId: (branchId: number | null) => void
  hasPermission: (code: string) => boolean
  hasAnyPermission: (codes: string[]) => boolean
}

const AuthContext = createContext<AuthContextValue | null>(null)

function pickDefaultBranch(
  branches: BranchSummary[],
  isTenantWide: boolean,
  preferred?: number | null,
): number | null {
  if (preferred != null && branches.some((b) => b.id === preferred)) {
    return preferred
  }
  if (!isTenantWide && branches.length > 0) {
    return branches[0].id
  }
  if (branches.length === 1) {
    return branches[0].id
  }
  return preferred ?? null
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient()
  const [token, setToken] = useState<string | null>(() => authStorage.getToken())
  const [portal, setPortal] = useState<PortalKind | null>(() => {
    const stored = authStorage.getPortal()
    if (stored) return stored
    // Legacy sessions only had a token — default to admin and persist.
    if (authStorage.getToken()) {
      authStorage.setPortal('admin')
      return 'admin'
    }
    return null
  })
  const [branchId, setBranchIdState] = useState<number | null>(() => authStorage.getBranchId())

  const meQuery = useQuery({
    queryKey: ['admin', 'me', portal],
    queryFn: fetchSessionMe,
    enabled: Boolean(token && portal),
    retry: false,
    staleTime: 60_000,
  })

  useEffect(() => {
    if (meQuery.isError) {
      authStorage.clearAll()
      setToken(null)
      setPortal(null)
      setBranchIdState(null)
    }
  }, [meQuery.isError])

  useEffect(() => {
    if (!meQuery.data) return
    const next = pickDefaultBranch(
      meQuery.data.branches,
      meQuery.data.isTenantWide,
      authStorage.getBranchId(),
    )
    if (next != null) {
      authStorage.setBranchId(next)
      setBranchIdState(next)
    } else if (meQuery.data.isTenantWide) {
      // Gym owners may work tenant-wide without a forced branch.
      authStorage.clearBranchId()
      setBranchIdState(null)
    }
  }, [meQuery.data])

  const login = useCallback(
    async (input: { email: string; password: string; tenantSlug?: string }) => {
      const result = await loginAdmin({
        email: input.email,
        password: input.password,
        tenantSlug: input.tenantSlug,
      })

      authStorage.setToken(result.token)
      authStorage.setPortal(result.portal)

      if (result.portal === 'admin' && result.tenant) {
        authStorage.setTenantSlug(result.tenant.slug)
      } else {
        authStorage.clearTenantSlug()
      }

      const nextBranch = pickDefaultBranch(
        result.branches,
        result.is_tenant_wide,
        null,
      )
      if (nextBranch != null) {
        authStorage.setBranchId(nextBranch)
        setBranchIdState(nextBranch)
      } else {
        authStorage.clearBranchId()
        setBranchIdState(null)
      }

      setPortal(result.portal)
      setToken(result.token)
      queryClient.setQueryData(['admin', 'me', result.portal], {
        portal: result.portal,
        user: result.user,
        tenant: result.tenant,
        branches: result.branches,
        isTenantWide: result.is_tenant_wide,
      })
    },
    [queryClient],
  )

  const logout = useCallback(async () => {
    try {
      if (authStorage.getToken()) {
        await logoutSession()
      }
    } finally {
      authStorage.clearAll()
      setToken(null)
      setPortal(null)
      setBranchIdState(null)
      queryClient.clear()
    }
  }, [queryClient])

  const setBranchId = useCallback(
    (id: number | null) => {
      if (id == null) {
        authStorage.clearBranchId()
        setBranchIdState(null)
      } else {
        authStorage.setBranchId(id)
        setBranchIdState(id)
      }

      // Drop cached admin/report data so the active page refetches with the
      // new X-Branch-Id header and synced branch filters.
      void queryClient.invalidateQueries({
        predicate: (query) => {
          const key = query.queryKey
          if (!Array.isArray(key) || key.length === 0) return false
          const root = key[0]
          if (root === 'reports' || root === 'memberships') return true
          // Refresh admin lists/forms, but leave the session `me` query alone.
          return root === 'admin' && key[1] !== 'me'
        },
      })
    },
    [queryClient],
  )

  const user = meQuery.data?.user ?? null
  const tenant = meQuery.data?.tenant ?? null
  const branches = meQuery.data?.branches ?? []
  const isTenantWide = meQuery.data?.isTenantWide ?? false

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      tenant,
      portal,
      branches,
      branchId,
      isTenantWide,
      token,
      isBootstrapping: Boolean(token && portal) && meQuery.isLoading,
      isAuthenticated: Boolean(token && user),
      login,
      logout,
      setBranchId,
      hasPermission: (code: string) => {
        if (!user?.permissions) return false
        return user.permissions.includes(code)
      },
      hasAnyPermission: (codes: string[]) => {
        if (!user?.permissions?.length) return false
        return codes.some((code) => user.permissions!.includes(code))
      },
    }),
    [
      user,
      tenant,
      portal,
      branches,
      branchId,
      isTenantWide,
      token,
      meQuery.isLoading,
      login,
      logout,
      setBranchId,
    ],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return ctx
}
