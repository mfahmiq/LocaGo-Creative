import { useState } from 'react'
import { Outlet } from 'react-router-dom'
import { Sidebar } from '@/layouts/Sidebar'
import { Topbar } from '@/layouts/Topbar'
import { useAuth } from '@/auth/AuthContext'
import { cn } from '@/lib/cn'

export function AppLayout() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const { portal, branchId } = useAuth()

  // Remount the active page when the topbar branch changes so local filters,
  // forms, and query keys re-initialize against the new scope.
  const outletKey =
    portal === 'admin' ? `branch-${branchId ?? 'all'}` : 'platform'

  return (
    <div className="min-h-screen bg-transparent lg:grid lg:grid-cols-[17.5rem_1fr]">
      <div className="hidden lg:block">
        <div className="sticky top-0 h-screen p-3 pr-0">
          <div className="h-full overflow-hidden rounded-2xl border border-white/12">
            <Sidebar />
          </div>
        </div>
      </div>

      <div
        className={cn(
          'fixed inset-0 z-40 bg-ink-soft/55 backdrop-blur-[2px] transition lg:hidden',
          mobileOpen ? 'opacity-100' : 'pointer-events-none opacity-0',
        )}
        onClick={() => setMobileOpen(false)}
        aria-hidden={!mobileOpen}
      />
      <div
        className={cn(
          'fixed inset-y-0 left-0 z-50 w-[17.5rem] transform p-3 transition duration-300 ease-out lg:hidden',
          mobileOpen ? 'translate-x-0' : '-translate-x-full',
        )}
      >
        <div className="h-full overflow-hidden rounded-2xl border border-white/12 shadow-2xl">
          <Sidebar onNavigate={() => setMobileOpen(false)} />
        </div>
      </div>

      <div className="flex min-w-0 flex-col bg-transparent">
        <Topbar onMenuClick={() => setMobileOpen(true)} />
        <main className="animate-fade-in flex-1 bg-transparent px-4 py-5 sm:px-6 sm:py-6 lg:px-8 lg:py-7">
          <div className="content-stage rounded-2xl px-4 py-5 sm:px-6 sm:py-6 lg:px-7 lg:py-7">
            <Outlet key={outletKey} />
          </div>
        </main>
      </div>
    </div>
  )
}
