import { Menu, LogOut, MapPin } from 'lucide-react'
import { useAuth } from '@/auth/AuthContext'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Select } from '@/components/ui/Select'

export function Topbar({ onMenuClick }: { onMenuClick: () => void }) {
  const { user, tenant, portal, branches, branchId, isTenantWide, setBranchId, logout } =
    useAuth()

  const showBranchPicker = portal === 'admin' && branches.length > 0
  const title =
    portal === 'platform' ? 'Platform console' : (tenant?.name ?? 'Your gym')
  const subtitle =
    portal === 'platform'
      ? 'Super Admin'
      : isTenantWide
        ? 'Tenant-wide access'
        : 'Branch-scoped access'

  return (
    <header className="sticky top-0 z-20 bg-transparent px-3 pt-3 sm:px-4 lg:px-6">
      <div className="glass-panel flex min-h-14 flex-wrap items-center justify-between gap-3 rounded-2xl px-3 py-2.5 sm:px-4">
        <div className="flex min-w-0 items-center gap-3">
          <button
            type="button"
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/15 bg-white/10 text-ink transition hover:bg-white/15 lg:hidden"
            onClick={onMenuClick}
            aria-label="Open navigation"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="min-w-0">
            <p className="truncate font-display text-lg font-bold uppercase tracking-wide text-ink sm:text-xl">
              {title}
            </p>
            <p className="truncate text-xs text-muted">{subtitle}</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-end gap-2 sm:gap-3">
          {showBranchPicker ? (
            <div className="relative min-w-[10rem] sm:min-w-[12rem]">
              <MapPin className="pointer-events-none absolute top-1/2 left-3 h-3.5 w-3.5 -translate-y-1/2 text-muted" />
              <Select
                aria-label="Active branch"
                className="h-10 border-white/15 bg-white/10 pl-9 text-sm text-ink"
                value={branchId != null ? String(branchId) : ''}
                onChange={(e) => {
                  const value = e.target.value
                  setBranchId(value ? Number(value) : null)
                }}
              >
                {isTenantWide ? <option value="">All branches</option> : null}
                {branches.map((branch) => (
                  <option key={branch.id} value={branch.id} className="bg-ink-soft text-ink">
                    {branch.name}
                  </option>
                ))}
              </Select>
            </div>
          ) : null}

          <div className="hidden text-right md:block">
            <p className="text-sm font-semibold text-ink">{user?.name}</p>
            <p className="max-w-[12rem] truncate text-xs text-muted">{user?.email}</p>
          </div>
          {user?.roles?.[0]?.name ? (
            <Badge tone="accent" className="hidden sm:inline-flex">
              {user.roles[0].name}
            </Badge>
          ) : null}
          <Button variant="secondary" size="sm" onClick={() => void logout()}>
            <LogOut className="h-4 w-4" />
            <span className="hidden sm:inline">Sign out</span>
          </Button>
        </div>
      </div>
    </header>
  )
}
