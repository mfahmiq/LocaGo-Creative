import type { ReactNode } from 'react'
import { Dumbbell, ShieldCheck, Users } from 'lucide-react'
import { env } from '@/config/env'

export function AuthLayout({
  title,
  subtitle,
  children,
}: {
  title: string
  subtitle?: string
  children: ReactNode
}) {
  return (
    <div className="relative min-h-screen overflow-hidden bg-transparent text-ink">
      <div className="relative mx-auto grid min-h-screen max-w-6xl items-center gap-8 px-4 py-8 sm:px-6 lg:grid-cols-[1.15fr_0.85fr] lg:gap-12 lg:py-12">
        <div className="hidden animate-slide-in lg:block">
          <div className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/10 px-3 py-1.5 backdrop-blur-md">
            <span className="h-2 w-2 rounded-sm bg-accent" />
            <p className="font-display text-sm font-bold uppercase tracking-[0.18em] text-ink">
              {env.appName}
            </p>
          </div>
          <h1 className="mt-6 max-w-xl font-display text-5xl font-bold uppercase leading-[0.95] tracking-wide drop-shadow-[0_8px_24px_rgba(0,0,0,0.45)] xl:text-6xl">
            Train the business.
            <span className="block text-accent">Lead the floor.</span>
          </h1>
          <p className="mt-5 max-w-md text-base leading-relaxed text-muted">
            Members, classes, billing, and attendance in one console built for busy gym teams.
          </p>

          <ul className="mt-10 grid max-w-lg gap-3 sm:grid-cols-3">
            {[
              { icon: Users, label: 'Members' },
              { icon: Dumbbell, label: 'Training' },
              { icon: ShieldCheck, label: 'Secure ops' },
            ].map((item) => (
              <li
                key={item.label}
                className="flex items-center gap-2.5 rounded-xl border border-white/15 bg-white/10 px-3 py-3 backdrop-blur-md"
              >
                <item.icon className="h-4 w-4 text-accent" aria-hidden />
                <span className="text-sm font-medium text-ink/90">{item.label}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="glass-panel animate-fade-up rounded-2xl p-5 shadow-[0_24px_60px_-20px_rgba(0,0,0,0.55)] sm:p-8">
          <div className="mb-6 flex items-center gap-3 lg:hidden">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent font-display text-sm font-bold text-accent-ink">
              FG
            </div>
            <div>
              <p className="font-display text-lg font-bold uppercase tracking-wide text-ink">
                {env.appName}
              </p>
              <p className="text-xs text-muted">Gym operations console</p>
            </div>
          </div>

          <h2 className="font-display text-3xl font-bold uppercase tracking-wide text-ink">{title}</h2>
          {subtitle ? <p className="mt-2 text-sm leading-relaxed text-muted">{subtitle}</p> : null}
          <div className="mt-6">{children}</div>
        </div>
      </div>
    </div>
  )
}
