import { useEffect, useMemo, useState } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { ChevronDown } from 'lucide-react'
import {
  filterNavSections,
  flattenNavItems,
  isNavItemActive,
  navSections,
  platformNavSections,
  type NavSection,
} from '@/config/nav'
import { env } from '@/config/env'
import { cn } from '@/lib/cn'
import { useAuth } from '@/auth/AuthContext'

function sectionContainsPath(
  section: NavSection,
  pathname: string,
  allItems: ReturnType<typeof flattenNavItems>,
): boolean {
  return section.items.some((item) => isNavItemActive(item.to, pathname, allItems))
}

function activeSectionTitle(
  sections: NavSection[],
  pathname: string,
  allItems: ReturnType<typeof flattenNavItems>,
): string | null {
  const match = sections.find((section) => sectionContainsPath(section, pathname, allItems))
  return match?.title ?? sections[0]?.title ?? null
}

export function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const { portal, hasPermission } = useAuth()
  const location = useLocation()

  const sections = useMemo(() => {
    const source = portal === 'platform' ? platformNavSections : navSections
    return filterNavSections(source, hasPermission)
  }, [portal, hasPermission])

  const allNavItems = useMemo(() => flattenNavItems(sections), [sections])

  const routeSection = useMemo(
    () => activeSectionTitle(sections, location.pathname, allNavItems),
    [sections, location.pathname, allNavItems],
  )

  const [openTitle, setOpenTitle] = useState<string | null>(routeSection)

  useEffect(() => {
    setOpenTitle(routeSection)
  }, [routeSection])

  return (
    <aside className="relative flex h-full w-full flex-col overflow-hidden bg-ink-soft/88 text-ink backdrop-blur-xl">
      <div className="pointer-events-none absolute inset-0 gym-mesh opacity-35" />
      <div className="pointer-events-none absolute -right-10 top-24 h-40 w-40 rounded-full bg-accent/20 blur-3xl" />

      <div className="relative border-b border-white/10 px-5 py-5">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent font-display text-base font-bold text-accent-ink shadow-[0_8px_20px_-8px_rgba(198,255,26,0.75)]">
            FG
          </div>
          <div className="min-w-0">
            <p className="truncate font-display text-xl font-bold uppercase tracking-wide">
              {env.appName}
            </p>
            <p className="truncate text-xs text-muted">
              {portal === 'platform' ? 'Platform console' : 'Gym operations'}
            </p>
          </div>
        </div>
      </div>

      <nav className="relative flex-1 space-y-2 overflow-y-auto px-3 py-5">
        {sections.map((section) => {
          const isOpen = openTitle === section.title
          const isActiveSection = routeSection === section.title

          return (
            <div
              key={section.title}
              className={cn(
                'rounded-2xl transition',
                isActiveSection && isOpen ? 'bg-white/6' : 'bg-transparent',
              )}
            >
              <button
                type="button"
                aria-expanded={isOpen}
                onClick={() =>
                  setOpenTitle((current) => (current === section.title ? null : section.title))
                }
                className={cn(
                  'flex w-full items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-left transition',
                  isActiveSection
                    ? 'text-accent'
                    : 'text-muted/90 hover:bg-white/8 hover:text-ink',
                )}
              >
                <span className="font-display text-[11px] font-bold uppercase tracking-[0.16em]">
                  {section.title}
                </span>
                <ChevronDown
                  className={cn(
                    'h-4 w-4 shrink-0 transition-transform duration-200',
                    isOpen ? 'rotate-0' : '-rotate-90',
                  )}
                />
              </button>

              <div
                className={cn(
                  'grid transition-[grid-template-rows] duration-200 ease-out',
                  isOpen ? 'grid-rows-[1fr]' : 'grid-rows-[0fr]',
                )}
              >
                <div className="overflow-hidden">
                  <ul className="space-y-1 px-1 pb-2">
                    {section.items.map((item) => {
                      const Icon = item.icon
                      const active = isNavItemActive(item.to, location.pathname, allNavItems)
                      return (
                        <li key={item.to}>
                          <NavLink
                            to={item.to}
                            end
                            onClick={onNavigate}
                            className={() =>
                              cn(
                                'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition duration-200',
                                active
                                  ? 'bg-accent text-accent-ink shadow-[0_10px_24px_-12px_rgba(198,255,26,0.85)]'
                                  : 'text-ink/80 hover:bg-white/10 hover:text-ink',
                              )
                            }
                          >
                            <Icon className="h-4 w-4 shrink-0 opacity-90" />
                            <span className="flex-1">{item.label}</span>
                            {item.comingSoon ? (
                              <span
                                className={cn(
                                  'rounded-md px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide',
                                  active
                                    ? 'bg-black/15 text-accent-ink'
                                    : 'bg-white/10 text-muted',
                                )}
                              >
                                Soon
                              </span>
                            ) : null}
                          </NavLink>
                        </li>
                      )
                    })}
                  </ul>
                </div>
              </div>
            </div>
          )
        })}
      </nav>

      <div className="relative border-t border-white/10 px-5 py-4">
        <p className="text-[11px] font-medium uppercase tracking-[0.12em] text-muted/70">
          Menus follow your RBAC permissions
        </p>
      </div>
    </aside>
  )
}
