import type { ReactNode } from 'react'
import { createBrowserRouter, Navigate } from 'react-router-dom'
import { GuestOnly, RequireAuth } from '@/auth/RequireAuth'
import { RequirePermission } from '@/auth/RequirePermission'
import { AppLayout } from '@/layouts/AppLayout'
import { LoginPage } from '@/pages/auth/LoginPage'
import { DashboardPage } from '@/pages/DashboardPage'
import { RbacSettingsPage } from '@/pages/settings/RbacSettingsPage'
import { PlatformRbacSettingsPage } from '@/pages/settings/PlatformRbacSettingsPage'
import { ChangePasswordPage } from '@/pages/settings/ChangePasswordPage'
import { BranchesPage } from '@/pages/settings/BranchesPage'
import { GymSettingsPage } from '@/pages/settings/GymSettingsPage'
import { PlatformUsersPage } from '@/pages/settings/PlatformUsersPage'
import { PlatformAuditPage } from '@/pages/settings/PlatformAuditPage'
import { PlatformTenantsPage } from '@/pages/platform/PlatformTenantsPage'
import { PlatformPlansPage } from '@/pages/platform/PlatformPlansPage'
import { PlatformBillingPage } from '@/pages/platform/PlatformBillingPage'
import { PlatformReportsOverviewPage } from '@/pages/platform/reports/PlatformReportsOverviewPage'
import { PlatformReportsTenantsPage } from '@/pages/platform/reports/PlatformReportsTenantsPage'
import { PlatformReportsBillingPage } from '@/pages/platform/reports/PlatformReportsBillingPage'
import { PlatformReportsPlansPage } from '@/pages/platform/reports/PlatformReportsPlansPage'
import { PlatformReportsExportsPage } from '@/pages/platform/reports/PlatformReportsExportsPage'
import { MembersPage } from '@/pages/members/MembersPage'
import { LeadsPage } from '@/pages/leads/LeadsPage'
import { StaffPage } from '@/pages/staff/StaffPage'
import { MembershipPlansPage } from '@/pages/membership-plans/MembershipPlansPage'
import { MembershipsPage } from '@/pages/memberships/MembershipsPage'
import { AttendancePage } from '@/pages/attendance/AttendancePage'
import { ClassesPage } from '@/pages/classes/ClassesPage'
import { TrainingPage } from '@/pages/training/TrainingPage'
import { NutritionPage } from '@/pages/nutrition/NutritionPage'
import { EquipmentPage } from '@/pages/equipment/EquipmentPage'
import { BillingPage } from '@/pages/billing/BillingPage'
import { PosPage } from '@/pages/pos/PosPage'
import { InventoryPage } from '@/pages/inventory/InventoryPage'
import { ExpensesPage } from '@/pages/expenses/ExpensesPage'
import { MarketingPage } from '@/pages/marketing/MarketingPage'
import { NotificationsPage } from '@/pages/notifications/NotificationsPage'
import { SupportPage } from '@/pages/support/SupportPage'
import { ReportsOverviewPage } from '@/pages/reports/ReportsOverviewPage'
import { ReportDashboardPage } from '@/pages/reports/ReportDashboardPage'
import { ReportExportsPage } from '@/pages/reports/ReportExportsPage'
import { AuditPage } from '@/pages/audit/AuditPage'

function gate(
  element: ReactNode,
  opts: { permission?: string; anyOf?: string[] },
) {
  return (
    <RequirePermission permission={opts.permission} anyOf={opts.anyOf}>
      {element}
    </RequirePermission>
  )
}

export const router = createBrowserRouter([
  {
    element: <GuestOnly />,
    children: [
      {
        path: '/login',
        element: <LoginPage />,
      },
    ],
  },
  {
    element: <RequireAuth />,
    children: [
      {
        element: <AppLayout />,
        children: [
          { path: '/', element: <DashboardPage /> },

          {
            path: '/members',
            element: gate(<MembersPage />, { permission: 'members.view' }),
          },
          {
            path: '/leads',
            element: gate(<LeadsPage />, { permission: 'sales.leads.view' }),
          },
          {
            path: '/staff',
            element: gate(<StaffPage />, { permission: 'identity.staff.view' }),
          },
          {
            path: '/membership-plans',
            element: gate(<MembershipPlansPage />, { permission: 'memberships.plans.view' }),
          },
          {
            path: '/memberships',
            element: gate(<MembershipsPage />, { permission: 'memberships.instances.view' }),
          },
          {
            path: '/attendance',
            element: gate(<AttendancePage />, { permission: 'attendance.view' }),
          },
          {
            path: '/classes',
            element: gate(<ClassesPage />, { permission: 'classes.view' }),
          },
          {
            path: '/training',
            element: gate(<TrainingPage />, { permission: 'training.view' }),
          },
          {
            path: '/nutrition',
            element: gate(<NutritionPage />, { permission: 'nutrition.view' }),
          },
          {
            path: '/equipment',
            element: gate(<EquipmentPage />, {
              anyOf: ['equipment.view', 'facilities.tasks.view'],
            }),
          },
          {
            path: '/billing',
            element: gate(<BillingPage />, {
              anyOf: ['billing.invoices.view', 'billing.payments.view'],
            }),
          },
          {
            path: '/pos',
            element: gate(<PosPage />, { permission: 'pos.sales.view' }),
          },
          {
            path: '/inventory',
            element: gate(<InventoryPage />, { permission: 'pos.inventory.view' }),
          },
          {
            path: '/expenses',
            element: gate(<ExpensesPage />, { permission: 'expenses.view' }),
          },
          {
            path: '/marketing',
            element: gate(<MarketingPage />, {
              anyOf: [
                'marketing.offers.view',
                'marketing.coupons.view',
                'marketing.referrals.view',
              ],
            }),
          },
          {
            path: '/notifications',
            element: gate(<NotificationsPage />, {
              anyOf: [
                'notifications.view',
                'notifications.manage',
                'notifications.send',
              ],
            }),
          },
          {
            path: '/support',
            element: gate(<SupportPage />, { permission: 'support.tickets.view' }),
          },
          {
            path: '/reports',
            element: gate(<ReportsOverviewPage />, { permission: 'reports.view' }),
          },
          {
            path: '/reports/exports',
            element: gate(<ReportExportsPage />, { permission: 'reports.export' }),
          },
          {
            path: '/reports/:reportSlug',
            element: gate(<ReportDashboardPage />, { permission: 'reports.view' }),
          },
          {
            path: '/audit',
            element: gate(<AuditPage />, { permission: 'audit.view' }),
          },

          {
            path: '/settings/rbac',
            element: gate(<RbacSettingsPage />, { permission: 'identity.roles.view' }),
          },
          {
            path: '/settings/roles',
            element: <Navigate to="/settings/rbac" replace />,
          },
          {
            path: '/settings/permissions',
            element: <Navigate to="/settings/rbac" replace />,
          },
          {
            path: '/settings/password',
            element: <ChangePasswordPage />,
          },
          {
            path: '/settings/branches',
            element: gate(<BranchesPage />, { permission: 'organization.branches.view' }),
          },
          {
            path: '/settings/gym',
            element: gate(<GymSettingsPage />, { permission: 'organization.settings.view' }),
          },
          { path: '/settings', element: <Navigate to="/settings/rbac" replace /> },

          {
            path: '/platform/tenants',
            element: gate(<PlatformTenantsPage />, { permission: 'platform.tenants.view' }),
          },
          {
            path: '/platform/plans',
            element: gate(<PlatformPlansPage />, { permission: 'platform.plans.view' }),
          },
          {
            path: '/platform/billing',
            element: gate(<PlatformBillingPage />, { permission: 'platform.billing.view' }),
          },
          {
            path: '/platform/reports',
            element: gate(<PlatformReportsOverviewPage />, {
              permission: 'platform.reports.view',
            }),
          },
          {
            path: '/platform/reports/tenants',
            element: gate(<PlatformReportsTenantsPage />, {
              permission: 'platform.reports.view',
            }),
          },
          {
            path: '/platform/reports/billing',
            element: gate(<PlatformReportsBillingPage />, {
              permission: 'platform.reports.view',
            }),
          },
          {
            path: '/platform/reports/plans',
            element: gate(<PlatformReportsPlansPage />, {
              permission: 'platform.reports.view',
            }),
          },
          {
            path: '/platform/reports/exports',
            element: gate(<PlatformReportsExportsPage />, {
              anyOf: ['platform.reports.export', 'platform.reports.view'],
            }),
          },
          {
            path: '/platform/settings/rbac',
            element: gate(<PlatformRbacSettingsPage />, {
              anyOf: [
                'platform.users.manage',
                'platform.tenants.view',
                'platform.audit.view',
                'platform.reports.view',
              ],
            }),
          },
          {
            path: '/platform/settings/roles',
            element: <Navigate to="/platform/settings/rbac" replace />,
          },
          {
            path: '/platform/settings/permissions',
            element: <Navigate to="/platform/settings/rbac" replace />,
          },
          {
            path: '/platform/settings/password',
            element: <ChangePasswordPage />,
          },
          {
            path: '/platform/settings/users',
            element: gate(<PlatformUsersPage />, {
              permission: 'platform.users.manage',
            }),
          },
          {
            path: '/platform/settings/audit',
            element: gate(<PlatformAuditPage />, {
              permission: 'platform.audit.view',
            }),
          },
          {
            path: '/platform/settings',
            element: <Navigate to="/platform/settings/rbac" replace />,
          },
        ],
      },
    ],
  },
  { path: '*', element: <Navigate to="/" replace /> },
])
