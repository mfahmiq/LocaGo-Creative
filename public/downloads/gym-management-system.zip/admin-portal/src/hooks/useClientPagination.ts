import { useEffect, useMemo, useState } from 'react'
import { DEFAULT_PAGE_SIZE, paginateItems } from '@/lib/pagination'
import type { PaginationMeta } from '@/api/types'

/**
 * Client-side pagination for in-memory lists. Resets to page 1 when `resetKey` changes.
 */
export function useClientPagination<T>(
  items: T[],
  resetKey?: string | number | boolean,
  perPage: number = DEFAULT_PAGE_SIZE,
): {
  rows: T[]
  meta: PaginationMeta
  page: number
  setPage: (page: number) => void
} {
  const [page, setPage] = useState(1)

  useEffect(() => {
    setPage(1)
  }, [resetKey])

  return useMemo(() => {
    const result = paginateItems(items, page, perPage)
    return {
      rows: result.rows,
      meta: result.meta,
      page: result.meta.current_page,
      setPage,
    }
  }, [items, page, perPage])
}
