import { useEffect, useState, type Dispatch, type SetStateAction } from 'react'
import { useAuth } from '@/auth/AuthContext'

/**
 * Page-level branch filter that stays in sync with the topbar active branch.
 * When the topbar changes (including "All branches"), this value updates so
 * list queries and forms reflect the selected scope.
 */
export function useBranchFilter(): [number | '', Dispatch<SetStateAction<number | ''>>] {
  const { branchId } = useAuth()
  const [branchFilter, setBranchFilter] = useState<number | ''>(branchId ?? '')

  useEffect(() => {
    setBranchFilter(branchId ?? '')
  }, [branchId])

  return [branchFilter, setBranchFilter]
}
