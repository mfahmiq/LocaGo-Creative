import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react'
import { CheckCircle2, X } from 'lucide-react'
import { Button } from '@/components/ui/Button'

type ConfirmOptions = {
  title?: string
  message: string
  confirmLabel?: string
  cancelLabel?: string
  tone?: 'danger' | 'primary'
}

type FeedbackContextValue = {
  showSuccess: (message: string) => void
  confirm: (options: ConfirmOptions) => Promise<boolean>
}

const FeedbackContext = createContext<FeedbackContextValue | null>(null)

export function FeedbackProvider({ children }: { children: ReactNode }) {
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  const [confirmState, setConfirmState] = useState<(ConfirmOptions & { open: true }) | null>(null)
  const confirmResolver = useRef<((value: boolean) => void) | null>(null)

  const closeSuccess = useCallback(() => setSuccessMessage(null), [])

  const showSuccess = useCallback((message: string) => {
    setSuccessMessage(message)
  }, [])

  const resolveConfirm = useCallback((value: boolean) => {
    confirmResolver.current?.(value)
    confirmResolver.current = null
    setConfirmState(null)
  }, [])

  const confirm = useCallback((options: ConfirmOptions) => {
    return new Promise<boolean>((resolve) => {
      confirmResolver.current?.(false)
      confirmResolver.current = resolve
      setConfirmState({ ...options, open: true })
    })
  }, [])

  const value = useMemo(() => ({ showSuccess, confirm }), [showSuccess, confirm])

  return (
    <FeedbackContext.Provider value={value}>
      {children}

      {successMessage ? (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center bg-ink-soft/60 p-4 backdrop-blur-[2px]"
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="success-popup-title"
        >
          <div className="glass-panel relative w-full max-w-md rounded-2xl border border-white/15 p-6 shadow-2xl animate-fade-up">
            <button
              type="button"
              onClick={closeSuccess}
              className="absolute right-3 top-3 inline-flex h-8 w-8 items-center justify-center rounded-lg text-muted transition hover:bg-white/10 hover:text-ink"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-success/20 text-success">
                <CheckCircle2 className="h-7 w-7" />
              </div>
              <h2 id="success-popup-title" className="font-display text-2xl font-bold uppercase tracking-wide text-ink">
                Success
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-muted">{successMessage}</p>
              <Button type="button" className="mt-6 min-w-[8rem]" onClick={closeSuccess}>
                OK
              </Button>
            </div>
          </div>
        </div>
      ) : null}

      {confirmState ? (
        <div
          className="fixed inset-0 z-[80] flex items-center justify-center bg-ink-soft/60 p-4 backdrop-blur-[2px]"
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="confirm-popup-title"
        >
          <div className="glass-panel w-full max-w-md rounded-2xl border border-white/15 p-6 shadow-2xl animate-fade-up">
            <h2
              id="confirm-popup-title"
              className="font-display text-2xl font-bold uppercase tracking-wide text-ink"
            >
              {confirmState.title ?? 'Are you sure?'}
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-muted">{confirmState.message}</p>
            <div className="mt-6 flex flex-wrap justify-end gap-2">
              <Button type="button" variant="secondary" onClick={() => resolveConfirm(false)}>
                {confirmState.cancelLabel ?? 'Cancel'}
              </Button>
              <Button
                type="button"
                variant={confirmState.tone === 'primary' ? 'primary' : 'danger'}
                onClick={() => resolveConfirm(true)}
              >
                {confirmState.confirmLabel ?? 'Confirm'}
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </FeedbackContext.Provider>
  )
}

export function useFeedback() {
  const ctx = useContext(FeedbackContext)
  if (!ctx) {
    throw new Error('useFeedback must be used within FeedbackProvider')
  }
  return ctx
}
