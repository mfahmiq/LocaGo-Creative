import type { LucideIcon } from 'lucide-react'
import {
  Activity,
  BadgePercent,
  Boxes,
  Building2,
  ClipboardList,
  CreditCard,
  Dumbbell,
  FileBarChart2,
  KeyRound,
  LayoutDashboard,
  Megaphone,
  Receipt,
  RefreshCw,
  Salad,
  Settings2,
  Shield,
  ShoppingCart,
  Ticket,
  UserCog,
  Users,
  Wallet,
  Wrench,
} from 'lucide-react'

export type NavItem = {
  label: string
  to: string
  icon: LucideIcon
  /** Single permission required to show this item */
  permission?: string
  /** Show if user has any of these permissions */
  anyOf?: string[]
  comingSoon?: boolean
}

export type NavSection = {
  title: string
  items: NavItem[]
}

/**
 * Admin (tenant) sidebar — Main module → Sub modules.
 * Visibility is filtered by RBAC permissions in the Sidebar.
 */
export const navSections: NavSection[] = [
  {
    title: 'Overview',
    items: [{ label: 'Dashboard', to: '/', icon: LayoutDashboard }],
  },
  {
    title: 'People',
    items: [
      { label: 'Members', to: '/members', icon: Users, permission: 'members.view' },
      {
        label: 'Leads',
        to: '/leads',
        icon: ClipboardList,
        permission: 'sales.leads.view',
      },
      {
        label: 'Staff',
        to: '/staff',
        icon: UserCog,
        permission: 'identity.staff.view',
      },
    ],
  },
  {
    title: 'Memberships',
    items: [
      {
        label: 'Plans',
        to: '/membership-plans',
        icon: CreditCard,
        permission: 'memberships.plans.view',
      },
      {
        label: 'Memberships',
        to: '/memberships',
        icon: CreditCard,
        permission: 'memberships.instances.view',
      },
    ],
  },
  {
    title: 'Operations',
    items: [
      {
        label: 'Attendance',
        to: '/attendance',
        icon: Activity,
        permission: 'attendance.view',
      },
      {
        label: 'Classes',
        to: '/classes',
        icon: ClipboardList,
        permission: 'classes.view',
      },
      {
        label: 'Training',
        to: '/training',
        icon: Dumbbell,
        permission: 'training.view',
      },
      {
        label: 'Nutrition',
        to: '/nutrition',
        icon: Salad,
        permission: 'nutrition.view',
      },
      {
        label: 'Equipment',
        to: '/equipment',
        icon: Wrench,
        anyOf: ['equipment.view', 'facilities.tasks.view'],
      },
    ],
  },
  {
    title: 'Commerce',
    items: [
      {
        label: 'Billing',
        to: '/billing',
        icon: Receipt,
        anyOf: ['billing.invoices.view', 'billing.payments.view'],
      },
      {
        label: 'POS',
        to: '/pos',
        icon: ShoppingCart,
        permission: 'pos.sales.view',
      },
      {
        label: 'Inventory',
        to: '/inventory',
        icon: Boxes,
        permission: 'pos.inventory.view',
      },
      {
        label: 'Expenses',
        to: '/expenses',
        icon: Wallet,
        permission: 'expenses.view',
      },
      {
        label: 'Marketing',
        to: '/marketing',
        icon: Megaphone,
        anyOf: [
          'marketing.offers.view',
          'marketing.coupons.view',
          'marketing.referrals.view',
        ],
      },
    ],
  },
  {
    title: 'Engagement',
    items: [
      {
        label: 'Notifications',
        to: '/notifications',
        icon: BadgePercent,
        anyOf: [
          'notifications.view',
          'notifications.manage',
          'notifications.send',
        ],
      },
      {
        label: 'Support',
        to: '/support',
        icon: Ticket,
        permission: 'support.tickets.view',
      },
      {
        label: 'Audit',
        to: '/audit',
        icon: Shield,
        permission: 'audit.view',
      },
    ],
  },
  {
    title: 'Reports',
    items: [
      {
        label: 'Overview',
        to: '/reports',
        icon: FileBarChart2,
        permission: 'reports.view',
      },
      {
        label: 'Membership',
        to: '/reports/membership',
        icon: CreditCard,
        permission: 'reports.view',
      },
      {
        label: 'Revenue',
        to: '/reports/revenue',
        icon: Wallet,
        permission: 'reports.view',
      },
      {
        label: 'Attendance',
        to: '/reports/attendance',
        icon: Activity,
        permission: 'reports.view',
      },
      {
        label: 'Trainer performance',
        to: '/reports/trainer-performance',
        icon: Dumbbell,
        permission: 'reports.view',
      },
      {
        label: 'Branch performance',
        to: '/reports/branch-performance',
        icon: Building2,
        permission: 'reports.view',
      },
      {
        label: 'Equipment',
        to: '/reports/equipment',
        icon: Wrench,
        permission: 'reports.view',
      },
      {
        label: 'Inventory',
        to: '/reports/inventory',
        icon: Boxes,
        permission: 'reports.view',
      },
      {
        label: 'Renewals',
        to: '/reports/renewals',
        icon: RefreshCw,
        permission: 'reports.view',
      },
      {
        label: 'Sales',
        to: '/reports/sales',
        icon: ShoppingCart,
        permission: 'reports.view',
      },
      {
        label: 'Customer analytics',
        to: '/reports/customer-analytics',
        icon: Users,
        permission: 'reports.view',
      },
      {
        label: 'Export center',
        to: '/reports/exports',
        icon: FileBarChart2,
        permission: 'reports.export',
      },
    ],
  },
  {
    title: 'Settings',
    items: [
      {
        label: 'Roles & permissions',
        to: '/settings/rbac',
        icon: Shield,
        permission: 'identity.roles.view',
      },
      {
        label: 'Change password',
        to: '/settings/password',
        icon: KeyRound,
      },
      {
        label: 'Branches',
        to: '/settings/branches',
        icon: Building2,
        permission: 'organization.branches.view',
      },
      {
        label: 'Gym settings',
        to: '/settings/gym',
        icon: Settings2,
        permission: 'organization.settings.view',
      },
    ],
  },
]

/**
 * Super Admin / Platform Support sidebar.
 */
export const platformNavSections: NavSection[] = [
  {
    title: 'Platform',
    items: [
      { label: 'Dashboard', to: '/', icon: LayoutDashboard },
      {
        label: 'Tenants',
        to: '/platform/tenants',
        icon: Building2,
        permission: 'platform.tenants.view',
      },
      {
        label: 'SaaS plans',
        to: '/platform/plans',
        icon: CreditCard,
        permission: 'platform.plans.view',
      },
      {
        label: 'Billing',
        to: '/platform/billing',
        icon: Receipt,
        permission: 'platform.billing.view',
      },
    ],
  },
  {
    title: 'Reports',
    items: [
      {
        label: 'Overview',
        to: '/platform/reports',
        icon: FileBarChart2,
        permission: 'platform.reports.view',
      },
      {
        label: 'Tenants',
        to: '/platform/reports/tenants',
        icon: Building2,
        permission: 'platform.reports.view',
      },
      {
        label: 'Billing',
        to: '/platform/reports/billing',
        icon: Receipt,
        permission: 'platform.reports.view',
      },
      {
        label: 'Plan adoption',
        to: '/platform/reports/plans',
        icon: CreditCard,
        permission: 'platform.reports.view',
      },
      {
        label: 'Exports',
        to: '/platform/reports/exports',
        icon: FileBarChart2,
        anyOf: ['platform.reports.export', 'platform.reports.view'],
      },
    ],
  },
  {
    title: 'Settings',
    items: [
      {
        label: 'Roles & permissions',
        to: '/platform/settings/rbac',
        icon: Shield,
        anyOf: [
          'platform.users.manage',
          'platform.tenants.view',
          'platform.audit.view',
          'platform.reports.view',
        ],
      },
      {
        label: 'Change password',
        to: '/platform/settings/password',
        icon: KeyRound,
      },
      {
        label: 'Platform users',
        to: '/platform/settings/users',
        icon: UserCog,
        permission: 'platform.users.manage',
      },
      {
        label: 'Audit logs',
        to: '/platform/settings/audit',
        icon: FileBarChart2,
        permission: 'platform.audit.view',
      },
    ],
  },
]

export function canSeeNavItem(
  item: NavItem,
  hasPermission: (code: string) => boolean,
): boolean {
  if (item.anyOf?.length) {
    return item.anyOf.some((code) => hasPermission(code))
  }
  if (item.permission) {
    return hasPermission(item.permission)
  }
  return true
}

export function filterNavSections(
  sections: NavSection[],
  hasPermission: (code: string) => boolean,
): NavSection[] {
  return sections
    .map((section) => ({
      ...section,
      items: section.items.filter((item) => canSeeNavItem(item, hasPermission)),
    }))
    .filter((section) => section.items.length > 0)
}

/** Flattened nav destinations used for longest-prefix active matching. */
export function flattenNavItems(sections: NavSection[]): NavItem[] {
  return sections.flatMap((section) => section.items)
}

/**
 * Active when path matches exactly, or is a nested path of this item,
 * unless a more specific sibling/nav item also matches (fixes /reports vs /reports/tenants).
 */
export function isNavItemActive(
  itemTo: string,
  pathname: string,
  allItems: NavItem[],
): boolean {
  if (itemTo === '/') {
    return pathname === '/'
  }

  const matches = pathname === itemTo || pathname.startsWith(`${itemTo}/`)
  if (!matches) {
    return false
  }

  const hasMoreSpecificMatch = allItems.some((other) => {
    if (other.to === itemTo || other.to === '/') return false
    if (!other.to.startsWith(`${itemTo}/`)) return false
    return pathname === other.to || pathname.startsWith(`${other.to}/`)
  })

  return !hasMoreSpecificMatch
}
