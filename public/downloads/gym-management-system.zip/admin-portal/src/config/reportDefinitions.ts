import type { LucideIcon } from 'lucide-react'
import {
  Activity,
  Boxes,
  Building2,
  CreditCard,
  Dumbbell,
  FileBarChart2,
  RefreshCw,
  ShoppingCart,
  Users,
  Wallet,
  Wrench,
} from 'lucide-react'

export type TenantReportDefinition = {
  key: string
  slug: string
  name: string
  description: string
  category: string
  icon: LucideIcon
  path: string
}

export const TENANT_REPORTS: TenantReportDefinition[] = [
  {
    key: 'membership_report',
    slug: 'membership',
    name: 'Membership Reports',
    description: 'Active, expired, and plan distribution for memberships.',
    category: 'Membership',
    icon: CreditCard,
    path: '/reports/membership',
  },
  {
    key: 'revenue_report',
    slug: 'revenue',
    name: 'Revenue Reports',
    description: 'Collections, outstanding balances, and net position.',
    category: 'Finance',
    icon: Wallet,
    path: '/reports/revenue',
  },
  {
    key: 'attendance_report',
    slug: 'attendance',
    name: 'Attendance Reports',
    description: 'Check-in volume by day, status, and branch.',
    category: 'Operations',
    icon: Activity,
    path: '/reports/attendance',
  },
  {
    key: 'trainer_performance',
    slug: 'trainer-performance',
    name: 'Trainer Performance',
    description: 'Assigned members, completed sessions, and no-show rates.',
    category: 'Performance',
    icon: Dumbbell,
    path: '/reports/trainer-performance',
  },
  {
    key: 'branch_performance',
    slug: 'branch-performance',
    name: 'Branch Performance',
    description: 'Compare members, attendance, sales, and revenue by branch.',
    category: 'Performance',
    icon: Building2,
    path: '/reports/branch-performance',
  },
  {
    key: 'equipment_report',
    slug: 'equipment',
    name: 'Equipment Reports',
    description: 'Assets by status, category, and warranty risk.',
    category: 'Assets',
    icon: Wrench,
    path: '/reports/equipment',
  },
  {
    key: 'inventory_report',
    slug: 'inventory',
    name: 'Inventory Reports',
    description: 'Stock levels, low-stock alerts, and inventory value.',
    category: 'Assets',
    icon: Boxes,
    path: '/reports/inventory',
  },
  {
    key: 'renewal_report',
    slug: 'renewals',
    name: 'Renewal Reports',
    description: 'Renewals, upgrades, and upcoming expirations.',
    category: 'Membership',
    icon: RefreshCw,
    path: '/reports/renewals',
  },
  {
    key: 'sales_report',
    slug: 'sales',
    name: 'Sales Reports',
    description: 'POS sales totals, tickets, and daily trends.',
    category: 'Finance',
    icon: ShoppingCart,
    path: '/reports/sales',
  },
  {
    key: 'customer_analytics',
    slug: 'customer-analytics',
    name: 'Customer Analytics',
    description: 'Acquisition, status mix, leads, and engagement.',
    category: 'Analytics',
    icon: Users,
    path: '/reports/customer-analytics',
  },
]

export function findReportBySlug(slug: string | undefined): TenantReportDefinition | undefined {
  if (!slug) return undefined
  return TENANT_REPORTS.find((r) => r.slug === slug)
}

export function findReportByKey(key: string | undefined): TenantReportDefinition | undefined {
  if (!key) return undefined
  return TENANT_REPORTS.find((r) => r.key === key)
}

export const REPORTS_HUB_ICON = FileBarChart2
