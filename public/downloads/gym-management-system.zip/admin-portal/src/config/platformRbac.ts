/** Platform menu ↔ permission mapping for the RBAC settings UI. */
export type PlatformMenuPermission = {
  code: string
  label: string
}

export type PlatformMenuGroup = {
  section: string
  menus: Array<{
    label: string
    description: string
    permissions: PlatformMenuPermission[]
  }>
}

export const platformMenuGroups: PlatformMenuGroup[] = [
  {
    section: 'Platform',
    menus: [
      {
        label: 'Tenants',
        description: 'Sidebar → Platform → Tenants',
        permissions: [
          { code: 'platform.tenants.view', label: 'Show menu & view tenants' },
          { code: 'platform.tenants.manage', label: 'Create, suspend & manage' },
        ],
      },
      {
        label: 'SaaS plans',
        description: 'Sidebar → Platform → SaaS plans',
        permissions: [
          { code: 'platform.plans.view', label: 'Show menu & view plans' },
          { code: 'platform.plans.manage', label: 'Create & edit plans' },
        ],
      },
      {
        label: 'Billing',
        description: 'Sidebar → Platform → Billing',
        permissions: [
          { code: 'platform.billing.view', label: 'Show menu & view billing' },
          { code: 'platform.billing.manage', label: 'Issue invoices & record payments' },
        ],
      },
    ],
  },
  {
    section: 'Reports',
    menus: [
      {
        label: 'Reports',
        description: 'Sidebar → Reports (Overview, Tenants, Billing, Plan adoption, Exports)',
        permissions: [
          { code: 'platform.reports.view', label: 'Show Reports menus' },
          { code: 'platform.reports.export', label: 'Allow exports & downloads' },
        ],
      },
    ],
  },
  {
    section: 'Settings',
    menus: [
      {
        label: 'Platform users & RBAC edits',
        description: 'Sidebar → Settings → Platform users; also required to edit role menus',
        permissions: [
          { code: 'platform.users.manage', label: 'Manage platform users & edit RBAC' },
        ],
      },
      {
        label: 'Audit logs',
        description: 'Sidebar → Settings → Audit logs',
        permissions: [
          { code: 'platform.audit.view', label: 'Show Audit logs menu' },
        ],
      },
    ],
  },
]

/** @deprecated Prefer platformMenuGroups for the live editor */
export const platformRbacCatalog = [
  {
    code: 'super_admin',
    name: 'Super Admin / Platform Owner',
    modules: [
      {
        main: 'Platform',
        subs: [
          'Tenants — view & manage',
          'SaaS plans — view & manage',
          'Users — manage platform operators',
          'Audit — view platform audit logs',
          'Billing — view & manage platform billing',
        ],
      },
      {
        main: 'Reports',
        subs: [
          'Overview — platform KPIs',
          'Tenants — growth & status',
          'Billing — subscription revenue',
          'Plan adoption — SaaS plan mix',
          'Exports — download report files',
        ],
      },
    ],
    permissions: [
      'platform.tenants.view',
      'platform.tenants.manage',
      'platform.plans.view',
      'platform.plans.manage',
      'platform.users.manage',
      'platform.audit.view',
      'platform.billing.view',
      'platform.billing.manage',
      'platform.reports.view',
      'platform.reports.export',
    ],
  },
  {
    code: 'platform_support',
    name: 'Platform Support',
    modules: [
      {
        main: 'Platform',
        subs: [
          'Tenants — view',
          'SaaS plans — view',
          'Audit — view',
          'Billing — view',
        ],
      },
      {
        main: 'Reports',
        subs: [
          'Overview — view',
          'Tenants — view',
          'Billing — view',
          'Plan adoption — view',
        ],
      },
    ],
    permissions: [
      'platform.tenants.view',
      'platform.plans.view',
      'platform.audit.view',
      'platform.billing.view',
      'platform.reports.view',
    ],
  },
] as const
