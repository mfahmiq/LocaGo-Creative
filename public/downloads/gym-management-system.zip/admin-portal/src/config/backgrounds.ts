/**
 * Gym background images served from `/images` (admin-portal/public/images).
 * Drop additional .jpg/.jpeg/.png/.webp files here and add them to this list.
 */
export const BACKGROUND_ROTATE_MS = 5 * 60 * 1000

export const gymBackgroundImages = [
  '/images/gym-1.jpg',
  '/images/gym-2.jpg',
  '/images/gym-3.jpg',
  '/images/gym-4.jpg',
] as const
