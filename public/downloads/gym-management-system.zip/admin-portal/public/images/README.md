# Gym background images

Place background photos in this folder. They are served at `/images/...`.

Current rotation set (see `src/config/backgrounds.ts`):

- `gym-1.jpg`
- `gym-2.jpg`
- `gym-3.jpg`
- `gym-4.jpg`

The Admin Portal fades to the next image every **10 seconds**.
