# Forge Admin Portal

React admin console for the Gym Management System.

## Stack

- React + Vite + TypeScript
- Tailwind CSS v4
- React Router
- TanStack Query
- Axios
- React Hook Form + Zod
- Recharts

## Run

1. Start Laravel API (default `http://127.0.0.1:8000`)
2. From this folder:

```bash
npm install
npm run dev
```

Vite proxies `/api` → `http://127.0.0.1:8000`.

Demo login:

- Tenant: `demo-gym`
- Email: `admin@demo-gym.test`
- Password: `Password1!`

## This release (foundation)

- Authentication (login, session restore, logout, route guards)
- App shell (sidebar, topbar, responsive layout)
- Reusable UI (forms, tables, charts, cards, alerts)
- Dashboard wired to `/admin/reports`

Domain modules are stubbed in the sidebar and will be built one at a time.
