# Gym Management System (GMS)

Multi-tenant gym management platform: **Laravel REST API**, **Admin Portal**, and **Member Portal**. Designed so future Android/iOS apps reuse the same `/api/v1` API.

---

## Documentation

**Start here → [docs/README.md](docs/README.md)**

| Guide | Description |
| --- | --- |
| [Installation Guide](docs/INSTALLATION.md) | Local XAMPP setup, schema, seed, first login |
| [Developer Guide](docs/DEVELOPER_GUIDE.md) | Stack, conventions, testing, extending |
| [Admin Guide](docs/ADMIN_GUIDE.md) | Staff / owner portal usage |
| [Member Guide](docs/MEMBER_GUIDE.md) | Member portal usage |
| [Deployment Guide](docs/DEPLOYMENT.md) | Production build, queues, scheduler |
| [API Documentation](docs/API.md) | REST contract, auth, endpoints |
| [Architecture Guide](docs/ARCHITECTURE_GUIDE.md) | System design overview |
| [Troubleshooting Guide](docs/TROUBLESHOOTING.md) | Common issues and fixes |
| [Mobile API](docs/MOBILE_API.md) | Offline sync, push, uploads for native apps |

Also available: [SRS](docs/SRS.md), [MODULES](docs/MODULES.md), [DATABASE](docs/DATABASE.md), [Enterprise Architecture](docs/ARCHITECTURE.md), [RBAC](backend/docs/RBAC.md).

---

## Quick start (local)

```bash
# 1) Database
mysql -u root -e "CREATE DATABASE IF NOT EXISTS gym CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -u root gym < database/schema.sql

# 2) API
cd backend
composer install
copy .env.example .env
php artisan key:generate
php artisan migrate
php artisan db:seed
php artisan serve

# 3) Admin Portal (new terminal)
cd admin-portal
npm install
npm run dev

# 4) Member Portal (new terminal)
cd member-portal
npm install
npm run dev
```

| Service | URL |
| --- | --- |
| API | http://127.0.0.1:8000/api/v1/health |
| Admin | http://localhost:5173 |
| Member | http://localhost:5174/demo-gym |

### Demo credentials

| Role | Email | Password |
| --- | --- | --- |
| Gym Owner | `admin@demo-gym.test` | `Password1!` |
| Platform Super Admin | `superadmin@gms.test` | `Password1!` |

Tenant slug: **`demo-gym`**

---

## Project structure

```text
backend/         Laravel 12 API (/api/v1)
admin-portal/    React admin SPA (Vite :5173)
member-portal/   React member SPA (Vite :5174)
database/        schema.sql + patches
docs/            Complete documentation set
```

---

## License / notes

Internal product documentation for GMS. Do not commit real production secrets to `.env` files in source control.
