<?php
include('includes/session.inc');
include('includes/CurrenciesArray.php'); // To get the currency name from the currency code.
include('includes/CountriesArray.php');

$Title = _('Customer Maintenance');
include('includes/header.inc');
include('includes/SQL_CommonFunctions.inc');

echo '<p class="page_title_text"><img src="css/'.$Theme.'/images/customer.png" title="' . _('Customer') .'" alt="" />' . ' ' . _('Customer Maintenance') . '</p>';


$i=0;
if(isset($_POST['submit'])){
    if(!isset($_POST['customerposting'])){
       prnMsg('You have to select a customer posting group','error');
       $i++;
    }
    
    if(!isset($_POST['curr_cod'])){
       prnMsg('You have to select a customer currency','error');
       $i++;
    }
    
    if($i==0){
        if($_POST['submit']=='Add New Customer'){
                       
            $result = DB_query("Select customer from debtors where customer like '".$_POST['customer']."'", $db);
            if(DB_num_rows($result)>0){
                prnMsg('The customer name '.$_POST['customer'].' already exists','warn');
            } else {
                  $ID = Triger_debtors($_POST['customer']);
                         
            $sql=sprintf("INSERT INTO [debtors]
           (itemcode,[contact] ,[creditlimit] ,[customer]  ,[middlen]
           ,[phone] ,[fax] ,[company],[altcontact],[email] ,[city] ,[country] 
           ,[inactive] ,[postcode] ,[curr_cod],[customerposting],[salesman]) 
           values ('%s' ,'%s' ,'%s' ,'%s' ,'%s' ,'%s' ,'%s','%s'  ,'%s'
           ,'%s' ,'%s' ,'%s' ,'%s' ,'%s' ,'%s' ,'%s' ,'%s' )",
           $ID, $_POST['contact'] ,$_POST['creditlimit'] ,
            $_POST['customer']  ,$_POST['middlen'],
            $_POST['phone'] ,$_POST['fax'] ,$_POST['company'],
            $_POST['altcontact'],$_POST['email'] ,
            $_POST['city'] ,$_POST['country'], 
            $_POST['inactive'] ,$_POST['postcode'] ,$_POST['curr_cod'],
            $_POST['customerposting'],$_POST['salesman']);
           DB_query($sql, $db);
            }
       }
     // end of create new
       
        if($_POST['submit']=='Update Customer'){
            
          $SQL="UPDATE [debtors]
          SET [contact] = '". $_POST['contact']."'
             ,[creditlimit] = '". $_POST['creditlimit']."'
             ,[customer] = '".$_POST['customer']."'
             ,[middlen] = '".$_POST['middlen']."'
             ,[phone] = '".$_POST['phone']."'
             ,[fax] = '".$_POST['fax']."'
             ,[company] = '".$_POST['company']."'
             ,[altcontact] = '".$_POST['altcontact']."'
             ,[email] = '".$_POST['email']."'
             ,[city] = '".$_POST['city']."'
             ,[country] = '".$_POST['country']."'
             ,[inactive] = '".$_POST['inactive']."'
             ,[postcode] = '".$_POST['postcode']."'
             ,[curr_cod] = '".$_POST['curr_cod']."'
             ,[username] = '".$_POST['username']."'
             ,[customerposting] = '".$_POST['customerposting']."'
             ,[salesman] = '".$_POST['salesman']."'
             WHERE [itemcode] ='".$_POST['editcode']."'";
                    DB_query($SQL,$db);
    }
 }
 // end of validation
}

if($_POST['delete']=='Delete Customer'){
    $result = DB_query("Select * from debtorsledger where acctfolio='".$_POST['editcode']."'", $db);
     if(DB_num_rows($result)>0){
         prnMsg('This account has transactions and cannot be deleted','error');
     }else{
         $result = DB_query("delete from debtors where itemcode='".$_POST['editcode']."'", $db);
         if(DB_num_rows($result)>0){
              prnMsg('This customer has been deleted','info');
         }
     }
}

if(isset($_GET['Modify']) ){
    
    $result = DB_query("Select * from debtors where itemcode='".$_GET['Modify']."'", $db);
    if(DB_num_rows($result)==0){
        Die('This code is not correct');
       }else{
        $myrows= DB_fetch_array($result);
        $_POST['customer']=trim($myrows['customer']);
        $_POST['company']=trim($myrows['company']);
        $_POST['postcode']=trim($myrows['postcode']);
        $_POST['city']=trim($myrows['city']);
        $_POST['country']=trim($myrows['country']);
        $_POST['phone']=trim($myrows['phone']);
        $_POST['fax']=trim($myrows['fax']);
        $_POST['altcontact']=trim($myrows['altcontact']);
        $_POST['email']=trim($myrows['email']);
        $_POST['creditlimit']=trim($myrows['creditlimit']);
        $_POST['curr_cod']=trim($myrows['curr_cod']);
        $_POST['inactive']=$myrows['inactive'];
        $_POST['customerposting']=trim($myrows['customerposting']);
        $_POST['salesman']=trim($myrows['salesman']);
        $_POST['middlen']=trim($myrows['middlen']);
    }
    
    
echo '<form action="' . htmlspecialchars($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8') . '" method="post">';
echo '<div class="card">';
echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
echo '<input type="hidden" name="editcode" value="' . $_GET['Modify'] . '" />';
echo '<div class="row g-3 customer-maintenance-layout"><div class="col-lg-6">'
. '<table class="table table-bordered customer-details-table"><caption>Corporate Details</caption>';

echo '<tr><td>' . _('Name').'</td><td><input type="text" class="form-control" name="customer" maxlength="50" required="required" value="'.$_POST['customer'].'"/></td></tr>';
echo '<tr><td>' . _('Address').'</td><td><input type="text" class="form-control" name="company" maxlength="50"  value="'.$_POST['company'].'"/></td></tr>';
echo '<tr><td>' . _('Address 2').'</td><td><input type="text" class="form-control" name="postcode" maxlength="100"  value="'.$_POST['postcode'].'"/></td></tr>';
echo '<tr><td>' . _('city').'</td><td><input type="text" class="form-control" name="city" maxlength="50" value="'.$_POST['city'].'"  /></td></tr>';
echo '<tr><td>' . _('Country').'</td><td><select class="form-select" name="country">';
foreach ($CountriesArray as $CountryEntry => $CountryName){
        if (isset($_POST['country']) AND (strtoupper($_POST['country']) == strtoupper($CountryName))){
                echo '<option selected="selected" value="' . $CountryName . '">' . $CountryName  . '</option>';
        }elseif (!isset($_POST['country']) AND $CountryName == "") {
                echo '<option selected="selected" value="' . $CountryName . '">' . $CountryName  . '</option>';
        } else {
                echo '<option value="' . $CountryName . '">' . $CountryName  . '</option>';
        }
}
echo '</select></td></tr>';
echo '<tr><td>' . _('Telephone No').'</td><td><input type="text" class="form-control" name="phone" maxlength="15"  value="'.$_POST['phone'].'"/></td></tr>';
echo '<tr><td>' . _('Fax No').'</td><td><input type="text" class="form-control" name="fax" maxlength="50"  value="'.$_POST['fax'].'"/></td></tr>';
echo '<tr><td>' . _('Alt Contact').'</td><td><input type="text" class="form-control" name="altcontact" maxlength="100"  value="'.$_POST['altcontact'].'"/></td></tr>';
echo '<tr><td>' . _('email').'</td><td><input type="text" class="form-control" name="email" maxlength="100"  value="'.$_POST['email'].'"' ;
        ?> pattern="[a-z0-9!#$%&'*+/=?^_{|}~.-]+@[a-z0-9-]+(\.[a-z0-9-]+)*"  <?php echo '/></td></tr>';
echo '</table></div><div class="col-lg-6"><table class="table table-bordered customer-details-table">';
echo '<tr><td>' . _('Discount Rate').'</td><td><input type="text" class="form-control integer" name="creditlimit" maxlength="2" required="required"  value="'.$_POST['creditlimit'].'"/></td></tr>';

        $result=DB_query("SELECT currency, currabrev FROM currencies",$db);
	if (DB_num_rows($result)==0){
		$DataError =1;
		echo '<tr><td colspan="2"><p>'._('There are no currencies currently defined - go to the setup tab of the main menu and set at least one up first').'</p></td></tr>';
	} else {
		if (!isset($_POST['curr_cod'])){
			$CurrResult = DB_query("SELECT currencydefault FROM companies WHERE coycode=1",$db);
			$myrow = DB_fetch_row($CurrResult);
			$_POST['curr_cod'] = $myrow[0];
		}
		echo '<tr><td>' . _('Customer Currency') . ':</td>
	<td><select class="form-select" name="curr_cod" required="required">';
		while ($myrow = DB_fetch_array($result)) {
                    if(isset($_POST['curr_cod'])){
                        
                        if ($_POST['curr_cod']==$myrow['currabrev']){
			    echo '<option selected="selected" value="'. $myrow['currabrev'] . '">' . $myrow['currency'] . '</option>';
			}else{
                           echo '<option value="'. $myrow['currabrev'] . '">' . $myrow['currency'] . '</option>';
                        }
                        
                    } elseif($myrow['currabrev']=='KES') {
                     
                       echo '<option  selected="selected" value="'. $myrow['currabrev'] . '">' . $myrow['currency'] . '</option>';
                    }else{
                      echo '<option value="'. $myrow['currabrev'] . '">' . $myrow['currency'] . '</option>';
                    }
                    
		} //end while loop
		DB_data_seek($result,0);

		echo '</select></td></tr>';
	}
        
        echo '<tr><td>' . _('Block Account').'</td><td>';
        echo '<select class="form-select" name="inactive">'
                . '<option  '.($_POST['inactive']==0?'selected="selected"':'').' value="0">No</option>'
                . '<option  '.($_POST['inactive']==1?'selected="selected"':'').' value="1">Yes</option>'
                . '</select>';
        echo  '</td></tr>';
       
        
        $result=DB_query("SELECT code FROM postinggroups",$db);
  	if (DB_num_rows($result)==0){
		echo '<tr><td colspan="2">' .
                        '<p>'. _('There are no posting currently defined - go to the setup tab of the main menu and set at least one up first').'</p></td>
			</tr>';
	} else {
        echo '<tr><td>'._('Customer Posting Group').'</td><td>';
        echo '<select class="form-select" name="customerposting">';
        while ($myrow = DB_fetch_array($result)) {
		echo '<option '. ($myrow['code']==$_POST['customerposting']?'selected="selected"':''). '>' . $myrow['code'] . '</option>';
		} //end while loop
        echo '</select>' ;
        }      
     echo  '</td></tr>';
     
        echo '<tr><td>'._('Sales Person').'</td><td>';
        $result=DB_query("select code,salesman from salesrepsinfo",$db);    
        echo '<select class="form-select" name="salesman"><option value="">not selected</option>';
        while ($myrow = DB_fetch_array($result)) {
		echo '<option  value="'.$myrow['code'].'"'. ($myrow['code']==$_POST['salesman']?' selected="selected"':''). '>' . $myrow['salesman'] . '</option>';
		} //end while loop
        echo '</select>' ;
         echo  '</td></tr>';
          echo '<tr><td>' . _('PIN').'</td><td><input type="text" class="form-control" name="middlen" maxlength="15" value="'.$_POST['middlen'].'"/>' ;
        
         
echo '</table></div></div>';
    
} else {

echo '<form action="' . htmlspecialchars($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8') . '" method="post">';
echo '<div class="card">';
echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';
echo '<div class="row g-3 customer-maintenance-layout"><div class="col-lg-6">'
. '<table class="table table-bordered customer-details-table"><caption>Corporate Details</caption>';

echo '<tr><td>' . _('Name').'</td><td><input type="text" class="form-control" name="customer" maxlength="50" required="required" /></td></tr>';
echo '<tr><td>' . _('Address').'</td><td><input type="text" class="form-control" name="company" maxlength="50"  /></td></tr>';
echo '<tr><td>' . _('Address 2').'</td><td><input type="text" class="form-control" name="postcode" maxlength="100"  /></td></tr>';
echo '<tr><td>' . _('city').'</td><td><input type="text" class="form-control" name="city" maxlength="50" /></td></tr>';
echo '<tr><td>' . _('Country').'</td><td><select class="form-select" name="country">';
        
foreach ($CountriesArray as $CountryEntry => $CountryName){
    echo '<option value="' . $CountryName . '">' . $CountryName  . '</option>';
}

echo '</select></td></tr>';
echo '<tr><td>' . _('Telephone No').'</td><td><input type="text" class="form-control" name="phone" maxlength="15"  /></td></tr>';
echo '<tr><td>' . _('Fax No').'</td><td><input type="text" class="form-control" name="fax" maxlength="50"  /></td></tr>';
echo '<tr><td>' . _('Alt Contact').'</td><td><input type="text" class="form-control" name="altcontact" maxlength="100"  /></td></tr>';
echo '<tr><td>' . _('email').'</td><td><input type="text" class="form-control" name="email" maxlength="100" ' ;
        ?>   pattern="[a-z0-9!#$%&'*+/=?^_{|}~.-]+@[a-z0-9-]+(\.[a-z0-9-]+)*"   <?php echo '/></td></tr>';

echo '</table></td><td  valign="top"><table class="table table-bordered">';
echo '<tr><td>' . _('Discount Rate').'</td><td><input type="text" class="integer" name="creditlimit" maxlength="2" required="required"  /></td></tr>';


$result=DB_query("SELECT currency, currabrev FROM currencies",$db);
	if (DB_num_rows($result)==0){
		$DataError =1;
		echo '<tr><td colspan="2">'
                . '<p>' . _('There are no currencies currently defined ').
                 '<br />'. _(' go to the setup tab of the main menu and set at least one up first') . '</p></td>
                </tr>';
	} else {
            
		echo '<tr><td>' . _('Customer Currency') . ':</td><td><select class="form-select" name="curr_cod" required="required">';
		while ($myrow = DB_fetch_array($result)) {
                    if(isset($_POST['curr_cod'])){
                        
                        if ($_POST['curr_cod']==$myrow['currabrev']){
			    echo '<option selected="selected" value="'. $myrow['currabrev'] . '">' . $myrow['currency'] . '</option>';
			}else{
                           echo '<option value="'. $myrow['currabrev'] . '">' . $myrow['currency'] . '</option>';
                        }
                        
                    } elseif($myrow['currabrev']==$_SESSION['CompanyRecord']['currencydefault']) {
                     
                       echo '<option  selected="selected" value="'. $myrow['currabrev'] . '">' . $myrow['currency'] . '</option>';
                    }else{
                      echo '<option value="'. $myrow['currabrev'] . '">' . $myrow['currency'] . '</option>';
                    }
                    
		} //end while loop
		DB_data_seek($result,0);

		echo '</select></td></tr>';
	}
        
        echo '<tr><td>' . _('Block Account').'</td><td>';
        echo '<select class="form-select" name="inactive">'
                . '<option  value="0">No</option>'
                . '<option   value="1">Yes</option>'
                . '</select>';
        echo  '</td></tr>';
       
        
        $result=DB_query("SELECT code FROM postinggroups",$db);
  	if (DB_num_rows($result)==0){
		echo '<tr><td colspan="2"><p>' .
                         _('There are no posting currently defined') 
                        .'<br />'. _('go to the setup tab of the main menu and set at least one up first'). '</p></td>
			</tr>';
	} else {
        echo '<tr><td>'._('Customer Posting Group').'</td><td>';
        echo '<select class="form-select" name="customerposting">';
        while ($myrow = DB_fetch_array($result)) {
		echo '<option >' . $myrow['code'] . '</option>';
		} //end while loop
        echo '</select>' ;
        }      
     echo  '</td></tr>';
     
        echo '<tr><td>'._('Sales Person').'</td><td>';
        $result=DB_query("select code,salesman from salesrepsinfo",$db);    
        echo '<select class="form-select" name="salesman"><option value="">not selected</option>';
        while ($myrow = DB_fetch_array($result)) {
		echo '<option value="'.$myrow['code'].'">' . $myrow['salesman'] . '</option>';
		} //end while loop
        echo '</select>' ;
        echo  '</td></tr>';
        
        echo '<tr><td>' . _('PIN').'</td><td><input type="text" class="form-control" name="middlen" maxlength="15" />' ;

        echo '</table></td></tr></table>';

}

if (!isset($_GET['Modify'])) {
		echo '<div class="centre">
                        <input type="submit" name="submit" value="' . _('Add New Customer') . '" />&nbsp;
                        <input type="Reset" name="Reset" value="' . _('Reset') . '" />
                    </div>';
	} else {
	   echo '<br />
		<div class="centre">
		<input type="submit" name="submit" value="' . _('Update Customer') . '" />&nbsp;
		<input type="submit" name="delete" value="' . _('Delete Customer') . '" onclick="return confirm(\'' . _('Are You Sure You Want To Delete?') . '\');" />
            </div>';
	}
        
echo '</div></form>' ;



include('includes/footer.inc');


?>
