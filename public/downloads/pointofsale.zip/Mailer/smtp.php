<?php
/**
 * This example shows making an SMTP connection with authentication.
 */
/*
Host/SMTP Mail Server  smtp.gmail.com
Port 	465 (SSL) or 587 (TLS)
Connection/Use TLS if available 	Use TLS/Yes 
Authentication 	Password/login

 *  */
//SMTP needs accurate times, and the PHP time zone MUST be set
//This should be done in your php.ini, but this is how to do it if you don't have access to that
date_default_timezone_set('Etc/UTC');

require 'PHPMailerAutoload.php';

//Create a new PHPMailer instance
$mail = new PHPMailer;
//Tell PHPMailer to use SMTP
$mail->isSMTP();
//Enable SMTP debugging
// 0 = off (for production use)
// 1 = client messages
// 2 = client and server messages
$mail->SMTPDebug = 2;
//Ask for HTML-friendly debug output
$mail->Debugoutput = 'html';
//Set the hostname of the mail server
$mail->Host = "smtp.mail.yahoo.com";
//Set the SMTP port number - likely to be 25, 465 or 587
$mail->Port = 587;
//Whether to use SMTP authentication
$mail->SMTPAuth = true;
//Username to use for SMTP authentication
$mail->Username = "kkjonathan2002";
//Password to use for SMTP authentication
$mail->Password = "farris2016";
//Set who the message is to be sent from
 $mail->setFrom('kkjonathan2002@yahoo.com', 'First Last');
//Set an alternative reply-to address
 $mail->addReplyTo('jonathankiranga@gmail.com', 'First Last');
//Set who the message is to be sent to
$mail->addAddress('jonathankiranga@gmail.com', 'John Doe');
//Set the subject line
$mail->Subject = 'PHPMailer SMTP test';
//Read an HTML message body from an external file, convert referenced images to embedded,
//convert HTML into a basic plain-text alternative body
$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));
//Replace the plain text body with one created manually
$mail->AltBody = 'This is a plain-text message body';
//Attach an image file
$mail->addAttachment('examples/images/phpmailer_mini.png');

//send the message, check for errors
if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message sent!";
}
