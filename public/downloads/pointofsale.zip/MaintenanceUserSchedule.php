<?php

/* $Id: MaintenanceTasks.php 5231 2012-04-07 18:10:09Z daitnree $*/

include('includes/session.inc');

$Title = _('My Maintenance Jobs');

$Title = _('Fixed Assets Maintenance Schedule');

$ViewTopic = 'FixedAssets';
$BookMark = 'AssetMaintenance';

include('includes/header.inc');

echo '<p class="page_title_text"><img src="css/'.$Theme.'/images/group_add.png" title="' . _('Search') . '" alt="" />' . ' ' . $Title . '</p><br />';


if (isset($_GET['Complete'])) {
	$result = DB_query("UPDATE fixedassettasks SET lastcompleted='" . Date('Y-m-d') . "' WHERE taskid='" . $_GET['TaskID'] . "'",$db);
}
//SELECT DATEADD(day, 3, pubdate)
##DATE_ADD("2017-06-15", INTERVAL 10 DAY); 

$sql="SELECT taskid,
                fixedassettasks.assetid,
                description,
                taskdescription,
                frequencydays,
                lastcompleted,
                DATE_ADD(lastcompleted, interval frequencydays day) AS duedate,
                userresponsible,
                realname,
                manager
		FROM fixedassettasks
		INNER JOIN fixedassets
		ON fixedassettasks.assetid=fixedassets.assetid
		INNER JOIN www_users
		ON fixedassettasks.userresponsible=www_users.userid
		WHERE userresponsible='" . $_SESSION['UserID'] . "'
		OR manager = '" . $_SESSION['UserID'] . "'
		ORDER BY lastcompleted DESC";

$ErrMsg = _('The maintenance schedule cannot be retrieved because');
$Result=DB_query($sql,$db,$ErrMsg);

echo '<table class="table table-bordered">
     <tr>
		<th>' . _('Task ID') . '</th>
		<th>' . _('Asset') . '</th>
		<th>' . _('Description') . '</th>
		<th>' . _('Last Completed') . '</th>
		<th>' . _('Due By') . '</td>
		<th>' . _('Person') . '</th>
		<th>' . _('Manager') . '</th>
		<th>' . _('Now Complete') . '</th>
    </tr>';

while ($myrow=DB_fetch_array($Result)) {

	if ($myrow['manager']!=''){
		$ManagerResult = DB_query("SELECT realname FROM www_users WHERE userid='" . $myrow['manager'] . "'",$db);
		$ManagerRow = DB_fetch_array($ManagerResult);
		$ManagerName = $ManagerRow['realname'];
	} else {
		$ManagerName = _('No Manager Set');
	}

	echo '<tr>
			<td>' . $myrow['taskid'] . '</td>
			<td>' . $myrow['description'] . '</td>
			<td>' . $myrow['taskdescription'] . '</td>
			<td>' . ConvertSQLDate($myrow['lastcompleted']) . '</td>
			<td>' . ConvertSQLDate($myrow['duedate']) . '</td>
			<td>' . $myrow['realname'] . '</td>
			<td>' . $ManagerName . '</td>
			<td><a href="MaintenanceUserSchedule.php?Complete=Yes&amp;TaskID=' . $myrow['taskid'] .'" onclick="return confirm(\'' . _('Are you sure you wish to mark this maintenance task as completed?') . '\');">' . _('Mark Completed') . '</a></td>
		</tr>';
}

echo '</table><br /><br />';

include('includes/footer.inc');
?>