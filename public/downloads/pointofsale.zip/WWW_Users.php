<?php
/* $Id: WWW_Users.php 6467 2013-12-02 03:19:37Z exsonqu $*/
if (isset($_POST['UserID']) AND isset($_POST['ID'])){
	if ($_POST['UserID'] == $_POST['ID']) {
            $_POST['Language'] = $_POST['UserLanguage'];
	}
}
include('includes/session.inc');
include('includes/MainMenuLinksArray.php');
$PDFLanguages = array(_('Latin Western Languages'),
                      _('Eastern European Russian Japanese Korean Vietnamese Hebrew Arabic Thai'),
                      _('Chinese'),
                      _('Free Serif'));


$Title = _('Users Maintenance');
/* webERP manual links before header.inc */
$ViewTopic= 'GettingStarted';
$BookMark = 'UserMaintenance';
include('includes/header.inc');
include('includes/SQL_CommonFunctions.inc');

echo '<p class="page_title_text"><img src="css/'.$Theme.'/images/group_add.png" title="' . _('Search') . '" alt="" />' . ' ' . $Title . '</p><br />';
// Make an array of the security roles
$sql = "SELECT secroleid,secrolename FROM securityroles where secroleid <=".$_SESSION['AccessLevel']."  ORDER BY secrolename";

$Sec_Result = DB_query($sql, $db);
$SecurityRoles = array();

// Now load it into an a ray using Key/Value pairs
while($Sec_row = DB_fetch_row($Sec_Result) ) {
    $SecurityRoles[$Sec_row[0]] = $Sec_row[1];
}


DB_free_result($Sec_Result);

if (isset($_GET['SelectedUser'])){
	$SelectedUser = $_GET['SelectedUser'];
} elseif (isset($_POST['SelectedUser'])){
	$SelectedUser = $_POST['SelectedUser'];
}

if (isset($_POST['submit'])) {

	//initialise no input errors assumed initially before we test
	$InputError = 0;

	/* actions to take once the user has clicked the submit button
	ie the page has called itself with some user input */

	//first off validate inputs sensible
	if (mb_strlen($_POST['UserID'])<4){
		$InputError = 1;
		prnMsg(_('The user ID entered must be at least 4 characters long'),'error');
	} elseif (ContainsIlLegalCharacters($_POST['UserID'])) {
		$InputError = 1;
		prnMsg(_('User names cannot contain any of the following characters') . " - ' &amp; + \" \\ " . _('or a space'),'error');
	} elseif (mb_strlen($_POST['Password'])<5){
		if (!$SelectedUser){
                    $InputError = 1;
                    prnMsg(_('The password entered must be at least 5 characters long'),'error');
		}
	} elseif (mb_strstr($_POST['Password'],$_POST['UserID'])!= False){
		$InputError = 1;
		prnMsg(_('The password cannot contain the user id'),'error');
	} elseif ((mb_strlen($_POST['Cust'])>0)
				AND (mb_strlen($_POST['BranchCode'])==0)) {
		$InputError = 1;
		prnMsg(_('If you enter a Customer Code you must also enter a Branch Code valid for this Customer'),'error');
	} elseif ($AllowDemoMode AND $_POST['UserID'] == 'admin') {
		prnMsg(_('The Administrator user called demo cannot be modified.'),'error');
		$InputError = 1;
	}

	if (!isset($SelectedUser)){
		/* check to ensure the user id is not already entered */
		$result = DB_query("SELECT userid FROM www_users WHERE userid='" . $_POST['UserID'] . "'",$db);
		if (DB_num_rows($result)==1){
			$InputError =1;
			prnMsg(_('The user ID') . ' ' . $_POST['UserID'] . ' ' . _('already exists and cannot be used again'),'error');
		}
	}

	

	/* Make a comma separated list of modules allowed ready to update the database*/
	$i=0;
	$ModulesAllowed = '';
	while ($i < count($ModuleList)){
		$FormVbl = 'Module_' . $i;
		$ModulesAllowed .= $_POST[($FormVbl)] . ',';
		$i++;
	}
	$_POST['ModulesAllowed']= $ModulesAllowed;

	if (isset($SelectedUser) AND $InputError !=1) {

/*SelectedUser could also exist if submit had not been clicked this code would not run in this case cos submit is false of course  see the delete code below*/

		if (!isset($_POST['Cust'])
			OR $_POST['Cust']==NULL
			OR $_POST['Cust']==''){

			$_POST['Cust']='';
			$_POST['BranchCode']='';
		}
		$UpdatePassword = '';
		if ($_POST['Password'] != ''){
			$UpdatePassword = "password='" . CryptPass($_POST['Password']) . "',";
		}

		$sql = "UPDATE www_users SET realname='" . $_POST['RealName'] . "',
                            customerid='" . $_POST['Cust'] ."',
                            phone='" . $_POST['Phone'] ."',
                            email='" . $_POST['Email'] ."',
                            " . $UpdatePassword . "
                            branchcode='" . $_POST['BranchCode'] . "',
                            supplierid='" . $_POST['SupplierID'] . "',
                            salesman='" . $_POST['Salesman'] . "',
                            pagesize='" . $_POST['PageSize'] . "',
                            fullaccess='" . $_POST['Access'] . "',
                            cancreatetender='" . $_POST['CanCreateTender'] . "',
                            theme='" . $_POST['Theme'] . "',
                            language ='" . $_POST['UserLanguage'] . "',
                            defaultlocation='" . $_POST['DefaultLocation'] ."',
                            modulesallowed='" . $ModulesAllowed . "',
                            blocked='" . $_POST['Blocked'] . "',
                            pdflanguage='" . $_POST['PDFLanguage'] . "' 
                            WHERE userid = '". $SelectedUser . "'";

		prnMsg( _('The selected user record has been updated'), 'success' );
	} elseif ($InputError !=1) {

		$sql = "INSERT INTO www_users (userid,
                        realname,
                        customerid,
                        branchcode,
                        supplierid,
                        salesman,
                        password,
                        phone,
                        email,
                        pagesize,
                        fullaccess,
                        cancreatetender,
                        defaultlocation,
                        modulesallowed,
                        displayrecordsmax,
                        theme,
                        language,
                        pdflanguage)
                VALUES ('" . $_POST['UserID'] . "',
                        '" . $_POST['RealName'] ."',
                        '" . $_POST['Cust'] ."',
                        '" . $_POST['BranchCode'] ."',
                        '" . $_POST['SupplierID'] ."',
                        '" . $_POST['Salesman'] . "',
                        '" . CryptPass($_POST['Password']) ."',
                        '" . $_POST['Phone'] . "',
                        '" . $_POST['Email'] ."',
                        '" . $_POST['PageSize'] ."',
                        '" . $_POST['Access'] . "',
                        '" . $_POST['CanCreateTender'] . "',
                        '" . $_POST['DefaultLocation'] ."',
                        '" . $ModulesAllowed . "',
                        '" . $_SESSION['DefaultDisplayRecordsMax'] . "',
                        '" . $_POST['Theme'] . "',
                        '". $_POST['UserLanguage'] ."',
                        '" . $_POST['PDFLanguage'] . "')";
		prnMsg( _('A new user record has been inserted'), 'success' );
	}

	if ($InputError!=1){
		//run the SQL from either of the above possibilites
		$ErrMsg = _('The user alterations could not be processed because');
		$DbgMsg = _('The SQL that was used to update the user and failed was');
		$result = DB_query($sql,$db,$ErrMsg,$DbgMsg);

		unset($_POST['UserID']);
		unset($_POST['RealName']);
		unset($_POST['Cust']);
		unset($_POST['BranchCode']);
		unset($_POST['SupplierID']);
		unset($_POST['Salesman']);
		unset($_POST['Phone']);
		unset($_POST['Email']);
		unset($_POST['Password']);
		unset($_POST['PageSize']);
		unset($_POST['Access']);
		unset($_POST['CanCreateTender']);
		unset($_POST['DefaultLocation']);
		unset($_POST['ModulesAllowed']);
		unset($_POST['Blocked']);
		unset($_POST['Theme']);
		unset($_POST['UserLanguage']);
		unset($_POST['PDFLanguage']);
		unset($_POST['Department']);
		unset($SelectedUser);
	}

} elseif (isset($_GET['delete'])) {
//the link to delete a selected record was clicked instead of the submit button


	if ($AllowDemoMode AND $SelectedUser == 'admin') {
		prnMsg(_('The user called admin cannot be deleted'),'error');
	} else {
		$sql="SELECT userid FROM audittrail where userid='" . $SelectedUser ."'";
		$result=DB_query($sql, $db);
		if (DB_num_rows($result)!=0) {
			prnMsg(_('Cannot delete user as entries already exist in the audit trail'), 'warn');
		} else {
			$sql="DELETE FROM www_users WHERE userid='" . $SelectedUser . "'";
			$ErrMsg = _('The User could not be deleted because');;
			$result = DB_query($sql,$db,$ErrMsg);
			prnMsg(_('User Deleted'),'info');
		}
		unset($SelectedUser);
	}

}

if (!isset($SelectedUser)) {

/* If its the first time the page has been displayed with no parameters then none of the above are true and the list of Users will be displayed with links to delete or edit each. These will call the same page again and allow update/input or deletion of the records*/

	$sql = "SELECT userid,
                    realname,
                    phone,
                    email,
                    customerid,
                    branchcode,
                    supplierid,
                    salesman,
                    lastvisitdate,
                    fullaccess,
                    cancreatetender,
                    pagesize,
                    theme,
                    language
            FROM www_users where fullaccess <='".$_SESSION['AccessLevel']."'";
	$result = DB_query($sql,$db);

	echo '<div class="card"><table class="table-bordered">';
	echo '<tr><th>' . _('User Login') . '</th>
                <th>' . _('Full Name') . '</th>
                <th>' . _('Telephone') . '</th>
                <th>' . _('Email') . '</th>
                <th>' . _('Customer Code') . '</th>
                <th>' . _('Supplier Code') . '</th>
                <th>' . _('Salesperson') . '</th>
                <th>' . _('Last Visit') . '</th>
                <th>' . _('Security Role')  . '</th>
                <th>' . _('Report Size')  . '</th>
                <th>' . _('Theme')  . '</th>
                <th>' . _('Language')  . '</th>
                </tr>';


	while ($myrow = DB_fetch_array($result)) {

	if ($myrow[8]=='') {
		$LastVisitDate = Date($_SESSION['DefaultDateFormat']);
	} else {
		$LastVisitDate = ConvertSQLDate($myrow['lastvisitdate']);
	}

		/*The SecurityHeadings array is defined in config.php */

		printf('<tr><td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td><a href="%s&amp;SelectedUser=%s">' . _('Edit') . '</a></td>
                            <td><a href="%s&amp;SelectedUser=%s&amp;delete=1" onclick="return confirm(\'' . _('Are you sure you wish to delete this user?') . '\');">' . _('Delete') . '</a></td>
                            </tr>',
                            $myrow['userid'],
                            $myrow['realname'],
                            $myrow['phone'],
                            $myrow['email'],
                            $myrow['customerid'],
                            $myrow['supplierid'],
                            $myrow['salesman'],
                            $LastVisitDate,
                            $SecurityRoles[($myrow['fullaccess'])],
                            $myrow['pagesize'],
                            $myrow['theme'],
                            $LanguagesArray[$myrow['language']]['LanguageName'],
                            htmlspecialchars($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8')  . '?',
                            $myrow['userid'],
                            htmlspecialchars($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8') . '?',
                            $myrow['userid']);

	} //END WHILE LIST LOOP
	echo '</table></div><br />';
} //end of ifs and buts!


if (isset($SelectedUser)) {
   echo '<div class="centre"><a href="' . htmlspecialchars($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8')  . '">' . _('Review Existing Users') . '</a></div><br />';
}

echo '<form method="post" action="' . htmlspecialchars($_SERVER['PHP_SELF'],ENT_QUOTES,'UTF-8') . '">';
echo '<div class="card">';
echo '<input type="hidden" name="FormID" value="' . $_SESSION['FormID'] . '" />';

if (isset($SelectedUser)) {
	//editing an existing User

	$sql = "SELECT userid,
			realname,
			phone,
			email,
			customerid,
			password,
			supplierid,
			salesman,
			pagesize,
			fullaccess,
			cancreatetender,
			defaultlocation,
			modulesallowed,
			blocked,
			theme,
			language,
			pdflanguage
		FROM www_users
		WHERE userid='" . $SelectedUser . "'";

	$result = DB_query($sql, $db);
	$myrow = DB_fetch_array($result);

	$_POST['UserID'] = $myrow['userid'];
	$_POST['RealName'] = $myrow['realname'];
	$_POST['Phone'] = $myrow['phone'];
	$_POST['Email'] = $myrow['email'];
	$_POST['Cust']	= $myrow['customerid'];
	$_POST['BranchCode']  = $myrow['branchcode'];
	$_POST['SupplierID'] = $myrow['supplierid'];
	$_POST['Salesman'] = $myrow['salesman'];
	$_POST['PageSize'] = $myrow['pagesize'];
	$_POST['Access'] = $myrow['fullaccess'];
	$_POST['CanCreateTender'] = $myrow['cancreatetender'];
	$_POST['DefaultLocation'] = $myrow['defaultlocation'];
	$_POST['ModulesAllowed'] = $myrow['modulesallowed'];
	$_POST['Theme'] = $myrow['theme'];
	$_POST['UserLanguage'] = $myrow['language'];
	$_POST['Blocked'] = $myrow['blocked'];
	$_POST['PDFLanguage'] = $myrow['pdflanguage'];
	
	echo '<input type="hidden" name="SelectedUser" value="' . $SelectedUser . '" />';
	echo '<input type="hidden" name="UserID" value="' . $_POST['UserID'] . '" />';
	echo '<input type="hidden" name="ModulesAllowed" value="' . $_POST['ModulesAllowed'] . '" />';
	echo '<table class="table table-bordered"><tr>
                    <td>' . _('User code') . ':</td>
                    <td>' . $_POST['UserID'] . '</td>
                </tr>';

} else { //end of if $SelectedUser only do the else when a new record is being entered
   
echo '<table class="table-bordered"><tr>
        <td>' . _('User Login') . ':</td>
        <td><input pattern="(?!^([aA]{1}[dD]{1}[mM]{1}[iI]{1}[nN]{1})$)[^?+.&\\>< ]{4,}" type="text" required="required" name="UserID" size="22" maxlength="20" placeholder="'._('At least 4 characters').'" title="'._('Please input not less than 4 characters and canot be admin or contains illegal characters').'"  /></td>
    </tr>';

	/*set the default modules to show to all
	this had trapped a few people previously*/
	$i=0;
	if (!isset($_POST['ModulesAllowed'])) {
		$_POST['ModulesAllowed']='';
	}

	foreach($ModuleList as $ModuleName){
		if ($i>0){
			$_POST['ModulesAllowed'] .=',';
		}
		$_POST['ModulesAllowed'] .= '1';
		$i++;
	}
}

if (!isset($_POST['Password'])) {
	$_POST['Password']='';
}
if (!isset($_POST['RealName'])) {
	$_POST['RealName']='';
}
if (!isset($_POST['Phone'])) {
	$_POST['Phone']='';
}
if (!isset($_POST['Email'])) {
	$_POST['Email']='';
}
echo '<tr>
		<td>' . _('Password') . ':</td>
		<td><input type="password" pattern=".{5,}" name="Password" ' . (!isset($SelectedUser) ? 'required="required"' : '') . ' size="22" maxlength="20" value="' . $_POST['Password'] . '" placeholder="'._('At least 5 characters').'" title="'._('Passwords must be 5 characters or more and cannot same as the users id. A mix of upper and lower case and some non-alphanumeric characters are recommended.').'" /></td>
	</tr>';
echo '<tr>
		<td>' . _('Full Name') . ':</td>
		<td><input type="text" name="RealName" ' . (isset($SelectedUser) ? 'autofocus="autofocus"' : '') . ' required="required" value="' . $_POST['RealName'] . '" size="20" maxlength="20" /></td>
	</tr>';
echo '<tr>
		<td>' . _('Telephone No') . ':</td>
		<td><input type="tel" name="Phone" pattern="[0-9+()\s-]*" value="' . $_POST['Phone'] . '"  size="32" maxlength="30" /></td>
	</tr>';
echo '<tr>
		<td>' . _('Email Address') .':</td>
		<td><input type="email" name="Email" placeholder="' . _('e.g. user@domain.com') . '" required="required" value="' . $_POST['Email'] .'" size="32" maxlength="55" title="'._('A valid email address is required').'" /></td>
	</tr>';
echo '<tr>
		<td>' . _('Security Role') . ':</td>
		<td><select name="Access">';

foreach ($SecurityRoles as $SecKey => $SecVal) {
	if (isset($_POST['Access']) and $SecKey == $_POST['Access']){
		echo '<option selected="selected" value="' . $SecKey . '">' . $SecVal  . '</option>';
	} else {
		echo '<option value="' . $SecKey . '">' . $SecVal  . '</option>';
	}
}
echo '</select>';
echo '<input type="hidden" name="ID" value="'.$_SESSION['UserID'].'" /></td>

    </tr>';

echo '<tr><td>' . _('User Can Create Tenders') . ':</td>
		<td><select name="CanCreateTender">';

if ($_POST['CanCreateTender']==0){
	echo '<option selected="selected" value="0">' . _('No') . '</option>';
	echo '<option value="1">' . _('Yes') . '</option>';
} else {
 	echo '<option selected="selected" value="1">' . _('Yes') . '</option>';
	echo '<option value="0">' . _('No') . '</option>';
}
echo '</select></td></tr>';

if (!isset($_POST['Cust'])) {
	$_POST['Cust']='';
}
if (!isset($_POST['BranchCode'])) {
	$_POST['BranchCode']='';
}
if (!isset($_POST['SupplierID'])) {
	$_POST['SupplierID']='';
}


echo '<tr><td>' . _('Customer Code') . ':</td><td>';
echo '<select name="Cust"><option VALUE="">Not Selected</option>';

    foreach($COMBOCLASS->CustomerArray as $row){
         if($row['debtorno']==$_POST['Cust']){
           echo '<option selected="selected"  value="'.$row['debtorno'].'">'.$row['name'].'</option>';
        } else {
           echo '<option value="'.$row['debtorno'].'">'.$row['name'].'</option>';
        }
    }
    echo '</select>';

echo '</tr><tr><td>' . _('Supplier Code') . ':</td><td>';

    echo '<select name="SupplierID"><option value="">Not Selected</option>';
    foreach($COMBOCLASS->SupplierArray as $row){
        if($row['supplierid']==$_POST['SupplierID']){
             echo '<option  selected="selected" value="'.$row['supplierid'].'">'. $row['suppname'] .'</option>';
        } else {
            echo '<option   value="'.$row['supplierid'].'">'. $row['suppname'] .'</option>';
        }
    }
    echo '</select>';

echo    '</td></tr><tr><td>' . _('Restrict to Sales Person') . ':</td><td><select name="Salesman">';

$sql = "SELECT [code],[salesman] FROM salesrepsinfo WHERE ([inactive] is null or [inactive]=0)"
        . " ORDER BY [salesman]";
$result = DB_query($sql,$db);
if ((isset($_POST['Salesman']) AND $_POST['Salesman']=='') OR !isset($_POST['Salesman'])){
	echo '<option selected="selected" value="">' .  _('Not a salesperson only login') . '</option>';
} else {
	echo '<option value="">' . _('Not a salesperson only login') . '</option>';
}
while ($myrow=DB_fetch_array($result)){

	if (isset($_POST['Salesman']) AND $myrow['code'] == $_POST['Salesman']){
		echo '<option selected="selected" value="' . $myrow['code'] . '">' . $myrow['salesman'] . '</option>';
	} else {
		echo '<option value="' . $myrow['code'] . '">' . $myrow['salesman'] . '</option>';
	}

}

echo '</select></td></tr>';
echo '<tr><td>' . _('Reports Page Size') .':</td><td><select name="PageSize">';

if(isset($_POST['PageSize']) AND $_POST['PageSize']=='A4'){
    echo '<option selected="selected" value="A4">' . _('A4')  . '</option>';
} else {
    echo '<option value="A4">' . _('A4') . '</option>';
}

if(isset($_POST['PageSize']) AND $_POST['PageSize']=='A3'){
    echo '<option selected="selected" value="A3">' . _('A3')  . '</option>';
} else {
    echo '<option value="A3">' . _('A3')  . '</option>';
}

if(isset($_POST['PageSize']) AND $_POST['PageSize']=='A3_Landscape'){
    echo '<option selected="selected" value="A3_Landscape">' . _('A3') . ' ' . _('landscape')  . '</option>';
} else {
    echo '<option value="A3_Landscape">' . _('A3') . ' ' . _('landscape')  . '</option>';
}

if(isset($_POST['PageSize']) AND $_POST['PageSize']=='Letter'){
    echo '<option selected="selected" value="Letter">' . _('Letter')  . '</option>';
} else {
   echo '<option value="Letter">' . _('Letter')  . '</option>';
}

if(isset($_POST['PageSize']) AND $_POST['PageSize']=='Letter_Landscape'){
	echo '<option selected="selected" value="Letter_Landscape">' . _('Letter') . ' ' . _('landscape')  . '</option>';
} else {
	echo '<option value="Letter_Landscape">' . _('Letter') . ' ' . _('landscape')  . '</option>';
}

if(isset($_POST['PageSize']) AND $_POST['PageSize']=='Legal'){
	echo '<option selected="selected" value="Legal">' . _('Legal')  . '</option>';
} else {
	echo '<option value="Legal">' . _('Legal')  . '</option>';
}
if(isset($_POST['PageSize']) AND $_POST['PageSize']=='Legal_Landscape'){
	echo '<option selected="selected" value="Legal_Landscape">' . _('Legal') . ' ' . _('landscape')  . '</option>';
} else {
	echo '<option value="Legal_Landscape">' . _('Legal') . ' ' . _('landscape')  . '</option>';
}

echo '</select></td>
	</tr>';

echo '<tr>
		<td>' . _('Theme') . ':</td>
		<td><select required="required" name="Theme">';

$ThemeDirectories = scandir('css/');


foreach ($ThemeDirectories as $ThemeName) {

	if (is_dir('css/' . $ThemeName) AND $ThemeName != '.' AND $ThemeName != '..' AND $ThemeName != '.svn'){

		if (isset($_POST['Theme']) AND $_POST['Theme'] == $ThemeName){
			echo '<option selected="selected" value="' . $ThemeName . '">' . $ThemeName  . '</option>';
		} else if (!isset($_POST['Theme']) AND ($_SESSION['DefaultTheme']==$ThemeName)) {
			echo '<option selected="selected" value="' . $ThemeName . '">' . $ThemeName  . '</option>';
		} else {
			echo '<option value="' . $ThemeName . '">' . $ThemeName . '</option>';
		}
	}
}

echo '</select></td>
	</tr>';


echo '<tr>
		<td>' . _('Language') . ':</td>
		<td><select required="required" name="UserLanguage">';

foreach ($LanguagesArray as $LanguageEntry => $LanguageName){
    if (isset($_POST['UserLanguage']) AND $_POST['UserLanguage'] == $LanguageEntry){
            echo '<option selected="selected" value="' . $LanguageEntry . '">' . $LanguageName['LanguageName']  . '</option>';
    } elseif (!isset($_POST['UserLanguage']) AND $LanguageEntry == $DefaultLanguage) {
            echo '<option selected="selected" value="' . $LanguageEntry . '">' . $LanguageName['LanguageName']  . '</option>';
    } else {
            echo '<option value="' . $LanguageEntry . '">' . $LanguageName['LanguageName']  . '</option>';
    }
}
echo '</select></td>
	</tr>';

/*Make an array out of the comma separated list of modules allowed*/
$ModulesAllowed = explode(',',$_POST['ModulesAllowed']);
/*
$i=0;
foreach($ModuleList as $ModuleName){

    echo '<tr><td>' . _('Display') . ' ' . $ModuleName . ' ' . _('module') . ': </td><td><select name="Module_' . $i . '">';
    if ($ModulesAllowed[$i]==0){
            echo '<option selected="selected" value="0">' . _('No') . '</option>';
            echo '<option value="1">' . _('Yes') . '</option>';
    } else {
            echo '<option selected="selected" value="1">' . _('Yes') . '</option>';
            echo '<option value="0">' . _('No') . '</option>';
    }
    echo '</select></td></tr>';
    $i++;
}
*/
if (!isset($_POST['PDFLanguage'])){
	$_POST['PDFLanguage']=0;
}

echo '<tr><td>' . _('PDF Language Support') . ': </td><td><select name="PDFLanguage">';
for($i=0;$i<count($PDFLanguages);$i++){
	if ($_POST['PDFLanguage']==$i){
		echo '<option selected="selected" value="' . $i .'">' . $PDFLanguages[$i] . '</option>';
	} else {
		echo '<option value="' . $i .'">' . $PDFLanguages[$i]. '</option>';
	}
}
echo '</select></td></tr>';



/* Account status */

echo '<tr><td>' . _('Account Status') . ':</td><td><select required="required" name="Blocked">';
if ($_POST['Blocked']==0){
	echo '<option selected="selected" value="0">' . _('Open') . '</option>';
	echo '<option value="1">' . _('Blocked') . '</option>';
} else {
 	echo '<option selected="selected" value="1">' . _('Blocked') . '</option>';
	echo '<option value="0">' . _('Open') . '</option>';
}
echo '</select></td></tr>';

echo '</table><br /><div class="centre">
		<input type="submit" name="submit" value="' . _('Enter Information') . '" />
	</div></div></form>';

include('includes/footer.inc');

class ComboBox {
    var  $CustomerArray = array();
    var  $SupplierArray = array();
    var  $accountno ;

    function getCustomers(){
        global $db;
        $results = DB_query('SELECT [itemcode] as debtorno,[customer] as name FROM [debtors]',$db);
        while($row = DB_fetch_array($results)){
             $this->CustomerArray[] = $row;
        }
    }

    function getSuppliers(){
        global $db;
        $results = DB_query('SELECT [itemcode] as supplierid,[customer] as suppname FROM [creditors]',$db);
        while($row = DB_fetch_array($results)){
              $this->SupplierArray[] = $row;
         }
    }

    function __construct() {
       $this->getCustomers() ;
       $this->getSuppliers() ;
    }

    


}

$COMBOCLASS = NEW ComboBox;