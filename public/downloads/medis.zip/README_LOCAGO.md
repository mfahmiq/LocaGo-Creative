# Pharmacy Store Management System - Medis

```
========================================================================
📦 Pharmacy Store Management System - Medis
Kategori     : Kesehatan & Medis
Tech Stack   : PHP Native • PHP • MySQL
Database     : MySQL (.sql) (File: database/database.sql)
Sumber Asli  : https://github.com/Zamkhammohsin/Medis (GitHub Open Source)
Stars GitHub : ⭐ 0 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/medis`
     * Untuk Laragon: `C:/laragon/www/medis`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - File SQL ini membuat database `medis_db` sendiri — tidak perlu membuat
     database manual. Klik tab 'Import', pilih file SQL yang disertakan pada:
     `database/database.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. JALANKAN SEED — WAJIB (membuat akun login + data contoh):
   - Buka di browser: http://localhost/medis/database/seed.php
   - Langkah ini membuat akun login di bawah + mengisi data contoh.
     TANPA langkah ini akun login TIDAK BISA dipakai: password di file .sql
     tidak didokumentasikan oleh repo aslinya.

4. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = medis_db

5. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/medis

6. AKUN LOGIN DEMO (dari README repo asli):
   - Administrator: admin@medis.pk / Admin@123
   - Branch Manager: manager.lahore@medis.pk / Manager@123
   - Cashier (POS): cashier1@medis.pk / Cashier@123

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
