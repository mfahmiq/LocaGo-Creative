# Panduan Deploy Katalog UMKM Next.js
1. Jalankan `npm install` di terminal.
2. Atur nomor WhatsApp toko di file config.
3. Tambahkan produk di `src/data/products.json`.
4. Jalankan `npm run dev` untuk preview lokal.
5. Push ke GitHub dan deploy gratis ke Vercel atau Cloudflare Pages!
