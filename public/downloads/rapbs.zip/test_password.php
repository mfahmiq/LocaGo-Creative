<?php

$hash = '$2y$10$fvSHKbYK6oIc81ctf8fwo.lLxBpcFBdJZtgFXeWFWgguoUA2QKr7O';

$password = 'AdminRAPBS2026!';

if (password_verify($password, $hash)) {
    echo 'PASSWORD BENAR';
} else {
    echo 'PASSWORD SALAH';
}