# RAPBS CodeIgniter 3 - Tahap 1

Tahap pertama berisi:
- konfigurasi database MySQL `rapbs_ci3`
- login
- setup password admin pertama kali
- session login
- dashboard
- total penerimaan
- total pengeluaran
- saldo
- jumlah murid
- jumlah pegawai
- ringkasan penerimaan per kategori
- ringkasan pengeluaran per kategori

## 1. Syarat
- PHP yang kompatibel dengan CodeIgniter 3
- MySQL/MariaDB
- CodeIgniter 3
- Database `rapbs_ci3` dari file `database_rapbs_ci3_fixed.sql`

## 2. Pasang
Ekstrak CodeIgniter 3.
Salin folder `application` dari paket ini ke project CI3 Anda.
Jika sudah ada folder application, backup dulu lalu gabungkan file-file di dalamnya.

## 3. Database
Edit:
`application/config/database.php`

Sesuaikan:
- hostname
- username
- password
- database

Default:
database = rapbs_ci3
username = root
password = kosong

## 4. Base URL
Edit:
`application/config/config.php`

Contoh XAMPP:
$config['base_url'] = 'http://localhost/rapbs/';

Nama folder project harus sama dengan URL tersebut.

## 5. Mod_rewrite
Tahap ini bisa tetap berjalan dengan index.php.
Jika ingin URL tanpa index.php, aktifkan rewrite Apache kemudian:
$config['index_page'] = '';

Jika belum paham rewrite, tidak perlu diubah dulu.

## 6. Buat password admin
Karena SQL awal sengaja tidak menyimpan password default:
buka:
http://localhost/rapbs/setup

Buat password minimal 8 karakter.

Setelah selesai, buka:
http://localhost/rapbs/login

Username:
admin

Password:
password yang baru dibuat.

## 7. Dashboard
Setelah login:
http://localhost/rapbs/dashboard

Dashboard membaca langsung dari tabel:
- budget_headers
- budget_items
- academic_years
- students
- employees
- income_categories
- expense_categories

## Catatan keamanan
- Ganti `encryption_key` pada config.php.
- Jangan memakai password admin sederhana pada server produksi.
- Setelah setup password berhasil, route setup otomatis menolak setup ulang karena password sudah terisi.
- Untuk produksi, aktifkan HTTPS dan CSRF.
