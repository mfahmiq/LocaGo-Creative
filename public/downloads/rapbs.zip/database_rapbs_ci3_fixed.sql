-- ============================================================
-- DATABASE RAPBS / RAKS - CodeIgniter 3
-- Sumber awal: RAPBS 2025/2026 KB AISYIYAH PENCONGAN
-- Dibuat dari workbook yang diunggah pengguna.
-- ============================================================

SET NAMES utf8mb4;
SET time_zone = '+07:00';

CREATE DATABASE IF NOT EXISTS rapbs_ci3
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE rapbs_ci3;

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS analysis_allocations;
DROP TABLE IF EXISTS budget_item_sources;
DROP TABLE IF EXISTS budget_items;
DROP TABLE IF EXISTS budget_headers;
DROP TABLE IF EXISTS employee_allowances;
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS fund_sources;
DROP TABLE IF EXISTS expense_categories;
DROP TABLE IF EXISTS income_categories;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS academic_years;
DROP TABLE IF EXISTS schools;

SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE schools (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    address TEXT NULL,
    phone VARCHAR(50) NULL,
    email VARCHAR(150) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE academic_years (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    school_id INT UNSIGNED NOT NULL,
    name VARCHAR(30) NOT NULL,
    start_year SMALLINT UNSIGNED NULL,
    end_year SMALLINT UNSIGNED NULL,
    status ENUM('aktif','nonaktif') NOT NULL DEFAULT 'nonaktif',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_academic_year (school_id, name),
    CONSTRAINT fk_year_school FOREIGN KEY (school_id) REFERENCES schools(id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(150) NOT NULL,
    password_hash VARCHAR(255) NULL,
    role ENUM('admin','bendahara','kepala_sekolah','operator') NOT NULL DEFAULT 'operator',
    active TINYINT(1) NOT NULL DEFAULT 1,
    last_login DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE students (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    academic_year_id INT UNSIGNED NOT NULL,
    nis VARCHAR(50) NULL,
    name VARCHAR(150) NOT NULL,
    gender ENUM('L','P') NULL,
    class_name VARCHAR(100) NULL,
    active TINYINT(1) NOT NULL DEFAULT 1,
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_student_year (academic_year_id),
    CONSTRAINT fk_student_year FOREIGN KEY (academic_year_id) REFERENCES academic_years(id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE employees (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    school_id INT UNSIGNED NOT NULL,
    employee_no VARCHAR(50) NULL,
    name VARCHAR(150) NOT NULL,
    join_date DATE NULL,
    permanent_date DATE NULL,
    sk_no VARCHAR(100) NULL,
    education VARCHAR(100) NULL,
    position VARCHAR(150) NULL,
    employment_status VARCHAR(100) NULL,
    first_basic_salary DECIMAL(15,2) NOT NULL DEFAULT 0,
    last_basic_salary DECIMAL(15,2) NOT NULL DEFAULT 0,
    active TINYINT(1) NOT NULL DEFAULT 1,
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_employee_school (school_id),
    CONSTRAINT fk_employee_school FOREIGN KEY (school_id) REFERENCES schools(id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE employee_allowances (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    employee_id INT UNSIGNED NOT NULL,
    allowance_name VARCHAR(150) NOT NULL,
    amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    period_months TINYINT UNSIGNED NOT NULL DEFAULT 12,
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_allowance_employee FOREIGN KEY (employee_id) REFERENCES employees(id)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE fund_sources (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE income_categories (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE expense_categories (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(200) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE budget_headers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    academic_year_id INT UNSIGNED NOT NULL,
    title VARCHAR(255) NOT NULL,
    status ENUM('draft','disetujui','ditutup') NOT NULL DEFAULT 'draft',
    prepared_date DATE NULL,
    approved_date DATE NULL,
    prepared_by INT UNSIGNED NULL,
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_budget_year (academic_year_id),
    CONSTRAINT fk_budget_year FOREIGN KEY (academic_year_id) REFERENCES academic_years(id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_budget_user FOREIGN KEY (prepared_by) REFERENCES users(id)
        ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE budget_items (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    budget_id INT UNSIGNED NOT NULL,
    item_type ENUM('penerimaan','pengeluaran') NOT NULL,
    income_category_id INT UNSIGNED NULL,
    expense_category_id INT UNSIGNED NULL,
    parent_id INT UNSIGNED NULL,
    item_code VARCHAR(50) NULL,
    description VARCHAR(255) NOT NULL,
    period_count DECIMAL(12,2) NOT NULL DEFAULT 1,
    quantity DECIMAL(12,2) NOT NULL DEFAULT 0,
    unit_price DECIMAL(15,2) NOT NULL DEFAULT 0,
    amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    fixed_cost DECIMAL(15,2) NOT NULL DEFAULT 0,
    variable_cost DECIMAL(15,2) NOT NULL DEFAULT 0,
    last_year_realization DECIMAL(15,2) NOT NULL DEFAULT 0,
    usage_description TEXT NULL,
    notes TEXT NULL,
    excel_row INT NULL,
    formula_reference VARCHAR(255) NULL,
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_budget_item_type (budget_id, item_type),
    INDEX idx_budget_item_parent (parent_id),
    CONSTRAINT fk_budget_item_header FOREIGN KEY (budget_id) REFERENCES budget_headers(id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_budget_item_income_cat FOREIGN KEY (income_category_id) REFERENCES income_categories(id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_budget_item_expense_cat FOREIGN KEY (expense_category_id) REFERENCES expense_categories(id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_budget_item_parent FOREIGN KEY (parent_id) REFERENCES budget_items(id)
        ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE budget_item_sources (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    budget_item_id INT UNSIGNED NOT NULL,
    fund_source_id INT UNSIGNED NOT NULL,
    amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    notes TEXT NULL,
    UNIQUE KEY uq_item_source (budget_item_id, fund_source_id),
    CONSTRAINT fk_item_source_item FOREIGN KEY (budget_item_id) REFERENCES budget_items(id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_item_source_fund FOREIGN KEY (fund_source_id) REFERENCES fund_sources(id)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE analysis_allocations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    budget_id INT UNSIGNED NOT NULL,
    income_item_id INT UNSIGNED NULL,
    expense_item_id INT UNSIGNED NULL,
    allocation_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    per_student_amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    plus_minus_per_student DECIMAL(15,2) NOT NULL DEFAULT 0,
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_analysis_budget FOREIGN KEY (budget_id) REFERENCES budget_headers(id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_analysis_income FOREIGN KEY (income_item_id) REFERENCES budget_items(id)
        ON UPDATE CASCADE ON DELETE SET NULL,
    CONSTRAINT fk_analysis_expense FOREIGN KEY (expense_item_id) REFERENCES budget_items(id)
        ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- View ringkas untuk dashboard.
DROP VIEW IF EXISTS v_budget_summary;
CREATE VIEW v_budget_summary AS
SELECT
    bh.id AS budget_id,
    bh.academic_year_id,
    SUM(CASE WHEN bi.item_type='penerimaan' THEN bi.amount ELSE 0 END) AS total_penerimaan,
    SUM(CASE WHEN bi.item_type='pengeluaran' THEN bi.amount ELSE 0 END) AS total_pengeluaran,
    SUM(CASE WHEN bi.item_type='penerimaan' THEN bi.amount ELSE -bi.amount END) AS saldo
FROM budget_headers bh
LEFT JOIN budget_items bi ON bi.budget_id = bh.id
GROUP BY bh.id, bh.academic_year_id;

-- DATA MASTER
INSERT INTO schools (id, name) VALUES (1, 'KB AISYIYAH PENCONGAN');
INSERT INTO academic_years (id, school_id, name, start_year, end_year, status) VALUES (1, 1, '2025/2026', 2025, 2026, 'aktif');
-- password_hash sengaja NULL agar password admin dibuat melalui fitur setup/ubah password CI3.
INSERT INTO users (id, username, full_name, role, active) VALUES (1, 'admin', 'Administrator', 'admin', 1);
INSERT INTO fund_sources (code, name) VALUES
('PEMERINTAH', 'Pemerintah'),
('WALI_MURID', 'Wali Murid'),
('SUMBER_LAIN', 'Sumber lain');
INSERT INTO income_categories (code, name, sort_order) VALUES
('1', 'Uang Pengembangan', 1),
('2', 'Uang SPP', 2),
('3', 'Uang BOP', 3),
('4', 'Uang PMB', 4),
('5', 'Uang Pembelian Produk PP', 5),
('6', 'Uang Infaq', 6);
INSERT INTO expense_categories (code, name, sort_order) VALUES
('1', 'STTPA', 1),
('2', 'STANDAR ISI', 2),
('3', 'STANDAR PROSES', 3),
('4', 'STANDAR PENILAIAN', 4),
('5', 'STANDAR PENGELOLAAN', 5),
('6', 'STANDAR PEMBIAYAAN', 6),
('7', 'STANDAR PENDIDIK DAN TENAGA KEPENDIDIKAN', 7),
('8', 'STANDAR SARANA DAN PRA SARANA', 8);
INSERT INTO budget_headers
(id, academic_year_id, title, status, prepared_date, notes)
VALUES
(1, 1, 'Rencana Kegiatan dan Anggaran Sekolah Tahun Pelajaran 2025/2026',
 'draft', '2025-07-28', 'Data awal diimpor dari workbook RAPBS 2025/2026.');

-- DATA AWAL PENERIMAAN DARI SHEET 'rincian'
INSERT INTO budget_items
(budget_id,item_type,income_category_id,expense_category_id,parent_id,item_code,description,
period_count,quantity,unit_price,amount,fixed_cost,variable_cost,last_year_realization,
usage_description,notes,excel_row,formula_reference,sort_order)
VALUES
(1,'penerimaan',1,NULL,NULL,'1.1','Murid KB',1.0,10.0,300000.0,3000000.0,0,0,0,NULL,'bla bla bla',11,'=D11*E11*F11',11),
(1,'penerimaan',2,NULL,NULL,'2.1','Infaq Wali murid',12.0,10.0,165000.0,19800000.0,0,0,0,NULL,NULL,14,'=D14*E14*F14',14),
(1,'penerimaan',2,NULL,NULL,'2.2','KPO',12.0,10.0,10000.0,1200000.0,0,0,0,NULL,NULL,15,'=D15*E15*F15',15),
(1,'penerimaan',2,NULL,NULL,'2.3','Dana Sosial',12.0,10.0,5000.0,600000.0,0,0,0,NULL,NULL,16,'=D16*E16*F16',16),
(1,'penerimaan',3,NULL,NULL,'3.1','Tahap 2 2024/2025',1.0,10.0,305000.0,3050000.0,0,0,0,NULL,NULL,18,'=D18*E18*F18',18),
(1,'penerimaan',3,NULL,NULL,'3.2','Tahap 1 2025/2026',1.0,10.0,305000.0,3050000.0,0,0,0,NULL,NULL,19,'=D19*E19*F19',19),
(1,'penerimaan',4,NULL,NULL,'4.1','Uang  pendaftaran',1.0,10.0,50000.0,500000.0,0,0,0,NULL,NULL,21,'=D21*E21*F21',21),
(1,'penerimaan',4,NULL,NULL,'4.2','Uang paket',0,0,0,0,0,0,0,NULL,NULL,22,NULL,22),
(1,'penerimaan',4,NULL,NULL,NULL,'Buku panduan ',1.0,10.0,100000.0,1000000.0,0,0,0,NULL,NULL,23,'=D23*E23*F23',23),
(1,'penerimaan',4,NULL,NULL,NULL,'Laporan perkembangan anak dan Atribut',1.0,10.0,65000.0,650000.0,0,0,0,NULL,NULL,24,'=D24*E24*F24',24),
(1,'penerimaan',4,NULL,NULL,'4.3','Uang  seragam',0,0,0,0,0,0,0,NULL,NULL,25,NULL,25),
(1,'penerimaan',4,NULL,NULL,NULL,'Murid KB',1.0,10.0,220000.0,2200000.0,0,0,0,NULL,NULL,26,'=D26*E26*F26',26),
(1,'penerimaan',5,NULL,NULL,'5.2','ACA dan AIK',1.0,10.0,170000.0,1700000.0,0,0,0,NULL,NULL,29,'=D29*E29*F29',29),
(1,'penerimaan',5,NULL,NULL,'5.1','DDTK',1.0,10.0,15000.0,150000.0,0,0,0,NULL,NULL,30,'=D30*E30*F30',30),
(1,'penerimaan',6,NULL,NULL,'5.1','Lazismu',0.0,0,0,0.0,0,0,0,NULL,NULL,32,'=D32*E32*F32',32),
(1,'penerimaan',6,NULL,NULL,'5.2','Hibah',0.0,0,0,0.0,0,0,0,NULL,NULL,33,'=D33*E33*F33',33),
(1,'penerimaan',6,NULL,NULL,'5.3','Hamba Allah ',12.0,2.0,200000.0,4800000.0,0,0,0,NULL,NULL,34,'=D34*E34*F34',34),
(1,'penerimaan',6,NULL,NULL,'5.4','Dana Sosial',12.0,10.0,5000.0,600000.0,0,0,0,NULL,NULL,35,'=D35*E35*F35',35);

-- DATA AWAL PENGELUARAN DARI SHEET 'rincian'
INSERT INTO budget_items
(budget_id,item_type,income_category_id,expense_category_id,parent_id,item_code,description,
period_count,quantity,unit_price,amount,fixed_cost,variable_cost,last_year_realization,
usage_description,notes,excel_row,formula_reference,sort_order)
VALUES
(1,'pengeluaran',NULL,1,NULL,NULL,'Penyusunan dan penggandaan dokumen Alur Tujuan Pembelajaran',1.0,2.0,55000.0,110000.0,0,110000.0,0,'=G41',NULL,41,'=D41*E41*F41',41),
(1,'pengeluaran',NULL,1,NULL,NULL,'Penyusunan dan penggandaan dokumen STTPA',1.0,1.0,25000.0,25000.0,0,25000.0,0,'=G42',NULL,42,'=D42*E42*F42',42),
(1,'pengeluaran',NULL,2,NULL,1,'Pelaksanaan Evadir',1.0,8.0,10000.0,80000.0,0,80000.0,0,'=G45',NULL,45,'=D45*E45*F45',45),
(1,'pengeluaran',NULL,2,NULL,2,'Pengembangan Kurikulum',2.0,8.0,10000.0,160000.0,0,160000.0,0,'=G46',NULL,46,'=D46*E46*F46',46),
(1,'pengeluaran',NULL,2,NULL,3,'Penyusunan Kurikulum ',2.0,8.0,10000.0,160000.0,0,160000.0,0,'=G47',NULL,47,'=D47*E47*F47',47),
(1,'pengeluaran',NULL,2,NULL,4,'Penyusunan Modul Intra Kurikuler',2.0,8.0,10000.0,160000.0,0,160000.0,0,'=G48',NULL,48,'=D48*E48*F48',48),
(1,'pengeluaran',NULL,2,NULL,5,'Penyusunan Modul  P5',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,49,'=D49*E49*F49',49),
(1,'pengeluaran',NULL,2,NULL,6,'Uji Publik Kurikulum',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,50,'=D50*E50*F50',50),
(1,'pengeluaran',NULL,3,NULL,'A','INTRA KURIKULER',0,0,0,0,0,0,0,NULL,NULL,53,NULL,53),
(1,'pengeluaran',NULL,3,NULL,1,'Paket murid',0,0,0,0,0,0,0,NULL,NULL,54,NULL,54),
(1,'pengeluaran',NULL,3,NULL,2,'Buku Panduan',0,0,0,0,0,0,0,NULL,NULL,57,NULL,57),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Panduan AIKA untuk Guru',1.0,3.0,136000.0,408000.0,0,408000.0,0,'=G58',NULL,58,'=D58*E58*F58',58),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Panduan Murid Awal Tahun',1.0,10.0,20000.0,200000.0,0,200000.0,0,NULL,NULL,59,'=D59*E59*F59',59),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Kartu kontrol baca Iqro''',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,60,'=D60*E60*F60',60),
(1,'pengeluaran',NULL,3,NULL,3,'Kegiatan  Literasi Murid',0,0,0,0,0,0,0,NULL,NULL,62,NULL,62),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Kartu kontrol apresiasi (karakter)',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,63,'=D63*E63*F63',63),
(1,'pengeluaran',NULL,3,NULL,4,'Perlengkapan project based learning',2.0,10.0,30000.0,600000.0,0,600000.0,0,NULL,NULL,64,'=D64*E64*F64',64),
(1,'pengeluaran',NULL,3,NULL,'B','KO KURIKULER',0,0,0,0,0,0,0,NULL,NULL,65,NULL,65),
(1,'pengeluaran',NULL,3,NULL,1,'Kegiatan PHBI, PHBN, Hari internasional',0,0,0,0,0,0,0,NULL,NULL,66,NULL,66),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Hari Anak Nasional',1.0,1.0,100000.0,100000.0,0,100000.0,0,NULL,NULL,67,'=D67*E67*F67',67),
(1,'pengeluaran',NULL,3,NULL,NULL,'    HUT RI',1.0,1.0,250000.0,250000.0,0,250000.0,0,'=G67',NULL,68,'=D68*E68*F68',68),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Milad TK ABA',0,0,0,0,0,0,0,'=G68',NULL,69,NULL,69),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Hari Ayah',1.0,1.0,300000.0,300000.0,0,300000.0,0,'=G70',NULL,70,'=D70*E70*F70',70),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Milad Muhammadiyah/Aisyiyah',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,71,'=D71*E71*F71',71),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Hari Ibu',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,72,'=D72*E72*F72',72),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Marhaban ya Ramadhan',1.0,10.0,25000.0,250000.0,0,250000.0,0,NULL,NULL,73,'=D73*E73*F73',73),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Hari Raya Idul Fitri',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,74,'=D74*E74*F74',74),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Milad IGABA',1.0,10.0,10000.0,100000.0,0,100000.0,0,NULL,NULL,75,'=D75*E75*F75',75),
(1,'pengeluaran',NULL,3,NULL,2,'Proyek Penguatan Profil Pelajar Pancasila',0,0,0,0,0,0,0,NULL,NULL,77,NULL,77),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Tahap Permulaan',0,0,0,0,0,0,0,NULL,NULL,78,NULL,78),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Tahap Pengembangan',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,79,'=D79*E79*F79',79),
(1,'pengeluaran',NULL,3,NULL,NULL,'    Tahap Penyimpulan',0,0,0,0,0,0,0,NULL,NULL,80,NULL,80),
(1,'pengeluaran',NULL,3,NULL,'C','EKSTRA KURIKULER',0,0,0,0,0,0,0,NULL,NULL,81,NULL,81),
(1,'pengeluaran',NULL,3,NULL,NULL,'Penyusunan Program Ekskul',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,82,'=D82*E82*F82',82),
(1,'pengeluaran',NULL,3,NULL,NULL,'Evaluasi kegiatan ekstra kurikuler',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,83,'=D83*E83*F83',83),
(1,'pengeluaran',NULL,3,NULL,'D','TUMBUH KEMBANG',0,0,0,0,0,0,0,NULL,NULL,84,NULL,84),
(1,'pengeluaran',NULL,3,NULL,NULL,'Screening kesehatan',2.0,10.0,20000.0,400000.0,0,400000.0,0,NULL,NULL,85,'=D85*E85*F85',85),
(1,'pengeluaran',NULL,3,NULL,NULL,'Screening gigi',1.0,1.0,200000.0,200000.0,0,200000.0,0,'=G86',NULL,86,'=D86*E86*F86',86),
(1,'pengeluaran',NULL,3,NULL,NULL,'Program makanan tambahan BOP ',2.0,20.0,10000.0,400000.0,0,400000.0,0,NULL,NULL,87,'=D87*E87*F87',87),
(1,'pengeluaran',NULL,3,NULL,NULL,'Biscuit Cahaya',2.0,20.0,2000.0,80000.0,0,80000.0,0,NULL,NULL,88,'=D88*E88*F88',88),
(1,'pengeluaran',NULL,4,NULL,1,'Penyusunan format  penilaian harian, mingguan, bulanan dan semester',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,90,NULL,90),
(1,'pengeluaran',NULL,4,NULL,2,'Workshop penggunaan aplikasi raport',1.0,3.0,50000.0,150000.0,0,150000.0,0,'=G91',NULL,91,'=D91*E91*F91',91),
(1,'pengeluaran',NULL,4,NULL,3,'Workshop penggunaan penyimpanan on line untuk dokumentasi penilaian harian',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,92,'=D92*E92*F92',92),
(1,'pengeluaran',NULL,4,NULL,4,'Penggandaan fasilitas pelaporan (portofolio, hasil karya, foto berseri dll)',2.0,10.0,2000.0,40000.0,0,40000.0,0,NULL,NULL,93,'=D93*E93*F93',93),
(1,'pengeluaran',NULL,4,NULL,5,'Laporan Perkembangan Murid, Tengah Semester',2.0,10.0,3000.0,60000.0,0,60000.0,0,NULL,NULL,94,'=D94*E94*F94',94),
(1,'pengeluaran',NULL,4,NULL,6,'Laporan Perkembangan Murid, Akhir Semester ',2.0,10.0,15000.0,300000.0,0,300000.0,0,NULL,NULL,95,'=D95*E95*F95',95),
(1,'pengeluaran',NULL,4,NULL,7,'Pembelian kertas E Raport',1.0,2.0,160000.0,320000.0,0,320000.0,0,'=G96',NULL,96,'=D96*E96*F96',96),
(1,'pengeluaran',NULL,4,NULL,8,'kuota untuk documentasi',12.0,1.0,10000.0,120000.0,0,120000.0,0,'=G97',NULL,97,'=D97*E97*F97',97),
(1,'pengeluaran',NULL,5,NULL,1,'Rapat Kerja Guru',2.0,1.0,400000.0,800000.0,0,800000.0,0,'=G100',NULL,100,'=D100*E100*F100',100),
(1,'pengeluaran',NULL,5,NULL,2,'Rapat Koordinasi Guru',6.0,3.0,15000.0,270000.0,0,270000.0,0,'=G101',NULL,101,'=D101*E101*F101',101),
(1,'pengeluaran',NULL,5,NULL,3,'Rapat Kepala Sekolah',12.0,1.0,25000.0,300000.0,0,300000.0,0,'=G102',NULL,102,'=D102*E102*F102',102),
(1,'pengeluaran',NULL,5,NULL,4,'Penyelenggaraan parenting',6.0,10.0,10000.0,600000.0,0,600000.0,0,NULL,NULL,103,'=D103*E103*F103',103),
(1,'pengeluaran',NULL,5,NULL,5,'penggandaan materi parenting',6.0,10.0,1000.0,60000.0,0,60000.0,0,NULL,NULL,104,'=D104*E104*F104',104),
(1,'pengeluaran',NULL,5,NULL,6,'Penerimaan Murid Baru, Flyer MMT dll',1.0,2.0,200000.0,400000.0,0,400000.0,0,'=G105',NULL,105,'=D105*E105*F105',105),
(1,'pengeluaran',NULL,5,NULL,7,'Akhirussanah/Karyawisata',1.0,1.0,0.0,0.0,0,0.0,0,NULL,NULL,106,'=D106*E106*F106',106),
(1,'pengeluaran',NULL,5,NULL,8,'Tuan Rumah Pertemuan gugus',1.0,1.0,300000.0,300000.0,0,300000.0,0,'=G107',NULL,107,'=D107*E107*F107',107),
(1,'pengeluaran',NULL,5,NULL,9,'Tuan Rumah pertemuan IGABA, Himpaudi',1.0,1.0,300000.0,300000.0,0,300000.0,0,'=G108',NULL,108,'=D108*E108*F108',108),
(1,'pengeluaran',NULL,5,NULL,10,'Dansos',12.0,10.0,5000.0,600000.0,0,600000.0,0,NULL,NULL,109,'=D109*E109*F109',109),
(1,'pengeluaran',NULL,6,NULL,1,'Gaji Pokok Guru',0,0,0,0,0,0,0,NULL,NULL,112,NULL,112),
(1,'pengeluaran',NULL,6,NULL,NULL,'TMT 0 - 1 Tahun',12.0,1.0,200000.0,2400000.0,0,2400000.0,0,'=G113',NULL,113,'=D113*E113*F113',113),
(1,'pengeluaran',NULL,6,NULL,NULL,'TMT 2 - 6 Tahun',12.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,114,'=D114*E114*F114',114),
(1,'pengeluaran',NULL,6,NULL,NULL,'TMT 5 - 7 Tahun',12.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,115,'=D115*E115*F115',115),
(1,'pengeluaran',NULL,6,NULL,NULL,'TMT 7 - keatas ',12.0,2.0,925000.0,22200000.0,0,22200000.0,0,'=G116',NULL,116,'=D116*E116*F116',116),
(1,'pengeluaran',NULL,6,NULL,2,'Tunjangan',0,0,0,0,0,0,0,NULL,NULL,118,NULL,118),
(1,'pengeluaran',NULL,6,NULL,NULL,'    Kepala Sekolah',12.0,1.0,300000.0,3600000.0,0,3600000.0,0,'=G119',NULL,119,'=D119*E119*F119',119),
(1,'pengeluaran',NULL,6,NULL,NULL,'    Bendahara',12.0,1.0,0.0,0.0,0,0.0,0,NULL,NULL,120,'=D120*E120*F120',120),
(1,'pengeluaran',NULL,6,NULL,NULL,'    Hari Raya ( Gaji Pokok )',1.0,1.0,1125000.0,1125000.0,0,1125000.0,0,'=G121',NULL,121,'=D121*E121*F121',121),
(1,'pengeluaran',NULL,6,NULL,NULL,'    BPJS Ketenagakerjaan',12.0,1.0,10000.0,120000.0,0,120000.0,0,'=G122',NULL,122,'=D122*E122*F122',122),
(1,'pengeluaran',NULL,6,NULL,3,'    Operator sekolah',12.0,1.0,100000.0,1200000.0,0,1200000.0,0,'=G123',NULL,123,'=D123*E123*F123',123),
(1,'pengeluaran',NULL,6,NULL,4,'    Fungsional',12.0,2.0,50000.0,1200000.0,0,1200000.0,0,'=G124',NULL,124,'=D124*E124*F124',124),
(1,'pengeluaran',NULL,6,NULL,5,'    Wali kelas',12.0,1.0,50000.0,600000.0,0,600000.0,0,'=G125',NULL,125,'=D125*E125*F125',125),
(1,'pengeluaran',NULL,6,NULL,6,'    Pengasuh',12.0,1.0,300000.0,3600000.0,0,3600000.0,0,'=G126',NULL,126,'=D126*E126*F126',126),
(1,'pengeluaran',NULL,6,NULL,7,'Honor guru ngaji',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,127,'=D127*E127*F127',127),
(1,'pengeluaran',NULL,6,NULL,8,'Honor petugas kebersihan',12.0,1.0,200000.0,2400000.0,0,2400000.0,0,'=G128',NULL,128,'=D128*E128*F128',128),
(1,'pengeluaran',NULL,6,NULL,9,'Pengurusan sampah',12.0,1.0,50000.0,600000.0,0,600000.0,0,'=G129',NULL,129,'=D129*E129*F129',129),
(1,'pengeluaran',NULL,6,NULL,10,'Pengurusan Pajak',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,130,'=D130*E130*F130',130),
(1,'pengeluaran',NULL,6,NULL,11,'Pengurusan Bank',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,131,'=D131*E131*F131',131),
(1,'pengeluaran',NULL,6,NULL,12,'Seragam guru',1.0,3.0,100000.0,300000.0,0,300000.0,0,'=G132',NULL,132,'=D132*E132*F132',132),
(1,'pengeluaran',NULL,6,NULL,13,'Air minum',12.0,3.0,20000.0,720000.0,0,720000.0,0,'=G133',NULL,133,'=D133*E133*F133',133),
(1,'pengeluaran',NULL,6,NULL,14,'Listrik',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,134,NULL,134),
(1,'pengeluaran',NULL,6,NULL,15,'Internet/Pulsa',12.0,1.0,100000.0,1200000.0,0,1200000.0,0,'=G135',NULL,135,'=D135*E135*F135',135),
(1,'pengeluaran',NULL,6,NULL,16,'Iuran',0,0,0,0,0,0,0,NULL,NULL,136,'=D136*E136*F136',136),
(1,'pengeluaran',NULL,6,NULL,NULL,'Himpaudi',12.0,2.0,20000.0,480000.0,0,480000.0,0,'=G137',NULL,137,'=D137*E137*F137',137),
(1,'pengeluaran',NULL,6,NULL,NULL,'IGABA',12.0,2.0,30000.0,720000.0,0,720000.0,0,'=G138',NULL,138,'=D138*E138*F138',138),
(1,'pengeluaran',NULL,6,NULL,NULL,'PKG',6.0,1.0,20000.0,120000.0,0,120000.0,0,'=G139',NULL,139,'=D139*E139*F139',139),
(1,'pengeluaran',NULL,6,NULL,NULL,'KKG',10.0,1.0,20000.0,200000.0,0,200000.0,0,'=G140',NULL,140,'=D140*E140*F140',140),
(1,'pengeluaran',NULL,6,NULL,17,'Organisasi ',0,0,0,0,0,0,0,NULL,NULL,142,NULL,142),
(1,'pengeluaran',NULL,6,NULL,NULL,'    Dana Wajib Murid ke PDA',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,143,'=D143*E143*F143',143),
(1,'pengeluaran',NULL,6,NULL,NULL,'    Dana Wajib Murid Baru  ke PDA',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,144,'=D144*E144*F144',144),
(1,'pengeluaran',NULL,6,NULL,NULL,'    Muktamar',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,145,'=D145*E145*F145',145),
(1,'pengeluaran',NULL,6,NULL,NULL,'    Taawun',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,146,'=D146*E146*F146',146),
(1,'pengeluaran',NULL,6,NULL,NULL,'PMI',1.0,2.0,2000.0,4000.0,0,4000.0,0,'=G147',NULL,147,'=D147*E147*F147',147),
(1,'pengeluaran',NULL,6,NULL,NULL,'Sosial Murid',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,148,'=D148*E148*F148',148),
(1,'pengeluaran',NULL,6,NULL,NULL,'Sosial Guru',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,149,'=D149*E149*F149',149),
(1,'pengeluaran',NULL,6,NULL,19,'Investasi ',0,0,0,0,0,0,0,NULL,NULL,151,NULL,151),
(1,'pengeluaran',NULL,6,NULL,NULL,'    Angsuran Lembaga Keuangan',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,152,'=D152*E152*F152',152),
(1,'pengeluaran',NULL,6,NULL,NULL,'    Pengembangan Khusus Lembaga oleh Penyelenggara (PRA)',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,153,'=D153*E153*F153',153),
(1,'pengeluaran',NULL,6,NULL,NULL,'    Pengembangan Umum Lembaga oleh Penyelenggara (PRA)',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,154,NULL,154),
(1,'pengeluaran',NULL,7,NULL,1,'Penguatan Ideologis',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,157,'=D157*E157*F157',157),
(1,'pengeluaran',NULL,7,NULL,2,'Workshop  Literasi Anak Usia Dini',1.0,1.0,100000.0,100000.0,0,100000.0,0,'=G158',NULL,158,'=D158*E158*F158',158),
(1,'pengeluaran',NULL,7,NULL,3,'Workshop  Impementasi Pembelajaran mendalam',1.0,1.0,100000.0,100000.0,0,100000.0,0,'=G159',NULL,159,'=D159*E159*F159',159),
(1,'pengeluaran',NULL,7,NULL,4,'IHT Kurikulum Aisyiyah',1.0,2.0,110000.0,220000.0,0,220000.0,0,'=G160',NULL,160,'=D160*E160*F160',160),
(1,'pengeluaran',NULL,7,NULL,5,'IHT Pengembangan Modul ajar dan RPM',1.0,2.0,50000.0,100000.0,0,100000.0,0,'=G161',NULL,161,'=D161*E161*F161',161),
(1,'pengeluaran',NULL,7,NULL,7,'Pelatihan  Excellent Service',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,163,'=D163*E163*F163',163),
(1,'pengeluaran',NULL,7,NULL,8,'Program Tahfidz Guru',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,164,'=D164*E164*F164',164),
(1,'pengeluaran',NULL,7,NULL,9,'Pembinaan PCA',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,165,'=D165*E165*F165',165),
(1,'pengeluaran',NULL,7,NULL,10,'Studi Banding/Piknik',1.0,2.0,0.0,0.0,0,0.0,0,NULL,NULL,166,'=D166*E166*F166',166),
(1,'pengeluaran',NULL,7,NULL,11,'Evaluasi Qirao''ati dari korcab',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,167,'=D167*E167*F167',167),
(1,'pengeluaran',NULL,8,NULL,1,'Paket Seragam',0,0,0,0,0,0,0,NULL,NULL,170,NULL,170),
(1,'pengeluaran',NULL,8,NULL,NULL,'    Murid laki-laki',1.0,5.0,225000.0,1125000.0,0,1125000.0,0,NULL,NULL,171,'=D171*E171*F171',171),
(1,'pengeluaran',NULL,8,NULL,NULL,'    Perempuan',1.0,5.0,225000.0,1125000.0,0,1125000.0,0,NULL,NULL,172,'=D172*E172*F172',172),
(1,'pengeluaran',NULL,8,NULL,2,'Perlengkapan Aransi Kelas',1.0,6.0,100000.0,600000.0,0,600000.0,0,'=G173',NULL,173,'=D173*E173*F173',173),
(1,'pengeluaran',NULL,8,NULL,3,'ATK Guru',12.0,3.0,10000.0,360000.0,0,360000.0,0,'=G174',NULL,174,'=D174*E174*F174',174),
(1,'pengeluaran',NULL,8,NULL,4,'P3K',1.0,6.0,10000.0,60000.0,0,60000.0,0,'=G175',NULL,175,'=D175*E175*F175',175),
(1,'pengeluaran',NULL,8,NULL,5,'Baterai Mic, jam dll',6.0,1.0,15000.0,90000.0,0,90000.0,0,'=G176',NULL,176,'=D176*E176*F176',176),
(1,'pengeluaran',NULL,8,NULL,6,'Laptop',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,177,'=D177*E177*F177',177),
(1,'pengeluaran',NULL,8,NULL,7,'Meja Plastik',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,178,'=D178*E178*F178',178),
(1,'pengeluaran',NULL,8,NULL,8,'Buku Referensi Kurikulum Aisyiyah',1.0,3.0,55000.0,165000.0,0,165000.0,0,'=G179',NULL,179,'=D179*E179*F179',179),
(1,'pengeluaran',NULL,8,NULL,9,'Produk Literasi Topik AIKA',0,0,0,0,0,0,0,NULL,NULL,180,NULL,180),
(1,'pengeluaran',NULL,8,NULL,NULL,'    Pencetakan buku ACA',1.0,10.0,120000.0,1200000.0,0,1200000.0,0,NULL,NULL,181,'=D181*E181*F181',181),
(1,'pengeluaran',NULL,8,NULL,NULL,'    Pencetakan buku karya murid',1.0,10.0,25000.0,250000.0,0,250000.0,0,NULL,NULL,182,'=D182*E182*F182',182),
(1,'pengeluaran',NULL,8,NULL,NULL,'    Pencetakan Buku 7 kebiasaan anak indonesia hebat',1.0,10.0,13500.0,135000.0,0,135000.0,0,NULL,NULL,183,'=D183*E183*F183',183),
(1,'pengeluaran',NULL,8,NULL,NULL,'    Buku DDTK',1.0,10.0,15000.0,150000.0,0,150000.0,0,NULL,NULL,184,'=D184*E184*F184',184),
(1,'pengeluaran',NULL,8,NULL,NULL,'    Panduan KeAisy/KeMuh Tarjih',1.0,10.0,150000.0,1500000.0,0,1500000.0,0,NULL,NULL,185,'=D185*E185*F185',185),
(1,'pengeluaran',NULL,8,NULL,NULL,'    Pencetakan ',0.0,0.0,0.0,0.0,0,0.0,0,NULL,NULL,186,'=D186*E186*F186',186),
(1,'pengeluaran',NULL,8,NULL,10,'Pemasangan Kanopi baja ringan',1.0,1.0,2000000.0,2000000.0,0,2000000.0,0,'=G187',NULL,187,'=D187*E187*F187',187);

-- PEMETAAN ANALISA UTAMA DARI SHEET 'Analisa'.
-- Query aplikasi dapat menampilkan relasi ini berdasarkan description.
INSERT INTO analysis_allocations
(budget_id, income_item_id, expense_item_id, allocation_amount, per_student_amount, plus_minus_per_student, notes)
SELECT
    1,
    inc.id,
    exp.id,
    exp.amount,
    CASE WHEN exp.quantity > 0 THEN exp.amount / exp.quantity ELSE 0 END,
    0,
    'Pemetaan awal dari catatan Analisa; dapat disempurnakan melalui menu Analisa.'
FROM budget_items inc
JOIN budget_items exp
WHERE inc.item_type='penerimaan'
  AND exp.item_type='pengeluaran'
  AND inc.description='Uang  pendaftaran'
  AND exp.description='Panduan Murid Awal Tahun'
LIMIT 1;

-- Indeks tambahan untuk pencarian laporan.
CREATE INDEX idx_budget_items_description ON budget_items(description);
CREATE INDEX idx_budget_items_excel_row ON budget_items(excel_row);

-- Catatan instalasi:
-- 1. Import file ini ke MySQL/MariaDB.
-- 2. Atur database CI3 ke database 'rapbs_ci3'.
-- 3. Password admin belum diisi; buat melalui halaman setup/ubah password.
-- 4. Rumus Excel TIDAK disimpan sebagai formula yang dieksekusi.
--    amount sudah dihitung dari periode x jumlah x tarif untuk data yang jelas.
