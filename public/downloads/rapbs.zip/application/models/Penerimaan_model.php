<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penerimaan_model extends CI_Model
{
    private $table = 'budget_items';

    public function get_all()
    {
        return $this->db
            ->select('
                bi.*,
                ic.name AS income_category_name
            ')
            ->from('budget_items bi')
            ->join(
                'income_categories ic',
                'ic.id = bi.income_category_id',
                'left'
            )
            ->where('bi.item_type', 'penerimaan')
            ->order_by('bi.id', 'DESC')
            ->get()
            ->result();
    }

    public function get_by_id($id)
    {
        return $this->db
            ->select('
                bi.*,
                ic.name AS income_category_name
            ')
            ->from('budget_items bi')
            ->join(
                'income_categories ic',
                'ic.id = bi.income_category_id',
                'left'
            )
            ->where('bi.id', (int) $id)
            ->where('bi.item_type', 'penerimaan')
            ->get()
            ->row();
    }

    public function get_total()
    {
        $row = $this->db
            ->select_sum('amount', 'total')
            ->where('item_type', 'penerimaan')
            ->get($this->table)
            ->row();

        return (float) ($row->total ?: 0);
    }

    public function get_categories()
    {
        return $this->db
            ->order_by('name', 'ASC')
            ->get('income_categories')
            ->result();
    }

    public function get_empty()
    {
        return (object) array(
            'id'                => '',
            'income_category_id' => '',
            'description'       => '',
            'period_count'      => 1,
            'quantity'          => 1,
            'unit_price'        => 0,
            'amount'            => 0,
            'notes'             => ''
        );
    }

public function prepare_item($post)
{
    $period = (float) ($post['period_count'] ?? 0);
    $quantity = (float) ($post['quantity'] ?? 0);
    $unit_price = (float) ($post['unit_price'] ?? 0);

    /*
     * Ambil budget_id dari RAPBS yang sudah ada.
     * Data penerimaan lama sudah memiliki budget_id,
     * sehingga data baru harus masuk ke header yang sama.
     */
    $budget = $this->db
        ->select('budget_id')
        ->from($this->table)
        ->where('item_type', 'penerimaan')
        ->where('budget_id IS NOT NULL', NULL, FALSE)
        ->limit(1)
        ->get()
        ->row();

    if (!$budget) {
        return FALSE;
    }

    $amount = $period * $quantity * $unit_price;

    return array(
        'budget_id'          => (int) $budget->budget_id,
        'item_type'          => 'penerimaan',
        'income_category_id' => (int) ($post['income_category_id'] ?? 0),
        'description'        => trim($post['description'] ?? ''),
        'period_count'       => $period,
        'quantity'           => $quantity,
        'unit_price'         => $unit_price,
        'amount'             => $amount,
        'notes'              => trim($post['notes'] ?? '')
    );
}    

    public function validate_data($data)
    {
        if ((int) $data['income_category_id'] <= 0) {
            return FALSE;
        }

        if ($data['description'] === '') {
            return FALSE;
        }

        if ((float) $data['period_count'] <= 0) {
            return FALSE;
        }

        if ((float) $data['quantity'] <= 0) {
            return FALSE;
        }

        if ((float) $data['unit_price'] < 0) {
            return FALSE;
        }

        return TRUE;
    }

    public function insert($data)
    {
        return $this->db->insert(
            $this->table,
            $data
        );
    }

    public function update($id, $data)
    {
        return $this->db
            ->where('id', (int) $id)
            ->where('item_type', 'penerimaan')
            ->update(
                $this->table,
                $data
            );
    }

    public function delete($id)
    {
        return $this->db
            ->where('id', (int) $id)
            ->where('item_type', 'penerimaan')
            ->delete($this->table);
    }
}