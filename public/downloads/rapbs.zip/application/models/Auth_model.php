<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model
{
    public function find_by_username($username)
    {
        return $this->db
            ->where('username', $username)
            ->where('active', 1)
            ->get('users')
            ->row();
    }

    public function set_password($user_id, $password)
    {
        return $this->db
            ->where('id', $user_id)
            ->update('users', array(
                'password_hash' => password_hash($password, PASSWORD_DEFAULT)
            ));
    }

    public function touch_login($user_id)
    {
        return $this->db
            ->where('id', $user_id)
            ->update('users', array('last_login' => date('Y-m-d H:i:s')));
    }
}
