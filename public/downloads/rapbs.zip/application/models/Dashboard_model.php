<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model
{
    public function get_active_year()
    {
        return $this->db
            ->select('ay.*, s.name AS school_name')
            ->from('academic_years ay')
            ->join('schools s', 's.id = ay.school_id', 'left')
            ->where('ay.status', 'aktif')
            ->order_by('ay.id', 'DESC')
            ->limit(1)
            ->get()
            ->row();
    }

    public function get_budget_summary($academic_year_id)
    {
        return $this->db
            ->select('
                bh.id AS budget_id,
                bh.title,
                bh.status,
                COALESCE(SUM(CASE WHEN bi.item_type = "penerimaan" THEN bi.amount ELSE 0 END), 0) AS total_penerimaan,
                COALESCE(SUM(CASE WHEN bi.item_type = "pengeluaran" THEN bi.amount ELSE 0 END), 0) AS total_pengeluaran,
                COALESCE(SUM(CASE WHEN bi.item_type = "penerimaan" THEN bi.amount ELSE -bi.amount END), 0) AS saldo
            ', FALSE)
            ->from('budget_headers bh')
            ->join('budget_items bi', 'bi.budget_id = bh.id', 'left')
            ->where('bh.academic_year_id', $academic_year_id)
            ->group_by(array('bh.id', 'bh.title', 'bh.status'))
            ->get()
            ->row();
    }

    public function count_students($academic_year_id)
    {
        return (int) $this->db
            ->where('academic_year_id', $academic_year_id)
            ->where('active', 1)
            ->count_all_results('students');
    }

    public function count_employees()
    {
        return (int) $this->db
            ->where('active', 1)
            ->count_all_results('employees');
    }

    public function get_income_by_category($budget_id)
    {
        return $this->db
            ->select('ic.name, COALESCE(SUM(bi.amount),0) AS total', FALSE)
            ->from('budget_items bi')
            ->join('income_categories ic', 'ic.id = bi.income_category_id')
            ->where('bi.budget_id', $budget_id)
            ->where('bi.item_type', 'penerimaan')
            ->group_by(array('ic.id', 'ic.name', 'ic.sort_order'))
            ->order_by('ic.sort_order', 'ASC')
            ->get()
            ->result();
    }

    public function get_expense_by_category($budget_id)
    {
        return $this->db
            ->select('ec.name, COALESCE(SUM(bi.amount),0) AS total', FALSE)
            ->from('budget_items bi')
            ->join('expense_categories ec', 'ec.id = bi.expense_category_id')
            ->where('bi.budget_id', $budget_id)
            ->where('bi.item_type', 'pengeluaran')
            ->group_by(array('ec.id', 'ec.name', 'ec.sort_order'))
            ->order_by('ec.sort_order', 'ASC')
            ->get()
            ->result();
    }
}
