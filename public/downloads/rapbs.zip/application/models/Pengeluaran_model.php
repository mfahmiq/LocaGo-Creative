<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengeluaran_model extends CI_Model
{
    private $table = 'budget_items';

    public function get_all()
    {
        return $this->db
            ->select('
                bi.*,
                ec.name AS expense_category_name
            ')
            ->from('budget_items bi')
            ->join(
                'expense_categories ec',
                'ec.id = bi.expense_category_id',
                'left'
            )
            ->where('bi.item_type', 'pengeluaran')
            ->order_by('bi.id', 'DESC')
            ->get()
            ->result();
    }

    public function get_by_id($id)
    {
        return $this->db
            ->select('
                bi.*,
                ec.name AS expense_category_name
            ')
            ->from('budget_items bi')
            ->join(
                'expense_categories ec',
                'ec.id = bi.expense_category_id',
                'left'
            )
            ->where('bi.id', (int) $id)
            ->where('bi.item_type', 'pengeluaran')
            ->get()
            ->row();
    }

    public function get_total()
    {
        $row = $this->db
            ->select_sum('amount', 'total')
            ->where('item_type', 'pengeluaran')
            ->get($this->table)
            ->row();

        return (float) ($row->total ?: 0);
    }

    public function get_categories()
    {
        return $this->db
            ->order_by('name', 'ASC')
            ->get('expense_categories')
            ->result();
    }

    public function get_empty()
    {
        return (object) array(
            'id'                 => '',
            'expense_category_id' => '',
            'description'        => '',
            'period_count'       => 1,
            'quantity'           => 1,
            'unit_price'         => 0,
            'amount'             => 0,
            'notes'              => ''
        );
    }

    public function prepare_item($post)
    {
        $period = (float) ($post['period_count'] ?? 0);
        $quantity = (float) ($post['quantity'] ?? 0);
        $unit_price = (float) ($post['unit_price'] ?? 0);

        $amount = $period * $quantity * $unit_price;

        return array(
            'budget_id'           => 1,
            'item_type'           => 'pengeluaran',
            'expense_category_id' => (int) ($post['expense_category_id'] ?? 0),
            'description'         => trim($post['description'] ?? ''),
            'period_count'        => $period,
            'quantity'            => $quantity,
            'unit_price'          => $unit_price,
            'amount'              => $amount,
            'notes'               => trim($post['notes'] ?? '')
        );
    }

    public function validate_data($data)
    {
        if ((int) $data['expense_category_id'] <= 0) {
            return FALSE;
        }

        if ($data['description'] === '') {
            return FALSE;
        }

        if ((float) $data['period_count'] <= 0) {
            return FALSE;
        }

        if ((float) $data['quantity'] <= 0) {
            return FALSE;
        }

        if ((float) $data['unit_price'] < 0) {
            return FALSE;
        }

        return TRUE;
    }

    public function insert($data)
    {
        return $this->db->insert(
            $this->table,
            $data
        );
    }

    public function update($id, $data)
    {
        return $this->db
            ->where('id', (int) $id)
            ->where('item_type', 'pengeluaran')
            ->update(
                $this->table,
                $data
            );
    }

    public function delete($id)
    {
        return $this->db
            ->where('id', (int) $id)
            ->where('item_type', 'pengeluaran')
            ->delete($this->table);
    }
}