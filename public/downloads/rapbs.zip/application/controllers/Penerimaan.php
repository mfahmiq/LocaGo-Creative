<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penerimaan extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->require_login();

        $this->load->model('Penerimaan_model');
    }

    /**
     * Daftar penerimaan
     */
    public function index()
    {
        $data = array(
            'title' => 'Penerimaan',
            'items' => $this->Penerimaan_model->get_all(),
            'total' => $this->Penerimaan_model->get_total()
        );

        $this->load->view('penerimaan/index', $data);
    }

    /**
     * Form tambah
     */
    public function create()
    {
        $data = array(
            'title'      => 'Tambah Penerimaan',
            'item'       => $this->Penerimaan_model->get_empty(),
            'categories' => $this->Penerimaan_model->get_categories()
        );

        $this->load->view('penerimaan/form', $data);
    }

    /**
     * Simpan data
     */
    public function store()
    {
        $post = $this->input->post(NULL, TRUE);

        $data = $this->Penerimaan_model->prepare_item($post);

        if (!$this->Penerimaan_model->validate_data($data)) {

            $this->session->set_flashdata(
                'error',
                'Data penerimaan belum lengkap.'
            );

            redirect('penerimaan/create');
            return;
        }

        if (!$this->Penerimaan_model->insert($data)) {

            $this->session->set_flashdata(
                'error',
                'Data penerimaan gagal disimpan.'
            );

            redirect('penerimaan/create');
            return;
        }

        $this->session->set_flashdata(
            'success',
            'Data penerimaan berhasil ditambahkan.'
        );

        redirect('penerimaan');
    }

    /**
     * Form edit
     */
    public function edit($id)
    {
        $item = $this->Penerimaan_model->get_by_id((int) $id);

        if (!$item) {
            show_404();
        }

        $data = array(
            'title'      => 'Edit Penerimaan',
            'item'       => $item,
            'categories' => $this->Penerimaan_model->get_categories()
        );

        $this->load->view('penerimaan/form', $data);
    }

    /**
     * Update
     */
    public function update($id)
    {
        $item = $this->Penerimaan_model->get_by_id((int) $id);

        if (!$item) {
            show_404();
        }

        $post = $this->input->post(NULL, TRUE);

        $data = $this->Penerimaan_model->prepare_item($post);

        if (!$this->Penerimaan_model->validate_data($data)) {

            $this->session->set_flashdata(
                'error',
                'Data penerimaan belum lengkap.'
            );

            redirect('penerimaan/edit/' . (int) $id);
            return;
        }

        if (!$this->Penerimaan_model->update((int) $id, $data)) {

            $this->session->set_flashdata(
                'error',
                'Data penerimaan gagal diperbarui.'
            );

            redirect('penerimaan/edit/' . (int) $id);
            return;
        }

        $this->session->set_flashdata(
            'success',
            'Data penerimaan berhasil diperbarui.'
        );

        redirect('penerimaan');
    }

    /**
     * Detail
     */
    public function detail($id)
    {
        $item = $this->Penerimaan_model->get_by_id((int) $id);

        if (!$item) {
            show_404();
        }

        $data = array(
            'title' => 'Detail Penerimaan',
            'item'  => $item
        );

        $this->load->view('penerimaan/detail', $data);
    }

    /**
     * Hapus
     */
    public function delete($id)
    {
        $item = $this->Penerimaan_model->get_by_id((int) $id);

        if (!$item) {
            show_404();
        }

        if (!$this->Penerimaan_model->delete((int) $id)) {

            $this->session->set_flashdata(
                'error',
                'Data penerimaan gagal dihapus.'
            );

            redirect('penerimaan');
            return;
        }

        $this->session->set_flashdata(
            'success',
            'Data penerimaan berhasil dihapus.'
        );

        redirect('penerimaan');
    }
}