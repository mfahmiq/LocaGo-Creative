<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Setup extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Auth_model');
    }

    public function index()
    {
        $admin = $this->Auth_model->find_by_username('admin');

        if (!$admin) {
            show_error('User admin tidak ditemukan di database.');
        }

        if (!empty($admin->password_hash)) {
            redirect('login');
        }

        $error = NULL;

        if ($this->input->method(TRUE) === 'POST') {
            $password = (string) $this->input->post('password');
            $confirm  = (string) $this->input->post('password_confirm');

            if (strlen($password) < 8) {
                $error = 'Password minimal 8 karakter.';
            } elseif ($password !== $confirm) {
                $error = 'Konfirmasi password tidak sama.';
            } else {
                $this->Auth_model->set_password($admin->id, $password);
                $this->session->set_flashdata('success', 'Password admin berhasil dibuat. Silakan login.');
                redirect('login');
            }
        }

        $this->load->view('auth/setup', array(
            'title' => 'Setup Password Admin',
            'error' => $error
        ));
    }
}
