<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Dashboard extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('Dashboard_model');
    }


    public function index()
    {
        /*
         * ==========================================
         * AMBIL RAPBS AKTIF DARI SESSION
         * ==========================================
         */

        $academic_year_id = $this->get_academic_year_id();
        $budget_id        = $this->get_budget_id();


        /*
         * ==========================================
         * DATA TAHUN PELAJARAN
         * ==========================================
         */

        $year = NULL;

        if ($academic_year_id) {

            $year = $this->db
                ->where('id', $academic_year_id)
                ->get('academic_years')
                ->row();
        }


        /*
         * ==========================================
         * DEFAULT DATA
         * ==========================================
         */

        $summary = NULL;

        $income = array();

        $expense = array();

        $student_count = 0;


        /*
         * ==========================================
         * DATA RAPBS
         * ==========================================
         */

        if ($budget_id) {

            /*
             * Ambil header RAPBS
             */
            $summary = $this->db
                ->select('
                    bh.id AS budget_id,
                    bh.title,
                    bh.status,
                    bh.prepared_date,
                    bh.approved_date,
                    s.name AS school_name
                ')
                ->select("
                    COALESCE(
                        (
                            SELECT SUM(bi.amount)
                            FROM budget_items bi
                            WHERE bi.budget_id = bh.id
                            AND bi.item_type = 'penerimaan'
                        ),
                        0
                    ) AS total_penerimaan
                ", FALSE)
                ->select("
                    COALESCE(
                        (
                            SELECT SUM(bi.amount)
                            FROM budget_items bi
                            WHERE bi.budget_id = bh.id
                            AND bi.item_type = 'pengeluaran'
                        ),
                        0
                    ) AS total_pengeluaran
                ", FALSE)
                ->from('budget_headers bh')
                ->join(
                    'academic_years ay',
                    'ay.id = bh.academic_year_id',
                    'inner'
                )
                ->join(
                    'schools s',
                    's.id = ay.school_id',
                    'inner'
                )
                ->where(
                    'bh.id',
                    $budget_id
                )
                ->get()
                ->row();            

            if ($summary) {

                $summary->total_penerimaan =
                    (float) $summary->total_penerimaan;

                $summary->total_pengeluaran =
                    (float) $summary->total_pengeluaran;

                $summary->saldo =
                    $summary->total_penerimaan -
                    $summary->total_pengeluaran;
            }                


            /*
             * Data penerimaan per kategori
             */
            $income =
                $this->Dashboard_model
                    ->get_income_by_category(
                        $budget_id
                    );


            /*
             * Data pengeluaran per kategori
             */
            $expense =
                $this->Dashboard_model
                    ->get_expense_by_category(
                        $budget_id
                    );
        }


        /*
         * ==========================================
         * JUMLAH MURID
         * ==========================================
         *
         * Tetap menggunakan model lama.
         */

        if ($academic_year_id) {

            $student_count =
                $this->Dashboard_model
                    ->count_students(
                        $academic_year_id
                    );
        }


        /*
         * ==========================================
         * DATA KE VIEW
         * ==========================================
         */

        $data = array(

            'title' =>
                'Dashboard - ' .
                RAPBS_APP_NAME,


            'year' =>
                $year,


            'summary' =>
                $summary,


            'income' =>
                $income,


            'expense' =>
                $expense,


            'student_count' =>
                $student_count,


            'employee_count' =>
                $this->Dashboard_model
                    ->count_employees(),


            'user' =>
                $this->current_user()
        );


        /*
         * ==========================================
         * LOAD VIEW LAMA
         * ==========================================
         */

        $this->load->view(
            'dashboard/index',
            $data
        );
    }
}