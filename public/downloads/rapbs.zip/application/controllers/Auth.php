<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('Auth_model');
        $this->load->library('session');
    }


    public function index()
    {
        if ($this->session->userdata('logged_in') === TRUE) {
            redirect('dashboard');
            return;
        }

        $data = array(
            'title'   => 'Login - ' . RAPBS_APP_NAME,
            'error'   => $this->session->flashdata('error'),
            'success' => $this->session->flashdata('success')
        );

        $this->load->view('auth/login', $data);
    }


public function login()
{
    if ($this->input->method(TRUE) !== 'POST') {
        redirect('login');
        return;
    }

    $username = trim(
        $this->input->post('username', TRUE)
    );

    $password = (string) $this->input->post('password');


    // Cari user
    $user = $this->Auth_model
        ->find_by_username($username);


    if (!$user) {
        $this->session->set_flashdata(
            'error',
            'Username admin tidak ditemukan.'
        );

        redirect('login');
        return;
    }


    if ((int) $user->active !== 1) {
        $this->session->set_flashdata(
            'error',
            'User admin tidak aktif.'
        );

        redirect('login');
        return;
    }


    if (empty($user->password_hash)) {
        $this->session->set_flashdata(
            'error',
            'Password hash kosong.'
        );

        redirect('login');
        return;
    }


    // Verifikasi password
    if (!password_verify(
        $password,
        $user->password_hash
    )) {
        $this->session->set_flashdata(
            'error',
            'Password salah.'
        );

        redirect('login');
        return;
    }


    // Password benar
    $this->session->sess_regenerate(FALSE);


    /*
     * Pastikan user sudah mempunyai sekolah.
     */
    if (empty($user->school_id)) {

        $this->session->set_flashdata(
            'error',
            'User belum terhubung dengan sekolah.'
        );

        redirect('login');
        return;
    }


    /*
     * Cari sekolah
     */
    $school = $this->db
        ->where('id', $user->school_id)
        
        ->get('schools')
        ->row();


    if (!$school) {

        $this->session->set_flashdata(
            'error',
            'Sekolah user tidak ditemukan atau tidak aktif.'
        );

        redirect('login');
        return;
    }


    /*
     * Cari RAPBS aktif sekolah
     */
    $budget = $this->db
        ->select('
            bh.id AS budget_id,
            bh.title AS budget_title,
            bh.status AS budget_status,
            ay.id AS academic_year_id,
            ay.name AS academic_year
        ')
        ->from('budget_headers bh')
        ->join(
            'academic_years ay',
            'ay.id = bh.academic_year_id',
            'inner'
        )
        ->where(
            'ay.school_id',
            $user->school_id
        )
        ->where(
            'ay.status',
            'aktif'
        )
        ->order_by(
            'ay.start_year',
            'DESC'
        )
        ->limit(1)
        ->get()
        ->row();


    /*
     * Session utama
     */
    $this->session->set_userdata(
        'logged_in',
        TRUE
    );


    /*
     * Data user
     */
    $this->session->set_userdata(
        'user',
        array(
            'id'        => $user->id,
            'username'  => $user->username,
            'full_name' => $user->full_name,
            'role'      => $user->role
        )
    );


    /*
     * Data sekolah
     */
    $this->session->set_userdata(
        'school_id',
        (int) $user->school_id
    );

    $this->session->set_userdata(
        'school_name',
        $school->name
    );

    $this->session->set_userdata(
        'school_name',
        $school->full_name
    );


    /*
     * Role
     */
    $this->session->set_userdata(
        'role',
        $user->role
    );


    /*
     * RAPBS aktif
     */
    if ($budget) {

        $this->session->set_userdata(
            'active_budget_id',
            (int) $budget->budget_id
        );

        $this->session->set_userdata(
            'academic_year_id',
            (int) $budget->academic_year_id
        );

        $this->session->set_userdata(
            'academic_year',
            $budget->academic_year
        );

        $this->session->set_userdata(
            'budget_title',
            $budget->budget_title
        );

        $this->session->set_userdata(
            'budget_status',
            $budget->budget_status
        );

    } else {

        $this->session->set_userdata(
            'active_budget_id',
            NULL
        );

        $this->session->set_userdata(
            'academic_year_id',
            NULL
        );

        $this->session->set_userdata(
            'academic_year',
            NULL
        );

        $this->session->set_userdata(
            'budget_title',
            NULL
        );

        $this->session->set_userdata(
            'budget_status',
            NULL
        );
    }


    /*
     * Update last login user
     */
    $this->Auth_model->touch_login(
        $user->id
    );


    redirect('dashboard');
}


    public function logout()
    {
        $this->session->sess_destroy();

        redirect('login');
    }


    public function setup()
    {
        redirect('setup');
    }
}