<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengeluaran extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->require_login();

        $this->load->model('Pengeluaran_model');
    }

    public function index()
    {
        $data = array(
            'title' => 'Pengeluaran',
            'items' => $this->Pengeluaran_model->get_all(),
            'total' => $this->Pengeluaran_model->get_total()
        );

        $this->load->view('pengeluaran/index', $data);
    }

    public function create()
    {
        $data = array(
            'title'      => 'Tambah Pengeluaran',
            'item'       => $this->Pengeluaran_model->get_empty(),
            'categories' => $this->Pengeluaran_model->get_categories()
        );

        $this->load->view('pengeluaran/form', $data);
    }

    public function store()
    {
        $post = $this->input->post(NULL, TRUE);

        $data = $this->Pengeluaran_model->prepare_item($post);

        if (!$this->Pengeluaran_model->validate_data($data)) {

            $this->session->set_flashdata(
                'error',
                'Data pengeluaran belum lengkap.'
            );

            redirect('pengeluaran/create');
            return;
        }

        if (!$this->Pengeluaran_model->insert($data)) {

            $this->session->set_flashdata(
                'error',
                'Data pengeluaran gagal disimpan.'
            );

            redirect('pengeluaran/create');
            return;
        }

        $this->session->set_flashdata(
            'success',
            'Data pengeluaran berhasil ditambahkan.'
        );

        redirect('pengeluaran');
    }

    public function edit($id)
    {
        $item = $this->Pengeluaran_model->get_by_id((int) $id);

        if (!$item) {
            show_404();
        }

        $data = array(
            'title'      => 'Edit Pengeluaran',
            'item'       => $item,
            'categories' => $this->Pengeluaran_model->get_categories()
        );

        $this->load->view('pengeluaran/form', $data);
    }

    public function update($id)
    {
        $item = $this->Pengeluaran_model->get_by_id((int) $id);

        if (!$item) {
            show_404();
        }

        $post = $this->input->post(NULL, TRUE);

        $data = $this->Pengeluaran_model->prepare_item($post);

        if (!$this->Pengeluaran_model->validate_data($data)) {

            $this->session->set_flashdata(
                'error',
                'Data pengeluaran belum lengkap.'
            );

            redirect('pengeluaran/edit/' . (int) $id);
            return;
        }

        if (!$this->Pengeluaran_model->update((int) $id, $data)) {

            $this->session->set_flashdata(
                'error',
                'Data pengeluaran gagal diperbarui.'
            );

            redirect('pengeluaran/edit/' . (int) $id);
            return;
        }

        $this->session->set_flashdata(
            'success',
            'Data pengeluaran berhasil diperbarui.'
        );

        redirect('pengeluaran');
    }

    public function detail($id)
    {
        $item = $this->Pengeluaran_model->get_by_id((int) $id);

        if (!$item) {
            show_404();
        }

        $data = array(
            'title' => 'Detail Pengeluaran',
            'item'  => $item
        );

        $this->load->view('pengeluaran/detail', $data);
    }

    public function delete($id)
    {
        $item = $this->Pengeluaran_model->get_by_id((int) $id);

        if (!$item) {
            show_404();
        }

        if (!$this->Pengeluaran_model->delete((int) $id)) {

            $this->session->set_flashdata(
                'error',
                'Data pengeluaran gagal dihapus.'
            );

            redirect('pengeluaran');
            return;
        }

        $this->session->set_flashdata(
            'success',
            'Data pengeluaran berhasil dihapus.'
        );

        redirect('pengeluaran');
    }
}