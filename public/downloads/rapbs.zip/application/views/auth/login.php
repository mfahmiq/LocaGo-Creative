<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= html_escape($title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#f5f7fb; }
        .login-card { max-width:420px; margin:8vh auto; }
    </style>
</head>
<body>
<div class="container">
    <div class="card shadow-sm border-0 login-card">
        <div class="card-body p-4">
            <h3 class="mb-1"><?= html_escape(RAPBS_APP_NAME); ?></h3>
            <p class="text-muted mb-4"><?= html_escape(RAPBS_SCHOOL_NAME); ?></p>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <?= html_escape($error); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    <?= html_escape($success); ?>
                </div>
            <?php endif; ?>

            <form method="post" action="<?= site_url('auth/login'); ?>">
                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" value="admin" required autofocus>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button class="btn btn-primary w-100">Login</button>
            </form>

            <div class="text-center mt-3">
                <a href="<?= site_url('setup'); ?>" class="small">Setup password admin</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
