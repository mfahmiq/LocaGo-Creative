<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= html_escape($title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container">
    <div class="card shadow-sm border-0" style="max-width:480px;margin:8vh auto;">
        <div class="card-body p-4">
            <h3>Setup Password Admin</h3>
            <p class="text-muted">Lakukan satu kali setelah import database.</p>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?= html_escape($error); ?></div>
            <?php endif; ?>

            <form method="post" action="<?= site_url('setup'); ?>">
                <div class="mb-3">
                    <label class="form-label">Password baru</label>
                    <input type="password" name="password" class="form-control" minlength="8" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Ulangi password</label>
                    <input type="password" name="password_confirm" class="form-control" minlength="8" required>
                </div>
                <button class="btn btn-primary">Simpan Password</button>
                <a href="<?= site_url('login'); ?>" class="btn btn-light">Batal</a>
            </form>
        </div>
    </div>
</div>
</body>
</html>
