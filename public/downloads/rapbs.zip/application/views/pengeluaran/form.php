<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$is_edit = !empty($item->id);

$action = $is_edit
    ? site_url('pengeluaran/update/' . $item->id)
    : site_url('pengeluaran/store');
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <title>
        <?= $is_edit ? 'Edit Pengeluaran' : 'Tambah Pengeluaran'; ?>
        - RAPBS
    </title>

    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial, sans-serif;
            color: #17202a;
        }

        .container {
            max-width: 850px;
            margin: 35px auto;
            padding: 0 20px;
        }

        h1 {
            margin: 0 0 5px;
        }

        .subtitle {
            color: #666;
            margin-bottom: 20px;
        }

        .card {
            background: #fff;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,.08);
        }

        .form-group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 7px;
        }

        .required {
            color: #d00;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 11px 12px;
            border: 1px solid #ced4da;
            border-radius: 6px;
            font-size: 15px;
            font-family: inherit;
        }

        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: #1677ff;
            box-shadow: 0 0 0 2px rgba(22,119,255,.1);
        }

        textarea {
            min-height: 100px;
            resize: vertical;
        }

        .row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }

        .amount-box {
            background: #f1f5f9;
            border-radius: 8px;
            padding: 18px;
            margin-top: 5px;
        }

        .amount-label {
            color: #666;
            margin-bottom: 5px;
        }

        .amount {
            font-size: 28px;
            font-weight: bold;
        }

        .formula {
            margin-top: 5px;
            color: #777;
            font-size: 13px;
        }

        .actions {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }

        .btn {
            border: 0;
            border-radius: 6px;
            padding: 11px 20px;
            font-size: 15px;
            text-decoration: none;
            cursor: pointer;
        }

        .btn-primary {
            background: #1677ff;
            color: #fff;
        }

        .btn-secondary {
            background: #6c757d;
            color: #fff;
        }

        .alert {
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .alert-error {
            background: #f8d7da;
            color: #842029;
        }

        @media(max-width:650px) {

            .row {
                grid-template-columns: 1fr;
                gap: 0;
            }

            .container {
                margin-top: 20px;
            }

        }

    </style>

</head>


<body>

<div class="container">

    <div style="margin-bottom:18px;">

        <a href="<?= site_url('pengeluaran'); ?>">
            ← Kembali ke Pengeluaran
        </a>

    </div>


    <h1>
        <?= $is_edit
            ? 'Edit Pengeluaran'
            : 'Tambah Pengeluaran'; ?>
    </h1>

    <div class="subtitle">
        RAPBS - Data Pengeluaran
    </div>


    <div class="card">


        <?php if ($this->session->flashdata('error')): ?>

            <div class="alert alert-error">

                <?= html_escape(
                    $this->session->flashdata('error')
                ); ?>

            </div>

        <?php endif; ?>


        <form
            method="post"
            action="<?= $action; ?>"
        >


            <!-- KATEGORI -->

            <div class="form-group">

                <label for="expense_category_id">

                    Kategori Pengeluaran
                    <span class="required">*</span>

                </label>


                <select
                    name="expense_category_id"
                    id="expense_category_id"
                    required
                >

                    <option value="">
                        -- Pilih Kategori Pengeluaran --
                    </option>


                    <?php foreach ($categories as $category): ?>

                        <option
                            value="<?= (int) $category->id; ?>"
                            <?= (
                                (int) $item->expense_category_id
                                === (int) $category->id
                            )
                            ? 'selected'
                            : ''; ?>
                        >

                            <?= html_escape(
                                $category->name
                            ); ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <!-- URAIAN -->

            <div class="form-group">

                <label for="description">

                    Uraian
                    <span class="required">*</span>

                </label>


                <input
                    type="text"
                    name="description"
                    id="description"
                    value="<?= html_escape(
                        $item->description
                    ); ?>"
                    placeholder="Contoh: Penyusunan Kurikulum"
                    required
                >

            </div>


            <!-- PERIODE + JUMLAH -->

            <div class="row">


                <div class="form-group">

                    <label for="period_count">

                        Periode
                        <span class="required">*</span>

                    </label>


                    <input
                        type="number"
                        name="period_count"
                        id="period_count"
                        min="0"
                        step="1"
                        value="<?= html_escape(
                            $item->period_count
                        ); ?>"
                        required
                    >

                    <small style="color:#777;">
                        Contoh: 1 kegiatan, 12 bulan
                    </small>

                </div>


                <div class="form-group">

                    <label for="quantity">

                        Jumlah
                        <span class="required">*</span>

                    </label>


                    <input
                        type="number"
                        name="quantity"
                        id="quantity"
                        min="0"
                        step="1"
                        value="<?= html_escape(
                            $item->quantity
                        ); ?>"
                        required
                    >

                </div>

            </div>


            <!-- TARIF -->

            <div class="form-group">

                <label for="unit_price">

                    Tarif / Harga Satuan
                    <span class="required">*</span>

                </label>


                <input
                    type="number"
                    name="unit_price"
                    id="unit_price"
                    min="0"
                    step="1"
                    value="<?= html_escape(
                        $item->unit_price
                    ); ?>"
                    required
                >

            </div>


            <!-- TOTAL -->

            <div class="amount-box">

                <div class="amount-label">
                    Total Pengeluaran
                </div>


                <div
                    class="amount"
                    id="amount_display"
                >
                    Rp 0
                </div>


                <div class="formula">

                    Periode × Jumlah × Tarif

                </div>

            </div>


            <!-- CATATAN -->

            <div
                class="form-group"
                style="margin-top:20px;"
            >

                <label for="notes">
                    Catatan
                </label>


                <textarea
                    name="notes"
                    id="notes"
                    placeholder="Catatan tambahan jika diperlukan..."
                ><?= html_escape(
                    $item->notes
                ); ?></textarea>

            </div>


            <!-- BUTTON -->

            <div class="actions">

                <button
                    type="submit"
                    class="btn btn-primary"
                >

                    <?= $is_edit
                        ? 'Simpan Perubahan'
                        : 'Simpan Pengeluaran'; ?>

                </button>


                <a
                    href="<?= site_url('pengeluaran'); ?>"
                    class="btn btn-secondary"
                >

                    Batal

                </a>

            </div>


        </form>

    </div>

</div>


<script>

function rupiah(angka)
{
    angka = Math.round(angka || 0);

    return 'Rp ' + angka.toLocaleString(
        'id-ID'
    );
}


function hitungTotal()
{
    const periode = parseFloat(
        document.getElementById(
            'period_count'
        ).value
    ) || 0;


    const jumlah = parseFloat(
        document.getElementById(
            'quantity'
        ).value
    ) || 0;


    const tarif = parseFloat(
        document.getElementById(
            'unit_price'
        ).value
    ) || 0;


    const total =
        periode *
        jumlah *
        tarif;


    document.getElementById(
        'amount_display'
    ).textContent = rupiah(total);
}


document.getElementById(
    'period_count'
).addEventListener(
    'input',
    hitungTotal
);


document.getElementById(
    'quantity'
).addEventListener(
    'input',
    hitungTotal
);


document.getElementById(
    'unit_price'
).addEventListener(
    'input',
    hitungTotal
);


hitungTotal();

</script>


</body>

</html>