<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">

    <title><?= html_escape($title); ?> - RAPBS</title>

    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <style>

        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial, sans-serif;
            color: #17202a;
        }

        .container {
            max-width: 800px;
            margin: 35px auto;
            padding: 0 20px;
        }

        .card {
            background: #fff;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,.08);
        }

        h1 {
            margin-top: 0;
        }

        .form-group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 7px;
        }

        input,
        select,
        textarea {
            width: 100%;
            box-sizing: border-box;
            padding: 11px;
            border: 1px solid #ced4da;
            border-radius: 6px;
            font-size: 15px;
        }

        textarea {
            min-height: 90px;
            resize: vertical;
        }

        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }

        .total-box {
            background: #f1f3f5;
            border-radius: 8px;
            padding: 16px;
            margin: 20px 0;
        }

        .total-label {
            font-size: 14px;
            color: #666;
        }

        .total {
            font-size: 28px;
            font-weight: bold;
            margin-top: 5px;
        }

        .actions {
            margin-top: 20px;
        }

        .btn {
            display: inline-block;
            padding: 11px 18px;
            border: 0;
            border-radius: 6px;
            text-decoration: none;
            cursor: pointer;
            font-size: 15px;
        }

        .btn-primary {
            background: #1677ff;
            color: #fff;
        }

        .btn-secondary {
            background: #6c757d;
            color: #fff;
        }

        .back {
            margin-bottom: 18px;
        }

        .back a {
            color: #1677ff;
        }

        @media(max-width:600px) {

            .grid {
                grid-template-columns: 1fr;
            }

        }

    </style>

</head>

<body>

<div class="container">

    <div class="back">

        <a href="<?= site_url('penerimaan'); ?>">
            ← Kembali ke Penerimaan
        </a>

    </div>


    <div class="card">

        <h1><?= html_escape($title); ?></h1>


        <?php if ($this->session->flashdata('error')): ?>

            <div style="
                background:#f8d7da;
                padding:12px;
                border-radius:6px;
                margin-bottom:18px;
            ">

                <?= html_escape(
                    $this->session->flashdata('error')
                ); ?>

            </div>

        <?php endif; ?>


        <?php

        $is_edit = !empty($item->id);

        if ($is_edit) {

            $action = site_url(
                'penerimaan/update/' . $item->id
            );

        } else {

            $action = site_url(
                'penerimaan/store'
            );

        }

        ?>


        <form method="post"
              action="<?= $action; ?>">


            <div class="form-group">

                <label>
                    Sumber Dana
                </label>

                <select
                    name="income_category_id"
                    required>

                    <option value="">
                        -- Pilih Sumber Dana --
                    </option>

                    <?php foreach ($categories as $category): ?>

                        <option
                            value="<?= $category->id; ?>"
                            <?= (
                                (int)$item->income_category_id
                                ===
                                (int)$category->id
                            )
                                ? 'selected'
                                : ''
                            ?>>

                            <?= html_escape(
                                $category->name
                            ); ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="form-group">

                <label>
                    Uraian
                </label>

                <input
                    type="text"
                    name="description"
                    value="<?= html_escape(
                        $item->description
                    ); ?>"
                    placeholder="Contoh: SPP bulan Januari"
                    required>

            </div>


            <div class="grid">

                <div class="form-group">

                    <label>
                        Periode
                    </label>

                    <input
                        id="period_count"
                        type="number"
                        name="period_count"
                        min="0"
                        step="1"
                        value="<?= html_escape(
                            $item->period_count
                        ); ?>"
                        required>

                </div>


                <div class="form-group">

                    <label>
                        Jumlah
                    </label>

                    <input
                        id="quantity"
                        type="number"
                        name="quantity"
                        min="0"
                        step="1"
                        value="<?= html_escape(
                            $item->quantity
                        ); ?>"
                        required>

                </div>

            </div>


            <div class="form-group">

                <label>
                    Tarif / Harga Satuan
                </label>

                <input
                    id="unit_price"
                    type="number"
                    name="unit_price"
                    min="0"
                    step="1"
                    value="<?= html_escape(
                        $item->unit_price
                    ); ?>"
                    required>

            </div>


            <div class="total-box">

                <div class="total-label">
                    Total Penerimaan
                </div>

                <div
                    class="total"
                    id="total_display">

                    Rp 0

                </div>

            </div>


            <div class="form-group">

                <label>
                    Catatan
                </label>

                <textarea
                    name="notes"
                    placeholder="Catatan tambahan (opsional)"
                ><?= html_escape(
                    $item->notes
                ); ?></textarea>

            </div>


            <div class="actions">

                <button
                    type="submit"
                    class="btn btn-primary">

                    Simpan

                </button>


                <a
                    href="<?= site_url('penerimaan'); ?>"
                    class="btn btn-secondary">

                    Batal

                </a>

            </div>

        </form>

    </div>

</div>


<script>

function formatRupiah(angka)
{
    angka = Math.round(angka);

    return 'Rp ' +
        angka.toLocaleString('id-ID');
}


function hitungTotal()
{
    const periode =
        parseFloat(
            document.getElementById(
                'period_count'
            ).value
        ) || 0;


    const jumlah =
        parseFloat(
            document.getElementById(
                'quantity'
            ).value
        ) || 0;


    const tarif =
        parseFloat(
            document.getElementById(
                'unit_price'
            ).value
        ) || 0;


    const total =
        periode *
        jumlah *
        tarif;


    document.getElementById(
        'total_display'
    ).innerText =
        formatRupiah(total);
}


document.getElementById(
    'period_count'
).addEventListener(
    'input',
    hitungTotal
);


document.getElementById(
    'quantity'
).addEventListener(
    'input',
    hitungTotal
);


document.getElementById(
    'unit_price'
).addEventListener(
    'input',
    hitungTotal
);


hitungTotal();

</script>

</body>
</html>