<!DOCTYPE html>
<html lang="id">
<head>

    <meta charset="UTF-8">

    <title>Penerimaan - RAPBS</title>

    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <style>

        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial, sans-serif;
            color: #17202a;
        }

        .container {
            max-width: 1150px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        h1 {
            margin: 0;
        }

        .btn {
            display: inline-block;
            padding: 10px 16px;
            border-radius: 6px;
            text-decoration: none;
            background: #1677ff;
            color: white;
        }

        .card {
            background: white;
            border-radius: 10px;
            padding: 22px;
            box-shadow: 0 2px 8px rgba(0,0,0,.08);
        }

        .total-label {
            color: #666;
        }

        .total {
            font-size: 28px;
            font-weight: bold;
            margin: 5px 0 25px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 11px;
            border-bottom: 1px solid #ddd;
        }

        th {
            text-align: left;
        }

        td.number,
        th.number {
            text-align: right;
        }

        .action a {
            margin-right: 8px;
        }

        .success {
            background: #d1e7dd;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

        .error {
            background: #f8d7da;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

    </style>

</head>

<body>

<div class="container">

    <div class="header">

        <div>

            <h1>Penerimaan</h1>

            <a href="<?= site_url('dashboard'); ?>">
                ← Kembali ke Dashboard
            </a>

        </div>

        <a class="btn"
           href="<?= site_url('penerimaan/create'); ?>">

            + Tambah Penerimaan

        </a>

    </div>


    <div class="card">

        <?php if ($this->session->flashdata('success')): ?>

            <div class="success">
                <?= html_escape(
                    $this->session->flashdata('success')
                ); ?>
            </div>

        <?php endif; ?>


        <?php if ($this->session->flashdata('error')): ?>

            <div class="error">
                <?= html_escape(
                    $this->session->flashdata('error')
                ); ?>
            </div>

        <?php endif; ?>


        <div class="total-label">
            Total Penerimaan
        </div>

        <div class="total">
            Rp <?= number_format(
                $total,
                0,
                ',',
                '.'
            ); ?>
        </div>


        <table>

            <thead>

                <tr>

                    <th>Sumber Dana</th>

                    <th>Uraian</th>

                    <th class="number">
                        Periode
                    </th>

                    <th class="number">
                        Jumlah
                    </th>

                    <th class="number">
                        Tarif
                    </th>

                    <th class="number">
                        Total
                    </th>

                    <th>Aksi</th>

                </tr>

            </thead>


            <tbody>

            <?php if (empty($items)): ?>

                <tr>

                    <td colspan="7">
                        Belum ada data penerimaan.
                    </td>

                </tr>

            <?php else: ?>

                <?php foreach ($items as $row): ?>

                    <tr>

                        <td>
                            <?= html_escape(
                                $row->income_category_name
                                ?: '-'
                            ); ?>
                        </td>

                        <td>
                            <?= html_escape(
                                $row->description
                            ); ?>
                        </td>

                        <td class="number">
                            <?= number_format(
                                $row->period_count,
                                0,
                                ',',
                                '.'
                            ); ?>
                        </td>

                        <td class="number">
                            <?= number_format(
                                $row->quantity,
                                0,
                                ',',
                                '.'
                            ); ?>
                        </td>

                        <td class="number">
                            Rp <?= number_format(
                                $row->unit_price,
                                0,
                                ',',
                                '.'
                            ); ?>
                        </td>

                        <td class="number">
                            Rp <?= number_format(
                                $row->amount,
                                0,
                                ',',
                                '.'
                            ); ?>
                        </td>

                        <td class="action">

                            <a href="<?= site_url(
                                'penerimaan/detail/' . $row->id
                            ); ?>">
                                Detail
                            </a>

                            <a href="<?= site_url(
                                'penerimaan/edit/' . $row->id
                            ); ?>">
                                Edit
                            </a>

                            <a href="<?= site_url(
                                'penerimaan/delete/' . $row->id
                            ); ?>"
                            onclick="return confirm(
                                'Yakin ingin menghapus data penerimaan ini?'
                            );">
                                Hapus
                            </a>

                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>