<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">

    <title><?= html_escape($title); ?> - RAPBS</title>

    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <style>

        body {
            margin: 0;
            background: #f4f6f9;
            font-family: Arial, sans-serif;
            color: #17202a;
        }

        .container {
            max-width: 800px;
            margin: 35px auto;
            padding: 0 20px;
        }

        .card {
            background: #fff;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,.08);
        }

        h1 {
            margin-top: 0;
        }

        .row {
            display: grid;
            grid-template-columns: 200px 1fr;
            padding: 13px 0;
            border-bottom: 1px solid #ddd;
        }

        .label {
            color: #666;
        }

        .value {
            font-weight: 500;
        }

        .total {
            font-size: 28px;
            font-weight: bold;
            margin-top: 8px;
        }

        .actions {
            margin-top: 25px;
        }

        .btn {
            display: inline-block;
            padding: 10px 17px;
            border-radius: 6px;
            text-decoration: none;
            margin-right: 8px;
        }

        .btn-primary {
            background: #1677ff;
            color: white;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        @media(max-width:600px) {

            .row {
                grid-template-columns: 1fr;
                gap: 5px;
            }

        }

    </style>

</head>

<body>

<div class="container">

    <div style="margin-bottom:18px;">

        <a href="<?= site_url('penerimaan'); ?>">
            ← Kembali ke Penerimaan
        </a>

    </div>


    <div class="card">

        <h1>Detail Penerimaan</h1>


        <div class="row">

            <div class="label">
                Sumber Dana
            </div>

            <div class="value">
                <?= html_escape(
                    $item->income_category_name ?: '-'
                ); ?>
            </div>

        </div>


        <div class="row">

            <div class="label">
                Uraian
            </div>

            <div class="value">
                <?= html_escape(
                    $item->description
                ); ?>
            </div>

        </div>


        <div class="row">

            <div class="label">
                Periode
            </div>

            <div class="value">
                <?= number_format(
                    $item->period_count,
                    0,
                    ',',
                    '.'
                ); ?>
            </div>

        </div>


        <div class="row">

            <div class="label">
                Jumlah
            </div>

            <div class="value">
                <?= number_format(
                    $item->quantity,
                    0,
                    ',',
                    '.'
                ); ?>
            </div>

        </div>


        <div class="row">

            <div class="label">
                Tarif / Harga Satuan
            </div>

            <div class="value">
                Rp <?= number_format(
                    $item->unit_price,
                    0,
                    ',',
                    '.'
                ); ?>
            </div>

        </div>


        <div class="row">

            <div class="label">
                Total Penerimaan
            </div>

            <div class="value total">
                Rp <?= number_format(
                    $item->amount,
                    0,
                    ',',
                    '.'
                ); ?>
            </div>

        </div>


        <div class="row">

            <div class="label">
                Catatan
            </div>

            <div class="value">
                <?= nl2br(
                    html_escape(
                        $item->notes ?: '-'
                    )
                ); ?>
            </div>

        </div>


        <div class="actions">

            <a
                class="btn btn-primary"
                href="<?= site_url(
                    'penerimaan/edit/' . $item->id
                ); ?>">

                Edit

            </a>


            <a
                class="btn btn-secondary"
                href="<?= site_url(
                    'penerimaan'
                ); ?>">

                Kembali

            </a>

        </div>

    </div>

</div>

</body>
</html>