<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= html_escape($title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#f5f7fb; }
        .sidebar { min-height:100vh; background:#212529; }
        .sidebar a { color:#dee2e6; text-decoration:none; display:block; padding:10px 16px; }
        .sidebar a:hover { background:#343a40; }
        .stat-card { border:0; border-radius:14px; }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <aside class="col-md-2 p-0 sidebar">
            <div class="p-3 text-white">
                <h5 class="mb-0">RAPBS</h5>
                <small><?= html_escape(RAPBS_SCHOOL_NAME); ?></small>
            </div>
            <a href="<?= site_url('dashboard'); ?>">Dashboard</a>
            <a href="../rapbs/penerimaan">Penerimaan</a>
            <a href="../rapbs/pengeluaran">Pengeluaran</a>
            <a href="#">Analisa RAPBS</a>
            <a href="#">Data Pegawai</a>
            <a href="#">Laporan</a>
            <a href="<?= site_url('logout'); ?>">Logout</a>
        </aside>

        <main class="col-md-10 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="mb-1">Dashboard</h2>
                    <div class="text-muted">
                        <?= $year ? html_escape($year->name) : 'Belum ada tahun aktif'; ?>
                    </div>
                </div>
                <div>Halo, <strong><?= html_escape($user['full_name']); ?></strong></div>
            </div>

            <?php if (!$summary): ?>
                <div class="alert alert-warning">
                    Belum ada data RAPBS untuk tahun aktif.
                </div>
            <?php endif; ?>

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="card stat-card shadow-sm">
                        <div class="card-body">
                            <div class="text-muted">Total Penerimaan</div>
                            <h3>Rp <?= number_format($summary ? $summary->total_penerimaan : 0, 0, ',', '.'); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card stat-card shadow-sm">
                        <div class="card-body">
                            <div class="text-muted">Total Pengeluaran</div>
                            <h3>Rp <?= number_format($summary ? $summary->total_pengeluaran : 0, 0, ',', '.'); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card stat-card shadow-sm">
                        <div class="card-body">
                            <div class="text-muted">Saldo Anggaran</div>
                            <h3>Rp <?= number_format($summary ? $summary->saldo : 0, 0, ',', '.'); ?></h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <h5>Data Master</h5>
                            <div class="row text-center mt-3">
                                <div class="col">
                                    <div class="fs-3"><?= $student_count; ?></div>
                                    <div class="text-muted">Murid</div>
                                </div>
                                <div class="col">
                                    <div class="fs-3"><?= $employee_count; ?></div>
                                    <div class="text-muted">Pegawai</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <h5>Status RAPBS</h5>
                            <p class="mb-0">
                                Status:
                                <span class="badge bg-secondary">
                                    <?= $summary ? html_escape($summary->status) : 'belum ada'; ?>
                                </span>
                            </p>
                            <?php if ($year): ?>
                                <small class="text-muted"><?= html_escape($year->name); ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-3">
                <div class="col-md-6">
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <h5>Ringkasan Penerimaan</h5>
                            <table class="table table-sm">
                                <thead><tr><th>Kategori</th><th class="text-end">Jumlah</th></tr></thead>
                                <tbody>
                                <?php foreach ($income as $row): ?>
                                    <tr>
                                        <td><?= html_escape($row->name); ?></td>
                                        <td class="text-end">Rp <?= number_format($row->total,0,',','.'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card shadow-sm border-0">
                        <div class="card-body">
                            <h5>Ringkasan Pengeluaran</h5>
                            <table class="table table-sm">
                                <thead><tr><th>Kategori</th><th class="text-end">Jumlah</th></tr></thead>
                                <tbody>
                                <?php foreach ($expense as $row): ?>
                                    <tr>
                                        <td><?= html_escape($row->name); ?></td>
                                        <td class="text-end">Rp <?= number_format($row->total,0,',','.'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html>
