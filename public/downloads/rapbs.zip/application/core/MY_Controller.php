<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->library('session');

        $this->require_login();
    }


    protected function require_login()
    {
        if ($this->session->userdata('logged_in') !== TRUE) {

            redirect('login');

            exit;
        }
    }


    /**
     * Data user yang sedang login.
     */
    protected function current_user()
    {
        return $this->session->userdata('user');
    }


    /**
     * ID sekolah.
     */
    protected function get_school_id()
    {
        return (int) $this->session
            ->userdata('school_id');
    }


    /**
     * ID RAPBS aktif.
     */
    protected function get_budget_id()
    {
        return (int) $this->session
            ->userdata('active_budget_id');
    }


    /**
     * ID tahun pelajaran.
     */
    protected function get_academic_year_id()
    {
        return (int) $this->session
            ->userdata('academic_year_id');
    }


    /**
     * Nama sekolah.
     */
    protected function get_school_name()
    {
        return $this->session
            ->userdata('school_name');
    }


    /**
     * Tahun pelajaran.
     */
    protected function get_academic_year()
    {
        return $this->session
            ->userdata('academic_year');
    }


    /**
     * Role.
     */
    protected function get_role()
    {
        return $this->session
            ->userdata('role');
    }
}