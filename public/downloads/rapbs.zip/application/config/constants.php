<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| RAPBS constants
|--------------------------------------------------------------------------
*/
defined('RAPBS_APP_NAME') OR define('RAPBS_APP_NAME', 'Sistem RAPBS');
defined('RAPBS_SCHOOL_NAME') OR define('RAPBS_SCHOOL_NAME', 'KB AISYIYAH PENCONGAN');
