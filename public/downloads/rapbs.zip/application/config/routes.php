<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'auth';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['login'] = 'auth';
$route['logout'] = 'auth/logout';
$route['setup'] = 'setup/index';

$route['dashboard'] = 'dashboard';
$route['dashboard/index'] = 'dashboard/index';

$route['penerimaan'] = 'penerimaan/index';
$route['penerimaan/create'] = 'penerimaan/create';
$route['penerimaan/store'] = 'penerimaan/store';
$route['penerimaan/edit/(:num)'] = 'penerimaan/edit/$1';
$route['penerimaan/update/(:num)'] = 'penerimaan/update/$1';
$route['penerimaan/detail/(:num)'] = 'penerimaan/detail/$1';
$route['penerimaan/delete/(:num)'] = 'penerimaan/delete/$1';

$route['pengeluaran'] = 'pengeluaran/index';
$route['pengeluaran/create'] = 'pengeluaran/create';
$route['pengeluaran/store'] = 'pengeluaran/store';
$route['pengeluaran/edit/(:num)'] = 'pengeluaran/edit/$1';
$route['pengeluaran/update/(:num)'] = 'pengeluaran/update/$1';
$route['pengeluaran/detail/(:num)'] = 'pengeluaran/detail/$1';
$route['pengeluaran/delete/(:num)'] = 'pengeluaran/delete/$1';