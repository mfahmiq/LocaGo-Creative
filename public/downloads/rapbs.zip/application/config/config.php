<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Basic
|--------------------------------------------------------------------------
*/

$config['base_url'] = 'http://localhost/rapbs/';
$config['index_page'] = '';
$config['uri_protocol'] = 'REQUEST_URI';
$config['url_suffix'] = '';

$config['language'] = 'english';
$config['charset'] = 'UTF-8';

$config['enable_hooks'] = FALSE;
$config['subclass_prefix'] = 'MY_';
$config['composer_autoload'] = FALSE;

$config['permitted_uri_chars'] = 'a-z 0-9~%.:_\-|';

$config['enable_query_strings'] = FALSE;
$config['allow_get_array'] = TRUE;


/*
|--------------------------------------------------------------------------
| Security
|--------------------------------------------------------------------------
*/

$config['encryption_key'] = 'RapbsKbAisyiyahPencongan2026_X9mP7qL2';

$config['enable_csrf'] = FALSE;
$config['csrf_regenerate'] = TRUE;
$config['csrf_exclude_uris'] = array();

$config['global_xss_filtering'] = FALSE;


/*
|--------------------------------------------------------------------------
| Session
|--------------------------------------------------------------------------
*/

$config['sess_driver'] = 'files';
$config['sess_cookie_name'] = 'rapbs_session';
$config['sess_expiration'] = 7200;

/*
 * Kita gunakan folder khusus agar mudah memastikan
 * PHP/CI3 bisa menulis file session.
 */
$config['sess_save_path'] = APPPATH . 'cache/sessions';

$config['sess_match_ip'] = FALSE;
$config['sess_time_to_update'] = 300;
$config['sess_use_database'] = FALSE;


/*
|--------------------------------------------------------------------------
| Cookie
|--------------------------------------------------------------------------
*/

$config['cookie_prefix'] = '';
$config['cookie_domain'] = '';
$config['cookie_path'] = '/';
$config['cookie_secure'] = FALSE;
$config['cookie_httponly'] = TRUE;


/*
|--------------------------------------------------------------------------
| Logs
|--------------------------------------------------------------------------
*/

$config['log_threshold'] = 1;
$config['log_path'] = '';
$config['log_file_extension'] = '';
$config['log_file_permissions'] = 0644;
$config['log_date_format'] = 'Y-m-d H:i:s';


/*
|--------------------------------------------------------------------------
| Cache
|--------------------------------------------------------------------------
*/

$config['cache_path'] = '';
$config['cache_query_string'] = FALSE;


/*
|--------------------------------------------------------------------------
| Misc
|--------------------------------------------------------------------------
*/

$config['error_views_path'] = '';
$config['rewrite_short_tags'] = FALSE;
$config['proxy_ips'] = '';