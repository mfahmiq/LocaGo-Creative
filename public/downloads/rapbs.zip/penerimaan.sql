-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versi server:                 10.4.27-MariaDB - mariadb.org binary distribution
-- OS Server:                    Win64
-- HeidiSQL Versi:               12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Membuang struktur basisdata untuk rapbs_ci3
CREATE DATABASE IF NOT EXISTS `rapbs_ci3` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `rapbs_ci3`;

-- membuang struktur untuk table rapbs_ci3.budget_headers
CREATE TABLE IF NOT EXISTS `budget_headers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `academic_year_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `status` enum('draft','disetujui','ditutup') NOT NULL DEFAULT 'draft',
  `prepared_date` date DEFAULT NULL,
  `approved_date` date DEFAULT NULL,
  `prepared_by` int(10) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_budget_year` (`academic_year_id`),
  KEY `fk_budget_user` (`prepared_by`),
  CONSTRAINT `fk_budget_user` FOREIGN KEY (`prepared_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_budget_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel rapbs_ci3.budget_headers: ~1 rows (lebih kurang)
INSERT INTO `budget_headers` (`id`, `academic_year_id`, `title`, `status`, `prepared_date`, `approved_date`, `prepared_by`, `notes`, `created_at`, `updated_at`) VALUES
	(1, 1, 'Rencana Kegiatan dan Anggaran Sekolah Tahun Pelajaran 2025/2026', 'draft', '2025-07-28', NULL, NULL, 'Data awal diimpor dari workbook RAPBS 2025/2026.', '2026-08-11 09:07:05', NULL);

-- membuang struktur untuk table rapbs_ci3.budget_items
CREATE TABLE IF NOT EXISTS `budget_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `budget_id` int(10) unsigned NOT NULL,
  `item_type` enum('penerimaan','pengeluaran') NOT NULL,
  `income_category_id` int(10) unsigned DEFAULT NULL,
  `expense_category_id` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `item_code` varchar(50) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `period_count` decimal(12,2) NOT NULL DEFAULT 1.00,
  `quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `unit_price` decimal(15,2) NOT NULL DEFAULT 0.00,
  `amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `fixed_cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `variable_cost` decimal(15,2) NOT NULL DEFAULT 0.00,
  `last_year_realization` decimal(15,2) NOT NULL DEFAULT 0.00,
  `usage_description` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `excel_row` int(11) DEFAULT NULL,
  `formula_reference` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_budget_item_type` (`budget_id`,`item_type`),
  KEY `idx_budget_item_parent` (`parent_id`),
  KEY `fk_budget_item_income_cat` (`income_category_id`),
  KEY `fk_budget_item_expense_cat` (`expense_category_id`),
  KEY `idx_budget_items_description` (`description`),
  KEY `idx_budget_items_excel_row` (`excel_row`),
  CONSTRAINT `fk_budget_item_expense_cat` FOREIGN KEY (`expense_category_id`) REFERENCES `expense_categories` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_budget_item_header` FOREIGN KEY (`budget_id`) REFERENCES `budget_headers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_budget_item_income_cat` FOREIGN KEY (`income_category_id`) REFERENCES `income_categories` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_budget_item_parent` FOREIGN KEY (`parent_id`) REFERENCES `budget_items` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel rapbs_ci3.budget_items: ~144 rows (lebih kurang)
INSERT INTO `budget_items` (`id`, `budget_id`, `item_type`, `income_category_id`, `expense_category_id`, `parent_id`, `item_code`, `description`, `period_count`, `quantity`, `unit_price`, `amount`, `fixed_cost`, `variable_cost`, `last_year_realization`, `usage_description`, `notes`, `excel_row`, `formula_reference`, `sort_order`, `created_at`, `updated_at`) VALUES
	(1, 1, 'penerimaan', 1, NULL, NULL, '1.1', 'Murid KB', 1.00, 10.00, 300000.00, 3000000.00, 0.00, 0.00, 0.00, NULL, 'bla bla bla', 11, '=D11*E11*F11', 11, '2026-08-11 09:07:05', NULL),
	(2, 1, 'penerimaan', 2, NULL, NULL, '2.1', 'Infaq Wali murid', 12.00, 10.00, 165000.00, 19800000.00, 0.00, 0.00, 0.00, NULL, NULL, 14, '=D14*E14*F14', 14, '2026-08-11 09:07:05', NULL),
	(3, 1, 'penerimaan', 2, NULL, NULL, '2.2', 'KPO', 12.00, 10.00, 10000.00, 1200000.00, 0.00, 0.00, 0.00, NULL, NULL, 15, '=D15*E15*F15', 15, '2026-08-11 09:07:05', NULL),
	(4, 1, 'penerimaan', 2, NULL, NULL, '2.3', 'Dana Sosial', 12.00, 10.00, 5000.00, 600000.00, 0.00, 0.00, 0.00, NULL, NULL, 16, '=D16*E16*F16', 16, '2026-08-11 09:07:05', NULL),
	(5, 1, 'penerimaan', 3, NULL, NULL, '3.1', 'Tahap 2 2024/2025', 1.00, 10.00, 305000.00, 3050000.00, 0.00, 0.00, 0.00, NULL, NULL, 18, '=D18*E18*F18', 18, '2026-08-11 09:07:05', NULL),
	(6, 1, 'penerimaan', 3, NULL, NULL, '3.2', 'Tahap 1 2025/2026', 1.00, 10.00, 305000.00, 3050000.00, 0.00, 0.00, 0.00, NULL, NULL, 19, '=D19*E19*F19', 19, '2026-08-11 09:07:05', NULL),
	(7, 1, 'penerimaan', 4, NULL, NULL, '4.1', 'Uang  pendaftaran', 1.00, 10.00, 50000.00, 500000.00, 0.00, 0.00, 0.00, NULL, NULL, 21, '=D21*E21*F21', 21, '2026-08-11 09:07:05', NULL),
	(8, 1, 'penerimaan', 4, NULL, NULL, '4.2', 'Uang paket', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 22, NULL, 22, '2026-08-11 09:07:05', NULL),
	(9, 1, 'penerimaan', 4, NULL, NULL, NULL, 'Buku panduan ', 1.00, 10.00, 100000.00, 1000000.00, 0.00, 0.00, 0.00, NULL, NULL, 23, '=D23*E23*F23', 23, '2026-08-11 09:07:05', NULL),
	(10, 1, 'penerimaan', 4, NULL, NULL, NULL, 'Laporan perkembangan anak dan Atribut', 1.00, 10.00, 65000.00, 650000.00, 0.00, 0.00, 0.00, NULL, NULL, 24, '=D24*E24*F24', 24, '2026-08-11 09:07:05', NULL),
	(11, 1, 'penerimaan', 4, NULL, NULL, '4.3', 'Uang  seragam', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 25, NULL, 25, '2026-08-11 09:07:05', NULL),
	(12, 1, 'penerimaan', 4, NULL, NULL, NULL, 'Murid KB', 1.00, 10.00, 220000.00, 2200000.00, 0.00, 0.00, 0.00, NULL, NULL, 26, '=D26*E26*F26', 26, '2026-08-11 09:07:05', NULL),
	(13, 1, 'penerimaan', 5, NULL, NULL, '5.2', 'ACA dan AIK', 1.00, 10.00, 170000.00, 1700000.00, 0.00, 0.00, 0.00, NULL, NULL, 29, '=D29*E29*F29', 29, '2026-08-11 09:07:05', NULL),
	(14, 1, 'penerimaan', 5, NULL, NULL, '5.1', 'DDTK', 1.00, 10.00, 15000.00, 150000.00, 0.00, 0.00, 0.00, NULL, NULL, 30, '=D30*E30*F30', 30, '2026-08-11 09:07:05', NULL),
	(15, 1, 'penerimaan', 6, NULL, NULL, '5.1', 'Lazismu', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 32, '=D32*E32*F32', 32, '2026-08-11 09:07:05', NULL),
	(16, 1, 'penerimaan', 6, NULL, NULL, '5.2', 'Hibah', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 33, '=D33*E33*F33', 33, '2026-08-11 09:07:05', NULL),
	(17, 1, 'penerimaan', 6, NULL, NULL, '5.3', 'Hamba Allah ', 12.00, 2.00, 200000.00, 4800000.00, 0.00, 0.00, 0.00, NULL, NULL, 34, '=D34*E34*F34', 34, '2026-08-11 09:07:05', NULL),
	(18, 1, 'penerimaan', 6, NULL, NULL, '5.4', 'Dana Sosial', 12.00, 10.00, 5000.00, 600000.00, 0.00, 0.00, 0.00, NULL, NULL, 35, '=D35*E35*F35', 35, '2026-08-11 09:07:05', NULL),
	(19, 1, 'pengeluaran', NULL, 1, NULL, NULL, 'Penyusunan dan penggandaan dokumen Alur Tujuan Pembelajaran', 1.00, 2.00, 55000.00, 110000.00, 0.00, 110000.00, 0.00, '=G41', NULL, 41, '=D41*E41*F41', 41, '2026-08-11 09:07:05', NULL),
	(20, 1, 'pengeluaran', NULL, 1, NULL, NULL, 'Penyusunan dan penggandaan dokumen STTPA', 1.00, 1.00, 25000.00, 25000.00, 0.00, 25000.00, 0.00, '=G42', NULL, 42, '=D42*E42*F42', 42, '2026-08-11 09:07:05', NULL),
	(21, 1, 'pengeluaran', NULL, 2, NULL, '1', 'Pelaksanaan Evadir', 1.00, 8.00, 10000.00, 80000.00, 0.00, 80000.00, 0.00, '=G45', NULL, 45, '=D45*E45*F45', 45, '2026-08-11 09:07:05', NULL),
	(22, 1, 'pengeluaran', NULL, 2, NULL, '2', 'Pengembangan Kurikulum', 2.00, 8.00, 10000.00, 160000.00, 0.00, 160000.00, 0.00, '=G46', NULL, 46, '=D46*E46*F46', 46, '2026-08-11 09:07:05', NULL),
	(23, 1, 'pengeluaran', NULL, 2, NULL, '3', 'Penyusunan Kurikulum ', 2.00, 8.00, 10000.00, 160000.00, 0.00, 160000.00, 0.00, '=G47', NULL, 47, '=D47*E47*F47', 47, '2026-08-11 09:07:05', NULL),
	(24, 1, 'pengeluaran', NULL, 2, NULL, '4', 'Penyusunan Modul Intra Kurikuler', 2.00, 8.00, 10000.00, 160000.00, 0.00, 160000.00, 0.00, '=G48', NULL, 48, '=D48*E48*F48', 48, '2026-08-11 09:07:05', NULL),
	(25, 1, 'pengeluaran', NULL, 2, NULL, '5', 'Penyusunan Modul  P5', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 49, '=D49*E49*F49', 49, '2026-08-11 09:07:05', NULL),
	(26, 1, 'pengeluaran', NULL, 2, NULL, '6', 'Uji Publik Kurikulum', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 50, '=D50*E50*F50', 50, '2026-08-11 09:07:05', NULL),
	(27, 1, 'pengeluaran', NULL, 3, NULL, 'A', 'INTRA KURIKULER', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 53, NULL, 53, '2026-08-11 09:07:05', NULL),
	(28, 1, 'pengeluaran', NULL, 3, NULL, '1', 'Paket murid', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 54, NULL, 54, '2026-08-11 09:07:05', NULL),
	(29, 1, 'pengeluaran', NULL, 3, NULL, '2', 'Buku Panduan', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 57, NULL, 57, '2026-08-11 09:07:05', NULL),
	(30, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Panduan AIKA untuk Guru', 1.00, 3.00, 136000.00, 408000.00, 0.00, 408000.00, 0.00, '=G58', NULL, 58, '=D58*E58*F58', 58, '2026-08-11 09:07:05', NULL),
	(31, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Panduan Murid Awal Tahun', 1.00, 10.00, 20000.00, 200000.00, 0.00, 200000.00, 0.00, NULL, NULL, 59, '=D59*E59*F59', 59, '2026-08-11 09:07:05', NULL),
	(32, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Kartu kontrol baca Iqro\'', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 60, '=D60*E60*F60', 60, '2026-08-11 09:07:05', NULL),
	(33, 1, 'pengeluaran', NULL, 3, NULL, '3', 'Kegiatan  Literasi Murid', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 62, NULL, 62, '2026-08-11 09:07:05', NULL),
	(34, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Kartu kontrol apresiasi (karakter)', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 63, '=D63*E63*F63', 63, '2026-08-11 09:07:05', NULL),
	(35, 1, 'pengeluaran', NULL, 3, NULL, '4', 'Perlengkapan project based learning', 2.00, 10.00, 30000.00, 600000.00, 0.00, 600000.00, 0.00, NULL, NULL, 64, '=D64*E64*F64', 64, '2026-08-11 09:07:05', NULL),
	(36, 1, 'pengeluaran', NULL, 3, NULL, 'B', 'KO KURIKULER', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 65, NULL, 65, '2026-08-11 09:07:05', NULL),
	(37, 1, 'pengeluaran', NULL, 3, NULL, '1', 'Kegiatan PHBI, PHBN, Hari internasional', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 66, NULL, 66, '2026-08-11 09:07:05', NULL),
	(38, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Hari Anak Nasional', 1.00, 1.00, 100000.00, 100000.00, 0.00, 100000.00, 0.00, NULL, NULL, 67, '=D67*E67*F67', 67, '2026-08-11 09:07:05', NULL),
	(39, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    HUT RI', 1.00, 1.00, 250000.00, 250000.00, 0.00, 250000.00, 0.00, '=G67', NULL, 68, '=D68*E68*F68', 68, '2026-08-11 09:07:05', NULL),
	(40, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Milad TK ABA', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '=G68', NULL, 69, NULL, 69, '2026-08-11 09:07:05', NULL),
	(41, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Hari Ayah', 1.00, 1.00, 300000.00, 300000.00, 0.00, 300000.00, 0.00, '=G70', NULL, 70, '=D70*E70*F70', 70, '2026-08-11 09:07:05', NULL),
	(42, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Milad Muhammadiyah/Aisyiyah', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 71, '=D71*E71*F71', 71, '2026-08-11 09:07:05', NULL),
	(43, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Hari Ibu', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 72, '=D72*E72*F72', 72, '2026-08-11 09:07:05', NULL),
	(44, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Marhaban ya Ramadhan', 1.00, 10.00, 25000.00, 250000.00, 0.00, 250000.00, 0.00, NULL, NULL, 73, '=D73*E73*F73', 73, '2026-08-11 09:07:05', NULL),
	(45, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Hari Raya Idul Fitri', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 74, '=D74*E74*F74', 74, '2026-08-11 09:07:05', NULL),
	(46, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Milad IGABA', 1.00, 10.00, 10000.00, 100000.00, 0.00, 100000.00, 0.00, NULL, NULL, 75, '=D75*E75*F75', 75, '2026-08-11 09:07:05', NULL),
	(47, 1, 'pengeluaran', NULL, 3, NULL, '2', 'Proyek Penguatan Profil Pelajar Pancasila', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 77, NULL, 77, '2026-08-11 09:07:05', NULL),
	(48, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Tahap Permulaan', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 78, NULL, 78, '2026-08-11 09:07:05', NULL),
	(49, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Tahap Pengembangan', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 79, '=D79*E79*F79', 79, '2026-08-11 09:07:05', NULL),
	(50, 1, 'pengeluaran', NULL, 3, NULL, NULL, '    Tahap Penyimpulan', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 80, NULL, 80, '2026-08-11 09:07:05', NULL),
	(51, 1, 'pengeluaran', NULL, 3, NULL, 'C', 'EKSTRA KURIKULER', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 81, NULL, 81, '2026-08-11 09:07:05', NULL),
	(52, 1, 'pengeluaran', NULL, 3, NULL, NULL, 'Penyusunan Program Ekskul', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 82, '=D82*E82*F82', 82, '2026-08-11 09:07:05', NULL),
	(53, 1, 'pengeluaran', NULL, 3, NULL, NULL, 'Evaluasi kegiatan ekstra kurikuler', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 83, '=D83*E83*F83', 83, '2026-08-11 09:07:05', NULL),
	(54, 1, 'pengeluaran', NULL, 3, NULL, 'D', 'TUMBUH KEMBANG', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 84, NULL, 84, '2026-08-11 09:07:05', NULL),
	(55, 1, 'pengeluaran', NULL, 3, NULL, NULL, 'Screening kesehatan', 2.00, 10.00, 20000.00, 400000.00, 0.00, 400000.00, 0.00, NULL, NULL, 85, '=D85*E85*F85', 85, '2026-08-11 09:07:05', NULL),
	(56, 1, 'pengeluaran', NULL, 3, NULL, NULL, 'Screening gigi', 1.00, 1.00, 200000.00, 200000.00, 0.00, 200000.00, 0.00, '=G86', NULL, 86, '=D86*E86*F86', 86, '2026-08-11 09:07:05', NULL),
	(57, 1, 'pengeluaran', NULL, 3, NULL, NULL, 'Program makanan tambahan BOP ', 2.00, 20.00, 10000.00, 400000.00, 0.00, 400000.00, 0.00, NULL, NULL, 87, '=D87*E87*F87', 87, '2026-08-11 09:07:05', NULL),
	(58, 1, 'pengeluaran', NULL, 3, NULL, NULL, 'Biscuit Cahaya', 2.00, 20.00, 2000.00, 80000.00, 0.00, 80000.00, 0.00, NULL, NULL, 88, '=D88*E88*F88', 88, '2026-08-11 09:07:05', NULL),
	(59, 1, 'pengeluaran', NULL, 4, NULL, '1', 'Penyusunan format  penilaian harian, mingguan, bulanan dan semester', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 90, NULL, 90, '2026-08-11 09:07:05', NULL),
	(60, 1, 'pengeluaran', NULL, 4, NULL, '2', 'Workshop penggunaan aplikasi raport', 1.00, 3.00, 50000.00, 150000.00, 0.00, 150000.00, 0.00, '=G91', NULL, 91, '=D91*E91*F91', 91, '2026-08-11 09:07:05', NULL),
	(61, 1, 'pengeluaran', NULL, 4, NULL, '3', 'Workshop penggunaan penyimpanan on line untuk dokumentasi penilaian harian', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 92, '=D92*E92*F92', 92, '2026-08-11 09:07:05', NULL),
	(62, 1, 'pengeluaran', NULL, 4, NULL, '4', 'Penggandaan fasilitas pelaporan (portofolio, hasil karya, foto berseri dll)', 2.00, 10.00, 2000.00, 40000.00, 0.00, 40000.00, 0.00, NULL, NULL, 93, '=D93*E93*F93', 93, '2026-08-11 09:07:05', NULL),
	(63, 1, 'pengeluaran', NULL, 4, NULL, '5', 'Laporan Perkembangan Murid, Tengah Semester', 2.00, 10.00, 3000.00, 60000.00, 0.00, 60000.00, 0.00, NULL, NULL, 94, '=D94*E94*F94', 94, '2026-08-11 09:07:05', NULL),
	(64, 1, 'pengeluaran', NULL, 4, NULL, '6', 'Laporan Perkembangan Murid, Akhir Semester ', 2.00, 10.00, 15000.00, 300000.00, 0.00, 300000.00, 0.00, NULL, NULL, 95, '=D95*E95*F95', 95, '2026-08-11 09:07:05', NULL),
	(65, 1, 'pengeluaran', NULL, 4, NULL, '7', 'Pembelian kertas E Raport', 1.00, 2.00, 160000.00, 320000.00, 0.00, 320000.00, 0.00, '=G96', NULL, 96, '=D96*E96*F96', 96, '2026-08-11 09:07:05', NULL),
	(66, 1, 'pengeluaran', NULL, 4, NULL, '8', 'kuota untuk documentasi', 12.00, 1.00, 10000.00, 120000.00, 0.00, 120000.00, 0.00, '=G97', NULL, 97, '=D97*E97*F97', 97, '2026-08-11 09:07:05', NULL),
	(67, 1, 'pengeluaran', NULL, 5, NULL, '1', 'Rapat Kerja Guru', 2.00, 1.00, 400000.00, 800000.00, 0.00, 800000.00, 0.00, '=G100', NULL, 100, '=D100*E100*F100', 100, '2026-08-11 09:07:05', NULL),
	(68, 1, 'pengeluaran', NULL, 5, NULL, '2', 'Rapat Koordinasi Guru', 6.00, 3.00, 15000.00, 270000.00, 0.00, 270000.00, 0.00, '=G101', NULL, 101, '=D101*E101*F101', 101, '2026-08-11 09:07:05', NULL),
	(69, 1, 'pengeluaran', NULL, 5, NULL, '3', 'Rapat Kepala Sekolah', 12.00, 1.00, 25000.00, 300000.00, 0.00, 300000.00, 0.00, '=G102', NULL, 102, '=D102*E102*F102', 102, '2026-08-11 09:07:05', NULL),
	(70, 1, 'pengeluaran', NULL, 5, NULL, '4', 'Penyelenggaraan parenting', 6.00, 10.00, 10000.00, 600000.00, 0.00, 600000.00, 0.00, NULL, NULL, 103, '=D103*E103*F103', 103, '2026-08-11 09:07:05', NULL),
	(71, 1, 'pengeluaran', NULL, 5, NULL, '5', 'penggandaan materi parenting', 6.00, 10.00, 1000.00, 60000.00, 0.00, 60000.00, 0.00, NULL, NULL, 104, '=D104*E104*F104', 104, '2026-08-11 09:07:05', NULL),
	(72, 1, 'pengeluaran', NULL, 5, NULL, '6', 'Penerimaan Murid Baru, Flyer MMT dll', 1.00, 2.00, 200000.00, 400000.00, 0.00, 400000.00, 0.00, '=G105', NULL, 105, '=D105*E105*F105', 105, '2026-08-11 09:07:05', NULL),
	(73, 1, 'pengeluaran', NULL, 5, NULL, '7', 'Akhirussanah/Karyawisata', 1.00, 1.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 106, '=D106*E106*F106', 106, '2026-08-11 09:07:05', NULL),
	(74, 1, 'pengeluaran', NULL, 5, NULL, '8', 'Tuan Rumah Pertemuan gugus', 1.00, 1.00, 300000.00, 300000.00, 0.00, 300000.00, 0.00, '=G107', NULL, 107, '=D107*E107*F107', 107, '2026-08-11 09:07:05', NULL),
	(75, 1, 'pengeluaran', NULL, 5, NULL, '9', 'Tuan Rumah pertemuan IGABA, Himpaudi', 1.00, 1.00, 300000.00, 300000.00, 0.00, 300000.00, 0.00, '=G108', NULL, 108, '=D108*E108*F108', 108, '2026-08-11 09:07:05', NULL),
	(76, 1, 'pengeluaran', NULL, 5, NULL, '10', 'Dansos', 12.00, 10.00, 5000.00, 600000.00, 0.00, 600000.00, 0.00, NULL, NULL, 109, '=D109*E109*F109', 109, '2026-08-11 09:07:05', NULL),
	(77, 1, 'pengeluaran', NULL, 6, NULL, '1', 'Gaji Pokok Guru', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 112, NULL, 112, '2026-08-11 09:07:05', NULL),
	(78, 1, 'pengeluaran', NULL, 6, NULL, NULL, 'TMT 0 - 1 Tahun', 12.00, 1.00, 200000.00, 2400000.00, 0.00, 2400000.00, 0.00, '=G113', NULL, 113, '=D113*E113*F113', 113, '2026-08-11 09:07:05', NULL),
	(79, 1, 'pengeluaran', NULL, 6, NULL, NULL, 'TMT 2 - 6 Tahun', 12.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 114, '=D114*E114*F114', 114, '2026-08-11 09:07:05', NULL),
	(80, 1, 'pengeluaran', NULL, 6, NULL, NULL, 'TMT 5 - 7 Tahun', 12.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 115, '=D115*E115*F115', 115, '2026-08-11 09:07:05', NULL),
	(81, 1, 'pengeluaran', NULL, 6, NULL, NULL, 'TMT 7 - keatas ', 12.00, 2.00, 925000.00, 22200000.00, 0.00, 22200000.00, 0.00, '=G116', NULL, 116, '=D116*E116*F116', 116, '2026-08-11 09:07:05', NULL),
	(82, 1, 'pengeluaran', NULL, 6, NULL, '2', 'Tunjangan', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 118, NULL, 118, '2026-08-11 09:07:05', NULL),
	(83, 1, 'pengeluaran', NULL, 6, NULL, NULL, '    Kepala Sekolah', 12.00, 1.00, 300000.00, 3600000.00, 0.00, 3600000.00, 0.00, '=G119', NULL, 119, '=D119*E119*F119', 119, '2026-08-11 09:07:05', NULL),
	(84, 1, 'pengeluaran', NULL, 6, NULL, NULL, '    Bendahara', 12.00, 1.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 120, '=D120*E120*F120', 120, '2026-08-11 09:07:05', NULL),
	(85, 1, 'pengeluaran', NULL, 6, NULL, NULL, '    Hari Raya ( Gaji Pokok )', 1.00, 1.00, 1125000.00, 1125000.00, 0.00, 1125000.00, 0.00, '=G121', NULL, 121, '=D121*E121*F121', 121, '2026-08-11 09:07:05', NULL),
	(86, 1, 'pengeluaran', NULL, 6, NULL, NULL, '    BPJS Ketenagakerjaan', 12.00, 1.00, 10000.00, 120000.00, 0.00, 120000.00, 0.00, '=G122', NULL, 122, '=D122*E122*F122', 122, '2026-08-11 09:07:05', NULL),
	(87, 1, 'pengeluaran', NULL, 6, NULL, '3', '    Operator sekolah', 12.00, 1.00, 100000.00, 1200000.00, 0.00, 1200000.00, 0.00, '=G123', NULL, 123, '=D123*E123*F123', 123, '2026-08-11 09:07:05', NULL),
	(88, 1, 'pengeluaran', NULL, 6, NULL, '4', '    Fungsional', 12.00, 2.00, 50000.00, 1200000.00, 0.00, 1200000.00, 0.00, '=G124', NULL, 124, '=D124*E124*F124', 124, '2026-08-11 09:07:05', NULL),
	(89, 1, 'pengeluaran', NULL, 6, NULL, '5', '    Wali kelas', 12.00, 1.00, 50000.00, 600000.00, 0.00, 600000.00, 0.00, '=G125', NULL, 125, '=D125*E125*F125', 125, '2026-08-11 09:07:05', NULL),
	(90, 1, 'pengeluaran', NULL, 6, NULL, '6', '    Pengasuh', 12.00, 1.00, 300000.00, 3600000.00, 0.00, 3600000.00, 0.00, '=G126', NULL, 126, '=D126*E126*F126', 126, '2026-08-11 09:07:05', NULL),
	(91, 1, 'pengeluaran', NULL, 6, NULL, '7', 'Honor guru ngaji', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 127, '=D127*E127*F127', 127, '2026-08-11 09:07:05', NULL),
	(92, 1, 'pengeluaran', NULL, 6, NULL, '8', 'Honor petugas kebersihan', 12.00, 1.00, 200000.00, 2400000.00, 0.00, 2400000.00, 0.00, '=G128', NULL, 128, '=D128*E128*F128', 128, '2026-08-11 09:07:05', NULL),
	(93, 1, 'pengeluaran', NULL, 6, NULL, '9', 'Pengurusan sampah', 12.00, 1.00, 50000.00, 600000.00, 0.00, 600000.00, 0.00, '=G129', NULL, 129, '=D129*E129*F129', 129, '2026-08-11 09:07:05', NULL),
	(94, 1, 'pengeluaran', NULL, 6, NULL, '10', 'Pengurusan Pajak', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 130, '=D130*E130*F130', 130, '2026-08-11 09:07:05', NULL),
	(95, 1, 'pengeluaran', NULL, 6, NULL, '11', 'Pengurusan Bank', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 131, '=D131*E131*F131', 131, '2026-08-11 09:07:05', NULL),
	(96, 1, 'pengeluaran', NULL, 6, NULL, '12', 'Seragam guru', 1.00, 3.00, 100000.00, 300000.00, 0.00, 300000.00, 0.00, '=G132', NULL, 132, '=D132*E132*F132', 132, '2026-08-11 09:07:05', NULL),
	(97, 1, 'pengeluaran', NULL, 6, NULL, '13', 'Air minum', 12.00, 3.00, 20000.00, 720000.00, 0.00, 720000.00, 0.00, '=G133', NULL, 133, '=D133*E133*F133', 133, '2026-08-11 09:07:05', NULL),
	(98, 1, 'pengeluaran', NULL, 6, NULL, '14', 'Listrik', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 134, NULL, 134, '2026-08-11 09:07:05', NULL),
	(99, 1, 'pengeluaran', NULL, 6, NULL, '15', 'Internet/Pulsa', 12.00, 1.00, 100000.00, 1200000.00, 0.00, 1200000.00, 0.00, '=G135', NULL, 135, '=D135*E135*F135', 135, '2026-08-11 09:07:05', NULL),
	(100, 1, 'pengeluaran', NULL, 6, NULL, '16', 'Iuran', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 136, '=D136*E136*F136', 136, '2026-08-11 09:07:05', NULL),
	(101, 1, 'pengeluaran', NULL, 6, NULL, NULL, 'Himpaudi', 12.00, 2.00, 20000.00, 480000.00, 0.00, 480000.00, 0.00, '=G137', NULL, 137, '=D137*E137*F137', 137, '2026-08-11 09:07:05', NULL),
	(102, 1, 'pengeluaran', NULL, 6, NULL, NULL, 'IGABA', 12.00, 2.00, 30000.00, 720000.00, 0.00, 720000.00, 0.00, '=G138', NULL, 138, '=D138*E138*F138', 138, '2026-08-11 09:07:05', NULL),
	(103, 1, 'pengeluaran', NULL, 6, NULL, NULL, 'PKG', 6.00, 1.00, 20000.00, 120000.00, 0.00, 120000.00, 0.00, '=G139', NULL, 139, '=D139*E139*F139', 139, '2026-08-11 09:07:05', NULL),
	(104, 1, 'pengeluaran', NULL, 6, NULL, NULL, 'KKG', 10.00, 1.00, 20000.00, 200000.00, 0.00, 200000.00, 0.00, '=G140', NULL, 140, '=D140*E140*F140', 140, '2026-08-11 09:07:05', NULL),
	(105, 1, 'pengeluaran', NULL, 6, NULL, '17', 'Organisasi ', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 142, NULL, 142, '2026-08-11 09:07:05', NULL),
	(106, 1, 'pengeluaran', NULL, 6, NULL, NULL, '    Dana Wajib Murid ke PDA', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 143, '=D143*E143*F143', 143, '2026-08-11 09:07:05', NULL),
	(107, 1, 'pengeluaran', NULL, 6, NULL, NULL, '    Dana Wajib Murid Baru  ke PDA', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 144, '=D144*E144*F144', 144, '2026-08-11 09:07:05', NULL),
	(108, 1, 'pengeluaran', NULL, 6, NULL, NULL, '    Muktamar', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 145, '=D145*E145*F145', 145, '2026-08-11 09:07:05', NULL),
	(109, 1, 'pengeluaran', NULL, 6, NULL, NULL, '    Taawun', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 146, '=D146*E146*F146', 146, '2026-08-11 09:07:05', NULL),
	(110, 1, 'pengeluaran', NULL, 6, NULL, NULL, 'PMI', 1.00, 2.00, 2000.00, 4000.00, 0.00, 4000.00, 0.00, '=G147', NULL, 147, '=D147*E147*F147', 147, '2026-08-11 09:07:05', NULL),
	(111, 1, 'pengeluaran', NULL, 6, NULL, NULL, 'Sosial Murid', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 148, '=D148*E148*F148', 148, '2026-08-11 09:07:05', NULL),
	(112, 1, 'pengeluaran', NULL, 6, NULL, NULL, 'Sosial Guru', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 149, '=D149*E149*F149', 149, '2026-08-11 09:07:05', NULL),
	(113, 1, 'pengeluaran', NULL, 6, NULL, '19', 'Investasi ', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 151, NULL, 151, '2026-08-11 09:07:05', NULL),
	(114, 1, 'pengeluaran', NULL, 6, NULL, NULL, '    Angsuran Lembaga Keuangan', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 152, '=D152*E152*F152', 152, '2026-08-11 09:07:05', NULL),
	(115, 1, 'pengeluaran', NULL, 6, NULL, NULL, '    Pengembangan Khusus Lembaga oleh Penyelenggara (PRA)', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 153, '=D153*E153*F153', 153, '2026-08-11 09:07:05', NULL),
	(116, 1, 'pengeluaran', NULL, 6, NULL, NULL, '    Pengembangan Umum Lembaga oleh Penyelenggara (PRA)', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 154, NULL, 154, '2026-08-11 09:07:05', NULL),
	(117, 1, 'pengeluaran', NULL, 7, NULL, '1', 'Penguatan Ideologis', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 157, '=D157*E157*F157', 157, '2026-08-11 09:07:05', NULL),
	(118, 1, 'pengeluaran', NULL, 7, NULL, '2', 'Workshop  Literasi Anak Usia Dini', 1.00, 1.00, 100000.00, 100000.00, 0.00, 100000.00, 0.00, '=G158', NULL, 158, '=D158*E158*F158', 158, '2026-08-11 09:07:05', NULL),
	(119, 1, 'pengeluaran', NULL, 7, NULL, '3', 'Workshop  Impementasi Pembelajaran mendalam', 1.00, 1.00, 100000.00, 100000.00, 0.00, 100000.00, 0.00, '=G159', NULL, 159, '=D159*E159*F159', 159, '2026-08-11 09:07:05', NULL),
	(120, 1, 'pengeluaran', NULL, 7, NULL, '4', 'IHT Kurikulum Aisyiyah', 1.00, 2.00, 110000.00, 220000.00, 0.00, 220000.00, 0.00, '=G160', NULL, 160, '=D160*E160*F160', 160, '2026-08-11 09:07:05', NULL),
	(121, 1, 'pengeluaran', NULL, 7, NULL, '5', 'IHT Pengembangan Modul ajar dan RPM', 1.00, 2.00, 50000.00, 100000.00, 0.00, 100000.00, 0.00, '=G161', NULL, 161, '=D161*E161*F161', 161, '2026-08-11 09:07:05', NULL),
	(122, 1, 'pengeluaran', NULL, 7, NULL, '7', 'Pelatihan  Excellent Service', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 163, '=D163*E163*F163', 163, '2026-08-11 09:07:05', NULL),
	(123, 1, 'pengeluaran', NULL, 7, NULL, '8', 'Program Tahfidz Guru', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 164, '=D164*E164*F164', 164, '2026-08-11 09:07:05', NULL),
	(124, 1, 'pengeluaran', NULL, 7, NULL, '9', 'Pembinaan PCA', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 165, '=D165*E165*F165', 165, '2026-08-11 09:07:05', NULL),
	(125, 1, 'pengeluaran', NULL, 7, NULL, '10', 'Studi Banding/Piknik', 1.00, 2.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 166, '=D166*E166*F166', 166, '2026-08-11 09:07:05', NULL),
	(126, 1, 'pengeluaran', NULL, 7, NULL, '11', 'Evaluasi Qirao\'ati dari korcab', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 167, '=D167*E167*F167', 167, '2026-08-11 09:07:05', NULL),
	(127, 1, 'pengeluaran', NULL, 8, NULL, '1', 'Paket Seragam', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 170, NULL, 170, '2026-08-11 09:07:05', NULL),
	(128, 1, 'pengeluaran', NULL, 8, NULL, NULL, '    Murid laki-laki', 1.00, 5.00, 225000.00, 1125000.00, 0.00, 1125000.00, 0.00, NULL, NULL, 171, '=D171*E171*F171', 171, '2026-08-11 09:07:05', NULL),
	(129, 1, 'pengeluaran', NULL, 8, NULL, NULL, '    Perempuan', 1.00, 5.00, 225000.00, 1125000.00, 0.00, 1125000.00, 0.00, NULL, NULL, 172, '=D172*E172*F172', 172, '2026-08-11 09:07:05', NULL),
	(130, 1, 'pengeluaran', NULL, 8, NULL, '2', 'Perlengkapan Aransi Kelas', 1.00, 6.00, 100000.00, 600000.00, 0.00, 600000.00, 0.00, '=G173', NULL, 173, '=D173*E173*F173', 173, '2026-08-11 09:07:05', NULL),
	(131, 1, 'pengeluaran', NULL, 8, NULL, '3', 'ATK Guru', 12.00, 3.00, 10000.00, 360000.00, 0.00, 360000.00, 0.00, '=G174', NULL, 174, '=D174*E174*F174', 174, '2026-08-11 09:07:05', NULL),
	(132, 1, 'pengeluaran', NULL, 8, NULL, '4', 'P3K', 1.00, 6.00, 10000.00, 60000.00, 0.00, 60000.00, 0.00, '=G175', NULL, 175, '=D175*E175*F175', 175, '2026-08-11 09:07:05', NULL),
	(133, 1, 'pengeluaran', NULL, 8, NULL, '5', 'Baterai Mic, jam dll', 6.00, 1.00, 15000.00, 90000.00, 0.00, 90000.00, 0.00, '=G176', NULL, 176, '=D176*E176*F176', 176, '2026-08-11 09:07:05', NULL),
	(134, 1, 'pengeluaran', NULL, 8, NULL, '6', 'Laptop', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 177, '=D177*E177*F177', 177, '2026-08-11 09:07:05', NULL),
	(135, 1, 'pengeluaran', NULL, 8, NULL, '7', 'Meja Plastik', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 178, '=D178*E178*F178', 178, '2026-08-11 09:07:05', NULL),
	(136, 1, 'pengeluaran', NULL, 8, NULL, '8', 'Buku Referensi Kurikulum Aisyiyah', 1.00, 3.00, 55000.00, 165000.00, 0.00, 165000.00, 0.00, '=G179', NULL, 179, '=D179*E179*F179', 179, '2026-08-11 09:07:05', NULL),
	(137, 1, 'pengeluaran', NULL, 8, NULL, '9', 'Produk Literasi Topik AIKA', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 180, NULL, 180, '2026-08-11 09:07:05', NULL),
	(138, 1, 'pengeluaran', NULL, 8, NULL, NULL, '    Pencetakan buku ACA', 1.00, 10.00, 120000.00, 1200000.00, 0.00, 1200000.00, 0.00, NULL, NULL, 181, '=D181*E181*F181', 181, '2026-08-11 09:07:05', NULL),
	(139, 1, 'pengeluaran', NULL, 8, NULL, NULL, '    Pencetakan buku karya murid', 1.00, 10.00, 25000.00, 250000.00, 0.00, 250000.00, 0.00, NULL, NULL, 182, '=D182*E182*F182', 182, '2026-08-11 09:07:05', NULL),
	(140, 1, 'pengeluaran', NULL, 8, NULL, NULL, '    Pencetakan Buku 7 kebiasaan anak indonesia hebat', 1.00, 10.00, 13500.00, 135000.00, 0.00, 135000.00, 0.00, NULL, NULL, 183, '=D183*E183*F183', 183, '2026-08-11 09:07:05', NULL),
	(141, 1, 'pengeluaran', NULL, 8, NULL, NULL, '    Buku DDTK', 1.00, 10.00, 15000.00, 150000.00, 0.00, 150000.00, 0.00, NULL, NULL, 184, '=D184*E184*F184', 184, '2026-08-11 09:07:05', NULL),
	(142, 1, 'pengeluaran', NULL, 8, NULL, NULL, '    Panduan KeAisy/KeMuh Tarjih', 1.00, 10.00, 150000.00, 1500000.00, 0.00, 1500000.00, 0.00, NULL, NULL, 185, '=D185*E185*F185', 185, '2026-08-11 09:07:05', NULL),
	(143, 1, 'pengeluaran', NULL, 8, NULL, NULL, '    Pencetakan ', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, NULL, 186, '=D186*E186*F186', 186, '2026-08-11 09:07:05', NULL),
	(144, 1, 'pengeluaran', NULL, 8, NULL, '10', 'Pemasangan Kanopi baja ringan', 1.00, 1.00, 2000000.00, 2000000.00, 0.00, 2000000.00, 0.00, '=G187', NULL, 187, '=D187*E187*F187', 187, '2026-08-11 09:07:05', NULL);

-- membuang struktur untuk table rapbs_ci3.income_categories
CREATE TABLE IF NOT EXISTS `income_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(30) NOT NULL,
  `name` varchar(150) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Membuang data untuk tabel rapbs_ci3.income_categories: ~6 rows (lebih kurang)
INSERT INTO `income_categories` (`id`, `code`, `name`, `sort_order`, `active`) VALUES
	(1, '1', 'Uang Pengembangan', 1, 1),
	(2, '2', 'Uang SPP', 2, 1),
	(3, '3', 'Uang BOP', 3, 1),
	(4, '4', 'Uang PMB', 4, 1),
	(5, '5', 'Uang Pembelian Produk PP', 5, 1),
	(6, '6', 'Uang Infaq', 6, 1);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
