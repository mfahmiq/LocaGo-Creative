<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class CreateAdminUser extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:name';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        try {
            $u = new \App\Models\User;
            $u->name = 'Admin';
            $u->email = 'admin@example.com';
            $u->password = \Illuminate\Support\Facades\Hash::make('password');
            $u->usertype = '1';
            $u->phone = '1234567890';
            $u->save();
            $this->info('Admin created successfully!');
        } catch (\Exception $e) {
            $this->error('Failed to create admin: ' . $e->getMessage());
        }
        return 0;
    }
}
