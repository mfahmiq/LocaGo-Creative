$u = new App\Models\User;
$u->name = 'Admin';
$u->email = 'admin@example.com';
$u->password = Hash::make('password');
$u->usertype = '1';
$u->phone = '1234567890';
$u->save();
echo "Admin created successfully!";

$u = new App\Models\User;
$u->name = 'Mohammad Raza';
$u->email = 'mdraza7586@gmail.com';
$u->password = Hash::make('mdraza7586');
$u->usertype = '2';
$u->phone = '1664631685';
$u->save();

echo "User created successfully!";