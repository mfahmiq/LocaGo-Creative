# Warehouse & Inventory Management System - Part Db Server

```
========================================================================
📦 Warehouse & Inventory Management System - Part Db Server
Kategori     : Bisnis & Manajemen
Tech Stack   : PHP Native • PHP • MySQL • Bootstrap
Database     : MySQL (.sql) (File: .github/assets/legacy_import/db_jbtronics.sql)
Sumber Asli  : https://github.com/Part-DB/Part-DB-server (GitHub Open Source)
Stars GitHub : ⭐ 1848 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/part-db-server`
     * Untuk Laragon: `C:/laragon/www/part-db-server`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `part_db_server`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `.github/assets/legacy_import/db_jbtronics.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = part_db_server

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/part-db-server

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
