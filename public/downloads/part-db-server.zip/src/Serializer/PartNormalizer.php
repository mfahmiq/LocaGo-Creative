<?php

declare(strict_types=1);

/*
 * This file is part of Part-DB (https://github.com/Part-DB/Part-DB-symfony).
 *
 *  Copyright (C) 2019 - 2023 Jan Böhmer (https://github.com/jbtronics)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
namespace App\Serializer;

use App\Entity\Parts\Part;
use App\Entity\Parts\PartLot;
use App\Entity\Parts\StorageLocation;
use App\Entity\Parts\Supplier;
use App\Entity\PriceInformations\Orderdetail;
use App\Entity\PriceInformations\Pricedetail;
use Brick\Math\BigDecimal;
use Symfony\Component\DependencyInjection\Attribute\AutoconfigureTag;
use Symfony\Component\Serializer\Normalizer\DenormalizerAwareInterface;
use Symfony\Component\Serializer\Normalizer\DenormalizerAwareTrait;
use Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use Symfony\Component\Serializer\Normalizer\NormalizerAwareInterface;
use Symfony\Component\Serializer\Normalizer\NormalizerAwareTrait;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;

/**
 * @see \App\Tests\Serializer\PartNormalizerTest
 */
// '*' makes this available to every named serializer (default, import_export, ...), not just the default one.
#[AutoconfigureTag('serializer.normalizer', ['serializer' => ['*']])]
class PartNormalizer implements NormalizerInterface, DenormalizerInterface, NormalizerAwareInterface, DenormalizerAwareInterface
{

    use NormalizerAwareTrait;
    use DenormalizerAwareTrait;

    private const ALREADY_CALLED = 'PART_NORMALIZER_ALREADY_CALLED';

    private const DENORMALIZE_KEY_MAPPING = [
        'notes' => 'comment',
        'quantity' => 'instock',
        'amount' => 'instock',
        'mpn' => 'manufacturer_product_number',
        'spn' => 'supplier_part_number',
        'supplier_product_number' => 'supplier_part_number',
        'storage_location' => 'storelocation',
        //EDA/KiCad field aliases
        'kicad_symbol' => 'eda_kicad_symbol',
        'kicad_footprint' => 'eda_kicad_footprint',
        'kicad_reference' => 'eda_reference_prefix',
        'kicad_value' => 'eda_value',
        'eda_exclude_bom' => 'eda_exclude_from_bom',
        'eda_exclude_board' => 'eda_exclude_from_board',
        'eda_exclude_sim' => 'eda_exclude_from_sim',
        //NOTE: "eda_invisible" is intentionally NOT mapped here: it is the *inverse* of
        //"eda_visibility", so a plain key rename would store the wrong value. It is handled
        //(and inverted) explicitly in applyEdaFields().
    ];

    public function __construct(
        private readonly StructuralElementFromNameDenormalizer $locationDenormalizer,
    )
    {
    }

    public function supportsNormalization($data, ?string $format = null, array $context = []): bool
    {
        //We only remove the type field for CSV export
        return !isset($context[self::ALREADY_CALLED]) && $format === 'csv' && $data instanceof Part ;
    }

    public function normalize($object, ?string $format = null, array $context = []): array
    {
        if (!$object instanceof Part) {
            throw new \InvalidArgumentException('This normalizer only supports Part objects!');
        }

        $context[self::ALREADY_CALLED] = true;

        //Prevent exception in API Platform
        if ($object->getID() === null) {
            $context['iri'] = 'not-persisted';
        }

        $data = $this->normalizer->normalize($object, $format, $context);

        //Remove type field for CSV export
        if ($format === 'csv') {
            unset($data['type']);
        }

        return $data;
    }

    public function supportsDenormalization($data, string $type, ?string $format = null, array $context = []): bool
    {
        //Only denormalize if we are doing a file import operation
        if (!($context['partdb_import'] ?? false)) {
            return false;
        }

        //Only make the denormalizer available on import operations
        return !isset($context[self::ALREADY_CALLED])
            && is_array($data) && is_a($type, Part::class, true);
    }

    private function normalizeKeys(array &$data): array
    {
        //Rename keys based on the mapping, while leaving the data untouched
        foreach ($data as $key => $value) {
            if (isset(self::DENORMALIZE_KEY_MAPPING[$key])) {
                $data[self::DENORMALIZE_KEY_MAPPING[$key]] = $value;
                unset($data[$key]);
            }
        }

        return $data;
    }

    public function denormalize($data, string $type, ?string $format = null, array $context = []): ?Part
    {
        $this->normalizeKeys($data);

        //Empty IPN should be null, or we get a constraint error
        if (isset($data['ipn']) && $data['ipn'] === '') {
            $data['ipn'] = null;
        }

        //Fill empty needs_review and needs_review_comment fields with false
        if (empty($data['needs_review'])) {
            $data['needs_review'] = false;
        }
        if (empty($data['favorite'])) {
            $data['favorite'] = false;
        }
        if (empty($data['minamount'])) {
            $data['minamount'] = 0.0;
        }

        $context[self::ALREADY_CALLED] = true;

        $object = $this->denormalizer->denormalize($data, $type, $format, $context);

        if (!$object instanceof Part) {
            throw new \InvalidArgumentException('This normalizer only supports Part objects!');
        }

        if ((isset($data['instock']) && trim((string) $data['instock']) !== "") || (isset($data['storelocation']) && trim((string) $data['storelocation']) !== "")) {
            $partLot = new PartLot();

            if (isset($data['instock']) && $data['instock'] !== "") {
                //Replace comma with dot
                $instock = (float) str_replace(',', '.', (string) $data['instock']);

                $partLot->setAmount($instock);
            } else {
                $partLot->setInstockUnknown(true);
            }

            if (isset($data['storelocation']) && $data['storelocation'] !== "") {
                $location = $this->locationDenormalizer->denormalize($data['storelocation'], StorageLocation::class, $format, $context);
                $partLot->setStorageLocation($location);
            }

            $object->addPartLot($partLot);
        }

        if (isset($data['supplier']) && $data['supplier'] !== "") {
            $supplier = $this->locationDenormalizer->denormalize($data['supplier'], Supplier::class, $format, $context);

            if ($supplier !== null) {
                $orderdetail = new Orderdetail();
                $orderdetail->setSupplier($supplier);

                if (isset($data['supplier_part_number']) && $data['supplier_part_number'] !== "") {
                    $orderdetail->setSupplierpartnr($data['supplier_part_number']);
                }

                $object->addOrderdetail($orderdetail);

                if (isset($data['price']) && $data['price'] !== "") {
                    $pricedetail = new Pricedetail();
                    $pricedetail->setMinDiscountQuantity(1);
                    $pricedetail->setPriceRelatedQuantity(1);
                    $price = BigDecimal::of(str_replace(',', '.', (string) $data['price']));
                    $pricedetail->setPrice($price);

                    $orderdetail->addPricedetail($pricedetail);
                }
            }
        }

        //Handle EDA/KiCad fields
        $this->applyEdaFields($object, $data);

        return $object;
    }

    /**
     * Apply EDA/KiCad fields from CSV data to the Part's EDAPartInfo.
     */
    private function applyEdaFields(Part $part, array $data): void
    {
        $edaInfo = $part->getEdaInfo();

        if (!empty($data['eda_kicad_symbol'])) {
            $edaInfo->setKicadSymbol(trim((string) $data['eda_kicad_symbol']));
        }
        if (!empty($data['eda_kicad_footprint'])) {
            $edaInfo->setKicadFootprint(trim((string) $data['eda_kicad_footprint']));
        }
        if (!empty($data['eda_reference_prefix'])) {
            $edaInfo->setReferencePrefix(trim((string) $data['eda_reference_prefix']));
        }
        if (!empty($data['eda_value'])) {
            $edaInfo->setValue(trim((string) $data['eda_value']));
        }
        if (isset($data['eda_exclude_from_bom']) && $data['eda_exclude_from_bom'] !== '') {
            $edaInfo->setExcludeFromBom(filter_var($data['eda_exclude_from_bom'], FILTER_VALIDATE_BOOLEAN));
        }
        if (isset($data['eda_exclude_from_board']) && $data['eda_exclude_from_board'] !== '') {
            $edaInfo->setExcludeFromBoard(filter_var($data['eda_exclude_from_board'], FILTER_VALIDATE_BOOLEAN));
        }
        if (isset($data['eda_exclude_from_sim']) && $data['eda_exclude_from_sim'] !== '') {
            $edaInfo->setExcludeFromSim(filter_var($data['eda_exclude_from_sim'], FILTER_VALIDATE_BOOLEAN));
        }
        if (isset($data['eda_visibility']) && $data['eda_visibility'] !== '') {
            $edaInfo->setVisibility(filter_var($data['eda_visibility'], FILTER_VALIDATE_BOOLEAN));
        } elseif (isset($data['eda_invisible']) && $data['eda_invisible'] !== '') {
            //"eda_invisible" is the inverse convenience alias of "eda_visibility"
            $edaInfo->setVisibility(!filter_var($data['eda_invisible'], FILTER_VALIDATE_BOOLEAN));
        }
    }

    /**
     * @return bool[]
     */
    public function getSupportedTypes(?string $format): array
    {
        //Must be false, because we rely on is_array($data) in supportsDenormalization()
        return [
            Part::class => false,
        ];
    }
}
