<?php
/**
 * This file is part of Part-DB (https://github.com/Part-DB/Part-DB-symfony).
 *
 * Copyright (C) 2019 - 2022 Jan Böhmer (https://github.com/jbtronics)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

declare(strict_types=1);

namespace App\Entity\Parts;

use ApiPlatform\Doctrine\Common\Filter\DateFilterInterface;
use ApiPlatform\Doctrine\Orm\Filter\BooleanFilter;
use ApiPlatform\Doctrine\Orm\Filter\DateFilter;
use ApiPlatform\Doctrine\Orm\Filter\OrderFilter;
use ApiPlatform\Doctrine\Orm\Filter\RangeFilter;
use ApiPlatform\Metadata\ApiFilter;
use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Delete;
use ApiPlatform\Metadata\Get;
use ApiPlatform\Metadata\GetCollection;
use ApiPlatform\Metadata\McpTool;
use ApiPlatform\Metadata\McpToolCollection;
use ApiPlatform\Metadata\Patch;
use ApiPlatform\Metadata\Post;
use ApiPlatform\Serializer\Filter\PropertyFilter;
use App\ApiPlatform\Filter\EntityFilter;
use App\ApiPlatform\Filter\LikeFilter;
use App\ApiPlatform\Filter\PartStoragelocationFilter;
use App\ApiPlatform\Filter\TagFilter;
use App\DataTables\Filters\PartSearchFilter;
use App\Entity\Attachments\Attachment;
use App\Entity\Attachments\AttachmentContainingDBElement;
use App\Entity\Attachments\PartAttachment;
use App\Entity\EDA\EDAPartInfo;
use App\Entity\InfoProviderSystem\BulkInfoProviderImportJobPart;
use App\Entity\Parameters\ParametersTrait;
use App\Entity\Parameters\PartParameter;
use App\Entity\Parts\PartTraits\AdvancedPropertyTrait;
use App\Entity\Parts\PartTraits\AssociationTrait;
use App\Entity\Parts\PartTraits\BasicPropertyTrait;
use App\Entity\Parts\PartTraits\EDATrait;
use App\Entity\Parts\PartTraits\InstockTrait;
use App\Entity\Parts\PartTraits\ManufacturerTrait;
use App\Entity\Parts\PartTraits\OrderTrait;
use App\Entity\Parts\PartTraits\ProjectTrait;
use App\EntityListeners\TreeCacheInvalidationListener;
use App\Mcp\DTO\AddPartStockInput;
use App\Mcp\DTO\AdvancedPartSearchInput;
use App\Mcp\DTO\CreatePartInput;
use App\Mcp\DTO\DeletePartInput;
use App\Mcp\DTO\ElementByIdInput;
use App\Mcp\DTO\StocktakePartLotInput;
use App\Mcp\DTO\UpdatePartInput;
use App\Mcp\DTO\WithdrawPartStockInput;
use App\Repository\PartRepository;
use App\State\Mcp\AddPartStockProcessor;
use App\State\Mcp\AdvancedPartSearchInputProvider;
use App\State\Mcp\AdvancedSearchPartsProcessor;
use App\State\Mcp\CreatePartInputProvider;
use App\State\Mcp\CreatePartProcessor;
use App\State\Mcp\DeletePartProcessor;
use App\State\Mcp\GetPartByIdProcessor;
use App\State\Mcp\GetPartPreviewImageProcessor;
use App\State\Mcp\SearchPartsProcessor;
use App\State\Mcp\StocktakePartLotProcessor;
use App\State\Mcp\UpdatePartInputProvider;
use App\State\Mcp\UpdatePartProcessor;
use App\State\Mcp\WithdrawPartStockProcessor;
use App\Validator\Constraints\UniqueObjectCollection;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use SortDirection;
use Symfony\Component\Serializer\Attribute\Groups;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

/**
 * Part class.
 *
 * The class properties are split over various traits in directory PartTraits.
 * Otherwise, this class would be too big, to be maintained.
 * @see \App\Tests\Entity\Parts\PartTest
 * @extends AttachmentContainingDBElement<PartAttachment>
 * @template-use ParametersTrait<PartParameter>
 */
#[ORM\Entity(repositoryClass: PartRepository::class)]
#[ORM\EntityListeners([TreeCacheInvalidationListener::class])]
#[ORM\Table('`parts`')]
#[ORM\Index(name: 'parts_idx_datet_name_last_id_needs', columns: ['datetime_added', 'name', 'last_modified', 'id', 'needs_review'])]
#[ORM\Index(name: 'parts_idx_name', columns: ['name'])]
#[ORM\Index(name: 'parts_idx_ipn', columns: ['ipn'])]
#[ORM\Index(name: 'parts_idx_gtin', columns: ['gtin'])]
#[ApiResource(
    operations: [
        new Get(normalizationContext: [
            'groups' => [
                'part:read',
                'provider_reference:read',
                'api:basic:read',
                'part_lot:read',
                'orderdetail:read',
                'pricedetail:read',
                'parameter:read',
                'attachment:read',
                'eda_info:read'
            ],
            'openapi_definition_name' => 'Read',
        ], security: 'is_granted("read", object)'),
        new GetCollection(security: 'is_granted("@parts.read")'),
        new Post(securityPostDenormalize: 'is_granted("create", object)'),
        new Patch(security: 'is_granted("edit", object)'),
        new Delete(security: 'is_granted("delete", object)'),
    ],
    normalizationContext: ['groups' => ['part:read', 'provider_reference:read', 'api:basic:read', 'part_lot:read'], 'openapi_definition_name' => 'Read'],
    denormalizationContext: ['groups' => ['part:write', 'api:basic:write', 'eda_info:write', 'attachment:write', 'parameter:write'], 'openapi_definition_name' => 'Write'],
    mcp: [
        'search_parts' => new McpToolCollection(
            title: "Search parts by keyword",
            description: 'Search for parts',
            annotations: ['readOnlyHint' => true, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => false],
            security: 'is_granted("@parts.read")',
            input: PartSearchFilter::class,
            processor: SearchPartsProcessor::class
        ),
        'advanced_search_parts' => new McpToolCollection(
            title: 'Advanced part search with structured filters',
            description: 'Search for parts using precise, structured filter criteria instead of a single free-text keyword (see search_parts for that). Every argument is optional and, if given, narrows the results further (all given constraints are combined with AND). Supports text fields (name, description, comment, ipn, gtin, manufacturer product number/url, stock lot description, attachment name) with operators like CONTAINS/STARTS/ENDS/=/!=; numeric fields (minAmount, mass, total stock amount, lot/orderdetails/attachments/parameters count) with </=/>=/BETWEEN; date fields (lastModified, addedDate, lot expiration date); booleans (favorite, needsReview, obsolete, lessThanDesired, lot needs refill/unknown amount); tags (ANY/ALL/NONE of a given list); manufacturing status (ANY/NONE of announced/active/nrfnd/eol/discontinued); relations by database ID (category, footprint, manufacturer, storage location, supplier, measurement unit, part custom state, attachment type, project), which for hierarchical relations also support INCLUDING_CHILDREN/EXCLUDING_CHILDREN to match an entire subtree; and a list of parameter constraints (each part must have at least one parameter matching all of a given entry\'s name/symbol/unit and numeric/text value comparison). Results can be sorted (orderBy/orderDirection) and are capped at "limit" (default 50, max 200).',
            annotations: ['readOnlyHint' => true, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => false],
            security: 'is_granted("@parts.read")',
            input: AdvancedPartSearchInput::class,
            provider: AdvancedPartSearchInputProvider::class,
            validate: false, // The nested per-field filter objects are barely-constrained; invalid operators/values are rejected manually inside AdvancedSearchPartsProcessor
            processor: AdvancedSearchPartsProcessor::class
        ),
        'get_part_details' => new McpTool(
            title: 'Get part details by ID',
            description: 'Get detailed information about a specific part by its database ID',
            annotations: ['readOnlyHint' => true, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => false],
            normalizationContext: [
                'groups' => ['part:read', 'provider_reference:read', 'api:basic:read', 'part_lot:read', 'orderdetail:read', 'pricedetail:read', 'parameter:read', 'attachment:read', 'eda_info:read'],
                'item_uri_template' => '/api/parts/{id}',
            ],
            security: 'is_granted("@parts.read")',
            input: ElementByIdInput::class,
            validate: true,
            processor: GetPartByIdProcessor::class
        ),
        'get_part_preview_image' => new McpTool(
            title: 'Get preview image for a part',
            description: 'Get the preview/thumbnail picture for a part by its database ID. Reuses the same fallback logic as the part list in the web UI: the part\'s own master picture is used if set, otherwise the picture of its footprint, and otherwise the picture of the project it is built from. Returns a short text message instead of an image if no preview picture is available.',
            structuredContent: false,
            annotations: ['readOnlyHint' => true, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => false],
            security: 'is_granted("@parts.read")',
            //The processor returns raw MCP content blocks (image/text) via a CallToolResult, not a normalized
            //representation of the Part resource, so no output schema must be advertised (otherwise MCP clients
            //reject the response for declaring a schema but returning no structuredContent).
            input: ElementByIdInput::class,
            validate: true,
            processor: GetPartPreviewImageProcessor::class
        ),
        'create_part' => new McpTool(
            title: 'Create a new part',
            description: 'Create a new part in the inventory. Only "name" is required; every other field is optional and, if omitted, the part is created with its normal default value for that field. Supports nested stock lots, parameters, orderdetails (with price breaks), associated parts, EDA info, and linking the part to the external info provider (providerKey/providerId/providerUrl) it was sourced from in a single call. Attachment file uploads are not supported here (MCP has no good way to transport binary file data) - use the web UI or REST API to upload attachments to a part after creating it.',
            annotations: ['readOnlyHint' => false, 'destructiveHint' => false, 'idempotentHint' => false, 'openWorldHint' => false],
            normalizationContext: [
                'groups' => ['part:read', 'provider_reference:read', 'api:basic:read', 'part_lot:read', 'orderdetail:read', 'pricedetail:read', 'parameter:read', 'attachment:read', 'eda_info:read'],
                'item_uri_template' => '/api/parts/{id}',
            ], // Not enforced by the MCP call pipeline (see notes on CreatePartProcessor) - the real check is manual, inside the processor. Kept for documentation/forward-compat.
            security: 'is_granted("@parts.create")',
            input: CreatePartInput::class,
            validate: false,
            provider: CreatePartInputProvider::class, // Entity validation is done manually in CreatePartProcessor, not on the (barely-constrained) input DTO
            processor: CreatePartProcessor::class
        ),
        'update_part' => new McpTool(
            title: 'Update an existing part',
            description: 'Update an existing part by its database ID. Only the fields you actually provide are changed; any field you omit is left completely untouched, including nested collections (partLots, parameters, orderdetails, associatedPartsAsOwner) - provide an item\'s "id" to update it, omit "id" to create a new one, and omit a previously-existing item entirely to remove it. To change a lot\'s stock amount use the withdraw_part_stock/add_part_stock/stocktake_part_lot tools instead - "amount" may only be set here when creating a brand-new lot. providerKey/providerId can be used to link or unlink the part to an external info provider (set both to link, both to null to unlink - they must be changed together).',
            annotations: ['readOnlyHint' => false, 'destructiveHint' => false, 'idempotentHint' => false, 'openWorldHint' => false],
            normalizationContext: [
                'groups' => ['part:read', 'provider_reference:read', 'api:basic:read', 'part_lot:read', 'orderdetail:read', 'pricedetail:read', 'parameter:read', 'attachment:read', 'eda_info:read'],
                'item_uri_template' => '/api/parts/{id}',
            ], // Not enforced by the MCP call pipeline - see create_part's note; the real check is manual, inside UpdatePartProcessor.
            security: 'is_granted("@parts.edit")',
            input: UpdatePartInput::class,
            validate: false,
            provider: UpdatePartInputProvider::class, // Entity validation is done manually in UpdatePartProcessor, not on the (barely-constrained) input DTO
            processor: UpdatePartProcessor::class
        ),
        'delete_part' => new McpTool(
            title: 'Delete a part',
            description: 'Permanently delete a part by its database ID, including its stock lots, parameters, orderdetails and associations. This cannot be undone - there is no confirmation step, so make sure this is really the part the user wants deleted before calling this tool.',
            structuredContent: false,
            annotations: ['readOnlyHint' => false, 'destructiveHint' => true, 'idempotentHint' => true, 'openWorldHint' => false], // Not enforced by the MCP call pipeline - see create_part's note; the real check is manual, inside DeletePartProcessor.
            security: 'is_granted("@parts.delete")', // The processor returns a plain text confirmation via CallToolResult, not a normalized Part (which no longer exists)
            input: DeletePartInput::class,
            validate: true,
            processor: DeletePartProcessor::class
        ),
        'withdraw_part_stock' => new McpTool(
            title: 'Withdraw stock from a part lot',
            description: 'Withdraw (remove) a given amount of stock from a part lot by its database ID, e.g. because parts were used up. Returns the updated part.',
            annotations: ['readOnlyHint' => false, 'destructiveHint' => true, 'idempotentHint' => false, 'openWorldHint' => false],
            normalizationContext: [
                'groups' => ['part:read', 'provider_reference:read', 'api:basic:read', 'part_lot:read', 'orderdetail:read', 'pricedetail:read', 'parameter:read', 'attachment:read', 'eda_info:read'],
                'item_uri_template' => '/api/parts/{id}',
            ],
            security: 'is_granted("@parts_stock.withdraw")',
            input: WithdrawPartStockInput::class,
            validate: true,
            processor: WithdrawPartStockProcessor::class
        ),
        'add_part_stock' => new McpTool(
            title: 'Add stock to a part lot',
            description: 'Add a given amount of stock to a part lot by its database ID, e.g. because new parts arrived. Returns the updated part.',
            annotations: ['readOnlyHint' => false, 'destructiveHint' => false, 'idempotentHint' => false, 'openWorldHint' => false],
            normalizationContext: [
                'groups' => ['part:read', 'provider_reference:read', 'api:basic:read', 'part_lot:read', 'orderdetail:read', 'pricedetail:read', 'parameter:read', 'attachment:read', 'eda_info:read'],
                'item_uri_template' => '/api/parts/{id}',
            ],
            security: 'is_granted("@parts_stock.add")',
            input: AddPartStockInput::class,
            validate: true,
            processor: AddPartStockProcessor::class
        ),
        'stocktake_part_lot' => new McpTool(
            title: 'Perform a stocktake on a part lot',
            description: 'Set a part lot\'s stock to a known actual amount (a "stocktake"/inventory count), clearing its unknown-instock flag if set. Returns the updated part.',
            annotations: ['readOnlyHint' => false, 'destructiveHint' => true, 'idempotentHint' => true, 'openWorldHint' => false],
            normalizationContext: [
                'groups' => ['part:read', 'provider_reference:read', 'api:basic:read', 'part_lot:read', 'orderdetail:read', 'pricedetail:read', 'parameter:read', 'attachment:read', 'eda_info:read'],
                'item_uri_template' => '/api/parts/{id}',
            ],
            security: 'is_granted("@parts_stock.stocktake")',
            input: StocktakePartLotInput::class,
            validate: true,
            processor: StocktakePartLotProcessor::class
        ),
    ],
)]
#[ApiFilter(PropertyFilter::class)]
#[ApiFilter(EntityFilter::class, properties: ["category", "footprint", "manufacturer", "partUnit", "partCustomState"])]
#[ApiFilter(PartStoragelocationFilter::class, properties: ["storage_location"])]
#[ApiFilter(LikeFilter::class, properties: ["name", "comment", "description", "ipn", "manufacturer_product_number"])]
#[ApiFilter(TagFilter::class, properties: ["tags"])]
#[ApiFilter(BooleanFilter::class, properties: ["favorite", "needs_review"])]
#[ApiFilter(RangeFilter::class, properties: ["mass", "minamount"])]
#[ApiFilter(DateFilter::class, strategy: DateFilterInterface::EXCLUDE_NULL)]
#[ApiFilter(OrderFilter::class, properties: ['name', 'id', 'addedDate', 'lastModified'])]
class Part extends AttachmentContainingDBElement
{
    use AdvancedPropertyTrait;
    //use MasterAttachmentTrait;
    use BasicPropertyTrait;
    use InstockTrait;
    use ManufacturerTrait;
    use OrderTrait;
    use ParametersTrait;
    use ProjectTrait;
    use AssociationTrait;
    use EDATrait;

    /** @var Collection<int, PartParameter>
     */
    #[Assert\Valid]
    #[Groups(['full', 'part:read', 'part:write', 'import'])]
    #[ORM\OneToMany(targetEntity: PartParameter::class, mappedBy: 'element', cascade: ['persist', 'remove'], orphanRemoval: true)]
    #[ORM\OrderBy(['group' => SortDirection::Ascending, 'name' => SortDirection::Ascending])]
    #[UniqueObjectCollection(fields: ['name', 'group', 'element'])]
    protected Collection $parameters;


    /** *************************************************************
     * Overridden properties
     * (They are defined here and not in a trait, to avoid conflicts).
     ****************************************************************/

    /**
     * @var string The name of this part
     */
    protected string $name = '';

    /**
     * @var Collection<int, PartAttachment>
     */
    #[Assert\Valid]
    #[Groups(['full', 'part:read', 'part:write'])]
    #[ORM\OneToMany(targetEntity: PartAttachment::class, mappedBy: 'element', cascade: ['persist', 'remove'], orphanRemoval: true)]
    #[ORM\OrderBy(['name' => SortDirection::Ascending])]
    protected Collection $attachments;

    /**
     * @var Attachment|null
     */
    #[Assert\Expression('value == null or value.isPicture()', message: 'part.master_attachment.must_be_picture')]
    #[ORM\ManyToOne(targetEntity: PartAttachment::class)]
    #[ORM\JoinColumn(name: 'id_preview_attachment', onDelete: 'SET NULL')]
    #[Groups(['part:read', 'part:write'])]
    protected ?Attachment $master_picture_attachment = null;

    #[Groups(['part:read'])]
    protected ?\DateTimeImmutable $addedDate = null;
    #[Groups(['part:read'])]
    protected ?\DateTimeImmutable $lastModified = null;

    /**
     * @var Collection<int, BulkInfoProviderImportJobPart>
     */
    #[ORM\OneToMany(targetEntity: BulkInfoProviderImportJobPart::class, mappedBy: 'part', cascade: ['remove'], orphanRemoval: true)]
    protected Collection $bulkImportJobParts;


    public function __construct()
    {
        $this->attachments = new ArrayCollection();
        parent::__construct();
        $this->partLots = new ArrayCollection();
        $this->orderdetails = new ArrayCollection();
        $this->parameters = new ArrayCollection();
        $this->project_bom_entries = new ArrayCollection();

        $this->associated_parts_as_owner = new ArrayCollection();
        $this->associated_parts_as_other = new ArrayCollection();
        $this->bulkImportJobParts = new ArrayCollection();

        //By default, the part has no provider
        $this->providerReference = InfoProviderReference::noProvider();
        $this->eda_info = new EDAPartInfo();
    }

    public function __clone()
    {
        if ($this->id) {
            //Deep clone part lots
            $lots = $this->partLots;
            $this->partLots = new ArrayCollection();
            foreach ($lots as $lot) {
                $this->addPartLot(clone $lot);
            }

            //Deep clone order details
            $orderdetails = $this->orderdetails;
            $this->orderdetails = new ArrayCollection();
            foreach ($orderdetails as $orderdetail) {
                $this->addOrderdetail(clone $orderdetail);
            }

            //Deep clone parameters
            $parameters = $this->parameters;
            $this->parameters = new ArrayCollection();
            foreach ($parameters as $parameter) {
                $this->addParameter(clone $parameter);
            }

            //Deep clone the owned part associations (the owned ones make not much sense without the owner)
            $ownedAssociations = $this->associated_parts_as_owner;
            $this->associated_parts_as_owner = new ArrayCollection();
            foreach ($ownedAssociations as $association) {
                $this->addAssociatedPartsAsOwner(clone $association);
            }

            //Deep clone info provider
            $this->providerReference = clone $this->providerReference;
            $this->eda_info = clone $this->eda_info;
        }
        parent::__clone();
    }

    #[Assert\Callback]
    public function validate(ExecutionContextInterface $context, $payload): void
    {
        //Ensure that the part name fullfills the regex of the category
        if ($this->category instanceof Category) {
            $regex = $this->category->getPartnameRegex();
            if ($regex !== '' && !preg_match($regex, $this->name)) {
                $context->buildViolation('part.name.must_match_category_regex')
                    ->atPath('name')
                    ->setParameter('%regex%', $regex)
                    ->addViolation();
            }
        }
    }

    /**
     * Get all bulk import job parts for this part
     * @return Collection<int, BulkInfoProviderImportJobPart>
     */
    public function getBulkImportJobParts(): Collection
    {
        return $this->bulkImportJobParts;
    }

    /**
     * Add a bulk import job part to this part
     */
    public function addBulkImportJobPart(BulkInfoProviderImportJobPart $jobPart): self
    {
        if (!$this->bulkImportJobParts->contains($jobPart)) {
            $this->bulkImportJobParts->add($jobPart);
            $jobPart->setPart($this);
        }
        return $this;
    }

    /**
     * Remove a bulk import job part from this part
     */
    public function removeBulkImportJobPart(BulkInfoProviderImportJobPart $jobPart): self
    {
        if ($this->bulkImportJobParts->removeElement($jobPart)) {
            if ($jobPart->getPart() === $this) {
                $jobPart->setPart(null);
            }
        }
        return $this;
    }
}
