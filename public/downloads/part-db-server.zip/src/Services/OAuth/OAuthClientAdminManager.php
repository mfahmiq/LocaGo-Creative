<?php
/*
 * This file is part of Part-DB (https://github.com/Part-DB/Part-DB-symfony).
 *
 *  Copyright (C) 2019 - 2026 Jan Böhmer (https://github.com/jbtronics)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

declare(strict_types=1);

namespace App\Services\OAuth;

use App\Entity\UserSystem\DynamicallyRegisteredOAuthClient;
use Doctrine\ORM\EntityManagerInterface;
use League\Bundle\OAuth2ServerBundle\Manager\ClientManagerInterface;
use League\Bundle\OAuth2ServerBundle\Manager\ScopeManagerInterface;
use League\Bundle\OAuth2ServerBundle\Model\AbstractClient;
use League\Bundle\OAuth2ServerBundle\Model\AccessToken;
use League\Bundle\OAuth2ServerBundle\Model\AuthorizationCode;
use League\Bundle\OAuth2ServerBundle\Model\Client;
use League\Bundle\OAuth2ServerBundle\Model\ClientInterface;
use League\Bundle\OAuth2ServerBundle\Model\RefreshToken;
use League\Bundle\OAuth2ServerBundle\ValueObject\Grant;
use League\Bundle\OAuth2ServerBundle\ValueObject\RedirectUri;
use League\Bundle\OAuth2ServerBundle\ValueObject\Scope;

/**
 * Backs the admin OAuth2 client overview (App\Controller\OAuthClientAdminController) - listing every
 * registered client (almost always RFC 7591 self-registered, see that controller's docblock) with how
 * many currently-live access and refresh tokens each one holds, and permanently removing a client plus
 * everything it was ever granted.
 *
 * Deliberately does NOT use League\Bundle\OAuth2ServerBundle\Service\CredentialsRevokerInterface's
 * DoctrineCredentialsRevoker: it unconditionally also issues an UPDATE against the DeviceCode model/table,
 * which does not exist in our schema (config/packages/league_oauth2_server.yaml disables the device code
 * grant, so migrations/Version20260726180454.php never created oauth2_device_code) - that call would
 * throw "no such table" here. The access/refresh tokens and authorization codes (the 3 credential types
 * we actually persist) are bulk-deleted directly instead, before removing the client itself - the
 * "client" FK columns are mapped ON DELETE CASCADE (see League's Persistence\Mapping\Driver), but SQLite
 * only enforces that when "PRAGMA foreign_keys = ON" is set on the connection, which is not guaranteed
 * here, so this does not rely on it.
 */
class OAuthClientAdminManager
{
    private const MAX_CLIENT_NAME_LENGTH = 128;

    public function __construct(
        private readonly EntityManagerInterface $entityManager,
        private readonly ClientManagerInterface $clientManager,
        private readonly ScopeManagerInterface $scopeManager,
        private readonly OAuthRedirectUriValidator $redirectUriValidator,
    ) {
    }

    /**
     * Manually registers a public (secret-less) client with a fixed authorization_code + refresh_token
     * grant set - the same shape App\Controller\OAuth\ClientRegistrationController's RFC 7591 endpoint
     * produces, just created directly by an admin instead of by the client itself. Useful when Dynamic
     * Client Registration is disabled (OAUTH_DCR_ENABLED) or simply not desired for a particular app.
     *
     * @param list<string> $redirectUris
     * @param list<string> $scopeNames
     *
     * @throws \InvalidArgumentException if $name, $redirectUris or $scopeNames are invalid - the message
     *                                    is safe to show directly to the (admin-only) user of this form
     */
    public function createClient(string $name, array $redirectUris, array $scopeNames): ClientInterface
    {
        $name = $this->validateName($name);
        $this->validateRedirectUris($redirectUris);
        $this->validateScopes($scopeNames);

        $identifier = bin2hex(random_bytes(16));

        $client = new Client($name, $identifier, null);
        $client->setRedirectUris(...array_map(static fn (string $uri): RedirectUri => new RedirectUri($uri), $redirectUris));
        $client->setGrants(new Grant('authorization_code'), new Grant('refresh_token'));
        $client->setScopes(...array_map(static fn (string $scope): Scope => new Scope($scope), $scopeNames));
        $client->setActive(true);

        $this->clientManager->save($client);

        return $client;
    }

    /**
     * Updates the name, redirect URIs, allowed scopes and active state of an already-registered client -
     * used by the admin "edit client" form. Grants are deliberately left untouched (both self-registered
     * and manually-created clients always get authorization_code + refresh_token, see createClient()) and
     * the client secret/identifier can not be changed here either.
     *
     * @param list<string> $redirectUris
     * @param list<string> $scopeNames
     *
     * @throws \InvalidArgumentException if $name, $redirectUris or $scopeNames are invalid - same rules as
     *                                    createClient(), the message is safe to show directly to the
     *                                    (admin-only) user of this form
     *
     * @return ClientInterface|null null if no client with that identifier exists
     */
    public function updateClient(string $identifier, string $name, array $redirectUris, array $scopeNames, bool $active): ?ClientInterface
    {
        $client = $this->clientManager->find($identifier);
        // AbstractClient (not just the ClientInterface every League client implements) is required here
        // because setName() is deliberately left off of ClientInterface itself - same as deleteClient().
        if (!$client instanceof AbstractClient) {
            return null;
        }

        $name = $this->validateName($name);
        $this->validateRedirectUris($redirectUris);
        $this->validateScopes($scopeNames);

        $client->setName($name);
        $client->setRedirectUris(...array_map(static fn (string $uri): RedirectUri => new RedirectUri($uri), $redirectUris));
        $client->setScopes(...array_map(static fn (string $scope): Scope => new Scope($scope), $scopeNames));
        $client->setActive($active);

        $this->clientManager->save($client);

        return $client;
    }

    /**
     * @return ClientInterface|null null if no client with that identifier exists
     */
    public function findClient(string $identifier): ?ClientInterface
    {
        return $this->clientManager->find($identifier);
    }

    private function validateName(string $name): string
    {
        $name = trim($name);
        if ('' === $name) {
            throw new \InvalidArgumentException('Name must not be empty.');
        }

        return mb_substr($name, 0, self::MAX_CLIENT_NAME_LENGTH);
    }

    /**
     * @param list<string> $redirectUris
     */
    private function validateRedirectUris(array $redirectUris): void
    {
        if ([] === $redirectUris) {
            throw new \InvalidArgumentException('At least one redirect URI is required.');
        }
        foreach ($redirectUris as $uri) {
            if (!$this->redirectUriValidator->isAllowed($uri)) {
                throw new \InvalidArgumentException(\sprintf('"%s" is not an allowed redirect URI.', $uri));
            }
        }
    }

    /**
     * @param list<string> $scopeNames
     */
    private function validateScopes(array $scopeNames): void
    {
        if ([] === $scopeNames) {
            throw new \InvalidArgumentException('At least one scope is required.');
        }
        foreach ($scopeNames as $scopeName) {
            if (null === $this->scopeManager->find($scopeName)) {
                throw new \InvalidArgumentException(\sprintf('Unknown scope "%s".', $scopeName));
            }
        }
    }

    /**
     * List every registered client, with how many currently-live access and refresh tokens each one holds
     * and whether it was dynamically registered (RFC 7591) or manually created by an admin.
     * @return list<array{client: ClientInterface, liveTokenCount: int, liveRefreshTokenCount: int, dynamicallyRegistered: bool}>
     */
    public function listClientsWithLiveTokenCounts(): array
    {
        $clients = $this->clientManager->list(null);
        $now = new \DateTimeImmutable();

        $rows = $this->entityManager->createQueryBuilder()
            ->select('IDENTITY(at.client) as clientId', 'COUNT(at.identifier) as tokenCount')
            ->from(AccessToken::class, 'at')
            ->where('at.revoked = false')
            ->andWhere('at.expiry > :now')
            ->groupBy('at.client')
            ->setParameter('now', $now)
            ->getQuery()
            ->getResult();

        /** @var array<string, int> $countByClientId */
        $countByClientId = [];
        foreach ($rows as $row) {
            $countByClientId[$row['clientId']] = (int) $row['tokenCount'];
        }

        // Refresh tokens reference an access token (not the client directly), so the client has to be
        // reached via that access token - see deleteAllCredentialsForClient() for the same relationship.
        $refreshRows = $this->entityManager->createQueryBuilder()
            ->select('IDENTITY(at.client) as clientId', 'COUNT(rt.identifier) as tokenCount')
            ->from(RefreshToken::class, 'rt')
            ->join(AccessToken::class, 'at', 'WITH', 'at.identifier = IDENTITY(rt.accessToken)')
            ->where('rt.revoked = false')
            ->andWhere('rt.expiry > :now')
            ->groupBy('at.client')
            ->setParameter('now', $now)
            ->getQuery()
            ->getResult();

        /** @var array<string, int> $refreshCountByClientId */
        $refreshCountByClientId = [];
        foreach ($refreshRows as $row) {
            $refreshCountByClientId[$row['clientId']] = (int) $row['tokenCount'];
        }

        $dynamicIdentifiers = array_flip($this->entityManager->createQueryBuilder()
            ->select('IDENTITY(m.client) as clientId')
            ->from(DynamicallyRegisteredOAuthClient::class, 'm')
            ->getQuery()
            ->getSingleColumnResult());

        return array_map(static fn (ClientInterface $client): array => [
            'client' => $client,
            'liveTokenCount' => $countByClientId[$client->getIdentifier()] ?? 0,
            'liveRefreshTokenCount' => $refreshCountByClientId[$client->getIdentifier()] ?? 0,
            'dynamicallyRegistered' => isset($dynamicIdentifiers[$client->getIdentifier()]),
        ], $clients);
    }

    /**
     * @return bool false if no client with that identifier exists
     */
    public function deleteClient(string $identifier): bool
    {
        $client = $this->clientManager->find($identifier);
        if (!$client instanceof AbstractClient) {
            return false;
        }

        $this->deleteAllCredentialsForClient($identifier);
        $this->clientManager->remove($client);
        // Any App\Entity\UserSystem\DynamicallyRegisteredOAuthClient row for this client is removed by the
        // database itself (ON DELETE CASCADE FK to oauth2_client.identifier) - no cleanup needed here.

        return true;
    }

    private function deleteAllCredentialsForClient(string $clientIdentifier): void
    {
        // Refresh tokens first - they reference access tokens (not the client directly), so this has to
        // run before the access tokens themselves are deleted.
        $accessTokenIdsSubQuery = $this->entityManager->createQueryBuilder()
            ->select('at2.identifier')
            ->from(AccessToken::class, 'at2')
            ->where('at2.client = :client')
            ->getDQL();

        $refreshTokenDelete = $this->entityManager->createQueryBuilder();
        $refreshTokenDelete->delete(RefreshToken::class, 'rt')
            ->where($refreshTokenDelete->expr()->in('rt.accessToken', $accessTokenIdsSubQuery))
            ->setParameter('client', $clientIdentifier)
            ->getQuery()
            ->execute();

        $this->entityManager->createQueryBuilder()
            ->delete(AccessToken::class, 'at')
            ->where('at.client = :client')
            ->setParameter('client', $clientIdentifier)
            ->getQuery()
            ->execute();

        $this->entityManager->createQueryBuilder()
            ->delete(AuthorizationCode::class, 'ac')
            ->where('ac.client = :client')
            ->setParameter('client', $clientIdentifier)
            ->getQuery()
            ->execute();
    }
}
