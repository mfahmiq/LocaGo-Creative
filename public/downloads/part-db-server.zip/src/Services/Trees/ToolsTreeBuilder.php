<?php
/**
 * This file is part of Part-DB (https://github.com/Part-DB/Part-DB-symfony).
 *
 * Copyright (C) 2019 - 2022 Jan Böhmer (https://github.com/jbtronics)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

declare(strict_types=1);

namespace App\Services\Trees;

use App\Entity\Attachments\AttachmentType;
use App\Entity\LabelSystem\LabelProfile;
use App\Entity\Parts\Category;
use App\Entity\Parts\Footprint;
use App\Entity\Parts\Manufacturer;
use App\Entity\Parts\MeasurementUnit;
use App\Entity\Parts\Part;
use App\Entity\Parts\PartCustomState;
use App\Entity\Parts\StorageLocation;
use App\Entity\Parts\Supplier;
use App\Entity\PriceInformations\Currency;
use App\Entity\ProjectSystem\Project;
use App\Entity\UserSystem\Group;
use App\Entity\UserSystem\User;
use App\Helpers\Trees\TreeViewNode;
use App\Services\Cache\UserCacheKeyGenerator;
use App\Services\ElementTypeNameGenerator;
use App\Settings\InfoProviderSystem\AIFileExtractorSettings;
use App\Settings\InfoProviderSystem\GenericWebProviderSettings;
use Symfony\Bundle\SecurityBundle\Security;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Contracts\Cache\ItemInterface;
use Symfony\Contracts\Cache\TagAwareCacheInterface;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * This Service generates the tree structure for the tools.
 * Whenever you change something here, you have to clear the cache, because the results are cached for performance reasons.
 */
class ToolsTreeBuilder
{
    public function __construct(
        protected TranslatorInterface $translator,
        protected UrlGeneratorInterface $urlGenerator,
        protected TagAwareCacheInterface $cache,
        protected UserCacheKeyGenerator $keyGenerator,
        protected Security $security,
        private readonly ElementTypeNameGenerator $elementTypeNameGenerator,
        private readonly GenericWebProviderSettings $genericWebProviderSettings,
        private readonly AIFileExtractorSettings $fileExtractorSettings,
        #[Autowire('%partdb.oauth_server.enabled%')]
        private readonly bool $oauthServerEnabled,
    ) {
    }

    /**
     * Generates the tree for the tools' menu.
     * The result is cached.
     *
     * @return TreeViewNode[] the array containing all Nodes for the tools menu
     */
    public function getTree(): array
    {
        $key = 'tree_tools_'.$this->keyGenerator->generateKey();

        return $this->cache->get($key, function (ItemInterface $item) {
            //Invalidate tree, whenever group or the user changes
            $item->tag(['tree_tools', 'groups', $this->keyGenerator->generateKey()]);

            $tree = [];
            if ($this->getToolsNode() !== []) {
                $tree[] = (new TreeViewNode($this->translator->trans('tree.tools.tools'), null, $this->getToolsNode()))
                    ->setIcon('fa-fw fa-treeview fa-solid fa-toolbox');
            }

            if ($this->getEditNodes() !== []) {
                $tree[] = (new TreeViewNode($this->translator->trans('tree.tools.edit'), null, $this->getEditNodes()))
                    ->setIcon('fa-fw fa-treeview fa-solid fa-pen-to-square');
            }
            if ($this->getShowNodes() !== []) {
                $tree[] = (new TreeViewNode($this->translator->trans('tree.tools.show'), null, $this->getShowNodes()))
                    ->setIcon('fa-fw fa-treeview fa-solid fa-eye');
            }
            if ($this->getSystemNodes() !== []) {
                $tree[] = (new TreeViewNode($this->translator->trans('tree.tools.system'), null, $this->getSystemNodes()))
                ->setIcon('fa-fw fa-treeview fa-solid fa-server');
            }

            return $tree;
        });
    }

    protected function getToolsNode(): array
    {
        $nodes = [];

        if ($this->security->isGranted('@labels.create_labels')) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('tree.tools.tools.label_dialog'),
                $this->urlGenerator->generate('label_dialog')
            ))->setIcon("fa-treeview fa-fw fa-solid fa-qrcode");
        }

        if ($this->security->isGranted('@tools.label_scanner')) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('tree.tools.tools.label_scanner'),
                $this->urlGenerator->generate('scan_dialog')
            ))->setIcon('fa-treeview fa-fw fa-solid fa-camera-retro');
        }

        if ($this->security->isGranted('@tools.reel_calculator')) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('tree.tools.tools.reel_calculator'),
                $this->urlGenerator->generate('tools_reel_calculator')
            ))->setIcon('fa-treeview fa-fw fa-solid fa-ruler');
        }
        if ($this->security->isGranted('@tools.builtin_footprints_viewer')) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('tools.builtin_footprints_viewer.title'),
                $this->urlGenerator->generate('tools_builtin_footprints_viewer')
            ))->setIcon('fa-treeview fa-fw fa-solid fa-images');
        }
        if ($this->security->isGranted('@tools.ic_logos')) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('perm.tools.ic_logos'),
                $this->urlGenerator->generate('tools_ic_logos')
            ))->setIcon('fa-treeview fa-fw fa-solid fa-flag');
        }
        if ($this->security->isGranted('@tools.component_image_generator')) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('tools.value_calc.title'),
                $this->urlGenerator->generate('tools_component_image_generator')
            ))->setIcon('fa-treeview fa-fw fa-solid fa-palette');
        }
        if ($this->security->isGranted('@parts.import')) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('parts.import.title'),
                $this->urlGenerator->generate('parts_import')
            ))->setIcon('fa-treeview fa-fw fa-solid fa-file-import');
        }

        if ($this->security->isGranted('@info_providers.create_parts')) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('info_providers.search.title'),
                $this->urlGenerator->generate('info_providers_search')
            ))->setIcon('fa-treeview fa-fw fa-solid fa-cloud-arrow-down');

            if ($this->genericWebProviderSettings->enabled) {
                $nodes[] = (new TreeViewNode(
                    $this->translator->trans('info_providers.from_url.title'),
                    $this->urlGenerator->generate('info_providers_from_url')
                ))->setIcon('fa-treeview fa-fw fa-solid fa-book-atlas');
            }

            if ($this->fileExtractorSettings->isConfigured()) {
                $nodes[] = (new TreeViewNode(
                    $this->translator->trans('info_providers.from_file.title'),
                    $this->urlGenerator->generate('info_providers_from_file')
                ))->setIcon('fa-treeview fa-fw fa-solid fa-file-lines');
            }

            $nodes[] = (new TreeViewNode(
                $this->translator->trans('info_providers.bulk_import.manage_jobs'),
                $this->urlGenerator->generate('bulk_info_provider_manage')
            ))->setIcon('fa-treeview fa-fw fa-solid fa-tasks');
        }

        return $nodes;
    }

    /**
     * This functions creates a tree entries for the "edit" node of the tool's tree.
     *
     * @return TreeViewNode[]
     */
    protected function getEditNodes(): array
    {
        $nodes = [];

        if ($this->security->isGranted('read', new AttachmentType())) {
            $nodes[] = (new TreeViewNode(
                $this->elementTypeNameGenerator->typeLabelPlural(AttachmentType::class),
                $this->urlGenerator->generate('attachment_type_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-file-alt');
        }
        if ($this->security->isGranted('read', new Category())) {
            $nodes[] = (new TreeViewNode(
                $this->elementTypeNameGenerator->typeLabelPlural(Category::class),
                $this->urlGenerator->generate('category_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-tags');
        }
        if ($this->security->isGranted('read', new Project())) {
            $nodes[] = (new TreeViewNode(
                $this->elementTypeNameGenerator->typeLabelPlural(Project::class),
                $this->urlGenerator->generate('project_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-archive');
        }
        if ($this->security->isGranted('read', new Supplier())) {
            $nodes[] = (new TreeViewNode(
                $this->elementTypeNameGenerator->typeLabelPlural(Supplier::class),
                $this->urlGenerator->generate('supplier_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-truck');
        }
        if ($this->security->isGranted('read', new Manufacturer())) {
            $nodes[] = (new TreeViewNode(
                $this->elementTypeNameGenerator->typeLabelPlural(Manufacturer::class),
                $this->urlGenerator->generate('manufacturer_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-industry');
        }
        if ($this->security->isGranted('read', new StorageLocation())) {
            $nodes[] = (new TreeViewNode(
                $this->elementTypeNameGenerator->typeLabelPlural(StorageLocation::class),
                $this->urlGenerator->generate('store_location_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-cube');
        }
        if ($this->security->isGranted('read', new Footprint())) {
            $nodes[] = (new TreeViewNode(
                $this->elementTypeNameGenerator->typeLabelPlural(Footprint::class),
                $this->urlGenerator->generate('footprint_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-microchip');
        }
        if ($this->security->isGranted('read', new Currency())) {
            $nodes[] = (new TreeViewNode(
                $this->elementTypeNameGenerator->typeLabelPlural(Currency::class),
                $this->urlGenerator->generate('currency_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-coins');
        }
        if ($this->security->isGranted('read', new MeasurementUnit())) {
            $nodes[] = (new TreeViewNode(
                $this->elementTypeNameGenerator->typeLabelPlural(MeasurementUnit::class),
                $this->urlGenerator->generate('measurement_unit_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-balance-scale');
        }
        if ($this->security->isGranted('read', new LabelProfile())) {
            $nodes[] = (new TreeViewNode(
                $this->elementTypeNameGenerator->typeLabelPlural(LabelProfile::class),
                $this->urlGenerator->generate('label_profile_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-qrcode');
        }
        if ($this->security->isGranted('read', new PartCustomState())) {
            $nodes[] = (new TreeViewNode(
                $this->elementTypeNameGenerator->typeLabelPlural(PartCustomState::class),
                $this->urlGenerator->generate('part_custom_state_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-tools');
        }
        if ($this->security->isGranted('create', new Part())) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('tree.tools.edit.part'),
                $this->urlGenerator->generate('part_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-plus-square');
        }

        return $nodes;
    }

    /**
     * This function creates the tree entries for the "show" node of the tools tree.
     *
     * @return TreeViewNode[]
     */
    protected function getShowNodes(): array
    {
        $show_nodes = [];

        if ($this->security->isGranted('@parts.read')) {
            $show_nodes[] = (new TreeViewNode(
                $this->translator->trans('tree.tools.show.all_parts'),
                $this->urlGenerator->generate('parts_show_all')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-globe');
        }

        if ($this->security->isGranted('@attachments.list_attachments')) {
            $show_nodes[] = (new TreeViewNode(
                $this->translator->trans('tree.tools.show.all_attachments'),
                $this->urlGenerator->generate('attachment_list')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-paperclip');
        }

        if ($this->security->isGranted('@tools.statistics')) {
            $show_nodes[] = (new TreeViewNode(
                $this->translator->trans('tree.tools.show.statistics'),
                $this->urlGenerator->generate('statistics_view')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-chart-bar');
        }

        return $show_nodes;
    }

    /**
     * This function creates the tree entries for the "system" node of the tools tree.
     */
    protected function getSystemNodes(): array
    {
        $nodes = [];

        if ($this->security->isGranted('read', new User())) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('tree.tools.system.users'),
                $this->urlGenerator->generate('user_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-user');
        }
        if ($this->security->isGranted('read', new Group())) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('tree.tools.system.groups'),
                $this->urlGenerator->generate('group_new')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-users');
        }

        if ($this->security->isGranted('@system.show_logs')) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('tree.tools.system.event_log'),
                $this->urlGenerator->generate('log_view')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-binoculars');
        }

        if ($this->security->isGranted('@system.server_infos')) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('tools.server_infos.title'),
                $this->urlGenerator->generate('tools_server_infos')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-database');
        }

        if ($this->security->isGranted('@config.change_system_settings')) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('tree.tools.system.settings'),
                $this->urlGenerator->generate('system_settings')
            ))->setIcon('fa fa-fw fa-gears fa-solid');
        }

        if ($this->security->isGranted('@system.show_updates')) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('tree.tools.system.update_manager'),
                $this->urlGenerator->generate('admin_update_manager')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-arrow-circle-up');
        }

        if ($this->oauthServerEnabled && $this->security->isGranted('@system.manage_oauth_clients')) {
            $nodes[] = (new TreeViewNode(
                $this->translator->trans('oauth_clients.title'),
                $this->urlGenerator->generate('oauth_clients_list')
            ))->setIcon('fa-fw fa-treeview fa-solid fa-key');
        }

        return $nodes;
    }
}
