<?php
/*
 * This file is part of Part-DB (https://github.com/Part-DB/Part-DB-symfony).
 *
 *  Copyright (C) 2019 - 2023 Jan Böhmer (https://github.com/jbtronics)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

declare(strict_types=1);


namespace App\Services\LabelSystem\BarcodeScanner;

/**
 * This enum represents the different types, where a barcode/QR-code can be generated from
 */
enum BarcodeSourceType: string
{
    /** This Barcode was generated using Part-DB internal recommended barcode generator */
    case INTERNAL = 'internal';
    /** This barcode is containing an internal part number (IPN) */
    case IPN = 'ipn';

    /**
     * This barcode is a user defined barcode defined on a part lot
     */
    case USER_DEFINED = 'user';

    /**
     * EIGP114 formatted barcodes like used by digikey, mouser, etc.
     */
    case EIGP114 = 'eigp';

    /**
     * GTIN /EAN barcodes, which are used on most products in the world. These are checked with the GTIN field of a part.
     */
    case GTIN = 'gtin';

    /** For LCSC.com formatted QR codes */
    case LCSC = 'lcsc';

    case AMAZON = 'amazon';

    /** For TME (tme.eu) formatted QR codes */
    case TME = 'tme';
}
