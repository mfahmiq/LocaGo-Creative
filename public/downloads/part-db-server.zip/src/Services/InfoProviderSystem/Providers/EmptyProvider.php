<?php
/*
 * This file is part of Part-DB (https://github.com/Part-DB/Part-DB-symfony).
 *
 *  Copyright (C) 2019 - 2025 Jan Böhmer (https://github.com/jbtronics)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

declare(strict_types=1);


namespace App\Services\InfoProviderSystem\Providers;

use App\Services\InfoProviderSystem\DTOs\PartDetailDTO;
use App\Services\InfoProviderSystem\DTOs\ProviderInfoDTO;
use Symfony\Component\DependencyInjection\Attribute\When;

/**
 * This is a provider, which is used during tests. It always returns no results.
 */
#[When(env: 'test')]
class EmptyProvider implements InfoProviderInterface
{
    public const PROVIDER_KEY = 'empty';

    public function getProviderInfo(): ProviderInfoDTO
    {
        return new ProviderInfoDTO(
            key: self::PROVIDER_KEY,
            name: 'Empty Provider',
            description: 'This is a test provider',
            disabledHelp: 'This provider is disabled for testing purposes',
            capabilities: [
                ProviderCapabilities::BASIC,
                ProviderCapabilities::FOOTPRINT,
            ],
        );
    }

    public function isActive(): bool
    {
        return true;
    }

    public function searchByKeyword(string $keyword, array $options = []): array
    {
        return [

        ];
    }

    public function getDetails(string $id, array $options = []): PartDetailDTO
    {
        throw new \RuntimeException('No part details available');
    }
}
