<?php
/*
 * This file is part of Part-DB (https://github.com/Part-DB/Part-DB-symfony).
 *
 *  Copyright (C) 2019 - 2023 Jan Böhmer (https://github.com/jbtronics)
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

declare(strict_types=1);


namespace App\Controller;

use App\Entity\Parts\Part;
use App\Exceptions\OAuthReconnectRequiredException;
use App\Services\OAuth\OAuthTokenManager;
use App\Form\InfoProviderSystem\DirectAccessFormType;
use App\Form\InfoProviderSystem\FromFileFormType;
use App\Form\InfoProviderSystem\FromURLFormType;
use App\Form\InfoProviderSystem\PartSearchType;
use App\Services\InfoProviderSystem\DTOs\UploadedDocument;
use App\Services\InfoProviderSystem\AIFileInputMode;
use App\Services\InfoProviderSystem\FileContentExtractor;
use App\Services\InfoProviderSystem\Providers\AIDocumentProvider;
use App\Services\InfoProviderSystem\SubmittedPageStorage;
use App\Services\InfoProviderSystem\UploadedDocumentStorage;
use App\Services\InfoProviderSystem\ExistingPartFinder;
use App\Services\InfoProviderSystem\CreateFromUrlHelper;
use App\Services\InfoProviderSystem\PartInfoRetriever;
use App\Services\InfoProviderSystem\ProviderRegistry;
use App\Services\InfoProviderSystem\Providers\InfoProviderInterface;
use App\Settings\InfoProviderSystem\AIFileExtractorSettings;
use App\Settings\InfoProviderSystem\InfoProviderGeneralSettings;
use Jbtronics\SettingsBundle\Form\SettingsFormFactoryInterface;
use Jbtronics\SettingsBundle\Manager\SettingsManagerInterface;
use Psr\Log\LoggerInterface;
use Symfony\Bridge\Doctrine\Attribute\MapEntity;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpClient\Exception\ClientException;
use Symfony\Component\HttpClient\Exception\ServerException;
use Symfony\Component\HttpClient\Exception\TransportException;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

use Symfony\Contracts\HttpClient\Exception\ExceptionInterface;

use function Symfony\Component\Translation\t;

#[Route('/tools/info_providers')]
class InfoProviderController extends  AbstractController
{

    public function __construct(private readonly ProviderRegistry $providerRegistry,
        private readonly PartInfoRetriever $infoRetriever,
        private readonly ExistingPartFinder $existingPartFinder,
        private readonly SettingsManagerInterface $settingsManager,
        private readonly SettingsFormFactoryInterface $settingsFormFactory,
        private readonly SubmittedPageStorage $browserHtmlStorage,
    )
    {

    }

    #[Route('/providers', name: 'info_providers_list')]
    public function listProviders(): Response
    {
        $this->denyAccessUnlessGranted('@info_providers.create_parts');

        return $this->render('info_providers/providers_list/providers_list.html.twig', [
            'active_providers' => $this->providerRegistry->getActiveProviders(),
            'disabled_providers' => $this->providerRegistry->getDisabledProviders(),
        ]);
    }

    #[Route('/provider/{provider}/settings', name: 'info_providers_provider_settings')]
    public function providerSettings(string $provider, Request $request, OAuthTokenManager $oauthTokenManager): Response
    {
        $this->denyAccessUnlessGranted('@config.change_system_settings');
        $this->denyAccessUnlessGranted('@info_providers.create_parts');

        $providerInstance = $this->providerRegistry->getProviderByKey($provider);
        $settingsClass = $providerInstance->getProviderInfo()->settingsClass ?? throw new \LogicException('Provider ' . $provider . ' does not have a settings class defined');

        //Create a clone of the settings object
        $settings = $this->settingsManager->createTemporaryCopy($settingsClass);

        //Create a form builder for the settings object
        $builder = $this->settingsFormFactory->createSettingsFormBuilder($settings);

        //Add a submit button to the form
        $builder->add('submit', SubmitType::class, ['label' => 'save']);

        //Create the form
        $form = $builder->getForm();
        $form->handleRequest($request);

        //If the form was submitted and is valid, save the settings
        if ($form->isSubmitted() && $form->isValid()) {
            $this->settingsManager->mergeTemporaryCopy($settings);
            $this->settingsManager->save($settings);

            $this->addFlash('success', t('settings.flash.saved'));
        }

        if ($form->isSubmitted() && !$form->isValid()) {
            $this->addFlash('error', t('settings.flash.invalid'));
        }

        //Render the form
        return $this->render('info_providers/settings/provider_settings.html.twig', [
            'form' => $form,
            'info_provider_key' => $provider,
            'info_provider_info' => $providerInstance->getProviderInfo(),
            'oauth_token' => $providerInstance->getProviderInfo()->oauthAppName !== null
                ? $oauthTokenManager->getToken($providerInstance->getProviderInfo()->oauthAppName) : null,
        ]);
    }

    #[Route('/search', name: 'info_providers_search')]
    #[Route('/update/{target}', name: 'info_providers_update_part_search')]
    public function search(Request $request, #[MapEntity(id: 'target')] ?Part $update_target, LoggerInterface $exceptionLogger, InfoProviderGeneralSettings $infoProviderSettings): Response
    {
        $this->denyAccessUnlessGranted('@info_providers.create_parts');

        $form = $this->createForm(PartSearchType::class);
        $form->handleRequest($request);

        $results = null;

        //When we are updating a part, use its name as keyword, to make searching easier
        //However we can only do this, if the form was not submitted yet
        if ($update_target !== null && !$form->isSubmitted()) {
            //Use the provider reference if available, otherwise use the manufacturer product number
            $keyword = $update_target->getProviderReference()->getProviderId() ?? $update_target->getManufacturerProductNumber();
            //Or the name if both are not available
            if ($keyword === "") {
                $keyword = $update_target->getName();
            }

            $form->get('keyword')->setData($keyword);

            //If we are updating a part, which already has a provider, preselect that provider in the form
            if ($update_target->getProviderReference()->getProviderKey() !== null) {
                try {
                    $form->get('providers')->setData([$this->providerRegistry->getProviderByKey($update_target->getProviderReference()->getProviderKey())]);
                } catch (\InvalidArgumentException $e) {
                    //If the provider is not found, just ignore it
                }
            }
        }

        //If the providers form is still empty, use our default value from the settings
        if (count($form->get('providers')->getData() ?? []) === 0) {
            $default_providers = $infoProviderSettings->defaultSearchProviders;
            $provider_objects = [];
            foreach ($default_providers as $provider_key) {
                try {
                    $tmp = $this->providerRegistry->getProviderByKey($provider_key);
                    if ($tmp->isActive()) {
                        $provider_objects[] = $tmp;
                    }
                } catch (\InvalidArgumentException $e) {
                    //If the provider is not found, just ignore it
                }
            }
            $form->get('providers')->setData($provider_objects);
        }

        if ($form->isSubmitted() && $form->isValid()) {
            $keyword = $form->get('keyword')->getData();
            $providers = $form->get('providers')->getData();

            $no_cache_search = $form->get('no_cache_search')->getData();
            $no_cache_details = $form->get('no_cache_details')->getData();

            $dtos = [];

            try {
                $dtos = $this->infoRetriever->searchByKeyword(keyword: $keyword, providers: $providers, options: [
                    InfoProviderInterface::OPTION_NO_CACHE => $no_cache_search
                ]);
            } catch (ClientException $e) {
                $this->addFlash('error', t('info_providers.search.error.client_exception'));
                $this->addFlash('error',$e->getMessage());
                //Log the exception
                $exceptionLogger->error('Error during info provider search: ' . $e->getMessage(), ['exception' => $e]);
            } catch (ServerException $e) {
                $this->addFlash('error', t('info_providers.error.server_exception', [
                    '%status%' => $e->getResponse()->getStatusCode(),
                    '%host%' => parse_url((string) $e->getResponse()->getInfo('url'), PHP_URL_HOST) ?? '',
                ]));
                $exceptionLogger->error('Server error during info provider search: ' . $e->getMessage(), ['exception' => $e]);
            } catch (OAuthReconnectRequiredException $e) {
                $this->addFlash('error', t('info_providers.search.error.oauth_reconnect', ['%provider%' => $e->getProviderName()]));
            } catch (TransportException $e) {
                $this->addFlash('error', t('info_providers.search.error.transport_exception'));
                $exceptionLogger->error('Transport error during info provider search: ' . $e->getMessage(), ['exception' => $e]);
            } catch (\RuntimeException $e) {
                $this->addFlash('error', t('info_providers.search.error.general_exception', ['%type%' => (new \ReflectionClass($e))->getShortName()]));
                //Log the exception
                $exceptionLogger->error('Error during info provider search: ' . $e->getMessage(), ['exception' => $e]);
            }


            // modify the array to an array of arrays that has a field for a matching local Part
            // the advantage to use that format even when we don't look for local parts is that we
            // always work with the same interface
            $results = array_map(static function ($result) {return ['dto' => $result, 'localPart' => null];}, $dtos);
            if(!$update_target) {
                foreach ($results as $index => $result) {
                    $results[$index]['localPart'] = $this->existingPartFinder->findFirstExisting($result['dto']);
                }
            }
        }

        return $this->render('info_providers/search/part_search.html.twig', [
            'form' => $form,
            'results' => $results,
            'update_target' => $update_target,
            'no_cache_details' => $no_cache_details ?? false,
        ]);
    }

    #[Route('/direct', name: 'info_providers_direct_access')]
    public function directAccess(Request $request, LoggerInterface $exceptionLogger): Response
    {
        $this->denyAccessUnlessGranted('@info_providers.create_parts');

        //Allow to prefill the form via query parameters (used by the search page, if no results were found)
        $form = $this->createForm(DirectAccessFormType::class, [
            'provider' => $request->query->getString('provider') ?: null,
            'provider_id' => $request->query->getString('provider_id') ?: null,
        ]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $providerKey = $form->get('provider')->getData();
            $providerId = trim($form->get('provider_id')->getData());

            try {
                //Retrieve the details here, so that errors (like an unknown part number) can be shown on this page.
                //The result is cached, so the part creation page does not have to query the provider again.
                $this->infoRetriever->getDetails($providerKey, $providerId, [
                    InfoProviderInterface::OPTION_NO_CACHE => $form->get('no_cache')->getData(),
                ]);

                return $this->redirectToRoute('info_providers_create_part', [
                    'providerKey' => $providerKey,
                    'providerId' => $providerId,
                ]);
            } catch (ClientException $e) {
                $this->addFlash('error', t('info_providers.search.error.client_exception'));
                $this->addFlash('error', $e->getMessage());
                $exceptionLogger->error('Error during direct info provider access: ' . $e->getMessage(), ['exception' => $e]);
            } catch (OAuthReconnectRequiredException $e) {
                $this->addFlash('error', t('info_providers.search.error.oauth_reconnect', ['%provider%' => $e->getProviderName()]));
            } catch (TransportException $e) {
                $this->addFlash('error', t('info_providers.search.error.transport_exception'));
                $exceptionLogger->error('Transport error during direct info provider access: ' . $e->getMessage(), ['exception' => $e]);
            } catch (\RuntimeException $e) {
                $this->addFlash('error', t('info_providers.search.error.general_exception', ['%type%' => (new \ReflectionClass($e))->getShortName()]));
                $exceptionLogger->error('Error during direct info provider access: ' . $e->getMessage(), ['exception' => $e]);
            }
        }

        return $this->render('info_providers/direct_access/direct_access.html.twig', [
            'form' => $form,
        ]);
    }

    #[Route('/from_url', name: 'info_providers_from_url')]
    public function fromURL(Request $request, CreateFromUrlHelper $fromUrlHelper, LoggerInterface $exceptionLogger): Response
    {
        $this->denyAccessUnlessGranted('@info_providers.create_parts');

        if (!$fromUrlHelper->canCreateFromUrl()) {
            $this->addFlash('error', "Generic Web Provider is not active. Please enable it in the provider settings.");
            return $this->redirectToRoute('info_providers_list');
        }

        $form = $this->createForm(FromURLFormType::class);
        $form->handleRequest($request);

        $partDetail = null;
        if ($form->isSubmitted() && $form->isValid()) {
            //Try to retrieve the part detail from the given URL
            $url = $form->get('url')->getData();

            $method = $form->get('method')->getData();
            $no_cache = $form->get('no_cache')->getData();
            $skip_delegation = $form->get('skip_delegation')->getData();

            $submittedPageToken = $request->request->get('submitted_page_token', null);
            if ($submittedPageToken !== null && $submittedPageToken !== '') {
                $url = $this->browserHtmlStorage->retrieve($submittedPageToken)->url;
            }


            try {
                //It's okay if we use the cached results here, as its just for convenience
                $searchResult = $this->infoRetriever->searchByKeyword(
                    keyword: $url,
                    providers: [$method],
                    options: [
                        InfoProviderInterface::OPTION_SKIP_DELEGATION => $skip_delegation,
                        InfoProviderInterface::OPTION_SUBMITTED_PAGE_TOKEN => $submittedPageToken,
                    ]
                );

                if (count($searchResult) === 0) {
                    $this->addFlash('warning', t('info_providers.from_url.no_part_found'));
                } else {
                    $searchResult = $searchResult[0];
                    //Redirect to the part creation page with the found part detail
                    return $this->redirectToRoute('info_providers_create_part', [
                        'providerKey' => $searchResult->provider_key,
                        'providerId' => $searchResult->provider_id,
                        'no_cache' => $no_cache ? 1 : null,
                        'skip_delegation' => $skip_delegation ? 1 : null,
                        'submitted_page_token' => $submittedPageToken ?: null,
                    ]);
                }
            } catch (ExceptionInterface $e) {
                $this->addFlash('error', t('info_providers.search.error.general_exception', ['%type%' => (new \ReflectionClass($e))->getShortName()]));
            } catch (\RuntimeException $e) {
                //Same handling as the search page: a provider which rejects the request (an unknown model or an
                //exhausted quota, for example) is a normal outcome here and has to be shown, not turned into a 500
                $this->addFlash('error', t('info_providers.search.error.general_exception', ['%type%' => (new \ReflectionClass($e))->getShortName()]));
                $exceptionLogger->error('Error while creating a part from an URL: '.$e->getMessage(), ['exception' => $e]);
            }
        }

        return $this->render('info_providers/from_url/from_url.html.twig', [
            'form' => $form,
            'partDetail' => $partDetail,
            'recentBrowserPages' => $this->browserHtmlStorage->getRecentPages(),
        ]);

    }

    #[Route('/from_file', name: 'info_providers_from_file')]
    public function fromFile(Request $request, FileContentExtractor $fileContentExtractor, UploadedDocumentStorage $documentStorage,
        AIFileExtractorSettings $fileExtractorSettings, LoggerInterface $exceptionLogger): Response
    {
        $this->denyAccessUnlessGranted('@info_providers.create_parts');

        if (!$this->providerRegistry->getProviderByKey(AIDocumentProvider::PROVIDER_KEY)->isActive()) {
            $this->addFlash('error', t('info_providers.from_file.not_active'));
            return $this->redirectToRoute('info_providers_list');
        }

        $allowFileInput = $fileExtractorSettings->allowFileInput;
        $form = $this->createForm(FromFileFormType::class, options: [
            'allow_file_input' => $allowFileInput,
        ]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            /** @var UploadedFile $file */
            $file = $form->get('file')->getData();
            $no_cache = $form->get('no_cache')->getData();
            $context = $form->get('context')->getData();
            $mimeType = $file->getMimeType();
            //The user chooses the mode for every upload, if the settings allow sending files at all
            $inputMode = $allowFileInput ? $form->get('input_mode')->getData() : AIFileInputMode::TEXT;

            if ($inputMode === AIFileInputMode::TEXT && $fileContentExtractor->isImage($mimeType)) {
                $this->addFlash('error', t('info_providers.from_file.error.image_in_text_mode'));
                return $this->redirectToRoute('info_providers_from_file');
            }

            //Images have no text to extract. In the file mode, PDFs are sent as they are too, so that the model sees
            //their layout. An empty text means, that the file is sent to the model (see UploadedDocument).
            $sendFile = $fileContentExtractor->isImage($mimeType)
                || ($inputMode === AIFileInputMode::FILE && $fileContentExtractor->isPdf($mimeType));

            $text = '';
            if (!$sendFile) {
                try {
                    $text = $fileContentExtractor->extractContent($file, $fileExtractorSettings->maxContentLength);
                } catch (\RuntimeException $e) {
                    $this->addFlash('error', t('info_providers.from_file.error.parse', ['%error%' => $e->getMessage()]));
                    return $this->redirectToRoute('info_providers_from_file');
                }

                //Scanned documents have no text layer, in the auto mode the model reads them itself
                if ($text === '' && !($inputMode === AIFileInputMode::AUTO && $fileContentExtractor->isPdf($mimeType))) {
                    $this->addFlash('error', t('info_providers.from_file.error.no_text'));
                    return $this->redirectToRoute('info_providers_from_file');
                }
            }

            //The original file is stored too (moved, not loaded), so that it can be attached to the created part
            //and sent to the model
            $token = $documentStorage->store(
                new UploadedDocument($file->getClientOriginalName(), $text, $context, $file->getSize(),
                    fileMimeType: $mimeType, fileHash: hash_file('xxh3', $file->getPathname()) ?: null),
                $file
            );

            try {
                //Run the extraction here, so that errors can be shown on this page. The provider caches the result,
                //so the part creation page does not have to call the AI model again.
                $this->infoRetriever->getDetails(AIDocumentProvider::PROVIDER_KEY, $token, [
                    InfoProviderInterface::OPTION_NO_CACHE => $no_cache,
                ]);

                return $this->redirectToRoute('info_providers_create_part', [
                    'providerKey' => AIDocumentProvider::PROVIDER_KEY,
                    'providerId' => $token,
                ]);
            } catch (\RuntimeException $e) {
                $this->addFlash('error', t('info_providers.search.error.general_exception', ['%type%' => (new \ReflectionClass($e))->getShortName()]));
                $exceptionLogger->error('Error while creating a part from a file: '.$e->getMessage(), ['exception' => $e]);
            }
        }

        return $this->render('info_providers/from_file/from_file.html.twig', [
            'form' => $form,
        ]);
    }
}
