<?php

require_once "../config/database.php";
require_once "../includes/role.php";
require_once "../includes/pagination.php";

requireRole(["admin", "waiter"]);

$pg = get_pagination_params(25, [25, 50, 100]);
$q = trim($_GET["q"] ?? "");

// 1. Summary KPIs across all customers
$kpi_sql = "SELECT
                COUNT(*) AS total_customers,
                SUM(CASE WHEN phone IS NOT NULL AND TRIM(phone) <> '' THEN 1 ELSE 0 END) AS with_phone,
                SUM(CASE WHEN address IS NOT NULL AND TRIM(address) <> '' THEN 1 ELSE 0 END) AS with_address
            FROM customers";
$kpi_row = mysqli_fetch_assoc(mysqli_query($conn, $kpi_sql));
$total_customers = (int) ($kpi_row['total_customers'] ?? 0);
$with_phone = (int) ($kpi_row['with_phone'] ?? 0);
$with_address = (int) ($kpi_row['with_address'] ?? 0);

// 2. Filtered WHERE clause
$where_clauses = [];
$bind_params = [];
$bind_types = "";

if ($q !== "") {
    $where_clauses[] = "(name LIKE ? OR COALESCE(phone, '') LIKE ? OR COALESCE(address, '') LIKE ?)";
    $like_q = "%" . $q . "%";
    $bind_params[] = $like_q;
    $bind_params[] = $like_q;
    $bind_params[] = $like_q;
    $bind_types .= "sss";
}

$where_sql = !empty($where_clauses) ? ("WHERE " . implode(" AND ", $where_clauses)) : "";

// 3. Filtered COUNT query
$count_sql = "SELECT COUNT(*) AS total FROM customers $where_sql";
$c_stmt = mysqli_prepare($conn, $count_sql);
if ($bind_types !== "") {
    mysqli_stmt_bind_param($c_stmt, $bind_types, ...$bind_params);
}
mysqli_stmt_execute($c_stmt);
$filtered_total = (int) (mysqli_fetch_assoc(mysqli_stmt_get_result($c_stmt))['total'] ?? 0);
mysqli_stmt_close($c_stmt);

$pagination = finalize_pagination($filtered_total, $pg['page'], $pg['per_page']);
$limit = $pagination['per_page'];
$offset = $pagination['offset'];

// 4. Paginated data query
$sql = "SELECT * FROM customers $where_sql ORDER BY id DESC LIMIT ? OFFSET ?";
$d_stmt = mysqli_prepare($conn, $sql);
$data_types = $bind_types . "ii";
$data_params = array_merge($bind_params, [$limit, $offset]);
mysqli_stmt_bind_param($d_stmt, $data_types, ...$data_params);
mysqli_stmt_execute($d_stmt);
$result = mysqli_stmt_get_result($d_stmt);

$customers = [];
while ($c = mysqli_fetch_assoc($result)) {
    $customers[] = $c;
}
mysqli_stmt_close($d_stmt);

$page_title = "Customers Directory";
$active_menu = "customers";

require_once "../includes/header.php";
?>

<!-- Page Header Bar -->
<div class="page-header-bar">
    <div>
        <h2 class="page-header-title">Customers Directory</h2>
        <p class="page-header-subtitle">Guest profiles, contact information &amp; service directory</p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="create.php" class="btn btn-primary btn-sm d-inline-flex align-items-center gap-1 shadow-sm">
            <i class="bi bi-person-plus"></i>
            <span>Add Customer</span>
        </a>
    </div>
</div>

<!-- Customer Metrics Summary -->
<div class="row g-3 mb-4">
    <div class="col-12 col-sm-4">
        <div class="pos-card p-3 d-flex align-items-center justify-content-between">
            <div>
                <span class="text-muted small d-block">Registered Guests</span>
                <span class="fs-4 fw-bold text-dark"><?php echo $total_customers; ?></span>
            </div>
            <div class="badge-subtle badge-status-completed p-2 rounded">
                <i class="bi bi-people fs-4"></i>
            </div>
        </div>
    </div>
    <div class="col-6 col-sm-4">
        <div class="pos-card p-3 d-flex align-items-center justify-content-between">
            <div>
                <span class="text-muted small d-block">Phone on Record</span>
                <span class="fs-4 fw-bold text-primary"><?php echo $with_phone; ?></span>
            </div>
            <div class="badge-subtle badge-status-preparing p-2 rounded">
                <i class="bi bi-telephone fs-4 text-primary"></i>
            </div>
        </div>
    </div>
    <div class="col-6 col-sm-4">
        <div class="pos-card p-3 d-flex align-items-center justify-content-between">
            <div>
                <span class="text-muted small d-block">Address on File</span>
                <span class="fs-4 fw-bold text-secondary"><?php echo $with_address; ?></span>
            </div>
            <div class="badge-subtle badge-status-ready p-2 rounded">
                <i class="bi bi-geo-alt fs-4 text-secondary"></i>
            </div>
        </div>
    </div>
</div>

<!-- Search & Controls Bar -->
<div class="pos-card mb-4">
    <div class="p-3">
        <form method="GET" class="row g-2 align-items-center justify-content-between">
            <input type="hidden" name="per_page" value="<?php echo (int)$pagination['per_page']; ?>">
            <input type="hidden" name="page" value="1">
            <div class="col-12 col-md-6 col-lg-5">
                <div class="input-group input-group-sm">
                    <span class="input-group-text bg-light border-end-0">
                        <i class="bi bi-search text-muted"></i>
                    </span>
                    <input 
                        type="text" 
                        name="q"
                        class="form-control pos-form-control border-start-0" 
                        id="customerSearch" 
                        value="<?php echo htmlspecialchars($q, ENT_QUOTES, 'UTF-8'); ?>"
                        placeholder="Search by name, phone or address..."
                    >
                    <button type="submit" class="btn btn-outline-primary">Search</button>
                    <?php if ($q !== "") { ?>
                        <a href="?per_page=<?php echo (int)$pagination['per_page']; ?>" class="btn btn-outline-secondary">Reset</a>
                    <?php } ?>
                </div>
            </div>
        </form>
    </div>
</div>

<?php if (empty($customers)) { ?>
    <!-- Empty State -->
    <div class="pos-card p-5 text-center shadow-sm">
        <div class="text-muted mb-3">
            <i class="bi bi-people fs-1 text-secondary opacity-50"></i>
        </div>
        <h5 class="fw-semibold text-dark mb-1">No Customers Registered</h5>
        <p class="text-muted small mb-4">There are currently no customer profiles in the system.</p>
        <a href="create.php" class="btn btn-primary btn-sm">
            <i class="bi bi-person-plus me-1"></i>Add First Customer
        </a>
    </div>
<?php } else { ?>
    <!-- Customers Table -->
    <div class="pos-card overflow-hidden shadow-sm">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" id="customersTable">
                <thead class="table-light">
                    <tr>
                        <th style="width: 70px;">ID</th>
                        <th>Customer Name</th>
                        <th>Phone Number</th>
                        <th>Address</th>
                        <th style="width: 140px;" class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($customers as $c) { 
                        $first_letter = mb_strtoupper(mb_substr($c['name'], 0, 1, 'UTF-8'));
                    ?>
                        <tr class="customer-row" 
                            data-search="<?php echo htmlspecialchars(mb_strtolower($c['name'] . ' ' . ($c['phone'] ?? '') . ' ' . ($c['address'] ?? '')), ENT_QUOTES, 'UTF-8'); ?>">
                            <td class="text-muted fw-semibold">#<?php echo $c["id"]; ?></td>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="customer-avatar">
                                        <?php echo htmlspecialchars($first_letter, ENT_QUOTES, 'UTF-8'); ?>
                                    </div>
                                    <span class="fw-semibold text-dark">
                                        <?php echo htmlspecialchars($c["name"], ENT_QUOTES, 'UTF-8'); ?>
                                    </span>
                                </div>
                            </td>
                            <td>
                                <?php if (!empty($c["phone"])) { ?>
                                    <a href="tel:<?php echo htmlspecialchars($c["phone"], ENT_QUOTES, 'UTF-8'); ?>" class="text-decoration-none text-dark d-inline-flex align-items-center gap-1">
                                        <i class="bi bi-telephone text-primary small"></i>
                                        <span><?php echo htmlspecialchars($c["phone"], ENT_QUOTES, 'UTF-8'); ?></span>
                                    </a>
                                <?php } else { ?>
                                    <span class="text-muted fst-italic small">Not provided</span>
                                <?php } ?>
                            </td>
                            <td>
                                <?php if (!empty($c["address"])) { ?>
                                    <span class="text-muted small d-inline-flex align-items-center gap-1">
                                        <i class="bi bi-geo-alt text-secondary small"></i>
                                        <span><?php echo htmlspecialchars($c["address"], ENT_QUOTES, 'UTF-8'); ?></span>
                                    </span>
                                <?php } else { ?>
                                    <span class="text-muted fst-italic small">Not provided</span>
                                <?php } ?>
                            </td>
                            <td class="text-end">
                                <div class="d-inline-flex align-items-center gap-1">
                                    <?php if (($_SESSION['role'] ?? '') === 'admin') { ?>
                                        <a href="../customer-ledger/view.php?id=<?php echo $c['id']; ?>" 
                                           class="btn btn-outline-secondary btn-sm" 
                                           title="Customer Financial Statement &amp; Ledger">
                                            <i class="bi bi-journal-text text-primary"></i>
                                        </a>
                                    <?php } ?>

                                    <a href="edit.php?id=<?php echo $c["id"]; ?>" 
                                       class="btn btn-outline-secondary btn-sm" 
                                       title="Edit Profile">
                                        <i class="bi bi-pencil"></i>
                                    </a>

                                    <?php if (($_SESSION['role'] ?? '') === 'admin') { ?>
                                        <form method="POST" action="delete.php" class="d-inline m-0 p-0" onsubmit="return confirm('Are you sure you want to delete customer <?php echo htmlspecialchars(addslashes($c['name']), ENT_QUOTES, 'UTF-8'); ?>? Note: Customers with existing orders cannot be deleted.');">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?php echo $c["id"]; ?>">
                                            <button type="submit" class="btn btn-outline-danger btn-sm" title="Delete Customer">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    <?php } ?>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <?php render_pagination_bar($pagination); ?>
    </div>
<?php } ?>

<?php

require_once "../includes/footer.php";

?>