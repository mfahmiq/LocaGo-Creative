<?php

require_once "../config/database.php";
require_once "../includes/role.php";

requireRole(["admin", "waiter"]);

$id = (int) ($_GET["id"] ?? 0);
if ($id <= 0) {
    $_SESSION["error"] = "Record not found or invalid identifier.";
    header("Location: index.php");
    exit;
}

$sql = "SELECT * FROM customers WHERE id = ?";

$stmt = mysqli_prepare($conn, $sql);

mysqli_stmt_bind_param($stmt, "i", $id);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

$customer = mysqli_fetch_assoc($result);

if (!$customer) {
    $_SESSION["error"] = "Record not found or invalid identifier.";
    header("Location: index.php");
    exit;
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (!verify_csrf_token()) {
        csrf_failure_response();
    }

    $name = preg_replace('/\s+/', ' ', trim($_POST["name"] ?? ""));
    $phone = trim($_POST["phone"] ?? "");
    $address = preg_replace('/\s+/', ' ', trim($_POST["address"] ?? ""));

    if ($name === "") {
        $error = "Customer full name is required and cannot be empty or whitespace only.";
    } elseif (mb_strlen($name) < 2 || mb_strlen($name) > 100) {
        $error = "Customer name must be between 2 and 100 characters.";
    } else {
        try {
            $sql = "UPDATE customers
                    SET name = ?, phone = ?, address = ?
                    WHERE id = ?";

            $stmt = mysqli_prepare($conn, $sql);

            mysqli_stmt_bind_param(
                $stmt,
                "sssi",
                $name,
                $phone,
                $address,
                $id
            );

            mysqli_stmt_execute($stmt);

            header("Location: index.php");
            exit;
        } catch (mysqli_sql_exception $e) {
            $error = "Database error while updating customer profile.";
        }
    }
}

$page_title = "Edit Customer #" . $id;
$active_menu = "customers";

require_once "../includes/header.php";

$display_name = isset($_POST["name"]) ? $name : $customer["name"];
$display_phone = isset($_POST["phone"]) ? $phone : $customer["phone"];
$display_address = isset($_POST["address"]) ? $address : $customer["address"];
?>

<!-- Page Header Bar -->
<div class="page-header-bar">
    <div>
        <h2 class="page-header-title">Edit Customer #<?php echo $id; ?></h2>
        <p class="page-header-subtitle">Update guest contact details and delivery preferences</p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="index.php" class="btn btn-outline-secondary btn-sm d-inline-flex align-items-center gap-1">
            <i class="bi bi-arrow-left"></i>
            <span>Back to Customers</span>
        </a>
        <?php if (($_SESSION['role'] ?? '') === 'admin') { ?>
            <a href="../customer-ledger/view.php?id=<?php echo $id; ?>" class="btn btn-outline-secondary btn-sm d-inline-flex align-items-center gap-1">
                <i class="bi bi-journal-text text-primary"></i>
                <span>Customer Ledger</span>
            </a>
        <?php } ?>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-12 col-md-8 col-lg-6">
        <?php if ($error !== "") { ?>
            <div class="alert alert-danger d-flex align-items-center mb-4 shadow-sm" role="alert">
                <i class="bi bi-exclamation-triangle-fill fs-5 me-2 flex-shrink-0"></i>
                <div>
                    <strong>Validation Error:</strong> <?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            </div>
        <?php } ?>

        <div class="pos-card shadow-sm">
            <div class="pos-card-header bg-light d-flex align-items-center justify-content-between">
                <span class="pos-card-title">
                    <i class="bi bi-pencil-square text-primary me-2"></i>Modify Customer Record
                </span>
                <span class="badge bg-white text-muted border">ID #<?php echo $id; ?></span>
            </div>
            <div class="pos-card-body p-4">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <!-- Customer Name -->
                    <div class="mb-3">
                        <label for="customerName" class="form-label pos-form-label">
                            Full Name <span class="text-danger">*</span>
                        </label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0">
                                <i class="bi bi-person text-muted"></i>
                            </span>
                            <input
                                type="text"
                                class="form-control pos-form-control border-start-0 py-2"
                                id="customerName"
                                name="name"
                                value="<?php echo htmlspecialchars($customer["name"], ENT_QUOTES, 'UTF-8'); ?>"
                                required
                            >
                        </div>
                        <div class="form-text text-muted small">Guest or organization name.</div>
                    </div>

                    <!-- Phone Number -->
                    <div class="mb-3">
                        <label for="customerPhone" class="form-label pos-form-label">
                            Phone Number
                        </label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0">
                                <i class="bi bi-telephone text-muted"></i>
                            </span>
                            <input
                                type="text"
                                class="form-control pos-form-control border-start-0 py-2"
                                id="customerPhone"
                                name="phone"
                                value="<?php echo htmlspecialchars($customer["phone"] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                            >
                        </div>
                        <div class="form-text text-muted small">Contact number for reservations and order status.</div>
                    </div>

                    <!-- Delivery Address -->
                    <div class="mb-4">
                        <label for="customerAddress" class="form-label pos-form-label">
                            Address / Delivery Details
                        </label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0 align-items-start pt-2">
                                <i class="bi bi-geo-alt text-muted"></i>
                            </span>
                            <textarea
                                class="form-control pos-form-control border-start-0 py-2"
                                id="customerAddress"
                                name="address"
                                rows="3"
                            ><?php echo htmlspecialchars($customer["address"] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                        </div>
                        <div class="form-text text-muted small">Useful for delivery orders and billing invoices.</div>
                    </div>

                    <!-- Actions -->
                    <div class="d-flex align-items-center justify-content-between pt-3 border-top">
                        <?php if (($_SESSION['role'] ?? '') === 'admin') { ?>
                            <button type="submit" form="deleteCustomerForm" class="btn btn-outline-danger px-3 d-inline-flex align-items-center gap-1">
                                <i class="bi bi-trash"></i>
                                <span>Delete</span>
                            </button>
                        <?php } else { ?>
                            <div></div>
                        <?php } ?>

                        <div class="d-flex align-items-center gap-2">
                            <a href="index.php" class="btn btn-outline-secondary px-3">
                                Cancel
                            </a>
                            <button type="submit" class="btn btn-primary px-4 d-inline-flex align-items-center gap-1 shadow-sm">
                                <i class="bi bi-check-lg"></i>
                                <span>Update Customer</span>
                            </button>
                        </div>
                    </div>
                </form>

                <?php if (($_SESSION['role'] ?? '') === 'admin') { ?>
                    <form id="deleteCustomerForm" method="POST" action="delete.php" class="d-none" onsubmit="return confirm('Are you sure you want to delete customer <?php echo htmlspecialchars(addslashes($customer['name']), ENT_QUOTES, 'UTF-8'); ?>? Note: Customers with existing orders cannot be deleted.');">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                    </form>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

<?php

require_once "../includes/footer.php";

?>