<?php

require_once "../config/database.php";
require_once "../includes/role.php";

requireRole(["admin"]);

$suppliers = mysqli_query(
    $conn,
    "SELECT id, name
     FROM suppliers
     ORDER BY name ASC"
);

$raw_materials = mysqli_query(
    $conn,
    "SELECT id, name, unit
     FROM raw_materials
     ORDER BY name ASC"
);

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (!verify_csrf_token()) {
        csrf_failure_response();
    }

    $supplier_id = (int) ($_POST["supplier_id"] ?? 0);
    $payment_status = trim($_POST["payment_status"] ?? "unpaid");
    $purchase_date = trim($_POST["purchase_date"] ?? date("Y-m-d"));

    $raw_material_ids = $_POST["raw_material_id"] ?? [];
    $quantities = $_POST["quantity"] ?? [];
    $unit_prices = $_POST["unit_price"] ?? [];

    // Verify supplier selection
    if ($supplier_id <= 0) {
        $error = "Please select a valid supplier.";
    } elseif (!in_array($payment_status, ["unpaid", "paid"], true)) {
        $error = "Invalid payment status selected. Full settlement (paid) or credit invoice (unpaid) only.";
    } elseif (
        !is_array($raw_material_ids)
        || !is_array($quantities)
        || !is_array($unit_prices)
        || empty($raw_material_ids)
        || empty($quantities)
        || empty($unit_prices)
    ) {
        $error = "Please add at least one raw material line item.";
    } elseif (
        count($raw_material_ids) !== count($quantities)
        || count($raw_material_ids) !== count($unit_prices)
    ) {
        $error = "Invalid purchase items: form row counts do not match.";
    }

    if ($error === "") {
        // Pre-validate all item rows strictly before entering database transaction
        $items_to_process = [];
        $seen_materials = [];

        foreach ($raw_material_ids as $index => $raw_mat_val) {
            $row_num = $index + 1;

            // 1. Raw material identifier validation
            if (!is_scalar($raw_mat_val) || !is_numeric($raw_mat_val)) {
                $error = "Row #{$row_num}: Invalid raw material selected.";
                break;
            }
            $mat_id = (int) $raw_mat_val;
            if ($mat_id <= 0) {
                $error = "Row #{$row_num}: Please select a valid raw material.";
                break;
            }
            if (isset($seen_materials[$mat_id])) {
                $error = "Row #{$row_num}: Duplicate raw material selected. Please combine quantities on a single row.";
                break;
            }
            $seen_materials[$mat_id] = true;

            // 2. Quantity validation (raw input string check)
            $qty_raw = $quantities[$index] ?? null;
            if ($qty_raw === null || is_array($qty_raw) || !is_scalar($qty_raw)) {
                $error = "Row #{$row_num}: Missing quantity.";
                break;
            }
            $qty_str = trim((string) $qty_raw);
            if ($qty_str === "") {
                $error = "Row #{$row_num}: Quantity is required.";
                break;
            }
            // Strict regex for decimal(10,3): optional leading digits, up to 3 decimal places
            if (!preg_match('/^\d+(\.\d{1,3})?$/', $qty_str)) {
                $error = "Row #{$row_num}: Quantity must be a valid positive number with at most 3 decimal places.";
                break;
            }
            $qty_float = (float) $qty_str;
            if (!is_finite($qty_float) || $qty_float <= 0) {
                $error = "Row #{$row_num}: Quantity must be greater than zero.";
                break;
            }
            if ($qty_float > 9999999.999) {
                $error = "Row #{$row_num}: Quantity exceeds the maximum allowed limit (9,999,999.999).";
                break;
            }

            // UOM Database Validation
            $uom_check = validateMaterialQuantity($conn, $mat_id, $qty_str, "Row #{$row_num} quantity");
            if (!$uom_check["valid"]) {
                $error = $uom_check["error"];
                break;
            }
            $qty_float = $uom_check["quantity"];

            // 3. Unit Price validation (raw input string check)
            $price_raw = $unit_prices[$index] ?? null;
            if ($price_raw === null || is_array($price_raw) || !is_scalar($price_raw)) {
                $error = "Row #{$row_num}: Missing unit price.";
                break;
            }
            $price_str = trim((string) $price_raw);
            if ($price_str === "") {
                $error = "Row #{$row_num}: Unit price is required.";
                break;
            }
            // Strict regex for decimal(10,2): non-negative number with up to 2 decimal places
            if (!preg_match('/^\d+(\.\d{1,2})?$/', $price_str)) {
                $error = "Row #{$row_num}: Unit price must be a valid non-negative number with at most 2 decimal places.";
                break;
            }
            $price_float = (float) $price_str;
            if (!is_finite($price_float) || $price_float < 0) {
                $error = "Row #{$row_num}: Unit price cannot be negative.";
                break;
            }
            if ($price_float > 9999999.99) {
                $error = "Row #{$row_num}: Unit price exceeds the maximum allowed limit (9,999,999.99).";
                break;
            }

            // 4. Calculate line subtotal rounded to 2 decimal places
            $line_subtotal = round($qty_float * $price_float, 2);

            $items_to_process[] = [
                "raw_material_id" => $mat_id,
                "quantity" => $qty_float,
                "unit_price" => $price_float,
                "subtotal" => $line_subtotal
            ];
        }
    }

    if ($error === "") {
        mysqli_begin_transaction($conn);

        try {
            // Verify supplier exists
            $sup_stmt = mysqli_prepare($conn, "SELECT id FROM suppliers WHERE id = ?");
            mysqli_stmt_bind_param($sup_stmt, "i", $supplier_id);
            mysqli_stmt_execute($sup_stmt);
            $sup_res = mysqli_stmt_get_result($sup_stmt);
            if (mysqli_num_rows($sup_res) === 0) {
                throw new Exception("Selected supplier does not exist.");
            }

            $total_amount = 0.00;
            $items = [];

            // Verify raw materials existence and calculate exact purchase header total
            foreach ($items_to_process as $item_data) {
                $mat_id = $item_data["raw_material_id"];

                $sql = "SELECT id, name FROM raw_materials WHERE id = ?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "i", $mat_id);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $material = mysqli_fetch_assoc($result);

                if (!$material) {
                    throw new Exception("Raw material #{$mat_id} was not found.");
                }

                $total_amount = round($total_amount + $item_data["subtotal"], 2);
                $items[] = $item_data;
            }

            if ($total_amount > 99999999.99) {
                throw new Exception("Total purchase amount exceeds maximum invoice limit.");
            }

            $paid_at = ($payment_status === "paid") ? date("Y-m-d H:i:s") : null;
            $creator_user_id = (int) ($_SESSION["user_id"] ?? 0);

            // Create purchase
            $sql = "INSERT INTO purchases
                    (
                        supplier_id,
                        total_amount,
                        payment_status,
                        paid_at,
                        purchase_date
                    )
                    VALUES (?, ?, ?, ?, ?)";

            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param(
                $stmt,
                "idsss",
                $supplier_id,
                $total_amount,
                $payment_status,
                $paid_at,
                $purchase_date
            );
            mysqli_stmt_execute($stmt);

            $purchase_id = mysqli_insert_id($conn);

            // Insert purchase items, increment stock, recalculate MAC, and record inventory transaction
            foreach ($items as $item) {
                $mat_id = (int) $item["raw_material_id"];
                $qty = (float) $item["quantity"];
                $unit_price = (float) $item["unit_price"];
                $line_subtotal = (float) $item["subtotal"];

                $sql = "INSERT INTO purchase_items
                        (
                            purchase_id,
                            raw_material_id,
                            quantity,
                            unit_price,
                            subtotal
                        )
                        VALUES (?, ?, ?, ?, ?)";

                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param(
                    $stmt,
                    "iiddd",
                    $purchase_id,
                    $mat_id,
                    $qty,
                    $unit_price,
                    $line_subtotal
                );
                mysqli_stmt_execute($stmt);

                // Lock raw material row for atomic update of stock and moving average cost
                $lock_stmt = mysqli_prepare($conn, "SELECT current_stock, current_unit_cost FROM raw_materials WHERE id = ? FOR UPDATE");
                mysqli_stmt_bind_param($lock_stmt, "i", $mat_id);
                mysqli_stmt_execute($lock_stmt);
                $mat_row = mysqli_fetch_assoc(mysqli_stmt_get_result($lock_stmt));

                $old_stock = (float) ($mat_row["current_stock"] ?? 0);
                $old_avg_cost = (float) ($mat_row["current_unit_cost"] ?? 0);

                // Moving Weighted Average Cost (MAC) formula:
                // new_avg_cost = ((old_stock * old_avg_cost) + (qty * unit_price)) / (old_stock + qty)
                // If old_stock <= 0 (zero or recovery), new average cost is the purchase unit price.
                if ($old_stock <= 0) {
                    $new_avg_cost = $unit_price;
                } else {
                    $new_total_val = ($old_stock * $old_avg_cost) + ($qty * $unit_price);
                    $new_total_qty = $old_stock + $qty;
                    $new_avg_cost = ($new_total_qty > 0) ? ($new_total_val / $new_total_qty) : $unit_price;
                }
                $new_avg_cost = round($new_avg_cost, 4);

                // Increase stock and update moving average unit cost
                $sql = "UPDATE raw_materials
                        SET current_stock = current_stock + ?,
                            current_unit_cost = ?
                        WHERE id = ?";

                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param(
                    $stmt,
                    "ddi",
                    $qty,
                    $new_avg_cost,
                    $mat_id
                );
                mysqli_stmt_execute($stmt);

                // Create inventory transaction with cost snapshot and creator metadata
                $sql = "INSERT INTO inventory_transactions
                        (
                            raw_material_id,
                            type,
                            quantity,
                            unit_cost,
                            total_cost,
                            reference_type,
                            reference_id,
                            created_by,
                            notes
                        )
                        VALUES
                        (
                            ?,
                            'purchase',
                            ?,
                            ?,
                            ?,
                            'purchase',
                            ?,
                            ?,
                            'Supplier PO receipt'
                        )";

                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param(
                    $stmt,
                    "idddii",
                    $mat_id,
                    $qty,
                    $unit_price,
                    $line_subtotal,
                    $purchase_id,
                    $creator_user_id
                );
                mysqli_stmt_execute($stmt);
            }

            mysqli_commit($conn);

            header("Location: view.php?id=" . $purchase_id);
            exit;

        } catch (Exception $exception) {
            mysqli_rollback($conn);
            $error = $exception->getMessage();
        }
    }
}

// Convert suppliers and materials to arrays
$suppliers_list = [];
if ($suppliers) {
    while ($s = mysqli_fetch_assoc($suppliers)) {
        $suppliers_list[] = $s;
    }
}

$materials_list = [];
if ($raw_materials) {
    while ($m = mysqli_fetch_assoc($raw_materials)) {
        $materials_list[] = $m;
    }
}

$page_title = "Create Purchase Order";
$active_menu = "purchases";

require_once "../includes/header.php";
?>

<!-- Page Header Bar -->
<div class="page-header-bar">
    <div>
        <h2 class="page-header-title">Create Purchase Order</h2>
        <p class="page-header-subtitle">Intake bulk raw materials, record supplier liability &amp; update active inventory</p>
    </div>
    <div class="d-flex align-items-center gap-2">
        <a href="index.php" class="btn btn-outline-secondary btn-sm d-inline-flex align-items-center gap-1">
            <i class="bi bi-arrow-left"></i>
            <span>Back to Purchases</span>
        </a>
    </div>
</div>

<?php if ($error !== "") { ?>
    <div class="alert alert-danger d-flex align-items-center gap-2 mb-4" role="alert">
        <i class="bi bi-exclamation-triangle-fill fs-5"></i>
        <div>
            <strong>Purchase Creation Error:</strong> <?php echo htmlspecialchars($error); ?>
        </div>
    </div>
<?php } ?>

<form method="POST" id="purchaseForm">
    <?php echo csrf_field(); ?>
    <div class="row g-4">
        <!-- Main Form Column -->
        <div class="col-12 col-lg-8">
            <!-- 1. Order Header Information Card -->
            <div class="pos-card mb-4">
                <div class="pos-card-header">
                    <span class="pos-card-title">
                        <span class="recipe-flow-step-num">1</span>Vendor &amp; Invoice Details
                    </span>
                    <span class="badge bg-light text-dark border">
                        Purchase Metadata
                    </span>
                </div>
                <div class="pos-card-body p-4">
                    <div class="row g-3">
                        <!-- Supplier Select -->
                        <div class="col-12 col-md-6">
                            <label class="form-label pos-form-label">
                                Supplier / Vendor <span class="text-danger">*</span>
                            </label>
                            <div class="input-group">
                                <span class="input-group-text bg-white border-end-0">
                                    <i class="bi bi-truck text-muted"></i>
                                </span>
                                <select name="supplier_id" class="form-select pos-form-control border-start-0" required>
                                    <option value="">Select Supplier...</option>
                                    <?php foreach ($suppliers_list as $sup) { ?>
                                        <option value="<?php echo $sup["id"]; ?>" <?php echo (isset($_POST["supplier_id"]) && $_POST["supplier_id"] == $sup["id"]) ? "selected" : ""; ?>>
                                            <?php echo htmlspecialchars($sup["name"]); ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="form-text text-muted small">Registered vendor supplying the materials.</div>
                        </div>

                        <!-- Purchase Date -->
                        <div class="col-12 col-md-3">
                            <label class="form-label pos-form-label">
                                Purchase Date <span class="text-danger">*</span>
                            </label>
                            <div class="input-group">
                                <span class="input-group-text bg-white border-end-0">
                                    <i class="bi bi-calendar-event text-muted"></i>
                                </span>
                                <input
                                    type="date"
                                    name="purchase_date"
                                    class="form-control pos-form-control border-start-0"
                                    value="<?php echo htmlspecialchars($_POST["purchase_date"] ?? date('Y-m-d')); ?>"
                                    required
                                >
                            </div>
                        </div>

                        <!-- Payment Status -->
                        <div class="col-12 col-md-3">
                            <label class="form-label pos-form-label">
                                Payment Status <span class="text-danger">*</span>
                            </label>
                            <div class="input-group">
                                <span class="input-group-text bg-white border-end-0">
                                    <i class="bi bi-wallet2 text-muted"></i>
                                </span>
                                <select name="payment_status" class="form-select pos-form-control border-start-0" required>
                                    <option value="unpaid" <?php echo (isset($_POST["payment_status"]) && $_POST["payment_status"] === "unpaid") ? "selected" : ""; ?>>Unpaid (Credit / Accounts Payable)</option>
                                    <option value="paid" <?php echo (isset($_POST["payment_status"]) && $_POST["payment_status"] === "paid") ? "selected" : ""; ?>>Paid (Settled Immediately)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 2. Purchased Materials Table Builder -->
            <div class="pos-card">
                <div class="pos-card-header d-flex justify-content-between align-items-center">
                    <span class="pos-card-title">
                        <span class="recipe-flow-step-num">2</span>Purchased Materials &amp; Line Items
                    </span>
                    <span class="badge bg-light text-primary border">
                        Stock Increment Items
                    </span>
                </div>
                <div class="pos-card-body p-4">
                    <p class="text-muted small mb-3">
                        Add raw materials included in this delivery. Stock quantities will be automatically credited to inventory upon saving.
                    </p>

                    <!-- Items Container -->
                    <div id="purchaseItems" class="d-flex flex-column gap-3">
                        <!-- Initial Row -->
                        <div class="purchase-item p-3 rounded border bg-white">
                            <div class="row g-2 align-items-center">
                                <div class="col-12 col-md-5">
                                    <label class="form-label pos-form-label mb-1">
                                        Raw Material <span class="text-danger">*</span>
                                    </label>
                                    <select name="raw_material_id[]" class="form-select pos-form-control" required onchange="handleMaterialChange(this)">
                                        <option value="">Select Raw Material</option>
                                        <?php foreach ($materials_list as $mat) { ?>
                                            <option value="<?php echo $mat["id"]; ?>" data-unit="<?php echo htmlspecialchars($mat["unit"]); ?>">
                                                <?php echo htmlspecialchars($mat["name"]); ?> (<?php echo htmlspecialchars($mat["unit"]); ?>)
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>

                                <div class="col-6 col-md-3">
                                    <label class="form-label pos-form-label mb-1">
                                        Quantity <span class="text-danger">*</span>
                                    </label>
                                    <div class="input-group">
                                        <input
                                            type="number"
                                            name="quantity[]"
                                            step="0.001"
                                            min="0.001"
                                            class="form-control pos-form-control text-end"
                                            placeholder="0.000"
                                            required
                                            oninput="recalcRow(this.closest('.purchase-item'))"
                                        >
                                        <span class="input-group-text bg-light text-muted unit-label" style="min-width: 58px; font-size: 0.75rem; justify-content: center;">
                                            unit
                                        </span>
                                    </div>
                                </div>

                                <div class="col-6 col-md-3">
                                    <label class="form-label pos-form-label mb-1">
                                        Unit Price (Rs.) <span class="text-danger">*</span>
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light text-muted" style="font-size: 0.8rem;">Rs.</span>
                                        <input
                                            type="number"
                                            name="unit_price[]"
                                            step="0.01"
                                            min="0"
                                            class="form-control pos-form-control text-end"
                                            placeholder="0.00"
                                            required
                                            oninput="recalcRow(this.closest('.purchase-item'))"
                                        >
                                    </div>
                                </div>

                                <div class="col-12 col-md-1 text-end">
                                    <label class="form-label pos-form-label mb-1 d-none d-md-block">&nbsp;</label>
                                    <button 
                                        type="button" 
                                        class="btn btn-outline-danger btn-sm w-100 d-flex align-items-center justify-content-center" 
                                        onclick="removePurchaseItem(this)" 
                                        title="Remove Line Item"
                                        style="height: 38px;"
                                    >
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end align-items-center gap-2 mt-2 pt-2 border-top text-muted small">
                                <span>Estimated Line Subtotal:</span>
                                <span class="line-subtotal fw-bold text-dark font-monospace">Rs. 0.00</span>
                            </div>
                        </div>
                    </div>

                    <!-- Add Row Button -->
                    <div class="mt-3">
                        <button
                            type="button"
                            class="btn btn-outline-primary btn-sm d-inline-flex align-items-center gap-1"
                            onclick="addPurchaseItem()"
                        >
                            <i class="bi bi-plus-circle"></i>
                            <span>Add Another Item</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sidebar Summary Column -->
        <div class="col-12 col-lg-4">
            <!-- Purchase Summary Card -->
            <div class="pos-card mb-4">
                <div class="pos-card-header">
                    <span class="pos-card-title">
                        <i class="bi bi-calculator text-primary me-2"></i>Order Financial Summary
                    </span>
                </div>
                <div class="pos-card-body p-3">
                    <div class="purchase-summary-box mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted small">Item Lines</span>
                            <span id="previewItemCount" class="fw-bold text-dark">1</span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted small">Stock Adjustment</span>
                            <span class="badge badge-subtle badge-status-ready">Immediate Credit</span>
                        </div>
                        <hr class="my-2 border-secondary-subtle">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="fw-bold text-dark">Total Amount</span>
                            <span id="previewGrandTotal" class="fs-4 fw-bold text-primary font-monospace">Rs. 0.00</span>
                        </div>
                    </div>

                    <div class="d-flex flex-column gap-2">
                        <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold d-inline-flex align-items-center justify-content-center gap-2 shadow-sm">
                            <i class="bi bi-check2-circle fs-5"></i>
                            <span>Create Purchase</span>
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary w-100 py-2">
                            Cancel
                        </a>
                    </div>
                </div>
            </div>

            <!-- Inventory Mechanics Guidance Card -->
            <div class="pos-card">
                <div class="pos-card-header">
                    <span class="pos-card-title">
                        <i class="bi bi-box-arrow-in-down text-secondary me-2"></i>Stock Intake Mechanics
                    </span>
                </div>
                <div class="pos-card-body p-3">
                    <div class="recipe-flow-card mb-3">
                        <div class="d-flex align-items-start gap-2 mb-2">
                            <span class="badge bg-primary text-white rounded-pill px-2">1</span>
                            <div>
                                <strong class="small d-block text-dark">Stock Increment</strong>
                                <span class="text-muted" style="font-size: 0.78rem;">Each material's current_stock is credited in real-time.</span>
                            </div>
                        </div>
                        <div class="d-flex align-items-start gap-2 mb-2">
                            <span class="badge bg-warning text-dark rounded-pill px-2">2</span>
                            <div>
                                <strong class="small d-block text-dark">Audit Transaction</strong>
                                <span class="text-muted" style="font-size: 0.78rem;">Records permanent inventory_transactions entry.</span>
                            </div>
                        </div>
                        <div class="d-flex align-items-start gap-2">
                            <span class="badge bg-success text-white rounded-pill px-2">3</span>
                            <div>
                                <strong class="small d-block text-dark">Supplier Account</strong>
                                <span class="text-muted" style="font-size: 0.78rem;">Invoice enters Supplier Ledger for payment tracking.</span>
                            </div>
                        </div>
                    </div>
                    <div class="text-muted small">
                        <i class="bi bi-shield-check text-success me-1"></i>
                        Decimal support up to 3 places (0.001) for precise weight/volume intake.
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<script>
function addPurchaseItem() {
    const purchaseItems = document.getElementById("purchaseItems");
    const firstItem = document.querySelector(".purchase-item");
    if (!purchaseItems || !firstItem) return;

    const newItem = firstItem.cloneNode(true);

    const select = newItem.querySelector("select");
    const inputs = newItem.querySelectorAll("input");
    const unitLabel = newItem.querySelector(".unit-label");
    const subtotalDisplay = newItem.querySelector(".line-subtotal");

    if (select) select.value = "";
    inputs.forEach(function (input) {
        input.value = "";
    });
    if (unitLabel) unitLabel.textContent = "unit";
    if (subtotalDisplay) subtotalDisplay.textContent = "Rs. 0.00";

    purchaseItems.appendChild(newItem);
    recalcPurchaseTotal();
}

function removePurchaseItem(btn) {
    const rows = document.querySelectorAll(".purchase-item");
    const row = btn.closest(".purchase-item");
    if (!row) return;

    if (rows.length > 1) {
        row.remove();
    } else {
        const select = row.querySelector("select");
        const inputs = row.querySelectorAll("input");
        const unitLabel = row.querySelector(".unit-label");
        const subtotalDisplay = row.querySelector(".line-subtotal");
        if (select) select.value = "";
        inputs.forEach(function (input) {
            input.value = "";
        });
        if (unitLabel) unitLabel.textContent = "unit";
        if (subtotalDisplay) subtotalDisplay.textContent = "Rs. 0.00";
    }
    recalcPurchaseTotal();
}

function handleMaterialChange(select) {
    const row = select.closest(".purchase-item");
    if (!row) return;
    const unitLabel = row.querySelector(".unit-label");
    const selectedOption = select.options[select.selectedIndex];
    const unit = selectedOption ? (selectedOption.getAttribute("data-unit") || "unit") : "unit";
    if (unitLabel) {
        unitLabel.textContent = unit;
    }
    recalcRow(row);
}

function recalcRow(row) {
    if (!row) return;
    const qtyInput = row.querySelector('input[name="quantity[]"]');
    const priceInput = row.querySelector('input[name="unit_price[]"]');
    const subtotalDisplay = row.querySelector('.line-subtotal');

    const qty = parseFloat(qtyInput ? qtyInput.value : 0) || 0;
    const price = parseFloat(priceInput ? priceInput.value : 0) || 0;
    const subtotal = qty * price;

    if (subtotalDisplay) {
        subtotalDisplay.textContent = 'Rs. ' + subtotal.toFixed(2);
    }
    recalcPurchaseTotal();
}

function recalcPurchaseTotal() {
    let grandTotal = 0;
    let validCount = 0;
    const rows = document.querySelectorAll('.purchase-item');
    rows.forEach(function (row) {
        const qtyInput = row.querySelector('input[name="quantity[]"]');
        const priceInput = row.querySelector('input[name="unit_price[]"]');
        const select = row.querySelector('select[name="raw_material_id[]"]');

        const qty = parseFloat(qtyInput ? qtyInput.value : 0) || 0;
        const price = parseFloat(priceInput ? priceInput.value : 0) || 0;

        if (select && select.value && qty > 0) {
            validCount++;
            grandTotal += (qty * price);
        }
    });

    const totalDisplay = document.getElementById('previewGrandTotal');
    const countDisplay = document.getElementById('previewItemCount');

    if (totalDisplay) totalDisplay.textContent = 'Rs. ' + grandTotal.toFixed(2);
    if (countDisplay) countDisplay.textContent = (validCount > 0 ? validCount : rows.length).toString();
}
</script>

<?php

require_once "../includes/footer.php";

?>