<?php

  header('location:store'); 
?>
