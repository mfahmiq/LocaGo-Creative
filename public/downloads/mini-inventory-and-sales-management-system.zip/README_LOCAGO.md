# Warehouse & Inventory Management System - Mini Inventory And Sales Management System

```
========================================================================
📦 Warehouse & Inventory Management System - Mini Inventory And Sales Management System
Kategori     : Bisnis & Manajemen
Tech Stack   : CodeIgniter • PHP • MySQL • Bootstrap
Database     : MySQL (.sql) (File: 1410inventory.sql)
Sumber Asli  : https://github.com/amirsanni/Mini-Inventory-and-Sales-Management-System (GitHub Open Source)
Stars GitHub : ⭐ 564 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/mini-inventory-and-sales-management-system`
     * Untuk Laragon: `C:/laragon/www/mini-inventory-and-sales-management-system`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `mini_inventory_and_sales_management_system`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `1410inventory.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = mini_inventory_and_sales_management_system

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/mini-inventory-and-sales-management-system

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
