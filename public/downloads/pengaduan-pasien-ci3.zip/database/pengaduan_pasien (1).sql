-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2023 at 02:53 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pengaduan_pasien`
--

-- --------------------------------------------------------

--
-- Table structure for table `balasan`
--

CREATE TABLE `balasan` (
  `id_balasan` int(10) NOT NULL,
  `tgl_balasan` date NOT NULL,
  `isi_balasan` text NOT NULL,
  `id_user` int(10) NOT NULL,
  `id_pertanyaan` int(10) NOT NULL,
  `status_balasan` enum('Selesai','Proses') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `balasan`
--

INSERT INTO `balasan` (`id_balasan`, `tgl_balasan`, `isi_balasan`, `id_user`, `id_pertanyaan`, `status_balasan`) VALUES
(1, '2023-07-08', 'okayy fiks', 3, 1, 'Selesai'),
(2, '2023-07-08', 'siapp ya', 3, 4, 'Selesai'),
(3, '2023-07-08', 'Bisa melalui bagian umum, kepegawaian dan humas', 1, 3, 'Selesai');

-- --------------------------------------------------------

--
-- Table structure for table `pertanyaan`
--

CREATE TABLE `pertanyaan` (
  `id_pertanyaan` int(10) NOT NULL,
  `subjek_pertanyaan` varchar(100) NOT NULL,
  `tgl_pertanyaan` date NOT NULL,
  `isi_pertanyaan` text NOT NULL,
  `bukti_pertanyaan` varchar(100) DEFAULT NULL,
  `balasan_pertanyaan` enum('Belum','Proses','Selesai') NOT NULL,
  `id_user` int(11) NOT NULL,
  `waktu` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pertanyaan`
--

INSERT INTO `pertanyaan` (`id_pertanyaan`, `subjek_pertanyaan`, `tgl_pertanyaan`, `isi_pertanyaan`, `bukti_pertanyaan`, `balasan_pertanyaan`, `id_user`, `waktu`) VALUES
(1, 'Gawat Darurat', '2023-07-08', 'apa sii', 'user.png', 'Selesai', 2, '00:00:00'),
(3, 'Ruang Arafah Kebidanan', '2023-07-08', 'Bagaimana proses mengurus akta kelahiran?', '20230108212017613.jpg', 'Selesai', 2, '00:00:00'),
(4, 'Gawat Darurat', '2023-07-08', 'igd apaa yaa', '20230507200431395.jpg', 'Selesai', 2, '00:00:00'),
(8, 'Gawat Darurat', '2023-07-08', 'sadadsds', '20230518153607460.jpg', 'Proses', 2, '11:02:31'),
(9, 'Ruang VIP Marwa', '2023-07-08', 'sasas', '202305181536074601.jpg', 'Proses', 2, '11:25:30');

-- --------------------------------------------------------

--
-- Table structure for table `tokens`
--

CREATE TABLE `tokens` (
  `id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `id_user` int(11) NOT NULL,
  `created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tokens`
--

INSERT INTO `tokens` (`id`, `token`, `id_user`, `created`) VALUES
(1, 'a50d63c4c876caf99e4e9f9c5fb1e6', 1, '2023-07-08'),
(2, '76a5f3914d7a97030e372aedab0478', 1, '2023-07-08');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(128) NOT NULL,
  `level` varchar(50) NOT NULL,
  `nama` varchar(64) NOT NULL,
  `noTelp` varchar(20) NOT NULL,
  `foto` varchar(128) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `level`, `nama`, `noTelp`, `foto`, `created_at`) VALUES
(1, 'admin', '$2y$10$2igldXHSeLfIhqS0SXcRsOvB2Piqv.dUclplFuJrIJ6tLIQbgSPpe', 'Admin', 'Louis Tomlinson', '081377228181', 'user.png', '2023-07-08'),
(2, 'harry', '$2y$10$8MUKLd/Rf2c3r1vmzGRiVuzGuBQhn23HPh9vQ68XM/ThvYpgvsP8C', 'Pasien', 'Harry Styles', '087868896040', 'user.png', '2023-07-08'),
(3, 'bangchan', '$2y$10$T0qhy8EcGIfW70qH7lnVq.4nUweb5ZDm3DSD5vJ87PujXkh4EDew2', 'Gawat Darurat', 'Bang Chan', '0878922112', 'user_(1).png', '2023-07-08'),
(4, 'hyunjin', '$2y$10$.ucNxk2yYjgWRvGcuXHkKuYNe/QH0dvFpjbd1YQG3jhLx35D/ZRoG', 'Rawat Jalan', 'Hyunjin', '0919212', 'user_(9).png', '2023-07-08'),
(5, 'mimau', '$2y$10$slnDJ79Kxq0Nr7kGbmLs.OzpYgZjnANqbZGT0qUEPtbYh.mpY3Luq', 'Ruang VIP Marwa', 'Mimau', '0878922112', 'IMG-20230612-WA0022.jpg', '2023-07-08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `balasan`
--
ALTER TABLE `balasan`
  ADD PRIMARY KEY (`id_balasan`);

--
-- Indexes for table `pertanyaan`
--
ALTER TABLE `pertanyaan`
  ADD PRIMARY KEY (`id_pertanyaan`);

--
-- Indexes for table `tokens`
--
ALTER TABLE `tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `balasan`
--
ALTER TABLE `balasan`
  MODIFY `id_balasan` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pertanyaan`
--
ALTER TABLE `pertanyaan`
  MODIFY `id_pertanyaan` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tokens`
--
ALTER TABLE `tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
