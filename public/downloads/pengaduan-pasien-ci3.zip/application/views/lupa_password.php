


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>EmailCHIMP | Responsive Bootstrap 4 Admin Dashboard Template</title>
      
      <!-- Favicon -->
      <link rel="shortcut icon" href="<?= base_url('template/html/'); ?>assets/images/favicon.ico" />
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/css/backend-plugin.min.css">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/css/backend.css?v=1.0.2">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/vendor/@fortawesome/fontawesome-free/css/all.min.css">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/vendor/line-awesome/dist/line-awesome/css/line-awesome.min.css">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/vendor/remixicon/fonts/remixicon.css">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/vendor/@icon/dripicons/dripicons.css">  </head>
  <body class=" ">
    <!-- loader Start -->
    <div id="loading">
          <div id="loading-center">
          </div>
    </div>
    <!-- loader END -->
    
      <div class="wrapper">
      <section class="login-content">
         <div class="container h-100">
            <div class="row align-items-center justify-content-center h-100">
               <div class="col-12">
                  <div class="row align-items-center">
                     <div class="col-lg-6">
                        <h2 class="mb-2"><?= $title; ?></h2>
                        <p>Masukkan username untuk mengganti password!</p>
                            <?php echo form_open('lupa_password'); ?>
                            <div class="row">
                              <div class="col-lg-12">
                                 <div class=" form-group">
                                    <label class="mb-0">Username</label>
                                    <input class=" form-control" type="text" name="username" id="username" value="<?php echo set_value('username'); ?>" placeholder=" ">
                                <?php echo form_error('username'); ?> 
                                </div>
                              </div>
                              
                           </div>
                           <input type="submit" name="btnSubmit" value="Submit" class="btn btn-primary btn-lg">
                     </div>
                     <div class="col-lg-6 rmb-30">
                        <img src="<?= base_url('template/html/'); ?>assets/images/login/01.png" class="img-fluid w-80" alt="">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      </div>
    
    <!-- Backend Bundle JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/backend-bundle.min.js"></script>
    
    <!-- Table Treeview JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/table-treeview.js"></script>
    
    <!-- SweetAlert JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/sweetalert.js"></script>
    
    <!-- Vectoe Map JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/vector-map-custom.js"></script>
    
    <!-- Chart Custom JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/chart-custom.js"></script>
    
    <!-- slider JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/slider.js"></script>
    
    <!-- app JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/app.js"></script>
  </body>
</html>