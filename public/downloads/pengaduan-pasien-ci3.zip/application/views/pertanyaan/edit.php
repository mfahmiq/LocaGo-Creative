<div class="content-page">
<div class="container-fluid">
   <div class="card">
      <div class="card-body">
         <div class="row">
            <div class="col-lg-12">
               <div class="d-flex align-items-center border-bottom justify-content-between mb-4">
                  <div class="form-name">
                     <h3 class="mb-2"><?= $title ?></h3>
                     <p>Note: Tanda ini <span style="color:red">*)</span> wajib di isi!</p>
                  </div>
                  
               </div>
            </div>
            
         </div>
         <div class="row">
            <div class="col-lg-12">
                     <div class="row">
                        <div class="col-sm-12">
                            <?= form_open_multipart('', [], ['id_user' => $this->session->userdata('login_session')['user']]); ?>
                              <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                       <label class="mb-0">Subjek <span style="color:red">*)</span></label>
                                        <select name="subjek_pertanyaan" id="subjek_pertanyaan" class="selectpicker form-control" data-style="py-0">
                                          <option value="" selected disabled>Pilih Subjek</option>
                                          <option <?= "Gawat Darurat" == $pertanyaan['subjek_pertanyaan'] ? "selected" : "Gawat Darurat"; ?> >Gawat Darurat</option>  
                                          <option <?= "Rawat Jalan" == $pertanyaan['subjek_pertanyaan'] ? "selected" : "Rawat Jalan"; ?> >Rawat Jalan</option>  
                                          <option <?= "Rawat Inap" == $pertanyaan['subjek_pertanyaan'] ? "selected" : "Rawat Inap"; ?> >Rawat Inap</option>  
                                           <option <?= "Ruang VIP Marwa" == $pertanyaan['subjek_pertanyaan'] ? "selected" : "Ruang VIP Marwa"; ?> >Ruang VIP Marwa</option>  
                                           <option <?= "Ruang Arafah Kebidanan" == $pertanyaan['subjek_pertanyaan'] ? "selected" : "Ruang Arafah Kebidanan"; ?> >Ruang Arafah Kebidanan</option>  
                                           <option <?= "Ruang Perinatologi" == $pertanyaan['subjek_pertanyaan'] ? "selected" : "Ruang Perinatologi"; ?> >Ruang Perinatologi</option>  
                                           <option <?= "Ruang Mina Anak" == $pertanyaan['subjek_pertanyaan'] ? "selected" : "Ruang Mina Anak"; ?> >Ruang Mina Anak</option>  
                                          <option <?= "Ruang Shafa Bedah" == $pertanyaan['subjek_pertanyaan'] ? "selected" : "Ruang Shafa Bedah"; ?> >Ruang Shafa Bedah</option>  
                                          <option <?= "Ruang Shafa Internis" == $pertanyaan['subjek_pertanyaan'] ? "selected" : "Ruang Shafa Internis"; ?> >Ruang Shafa Internis</option>  
                                          <option value="Ruang Shafa Internis">Ruang Shafa Internis</option>
                                          <option value="Ruang Paru">Ruang Paru</option>
                                          <option value="Ruang Hemodialisa">Ruang Hemodialisa</option>
                                          <option value="Ruang Raudhah ICU">Ruang Raudhah ICU</option>
                                          <option value="Ruang IBS">Ruang IBS</option>
                                          <option value="Ruang CSSD">Ruang CSSD</option>
                                          <option value="Radiologi">Radiologi</option>
                                          <option value="Laboratorium">Laboratorium</option>
                                          <option value="Fisioterapi">Fisioterapi</option>
                                          <option value="Farmasi">Farmasi</option>
                                          <option value="Gizi">Gizi</option>
                                          <option value="Rekam Medik">Rekam Medik</option>
                                          <option value="Unit Transfusi Darah Rumah Sakit (UTDRS)">Unit Transfusi Darah Rumah Sakit (UTDRS)</option>
                                          <option value="Kasir">Kasir</option>
                                          <option value="Pelayanan Ambulance">Pelayanan Ambulance</option>
                                          <option value="Gas Medis">Gas Medis</option>
                                       </select>
                                       <?= form_error('subjek_pertanyaan'); ?>
                                       <?= form_error('id_subjek'); ?>
                                    </div>
                                 </div>
                                 <div class="col-lg-12">
                                    <div class="form-group">
                                       <label class="mb-0">Tanggal pertanyaan</label>
                                       <input class="form-control" readonly type="text" placeholder="Tanggal pertanyaan..." name="tgl_pertanyaan" id="tgl_pertanyaan" value="<?= set_value('tgl_pertanyaan', indo_date($pertanyaan['tgl_pertanyaan'])); ?>">
                                       <?= form_error('tgl_pertanyaan'); ?>
                                    </div>
                                 </div>
                                 <div class="col-lg-12">
                                    <div class="form-group">
                                       <label class="mb-0">Isi pertanyaan <span style="color:red">*)</span></label>
                                       <textarea class="form-control" type="text" placeholder="Isi pertanyaan..." name="isi_pertanyaan" id="isi_pertanyaan" value="<?= set_value('isi_pertanyaan', $pertanyaan['isi_pertanyaan']); ?>"><?php echo $pertanyaan['isi_pertanyaan'] ?> </textarea>
                                       <?= form_error('isi_pertanyaan'); ?>
                                    </div>
                                 </div>
                                 <div class="col-lg-12">
                                    <div class="form-group">
                                       <label class="mb-0">Bukti pertanyaan</label>
                                                 <input type="file" id="bukti_pertanyaan" name="bukti_pertanyaan" class="form-control">
                                    </div>
                                 </div>
                              </div>
                              <a href="<?= base_url('pertanyaan') ?>" class="btn btn-danger btn-lg mt-4">Cancel</a>
                              <button type="submit" class="btn btn-primary btn-lg mt-4">Send</button>
                           <?= form_close(); ?>
                        </div>
                  
                  
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- Page end  -->
</div>
      </div>