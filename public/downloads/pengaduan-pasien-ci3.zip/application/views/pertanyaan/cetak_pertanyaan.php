<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title><?= $title; ?></title>
</head>
<body>
  <h3><center><?= $title; ?></center></h3>
  <hr>
  <table border="0" cellpadding="8" width="100%">
     <?php foreach ($pertanyaan as $row) {
 echo "<tr align='left'>";
    echo "<td>Tanggal pertanyaan</td>";
    echo "<td>:</td>";
    echo "<td>".indo_date($row['tgl_pertanyaan'])."</td>";
 echo "</tr>";
echo "<tr align='left'>";
  echo  "<td>Pengirim</td>";
  echo  "<td>:</td>";
  echo  "<td>".$row['nama']."</td>";
 echo "</tr>";
echo "<tr align='left'>";
 echo   "<td>Subjek pertanyaan</td>";
 echo  "<td>:</td>";
 echo   "<td>".$row["subjek_pertanyaan"]."</td>";
 echo "</tr>";
echo "<tr align='left'>";
 echo   "<td>Isi pertanyaan</td>";
  echo  "<td>:</td>";
  echo  "<td>".$row["isi_pertanyaan"]."</td>";
 echo "</tr>";
   echo "<tr align='left'>";
    echo "<td>Bukti pertanyaan</td>";
    echo "<td>:</td>";
    echo "<td><img src='template/html/assets/pertanyaan/".$row['bukti_pertanyaan']."' width='130px' height='100px'/></td>";
 echo "</tr>";
 } ?>
</table>
</body>
</html>