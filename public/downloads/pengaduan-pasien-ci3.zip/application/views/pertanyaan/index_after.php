<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
                  <div class="card">
                     <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                           <h4 class="card-title"><?= $title; ?></h4>
                        </div>
                        <div class="row justify-content-between">
                              
                              <div class="col-sm-12 col-md-12">
                                 <div class="pertanyaan-list-files d-flex">
                                    <a class="btn btn-primary" href="<?= base_url('pertanyaan/add') ?>">
                                       Add
                                    </a>
                                    
                                 </div>
                              </div>
                              
                           </div>
                     </div>
                     <div class="card-body">
                        <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped table-bordered" >
                           <thead>
                                 <tr>
                                    <th class="text-center">No.</th>
                                    <th class="text-center">Tanggal</th>
                                    <th class="text-center">Subjek</th>
                                    <th class="text-center">Balasan</th>
                                 </tr>
                           </thead>
                           <tbody>
<?php
                        $no = 1;
                        foreach ($pertanyaan as $row) : ?>
                                 <tr>
                                    <td class="text-center"><?= $no++; ?>.</td>
                                    <td class="text-center"><?= indo_date($row['tgl_pertanyaan']); ?></td>
                                    <td class="text-center"><?= $row['subjek_pertanyaan']; ?></td>
                                    <td class="text-center">
                                      
                                     <?php if ($row['balasan_pertanyaan'] == "Proses") { ?>
                                                                    <a title="Detail" class="btn btn-info" href="<?= base_url('pertanyaan/detail_proses/') . $row['id_pertanyaan'] ?>">PROSES</a>

                                                        <?php } ?>
                                    <?php if ($row['balasan_pertanyaan'] == "Selesai") { ?>
                                                                    <a title="Detail" class="btn btn-success" href="<?= base_url('pertanyaan/detail_selesai/') . $row['id_pertanyaan'] ?>">SELESAI</a>

                                                        <?php } ?>
                                    </td>
                                 </tr>
                                 <?php endforeach; ?>
                           </tbody>
                           </table>
                        </div>

                     </div>
                  </div>
            </div>
         </div>
      </div>
      </div>