<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title><?= $title; ?></title>
</head>
<body>
  <h3><center><?= $title; ?></center></h3>
  <hr>
  <table border="1" cellspacing="0" cellpadding="5" width="100%">
                           <thead>
                                 <tr>
                                    <th>No.</th>
                                    <th>Pengirim</th>
                                    <th>Tanggal</th>
                                    <th>Subjek</th>
                                    <th>Balasan</th>
                                 </tr>
                           </thead>
                           <tbody>
                           <?php 
                           $no=0;
                           foreach ($pertanyaan as $row) {
                              $no++;
                                 echo "<tr>";
                                 echo "<td>".$no."</td>";
                                    echo "<td>".$row['nama']."</td>";
                                    echo "<td>".indo_date($row['tgl_pertanyaan'])."</td>";
                                     echo "<td>".$row['nama_subjek']."</td>";
                                      echo "<td>".$row['balasan_pertanyaan']."</td>";
                                 echo "</tr>";
                           } ?>
                           </tbody>
                           </table>
     </div>
</body>
</html>