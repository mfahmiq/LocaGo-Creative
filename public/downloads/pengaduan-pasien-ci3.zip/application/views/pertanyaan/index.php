<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
                  <div class="card">
                     <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                           <h4 class="card-title"><?= $title; ?></h4>
                        </div>
                        <div class="row justify-content-between">
                              
                              <div class="col-sm-12 col-md-12">
                                 <div class="pertanyaan-list-files d-flex">
                                    <a class="btn btn-primary" href="<?= base_url('pertanyaan/add') ?>">
                                       Add
                                    </a>
                                    
                                 </div>
                              </div>
                              
                           </div>
                     </div>
                     <div class="card-body">
                        <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped table-bordered" >
                           <thead>
                                 <tr>
                                    <th class="text-center">No.</th>
                                    <th class="text-center">Tanggal</th>
                                    <th class="text-center">Subjek</th>
                                    <th class="text-center">Balasan</th>
                                    <th class="text-center">Aksi</th>
                                 </tr>
                           </thead>
                           <tbody>
<?php
                        $no = 1;
                        foreach ($pertanyaan as $row) : ?>
                                 <tr>
                                    <td class="text-center"><?= $no++; ?>.</td>
                                    <td class="text-center"><?= indo_date($row['tgl_pertanyaan']); ?></td>
                                    <td class="text-center"><?= $row['subjek_pertanyaan']; ?></td>
                                    <td class="text-center">
                                       <?php if ($row['balasan_pertanyaan'] == "Belum") { ?>
                                                                    <a class="btn btn-danger" href="<?= base_url('pertanyaan/detail_belum/') . $row['id_pertanyaan'] ?>">BELUM</a>

                                                        <?php } ?>
                                    
                                    </td>
                                    <td class="text-center">
                                       <div class="flex align-items-center list-pertanyaan-action">
                                          <a class="iq-bg-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Kirim" href="<?= base_url('pertanyaan/kirim_pertanyaan/') . $row['id_pertanyaan'] ?>">
                                          <i class="ri-user-add-line"></i>
                                          </a>
                                          <a class="iq-bg-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit" href="<?= base_url('pertanyaan/edit/') . $row['id_pertanyaan'] ?>"><i class="ri-pencil-line"></i></a>
                                          <a class="iq-bg-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete" onclick="return confirm('Yakin ingin hapus data?')" href="<?= base_url('pertanyaan/hapus/') . $row['id_pertanyaan'] ?>"><i class="ri-delete-bin-line"></i></a>
                                       </div>
                                    </td>
                                 </tr>
                                 <?php endforeach; ?>
                           </tbody>
                           </table>
                        </div>

                     </div>
                  </div>
            </div>
         </div>
      </div>
      </div>