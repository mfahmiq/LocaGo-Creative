
<div class="content-page">
<div class="container-fluid">
   <div class="card">
      <div class="card-body">
         <div class="row">
            <div class="col-lg-12">
               <div class="d-flex align-items-center border-bottom justify-content-between mb-4">
                  <div class="form-name">
                     <h3 class="mb-2"><?= $title ?></h3>
                     <p>Note: Tanda ini <span style="color:red">*)</span> wajib di isi!</p>
                  </div>
                  
               </div>
            </div>
            
         </div>
         <div class="row">
            <div class="col-lg-12">
                     <div class="row">
                        <div class="col-sm-12">
                            <?= form_open_multipart('', [], ['id_user' => $this->session->userdata('login_session')['user']]); ?>
                              <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                       <label class="mb-0">Subjek <span style="color:red">*)</span></label>
                                        <select data-live-search="true" name="subjek_pertanyaan" id="subjek_pertanyaan" class="selectpicker form-control" data-style="py-0">
                                          <option value="" selected disabled>Pilih Subjek</option>
                                          <option value="Gawat Darurat">Gawat Darurat</option>
                                          <option value="Rawat Jalan">Rawat Jalan</option>
                                          <option value="Ruang VIP Marwa">Ruang VIP Marwa</option>
                                          <option value="Ruang Arafah Kebidanan">Ruang Arafah Kebidanan</option>
                                          <option value="Ruang Perinatologi">Ruang Perinatologi</option>
                                          <option value="Ruang Mina Anak">Ruang Mina Anak</option>
                                          <option value="Ruang Shafa Bedah">Ruang Shafa Bedah</option>
                                          <option value="Ruang Shafa Internis">Ruang Shafa Internis</option>
                                          <option value="Ruang Paru">Ruang Paru</option>
                                          <option value="Ruang Hemodialisa">Ruang Hemodialisa</option>
                                          <option value="Ruang Raudhah ICU">Ruang Raudhah ICU</option>
                                          <option value="Ruang IBS">Ruang IBS</option>
                                          <option value="Ruang CSSD">Ruang CSSD</option>
                                          <option value="Radiologi">Radiologi</option>
                                          <option value="Laboratorium">Laboratorium</option>
                                          <option value="Fisioterapi">Fisioterapi</option>
                                          <option value="Farmasi">Farmasi</option>
                                          <option value="Gizi">Gizi</option>
                                          <option value="Rekam Medik">Rekam Medik</option>
                                          <option value="Unit Transfusi Darah Rumah Sakit (UTDRS)">Unit Transfusi Darah Rumah Sakit (UTDRS)</option>
                                          <option value="Kasir">Kasir</option>
                                          <option value="Pelayanan Ambulance">Pelayanan Ambulance</option>
                                          <option value="Gas Medis">Gas Medis</option>
                                       </select>
                                       <?= form_error('subjek_pertanyaan'); ?>
                                    </div>
                                 </div>
                                 <div class="col-lg-12">
                                    <div class="form-group">
                                       <label class="mb-0">Tanggal pertanyaan <span style="color:red">*)</span></label>
                                       <input readonly class="form-control" type="text" placeholder="Tanggal pertanyaan..." name="tgl_pertanyaan" id="tgl_pertanyaan" value="<?= indo_date(date('Y-m-d')); ?>">
                                       <?= form_error('tgl_pertanyaan'); ?>
                                    </div>
                                 </div>
                                 <div class="col-lg-12">
                                    <div class="form-group">
                                       <label class="mb-0">Isi pertanyaan <span style="color:red">*)</span></label>
                                       <textarea rows="5" cols="10" class="form-control" type="text" placeholder="Isi pertanyaan..." name="isi_pertanyaan" id="isi_pertanyaan" value="<?= set_value('isi_pertanyaan'); ?>"></textarea>
                                       <?= form_error('isi_pertanyaan'); ?>
                                    </div>
                                 </div>
                                 <div class="col-lg-12">
                                    <div class="form-group">
                                       <label class="mb-0">Bukti pertanyaan</label>
                                          <input value="<?= set_value('bukti_pertanyaan'); ?>" type="file" id="bukti_pertanyaan" name="bukti_pertanyaan" class="form-control">
                                    </div>
                                 </div>
                              </div>
                              <a href="<?= base_url('pertanyaan') ?>" class="btn btn-danger btn-lg mt-4">Cancel</a>
                              <button type="submit" class="btn btn-primary btn-lg mt-4">Add</button>
                           <?= form_close(); ?>
                        </div>
                  
                  
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- Page end  -->
</div>
      </div>