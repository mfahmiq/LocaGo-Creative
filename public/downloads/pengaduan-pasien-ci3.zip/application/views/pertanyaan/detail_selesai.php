<div class="content-page">
<div class="container-fluid">
   <div class="card">
      <div class="card-body">
         <div class="row">
            <div class="col-lg-12">
               <div class="d-flex align-items-center border-bottom justify-content-between mb-4">
                  <div class="form-name">
                     <h3 class="mb-2">Pertanyaan</h3>
                  </div>
                  
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-lg-12">
                     <div class="row">
                        <div class="col-sm-12">
                           <table border="0" cellpadding="8" width="100%">
     <?php foreach ($pertanyaan as $pertanyaan) {
 echo "<tr align='left'>";
    echo "<td>Tanggal pertanyaan</td>";
    echo "<td>:</td>";
    echo "<td>".indo_date($pertanyaan['tgl_pertanyaan'])."</td>";
 echo "</tr>";
echo "<tr align='left'>";
  echo  "<td>Pengirim</td>";
  echo  "<td>:</td>";
  echo  "<td>".$pertanyaan['nama']."</td>";
 echo "</tr>";
echo "<tr align='left'>";
 echo   "<td>Subjek pertanyaan</td>";
 echo  "<td>:</td>";
 echo   "<td>".$pertanyaan["subjek_pertanyaan"]."</td>";
 echo "</tr>";
echo "<tr align='left'>";
 echo   "<td>Isi pertanyaan</td>";
  echo  "<td>:</td>";
  echo  "<td>".$pertanyaan["isi_pertanyaan"]."</td>";
 echo "</tr>";
 
 } ?>
 <tr align='left'>
   <td>Bukti pertanyaan</td>
   <td>:</td>
   <td><button type="button" class="btn btn-info btn-lg mt-4" data-toggle="modal" data-target="#exampleModal"
                    id="#myBtn"><?php echo $pertanyaan['bukti_pertanyaan'];?>
                </button></td>
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                          aria-hidden="true">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Bukti pertanyaan</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <p class="text-center">
                                  <img src="<?= base_url() ?>template/html/assets/pertanyaan/<?php echo $pertanyaan['bukti_pertanyaan'];?>" width="400dp" height="240dp">
                                  
                                </p>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                              </div>
                            </div>
                        </div>
</tr>
<tr align='left'>
<td>Balasan pertanyaan</td>
<td>:</td>
<?php if ($pertanyaan['balasan_pertanyaan'] == "Belum") { ?>
<td style="color:red">
   <?php echo $pertanyaan['balasan_pertanyaan'];?>
</td>
<?php } ?>
<?php if ($pertanyaan['balasan_pertanyaan'] == "Proses") { ?>
<td style="color:blue">
   <?php echo $pertanyaan['balasan_pertanyaan'];?>
</td>
<?php } ?>
<?php if ($pertanyaan['balasan_pertanyaan'] == "Selesai") { ?>
<td style="color:green">
   <?php echo $pertanyaan['balasan_pertanyaan'];?>
</td>
<?php } ?>
</tr>
</table>
                        </div>
                  
                  
               </div>
            </div>
         </div>

      </div>
   </div>
   <div class="card">
      <div class="card-body">
         <div class="row">
            <div class="col-lg-12">
               <div class="d-flex align-items-center border-bottom justify-content-between mb-4">
                  <div class="form-name">
                     <h3 class="mb-2"><? $title; ?></h3>
                  </div>
                  
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-lg-12">
                     <div class="row">
                        <div class="col-sm-12">
                           <table border="0" cellpadding="8" width="100%">
     <?php foreach ($balasan as $balasan) {
       echo "<tr align='left'>";
    echo "<td>Petugas</td>";
    echo "<td>:</td>";
    echo "<td>".$balasan['nama']."</td>";
 echo "</tr>";
 echo "<tr align='left'>";
    echo "<td>Tanggal balasan</td>";
    echo "<td>:</td>";
    echo "<td>".$balasan['tgl_balasan']."</td>";
 echo "</tr>";
echo "<tr align='left'>";
 echo   "<td>Isi balasan</td>";
  echo  "<td>:</td>";
  echo  "<td>".$balasan["isi_balasan"]."</td>";
 echo "</tr>";

 } ?>
 
</table>
<?php if (is_gawatdarurat() || is_rawatjalan() || is_marwavip() || is_arafahkebidanan() || is_perinatologi() || is_minaanak() || is_shafabedah() || is_shafainternis() || is_paru() || is_hemodialisa() || is_raudhahicu() || is_ibs() || is_cssd() || is_radiologi() || is_laboratorium() || is_fisioterapi() || is_farmasi() || is_gizi() || is_rekammedik() || is_utdrs() || is_kasir() || is_pelayananambulance() || is_gasmedis()) : ?>
                             <a href="<?= base_url('petugas/daftar_pertanyaan') ?>" class="btn btn-danger btn-lg mt-4">Cancel</a>
<?php endif; ?>
<?php if (is_admin()) : ?>
                             <a href="<?= base_url('admin/daftar_pertanyaan') ?>" class="btn btn-danger btn-lg mt-4">Cancel</a>
<?php endif; ?>
<?php if (is_pasien()) : ?>
                             <a href="<?= base_url('pertanyaan/daftar_pertanyaan') ?>" class="btn btn-danger btn-lg mt-4">Cancel</a>
<?php endif; ?>
                               <a href="<?php echo base_url('pertanyaan/export_balasan/') . $pertanyaan['id_pertanyaan'] ?>" class="btn btn-primary btn-lg mt-4">Cetak</a>

                           <?= form_close(); ?>
                        </div>
                  
                  
               </div>
            </div>
         </div>
         
      </div>
   </div>
</div>
      </div>