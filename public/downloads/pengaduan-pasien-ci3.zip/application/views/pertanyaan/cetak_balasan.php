<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title><h2><?= $title; ?></h2></title>
  <hr>
</head>
<body>
  <h3><center><?= $title; ?></center></h3>
  <table border="0" cellpadding="8" width="100%">
     <?php foreach ($pertanyaan as $row) : ?>
      <tr align='left'>
    <td>Pengirim</td>
    <td>:</td>
    <td><?= $row['nama']; ?></td>
 </tr>
      <tr align='left'>
    <td>Subjek pertanyaan</td>
    <td>:</td>
    <td><?= $row['subjek_pertanyaan']; ?></td>
 </tr>
 <tr align='left'>
    <td>Tanggal pertanyaan</td>
    <td>:</td>
    <td><?= indo_date($row['tgl_pertanyaan']); ?></td>
 </tr>
 <tr align='left'>
    <td>Isi pertanyaan</td>
    <td>:</td>
    <td><?= $row['isi_pertanyaan']; ?></td>
 </tr>
  <tr align='left'>
    <td>Bukti pertanyaan</td>
    <td>:</td>
    <td><img src='template/html/assets/pertanyaan/<?= $row['bukti_pertanyaan']; ?>' width='130px' height='100px'/></td>
 </tr>
<?php endforeach; ?>
<?php foreach ($balasan as $row) : ?>
   <tr align='left'>
    <td>Petugas</td>
    <td>:</td>
    <td><?= $row['nama']; ?></td>
 </tr>
 <tr align='left'>
    <td>Tanggal Balasan</td>
    <td>:</td>
    <td><?= indo_date($row['tgl_balasan']); ?></td>
 </tr>
<tr align='left'>
 <td>Subjek pertanyaan</td>
 <td>:</td>
 <td><?= $row["subjek_pertanyaan"]; ?></td>
 </tr>
<tr align='left'>
 <td>Isi balasan</td>
  <td>:</td>
  <td><?= $row["isi_balasan"]; ?></td>
 </tr>
<?php endforeach; ?>
</table>

     </div>
</body>
</html>