<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
                  <div class="card">
                     <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                           <h4 class="card-title"><?= $title; ?></h4>
                        </div>
                        <div class="row justify-content-between">
                              
                              <div class="col-sm-12 col-md-12">
                                 <div class="user-list-files d-flex">
                                    <a class="bg-primary" href="<?= base_url('user/add') ?>">
                                       Add
                                    </a>
                                    
                                 </div>
                              </div>
                              
                           </div>
                     </div>
                     <div class="card-body">
                        <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped table-bordered">
                           <thead>
                                 <tr>
                                    <th class="text-center">No.</th>
                                    <th class="text-center">Profile</th>
                                    <th class="text-center">Username</th>
                            <th class="text-center">Level</th>
                            <th class="text-center">Nama</th>
                            <th class="text-center">No Telp</th>
                            <th class="text-center">Created At</th>
                                    <th class="text-center">Aksi</th>
                                 </tr>
                           </thead>
                           <tbody>
<?php
                        $no = 1;
                        foreach ($user as $row) : ?>
                                 <tr>
                                                                    <td class="text-center"><?= $no++; ?>.</td>

                                    <td class="text-center"><img class="img-fluid avatar-40" src="<?= base_url('template/html/assets/user/' . $row['foto']); ?>" alt="<?= $row['nama']; ?>"></td>
                                    <td class="text-center"><?= $row['username']; ?></td>
                                    <td class="text-center"><?= $row['level']; ?></td>
                                    <td class="text-center"><?= $row['nama']; ?></td>
                                    <td class="text-center"><?= $row['noTelp']; ?></td>
                                    <td class="text-center"><?= indo_date($row['created_at']); ?></td>
                                    <?php if ($row['level'] == "Admin") { ?>
                                    <td class="text-center">
                                       <div class="flex align-items-center list-user-action">
                                          <a class="iq-bg-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit" href="<?= base_url('user/edit/') . $row['id_user'] ?>"><i class="ri-pencil-line"></i></a>
                                          <a class="iq-bg-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete" onclick="return confirm('Yakin ingin hapus data?')" href="<?= base_url('user/hapus/') . $row['id_user'] ?>"><i class="ri-delete-bin-line"></i></a>
                                       </div>
                                    </td>
                                    <?php } ?>
                                    <?php if ($row['level'] != "Admin") { ?>
                                    <td class="text-center">
                                       <div class="flex align-items-center list-user-action">
                                          <a class="iq-bg-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete" onclick="return confirm('Yakin ingin hapus data?')" href="<?= base_url('user/hapus/') . $row['id_user'] ?>"><i class="ri-delete-bin-line"></i></a>
                                       </div>
                                    </td>
                                    <?php } ?>
                                 </tr>
                                 <?php endforeach; ?>
                           </tbody>
                           </table>
                        </div>

                     </div>
                  </div>
            </div>
         </div>
      </div>
      </div>