<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
                  <div class="card">
                     <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                           <h4 class="card-title"><?= $title; ?></h4>
                        </div>
                        <div class="row justify-content-between">
                              
                              
                              
                           </div>
                     </div>
                     <div class="card-body">
                        <div class="table-responsive">
                        <table id="datatable" class="table data-table table-striped table-bordered">
                           <thead>
                                 <tr>
                                    <th class="text-center">No.</th>
                                    <th class="text-center">Profile</th>
                                    <th class="text-center">Username</th>
                            <th class="text-center">Level</th>
                            <th class="text-center">Nama</th>
                            <th class="text-center">No Telp</th>
                            <th class="text-center">Created At</th>
                                 </tr>
                           </thead>
                           <tbody>
<?php
                        $no = 1;
                        foreach ($user as $row) : ?>
                                 <tr>
                                                                    <td class="text-center"><?= $no++; ?>.</td>

                                    <td class="text-center"><img class="img-fluid avatar-40" src="<?= base_url('template/html/assets/user/' . $row['foto']); ?>" alt="<?= $row['nama']; ?>"></td>
                                    <td class="text-center"><?= $row['username']; ?></td>
                                    <td class="text-center"><?= $row['level']; ?></td>
                                    <td class="text-center"><?= $row['nama']; ?></td>
                                    <td class="text-center"><?= $row['noTelp']; ?></td>
                                    <td class="text-center"><?= indo_date($row['created_at']); ?></td>
                                    
                                    
                                 </tr>
                                 <?php endforeach; ?>
                           </tbody>
                           </table>
                        </div>

                     </div>
                  </div>
            </div>
         </div>
      </div>
      </div>