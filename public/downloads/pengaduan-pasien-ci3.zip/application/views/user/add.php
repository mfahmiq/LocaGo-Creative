<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-xl-3 col-lg-4">
                  <div class="card">
                     <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                           <h4 class="card-title"><?= $title; ?></h4>
                        </div>
                     </div>
                     <div class="card-body">
                        <?= form_open_multipart(); ?>
                           <div class="form-group">
                              <div class="crm-profile-img-edit position-relative">
                                 <img class="profile-pic rounded-circle avatar-100" src="<?= base_url('template/html/assets/user') ?>" alt="foto">
                                 <div class="crm-p-image bg-primary">
                                    <i class="las la-pen upload-button"></i>
                                    <input class="file-upload" type="file" name="foto" id="foto" value="<?= set_value('foto'); ?>">
                                                                 <?= form_error('foto'); ?>
 
                                </div>
                              </div>
                           <div class="img-extension mt-3">
                              <div class="d-inline-block align-items-center">
                                    <span>Only</span>
                                 <a href="javascript:void();">.jpg</a>
                                 <a href="javascript:void();">.png</a>
                                 <a href="javascript:void();">.jpeg</a>
                                 <span>allowed</span>
                              </div>
                           </div>
                           </div>
                           <div class="form-group">
                                    <label class="mb-0">User Role:</label>
                                          <select name="level" value="<?= set_value('level'); ?>" class="selectpicker form-control" data-style="py-0" id="level">
                                          <option value="Admin">Admin</option>
                                          <option value="Gawat Darurat">Gawat Darurat</option>
                                          <option value="Rawat Jalan">Rawat Jalan</option>
                                          <option value="Ruang VIP Marwa">Ruang VIP Marwa</option>
                                          <option value="Ruang Arafah Kebidanan">Ruang Arafah Kebidanan</option>
                                          <option value="Ruang Perinatologi">Ruang Perinatologi</option>
                                          <option value="Ruang Mina Anak">Ruang Mina Anak</option>
                                          <option value="Ruang Shafa Bedah">Ruang Shafa Bedah</option>
                                          <option value="Ruang Shafa Internis">Ruang Shafa Internis</option>
                                          <option value="Ruang Paru">Ruang Paru</option>
                                          <option value="Ruang Hemodialisa">Ruang Hemodialisa</option>
                                          <option value="Ruang Raudhah ICU">Ruang Raudhah ICU</option>
                                          <option value="Ruang IBS">Ruang IBS</option>
                                          <option value="Ruang CSSD">Ruang CSSD</option>
                                          <option value="Radiologi">Radiologi</option>
                                          <option value="Laboratorium">Laboratorium</option>
                                          <option value="Fisioterapi">Fisioterapi</option>
                                          <option value="Farmasi">Farmasi</option>
                                          <option value="Gizi">Gizi</option>
                                          <option value="Rekam Medik">Rekam Medik</option>
                                          <option value="Unit Transfusi Darah Rumah Sakit (UTDRS)">Unit Transfusi Darah Rumah Sakit (UTDRS)</option>
                                          <option value="Kasir">Kasir</option>
                                          <option value="Pelayanan Ambulance">Pelayanan Ambulance</option>
                                          <option value="Gas Medis">Gas Medis</option>
                                          </select>
                                          <?= form_error('level'); ?>
                                    </div>
                     </div>
                  </div>
            </div>
            <div class="col-xl-9 col-lg-8">
                  <div class="card">
                     <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                           <h4 class="card-title">New User Information</h4>
                        </div>
                     </div>
                     <div class="card-body">
                        <div class="new-user-info">
                              <div class="row">
                                 <div class="form-group col-md-6">
                                    <label for="nama">Nama Lengkap:</label>
                                    <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Lengkap"value="<?= set_value('nama'); ?>" >
                                                                 <?= form_error('nama'); ?>
 
                                </div>
                                 <div class="form-group col-md-6">
                                    <label for="noTelp">No. Hp:</label>
                                    <input type="text" class="form-control" id="noTelp" name="noTelp" placeholder="No. Hp" value="<?= set_value('noTelp'); ?>">
                                                                 <?= form_error('noTelp'); ?>
 
                                </div>
                              </div>
                              <div class="row">
                                 <div class="form-group col-md-12">
                                    <label for="username">User Name:</label>
                                    <input type="text" class="form-control" id="username" name="username" placeholder="User Name" value="<?= set_value('username'); ?>">
                                    <?= form_error('username'); ?>
                                 </div>
                                 <div class="form-group col-md-6">
                                    <label for="password">Password:</label>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" value="<?= set_value('password'); ?>">
                                                                 <?= form_error('password'); ?>
 
                                </div>
                                 <div class="form-group col-md-6">
                                    <label for="konfpass">Ulangi Password:</label>
                                    <input type="password" class="form-control" id="konfpass" name="konfpass" placeholder="Ulangi Password" value="<?= set_value('konfpass'); ?>">
                                                                 <?= form_error('konfpass'); ?>
 
                                </div>
                              </div>
                              
                              <a href="<?= base_url('user') ?>" class="btn btn-danger btn-lg mt-3">Cancel</a>
                              <button type="submit" class="btn btn-primary btn-lg mt-3">Add</button>
                           <?= form_close(); ?>
                        </div>
                     </div>
                  </div>
            </div>
         </div>
      </div>
      </div>