<div class="iq-sidebar  sidebar-default ">
          <div class="iq-sidebar-logo d-flex align-items-center justify-content-between">
              <a href="" class="header-logo">
                  <img src="<?= base_url('template/html/'); ?>assets/images/logo.png" class="img-fluid  light-logo" alt="logo"><h5 class="logo-title text-white ml-3 mt-1">SIPPAS</h5>
              </a>
              <div class="iq-menu-bt-sidebar ">
                  <svg class="svg-icon feather feather-repeat wrapper-menu animated rotation"  xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"></polyline>
                  <path d="M3 11V9a4 4 0 0 1 4-4h14"></path><polyline points="7 23 3 19 7 15"></polyline><path d="M21 13v2a4 4 0 0 1-4 4H3"></path>
                  </svg>
              </div>
          </div>
          <div class="data-scrollbar" data-scroll="1">
              <nav class="iq-sidebar-menu">
                        <ul id="iq-sidebar-toggle" class="iq-menu">
                            <?php if (is_admin()) : ?>
                             <li class="active">
                                  <a href="<?= base_url('dashboard'); ?>" class="svg-icon">                        
                                          <svg class="svg-icon feather feather-home"  width="20" height="20" xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline>
                                          </svg>
                                      <span class="ml-3">Dashboard</span>
                                  </a>
                             </li>
                             <li class=" ">
                                            <a href="#user" class="collapsed" data-toggle="collapse" aria-expanded="false">
                                                <i class="las la-user-cog"></i><span>User Details</span>
                                                <i class="las la-angle-right iq-arrow-right arrow-active"></i>
                                                <i class="las la-angle-down iq-arrow-right arrow-hover"></i>
                                            </a>
                                            <ul id="user" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                                    
                                                    <li class="">
                                                        <a href="<?= base_url('user'); ?>">
                                                            <i class="las la-user-plus"></i><span>Petugas List</span>
                                                        </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="<?= base_url('user/pasien'); ?>">
                                                            <i class="las la-list-alt"></i><span>Pasien List</span>
                                                        </a>
                                                    </li>
                                            </ul>
                                        </li>
                                        <li class="">
                                    <a href="#pertanyaan" class="collapsed" data-toggle="collapse" aria-expanded="false">
                                        <svg class="svg-icon feather feather-file-minus" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="9" y1="15" x2="15" y2="15"></line></svg>
                                        <span class="ml-3">pertanyaan</span>
                                        <i class="las la-angle-right iq-arrow-right arrow-active"></i>
                                                <i class="las la-angle-down iq-arrow-right arrow-hover"></i>
                                    </a>
                                <ul id="pertanyaan" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                    <li class="">
                                                        <a href="<?= base_url('admin/pertanyaan_baru'); ?>">
                                                            <i class="las la-user-plus"></i><span>pertanyaan Baru</span>
                                                        </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="<?= base_url('admin/daftar_pertanyaan'); ?>">
                                                            <i class="las la-list-alt"></i><span>Daftar pertanyaan</span>
                                                        </a>
                                                    </li>
                             <?php endif; ?>
                             <?php if (is_gawatdarurat() || is_rawatjalan() || is_marwavip() || is_arafahkebidanan() || is_perinatologi() || is_minaanak() || is_shafabedah() || is_shafainternis() || is_paru() || is_hemodialisa() || is_raudhahicu() || is_ibs() || is_cssd() || is_radiologi() || is_laboratorium() || is_fisioterapi() || is_farmasi() || is_gizi() || is_rekammedik() || is_utdrs() || is_kasir() || is_pelayananambulance() || is_gasmedis()) : ?>
                                 <li class="active">
                                  <a href="<?= base_url('dashboard/petugas'); ?>" class="svg-icon">                        
                                          <svg class="svg-icon feather feather-home"  width="20" height="20" xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline>
                                          </svg>
                                      <span class="ml-3">Dashboard</span>
                                  </a>
                             </li>
                                        <li class="">
                                    <a href="#pertanyaan" class="collapsed" data-toggle="collapse" aria-expanded="false">
                                        <svg class="svg-icon feather feather-file-minus" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="9" y1="15" x2="15" y2="15"></line></svg>
                                        <span class="ml-3">pertanyaan</span>
                                        <i class="las la-angle-right iq-arrow-right arrow-active"></i>
                                                <i class="las la-angle-down iq-arrow-right arrow-hover"></i>
                                    </a>
                                <ul id="pertanyaan" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                    <li class="">
                                                        <a href="<?= base_url('petugas/pertanyaan_baru'); ?>">
                                                            <i class="las la-user-plus"></i><span>pertanyaan Baru</span>
                                                        </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="<?= base_url('petugas/daftar_pertanyaan'); ?>">
                                                            <i class="las la-list-alt"></i><span>Daftar pertanyaan</span>
                                                        </a>
                                                    </li>
                             <?php endif; ?>
                             <?php if (is_pasien()) : ?>
                             <li class="active">
                                  <a href="<?= base_url('dashboard/pasien'); ?>" class="svg-icon">                        
                                          <svg class="svg-icon feather feather-home"  width="20" height="20" xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline>
                                          </svg>
                                      <span class="ml-3">Dashboard</span>
                                  </a>
                             </li>
                            <li class="">
                                    <a href="#pertanyaan" class="collapsed" data-toggle="collapse" aria-expanded="false">
                                        <svg class="svg-icon feather feather-file-minus" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="9" y1="15" x2="15" y2="15"></line></svg>
                                        <span class="ml-3">pertanyaan</span>
                                        <i class="las la-angle-right iq-arrow-right arrow-active"></i>
                                                <i class="las la-angle-down iq-arrow-right arrow-hover"></i>
                                    </a>
                                <ul id="pertanyaan" class="iq-submenu collapse" data-parent="#iq-sidebar-toggle">
                                    <li class="">
                                                        <a href="<?= base_url('pertanyaan/add'); ?>">
                                                            <i class="las la-user-plus"></i><span>Buat pertanyaan</span>
                                                        </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="<?= base_url('pertanyaan/daftar_pertanyaan'); ?>">
                                                            <i class="las la-list-alt"></i><span>Daftar pertanyaan</span>
                                                        </a>
                                                    </li>
                                                    <!-- <li class="">
                                                        <a href="<?= base_url('pertanyaan/export'); ?>">
                                                            <i class="las la-receipt"></i><span>Cetak pertanyaan</span>
                                                        </a>
                                                    </li> -->
                             <?php endif; ?>
                                
                                </ul>
                             </li>
                        </ul>
                    </nav>
              <div class="p-3"></div>
          </div>
          </div>       
          