<div class="iq-top-navbar">
          <div class="iq-navbar-custom">
              <nav class="navbar navbar-expand-lg navbar-light">
      
              <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                  <i class="ri-menu-line wrapper-menu"></i>
                  <a class="header-logo">
                  <img src="<?= base_url('template/html/'); ?>assets/images/logo.png" class="img-fluid  light-logo" alt="logo"><h5 class="logo-title ml-3 mt-1">SIPPAS</h5>
                      
                  </a>
                  <div class="navbar-breadcrumb">
                                  <h4></h4>
                              </div>
              </div>
              <div class="d-flex align-items-center justify-content-between">
                  
                  <div class="d-flex align-items-center">
                      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"  aria-label="Toggle navigation">
                      <i class="ri-menu-3-line"></i>
                      </button>
                      <div class="collapse navbar-collapse" id="navbarSupportedContent">
                          <ul class="navbar-nav ml-auto navbar-list align-items-center">  
                          <li class="nav-item nav-icon search-content">
                                    <a href="#" class="search-toggle rounded" id="dropdownSearch" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="ri-search-line"></i>
                                    </a>
                                    <div class="iq-search-bar iq-sub-dropdown dropdown-menu" aria-labelledby="dropdownSearch">
                                        <form action="#" class="searchbox p-2">
                                            <div class="form-group mb-0 position-relative">
                                            <input type="text" class="text search-input font-size-12" placeholder="type here to search...">
                                            <a href="#" class="search-link"><i class="las la-search"></i></a> 
                                            </div>
                                        </form>
                                    </div>
                                </li>               
                          
      
                          <li class="nav-item nav-icon dropdown"> 
                              <a href="#" class="search-toggle iq-user-toggle dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <img src="<?= base_url() ?>template/html/assets/user/<?= userdata('foto'); ?>" class="img-fluid rounded-small" alt="user">
                                        </a>
                          <div class="iq-sub-dropdown dropdown-menu" aria-labelledby="dropdownMenuButton">
                                  <div class="card mb-0">
                                    
                                              <div class="card-body p-0">
                                                  <div class="profile-header">
                                                              <div class="profile-details">
                                                                  <a href="<?= base_url('profile'); ?>" class="iq-sub-card"> 
                                                                      <div class="rounded bg-info iq-card-icon-small">
                                                                          <i class="ri-file-user-line"></i>
                                                                      </div>
                                                                      <div class="media-body">
                                                                      <h5 class="mb-0">My Profile</h5>
                                                                      <p class="mb-0 font-size-14">View personal profile details</p>
                                                                      </div>
                                                                  </a>
                                                              </div>
                                                              <div class="profile-details">
                                                                  <a href="<?= base_url('profile/setting/' . userdata('id_user')); ?>" class="iq-sub-card">
                                                                      <div class="rounded bg-success iq-card-icon-small">
                                                                          <i class="ri-profile-line"></i>
                                                                      </div>
                                                                      <div class="media-body">
                                                                      <h5 class="mb-0">Edit Profile</h5>
                                                                      <p class="mb-0 font-size-14">Modify Your details</p>
                                                                      </div>
                                                                  </a>
                                                              </div>
                                                              <div class="profile-details">
                                                                  <a href="<?= base_url('profile/ubahpassword'); ?>" class="iq-sub-card border-none">
                                                                      <div class="rounded bg-warning iq-card-icon-small">
                                                                      <i class="ri-lock-line"></i>
                                                                      </div>
                                                                      <div class="media-body">
                                                                      <h5 class="mb-0">Ubah Password</h5>
                                                                      <p class="mb-0 font-size-14">Control your privacy parameters.</p>
                                                                      </div>
                                                                  </a>
                                                              </div>
                                                      
                                                  </div>
      
                                                  <a class="right-ic btn btn-primary btn-block   position-relative iq-logout" href="#logoutModal" data-toggle="modal" role="button">
                                                
                                                Log Out
                                            </a>
                                             
      
                                  </div>
                              </div>
                              </div>
                             
                          </li>                    
                          </ul>                     
                      </div> 
                  </div>
                  </div>
              </nav>
          </div>
      </div>