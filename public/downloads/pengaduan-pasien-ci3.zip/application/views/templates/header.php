<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta http-equiv="refresh" content="60" />
      <title>SIPPAS | <?= $title ?></title>
      
      <!-- Favicon -->
      <link rel="shortcut icon" href="<?= base_url('template/html/'); ?>assets/images/favicon.ico" />
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/css/backend-plugin.min.css">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/css/backend.css?v=1.0.2">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/vendor/@fortawesome/fontawesome-free/css/all.min.css">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/vendor/line-awesome/dist/line-awesome/css/line-awesome.min.css">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/vendor/remixicon/fonts/remixicon.css">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/vendor/@icon/dripicons/dripicons.css">  
      
    </head>
  <body>
    <!-- loader Start -->
    <div id="loading">
          <div id="loading-center">
          </div>
    </div>
    <!-- loader END -->
    <!-- Wrapper Start -->
    <div class="wrapper">
      
      
      
      