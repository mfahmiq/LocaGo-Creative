</div>
    </div>
    <!-- Wrapper End-->
    <footer class="iq-footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item"><a href="<?= base_url('template/html/'); ?>backend/privacy-policy.html">Privacy Policy</a></li>
                        <li class="list-inline-item"><a href="<?= base_url('template/html/'); ?>backend/terms-of-service.html">Terms of Use</a></li>
                    </ul>
                </div>
                <div class="col-lg-6 text-right">
                    Copyright 2021 <a href="#">EmailCHIMP</a>
                </div>
            </div>
        </div>
    </footer>

<!-- logoutModal -->
<div id="logoutModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm modal-dialog-scrollable modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Logout?</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body text-center">
                Yakin ingin logout?
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                <a href="<?= base_url('auth/logout') ?>" class="btn btn-danger">Logout</a>
            </div>
        </div>
    </div>
</div>
<!-- ./logoutModal -->

    <!-- Backend Bundle JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/backend-bundle.min.js"></script>
    
    <!-- Table Treeview JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/table-treeview.js"></script>
    
    <!-- SweetAlert JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/sweetalert.js"></script>
    
    <!-- Vectoe Map JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/vector-map-custom.js"></script>
    
    <!-- Chart Custom JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/chart-custom.js"></script>
    
    <!-- slider JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/slider.js"></script>
    
    <!-- app JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/app.js"></script>

     <script type="text/javascript">
        $(document).ready(function(){		
            $('.form-check-input').click(function(){
                if($(this).is(':checked')){
                    $('.form-password').attr('type','text');
                }else{
                    $('.form-password').attr('type','password');
                }
            });
        });
    </script>
    
  </body>
</html>