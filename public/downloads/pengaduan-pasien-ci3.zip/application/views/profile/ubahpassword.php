<div class="content-page">
<div class="container-fluid">
   <div class="card">
      <div class="card-body">
         <div class="row">
            <div class="col-lg-12">
               <div class="d-flex align-items-center border-bottom justify-content-between mb-4">
                  <div class="form-name">
                     <h3 class="mb-2"><?= $title ?></h3>
                  </div>
                  
               </div>
               <?= form_open(); ?>
                            <div class="card-body">
                                <div class="new-user-info">
                                        <div class="row">
                                            <div class="form-group col-md-12">
                                                <label class="form-label" for="add1">Password Lama:</label>
                                                 <input value="<?= set_value('password_lama'); ?>" name="password_lama" id="password_lama" type="password" class="form-control" placeholder="Password Lama...">
                        <?= form_error('password_lama', '<small class="text-danger">', '</small>'); ?>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label class="form-label" for="add1">Password Baru</label>
                                                 <input value="<?= set_value('password_baru'); ?>" name="password_baru" id="password_baru" type="password" class="form-control" placeholder="Password Baru...">
                        <?= form_error('password_baru', '<small class="text-danger">', '</small>'); ?>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label class="form-label" for="add1">Konfirmasi Password</label>
                                                 <input value="<?= set_value('konfirmasi_password'); ?>" name="konfirmasi_password" id="konfirmasi_password" type="password" class="form-control" placeholder="Konfirmasi Password...">
                        <?= form_error('konfirmasi_password', '<small class="text-danger">', '</small>'); ?>
                                            </div>
                                        </div>
                                        
                                        </div>
                                         <a href="<?= base_url('dashboard') ?>" class="btn btn-danger btn-lg mt-3">Cancel</a>
                              <button type="submit" class="btn btn-primary btn-lg mt-3">Update</button>
                                        
                <?= form_close(); ?>
            </div>
            
         </div>
         
      </div>
   </div>
   <!-- Page end  -->
</div>
      </div>