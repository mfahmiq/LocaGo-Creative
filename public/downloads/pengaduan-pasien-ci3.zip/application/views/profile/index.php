<style type="text/css">
   .profil {
   font-size: 18px;
   font-family: "DM Sans", sans-serif;
   }
</style>
<div class="content-page">
<div class="container-fluid">
   <div class="card">
      <div class="card-body">
         <div class="row">
            <div class="col-lg-12">
               <div class="d-flex align-items-center border-bottom justify-content-between mb-4">
                  <div class="form-name">
                     <h3 class="mb-2"><?= $title ?></h3>
                  </div>
                  
               </div>
            </div>
            <div class="row">
            
            <div class="col-md-3">
                <div class="card-body">
                <img src="<?= base_url('template/html/assets/user/') . $user['foto']; ?>" class="card-img">

                </div>
            </div>
            <div class="col-md-8">
                <div class="card-body">
                  <h5 style="font-size: 25px" class="card-title">Selamat Datang, <?= $user['nama']; ?></h5>

                  <table cellpadding="5" width="100%" class="profil">
                     <tr>
                        <th>Username</th>
                        <td>:</td>
                        <td><?= $user['username']; ?></td>
                     </tr>
                     <tr>
                        <th>Level</th>
                        <td>:</td>
                        <td><?= $user['level']; ?></td>
                     </tr>
                     <tr>
                        <th>No. Telp</th>
                        <td>:</td>
                        <td><?= $user['noTelp']; ?></td>
                     </tr>
                     <tr>
                        <th>Anggota Sejak</th>
                        <td>:</td>
                        <td><p class="card-text" style="font-size:16px"><?= indo_date($user['created_at']); ?></p></td>
                     </tr>
                  </table>

                </div>

            </div>

           
        </div>
         </div>
         
      </div>
   </div>
   <!-- Page end  -->
</div>
      </div>