<div class="content-page">
<div class="container-fluid">
   <div class="card">
      <div class="card-body">
         <div class="row">
            <div class="col-lg-12">
               <div class="d-flex align-items-center border-bottom justify-content-between mb-4">
                  <div class="form-name">
                     <h3 class="mb-2"><? $title; ?></h3>
                  </div>
                  
               </div>
            </div>
         </div>
         <div class="row">
            <div class="col-lg-12">
                     <div class="row">
                        <div class="col-sm-12">
                           <table border="0" cellpadding="8" width="100%">
<?php foreach ($pertanyaan as $row) : ?>
 <tr align='left'>
    <td>Tanggal pertanyaan</td>
    <td>:</td>
    <td><?= indo_date($row['tgl_pertanyaan']); ?></td>
 </tr>
<tr align='left'>
  <td>Pengirim</td>
  <td>:</td>
  <td><?=$row['nama']; ?></td>
 </tr>
<tr align='left'>
 <td>Subjek pertanyaan</td>
 <td>:</td>
 <td><?=$row['subjek_pertanyaan']; ?></td>
 </tr>
<tr align='left'>
 <td>Isi pertanyaan</td>
  <td>:</td>
  <td><?= $row['isi_pertanyaan']; ?></td>
 </tr>
 <tr align='left'>
   <td>Bukti pertanyaan</td>
   <td>:</td>
   <td><button type="button" class="btn btn-info btn-lg mt-4" data-toggle="modal" data-target="#exampleModal"
                    id="#myBtn"><?= $row['bukti_pertanyaan'];?>
                </button></td>
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                          aria-hidden="true">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Bukti pertanyaan</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <p class="text-center">
                                  <img src="<?= base_url('template/html/assets/pertanyaan/' . $row['']); ?>" width="400dp" height="240dp">
                                  
                                </p>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
                              </div>
                            </div>
                        </div>
</tr>
<tr align='left'>
<td>Balasan pertanyaan</td>
<td>:</td>
<?php if ($row['balasan_pertanyaan'] == "Belum") { ?>
<td style="color:red">
   <?php echo $row['balasan_pertanyaan'];?>
</td>
<?php } ?>
<?php if ($row['balasan_pertanyaan'] == "Proses") { ?>
<td style="color:blue">
   <?php echo $row['balasan_pertanyaan'];?>
</td>
<?php } ?>
<?php if ($row['balasan_pertanyaan'] == "Selesai") { ?>
<td style="color:green">
   <?php echo $row['balasan_pertanyaan'];?>
</td>
<?php } ?>
</tr>
<?php endforeach; ?>
</table>
                             <a href="<?= base_url('petugas/daftar_pertanyaan') ?>" class="btn btn-danger btn-lg mt-4">Cancel</a>
                               <a href="<?php echo base_url('pertanyaan/export_pertanyaan/') . $row['id_pertanyaan'] ?>" class="btn btn-primary btn-lg mt-4">Cetak</a>

                        </div>
                  
                  
               </div>
            </div>
         </div>

      </div>
   </div>

      </div>