<div class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
                  <div class="card">
                     <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                           <h4 class="card-title"><?= $title; ?></h4>
                        </div>
                        <div class="row justify-content-between">
                              
                              
                              
                           </div>
                     </div>
                     <div class="card-body">
                       
                        <div class="table-responsive">
                           
                        <table id="datatable" class="table data-table table-striped table-bordered" >
                           <thead>
                                 <tr>
                                    <th class="text-center">No.</th>
                                    <th class="text-center">Tanggal</th>
                                    <th class="text-center">Subjek</th>
                                    <th class="text-center">Aksi</th>
                                 </tr>
                           </thead>
                           <tbody>
<?php
                        $no = 1;
                        foreach ($pertanyaan as $row) : ?>
                                 <tr>
                                    <td class="text-center"><?= $no++; ?>.</td>
                                    <td class="text-center"><?= indo_date($row['tgl_pertanyaan']); ?></td>
                                    <td class="text-center"><?= $row['subjek_pertanyaan']; ?></td>
                                   
                                    <td class="text-center">
                                       <div class="flex align-items-center list-pertanyaan-action">
                                          <a class="iq-bg-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Balas" href="<?= base_url('petugas/balasan_pertanyaan/') . $row['id_pertanyaan'] ?>">
                                          <svg class="svg-icon feather feather feather-send" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                         <line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                                         </svg></a>
                                          
                                       </div>
                                    </td>
                                 </tr>
                                 <?php endforeach; ?>
                           </tbody>
                           </table>
                           
                        </div>
                     </div>
                  </div>
            </div>
         </div>
      </div>
      </div>