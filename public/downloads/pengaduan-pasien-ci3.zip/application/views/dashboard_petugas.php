<div class="content-page">
<div class="container-fluid">
   <div class="d-grid grid-cols-2 custom-grid-media">
      <div class="">
         <div class="card border subs-card">
            <div class="card-body">
               <div class="">
                  <div class="">
                     <h2 class="mb-2">Hi , <?= userdata('nama'); ?></h2>
                     <p class="pb-3">Anda Login sebagai <?= userdata('level'); ?></p>
                  </div>
               </div>
               <div class="subs-image">
                  <img src="<?= base_url('template/html/'); ?>assets/images/layouts/banner.png" alt="user-image" class="img-fluid">
               </div>
            </div>
         </div>
      </div>
      <div class="right-list index-list-scrollbar" data-scrollbar="true" tabindex="-1" style="overflow: hidden; outline: none;">
      <div class="scroll-content">
         <a href="<?= base_url('petugas/pertanyaan_baru') ?>" title="pertanyaan belum dibalas">
            <div class="media iq-option border align-items-center p-3">
               <div class="bg-success-light rounded p-4">
                  <img src="<?= base_url('template/html/'); ?>assets/images/belum.png" class="img-fluid avatar-50" alt="image">
               </div>
               <div class="media-body">
                  <h4 class="mb-2">pertanyaan belum dibalas</h4>
                  <p class="mb-0"><?= $proses; ?></p>
               </div>
            </div>
         </a>
          <a href="<?= base_url('petugas/daftar_pertanyaan') ?>" title="Total pertanyaan">
            <div class="media iq-option border align-items-center p-3">
               <div class="bg-info-light rounded p-4">
                  <img src="<?= base_url('template/html/'); ?>assets/images/total.png" class="img-fluid avatar-50" alt="image">
               </div>
               <div class="media-body">
                  <h4 class="mb-2">Total pertanyaan</h4>
                  <p class="mb-0"><?= $total ?></p>
               </div>
            </div>
         </a>
      </div>
      <div class="scrollbar-track scrollbar-track-x" style="display: none;">
      <div class="scrollbar-thumb scrollbar-thumb-x" style="width: 741px; transform: translate3d(0px, 0px, 0px);">
   </div>
</div>
<div class="scrollbar-track scrollbar-track-y" style="display: none;">
<div class="scrollbar-thumb scrollbar-thumb-y" style="height: 824px; transform: translate3d(0px, 0px, 0px);">
</div>
</div>
</div>
   </div>
   <!-- Page end  -->
</div>
      </div>