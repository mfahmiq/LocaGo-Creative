


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>SIPPAS | Registrasi</title>
      
      <!-- Favicon -->
      <link rel="shortcut icon" href="<?= base_url('template/html/'); ?>assets/images/favicon.ico" />
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/css/backend-plugin.min.css">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/css/backend.css?v=1.0.2">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/vendor/@fortawesome/fontawesome-free/css/all.min.css">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/vendor/line-awesome/dist/line-awesome/css/line-awesome.min.css">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/vendor/remixicon/fonts/remixicon.css">
      <link rel="stylesheet" href="<?= base_url('template/html/'); ?>assets/vendor/@icon/dripicons/dripicons.css">  </head>
  <body class=" ">
    <!-- loader Start -->
    <div id="loading">
          <div id="loading-center">
          </div>
    </div>
    <!-- loader END -->
    
      <div class="wrapper">
      <section class="login-content">
         <div class="container h-100">
            <div class="row align-items-center justify-content-center h-100">
               <div class="col-12">
                  <div class="row align-items-center">
                     <div class="col-lg-6">
                        <h2 class="mb-2"><?= $title; ?></h2>
                        <p>Enter your personal details and start journey with us.</p>
                        <?= form_open(); ?>
                           <div class="row">
                              <div class="col-lg-12">
                                 <div class="form-group">
                                    <label class="mb-0">Username</label>
                            <input value="<?= set_value('username'); ?>" type="text" id="username" name="username" class="form-control">
                                    
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <div class="form-group">
                                    <label class="mb-0">Nama Lengkap</label>
                            <input value="<?= set_value('nama'); ?>" type="text" id="nama" name="nama" class="form-control">
                                    
                                 </div>
                              </div>
                              <div class="col-lg-6">
                                 <div class="form-group">
                                    <label class="mb-0">No. Hp</label>
                            <input value="<?= set_value('noTelp'); ?>" type="text" id="noTelp" name="noTelp" class="form-control">
                                    
                                 </div>
                                                             <?= form_error('noTelp'); ?>

                              </div>
                              <div class="col-lg-6">
                                 <div class="form-group">
                                    <label class="mb-0">Password</label>
                            <input style="display: block;
  width: 100%;
  height: calc(1.5em + 0.75rem + 2px);
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  padding: 0px 0px;
  border: none;
  border-bottom: 2px solid #CCD3DC;
  height: 40px;
  background: transparent;
  -webkit-border-radius: 0px;
  -moz-border-radius: 0px;
  -ms-border-radius: 0px;
  -o-border-radius: 0px;
  border-radius: 0px;
  margin-bottom: 27px;
  height: 45px;
  line-height: 45px;
  font-size: 14px;
  color: #8E9EB1;
  box-shadow: none;" value="<?= set_value('password'); ?>" type="password" id="password" name="password" class="form-password">
                                    
                                 </div>
                                                             <?= form_error('password'); ?>

                              </div>
                              <div class="col-lg-6">
                                 <div class="form-group">
                                    <label class="mb-0">Konfirmasi Password</label>
                            <input style="display: block;
  width: 100%;
  height: calc(1.5em + 0.75rem + 2px);
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  padding: 0px 0px;
  border: none;
  border-bottom: 2px solid #CCD3DC;
  height: 40px;
  background: transparent;
  -webkit-border-radius: 0px;
  -moz-border-radius: 0px;
  -ms-border-radius: 0px;
  -o-border-radius: 0px;
  border-radius: 0px;
  margin-bottom: 27px;
  height: 45px;
  line-height: 45px;
  font-size: 14px;
  color: #8E9EB1;
  box-shadow: none;" value="<?= set_value('konfpass'); ?>" type="password" id="konfpass" name="konfpass" class="form-password">
                                                                <?= form_error('konfpass'); ?>

                                 </div>
                              </div>
                              <div class="col-lg-12">
                                 <div class="form-check mb-3">
                                                    <input type="checkbox" class="form-check-input">
                                                    <label class="form-check-label">Show Password</label>
                                                </div>
                              </div>
                             
                           </div>
                           <button type="submit" class="btn btn-primary btn-lg">Registrasi</button>
                           <p class="mt-3">
                              Sudah punya akun? silahkan <a href="<?= base_url('auth') ?>" class="text-primary">Login!</a>
                           </p>
                        <?= form_close(); ?>
                     </div>
                     <div class="col-lg-6 mb-lg-0 mb-4 mt-lg-0 mt-4">
                        <img src="<?= base_url('template/html/'); ?>assets/images/login/01.png" class="img-fluid w-80" alt="">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      </div>
    
    <!-- Backend Bundle JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/backend-bundle.min.js"></script>
    
    <!-- Table Treeview JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/table-treeview.js"></script>
    
    <!-- SweetAlert JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/sweetalert.js"></script>
    
    <!-- Vectoe Map JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/vector-map-custom.js"></script>
    
    <!-- Chart Custom JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/chart-custom.js"></script>
    
    <!-- slider JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/slider.js"></script>
    
    <!-- app JavaScript -->
    <script src="<?= base_url('template/html/'); ?>assets/js/app.js"></script>

    <script type="text/javascript">
        $(document).ready(function(){		
            $('.form-check-input').click(function(){
                if($(this).is(':checked')){
                    $('.form-password').attr('type','text');
                }else{
                    $('.form-password').attr('type','password');
                }
            });
        });
    </script>
  </body>
</html>