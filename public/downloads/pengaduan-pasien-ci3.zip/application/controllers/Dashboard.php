<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('MainModel', 'main');
        $this->load->model('TransaksiModel', 'transaksi');
        // cek_login();
    }

    public function index()
    {
        $data['title'] = "Dashboard";
        $data['pasien'] = $this->transaksi->jlhPasien();
        $data['petugas'] = $this->transaksi->jlhPetugas();
        $data['total'] = $this->transaksi->Jlhpertanyaan();
        $data['proses'] = $this->transaksi->Jlhpertanyaan_proses();
        
        template_view_dashboard('dashboard', $data);
    }

    public function petugas()
    {
        $data['title'] = "Dashboard";
        $data['total'] = $this->transaksi->Jlhpertanyaan_petugas();
        $data['proses'] = $this->transaksi->Jlhpertanyaan_proses_petugas();
        
        template_view_dashboard('dashboard_petugas', $data);
    }

    public function pasien()
    {
        $data['title'] = "Dashboard";
        $data['belum'] = $this->transaksi->Jlhpertanyaan_belum();
        $data['proses'] = $this->transaksi->Jlhpertanyaan_proses();
        $data['selesai'] = $this->transaksi->Jlhpertanyaan_selesai();
        $data['total'] = $this->transaksi->Jlhpertanyaan();
        template_view_dashboard('dashboard_pasien', $data);
    }
}
