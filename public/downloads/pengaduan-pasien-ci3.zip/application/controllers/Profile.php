<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Profile extends CI_Controller
{
    protected $user;

    public function __construct()
    {
        parent::__construct();
        // cek_login();        
        $this->load->model('MainModel', 'main');

       $userId = $this->session->userdata('login_session')['user'];
        $this->user = $this->main->get('user', ['id_user' => $userId]);
        $this->form_validation->set_error_delimiters('<small class="text-danger">', '</small>');

    }

    public function index()
    {
        $data['title'] = "Profile";
        $data['user'] = $this->user;
        template_view('profile/index', $data);
    }

    private function _validasi()
    {
        $db = $this->main->get('user', ['id_user' => $this->input->post('id_user', true)]);
        $username = $this->input->post('username', true);

        $uniq_username = $db['username'] == $username ? '' : '|is_unique[user.username]';

        $this->form_validation->set_rules('username', 'Username', 'required|trim|alpha_numeric' . $uniq_username);
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
        $this->form_validation->set_rules('noTelp', 'Nomor Telepon', 'required|trim|numeric');
    }

    private function _config()
    {
        $config['upload_path']      = "./template/html/assets/user";
        $config['allowed_types']    = 'gif|jpg|jpeg|png';
        $config['encrypt_name']     = FALSE;
        $config['max_size']         = '2048';
        $this->load->library('upload', $config);
    }

    public function setting($getId)
    {
        $id = encode_php_tags($getId);
        $data['title'] = "Edit User";
        $data['user'] = $this->main->get('user', ['id_user' => $id]);
        $username = $data['user']['username'];

        $this->form_validation->set_rules('username', 'Username', 'required|min_length[3]|trim');
        $this->form_validation->set_rules('nama', 'nama', 'required|trim');
        $this->form_validation->set_rules('noTelp', 'Nomor Telepon', 'required|numeric|trim');

        $this->_config();
        if ($this->form_validation->run() == false) {
            template_view('profile/setting', $data);
        } else {
            $input = $this->input->post(null, true);
            if (!empty($_FILES['foto']['name'])) {
                if ($this->upload->do_upload('foto')) {
                    if ($this->upload->data()) {
                        $input['foto'] = $this->upload->data('file_name');

                        $dir = FCPATH . 'template/html/assets/user/';
                        // $oldfoto = $data['user']['foto'];
                        // if (file_exists($dir . $oldfoto) && $oldfoto != 'user.png') {
                        //     if (!unlink($dir . $oldfoto)) {
                        //         echo "gagal hapus foto";
                        //         die;
                        //     }
                        // }
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        setMsg('danger', $this->upload->display_errors('', ''));
                        redirect('profile/setting/' . $id);
                    }
                }
            }
            $edit = $this->main->update('user', 'id_user', $id, $input);
            if ($edit) {
                msgBox('edit');
                redirect('profile');
            } else {
                msgBox('edit', false);
                redirect('profile/setting' . $id);
            }
        }
    }

    public function ubahpassword()
    {
        $this->form_validation->set_rules('password_lama', 'Password Lama', 'required|trim');
        $this->form_validation->set_rules('password_baru', 'Password Baru', 'required|trim|min_length[3]|differs[password_lama]');
        $this->form_validation->set_rules('konfirmasi_password', 'Konfirmasi Password', 'matches[password_baru]');
        if ($this->form_validation->run() == false) {
            $data['title'] = "Ubah Password";
            template_view('profile/ubahpassword', $data);
        } else {
            $input = $this->input->post(null, true);
            if (password_verify($input['password_lama'], userdata('password'))) {
                $new_pass = ['password' => password_hash($input['password_baru'], PASSWORD_DEFAULT)];
                $query = $this->main->update('user', 'id_user', userdata('id_user'), $new_pass);
                if ($query) {
                    setMsg('success', 'Password berhasil diubah, Silahkan Login!');
                    $this->session->unset_userdata('login_session');
                    redirect('auth');
                } else {
                    setMsg('danger', 'Perubahan gagal disimpan!', false);
                }
            } else {
                setMsg('danger', 'Password lama salah!', false);
            }
            redirect('auth/logout');
        }
    }
}
