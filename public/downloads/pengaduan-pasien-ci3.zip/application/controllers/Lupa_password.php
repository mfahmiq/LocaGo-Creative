<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Lupa_password extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_account', 'm_account');
        $this->load->model('MainModel', 'main');
    }

    public function index()
    {

        $this->form_validation->set_rules('username', 'Username', 'required|min_length[3]|trim');
        if ($this->form_validation->run() == FALSE) {
            $data['title'] = 'Lupa Password';
            $this->load->view('lupa_password', $data);
        } else {
            $username = $this->input->post('username');
            $clean = $this->security->xss_clean($username);
            $userInfo = $this->m_account->getUserInfoByUsername($clean);

            if (!$userInfo) {
                setMsg('danger', 'Username salah, silahkan coba lagi!');
                redirect(site_url('auth'), 'refresh');
            }

            //build token   

            $token = $this->m_account->insertToken($userInfo->id_user);
            $qstring = $this->base64url_encode($token);
            $url = site_url() . '/lupa_password/reset_password/token/' . $qstring;
            $link = '<a href="' . $url . '">' . $url . '</a>';

            $message = '';
            $message .= '<strong>Hai, anda menerima username ini karena ada permintaan untuk memperbaharui  
                 password anda.</strong><br>';
            $message .= '<strong>Silakan klik link ini:</strong> ' . $link;

            echo $message; //send this through mail  
            exit;
        }
    }

    public function reset_password()
    {
        $token = $this->base64url_decode($this->uri->segment(4));
        $cleanToken = $this->security->xss_clean($token);

        $user_info = $this->m_account->isTokenValid($cleanToken); //either false or array();          

        if (!$user_info) {
            setMsg('danger', 'Token tidak valid atau kadaluarsa');
            redirect(site_url('auth'), 'refresh');
        }

        $data = array(
            'title' => 'Reset Password',
            'nama' => $user_info->nama,
            'username' => $user_info->username,
            'token' => $this->base64url_encode($token)
        );

        $this->form_validation->set_rules('password', 'Password', 'required|min_length[5]');
        $this->form_validation->set_rules('passconf', 'Password Confirmation', 'required|matches[password]');

        if ($this->form_validation->run() == FALSE) {
            $this->data['title'] = "Reset Password";
            $this->load->view('reset_password', $data);
        } else {
            $post = $this->input->post(NULL, TRUE);
            $cleanPost = $this->security->xss_clean($post);
            $hashed = md5($cleanPost['password']);
            $cleanPost['password'] = $hashed;
            $cleanPost['id_user'] = $user_info->id_user;
            unset($cleanPost['passconf']);
            if (!$this->m_account->updatePassword($cleanPost)) {
                setMsg('danger', 'Update password gagal, silahkan coba lagi!');
            } else {
                setMsg('danger', 'Password anda sudah diperbaharui. Silakan login!');
            }
            redirect(site_url('auth'), 'refresh');
            
        }
    }

    public function base64url_encode($data)
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    public function base64url_decode($data)
    {
        return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
    }
}