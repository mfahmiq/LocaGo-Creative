<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        // cek_login();
        //        is_main();

        $this->load->model('MainModel', 'main');
                $this->load->model('TransaksiModel', 'transaksi');

        $this->form_validation->set_error_delimiters('<small class="text-danger">', '</small>');
    }

    public function index()
    {
        $data['title'] = "List User";
        $data['user'] = $this->transaksi->getPetugas();

        template_view('user/index', $data);
    }

    public function pasien()
    {
        $data['title'] = "List User";
        $data['user'] = $this->transaksi->getPasien();

        template_view('user/index_pasien', $data);
    }

    private function _config()
    {
        $config['upload_path']      = './template/html/assets/user/';
        $config['allowed_types']    = 'gif|jpg|jpeg|png';
        $config['max_size']         = '2048';
        $config['encrypt_name']     = FALSE;

        $this->load->library('upload', $config);
    }

    public function add()
    {
        $this->_config();
        $this->form_validation->set_rules('username', 'Username', 'required|trim|is_unique[user.username]|alpha_numeric');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[3]|trim');
        $this->form_validation->set_rules('konfpass', 'Konfirmasi Password', 'matches[password]|trim');
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');
        $this->form_validation->set_rules('noTelp', 'Nomor Telepon', 'required|trim');
        $this->form_validation->set_rules('level', 'level', 'required|trim');

        if ($this->form_validation->run() == false || $this->upload->do_upload('foto') == false) {
            $data['title'] = "Add User";
            template_view('user/add', $data);
        } else {
            $input = $this->input->post(null, true);
            unset($input['konfpass']);
            $input['password'] = password_hash($input['password'], PASSWORD_DEFAULT);
            $input['foto'] = $this->upload->data('file_name');
            $input['created_at']    = date('Y-m-d');

            $save = $this->main->insert('user', $input);
            if ($save) {
                msgBox('save');
            } else {
                msgBox('save', false);
            }
            redirect('user');
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);

        $data['title'] = "Edit User";
        $data['user'] = $this->main->get('user', ['id_user' => $id]);
        $username = $data['user']['username'];

        $this->form_validation->set_rules('username', 'Username', 'required|min_length[3]|trim');
        $this->form_validation->set_rules('nama', 'nama', 'required|trim');
        $this->form_validation->set_rules('noTelp', 'Nomor Telepon', 'required|numeric|trim');

        $this->_config();
        if ($this->form_validation->run() == false) {
            template_view('user/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            if (!empty($_FILES['foto']['name'])) {
                if ($this->upload->do_upload('foto')) {
                    if ($this->upload->data()) {
                        $input['foto'] = $this->upload->data('file_name');

                        $dir = FCPATH . 'template/html/assets/user/';
                        // $oldfoto = $data['user']['foto'];
                        // if (file_exists($dir . $oldfoto) && $oldfoto != 'user.png') {
                        //     if (!unlink($dir . $oldfoto)) {
                        //         echo "gagal hapus foto";
                        //         die;
                        //     }
                        // }
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        setMsg('danger', $this->upload->display_errors('', ''));
                        redirect('user/edit/' . $id);
                    }
                }
            }
            $edit = $this->main->update('user', 'id_user', $id, $input);
            if ($edit) {
                msgBox('edit');
                redirect('user');
            } else {
                msgBox('edit', false);
                redirect('user/edit' . $id);
            }
        }
    }

    public function hapus($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->main->delete('user', 'id_user', $id)) {
            setMsg('sucess','data berhasil dihapus.');
        } else {
            setMsg('danger','data gagal dihapus.', false);
        }
        redirect('user');
    }
}
