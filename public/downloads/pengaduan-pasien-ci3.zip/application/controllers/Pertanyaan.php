<?php
defined('BASEPATH') or exit('No direct script access allowed');

use Fpdf\Fpdf;
class pertanyaan extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        // cek_login();
        $this->load->model('MainModel', 'main');
        $this->load->model('TransaksiModel', 'transaksi');
        $this->form_validation->set_error_delimiters('<small class="text-danger">', '</small>');
    }

    public function pertanyaan_pasien(){
        $balasan_pertanyaan = $this->transaksi->getpertanyaan_belum();
        if($balasan_pertanyaan = $this->transaksi->getpertanyaan_belum()){
            redirect('pertanyaan');
        }
        elseif($balasan_pertanyaan = $this->transaksi->getpertanyaan_proses()){
            redirect('pertanyaan/index_after');
        }
        else{
            redirect('pertanyaan/index_after');
        }
    }

    public function index()
    {
        $data['title'] = "List Pertanyaan";
        $data['pertanyaan'] = $this->transaksi->getpertanyaan_belum();

        template_view('pertanyaan/index', $data);
    }

    public function index_after()
    {
        $data['title'] = "List Pertanyaan";
        $data['pertanyaan'] = $this->transaksi->getpertanyaan_proses();

        template_view('pertanyaan/index_after', $data);
    }

    public function daftar_pertanyaan()
    {
        $data['title'] = "List Pertanyaan";
        $data['pertanyaan'] = $this->transaksi->getpertanyaan_user();

        template_view('pertanyaan/list_pertanyaan', $data);
    }

    private function _config()
    {
        $config['upload_path']      = './template/html/assets/pertanyaan/';
        $config['allowed_types']    = 'jpg|jpeg|png|pdf';
        $config['max_size']         = '4096';
        $config['encrypt_name']     = FALSE;

        $this->load->library('upload', $config);
    }

    private function _validasi()
    {
        // $this->form_validation->set_rules('tgl_pertanyaan', 'Tanggal pertanyaan', 'required|trim');
        $this->form_validation->set_rules('isi_pertanyaan', 'Isi pertanyaan', 'required|trim');
        $this->form_validation->set_rules('subjek_pertanyaan', 'Subjek pertanyaan', 'required');
        $this->form_validation->set_rules('id_user', 'User', 'required');
        

    }

    public function add()
    {
        $data['title'] = "Add Pertanyaan";
        $data['user'] = $this->main->get('user');

        $this->_validasi();
        $this->_config();
        if ($this->form_validation->run() == false) {
            template_view('pertanyaan/add', $data);
        } else {
            $input = $this->input->post(null, true);
            if (!empty($_FILES['bukti_pertanyaan']['name'])) {
                if ($this->upload->do_upload('bukti_pertanyaan')) {
                    if ($this->upload->data()) {
                        $bukti_pertanyaan = $this->upload->data('file_name');

                        $dir = FCPATH . 'template/html/assets/pertanyaan/';
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        setMsg('danger', $this->upload->display_errors('', ''));
                        redirect('user/add');
                    }
                }
            }
            date_default_timezone_set('Asia/Jakarta');
            $input_data = [
                'tgl_pertanyaan' => date('Y-m-d'),
                'isi_pertanyaan' => $input['isi_pertanyaan'],
                'subjek_pertanyaan' => $input['subjek_pertanyaan'],
                'id_user' => $this->session->userdata('login_session')['user'],
                'bukti_pertanyaan' => $bukti_pertanyaan,
                'waktu' => date('h:i:s a')
            ];

            $save = $this->main->insert('pertanyaan', $input_data);
            if ($save) {
                msgBox('save');
                redirect('pertanyaan');
            } else {
                msgBox('save', false);
                redirect('pertanyaan/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pertanyaan' => $id];

        $data['title'] = 'Edit Pertanyaan';
        $data['user'] = $this->main->get('user');
        $data['pertanyaan'] = $this->main->get('pertanyaan', ['id_pertanyaan' => $id]);

        $this->_validasi();
        $this->_config();
        if ($this->form_validation->run() == false) {
            template_view('pertanyaan/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            if (!empty($_FILES['bukti_pertanyaan']['name'])) {
                if ($this->upload->do_upload('bukti_pertanyaan')) {
                    if ($this->upload->data()) {
                        $bukti_pertanyaan = $this->upload->data('file_name');

                        $dir = FCPATH . 'template/html/assets/pertanyaan/';
                    }
                } else {
                    if ($this->upload->display_errors()) {
                        setMsg('danger', $this->upload->display_errors('', ''));
                        redirect('user/edit/' . $id);
                    }
                }
            }
            $balasan_pertanyaan = "Proses";
            $input_data = [
                'tgl_pertanyaan' => date('Y-m-d'),
                'isi_pertanyaan' => $input['isi_pertanyaan'],
                'subjek_pertanyaan' => $input['subjek_pertanyaan'],
                'id_user' => $this->session->userdata('login_session')['user'],
                'bukti_pertanyaan' => $bukti_pertanyaan,
                'balasan_pertanyaan' => $balasan_pertanyaan
            ];
            $edit = $this->main->update('pertanyaan', 'id_pertanyaan', $id, $input_data);
            if ($edit) {
                msgBox('edit');
                redirect('pertanyaan');
            } else {
                msgBox('edit', false);
                redirect('pertanyaan/edit/' . $id);
            }
        }
    }

    public function hapus($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pertanyaan' => $id];

            $del = $this->main->delete('pertanyaan', 'id_pertanyaan', $id);
            if ($del) {
                msgBox('delete');
                redirect('pertanyaan');
            } else {
                msgBox('delete', false);
                redirect('pertanyaan');
            }
    }

    public function detail_selesai($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pertanyaan' => $id];

        $data['title'] = 'Balasan';
        $data['pertanyaan'] = $this->transaksi->getpertanyaanbyselesai($where);
        $data['balasan'] = $this->transaksi->getbalasan_selesai($id);

        template_view('pertanyaan/detail_selesai', $data);
    }

    public function detail_proses($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pertanyaan' => $id];
        $data['title'] = 'Pertanyaan';
        $data['pertanyaan'] = $this->transaksi->getpertanyaanbyproses($where);
        template_view('pertanyaan/detail_proses', $data);
    }

    public function detail_belum($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pertanyaan' => $id];
        $data['title'] = 'Pertaanyaan';
        $data['pertanyaan'] = $this->transaksi->getpertanyaanbybelum($where);


        template_view('pertanyaan/detail_belum', $data);
    }

    public function export(){
        $data['title'] = 'Laporan Pertanyaan';
        $data['pertanyaan'] = $this->transaksi->getpertanyaan_user();
        $this->load->library('pdf');
	    $this->pdf->setPaper('A4', 'landscape');
	    $this->pdf->filename = "Laporan-Pertanyaan". date('-d-m-Y');
	    $this->pdf->load_view('pertanyaan/list_pertanyaan', $data);
    }

     public function export_balasan($getId){
        $id = encode_php_tags($getId);
        $where = ['id_pertanyaan' => $id];
        $data['title'] = 'Detail Balasan';
        $data['pertanyaan'] = $this->transaksi->getpertanyaanbyselesai($where);
        $data['balasan'] = $this->transaksi->getbalasan_selesai($id);
        $this->load->library('pdf');
	    $this->pdf->setPaper('A4', 'landscape');
	    $this->pdf->filename = "Laporan-Balasan". date('-d-m-Y');
	    $this->pdf->load_view('pertanyaan/cetak_balasan', $data);
    }

    public function export_pertanyaan($getId){
        $id = encode_php_tags($getId);
        $where = ['id_pertanyaan' => $id];

        $data['title'] = 'Detail Pertanyaan';
        $data['pertanyaan'] = $this->transaksi->getpertanyaanbyId($where);
        $this->load->library('pdf');
	    $this->pdf->setPaper('A4', 'landscape');
	    $this->pdf->filename = "Laporan-Pertanyaan". date('-d-m-Y');
	    $this->pdf->load_view('pertanyaan/cetak_pertanyaan', $data);
    }

    public function get_proses()
    {
        $data['title'] = "List Pertanyaan";
        $data['pertanyaan'] = $this->transaksi->getpertanyaan_proses();

        template_view('pertanyaan/index_after', $data);
    }

    public function get_selesai()
    {
        $data['title'] = "List Pertanyaan";
        $data['pertanyaan'] = $this->transaksi->getpertanyaan_selesai();

        template_view('pertanyaan/index_after', $data);
    }

    public function total_pertanyaan()
    {
        $data['title'] = "List Pertanyaan";
        $data['pertanyaan'] = $this->transaksi->getpertanyaan();

        template_view('pertanyaan/list_pertanyaan', $data);
    }

    public function kirim_pertanyaan($getId)
    {
        $id = encode_php_tags($getId);
        $input_data = [
            'balasan_pertanyaan' => "Proses"
        ];
        $update = $this->main->update('pertanyaan', 'id_pertanyaan', $id, $input_data);
        if ($update) {
            msgBox('save');
            redirect('pertanyaan/index_after');
        } else {
            msgBox('save', false);
            redirect('pertanyaan');
        }
    }
    
}
