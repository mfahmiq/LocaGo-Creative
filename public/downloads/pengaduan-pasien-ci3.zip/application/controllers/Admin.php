<?php
defined('BASEPATH') or exit('No direct script access allowed');
use Fpdf\Fpdf;
class Admin extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        // cek_login();
        $this->load->model('MainModel', 'main');
        $this->load->model('TransaksiModel', 'transaksi');
        $this->form_validation->set_error_delimiters('<small class="text-danger">', '</small>');
    }
    
    public function pertanyaan_baru()
    {
        $data['title'] = "Pertanyaan Baru";
        $data['pertanyaan'] = $this->transaksi->getpertanyaanbaru();

        template_view('admin/pertanyaan_baru', $data);
    }

     public function daftar_pertanyaan()
    {
        $data['title'] = "Daftar Pertanyaan";
        $data['pertanyaan'] = $this->transaksi->getpertanyaan();

        template_view('admin/daftar_pertanyaan', $data);
    }

     public function balasan_pertanyaan($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pertanyaan' => $id];
        $data['pertanyaan'] = $this->transaksi->getpertanyaanbyId($where);
        $data['title'] = "Balasan";

    //    $this->form_validation->set_rules('tgl_balasan', 'Tanggal pertanyaan', 'required|trim');
        $this->form_validation->set_rules('isi_balasan', 'Isi pertanyaan', 'required|trim');

        if ($this->form_validation->run() == false) {
            template_view('admin/balasan_pertanyaan', $data);
        } else {
            $input = $this->input->post(null, true);
            $status_balasan = "Selesai";
            $input_data = [
                'tgl_balasan' => date('Y-m-d'),
                'isi_balasan' => $input['isi_balasan'],
                'id_user' => $input['id_user'],
                'id_pertanyaan' => $id,
                'status_balasan' => $status_balasan
            ];
             $save = $this->main->insert('balasan', $input_data);
            if ($save) {
                msgBox('save');
                $input = $this->input->post(null, true);
                $balasan_pertanyaan = "Selesai";
                $input_data = [
                    'balasan_pertanyaan' => $balasan_pertanyaan
                ];
                $edit = $this->main->update('pertanyaan', 'id_pertanyaan', $id, $input_data);
                redirect('admin/daftar_pertanyaan');
            } else {
                msgBox('save', false);
                redirect('admin/balasan_pertanyaan/' . $id);
            }
        }
    }

    public function detail_selesai($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pertanyaan' => $id];

        $data['title'] = "Balasan";
        $data['pertanyaan'] = $this->transaksi->getpertanyaanbyselesai($where);
        $data['balasan'] = $this->transaksi->getbalasan_selesai($id);
        
        template_view('admin/detail_selesai', $data);
    }

    public function detail_proses($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pertanyaan' => $id];

        $data['title'] = "Pertanyaan";
        $data['pertanyaan'] = $this->transaksi->getpertanyaanbyproses($where);


        template_view('admin/detail_proses', $data);
    }

    public function detail_belum($getId)
    {
        $id = encode_php_tags($getId);
        $where = ['id_pertanyaan' => $id];

        $data['title'] = "Pertanyaan";
        $data['pertanyaan'] = $this->transaksi->getpertanyaanbybelum($where);


        template_view('admin/detail_belum', $data);
    }

    
}
