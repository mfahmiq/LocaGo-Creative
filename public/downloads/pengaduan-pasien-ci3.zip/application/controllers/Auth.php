<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('MainModel', 'main');
        $this->form_validation->set_error_delimiters('<small class="text-danger">', '</small>');
    }

        private function _has_login()
    {
        if ($this->session->has_userdata('login_session')) {
            redirect('profile');
        }
    }
    
    public function index()
    {
        $this->_has_login();
        $data['title'] = "Login";

        $this->form_validation->set_rules('username', 'Username', 'required|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('login', $data);
        } else {
            $input = $this->input->post(null, true);
            $cek_username = $this->main->cek_username($input['username']);
            if ($cek_username > 0) {
                $password = $this->main->get_password($input['username']);
                if (password_verify($input['password'], $password)) {
                    $user_db = $this->main->userdata($input['username']);
                    $userdata = [
                            'user'  => $user_db['id_user'],
                            'level'  => $user_db['level'],
                        ];
                        $this->session->set_userdata('login_session', $userdata);
                        redirect('profile');
                } else {
                    setMsg('danger', 'Password Salah!');
                    redirect('auth');
                } 
            }
            else {
                setMsg('danger', 'Username tidak ditemukan');
                redirect('auth');
            }
        }
    }

    public function logout()
    {
         $this->session->unset_userdata('login_session');
        setMsg("success", "Logout berhasil!");
        redirect('auth');
    }

     public function register()
    {

        $this->form_validation->set_rules('username', 'Username', 'required|min_length[3]|trim|is_unique[user.username]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[5]|trim');
        $this->form_validation->set_rules('konfpass', 'Konfirmasi Password', 'required|matches[password]');
        $this->form_validation->set_rules('nama', 'nama', 'required|trim');
        $this->form_validation->set_rules('noTelp', 'Nomor Telepon', 'required|numeric|trim');

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Registrasi';
            $this->load->view('registrasi', $data);
        } else {
            $input = $this->input->post(null, true);
            unset($input['konfpass']);
            $input['password']      = password_hash($input['password'], PASSWORD_DEFAULT);
            $input['level']         = 'Pasien';
            $input['foto']          = 'user.png';
            $input['created_at']    = date('Y-m-d');

            $query = $this->main->insert('user', $input);
            if ($query) {
                setMsg('success', 'Registrasi berhasil, silahkan login!');
                redirect('auth');
            } else {
                setMsg('danger', 'Gagal Registrasi, Silahkan coba lagi!');
                redirect('auth/register');
            }
        }
    }

    public function lupa_password(){
        $this->form_validation->set_rules('username', 'Username', 'required|min_length[3]|trim|is_unique[user.username]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[5]|trim');
        $this->form_validation->set_rules('konfpass', 'Konfirmasi Password', 'required|matches[password]');
        if ($this->form_validation->run() == false) {
            $data['title'] = 'Lupa Password';
            $this->load->view('lupa_password', $data);
        } else {
            $input = $this->input->post(null, true);
            unset($input['konfpass']);
            $input['password']      = password_hash($input['password'], PASSWORD_DEFAULT);

            $query = $this->main->update('user', $input);
            if ($query) {
                setMsg('success', "Ubah Password berhasil, silahkan login!");
                redirect('auth');
            } else {
                setMsg('danger', 'Gagal Ubah Password, Silahkan coba lagi!');
                redirect('auth/lupa_password');
            }
        }
    }

    public function reset_password(){
        $data['title'] = 'Ganti Password';
        $this->load->view('reset_password', $data);
    }
}
