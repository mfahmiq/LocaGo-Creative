<?php
defined('BASEPATH') or exit('No direct script access allowed');

class TransaksiModel extends CI_Model
{



    public function getpertanyaan_user()
    {
        $balasan_pertanyaan = "Belum";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
        $this->db->where('b.balasan_pertanyaan !=', $balasan_pertanyaan);
        $this->db->order_by('id_pertanyaan desc');
        return $this->db->get('pertanyaan b')->result_array();
    }

    public function getbalasan_user()
    {
        $status_balasan = "Selesai";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.status_balasan', $status_balasan);
        $this->db->join('pertanyaan p', 'b.id_pertanyaan = p.id_pertanyaan');
        $this->db->order_by('id_balasan');
        return $this->db->get('balasan b')->result_array();
    }

    public function jlhpertanyaan()
    {
        $balasan_pertanyaan = "Belum";
        $this->db->where('b.balasan_pertanyaan !=', $balasan_pertanyaan);
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->order_by('id_pertanyaan');
        $query = $this->db->get('pertanyaan b');
                return $query->num_rows();
    }

    public function getpertanyaanbyId($where)
    {
        $this->db->join('user k', 'k.id_user=b.id_user');
        return $this->db->get_where('pertanyaan b', $where)->result_array();
    }

    public function getPasien()
    {
        $level = "Pasien";
        $this->db->where('level =', $level);
        return $this->db->get('user')->result_array();
    }

    public function jlhPasien()
    {
        $level = "Pasien";
        $this->db->where('level =', $level);
        $query = $this->db->get('user');
        return $query->num_rows();
    }

    public function getPetugas()
    {
        $level = "Pasien";
        $this->db->where('level !=', $level);
        return $this->db->get('user')->result_array();
    }

    public function jlhPetugas()
    {
        $level = "Pasien";
        $this->db->where('level !=', $level);
        $query = $this->db->get('user');
        return $query->num_rows();
    }

    public function jlhpertanyaan_belum()
    {
        $balasan_pertanyaan = "Belum";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.balasan_pertanyaan', $balasan_pertanyaan);
        $query = $this->db->get('pertanyaan b');
        return $query->num_rows();
    }

    public function jlhpertanyaan_proses()
    {
        $balasan_pertanyaan = "Proses";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.balasan_pertanyaan', $balasan_pertanyaan);
        $query = $this->db->get('pertanyaan b');
        return $query->num_rows();
    }

    public function jlhpertanyaan_selesai()
    {
        $balasan_pertanyaan = "Selesai";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.balasan_pertanyaan', $balasan_pertanyaan);
        $query = $this->db->get('pertanyaan b');
        return $query->num_rows();
    }

    public function getpertanyaan_belum()
    {
        $balasan_pertanyaan = "Belum";
        $this->db->join('user j', 'b.id_user = j.id_user');
         $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
         $this->db->where('b.balasan_pertanyaan', $balasan_pertanyaan);
        $this->db->order_by('id_pertanyaan');
        return $this->db->get('pertanyaan b')->result_array();
    }

    public function getpertanyaan_proses()
    {
        $balasan_pertanyaan = "Proses";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
         $this->db->where('b.balasan_pertanyaan', $balasan_pertanyaan);
        $this->db->order_by('id_pertanyaan');
        return $this->db->get('pertanyaan b')->result_array();
    }

    public function getpertanyaan_selesai()
    {
        $balasan_pertanyaan = "Selesai";
        $this->db->join('user j', 'b.id_user = j.id_user');
         $this->db->where('b.balasan_pertanyaan', $balasan_pertanyaan);
        $this->db->order_by('id_pertanyaan');
        return $this->db->get('pertanyaan b')->result_array();
    }

    public function getpertanyaanbybelum($where)
    {
        $balasan_pertanyaan = "Belum";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_user', $this->session->userdata('login_session')['user']);
         $this->db->where('b.balasan_pertanyaan', $balasan_pertanyaan);
        $this->db->order_by('id_pertanyaan');
        return $this->db->get_where('pertanyaan b', $where)->result_array();
    }

     public function getpertanyaanbyproses($where)
    {
        $balasan_pertanyaan = "Proses";
        $this->db->join('user j', 'b.id_user = j.id_user');
         $this->db->where('b.balasan_pertanyaan', $balasan_pertanyaan);
        $this->db->order_by('id_pertanyaan');
        return $this->db->get_where('pertanyaan b', $where)->result_array();
    }


    public function getpertanyaanbyselesai($where)
    {
        $balasan_pertanyaan = "Selesai";
        $this->db->join('user j', 'b.id_user = j.id_user');
         $this->db->where('b.balasan_pertanyaan', $balasan_pertanyaan);
        $this->db->order_by('id_pertanyaan');
        return $this->db->get_where('pertanyaan b', $where)->result_array();
    }

    public function getbalasan_selesai($id)
    {
        $status_balasan = "Selesai";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->join('pertanyaan p', 'b.id_pertanyaan = p.id_pertanyaan');
        $this->db->where('b.status_balasan', $status_balasan);
        $this->db->where('b.id_pertanyaan', $id);
        $this->db->order_by('id_balasan');
        return $this->db->get('balasan b')->result_array();
    }

    public function getpertanyaanbaru()
    {
        $balasan_pertanyaan = "Proses";
        $this->db->select('*');
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_pertanyaan not in (SELECT id_pertanyaan FROM balasan)');
        $this->db->where('b.balasan_pertanyaan', $balasan_pertanyaan);
        $this->db->order_by('id_pertanyaan');
        return $this->db->get('pertanyaan b')->result_array();
    }

    public function getpertanyaan()
    {   
        $balasan_pertanyaan = "Belum";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.balasan_pertanyaan !=', $balasan_pertanyaan);
        $this->db->order_by('id_pertanyaan');
        return $this->db->get('pertanyaan b')->result_array();
    }

    public function getpertanyaanbaru_gawatdarurat()
    {
        $balasan_pertanyaan = "Proses";
        $subjek_pertanyaan = "Gawat Darurat";
        $this->db->select('*');
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_pertanyaan not in (SELECT id_pertanyaan FROM balasan)');
        $this->db->where('b.balasan_pertanyaan', $balasan_pertanyaan);
        $this->db->where('b.subjek_pertanyaan', $subjek_pertanyaan);
         $this->db->order_by('id_pertanyaan');
        return $this->db->get('pertanyaan b')->result_array();
    }

    public function getpertanyaan_gawatdarurat()
    {   
        $balasan_pertanyaan = "Belum";
        $subjek_pertanyaan = "Gawat Darurat";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.balasan_pertanyaan !=', $balasan_pertanyaan);
        $this->db->where('b.subjek_pertanyaan', $subjek_pertanyaan);
        $this->db->order_by('id_pertanyaan');
        return $this->db->get('pertanyaan b')->result_array();
    }

    public function getpertanyaanbaru_petugas()
    {
        $ci = get_instance();
        $level = $ci->session->userdata('login_session')['level'];
        $balasan_pertanyaan = "Proses";
        $this->db->select('*');
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.id_pertanyaan not in (SELECT id_pertanyaan FROM balasan)');
        $this->db->where('b.balasan_pertanyaan', $balasan_pertanyaan);
        $this->db->where('b.subjek_pertanyaan =', $level);
         $this->db->order_by('id_pertanyaan');
        return $this->db->get('pertanyaan b')->result_array();
    }

    public function getpertanyaan_petugas()
    {   
        $ci = get_instance();
        $level = $ci->session->userdata('login_session')['level'];
        $balasan_pertanyaan = "Belum";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.balasan_pertanyaan !=', $balasan_pertanyaan);
        $this->db->where('b.subjek_pertanyaan =', $level);
        $this->db->order_by('id_pertanyaan');
        return $this->db->get('pertanyaan b')->result_array();
    }

    public function jlhpertanyaan_proses_petugas()
    {
        $ci = get_instance();
        $level = $ci->session->userdata('login_session')['level'];
        $balasan_pertanyaan = "Proses";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->where('b.balasan_pertanyaan', $balasan_pertanyaan);
        $this->db->where('b.subjek_pertanyaan =', $level);
        $query = $this->db->get('pertanyaan b');
        return $query->num_rows();
    }

    public function jlhpertanyaan_petugas()
    {
        $ci = get_instance();
        $level = $ci->session->userdata('login_session')['level'];
        $balasan_pertanyaan = "Belum";
        $this->db->join('user j', 'b.id_user = j.id_user');
        $this->db->order_by('id_pertanyaan');
        $this->db->where('b.balasan_pertanyaan !=', $balasan_pertanyaan);
        $this->db->where('b.subjek_pertanyaan =', $level);
        $query = $this->db->get('pertanyaan b');
        return $query->num_rows();
    }
}
