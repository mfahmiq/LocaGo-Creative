<?php
function template_view($view, $data)
{
    $ci = get_instance();
    $ci->load->view('templates/header', $data);
    $ci->load->view('templates/topnav');
    $ci->load->view('templates/sidenav');
    $ci->load->view($view);
    $ci->load->view('templates/footer');
}

function template_view_dashboard($view, $data)
{
    $ci = get_instance();
    $ci->load->view('templates/header_dashboard', $data);
    $ci->load->view('templates/topnav');
    $ci->load->view('templates/sidenav');
    $ci->load->view($view);
    $ci->load->view('templates/footer');
}

function setMsg($type, $msg){
    $ci = get_instance();
    $text = "";
    $text .= "<div class='alert text-white bg-{$type}' role='alert'>";
    $text .= "<div class='iq-alert-text'>{$msg}</div>";
    $text .= "<button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                           <i class='ri-close-line'></i>
                           </button>
                        </div>";
    return $ci->session->set_flashdata('msg', $text);
}

function msgBox($msg = "save", $success = true)
{
    switch ($msg) {
        case "save":
            $pesan = $success ? "Data berhasil disimpan!" : "Gagal menyimpan data!";
            break;
        case "edit":
            $pesan = $success ? "Data berhasil diedit!" : "Gagal mengedit data!";
            break;
        case "delete":
            $pesan = $success ? "Data berhasil dihapus!" : "Gagal menghapus data!";
            break;
        default:
            $pesan = "";
            break;
    }
    $title = $success ? "Berhasil!" : "Gagal!";
    $type = $success ? "success" : "error";
    $alert = "
        <script type='text/javascript'>
        $(document).ready(function() {
            Swal.fire(
                '{$title}',
                '{$pesan}',
                '{$type}'
            );
        });
        </script>
    ";
    $ci = get_instance();
    return $ci->session->set_flashdata('pesan', $alert);
}


function cek_login()
{
    $ci = get_instance();
    if (!$ci->session->has_userdata('login_session')) {
        setMsg("success", "Login Berhasil!");
        redirect('auth');
    }
}

function is_admin()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Admin') {
        $status = false;
    }

    return $status;
}

function is_pasien()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Pasien') {
        $status = false;
    }

    return $status;
}

function is_gawatdarurat()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Gawat Darurat') {
        $status = false;
    }

    return $status;
}

function is_rawatjalan()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Rawat Jalan') {
        $status = false;
    }

    return $status;
}

function is_marwavip()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Ruang VIP Marwa') {
        $status = false;
    }

    return $status;
}

function is_arafahkebidanan()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Ruang Arafah Kebidanan') {
        $status = false;
    }

    return $status;
}

function is_perinatologi()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Ruang Perinatologi') {
        $status = false;
    }

    return $status;
}

function is_minaanak()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Ruang Mina Anak') {
        $status = false;
    }

    return $status;
}

function is_shafabedah()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Ruang Shafa Bedah') {
        $status = false;
    }

    return $status;
}

function is_shafainternis()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Ruang Shafa Internis') {
        $status = false;
    }

    return $status;
}

function is_paru()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Ruang Paru') {
        $status = false;
    }

    return $status;
}

function is_hemodialisa()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Ruang Hemodialisa') {
        $status = false;
    }

    return $status;
}

function is_raudhahicu()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Ruang Raudhah ICU') {
        $status = false;
    }

    return $status;
}

function is_ibs()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Ruang IBS') {
        $status = false;
    }

    return $status;
}

function is_cssd()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Ruang CSSD') {
        $status = false;
    }

    return $status;
}

function is_radiologi()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Radiologi') {
        $status = false;
    }

    return $status;
}

function is_laboratorium()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Laboratorium') {
        $status = false;
    }

    return $status;
}

function is_fisioterapi()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Fisioterapi') {
        $status = false;
    }

    return $status;
}

function is_farmasi()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Farmasi') {
        $status = false;
    }

    return $status;
}

function is_gizi()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Gizi') {
        $status = false;
    }

    return $status;
}

function is_rekammedik()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Rekam Medik') {
        $status = false;
    }

    return $status;
}

function is_utdrs()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Unit Transfusi Darah Rumah Sakit (UTDRS)') {
        $status = false;
    }

    return $status;
}

function is_kasir()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Kasir') {
        $status = false;
    }

    return $status;
}

function is_pelayananambulance()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Pelayanan Ambulance') {
        $status = false;
    }

    return $status;
}

function is_gasmedis()
{
    $ci = get_instance();
    $level = $ci->session->userdata('login_session')['level'];

    $status = true;

    if ($level != 'Gas Medis') {
        $status = false;
    }

    return $status;
}

function userdata($field)
{
    $ci = get_instance();
    $ci->load->model('Main_model', 'main');

    $userId = $ci->session->userdata('login_session')['user'];
    return $ci->main->get('user', ['id_user' => $userId])[$field];
}

function indo_date($date, $print_day = false)
{
    $day        = [1 => 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
    $month      = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    $split      = explode('-', $date);
    $nice_date  = $split[2] . ' ' . $month[(int) $split[1]] . ' ' . $split[0];

    if ($print_day) {
        $num = date('N', strtotime($date));
        return $day[$num] . ', ' . $nice_date;
    }
    return $nice_date;
}