<?php
$pageTitle = 'Dashboard';
require_once 'config/database.php';
require_once 'includes/header.php';

$totalAlternatif  = $conn->query("SELECT COUNT(*) as c FROM supplier")->fetch_assoc()['c'] ?? 0;
$totalKriteria    = $conn->query("SELECT COUNT(*) as c FROM kriteria")->fetch_assoc()['c'] ?? 0;
$totalPenilaian   = $conn->query("SELECT COUNT(DISTINCT supplier_id) as c FROM penilaian")->fetch_assoc()['c'] ?? 0;

$suppliers = $conn->query("SELECT * FROM supplier ORDER BY kode")->fetch_all(MYSQLI_ASSOC);
$kriteria  = $conn->query("SELECT * FROM kriteria ORDER BY kode")->fetch_all(MYSQLI_ASSOC);

$nilaiMap = [];
$res = $conn->query("SELECT supplier_id, kriteria_id, nilai FROM penilaian");
while ($r = $res->fetch_assoc()) {
    $nilaiMap[$r['supplier_id']][$r['kriteria_id']] = floatval($r['nilai']);
}

$topRanked  = [];
$winnerName = '-';
$winnerScore = '0.0000';

if (!empty($nilaiMap) && !empty($suppliers) && !empty($kriteria)) {
    $minMax = [];
    foreach ($kriteria as $k) {
        $vals = array_filter(array_map(fn($s) => $nilaiMap[$s['id']][$k['id']] ?? 0, $suppliers));
        $minMax[$k['id']] = ['max' => $vals ? max($vals) : 0, 'min' => $vals ? min($vals) : 0];
    }

    $viData = [];
    foreach ($suppliers as $s) {
        $vi = 0;
        foreach ($kriteria as $k) {
            $xij = $nilaiMap[$s['id']][$k['id']] ?? 0;
            $max = $minMax[$k['id']]['max'];
            $min = $minMax[$k['id']]['min'];
            $rij = ($k['jenis'] === 'benefit')
                ? ($max > 0 ? $xij / $max : 0)
                : ($xij > 0 ? $min / $xij : 0);
            $vi += floatval($k['bobot']) * $rij;
        }
        $viData[] = ['supplier' => $s, 'vi' => $vi];
    }

    usort($viData, fn($a, $b) => $b['vi'] <=> $a['vi']);
    $topRanked = array_slice($viData, 0, 5);
    if (!empty($viData)) {
        $winnerName  = $viData[0]['supplier']['nama'];
        $winnerScore = number_format($viData[0]['vi'], 4);
    }
}
?>

<style>
  
  .dash-hero {
    background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
    border-radius: 12px;
    padding: 24px 28px;
    color: #ffffff;
    box-shadow: 0 4px 20px rgba(37, 99, 235, 0.18);
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 22px;
    border: 1px solid #bfdbfe;
  }
  .dash-hero-title {
    font-size: 21px;
    font-weight: 800;
    margin-bottom: 4px;
    color: #ffffff;
  }
  .dash-hero-sub {
    font-size: 13px;
    color: #dbeafe;
  }

  .btn-hero-primary {
    background: #F59E0B;
    color: #0F172A;
    font-weight: 700;
    padding: 10px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 14px rgba(245, 158, 11, 0.35);
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
  }
  .btn-hero-primary:hover {
    background: #d97706;
    color: #0F172A;
    transform: translateY(-2px);
    box-shadow: 0 6px 18px rgba(245, 158, 11, 0.45);
    text-decoration: none;
  }
  .btn-hero-secondary {
    background: rgba(255, 255, 255, 0.15);
    color: #ffffff;
    font-weight: 600;
    padding: 10px 18px;
    border-radius: 8px;
    border: 1px solid rgba(255, 255, 255, 0.3);
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    text-decoration: none;
  }
  .btn-hero-secondary:hover {
    background: rgba(255, 255, 255, 0.25);
    color: #ffffff;
    transform: translateY(-2px);
    text-decoration: none;
  }

  .metric-cards-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin-bottom: 24px;
  }
  .m-card {
    background: #ffffff;
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 4px 16px rgba(0,0,0,0.03);
    transition: all 0.25s ease;
    position: relative;
    overflow: hidden;
  }
  .m-card::after {
    display: none;
  }
  .m-card-bar-blue   { border-left: 4px solid #2563EB; }
  .m-card-bar-teal   { border-left: 4px solid #10B981; }
  .m-card-bar-purple { border-left: 4px solid #8B5CF6; }
  .m-card-bar-gold   { border-left: 4px solid #F59E0B; }

  .m-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 24px rgba(0,0,0,0.07);
  }
  .m-num {
    font-size: 26px;
    font-weight: 800;
    color: #1e293b;
    line-height: 1.1;
  }
  .m-label {
    font-size: 12px;
    font-weight: 600;
    color: #64748b;
    margin-top: 4px;
  }
  .m-icon {
    font-size: 32px;
    opacity: 0.85;
  }

  .rank-badge-item {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 26px; height: 26px;
    border-radius: 50%;
    font-weight: 800;
    font-size: 12px;
  }
  .rank-1-badge { background: #FEF3C7; color: #B45309; border: 1px solid #FDE68A; }
  .rank-2-badge { background: #F1F5F9; color: #475569; border: 1px solid #E2E8F0; }
  .rank-3-badge { background: #FFEDD5; color: #C2410C; border: 1px solid #FED7AA; }
  .rank-normal  { background: #F8FAFC; color: #64748B; border: 1px solid #E2E8F0; }

  @media (max-width: 992px) {
    .metric-cards-grid { grid-template-columns: repeat(2, 1fr); }
    .dash-hero { flex-direction: column; text-align: center; }
  }
</style>

<div class="fade-in">

  <div class="dash-hero">
    <div style="display:flex; align-items:center; gap:20px;">
      <img src="<?= BASE_URL ?>/assets/img/logo.jpg?v=<?= time() ?>" alt="Logo Bengkel" style="height:65px; width:auto; border-radius:10px; background:#ffffff; padding:6px; box-shadow:0 4px 12px rgba(0,0,0,0.2); flex-shrink:0;">
      <div>
        <h1 class="dash-hero-title">Sistem Pendukung Keputusan Pemilihan Supplier Sparepart</h1>
      </div>
    </div>
    <div style="display:flex; gap:12px; align-items:center;" class="no-print">
      <a href="<?= BASE_URL ?>/penilaian/index.php" class="btn-hero-primary">
        📝 Input Penilaian
      </a>
      <a href="<?= BASE_URL ?>/spk/hasil.php" class="btn-hero-secondary">
        ⚙️ Perhitungan SAW →
      </a>
    </div>
  </div>

  <div style="background: #ffffff; border: 1px solid var(--border); border-radius: 16px; padding: 45px 20px; text-align: center; box-shadow: 0 4px 20px rgba(0,0,0,0.04); margin-top: 10px;">
    <img src="<?= BASE_URL ?>/assets/img/logo.jpg?v=<?= time() ?>" alt="Logo Bengkel Putri Mandiri Motor" style="max-width: 520px; width: 90%; height: auto; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.1);">
  </div>

</div>

<?php require_once 'includes/footer.php'; ?>
