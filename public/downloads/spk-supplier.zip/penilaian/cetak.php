<?php

session_status() === PHP_SESSION_NONE && session_start();

require_once '../config/database.php';

$suppliers = $conn->query("
    SELECT *
    FROM supplier
    ORDER BY CAST(SUBSTRING(kode, 2) AS UNSIGNED)
    LIMIT 10
")->fetch_all(MYSQLI_ASSOC);

$kriteria = $conn->query("
    SELECT *
    FROM kriteria
    WHERE kode IN ('C1', 'C2', 'C3', 'C4', 'C5', 'C6')
    ORDER BY CAST(SUBSTRING(kode, 2) AS UNSIGNED) ASC
")->fetch_all(MYSQLI_ASSOC);

$jumlahKriteria = count($kriteria);

$nilaiMap = [];

$res = $conn->query("
    SELECT supplier_id, kriteria_id, nilai
    FROM penilaian
");

while ($r = $res->fetch_assoc()) {
    $nilaiMap[$r['supplier_id']][$r['kriteria_id']] = floatval($r['nilai']);
}

$hariInd = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
$bulanInd = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
$tglCetak  = $hariInd[date('w')] . ', ' . date('d') . ' ' . $bulanInd[(int)date('n')] . ' ' . date('Y');
$adminNama = $_SESSION['nama'] ?? 'Administrator';

?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Cetak Matriks Penilaian</title>
<style>

    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    html, body {
        width: 100%;
        background: #e5e7eb;
        font-family: 'Segoe UI', Arial, sans-serif;
        color: #000;
    }

    .kertas {
        width: 210mm;
        min-height: 297mm;
        margin: 20px auto;
        background: #fff;
        padding: 15mm 12mm;
        box-shadow: 0 0 8px rgba(0,0,0,0.25);
    }

    .kop {
        display: flex;
        align-items: center;
        gap: 16px;
        border-bottom: 3px double #000;
        padding-bottom: 10px;
        margin-bottom: 18px;
    }
    .kop img {
        width: 60px;
        height: 60px;
        object-fit: contain;
    }
    .kop-text {
        flex: 1;
        text-align: center;
    }
    .kop-text h1 {
        font-size: 18pt;
        color: #d43f00;
        letter-spacing: 1px;
    }
    .kop-text p {
        font-size: 9pt;
        line-height: 1.4;
    }

    .judul-laporan h2 {
        font-size: 13pt;
        margin-bottom: 2px;
    }
    .judul-laporan p {
        font-size: 9pt;
        color: #444;
        margin-bottom: 14px;
    }

    .card-title {
        font-size: 10.5pt;
        font-weight: 700;
        margin-bottom: 6px;
    }

    .frame-tabel {
        border: 1px solid #000;
        overflow: hidden;
    }

    table.tabel-matriks {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
        font-size: 8.5pt;
    }

    table.tabel-matriks th,
    table.tabel-matriks td {
        border: 1px solid #000;
        padding: 4px 3px;
        text-align: center;
        overflow: hidden;
        word-wrap: break-word;
        vertical-align: middle;
    }

    table.tabel-matriks thead th {
        background: #f1f5f9;
        font-weight: 700;
    }

    table.tabel-matriks td.td-left,
    table.tabel-matriks th.th-left {
        text-align: left;
    }

    table.tabel-matriks th:nth-child(1),
    table.tabel-matriks td:nth-child(1) { width: 5%; }

    table.tabel-matriks th:nth-child(2),
    table.tabel-matriks td:nth-child(2) { width: 7%; }

    table.tabel-matriks th:nth-child(3),
    table.tabel-matriks td:nth-child(3) { width: 34.6666%; }

    table.tabel-matriks th:nth-child(n+4),
    table.tabel-matriks td:nth-child(n+4) { width: 8.8889%; } 

    .tag-kode {
        display: inline-block;
        padding: 1px 4px;
        font-size: 8pt;
        background: #eef2ff;
        border-radius: 3px;
    }

    .ttd {
        margin-top: 30px;
        display: flex;
        justify-content: flex-end;
    }
    .ttd-box {
        text-align: center;
        min-width: 200px;
        font-size: 9.5pt;
    }
    .ttd-box .garis {
        margin-top: 45px;
        border-top: 1px solid #000;
        width: 100%;
    }

    .toolbar {
        max-width: 210mm;
        margin: 12px auto 0;
        display: flex;
        justify-content: flex-end;
        gap: 8px;
    }
    .btn {
        padding: 8px 16px;
        border-radius: 6px;
        border: none;
        cursor: pointer;
        font-size: 9pt;
        text-decoration: none;
        color: #fff;
    }
    .btn-back { background: #6b7280; }
    .btn-print { background: #16a34a; }

    @media print {
        html, body {
            background: #fff;
        }
        .no-print {
            display: none !important;
        }
        .kertas {
            width: 100%;
            min-height: 0;
            margin: 0;
            padding: 0;
            box-shadow: none;
        }
        @page {
            size: A4 portrait;
            margin: 10mm 12mm;
        }
        table.tabel-matriks {
            font-size: 8pt;
        }
        table, tr, td, th {
            page-break-inside: avoid;
        }
    }

</style>
</head>
<body>

    <div class="toolbar no-print">
        <a href="index.php" class="btn btn-back">&larr; Kembali</a>
        <button onclick="window.print()" class="btn btn-print">🖨️ Cetak PDF</button>
    </div>

    <div class="kertas">

        <div class="kop">
            <img src="../assets/img/logo.png" alt="Logo" onerror="this.style.display='none'">
            <div class="kop-text">
                <h1>PUTRI MANDIRI MOTOR</h1>
                <p>Jl. Damai No.65a, Jatiasih, Kota Bekasi, Jawa Barat 17423</p>
                <p>Bengkel Sparepart Kendaraan Bermotor</p>
            </div>
        </div>

        <div class="judul-laporan">
            <h2>Matriks Penilaian</h2>
            <p>Laporan Data Matriks Penilaian Awal (10 Supplier Sampel — C1 s/d C<?= $jumlahKriteria ?>)</p>
        </div>

        <div class="card-title">Matriks Keputusan (Nilai Mentah)</div>

        <div class="frame-tabel">
        <table class="tabel-matriks">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode</th>
                    <th class="th-left">Nama Alternatif</th>
                    <?php foreach ($kriteria as $k): ?>
                        <th><?= htmlspecialchars($k['kode']) ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($suppliers as $s): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><span class="tag-kode"><?= htmlspecialchars($s['kode']) ?></span></td>
                        <td class="td-left"><?= htmlspecialchars($s['nama']) ?></td>
                        <?php foreach ($kriteria as $k): ?>
                            <td><?= $nilaiMap[$s['id']][$k['id']] ?? '-' ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>

                <?php if (empty($suppliers)): ?>
                    <tr>
                        <td colspan="<?= 3 + $jumlahKriteria ?>">Belum ada data supplier.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        </div>

        <div class="ttd">
            <div class="ttd-box">
                <div>Bekasi, <?= $tglCetak ?></div>
                <div style="margin-top:2px;">Mengetahui,</div>
                <div class="garis"></div>
                <div style="margin-top:4px; font-size:9.5pt;">Administrator</div>
            </div>
        </div>

    </div>

    <script>
        window.onload = function () {
            setTimeout(function () {
                window.print();
            }, 500);
        };
    </script>

</body>
</html>