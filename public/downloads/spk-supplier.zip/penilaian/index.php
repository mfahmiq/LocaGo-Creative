<?php
$pageTitle = 'Penilaian Supplier';
require_once '../config/database.php';
require_once '../includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['supplier_id'])) {
    $sid  = intval($_POST['supplier_id']);
    $next = intval($_POST['next_sid'] ?? 0);
    foreach ($_POST['nilai'] ?? [] as $kid => $val) {
        $val = intval($val); $kid = intval($kid);
        if ($val < 1 || $val > 5) continue;
        $exists = $conn->query("SELECT id FROM penilaian WHERE supplier_id=$sid AND kriteria_id=$kid")->num_rows;
        if ($exists)
            $conn->query("UPDATE penilaian SET nilai=$val WHERE supplier_id=$sid AND kriteria_id=$kid");
        else
            $conn->query("INSERT INTO penilaian (supplier_id, kriteria_id, nilai) VALUES ($sid,$kid,$val)");
    }
    $go = $next ?: $sid;
    header("Location: ?sid=$go&saved=1");
    exit;
}

$kriteria  = $conn->query("SELECT * FROM kriteria ORDER BY kode")->fetch_all(MYSQLI_ASSOC);
$suppliers = $conn->query("SELECT * FROM supplier ORDER BY CAST(SUBSTRING(kode,2) AS UNSIGNED)")->fetch_all(MYSQLI_ASSOC);

$nilaiMap = [];
$res = $conn->query("SELECT supplier_id, kriteria_id, nilai FROM penilaian");
while ($r = $res->fetch_assoc())
    $nilaiMap[$r['supplier_id']][$r['kriteria_id']] = intval($r['nilai']);

$activeSid = intval($_GET['sid'] ?? ($suppliers[0]['id'] ?? 0));
$activeIdx  = 0;
$activeS    = null;
foreach ($suppliers as $i => $s) {
    if ($s['id'] == $activeSid) { $activeS = $s; $activeIdx = $i; break; }
}
if (!$activeS && !empty($suppliers)) { $activeS = $suppliers[0]; $activeIdx = 0; $activeSid = $activeS['id']; }

$prevS = $activeIdx > 0 ? $suppliers[$activeIdx - 1] : null;
$nextS = $activeIdx < count($suppliers) - 1 ? $suppliers[$activeIdx + 1] : null;

$totalK = count($kriteria);
$done   = count(array_filter($suppliers, fn($s) => isset($nilaiMap[$s['id']]) && count($nilaiMap[$s['id']]) >= $totalK));
?>

<div class="page-header fade-in">
  <div class="page-title-wrap">
    <span class="page-title-icon">📝</span>
    <div>
      <h1>Data Penilaian</h1>
      <p>Input Penilaian Alternatif Supplier Berdasarkan Kriteria</p>
    </div>
  </div>
  <div class="d-flex gap-2 no-print">
    <a href="<?= BASE_URL ?>/penilaian/cetak.php" target="_blank" class="btn btn-success btn-sm">🖨️ Cetak Matriks</a>
  </div>
</div>

<?php if(isset($_GET['saved'])): ?>
<div class="alert alert-success fade-in">✅ Penilaian berhasil disimpan!</div>
<?php endif; ?>

<div class="card fade-in" style="max-width:740px;">
  <div class="card-header">
    <div class="card-title">📝 Input Penilaian Alternatif</div>
  </div>

  <div class="card-body">
    <div class="form-group mb-0">
      <label class="form-label" style="font-weight:600; color:var(--text);">Pilih Alternatif Supplier:</label>
      <select class="form-control" onchange="window.location='?sid='+this.value" style="font-size:13px; font-weight:600; color:#4361ee; border-color:#bfdbfe;">
        <?php foreach($suppliers as $s):
          $f = isset($nilaiMap[$s['id']]) && count($nilaiMap[$s['id']]) >= $totalK;
        ?>
        <option value="<?= $s['id'] ?>" <?= $s['id']==$activeSid?'selected':'' ?>>
          <?= $s['kode'] ?> — <?= htmlspecialchars($s['nama']) ?><?= $f ? ' ✓' : '' ?>
        </option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>

  <?php if($activeS): ?>
  <form method="POST" action="">
    <input type="hidden" name="supplier_id" value="<?= $activeS['id'] ?>">
    <input type="hidden" name="next_sid"    value="<?= $nextS['id'] ?? '' ?>">

    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>Kriteria Penilaian</th>
            <th style="text-align:center; width:65px;">1<br><small style="font-weight:400;font-size:10px;color:#fff;">S.Buruk</small></th>
            <th style="text-align:center; width:65px;">2<br><small style="font-weight:400;font-size:10px;color:#fff;">Buruk</small></th>
            <th style="text-align:center; width:65px;">3<br><small style="font-weight:400;font-size:10px;color:#fff;">Cukup</small></th>
            <th style="text-align:center; width:65px;">4<br><small style="font-weight:400;font-size:10px;color:#fff;">Baik</small></th>
            <th style="text-align:center; width:65px;">5<br><small style="font-weight:400;font-size:10px;color:#fff;">S.Baik</small></th>
          </tr>
        </thead>
        <tbody>
        <?php foreach($kriteria as $k):
          $cur = $nilaiMap[$activeS['id']][$k['id']] ?? 0;
        ?>
        <tr>
          <td>
            <span class="tag-kode"><?= $k['kode'] ?></span>
            <strong style="font-size:13px; margin-left:6px;"><?= htmlspecialchars($k['nama']) ?></strong>
            <span class="badge badge-<?= $k['jenis'] ?>" style="margin-left:4px; font-size:10px;"><?= strtoupper($k['jenis']) ?></span>
          </td>
          <?php for($v=1;$v<=5;$v++):
            $colors = ['','#ef4444','#f59e0b','#eab308','#22c55e','#10b981'];
            $chk    = ($cur == $v);
          ?>
          <td style="text-align:center;">
            <label style="cursor:pointer; display:block; padding:4px 0;">
              <input type="radio" name="nilai[<?= $k['id'] ?>]" value="<?= $v ?>"
                <?= $chk ? 'checked' : '' ?>
                style="accent-color:<?= $colors[$v] ?>; width:18px; height:18px; cursor:pointer;">
            </label>
          </td>
          <?php endfor; ?>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="card-body" style="border-top:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; background:#f8fafc;">
      <div>
        <?php if($prevS): ?>
        <a href="?sid=<?= $prevS['id'] ?>" class="btn btn-secondary btn-sm">‹ <?= $prevS['kode'] ?></a>
        <?php endif; ?>
      </div>
      <div style="display:flex; gap:10px;">
        <button type="submit" class="btn btn-primary">Simpan</button>
        <?php if($nextS): ?>
        <button type="submit" class="btn btn-success">Simpan & Lanjut › <?= $nextS['kode'] ?></button>
        <?php endif; ?>
      </div>
      <div>
        <?php if($nextS): ?>
        <a href="?sid=<?= $nextS['id'] ?>" class="btn btn-secondary btn-sm"><?= $nextS['kode'] ?> ›</a>
        <?php endif; ?>
      </div>
    </div>
  </form>
  <?php endif; ?>

</div>

<?php require_once '../includes/footer.php'; ?>
