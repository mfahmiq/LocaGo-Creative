<?php
session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nilaiArr = $_POST['nilai'] ?? [];
    $count = 0;

    foreach ($nilaiArr as $supplierId => $kriteriaArr) {
        foreach ($kriteriaArr as $kriteriaId => $nilai) {
            $sId = intval($supplierId);
            $kId = intval($kriteriaId);
            $val = floatval($nilai);

            if ($sId && $kId && $val >= 1 && $val <= 5) {
                $stmt = $conn->prepare("
                    INSERT INTO penilaian (supplier_id, kriteria_id, nilai)
                    VALUES (?,?,?)
                    ON DUPLICATE KEY UPDATE nilai = VALUES(nilai)
                ");
                $stmt->bind_param('iid', $sId, $kId, $val);
                $stmt->execute();
                $count++;
            }
        }
    }
    $_SESSION['msg'] = "Berhasil menyimpan $count data penilaian!";
}

header('Location: index.php');
exit;
