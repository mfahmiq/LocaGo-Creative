</main>

<script>
document.querySelectorAll('.alert').forEach(function(el) {
  setTimeout(function() { el.style.opacity = '0'; el.style.transition = 'opacity 0.5s'; setTimeout(function(){ el.remove(); }, 500); }, 4000);
});

document.querySelectorAll('.btn-confirm-delete').forEach(function(btn) {
  btn.addEventListener('click', function(e) {
    if (!confirm('Yakin ingin menghapus data ini?')) e.preventDefault();
  });
});
</script>
</body>
</html>