<?php
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$currentFile = basename($_SERVER['PHP_SELF']);
$currentDir  = basename(dirname($_SERVER['PHP_SELF']));

function isActive($page, $dir = '') {
    global $currentFile, $currentDir;
    if ($dir && $currentDir === $dir) return 'active';
    if (!$dir && $currentFile === $page) return 'active';
    return '';
}

$adminNama = $_SESSION['nama'] ?? 'Admin';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle ?? 'SPK Supplier') ?> — Putri Mandiri Motor</title>
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>

<nav class="navbar">
  <a href="<?= BASE_URL ?>/dashboard.php" class="navbar-brand" style="width: 220px; background: #2563EB; display: flex; align-items: center; gap: 10px; padding: 0 12px;">
    <img src="<?= BASE_URL ?>/assets/img/logo.jpg?v=<?= time() ?>" alt="Logo Putri Mandiri Motor" style="height: 44px; width: auto; max-width: 85px; object-fit: contain; border-radius: 6px; flex-shrink: 0; background: #ffffff; padding: 2px 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.15);">
    <div class="navbar-logo-text" style="font-size: 11px; font-weight: 700; color: #FFFFFF; line-height: 1.25; text-align: left; white-space: nowrap;">
      PUTRI MANDIRI<br>MOTOR
    </div>
  </a>
  <div class="navbar-right">
    <div class="admin-menu">👤 <?= htmlspecialchars($adminNama) ?></div>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-logout">🚪 Logout</a>
  </div>
</nav>

<aside class="sidebar" style="width: 220px; background: #2563EB;">
  <a href="<?= BASE_URL ?>/dashboard.php" class="sidebar-link <?= isActive('dashboard.php') ?>">
    <span class="sidebar-icon">🏠</span> Dashboard
  </a>
  
  <a href="<?= BASE_URL ?>/supplier/index.php" class="sidebar-link <?= isActive('', 'supplier') ?>">
    <span class="sidebar-icon">🏪</span> Data Alternatif
  </a>

  <a href="<?= BASE_URL ?>/kriteria/index.php" class="sidebar-link <?= isActive('', 'kriteria') ?>">
    <span class="sidebar-icon">📊</span> Data Kriteria
  </a>
  
  <a href="<?= BASE_URL ?>/penilaian/index.php" class="sidebar-link <?= isActive('', 'penilaian') ?>">
    <span class="sidebar-icon">📝</span> Data Penilaian
  </a>
  
  <a href="<?= BASE_URL ?>/spk/normalisasi.php" class="sidebar-link <?= isActive('normalisasi.php', 'spk') ?>">
    <span class="sidebar-icon">🔢</span> Data Normalisasi
  </a>
  
  <a href="<?= BASE_URL ?>/spk/hasil.php" class="sidebar-link <?= isActive('hasil.php', 'spk') || isActive('hitung.php', 'spk') ? 'active' : '' ?>">
    <span class="sidebar-icon">🧮</span> Data Perhitungan
  </a>
  
  <hr class="sidebar-divider" style="border-color: rgba(255,255,255,0.25);">
  
  <a href="<?= BASE_URL ?>/logout.php" class="sidebar-link" style="color: #FFFFFF;">
    <span class="sidebar-icon">🚪</span> Logout
  </a>
</aside>

<main class="main-content" style="margin-left: 220px;">

<style>
@media print {
  @page { margin: 0; }
  body { padding: 1.5cm; }
  .no-print-screen {
    display: flex !important;
  }
}
</style>

<div class="print-kop no-print-screen" style="display:none; align-items:center; border-bottom:3px double #333; padding-bottom:15px; margin-bottom:20px;">
  <img src="<?= BASE_URL ?>/assets/img/logo.jpg" alt="Logo Bengkel" style="width:110px; height:auto; margin-right:20px; flex-shrink:0;">
  <div class="print-kop-text" style="flex-grow:1; text-align:center; padding-right:130px;">
    <h2 style="margin:0; font-size:23px; color:#E74C3C; font-weight:800; letter-spacing:1px; white-space:nowrap;">PUTRI MANDIRI MOTOR</h2>
    <p style="margin:2px 0 0 0; font-size:12px; color:#222; font-weight:600;">Jl. Damai No.65a, Jatiasih, Kota Bekasi, Jawa Barat 17423</p>
    <p style="margin:1px 0 0 0; font-size:11.5px; color:#444;">Bengkel Sparepart Kendaraan Bermotor</p>
  </div>
</div>
