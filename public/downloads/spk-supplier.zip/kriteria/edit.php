<?php
$pageTitle = 'Edit Kriteria';
require_once '../config/database.php';
require_once '../includes/header.php';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

$k = $conn->query("SELECT * FROM kriteria WHERE id = $id")->fetch_assoc();
if (!$k) {
    header('Location: index.php');
    exit;
}

$msg = '';
$msgType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama  = trim($_POST['nama']  ?? '');
    $bobot = floatval($_POST['bobot'] ?? 0);
    $jenis = in_array($_POST['jenis'] ?? '', ['benefit','cost']) ? $_POST['jenis'] : 'benefit';

    if ($nama && $bobot > 0) {
        $upd = $conn->prepare("UPDATE kriteria SET nama=?, bobot=?, jenis=? WHERE id=?");
        $upd->bind_param('sdsi', $nama, $bobot, $jenis, $id);
        $upd->execute();
        $_SESSION['msg'] = 'Kriteria berhasil diperbarui!';
        header('Location: index.php');
        exit;
    } else {
        $msg = 'Harap isi semua field dengan benar.';
        $msgType = 'danger';
    }
}
?>

<div class="page-header fade-in">
  <h1>Edit Kriteria</h1>
</div>

<?php if($msg): ?>
<div class="alert alert-<?= $msgType ?> fade-in"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="card fade-in-delay-1" style="max-width: 500px;">
  <div class="card-header">
    <div class="card-title">Form Edit Kriteria</div>
  </div>
  <div class="card-body">
    <form method="POST" action="">

      <div class="form-group">
        <label class="form-label">Nama Kriteria</label>
        <input type="text" name="nama" class="form-control"
          value="<?= htmlspecialchars($_POST['nama'] ?? $k['nama']) ?>"
          placeholder="Nama Kriteria" required>
      </div>

      <div class="form-group">
        <label class="form-label">Bobot</label>
        <input type="number" name="bobot" class="form-control"
          value="<?= htmlspecialchars($_POST['bobot'] ?? $k['bobot']) ?>"
          step="0.01" min="0.01" max="1" placeholder="Contoh: 0.25" required>
        <div class="form-hint">Nilai desimal antara 0–1. Contoh: 0.25 = 25%</div>
      </div>

      <div class="form-group">
        <label class="form-label">Jenis Kriteria</label>
        <div style="margin-top:6px; display:flex; flex-direction:column; gap:6px;">
          <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-size:13px;">
            <input type="radio" name="jenis" value="cost"
              <?= (($_POST['jenis'] ?? $k['jenis']) === 'cost') ? 'checked' : '' ?>>
            Cost
          </label>
          <label style="display:flex; align-items:center; gap:8px; cursor:pointer; font-size:13px;">
            <input type="radio" name="jenis" value="benefit"
              <?= (($_POST['jenis'] ?? $k['jenis']) === 'benefit') ? 'checked' : '' ?>>
            Benefit
          </label>
        </div>
      </div>

      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-primary">simpan</button>
        <a href="index.php" class="btn btn-danger">Kembali</a>
      </div>

    </form>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
