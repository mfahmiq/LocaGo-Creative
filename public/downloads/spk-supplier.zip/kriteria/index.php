<?php
$pageTitle = 'Data Kriteria';
require_once '../config/database.php';
require_once '../includes/header.php';

$msg = $_SESSION['msg'] ?? '';
unset($_SESSION['msg']);

$kriteria = $conn->query("SELECT * FROM kriteria ORDER BY kode");
$hariInd = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
$bulanInd = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
$tglCetak  = $hariInd[date('w')] . ', ' . date('d') . ' ' . $bulanInd[(int)date('n')] . ' ' . date('Y');
$adminNama = $_SESSION['nama'] ?? 'Administrator';
?>

<style>
@media print {
    @page { size: A4 portrait; margin: 10mm; }
    body { padding: 0 !important; margin: 0 !important; background: #fff !important; font-size: 9.5pt !important; }
    .main-content { margin-left: 0 !important; padding: 0 !important; width: 100% !important; max-width: 100% !important; }
    .card { width: 100% !important; max-width: 100% !important; margin: 0 0 12px 0 !important; border: 1px solid #000 !important; box-shadow: none !important; border-radius: 0 !important; }
    .table-wrapper { width: 100% !important; overflow: visible !important; }
    table { width: 100% !important; table-layout: auto !important; border-collapse: collapse !important; }
    th, td { border: 1px solid #000 !important; padding: 6px 8px !important; color: #000 !important; }
    thead tr { background: #f1f5f9 !important; color: #000 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    thead th { color: #000 !important; background: #f1f5f9 !important; }
    .card-header { background: #f1f5f9 !important; color: #000 !important; border-bottom: 1px solid #000 !important; }
    .card-title { color: #000 !important; }
    .print-ttd { display: flex !important; }
}
</style>

<div class="page-header fade-in">
  <div class="page-title-wrap">
    <span class="page-title-icon">📦</span>
    <div>
      <h1>Data Kriteria</h1>
      <p>Kelola Kriteria Penilaian Pemilihan Supplier</p>
    </div>
  </div>
  <div class="d-flex gap-2 no-print">
    <button onclick="window.print()" class="btn btn-success btn-sm">🖨️ Cetak Kriteria</button>
  </div>
</div>

<?php if($msg): ?>
<div class="alert alert-success fade-in"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="card fade-in" style="width: 100%;">
  <div class="card-header">
    <div class="card-title">📋 Daftar Data Kriteria</div>
  </div>
  <div class="table-wrapper" style="width: 100%;">
    <table style="width: 100%; border-collapse: collapse;">
      <thead>
        <tr>
          <th style="text-align:center; width: 45px;">No</th>
          <th style="width: 100px;">Kode Kriteria</th>
          <th>Nama Kriteria</th>
          <th style="text-align:center; width: 100px;">Bobot (%)</th>
          <th style="text-align:center; width: 110px;">Bobot Desimal</th>
          <th style="text-align:center; width: 90px;">Jenis</th>
          <th class="no-print" style="text-align:center;">Aksi</th>
        </tr>
      </thead>
      <tbody>
      <?php $no=1; while($k = $kriteria->fetch_assoc()): ?>
      <tr>
        <td class="td-muted" style="text-align:center;"><?= $no++ ?></td>
        <td><span class="tag-kode"><?= $k['kode'] ?></span></td>
        <td><strong><?= htmlspecialchars($k['nama']) ?></strong></td>
        <td style="text-align:center; font-weight:600;"><?= ($k['bobot']*100) ?>%</td>
        <td style="text-align:center; font-weight:600;"><?= $k['bobot'] ?></td>
        <td style="text-align:center;">
          <span class="badge badge-<?= $k['jenis']==='benefit'?'benefit':'cost' ?>">
            <?= strtoupper($k['jenis']) ?>
          </span>
        </td>
        <td class="no-print" style="text-align:center;">
          <a href="<?= BASE_URL ?>/kriteria/edit.php?id=<?= $k['id'] ?>" class="btn btn-warning" style="padding: 4px 8px; font-size: 11px;" title="Edit Data">✏️ Edit</a>
        </td>
      </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="print-ttd no-print-screen" style="display:none; margin-top:25px; justify-content:flex-end; font-family:'Poppins', 'Segoe UI', Arial, sans-serif; font-size:10pt; color:#000; page-break-inside:avoid;">
  <div style="text-align:center; min-width:210px;">
    <div>Bekasi, <?= $tglCetak ?></div>
    <div style="margin-top:2px;">Mengetahui,</div>
    <div style="margin-top:45px; border-top:1px solid #000; width:100%;"></div>
    <div style="margin-top:4px; font-size:9.5pt;">Administrator</div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
