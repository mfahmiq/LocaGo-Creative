<?php
$pageTitle = 'Kesimpulan';
require_once '../config/database.php';
require_once '../includes/header.php';

$sqlHasil = "
    SELECT h.peringkat, h.nilai_akhir, h.tanggal, s.kode, s.nama, s.telpon, s.alamat
    FROM hasil_spk h
    JOIN supplier s ON s.id = h.supplier_id
    ORDER BY h.peringkat ASC
";
$hasilData = $conn->query($sqlHasil)->fetch_all(MYSQLI_ASSOC);
$winner    = $hasilData[0] ?? null;
$jumlah    = count($hasilData);

$totalSup    = $conn->query("SELECT COUNT(*) as c FROM supplier")->fetch_assoc()['c'];
$totalKrit   = $conn->query("SELECT COUNT(*) as c FROM kriteria")->fetch_assoc()['c'];
$kriteria    = $conn->query("SELECT * FROM kriteria ORDER BY kode")->fetch_all(MYSQLI_ASSOC);
?>

<div class="page-header fade-in">
  <h1>Kesimpulan Hasil SPK</h1>
  <p>Ringkasan hasil dan rekomendasi supplier terbaik berdasarkan metode SAW</p>
</div>

<div class="d-flex gap-2 mb-3 no-print fade-in">
  <a href="cetak_hasil.php" class="btn btn-success">🖨️ Cetak Hasil Pemilihan Supplier</a>
  <button onclick="window.print()" class="btn btn-outline">🖨️ Cetak Halaman Ini</button>
  <a href="hasil.php" class="btn btn-accent btn-sm">← Kembali ke Hasil</a>
</div>

<?php if(empty($hasilData)): ?>
<div class="alert alert-warning">⚠️ Belum ada hasil perhitungan. <a href="hitung.php">Hitung SAW dulu.</a></div>
<?php else: ?>

<div class="card fade-in-delay-1" style="border:2px solid var(--primary);">
  <div class="card-body" style="text-align:center; padding:32px;">
    <div style="font-size:36px; margin-bottom:8px;">🏍️</div>
    <h2 style="font-size:18px; font-weight:800; color:var(--primary-light); margin-bottom:4px;">
      LAPORAN HASIL SPK PEMILIHAN SUPPLIER SPAREPART
    </h2>
    <h3 style="font-size:15px; font-weight:600; margin-bottom:6px;">Bengkel Putri Mandiri Motor</h3>
    <p style="font-size:12px; color:var(--text-muted);">
      Jl. Damai No.65a, Jatiasih, Kota Bekasi, Jawa Barat · Metode: Simple Additive Weighting (SAW)
    </p>
    <?php if($winner): ?>
    <p style="font-size:11px; color:var(--text-dim); margin-top:8px;">
      Tanggal: <?= date('d F Y', strtotime($winner['tanggal'])) ?>
    </p>
    <?php endif; ?>
  </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px;" class="fade-in-delay-1">
  <div class="card">
    <div class="card-body" style="text-align:center;">
      <div style="font-size:36px; font-weight:800; color:var(--primary-light);"><?= $totalSup ?></div>
      <div style="font-size:13px; color:var(--text-muted);">Total Supplier Dievaluasi</div>
    </div>
  </div>
  <div class="card">
    <div class="card-body" style="text-align:center;">
      <div style="font-size:36px; font-weight:800; color:var(--accent);"><?= $totalKrit ?></div>
      <div style="font-size:13px; color:var(--text-muted);">Kriteria Penilaian</div>
    </div>
  </div>
  <div class="card">
    <div class="card-body" style="text-align:center;">
      <div style="font-size:36px; font-weight:800; color:var(--success);">SAW</div>
      <div style="font-size:13px; color:var(--text-muted);">Metode yang Digunakan</div>
    </div>
  </div>
</div>

<?php if($winner): ?>
<div class="hasil-winner fade-in-delay-2" style="border-width:2px;">
  <div class="winner-rank-badge">1</div>
  <div>
    <div style="font-size:11px; color:var(--text-muted); text-transform:uppercase; letter-spacing:0.1em; margin-bottom:6px;">
      ✅ REKOMENDASI SUPPLIER TERBAIK
    </div>
    <div class="winner-name" style="font-size:22px;"><?= htmlspecialchars($winner['nama']) ?></div>
    <div style="font-size:13px; color:var(--text-muted); margin:4px 0;">
      <span class="tag-kode"><?= $winner['kode'] ?></span>
      <?php if($winner['alamat']): ?> · 📍 <?= htmlspecialchars($winner['alamat']) ?><?php endif; ?>
      <?php if($winner['telpon']): ?> · 📞 <?= htmlspecialchars($winner['telpon']) ?><?php endif; ?>
    </div>
    <div class="winner-score">Vi = <?= number_format($winner['nilai_akhir'], 4) ?></div>
  </div>
</div>
<?php endif; ?>

<div class="card fade-in-delay-2">
  <div class="card-header">
    <div class="card-title"><div class="card-title-icon">📋</div> Tabel Peringkat Seluruh Supplier</div>
  </div>
  <div class="table-wrapper">
    <table>
      <thead><tr>
        <th>Peringkat</th><th>Kode</th><th>Nama Supplier</th><th>Alamat</th><th>Telepon</th>
        <th style="text-align:center;">Nilai Vi</th><th>Keterangan</th>
      </tr></thead>
      <tbody>
      <?php foreach($hasilData as $h):
        $rank = (int)$h['peringkat'];
        $rankClass = match($rank) { 1 => 'rank-1', 2 => 'rank-2', 3 => 'rank-3', default => 'rank-other' };
        $medal = match($rank) { 1 => '🥇 Sangat Direkomendasikan', 2 => '🥈 Direkomendasikan', 3 => '🥉 Cukup Direkomendasikan', default => 'Kurang Direkomendasikan' };
      ?>
      <tr>
        <td><div class="td-rank <?= $rankClass ?>"><?= $h['peringkat'] ?></div></td>
        <td><span class="tag-kode"><?= $h['kode'] ?></span></td>
        <td><strong><?= htmlspecialchars($h['nama']) ?></strong></td>
        <td class="td-muted" style="font-size:11px;"><?= htmlspecialchars($h['alamat'] ?? '-') ?></td>
        <td class="td-muted"><?= htmlspecialchars($h['telpon'] ?? '-') ?></td>
        <td style="text-align:center;"><strong style="color:var(--accent);"><?= number_format($h['nilai_akhir'], 4) ?></strong></td>
        <td style="font-size:12px;"><?= $medal ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card fade-in-delay-2">
  <div class="card-header">
    <div class="card-title"><div class="card-title-icon">📊</div> Kriteria yang Digunakan</div>
  </div>
  <div class="table-wrapper">
    <table>
      <thead><tr><th>Kode</th><th>Nama Kriteria</th><th>Bobot</th><th>Jenis</th></tr></thead>
      <tbody>
      <?php foreach($kriteria as $k): ?>
      <tr>
        <td><span class="tag-kode"><?= $k['kode'] ?></span></td>
        <td><?= htmlspecialchars($k['nama']) ?></td>
        <td><strong><?= ($k['bobot']*100) ?>%</strong> (<?= $k['bobot'] ?>)</td>
        <td><span class="badge badge-<?= $k['jenis']==='benefit'?'benefit':'cost' ?>"><?= strtoupper($k['jenis']) ?></span></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card fade-in-delay-2">
  <div class="card-header">
    <div class="card-title"><div class="card-title-icon">📝</div> Kesimpulan</div>
  </div>
  <div class="card-body" style="line-height:2;">
    <p style="font-size:14px; color:var(--text-main);">
      Berdasarkan hasil perhitungan menggunakan metode <strong>Simple Additive Weighting (SAW)</strong>,
      sistem pendukung keputusan pemilihan supplier sparepart terbaik di <strong>Bengkel Putri Mandiri Motor</strong>
      telah berhasil mengevaluasi <strong><?= $totalSup ?> supplier</strong> berdasarkan
      <strong><?= $totalKrit ?> kriteria</strong> penilaian, yaitu:
      <strong><?= implode(', ', array_column($kriteria, 'nama')) ?></strong>.
    </p>
    <br>
    <?php if($winner): ?>
    <p style="font-size:14px; color:var(--text-main);">
      Dari hasil perhitungan diperoleh bahwa supplier dengan nilai preferensi tertinggi adalah
      <strong style="color:var(--primary-light);"><?= htmlspecialchars($winner['nama']) ?></strong>
      dengan kode <span class="tag-kode"><?= $winner['kode'] ?></span> dan nilai Vi =
      <strong style="color:var(--accent);"><?= number_format($winner['nilai_akhir'], 4) ?></strong>.
      Oleh karena itu, <strong><?= htmlspecialchars($winner['nama']) ?></strong>
      direkomendasikan sebagai supplier sparepart terbaik dan paling sesuai dengan kebutuhan
      operasional Bengkel Putri Mandiri Motor.
    </p>
    <br>
    <p style="font-size:14px; color:var(--text-muted);">
      Hasil ini bersifat sebagai alat bantu pengambilan keputusan. Keputusan akhir tetap
      sepenuhnya berada di tangan pengelola Bengkel Putri Mandiri Motor.
    </p>
    <?php endif; ?>
  </div>
</div>

<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
