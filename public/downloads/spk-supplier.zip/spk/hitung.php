<?php
$pageTitle = 'Perhitungan SAW';
require_once '../config/database.php';
require_once '../includes/header.php';

$saved = false;
if (isset($_POST['simpan_hasil'])) {
    $conn->query("DELETE FROM hasil_spk");
    $dataHasil = json_decode($_POST['data_hasil'], true);
    foreach ($dataHasil as $row) {
        $sid  = intval($row['supplier_id']);
        $vi   = floatval($row['nilai_akhir']);
        $rank = intval($row['peringkat']);
        $ins  = $conn->prepare("INSERT INTO hasil_spk (supplier_id, nilai_akhir, peringkat) VALUES (?,?,?)");
        $ins->bind_param('idi', $sid, $vi, $rank);
        $ins->execute();
    }
    $saved = true;
}

$suppliers = $conn->query("SELECT * FROM supplier ORDER BY kode")->fetch_all(MYSQLI_ASSOC);
$kriteria  = $conn->query("SELECT * FROM kriteria ORDER BY kode")->fetch_all(MYSQLI_ASSOC);

$nilaiMap = [];
$res = $conn->query("SELECT supplier_id, kriteria_id, nilai FROM penilaian");
while ($r = $res->fetch_assoc()) {
    $nilaiMap[$r['supplier_id']][$r['kriteria_id']] = floatval($r['nilai']);
}

$minMax = [];
foreach ($kriteria as $k) {
    $vals = array_filter(array_map(fn($s) => $nilaiMap[$s['id']][$k['id']] ?? 0, $suppliers));
    $minMax[$k['id']] = ['max' => $vals ? max($vals) : 0, 'min' => $vals ? min($vals) : 0];
}

$rij = [];
foreach ($suppliers as $s) {
    foreach ($kriteria as $k) {
        $xij = $nilaiMap[$s['id']][$k['id']] ?? 0;
        $max = $minMax[$k['id']]['max'];
        $min = $minMax[$k['id']]['min'];
        $rij[$s['id']][$k['id']] = ($k['jenis'] === 'benefit')
            ? ($max > 0 ? $xij / $max : 0)
            : ($xij  > 0 ? $min / $xij : 0);
    }
}

$viData = [];
foreach ($suppliers as $s) {
    $vi = 0;
    foreach ($kriteria as $k) {
        $vi += floatval($k['bobot']) * ($rij[$s['id']][$k['id']] ?? 0);
    }
    $viData[] = ['supplier' => $s, 'vi' => $vi];
}
usort($viData, fn($a, $b) => $b['vi'] <=> $a['vi']);
foreach ($viData as $i => &$vd) { $vd['peringkat'] = $i + 1; }
unset($vd);
?>

<div class="page-header fade-in">
  <h1>Perhitungan SAW</h1>
  <p>Perhitungan Pemilihan Supplier Sparepart Terbaik</p>
</div>

<?php if($saved): ?>
<div class="alert alert-success fade-in">✅ Hasil berhasil disimpan! <a href="hasil.php">Lihat Ranking →</a></div>
<?php endif; ?>

<?php if(empty($suppliers) || empty($nilaiMap)): ?>
<div class="alert alert-warning">
  ⚠️ Belum ada data penilaian. <a href="<?= BASE_URL ?>/penilaian/index.php" class="btn btn-primary btn-sm" style="margin-left:8px;">Input Penilaian</a>
</div>
<?php else: ?>

<div class="card fade-in-delay-1">
  <div class="card-header">
    <div class="card-title">Matriks Keputusan (X)</div>
  </div>
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th>No</th><th>Kode</th><th>Nama Supplier</th>
          <?php foreach($kriteria as $k): ?>
          <th style="text-align:center;"><?= $k['kode'] ?><br>
            <small style="font-weight:400;font-size:10px;color:var(--muted);">(<?= $k['jenis'] ?>)</small>
          </th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
      <?php $no=1; foreach($suppliers as $s): ?>
      <tr>
        <td class="td-muted"><?= $no++ ?></td>
        <td><span class="tag-kode"><?= $s['kode'] ?></span></td>
        <td><?= htmlspecialchars($s['nama']) ?></td>
        <?php foreach($kriteria as $k): $v = $nilaiMap[$s['id']][$k['id']] ?? 0; ?>
        <td style="text-align:center;" class="<?= $k['jenis']==='benefit'?'cell-benefit':'cell-cost' ?>"><?= $v ?></td>
        <?php endforeach; ?>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card fade-in-delay-1">
  <div class="card-header">
    <div class="card-title">Matriks Normalisasi (R)</div>
  </div>
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th>No</th><th>Kode</th><th>Nama Supplier</th>
          <?php foreach($kriteria as $k): ?>
          <th style="text-align:center;">r_<?= strtolower($k['kode']) ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
      <?php $no=1; foreach($suppliers as $s): ?>
      <tr>
        <td class="td-muted"><?= $no++ ?></td>
        <td><span class="tag-kode"><?= $s['kode'] ?></span></td>
        <td><?= htmlspecialchars($s['nama']) ?></td>
        <?php foreach($kriteria as $k): $r = $rij[$s['id']][$k['id']] ?? 0; ?>
        <td style="text-align:center;"><?= number_format($r, 2) ?></td>
        <?php endforeach; ?>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card fade-in-delay-2">
  <div class="card-header">
    <div class="card-title">Nilai Preferensi (Vi) & Peringkat</div>
  </div>
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th>Peringkat</th><th>Kode</th><th>Nama Supplier</th>
          <th style="text-align:center;">Nilai Vi</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach($viData as $vd):
        $s  = $vd['supplier'];
        $rc = match($vd['peringkat']) { 1=>'rank-1', 2=>'rank-2', 3=>'rank-3', default=>'rank-other' };
        $md = match($vd['peringkat']) { 1=>'🥇', 2=>'🥈', 3=>'🥉', default=>'' };
      ?>
      <tr>
        <td><div class="td-rank <?= $rc ?>"><?= $vd['peringkat'] ?></div></td>
        <td><span class="tag-kode"><?= $s['kode'] ?></span></td>
        <td><?= $md ?> <strong><?= htmlspecialchars($s['nama']) ?></strong></td>
        <td style="text-align:center;">
          <strong style="color:var(--primary); font-size:14px;"><?= number_format($vd['vi'], 4) ?></strong>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <div class="card-body-sm" style="border-top:1px solid var(--border);">
    <form method="POST" action="hitung.php">
      <input type="hidden" name="simpan_hasil" value="1">
      <input type="hidden" name="data_hasil" value='<?= htmlspecialchars(json_encode(array_map(fn($vd) => [
        "supplier_id" => $vd['supplier']['id'],
        "nilai_akhir" => $vd['vi'],
        "peringkat"   => $vd['peringkat']
      ], $viData))) ?>'>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-primary">💾 Simpan Hasil</button>
        <a href="hasil.php" class="btn btn-success">📊 Lihat Ranking</a>
      </div>
    </form>
  </div>
</div>

<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
