<?php
$pageTitle = 'Normalisasi';
require_once '../config/database.php';
require_once '../includes/header.php';

$suppliers = $conn->query("SELECT * FROM supplier ORDER BY kode")->fetch_all(MYSQLI_ASSOC);
$kriteria  = $conn->query("SELECT * FROM kriteria ORDER BY kode")->fetch_all(MYSQLI_ASSOC);

$nilaiMap = [];
$res = $conn->query("SELECT supplier_id, kriteria_id, nilai FROM penilaian");
while ($r = $res->fetch_assoc()) {
    $nilaiMap[$r['supplier_id']][$r['kriteria_id']] = floatval($r['nilai']);
}

$minMax = [];
foreach ($kriteria as $k) {
    $vals = array_filter(array_map(fn($s) => $nilaiMap[$s['id']][$k['id']] ?? 0, $suppliers));
    $minMax[$k['id']] = ['max' => $vals ? max($vals) : 0, 'min' => $vals ? min($vals) : 0];
}

$rij = [];
foreach ($suppliers as $s) {
    foreach ($kriteria as $k) {
        $xij = $nilaiMap[$s['id']][$k['id']] ?? 0;
        $max = $minMax[$k['id']]['max'];
        $min = $minMax[$k['id']]['min'];
        $rij[$s['id']][$k['id']] = ($k['jenis'] === 'benefit')
            ? ($max > 0 ? $xij / $max : 0)
            : ($xij  > 0 ? $min / $xij : 0);
    }
}
?>

<div class="page-header fade-in">
  <div class="page-title-wrap">
    <span class="page-title-icon">🔢</span>
    <div>
      <h1>Data Normalisasi</h1>
      <p>Tabel Matriks Ternormalisasi (R) Berdasarkan Jenis Kriteria (Benefit &amp; Cost)</p>
    </div>
  </div>
  <div class="d-flex gap-2 no-print">
    <a href="<?= BASE_URL ?>/spk/hasil.php" class="btn btn-primary btn-sm">Lanjut Perhitungan SAW →</a>
  </div>
</div>

<?php if(empty($suppliers) || empty($nilaiMap)): ?>
<div class="alert alert-warning fade-in">
  ⚠️ Belum ada data penilaian.
  <a href="<?= BASE_URL ?>/penilaian/index.php" class="btn btn-primary btn-sm" style="margin-left:8px;">Input Penilaian</a>
</div>
<?php else: ?>

<div class="card fade-in">
  <div class="card-header">
    <div class="card-title">🔢 Tabel Matriks Ternormalisasi (R)</div>
  </div>
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th style="text-align:center; width:50px;">No</th>
          <th>Kode</th>
          <th>Nama Supplier</th>
          <?php foreach($kriteria as $k): ?>
          <th style="text-align:center;">
            Nilai <?= $k['kode'] ?><br>
            <small style="font-weight:400; text-transform:uppercase; font-size:10px; color:#e0e7ff;">
              (<?= $k['jenis'] ?>)
            </small>
          </th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
      <?php $no=1; foreach($suppliers as $s): ?>
      <tr>
        <td class="td-muted" style="text-align:center;"><?= $no++ ?></td>
        <td><span class="tag-kode"><?= $s['kode'] ?></span></td>
        <td><strong><?= htmlspecialchars($s['nama']) ?></strong></td>
        <?php foreach($kriteria as $k): $r = $rij[$s['id']][$k['id']] ?? 0; ?>
        <td style="text-align:center; font-weight:600; color:#4361ee;"><?= number_format($r, 3) ?></td>
        <?php endforeach; ?>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card fade-in">
  <div class="card-header">
    <div class="card-title">📊 Tabel Nilai Awal (X) &amp; Nilai Max/Min</div>
  </div>
  <div class="table-wrapper">
    <table>
      <thead>
        <tr>
          <th style="text-align:center; width:50px;">No</th>
          <th>Kode</th>
          <th>Nama Supplier</th>
          <?php foreach($kriteria as $k): ?>
          <th style="text-align:center;">
            <?= $k['kode'] ?><br>
            <small style="font-weight:400; font-size:10px; color:#e0e7ff;">(<?= $k['jenis'] ?>)</small>
          </th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
      <?php $no=1; foreach($suppliers as $s): ?>
      <tr>
        <td class="td-muted" style="text-align:center;"><?= $no++ ?></td>
        <td><span class="tag-kode"><?= $s['kode'] ?></span></td>
        <td><strong><?= htmlspecialchars($s['nama']) ?></strong></td>
        <?php foreach($kriteria as $k): $v = $nilaiMap[$s['id']][$k['id']] ?? '-'; ?>
        <td style="text-align:center; font-weight:600;"><?= $v ?></td>
        <?php endforeach; ?>
      </tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr style="background:#f8fafc; font-size:12px; font-weight:600;">
          <td colspan="3" style="padding:10px 16px; text-align:right; color:var(--text);">Max / Min</td>
          <?php foreach($kriteria as $k): ?>
          <td style="text-align:center; padding:10px 16px;">
            <span style="color:#10b981;">Max: <?= $minMax[$k['id']]['max'] ?></span><br>
            <span style="color:#ef4444;">Min: <?= $minMax[$k['id']]['min'] ?></span>
          </td>
          <?php endforeach; ?>
        </tr>
      </tfoot>
    </table>
  </div>
</div>

<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
