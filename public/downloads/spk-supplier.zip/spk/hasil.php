<?php
$pageTitle = 'Hasil Perhitungan';
require_once '../config/database.php';
require_once '../includes/header.php';

$suppliers = $conn->query("SELECT * FROM supplier ORDER BY kode")->fetch_all(MYSQLI_ASSOC);
$kriteria  = $conn->query("SELECT * FROM kriteria ORDER BY kode")->fetch_all(MYSQLI_ASSOC);

$nilaiMap = [];
$res = $conn->query("SELECT supplier_id, kriteria_id, nilai FROM penilaian");
while ($r = $res->fetch_assoc()) {
    $nilaiMap[$r['supplier_id']][$r['kriteria_id']] = floatval($r['nilai']);
}

$minMax = [];
foreach ($kriteria as $k) {
    $vals = array_filter(array_map(fn($s) => $nilaiMap[$s['id']][$k['id']] ?? 0, $suppliers));
    $minMax[$k['id']] = ['max' => $vals ? max($vals) : 0, 'min' => $vals ? min($vals) : 0];
}

$rij = [];
foreach ($suppliers as $s) {
    foreach ($kriteria as $k) {
        $xij = $nilaiMap[$s['id']][$k['id']] ?? 0;
        $max = $minMax[$k['id']]['max'];
        $min = $minMax[$k['id']]['min'];
        $rij[$s['id']][$k['id']] = ($k['jenis'] === 'benefit')
            ? ($max > 0 ? $xij / $max : 0)
            : ($xij  > 0 ? $min / $xij : 0);
    }
}

$viData = [];
foreach ($suppliers as $s) {
    $vi = 0;
    foreach ($kriteria as $k) {
        $vi += floatval($k['bobot']) * ($rij[$s['id']][$k['id']] ?? 0);
    }
    $viData[] = ['supplier' => $s, 'vi' => $vi];
}
usort($viData, fn($a,$b) => $b['vi'] <=> $a['vi']);
foreach ($viData as $i => &$vd) { $vd['peringkat'] = $i + 1; }
unset($vd);

$bobotStr = '(' . implode(')(', array_map(fn($k) => $k['bobot'], $kriteria)) . ')';
$winner   = $viData[0]['supplier']['nama'] ?? '-';
$winScore = number_format($viData[0]['vi'] ?? 0, 4);

$isSubmitted = isset($_GET['metode']);
$hariInd = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
$bulanInd = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
$tglCetak    = $hariInd[date('w')] . ', ' . date('d') . ' ' . $bulanInd[(int)date('n')] . ' ' . date('Y');
$adminNama   = $_SESSION['nama'] ?? 'Administrator';
?>

<style>
@media print {
    @page { size: A4 portrait; margin: 8mm 10mm; }
    body { padding: 0 !important; margin: 0 !important; background: #fff !important; font-size: 9.5pt !important; }
    .main-content { margin-left: 0 !important; padding: 0 !important; width: 100% !important; max-width: 100% !important; }
    .card { width: 100% !important; max-width: 100% !important; margin: 0 0 10px 0 !important; border: 1px solid #000 !important; box-shadow: none !important; border-radius: 0 !important; }
    .table-wrapper { width: 100% !important; overflow: visible !important; }
    table { width: 100% !important; table-layout: auto !important; border-collapse: collapse !important; }
    th, td { border: 1px solid #000 !important; padding: 4px 8px !important; color: #000 !important; }
    thead tr, tr[style*="background"] { background: #f1f5f9 !important; color: #000 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    thead th, th { color: #000 !important; background: #f1f5f9 !important; }
    .card-header { background: #f1f5f9 !important; color: #000 !important; border-bottom: 1px solid #000 !important; }
    .card-title { color: #000 !important; }
    .print-ttd { display: flex !important; }
    
    .card-matrix-x { display: none !important; }
    
    .tbl-ranking tbody tr:nth-child(n+6) { display: none !important; }
}
</style>

<div class="page-header fade-in">
  <div class="page-title-wrap">
    <span class="page-title-icon">🧮</span>
    <div>
      <h1>Data Perhitungan</h1>
      <p>Proses Perhitungan Metode SAW (Simple Additive Weighting) — Bobot : <?= $bobotStr ?></p>
    </div>
  </div>
  <div class="d-flex gap-2 no-print">
    <a href="<?= BASE_URL ?>/spk/normalisasi.php" class="btn btn-secondary btn-sm">← Kembali</a>
    <button onclick="window.print()" class="btn btn-success btn-sm">🖨️ Cetak PDF</button>
  </div>
</div>

<div class="card fade-in no-print">
  <div class="card-header">
    <div class="card-title">🗂️ Hitung Berdasarkan Metode</div>
  </div>
  <div class="card-body">
    <form method="GET" action="" style="display: flex; align-items: center; gap: 10px; flex-wrap: nowrap; max-width: 720px;">
      <div style="display: flex; flex-grow: 1; border: 1px solid #cbd5e1; border-radius: var(--radius); overflow: hidden;">
        <span style="background: #f1f5f9; padding: 8px 14px; font-weight: 600; color: #475569; border-right: 1px solid #cbd5e1; white-space: nowrap; font-size: 12.5px;">Pilih Metode</span>
        <select name="metode" class="form-control" style="border: none; border-radius: 0; padding: 8px 12px; font-weight: 600; color: #1e293b; font-size: 12.5px; width: 100%;">
          <option value="SAW" selected>Perhitungan Metode SAW (Simple Additive Weighting)</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary" style="padding: 8px 24px; white-space: nowrap; font-weight: 700; background: #2563eb; border: none; flex-shrink: 0; height: 38px; box-shadow: 0 2px 6px rgba(37,99,235,0.3);">
        🔍 Hitung
      </button>
    </form>
  </div>
</div>

<?php if ($isSubmitted): ?>

<div class="alert alert-success fade-in no-print">
  <span>✅ <strong>Kalkulasi Berhasil Dilakukan!</strong> Perhitungan metode SAW telah diperbarui secara real-time berdasarkan data penilaian dan bobot kriteria terbaru.</span>
</div>
<?php endif; ?>

<?php if(empty($nilaiMap)): ?>
<div class="alert alert-warning fade-in no-print">
  ⚠️ Belum ada data penilaian. <a href="<?= BASE_URL ?>/penilaian/index.php" class="btn btn-primary btn-sm" style="margin-left:8px;">Input Penilaian</a>
</div>
<?php else: ?>

<div class="card card-matrix-x fade-in" style="width:100%;">
  <div class="card-header" style="background: #2563eb; color: #ffffff;">
    <div class="card-title" style="color: #ffffff;">🗂️ Matrix Keputusan (X)</div>
  </div>
  <div class="table-wrapper" style="width:100%;">
    <table style="width:100%;">
      <thead>
        <tr style="background: #1d4ed8; color: #ffffff;">
          <th style="text-align:center; width:50px; color:#ffffff;">No</th>
          <th style="color:#ffffff; text-align:left;">Nama Alternatif</th>
          <?php foreach($kriteria as $k): ?>
          <th style="text-align:center; color:#ffffff; width:60px;"><?= $k['kode'] ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
      <?php $no=1; foreach($suppliers as $s): ?>
      <tr>
        <td class="td-muted" style="text-align:center;"><?= $no++ ?></td>
        <td style="font-weight:600; color:#1e293b; text-align:left;"><?= htmlspecialchars($s['nama']) ?></td>
        <?php foreach($kriteria as $k): ?>
        <td style="text-align:center; font-weight:600;"><?= $nilaiMap[$s['id']][$k['id']] ?? '-' ?></td>
        <?php endforeach; ?>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card fade-in" style="width:100%;">
  <div class="card-header" style="background: #2563eb; color: #ffffff;">
    <div class="card-title" style="color: #ffffff;">🏆 Hasil Perangkingan Supplier</div>
  </div>
  <div class="table-wrapper" style="width:100%;">
    <table class="tbl-ranking" style="width:100%;">
      <thead>
        <tr style="background: #1d4ed8; color: #ffffff;">
          <th style="text-align:center; width:80px; color:#ffffff;">Rank</th>
          <th style="color:#ffffff; text-align:left;">Nama Alternatif Supplier</th>
          <th style="text-align:center; color:#ffffff; width:160px;">Nilai Preferensi (V<sub>i</sub>)</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach($viData as $vd): $s = $vd['supplier']; ?>
      <tr style="<?= $vd['peringkat'] === 1 ? 'background:#f0fdf4;' : '' ?>">
        <td style="text-align:center;">
          <span class="badge <?= $vd['peringkat'] === 1 ? 'badge-benefit' : 'tag-kode' ?>" style="font-size:12px;">
            <?= $vd['peringkat'] === 1 ? '🥇 Rank 1' : 'Rank ' . $vd['peringkat'] ?>
          </span>
        </td>
        <td style="font-weight:600; color:#1e293b; text-align:left;"><?= htmlspecialchars($s['nama']) ?></td>
        <td style="text-align:center; font-size:13.5px; font-weight:800; color:#10b981;">
          <?= number_format($vd['vi'], 4) ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <div style="margin:14px 18px; padding:14px 18px; background:#ecfdf5; border:1px solid #a7f3d0; border-radius:8px;">
    <div style="font-size:13.5px; font-weight:800; color:#047857; margin-bottom:4px;">
      💡 Kesimpulan Rekomendasi Sistem:
    </div>
    <p style="font-size:12.5px; color:#1e293b; line-height:1.5; margin:0;">
      Berdasarkan hasil perhitungan metode SAW di atas, supplier dengan nilai preferensi tertinggi adalah <strong><?= htmlspecialchars($winner) ?></strong> dengan skor <strong><?= $winScore ?></strong>.
      Sehingga <strong><?= htmlspecialchars($winner) ?></strong> direkomendasikan sebagai supplier <em>sparepart</em> terbaik untuk Bengkel Putri Mandiri Motor.
    </p>
  </div>
</div>

<div class="print-ttd no-print-screen" style="display:none; margin-top:20px; justify-content:flex-end; font-family:'Poppins', 'Segoe UI', Arial, sans-serif; font-size:10pt; color:#000; page-break-inside:avoid;">
  <div style="text-align:center; min-width:210px;">
    <div>Bekasi, <?= $tglCetak ?></div>
    <div style="margin-top:2px;">Mengetahui,</div>
    <div style="margin-top:45px; border-top:1px solid #000; width:100%;"></div>
    <div style="margin-top:4px; font-size:9.5pt;">Administrator</div>
  </div>
</div>

<div class="no-print" style="display: flex; justify-content: flex-end; margin-top: 16px; margin-bottom: 8px;">
  <a href="<?= BASE_URL ?>/spk/cetak_hasil.php"
     class="btn btn-primary"
     style="padding: 10px 24px; font-size: 13.5px; font-weight: 700; display: inline-flex; align-items: center; gap: 8px; box-shadow: 0 2px 8px rgba(37,99,235,0.25); border-radius: var(--radius);">
    📋 Cetak Hasil Laporan
  </a>
</div>

<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
