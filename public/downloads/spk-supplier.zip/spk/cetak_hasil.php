<?php
$pageTitle = 'Cetak Hasil Pemilihan Supplier';
require_once '../config/database.php';
require_once '../includes/header.php';

$sqlHasil = "
    SELECT h.peringkat, h.nilai_akhir, h.tanggal, s.kode, s.nama, s.telpon, s.alamat
    FROM hasil_spk h
    JOIN supplier s ON s.id = h.supplier_id
    ORDER BY h.peringkat ASC
    LIMIT 5
";
$hasilData = $conn->query($sqlHasil)->fetch_all(MYSQLI_ASSOC);
$winner    = $hasilData[0] ?? null;

$kriteria  = $conn->query("SELECT * FROM kriteria ORDER BY kode")->fetch_all(MYSQLI_ASSOC);
$totalSup  = $conn->query("SELECT COUNT(*) as c FROM supplier")->fetch_assoc()['c'];
$totalKrit = count($kriteria);

$hariInd = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
$bulanInd = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
$tglCetak  = $hariInd[date('w')] . ', ' . date('d') . ' ' . $bulanInd[(int)date('n')] . ' ' . date('Y');
$kotaCetak = 'Bekasi';
$adminNama = $_SESSION['nama'] ?? 'Administrator';
?>

<style>
@media print {
    @page { size: A4 portrait; margin: 8mm 10mm; }
    .no-print, .navbar, .sidebar, .cetak-toolbar, .admin-menu, .nav-logout, .print-kop, .no-print-screen {
        display: none !important;
    }
    body { background: #fff !important; margin: 0 !important; padding: 0 !important; font-size: 9.5pt !important; }
    .main-content { margin-left: 0 !important; padding: 0 !important; }
    .cetak-wrap { border: none !important; box-shadow: none !important; padding: 0 !important; max-width: 100% !important; }
    * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
}

.cetak-toolbar {
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 12px; flex-wrap: wrap; gap: 8px;
}

.cetak-wrap {
    max-width: 780px;
    margin: 0 auto;
    background: #fff;
    padding: 20px 28px;
    border: 1px solid #cbd5e1;
    border-radius: 6px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    font-family: 'Poppins', 'Segoe UI', Arial, sans-serif;
    font-size: 10pt;
    color: #000 !important;
    line-height: 1.35;
}

.kop-wrap {
    display: flex;
    align-items: center;
    gap: 14px;
    padding-bottom: 8px;
    border-bottom: 3px double #000;
    margin-bottom: 10px;
}
.kop-wrap img { width: 80px; height: auto; flex-shrink: 0; }
.kop-center { text-align: center; flex-grow: 1; }
.kop-center .kop-nama {
    font-size: 16pt; font-weight: 900; letter-spacing: 0.5px;
    color: #b91c1c !important; text-transform: uppercase; margin: 0; line-height: 1.1;
}
.kop-center .kop-alamat { font-size: 9pt; color: #222 !important; margin: 2px 0 0 0; }

.lap-judul {
    text-align: center;
    margin: 8px 0 10px 0;
    border-bottom: 1px solid #000;
    padding-bottom: 6px;
}
.lap-judul h3 {
    font-size: 11.5pt; font-weight: 700; text-transform: uppercase;
    text-decoration: underline; margin: 0; color: #000 !important; letter-spacing: 0.5px;
}
.lap-judul p { font-size: 9.5pt; margin: 2px 0 0 0; color: #333 !important; }

.meta-tbl { border-collapse: collapse; width: 100%; margin-bottom: 8px; }
.meta-tbl td {
    border: none !important; padding: 2px 6px; font-size: 9.5pt;
    color: #000 !important; vertical-align: middle;
    background: transparent !important; font-family: 'Poppins', 'Segoe UI', Arial, sans-serif !important;
    white-space: nowrap;
}
.meta-tbl td.lbl { width: 155px; font-weight: 600; color: #000 !important; }
.meta-tbl td.sep { width: 8px; font-weight: 600; color: #000 !important; }
.meta-tbl td.val { color: #000 !important; font-weight: 400; white-space: nowrap; }
.meta-tbl td.spc { width: 24px; }

.hr-tipis { border: none; border-top: 1px solid #ccc; margin: 8px 0; }

.rec-box-simple {
    border: 1px solid #000;
    background: #f8fafc !important;
    padding: 7px 12px;
    margin: 8px 0 10px 0;
    font-size: 9.5pt;
    color: #000 !important;
    line-height: 1.4;
}
.rec-box-simple .rec-title {
    font-weight: 700;
    text-transform: uppercase;
    font-size: 9pt;
    margin-bottom: 2px;
    color: #000 !important;
}

.tbl-formal {
    width: 100%; border-collapse: collapse;
    font-size: 9pt; margin: 4px 0 10px 0;
}
.tbl-formal thead th {
    background: #1e293b !important; color: #ffffff !important;
    border: 1px solid #000; padding: 4px 6px;
    text-align: center; font-size: 9pt; font-weight: 700;
}
.tbl-formal tbody td {
    border: 1px solid #000; padding: 3px 6px;
    vertical-align: middle; color: #000 !important;
}
.tbl-formal tbody tr:nth-child(even) { background: #f8fafc; }
.tbl-formal .td-rank-1 { font-weight: 700; background: #f0fdf4 !important; }
.tbl-formal .td-center { text-align: center; }
.tbl-formal .td-small { font-size: 8.5pt; }

.sec-label {
    font-size: 9.5pt; font-weight: 700; margin: 8px 0 3px 0;
    color: #000 !important; border-left: 3px solid #000; padding-left: 6px;
}

.ttd-wrap {
    margin-top: 14px;
    text-align: right;
    font-size: 9.5pt;
    color: #000 !important;
    line-height: 1.4;
    page-break-inside: avoid;
}
.ttd-nama-box {
    display: inline-block;
    min-width: 180px;
    text-align: center;
    margin-top: 38px;
    border-top: 1px solid #000;
    padding-top: 2px;
    font-weight: 700;
    font-size: 9.5pt;
    color: #000 !important;
}
.ttd-jabatan-box {
    display: inline-block;
    min-width: 180px;
    text-align: center;
    font-size: 9pt;
    color: #000 !important;
}
</style>

<div class="cetak-toolbar no-print fade-in">
    <div>
        <h1 style="margin:0; font-size:16px; font-weight:700;">🖨️ Laporan Hasil Pemilihan Supplier</h1>
        <p style="margin:2px 0 0; font-size:12px; color:#64748b;">Preview Laporan Hasil Pemilihan Supplier</p>
    </div>
    <div class="d-flex gap-2">
        <a href="hasil.php" class="btn btn-secondary btn-sm">← Kembali</a>
        <button onclick="window.print()" class="btn btn-success btn-sm">🖨️ Cetak / Simpan PDF</button>
    </div>
</div>

<div class="cetak-wrap fade-in-delay-1">

<?php if (empty($hasilData)): ?>
<p style="color:#b91c1c; text-align:center; padding:20px;">
    ⚠️ Belum ada hasil perhitungan. <a href="hitung.php">Hitung SAW dahulu.</a>
</p>
<?php else: ?>

<div class="kop-wrap">
    <img src="<?= BASE_URL ?>/assets/img/logo.jpg" alt="Logo Bengkel">
    <div class="kop-center">
        <div class="kop-nama">Putri Mandiri Motor</div>
        <div class="kop-alamat">Jl. Damai No.65a, Jatiasih, Kota Bekasi, Jawa Barat 17423</div>
        <div class="kop-alamat">Bengkel Sparepart Kendaraan Bermotor</div>
    </div>
</div>

<div class="lap-judul">
    <h3>Laporan Hasil Pemilihan Supplier Sparepart</h3>
    <p>Sistem Pendukung Keputusan Metode <em>Simple Additive Weighting</em> (SAW)</p>
</div>

<table class="meta-tbl">
    <tr>
        <td class="lbl">Tanggal Cetak</td>
        <td class="sep">:</td>
        <td class="val"><?= $tglCetak ?></td>
        <td class="spc"></td>
        <td class="lbl">Dicetak Oleh</td>
        <td class="sep">:</td>
        <td class="val"><?= htmlspecialchars($adminNama) ?></td>
    </tr>
    <tr>
        <td class="lbl">Kota</td>
        <td class="sep">:</td>
        <td class="val"><?= $kotaCetak ?></td>
        <td class="spc"></td>
        <td class="lbl">Metode</td>
        <td class="sep">:</td>
        <td class="val"><em>Simple Additive Weighting</em> (SAW)</td>
    </tr>
    <tr>
        <td class="lbl">Jumlah Supplier Dievaluasi</td>
        <td class="sep">:</td>
        <td class="val"><?= $totalSup ?> Supplier</td>
        <td class="spc"></td>
        <td class="lbl">Jumlah Kriteria</td>
        <td class="sep">:</td>
        <td class="val"><?= $totalKrit ?> Kriteria</td>
    </tr>
</table>

<?php if ($winner): ?>
<div class="rec-box-simple">
    <div class="rec-title">★ Rekomendasi Supplier Terbaik:</div>
    <div>
        <strong><?= htmlspecialchars($winner['nama']) ?></strong> (Kode: <strong><?= $winner['kode'] ?></strong>)
        &nbsp;&mdash;&nbsp; Nilai Preferensi (V<sub>i</sub>) = <strong><?= number_format($winner['nilai_akhir'], 4) ?></strong>
    </div>
</div>
<?php endif; ?>

<div class="sec-label">5 Besar Hasil Perangkingan Supplier (Top 5)</div>
<table class="tbl-formal">
    <thead>
        <tr>
            <th style="width:50px;">Peringkat</th>
            <th style="width:55px;">Kode</th>
            <th>Nama Supplier</th>
            <th>Alamat</th>
            <th style="width:100px;">Telepon</th>
            <th style="width:75px;">Nilai Vi</th>
            <th style="width:130px;">Keterangan</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($hasilData as $h):
        $rank = (int)$h['peringkat'];
        $isWinner = ($rank === 1);
        $medal = match($rank) {
            1 => 'Sangat Direkomendasikan',
            2 => 'Direkomendasikan',
            3 => 'Cukup Direkomendasikan',
            default => 'Kurang Direkomendasikan'
        };
    ?>
    <tr class="<?= $isWinner ? 'td-rank-1' : '' ?>">
        <td class="td-center"><strong><?= $rank ?></strong></td>
        <td class="td-center"><?= $h['kode'] ?></td>
        <td style="font-weight:<?= $isWinner ? '700' : '400' ?>;"><?= htmlspecialchars($h['nama']) ?></td>
        <td class="td-small"><?= htmlspecialchars($h['alamat'] ?? '-') ?></td>
        <td class="td-small"><?= htmlspecialchars($h['telpon'] ?? '-') ?></td>
        <td class="td-center" style="font-weight:700; color:#1e293b;"><?= number_format($h['nilai_akhir'], 4) ?></td>
        <td class="td-small"><?= $medal ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<div class="sec-label">Kriteria Penilaian yang Digunakan</div>
<table class="tbl-formal">
    <thead>
        <tr>
            <th style="width:55px;">Kode</th>
            <th>Nama Kriteria</th>
            <th style="width:70px;">Bobot (%)</th>
            <th style="width:65px;">Bobot</th>
            <th style="width:65px;">Jenis</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($kriteria as $k): ?>
    <tr>
        <td class="td-center"><?= $k['kode'] ?></td>
        <td><?= htmlspecialchars($k['nama']) ?></td>
        <td class="td-center"><?= ($k['bobot'] * 100) ?>%</td>
        <td class="td-center"><?= $k['bobot'] ?></td>
        <td class="td-center" style="font-weight:600; text-transform:uppercase; font-size:8.5pt;">
            <?= $k['jenis'] ?>
        </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<div style="display: flex; justify-content: flex-end; margin-top: 18px; page-break-inside: avoid;">
    <div style="text-align: center; min-width: 210px; font-size: 9.5pt; color: #000;">
        <div><?= $kotaCetak ?>, <?= $tglCetak ?></div>
        <div style="margin-top: 2px;">Mengetahui,</div>
        <div style="margin-top: 45px; border-top: 1px solid #000; width: 100%;"></div>
        <div style="margin-top: 4px; font-size: 9pt;">Administrator</div>
    </div>
</div>

<?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>
