<?php
$pageTitle = 'Data Supplier';
require_once '../config/database.php';
require_once '../includes/header.php';

$msg = $_SESSION['msg'] ?? '';
unset($_SESSION['msg']);

$suppliers = $conn->query("SELECT * FROM supplier ORDER BY CAST(SUBSTRING(kode,2) AS UNSIGNED)");
$hariInd = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
$bulanInd = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
$tglCetak  = $hariInd[date('w')] . ', ' . date('d') . ' ' . $bulanInd[(int)date('n')] . ' ' . date('Y');
$adminNama = $_SESSION['nama'] ?? 'Administrator';
?>

<style>
@media print {
    @page { size: A4 portrait; margin: 10mm; }
    body { padding: 0 !important; margin: 0 !important; background: #fff !important; font-size: 9.5pt !important; }
    .main-content { margin-left: 0 !important; padding: 0 !important; width: 100% !important; max-width: 100% !important; }
    .card { width: 100% !important; max-width: 100% !important; margin: 0 0 12px 0 !important; border: 1px solid #000 !important; box-shadow: none !important; border-radius: 0 !important; }
    .table-wrapper { width: 100% !important; overflow: visible !important; }
    table { width: 100% !important; table-layout: auto !important; border-collapse: collapse !important; }
    th, td { border: 1px solid #000 !important; padding: 5px 8px !important; color: #000 !important; }
    thead tr { background: #f1f5f9 !important; color: #000 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    thead th { color: #000 !important; background: #f1f5f9 !important; }
    .card-header { background: #f1f5f9 !important; color: #000 !important; border-bottom: 1px solid #000 !important; }
    .card-title { color: #000 !important; }
    .print-ttd { display: flex !important; }
    
    tbody tr:nth-child(n+11) { display: none !important; }
}
</style>

<div class="page-header fade-in">
  <div class="page-title-wrap">
    <span class="page-title-icon">👥</span>
    <div>
      <h1>Data Alternatif</h1>
      <p>Kelola Data Alternatif Supplier Sparepart</p>
    </div>
  </div>
  <div class="d-flex gap-2 no-print">
    <button onclick="window.print()" class="btn btn-success btn-sm">🖨️ Cetak Alternatif</button>
    <a href="<?= BASE_URL ?>/supplier/tambah.php" class="btn btn-primary btn-sm">+ Tambah Data</a>
  </div>
</div>

<?php if($msg): ?>
<div class="alert alert-success fade-in"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="card fade-in" style="width: 100%;">
  <div class="card-header">
    <div class="card-title">📋 Daftar Data Alternatif</div>
  </div>
  <div class="table-wrapper" style="width: 100%;">
    <table style="width: 100%; border-collapse: collapse;">
      <thead>
        <tr>
          <th style="width: 45px; text-align: center;">No</th>
          <th style="width: 65px; text-align: center;">Kode</th>
          <th style="text-align: left;">Nama Supplier</th>
          <th style="width: 120px;">Telepon</th>
          <th style="text-align: left;">Alamat</th>
          <th style="width: 100px;">Tgl Input</th>
          <th class="no-print" style="text-align:center;">Aksi</th>
        </tr>
      </thead>
      <tbody>
      <?php if($suppliers->num_rows > 0): $no=1; while($s = $suppliers->fetch_assoc()): ?>
      <tr>
        <td class="td-muted" style="text-align:center;"><?= $no++ ?></td>
        <td style="text-align:center;"><span class="tag-kode"><?= htmlspecialchars($s['kode']) ?></span></td>
        <td style="text-align:left;"><strong><?= htmlspecialchars($s['nama']) ?></strong></td>
        <td class="td-muted"><?= htmlspecialchars($s['telpon'] ?? '-') ?></td>
        <td class="td-muted" style="text-align:left;"><?= htmlspecialchars($s['alamat'] ?? '-') ?></td>
        <td class="td-muted" style="text-align:center;"><?= date('d/m/Y', strtotime($s['created_at'])) ?></td>
        <td class="no-print" style="text-align:center;">
          <a href="<?= BASE_URL ?>/supplier/edit.php?id=<?= $s['id'] ?>" class="btn btn-warning" style="padding: 4px 8px; font-size: 11px; margin-right: 4px;" title="Edit Data">✏️ Edit</a>
          <a href="<?= BASE_URL ?>/supplier/hapus.php?id=<?= $s['id'] ?>" class="btn btn-danger" style="padding: 4px 8px; font-size: 11px;" title="Hapus Data" onclick="return confirm('Yakin ingin menghapus data alternatif ini?')">🗑️ Hapus</a>
        </td>
      </tr>
      <?php endwhile; else: ?>
      <tr><td colspan="7" style="text-align:center; padding:30px; color:var(--muted);">Belum ada data alternatif.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="print-ttd no-print-screen" style="display:none; margin-top:25px; justify-content:flex-end; font-family:'Poppins', 'Segoe UI', Arial, sans-serif; font-size:10pt; color:#000; page-break-inside:avoid;">
  <div style="text-align:center; min-width:210px;">
    <div>Bekasi, <?= $tglCetak ?></div>
    <div style="margin-top:2px;">Mengetahui,</div>
    <div style="margin-top:45px; border-top:1px solid #000; width:100%;"></div>
    <div style="margin-top:4px; font-size:9.5pt;">Administrator</div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>