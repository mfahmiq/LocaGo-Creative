<?php
session_start();
require_once '../config/database.php';

$id = intval($_GET['id'] ?? 0);
if ($id > 0) {
    $conn->query("DELETE FROM penilaian WHERE supplier_id = $id");
    $conn->query("DELETE FROM hasil_spk WHERE supplier_id = $id");
    $stmt = $conn->prepare("DELETE FROM supplier WHERE id = ?");
    $stmt->bind_param('i', $id);
    if ($stmt->execute()) {
        $_SESSION['msg'] = 'Alternatif berhasil dihapus!';
    }
    $stmt->close();
}

header('Location: index.php');
exit;
