<?php
$pageTitle = 'Edit Supplier';
require_once '../config/database.php';
require_once '../includes/header.php';

$id = intval($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM supplier WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$s = $stmt->get_result()->fetch_assoc();

if (!$s) {
    echo '<div class="alert alert-danger">Data tidak ditemukan.</div>';
    require_once '../includes/footer.php';
    exit;
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode   = trim($_POST['kode'] ?? '');
    $nama   = trim($_POST['nama'] ?? '');
    $telpon = trim($_POST['telpon'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');
    $upd    = $conn->prepare("UPDATE supplier SET kode=?, nama=?, telpon=?, alamat=? WHERE id=?");
    $upd->bind_param('ssssi', $kode, $nama, $telpon, $alamat, $id);
    if ($upd->execute()) {
        session_start();
        $_SESSION['msg'] = "alternatif berhasil diperbarui!";
        header('Location: index.php');
        exit;
    }
    $msg = 'Gagal menyimpan perubahan.';
}
?>

<div class="page-header fade-in">
  <h1>Edit Alternatif</h1>
  <p>Perbarui informasi alternatif yang terdaftar</p>
</div>

<?php if($msg): ?><div class="alert alert-danger"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

<div style="max-width:560px;" class="fade-in-delay-1">
  <div class="card">
    <div class="card-header">
      <div class="card-title"><div class="card-title-icon">✏️</div> Edit Data Alternatif</div>
    </div>
    <div class="card-body">
      <form method="POST">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Kode</label>
            <input type="text" name="kode" class="form-control" value="<?= htmlspecialchars($s['kode']) ?>" required maxlength="10">
          </div>
          <div class="form-group">
            <label class="form-label">Nama</label>
            <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($s['nama']) ?>" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Nomor Telepon</label>
          <input type="text" name="telpon" class="form-control" value="<?= htmlspecialchars($s['telpon'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Alamat</label>
          <textarea name="alamat" class="form-control"><?= htmlspecialchars($s['alamat'] ?? '') ?></textarea>
        </div>
        <div class="d-flex gap-2">
          <button type="submit" class="btn btn-primary">💾 Simpan</button>
          <a href="index.php" class="btn btn-outline">← Batal</a>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
