<?php
$pageTitle = 'Tambah alternatif';
require_once '../config/database.php';
require_once '../includes/header.php';

$lastRow  = $conn->query("SELECT kode FROM supplier ORDER BY id DESC LIMIT 1")->fetch_assoc();
$lastKode = $lastRow['kode'] ?? 'A0';
preg_match('/\d+/', $lastKode, $m);
$nextKode = 'A' . (intval($m[0] ?? 0) + 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode   = trim($_POST['kode']   ?? '');
    $nama   = trim($_POST['nama']   ?? '');
    $telpon = trim($_POST['telpon'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');

    if ($kode && $nama) {
        $stmt = $conn->prepare("INSERT INTO supplier (kode, nama, telpon, alamat) VALUES (?,?,?,?)");
        $stmt->bind_param('ssss', $kode, $nama, $telpon, $alamat);
        $stmt->execute();
        $_SESSION['msg'] = "Data alternatif $nama berhasil ditambahkan!";
        header('Location: index.php');
        exit;
    }
}
?>

<div class="page-header fade-in">
  <h1>Tambah Alternatif</h1>
</div>

<div class="card fade-in-delay-1" style="max-width: 540px;">
  <div class="card-header">
    <div class="card-title">Form Tambah Alternatif</div>
  </div>
  <div class="card-body">
    <form method="POST" action="">
      <div class="form-group">
        <label class="form-label">Kode</label>
        <input type="text" name="kode" class="form-control"
          value="<?= htmlspecialchars($_POST['kode'] ?? $nextKode) ?>"
          placeholder="Contoh: A1, A2 ..." required maxlength="10">
      </div>
      <div class="form-group">
        <label class="form-label">Nama</label>
        <input type="text" name="nama" class="form-control"
          value="<?= htmlspecialchars($_POST['nama'] ?? '') ?>"
          placeholder="Nama toko/distributor" required>
      </div>
      <div class="form-group">
        <label class="form-label">Telepon</label>
        <input type="text" name="telpon" class="form-control"
          value="<?= htmlspecialchars($_POST['telpon'] ?? '') ?>"
          placeholder="08xxxxxxxxxx">
      </div>
      <div class="form-group">
        <label class="form-label">Alamat</label>
        <textarea name="alamat" class="form-control" rows="3"
          placeholder="Alamat lengkap supplier"><?= htmlspecialchars($_POST['alamat'] ?? '') ?></textarea>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-primary">Tambah</button>
        <a href="index.php" class="btn btn-danger">Kembali</a>
      </div>
    </form>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
