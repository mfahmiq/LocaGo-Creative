<?php
require_once 'config/database.php';

if (isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $stmt = $conn->prepare("SELECT id, username, password, nama FROM users WHERE username = ?");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['nama']     = $user['nama'];
            header('Location: ' . BASE_URL . '/dashboard.php');
            exit;
        } else {
            $error = 'Username atau password salah.';
        }
    } else {
        $error = 'Harap isi username dan password.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login — SPK Putri Mandiri Motor</title>
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css?v=<?= time() ?>">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    .login-page {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
      padding: 20px;
    }
    .login-card {
      width: 100% !important;
      max-width: 400px !important;
      background: #FFFFFF !important;
      border-radius: 16px !important;
      padding: 35px 30px !important;
      box-shadow: 0 15px 35px rgba(0, 0, 0, 0.4) !important;
    }
    .form-group {
      margin-bottom: 18px !important;
      text-align: left !important;
    }
    .form-label {
      display: block !important;
      font-size: 13px !important;
      font-weight: 600 !important;
      color: #334155 !important;
      margin-bottom: 6px !important;
    }
    .form-control {
      width: 100% !important;
      padding: 10px 14px !important;
      border: 1px solid #CBD5E1 !important;
      border-radius: 8px !important;
      font-size: 13px !important;
      font-family: inherit !important;
      background: #F8FAFC !important;
      color: #1E293B !important;
      box-sizing: border-box !important;
    }
    .form-control:focus {
      outline: none !important;
      border-color: #2563EB !important;
      background: #FFFFFF !important;
      box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15) !important;
    }
    .login-btn {
      width: 100% !important;
      justify-content: center !important;
      padding: 11px !important;
      font-size: 14px !important;
      margin-top: 10px !important;
      background: #2563EB !important;
      color: #FFFFFF !important;
      border: none !important;
      border-radius: 8px !important;
      font-weight: 600 !important;
      cursor: pointer !important;
    }
  </style>
</head>
<body>
<div class="login-page">
  <div class="login-card fade-in">

    <div style="text-align:center; margin-bottom:20px;">
      <img src="<?= BASE_URL ?>/assets/img/logo.jpg" alt="Logo Putri Mandiri Motor" style="max-width: 180px; height: auto;">
    </div>
    <?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="" autocomplete="off">
      <div class="form-group">
        <label class="form-label" for="username">Username</label>
        <input type="text" id="username" name="username"
          class="form-control" placeholder="Masukkan username"
          value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
          required autofocus>
      </div>
      <div class="form-group">
        <label class="form-label" for="password">Password</label>
        <input type="password" id="password" name="password"
          class="form-control" placeholder="Masukkan password" required>
        <div style="margin-top: 8px; display: flex; align-items: center; gap: 6px;">
          <input type="checkbox" id="show-password" style="cursor: pointer; width: auto !important;">
          <label for="show-password" style="font-size: 12px; color: #64748b; cursor: pointer; user-select: none;">Tampilkan Password</label>
        </div>
      </div>
      <button type="submit" class="btn btn-primary login-btn" id="btn-login">
        Login
      </button>
    </form>

    <div class="login-footer">
    </div>
  </div>
</div>

<script>
document.getElementById('show-password').addEventListener('change', function() {
  const pwd = document.getElementById('password');
  pwd.type = this.checked ? 'text' : 'password';
});
</script>
</body>
</html>
