<?php

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host     = $_SERVER['HTTP_HOST'] ?? 'localhost';
$script   = $_SERVER['SCRIPT_NAME'] ?? '';

$parts    = explode('/', trim($script, '/'));
$rootDir  = '/' . ($parts[0] ?? 'spk-supplier');

if (count($parts) <= 1) $rootDir = '';

define('BASE_URL', $protocol . '://' . $host . $rootDir);
define('ROOT_PATH', dirname(__DIR__) . '/');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'spk_supplier');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die('
    <!DOCTYPE html>
    <html>
    <head><title>Error Koneksi</title>
    <style>
        body { font-family: sans-serif; background: #0f0f1a; color: #fff;
               display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .box { background: #1a1a2e; border: 1px solid #e74c3c; padding: 30px 40px;
               border-radius: 12px; text-align: center; max-width: 420px; }
        h2 { color: #e74c3c; }
        code { background: #2a2a3e; padding: 8px 12px; border-radius: 6px;
               display: block; margin: 10px 0; font-size: 13px; color: #aaa; }
        a { color: #6C63FF; }
    </style>
    </head>
    <body>
    <div class="box">
        <h2>⚠️ Koneksi Database Gagal</h2>
        <p>Pastikan <strong>XAMPP sudah berjalan</strong> dan database sudah diimport.</p>
        <code>' . htmlspecialchars($conn->connect_error) . '</code>
        <p style="font-size:13px; color:#aaa;">
            Import file: <strong>database/spk_supplier.sql</strong><br>
            ke <strong>PHPMyAdmin → database: spk_supplier</strong>
        </p>
    </div>
    </body>
    </html>');
}

$conn->set_charset('utf8mb4');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
