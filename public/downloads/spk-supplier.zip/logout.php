<?php
require_once 'config/database.php';
session_unset();
session_destroy();
header('Location: ' . BASE_URL . '/login.php');
exit;
