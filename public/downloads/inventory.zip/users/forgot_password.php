<?php
/**
 * users/forgot_password.php
 *
 * Forgot password form. Accepts email or username and sends (or generates)
 * a password reset token. Uses generic messaging to prevent username enumeration.
 *
 * @package default
 */

// spaces before html can cause some servers to error.
ob_start();
require_once '../includes/load.php';

// Redirect if already logged in
if ($session->isUserLoggedIn()) {
    redirect('../users/home.php', false);
}

$error = '';
$sent  = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $error = 'Security check failed. Please try again.';
    } else {
        $identifier = sanitize_input($_POST['identifier'] ?? '');
        if (empty($identifier)) {
            $error = 'Please enter your username or email.';
        } else {
            $token = create_password_reset($identifier);
            // Always show success to avoid username enumeration
            $sent = true;
            if ($token) {
                // Token generated — deliver via SMTP when Plan C (alerts.php) is ported.
                error_log("Password reset requested for identifier (token generated but not emailed).");
            }
        }
    }
}

$page_title = 'Forgot Password';
?>
<?php include_once '../layouts/header.php'; ?>

<div class="login-page">
    <div class="text-center">
        <h1>Reset your password</h1>
    </div>

    <?php if ($sent): ?>
        <div class="alert alert-success">
            <p>If that account exists, a password reset link has been sent. Check your email or contact your administrator.</p>
        </div>
        <div class="text-center">
            <a href="index.php" class="btn btn-info">Back to login</a>
        </div>
    <?php else: ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo remove_junk($error); ?></div>
        <?php endif; ?>

        <form method="post" class="clearfix">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="identifier" class="control-label">Username or Email</label>
                <input type="text" class="form-control" name="identifier" placeholder="Enter your username or email" required autofocus>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-info float-end">Send Reset Link</button>
            </div>
        </form>

        <div class="text-center mt-3">
            <a href="index.php">Back to login</a>
        </div>
    <?php endif; ?>
</div>

<?php include_once '../layouts/footer.php'; ?>
