<?php
/**
 * users/reset_password.php
 *
 * Password reset form. Accepts token (from email) and validates it.
 * If valid, allows user to set a new password.
 *
 * @package default
 */

// spaces before html can cause some servers to error.
ob_start();
require_once '../includes/load.php';

$token = sanitize_input(
    $_SERVER['REQUEST_METHOD'] === 'POST'
        ? ($_POST['token'] ?? '')
        : ($_GET['token'] ?? '')
);
$error = '';
$done  = false;

// Check if token is valid
if (empty($token) || !validate_reset_token($token)) {
    $page_title = 'Invalid Link';
    include '../layouts/header.php';
    ?>
    <div class="container mt-5">
        <div class="alert alert-danger">
            <p>This password reset link is invalid or has expired.</p>
            <a href="forgot_password.php" class="btn btn-secondary">Request a new reset link</a>
        </div>
    </div>
    <?php
    include '../layouts/footer.php';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $error = 'Security check failed. Please try again.';
    } else {
        $new_pass  = $_POST['password']         ?? '';
        $conf_pass = $_POST['password_confirm'] ?? '';

        if (strlen($new_pass) < 8) {
            $error = 'Password must be at least 8 characters.';
        } elseif ($new_pass !== $conf_pass) {
            $error = 'Passwords do not match.';
        } else {
            if (consume_reset_token($token, $new_pass)) {
                $done = true;
            } else {
                $error = 'Reset failed — the link may have just expired. Try again.';
            }
        }
    }
}

$page_title = 'Reset Password';
?>
<?php include_once '../layouts/header.php'; ?>

<div class="login-page">
    <div class="text-center">
        <h1>Set new password</h1>
    </div>

    <?php if ($done): ?>
        <div class="alert alert-success">
            <p>Your password has been updated successfully. You can now log in.</p>
        </div>
        <div class="text-center">
            <a href="index.php" class="btn btn-info">Go to login</a>
        </div>
    <?php else: ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo remove_junk($error); ?></div>
        <?php endif; ?>

        <form method="post" class="clearfix">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo h($token); ?>">

            <div class="form-group">
                <label for="password" class="control-label">New Password</label>
                <input type="password" class="form-control" name="password" placeholder="Minimum 8 characters" required minlength="8" autofocus>
            </div>

            <div class="form-group">
                <label for="password_confirm" class="control-label">Confirm Password</label>
                <input type="password" class="form-control" name="password_confirm" placeholder="Confirm your password" required minlength="8">
            </div>

            <div class="form-group">
                <button type="submit" class="btn btn-info float-end">Set Password</button>
            </div>
        </form>
    <?php endif; ?>
</div>

<?php include_once '../layouts/footer.php'; ?>
