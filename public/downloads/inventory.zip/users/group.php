<?php
/**
 * group.php
 *
 * @package default
 */


$page_title = 'All Group';
require_once '../includes/load.php';
// Checkin What level user has permission to view this page
page_require_level(ROLE_ADMIN);

// Setting language var
$lang->set('users.php');

$all_groups = find_all('user_groups');

?>

<?php include_once '../layouts/header.php'; ?>

<div class="row">
   <div class="col-md-12">
     <?php echo display_msg($msg); ?>
   </div>
</div>
<!--     *************************     -->
<div class="row">
  <div class="col-md-12">
    <div class="card">
    <div class="card-header clearfix">
      <strong>
        <?php echo bi('grid-3x3-gap'); ?>
        <span>Groups</span>
     </strong>
          <div class="float-end">
             <!-- <a href="../users/add_group.php"class="btn btn-primary">Add New Group</a> -->
          </div>
    </div>
<!--     *************************     -->
     <div class="card-body">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th class="text-center col-w-50">#</th>
<!--     *************************     -->
            <th>Group Name</th>
<!--     *************************     -->
            <th class="text-center col-w-20p">Group Level</th>
            <th class="text-center col-w-15p">Status</th>
            <th class="text-center col-w-100">Actions</th>
          </tr>
        </thead>
        <tbody>


        <?php foreach ($all_groups as $a_group): ?>

          <tr>
           <td class="text-center"><?php echo count_id();?></td>
           <td><?php echo ucwords($a_group['group_name'])?></td>
           <td class="text-center">
             <?php echo ucwords($a_group['group_level'])?>
           </td>
<!--     *************************     -->
           <td class="text-center">
           <?php if ((int)$a_group['group_status'] === 1): ?>
            <span class="badge bg-success"><?php echo "Active"; ?></span>
          <?php else: ?>
            <span class="badge bg-danger"><?php echo "Deactive"; ?></span>
          <?php endif;?>
           </td>
<!--     *************************     -->
           <td class="text-center">
             <div class="btn-group">
                <a href="../users/edit_group.php?id=<?php echo (int)$a_group['id'];?>" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
                  <?php echo bi('pencil'); ?>
               </a>
<!--
                <a href="../users/delete_group.php?id=<?php echo (int)$a_group['id'];?>" onClick=\"return confirm('Are you sure you want to delete?')\" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Remove">
                  <?php echo bi('x-lg'); ?>
                </a>
-->
                </div>
           </td>
<!--     *************************     -->
          </tr>


        <?php endforeach;?>


       </tbody>
     </table>
     </div>
    </div>
  </div>
</div>
  <?php include_once '../layouts/footer.php'; ?>
