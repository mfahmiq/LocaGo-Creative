<?php
/**
 * profile.php
 *
 * @package default
 */


$page_title = 'My Profile';
require_once '../includes/load.php';
// Checkin What level user has permission to view this page
page_require_level(ROLE_USER);
?>
  <?php
$user_id = (int)$_GET['id'];
if (empty($user_id)):
	redirect('home.php', false);
else:
	$user_p = find_by_id('users', $user_id);
endif;
?>
<?php include_once '../layouts/header.php'; ?>
<div class="row">
   <div class="col-md-4">
       <div class="card profile">
         <div class="bg-danger text-white rounded-3 p-4 text-center">
            <img class="img-circle img-size-2" src="../uploads/users/<?php echo h($user_p['image']);?>" alt="">
           <h3><?php echo first_character($user_p['name']); ?></h3>
         </div>
        <?php if ( $user_p['id'] === $user['id']):?>
         <ul class="nav nav-pills flex-column">
          <li><a href="../users/edit_account.php"> <?php echo bi('pencil'); ?> Edit profile</a></li>
         </ul>
       <?php endif;?>
       </div>
   </div>
</div>
<?php include_once '../layouts/footer.php'; ?>
