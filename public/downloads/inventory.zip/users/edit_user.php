<?php
/**
 * edit_user.php
 *
 * @package default
 */


$page_title = 'Edit User';
require_once '../includes/load.php';
// Checkin What level user has permission to view this page
page_require_level(ROLE_ADMIN);
?>

<!--     *************************     -->

<?php
$e_user = find_by_id('users', (int)$_GET['id']);
$groups  = find_all('user_groups');
if (!$e_user) {
	$session->msg("d", "Missing user id.");
	redirect('../users/users.php');
}
?>

<!--     *************************     -->

<?php
//Update User basic info
if (!verify_csrf()) { $session->msg('d', 'Invalid or missing security token.'); redirect($_SERVER['HTTP_REFERER'] ?? 'index.php', false); }
  if (isset($_POST['update'])) {
$req_fields = array('name', 'username', 'level');
	validate_fields($req_fields);
	if (empty($errors)) {
		$id = (int)$e_user['id'];
		$name = remove_junk($db->escape($_POST['name']));
		$username = remove_junk($db->escape($_POST['username']));
		$level = (int)$db->escape($_POST['level']);
		$status   = remove_junk($db->escape($_POST['status']));
		$sql = "UPDATE users SET name ='{$name}', username ='{$username}',user_level='{$level}',status='{$status}' WHERE id='{$db->escape($id)}'";
		$result = $db->query($sql);
		if ($result && $db->affected_rows() === 1) {
			$session->msg('s', "Acount Updated ");
			redirect('../users/edit_user.php?id='.(int)$e_user['id'], false);
		} else {
			$session->msg('d', ' Sorry failed to updated!');
			redirect('../users/edit_user.php?id='.(int)$e_user['id'], false);
		}
	} else {
		$session->msg("d", $errors);
		redirect('../users/edit_user.php?id='.(int)$e_user['id'], false);
	}
}
?>

<!--     *************************     -->


<?php
// Update user password
if (isset($_POST['update-pass'])) {
$req_fields = array('password');
	validate_fields($req_fields);
	if (empty($errors)) {
		$id = (int)$e_user['id'];
		$password = $_POST['password'];
		$pw_err = validate_password($password);
		if ($pw_err !== null) {
			$session->msg('d', $pw_err);
			redirect('../users/edit_user.php?id='.(int)$e_user['id'], false);
		}
		$h_pass   = password_hash($password, PASSWORD_BCRYPT);
		$stmt = $db->prepare_query(
			"UPDATE users SET password = ? WHERE id = ?",
			"si", $h_pass, $id
		);
		$affected = $stmt->affected_rows;
		$stmt->close();
		if ($affected === 1) {
			$session->msg('s', "User password has been updated ");
			redirect('../users/edit_user.php?id='.(int)$e_user['id'], false);
		} else {
			$session->msg('d', ' Sorry failed to updated user password!');
			redirect('../users/edit_user.php?id='.(int)$e_user['id'], false);
		}
	} else {
		$session->msg("d", $errors);
		redirect('../users/edit_user.php?id='.(int)$e_user['id'], false);
	}
}

?>

<!--     *************************     -->


<?php include_once '../layouts/header.php'; ?>
 <div class="row">
   <div class="col-md-12"> <?php echo display_msg($msg); ?> </div>

<!--     *************************     -->

  <div class="col-md-6">
     <div class="card">
<!--     *************************     -->
       <div class="card-header">
        <strong>
          <?php echo bi('grid-3x3-gap'); ?>
          Update <?php echo ucwords($e_user['name']); ?> Account
        </strong>
       </div>
<!--     *************************     -->

       <div class="card-body">

          <form method="post" action="../users/edit_user.php?id=<?php echo (int)$e_user['id'];?>" class="clearfix">
              <?php echo csrf_field(); ?>
<!--     *************************     -->
            <div class="form-group">
                  <label for="name" class="control-label">Name</label>
                  <input type="name" class="form-control" name="name" value="<?php echo ucwords($e_user['name']); ?>">
            </div>
<!--     *************************     -->
            <div class="form-group">
                  <label for="username" class="control-label">Username</label>
                  <input type="text" class="form-control" name="username" value="<?php echo h($e_user['username']); ?>">
            </div>
<!--     *************************     -->
            <div class="form-group">
              <label for="level">User Role</label>
                <select class="form-control" name="level">
                  <?php foreach ($groups as $group ):?>
                   <option <?php if ((int)$group['group_level'] === (int)$e_user['user_level']) echo 'selected="selected"';?> value="<?php echo (int)$group['group_level'];?>"><?php echo h(ucwords($group['group_name']));?></option>
                <?php endforeach;?>
                </select>
            </div>
<!--     *************************     -->
            <div class="form-group">
              <label for="status">Status</label>
                <select class="form-control" name="status">
                  <option <?php if ((int)$e_user['status'] === 1) echo 'selected="selected"';?> value="1">Active</option>
                  <option <?php if ((int)$e_user['status'] === 0) echo 'selected="selected"';?> value="0">Deactive</option>
                </select>
            </div>
<!--     *************************     -->
            <div class="form-group clearfix">
                    <button type="submit" name="update" class="btn btn-info">Update</button>
            </div>
        </form>
       </div>
     </div>
  </div>


  <!-- Change password form -->

  <div class="col-md-6">
    <div class="card">
      <div class="card-header">
        <strong>
          <?php echo bi('grid-3x3-gap'); ?>
          Change <?php echo ucwords($e_user['name']); ?> password
        </strong>
      </div>
      <div class="card-body">
        <form action="../users/edit_user.php?id=<?php echo (int)$e_user['id'];?>" method="post" class="clearfix">
          <div class="form-group">
                <label for="password" class="control-label">Password</label>
                <input type="password" class="form-control" name="password" placeholder="Type user new password">
          </div>
          <div class="form-group clearfix">
                  <button type="submit" name="update-pass" class="btn btn-danger float-end">Change</button>
          </div>
        </form>
      </div>
    </div>
  </div>

<!--     *************************     -->

 </div>
<?php include_once '../layouts/footer.php'; ?>
