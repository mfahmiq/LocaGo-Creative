<?php
/**
 * users/audit.php
 */
require_once '../includes/load.php';
page_require_level(ROLE_ADMIN);

$entries    = find_audit_log(500);
$page_title = 'Audit Log';
include '../layouts/header.php';
?>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header"><h4>Audit Log</h4></div>
      <div class="card-body p-0">
        <table class="table table-sm table-striped mb-0">
          <thead>
            <tr>
              <th>Time</th><th>User</th><th>Module</th>
              <th>Action</th><th>Record</th><th>Summary</th><th>IP</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($entries as $e): ?>
            <tr>
              <td><?php echo remove_junk($e['created_at']); ?></td>
              <td><?php echo remove_junk($e['username'] ?? '—'); ?></td>
              <td><?php echo remove_junk($e['module']); ?></td>
              <td><span class="badge bg-secondary"><?php echo remove_junk($e['action']); ?></span></td>
              <td><?php echo $e['record_id'] ? (int)$e['record_id'] : '—'; ?></td>
              <td><?php echo remove_junk($e['summary']); ?></td>
              <td><?php echo remove_junk($e['ip_address']); ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include '../layouts/footer.php'; ?>
