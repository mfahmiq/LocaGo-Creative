<?php
/**
 * add_user.php
 *
 * @package default
 */


$page_title = 'Add User';
require_once '../includes/load.php';

// Setting language var
$lang->set('users.php');

// Checkin What level user has permission to view this page
page_require_level(ROLE_ADMIN);


$groups = find_all('user_groups');
$all_users = find_all_user();

if (!verify_csrf()) { $session->msg('d', 'Invalid or missing security token.'); redirect($_SERVER['HTTP_REFERER'] ?? 'index.php', false); }
  if (isset($_POST['add_user'])) {
$req_fields = array('full-name', 'username', 'password', 'level' );
	validate_fields($req_fields);

	if (empty($errors)) {
		$name   = remove_junk($db->escape($_POST['full-name']));
		$username   = strtolower(remove_junk($db->escape($_POST['username'])));

		foreach ($all_users as $a_user) {
			if ( $username == $a_user['username'] ) {
				//failed
				$session->msg('d', ' Sorry, username already used!');
				redirect('../users/add_user.php', false);
			}
		}

		$password   = $_POST['password'];
		$user_level = (int)$_POST['level'];
		$pw_err = validate_password($password);
		if ($pw_err !== null) {
			$session->msg('d', $pw_err);
			redirect('../users/add_user.php', false);
		}
		$password_hash = password_hash($password, PASSWORD_BCRYPT);
		$stmt = $db->prepare_query(
			"INSERT INTO users (name, username, password, user_level, status) VALUES (?, ?, ?, ?, '1')",
			"sssi", $name, $username, $password_hash, $user_level
		);
		if ($stmt) {
			//sucess
			$session->msg('s', "User account has been created! ");
			redirect('../users/add_user.php', false);
		} else {
			//failed
			$session->msg('d', ' Sorry, failed to create account!');
			redirect('../users/add_user.php', false);
		}



	} else {
		$session->msg("d", $errors);
		redirect('../users/add_user.php', false);
	}
}
?>
<?php include_once '../layouts/header.php'; ?>
  <?php echo display_msg($msg); ?>
  <div class="row">
    <div class="card">
      <div class="card-header">
        <strong>
          <?php echo bi('grid-3x3-gap'); ?>
          <span>Add New User</span>
       </strong>
      </div>
      <div class="card-body">
        <div class="col-md-6">
          <form method="post" action="../users/add_user.php">
              <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" name="full-name" placeholder="Full Name">
            </div>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" name="username" placeholder="Username">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name ="password"  placeholder="Password">
            </div>
            <div class="form-group">
              <label for="level">User Role</label>
                <select class="form-control" name="level">
                  <?php foreach ($groups as $group ):?>
                   <option value="<?php echo $group['group_level'];?>"><?php echo ucwords($group['group_name']);?></option>
                <?php endforeach;?>
                </select>
            </div>
            <div class="form-group clearfix">
              <button type="submit" name="add_user" class="btn btn-primary">Add User</button>
            </div>
        </form>
        </div>

      </div>

    </div>
  </div>

<?php include_once '../layouts/footer.php'; ?>
