<?php
/**
 * logout.php
 *
 * @package default
 */


require_once '../includes/load.php';
$uid = $_SESSION['user_id'] ?? null;
if ($uid) {
	audit('users', 'logout', (int)$uid, 'Logout');
}
if (!$session->logout()) {redirect("index.php");}
?>
