<?php
/**
 * users.php
 *
 * @package default
 */


?>

<?php
$page_title = 'All Users';
require_once '../includes/load.php';
?>

<?php
// Checkin What level user has permission to view this page
page_require_level(ROLE_ADMIN);
//pull out all user form database

$all_users = find_all_user();

?>

<?php include_once '../layouts/header.php'; ?>

<div class="row">
   <div class="col-md-12">
     <?php echo display_msg($msg); ?>
   </div>
</div>
<!--     *************************     -->

<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <strong>
          <?php echo bi('grid'); ?>
          <span>Users</span>
<!--     *************************     -->
       </strong>
         <a href="../users/add_user.php" class="btn btn-info">Add New User</a>
      </div>
     <div class="card-body p-0">
      <table class="table table-bordered table-striped">
        <thead>
<!--     *************************     -->
          <tr>
            <th class="text-center col-w-50">ID#</th>
            <th>Name </th>
            <th>Username</th>
            <th class="text-center col-w-15p">User Role</th>
            <th class="text-center col-w-10p">Status</th>
            <th class="col-w-20p">Last Login</th>
            <th class="text-center col-w-100">Actions</th>
          </tr>
<!--     *************************     -->
        </thead>
        <tbody>

<!--     *************************     -->
        <?php foreach ($all_users as $a_user): ?>

          <tr>
           <td class="text-center"><?php echo $a_user['id'];?></td>
           <td><?php echo ucwords($a_user['name'])?></td>
           <td><?php echo $a_user['username']?></td>
           <td class="text-center"><?php echo ucwords($a_user['group_name'])?></td>
<!--     *************************     -->
           <td class="text-center">
           <?php if ((int)$a_user['status'] === 1): ?>
            <span class="badge bg-success"><?php echo "Active"; ?></span>
          <?php else: ?>
            <span class="badge bg-danger"><?php echo "Deactive"; ?></span>
          <?php endif;?>
           </td>
<!--     *************************     -->
           <td><?php echo read_date($a_user['last_login'])?></td>
<!--     *************************     -->
           <td class="text-center">
             <div class="btn-group">
                <a href="../users/edit_user.php?id=<?php echo (int)$a_user['id'];?>" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
                  <?php echo bi('pencil'); ?>
               </a>
                <a href="../users/delete_user.php?id=<?php echo (int)$a_user['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Remove">
                  <?php echo bi('trash'); ?>
                </a>
                </div>
           </td>
<!--     *************************     -->
          </tr>

        <?php endforeach;?>
<!--     *************************     -->

       </tbody>
     </table>
     </div>
    </div>
  </div>
</div>
  <?php include_once '../layouts/footer.php'; ?>
