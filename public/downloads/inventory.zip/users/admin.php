<?php
/**
 * admin.php
 *
 * @package default
 */


$page_title = 'Admin Home Page';
require_once '../includes/load.php';

page_require_level(ROLE_ADMIN);

$c_categories     = count_by_id('categories');
$c_products       = count_by_id('products');
$c_sales          = count_by_id('sales');
$c_customers          = count_by_id('customers');
$products_sold   = find_highest_selling_product('10');
$recent_products = find_recent_product_added('5');
$recent_sales    = find_recent_sale_added('5')
?>
<?php include_once '../layouts/header.php'; ?>


<div class="row">
   <div class="col-md-12">
     <?php echo display_msg($msg); ?>
   </div>
</div>
  <div class="row">
    <div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon float-start bg-green">

          <?php echo bi('person'); ?>

        </div>
        <div class="panel-value float-end">
          <h2 class="margin-top"> <?php  echo $c_customers['total']; ?> </h2>
          <p class="text-muted">Customers</p>
        </div>
       </div>
    </div>

    <div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon float-start bg-red">

          <?php echo bi('list'); ?>

        </div>
        <div class="panel-value float-end">
          <h2 class="margin-top"> <?php  echo $c_categories['total']; ?> </h2>
          <p class="text-muted">Categories</p>
        </div>
       </div>
    </div>

    <div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon float-start bg-blue">

          <?php echo bi('cart'); ?>

        </div>
        <div class="panel-value float-end">
          <h2 class="margin-top"> <?php  echo $c_products['total']; ?> </h2>
          <p class="text-muted">Products</p>
        </div>
       </div>
    </div>
<!--     *************************     -->
    <div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon float-start bg-yellow">

          <?php echo bi('piggy-bank'); ?>

        </div>
        <div class="panel-value float-end">
          <h2 class="margin-top"> <?php  echo $c_sales['total']; ?> </h2>
          <p class="text-muted">Sales</p>
        </div>
       </div>
    </div>
    </div>

  <div class="row" id="myDIV">
   <div class="col-md-12">
      <div class="card">
        <div class="float-end">
		<a href="#" data-close-target="#myDIV" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Close"><?php echo bi('x-lg'); ?></a>
        </div>

        <div class="bg-light rounded-3 p-4 text-center">
           <h3>Welcome!</h3>Contact support for additional assistance.
        </div>

      </div>
   </div>
  </div>

  <div class="row">
    <div class="col-md-3 col-sm-6">
      <a href="../users/users.php" class="card text-center border-info">
        <div class="card-body">
          <?php echo bi('people', 'icon-2x'); ?>
          <h4>Manage Users</h4>
        </div>
      </a>
    </div>
    <div class="col-md-3 col-sm-6">
      <a href="../users/group.php" class="card text-center border-info">
        <div class="card-body">
          <?php echo bi('grid', 'icon-2x'); ?>
          <h4>Manage Groups</h4>
        </div>
      </a>
    </div>
    <div class="col-md-3 col-sm-6">
      <a href="../orgs/orgs.php" class="card text-center border-info">
        <div class="card-body">
          <?php echo bi('list-ul', 'icon-2x'); ?>
          <h4>Organizations</h4>
        </div>
      </a>
    </div>
  </div>

  <div class="row">
   <div class="col-md-4">
     <div class="card">
       <div class="card-header">
         <strong>
           <?php echo bi('grid'); ?>
           <span>Highest Selling Products</span>
         </strong>
       </div>

       <div class="card-body">
         <table class="table table-striped table-bordered table-condensed">

          <thead>
           <tr>
             <th>Product</th>
             <th>Total Sold</th>
             <th>Total Quantity</th>
           <tr>
          </thead>


          <tbody>

            <?php foreach ($products_sold as  $product_sold): ?>

              <tr>
                <td><?php echo first_character($product_sold['name']); ?></td>
                <td><?php echo (int)$product_sold['totalSold']; ?></td>
                <td><?php echo (int)$product_sold['totalQty']; ?></td>
              </tr>

            <?php endforeach; ?>


          <tbody>
         </table>
       </div>
     </div>
   </div>
<!--     *************************     -->
   <div class="col-md-4">
      <div class="card">
        <div class="card-header">
          <strong>
            <?php echo bi('grid'); ?>
            <span>LATEST SALES</span>
          </strong>
        </div>
        <div class="card-body">
          <table class="table table-striped table-bordered table-condensed">
       <thead>
         <tr>
           <th class="text-center col-w-50">#</th>
           <th>Product</th>
           <th>Date</th>
           <th>Total Sale</th>
         </tr>
       </thead>
       <tbody>


         <?php foreach ($recent_sales as  $recent_sale): ?>
         <tr>
           <td class="text-center"><?php echo count_id();?></td>
           <td>
            <a href="../sales/edit_sale.php?id=<?php echo (int)$recent_sale['id']; ?>">
             <?php echo first_character($recent_sale['name']); ?>
           </a>
           </td>
           <td><?php echo ucfirst($recent_sale['date']); ?></td>
           <td><?php echo formatcurrency( first_character($recent_sale['price']), $CURRENCY_CODE); ?></td>
        </tr>

       <?php endforeach; ?>


       </tbody>
     </table>
    </div>
   </div>
  </div>
<!--     *************************     -->

  <div class="col-md-4">
    <div class="card">
      <div class="card-header">
        <strong>
          <?php echo bi('grid'); ?>
          <span>Recently Added Products</span>
        </strong>
      </div>
      <div class="card-body">

        <div class="list-group">


      <?php foreach ($recent_products as  $recent_product): ?>
            <a class="list-group-item clearfix" href="../products/view_product.php?id=<?php echo    (int)$recent_product['id'];?>">
                <h4 class="list-group-item-heading">
                 <?php if (empty($recent_product['media_id'])): ?>
                    <img class="img-avatar img-circle" src="../uploads/products/no_image.jpg" alt="">
                  <?php else: ?>
                  <img class="img-avatar img-circle" src="../uploads/products/<?php echo h($recent_product['image']);?>" alt="" />
                <?php endif;?>
                <?php echo first_character($recent_product['name']);?>
                  <span class="badge bg-warning text-dark float-end">
                 <?php echo formatcurrency( (int)$recent_product['sale_price'], $CURRENCY_CODE); ?>
                  </span>
                </h4>
                <span class="list-group-item-text float-end">
                <?php echo first_character($recent_product['category']); ?>
              </span>
          </a>

      <?php endforeach; ?>


    </div>
  </div>
 </div>
</div>
 </div>
  <div class="row">

  </div>


<?php include_once '../layouts/footer.php'; ?>
