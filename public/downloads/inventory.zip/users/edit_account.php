<?php
/**
 * edit_account.php
 *
 * @package default
 */


$page_title = 'Edit Account';
require_once '../includes/load.php';
page_require_level(ROLE_USER);
?>
<?php
//update user image
if (!verify_csrf()) { $session->msg('d', 'Invalid or missing security token.'); redirect($_SERVER['HTTP_REFERER'] ?? 'index.php', false); }
  if (isset($_POST['submit'])) {
$photo = new Media();
	$user_id = (int)$_POST['user_id'];
	$photo->upload($_FILES['file_upload']);
	if ($photo->process_user($user_id)) {
		$session->msg('s', 'photo has been uploaded.');
		redirect('../users/edit_account.php');
	} else {
		$session->msg('d', join($photo->errors));
		redirect('../users/edit_account.php');
	}
}
?>
<?php
//update user other info
if (isset($_POST['update'])) {
$req_fields = array('name', 'username' );
	validate_fields($req_fields);
	if (empty($errors)) {
		$id = (int)$_SESSION['user_id'];
		$name = remove_junk($db->escape($_POST['name']));
		$username = remove_junk($db->escape($_POST['username']));
		$sql = "UPDATE users SET name ='{$name}', username ='{$username}' WHERE id='{$id}'";
		$result = $db->query($sql);
		if ($result && $db->affected_rows() === 1) {
			$session->msg('s', "Acount updated ");
			redirect('../users/edit_account.php', false);
		} else {
			$session->msg('d', ' Sorry, failed to update!');
			redirect('../users/edit_account.php', false);
		}
	} else {
		$session->msg("d", $errors);
		redirect('../users/edit_account.php', false);
	}
}
?>
<?php include_once '../layouts/header.php'; ?>
<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
  <div class="col-md-6">
      <div class="card">
          <div class="card-header clearfix">
            <?php echo bi('camera'); ?>
            <span>Change My Photo</span>
          </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-4">
                <img class="img-circle img-size-2" src="../uploads/users/<?php echo h($user['image']);?>" alt="">
            </div>
            <div class="col-md-8">
              <form class="form" action="../users/edit_account.php" method="POST" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <input type="file" name="file_upload" multiple="multiple" class="btn btn-outline-secondary btn-file"/>
              </div>
              <div class="form-group">
                <input type="hidden" name="user_id" value="<?php echo $user['id'];?>">
                 <button type="submit" name="submit" class="btn btn-warning">Change</button>
              </div>
             </form>
            </div>
          </div>
        </div>
      </div>
  </div>
  <div class="col-md-6">
    <div class="card">
      <div class="card-header clearfix">
        <?php echo bi('pencil'); ?>
        <span>Edit My Account</span>
      </div>
      <div class="card-body">
          <form method="post" action="../users/edit_account.php?id=<?php echo (int)$user['id'];?>" class="clearfix">
              <?php echo csrf_field(); ?>
            <div class="form-group">
                  <label for="name" class="control-label">Name</label>
                  <input type="name" class="form-control" name="name" value="<?php echo h(ucwords($user['name'])); ?>">
            </div>
            <div class="form-group">
                  <label for="username" class="control-label">Username</label>
                  <input type="text" class="form-control" name="username" value="<?php echo h($user['username']); ?>">
            </div>
            <div class="form-group clearfix">
                    <a href="../users/change_password.php" title="change password" class="btn btn-danger float-end">Change Password</a>
                    <button type="submit" name="update" class="btn btn-info">Update</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>


<?php include_once '../layouts/footer.php'; ?>
