<?php
/**
 * users/index.php
 *
 * @package default
 */
// spaces before html can cause some servers to error.
ob_start();
require_once '../includes/load.php';
if ($session->isUserLoggedIn()) { redirect('../users/home.php', false);}
$username = '';
$password = '';
$msg = $msg ?? '';
?>
<?php include_once '../layouts/header.php'; ?>
<div class="login-page">
    <div class="text-center">
       <h1>Welcome</h1>
       <p>Sign in to start your session</p>
     </div>
     <?php echo display_msg($msg); ?>
      <form method="post" action="../users/auth.php" class="clearfix">
              <?php echo csrf_field(); ?>
        <div class="form-group">
              <label for="username" class="control-label">Username</label>
              <input type="text" class="form-control" name="username" value="<?php echo h($username);?>" placeholder="Username" autocomplete="username">
        </div>
        <div class="form-group">
            <label for="Password" class="control-label">Password</label>
            <input type="password" class="form-control" name="password" value="" placeholder="Password" autocomplete="current-password">
        </div>
        <div class="form-group">
                <button type="submit" class="btn btn-info  float-end">Login</button>
        </div>
    </form>
    <div class="text-center mt-3">
       <a href="forgot_password.php">Forgot your password?</a>
     </div>
</div>
<?php include_once '../layouts/footer.php'; ?>
