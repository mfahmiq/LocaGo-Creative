<?php
$page_title = 'Home Page';
require_once '../includes/load.php';
if (!$session->isUserLoggedIn(true)) { redirect('index.php', false); }
page_require_level(ROLE_USER);

$current_level   = (int)current_user()['user_level'];
$recent_products = find_recent_product_added('5');
if ($current_level <= ROLE_SUPERVISOR) {
    $products_sold = find_highest_selling_product('10');
    $recent_sales  = find_recent_sale_added('5');
}
?>
<?php include_once '../layouts/header.php'; ?>

<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
</div>

<div class="row" id="myDIV">
  <div class="col-md-12">
    <div class="card mb-3">
      <div class="card-body">
        <div class="float-end">
          <a href="#" data-close-target="#myDIV" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Close"><?php echo bi('x-lg'); ?></a>
        </div>
        <div class="p-4 mb-0 bg-light rounded-3 text-center">
          <h3>Welcome!</h3>Contact support for additional assistance.
        </div>
      </div>
    </div>
  </div>
</div>

<?php if ($current_level <= ROLE_SUPERVISOR): ?>
<div class="row">
  <div class="col-md-6">
    <div class="card mb-3">
      <div class="card-header">
        <strong><?php echo bi('grid'); ?> Highest Selling Products</strong>
      </div>
      <div class="card-body p-0">
        <table class="table table-striped table-bordered table-sm mb-0">
          <thead>
            <tr>
              <th>Product</th>
              <th>Total Sold</th>
              <th>Total Quantity</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($products_sold as $product_sold): ?>
            <tr>
              <td><?php echo first_character($product_sold['name']); ?></td>
              <td><?php echo (int)$product_sold['totalSold']; ?></td>
              <td><?php echo (int)$product_sold['totalQty']; ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card mb-3">
      <div class="card-header">
        <strong><?php echo bi('grid'); ?> LATEST SALES</strong>
      </div>
      <div class="card-body p-0">
        <table class="table table-striped table-bordered table-sm mb-0">
          <thead>
            <tr>
              <th class="text-center col-w-50">#</th>
              <th>Product</th>
              <th>Date</th>
              <th>Total Sale</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($recent_sales as $recent_sale): ?>
            <tr>
              <td class="text-center"><?php echo count_id(); ?></td>
              <td>
                <a href="../sales/edit_sale.php?id=<?php echo (int)$recent_sale['id']; ?>">
                  <?php echo first_character($recent_sale['name']); ?>
                </a>
              </td>
              <td><?php echo ucfirst($recent_sale['date']); ?></td>
              <td><?php echo formatcurrency(first_character($recent_sale['price']), $CURRENCY_CODE); ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<div class="row">
  <div class="col-md-12">
    <div class="card mb-3">
      <div class="card-header">
        <strong><?php echo bi('grid'); ?> Recently Added Products</strong>
      </div>
      <div class="card-body">
        <div class="list-group list-group-flush">
          <?php foreach ($recent_products as $recent_product): ?>
          <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"
             href="../products/view_product.php?id=<?php echo (int)$recent_product['id']; ?>">
            <span>
              <?php if ((int)$recent_product['media_id'] === 0): ?>
                <img class="img-avatar rounded-circle me-2" src="../uploads/products/no_image.jpg" alt="">
              <?php else: ?>
                <img class="img-avatar rounded-circle me-2" src="../uploads/products/<?php echo $recent_product['image']; ?>" alt="">
              <?php endif; ?>
              <?php echo first_character($recent_product['name']); ?>
            </span>
            <span>
              <span class="badge bg-warning text-dark me-2">
                <?php echo formatcurrency((int)$recent_product['sale_price'], $CURRENCY_CODE); ?>
              </span>
              <small class="text-muted"><?php echo first_character($recent_product['category']); ?></small>
            </span>
          </a>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include_once '../layouts/footer.php'; ?>
