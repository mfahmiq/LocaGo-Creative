<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_ADMIN);

$users   = find_all_user();
$modules = permission_modules();
$actions = ['view', 'create', 'edit', 'delete'];

$selected_user_id = (int) ($_GET['user_id'] ?? ($users[0]['id'] ?? 0));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	csrf_verify();
	$uid = (int) ($_POST['user_id'] ?? 0);
	if ($uid) {
		foreach ($modules as $mod => $_label) {
			$view   = isset($_POST["perm_{$mod}_view"])   ? 1 : 0;
			$create = isset($_POST["perm_{$mod}_create"]) ? 1 : 0;
			$edit   = isset($_POST["perm_{$mod}_edit"])   ? 1 : 0;
			$delete = isset($_POST["perm_{$mod}_delete"]) ? 1 : 0;

			$db->prepare_query(
				"INSERT INTO permissions (user_id, module, can_view, can_create, can_edit, can_delete)
				 VALUES (?, ?, ?, ?, ?, ?)
				 ON DUPLICATE KEY UPDATE
				   can_view=VALUES(can_view), can_create=VALUES(can_create),
				   can_edit=VALUES(can_edit), can_delete=VALUES(can_delete)",
				'isiiii', $uid, $mod, $view, $create, $edit, $delete
			);
		}
		audit('users', 'update', $uid, "Updated permissions for user_id=$uid");
		$session->msg('s', 'Permissions saved.');
	}
	redirect('permissions.php?user_id=' . $uid, false);
}

$perms      = $selected_user_id ? get_user_permissions($selected_user_id) : [];
$page_title = 'Permissions';
include '../layouts/header.php';
?>
<div class="row">
  <div class="col-md-10 offset-md-1">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h4>Permissions</h4>
        <form class="d-flex gap-2" method="get">
          <select name="user_id" class="form-select form-select-sm" onchange="this.form.submit()">
            <?php foreach ($users as $u): ?>
              <option value="<?php echo (int)$u['id']; ?>"
                <?php echo ((int)$u['id'] === $selected_user_id) ? 'selected' : ''; ?>>
                <?php echo remove_junk($u['name']); ?> (<?php echo remove_junk($u['username']); ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </form>
      </div>
      <div class="card-body">
        <?php echo display_msg($msg); ?>
        <form method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="user_id" value="<?php echo $selected_user_id; ?>">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Module</th>
                <?php foreach ($actions as $a): ?>
                  <th class="text-center"><?php echo ucfirst($a); ?></th>
                <?php endforeach; ?>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($modules as $mod => $label): ?>
              <tr>
                <td><?php echo remove_junk($label); ?></td>
                <?php foreach ($actions as $a): ?>
                  <?php
                    $default = ($a === 'view');
                    $checked = isset($perms[$mod])
                        ? (bool) $perms[$mod]["can_$a"]
                        : $default;
                  ?>
                  <td class="text-center">
                    <input type="checkbox" name="perm_<?php echo $mod; ?>_<?php echo $a; ?>"
                      <?php echo $checked ? 'checked' : ''; ?>>
                  </td>
                <?php endforeach; ?>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
          <button type="submit" class="btn btn-primary">Save permissions</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include '../layouts/footer.php'; ?>
