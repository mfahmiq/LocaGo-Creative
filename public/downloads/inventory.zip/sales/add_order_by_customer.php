<?php
/**
 * add_order.php
 *
 * @package default
 */


$page_title = 'Add Order';
require_once '../includes/load.php';
// Checkin What level user has permission to view this page
page_require_level(ROLE_ADMIN);

$all_orders = find_all('orders');
$order_id = last_id('orders');
$new_order_id = $order_id['id'] + 1;

?>
<?php
if (!verify_csrf()) { $session->msg('d', 'Invalid or missing security token.'); redirect($_SERVER['HTTP_REFERER'] ?? 'index.php', false); }
  if (isset($_POST['add_order'])) {
$req_fields = array('customer-name', 'paymethod' );
	validate_fields($req_fields);
	$customer_name = $db->escape($_POST['customer-name']);
	$paymethod = $db->escape($_POST['paymethod']);
	$notes = '';

	if (empty($errors)) {
		if ( ! find_by_name('customers', $customer_name) ) {
			$query  = "INSERT INTO customers (";
			//$query .=" name,address,postcode,telephone,email,paymethod";
			$query .=" name,paymethod,org_id";
			$query .=") VALUES (";
			//$query .=" '{$customer}', '{$c_address}', '{$c_postcode}', '{$c_telephone}', '{$c_email}', '{$paymethod}'";
			$query .=" '{$customer_name}', '{$paymethod}', '" . current_org_id() . "'";
			$query .=")";
			$result = $db->query($query);
			if ($result && $db->affected_rows() === 1) {
				$session->msg('s', "Customer Added! ");
			} else {
				$session->msg('d', ' Sorry, Failed to Add!');
			}
		}

		$current_date    = make_date();

		$sql  = "INSERT INTO orders (id,customer,paymethod,notes,date,org_id)";
		$sql .= " VALUES ('{$new_order_id}','{$customer_name}','{$paymethod}','{$notes}','{$current_date}','" . current_org_id() . "')";
		if ($db->query($sql)) {
			$session->msg("s", "Successfully Added Order");
			redirect( ( '../sales/add_sale_to_order.php?id=' . $new_order_id ) , false);
		} else {
			$session->msg("d", "Sorry, Failed to Add Order!");
			redirect( '../sales/add_order.php' , false);
		}
	} else {
		$session->msg("d", $errors);
		redirect( '../sales/add_order.php' , false);
	}
}
?>

<?php include_once '../layouts/header.php'; ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
    <form method="post" action="../sales/ajax_customer.php" autocomplete="off" id="sug-customer-form">
              <?php echo csrf_field(); ?>
        <div class="form-group">
          <div class="input-group">
            <button type="submit" class="btn btn-primary">Search </button>
            <input type="text" id="sug_customer_input" class="form-control" name="customer_name" value="" placeholder="Customer Name">
         </div>
         <div id="result" class="list-group"></div>
        </div>
    </form>
  </div>

  <div class="col-md-6">
    <div class="card">
      <div class="bg-light rounded-3 p-4 text-center">
<h3>Order #<?php echo $new_order_id; ?></h3>
      </div>
    </div>
</div>


</div>
<div class="row">

  <div class="col-md-12">
    <div class="card">
      <div class="card-header clearfix">
        <strong>
          <?php echo bi('grid'); ?>
          <span>Select Customer</span>
       </strong>
      </div>
      <div class="card-body">
        <form method="post" action="../sales/add_order.php">
              <?php echo csrf_field(); ?>
         <table class="table table-bordered">
           <thead>
                <tr>
                    <th class="text-center col-w-100">Customer</th>
                    <th class="text-center col-w-100">Address</th>
                    <th class="text-center col-w-50">Postal Code</th>
                    <th class="text-center col-w-50">Pay Method</th>
                    <th class="text-center col-w-50">Actions</th>
                </tr>
           </thead>
           <tbody  id="customer_info"> </tbody>
         </table>
       </form>
      </div>
    </div>
  </div>

</div>
<?php include_once '../layouts/footer.php'; ?>
