<?php
/**
 * orders.php
 *
 * @package default
 */


$page_title = 'All Orders';
require_once '../includes/load.php';
// Checkin What level user has permission to view this page
page_require_level(ROLE_ADMIN);

$all_orders = find_all('orders');
$orders = array_reverse($all_orders);
?>
<?php include_once '../layouts/header.php'; ?>
  <div class="row">
     <div class="col-md-12">
       <?php echo display_msg($msg); ?>
     </div>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <strong>
            <?php echo bi('grid'); ?>
            <span>All Orders</span>
          </strong>
          <a href="../sales/add_order.php" class="btn btn-primary">Add Order</a>
        </div>
        <div class="card-body p-0">

          <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th class="text-center col-w-50">#</th>
                    <th class="text-center col-w-50">Customer</th>
                    <th class="text-center col-w-50">Pay Method</th>
                    <th class="text-center col-w-50">Notes</th>
                    <th class="text-center col-w-50">Date</th>
                    <th class="text-center col-w-100">Actions</th>
                </tr>
            </thead>
            <tbody>


              <?php foreach ($orders as $order):?>
                <tr>
                    <td class="text-center">
					<a href="../sales/sales_by_order.php?id=<?php echo (int)$order['id'];?>">
					<?php echo $order['id'];?>
					</a>
					</td>

                    <td class="text-center">
						<?php echo h(ucfirst($order['customer']));?>
					</td>
                    <td class="text-center">
						<?php echo h(ucfirst($order['paymethod']));?>
					</td>

                    <td class="text-center">
						<?php echo h($order['notes']);?>
					</td>

                    <td class="text-center">
						<?php echo h($order['date']);?>
					</td>

  <?php $customer = find_by_name('customers', $order['customer']); ?>

                    <td class="text-center">
                      <div class="btn-group">
                        <a href="../sales/edit_order.php?id=<?php echo (int)$order['id'];?>"  class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
                          <?php echo bi('pencil'); ?>
                        </a>
                        <a href="../customers/edit_customer.php?id=<?php echo (int)$customer['id'];?>"  class="btn btn-sm btn-info" data-bs-toggle="tooltip" title="Customer Details">
                          <?php echo bi('person'); ?>
                        </a>
                        <a href="../sales/delete_order.php?id=<?php echo (int)$order['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Remove">
                          <?php echo bi('trash'); ?>
                        </a>
                      </div>
                    </td>

                </tr>
              <?php endforeach; ?>


            </tbody>
          </table>
       </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once '../layouts/footer.php'; ?>
