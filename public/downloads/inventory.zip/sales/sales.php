<?php
/**
 * sales.php
 *
 * @package default
 */


$page_title = 'All Sales';
require_once '../includes/load.php';
// Checkin What level user has permission to view this page
page_require_level(ROLE_USER);
?>

<?php $sales = find_all_sales(); ?>
<?php include_once '../layouts/header.php'; ?>

<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>
</div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <strong>
            <?php echo bi('grid'); ?>
            <span>All Sales</span>
          </strong>
        </div>
        <div class="card-body p-0">


          <table class="table table-bordered table-striped">
            <thead>
              <tr>
                <th class="text-center col-w-15p">Order</th>
                <th> Product </th>
                <th class="text-center col-w-15p"> Quantity</th>
                <th class="text-center col-w-15p"> Total </th>
                <th class="text-center col-w-15p"> Date </th>
                <th class="text-center col-w-100"> Actions </th>
             </tr>
            </thead>


           <tbody>

             <?php foreach ($sales as $sale):?>

             <tr>
               <td class="text-center"><?php echo (int)$sale['order_id']; ?></td>
               <td><?php echo h($sale['name']); ?></td>
               <td class="text-center"><?php echo (int)$sale['qty']; ?></td>
               <td class="text-center"><?php echo formatcurrency($sale['price'], $CURRENCY_CODE); ?></td>
               <td class="text-center"><?php echo $sale['date']; ?></td>
               <td class="text-center">
                  <div class="btn-group">
                     <a href="../sales/edit_sale.php?id=<?php echo (int)$sale['id'];?>" class="btn btn-warning btn-sm"  title="Edit" data-bs-toggle="tooltip">
                       <?php echo bi('pencil'); ?>
                     </a>
                     <a href="../sales/delete_sale.php?id=<?php echo (int)$sale['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-danger btn-sm"  title="Delete" data-bs-toggle="tooltip">
                       <?php echo bi('trash'); ?>
                     </a>
                  </div>
               </td>
             </tr>

             <?php endforeach;?>

           </tbody>
         </table>


        </div>
      </div>

    </div>
  </div>
<?php include_once '../layouts/footer.php'; ?>
