<?php
/**
 * sales_by_order.php
 *
 * @package default
 */


$page_title = 'Sales by Order';
require_once '../includes/load.php';
// Checkin What level user has permission to view this page
page_require_level(ROLE_USER);

$order_id  = 0;

if (isset($_GET['id'])) {
	$order_id = (int) $_GET['id'];
} else {
	$session->msg("d", "Missing order id.");
}

$sales = find_sales_by_order_id( $order_id );
$order = find_by_id("orders", $order_id);
?>



<?php include_once '../layouts/header.php'; ?>
  <div class="row">
     <div class="col-md-12">
       <?php echo display_msg($msg); ?>
     </div>
  </div>

    <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <strong>
          <?php echo bi('grid'); ?>

            <span>Order #<?php echo $order_id; ?></span>

       </strong>
      </div>
        <div class="card-body">
          <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th class="text-center col-w-50">#</th>
                    <th class="text-center col-w-50">Customer</th>
                    <th class="text-center col-w-50">Pay Method</th>
                    <th class="text-center col-w-50">Notes</th>
                    <th class="text-center col-w-50">Date</th>
                    <th class="text-center col-w-100">Actions</th>
                </tr>
            </thead>
            <tbody>

                <tr>
                    <td class="text-center"><?php echo $order['id'];?>
					</td>

                    <td class="text-center">
						<?php echo ucfirst($order['customer']);?>
					</td>
                    <td class="text-center">
						<?php echo ucfirst($order['paymethod']);?>
					</td>

                    <td class="text-center">
						<?php echo h($order['notes']);?>
					</td>

                    <td class="text-center">
						<?php echo $order['date'];?>
					</td>

                    <td class="text-center">
                      <div class="btn-group">
                        <a href="../sales/edit_order.php?id=<?php echo (int)$order['id'];?>"  class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
                          <?php echo bi('pencil'); ?>
                        </a>
                        <a href="../sales/order_picklist.php?id=<?php echo (int)$order['id'];?>"  class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="Picklist">
                          <?php echo bi('hand-index'); ?>
                        </a>
                        <a href="../sales/sales_invoice.php?id=<?php echo (int)$order['id'];?>"  class="btn btn-sm btn-success" data-bs-toggle="tooltip" title="Invoice">
                          <?php echo bi('box-arrow-up-right'); ?>
                        </a>
                      </div>
                    </td>

                </tr>

            </tbody>
          </table>
       </div>
    </div>



  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header clearfix">
          <strong>
            <?php echo bi('grid'); ?>
            <span>Sales</span>
          </strong>
          <div class="float-end">
            <a href="../sales/add_sale_by_search.php?id=<?php echo $order_id; ?>" class="btn btn-primary">Add sale</a>
          </div>
        </div>
        <div class="card-body">

          <table class="table table-bordered table-striped">
            <thead>
              <tr>
                <th class="text-center col-w-50">#</th>
                <th> Product </th>
                <th class="text-center col-w-15p"> SKU </th>
                <th class="text-center col-w-15p"> Location </th>
                <th class="text-center col-w-15p"> Quantity </th>
                <th class="text-center col-w-15p"> Total </th>
                <th class="text-center col-w-100"> Actions </th>
             </tr>
            </thead>

           <tbody>

             <?php foreach ($sales as $sale):?>

             <tr>
               <td class="text-center"><?php echo count_id();?></td>
               <td><?php echo h($sale['name']); ?></td>
               <td class="text-center"><?php echo h($sale['sku']); ?></td>
               <td class="text-center"><?php echo h($sale['location']); ?></td>
               <td class="text-center"><?php echo (int)$sale['qty']; ?></td>
               <td class="text-center"><?php echo formatcurrency($sale['price'], $CURRENCY_CODE); ?></td>
               <td class="text-center">
                  <div class="btn-group">
                     <a href="../sales/edit_sale.php?id=<?php echo (int)$sale['id'];?>" class="btn btn-warning btn-sm"  title="Edit" data-bs-toggle="tooltip">
                       <?php echo bi('pencil'); ?>
                     </a>
                     <a href="../sales/delete_sale.php?id=<?php echo (int)$sale['id'];?>" class="btn btn-danger btn-sm"  title="Delete" data-bs-toggle="tooltip">
                       <?php echo bi('trash'); ?>
                     </a>
                  </div>
               </td>
             </tr>

             <?php endforeach;?>

             <tr>
               <td class="text-center"></td>
               <td class="text-center"></td>
               <td class="text-center"></td>
               <td class="text-center"></td>
               <td class="text-center"></td>
<?php
$order_total = 0;
foreach ($sales as $sale) {
	$order_total = $order_total + $sale['price'];
}
?>
               <td class="text-center"><?php echo formatcurrency($order_total, $CURRENCY_CODE); ?></td>
               <td class="text-center"></td>


			</tr>


           </tbody>
         </table>
<!--     *************************     -->
        </div>
      </div>


    </div>
  </div>
<?php include_once '../layouts/footer.php'; ?>
