-- Rollback for Migration 022 — password_resets table
DROP TABLE IF EXISTS `password_resets`;
