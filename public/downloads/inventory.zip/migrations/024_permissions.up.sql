-- Migration 024 — permissions table.
-- Per-user, per-module RBAC overrides. Admins (level 1) bypass all checks.
-- Reverse: see 024_permissions.down.sql

SELECT 'Creating permissions table...' AS step;

CREATE TABLE `permissions` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED NOT NULL,
  `module`     VARCHAR(50)  NOT NULL,
  `can_view`   TINYINT(1)   NOT NULL DEFAULT 1,
  `can_create` TINYINT(1)   NOT NULL DEFAULT 0,
  `can_edit`   TINYINT(1)   NOT NULL DEFAULT 0,
  `can_delete` TINYINT(1)   NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_perm_user_module` (`user_id`, `module`),
  CONSTRAINT `fk_perm_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT 'permissions created.' AS step;
