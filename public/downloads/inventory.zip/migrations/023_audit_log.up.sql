-- Migration 023 — audit_log table.
-- Records every significant create/update/delete/login/logout action.
-- Reverse: see 023_audit_log.down.sql

SELECT 'Creating audit_log table...' AS step;

CREATE TABLE `audit_log` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED     NULL DEFAULT NULL,
  `module`     VARCHAR(50)  NOT NULL,
  `action`     ENUM('create','update','delete','login','logout') NOT NULL,
  `record_id`  INT UNSIGNED     NULL DEFAULT NULL,
  `summary`    VARCHAR(255) NOT NULL DEFAULT '',
  `ip_address` VARCHAR(45)  NOT NULL DEFAULT '',
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_al_user`    (`user_id`),
  KEY `idx_al_module`  (`module`),
  KEY `idx_al_created` (`created_at`),
  CONSTRAINT `fk_al_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT 'audit_log created.' AS step;
