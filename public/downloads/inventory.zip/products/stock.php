<?php
/**
 * stock.php
 *
 * @package default
 */


$page_title = 'All stock';
require_once '../includes/load.php';
// Checkin What level user has permission to view this page
page_require_level(ROLE_ADMIN);

$all_stock = find_all('stock');
$all_products = find_all('products');

?>
<?php include_once '../layouts/header.php'; ?>
  <div class="row">
     <div class="col-md-12">
       <?php echo display_msg($msg); ?>
     </div>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <strong>
            <?php echo bi('grid-3x3-gap'); ?>
            <span>Inventory Log</span>
          </strong>
          <div>
            <a href="../products/add_stock.php" class="btn btn-primary">Add Stock</a>
          </div>
        </div>
        <div class="card-body p-0">

          <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th class="text-center col-w-50">Product</th>
                    <th class="text-center col-w-50">Quantity</th>
                    <th class="text-center col-w-50">Comments</th>
                    <th class="text-center col-w-50">Date</th>
                    <th class="text-center col-w-100">Actions</th>
                </tr>
            </thead>
            <tbody>
<!--     *************************     -->
              <?php foreach ($all_stock as $stock):?>
                <tr>

                    <td class="text-center">
					<a href="../products/view_product.php?id=<?php echo (int)$stock['product_id'];?>">
					<?php

foreach ( $all_products as $product ) {
	if ( $stock['product_id'] == $product['id'] ) { echo h($product['name']); }
}

?>
					</a>
					</td>

                    <td class="text-center">
						<?php echo $stock['quantity'];?>
					</td>


                    <td class="text-center">
						<?php echo h($stock['comments']);?>
					</td>
                    <td class="text-center">
						<?php echo $stock['date'];?>
					</td>


                    <td class="text-center">
                      <div class="btn-group">
                        <a href="../products/edit_stock.php?id=<?php echo (int)$stock['id'];?>"  class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
                          <?php echo bi('pencil'); ?>
                        </a>
                        <a href="../products/delete_stock.php?id=<?php echo (int)$stock['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Remove">
                          <?php echo bi('trash'); ?>
                        </a>
                      </div>
                    </td>

                </tr>
              <?php endforeach; ?>
<!--     *************************     -->
            </tbody>
          </table>
       </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once '../layouts/footer.php'; ?>
