<?php
/**
 * media.php
 *
 * @package default
 */


$page_title = 'All Image';
require_once '../includes/load.php';
// Checkin What level user has permission to view this page
page_require_level(ROLE_SUPERVISOR);
?>
<?php $media_files = find_all('media');?>
<?php
if (isset($_POST['submit'])) {
	$photo = new Media();
	$photo->upload($_FILES['file_upload']);
	if ($photo->process_media()) {
		$session->msg('s', 'photo has been uploaded.');
		redirect('../products/media.php');
	} else {
		$session->msg('d', join($photo->errors));
		redirect('../products/media.php');
	}

}

?>
<?php include_once '../layouts/header.php'; ?>
     <div class="row">
        <div class="col-md-6">
          <?php echo display_msg($msg); ?>
        </div>

      <div class="col-md-12">
        <div class="card">
          <div class="card-header clearfix">
            <?php echo bi('camera'); ?>
            <span>All Photos</span>
            <div class="float-end">
              <form class="form-inline" action="../products/media.php" method="POST" enctype="multipart/form-data">
              <div class="form-group">
                <div class="input-group">
                  <span class="input-group-text">
                    <input type="file" name="file_upload" multiple="multiple" class="btn btn-primary btn-file"/>
                 </span>

                 <button type="submit" name="submit" class="btn btn-outline-secondary">Upload</button>
               </div>
              </div>
             </form>
            </div>
          </div>
          <div class="card-body">
            <table class="table">
              <thead>
                <tr>
                  <th class="text-center col-w-50">#</th>
                  <th class="text-center">Photo</th>
                  <th class="text-center">Photo Name</th>
                  <th class="text-center col-w-20p">Photo Type</th>
                  <th class="text-center col-w-50">Actions</th>
                </tr>
              </thead>
                <tbody>
                <?php foreach ($media_files as $media_file): ?>
                <tr class="list-inline">
                 <td class="text-center"><?php echo count_id();?></td>
                  <td class="text-center">
                      <img src="../uploads/products/<?php echo $media_file['file_name'];?>" class="img-thumbnail" />
                  </td>
                <td class="text-center">
                  <?php echo $media_file['file_name'];?>
                </td>
                <td class="text-center">
                  <?php echo $media_file['file_type'];?>
                </td>
                <td class="text-center">
                  <a href="../products/delete_media.php?id=<?php echo (int) $media_file['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-danger btn-sm"  title="Edit">
                    <?php echo bi('trash'); ?>
                  </a>
                </td>
               </tr>
              <?php endforeach;?>
            </tbody>
          </div>
        </div>
      </div>
</div>


<?php include_once '../layouts/footer.php'; ?>
