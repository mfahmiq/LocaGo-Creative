<?php
/**
 * categories.php
 *
 * @package default
 */


$page_title = 'All Categories';
require_once '../includes/load.php';
// Checkin What level user has permission to view this page
page_require_level(ROLE_ADMIN);

$all_categories = find_all('categories')
?>

<!--     *************************     -->

<?php
if (!verify_csrf()) { $session->msg('d', 'Invalid or missing security token.'); redirect($_SERVER['HTTP_REFERER'] ?? 'index.php', false); }
  if (isset($_POST['add_cat'])) {
$req_field = array('category-name');
	validate_fields($req_field);
	$cat_name = remove_junk($db->escape($_POST['category-name']));
	if (empty($errors)) {
		$sql  = "INSERT INTO categories (name,org_id)";
		$sql .= " VALUES ('{$cat_name}','" . current_org_id() . "')";
		if ($db->query($sql)) {
			$session->msg("s", "Successfully Added Category");
			redirect('../products/categories.php', false);
		} else {
			$session->msg("d", "Sorry Failed to insert.");
			redirect('../products/categories.php', false);
		}
	} else {
		$session->msg("d", $errors);
		redirect('../products/categories.php', false);
	}
}
?>

<!--     *************************     -->


<?php include_once '../layouts/header.php'; ?>
  <div class="row">
     <div class="col-md-12">
       <?php echo display_msg($msg); ?>
     </div>
  </div>
   <div class="row">
    <div class="col-md-5">
      <div class="card">
        <div class="card-header">
          <strong>
            <?php echo bi('grid-3x3-gap'); ?>
<!--     *************************     -->
            <span>Add New category</span>
<!--     *************************     -->
         </strong>
        </div>
        <div class="card-body p-0">
          <form method="post" action="../products/categories.php">
              <?php echo csrf_field(); ?>
            <div class="form-group">
<!--     *************************     -->
                <input type="text" class="form-control" name="category-name" placeholder="Category Name">
            </div>

         <div class="float-end">
            <button type="submit" name="add_cat" class="btn btn-primary">Add Category</button>
        </div>

<!--     *************************     -->
        </form>
        </div>
      </div>
    </div>
    <div class="col-md-7">
    <div class="card">
      <div class="card-header">
        <strong>
          <?php echo bi('grid-3x3-gap'); ?>
<!--     *************************     -->
          <span>All Categories</span>
<!--     *************************     -->
       </strong>
      </div>
        <div class="card-body p-0">
          <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th class="text-center col-w-50">#</th>
<!--     *************************     -->
                    <th>Categories</th>
<!--     *************************     -->
                    <th class="text-center col-w-100">Actions</th>
                </tr>
            </thead>
            <tbody>
<!--     *************************     -->
              <?php foreach ($all_categories as $cat):?>
                <tr>
                    <td class="text-center"><?php echo count_id();?></td>
                    <td><?php echo ucfirst($cat['name']); ?></td>
                    <td class="text-center">
                      <div class="btn-group">
                        <a href="../products/edit_category.php?id=<?php echo (int)$cat['id'];?>"  class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
                          <?php echo bi('pencil'); ?>
                        </a>
                        <a href="../products/delete_category.php?id=<?php echo (int)$cat['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Remove">
                          <?php echo bi('trash'); ?>
                        </a>
                      </div>
                    </td>

                </tr>
              <?php endforeach; ?>
<!--     *************************     -->
            </tbody>
          </table>
       </div>
    </div>
    </div>
   </div>
  </div>
  <?php include_once '../layouts/footer.php'; ?>
