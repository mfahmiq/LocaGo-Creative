<?php
/**
 * view_product.php
 *
 * @package default
 */


$page_title = 'All Product';
require_once '../includes/load.php';
// Checkin What level user has permission to view this page
page_require_level(ROLE_SUPERVISOR);

if ( isset( $_GET['id'] ) ) {
	$product = find_by_id('products', (int)$_GET['id']);
	$all_categories = find_all('categories');
	$all_photo = find_all('media');
	if ( ! $product ) {
		$session->msg("d", "Missing product id.");
		redirect('../products/products.php');
	}
} else {
	$session->msg("d", "Missing product id.");
	redirect('../products/products.php');
}


?>

<?php include_once '../layouts/header.php'; ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
</div>
</div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">

        <div class="card-header d-flex justify-content-between align-items-center">
         <strong>
          <?php echo bi('grid-3x3-gap'); ?>
          <span>Product Detail</span></strong>
		</div>

        <div class="card-body p-0">

  <div class="row">
    <div class="col-md-1">
    </div>
    <div class="col-md-6">
<h4><?php echo first_character($product['name']);?></h4>

<div><label>Description:</label></div>
<div><?php echo h($product['description']);?></div>

    </div>



    <div class="col-md-1">
    </div>
    <div class="col-md-4">
<?php
foreach ($all_photo as $photo) {
	if ( $product['media_id'] == $photo['id'] ) {
?>
	<img class="img-thumbnail" src="../uploads/products/<?php echo h($photo['file_name']); ?>" alt="">
<?php
	}
}
?>
    </div>
</div>



  <div class="row">
    <div class="col-md-1">
	</div>
    <div class="col-md-10">
<div class="text-center"><label></label></div>
    </div>
</div>



  <div class="row">
    <div class="col-md-1">
	</div>
    <div class="col-md-10">

        <div>

          <table class="table table-bordered">
            <thead>
              <tr>
<!--     *************************     -->
                <th class="text-center col-w-10p"> Category </th>
                <th class="text-center col-w-10p"> Location </th>
                <th class="text-center col-w-10p"> SKU </th>
                <th class="text-center col-w-10p"> Stock </th>
                <th class="text-center col-w-15p"> Cost Price </th>
                <th class="text-center col-w-15p"> Sale Price </th>
                <th class="text-center col-w-15p"> Product Added </th>
                <th class="text-center col-w-50"> Actions </th>
              </tr>
<!--     *************************     -->
            </thead>
            <tbody>
<!--     *************************     -->

              <tr>
<?php
foreach ($all_categories as $category ) {
	if ( $product['category_id'] == $category['id'] ) {
		break;
	}
}
?>
 			    <td class="text-center"> <?php echo h($category['name']); ?></td>
                <td class="text-center"> <?php echo h($product['location']); ?></td>
                <td class="text-center"> <?php echo h($product['sku']); ?></td>
                <td class="text-center"> <?php echo h($product['quantity']); ?></td>
                <td class="text-center"> <?php echo formatcurrency( $product['buy_price'], $CURRENCY_CODE); ?></td>
                <td class="text-center"> <?php echo formatcurrency( $product['sale_price'], $CURRENCY_CODE); ?></td>
                <td class="text-center"> <?php echo read_date($product['date']); ?></td>
<!--     *************************     -->
                <td class="text-center">
                  <div class="btn-group">
					<a href="../products/add_stock.php?id=<?php echo (int)$product['id'];?>"  class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Add">
					  <?php echo bi('plus-circle'); ?>
					</a>
                    <a href="../products/edit_product.php?id=<?php echo (int)$product['id'];?>" class="btn btn-info btn-sm"  title="Edit" data-bs-toggle="tooltip">
                      <?php echo bi('pencil'); ?>
                    </a>
                    <a href="../products/delete_product.php?id=<?php echo (int)$product['id'];?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-danger btn-sm"  title="Delete" data-bs-toggle="tooltip">
                      <?php echo bi('trash'); ?>
                    </a>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>


    </div>
  </div>

<?php
// print "<pre>";
// print_r($product);
// print "</pre>\n";
?>

    </div>
  </div>
    </div>
  </div>

  <?php include_once '../layouts/footer.php'; ?>
