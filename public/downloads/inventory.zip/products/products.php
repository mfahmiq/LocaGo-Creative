<?php
/**
 * products.php
 *
 * @package default
 */


$page_title = 'All Product';
require_once '../includes/load.php';
// Checkin What level user has permission to view this page
page_require_level(ROLE_SUPERVISOR);

$all_categories = find_all('categories');
$selected_category = 0;
if (!verify_csrf()) { $session->msg('d', 'Invalid or missing security token.'); redirect($_SERVER['HTTP_REFERER'] ?? 'index.php', false); }
  if ( isset( $_POST['product-category'] ) ) {
$selected_category = (int)$_POST['product-category']; }
if ( ( isset($_POST['update_category'] ) ) && ( $selected_category > 0 ) ) {
	$products = find_products_by_category($selected_category);
} else {
	$products = join_product_table();
}
?>
<?php include_once '../layouts/header.php'; ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
    <form method="post" action="">
              <?php echo csrf_field(); ?>
        <div class="form-group">
          <div class="input-group">
            <span class="input-group-text">
            <button type="submit" name="update_category" class="btn btn-primary">Update Category</button>
            </span>
                    <select class="form-control" name="product-category">
                      <option value="0">Select Product Category</option>
		    <?php
foreach ($all_categories as $cat) {
	echo "<option value=\"";
	echo (int)$cat['id'];
	if ( (int)$cat['id'] == $selected_category ) { echo "\" selected>"; } else { echo "\">"; }
	echo h($cat['name']);
}
?>
                    </select>

         </div>
        </div>
    </form>
  </div>

  <div class="col-md-6">
</div>


</div>

  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <strong>
            <?php echo bi('grid-3x3-gap'); ?>
            <span>
 <?php
if ( ( isset($_POST['update_category'] ) ) && ( $selected_category > 0 ) ) {
	echo "Products by Category";
} else {
	echo "All Products";
}
?>
            </span>
          </strong>
          <a href="../products/add_product.php" class="btn btn-primary">Add Product</a>
        </div>
        <div class="card-body p-0">


          <table class="table table-bordered table-striped">
            <thead>
              <tr>
<!--     *************************     -->
                <th> Product </th>
                <th> Photo</th>
                <th class="text-center col-w-10p"> SKU</th>
                <th class="text-center col-w-10p"> Category </th>
                <th class="text-center col-w-10p"> Location </th>
                <th class="text-center col-w-10p"> Stock </th>
                <th class="text-center col-w-10p"> Cost Price </th>
                <th class="text-center col-w-10p"> Sale Price </th>
                <th class="text-center col-w-10p"> Product Added </th>
                <th class="text-center col-w-100"> Actions </th>
              </tr>
<!--     *************************     -->
            </thead>
            <tbody>
<!--     *************************     -->
              <?php foreach ($products as $product):?>
              <tr>

                <td><a href="../products/view_product.php?id=<?php echo (int)$product['id'];?>"><?php echo h($product['name']); ?></a></td>

                <td>
                  <?php if (empty($product['media_id'])): ?>
                    <img class="img-avatar img-circle" src="../uploads/products/no_image.jpg" alt="">
                  <?php else: ?>
                  <img class="img-avatar img-circle" src="../uploads/products/<?php echo h($product['image']); ?>" alt="">
                <?php endif; ?>
                </td>
                <td class="text-center"><?php echo h($product['sku']);?></td>
                <td class="text-center"> <?php echo h($product['category']); ?></td>
                <td class="text-center"> <?php echo h($product['location']); ?></td>
                <td class="text-center"> <?php echo h($product['quantity']); ?></td>
                <td class="text-center"> <?php echo formatcurrency( $product['buy_price'], $CURRENCY_CODE); ?></td>
                <td class="text-center"> <?php echo formatcurrency( $product['sale_price'], $CURRENCY_CODE); ?></td>
                <td class="text-center"> <?php echo read_date($product['date']); ?></td>
<!--     *************************     -->
                <td class="text-center">
                  <div class="btn-group">
					<a href="../products/add_stock.php?id=<?php echo (int)$product['id'];?>"  class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Add">
					  <?php echo bi('plus-circle'); ?>
					</a>
                    <a href="../products/edit_product.php?id=<?php echo (int)$product['id'];?>" class="btn btn-info btn-sm"  title="Edit" data-bs-toggle="tooltip">
                      <?php echo bi('pencil'); ?>
                    </a>
                    <a href="../products/delete_product.php?id=<?php echo (int)$product['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-danger btn-sm"  title="Delete" data-bs-toggle="tooltip">
                      <?php echo bi('trash'); ?>
                    </a>
                  </div>
                </td>
<!--     *************************     -->
              </tr>
             <?php endforeach; ?>
<!--     *************************     -->
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <?php include_once '../layouts/footer.php'; ?>
