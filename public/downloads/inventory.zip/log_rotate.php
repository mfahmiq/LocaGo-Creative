<?php
/**
 * log_rotate.php
 *
 * Cron-callable script to prune old log entries and stale failed-login
 * rows. Keeps recent data and deletes anything older than the configured
 * retention periods.
 *
 * Cron example (weekly on Sunday at 3 AM):
 *   0 3 * * 0 /usr/bin/php /var/www/inventory/log_rotate.php >> /var/log/inventory_logrotate.log 2>&1
 *
 * Retention defaults (override via .env):
 *   LOG_RETAIN_DAYS=90         — page-view log table
 *   AUDIT_LOG_RETAIN_DAYS=365  — audit_log table (kept longer for compliance;
 *                                 only used if the audit_log table exists)
 *
 * Note on porting from cc-inventory: this script uses inventory's
 * MySqli_DB::prepare_query() wrapper instead of raw mysqli prepare/bind/execute,
 * targets failed_logins (inventory) instead of login_attempts (cc-inventory),
 * and guards the audit_log block behind a SHOW TABLES check because inventory
 * does not yet have that table.
 */

require_once __DIR__ . '/includes/load.php';

// Only allow CLI or admin browser access
if (PHP_SAPI !== 'cli') {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(403);
        exit('Access denied.');
    }
    $runner = find_by_id('users', (int) $_SESSION['user_id']);
    if (!$runner || (int) $runner['user_level'] > ROLE_ADMIN) {
        http_response_code(403);
        exit('Admin access required.');
    }
}

header('Content-Type: text/plain');

$log_days   = (int) (getenv('LOG_RETAIN_DAYS')        ?: 90);
$audit_days = (int) (getenv('AUDIT_LOG_RETAIN_DAYS')  ?: 365);

$db = new MySqli_DB();

$timestamp = date('Y-m-d H:i:s');
echo "=== Log Rotation — $timestamp ===\n\n";

// ---------------------------------------------------------------------------
// 1. Prune page-view log (older than $log_days days)
// ---------------------------------------------------------------------------
$stmt = $db->prepare_query(
    "DELETE FROM `log` WHERE `date` < DATE_SUB(NOW(), INTERVAL ? DAY)",
    'i', $log_days
);
$log_deleted = $stmt->affected_rows;
echo "log: deleted $log_deleted rows older than $log_days days\n";

// ---------------------------------------------------------------------------
// 2. Prune audit_log if the table exists. Inventory may not have it yet;
//    leave the block in place so it lights up automatically when the
//    table is added in a future phase.
// ---------------------------------------------------------------------------
$has_audit = $db->query("SHOW TABLES LIKE 'audit_log'");
if ($has_audit && $db->num_rows($has_audit) > 0) {
    $stmt = $db->prepare_query(
        "DELETE FROM `audit_log` WHERE `created_at` < DATE_SUB(NOW(), INTERVAL ? DAY)",
        'i', $audit_days
    );
    $audit_deleted = $stmt->affected_rows;
    echo "audit_log: deleted $audit_deleted rows older than $audit_days days\n";
} else {
    echo "audit_log: skipped (table absent)\n";
}

// ---------------------------------------------------------------------------
// 3. Prune failed_logins (older than 7 days). Same role as cc-inventory's
//    login_attempts; inventory's failed_logins table (migration 002) is the
//    equivalent.
// ---------------------------------------------------------------------------
$login_retain = 7;
$stmt = $db->prepare_query(
    "DELETE FROM `failed_logins` WHERE `attempted_at` < DATE_SUB(NOW(), INTERVAL ? DAY)",
    'i', $login_retain
);
$login_deleted = $stmt->affected_rows;
echo "failed_logins: deleted $login_deleted rows older than $login_retain days\n";

echo "\nDone.\n";
