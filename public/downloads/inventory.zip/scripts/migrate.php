#!/usr/bin/env php
<?php
/**
 * scripts/migrate.php
 *
 * Applies one or more .up.sql migration files to the live database.
 *
 * Usage:
 *   php scripts/migrate.php             # apply all pending (022–024)
 *   php scripts/migrate.php 022 023 024 # apply specific migrations
 *   php scripts/migrate.php --status    # show applied / pending status
 *
 * Reads DB_HOST, DB_USER, DB_PASS, DB_NAME from .env at project root.
 */

define('PROJECT_ROOT', dirname(__DIR__));
chdir(PROJECT_ROOT);

function colour(string $code, string $text): string {
    return "\033[{$code}m{$text}\033[0m";
}
function printOk(string $s): void   { echo colour('32', '  [OK]   ') . $s . PHP_EOL; }
function printWarn(string $s): void { echo colour('33', '  [WARN] ') . $s . PHP_EOL; }
function printErr(string $s): void  { echo colour('31', '  [ERR]  ') . $s . PHP_EOL; }
function printInfo(string $s): void { echo colour('36', '  [info] ') . $s . PHP_EOL; }

// Load .env
$envFile = PROJECT_ROOT . '/.env';
if (!file_exists($envFile)) {
    printErr('.env not found. Run install.sh first.');
    exit(1);
}
$env = parse_ini_file($envFile);
if ($env === false) {
    printErr('Failed to parse .env');
    exit(1);
}

$dbHost = $env['DB_HOST'] ?? 'localhost';
$dbUser = $env['DB_USER'] ?? 'webuser';
$dbPass = $env['DB_PASS'] ?? '';
$dbName = $env['DB_NAME'] ?? 'inventory';

echo PHP_EOL;
echo "=========================================" . PHP_EOL;
echo " Inventory Migration Runner" . PHP_EOL;
echo "=========================================" . PHP_EOL;
echo PHP_EOL;
printInfo("Connecting as {$dbUser}@{$dbHost}/{$dbName}…");

try {
    $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    printErr('Cannot connect: ' . $e->getMessage());
    exit(1);
}
printOk("Connected.");

// Parse args
$args       = array_slice($argv, 1);
$showStatus = in_array('--status', $args, true);
$targets    = array_filter($args, fn($a) => preg_match('/^\d{3}$/', $a));

// Discover migration files
$migDir = PROJECT_ROOT . '/migrations';
$files  = glob($migDir . '/*.up.sql');
sort($files);

$allMigrations = [];
foreach ($files as $f) {
    $base = basename($f, '.up.sql');
    if (preg_match('/^(\d{3})/', $base, $m)) {
        $allMigrations[$m[1]] = ['file' => $f, 'name' => $base];
    }
}

// Table-presence map for status detection
$tableMap = [
    '022' => 'password_resets',
    '023' => 'audit_log',
    '024' => 'permissions',
];

if ($showStatus) {
    $rows   = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $tables = array_flip($rows);
    echo PHP_EOL;
    foreach ($allMigrations as $num => $m) {
        $indicator = isset($tableMap[$num])
            ? (isset($tables[$tableMap[$num]]) ? colour('32', '[applied]') : colour('33', '[pending]'))
            : colour('36', '[n/a]    ');
        printf("  %s %s  %s\n", $num, $indicator, $m['name']);
    }
    echo PHP_EOL;
    exit(0);
}

// Determine which migrations to run
$toRun = [];
if (!empty($targets)) {
    foreach ($targets as $num) {
        if (!isset($allMigrations[$num])) { printWarn("Migration {$num} not found."); continue; }
        $toRun[$num] = $allMigrations[$num];
    }
} else {
    // Auto: apply pending 022–024 only
    $rows   = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $tables = array_flip($rows);
    foreach ($tableMap as $num => $table) {
        if (!isset($tables[$table]) && isset($allMigrations[$num])) {
            $toRun[$num] = $allMigrations[$num];
        }
    }
}

if (empty($toRun)) {
    printOk("Nothing to apply — all target tables already exist.");
    echo PHP_EOL;
    exit(0);
}

echo PHP_EOL;
printInfo("Migrations to apply: " . implode(', ', array_keys($toRun)));
echo PHP_EOL;

$applied = 0;
$failed  = 0;

foreach ($toRun as $num => $m) {
    $sql = file_get_contents($m['file']);
    if ($sql === false) { printErr("Cannot read {$m['file']}"); $failed++; continue; }

    echo "  Applying {$num} — {$m['name']}…" . PHP_EOL;

    // Split into individual statements; skip comment-only lines
    $statements = array_filter(
        array_map('trim', explode(';', $sql)),
        fn($s) => $s !== '' && !preg_match('/^\s*--/', $s)
    );

    $ok = true;
    foreach ($statements as $stmt) {
        if (trim($stmt) === '') continue;
        try {
            $pdo->query($stmt);
        } catch (PDOException $e) {
            if (str_contains($e->getMessage(), 'already exists')) {
                printWarn("Already exists — skipping: " . substr($e->getMessage(), 0, 80));
            } else {
                printErr("SQL error: " . $e->getMessage());
                $ok = false;
                break;
            }
        }
    }

    if ($ok) {
        printOk("{$num} applied successfully.");
        $applied++;
    } else {
        printErr("{$num} FAILED. User '{$dbUser}' may lack CREATE TABLE rights.");
        printErr("Run manually:  sudo mysql {$dbName} < migrations/{$num}_*.up.sql");
        $failed++;
    }
    echo PHP_EOL;
}

echo "=========================================" . PHP_EOL;
if ($failed === 0) {
    echo colour('32', " Done: {$applied} migration(s) applied.") . PHP_EOL;
} else {
    echo colour('33', " Applied: {$applied}  Failed: {$failed}") . PHP_EOL;
    echo PHP_EOL;
    echo "  Manual fallback (run as root):" . PHP_EOL;
    foreach (array_keys($toRun) as $num) {
        echo "    sudo mysql {$dbName} < migrations/{$num}_*.up.sql" . PHP_EOL;
    }
}
echo "=========================================" . PHP_EOL;
echo PHP_EOL;

exit($failed > 0 ? 1 : 0);
