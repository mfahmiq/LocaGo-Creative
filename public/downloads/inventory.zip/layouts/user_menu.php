<?php
/**
 * layouts/user_menu.php  —  Standard user (level 3)
 */
?>
<ul>
  <li>
    <a href="../users/home.php">
      <?php echo bi('house'); ?>
      <span>Dashboard</span>
    </a>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('cart3'); ?>
      <span>Products</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../products/products.php">Products</a></li>
      <li><a href="../products/product_search.php">Product Search</a></li>
    </ul>
  </li>

  <li>
    <a href="../customers/customers.php">
      <?php echo bi('people'); ?>
      <span>Customers</span>
    </a>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('receipt'); ?>
      <span>Sales</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../sales/add_order_by_customer.php">Add Order</a></li>
      <li><a href="../sales/orders.php">Orders</a></li>
      <li><a href="../sales/sales.php">Sales</a></li>
    </ul>
  </li>
</ul>
