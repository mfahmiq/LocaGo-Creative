<?php
/**
 * layouts/admin_menu.php
 */
?>
<ul>
  <li>
    <a href="../users/admin.php">
      <?php echo bi('house'); ?>
      <span>Dashboard</span>
    </a>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('cart3'); ?>
      <span>Products</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../products/categories.php">Categories</a></li>
      <li><a href="../products/products.php">Manage Products</a></li>
      <li><a href="../products/product_search.php">Product Search</a></li>
      <li><a href="../products/stock.php">Manage Stock</a></li>
      <li><a href="../products/media.php">Media</a></li>
    </ul>
  </li>

  <li>
    <a href="../customers/customers.php">
      <?php echo bi('people'); ?>
      <span>Customers</span>
    </a>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('receipt'); ?>
      <span>Sales</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../sales/add_order_by_customer.php">Add Order</a></li>
      <li><a href="../sales/orders.php">Manage Orders</a></li>
      <li><a href="../sales/sales.php">Manage Sales</a></li>
      <li><a href="../sales/add_sale_by_sku.php">Add Sale by SKU</a></li>
    </ul>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('bar-chart-line'); ?>
      <span>Reports</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../reports/stock_report.php">Stock Report</a></li>
      <li><a href="../reports/sales_report.php">Sales by Dates</a></li>
      <li><a href="../reports/monthly_sales.php">Monthly Sales</a></li>
      <li><a href="../reports/daily_sales.php">Daily Sales</a></li>
    </ul>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('gear'); ?>
      <span>User Management</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../users/group.php">Manage Groups</a></li>
      <li><a href="../users/users.php">Manage Users</a></li>
      <li><a href="../users/permissions.php">Permissions</a></li>
      <li><a href="../users/log.php">System Log</a></li>
      <li><a href="../users/audit.php">Audit Log</a></li>
      <li><a href="../users/settings.php">Settings</a></li>
      <li><a href="../users/trash.php">Trash</a></li>
      <li><a href="../orgs/orgs.php">Organizations</a></li>
    </ul>
  </li>
</ul>
