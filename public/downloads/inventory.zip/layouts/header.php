<?php
/**
 * layouts/header.php
 */

header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; frame-ancestors 'none'");
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');

$user     = current_user();
$app_name = defined('APP_NAME')      ? APP_NAME      : 'Inventory';
$base     = defined('APP_BASE_PATH') ? APP_BASE_PATH : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php if ($session->isUserLoggedIn()): ?>
  <meta name="csrf-token" content="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
  <?php endif; ?>
  <title><?php
    if (!empty($page_title)) echo remove_junk($page_title) . ' — ' . $app_name;
    elseif (!empty($user))   echo ucfirst(remove_junk($user['name']));
    else                     echo $app_name;
  ?></title>
  <link rel="stylesheet" href="<?php echo $base; ?>/libs/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $base; ?>/libs/css/bootstrap-datepicker3.min.css">
  <link rel="stylesheet" href="<?php echo $base; ?>/libs/css/icons.css">
  <link rel="stylesheet" href="<?php echo $base; ?>/libs/css/main.css">
</head>
<body>
<a href="#main" class="skip-link">Skip to main content</a>

<?php if ($session->isUserLoggedIn()): ?>
<button id="sidebar-toggle" onclick="toggleSidebar()"
        aria-label="Toggle navigation" aria-expanded="false" aria-controls="sidebar">&#9776;</button>

<header id="header">
  <a href="<?php echo $base; ?>/users/admin.php" class="cc-logo">
    <div class="logo-mark"><span class="cc-inner">CC</span></div>
    <span class="brand-name">Core<span class="highlight">Inventory</span></span>
  </a>

  <div class="header-content">
    <div class="header-date float-start">
      <strong><?php echo date('F j, Y, g:i a'); ?></strong>
    </div>
    <div class="float-end clearfix">
      <ul class="info-menu list-inline list-unstyled">

        <?php
        $_user_orgs = [];
        if (isset($_SESSION['user_id'])) {
            $_user_orgs = find_org_memberships((int)$_SESSION['user_id']);
        }
        if (count($_user_orgs) >= 2):
            $_current_org_name = 'Organization';
            foreach ($_user_orgs as $_o) {
                if ((int)$_o['org_id'] === (int)($_SESSION['current_org_id'] ?? 0)) {
                    $_current_org_name = h($_o['name']);
                    break;
                }
            }
        ?>
        <li class="dropdown">
          <a href="#" data-bs-toggle="dropdown" class="toggle">
            <?php echo bi('list-ul'); ?>
            <?php echo $_current_org_name; ?> <i class="caret"></i>
          </a>
          <ul class="dropdown-menu">
            <?php foreach ($_user_orgs as $_o): ?>
            <li>
              <form method="POST" action="<?php echo $base; ?>/users/switch_org.php">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="org_id" value="<?php echo (int)$_o['org_id']; ?>">
                <button type="submit" class="org-switcher-btn">
                  <?php echo h($_o['name']); ?>
                  <?php if ((int)$_o['org_id'] === (int)($_SESSION['current_org_id'] ?? 0)): ?>
                  <?php echo bi('check-lg', 'float-end'); ?>
                  <?php endif; ?>
                </button>
              </form>
            </li>
            <?php endforeach; ?>
          </ul>
        </li>
        <?php endif; ?>

        <li class="profile">
          <a href="#" data-bs-toggle="dropdown" class="toggle" aria-expanded="false">
            <img src="<?php echo $base; ?>/uploads/users/<?php echo h($user['image']); ?>"
                 alt="user" class="img-circle img-inline">
            <span><?php echo remove_junk(ucfirst($user['name'])); ?> <i class="caret"></i></span>
          </a>
          <ul class="dropdown-menu">
            <li>
              <a href="<?php echo $base; ?>/users/profile.php?id=<?php echo (int)$user['id']; ?>">
                <?php echo bi('person'); ?> Profile
              </a>
            </li>
            <li>
              <a href="<?php echo $base; ?>/users/edit_account.php">
                <?php echo bi('gear'); ?> Settings
              </a>
            </li>
            <li class="last">
              <a href="<?php echo $base; ?>/users/logout.php">
                <?php echo bi('power'); ?> Logout
              </a>
            </li>
          </ul>
        </li>

      </ul>
    </div>
  </div>
</header>

<div id="sidebar" class="sidebar">
  <?php $ulvl = (int)($user['user_level'] ?? 0); ?>
  <?php if ($ulvl === 1): ?>
    <?php include_once 'admin_menu.php'; ?>
  <?php elseif ($ulvl === 2): ?>
    <?php include_once 'special_menu.php'; ?>
  <?php elseif ($ulvl === 3): ?>
    <?php include_once 'user_menu.php'; ?>
  <?php else: ?>
    <?php redirect($base . '/users/logout.php', false); ?>
  <?php endif; ?>
</div>
<?php endif; ?>

<div id="main" class="page">
  <div class="container-fluid">
