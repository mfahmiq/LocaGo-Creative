<?php
/**
 * layouts/footer.php
 */
$base = defined('APP_BASE_PATH') ? APP_BASE_PATH : '';
?>
     </div>
    </div>
    <script src="<?php echo $base; ?>/libs/js/jquery.min.js"></script>
    <script src="<?php echo $base; ?>/libs/js/bootstrap.min.js"></script>
    <script src="<?php echo $base; ?>/libs/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo $base; ?>/libs/js/functions.js"></script>
  </body>
</html>
<?php if (isset($db)) { $db->db_disconnect(); } ?>
