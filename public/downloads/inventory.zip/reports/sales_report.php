<?php
/**
 * sales_report.php
 *
 * @package default
 */


$page_title = 'Sale Report';
require_once '../includes/load.php';
// Checkin What level user has permission to view this page
page_require_level(ROLE_USER);
?>
<?php include_once '../layouts/header.php'; ?>
<div class="row">
  <div class="col-md-6">
    <?php echo display_msg($msg); ?>
  </div>
</div>

<div class="row">
  <div class="col-md-6">
    <div class="card">
      <div class="bg-light rounded-3 p-4 text-center">
      <h3>Sales Report</h3>
          <form class="clearfix" method="post" action="sale_report_process.php">
              <?php echo csrf_field(); ?>
            <div class="form-group">
              <label class="form-label">Date Range</label>
                <div class="input-group">
                  <input type="text" class="datepicker form-control" name="start-date" placeholder="From">
                  <span class="input-group-text"><?php echo bi('chevron-right'); ?></span>
                  <input type="text" class="datepicker form-control" name="end-date" placeholder="To">
                </div>
            </div>
            <div class="form-group">
                 <button type="submit" name="submit" class="btn btn-primary">Generate Report</button>
            </div>
          </form>
      </div>

    </div>
  </div>

</div>
<?php include_once '../layouts/footer.php'; ?>
