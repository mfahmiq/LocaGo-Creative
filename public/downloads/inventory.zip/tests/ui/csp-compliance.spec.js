// @ts-check
const { test, expect } = require('@playwright/test');

test.describe('CSP compliance and asset delivery', () => {
  test.use({ storageState: 'tests/ui/.auth/admin.json' });

  test('no inline style attributes on admin dashboard content', async ({ page }) => {
    await page.goto('/users/admin.php');
    const inlineStyles = await page.locator('#main [style]').count();
    expect(inlineStyles).toBe(0);
  });

  test('no glyphicon classes anywhere in DOM', async ({ page }) => {
    await page.goto('/users/admin.php');
    const glyphicons = await page.locator('[class*="glyphicon"]').count();
    expect(glyphicons).toBe(0);
  });

  test('bi.svg responds 200', async ({ page }) => {
    const res = await page.request.get('/libs/icons/bi.svg');
    expect(res.status()).toBe(200);
  });

  test('bootstrap.min.css responds 200', async ({ page }) => {
    const res = await page.request.get('/libs/css/bootstrap.min.css');
    expect(res.status()).toBe(200);
  });

  test('Exo 2 font responds 200', async ({ page }) => {
    const res = await page.request.get('/libs/fonts/exo-2-latin-700-normal.woff2');
    expect(res.status()).toBe(200);
  });

  test('Bootstrap Icon SVGs present in admin dashboard content', async ({ page }) => {
    await page.goto('/users/admin.php');
    const count = await page.locator('#main svg.bi').count();
    expect(count).toBeGreaterThan(0);
  });
});
