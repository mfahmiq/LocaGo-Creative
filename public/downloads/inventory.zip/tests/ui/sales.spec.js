const { test, expect } = require('@playwright/test');

const HARNESS_CAT      = 'HARNESS_SalesCat';
const HARNESS_PRODUCT  = 'HARNESS_SalesProduct_' + Date.now();
const HARNESS_CUSTOMER = 'HARNESS_SalesCust_' + Date.now();
const INITIAL_QTY      = 50;

let orderId;

async function ensureCategoryExists(page, name) {
  await page.goto('/products/categories.php');
  const exists = page.locator(`tbody td:text-is("${name}")`);
  if ((await exists.count()) === 0) {
    await page.fill('input[name="category-name"]', name);
    await page.click('button[name="add_cat"]');
    await page.waitForURL(/categories\.php/);
  }
}

test.describe('Sales golden path', () => {
  test.beforeAll(async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();
    page.on('dialog', d => d.accept());

    await ensureCategoryExists(page, HARNESS_CAT);

    // Reap any leftover HARNESS_SalesProduct_* rows from prior runs
    await page.goto('/products/products.php');
    for (let i = 0; i < 10; i++) {
      const leftover = page.locator('tbody tr', { hasText: /HARNESS_SalesProduct_/ });
      if ((await leftover.count()) === 0) break;
      await leftover.first().locator('a.btn-danger').click();
      await page.waitForLoadState('networkidle');
    }

    await page.goto('/products/add_product.php');
    await page.fill('input[name="product-title"]', HARNESS_PRODUCT);
    await page.fill('input[name="product-desc"]', 'Playwright sales test product');
    await page.fill('input[name="product-sku"]', 'PWSALE-' + Date.now());
    await page.fill('input[name="product-location"]', 'PW-SALES');
    await page.selectOption('select[name="product-category"]', { label: HARNESS_CAT });
    await page.fill('input[name="product-quantity"]', String(INITIAL_QTY));
    await page.fill('input[name="cost-price"]', '10');
    await page.fill('input[name="sale-price"]', '30');
    await page.click('button[name="add_product"]');
    await page.waitForURL(/\/products\/products\.php/);

    await page.goto('/sales/add_order.php');
    await page.fill('input[name="customer-name"]', HARNESS_CUSTOMER);
    await page.selectOption('select[name="paymethod"]', 'Cash');
    await page.fill('input[name="notes"]', 'Playwright test order');
    await page.click('button[name="add_order"]');
    await page.waitForURL(/add_sale_by_search\.php\?id=(\d+)/);
    const url = page.url();
    orderId = url.match(/id=(\d+)/)[1];

    await ctx.close();
  });

  test.afterAll(async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();
    page.on('dialog', d => d.accept());

    await page.goto('/products/products.php');
    const prodRow = page.locator('tbody tr', { hasText: HARNESS_PRODUCT });
    if ((await prodRow.count()) > 0) {
      await prodRow.locator('a.btn-danger').click();
      await page.waitForLoadState('networkidle');
    }

    if (orderId) {
      await page.goto('/sales/orders.php');
      const orderRow = page.locator('tbody tr', { hasText: HARNESS_CUSTOMER });
      if ((await orderRow.count()) > 0) {
        await orderRow.locator('a.btn-danger').click();
        await page.waitForLoadState('networkidle');
      }
    }

    await ctx.close();
  });

  test('add sale to order via product search', async ({ page }) => {
    await page.goto(`/sales/add_sale_by_search.php?id=${orderId}`);
    await page.fill('input[name="search"]', HARNESS_PRODUCT);
    await page.click('form:has(input[name="search"]) button[type="submit"]');
    await page.waitForLoadState('networkidle');

    const productRow = page.locator('tr', { hasText: HARNESS_PRODUCT });
    await expect(productRow).toHaveCount(1);

    await productRow.locator('input[name="quantity"]').fill('2');
    await productRow.locator('button[name="add_sale"]').click();

    await page.waitForURL(/\/sales\/orders\.php/);
    await expect(page).toHaveURL(/orders\.php/);
  });

  test('order with sale appears in orders list', async ({ page }) => {
    await page.goto('/sales/orders.php');
    const orderRow = page.locator('tbody tr', { hasText: HARNESS_CUSTOMER });
    await expect(orderRow).toHaveCount(1);
    await expect(orderRow.locator('td').first()).toContainText(orderId);
  });

  test('sold product stock is reduced', async ({ page }) => {
    await page.goto('/products/products.php');
    const row = page.locator('tbody tr', { hasText: HARNESS_PRODUCT });
    await expect(row).toHaveCount(1);
    const stockText = await row.locator('td').nth(5).innerText();
    expect(parseInt(stockText.trim(), 10)).toBe(INITIAL_QTY - 2);
  });
});

// ─── Zero-stock edge case ────────────────────────────────────────────────────

const HARNESS_ZERO_PRODUCT  = 'HARNESS_ZeroStock_' + Date.now();
const HARNESS_ZERO_CUSTOMER = 'HARNESS_ZeroCust_'  + Date.now();

let zeroOrderId;

test.describe('Sales zero-stock edge case', () => {
  test.beforeAll(async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();
    page.on('dialog', d => d.accept());

    await ensureCategoryExists(page, HARNESS_CAT);

    // Create a product with qty=0
    await page.goto('/products/add_product.php');
    await page.fill('input[name="product-title"]',    HARNESS_ZERO_PRODUCT);
    await page.fill('input[name="product-desc"]',     'Playwright zero-stock test');
    await page.fill('input[name="product-sku"]',      'PWZERO-' + Date.now());
    await page.fill('input[name="product-location"]', 'PW-ZERO');
    await page.selectOption('select[name="product-category"]', { label: HARNESS_CAT });
    await page.fill('input[name="product-quantity"]', '0');
    await page.fill('input[name="cost-price"]',       '5');
    await page.fill('input[name="sale-price"]',       '10');
    await page.click('button[name="add_product"]');
    await page.waitForURL(/\/products\/products\.php/);

    // Create an order to sell against
    await page.goto('/sales/add_order.php');
    await page.fill('input[name="customer-name"]',  HARNESS_ZERO_CUSTOMER);
    await page.selectOption('select[name="paymethod"]', 'Cash');
    await page.fill('input[name="notes"]', 'Playwright zero-stock test order');
    await page.click('button[name="add_order"]');
    await page.waitForURL(/add_sale_by_search\.php\?id=(\d+)/);
    const zeroMatch = page.url().match(/id=(\d+)/);
    zeroOrderId = zeroMatch ? zeroMatch[1] : null;

    await ctx.close();
  });

  test.afterAll(async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();
    page.on('dialog', d => d.accept());

    // Delete zero-stock product
    await page.goto('/products/products.php');
    const prodRow = page.locator('tbody tr', { hasText: HARNESS_ZERO_PRODUCT });
    if ((await prodRow.count()) > 0) {
      await prodRow.locator('a.btn-danger').click();
      await page.waitForLoadState('networkidle');
    }

    // Delete zero-stock order
    if (zeroOrderId) {
      await page.goto('/sales/orders.php');
      const orderRow = page.locator('tbody tr', { hasText: HARNESS_ZERO_CUSTOMER });
      if ((await orderRow.count()) > 0) {
        await orderRow.locator('a.btn-danger').click();
        await page.waitForLoadState('networkidle');
      }
    }

    await ctx.close();
  });

  test('oversell attempt redirects to order view', async ({ page }) => {
    await page.goto(`/sales/add_sale_by_search.php?id=${zeroOrderId}`);

    // Search for the zero-stock product
    await page.fill('input[name="search"]', HARNESS_ZERO_PRODUCT);
    await page.click('form:has(input[name="search"]) button[type="submit"]');
    await page.waitForLoadState('networkidle');

    // Product row should appear in results
    const productRow = page.locator('tr', { hasText: HARNESS_ZERO_PRODUCT });
    await expect(productRow).toHaveCount(1);

    // Attempt to add 1 unit (stock is 0 — server guard fires at add_sale_by_search.php:34)
    await productRow.locator('input[name="quantity"]').fill('1');
    await productRow.locator('button[name="add_sale"]').click();

    // Server redirects to sales_by_order (not orders.php) when qty > stock
    await expect(page).toHaveURL(new RegExp(`sales_by_order\\.php\\?id=${zeroOrderId}`));
  });
});
