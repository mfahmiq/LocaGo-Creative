// @ts-check
const { test, expect } = require('@playwright/test');

test.describe('Navigation shell — admin', () => {
  test.use({ storageState: 'tests/ui/.auth/admin.json' });

  test('CC logo is present', async ({ page }) => {
    await page.goto('/users/admin.php');
    await expect(page.locator('.cc-logo')).toBeVisible();
  });

  test('brand name shows CoreInventory', async ({ page }) => {
    await page.goto('/users/admin.php');
    await expect(page.locator('.cc-logo .brand-name')).toContainText('Core');
    await expect(page.locator('.cc-logo .brand-name .highlight')).toContainText('Inventory');
  });

  test('sidebar has all six top-level entries', async ({ page }) => {
    await page.goto('/users/admin.php');
    const sb = page.locator('.sidebar');
    await expect(sb.locator('a', { hasText: 'Dashboard' })).toBeVisible();
    await expect(sb.locator('.submenu-toggle', { hasText: 'Products' })).toBeVisible();
    await expect(sb.locator('a', { hasText: 'Customers' })).toBeVisible();
    await expect(sb.locator('.submenu-toggle', { hasText: 'Sales' })).toBeVisible();
    await expect(sb.locator('.submenu-toggle', { hasText: 'Reports' })).toBeVisible();
    await expect(sb.locator('.submenu-toggle', { hasText: 'User Management' })).toBeVisible();
  });

  test('Organizations link visible under User Management', async ({ page }) => {
    await page.goto('/users/admin.php');
    await page.locator('.sidebar .submenu-toggle', { hasText: 'User Management' }).click();
    await expect(page.locator('.sidebar a[href*="orgs.php"]')).toBeVisible();
  });

  test('no glyphicon classes in sidebar', async ({ page }) => {
    await page.goto('/users/admin.php');
    const count = await page.locator('.sidebar [class*="glyphicon"]').count();
    expect(count).toBe(0);
  });

  test('Bootstrap Icon SVG elements present in sidebar', async ({ page }) => {
    await page.goto('/users/admin.php');
    const count = await page.locator('.sidebar svg.bi').count();
    expect(count).toBeGreaterThan(0);
  });
});

test.describe('Navigation shell — level-3 user', () => {
  test.use({ storageState: 'tests/ui/.auth/user.json' });

  test('Products submenu has exactly 2 items', async ({ page }) => {
    await page.goto('/users/home.php');
    await page.locator('.sidebar .submenu-toggle', { hasText: 'Products' }).click();
    const productsLi = page.locator('.sidebar li', {
      has: page.locator('.submenu-toggle', { hasText: 'Products' }),
    });
    await expect(productsLi.locator('ul.submenu li')).toHaveCount(2);
  });

  test('Manage Stock is not in sidebar', async ({ page }) => {
    await page.goto('/users/home.php');
    await expect(page.locator('.sidebar a', { hasText: 'Manage Stock' })).toHaveCount(0);
  });

  test('Media is not in sidebar', async ({ page }) => {
    await page.goto('/users/home.php');
    await expect(page.locator('.sidebar a', { hasText: 'Media' })).toHaveCount(0);
  });

  test('Sales submenu has exactly 3 items', async ({ page }) => {
    await page.goto('/users/home.php');
    await page.locator('.sidebar .submenu-toggle', { hasText: 'Sales' }).click();
    const salesLi = page.locator('.sidebar li', {
      has: page.locator('.submenu-toggle', { hasText: 'Sales' }),
    });
    await expect(salesLi.locator('ul.submenu li')).toHaveCount(3);
  });

  test('Add Sale by SKU is not in sidebar', async ({ page }) => {
    await page.goto('/users/home.php');
    await expect(page.locator('.sidebar a', { hasText: 'Add Sale by SKU' })).toHaveCount(0);
  });
});
