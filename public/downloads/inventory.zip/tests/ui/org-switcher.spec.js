const { test, expect } = require('@playwright/test');

const HARNESS_ORG = 'HARNESS_PlaywrightOrg';

test.describe('Org switcher', () => {
  test.beforeAll(async ({ browser }) => {
    const context = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await context.newPage();

    // Clean up any leftover HARNESS_ org from a previous failed run.
    await page.goto('/orgs/orgs.php');
    const leftover = page.locator('tr', { hasText: HARNESS_ORG });
    if (await leftover.count() > 0) {
      const deleteBtn = leftover.locator('button.btn-danger');
      if (await deleteBtn.count() > 0) {
        page.on('dialog', d => d.accept());
        await deleteBtn.click();
        await page.waitForURL(/orgs\.php/);
      }
    }

    // Create the HARNESS_ org via the org management UI.
    // The create form has a hidden org_id=0; the rename form has a non-zero org_id.
    await page.fill('form:has(input[name="org_id"][value="0"]) input[name="name"]', HARNESS_ORG);
    await page.click('form:has(input[name="org_id"][value="0"]) button[type="submit"]');
    // Success redirects to edit_org.php
    await expect(page).toHaveURL(/edit_org\.php/);

    await context.close();
  });

  test.afterAll(async ({ browser }) => {
    // Safety net: delete HARNESS_ org if it's still active (e.g. a test failed).
    const context = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await context.newPage();
    await page.goto('/orgs/orgs.php');

    const harnessRow = page.locator('tr', { hasText: HARNESS_ORG });
    const deleteBtn = harnessRow.locator('button.btn-danger');

    // Only try to delete if the button exists (soft-deleted rows have a Restore button instead)
    if (await deleteBtn.count() > 0) {
      page.on('dialog', d => d.accept());
      await deleteBtn.click();
      await expect(page).toHaveURL(/orgs\.php/);
    }

    await context.close();
  });

  test('switcher dropdown appears with ≥2 orgs', async ({ page }) => {
    await page.goto('/users/home.php');
    await expect(page.locator('li.dropdown')).toBeVisible();
  });

  test('current org has active checkmark in dropdown', async ({ page }) => {
    await page.goto('/users/home.php');
    await page.click('li.dropdown > a.toggle');
    // The active org's button contains the checkmark SVG icon (bi-check-lg)
    const activeBtn = page.locator('.org-switcher-btn', { has: page.locator('svg.bi') });
    await expect(activeBtn).toContainText('Default Organization');
  });

  test('switching to HARNESS_ org updates topbar', async ({ page }) => {
    await page.goto('/users/home.php');
    await page.click('li.dropdown > a.toggle');
    await page.click(`.org-switcher-btn:has-text("${HARNESS_ORG}")`);
    // Form submit reloads the page; wait for the URL to settle
    await page.waitForLoadState('networkidle');
    await expect(page.locator('li.dropdown > a.toggle')).toContainText(HARNESS_ORG);
  });

  test('switching back to Default Organization updates topbar', async ({ page }) => {
    // Start on home while HARNESS_ org may be active from previous test — switch either way
    await page.goto('/users/home.php');
    await page.click('li.dropdown > a.toggle');
    await page.click('.org-switcher-btn:has-text("Default Organization")');
    await page.waitForLoadState('networkidle');
    await expect(page.locator('li.dropdown > a.toggle')).toContainText('Default Organization');
  });

  test('deleting HARNESS_ org removes it from switcher', async ({ page }) => {
    // Verify HARNESS_ORG is in the switcher before deletion
    await page.goto('/users/home.php');
    await page.click('li.dropdown > a.toggle');
    await expect(page.locator(`.org-switcher-btn:has-text("${HARNESS_ORG}")`)).toBeVisible();

    // Close the dropdown
    await page.click('body');

    // Navigate to orgs page and delete the org
    await page.goto('/orgs/orgs.php');
    const harnessRow = page.locator('tr', { hasText: HARNESS_ORG });
    page.on('dialog', d => d.accept());
    await harnessRow.locator('button.btn-danger').click();
    await expect(page).toHaveURL(/orgs\.php/);

    // Navigate back to home and verify HARNESS_ORG is no longer in the switcher
    await page.goto('/users/home.php');
    // If switcher still exists, verify HARNESS_ORG is not in it
    const switcher = page.locator('li.dropdown');
    if (await switcher.count() > 0) {
      await page.click('li.dropdown > a.toggle');
      await expect(page.locator(`.org-switcher-btn:has-text("${HARNESS_ORG}")`)).not.toBeVisible();
    }
  });
});

// ─── Soft-delete / restore cycle ─────────────────────────────────────────────

// Timestamp-based name ensures each run's locator can't match prior-run rows.
// The UI only soft-deletes orgs (no hard-delete), so old rows accumulate with
// different timestamps and can't be fully purged from the UI — but since each
// run uses a unique name, the test locators resolve to exactly 1 row.
const HARNESS_RESTORE_ORG = 'HARNESS_RestoreOrg_' + Date.now();

test.describe('Org soft-delete and restore cycle', () => {
  test.beforeAll(async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();
    page.on('dialog', d => d.accept());

    await page.goto('/orgs/orgs.php');

    // Soft-delete any ACTIVE HARNESS_RestoreOrg_* orgs from prior runs so they
    // don't appear in the switcher and skew the visibility assertions.
    for (let i = 0; i < 10; i++) {
      const activeLeftover = page.locator('tr', { hasText: 'HARNESS_RestoreOrg_' })
        .filter({ has: page.locator('button.btn-danger') });
      if ((await activeLeftover.count()) === 0) break;
      await activeLeftover.first().locator('button.btn-danger').click();
      await page.waitForURL(/orgs\.php/);
    }

    // Create this run's uniquely-named HARNESS_RestoreOrg_<ts> org
    await page.fill('form:has(input[name="org_id"][value="0"]) input[name="name"]', HARNESS_RESTORE_ORG);
    await page.click('form:has(input[name="org_id"][value="0"]) button[type="submit"]');
    await expect(page).toHaveURL(/edit_org\.php/);

    await ctx.close();
  });

  test.afterAll(async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();
    page.on('dialog', d => d.accept());

    await page.goto('/orgs/orgs.php');

    // Soft-delete this run's org if it was restored by Test B and is still active
    const row = page.locator('tr', { hasText: HARNESS_RESTORE_ORG });
    const deleteBtn = row.locator('button.btn-danger');
    if ((await deleteBtn.count()) > 0) {
      await deleteBtn.click();
      await page.waitForURL(/orgs\.php/);
    }

    await ctx.close();
  });

  test('soft-deleting org removes it from switcher', async ({ page }) => {
    await page.goto('/orgs/orgs.php');

    const row = page.locator('tr', { hasText: HARNESS_RESTORE_ORG });

    page.on('dialog', d => d.accept());
    await row.locator('button.btn-danger').click();
    await page.waitForURL(/orgs\.php/);

    // Row should now show the Deleted badge
    const deletedRow = page.locator('tr', { hasText: HARNESS_RESTORE_ORG });
    await expect(deletedRow.locator('.badge.bg-danger')).toBeVisible();

    // Org should not appear in the switcher dropdown.
    // After deletion admin may have only 1 active org → switcher hides entirely.
    // Absence of the switcher is itself sufficient proof the org is gone.
    await page.goto('/users/home.php');
    const switcher = page.locator('li.dropdown');
    if (await switcher.count() > 0) {
      await page.click('li.dropdown > a.toggle');
      await expect(
        page.locator(`.org-switcher-btn:has-text("${HARNESS_RESTORE_ORG}")`)
      ).not.toBeVisible();
    }
  });

  test('restoring org brings it back to switcher', async ({ page }) => {
    await page.goto('/orgs/orgs.php');

    const row = page.locator('tr', { hasText: HARNESS_RESTORE_ORG });

    await row.locator('button.btn-success').click();
    await page.waitForURL(/orgs\.php/);

    // Row should now show the Active badge
    const activeRow = page.locator('tr', { hasText: HARNESS_RESTORE_ORG });
    await expect(activeRow.locator('.badge.bg-success')).toBeVisible();

    // Org should reappear in the switcher dropdown
    await page.goto('/users/home.php');
    await page.click('li.dropdown > a.toggle');
    await expect(
      page.locator(`.org-switcher-btn:has-text("${HARNESS_RESTORE_ORG}")`)
    ).toBeVisible();
  });
});
