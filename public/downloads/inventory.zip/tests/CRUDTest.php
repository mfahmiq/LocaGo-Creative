<?php
/**
 * tests/CRUDTest.php
 *
 * Smoke tests for product CRUD: create, read, update, delete.
 *
 * Note: uses a check()/throw helper instead of PHP's assert(),
 * because assert() is a no-op when zend.assertions=-1 (the default
 * in production-mode PHP), which means assert() failures silently
 * pass. check() always throws on failure so test() catches it.
 */

require_once __DIR__ . '/bootstrap.php';

$pass = 0;
$fail = 0;
$created_product_id = null;

// Set up org context for tests that need org_id guards
$_SESSION['current_org_id'] = 1;

function test(string $name, callable $fn): void
{
    global $pass, $fail;
    try {
        $fn();
        $pass++;
        echo "  PASS: $name\n";
    } catch (Throwable $e) {
        $fail++;
        echo "  FAIL: $name — " . $e->getMessage() . "\n";
    }
}

function check(bool $cond, string $msg): void
{
    if (!$cond) {
        throw new RuntimeException($msg);
    }
}

echo "=== CRUDTest ===\n\n";

// 1. List products (join_product_table)
test('join_product_table() returns products', function () {
    global $db;
    $products = join_product_table();
    check(is_array($products), 'join_product_table() should return an array');
    echo "       [" . count($products) . " products in database]\n";
});

// 2. Create a test product. Provision a HARNESS category first so we
//    don't depend on seed data existing in the test DB.
$created_category_id = null;
test('Create product via INSERT', function () use (&$created_product_id, &$created_category_id) {
    global $db;
    // Create a throwaway category for this test run.
    $cat_name = 'HARNESS_Cat_' . uniqid();
    $e_cat = $db->escape($cat_name);
    $db->query("INSERT INTO categories (name) VALUES ('{$e_cat}')");
    $created_category_id = $db->insert_id();
    check($created_category_id > 0, 'Failed to create test category');

    $name = 'HARNESS_TestProduct_' . uniqid();
    $date = date('Y-m-d H:i:s');
    $e_name = $db->escape($name);
    // Supply all NOT-NULL columns: name, description, location, sale_price,
    // category_id, date, org_id. (sku, quantity, buy_price, media_id have defaults.)
    $sql = "INSERT INTO products (name, description, location, quantity, buy_price, sale_price, category_id, media_id, date, org_id)
            VALUES ('{$e_name}', '', 'TEST_LOC', 100, 5.00, 10.00, {$created_category_id}, NULL, '{$date}', 1)";
    $db->query($sql);
    $created_product_id = $db->insert_id();
    check($created_product_id > 0, 'Failed to create product');
    echo "       [created product id=$created_product_id name=$name]\n";
});

// 3. Read the created product
test('find_by_id() retrieves created product', function () use (&$created_product_id) {
    check($created_product_id > 0, 'Prior test failed to create a product to read');
    $product = find_by_id('products', $created_product_id);
    check($product !== null, 'find_by_id() returned null');
    check(
        strpos($product['name'], 'HARNESS_TestProduct_') === 0,
        'Product name mismatch: ' . ($product['name'] ?? 'null')
    );
    echo "       [retrieved: {$product['name']}]\n";
});

// 4. Update product quantity
test('increase_product_qty() updates quantity', function () use (&$created_product_id) {
    check($created_product_id > 0, 'No product to update');
    $before = find_by_id('products', $created_product_id);
    $old_qty = (int) $before['quantity'];
    increase_product_qty(50, $created_product_id);
    $after = find_by_id('products', $created_product_id);
    check((int)$after['quantity'] === $old_qty + 50, "Quantity expected " . ($old_qty + 50) . ", got {$after['quantity']}");
    echo "       [quantity: $old_qty -> {$after['quantity']}]\n";
});

// 5. Test decrease_product_qty
test('decrease_product_qty() updates quantity', function () use (&$created_product_id) {
    check($created_product_id > 0, 'No product to update');
    $before = find_by_id('products', $created_product_id);
    $old_qty = (int) $before['quantity'];
    decrease_product_qty(25, $created_product_id);
    $after = find_by_id('products', $created_product_id);
    check((int)$after['quantity'] === $old_qty - 25, "Quantity expected " . ($old_qty - 25) . ", got {$after['quantity']}");
    echo "       [quantity: $old_qty -> {$after['quantity']}]\n";
});

// 6. Delete the test product
test('Delete product via delete_by_id', function () use (&$created_product_id, &$created_category_id) {
    check($created_product_id > 0, 'No product to delete');
    $result = delete_by_id('products', $created_product_id);
    check($result !== false, 'delete_by_id() failed');
    $gone = find_by_id('products', $created_product_id);
    check($gone === null, 'Product still exists after delete');
    echo "       [product id=$created_product_id deleted]\n";
    // Clean up the HARNESS category we created.
    if ($created_category_id > 0) {
        delete_by_id('categories', $created_category_id);
    }
});

// 7. Verify quantity column type. We accept either INT (post-migration)
//    or VARCHAR (pre-migration, but flag it as a known issue).
test('Quantity column has the expected type', function () {
    global $db;
    $result = $db->query("SHOW COLUMNS FROM products LIKE 'quantity'");
    $row = $db->fetch_assoc($result);
    check($row !== false && $row !== null, 'Could not inspect quantity column');
    $type = strtolower($row['Type']);
    if (strpos($type, 'int') !== false) {
        echo "       [quantity column type: {$row['Type']} — OK]\n";
    } elseif (strpos($type, 'varchar') !== false) {
        // Known issue tracked in gap-analysis.md — schema migration pending.
        echo "       [quantity column type: {$row['Type']} — known issue, see gap-analysis.md]\n";
    } else {
        throw new RuntimeException("quantity column is $type, expected INT or VARCHAR");
    }
});

// 8. Sales functions exist
test('find_sale_by_dates() executes', function () {
    $sales = find_sale_by_dates('2020-01-01', '2030-12-31');
    check(is_array($sales), 'find_sale_by_dates() should return an array');
    echo "       [" . count($sales) . " sales in range]\n";
});

// 9. SQL injection: find_by_id() rejects non-integer ID strings
test('find_by_id() treats injection string as literal integer 0', function () {
    // "1 OR 1=1" cast to int becomes 1, not a SQLi payload — assert behaviour is defined
    $result = find_by_id('products', "1 OR 1=1");
    // (int)"1 OR 1=1" === 1, so this returns the product with id=1 or null — not all rows
    // The key assertion: result is null OR a single row, never an array of multiple rows
    check($result === null || (is_array($result) && isset($result['id'])),
        'find_by_id() must return null or a single row, not multiple rows');
});

// 10. SQL injection: find_by_name() treats SQL payload as literal string
test('find_by_name() treats SQL injection payload as literal name', function () {
    $payload = "'; DROP TABLE products; --";
    $result = find_by_name('products', $payload);
    // Should return null (no product with that name) — NOT execute the injection
    check($result === null, 'find_by_name() should return null for injection payload, not execute it');
    // Verify products table still exists
    global $db;
    $check_q = $db->query("SELECT COUNT(*) as n FROM products");
    $row = $db->fetch_assoc($check_q);
    check($row !== false && $row !== null, 'products table must still exist after injection attempt');
});

// 11. delete_by_id() returns false for non-existent ID
test('delete_by_id() returns false for non-existent ID', function () {
    $result = delete_by_id('products', 999999999);
    check($result === false, 'delete_by_id() should return false when no row matches');
});

// 12. Search function — exercises find_all_product_info_by_search()
test('find_all_product_info_by_search() returns array without ArgumentCountError', function () {
    $_SESSION['current_org_id'] = 1;
    $results = find_all_product_info_by_search('HARNESS_');
    check(is_array($results), 'search should return an array');
});

// 13. Search function with empty string
test('find_all_product_info_by_search() with empty string returns array', function () {
    $_SESSION['current_org_id'] = 1;
    $results = find_all_product_info_by_search('');
    check(is_array($results), 'empty search should return an array');
});

echo "\n---\nResults: $pass passed, $fail failed\n";

exit($fail > 0 ? 1 : 0);
