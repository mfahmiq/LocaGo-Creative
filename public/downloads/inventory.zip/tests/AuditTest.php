<?php
/**
 * tests/AuditTest.php
 */
use PHPUnit\Framework\TestCase;

class AuditTest extends TestCase {

	public function test_audit_action_values_are_valid(): void {
		$valid = ['create', 'update', 'delete', 'login', 'logout'];
		foreach ($valid as $action) {
			$this->assertMatchesRegularExpression('/^[a-z]+$/', $action);
		}
	}

	public function test_summary_truncated_to_255(): void {
		$long    = str_repeat('x', 300);
		$trimmed = substr($long, 0, 255);
		$this->assertSame(255, strlen($trimmed));
	}
}
