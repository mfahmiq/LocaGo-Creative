<?php
/**
 * tests/CSRFTest.php
 *
 * PHPUnit tests for CSRF token generation and validation.
 */

use PHPUnit\Framework\Attributes\Test;
use PHPUnit\Framework\TestCase;

class CSRFTest extends TestCase
{
    protected function setUp(): void
    {
        if (!isset($_SESSION)) {
            $_SESSION = [];
        }
        unset($_SESSION['csrf_token']);
    }

    protected function tearDown(): void
    {
        unset($_SERVER['REQUEST_METHOD'], $_POST['csrf_token'], $_GET['csrf_token']);
    }

    #[Test]
    public function csrf_token_generates_a_hex_token(): void
    {
        $token = csrf_token();
        $this->assertNotEmpty($token, 'Token is empty');
        $this->assertSame(64, strlen($token), 'Token should be 64 hex chars (32 bytes), got ' . strlen($token));
        $this->assertArrayHasKey('csrf_token', $_SESSION, 'Token not stored in session');
    }

    #[Test]
    public function csrf_token_returns_same_token_on_second_call(): void
    {
        $token1 = csrf_token();
        $token2 = csrf_token();
        $this->assertSame($token1, $token2, 'Token changed between calls');
    }

    #[Test]
    public function csrf_field_returns_hidden_input_html(): void
    {
        $field = csrf_field();
        $this->assertStringContainsString('<input', $field, 'Missing <input> tag');
        $this->assertStringContainsString('type="hidden"', $field, 'Missing type="hidden"');
        $this->assertStringContainsString('name="csrf_token"', $field, 'Missing name="csrf_token"');
        $this->assertStringContainsString(csrf_token(), $field, 'Token value not in field');
    }

    #[Test]
    public function verify_csrf_passes_with_correct_token(): void
    {
        $token = csrf_token();
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST['csrf_token'] = $token;
        $result = verify_csrf();
        $this->assertTrue($result, 'verify_csrf() should return true for valid token');
    }

    #[Test]
    public function verify_csrf_rejects_wrong_token(): void
    {
        csrf_token(); // ensure token exists
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST['csrf_token'] = '0000000000000000000000000000000000000000000000000000000000000000';
        $result = verify_csrf();
        $this->assertFalse($result, 'Should reject wrong token');
    }

    #[Test]
    public function verify_csrf_rejects_missing_token(): void
    {
        csrf_token();
        $_SERVER['REQUEST_METHOD'] = 'POST';
        // No csrf_token in $_POST
        $result = verify_csrf();
        $this->assertFalse($result, 'Should reject when token is missing');
    }

    #[Test]
    public function verify_csrf_returns_true_for_get_requests(): void
    {
        $_SERVER['REQUEST_METHOD'] = 'GET';
        $result = verify_csrf();
        // Should return true (no CSRF check needed for GET)
        $this->assertTrue($result, 'Should skip CSRF check for GET');
    }

    #[Test]
    public function h_escapes_html_special_characters(): void
    {
        $input = '<script>alert("xss")</script>';
        $escaped = h($input);
        $this->assertStringNotContainsString('<', $escaped, '< should be escaped');
        $this->assertStringNotContainsString('>', $escaped, '> should be escaped');
        $this->assertStringNotContainsString('"', $escaped, '" should be escaped');
        $this->assertStringContainsString('&lt;', $escaped, 'Should contain &lt;');
    }

    #[Test]
    public function remove_junk_strips_tags_and_escapes(): void
    {
        $input = '<p>Hello <b>World</b></p>';
        $result = remove_junk($input);
        $this->assertStringNotContainsString('<', $result, 'HTML tags should be removed');
        $this->assertStringContainsString('Hello', $result, 'Text content should remain');
    }

    #[Test]
    public function randString_produces_correct_length(): void
    {
        $s = randString(10);
        $this->assertSame(10, strlen($s), 'randString(10) should return 10 chars, got ' . strlen($s));
    }

    #[Test]
    public function verify_csrf_rejects_stale_token_after_session_cleared(): void
    {
        $token = csrf_token();
        // Simulate session destruction on logout
        $saved = $_SESSION;
        $_SESSION = [];
        $_SERVER['REQUEST_METHOD'] = 'POST';
        $_POST['csrf_token'] = $token;
        $result = verify_csrf();
        $this->assertFalse($result, 'Stale token from destroyed session should be rejected');
        // Restore
        $_SESSION = $saved;
    }

    #[Test]
    public function h_preserves_utf8_and_multibyte_characters(): void
    {
        $input = 'Héllo 世界 <script>';
        $escaped = h($input);
        $this->assertStringContainsString('Héllo', $escaped, 'Latin extended chars should be preserved');
        $this->assertStringContainsString('世界', $escaped, 'CJK chars should be preserved');
        $this->assertStringNotContainsString('<script>', $escaped, 'Tags should be escaped');
    }

    #[Test]
    public function verify_get_csrf_passes_with_correct_token_in_get(): void
    {
        $token = csrf_token();
        $_GET['csrf_token'] = $token;
        $this->assertTrue(verify_get_csrf(), 'verify_get_csrf() should return true for valid token');
    }

    #[Test]
    public function verify_get_csrf_rejects_wrong_token(): void
    {
        csrf_token();
        $_GET['csrf_token'] = str_repeat('0', 64);
        $this->assertFalse(verify_get_csrf(), 'verify_get_csrf() should reject wrong token');
    }

    #[Test]
    public function verify_get_csrf_rejects_missing_token(): void
    {
        csrf_token();
        unset($_GET['csrf_token']);
        $this->assertFalse(verify_get_csrf(), 'verify_get_csrf() should reject missing token');
    }

    #[Test]
    public function csrf_url_param_returns_csrf_token_hex_string(): void
    {
        $param = csrf_url_param();
        $this->assertStringStartsWith('csrf_token=', $param, 'Should start with csrf_token=');
        $token_part = substr($param, strlen('csrf_token='));
        $token_part = urldecode($token_part);
        $this->assertSame(64, strlen($token_part), 'Token should be 64 hex chars');
        $this->assertTrue(ctype_xdigit($token_part), 'Token should be hex');
    }
}
