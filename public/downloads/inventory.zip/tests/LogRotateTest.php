<?php
/**
 * tests/LogRotateTest.php
 *
 * Tests log_rotate.php: seeds known-stale rows in `log` and `failed_logins`,
 * runs the rotation, asserts the rows are gone and recent rows survive.
 */

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;

class LogRotateTest extends TestCase
{
    private \MySqli_DB $db;
    private array $seeded_log_ids = [];
    private array $seeded_fail_ids = [];

    protected function setUp(): void
    {
        if (getenv('TESTS_NO_DB')) {
            $this->markTestSkipped('TESTS_NO_DB set — log_rotate test requires a live DB');
        }
        $this->db = new \MySqli_DB();
    }

    protected function tearDown(): void
    {
        if (isset($this->db)) {
            foreach ($this->seeded_log_ids as $id) {
                $this->db->prepare_query('DELETE FROM `log` WHERE id = ?', 'i', $id);
            }
            foreach ($this->seeded_fail_ids as $id) {
                $this->db->prepare_query('DELETE FROM `failed_logins` WHERE id = ?', 'i', $id);
            }
        }
    }

    #[Test]
    public function log_rotate_file_exists(): void
    {
        $this->assertFileExists(dirname(__DIR__) . '/log_rotate.php');
    }

    #[Test]
    public function log_rotate_prunes_stale_log_row_and_keeps_recent_one(): void
    {
        // Seed: one row 200 days old (stale, should be pruned at default 90-day retention)
        // and one row 1 day old (recent, should survive).
        $stale_action = 'HARNESS_log_rotate_stale_' . uniqid();
        $fresh_action = 'HARNESS_log_rotate_fresh_' . uniqid();

        $this->db->prepare_query(
            "INSERT INTO `log` (user_id, remote_ip, action, date) VALUES (NULL, '0.0.0.0', ?, DATE_SUB(NOW(), INTERVAL 200 DAY))",
            's', $stale_action
        );
        $this->seeded_log_ids[] = (int) $this->db->insert_id();

        $this->db->prepare_query(
            "INSERT INTO `log` (user_id, remote_ip, action, date) VALUES (NULL, '0.0.0.0', ?, DATE_SUB(NOW(), INTERVAL 1 DAY))",
            's', $fresh_action
        );
        $fresh_id = (int) $this->db->insert_id();
        $this->seeded_log_ids[] = $fresh_id;

        // Run the rotation.
        ob_start();
        $original_error_reporting = error_reporting();
        error_reporting($original_error_reporting & ~E_WARNING);
        try {
            include dirname(__DIR__) . '/log_rotate.php';
        } finally {
            error_reporting($original_error_reporting);
        }
        ob_end_clean();

        // Assert stale row is gone, fresh row survives.
        $stale_rows = $this->db->prepare_select(
            'SELECT id FROM `log` WHERE action = ?', 's', $stale_action
        );
        $this->assertSame([], $stale_rows, 'Stale log row should have been pruned');

        $fresh_rows = $this->db->prepare_select(
            'SELECT id FROM `log` WHERE id = ?', 'i', $fresh_id
        );
        $this->assertCount(1, $fresh_rows, 'Fresh log row should survive');
    }

    #[Test]
    public function log_rotate_prunes_stale_failed_login_attempts(): void
    {
        $stale_ip = '203.0.113.' . random_int(1, 254); // RFC 5737 test-net
        $this->db->prepare_query(
            "INSERT INTO `failed_logins` (ip, username_attempted, attempted_at) VALUES (?, 'HARNESS_user', DATE_SUB(NOW(), INTERVAL 30 DAY))",
            's', $stale_ip
        );
        $this->seeded_fail_ids[] = (int) $this->db->insert_id();

        ob_start();
        $original_error_reporting = error_reporting();
        error_reporting($original_error_reporting & ~E_WARNING);
        try {
            include dirname(__DIR__) . '/log_rotate.php';
        } finally {
            error_reporting($original_error_reporting);
        }
        ob_end_clean();

        $rows = $this->db->prepare_select(
            'SELECT id FROM `failed_logins` WHERE ip = ?', 's', $stale_ip
        );
        $this->assertSame([], $rows, 'Stale failed_logins row (>7 days) should have been pruned');
    }

    #[Test]
    public function log_rotate_audit_log_block_is_guarded_when_table_missing(): void
    {
        // Inventory does not have an audit_log table yet. The ported script
        // must check for the table's existence and skip the block silently
        // (or print "audit_log: skipped (table absent)") rather than crash.
        $source = file_get_contents(dirname(__DIR__) . '/log_rotate.php');
        $this->assertMatchesRegularExpression(
            '/SHOW\s+TABLES\s+LIKE\s+[\'"]audit_log[\'"]/i',
            $source,
            'log_rotate.php must guard the audit_log block with a SHOW TABLES check'
        );
    }
}
