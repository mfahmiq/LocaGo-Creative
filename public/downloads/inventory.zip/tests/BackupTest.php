<?php
/**
 * tests/BackupTest.php
 *
 * Tests backup.php: admin-gate enforcement (source inspection), htaccess
 * deny, optional CLI smoke when the dump binary is installed.
 */

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;

class BackupTest extends TestCase
{
    private string $backup_dir;

    protected function setUp(): void
    {
        $this->backup_dir = sys_get_temp_dir() . '/inventory-test-backups-' . posix_getpid();
        if (!is_dir($this->backup_dir)) {
            mkdir($this->backup_dir, 0750, true);
        }
    }

    protected function tearDown(): void
    {
        if (is_dir($this->backup_dir)) {
            array_map('unlink', glob($this->backup_dir . '/*') ?: []);
            @unlink($this->backup_dir . '/.htaccess');
            @rmdir($this->backup_dir);
        }
    }

    #[Test]
    public function backup_file_exists_at_project_root(): void
    {
        $this->assertFileExists(dirname(__DIR__) . '/backup.php');
    }

    #[Test]
    public function backups_htaccess_denies_all(): void
    {
        $htaccess = dirname(__DIR__) . '/backups/.htaccess';
        $this->assertFileExists($htaccess, 'backups/.htaccess must exist to block web access');
        $content = file_get_contents($htaccess);
        $this->assertStringContainsString('Require all denied', $content);
    }

    #[Test]
    public function backup_source_has_sapi_gate_and_admin_check(): void
    {
        $source = file_get_contents(dirname(__DIR__) . '/backup.php');
        $this->assertStringContainsString("PHP_SAPI === 'cli'", $source, 'Must check SAPI before allowing access');
        $this->assertStringContainsString('http_response_code(403)', $source, 'Must return 403 for unauthenticated web access');
        $this->assertStringContainsString('ROLE_ADMIN', $source, 'Must require ROLE_ADMIN');
    }

    #[Test]
    public function backup_cli_run_produces_gzipped_dump_when_binary_available(): void
    {
        if (getenv('TESTS_NO_DB')) {
            $this->markTestSkipped('TESTS_NO_DB set — backup smoke test requires a live DB');
        }
        $dump_bin = trim((string) shell_exec('which mysqldump 2>/dev/null'));
        if (empty($dump_bin)) {
            $this->markTestSkipped('mysqldump not installed on this host');
        }

        $project_root = dirname(__DIR__);
        $env_dir      = escapeshellarg($this->backup_dir);
        $script       = escapeshellarg($project_root . '/backup.php');
        $output       = shell_exec("BACKUP_DIR=$env_dir BACKUP_RETAIN_COUNT=3 php $script 2>&1");
        $files        = glob($this->backup_dir . '/*.sql.gz');

        $this->assertNotEmpty(
            $files,
            "Expected a .sql.gz in {$this->backup_dir}; script output was:\n$output"
        );
        $this->assertGreaterThan(100, filesize($files[0]), 'Backup file should be > 100 bytes');
    }
}
