<?php
/**
 * tests/PasswordResetTest.php
 *
 * PHPUnit tests for password reset token generation, validation, and consumption.
 */

use PHPUnit\Framework\Attributes\Test;
use PHPUnit\Framework\TestCase;

class PasswordResetTest extends TestCase
{
    #[Test]
    public function token_is_64_hex_chars(): void
    {
        $token = bin2hex(random_bytes(32));
        $this->assertSame(64, strlen($token));
        $this->assertMatchesRegularExpression('/^[0-9a-f]{64}$/', $token);
    }

    #[Test]
    public function expiry_is_one_hour_from_now(): void
    {
        $now = time();
        $expires = date('Y-m-d H:i:s', $now + 3600);
        $ts = strtotime($expires);
        $diff = $ts - $now;
        // Allow 10 second variance
        $this->assertGreaterThan(3590, $diff);
        $this->assertLessThan(3610, $diff);
    }

    #[Test]
    public function password_hash_produces_bcrypt_hash(): void
    {
        $password = 'TestPassword123!';
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $this->assertTrue(password_verify($password, $hash));
    }

    #[Test]
    public function password_verify_detects_wrong_password(): void
    {
        $password = 'TestPassword123!';
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $this->assertFalse(password_verify('WrongPassword', $hash));
    }
}
