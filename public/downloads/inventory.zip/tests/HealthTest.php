<?php
/**
 * tests/HealthTest.php
 *
 * Tests health.php: JSON output shape, status determination,
 * HTTP status code via http_response_code() side effect.
 */

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;

class HealthTest extends TestCase
{
    #[Test]
    public function health_endpoint_outputs_json_with_status_and_checks(): void
    {
        $project_root = dirname(__DIR__);
        $health_file  = $project_root . '/health.php';
        $this->assertFileExists($health_file, 'health.php must exist at project root');

        ob_start();
        // Suppress header() warnings — PHPUnit has already sent headers.
        $original_error_reporting = error_reporting();
        error_reporting($original_error_reporting & ~E_WARNING);
        try {
            include $health_file;
        } finally {
            error_reporting($original_error_reporting);
        }
        $output = ob_get_clean();

        $decoded = json_decode($output, true);
        $this->assertIsArray($decoded, 'health.php must emit valid JSON');
        $this->assertArrayHasKey('status', $decoded);
        $this->assertArrayHasKey('timestamp', $decoded);
        $this->assertArrayHasKey('checks', $decoded);
        $this->assertContains($decoded['status'], ['ok', 'degraded'], 'status must be ok or degraded');
    }

    #[Test]
    public function health_checks_include_database_and_disk_free(): void
    {
        $project_root = dirname(__DIR__);
        $health_file  = $project_root . '/health.php';

        ob_start();
        $original_error_reporting = error_reporting();
        error_reporting($original_error_reporting & ~E_WARNING);
        try {
            include $health_file;
        } finally {
            error_reporting($original_error_reporting);
        }
        $output = ob_get_clean();

        $decoded = json_decode($output, true);
        $this->assertArrayHasKey('database', $decoded['checks'], 'database check expected');
        $this->assertArrayHasKey('disk_free_mb', $decoded['checks'], 'disk_free_mb check expected');
        $this->assertContains($decoded['checks']['database'], ['ok', 'error'], 'database check must be ok or error');
    }
}
