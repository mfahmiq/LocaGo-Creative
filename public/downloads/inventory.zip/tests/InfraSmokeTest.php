<?php

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;

class InfraSmokeTest extends TestCase
{
    #[Test]
    public function bootstrap_loaded_constants(): void
    {
        $this->assertTrue(defined('SITE_ROOT'), 'SITE_ROOT should be defined by bootstrap');
        $this->assertTrue(defined('APP_LANG'), 'APP_LANG should be defined by bootstrap');
        $this->assertTrue(defined('ROLE_ADMIN'), 'ROLE_ADMIN should be defined by bootstrap');
    }

    #[Test]
    public function phpunit_runner_env_is_set(): void
    {
        $this->assertSame('phpunit', getenv('INVENTORY_TEST_RUNNER'));
    }

    #[Test]
    public function bootstrap_does_not_print_banner_under_phpunit(): void
    {
        // The bootstrap should detect INVENTORY_TEST_RUNNER=phpunit and skip
        // the "Test bootstrap loaded." echo lines. If those echoes happen,
        // PHPUnit raises a "test printed unexpected output" warning, which
        // failOnWarning="true" promotes to a failure.
        $this->expectNotToPerformAssertions();
    }
}
