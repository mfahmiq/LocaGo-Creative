<?php
use PHPUnit\Framework\TestCase;

class PermissionsTest extends TestCase {

    public function test_permission_modules_returns_expected_keys(): void {
        $expected_keys = ['products','customers','sales','orders','reports',
                          'stock','users','data_tools'];
        $modules = [
            'products'   => 'Products',
            'customers'  => 'Customers',
            'sales'      => 'Sales',
            'orders'     => 'Orders',
            'reports'    => 'Reports',
            'stock'      => 'Stock',
            'users'      => 'Users',
            'data_tools' => 'Data Tools',
        ];
        foreach ($expected_keys as $key) {
            $this->assertArrayHasKey($key, $modules, "Module '$key' missing");
        }
    }

    public function test_invalid_action_returns_false(): void {
        $action = 'fly';
        $valid  = in_array($action, ['view','create','edit','delete'], true);
        $this->assertFalse($valid, 'Unknown actions must be rejected');
    }

    public function test_can_rejects_invalid_action(): void {
        // can() checks action validity before anything else
        $valid   = in_array('fly',    ['view','create','edit','delete'], true);
        $invalid = in_array('delete', ['view','create','edit','delete'], true);
        $this->assertFalse($valid);
        $this->assertTrue($invalid);
    }

    public function test_supervisor_defaults_allow_view_create_edit(): void {
        // Replicate the level-based fallback logic from can()
        $supervisor_allowed = ['view', 'create', 'edit'];
        $this->assertContains('view',   $supervisor_allowed);
        $this->assertContains('create', $supervisor_allowed);
        $this->assertContains('edit',   $supervisor_allowed);
        $this->assertNotContains('delete', $supervisor_allowed);
    }

    public function test_user_default_allows_only_view(): void {
        // ROLE_USER default: view only
        $user_action = 'view';
        $allowed = ($user_action === 'view');
        $this->assertTrue($allowed);

        foreach (['create', 'edit', 'delete'] as $action) {
            $this->assertFalse($action === 'view', "ROLE_USER should not default-allow $action");
        }
    }
}
