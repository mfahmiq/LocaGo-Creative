#!/bin/bash
#
# tests/run.sh
#
# Run all PHP + Playwright tests for the Inventory Management System.
# Usage: bash tests/run.sh
#
# Two runners coexist during the legacy→PHPUnit migration:
#   - vendor/bin/phpunit runs every tests/*Test.php that defines a class.
#   - php tests/<File>.php runs the legacy hand-rolled test scripts that
#     haven't been converted yet (tracked in Phase 1.5).
#
# Requires a valid .env file with database credentials for full suite.
# When .env is missing or DB is unreachable, integration tests are skipped.

cd "$(dirname "$0")/.."

TOTAL=0
PASSED=0
FAILED=0
SKIPPED=0

echo "========================================="
echo " Inventory Management System — Test Suite"
echo " Date: $(date)"
echo "========================================="
echo ""

# ── PHPUnit (CSRFTest + InfraSmokeTest, plus any future PHPUnit class) ──
TOTAL=$((TOTAL + 1))
echo "--- PHPUnit ---"
if vendor/bin/phpunit --colors=never; then
    PASSED=$((PASSED + 1))
else
    FAILED=$((FAILED + 1))
fi
echo ""

# ── Legacy scripts that still use the hand-rolled test() helper ──
run_legacy() {
    local test_file="$1"
    local name="$2"
    local nodb="${3:-}"
    TOTAL=$((TOTAL + 1))
    echo "--- $name (legacy) ---"
    if [ -n "$nodb" ]; then
        export TESTS_NO_DB=1
    fi
    if php "$test_file" 2>&1; then
        PASSED=$((PASSED + 1))
    else
        FAILED=$((FAILED + 1))
    fi
    unset TESTS_NO_DB
    echo ""
}

# DB reachability probe (same as before)
DB_OK=0
if php -r "
define('URL_SEPARATOR', '/');
define('DS', DIRECTORY_SEPARATOR);
define('SITE_ROOT', realpath('includes'));
define('LIB_PATH_INC', SITE_ROOT . DS);
require_once 'includes/config.php';
try {
    \$c = @mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (\$c) { echo 'OK'; exit(0); }
} catch (Exception \$e) {}
exit(1);
" 2>/dev/null; then
    DB_OK=1
fi

if [ "$DB_OK" -eq 1 ]; then
    run_legacy "tests/AuthTest.php"          "Authentication (integration)"
    run_legacy "tests/CRUDTest.php"          "CRUD Operations (integration)"
    run_legacy "tests/SettingsTest.php"      "Settings (integration)"
    run_legacy "tests/SoftDeleteTest.php"    "Soft-Delete (integration)"
    run_legacy "tests/TenancyTest.php"       "Tenancy (integration)"
    run_legacy "tests/OrgManagementTest.php" "Org Management (integration)"
else
    echo "--- Integration tests ---"
    echo "  SKIPPED: Database not accessible."
    SKIPPED=$((SKIPPED + 6))
    TOTAL=$((TOTAL + 6))
    echo ""
fi

# HTTP-dependent legacy test
run_legacy "tests/SecurityHeadersTest.php" "Security Headers (http)" nodb

# ── Playwright ──
HTTP_OK=0
if php -r "
\$base = getenv('INVENTORY_BASE_URL') ?: 'http://blueberry.local:8080';
\$ctx = stream_context_create(['http' => ['method' => 'GET', 'timeout' => 3, 'ignore_errors' => true]]);
@file_get_contents(\$base . '/users/index.php', false, \$ctx);
if (isset(\$http_response_header)) { echo 'OK'; exit(0); }
exit(1);
" 2>/dev/null; then
    HTTP_OK=1
fi

TOTAL=$((TOTAL + 1))
echo "--- Playwright UI Tests ---"
if [ "$HTTP_OK" -eq 1 ] && command -v npx &>/dev/null; then
    if npx playwright test --reporter=line 2>&1; then
        PASSED=$((PASSED + 1))
    else
        FAILED=$((FAILED + 1))
    fi
else
    echo "  SKIPPED: server not reachable or npx not found."
    SKIPPED=$((SKIPPED + 1))
fi
echo ""

echo "========================================="
echo " Summary: $PASSED/$TOTAL suites passed"
[ "$SKIPPED" -gt 0 ] && echo " ($SKIPPED skipped)"
echo "========================================="

if [ "$FAILED" -gt 0 ]; then
    echo "FAILED: $FAILED test suite(s)"
    exit 1
fi

echo "OK: All available test suites passed."
exit 0
