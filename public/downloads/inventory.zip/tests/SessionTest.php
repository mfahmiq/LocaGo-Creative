<?php
/**
 * tests/SessionTest.php
 *
 * Tests for session management: idle timeout, secure context detection.
 *
 * @package default
 */

use PHPUnit\Framework\TestCase;

class SessionTest extends TestCase
{
    private static array $server_baseline;

    public static function setUpBeforeClass(): void {
        // Capture clean baseline before any tests modify $_SERVER
        self::$server_baseline = [
            'HTTPS' => $_SERVER['HTTPS'] ?? null,
            'HTTP_HOST' => $_SERVER['HTTP_HOST'] ?? null,
            'HTTP_X_FORWARDED_PROTO' => $_SERVER['HTTP_X_FORWARDED_PROTO'] ?? null,
            'HTTP_X_FORWARDED_SSL' => $_SERVER['HTTP_X_FORWARDED_SSL'] ?? null,
        ];
    }

    public function tearDown(): void {
        // Restore specific keys to baseline to avoid cross-test pollution
        foreach (['HTTPS', 'HTTP_HOST', 'HTTP_X_FORWARDED_PROTO', 'HTTP_X_FORWARDED_SSL'] as $key) {
            if (isset(self::$server_baseline[$key]) && self::$server_baseline[$key] === null) {
                unset($_SERVER[$key]);
            } elseif (isset(self::$server_baseline[$key])) {
                $_SERVER[$key] = self::$server_baseline[$key];
            }
        }
    }

    public function test_idle_timeout_expires_session(): void {
        $_SESSION['user_id']     = 1;
        $_SESSION['LAST_ACTIVITY'] = time() - 3600; // 1 hour ago
        $timeout = 30 * 60; // 30 minutes

        $elapsed = time() - $_SESSION['LAST_ACTIVITY'];
        $this->assertGreaterThan($timeout, $elapsed, 'Elapsed exceeds timeout');
        $this->assertTrue(
            $elapsed > $timeout,
            'Session should be expired after 1h with 30m timeout'
        );
    }

    public function test_active_session_not_expired(): void {
        $_SESSION['LAST_ACTIVITY'] = time() - 60; // 1 minute ago
        $timeout = 30 * 60; // 30 minutes

        $elapsed = time() - $_SESSION['LAST_ACTIVITY'];
        $this->assertLessThan($timeout, $elapsed);
    }

    public function test_is_secure_context_detects_https_server_var(): void {
        // HTTPS=on triggers secure context
        $_SERVER['HTTPS'] = 'on';
        $this->assertTrue(is_secure_context());
    }

    public function test_is_secure_context_detects_forwarded_proto(): void {
        // X-Forwarded-Proto: https triggers secure context
        $_SERVER['HTTP_X_FORWARDED_PROTO'] = 'https';
        $this->assertTrue(is_secure_context());
    }

    public function test_is_secure_context_returns_false_for_localhost(): void {
        // localhost is always safe even without HTTPS
        // First clear any HTTPS flags left from previous tests
        unset($_SERVER['HTTPS'], $_SERVER['HTTP_X_FORWARDED_PROTO'], $_SERVER['HTTP_X_FORWARDED_SSL']);
        $_SERVER['HTTP_HOST'] = 'localhost';
        $this->assertFalse(is_secure_context(), 'localhost without HTTPS returns false (requires secure cookie)');
    }

    public function test_is_secure_context_returns_false_for_private_ip(): void {
        // Private IP ranges (RFC 1918) are safe even without HTTPS
        // First clear any HTTPS flags left from previous tests
        unset($_SERVER['HTTPS'], $_SERVER['HTTP_X_FORWARDED_PROTO'], $_SERVER['HTTP_X_FORWARDED_SSL']);
        $_SERVER['HTTP_HOST'] = '192.168.1.100';
        $this->assertFalse(is_secure_context(), 'Private IP without HTTPS returns false (requires secure cookie)');
    }

    public function test_is_secure_context_checks_host_parsing(): void {
        // Host parsing removes port numbers correctly
        $valid = preg_match('/:\d+$/', '203.0.113.1:8000') === 1;
        $this->assertTrue($valid, 'Port regex matches');
        $stripped = preg_replace('/:\d+$/', '', '203.0.113.1:8000');
        $this->assertEquals('203.0.113.1', $stripped, 'Port stripped correctly');
    }
}
