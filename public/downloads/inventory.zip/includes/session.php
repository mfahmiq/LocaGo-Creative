<?php
/**
 * includes/session.php
 *
 * @package default
 */

/**
 * Returns true only when HTTPS is detected (direct or via trusted proxy headers).
 * Returns false for localhost/LAN — intentional, so cookie_secure stays off on HTTP
 * local dev and doesn't break logins. Returns false for all other non-HTTPS contexts.
 */
function is_secure_context(): bool {
    if ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        // Trust X-Forwarded-Proto only if your reverse proxy strips/controls this header.
        || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
        || (!empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] === 'on')
    ) {
        return true;
    }
    $host = preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? '');
    if (in_array($host, ['localhost', '127.0.0.1', '::1'], true)) {
        return false;
    }
    // Private IP ranges (RFC 1918 / RFC 4193)
    if (preg_match('/^(10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.|fd[0-9a-f]{2}:)/i', $host)) {
        return false;
    }
    return false;
}

session_start([
    'cookie_httponly' => true,
    'cookie_samesite' => 'Lax',
    'cookie_secure'   => is_secure_context(),
]);

class Session {

	public $msg;
	private bool $user_is_logged_in = false;


	/**
	 * Initialize session and enforce idle timeout.
	 */
	function __construct() {
		$this->flash_msg();
		$this->userLoginSetup();
		if ($this->user_is_logged_in) {
			$this->check_session_timeout();
		}
	}


	/**
	 * Enforce idle timeout (SESSION_TIMEOUT_MINUTES in .env, default 30 min).
	 * Destroys the session and forces re-login after inactivity.
	 */
	private function check_session_timeout(): void {
		$timeout = defined('SESSION_TIMEOUT') ? SESSION_TIMEOUT : 1800;
		if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout) {
			$this->logout();
			return;
		}
		$_SESSION['LAST_ACTIVITY'] = time();
	}


	/**
	 * @return bool
	 */
	public function isUserLoggedIn() {
		return $this->user_is_logged_in;
	}


	/**
	 * Log in a user by ID. Regenerates session ID to prevent
	 * session fixation attacks.
	 *
	 * @param int $user_id
	 * @param int $org_id
	 */
	public function login(int $user_id, int $org_id): void {
		$_SESSION['user_id']        = $user_id;
		$_SESSION['current_org_id'] = $org_id;
		$_SESSION['LAST_ACTIVITY']  = time();
		session_regenerate_id(true);
	}


	/**
	 *
	 */
	private function userLoginSetup() {
		if (isset($_SESSION['user_id'])) {
			$this->user_is_logged_in = true;
		} else {
			$this->user_is_logged_in = false;
		}

	}


	/**
	 *
	 */
	public function logout() {
		unset($_SESSION['user_id'], $_SESSION['current_org_id'], $_SESSION['LAST_ACTIVITY']);
	}


	/**
	 *
	 * @param string $type (optional)
	 * @param string $msg  (optional)
	 * @return unknown
	 */
	public function msg($type ='', $msg ='') {
		if (!empty($msg)) {
			if (strlen(trim($type)) == 1) {
				$type = str_replace( array('d', 'i', 'w', 's'), array('danger', 'info', 'warning', 'success'), $type );
			}
			$_SESSION['msg'][$type] = $msg;
		} else {
			return $this->msg;
		}
	}


	/**
	 *
	 */
	private function flash_msg() {

		if (isset($_SESSION['msg'])) {
			$this->msg = $_SESSION['msg'];
			unset($_SESSION['msg']);
		} else {
			$this->msg;
		}
	}


}


$session = new Session();
$msg = $session->msg();
