<?php
/**
 * includes/sql_password_reset.php
 *
 * Password reset token creation, validation, and consumption.
 */

/**
 * Create a reset token for the user identified by email or username.
 * Returns the plain 64-char hex token, or null if user not found.
 * Always invalidates prior unused tokens for this user.
 *
 * @param string $identifier Email or username
 * @return string|null The token if created, null if user not found
 */
function create_password_reset(string $identifier): ?string {
    global $db;

    // Find user by email or username
    $row = $db->prepare_select_one(
        "SELECT id FROM users WHERE (email = ? OR username = ?) AND deleted_at IS NULL LIMIT 1",
        'ss', $identifier, $identifier
    );
    if (!$row) {
        return null;
    }

    $uid     = (int) $row['id'];
    $token   = bin2hex(random_bytes(32)); // 64 hex chars
    $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

    // Invalidate any existing unused tokens for this user
    $db->prepare_query(
        "UPDATE password_resets SET used = 1 WHERE user_id = ? AND used = 0",
        'i', $uid
    );

    // Insert new token
    $db->prepare_query(
        "INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)",
        'iss', $uid, $token, $expires
    );

    return $token;
}

/**
 * Validate a reset token. Returns user_id if valid, null otherwise.
 *
 * @param string $token The reset token
 * @return int|null The user_id if valid, null otherwise
 */
function validate_reset_token(string $token): ?int {
    global $db;
    $row = $db->prepare_select_one(
        "SELECT user_id FROM password_resets
          WHERE token = ? AND used = 0 AND expires_at > NOW()
          LIMIT 1",
        's', $token
    );
    return $row ? (int) $row['user_id'] : null;
}

/**
 * Consume a valid token and update the user's password.
 * Returns false if token invalid or already consumed.
 * Password and token-marking are transactional — if either fails, both roll back.
 *
 * @param string $token The reset token
 * @param string $new_password The new plaintext password
 * @return bool True if password updated, false otherwise
 */
function consume_reset_token(string $token, string $new_password): bool {
    global $db;

    $user_id = validate_reset_token($token);
    if (!$user_id) {
        return false;
    }

    $hash = password_hash($new_password, PASSWORD_BCRYPT);
    $conn = $db->connection();

    $conn->begin_transaction();
    try {
        // Update password
        $db->prepare_query(
            "UPDATE users SET password = ? WHERE id = ?",
            'si', $hash, $user_id
        );

        // Mark token as used
        $db->prepare_query(
            "UPDATE password_resets SET used = 1 WHERE token = ?",
            's', $token
        );

        $conn->commit();
        return true;
    } catch (\Throwable $e) {
        $conn->rollback();
        error_log('consume_reset_token() failed: ' . $e->getMessage());
        return false;
    }
}
