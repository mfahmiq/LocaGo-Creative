<?php
/**
 * includes/sql.php
 *
 * @package default
 */

// Constants must be defined before require_once 'load.php' because load.php
// can call prune_failed_logins() and page_require_level() via audit hooks,
// which reference these constants before the rest of this file has loaded.
if (!defined('ROLE_ADMIN')) {
	define('ROLE_ADMIN',      1); // group_level 1 = Admin (bypasses org-membership checks)
	define('ROLE_SUPERVISOR', 2); // group_level 2 = Supervisor
	define('ROLE_USER',       3); // group_level 3 = User (any logged-in account)
}
if (!defined('LOGIN_MAX_ATTEMPTS')) {
	define('LOGIN_MAX_ATTEMPTS', 5);
}
if (!defined('LOGIN_WINDOW_SECONDS')) {
	define('LOGIN_WINDOW_SECONDS', 900); // 15 minutes
}

require_once 'load.php';

/*--------------------------------------------------------------*/
/* Function for find all database table rows by table name
/*--------------------------------------------------------------*/


/**
 *
 * @param unknown $table
 * @return unknown
 */
function find_all(string $table): ?array {
	global $db;
	if (!tableExists($table)) {
		return null;
	}
	$where  = [];
	$params = [];
	$types  = '';

	if (table_has_org_id($table) && isset($_SESSION['current_org_id'])) {
		$where[]  = 'org_id = ?';
		$params[] = current_org_id();
		$types   .= 'i';
	}
	if (table_has_soft_delete($table)) {
		$where[] = 'deleted_at IS NULL';
	}

	$sql = 'SELECT * FROM ' . $db->escape($table);
	if ($where) {
		$sql .= ' WHERE ' . implode(' AND ', $where);
	}

	if ($params) {
		return $db->prepare_select($sql, $types, ...$params);
	}
	return find_by_sql($sql);
}


/*--------------------------------------------------------------*/
/* Function for Perform queries (legacy — still used internally for complex joins.
/* New queries with user input must use prepare_select() instead)
/*--------------------------------------------------------------*/


/**
 *
 * @param unknown $sql
 * @return unknown
 */
function find_by_sql($sql) {
	global $db;
	$result = $db->query($sql);
	$result_set = $db->while_loop($result);
	return $result_set;
}


/*--------------------------------------------------------------*/
/*  Function for Find data from table by id
/*--------------------------------------------------------------*/


/**
 *
 * @param unknown $table
 * @param unknown $id
 * @return unknown
 */
function find_by_id($table, $id): ?array {
	global $db;
	if (!tableExists($table)) {
		return null;
	}
	$id = (int)$id;
	$where  = 'WHERE id = ?';
	$params = [$id];
	$types  = 'i';

	if (table_has_org_id($table) && isset($_SESSION['current_org_id'])) {
		$where   .= ' AND org_id = ?';
		$params[] = current_org_id();
		$types   .= 'i';
	}
	if (table_has_soft_delete($table)) {
		$where .= ' AND deleted_at IS NULL';
	}

	return $db->prepare_select_one(
		'SELECT * FROM ' . $db->escape($table) . " {$where} LIMIT 1",
		$types,
		...$params
	);
}


/*--------------------------------------------------------------*/
/*  Function for Find data from table by name
/*--------------------------------------------------------------*/


/**
 *
 * @param unknown $table
 * @param unknown $name
 * @return unknown
 */
function find_by_name($table, $name) {
	global $db;
	if (tableExists($table)) {
		return $db->prepare_select_one(
			"SELECT * FROM {$db->escape($table)} WHERE name = ? LIMIT 1",
			"s", $name
		);
	}
	return null;
}


/*--------------------------------------------------------------*/
/* Function for Delete data from table by id
/*--------------------------------------------------------------*/


/**
 *
 * @param unknown $table
 * @param unknown $id
 * @return unknown
 */
function delete_by_id($table, $id) {
	global $db;
	if (tableExists($table)) {
		$id = (int)$id;

		// Add org_id guard for org-scoped tables
		if (table_has_org_id($table)) {
			$stmt = $db->prepare_query(
				"DELETE FROM ".$db->escape($table)." WHERE id = ? AND org_id = ? LIMIT 1",
				"ii", $id, current_org_id()
			);
		} else {
			$stmt = $db->prepare_query(
				"DELETE FROM ".$db->escape($table)." WHERE id = ? LIMIT 1",
				"i", $id
			);
		}

		$affected = $stmt->affected_rows;
		$stmt->close();
		return ($affected === 1);
	}
	return false;
}


/*--------------------------------------------------------------*/
/* Soft-delete helpers (PR: soft-delete pattern, 2026-05-16).
/* In-scope tables: users, customers, sales, orders, stock.
/*--------------------------------------------------------------*/

/**
 * In-scope tables for the soft-delete pattern. Adding a table here is
 * NOT enough to enable soft-delete — the table also needs the
 * `deleted_at` column from the matching 005-009 migration.
 */
const SOFT_DELETE_TABLES = ['users', 'customers', 'sales', 'orders', 'stock'];

/**
 * Returns true when $table is in the in-scope allowlist AND its
 * `deleted_at` column exists. Cached per request. Never throws —
 * a probe failure returns false so the deploy-window fallback works.
 *
 * @param string $table
 * @return bool
 */
function table_has_soft_delete(string $table): bool {
	static $cache = [];
	if (array_key_exists($table, $cache)) {
		return $cache[$table];
	}
	if (!in_array($table, SOFT_DELETE_TABLES, true)) {
		return $cache[$table] = false;
	}
	global $db;
	try {
		$r = $db->connection()->query(
			"SHOW COLUMNS FROM `" . $db->escape($table) . "` LIKE 'deleted_at'"
		);
		$has = ($r !== false && $r->num_rows > 0);
		if ($r) {
			$r->free();
		}
		return $cache[$table] = $has;
	} catch (\Throwable $e) {
		return $cache[$table] = false;
	}
}

/*--------------------------------------------------------------*/
/* Tenancy: org-scoped tables and helpers
/*--------------------------------------------------------------*/

/**
 * In-scope tables for the org-scoping pattern. Adding a table here is
 * NOT enough to enable org-scoping — the table also needs the
 * `org_id` column from the matching 013-019 migration.
 */
const ORG_SCOPED_TABLES = [
	'customers', 'products', 'categories',
	'sales', 'orders', 'stock', 'media',
];

/**
 * Returns true when $table is in the in-scope allowlist AND its
 * `org_id` column exists. Cached per request. Never throws —
 * a probe failure returns false so the deploy-window fallback works.
 *
 * @param string $table
 * @return bool
 */
function table_has_org_id(string $table): bool {
	static $cache = [];
	if (array_key_exists($table, $cache)) {
		return $cache[$table];
	}
	if (!in_array($table, ORG_SCOPED_TABLES, true)) {
		return $cache[$table] = false;
	}
	global $db;
	try {
		$r = $db->connection()->query(
			"SHOW COLUMNS FROM `" . $db->escape($table) . "` LIKE 'org_id'"
		);
		$has = ($r !== false && $r->num_rows > 0);
		if ($r) {
			$r->free();
		}
		return $cache[$table] = $has;
	} catch (\Throwable $e) {
		return $cache[$table] = false;
	}
}

/**
 * Returns the active org_id from the session.
 * Throws RuntimeException when called outside an authenticated session.
 *
 * @return int
 * @throws RuntimeException
 */
function current_org_id(): int {
	if (empty($_SESSION['current_org_id'])) {
		throw new \RuntimeException(
			'current_org_id() called with no active org — session not initialized'
		);
	}
	return (int)$_SESSION['current_org_id'];
}

/**
 * Returns the active org_id if session is set, otherwise returns null.
 * Safe for use in tests and reports that may not have an authenticated session.
 *
 * @return int|null
 */
function current_org_id_safe(): ?int {
	return isset($_SESSION['current_org_id']) ? (int)$_SESSION['current_org_id'] : null;
}

/**
 * Soft-delete a row. Stamps deleted_at = NOW() and deleted_by = actor.
 * No-op when the table is not in scope.
 *
 * @param string $table
 * @param int $id
 * @param int|null $actor_user_id  Defaults to $_SESSION['user_id'].
 * @return bool  True when exactly one row was updated.
 */
function soft_delete_by_id(string $table, int $id, ?int $actor_user_id = null): bool {
	if (!table_has_soft_delete($table)) {
		return false;
	}
	if ($actor_user_id === null) {
		$actor_user_id = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
	}
	global $db;

	// Add org_id guard for org-scoped tables
	if (table_has_org_id($table)) {
		$stmt = $db->prepare_query(
			"UPDATE `" . $db->escape($table) . "`
				SET deleted_at = NOW(), deleted_by = ?
			  WHERE id = ? AND deleted_at IS NULL AND org_id = ? LIMIT 1",
			"iii", $actor_user_id, $id, current_org_id()
		);
	} else {
		$stmt = $db->prepare_query(
			"UPDATE `" . $db->escape($table) . "`
				SET deleted_at = NOW(), deleted_by = ?
			  WHERE id = ? AND deleted_at IS NULL LIMIT 1",
			"ii", $actor_user_id, $id
		);
	}

	$affected = $stmt->affected_rows;
	$stmt->close();
	return ($affected === 1);
}

/**
 * Reverse a soft-delete. Sets both deleted_at and deleted_by to NULL.
 *
 * @param string $table
 * @param int $id
 * @return bool  True when exactly one row was updated.
 */
function restore_by_id(string $table, int $id): bool {
	if (!table_has_soft_delete($table)) {
		return false;
	}
	global $db;

	// Add org_id guard for org-scoped tables
	if (table_has_org_id($table)) {
		$stmt = $db->prepare_query(
			"UPDATE `" . $db->escape($table) . "`
				SET deleted_at = NULL, deleted_by = NULL
			  WHERE id = ? AND deleted_at IS NOT NULL AND org_id = ? LIMIT 1",
			"ii", $id, current_org_id()
		);
	} else {
		$stmt = $db->prepare_query(
			"UPDATE `" . $db->escape($table) . "`
				SET deleted_at = NULL, deleted_by = NULL
			  WHERE id = ? AND deleted_at IS NOT NULL LIMIT 1",
			"i", $id
		);
	}

	$affected = $stmt->affected_rows;
	$stmt->close();
	return ($affected === 1);
}

/**
 * Permanently delete a soft-deleted row. Refuses when the row is still
 * active (deleted_at IS NULL) — must be soft-deleted first.
 *
 * @param string $table
 * @param int $id
 * @return bool  True when one row was removed.
 */
function purge_by_id(string $table, int $id): bool {
	if (!table_has_soft_delete($table)) {
		return false;
	}
	global $db;

	// Add org_id guard for org-scoped tables
	if (table_has_org_id($table)) {
		$stmt = $db->prepare_query(
			"DELETE FROM `" . $db->escape($table) . "`
			  WHERE id = ? AND deleted_at IS NOT NULL AND org_id = ? LIMIT 1",
			"ii", $id, current_org_id()
		);
	} else {
		$stmt = $db->prepare_query(
			"DELETE FROM `" . $db->escape($table) . "`
			  WHERE id = ? AND deleted_at IS NOT NULL LIMIT 1",
			"i", $id
		);
	}
	$affected = $stmt->affected_rows;
	$stmt->close();
	return ($affected === 1);
}

/**
 * Same as find_by_id but does NOT filter out soft-deleted rows.
 * For the trash UI and audit lookups.
 *
 * @param string $table
 * @param int $id
 * @return array|null
 */
function find_by_id_with_deleted(string $table, int $id): ?array {
	global $db;
	if (!tableExists($table)) {
		return null;
	}
	$where  = 'WHERE id = ?';
	$params = [$id];
	$types  = 'i';

	if (table_has_org_id($table) && isset($_SESSION['current_org_id'])) {
		$where   .= ' AND org_id = ?';
		$params[] = current_org_id();
		$types   .= 'i';
	}
	// Note: intentionally do NOT filter deleted_at — that's the purpose of this function

	return $db->prepare_select_one(
		'SELECT * FROM ' . $db->escape($table) . " {$where} LIMIT 1",
		$types,
		...$params
	);
}

/**
 * Same as find_all but does NOT filter out soft-deleted rows.
 * For the trash UI and audit/export lookups.
 *
 * @param string $table
 * @return array|null
 */
function find_with_deleted(string $table): ?array {
	global $db;
	if (!tableExists($table)) {
		return null;
	}
	return find_by_sql("SELECT * FROM " . $db->escape($table));
}


/*--------------------------------------------------------------*/
/* Function for Delete data from table by ip
/*--------------------------------------------------------------*/


/**
 *
 * @param unknown $table
 * @param unknown $remote_ip
 * @return unknown
 */
function delete_by_ip($table, $remote_ip) {
	global $db;
	if (tableExists($table)) {
		$stmt = $db->prepare_query(
			"DELETE FROM ".$db->escape($table)." WHERE remote_ip = ?",
			"s", $remote_ip
		);
		$affected = $stmt->affected_rows;
		$stmt->close();
		return ($affected >= 1);
	}
	return false;
}


/*--------------------------------------------------------------*/
/* Function for Count id  By table name
/*--------------------------------------------------------------*/


/**
 *
 * @param unknown $table
 * @return unknown
 */
function count_by_id($table) {
	global $db;
	if (tableExists($table)) {
		$sql    = "SELECT COUNT(id) AS total FROM ".$db->escape($table);
		$result = $db->query($sql);
		return $db->fetch_assoc($result);
	}
}


/*--------------------------------------------------------------*/
/* Function for last id  By table name
/*--------------------------------------------------------------*/


/**
 *
 * @param unknown $table
 * @return unknown
 */
function last_id($table) {
	global $db;
	if (tableExists($table)) {
		$sql    = "SELECT id FROM ".$db->escape($table) . " ORDER BY id DESC LIMIT 1";
		$result = $db->query($sql);
		return $db->fetch_assoc($result);
	}
}


/*--------------------------------------------------------------*/
/* Determine if database table exists
/*--------------------------------------------------------------*/


/**
 *
 * @param unknown $table
 * @return unknown
 */
function tableExists($table) {
	global $db;
	$table_exit = $db->query('SHOW TABLES FROM '.DB_NAME.' LIKE "'.$db->escape($table).'"');
	if ($table_exit) {
		if ($db->num_rows($table_exit) > 0)
			return true;
		else
			return false;
	}
}


/*--------------------------------------------------------------*/
/* Login with the data provided in $_POST,
 /* coming from the login form.
/*--------------------------------------------------------------*/


/**
 * Resolves which org_id to use at login for a given user.
 * Returns org_id (int) or false if user has no accessible org.
 *
 * Resolution order:
 * 1. last_active_org_id if set and membership exists for a live org
 * 2. Oldest membership by joined_at for a live (non-soft-deleted) org
 * 3. false — user has no org access
 */
function resolve_login_org(int $user_id, ?int $last_active_org_id): int|false {
	global $db;
	if ($last_active_org_id !== null) {
		$row = $db->prepare_select_one(
			"SELECT m.org_id FROM org_members m
			   JOIN orgs o ON o.id = m.org_id
			  WHERE m.user_id = ? AND m.org_id = ? AND o.deleted_at IS NULL",
			'ii', $user_id, $last_active_org_id
		);
		if ($row) {
			return (int)$row['org_id'];
		}
	}
	$row = $db->prepare_select_one(
		"SELECT m.org_id FROM org_members m
		   JOIN orgs o ON o.id = m.org_id
		  WHERE m.user_id = ? AND o.deleted_at IS NULL
		  ORDER BY m.joined_at ASC LIMIT 1",
		'i', $user_id
	);
	return $row ? (int)$row['org_id'] : false;
}


/**
 * Find all members of an organization with user details.
 *
 * @param int $org_id
 * @return array  Array of member records, each with id, name, username, email, status, role, joined_at
 */
function find_org_members(int $org_id): array {
	global $db;
	$rows = $db->prepare_select(
		"SELECT u.id, u.name, u.username, u.email, u.status,
		        m.role, m.joined_at
		   FROM org_members m
		   JOIN users u ON u.id = m.user_id
		  WHERE m.org_id = ?
		  ORDER BY FIELD(m.role,'owner','admin','member'), u.name",
		'i', $org_id
	);
	return $rows ?? [];
}


/**
 * Validate that the current user is a member of the current org with required role(s).
 * ROLE_ADMIN bypasses this check.
 *
 * @param string ...$roles  One or more roles to check (e.g., 'owner', 'admin', 'member')
 * @return void  Exits with 403 if user is not a member or lacks required role
 */
function require_org_role(string ...$roles): void {
	global $db;
	$org_id = current_org_id();
	$user_id = (int)($_SESSION['user_id'] ?? 0);
	if (!$user_id) {
		http_response_code(403);
		exit('Forbidden');
	}
	// ROLE_ADMIN bypasses org-role checks
	$user = $db->prepare_select_one(
		"SELECT user_level FROM users WHERE id = ?",
		'i', $user_id
	);
	if ($user && (int)$user['user_level'] === ROLE_ADMIN) {
		return;
	}
	if (empty($roles)) {
		$row = $db->prepare_select_one(
			"SELECT role FROM org_members WHERE user_id = ? AND org_id = ?",
			'ii', $user_id, $org_id
		);
	} else {
		$placeholders = implode(',', array_fill(0, count($roles), '?'));
		$types = 'ii' . str_repeat('s', count($roles));
		$args = array_merge([$user_id, $org_id], $roles);
		$row = $db->prepare_select_one(
			"SELECT role FROM org_members WHERE user_id = ? AND org_id = ? AND role IN ($placeholders)",
			$types, ...$args
		);
	}
	if (!$row) {
		http_response_code(403);
		exit('Forbidden');
	}
}


/**
 * Authenticate a user by username and password.
 * Supports legacy SHA1 hashes and modern bcrypt hashes. Automatic rehash
 * on login: SHA1 → bcrypt on first login after migration, and bcrypt →
 * bcrypt if cost factor changes (password_needs_rehash).
 *
 * @param string $username
 * @param string $password
 * @return array|false  ['user_id' => int, 'org_id' => int] on success, false on failure
 */
function authenticate($username='', $password='') {
	global $db;
	$sql  = "SELECT id,username,password,user_level,last_active_org_id FROM users WHERE username = ? AND deleted_at IS NULL LIMIT 1";
	$result = $db->prepare_select_one($sql, "s", $username);

	if ($result) {
		$stored_hash = $result['password'];

		// Check if stored hash is a legacy SHA1 hash (40-char hex string)
		if (strlen($stored_hash) === 40 && ctype_xdigit($stored_hash)) {
			// Legacy SHA1 comparison — hash_equals prevents timing attacks
			if (hash_equals($stored_hash, sha1($password))) {
				// Rehash with bcrypt for future logins
				$new_hash = password_hash($password, PASSWORD_BCRYPT);
				$db->prepare_query(
					"UPDATE users SET password = ? WHERE id = ?",
					"si", $new_hash, $result['id']
				);
				$org_id = resolve_login_org((int)$result['id'], isset($result['last_active_org_id']) ? (int)$result['last_active_org_id'] : null);
				if ($org_id === false) {
					return false;
				}
				return ['user_id' => (int)$result['id'], 'org_id' => $org_id];
			}
		} else {
			// Modern bcrypt comparison
			if (password_verify($password, $stored_hash)) {
				// Check if hash needs rehash (cost factor change, etc.)
				if (password_needs_rehash($stored_hash, PASSWORD_BCRYPT)) {
					$new_hash = password_hash($password, PASSWORD_BCRYPT);
					$db->prepare_query(
						"UPDATE users SET password = ? WHERE id = ?",
						"si", $new_hash, $result['id']
					);
				}
				$org_id = resolve_login_org((int)$result['id'], isset($result['last_active_org_id']) ? (int)$result['last_active_org_id'] : null);
				if ($org_id === false) {
					return false;
				}
				return ['user_id' => (int)$result['id'], 'org_id' => $org_id];
			}
		}
	}
	return false;
}


/*--------------------------------------------------------------*/
/* Find current log in user by session id
  /*--------------------------------------------------------------*/


/**
 *
 * @return unknown
 */
function current_user() {
	static $current_user;
	global $db;
	if (!$current_user) {
		if (isset($_SESSION['user_id'])):
			$user_id = intval($_SESSION['user_id']);
			$current_user = find_by_id('users', $user_id);
		endif;
	}
	return $current_user;
}


/*--------------------------------------------------------------*/
/* Find all user by
  /* Joining users table and user gropus table
  /*--------------------------------------------------------------*/


/**
 *
 * @return unknown
 */
function find_all_user() {
	global $db;
	$sql = "SELECT u.id,u.name,u.username,u.user_level,u.status,u.last_login,";
	$sql .="g.group_name ";
	$sql .="FROM users u ";
	$sql .="LEFT JOIN user_groups g ";
	$sql .="ON g.group_level=u.user_level ";
	$sql .="WHERE u.deleted_at IS NULL ";
	$sql .="ORDER BY u.name ASC";
	return find_by_sql($sql);
}


/*--------------------------------------------------------------*/
/* Function to update the last log in of a user
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $user_id
 * @return unknown
 */
function updateLastLogIn($user_id) {
	global $db;
	$date = make_date();
	$stmt = $db->prepare_query(
		"UPDATE users SET last_login = ? WHERE id = ? LIMIT 1",
		"si", $date, $user_id
	);
	$affected = $stmt->affected_rows;
	$stmt->close();
	return ($affected === 1);
}


/*--------------------------------------------------------------*/
/* Function to log the action of a user
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $user_id
 * @param unknown $remote_ip
 * @param unknown $action
 * @return unknown
 */
function logAction($user_id, $remote_ip, $action) {
	global $db;
	$date = make_date();
	// Anonymous hits (no session yet) insert NULL so the fk_log_user FK
	// is satisfied. Branching the SQL is more portable across mysqli
	// versions than relying on bind_param to translate PHP null on an
	// "i"-typed parameter.
	if (!$user_id) {
		$stmt = $db->prepare_query(
			"INSERT INTO log (remote_ip, action, date) VALUES (?, ?, ?)",
			"sss", $remote_ip, $action, $date
		);
	} else {
		$stmt = $db->prepare_query(
			"INSERT INTO log (user_id, remote_ip, action, date) VALUES (?, ?, ?, ?)",
			"isss", $user_id, $remote_ip, $action, $date
		);
	}
	$affected = $stmt->affected_rows;
	$stmt->close();
	return ($affected === 1);
}


/*--------------------------------------------------------------*/
/* Find all Group name
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $val
 * @return unknown
 */
function find_by_groupName($val) {
	global $db;
	$sql = "SELECT group_name FROM user_groups WHERE group_name = ? LIMIT 1";
	$result = $db->prepare_select($sql, "s", $val);
	return count($result) === 0;
}


/*--------------------------------------------------------------*/
/* Find group level
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $level
 * @return unknown
 */
function find_by_groupLevel($level) {
	global $db;
	$sql = "SELECT group_status FROM user_groups WHERE group_level = ? LIMIT 1";
	return $db->prepare_select_one($sql, "i", (int)$level);
}


/*--------------------------------------------------------------*/
/* Function for cheaking which user level has access to page
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $require_level
 * @return unknown
 */
function page_require_level($require_level) {
	global $session;
	$current_user = current_user();
	$login_level = find_by_groupLevel($current_user['user_level']);
	//if user not login
	if (!$session->isUserLoggedIn()):
		$session->msg('d', 'Please login...');
		redirect('index.php', false);
	// Disabled-account / disabled-group enforcement.
	// mysqli returns INT columns as int on PHP 8.1+, so compare as int.
	elseif ((int)$current_user['status'] === 0):
		$session->msg('d', 'Your account has been disabled!');
		redirect('../users/home.php', false);
	elseif ((int)$login_level['group_status'] === 0):
		$session->msg('d', 'Your group has been disabled!');
		redirect('../users/home.php', false);
	//cheackin log in User level and Require level is Less than or equal to
	elseif ($current_user['user_level'] <= (int)$require_level):
		// Validate org membership: if session has current_org_id, ensure
		// user is actually a member. ROLE_ADMIN bypasses this check.
		if (isset($_SESSION['current_org_id']) && (int)$current_user['user_level'] !== ROLE_ADMIN) {
			global $db;
			$row = $db->prepare_select_one(
				"SELECT 1 FROM org_members WHERE user_id = ? AND org_id = ?",
				'ii', (int)$current_user['id'], (int)$_SESSION['current_org_id']
			);
			if (!$row) {
				unset($_SESSION['current_org_id']);
				$session->msg("d", "You do not have access to that organization.");
				redirect('../users/home.php', false);
			}
		}
		return true;
	else:
		$session->msg("d", "Sorry! you dont have permission to view the page.");
		redirect('../users/home.php', false);
	endif;

}


/*--------------------------------------------------------------*/
/* Function for Finding all product name
   /* JOIN with category  and media database table
   /*--------------------------------------------------------------*/


/**
 *
 * @return unknown
 */
function join_product_table() {
	global $db;
	$sql  =" SELECT p.id,p.name,p.sku,p.location,p.quantity,p.buy_price,p.sale_price,p.media_id,p.date,c.name";
	$sql  .=" AS category,m.file_name AS image";
	$sql  .=" FROM products p";
	$sql  .=" LEFT JOIN categories c ON c.id = p.category_id";
	$sql  .=" LEFT JOIN media m ON m.id = p.media_id";
	$sql  .=" WHERE p.deleted_at IS NULL";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		$sql .= " AND p.org_id = " . $org_id;
	}
	$sql  .=" ORDER BY p.id ASC";
	return find_by_sql($sql);
}


/*--------------------------------------------------------------*/
/* Function for Finding all product name
  /* Request coming from ajax.php for auto suggest
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $product_name
 * @return unknown
 */
function find_product_by_title($product_name) {
	global $db;
	$p_name = remove_junk($db->escape($product_name));
	$search = "%{$p_name}%";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		return $db->prepare_select(
			"SELECT name FROM products WHERE name LIKE ? AND org_id = ? LIMIT 5",
			"si", $search, $org_id
		);
	}
	return $db->prepare_select(
		"SELECT name FROM products WHERE name LIKE ? LIMIT 5",
		"s", $search
	);
}


/*--------------------------------------------------------------*/
/* Function for Finding all product info by product title
  /* Request coming from ajax.php
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $title
 * @return unknown
 */
function find_all_product_info_by_title($title) {
	global $db;
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		return $db->prepare_select(
			"SELECT * FROM products WHERE name = ? AND org_id = ? LIMIT 1",
			"si", $title, $org_id
		);
	}
	return $db->prepare_select(
		"SELECT * FROM products WHERE name = ? LIMIT 1",
		"s", $title
	);
}


/*--------------------------------------------------------------*/
/* Function for Finding all product name
  /* Request coming from ajax_sku.php for auto suggest
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $product_sku
 * @return unknown
 */
function find_product_by_sku($product_sku) {
	global $db;
	$search = "%{$product_sku}%";
	return $db->prepare_select(
		"SELECT sku FROM products WHERE sku LIKE ? AND org_id = ? LIMIT 5",
		"si", $search, current_org_id_safe()
	);
}


/*--------------------------------------------------------------*/
/* Function for Finding all product info by product title
  /* Request coming from ajax_sku.php
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $product_sku
 * @return unknown
 */
function find_all_product_info_by_sku($product_sku) {
	global $db;
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		return $db->prepare_select(
			"SELECT * FROM products WHERE sku = ? AND org_id = ? LIMIT 1",
			"si", $product_sku, $org_id
		);
	}
	return $db->prepare_select(
		"SELECT * FROM products WHERE sku = ? LIMIT 1",
		"s", $product_sku
	);
}


/*--------------------------------------------------------------*/
/* Function for Finding by customer name
  /* Request coming from ajax_customer.php for auto suggest
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $customer_name
 * @return unknown
 */
function find_customer_by_name($customer_name) {
	global $db;
	$customer = remove_junk($db->escape($customer_name));
	$search = "%{$customer}%";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		return $db->prepare_select(
			"SELECT name FROM customers WHERE name LIKE ? AND deleted_at IS NULL AND org_id = ? LIMIT 5",
			"si", $search, $org_id
		);
	}
	return $db->prepare_select(
		"SELECT name FROM customers WHERE name LIKE ? AND deleted_at IS NULL LIMIT 5",
		"s", $search
	);
}


/*--------------------------------------------------------------*/
/* Function for Finding all product info by product title
  /* Request coming from ajax_customer.php
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $customer_name
 * @return unknown
 */
function find_all_customer_info_by_name($customer_name) {
	global $db;
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		return $db->prepare_select(
			"SELECT * FROM customers WHERE name = ? AND deleted_at IS NULL AND org_id = ? LIMIT 1",
			"si", $customer_name, $org_id
		);
	}
	return $db->prepare_select(
		"SELECT * FROM customers WHERE name = ? AND deleted_at IS NULL LIMIT 1",
		"s", $customer_name
	);
}


/*--------------------------------------------------------------*/
/* Function for Finding all product search
  /* Request coming from ajax_product.php for auto suggest
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $product_search
 * @return unknown
 */
function find_products_by_search($product_search) {
	global $db;
	$p_search = remove_junk($db->escape($product_search));
	$search = "%{$p_search}%";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		return $db->prepare_select(
			"SELECT * FROM products WHERE (name LIKE ? OR sku LIKE ? OR description LIKE ?) AND deleted_at IS NULL AND org_id = ? LIMIT 5",
			"sssi", $search, $search, $search, $org_id
		);
	}
	return $db->prepare_select(
		"SELECT * FROM products WHERE (name LIKE ? OR sku LIKE ? OR description LIKE ?) AND deleted_at IS NULL LIMIT 5",
		"sss", $search, $search, $search
	);
}


/*--------------------------------------------------------------*/
/* Function for Finding all product info by product search
  /* Request coming from ajax_product.php
  /*--------------------------------------------------------------*/


function find_all_product_info_by_search($search) {
	global $db;
	$p_search = remove_junk($db->escape($search));
	$like = "%{$p_search}%";
	$org_id = (int)(current_org_id_safe() ?? 0);

	$sql  = " SELECT p.id,p.name,p.sku,p.location,p.quantity,p.buy_price,p.sale_price,p.media_id,p.date,c.name";
	$sql .= " AS category,m.file_name AS image";
	$sql .= " FROM products p";
	$sql .= " LEFT JOIN categories c ON c.id = p.category_id";
	$sql .= " LEFT JOIN media m ON m.id = p.media_id";
	$sql .= " WHERE p.deleted_at IS NULL AND (p.name LIKE ? OR p.sku LIKE ? OR p.description LIKE ?) AND p.org_id = ?";
	$sql .= " ORDER BY p.id ASC";

	return $db->prepare_select($sql, "sssi", $like, $like, $like, $org_id);
}


/*--------------------------------------------------------------*/
/* Function for Finding all product by category
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $cat
 * @return unknown
 */
function find_products_by_category($cat) {
	global $db;
	$sql  =" SELECT p.id,p.name,p.sku,p.location,p.quantity,p.buy_price,p.sale_price,p.media_id,p.date,c.name";
	$sql  .=" AS category,m.file_name AS image";
	$sql  .=" FROM products p";
	$sql  .=" LEFT JOIN categories c ON c.id = p.category_id";
	$sql  .=" LEFT JOIN media m ON m.id = p.media_id";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		$sql  .=" WHERE p.deleted_at IS NULL AND c.id = ? AND p.org_id = ?";
	} else {
		$sql  .=" WHERE p.deleted_at IS NULL AND c.id = ?";
	}
	$sql  .=" ORDER BY p.id ASC";
	if ($org_id !== null) {
		return $db->prepare_select($sql, "ii", (int)$cat, $org_id);
	}
	return $db->prepare_select($sql, "i", (int)$cat);
}


/*--------------------------------------------------------------*/
/* Function for Increase product quantity
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $qty
 * @param unknown $p_id
 * @return unknown
 */
function increase_product_qty($qty, $p_id) {
	global $db;
	$qty = (int) $qty;
	$id  = (int) $p_id;
	$stmt = $db->prepare_query(
		"UPDATE products SET quantity = quantity + ? WHERE id = ? AND org_id = ?",
		"iii", $qty, $id, current_org_id()
	);
	$affected = $stmt->affected_rows;
	$stmt->close();
	return ($affected === 1);
}


/*--------------------------------------------------------------*/
/* Function for Decrease product quantity
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $qty
 * @param unknown $p_id
 * @return unknown
 */
function decrease_product_qty($qty, $p_id) {
	global $db;
	$qty = (int) $qty;
	$id  = (int) $p_id;
	$stmt = $db->prepare_query(
		"UPDATE products SET quantity = quantity - ? WHERE id = ? AND org_id = ?",
		"iii", $qty, $id, current_org_id()
	);
	$affected = $stmt->affected_rows;
	$stmt->close();
	return ($affected === 1);
}


/*--------------------------------------------------------------*/
/* Function for Display Recent product Added
  /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $limit
 * @return unknown
 */
function find_recent_product_added($limit) {
	global $db;
	$sql   = " SELECT p.id,p.name,p.sale_price,p.media_id,c.name AS category,";
	$sql  .= "m.file_name AS image FROM products p";
	$sql  .= " LEFT JOIN categories c ON c.id = p.category_id";
	$sql  .= " LEFT JOIN media m ON m.id = p.media_id";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		$sql  .= " WHERE p.deleted_at IS NULL AND p.org_id = " . $org_id;
	} else {
		$sql  .= " WHERE p.deleted_at IS NULL";
	}
	$sql  .= " ORDER BY p.id DESC LIMIT ".$db->escape((int)$limit);
	return find_by_sql($sql);
}


/*--------------------------------------------------------------*/
/* Function for Find Highest selling Product
 /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $limit
 * @return unknown
 */
function find_highest_selling_product($limit) {
	global $db;
	$sql  = "SELECT p.name, COUNT(s.product_id) AS totalSold, SUM(s.qty) AS totalQty";
	$sql .= " FROM sales s";
	$sql .= " LEFT JOIN products p ON p.id = s.product_id ";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		$sql .= " WHERE s.deleted_at IS NULL AND p.org_id = " . $org_id;
	} else {
		$sql .= " WHERE s.deleted_at IS NULL";
	}
	$sql .= " GROUP BY s.product_id";
	$sql .= " ORDER BY SUM(s.qty) DESC LIMIT ".$db->escape((int)$limit);
	return $db->query($sql);
}


/*--------------------------------------------------------------*/
/* Function for find all sales
 /*--------------------------------------------------------------*/


/**
 *
 * @return unknown
 */
function find_all_sales() {
	global $db;
	$sql  = "SELECT s.id,s.order_id,s.qty,s.price,s.date,p.name";
	$sql .= " FROM sales s";
	$sql .= " LEFT JOIN orders o ON s.order_id = o.id";
	$sql .= " LEFT JOIN products p ON s.product_id = p.id";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		$sql .= " WHERE s.deleted_at IS NULL AND p.org_id = " . $org_id;
	} else {
		$sql .= " WHERE s.deleted_at IS NULL";
	}
	$sql .= " ORDER BY s.date DESC";
	return find_by_sql($sql);
}


/*--------------------------------------------------------------*/
/* Function for find all orders
 /*--------------------------------------------------------------*/


/**
 *
 * @return unknown
 */
function find_all_orders() {
	global $db;
	$sql  = "SELECT o.id,o.sales_id,o.date";
	$sql .= " FROM orders o";
	$sql .= " LEFT JOIN sales s ON s.id = o.sales_id";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		$sql .= " WHERE o.deleted_at IS NULL AND o.org_id = " . $org_id;
	} else {
		$sql .= " WHERE o.deleted_at IS NULL";
	}
	$sql .= " ORDER BY o.date DESC";
	return find_by_sql($sql);
}


/*--------------------------------------------------------------*/
/* Function for find sales by order_id
 /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $id
 * @return unknown
 */
function find_sales_by_order_id($id) {
	global $db;
	$sql  = "SELECT s.id,s.product_id,s.qty,s.price,s.date,p.name,p.sku,p.location";
	$sql .= " FROM sales s";
	$sql .= " LEFT JOIN orders o ON s.order_id = o.id";
	$sql .= " LEFT JOIN products p ON s.product_id = p.id";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		$sql .= " WHERE s.order_id = ? AND s.deleted_at IS NULL AND p.org_id = ?";
		$sql .= " ORDER BY s.date DESC";
		return $db->prepare_select($sql, "ii", (int)$id, $org_id);
	}
	$sql .= " WHERE s.order_id = ? AND s.deleted_at IS NULL";
	$sql .= " ORDER BY s.date DESC";
	return $db->prepare_select($sql, "i", (int)$id);
}




/*--------------------------------------------------------------*/
/* Function for Display Recent sale
 /*--------------------------------------------------------------*/


/**
 *
 * @param unknown $limit
 * @return unknown
 */
function find_recent_sale_added($limit) {
	global $db;
	$sql  = "SELECT s.id,s.qty,s.price,s.date,p.name";
	$sql .= " FROM sales s";
	$sql .= " LEFT JOIN products p ON s.product_id = p.id";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		$sql .= " WHERE s.deleted_at IS NULL AND p.org_id = " . $org_id;
	} else {
		$sql .= " WHERE s.deleted_at IS NULL";
	}
	$sql .= " ORDER BY s.date DESC LIMIT ".$db->escape((int)$limit);
	return find_by_sql($sql);
}


/*--------------------------------------------------------------*/
/* Function for Generate sales report by two dates
/*--------------------------------------------------------------*/


/**
 *
 * @param unknown $start_date
 * @param unknown $end_date
 * @return unknown
 */
function find_sale_by_dates($start_date, $end_date) {
	global $db;
	$start_date  = date("Y-m-d", strtotime($start_date));
	$end_date    = date("Y-m-d", strtotime($end_date));
	$sql  = "SELECT s.date, p.name,p.sale_price,p.buy_price,";
	$sql .= "COUNT(s.product_id) AS total_records,";
	$sql .= "SUM(s.qty) AS total_sales,";
	$sql .= "SUM(p.sale_price * s.qty) AS total_selling_price,";
	$sql .= "SUM(p.buy_price * s.qty) AS total_buying_price ";
	$sql .= "FROM sales s ";
	$sql .= "LEFT JOIN products p ON s.product_id = p.id";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		$sql .= " WHERE s.date BETWEEN ? AND ? AND s.deleted_at IS NULL AND p.org_id = ?";
		$sql .= " GROUP BY DATE(s.date),p.name";
		$sql .= " ORDER BY DATE(s.date) DESC";
		return $db->prepare_select($sql, "ssi", $start_date, $end_date, $org_id);
	}
	$sql .= " WHERE s.date BETWEEN ? AND ? AND s.deleted_at IS NULL";
	$sql .= " GROUP BY DATE(s.date),p.name";
	$sql .= " ORDER BY DATE(s.date) DESC";
	return $db->prepare_select($sql, "ss", $start_date, $end_date);
}


/*--------------------------------------------------------------*/
/* Function for Generate Daily sales report
/*--------------------------------------------------------------*/


/**
 *
 * @param unknown $year
 * @param unknown $month
 * @return unknown
 */
function dailySales($year, $month) {
	global $db;
	$year_month = "{$year}-{$month}";
	$sql  = "SELECT s.qty,";
	$sql .= " DATE_FORMAT(s.date, '%Y-%m-%e') AS date,p.name,";
	$sql .= "SUM(p.sale_price * s.qty) AS total_selling_price";
	$sql .= " FROM sales s";
	$sql .= " LEFT JOIN products p ON s.product_id = p.id";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		$sql .= " WHERE DATE_FORMAT(s.date, '%Y-%m' ) = ? AND s.deleted_at IS NULL AND p.org_id = ?";
		$sql .= " GROUP BY DATE_FORMAT( s.date,  '%e' ),s.product_id";
		return $db->prepare_select($sql, "si", $year_month, $org_id);
	}
	$sql .= " WHERE DATE_FORMAT(s.date, '%Y-%m' ) = ? AND s.deleted_at IS NULL";
	$sql .= " GROUP BY DATE_FORMAT( s.date,  '%e' ),s.product_id";
	return $db->prepare_select($sql, "s", $year_month);
}


/*--------------------------------------------------------------*/
/* Function for Generate Monthly sales report
/*--------------------------------------------------------------*/


/**
 *
 * @param unknown $year
 * @return unknown
 */
function monthlySales($year) {
	global $db;
	$sql  = "SELECT s.qty,";
	$sql .= " DATE_FORMAT(s.date, '%Y-%m-%e') AS date,p.name,";
	$sql .= "SUM(p.sale_price * s.qty) AS total_selling_price";
	$sql .= " FROM sales s";
	$sql .= " LEFT JOIN products p ON s.product_id = p.id";
	$org_id = current_org_id_safe();
	if ($org_id !== null) {
		$sql .= " WHERE DATE_FORMAT(s.date, '%Y' ) = ? AND s.deleted_at IS NULL AND p.org_id = ?";
		$sql .= " GROUP BY DATE_FORMAT( s.date,  '%c' ),s.product_id";
		$sql .= " ORDER BY date_format(s.date, '%c' ) ASC";
		return $db->prepare_select($sql, "si", $year, $org_id);
	}
	$sql .= " WHERE DATE_FORMAT(s.date, '%Y' ) = ? AND s.deleted_at IS NULL";
	$sql .= " GROUP BY DATE_FORMAT( s.date,  '%c' ),s.product_id";
	$sql .= " ORDER BY date_format(s.date, '%c' ) ASC";
	return $db->prepare_select($sql, "s", $year);
}


/*--------------------------------------------------------------*/
/* Org-management helpers
/*--------------------------------------------------------------*/

function find_all_orgs(): array
{
	global $db;
	return $db->prepare_select(
		"SELECT id, name, slug, deleted_at FROM orgs ORDER BY name",
		''
	);
}

function find_org_by_id(int $id): ?array
{
	global $db;
	return $db->prepare_select_one(
		"SELECT id, name, slug, deleted_at FROM orgs WHERE id = ?",
		'i', $id
	);
}

/**
 * Returns non-deleted org memberships for a user: [['org_id'=>N,'name'=>'...'],...]
 */
function find_org_memberships(int $user_id): array
{
	global $db;
	return $db->prepare_select(
		"SELECT o.id AS org_id, o.name
		   FROM org_members m
		   JOIN orgs o ON o.id = m.org_id
		  WHERE m.user_id = ? AND o.deleted_at IS NULL
		  ORDER BY o.name",
		'i', $user_id
	);
}

/**
 * Creates a new org and auto-enrolls the creator as owner.
 * Returns the new org_id or false on failure.
 */
function create_org(string $name, int $creator_user_id): int|false
{
	global $db;
	$slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($name)), '-') ?: 'org';
	$db->prepare_query("INSERT INTO orgs (name, slug) VALUES (?, ?)", 'ss', $name, $slug);
	$org_id = (int)$db->insert_id();
	if (!$org_id) return false;
	// Suffix slug with ID to guarantee uniqueness.
	$db->prepare_query("UPDATE orgs SET slug = ? WHERE id = ?", 'si', $slug . '-' . $org_id, $org_id);
	$db->prepare_query(
		"INSERT INTO org_members (org_id, user_id, role) VALUES (?, ?, 'owner')",
		'ii', $org_id, $creator_user_id
	);
	return $org_id;
}

/**
 * Renames an org. Returns true (failure kills the process via prepare_query).
 */
function rename_org(int $id, string $name): bool
{
	global $db;
	$db->prepare_query(
		"UPDATE orgs SET name = ? WHERE id = ? AND deleted_at IS NULL",
		'si', $name, $id
	);
	return true;
}

/*--------------------------------------------------------------*/
/* Login rate limiting
/*--------------------------------------------------------------*/

/**
 * Count failed logins from the given IP within the rate-limit window.
 *
 * @param string $ip Client IP
 * @return int Number of attempts in the window
 */
function recent_failed_login_count(string $ip): int
{
	global $db;
	$window = LOGIN_WINDOW_SECONDS;
	$rows = $db->prepare_select(
		"SELECT COUNT(*) AS n FROM failed_logins
		 WHERE ip = ? AND attempted_at > (NOW() - INTERVAL ? SECOND)",
		"si", $ip, $window
	);
	return isset($rows[0]['n']) ? (int)$rows[0]['n'] : 0;
}

/**
 * Return true if this IP has exceeded the rate limit and should be blocked.
 */
function is_login_rate_limited(string $ip): bool
{
	return recent_failed_login_count($ip) >= LOGIN_MAX_ATTEMPTS;
}

/**
 * Record a failed login attempt (IP + username attempted).
 */
function record_failed_login(string $ip, string $username_attempted): void
{
	global $db;
	$stmt = $db->prepare_query(
		"INSERT INTO failed_logins (ip, username_attempted, attempted_at)
		 VALUES (?, ?, NOW())",
		"ss", $ip, $username_attempted
	);
	$stmt->close();
}

/**
 * Clear all failed-login records for this IP. Called on successful login.
 */
function clear_failed_logins(string $ip): void
{
	global $db;
	$stmt = $db->prepare_query(
		"DELETE FROM failed_logins WHERE ip = ?",
		"s", $ip
	);
	$stmt->close();
}

/**
 * Prune failed_logins rows older than the rate-limit window.
 * Called probabilistically from load.php on page request — no cron needed.
 * A row older than the window has no effect on rate limiting, so its only
 * value is forensic, and we keep that in the audit log table instead.
 */
function prune_failed_logins(): void
{
	global $db;
	$window = LOGIN_WINDOW_SECONDS;
	$stmt = $db->prepare_query(
		"DELETE FROM failed_logins WHERE attempted_at < (NOW() - INTERVAL ? SECOND)",
		"i", $window
	);
	$stmt->close();
}

/*--------------------------------------------------------------*/
/* Audit log
/*--------------------------------------------------------------*/

/**
 * Record a user action in audit_log.
 *
 * @param string   $module    e.g. 'products', 'users'
 * @param string   $action    create|update|delete|login|logout
 * @param int|null $record_id PK of the affected row (null for login/logout)
 * @param string   $summary   Human-readable description, max 255 chars
 */
function audit(string $module, string $action, ?int $record_id = null, string $summary = ''): void {
	global $db;
	try {
		$user    = current_user();
		$user_id = $user ? (int) $user['id'] : null;
		$ip      = filter_var($_SERVER['REMOTE_ADDR'] ?? '', FILTER_VALIDATE_IP) ?: '';
		$sum     = substr($summary, 0, 255);
		$db->prepare_query(
			"INSERT INTO audit_log (user_id, module, action, record_id, summary, ip_address)
			 VALUES (?, ?, ?, ?, ?, ?)",
			'ississ', $user_id, $module, $action, $record_id, $sum, $ip
		);
	} catch (\Throwable $e) {
		error_log('audit() failed: ' . $e->getMessage());
	}
}

/**
 * Fetch recent audit log entries, newest first.
 */
function find_audit_log(int $limit = 200): array {
	global $db;
	return $db->prepare_select(
		"SELECT al.*, u.name AS user_name, u.username
		   FROM audit_log al
		   LEFT JOIN users u ON u.id = al.user_id
		  ORDER BY al.created_at DESC
		  LIMIT ?",
		'i', $limit
	) ?? [];
}

/*--------------------------------------------------------------*/
/* Per-module permissions (RBAC layer 2)
/*--------------------------------------------------------------*/

/**
 * All grantable modules and their display names.
 */
function permission_modules(): array {
	return [
		'products'   => 'Products',
		'customers'  => 'Customers',
		'sales'      => 'Sales',
		'orders'     => 'Orders',
		'reports'    => 'Reports',
		'stock'      => 'Stock',
		'users'      => 'Users',
		'data_tools' => 'Data Tools',
	];
}

/**
 * Load all permission rows for a user, keyed by module.
 */
function get_user_permissions(int $user_id): array {
	global $db;
	$rows = $db->prepare_select(
		"SELECT module, can_view, can_create, can_edit, can_delete
		   FROM permissions WHERE user_id = ?",
		'i', $user_id
	) ?? [];
	$out = [];
	foreach ($rows as $row) {
		$out[$row['module']] = $row;
	}
	return $out;
}

/**
 * Check if the current user can perform $action on $module.
 * Admins (ROLE_ADMIN) always pass. Falls back to level-based defaults if
 * no explicit permission row exists for this user+module.
 */
function can(string $module, string $action): bool {
	if (!in_array($action, ['view', 'create', 'edit', 'delete'], true)) {
		return false;
	}
	$user = current_user();
	if (!$user) return false;

	$level = (int) $user['user_level'];

	if ($level === ROLE_ADMIN) return true;

	$perms = get_user_permissions((int) $user['id']);
	if (isset($perms[$module])) {
		return (bool) $perms[$module]["can_$action"];
	}

	// Default: supervisors can view+create+edit; regular users view only
	if ($level === ROLE_SUPERVISOR) {
		return in_array($action, ['view', 'create', 'edit'], true);
	}
	return $action === 'view';
}

/**
 * Redirect with error if the current user lacks permission.
 */
function require_permission(string $module, string $action): void {
	global $session;
	if (!can($module, $action)) {
		$session->msg('d', "You do not have permission to $action $module.");
		redirect('home.php', false);
	}
}
