<?php
/**
 * health.php
 * Lightweight health check endpoint returning JSON status.
 * No authentication required — returns only safe operational metadata.
 */

header('Content-Type: application/json');
header('Cache-Control: no-store');

$status  = 'ok';
$checks  = [];

// ---------------------------------------------------------------------------
// 1. Database connectivity
// ---------------------------------------------------------------------------
defined('DS')           || define('DS', DIRECTORY_SEPARATOR);
defined('LIB_PATH_INC') || define('LIB_PATH_INC', __DIR__ . '/includes' . DIRECTORY_SEPARATOR);
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/database.php';

try {
    $db     = new MySqli_DB();
    $result = $db->query("SELECT 1");
    $checks['database'] = $result ? 'ok' : 'error';
    if (!$result) $status = 'degraded';
} catch (\Throwable $e) {
    $checks['database'] = 'error';
    $status = 'degraded';
}

// ---------------------------------------------------------------------------
// 2. Writable directories
// ---------------------------------------------------------------------------
$upload_dirs = [
    'uploads/products' => __DIR__ . '/uploads/products',
    'uploads/users'    => __DIR__ . '/uploads/users',
];
foreach ($upload_dirs as $label => $path) {
    $checks[$label] = is_writable($path) ? 'ok' : 'not_writable';
    if (!is_writable($path)) $status = 'degraded';
}

// ---------------------------------------------------------------------------
// 3. Disk space (warn below 100 MB free)
// ---------------------------------------------------------------------------
$free_bytes = disk_free_space(__DIR__);
$checks['disk_free_mb'] = $free_bytes !== false ? round($free_bytes / 1048576) : null;
if ($free_bytes !== false && $free_bytes < 104857600) {
    $status = 'degraded';
}

// ---------------------------------------------------------------------------
// Response
// ---------------------------------------------------------------------------
$http_code = $status === 'ok' ? 200 : 503;
http_response_code($http_code);

echo json_encode([
    'status'    => $status,
    'timestamp' => gmdate('c'),
    'checks'    => $checks,
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
