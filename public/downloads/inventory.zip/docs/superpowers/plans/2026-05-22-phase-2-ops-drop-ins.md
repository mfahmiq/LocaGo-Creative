# Phase 2 — Ops Drop-Ins Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Port three ops endpoints/cron scripts from `~/cc-inventory` into `~/inventory`: `health.php` (web-accessible JSON health probe), `backup.php` (cron-callable mysqldump backup with admin-gated web access), and `log_rotate.php` (cron-callable log-table pruner). Each ships with a PHPUnit test class that gets added to the strict `phpunit.xml` allowlist.

**Architecture:** All three scripts live at the project root (web-accessible paths preserved). They share inventory's existing `includes/config.php` + `includes/database.php` (MySqli_DB class) and reuse `ROLE_ADMIN` from `includes/sql.php`. `log_rotate.php` is rewritten on port to use inventory's `prepare_query()` wrapper API (not raw mysqli prepare/bind/execute), to skip the missing `audit_log` table, and to target inventory's `failed_logins` table (cc-inventory called it `login_attempts`). Each new test goes into the `phpunit.xml` `<file>` allowlist so directory-discovery doesn't re-execute legacy script top-level code.

**Tech Stack:** PHP 8.2+ CLI/CGI, MySQL/MariaDB via inventory's `MySqli_DB` class, mysqldump system binary, PHPUnit 11.

---

## Spec reference

This plan implements **Phase 2** of `docs/superpowers/specs/2026-05-22-cc-inventory-merge-design.md`. Phase 3 (org-aware crons: `alerts_check.php`, `log_monitor_scan.php`) is a separate plan. Phase 1.5 (converting the remaining 7 legacy tests to PHPUnit) is also separate and unblocked relative to Phase 2.

## Source files (copy by file path from cc-inventory)

When a task says "copy verbatim from cc-inventory", the implementer reads the source from `/home/coreconduit/cc-inventory/<file>` and writes it byte-for-byte to `/home/coreconduit/inventory/<file>`. Do NOT inline the source contents in this plan — the cc-archive remote is also reachable via `git show cc-archive/main:<file>` if direct filesystem access becomes unavailable.

- `/home/coreconduit/cc-inventory/health.php` — 63 LOC, **verbatim** (inventory has the same `MySqli_DB` class and the same `includes/config.php` + `includes/database.php` paths).
- `/home/coreconduit/cc-inventory/backup.php` — 130 LOC, **verbatim** (uses `find_by_id`, `ROLE_ADMIN`, `DB_*` constants that exist in inventory unchanged).
- `/home/coreconduit/cc-inventory/log_rotate.php` — 67 LOC, **rewritten on port** to fit inventory's DB API and schema (see Task C).

## File structure

| File | Action | Responsibility |
|---|---|---|
| `health.php` | create | Web-accessible JSON health probe. No auth. Returns 200 ok / 503 degraded based on DB + writable uploads + free disk. |
| `backup.php` | create | mysqldump + gzip + retention prune. CLI or admin-only web. Writes to `backups/`. |
| `log_rotate.php` | create | Prunes stale rows from `log` and `failed_logins`. CLI or admin-only web. |
| `backups/.htaccess` | create | `Require all denied` — prevents serving backup gz files via Apache. |
| `tests/HealthTest.php` | create | Smoke test invoking `health.php` via include + output capture; asserts JSON shape + 200 status. |
| `tests/BackupTest.php` | create | Tests admin-gate enforcement + config defaults; does NOT actually shell out to the dump binary unless the host has it. |
| `tests/LogRotateTest.php` | create | Seeds a stale `log` row, runs the prune logic, asserts the row is gone. Same for `failed_logins`. |
| `phpunit.xml` | modify | Add `tests/HealthTest.php`, `tests/BackupTest.php`, `tests/LogRotateTest.php` to the `<file>` allowlist. |
| `.env.example` | modify | Document `BACKUP_DIR`, `BACKUP_RETAIN_COUNT`, `LOG_RETAIN_DAYS`. |
| `README.md` | modify | Document `health.php` endpoint, backup cron example, log_rotate cron example. |

`backups/` directory itself is created by `backup.php` on first run; only the `.htaccess` lives in git.

Total estimated PR size: ~700 LOC (production files ~260, tests ~250, docs ~190).

---

## Phase 2.0 — Pre-flight (no PR commits)

### Task 2.0: Branch off main and confirm Phase 1 has landed

**Files:** none — git only.

- [ ] **Step 1: Confirm Phase 1 is merged**

Run:

```bash
cd /home/coreconduit/inventory
git fetch origin
git log origin/main --oneline -3
```

Expected: Phase 1 commits (`composer + PHPUnit`, `wire tests/run.sh`, `add PHPUnit unit gate`, etc.) appear in `origin/main`. If PR #47 hasn't merged yet, STOP — Phase 2 depends on `vendor/bin/phpunit` being installed and on the strict `phpunit.xml` allowlist that Phase 1 introduced.

- [ ] **Step 2: Update main and branch off**

```bash
cd /home/coreconduit/inventory
git checkout main
git pull --ff-only origin main
git checkout -b feature/phase2-ops-drop-ins main
composer install --no-interaction
vendor/bin/phpunit --colors=never
```

Expected: branch created from latest main, `composer install` succeeds, `OK (19 tests, 33 assertions)`.

If PHPUnit reports any failure, STOP — fix the regression on main before continuing.

---

## Phase 2 — Ops drop-ins (PR2, ~700 LOC)

All Task work happens on branch `feature/phase2-ops-drop-ins`. Each Task is one logical commit.

### Task A: Port `health.php` (TDD)

**Files:**
- Create: `tests/HealthTest.php`
- Create: `health.php`
- Modify: `phpunit.xml` (add `<file>tests/HealthTest.php</file>`)

#### A.1 — Write the failing test

- [ ] **Step 1: Create `tests/HealthTest.php`**

Write `/home/coreconduit/inventory/tests/HealthTest.php`:

```php
<?php
/**
 * tests/HealthTest.php
 *
 * Tests health.php: JSON output shape, status determination,
 * HTTP status code via http_response_code() side effect.
 */

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;

class HealthTest extends TestCase
{
    #[Test]
    public function health_endpoint_outputs_json_with_status_and_checks(): void
    {
        $project_root = dirname(__DIR__);
        $health_file  = $project_root . '/health.php';
        $this->assertFileExists($health_file, 'health.php must exist at project root');

        ob_start();
        // Suppress header() warnings — PHPUnit has already sent headers.
        $original_error_reporting = error_reporting();
        error_reporting($original_error_reporting & ~E_WARNING);
        try {
            include $health_file;
        } finally {
            error_reporting($original_error_reporting);
        }
        $output = ob_get_clean();

        $decoded = json_decode($output, true);
        $this->assertIsArray($decoded, 'health.php must emit valid JSON');
        $this->assertArrayHasKey('status', $decoded);
        $this->assertArrayHasKey('timestamp', $decoded);
        $this->assertArrayHasKey('checks', $decoded);
        $this->assertContains($decoded['status'], ['ok', 'degraded'], 'status must be ok or degraded');
    }

    #[Test]
    public function health_checks_include_database_and_disk_free(): void
    {
        $project_root = dirname(__DIR__);
        $health_file  = $project_root . '/health.php';

        ob_start();
        $original_error_reporting = error_reporting();
        error_reporting($original_error_reporting & ~E_WARNING);
        try {
            include $health_file;
        } finally {
            error_reporting($original_error_reporting);
        }
        $output = ob_get_clean();

        $decoded = json_decode($output, true);
        $this->assertArrayHasKey('database', $decoded['checks'], 'database check expected');
        $this->assertArrayHasKey('disk_free_mb', $decoded['checks'], 'disk_free_mb check expected');
        $this->assertContains($decoded['checks']['database'], ['ok', 'error'], 'database check must be ok or error');
    }
}
```

Note the `error_reporting()` dance: when PHPUnit's bootstrap runs, headers have already been sent (PHPUnit emits its own output). `health.php` calls `header('Content-Type: application/json')` which would warn. Suppressing E_WARNING for the include is intentional — we test the JSON body, not the HTTP transport.

- [ ] **Step 2: Add the test to the phpunit.xml allowlist**

Edit `/home/coreconduit/inventory/phpunit.xml`. The current `<testsuites>` block reads:

```xml
<testsuites>
    <testsuite name="Inventory">
        <file>tests/InfraSmokeTest.php</file>
        <file>tests/CSRFTest.php</file>
    </testsuite>
</testsuites>
```

Add one line so it becomes:

```xml
<testsuites>
    <testsuite name="Inventory">
        <file>tests/InfraSmokeTest.php</file>
        <file>tests/CSRFTest.php</file>
        <file>tests/HealthTest.php</file>
    </testsuite>
</testsuites>
```

- [ ] **Step 3: Run the test — expect FAIL because health.php doesn't exist yet**

```bash
cd /home/coreconduit/inventory && vendor/bin/phpunit --filter HealthTest --colors=never
```

Expected: `Failed asserting that file "…/health.php" exists` (assertion in the first test). The other tests fail on the include because the file is missing.

#### A.2 — Port the file

- [ ] **Step 4: Copy `health.php` verbatim from cc-inventory**

Source path: `/home/coreconduit/cc-inventory/health.php`. Target path: `/home/coreconduit/inventory/health.php`.

```bash
cp /home/coreconduit/cc-inventory/health.php /home/coreconduit/inventory/health.php
```

Or use the Read tool on the source and the Write tool on the target — same byte content either way. Do NOT edit the contents; the script works as-is against inventory's `MySqli_DB` class and `includes/config.php` paths.

- [ ] **Step 5: Run the test — expect PASS**

```bash
cd /home/coreconduit/inventory && vendor/bin/phpunit --filter HealthTest --colors=never
```

Expected: `OK (2 tests, …)`.

If the database check reports `error` on this host even though DB is up, that means `MySqli_DB` constructor or `query()` failed. Read the error output — likely `.env` credentials issue, not a test bug. Fix the underlying issue.

- [ ] **Step 6: Run the full suite to confirm no regression**

```bash
cd /home/coreconduit/inventory && vendor/bin/phpunit --colors=never
```

Expected: `OK (21 tests, …)` — InfraSmokeTest (3) + CSRFTest (16) + HealthTest (2) = 21.

- [ ] **Step 7: Commit**

```bash
cd /home/coreconduit/inventory
git add health.php tests/HealthTest.php phpunit.xml
git commit -m "feat(ops): port health.php JSON probe + PHPUnit coverage

Ported verbatim from cc-inventory. No tenancy concerns; no auth required.
Returns 200 ok / 503 degraded based on DB connectivity, uploads/* writability,
and disk_free_mb < 100. HealthTest exercises the include + JSON shape."
```

### Task B: Port `backup.php` (TDD)

**Files:**
- Create: `tests/BackupTest.php`
- Create: `backup.php`
- Create: `backups/.htaccess`
- Modify: `phpunit.xml` (add `<file>tests/BackupTest.php</file>`)

The cc-inventory `backup.php` shells out to the system `mysqldump` binary and writes gzipped SQL to `backups/`. The PHPUnit test does NOT exercise the dump path in CI by default (too slow + has side effects); it covers:
1. File presence (`backup.php` and `backups/.htaccess`).
2. Source-level inspection — confirms the SAPI gate + `ROLE_ADMIN` check + `http_response_code(403)` literal are present in the ported file.
3. CLI smoke — if `which mysqldump` succeeds and `TESTS_NO_DB` is unset, run the script against a temp `BACKUP_DIR` and assert a `.sql.gz` was produced. Skips otherwise.

#### B.1 — Write the failing test

- [ ] **Step 1: Create `tests/BackupTest.php`**

Write `/home/coreconduit/inventory/tests/BackupTest.php`:

```php
<?php
/**
 * tests/BackupTest.php
 *
 * Tests backup.php: admin-gate enforcement (source inspection), htaccess
 * deny, optional CLI smoke when the dump binary is installed.
 */

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;

class BackupTest extends TestCase
{
    private string $backup_dir;

    protected function setUp(): void
    {
        $this->backup_dir = sys_get_temp_dir() . '/inventory-test-backups-' . posix_getpid();
        if (!is_dir($this->backup_dir)) {
            mkdir($this->backup_dir, 0750, true);
        }
    }

    protected function tearDown(): void
    {
        if (is_dir($this->backup_dir)) {
            array_map('unlink', glob($this->backup_dir . '/*') ?: []);
            @unlink($this->backup_dir . '/.htaccess');
            @rmdir($this->backup_dir);
        }
    }

    #[Test]
    public function backup_file_exists_at_project_root(): void
    {
        $this->assertFileExists(dirname(__DIR__) . '/backup.php');
    }

    #[Test]
    public function backups_htaccess_denies_all(): void
    {
        $htaccess = dirname(__DIR__) . '/backups/.htaccess';
        $this->assertFileExists($htaccess, 'backups/.htaccess must exist to block web access');
        $content = file_get_contents($htaccess);
        $this->assertStringContainsString('Require all denied', $content);
    }

    #[Test]
    public function backup_source_has_sapi_gate_and_admin_check(): void
    {
        // We can't switch SAPI from inside PHPUnit, so we verify the gate
        // code is literally present in the source. The smoke test below
        // covers the happy-path CLI execution when the binary is available.
        $source = file_get_contents(dirname(__DIR__) . '/backup.php');
        $this->assertStringContainsString("PHP_SAPI === 'cli'", $source, 'Must check SAPI before allowing access');
        $this->assertStringContainsString('http_response_code(403)', $source, 'Must return 403 for unauthenticated web access');
        $this->assertStringContainsString('ROLE_ADMIN', $source, 'Must require ROLE_ADMIN');
    }

    #[Test]
    public function backup_cli_run_produces_gzipped_dump_when_binary_available(): void
    {
        if (getenv('TESTS_NO_DB')) {
            $this->markTestSkipped('TESTS_NO_DB set — backup smoke test requires a live DB');
        }
        $dump_bin = trim((string) shell_exec('which mysqldump 2>/dev/null'));
        if (empty($dump_bin)) {
            $this->markTestSkipped('mysqldump not installed on this host');
        }

        $project_root = dirname(__DIR__);
        $env_dir      = escapeshellarg($this->backup_dir);
        $script       = escapeshellarg($project_root . '/backup.php');
        $output       = shell_exec("BACKUP_DIR=$env_dir BACKUP_RETAIN_COUNT=3 php $script 2>&1");
        $files        = glob($this->backup_dir . '/*.sql.gz');

        $this->assertNotEmpty(
            $files,
            "Expected a .sql.gz in {$this->backup_dir}; script output was:\n$output"
        );
        $this->assertGreaterThan(100, filesize($files[0]), 'Backup file should be > 100 bytes');
    }
}
```

- [ ] **Step 2: Add to phpunit.xml allowlist**

```xml
<file>tests/BackupTest.php</file>
```

- [ ] **Step 3: Run the test — expect FAIL (no backup.php, no backups/.htaccess)**

```bash
cd /home/coreconduit/inventory && vendor/bin/phpunit --filter BackupTest --colors=never
```

Expected: 4 failures or skips depending on host capabilities.

#### B.2 — Port the file + create the backups directory marker

- [ ] **Step 4: Create `backups/.htaccess`**

```bash
mkdir -p /home/coreconduit/inventory/backups
```

Write `/home/coreconduit/inventory/backups/.htaccess` with exactly one line:

```
Require all denied
```

(`backups/` is now a tracked directory because git includes the .htaccess.)

- [ ] **Step 5: Copy `backup.php` verbatim from cc-inventory**

Source path: `/home/coreconduit/cc-inventory/backup.php`. Target path: `/home/coreconduit/inventory/backup.php`.

```bash
cp /home/coreconduit/cc-inventory/backup.php /home/coreconduit/inventory/backup.php
```

Or Read + Write — same byte content. Do not modify; the script uses `find_by_id`, `ROLE_ADMIN`, and `DB_*` constants that exist in inventory unchanged.

- [ ] **Step 6: Run the test — expect PASS**

```bash
cd /home/coreconduit/inventory && vendor/bin/phpunit --filter BackupTest --colors=never
```

Expected: `OK (4 tests, …)` — or `OK, but incomplete, skipped, …` if mysqldump is missing on this host.

If `backup_cli_run_produces_gzipped_dump_when_binary_available` fails because the CLI invocation returns non-zero, read the captured stdout (printed in the assertion message). Common causes: `.env` credentials wrong, dump binary not on PATH for the CLI user, `backups/` not writable.

- [ ] **Step 7: Full suite green-check**

```bash
cd /home/coreconduit/inventory && vendor/bin/phpunit --colors=never
```

Expected: `OK (25 tests, …)` — 21 + 4.

- [ ] **Step 8: Commit**

```bash
cd /home/coreconduit/inventory
git add backup.php backups/.htaccess tests/BackupTest.php phpunit.xml
git commit -m "feat(ops): port backup.php mysqldump cron + admin-gated web access

Ported verbatim from cc-inventory. CLI invocation runs unattended;
web invocation requires ROLE_ADMIN session. Writes gzipped SQL dumps
to backups/ with .htaccess locking the directory from Apache.
BackupTest covers admin-gate source presence, htaccess, and a real
CLI smoke run when the dump binary is available."
```

### Task C: Port `log_rotate.php` (TDD, with rewrites)

**Files:**
- Create: `tests/LogRotateTest.php`
- Create: `log_rotate.php`
- Modify: `phpunit.xml`

This is the biggest port because cc-inventory's `log_rotate.php` uses APIs and tables that inventory doesn't have. Diff from source to ported version:

| cc-inventory | inventory | Action |
|---|---|---|
| `$db->prepare(...)` / `bind_param` / `execute` / `affected_rows` | `$db->prepare_query($sql, $types, $params)` | Switch every DELETE to the wrapper. |
| `audit_log` table | (does not exist) | Wrap the audit_log block in a `SHOW TABLES LIKE 'audit_log'` guard and skip if absent. Keep the code path so it lights up when we port the table later. |
| `login_attempts` table with `attempted_at` column | `failed_logins` table with `attempted_at` column (migration 002) | Rename `login_attempts` → `failed_logins`. |
| `$db->run(...)` method | (does not exist) | Replace with `prepare_query()`. |

#### C.1 — Write the failing test

- [ ] **Step 1: Create `tests/LogRotateTest.php`**

Write `/home/coreconduit/inventory/tests/LogRotateTest.php`:

```php
<?php
/**
 * tests/LogRotateTest.php
 *
 * Tests log_rotate.php: seeds known-stale rows in `log` and `failed_logins`,
 * runs the rotation, asserts the rows are gone and recent rows survive.
 */

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;

class LogRotateTest extends TestCase
{
    private \MySqli_DB $db;
    private array $seeded_log_ids = [];
    private array $seeded_fail_ids = [];

    protected function setUp(): void
    {
        if (getenv('TESTS_NO_DB')) {
            $this->markTestSkipped('TESTS_NO_DB set — log_rotate test requires a live DB');
        }
        $this->db = new \MySqli_DB();
    }

    protected function tearDown(): void
    {
        if (isset($this->db)) {
            foreach ($this->seeded_log_ids as $id) {
                $this->db->prepare_query('DELETE FROM `log` WHERE id = ?', 'i', $id);
            }
            foreach ($this->seeded_fail_ids as $id) {
                $this->db->prepare_query('DELETE FROM `failed_logins` WHERE id = ?', 'i', $id);
            }
        }
    }

    #[Test]
    public function log_rotate_file_exists(): void
    {
        $this->assertFileExists(dirname(__DIR__) . '/log_rotate.php');
    }

    #[Test]
    public function log_rotate_prunes_stale_log_row_and_keeps_recent_one(): void
    {
        // Seed: one row 200 days old (stale, should be pruned at default 90-day retention)
        // and one row 1 day old (recent, should survive).
        $stale_action = 'HARNESS_log_rotate_stale_' . uniqid();
        $fresh_action = 'HARNESS_log_rotate_fresh_' . uniqid();

        $this->db->prepare_query(
            "INSERT INTO `log` (user_id, remote_ip, action, date) VALUES (NULL, '0.0.0.0', ?, DATE_SUB(NOW(), INTERVAL 200 DAY))",
            's', $stale_action
        );
        $this->seeded_log_ids[] = (int) $this->db->insert_id();

        $this->db->prepare_query(
            "INSERT INTO `log` (user_id, remote_ip, action, date) VALUES (NULL, '0.0.0.0', ?, DATE_SUB(NOW(), INTERVAL 1 DAY))",
            's', $fresh_action
        );
        $fresh_id = (int) $this->db->insert_id();
        $this->seeded_log_ids[] = $fresh_id;

        // Run the rotation.
        ob_start();
        $original_error_reporting = error_reporting();
        error_reporting($original_error_reporting & ~E_WARNING);
        try {
            include dirname(__DIR__) . '/log_rotate.php';
        } finally {
            error_reporting($original_error_reporting);
        }
        ob_end_clean();

        // Assert stale row is gone, fresh row survives.
        $stale_rows = $this->db->prepare_select(
            'SELECT id FROM `log` WHERE action = ?', 's', $stale_action
        );
        $this->assertSame([], $stale_rows, 'Stale log row should have been pruned');

        $fresh_rows = $this->db->prepare_select(
            'SELECT id FROM `log` WHERE id = ?', 'i', $fresh_id
        );
        $this->assertCount(1, $fresh_rows, 'Fresh log row should survive');
    }

    #[Test]
    public function log_rotate_prunes_stale_failed_login_attempts(): void
    {
        $stale_ip = '203.0.113.' . random_int(1, 254); // RFC 5737 test-net
        $this->db->prepare_query(
            "INSERT INTO `failed_logins` (ip, username_attempted, attempted_at) VALUES (?, 'HARNESS_user', DATE_SUB(NOW(), INTERVAL 30 DAY))",
            's', $stale_ip
        );
        $this->seeded_fail_ids[] = (int) $this->db->insert_id();

        ob_start();
        $original_error_reporting = error_reporting();
        error_reporting($original_error_reporting & ~E_WARNING);
        try {
            include dirname(__DIR__) . '/log_rotate.php';
        } finally {
            error_reporting($original_error_reporting);
        }
        ob_end_clean();

        $rows = $this->db->prepare_select(
            'SELECT id FROM `failed_logins` WHERE ip = ?', 's', $stale_ip
        );
        $this->assertSame([], $rows, 'Stale failed_logins row (>7 days) should have been pruned');
    }

    #[Test]
    public function log_rotate_audit_log_block_is_guarded_when_table_missing(): void
    {
        // Inventory does not have an audit_log table yet. The ported script
        // must check for the table's existence and skip the block silently
        // (or print "audit_log: skipped (table absent)") rather than crash.
        $source = file_get_contents(dirname(__DIR__) . '/log_rotate.php');
        $this->assertMatchesRegularExpression(
            '/SHOW\s+TABLES\s+LIKE\s+[\'"]audit_log[\'"]/i',
            $source,
            'log_rotate.php must guard the audit_log block with a SHOW TABLES check'
        );
    }
}
```

- [ ] **Step 2: Add to phpunit.xml allowlist**

```xml
<file>tests/LogRotateTest.php</file>
```

- [ ] **Step 3: Run the test — expect FAIL (no log_rotate.php yet)**

```bash
cd /home/coreconduit/inventory && vendor/bin/phpunit --filter LogRotateTest --colors=never
```

Expected: 4 failures or skips depending on DB availability.

#### C.2 — Port the rewritten file

- [ ] **Step 4: Write `log_rotate.php`**

Write `/home/coreconduit/inventory/log_rotate.php`:

```php
<?php
/**
 * log_rotate.php
 *
 * Cron-callable script to prune old log entries and stale failed-login
 * rows. Keeps recent data and deletes anything older than the configured
 * retention periods.
 *
 * Cron example (weekly on Sunday at 3 AM):
 *   0 3 * * 0 /usr/bin/php /var/www/inventory/log_rotate.php >> /var/log/inventory_logrotate.log 2>&1
 *
 * Retention defaults (override via .env):
 *   LOG_RETAIN_DAYS=90         — page-view log table
 *   AUDIT_LOG_RETAIN_DAYS=365  — audit_log table (kept longer for compliance;
 *                                 only used if the audit_log table exists)
 *
 * Note on porting from cc-inventory: this script uses inventory's
 * MySqli_DB::prepare_query() wrapper instead of raw mysqli prepare/bind/execute,
 * targets failed_logins (inventory) instead of login_attempts (cc-inventory),
 * and guards the audit_log block behind a SHOW TABLES check because inventory
 * does not yet have that table.
 */

require_once __DIR__ . '/includes/load.php';

// Only allow CLI or admin browser access
if (PHP_SAPI !== 'cli') {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(403);
        exit('Access denied.');
    }
    $runner = find_by_id('users', (int) $_SESSION['user_id']);
    if (!$runner || (int) $runner['user_level'] > ROLE_ADMIN) {
        http_response_code(403);
        exit('Admin access required.');
    }
}

header('Content-Type: text/plain');

$log_days   = (int) (getenv('LOG_RETAIN_DAYS')        ?: 90);
$audit_days = (int) (getenv('AUDIT_LOG_RETAIN_DAYS')  ?: 365);

$db = new MySqli_DB();

$timestamp = date('Y-m-d H:i:s');
echo "=== Log Rotation — $timestamp ===\n\n";

// ---------------------------------------------------------------------------
// 1. Prune page-view log (older than $log_days days)
// ---------------------------------------------------------------------------
$db->prepare_query(
    "DELETE FROM `log` WHERE `date` < DATE_SUB(NOW(), INTERVAL ? DAY)",
    'i', $log_days
);
$log_deleted = $db->affected_rows();
echo "log: deleted $log_deleted rows older than $log_days days\n";

// ---------------------------------------------------------------------------
// 2. Prune audit_log if the table exists. Inventory may not have it yet;
//    leave the block in place so it lights up automatically when the
//    table is added in a future phase.
// ---------------------------------------------------------------------------
$has_audit = $db->query("SHOW TABLES LIKE 'audit_log'");
if ($has_audit && $db->num_rows($has_audit) > 0) {
    $db->prepare_query(
        "DELETE FROM `audit_log` WHERE `created_at` < DATE_SUB(NOW(), INTERVAL ? DAY)",
        'i', $audit_days
    );
    $audit_deleted = $db->affected_rows();
    echo "audit_log: deleted $audit_deleted rows older than $audit_days days\n";
} else {
    echo "audit_log: skipped (table absent)\n";
}

// ---------------------------------------------------------------------------
// 3. Prune failed_logins (older than 7 days). Same role as cc-inventory's
//    login_attempts; inventory's failed_logins table (migration 002) is the
//    equivalent.
// ---------------------------------------------------------------------------
$login_retain = 7;
$db->prepare_query(
    "DELETE FROM `failed_logins` WHERE `attempted_at` < DATE_SUB(NOW(), INTERVAL ? DAY)",
    'i', $login_retain
);
$login_deleted = $db->affected_rows();
echo "failed_logins: deleted $login_deleted rows older than $login_retain days\n";

echo "\nDone.\n";
```

Key changes vs the cc-inventory source:
1. `$db->prepare_query($sql, 'i', $log_days)` — single-call wrapper that handles prepare + bind + execute.
2. `$db->affected_rows()` — separate call (inventory's wrapper doesn't return affected_rows from prepare_query).
3. `SHOW TABLES LIKE 'audit_log'` guard before the audit block.
4. `failed_logins` table instead of `login_attempts`.
5. No use of `$db->run(...)` (that method doesn't exist in inventory's MySqli_DB).

- [ ] **Step 5: Run the test — expect PASS**

```bash
cd /home/coreconduit/inventory && vendor/bin/phpunit --filter LogRotateTest --colors=never
```

Expected: `OK (4 tests, …)`. If the `log` INSERT fails because of column mismatch, read `migrations/003_log_user_fk.up.sql` and `includes/sql.php:789-794` (which has the production INSERT signature) to confirm the actual columns and adjust the test's INSERT. The verified columns are `user_id`, `remote_ip`, `action`, `date`.

- [ ] **Step 6: Full suite green-check**

```bash
cd /home/coreconduit/inventory && vendor/bin/phpunit --colors=never
```

Expected: `OK (29 tests, …)` — 25 + 4.

- [ ] **Step 7: Commit**

```bash
cd /home/coreconduit/inventory
git add log_rotate.php tests/LogRotateTest.php phpunit.xml
git commit -m "feat(ops): port log_rotate.php with inventory's DB API + schema

Adapted from cc-inventory:
- Switch raw mysqli prepare/bind/execute to MySqli_DB::prepare_query()
- Guard audit_log DELETE behind SHOW TABLES (inventory lacks the table)
- Target failed_logins (inventory) instead of login_attempts (cc-inventory)
- Drop unused MySqli_DB::run() call (method does not exist in inventory)

LogRotateTest seeds stale rows in log + failed_logins, runs the script,
asserts stale gone and fresh survives. Verifies audit_log guard is present."
```

### Task D: Docs + env example

**Files:**
- Modify: `.env.example`
- Modify: `README.md`

- [ ] **Step 1: Append env vars to `.env.example`**

The exact location depends on the existing structure of `.env.example`. Find the end of the file and append:

```ini

# ---------------------------------------------------------------------------
# Ops / cron scripts (Phase 2)
# ---------------------------------------------------------------------------

# backup.php — gzipped mysqldump retention
BACKUP_DIR=
BACKUP_RETAIN_COUNT=14

# log_rotate.php — log table pruning (days)
LOG_RETAIN_DAYS=90
AUDIT_LOG_RETAIN_DAYS=365
```

Leave `BACKUP_DIR` empty so the default `./backups` kicks in when unset.

- [ ] **Step 2: Append "Ops endpoints" section to `README.md`**

Add a new top-level section after "Testing":

```markdown
## Ops endpoints

| Path | Type | Auth | Purpose |
|---|---|---|---|
| `health.php` | HTTP | none | JSON probe — DB connectivity, writable uploads, free disk |
| `backup.php` | CLI / HTTP | CLI: none; HTTP: ROLE_ADMIN | Gzipped mysqldump → `backups/` with retention |
| `log_rotate.php` | CLI / HTTP | CLI: none; HTTP: ROLE_ADMIN | Prune `log` and `failed_logins` tables |

### Cron examples

```cron
# Daily backup at 2 AM
0 2 * * * /usr/bin/php /var/www/inventory/backup.php >> /var/log/inventory_backup.log 2>&1

# Weekly log rotation on Sunday at 3 AM
0 3 * * 0 /usr/bin/php /var/www/inventory/log_rotate.php >> /var/log/inventory_logrotate.log 2>&1
```

### Health probe

```bash
curl http://localhost:8080/health.php
```

Returns `{"status": "ok", ...}` with HTTP 200 when healthy; `503` with details
when DB is unreachable, uploads/* not writable, or free disk < 100 MB.
```

- [ ] **Step 3: Commit**

```bash
cd /home/coreconduit/inventory
git add .env.example README.md
git commit -m "docs(ops): document health/backup/log_rotate endpoints + cron examples"
```

### Task E: Final verification + PR

**Files:** none.

- [ ] **Step 1: Run the full test suite and run.sh wrapper**

```bash
cd /home/coreconduit/inventory && vendor/bin/phpunit --colors=never
bash tests/run.sh
```

Expected: PHPUnit `OK (29 tests, …)`. `bash tests/run.sh` summary matches the Phase 1 baseline minus the noise (PHPUnit suite now includes 4 new tests).

- [ ] **Step 2: Smoke-test the endpoints manually**

If Apache is up on `:8080`:

```bash
curl -s http://localhost:8080/health.php | head -20
```

Expected: JSON output starting with `{"status": "ok", ...`.

CLI-invoke backup against a temp dir:

```bash
BACKUP_DIR=/tmp/inv-smoke-backup BACKUP_RETAIN_COUNT=3 php /home/coreconduit/inventory/backup.php
ls /tmp/inv-smoke-backup/
```

Expected: a single `.sql.gz` file. Clean up afterward.

CLI-invoke log rotation (idempotent, safe to run):

```bash
php /home/coreconduit/inventory/log_rotate.php
```

Expected: prints `log: deleted …`, `audit_log: skipped (table absent)`, `failed_logins: deleted …`, then `Done.`.

- [ ] **Step 3: Diff stat and branch state**

```bash
git -C /home/coreconduit/inventory diff main..HEAD --stat
```

Expected file list (no surprises):
```
.env.example                    | XX +
README.md                       | XX +
backup.php                      | new
backups/.htaccess               | new
health.php                      | new
log_rotate.php                  | new
phpunit.xml                     | XX +
tests/BackupTest.php            | new
tests/HealthTest.php            | new
tests/LogRotateTest.php         | new
```

No other files.

- [ ] **Step 4: Push and open the PR**

```bash
cd /home/coreconduit/inventory
git push -u origin feature/phase2-ops-drop-ins
gh pr create --base main --head feature/phase2-ops-drop-ins --title "Phase 2: ops drop-ins (health, backup, log_rotate)" --body "$(cat <<'EOF'
## Summary

Ports three ops scripts from cc-inventory into inventory:

- **health.php** — verbatim. HTTP JSON probe (DB + writable uploads + disk_free_mb). 200 ok / 503 degraded.
- **backup.php** — verbatim. CLI or admin-gated web. mysqldump → gzip → `backups/` with retention.
- **log_rotate.php** — adapted to inventory's API and schema:
  - Switch raw mysqli prepare/bind/execute to `MySqli_DB::prepare_query()`.
  - Guard `audit_log` DELETE behind `SHOW TABLES` (inventory lacks the table — block lights up automatically when added later).
  - Target `failed_logins` (inventory) instead of `login_attempts` (cc-inventory).

Each script ships with a PHPUnit test class added to the strict `phpunit.xml` allowlist. `backups/.htaccess` (`Require all denied`) prevents Apache from serving gz dumps.

Spec: `docs/superpowers/specs/2026-05-22-cc-inventory-merge-design.md` (Phase 2).
Plan: `docs/superpowers/plans/2026-05-22-phase-2-ops-drop-ins.md`.

## Test plan

- [x] `vendor/bin/phpunit` → `OK (29 tests, …)`
- [x] `curl http://localhost:8080/health.php` returns 200 + valid JSON
- [x] `BACKUP_DIR=/tmp/… php backup.php` creates a `.sql.gz`
- [x] `php log_rotate.php` prints `audit_log: skipped (table absent)` and prunes stale `log` / `failed_logins` rows

## What's NOT in this PR

- Phase 1.5 legacy-test conversions (Auth/CRUD/Settings/SoftDelete/Tenancy/OrgManagement/SecurityHeaders).
- Phase 3 org-aware crons (`alerts_check.php`, `log_monitor_scan.php`).
- systemd timers for the cron scripts — left to ops to configure per host.
EOF
)"
```

Expected: PR URL printed.

---

## Definition of done

1. `health.php`, `backup.php`, `log_rotate.php`, `backups/.htaccess` exist at project root.
2. `tests/HealthTest.php`, `tests/BackupTest.php`, `tests/LogRotateTest.php` exist and are listed in `phpunit.xml`.
3. `vendor/bin/phpunit` returns `OK (29 tests, …)`.
4. `bash tests/run.sh` exit code matches the Phase 1 baseline (1, due to pre-existing Playwright timeouts).
5. Manual smoke of all three endpoints succeeds.
6. `.env.example` documents `BACKUP_DIR`, `BACKUP_RETAIN_COUNT`, `LOG_RETAIN_DAYS`, `AUDIT_LOG_RETAIN_DAYS`.
7. `README.md` has the "Ops endpoints" section.
8. PR opened against `bitsandbots/inventory` main.

## What's NOT in this plan

- **Phase 1.5** legacy-test conversions — separate plan, runs independently.
- **Phase 3** org-aware crons (`alerts_check.php`, `log_monitor_scan.php`) — needs the `org_id` extension scaffolding.
- **systemd timers / cron.d entries** — left to ops to configure per host. Cron examples are in the README.
- **`audit_log` table migration** — out of scope; the script gracefully skips when the table is absent.

## Self-review notes

- **Spec coverage:** Phase 2 §"Ops drop-ins" maps task-by-task: health.php (Task A), backup.php (Task B), log_rotate.php (Task C). The spec's acceptance criterion `php health.php returns expected JSON; backup writes to backups/` is covered by Task E Step 2 (smoke) and Tasks A/B PHPUnit assertions.
- **Placeholder scan:** none. Where the cc-inventory source is reused verbatim (health.php, backup.php), the plan references the source path explicitly. The one rewritten file (log_rotate.php) has its full contents inline.
- **Type consistency:** `MySqli_DB::prepare_query()` signature `(string $sql, string $types, ...$params)` matches the actual method in `includes/database.php:102`. `affected_rows()` is a separate call (line 208). `num_rows($result)` is line 190. `find_by_id($table, $id): ?array` matches `includes/sql.php:95`. `ROLE_ADMIN` is defined in `includes/sql.php:12` as 1.
- **Test isolation:** LogRotateTest seeds rows with HARNESS_ prefix per CoreConduit Test Data Isolation rule. BackupTest writes to a per-PID temp dir and cleans up in `tearDown()`. HealthTest is read-only.
