# UI/UX Consolidation — Shell Sync Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Port the CoreConduit brand shell (Bootstrap 5, CC fonts, Bootstrap Icons, CC CSS tokens) from `~/cc-inventory` into this project, fixing all 7 UI/UX gaps identified in Phase 1.

**Architecture:** Approach A — replace the layout shell files (`layouts/`, `libs/`) with cc-inventory equivalents, leaving all 60+ content pages untouched. `main.css` includes BS3 compat shims (`.pull-left`, `.panel-default`, `.btn-xs`, etc.) so content pages continue to render correctly under Bootstrap 5.

**Tech Stack:** Bootstrap 5.x, Bootstrap Icons (SVG sprite at `libs/icons/bi.svg`), Exo 2 + Plus Jakarta Sans (self-hosted woff2), jQuery 3.x (retained for datepicker + AJAX), PHP 8.x

---

### Task 1: Copy binary assets from cc-inventory

**Files:**
- Create: `libs/icons/bi.svg`
- Create: `libs/fonts/exo-2-latin-700-normal.woff2`
- Create: `libs/fonts/plus-jakarta-sans-latin-400-normal.woff2`
- Create: `libs/fonts/plus-jakarta-sans-latin-600-normal.woff2`
- Create: `libs/fonts/ibm-plex-mono-latin-400-normal.woff2`
- Create: `libs/css/bootstrap.min.css` (Bootstrap 5)
- Create: `libs/css/icons.css`
- Create: `libs/css/bootstrap-datepicker3.min.css`
- Create: `libs/js/bootstrap.min.js` (Bootstrap 5)
- Create: `libs/js/bootstrap-datepicker.min.js`

- [ ] **Step 1: Create new sub-directories**
```bash
mkdir -p libs/icons libs/fonts
```
Expected: no output, exits 0.

- [ ] **Step 2: Copy Bootstrap 5**
```bash
cp ~/cc-inventory/libs/css/bootstrap.min.css libs/css/bootstrap.min.css
cp ~/cc-inventory/libs/js/bootstrap.min.js   libs/js/bootstrap.min.js
```

- [ ] **Step 3: Copy Bootstrap Icons**
```bash
cp ~/cc-inventory/libs/css/icons.css  libs/css/icons.css
cp ~/cc-inventory/libs/icons/bi.svg   libs/icons/bi.svg
```

- [ ] **Step 4: Copy BS5-compatible datepicker**
```bash
cp ~/cc-inventory/libs/css/bootstrap-datepicker3.min.css libs/css/bootstrap-datepicker3.min.css
cp ~/cc-inventory/libs/js/bootstrap-datepicker.min.js    libs/js/bootstrap-datepicker.min.js
```

- [ ] **Step 5: Copy self-hosted fonts**
```bash
cp ~/cc-inventory/libs/fonts/exo-2-latin-700-normal.woff2          libs/fonts/
cp ~/cc-inventory/libs/fonts/plus-jakarta-sans-latin-400-normal.woff2 libs/fonts/
cp ~/cc-inventory/libs/fonts/plus-jakarta-sans-latin-600-normal.woff2 libs/fonts/
cp ~/cc-inventory/libs/fonts/ibm-plex-mono-latin-400-normal.woff2   libs/fonts/
```

- [ ] **Step 6: Verify all assets landed**
```bash
ls libs/css/ libs/js/ libs/icons/ libs/fonts/
```
Expected output includes: `bootstrap.min.css icons.css bootstrap-datepicker3.min.css` in css/; `bootstrap.min.js bootstrap-datepicker.min.js jquery.min.js functions.js` in js/; `bi.svg` in icons/; 4 `.woff2` files in fonts/.

- [ ] **Step 7: Commit**
```bash
git add libs/css/bootstrap.min.css libs/css/icons.css libs/css/bootstrap-datepicker3.min.css \
        libs/js/bootstrap.min.js libs/js/bootstrap-datepicker.min.js \
        libs/icons/bi.svg libs/fonts/
git commit -m "feat: add Bootstrap 5, Bootstrap Icons, CC fonts from cc-inventory"
```

---

### Task 2: Replace main.css and remove old asset directories

**Files:**
- Modify: `libs/css/main.css`
- Delete: `libs/bootstrap/` (entire directory)
- Delete: `libs/datepicker/` (entire directory)

- [ ] **Step 1: Replace main.css with cc-inventory's CC token system**
```bash
cp ~/cc-inventory/libs/css/main.css libs/css/main.css
```

- [ ] **Step 2: Append inventory-specific classes missing from cc-inventory**

Append the following block to the end of `libs/css/main.css`:

```css
/* ── Inventory-specific utilities ── */

/* Table column width helpers */
.col-w-15  { width: 15px; }
.col-w-50  { width: 50px; }
.col-w-100 { width: 100px; }
.col-w-10p { width: 10%; }
.col-w-15p { width: 15%; }
.col-w-20p { width: 20%; }

/* Inline form display for trash action buttons in table rows */
.trash-action { display: inline; }

/* Org switcher dropdown button */
.org-switcher-btn {
    background: none;
    border: none;
    padding: 4px 12px;
    width: 100%;
    text-align: left;
    cursor: pointer;
    white-space: nowrap;
}
.org-switcher-btn:hover {
    background-color: var(--cc-bg-hover, #b5b9c2);
}
```

- [ ] **Step 3: Verify key CC classes are present in the new file**
```bash
grep -c "cc-logo\|sidebar-toggle\|skip-link\|icon-2x\|panel-default" libs/css/main.css
```
Expected: `5` (each pattern found at least once).

- [ ] **Step 4: Remove old Bootstrap 3 and datepicker directories**
```bash
git rm -r libs/bootstrap libs/datepicker
```
Expected: lists the removed files, exits 0.

- [ ] **Step 5: Commit**
```bash
git add libs/css/main.css
git commit -m "feat: replace main.css with CC token system + BS3 compat shims; remove BS3 bundle"
```

---

### Task 3: Add APP_BASE_PATH and APP_NAME to config.php

**Files:**
- Modify: `includes/config.php`

- [ ] **Step 1: Find the APP_SECRET define line**
```bash
grep -n "APP_SECRET\|define(" includes/config.php | tail -5
```
Note the line number after which to insert.

- [ ] **Step 2: Add the two new constants immediately after the APP_SECRET define**

In `includes/config.php`, after the line `define('APP_SECRET', ...);`, add:
```php
define('APP_NAME', getenv('APP_NAME') ?: 'Inventory');

// APP_BASE_PATH: empty string for standard port-8080 root install.
// Override via APP_BASE_PATH= in .env if the app is in a subdirectory.
$_app_base = getenv('APP_BASE_PATH') ?: '';
define('APP_BASE_PATH', $_app_base);
unset($_app_base);
```

- [ ] **Step 3: Verify syntax**
```bash
php -l includes/config.php
```
Expected: `No syntax errors detected in includes/config.php`

- [ ] **Step 4: Commit**
```bash
git add includes/config.php
git commit -m "feat: add APP_BASE_PATH and APP_NAME constants to config"
```

---

### Task 4: Add bi() Bootstrap Icons helper to functions.php

**Files:**
- Modify: `includes/functions.php`

- [ ] **Step 1: Append bi() to the end of includes/functions.php**

Add this function at the very end of `includes/functions.php`:
```php
/**
 * Emit a Bootstrap Icon SVG referencing the self-hosted libs/icons/bi.svg sprite.
 *
 * @param string $name  Icon name without "bi-" prefix (e.g. "house", "cart3").
 * @param string $extra Additional CSS classes (e.g. "icon-2x text-success").
 * @param string $label Non-empty string adds role="img" aria-label; empty = aria-hidden.
 */
function bi(string $name, string $extra = '', string $label = ''): string
{
    $name   = preg_replace('/[^a-z0-9-]/', '', $name);
    $cls    = trim('bi ' . $extra);
    $aria   = $label !== ''
        ? 'role="img" aria-label="' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '"'
        : 'aria-hidden="true"';
    $sprite = APP_BASE_PATH . '/libs/icons/bi.svg';
    return '<svg class="' . htmlspecialchars($cls, ENT_QUOTES, 'UTF-8') . '" ' . $aria . '>'
         . '<use href="' . htmlspecialchars($sprite, ENT_QUOTES, 'UTF-8') . '#' . $name . '"/></svg>';
}
```

- [ ] **Step 2: Verify PHP syntax**
```bash
php -l includes/functions.php
```
Expected: `No syntax errors detected in includes/functions.php`

- [ ] **Step 3: Commit**
```bash
git add includes/functions.php
git commit -m "feat: add bi() Bootstrap Icons SVG helper to functions.php"
```

---

### Task 5: Write nav-shell Playwright spec (TDD — write before implementing)

**Files:**
- Create: `tests/ui/nav-shell.spec.js`

- [ ] **Step 1: Create the spec file**

Write `tests/ui/nav-shell.spec.js`:
```javascript
// @ts-check
const { test, expect } = require('@playwright/test');

test.describe('Navigation shell — admin', () => {
  test.use({ storageState: 'tests/ui/.auth/admin.json' });

  test('CC logo is present', async ({ page }) => {
    await page.goto('/users/admin.php');
    await expect(page.locator('.cc-logo')).toBeVisible();
  });

  test('brand name shows CoreInventory', async ({ page }) => {
    await page.goto('/users/admin.php');
    await expect(page.locator('.cc-logo .brand-name')).toContainText('Core');
    await expect(page.locator('.cc-logo .brand-name .highlight')).toContainText('Inventory');
  });

  test('sidebar has all six top-level entries', async ({ page }) => {
    await page.goto('/users/admin.php');
    const sb = page.locator('.sidebar');
    await expect(sb.locator('a', { hasText: 'Dashboard' })).toBeVisible();
    await expect(sb.locator('.submenu-toggle', { hasText: 'Products' })).toBeVisible();
    await expect(sb.locator('a', { hasText: 'Customers' })).toBeVisible();
    await expect(sb.locator('.submenu-toggle', { hasText: 'Sales' })).toBeVisible();
    await expect(sb.locator('.submenu-toggle', { hasText: 'Reports' })).toBeVisible();
    await expect(sb.locator('.submenu-toggle', { hasText: 'User Management' })).toBeVisible();
  });

  test('Organizations link visible under User Management', async ({ page }) => {
    await page.goto('/users/admin.php');
    await page.locator('.sidebar .submenu-toggle', { hasText: 'User Management' }).click();
    await expect(page.locator('.sidebar a[href*="orgs.php"]')).toBeVisible();
  });

  test('no glyphicon classes in sidebar', async ({ page }) => {
    await page.goto('/users/admin.php');
    const count = await page.locator('.sidebar [class*="glyphicon"]').count();
    expect(count).toBe(0);
  });

  test('Bootstrap Icon SVG elements present in sidebar', async ({ page }) => {
    await page.goto('/users/admin.php');
    const count = await page.locator('.sidebar svg.bi').count();
    expect(count).toBeGreaterThan(0);
  });
});

test.describe('Navigation shell — level-3 user', () => {
  test.use({ storageState: 'tests/ui/.auth/uitest_user.json' });

  test('Products submenu has exactly 2 items', async ({ page }) => {
    await page.goto('/users/home.php');
    await page.locator('.sidebar .submenu-toggle', { hasText: 'Products' }).click();
    const productsLi = page.locator('.sidebar li', {
      has: page.locator('.submenu-toggle', { hasText: 'Products' }),
    });
    await expect(productsLi.locator('ul.submenu li')).toHaveCount(2);
  });

  test('Manage Stock is not in sidebar', async ({ page }) => {
    await page.goto('/users/home.php');
    await expect(page.locator('.sidebar a', { hasText: 'Manage Stock' })).toHaveCount(0);
  });

  test('Media is not in sidebar', async ({ page }) => {
    await page.goto('/users/home.php');
    await expect(page.locator('.sidebar a', { hasText: 'Media' })).toHaveCount(0);
  });

  test('Sales submenu has exactly 3 items', async ({ page }) => {
    await page.goto('/users/home.php');
    await page.locator('.sidebar .submenu-toggle', { hasText: 'Sales' }).click();
    const salesLi = page.locator('.sidebar li', {
      has: page.locator('.submenu-toggle', { hasText: 'Sales' }),
    });
    await expect(salesLi.locator('ul.submenu li')).toHaveCount(3);
  });

  test('Add Sale by SKU is not in sidebar', async ({ page }) => {
    await page.goto('/users/home.php');
    await expect(page.locator('.sidebar a', { hasText: 'Add Sale by SKU' })).toHaveCount(0);
  });
});
```

- [ ] **Step 2: Run the spec — confirm it fails as expected**
```bash
npx playwright test tests/ui/nav-shell.spec.js --reporter=line 2>&1 | tail -20
```
Expected: Multiple FAILs. Admin tests fail because `.cc-logo` doesn't exist yet. Level-3 tests fail because menu still has old items. This confirms the selectors are correct.

- [ ] **Step 3: Commit the red spec**
```bash
git add tests/ui/nav-shell.spec.js
git commit -m "test(ui): nav-shell spec — red (pre-implementation)"
```

---

### Task 6: Rewrite header.php, update footer.php, add toggleSidebar()

**Files:**
- Modify: `layouts/header.php`
- Modify: `layouts/footer.php`
- Modify: `libs/js/functions.js`

- [ ] **Step 1: Overwrite layouts/header.php**

Write `layouts/header.php` with the following complete content:
```php
<?php
/**
 * layouts/header.php
 */

$user     = current_user();
$app_name = defined('APP_NAME')      ? APP_NAME      : 'Inventory';
$base     = defined('APP_BASE_PATH') ? APP_BASE_PATH : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php if ($session->isUserLoggedIn()): ?>
  <meta name="csrf-token" content="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
  <?php endif; ?>
  <title><?php
    if (!empty($page_title)) echo remove_junk($page_title) . ' — ' . $app_name;
    elseif (!empty($user))   echo ucfirst(remove_junk($user['name']));
    else                     echo $app_name;
  ?></title>
  <link rel="stylesheet" href="<?php echo $base; ?>/libs/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo $base; ?>/libs/css/bootstrap-datepicker3.min.css">
  <link rel="stylesheet" href="<?php echo $base; ?>/libs/css/icons.css">
  <link rel="stylesheet" href="<?php echo $base; ?>/libs/css/main.css">
</head>
<body>
<a href="#main" class="skip-link">Skip to main content</a>

<?php if ($session->isUserLoggedIn()): ?>
<button id="sidebar-toggle" onclick="toggleSidebar()"
        aria-label="Toggle navigation" aria-expanded="false" aria-controls="sidebar">&#9776;</button>

<header id="header">
  <a href="<?php echo $base; ?>/users/admin.php" class="cc-logo">
    <div class="logo-mark"><span class="cc-inner">CC</span></div>
    <span class="brand-name">Core<span class="highlight">Inventory</span></span>
  </a>

  <div class="header-content">
    <div class="header-date pull-left">
      <strong><?php echo date('F j, Y, g:i a'); ?></strong>
    </div>
    <div class="pull-right clearfix">
      <ul class="info-menu list-inline list-unstyled">

        <?php
        $_user_orgs = [];
        if (isset($_SESSION['user_id'])) {
            $_user_orgs = find_org_memberships((int)$_SESSION['user_id']);
        }
        if (count($_user_orgs) >= 2):
            $_current_org_name = 'Organization';
            foreach ($_user_orgs as $_o) {
                if ((int)$_o['org_id'] === (int)($_SESSION['current_org_id'] ?? 0)) {
                    $_current_org_name = h($_o['name']);
                    break;
                }
            }
        ?>
        <li class="dropdown">
          <a href="#" data-bs-toggle="dropdown" class="toggle">
            <?php echo bi('list-ul'); ?>
            <?php echo $_current_org_name; ?> <i class="caret"></i>
          </a>
          <ul class="dropdown-menu">
            <?php foreach ($_user_orgs as $_o): ?>
            <li>
              <form method="POST" action="<?php echo $base; ?>/users/switch_org.php">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="org_id" value="<?php echo (int)$_o['org_id']; ?>">
                <button type="submit" class="org-switcher-btn">
                  <?php echo h($_o['name']); ?>
                  <?php if ((int)$_o['org_id'] === (int)($_SESSION['current_org_id'] ?? 0)): ?>
                  <?php echo bi('check-lg', 'pull-right'); ?>
                  <?php endif; ?>
                </button>
              </form>
            </li>
            <?php endforeach; ?>
          </ul>
        </li>
        <?php endif; ?>

        <li class="profile">
          <a href="#" data-bs-toggle="dropdown" class="toggle" aria-expanded="false">
            <img src="<?php echo $base; ?>/uploads/users/<?php echo h($user['image']); ?>"
                 alt="user" class="img-circle img-inline">
            <span><?php echo remove_junk(ucfirst($user['name'])); ?> <i class="caret"></i></span>
          </a>
          <ul class="dropdown-menu">
            <li>
              <a href="<?php echo $base; ?>/users/profile.php?id=<?php echo (int)$user['id']; ?>">
                <?php echo bi('person'); ?> Profile
              </a>
            </li>
            <li>
              <a href="<?php echo $base; ?>/users/edit_account.php">
                <?php echo bi('gear'); ?> Settings
              </a>
            </li>
            <li class="last">
              <a href="<?php echo $base; ?>/users/logout.php">
                <?php echo bi('power'); ?> Logout
              </a>
            </li>
          </ul>
        </li>

      </ul>
    </div>
  </div>
</header>

<div id="sidebar" class="sidebar">
  <?php $ulvl = (int)($user['user_level'] ?? 0); ?>
  <?php if ($ulvl === 1): ?>
    <?php include_once 'admin_menu.php'; ?>
  <?php elseif ($ulvl === 2): ?>
    <?php include_once 'special_menu.php'; ?>
  <?php elseif ($ulvl === 3): ?>
    <?php include_once 'user_menu.php'; ?>
  <?php else: ?>
    <?php redirect($base . '/users/logout.php', false); ?>
  <?php endif; ?>
</div>
<?php endif; ?>

<div id="main" class="page">
  <div class="container-fluid">
```

- [ ] **Step 2: Verify header syntax**
```bash
php -l layouts/header.php
```
Expected: `No syntax errors detected in layouts/header.php`

- [ ] **Step 3: Overwrite layouts/footer.php with updated JS paths**

Write `layouts/footer.php`:
```php
<?php
/**
 * layouts/footer.php
 */
$base = defined('APP_BASE_PATH') ? APP_BASE_PATH : '';
?>
     </div>
    </div>
    <script src="<?php echo $base; ?>/libs/js/jquery.min.js"></script>
    <script src="<?php echo $base; ?>/libs/js/bootstrap.min.js"></script>
    <script src="<?php echo $base; ?>/libs/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo $base; ?>/libs/js/functions.js"></script>
  </body>
</html>
<?php if (isset($db)) { $db->db_disconnect(); } ?>
```

- [ ] **Step 4: Verify footer syntax**
```bash
php -l layouts/footer.php
```
Expected: `No syntax errors detected in layouts/footer.php`

- [ ] **Step 5: Add toggleSidebar() to libs/js/functions.js**

In `libs/js/functions.js`, add the following function **immediately before** the `$(document).ready(function() {` line:
```javascript
function toggleSidebar() {
    var sidebar = document.getElementById('sidebar');
    var btn     = document.getElementById('sidebar-toggle');
    if (!sidebar || !btn) { return; }
    sidebar.classList.toggle('sidebar-collapsed');
    btn.setAttribute('aria-expanded',
        String(!sidebar.classList.contains('sidebar-collapsed')));
}
```

- [ ] **Step 6: Verify JS syntax**
```bash
node --check libs/js/functions.js
```
Expected: no output, exits 0.

- [ ] **Step 7: Commit**
```bash
git add layouts/header.php layouts/footer.php libs/js/functions.js
git commit -m "feat: CC header shell, BS5 footer paths, sidebar toggle"
```

---

### Task 7: Update layouts/admin_menu.php

**Files:**
- Modify: `layouts/admin_menu.php`

- [ ] **Step 1: Overwrite with bi() version, add Organizations, reorder Products**

Write `layouts/admin_menu.php`:
```php
<?php
/**
 * layouts/admin_menu.php
 */
?>
<ul>
  <li>
    <a href="../users/admin.php">
      <?php echo bi('house'); ?>
      <span>Dashboard</span>
    </a>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('cart3'); ?>
      <span>Products</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../products/categories.php">Categories</a></li>
      <li><a href="../products/products.php">Manage Products</a></li>
      <li><a href="../products/product_search.php">Product Search</a></li>
      <li><a href="../products/stock.php">Manage Stock</a></li>
      <li><a href="../products/media.php">Media</a></li>
    </ul>
  </li>

  <li>
    <a href="../customers/customers.php">
      <?php echo bi('people'); ?>
      <span>Customers</span>
    </a>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('receipt'); ?>
      <span>Sales</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../sales/add_order_by_customer.php">Add Order</a></li>
      <li><a href="../sales/orders.php">Manage Orders</a></li>
      <li><a href="../sales/sales.php">Manage Sales</a></li>
      <li><a href="../sales/add_sale_by_sku.php">Add Sale by SKU</a></li>
    </ul>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('bar-chart-line'); ?>
      <span>Reports</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../reports/stock_report.php">Stock Report</a></li>
      <li><a href="../reports/sales_report.php">Sales by Dates</a></li>
      <li><a href="../reports/monthly_sales.php">Monthly Sales</a></li>
      <li><a href="../reports/daily_sales.php">Daily Sales</a></li>
    </ul>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('gear'); ?>
      <span>User Management</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../users/group.php">Manage Groups</a></li>
      <li><a href="../users/users.php">Manage Users</a></li>
      <li><a href="../users/log.php">System Log</a></li>
      <li><a href="../users/settings.php">Settings</a></li>
      <li><a href="../users/trash.php">Trash</a></li>
      <li><a href="../orgs/orgs.php">Organizations</a></li>
    </ul>
  </li>
</ul>
```

- [ ] **Step 2: Verify syntax**
```bash
php -l layouts/admin_menu.php
```
Expected: `No syntax errors detected in layouts/admin_menu.php`

- [ ] **Step 3: Commit**
```bash
git add layouts/admin_menu.php
git commit -m "feat: admin menu — Bootstrap Icons, Organizations link, Products reordered"
```

---

### Task 8: Update layouts/special_menu.php

**Files:**
- Modify: `layouts/special_menu.php`

- [ ] **Step 1: Overwrite with bi() version**

Write `layouts/special_menu.php`:
```php
<?php
/**
 * layouts/special_menu.php  —  Supervisor (level 2)
 */
?>
<ul>
  <li>
    <a href="../users/home.php">
      <?php echo bi('house'); ?>
      <span>Dashboard</span>
    </a>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('cart3'); ?>
      <span>Products</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../products/categories.php">Categories</a></li>
      <li><a href="../products/products.php">Manage Products</a></li>
      <li><a href="../products/product_search.php">Product Search</a></li>
      <li><a href="../products/stock.php">Manage Stock</a></li>
      <li><a href="../products/media.php">Media</a></li>
    </ul>
  </li>

  <li>
    <a href="../customers/customers.php">
      <?php echo bi('people'); ?>
      <span>Customers</span>
    </a>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('receipt'); ?>
      <span>Sales</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../sales/add_order_by_customer.php">Add Order</a></li>
      <li><a href="../sales/orders.php">Manage Orders</a></li>
      <li><a href="../sales/sales.php">Manage Sales</a></li>
      <li><a href="../sales/add_sale_by_sku.php">Add Sale by SKU</a></li>
    </ul>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('bar-chart-line'); ?>
      <span>Reports</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../reports/stock_report.php">Stock Report</a></li>
      <li><a href="../reports/sales_report.php">Sales by Dates</a></li>
      <li><a href="../reports/monthly_sales.php">Monthly Sales</a></li>
      <li><a href="../reports/daily_sales.php">Daily Sales</a></li>
    </ul>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('gear'); ?>
      <span>User Management</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../users/group.php">Manage Groups</a></li>
      <li><a href="../users/users.php">Manage Users</a></li>
    </ul>
  </li>
</ul>
```

- [ ] **Step 2: Verify syntax**
```bash
php -l layouts/special_menu.php
```
Expected: `No syntax errors detected in layouts/special_menu.php`

- [ ] **Step 3: Commit**
```bash
git add layouts/special_menu.php
git commit -m "feat: supervisor menu — Bootstrap Icons"
```

---

### Task 9: Update layouts/user_menu.php

**Files:**
- Modify: `layouts/user_menu.php`

- [ ] **Step 1: Overwrite with trimmed bi() version**

Write `layouts/user_menu.php`:
```php
<?php
/**
 * layouts/user_menu.php  —  Standard user (level 3)
 */
?>
<ul>
  <li>
    <a href="../users/home.php">
      <?php echo bi('house'); ?>
      <span>Dashboard</span>
    </a>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('cart3'); ?>
      <span>Products</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../products/products.php">Products</a></li>
      <li><a href="../products/product_search.php">Product Search</a></li>
    </ul>
  </li>

  <li>
    <a href="../customers/customers.php">
      <?php echo bi('people'); ?>
      <span>Customers</span>
    </a>
  </li>

  <li>
    <a href="#" class="submenu-toggle">
      <?php echo bi('receipt'); ?>
      <span>Sales</span>
    </a>
    <ul class="nav submenu">
      <li><a href="../sales/add_order_by_customer.php">Add Order</a></li>
      <li><a href="../sales/orders.php">Orders</a></li>
      <li><a href="../sales/sales.php">Sales</a></li>
    </ul>
  </li>
</ul>
```

- [ ] **Step 2: Verify syntax**
```bash
php -l layouts/user_menu.php
```
Expected: `No syntax errors detected in layouts/user_menu.php`

- [ ] **Step 3: Run nav-shell spec — expect all green**
```bash
npx playwright test tests/ui/nav-shell.spec.js --reporter=line 2>&1 | tail -20
```
Expected: `11 passed`. If any test fails, check the diff between the expected selector and the actual rendered HTML before continuing.

- [ ] **Step 4: Commit**
```bash
git add layouts/user_menu.php
git commit -m "feat: user menu — Bootstrap Icons, remove inaccessible items"
```

---

### Task 10: Write csp-compliance Playwright spec (TDD — write before fixing)

**Files:**
- Create: `tests/ui/csp-compliance.spec.js`

- [ ] **Step 1: Create the spec**

Write `tests/ui/csp-compliance.spec.js`:
```javascript
// @ts-check
const { test, expect } = require('@playwright/test');

test.describe('CSP compliance and asset delivery', () => {
  test.use({ storageState: 'tests/ui/.auth/admin.json' });

  test('no inline style attributes on admin dashboard content', async ({ page }) => {
    await page.goto('/users/admin.php');
    const inlineStyles = await page.locator('#main [style]').count();
    expect(inlineStyles).toBe(0);
  });

  test('no glyphicon classes anywhere in DOM', async ({ page }) => {
    await page.goto('/users/admin.php');
    const glyphicons = await page.locator('[class*="glyphicon"]').count();
    expect(glyphicons).toBe(0);
  });

  test('bi.svg responds 200', async ({ page }) => {
    const res = await page.request.get('/libs/icons/bi.svg');
    expect(res.status()).toBe(200);
  });

  test('bootstrap.min.css responds 200', async ({ page }) => {
    const res = await page.request.get('/libs/css/bootstrap.min.css');
    expect(res.status()).toBe(200);
  });

  test('Exo 2 font responds 200', async ({ page }) => {
    const res = await page.request.get('/libs/fonts/exo-2-latin-700-normal.woff2');
    expect(res.status()).toBe(200);
  });

  test('Bootstrap Icon SVGs present in admin dashboard content', async ({ page }) => {
    await page.goto('/users/admin.php');
    const count = await page.locator('#main svg.bi').count();
    expect(count).toBeGreaterThan(0);
  });
});
```

- [ ] **Step 2: Run and confirm partial failure**
```bash
npx playwright test tests/ui/csp-compliance.spec.js --reporter=line 2>&1 | tail -20
```
Expected: Asset tests pass (bi.svg, CSS, font all exist). "no glyphicon" FAILS — `users/admin.php` still has `glyphicon-user`, `glyphicon-th`, `glyphicon-th-list`. "Bootstrap Icon SVGs in content" FAILS for the same reason.

- [ ] **Step 3: Commit the red spec**
```bash
git add tests/ui/csp-compliance.spec.js
git commit -m "test(ui): csp-compliance spec — red (pre-fix)"
```

---

### Task 11: Fix CSP violations in users/admin.php + BS5 tooltip compat

**Files:**
- Modify: `users/admin.php`
- Modify: `libs/js/functions.js`

- [ ] **Step 1: Confirm the three offending lines**
```bash
grep -n "style=\|glyphicon" users/admin.php
```
Expected: three lines containing `style="font-size:2em"` combined with glyphicon class names.

- [ ] **Step 2: Replace the three icon spans in users/admin.php**

Find and replace each occurrence:

Replace (line ~107):
```php
<span class="glyphicon glyphicon-user" style="font-size:2em"></span>
```
With:
```php
<?php echo bi('people', 'icon-2x'); ?>
```

Replace (line ~115):
```php
<span class="glyphicon glyphicon-th" style="font-size:2em"></span>
```
With:
```php
<?php echo bi('grid', 'icon-2x'); ?>
```

Replace (line ~123):
```php
<span class="glyphicon glyphicon-th-list" style="font-size:2em"></span>
```
With:
```php
<?php echo bi('list-ul', 'icon-2x'); ?>
```

- [ ] **Step 3: Verify no glyphicon or inline style references remain in admin.php**
```bash
grep "glyphicon\|style=" users/admin.php
```
Expected: no output.

- [ ] **Step 4: Verify PHP syntax**
```bash
php -l users/admin.php
```
Expected: `No syntax errors detected in users/admin.php`

- [ ] **Step 5: Replace the tooltip initializer in libs/js/functions.js**

In `libs/js/functions.js`, inside `$(document).ready`, replace:
```javascript
$('[data-toggle="tooltip"]').tooltip();
```
With:
```javascript
$('[data-toggle="tooltip"], [data-bs-toggle="tooltip"]').each(function () {
    new bootstrap.Tooltip(this);
});
```

- [ ] **Step 6: Verify JS syntax**
```bash
node --check libs/js/functions.js
```
Expected: no output, exits 0.

- [ ] **Step 7: Run csp-compliance spec — expect all green**
```bash
npx playwright test tests/ui/csp-compliance.spec.js --reporter=line 2>&1 | tail -20
```
Expected: `6 passed`.

- [ ] **Step 8: Commit**
```bash
git add users/admin.php libs/js/functions.js
git commit -m "fix: CSP inline styles → bi() in admin dashboard; BS5 tooltip compat shim"
```

---

### Task 12: Full suite validation and final commit

**Files:** none — validation only.

- [ ] **Step 1: Run the complete Playwright suite**
```bash
npx playwright test --reporter=line 2>&1 | tail -30
```
Expected: all specs pass (login, org-switcher, core-inventory, nav-shell, csp-compliance). Total should be ≥ 19 tests passing.

- [ ] **Step 2: If any existing spec fails — fix selector drift**

Run the failing spec in headed mode to inspect the actual DOM:
```bash
npx playwright test tests/ui/<failing>.spec.js --headed --reporter=line 2>&1 | tail -30
```
Common changes after this refactor:
- `.logo` selector → `.cc-logo`
- Paths in `page.request.get()` that referenced old `libs/bootstrap/` paths

Update the selector in the failing spec to match the new HTML and re-run.

- [ ] **Step 3: Run the PHP unit test suite**
```bash
bash tests/run.sh 2>&1 | tail -10
```
Expected: `62 tests, 0 failures` (or current count — auth, CSRF, CRUD, security headers, settings, soft-delete). None of those files were touched.

- [ ] **Step 4: Verify no old path references remain**
```bash
grep -r "libs/bootstrap\|libs/datepicker\|glyphicon" layouts/ users/admin.php libs/js/functions.js 2>/dev/null
```
Expected: no output. If any matches: fix the file, re-run both test suites, then commit.

- [ ] **Step 5: Commit final state**
```bash
git add -A
git status   # confirm only intended files changed
git commit -m "test(ui): full suite green — UI consolidation complete"
```
