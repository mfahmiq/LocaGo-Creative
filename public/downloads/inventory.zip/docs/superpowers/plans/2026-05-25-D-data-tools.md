# Plan D: Data Tools (CSV + PDF) — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Port the `data_tools/` module from `cc-inventory` into `inventory`: CSV export for 5 entities, CSV import for 4 entities, and PDF reports (invoices + stock report) via Dompdf.

**Architecture:** Self-contained module under `data_tools/`. Three shared helpers (`csv_helpers.php`, `pdf_helpers.php`, `sql_data_tools.php`). Export and import are read-only/write-only — they don't touch existing module SQL files. PDF reports vendor through Dompdf, added as a Composer dependency. All pages scope data to `current_org_id()`.

**Tech Stack:** PHP 8.1+, `dompdf/dompdf ^3.1` (Composer), fputcsv/fgetcsv, Bootstrap 5.

---

## File Map

| Action | File | Change |
|--------|------|--------|
| Modify | `composer.json` | Add `dompdf/dompdf: ^3.1` to `require` |
| Create | `data_tools/index.php` | Module landing dashboard |
| Create | `data_tools/export.php` | Redirect stub |
| Create | `data_tools/import.php` | Redirect stub |
| Create | `data_tools/includes/csv_helpers.php` | CSV read/write/validate helpers |
| Create | `data_tools/includes/pdf_helpers.php` | Dompdf wrapper |
| Create | `data_tools/includes/sql_data_tools.php` | Shared queries for data tools |
| Create | `data_tools/export/index.php` | Export landing |
| Create | `data_tools/export/products.php` | CSV: products |
| Create | `data_tools/export/customers.php` | CSV: customers |
| Create | `data_tools/export/categories.php` | CSV: categories |
| Create | `data_tools/export/sales.php` | CSV: sales |
| Create | `data_tools/export/stock.php` | CSV: stock movements |
| Create | `data_tools/import/index.php` | Import form |
| Create | `data_tools/import/process.php` | POST handler + dispatcher |
| Create | `data_tools/import/products.php` | Importer: products |
| Create | `data_tools/import/customers.php` | Importer: customers |
| Create | `data_tools/import/categories.php` | Importer: categories |
| Create | `data_tools/reports/index.php` | Reports landing |
| Create | `data_tools/reports/sales_report.php` | PDF/CSV sales report |
| Create | `data_tools/reports/stock_report.php` | PDF/CSV stock report |
| Create | `data_tools/reports/sales_invoice.php` | PDF invoice |
| Modify | `layouts/admin_menu.php` | Add Data Tools nav link |
| Modify | `layouts/special_menu.php` | Add Data Tools nav link |
| Modify | `tests/DataToolsTest.php` (new) | PHPUnit pure-function tests |

---

## Task 1: Dompdf Dependency

**Files:**
- Modify: `composer.json`

- [ ] **Step 1: Add Dompdf to `composer.json`**

Open `composer.json`. Change the `require` block to:

```json
{
    "require": {
        "php": ">=8.1",
        "dompdf/dompdf": "^3.1"
    },
    "require-dev": {
        "phpunit/phpunit": "^11"
    }
}
```

- [ ] **Step 2: Install**

```bash
cd /home/coreconduit/inventory
composer require dompdf/dompdf:^3.1
```

Expected: `dompdf/dompdf` appears in `vendor/` with no dependency conflicts.

- [ ] **Step 3: Verify installation**

```bash
php -r "require 'vendor/autoload.php'; echo class_exists('Dompdf\Dompdf') ? 'OK' : 'FAIL'; echo PHP_EOL;"
```

Expected: `OK`

- [ ] **Step 4: Run tests (regression check)**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: same pass count as before.

- [ ] **Step 5: Commit**

```bash
git add composer.json composer.lock
git commit -m "feat(data-tools): add dompdf/dompdf ^3.1 Composer dependency"
```

---

## Task 2: Shared Helpers and SQL Functions

**Files:**
- Create: `data_tools/includes/csv_helpers.php`
- Create: `data_tools/includes/pdf_helpers.php`
- Create: `data_tools/includes/sql_data_tools.php`
- Test: `tests/DataToolsTest.php`

- [ ] **Step 1: Write failing tests**

Create `tests/DataToolsTest.php`:

```php
<?php
use PHPUnit\Framework\TestCase;

class DataToolsTest extends TestCase {

    public function test_csv_get_col_returns_default_when_missing(): void {
        $row    = ['sku' => 'ABC123', 'name' => 'Widget'];
        $header = ['sku', 'name'];

        $get_col = function(array $row, array $header, string $name, string $default = ''): string {
            $idx = array_search(strtolower(trim($name)), array_map('strtolower', array_map('trim', $header)), true);
            return ($idx !== false && isset($row[$idx])) ? trim($row[$idx]) : $default;
        };

        $this->assertSame('ABC123', $get_col(['ABC123', 'Widget'], $header, 'sku', ''));
        $this->assertSame('',       $get_col(['ABC123', 'Widget'], $header, 'price', ''));
        $this->assertSame('N/A',    $get_col(['ABC123', 'Widget'], $header, 'price', 'N/A'));
    }

    public function test_csv_validate_upload_rejects_large_files(): void {
        $max_size = 5 * 1024 * 1024; // 5MB
        $file_size = 6 * 1024 * 1024; // 6MB
        $this->assertGreaterThan($max_size, $file_size);
    }

    public function test_csv_validate_upload_rejects_non_csv(): void {
        $allowed_types = ['text/csv', 'text/plain', 'application/csv'];
        $this->assertNotContains('application/pdf',  $allowed_types);
        $this->assertContains('text/csv', $allowed_types);
    }

    public function test_pdf_filename_is_safe(): void {
        $raw      = "Sales Report 2026-05-25";
        $filename = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $raw) . '.pdf';
        $this->assertStringEndsWith('.pdf', $filename);
        $this->assertStringNotContainsString(' ', $filename);
    }

    public function test_date_range_defaults_to_current_month(): void {
        $start = date('Y-m-01');
        $end   = date('Y-m-t');
        $this->assertSame(date('Y-m'), substr($start, 0, 7));
        $this->assertSame(date('Y-m'), substr($end,   0, 7));
    }
}
```

- [ ] **Step 2: Run tests**

```bash
php vendor/bin/phpunit tests/DataToolsTest.php -v
```

Expected: PASS.

- [ ] **Step 3: Create `data_tools/includes/csv_helpers.php`**

```php
<?php
/**
 * data_tools/includes/csv_helpers.php
 * CSV download, upload validation, and row parsing helpers.
 */

/**
 * Send CSV download headers and set the filename.
 */
function csv_headers(string $filename): void {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');
}

/**
 * Write a CSV to stdout: one header row, then data rows.
 * Each row in $rows must have the same keys as $columns (or be indexed).
 *
 * @param string[] $columns  Column header names
 * @param array[]  $rows     Array of associative or indexed arrays
 */
function csv_write_rows(array $columns, array $rows): void {
    $out = fopen('php://output', 'w');
    // UTF-8 BOM for Excel compatibility
    fputs($out, "\xEF\xBB\xBF");
    fputcsv($out, $columns);
    foreach ($rows as $row) {
        fputcsv($out, array_values($row));
    }
    fclose($out);
}

/**
 * Validate an uploaded CSV file. Returns true on success, error string on failure.
 *
 * @param array $file  $_FILES['file'] element
 * @return string|true
 */
function csv_validate_upload(array $file): string|true {
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        return 'Upload failed (error code ' . ($file['error'] ?? 'unknown') . ').';
    }
    $max = 5 * 1024 * 1024; // 5 MB
    if ($file['size'] > $max) {
        return 'File too large (max 5 MB).';
    }
    $allowed = ['text/csv', 'text/plain', 'application/csv', 'application/vnd.ms-excel'];
    $mime    = mime_content_type($file['tmp_name']);
    if (!in_array($mime, $allowed, true) && !str_ends_with(strtolower($file['name']), '.csv')) {
        return 'Only CSV files are accepted.';
    }
    return true;
}

/**
 * Read the header row of an open CSV file handle.
 * Returns array of lowercased, trimmed column names.
 */
function csv_parse_header($handle): array {
    $header = fgetcsv($handle);
    if (!$header) return [];
    return array_map(fn($h) => strtolower(trim($h)), $header);
}

/**
 * Get a value from an indexed row using the header array.
 * Column name matching is case-insensitive.
 *
 * @param array  $row      Indexed row from fgetcsv()
 * @param array  $header   Header array from csv_parse_header()
 * @param string $name     Column name to look up
 * @param string $default  Default if column not found
 */
function csv_get_col(array $row, array $header, string $name, string $default = ''): string {
    $idx = array_search(strtolower(trim($name)), $header, true);
    return ($idx !== false && isset($row[$idx])) ? trim((string) $row[$idx]) : $default;
}
```

- [ ] **Step 4: Create `data_tools/includes/pdf_helpers.php`**

```php
<?php
/**
 * data_tools/includes/pdf_helpers.php
 * Thin Dompdf wrapper. Call pdf_render_html() to stream a PDF download.
 */

require_once __DIR__ . '/../../vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

/**
 * Render an HTML string as a PDF and stream it to the browser as a download.
 *
 * @param string $html         Full HTML document string
 * @param string $filename     Suggested download filename (e.g. 'invoice.pdf')
 * @param string $orientation  'portrait' or 'landscape'
 */
function pdf_render_html(string $html, string $filename, string $orientation = 'portrait'): void {
    $opts = new Options();
    $opts->set('isRemoteEnabled', false);      // never fetch remote assets
    $opts->set('isHtml5ParserEnabled', true);
    $opts->set('defaultFont', 'Helvetica');

    $pdf = new Dompdf($opts);
    $pdf->loadHtml($html);
    $pdf->setPaper('A4', $orientation);
    $pdf->render();
    $pdf->stream($filename, ['Attachment' => true]);
    exit;
}

/**
 * Return a safe filename slug for use as a PDF download name.
 */
function pdf_safe_name(string $raw): string {
    return preg_replace('/[^a-zA-Z0-9_\-]/', '_', $raw) . '.pdf';
}
```

- [ ] **Step 5: Create `data_tools/includes/sql_data_tools.php`**

```php
<?php
/**
 * data_tools/includes/sql_data_tools.php
 * Shared queries for data tools module. All queries scope to current_org_id().
 */

/**
 * Fetch sales (with customer + product info) between two dates.
 */
function dt_find_sales(string $start, string $end): array {
    global $db;
    return $db->prepare_select(
        "SELECT o.id AS order_id, o.created_at AS order_date, o.status,
                c.name AS customer_name,
                p.name AS product_name, p.sku,
                s.qty, s.price,
                (s.qty * s.price) AS line_total
           FROM orders o
           JOIN customers c ON c.id = o.customer_id
           JOIN sales    s ON s.order_id = o.id
           JOIN products p ON p.id = s.product_id
          WHERE o.org_id = ?
            AND DATE(o.created_at) BETWEEN ? AND ?
            AND o.deleted_at IS NULL
          ORDER BY o.created_at, o.id",
        'iss', current_org_id(), $start, $end
    ) ?? [];
}

/**
 * Fetch stock movements between two dates for current org.
 */
function dt_find_stock_movements(string $start, string $end): array {
    global $db;
    return $db->prepare_select(
        "SELECT st.*, p.name AS product_name, p.sku
           FROM stock st
           JOIN products p ON p.id = st.product_id
          WHERE p.org_id = ?
            AND st.date BETWEEN ? AND ?
            AND st.deleted_at IS NULL
          ORDER BY st.date, st.id",
        'iss', current_org_id(), $start, $end
    ) ?? [];
}
```

- [ ] **Step 6: Run full tests**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: DataToolsTest passes, no regressions.

- [ ] **Step 7: Commit**

```bash
git add data_tools/includes/ tests/DataToolsTest.php
git commit -m "feat(data-tools): csv_helpers, pdf_helpers, sql_data_tools + tests"
```

---

## Task 3: Export Module

**Files:**
- Create: `data_tools/export.php` (redirect stub)
- Create: `data_tools/export/index.php`
- Create: `data_tools/export/products.php`
- Create: `data_tools/export/customers.php`
- Create: `data_tools/export/categories.php`
- Create: `data_tools/export/sales.php`
- Create: `data_tools/export/stock.php`

- [ ] **Step 1: Create `data_tools/export.php`**

```php
<?php header('Location: export/index.php'); exit;
```

- [ ] **Step 2: Create `data_tools/export/index.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../../includes/load.php';
page_require_level(ROLE_USER);

$page_title = 'Export';
include '../../layouts/header.php';
?>
<div class="row"><div class="col-md-8 offset-md-2">
  <div class="card">
    <div class="card-header"><strong>Export Data</strong></div>
    <div class="card-body">
      <p class="text-muted">Download your data as CSV files for use in spreadsheets.</p>
      <div class="list-group">
        <a href="products.php"   class="list-group-item list-group-item-action">Products (CSV)</a>
        <a href="customers.php"  class="list-group-item list-group-item-action">Customers (CSV)</a>
        <a href="categories.php" class="list-group-item list-group-item-action">Categories (CSV)</a>
        <a href="sales.php"      class="list-group-item list-group-item-action">Sales (CSV, current month)</a>
        <a href="stock.php"      class="list-group-item list-group-item-action">Stock Movements (CSV, current month)</a>
      </div>
    </div>
  </div>
</div></div>
<?php include '../../layouts/footer.php'; ?>
```

- [ ] **Step 3: Create `data_tools/export/products.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../../includes/load.php';
page_require_level(ROLE_USER);
require_once '../includes/csv_helpers.php';

global $db;
$rows = $db->prepare_select(
    "SELECT p.name, p.sku, p.location, p.quantity, p.low_stock_threshold,
            p.buy_price, p.sale_price, c.name AS category
       FROM products p
       LEFT JOIN categories c ON c.id = p.category_id
      WHERE p.org_id = ? AND p.deleted_at IS NULL
      ORDER BY p.name",
    'i', current_org_id()
) ?? [];

csv_headers('products_' . date('Y-m-d') . '.csv');
csv_write_rows(
    ['Name', 'SKU', 'Location', 'Quantity', 'Low Stock Threshold', 'Buy Price', 'Sale Price', 'Category'],
    $rows
);
exit;
```

- [ ] **Step 4: Create `data_tools/export/customers.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../../includes/load.php';
page_require_level(ROLE_USER);
require_once '../includes/csv_helpers.php';

global $db;
$rows = $db->prepare_select(
    "SELECT name, address, city, region, postcode, telephone, email, paymethod
       FROM customers
      WHERE org_id = ? AND deleted_at IS NULL
      ORDER BY name",
    'i', current_org_id()
) ?? [];

csv_headers('customers_' . date('Y-m-d') . '.csv');
csv_write_rows(['Name','Address','City','Region','Postcode','Telephone','Email','Pay Method'], $rows);
exit;
```

- [ ] **Step 5: Create `data_tools/export/categories.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../../includes/load.php';
page_require_level(ROLE_USER);
require_once '../includes/csv_helpers.php';

global $db;
$rows = $db->prepare_select(
    "SELECT name FROM categories WHERE org_id = ? ORDER BY name",
    'i', current_org_id()
) ?? [];

csv_headers('categories_' . date('Y-m-d') . '.csv');
csv_write_rows(['Category Name'], $rows);
exit;
```

- [ ] **Step 6: Create `data_tools/export/sales.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../../includes/load.php';
page_require_level(ROLE_USER);
require_once '../includes/csv_helpers.php';
require_once '../includes/sql_data_tools.php';

$start = sanitize_input($_GET['start'] ?? date('Y-m-01'));
$end   = sanitize_input($_GET['end']   ?? date('Y-m-t'));
$rows  = dt_find_sales($start, $end);

csv_headers('sales_' . $start . '_to_' . $end . '.csv');
csv_write_rows(
    ['Order ID','Order Date','Status','Customer','Product','SKU','Qty','Unit Price','Line Total'],
    $rows
);
exit;
```

- [ ] **Step 7: Create `data_tools/export/stock.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../../includes/load.php';
page_require_level(ROLE_USER);
require_once '../includes/csv_helpers.php';
require_once '../includes/sql_data_tools.php';

$start = sanitize_input($_GET['start'] ?? date('Y-m-01'));
$end   = sanitize_input($_GET['end']   ?? date('Y-m-t'));
$rows  = dt_find_stock_movements($start, $end);

csv_headers('stock_' . $start . '_to_' . $end . '.csv');
csv_write_rows(['Product','SKU','Quantity','Comments','Date'], $rows);
exit;
```

- [ ] **Step 8: Run tests**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: no regressions.

- [ ] **Step 9: Commit**

```bash
git add data_tools/export.php data_tools/export/
git commit -m "feat(data-tools): CSV export for products, customers, categories, sales, stock"
```

---

## Task 4: Import Module

**Files:**
- Create: `data_tools/import.php` (redirect stub)
- Create: `data_tools/import/index.php`
- Create: `data_tools/import/process.php`
- Create: `data_tools/import/products.php`
- Create: `data_tools/import/customers.php`
- Create: `data_tools/import/categories.php`

- [ ] **Step 1: Create `data_tools/import.php`**

```php
<?php header('Location: import/index.php'); exit;
```

- [ ] **Step 2: Create `data_tools/import/index.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../../includes/load.php';
page_require_level(ROLE_SUPERVISOR);

$page_title = 'Import';
include '../../layouts/header.php';
?>
<div class="row"><div class="col-md-8 offset-md-2">
  <div class="card">
    <div class="card-header"><strong>Import Data from CSV</strong></div>
    <div class="card-body">
      <?php echo display_msg($msg); ?>
      <p class="text-muted">Upload a CSV file to bulk-import data. Download the template below first.</p>

      <h6>Products</h6>
      <p class="small text-muted">Required columns: <code>name, sku, buy_price, sale_price</code>. Optional: <code>location, quantity, low_stock_threshold, category</code></p>
      <form method="post" action="process.php" enctype="multipart/form-data" class="mb-3">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="import_type" value="products">
        <div class="input-group">
          <input type="file" name="file" class="form-control" accept=".csv" required>
          <button type="submit" class="btn btn-primary">Import Products</button>
        </div>
      </form>

      <h6>Customers</h6>
      <p class="small text-muted">Required: <code>name, city, region</code>. Optional: <code>address, postcode, telephone, email, paymethod</code></p>
      <form method="post" action="process.php" enctype="multipart/form-data" class="mb-3">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="import_type" value="customers">
        <div class="input-group">
          <input type="file" name="file" class="form-control" accept=".csv" required>
          <button type="submit" class="btn btn-primary">Import Customers</button>
        </div>
      </form>

      <h6>Categories</h6>
      <p class="small text-muted">Required: <code>name</code></p>
      <form method="post" action="process.php" enctype="multipart/form-data" class="mb-3">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="import_type" value="categories">
        <div class="input-group">
          <input type="file" name="file" class="form-control" accept=".csv" required>
          <button type="submit" class="btn btn-primary">Import Categories</button>
        </div>
      </form>
    </div>
  </div>
</div></div>
<?php include '../../layouts/footer.php'; ?>
```

- [ ] **Step 3: Create `data_tools/import/process.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../../includes/load.php';
page_require_level(ROLE_SUPERVISOR);
require_once '../includes/csv_helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect('index.php'); }
if (!verify_csrf()) { $session->msg('d', 'Invalid CSRF token.'); redirect('index.php'); }

$type = sanitize_input($_POST['import_type'] ?? '');
$allowed = ['products', 'customers', 'categories'];
if (!in_array($type, $allowed, true)) {
    $session->msg('d', 'Unknown import type.');
    redirect('index.php');
}

$file = $_FILES['file'] ?? [];
$check = csv_validate_upload($file);
if ($check !== true) {
    $session->msg('d', $check);
    redirect('index.php');
}

require_once "$type.php";  // delegates to products.php / customers.php / categories.php
```

- [ ] **Step 4: Create `data_tools/import/products.php`**

```php
<?php
// SPDX-License-Identifier: MIT
// Called by process.php after validation. $file is already available.
global $db;

$handle = fopen($file['tmp_name'], 'r');
$header = csv_parse_header($handle);

$inserted = 0;
$skipped  = 0;
$errors   = [];
$org_id   = current_org_id();

// Resolve category name → id (cached)
$cat_cache = [];
$get_cat_id = function(string $cat_name) use ($db, $org_id, &$cat_cache): ?int {
    if (empty($cat_name)) return null;
    $key = strtolower($cat_name);
    if (!isset($cat_cache[$key])) {
        $row = $db->prepare_select_one(
            "SELECT id FROM categories WHERE org_id = ? AND name = ? LIMIT 1",
            'is', $org_id, $cat_name
        );
        if (!$row) {
            $db->prepare_query(
                "INSERT IGNORE INTO categories (org_id, name) VALUES (?, ?)",
                'is', $org_id, $cat_name
            );
            $new_id = (int) $db->insert_id();
            $cat_cache[$key] = $new_id ?: null;
        } else {
            $cat_cache[$key] = (int) $row['id'];
        }
    }
    return $cat_cache[$key];
};

$line = 1;
while (($row = fgetcsv($handle)) !== false) {
    $line++;
    $name     = csv_get_col($row, $header, 'name');
    $sku      = csv_get_col($row, $header, 'sku');
    $buy      = (float) csv_get_col($row, $header, 'buy_price', '0');
    $sale     = (float) csv_get_col($row, $header, 'sale_price', '0');
    $location = csv_get_col($row, $header, 'location', '');
    $qty      = (int)   csv_get_col($row, $header, 'quantity',   '0');
    $threshold= (int)   csv_get_col($row, $header, 'low_stock_threshold', '0');
    $cat_name = csv_get_col($row, $header, 'category', '');
    $cat_id   = $get_cat_id($cat_name);

    if (empty($name)) { $errors[] = "Line $line: name is required."; $skipped++; continue; }

    $existing = $db->prepare_select_one(
        "SELECT id FROM products WHERE org_id = ? AND (name = ? OR (sku != '' AND sku = ?)) AND deleted_at IS NULL LIMIT 1",
        'iss', $org_id, $name, $sku ?: '__NOSKU__'
    );
    if ($existing) { $skipped++; continue; } // skip duplicates

    $db->prepare_query(
        "INSERT INTO products (org_id, name, sku, location, quantity, low_stock_threshold,
                               buy_price, sale_price, category_id, media_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)",
        'isssiiiddi',
        $org_id, $name, $sku, $location, $qty, $threshold, $buy, $sale, $cat_id
    );
    $inserted++;
}
fclose($handle);

$summary = "Products imported: $inserted added, $skipped skipped.";
if (!empty($errors)) {
    $summary .= ' Errors: ' . implode('; ', array_slice($errors, 0, 5));
    if (count($errors) > 5) $summary .= ' (and ' . (count($errors) - 5) . ' more)';
}
$session->msg($errors ? 'w' : 's', $summary);
redirect('index.php');
```

- [ ] **Step 5: Create `data_tools/import/customers.php`**

```php
<?php
// SPDX-License-Identifier: MIT
// Called by process.php after validation.
global $db;

$handle   = fopen($file['tmp_name'], 'r');
$header   = csv_parse_header($handle);
$inserted = 0;
$skipped  = 0;
$org_id   = current_org_id();

while (($row = fgetcsv($handle)) !== false) {
    $name  = csv_get_col($row, $header, 'name');
    $city  = csv_get_col($row, $header, 'city');
    $region= csv_get_col($row, $header, 'region');
    if (empty($name) || empty($city) || empty($region)) { $skipped++; continue; }

    $existing = $db->prepare_select_one(
        "SELECT id FROM customers WHERE org_id = ? AND name = ? AND deleted_at IS NULL LIMIT 1",
        'is', $org_id, $name
    );
    if ($existing) { $skipped++; continue; }

    $db->prepare_query(
        "INSERT INTO customers (org_id, name, address, city, region, postcode, telephone, email, paymethod)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        'issssssss',
        $org_id, $name,
        csv_get_col($row, $header, 'address'),
        $city, $region,
        csv_get_col($row, $header, 'postcode'),
        csv_get_col($row, $header, 'telephone'),
        csv_get_col($row, $header, 'email'),
        csv_get_col($row, $header, 'paymethod')
    );
    $inserted++;
}
fclose($handle);

$session->msg('s', "Customers imported: $inserted added, $skipped skipped.");
redirect('index.php');
```

- [ ] **Step 6: Create `data_tools/import/categories.php`**

```php
<?php
// SPDX-License-Identifier: MIT
// Called by process.php after validation.
global $db;

$handle   = fopen($file['tmp_name'], 'r');
$header   = csv_parse_header($handle);
$inserted = 0;
$skipped  = 0;
$org_id   = current_org_id();

while (($row = fgetcsv($handle)) !== false) {
    $name = csv_get_col($row, $header, 'name');
    if (empty($name)) { $skipped++; continue; }

    $db->prepare_query(
        "INSERT IGNORE INTO categories (org_id, name) VALUES (?, ?)",
        'is', $org_id, $name
    );
    $affected = $db->affected_rows();
    $affected > 0 ? $inserted++ : $skipped++;
}
fclose($handle);

$session->msg('s', "Categories imported: $inserted added, $skipped skipped (duplicates ignored).");
redirect('index.php');
```

- [ ] **Step 7: Run tests**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: no regressions.

- [ ] **Step 8: Commit**

```bash
git add data_tools/import.php data_tools/import/
git commit -m "feat(data-tools): CSV import for products, customers, categories"
```

---

## Task 5: PDF Reports

**Files:**
- Create: `data_tools/reports/index.php`
- Create: `data_tools/reports/sales_report.php`
- Create: `data_tools/reports/stock_report.php`
- Create: `data_tools/reports/sales_invoice.php`

- [ ] **Step 1: Create `data_tools/reports/index.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../../includes/load.php';
page_require_level(ROLE_USER);

$start = date('Y-m-01');
$end   = date('Y-m-t');
$page_title = 'Reports';
include '../../layouts/header.php';
?>
<div class="row"><div class="col-md-8 offset-md-2">
  <div class="card">
    <div class="card-header"><strong>Reports</strong></div>
    <div class="card-body">
      <form method="get" class="row g-2 mb-4">
        <div class="col-auto">
          <label class="form-label">From</label>
          <input type="date" name="start" class="form-control" value="<?php echo htmlspecialchars($start, ENT_QUOTES, 'UTF-8'); ?>">
        </div>
        <div class="col-auto">
          <label class="form-label">To</label>
          <input type="date" name="end" class="form-control" value="<?php echo htmlspecialchars($end, ENT_QUOTES, 'UTF-8'); ?>">
        </div>
        <div class="col-auto align-self-end d-flex gap-2">
          <a href="sales_report.php?start=<?php echo urlencode($start); ?>&end=<?php echo urlencode($end); ?>&format=pdf"
             class="btn btn-danger">Sales PDF</a>
          <a href="sales_report.php?start=<?php echo urlencode($start); ?>&end=<?php echo urlencode($end); ?>&format=csv"
             class="btn btn-success">Sales CSV</a>
          <a href="stock_report.php?format=pdf" class="btn btn-danger">Stock PDF</a>
          <a href="stock_report.php?format=csv" class="btn btn-success">Stock CSV</a>
        </div>
      </form>
    </div>
  </div>
</div></div>
<?php include '../../layouts/footer.php'; ?>
```

- [ ] **Step 2: Create `data_tools/reports/sales_report.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../../includes/load.php';
page_require_level(ROLE_USER);
require_once '../includes/csv_helpers.php';
require_once '../includes/pdf_helpers.php';
require_once '../includes/sql_data_tools.php';

$start  = sanitize_input($_GET['start'] ?? date('Y-m-01'));
$end    = sanitize_input($_GET['end']   ?? date('Y-m-t'));
$format = sanitize_input($_GET['format'] ?? 'pdf');
$rows   = dt_find_sales($start, $end);

$total = array_sum(array_column($rows, 'line_total'));

if ($format === 'csv') {
    csv_headers("sales_report_{$start}_to_{$end}.csv");
    csv_write_rows(
        ['Order ID','Order Date','Status','Customer','Product','SKU','Qty','Unit Price','Line Total'],
        $rows
    );
    exit;
}

// PDF
$app_name = defined('APP_NAME') ? APP_NAME : 'Inventory';
$html = <<<HTML
<!DOCTYPE html><html><head>
<meta charset="UTF-8">
<style>
  body{font-family:Helvetica,sans-serif;font-size:12px;color:#222}
  h1{font-size:18px;margin-bottom:4px}
  p{margin:0 0 8px}
  table{width:100%;border-collapse:collapse;margin-top:12px}
  th,td{border:1px solid #ccc;padding:6px 8px;text-align:left}
  th{background:#f0f0f0;font-weight:bold}
  .total{font-weight:bold;text-align:right}
</style></head><body>
<h1>$app_name — Sales Report</h1>
<p>Period: $start to $end</p>
<table>
  <thead><tr>
    <th>Order</th><th>Date</th><th>Customer</th><th>Product</th>
    <th>Qty</th><th>Unit Price</th><th>Line Total</th>
  </tr></thead>
  <tbody>
HTML;
foreach ($rows as $r) {
    $lt = number_format((float)$r['line_total'], 2);
    $pr = number_format((float)$r['price'], 2);
    $html .= "<tr>"
        . "<td>" . htmlspecialchars($r['order_id'], ENT_QUOTES, 'UTF-8') . "</td>"
        . "<td>" . htmlspecialchars(substr($r['order_date'], 0, 10), ENT_QUOTES, 'UTF-8') . "</td>"
        . "<td>" . htmlspecialchars($r['customer_name'], ENT_QUOTES, 'UTF-8') . "</td>"
        . "<td>" . htmlspecialchars($r['product_name'],  ENT_QUOTES, 'UTF-8') . "</td>"
        . "<td>" . (int)$r['qty'] . "</td>"
        . "<td>$pr</td><td>$lt</td></tr>\n";
}
$html .= "<tr><td colspan='6' class='total'>Total:</td><td class='total'>"
    . number_format($total, 2) . "</td></tr>";
$html .= "</tbody></table></body></html>";

pdf_render_html($html, pdf_safe_name("sales_report_{$start}_to_{$end}"), 'landscape');
```

- [ ] **Step 3: Create `data_tools/reports/stock_report.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../../includes/load.php';
page_require_level(ROLE_USER);
require_once '../includes/csv_helpers.php';
require_once '../includes/pdf_helpers.php';

$format  = sanitize_input($_GET['format'] ?? 'pdf');
global $db;
$rows = $db->prepare_select(
    "SELECT p.name, p.sku, p.location, p.quantity, p.low_stock_threshold,
            p.buy_price, p.sale_price,
            (p.quantity * p.buy_price) AS stock_value
       FROM products p
      WHERE p.org_id = ? AND p.deleted_at IS NULL
      ORDER BY p.name",
    'i', current_org_id()
) ?? [];

if ($format === 'csv') {
    csv_headers('stock_report_' . date('Y-m-d') . '.csv');
    csv_write_rows(
        ['Product','SKU','Location','Qty','Low Threshold','Buy Price','Sale Price','Stock Value'],
        $rows
    );
    exit;
}

$app_name   = defined('APP_NAME') ? APP_NAME : 'Inventory';
$total_val  = array_sum(array_column($rows, 'stock_value'));

$html = <<<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>
  body{font-family:Helvetica,sans-serif;font-size:11px;color:#222}
  h1{font-size:16px;margin-bottom:4px}
  table{width:100%;border-collapse:collapse}
  th,td{border:1px solid #ccc;padding:5px 7px}
  th{background:#f0f0f0;font-weight:bold}
  .low{color:#c00;font-weight:bold}
  .total{font-weight:bold;text-align:right}
</style></head><body>
<h1>$app_name — Stock Report</h1>
<p>Generated: HTML;
$html .= date('Y-m-d H:i') . "</p><table><thead><tr>"
    . "<th>Product</th><th>SKU</th><th>Location</th><th>Qty</th>"
    . "<th>Threshold</th><th>Buy Price</th><th>Sale Price</th><th>Value</th>"
    . "</tr></thead><tbody>\n";
foreach ($rows as $r) {
    $low   = ((int)$r['quantity'] <= (int)$r['low_stock_threshold']) ? ' class="low"' : '';
    $html .= "<tr$low>"
        . "<td>" . htmlspecialchars($r['name'],     ENT_QUOTES, 'UTF-8') . "</td>"
        . "<td>" . htmlspecialchars($r['sku'],      ENT_QUOTES, 'UTF-8') . "</td>"
        . "<td>" . htmlspecialchars($r['location'], ENT_QUOTES, 'UTF-8') . "</td>"
        . "<td>" . (int)$r['quantity'] . "</td>"
        . "<td>" . (int)$r['low_stock_threshold'] . "</td>"
        . "<td>" . number_format((float)$r['buy_price'],  2) . "</td>"
        . "<td>" . number_format((float)$r['sale_price'], 2) . "</td>"
        . "<td>" . number_format((float)$r['stock_value'],2) . "</td></tr>\n";
}
$html .= "<tr><td colspan='7' class='total'>Total Stock Value:</td><td class='total'>"
    . number_format($total_val, 2) . "</td></tr>"
    . "</tbody></table></body></html>";

pdf_render_html($html, pdf_safe_name('stock_report_' . date('Y-m-d')));
```

- [ ] **Step 4: Create `data_tools/reports/sales_invoice.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../../includes/load.php';
page_require_level(ROLE_USER);
require_once '../includes/pdf_helpers.php';

$order_id = (int) ($_GET['order_id'] ?? 0);
if (!$order_id) { $session->msg('d', 'Order ID required.'); redirect('index.php'); }

global $db;
$order = $db->prepare_select_one(
    "SELECT o.*, c.name AS customer_name, c.address, c.city, c.region, c.postcode
       FROM orders o
       LEFT JOIN customers c ON c.id = o.customer_id
      WHERE o.id = ? AND o.org_id = ? LIMIT 1",
    'ii', $order_id, current_org_id()
);
if (!$order) { $session->msg('d', 'Order not found.'); redirect('index.php'); }

$items = $db->prepare_select(
    "SELECT s.qty, s.price, (s.qty * s.price) AS line_total,
            p.name AS product_name, p.sku
       FROM sales s
       JOIN products p ON p.id = s.product_id
      WHERE s.order_id = ?",
    'i', $order_id
) ?? [];

$total    = array_sum(array_column($items, 'line_total'));
$app_name = defined('APP_NAME') ? APP_NAME : 'Inventory';
$date     = date('Y-m-d');

$html = <<<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>
  body{font-family:Helvetica,sans-serif;font-size:12px;color:#222;padding:20px}
  .header{display:flex;justify-content:space-between;margin-bottom:24px}
  h1{font-size:22px;margin:0}
  h2{font-size:14px;margin:0 0 4px}
  table{width:100%;border-collapse:collapse;margin-top:16px}
  th,td{border:1px solid #ccc;padding:7px 10px;text-align:left}
  th{background:#f0f0f0}
  .total{font-weight:bold;text-align:right}
</style></head><body>
<div class="header">
  <div><h1>$app_name</h1><p>Invoice</p></div>
  <div>
    <h2>Order #$order_id</h2>
    <p>Date: $date</p>
  </div>
</div>
<h2>Bill To</h2>
<p>HTML;
$html .= htmlspecialchars($order['customer_name'] ?? '', ENT_QUOTES, 'UTF-8') . "<br>"
    . htmlspecialchars($order['address']  ?? '', ENT_QUOTES, 'UTF-8') . "<br>"
    . htmlspecialchars($order['city']     ?? '', ENT_QUOTES, 'UTF-8') . ", "
    . htmlspecialchars($order['region']   ?? '', ENT_QUOTES, 'UTF-8') . " "
    . htmlspecialchars($order['postcode'] ?? '', ENT_QUOTES, 'UTF-8')
    . "</p><table><thead><tr>"
    . "<th>Product</th><th>SKU</th><th>Qty</th><th>Unit Price</th><th>Total</th>"
    . "</tr></thead><tbody>\n";
foreach ($items as $i) {
    $html .= "<tr>"
        . "<td>" . htmlspecialchars($i['product_name'], ENT_QUOTES, 'UTF-8') . "</td>"
        . "<td>" . htmlspecialchars($i['sku'],          ENT_QUOTES, 'UTF-8') . "</td>"
        . "<td>" . (int)$i['qty'] . "</td>"
        . "<td>" . number_format((float)$i['price'],     2) . "</td>"
        . "<td>" . number_format((float)$i['line_total'],2) . "</td></tr>\n";
}
$html .= "<tr><td colspan='4' class='total'>Total:</td><td class='total'>"
    . number_format($total, 2) . "</td></tr>"
    . "</tbody></table></body></html>";

pdf_render_html($html, pdf_safe_name("invoice_order_{$order_id}"));
```

- [ ] **Step 5: Run full test suite**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: no regressions.

- [ ] **Step 6: Commit**

```bash
git add data_tools/reports/
git commit -m "feat(data-tools): PDF reports (sales, stock, invoice) via Dompdf"
```

---

## Task 6: Module Landing + Nav Links

**Files:**
- Create: `data_tools/index.php`
- Modify: `layouts/admin_menu.php`
- Modify: `layouts/special_menu.php`

- [ ] **Step 1: Create `data_tools/index.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_USER);

$page_title = 'Data Tools';
include '../layouts/header.php';
?>
<div class="row"><div class="col-md-8 offset-md-2">
  <div class="row g-3">
    <div class="col-md-4">
      <div class="card h-100">
        <div class="card-body text-center">
          <h5>Export</h5>
          <p class="text-muted small">Download data as CSV</p>
          <a href="export/index.php" class="btn btn-success">Go to Export</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card h-100">
        <div class="card-body text-center">
          <h5>Import</h5>
          <p class="text-muted small">Upload CSV to bulk-add records</p>
          <a href="import/index.php" class="btn btn-primary">Go to Import</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card h-100">
        <div class="card-body text-center">
          <h5>Reports</h5>
          <p class="text-muted small">Generate PDF or CSV reports</p>
          <a href="reports/index.php" class="btn btn-danger">Go to Reports</a>
        </div>
      </div>
    </div>
  </div>
</div></div>
<?php include '../layouts/footer.php'; ?>
```

- [ ] **Step 2: Add nav link to `layouts/admin_menu.php`**

```html
<li class="nav-item">
  <a class="nav-link" href="<?php echo $base; ?>/data_tools/index.php">Data Tools</a>
</li>
```

- [ ] **Step 3: Add nav link to `layouts/special_menu.php`**

Same link as above.

- [ ] **Step 4: Run tests**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: no regressions.

- [ ] **Step 5: Commit**

```bash
git add data_tools/index.php layouts/admin_menu.php layouts/special_menu.php
git commit -m "feat(data-tools): module landing page + nav links"
```

---

## Self-Review Checklist

- [x] `composer.json` uses `^3.1` — compatible with current Dompdf
- [x] `pdf_render_html()` sets `isRemoteEnabled=false` — no external HTTP in PDF render
- [x] `csv_validate_upload()` checks file size (5MB cap) + MIME type + extension
- [x] `csv_get_col()` is case-insensitive — handles exported-then-reimported files
- [x] Import uses `INSERT IGNORE` for categories (idempotent) and skip-on-duplicate for products/customers
- [x] All exports scoped to `current_org_id()` — no cross-org data leakage
- [x] Sales report query joins `orders` (soft-delete filtered) → only non-deleted records
- [x] Stock report filters `deleted_at IS NULL` on products
- [x] `html_specialchars(ENT_QUOTES, UTF-8)` on all user data in PDF HTML templates
- [x] CSRF on all import POSTs
- [x] All pages call `page_require_level()` before any DB access
- [x] `process.php` whitelists `import_type` values before `require_once`
- [x] Invoice endpoint scopes by `org_id` — no cross-org invoice access
