# Tenancy Query Hardening Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix `join_product_table()` and `find_recent_product_added()` in `includes/sql.php` — the two functions that bypass org tenancy and soft-delete filtering, leaking cross-org product data on the products list and home dashboard.

**Architecture:** Both functions build raw SQL strings with `find_by_sql()`. Add `WHERE p.deleted_at IS NULL` and `AND p.org_id = N` (guarded by `current_org_id_safe()`) matching the pattern already used in `find_recent_sale_added()` and `find_highest_selling_product()`. Add two TenancyTest cases to verify the fix.

**Tech Stack:** PHP 8.x, MySQLi via `$db->prepare_select()`, existing `tenancy_fixtures.php` helpers

---

### Task 1: Fix `join_product_table()` in `includes/sql.php`

**Files:**
- Modify: `includes/sql.php:900-910`

The function currently fetches ALL products from ALL orgs with no `deleted_at IS NULL` guard:

```php
// BEFORE (lines 900-910)
function join_product_table() {
    global $db;
    $sql  =" SELECT p.id,p.name,p.sku,p.location,p.quantity,p.buy_price,p.sale_price,p.media_id,p.date,c.name";
    $sql  .=" AS category,m.file_name AS image";
    $sql  .=" FROM products p";
    $sql  .=" LEFT JOIN categories c ON c.id = p.category_id";
    $sql  .=" LEFT JOIN media m ON m.id = p.media_id";
    $sql  .=" ORDER BY p.id ASC";
    return find_by_sql($sql);
}
```

- [ ] **Step 1: Replace the function body**

Edit `includes/sql.php`, replace the function with:

```php
function join_product_table() {
    global $db;
    $sql  =" SELECT p.id,p.name,p.sku,p.location,p.quantity,p.buy_price,p.sale_price,p.media_id,p.date,c.name";
    $sql  .=" AS category,m.file_name AS image";
    $sql  .=" FROM products p";
    $sql  .=" LEFT JOIN categories c ON c.id = p.category_id";
    $sql  .=" LEFT JOIN media m ON m.id = p.media_id";
    $sql  .=" WHERE p.deleted_at IS NULL";
    $org_id = current_org_id_safe();
    if ($org_id !== null) {
        $sql .= " AND p.org_id = " . $org_id;
    }
    $sql  .=" ORDER BY p.id ASC";
    return find_by_sql($sql);
}
```

- [ ] **Step 2: Verify syntax**

```bash
php -l includes/sql.php
```
Expected: `No syntax errors detected in includes/sql.php`

---

### Task 2: Fix `find_recent_product_added()` in `includes/sql.php`

**Files:**
- Modify: `includes/sql.php:1224-1240`

The function filters by `org_id` when set but never filters `p.deleted_at IS NULL`, so soft-deleted products appear on the home dashboard.

```php
// BEFORE (lines 1224-1240)
function find_recent_product_added($limit) {
    global $db;
    $sql   = " SELECT p.id,p.name,p.sale_price,p.media_id,c.name AS category,";
    $sql  .= "m.file_name AS image FROM products p";
    $sql  .= " LEFT JOIN categories c ON c.id = p.category_id";
    $sql  .= " LEFT JOIN media m ON m.id = p.media_id";
    $org_id = current_org_id_safe();
    if ($org_id !== null) {
        $sql  .= " WHERE p.org_id = " . $org_id;
    }
    $sql  .= " ORDER BY p.id DESC LIMIT ".$db->escape((int)$limit);
    return find_by_sql($sql);
}
```

- [ ] **Step 1: Replace the function body**

```php
function find_recent_product_added($limit) {
    global $db;
    $sql   = " SELECT p.id,p.name,p.sale_price,p.media_id,c.name AS category,";
    $sql  .= "m.file_name AS image FROM products p";
    $sql  .= " LEFT JOIN categories c ON c.id = p.category_id";
    $sql  .= " LEFT JOIN media m ON m.id = p.media_id";
    $org_id = current_org_id_safe();
    if ($org_id !== null) {
        $sql  .= " WHERE p.deleted_at IS NULL AND p.org_id = " . $org_id;
    } else {
        $sql  .= " WHERE p.deleted_at IS NULL";
    }
    $sql  .= " ORDER BY p.id DESC LIMIT ".$db->escape((int)$limit);
    return find_by_sql($sql);
}
```

- [ ] **Step 2: Verify syntax**

```bash
php -l includes/sql.php
```
Expected: `No syntax errors detected`

---

### Task 3: Write failing tests

**Files:**
- Modify: `tests/TenancyTest.php` (append after the last `test(...)` call, before the runner at the bottom)

- [ ] **Step 1: Locate the end of TenancyTest.php**

```bash
grep -n "^test\|^// " tests/TenancyTest.php | tail -10
```

Note the last test's closing line number.

- [ ] **Step 2: Append two new tests**

Add at the end of the test block (before any runner/output code):

```php
// T09: join_product_table() tenancy + soft-delete filtering
test('join_product_table() excludes cross-org products', function () {
    fixture_ensure_test_org();
    fixture_add_member(2, 1);

    $org2_prod_id = fixture_create_product(2, 'JOIN_CROSS_ORG', 'Join Cross Org');

    setup_test_org_session(1);
    $products = join_product_table();
    $found = array_filter($products ?? [], fn($p) => (int)$p['id'] === $org2_prod_id);
    check(count($found) === 0, "join_product_table() must not return cross-org products");

    fixture_teardown_org2();
});

test('join_product_table() excludes soft-deleted products', function () {
    fixture_ensure_test_org();

    // Create a product in org 1
    $prod_id = fixture_create_product(1, 'JOIN_SOFTDEL', 'Join Soft Del');

    setup_test_org_session(1);
    $before = join_product_table();
    $found_before = array_filter($before ?? [], fn($p) => (int)$p['id'] === $prod_id);
    check(count($found_before) === 1, "join_product_table() must see the live product");

    // Soft-delete it
    soft_delete_by_id('products', $prod_id, 1);

    $after = join_product_table();
    $found_after = array_filter($after ?? [], fn($p) => (int)$p['id'] === $prod_id);
    check(count($found_after) === 0, "join_product_table() must not return soft-deleted products");

    // Cleanup: hard-delete the soft-deleted row
    global $db;
    $db->prepare_query("DELETE FROM products WHERE id = ?", 'i', $prod_id);
});

test('find_recent_product_added() excludes soft-deleted products', function () {
    fixture_ensure_test_org();

    $prod_id = fixture_create_product(1, 'RECENT_SOFTDEL', 'Recent Soft Del');

    setup_test_org_session(1);
    $before = find_recent_product_added(50);
    $found_before = array_filter($before ?? [], fn($p) => (int)$p['id'] === $prod_id);
    check(count($found_before) === 1, "find_recent_product_added() must see the live product");

    soft_delete_by_id('products', $prod_id, 1);

    $after = find_recent_product_added(50);
    $found_after = array_filter($after ?? [], fn($p) => (int)$p['id'] === $prod_id);
    check(count($found_after) === 0, "find_recent_product_added() must not return soft-deleted products");

    global $db;
    $db->prepare_query("DELETE FROM products WHERE id = ?", 'i', $prod_id);
});
```

- [ ] **Step 3: Run the tests — expect 3 new FAILs (red)**

```bash
php tests/TenancyTest.php 2>&1 | tail -20
```

Expected: 3 new FAILs for the three new test cases (the sql.php fix is not yet applied at this point — this step confirms the tests actually catch the bug before applying the fix). If running after Task 1+2, expect 3 PASSes.

---

### Task 4: Run full test suite and commit

- [ ] **Step 1: Run all PHP tests**

```bash
bash tests/run.sh 2>&1 | tail -20
```

Expected: all suites pass, including the 3 new TenancyTest cases.

- [ ] **Step 2: Commit**

```bash
git add includes/sql.php tests/TenancyTest.php
git commit -m "fix: join_product_table + find_recent_product_added tenancy + soft-delete gaps"
```
