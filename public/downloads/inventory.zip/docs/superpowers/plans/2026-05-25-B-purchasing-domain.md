# Plan B: Purchasing Domain — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Port the full purchasing domain from `cc-inventory` into `inventory`: supplier CRUD and a purchase order module with receive-goods workflow and stock auto-increment.

**Architecture:** Three new migrations (suppliers table, PO tables, org_id columns on both). One new `includes/sql_purchasing.php`. Two new module directories: `suppliers/` (5 files) and `purchasing/` (6 files). No changes to existing modules except adding `org_id` scoping and nav links. The `receive_purchase_order()` function uses a transaction via `$db->connection()->begin_transaction()` since `MySqli_DB` exposes the raw connection via `connection()`.

**Tech Stack:** PHP 8.1+, MySQLi via `MySqli_DB` (`prepare_query` / `prepare_select` / `prepare_select_one`), Bootstrap 5, migrations 025–027.

**DB note:** `inventory` is multi-tenant with `org_id` on all domain tables. Both `suppliers` and `purchase_orders` must carry `org_id` scoped to the current session org.

---

## File Map

| Action | File | Change |
|--------|------|--------|
| Create | `migrations/025_suppliers.up.sql` | New table |
| Create | `migrations/025_suppliers.down.sql` | Rollback |
| Create | `migrations/026_purchase_orders.up.sql` | New tables (po + po_items) |
| Create | `migrations/026_purchase_orders.down.sql` | Rollback |
| Create | `includes/sql_purchasing.php` | All supplier/PO query functions |
| Modify | `includes/load.php` | require_once sql_purchasing.php |
| Create | `suppliers/index.php` | Redirect stub |
| Create | `suppliers/suppliers.php` | Supplier list |
| Create | `suppliers/add_supplier.php` | Create form |
| Create | `suppliers/edit_supplier.php` | Edit form |
| Create | `suppliers/delete_supplier.php` | Delete POST handler |
| Create | `purchasing/index.php` | Redirect stub |
| Create | `purchasing/purchase_orders.php` | PO list |
| Create | `purchasing/add_purchase_order.php` | Create PO |
| Create | `purchasing/view_purchase_order.php` | PO detail |
| Create | `purchasing/edit_purchase_order.php` | Edit draft PO |
| Create | `purchasing/receive_purchase_order.php` | Mark goods received |
| Modify | `layouts/admin_menu.php` | Add Suppliers + Purchasing nav links |
| Modify | `layouts/special_menu.php` | Add Purchasing nav link |
| Create | `tests/PurchasingTest.php` | PHPUnit pure-function tests |

---

## Task 1: Suppliers Migration

**Files:**
- Create: `migrations/025_suppliers.up.sql`
- Create: `migrations/025_suppliers.down.sql`

- [ ] **Step 1: Create migration up**

```sql
-- Migration 025 — suppliers table.
-- Vendor/supplier records scoped to an org.
-- Reverse: see 025_suppliers.down.sql

SELECT 'Creating suppliers table...' AS step;

CREATE TABLE `suppliers` (
  `id`        INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `org_id`    INT UNSIGNED  NOT NULL DEFAULT 1,
  `name`      VARCHAR(200)  NOT NULL,
  `contact`   VARCHAR(150)  DEFAULT NULL,
  `email`     VARCHAR(255)  DEFAULT NULL,
  `telephone` VARCHAR(30)   DEFAULT NULL,
  `address`   TEXT          DEFAULT NULL,
  `status`    TINYINT(1)    NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_suppliers_org` (`org_id`),
  CONSTRAINT `fk_suppliers_org`
    FOREIGN KEY (`org_id`) REFERENCES `orgs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT 'suppliers created.' AS step;
```

Save to `migrations/025_suppliers.up.sql`.

- [ ] **Step 2: Create migration down**

```sql
DROP TABLE IF EXISTS `suppliers`;
```

Save to `migrations/025_suppliers.down.sql`.

- [ ] **Step 3: Apply migration**

```bash
mysql -u root -p inventory < migrations/025_suppliers.up.sql
```

Expected: `suppliers created.`

- [ ] **Step 4: Commit**

```bash
git add migrations/025_suppliers.up.sql migrations/025_suppliers.down.sql
git commit -m "feat(purchasing): add suppliers table (migration 025)"
```

---

## Task 2: Purchase Orders Migration

**Files:**
- Create: `migrations/026_purchase_orders.up.sql`
- Create: `migrations/026_purchase_orders.down.sql`

- [ ] **Step 1: Create migration up**

```sql
-- Migration 026 — purchase_orders and purchase_order_items tables.
-- Reverse: see 026_purchase_orders.down.sql

SELECT 'Creating purchase_orders table...' AS step;

CREATE TABLE `purchase_orders` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `org_id`      INT UNSIGNED NOT NULL DEFAULT 1,
  `supplier_id` INT UNSIGNED NOT NULL,
  `reference`   VARCHAR(100) DEFAULT NULL,
  `status`      ENUM('draft','ordered','partial','received','cancelled')
                NOT NULL DEFAULT 'draft',
  `notes`       TEXT DEFAULT NULL,
  `created_by`  INT UNSIGNED DEFAULT NULL,
  `received_at` DATE         DEFAULT NULL,
  `updated_at`  DATE         DEFAULT NULL,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_po_org`      (`org_id`),
  KEY `idx_po_supplier` (`supplier_id`),
  CONSTRAINT `fk_po_org`
    FOREIGN KEY (`org_id`) REFERENCES `orgs` (`id`),
  CONSTRAINT `fk_po_supplier`
    FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT 'Creating purchase_order_items table...' AS step;

CREATE TABLE `purchase_order_items` (
  `id`           INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `po_id`        INT UNSIGNED    NOT NULL,
  `product_id`   INT UNSIGNED    NOT NULL,
  `qty_ordered`  INT UNSIGNED    NOT NULL DEFAULT 0,
  `qty_received` INT UNSIGNED    NOT NULL DEFAULT 0,
  `unit_cost`    DECIMAL(10, 2)  NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `idx_poi_po`      (`po_id`),
  KEY `idx_poi_product` (`product_id`),
  CONSTRAINT `fk_poi_po`
    FOREIGN KEY (`po_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_poi_product`
    FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT 'purchase_orders and purchase_order_items created.' AS step;
```

Save to `migrations/026_purchase_orders.up.sql`.

- [ ] **Step 2: Create migration down**

```sql
DROP TABLE IF EXISTS `purchase_order_items`;
DROP TABLE IF EXISTS `purchase_orders`;
```

Save to `migrations/026_purchase_orders.down.sql`.

- [ ] **Step 3: Apply migration**

```bash
mysql -u root -p inventory < migrations/026_purchase_orders.up.sql
```

Expected: `purchase_orders and purchase_order_items created.`

- [ ] **Step 4: Commit**

```bash
git add migrations/026_purchase_orders.up.sql migrations/026_purchase_orders.down.sql
git commit -m "feat(purchasing): add purchase_orders + purchase_order_items tables (migration 026)"
```

---

## Task 3: SQL Purchasing Functions

**Files:**
- Create: `includes/sql_purchasing.php`
- Modify: `includes/load.php`
- Test: `tests/PurchasingTest.php`

- [ ] **Step 1: Write failing tests**

Create `tests/PurchasingTest.php`:

```php
<?php
use PHPUnit\Framework\TestCase;

class PurchasingTest extends TestCase {

    public function test_po_statuses_are_complete(): void {
        // Replicate the pure-logic part of po_statuses()
        $statuses = ['draft', 'ordered', 'partial', 'received', 'cancelled'];
        $this->assertCount(5, $statuses);
        $this->assertContains('draft',     $statuses);
        $this->assertContains('cancelled', $statuses);
    }

    public function test_po_status_class_returns_string(): void {
        $map = [
            'draft'     => 'secondary',
            'ordered'   => 'info',
            'partial'   => 'warning',
            'received'  => 'success',
            'cancelled' => 'danger',
        ];
        foreach ($map as $status => $expected) {
            $this->assertSame($expected, $map[$status]);
        }
    }

    public function test_qty_received_cannot_exceed_ordered(): void {
        $qty_ordered  = 10;
        $qty_received = 8;
        $incoming     = 5;
        // Enforce the cap: can only receive up to the remainder
        $capped = min($incoming, $qty_ordered - $qty_received);
        $this->assertSame(2, $capped);
    }
}
```

- [ ] **Step 2: Run tests (pure logic)**

```bash
php vendor/bin/phpunit tests/PurchasingTest.php -v
```

Expected: PASS (no DB required).

- [ ] **Step 3: Create `includes/sql_purchasing.php`**

```php
<?php
/**
 * includes/sql_purchasing.php
 * Supplier and purchase order queries (inventory multi-tenant port).
 * All queries scope to current_org_id().
 */

// ---------------------------------------------------------------------------
// Suppliers
// ---------------------------------------------------------------------------

function po_statuses(): array {
    return ['draft', 'ordered', 'partial', 'received', 'cancelled'];
}

/** Bootstrap 5 badge class for a PO status. */
function po_status_class(string $status): string {
    return [
        'draft'     => 'secondary',
        'ordered'   => 'info',
        'partial'   => 'warning',
        'received'  => 'success',
        'cancelled' => 'danger',
    ][$status] ?? 'secondary';
}

function find_all_suppliers(): array {
    global $db;
    return $db->prepare_select(
        "SELECT * FROM suppliers WHERE org_id = ? AND status = 1 ORDER BY name ASC",
        'i', current_org_id()
    ) ?? [];
}

function find_supplier(int $id): ?array {
    global $db;
    $row = $db->prepare_select_one(
        "SELECT * FROM suppliers WHERE id = ? AND org_id = ? LIMIT 1",
        'ii', $id, current_org_id()
    );
    return $row ?: null;
}

function create_supplier(array $data): int {
    global $db;
    $db->prepare_query(
        "INSERT INTO suppliers (org_id, name, contact, email, telephone, address, status)
         VALUES (?, ?, ?, ?, ?, ?, 1)",
        'isssss',
        current_org_id(),
        $data['name'],
        $data['contact']   ?? '',
        $data['email']     ?? '',
        $data['telephone'] ?? '',
        $data['address']   ?? ''
    );
    return (int) $db->insert_id();
}

function update_supplier(int $id, array $data): void {
    global $db;
    $db->prepare_query(
        "UPDATE suppliers SET name=?, contact=?, email=?, telephone=?, address=?
          WHERE id = ? AND org_id = ?",
        'sssssii',
        $data['name'],
        $data['contact']   ?? '',
        $data['email']     ?? '',
        $data['telephone'] ?? '',
        $data['address']   ?? '',
        $id, current_org_id()
    );
}

function delete_supplier(int $id): void {
    global $db;
    $db->prepare_query(
        "UPDATE suppliers SET status = 0 WHERE id = ? AND org_id = ?",
        'ii', $id, current_org_id()
    );
}

// ---------------------------------------------------------------------------
// Purchase Orders
// ---------------------------------------------------------------------------

function find_all_purchase_orders(string $status = ''): array {
    global $db;
    $org = current_org_id();
    if ($status !== '' && in_array($status, po_statuses(), true)) {
        return $db->prepare_select(
            "SELECT po.*, s.name AS supplier_name,
                    COUNT(poi.id) AS line_items,
                    COALESCE(SUM(poi.qty_ordered * poi.unit_cost), 0) AS total_cost
               FROM purchase_orders po
               LEFT JOIN suppliers s   ON s.id   = po.supplier_id
               LEFT JOIN purchase_order_items poi ON poi.po_id = po.id
              WHERE po.org_id = ? AND po.status = ?
              GROUP BY po.id ORDER BY po.id DESC",
            'is', $org, $status
        ) ?? [];
    }
    return $db->prepare_select(
        "SELECT po.*, s.name AS supplier_name,
                COUNT(poi.id) AS line_items,
                COALESCE(SUM(poi.qty_ordered * poi.unit_cost), 0) AS total_cost
           FROM purchase_orders po
           LEFT JOIN suppliers s   ON s.id   = po.supplier_id
           LEFT JOIN purchase_order_items poi ON poi.po_id = po.id
          WHERE po.org_id = ?
          GROUP BY po.id ORDER BY po.id DESC",
        'i', $org
    ) ?? [];
}

function find_purchase_order(int $id): ?array {
    global $db;
    $po = $db->prepare_select_one(
        "SELECT po.*, s.name AS supplier_name
           FROM purchase_orders po
           LEFT JOIN suppliers s ON s.id = po.supplier_id
          WHERE po.id = ? AND po.org_id = ? LIMIT 1",
        'ii', $id, current_org_id()
    );
    if (!$po) return null;

    $po['items'] = $db->prepare_select(
        "SELECT poi.*, p.name AS product_name, p.sku, p.location
           FROM purchase_order_items poi
           LEFT JOIN products p ON p.id = poi.product_id
          WHERE poi.po_id = ?",
        'i', $id
    ) ?? [];
    return $po;
}

function create_purchase_order(int $supplier_id, string $reference, string $notes = ''): int {
    global $db;
    $db->prepare_query(
        "INSERT INTO purchase_orders (org_id, supplier_id, reference, notes, created_by)
         VALUES (?, ?, ?, ?, ?)",
        'iissi',
        current_org_id(), $supplier_id, $reference, $notes,
        (int) ($_SESSION['user_id'] ?? 0)
    );
    return (int) $db->insert_id();
}

function add_po_item(int $po_id, int $product_id, int $qty, float $unit_cost): void {
    global $db;
    $db->prepare_query(
        "INSERT INTO purchase_order_items (po_id, product_id, qty_ordered, unit_cost)
         VALUES (?, ?, ?, ?)",
        'iiid', $po_id, $product_id, $qty, $unit_cost
    );
}

function update_po_status(int $po_id, string $status): void {
    global $db;
    if (!in_array($status, po_statuses(), true)) return;
    $db->prepare_query(
        "UPDATE purchase_orders SET status = ?, updated_at = CURDATE() WHERE id = ? AND org_id = ?",
        'sii', $status, $po_id, current_org_id()
    );
}

/**
 * Process a receive-goods submission.
 * Updates qty_received per line item, increments product stock,
 * inserts a stock log row, and auto-updates PO status.
 * Uses a DB transaction to keep stock + PO in sync.
 *
 * @param  int   $po_id
 * @param  array $received  Map of poi_id (int) => qty_to_receive (int)
 */
function receive_purchase_order(int $po_id, array $received): bool {
    global $db;
    $po = find_purchase_order($po_id);
    if (!$po || $po['status'] === 'cancelled') return false;

    $conn = $db->connection();
    $conn->begin_transaction();
    try {
        $all_received = true;
        $any_received = false;

        foreach ($po['items'] as $item) {
            $poi_id    = (int) $item['id'];
            $incoming  = (int) ($received[$poi_id] ?? 0);
            if ($incoming <= 0) continue;

            // Cap to the remaining un-received quantity
            $remaining = (int) $item['qty_ordered'] - (int) $item['qty_received'];
            $qty       = min($incoming, $remaining);
            if ($qty <= 0) continue;

            $db->prepare_query(
                "UPDATE purchase_order_items SET qty_received = qty_received + ? WHERE id = ?",
                'ii', $qty, $poi_id
            );
            increase_product_qty($qty, (int) $item['product_id']);
            $db->prepare_query(
                "INSERT INTO stock (product_id, quantity, comments, date) VALUES (?, ?, ?, ?)",
                'iiss',
                (int) $item['product_id'], $qty,
                "Received via PO #$po_id", make_date()
            );
            $any_received = true;
        }

        // Re-check all items for completeness
        $items = $db->prepare_select(
            "SELECT qty_ordered, qty_received FROM purchase_order_items WHERE po_id = ?",
            'i', $po_id
        ) ?? [];
        foreach ($items as $it) {
            if ((int) $it['qty_received'] < (int) $it['qty_ordered']) {
                $all_received = false;
            }
        }

        $new_status = $all_received ? 'received'
            : ($any_received       ? 'partial'
            : $po['status']);

        if ($all_received) {
            $db->prepare_query(
                "UPDATE purchase_orders SET status = ?, updated_at = CURDATE(), received_at = CURDATE()
                  WHERE id = ? AND org_id = ?",
                'sii', $new_status, $po_id, current_org_id()
            );
        } else {
            $db->prepare_query(
                "UPDATE purchase_orders SET status = ?, updated_at = CURDATE()
                  WHERE id = ? AND org_id = ?",
                'sii', $new_status, $po_id, current_org_id()
            );
        }

        $conn->commit();
        return true;

    } catch (Exception $e) {
        $conn->rollback();
        error_log("receive_purchase_order failed for PO #$po_id: " . $e->getMessage());
        return false;
    }
}
```

- [ ] **Step 4: Add require in `includes/load.php`**

Find the section where other `sql_*.php` files are required and add:

```php
require_once LIB_PATH_INC . DS . 'sql_purchasing.php';
```

- [ ] **Step 5: Run full test suite**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: PurchasingTest passes, no regressions.

- [ ] **Step 6: Commit**

```bash
git add includes/sql_purchasing.php includes/load.php tests/PurchasingTest.php
git commit -m "feat(purchasing): sql_purchasing.php — supplier + PO query functions"
```

---

## Task 4: Suppliers Module

**Files:**
- Create: `suppliers/index.php`
- Create: `suppliers/suppliers.php`
- Create: `suppliers/add_supplier.php`
- Create: `suppliers/edit_supplier.php`
- Create: `suppliers/delete_supplier.php`

- [ ] **Step 1: Create `suppliers/index.php`**

```php
<?php header('Location: suppliers.php'); exit;
```

- [ ] **Step 2: Create `suppliers/suppliers.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_SUPERVISOR);

$suppliers  = find_all_suppliers();
$page_title = 'Suppliers';
include '../layouts/header.php';
?>
<div class="row">
  <div class="col-md-12"><?php echo display_msg($msg); ?></div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <strong>Suppliers (<?php echo count($suppliers); ?>)</strong>
        <?php if (can('suppliers', 'create')): ?>
          <a href="add_supplier.php" class="btn btn-primary btn-sm">+ Add Supplier</a>
        <?php endif; ?>
      </div>
      <div class="card-body p-0">
        <table class="table table-striped mb-0">
          <thead>
            <tr><th>Name</th><th>Contact</th><th>Email</th><th>Phone</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <?php foreach ($suppliers as $s): ?>
            <tr>
              <td><?php echo remove_junk($s['name']); ?></td>
              <td><?php echo remove_junk($s['contact'] ?? ''); ?></td>
              <td><?php echo remove_junk($s['email']    ?? ''); ?></td>
              <td><?php echo remove_junk($s['telephone']?? ''); ?></td>
              <td>
                <?php if (can('suppliers', 'edit')): ?>
                  <a href="edit_supplier.php?id=<?php echo (int)$s['id']; ?>"
                     class="btn btn-warning btn-sm">Edit</a>
                <?php endif; ?>
                <?php if (can('suppliers', 'delete')): ?>
                  <a href="delete_supplier.php?id=<?php echo (int)$s['id']; ?>"
                     class="btn btn-danger btn-sm"
                     onclick="return confirm('Delete this supplier?')">Delete</a>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($suppliers)): ?>
              <tr><td colspan="5" class="text-center text-muted">No suppliers yet.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include '../layouts/footer.php'; ?>
```

- [ ] **Step 3: Create `suppliers/add_supplier.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_SUPERVISOR);
require_permission('suppliers', 'create');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $session->msg('d', 'Invalid request token.');
        redirect('add_supplier.php');
    }
    $data = [
        'name'      => sanitize_input($_POST['name']      ?? ''),
        'contact'   => sanitize_input($_POST['contact']   ?? ''),
        'email'     => sanitize_input($_POST['email']     ?? ''),
        'telephone' => sanitize_input($_POST['telephone'] ?? ''),
        'address'   => sanitize_input($_POST['address']   ?? ''),
    ];
    if (empty($data['name'])) {
        $session->msg('d', 'Supplier name is required.');
        redirect('add_supplier.php');
    }
    $id = create_supplier($data);
    audit('suppliers', 'create', $id, "Added supplier: {$data['name']}");
    $session->msg('s', 'Supplier added.');
    redirect('suppliers.php');
}

$page_title = 'Add Supplier';
include '../layouts/header.php';
?>
<div class="row"><div class="col-md-6 offset-md-3">
  <?php echo display_msg($msg); ?>
  <div class="card">
    <div class="card-header"><strong>Add Supplier</strong></div>
    <div class="card-body">
      <form method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3"><label class="form-label">Name *</label>
          <input type="text" name="name" class="form-control" required></div>
        <div class="mb-3"><label class="form-label">Contact Person</label>
          <input type="text" name="contact" class="form-control"></div>
        <div class="mb-3"><label class="form-label">Email</label>
          <input type="email" name="email" class="form-control"></div>
        <div class="mb-3"><label class="form-label">Telephone</label>
          <input type="tel" name="telephone" class="form-control"></div>
        <div class="mb-3"><label class="form-label">Address</label>
          <textarea name="address" class="form-control" rows="3"></textarea></div>
        <button type="submit" class="btn btn-primary">Save</button>
        <a href="suppliers.php" class="btn btn-secondary ms-2">Cancel</a>
      </form>
    </div>
  </div>
</div></div>
<?php include '../layouts/footer.php'; ?>
```

- [ ] **Step 4: Create `suppliers/edit_supplier.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_SUPERVISOR);
require_permission('suppliers', 'edit');

$id       = (int) ($_GET['id'] ?? 0);
$supplier = find_supplier($id);
if (!$supplier) {
    $session->msg('d', 'Supplier not found.');
    redirect('suppliers.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $session->msg('d', 'Invalid request token.');
        redirect('edit_supplier.php?id=' . $id);
    }
    $data = [
        'name'      => sanitize_input($_POST['name']      ?? ''),
        'contact'   => sanitize_input($_POST['contact']   ?? ''),
        'email'     => sanitize_input($_POST['email']     ?? ''),
        'telephone' => sanitize_input($_POST['telephone'] ?? ''),
        'address'   => sanitize_input($_POST['address']   ?? ''),
    ];
    if (empty($data['name'])) {
        $session->msg('d', 'Supplier name is required.');
        redirect('edit_supplier.php?id=' . $id);
    }
    update_supplier($id, $data);
    audit('suppliers', 'update', $id, "Updated supplier: {$data['name']}");
    $session->msg('s', 'Supplier updated.');
    redirect('suppliers.php');
}

$page_title = 'Edit Supplier';
include '../layouts/header.php';
?>
<div class="row"><div class="col-md-6 offset-md-3">
  <?php echo display_msg($msg); ?>
  <div class="card">
    <div class="card-header"><strong>Edit Supplier</strong></div>
    <div class="card-body">
      <form method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3"><label class="form-label">Name *</label>
          <input type="text" name="name" class="form-control" required
                 value="<?php echo remove_junk($supplier['name']); ?>"></div>
        <div class="mb-3"><label class="form-label">Contact Person</label>
          <input type="text" name="contact" class="form-control"
                 value="<?php echo remove_junk($supplier['contact'] ?? ''); ?>"></div>
        <div class="mb-3"><label class="form-label">Email</label>
          <input type="email" name="email" class="form-control"
                 value="<?php echo remove_junk($supplier['email'] ?? ''); ?>"></div>
        <div class="mb-3"><label class="form-label">Telephone</label>
          <input type="tel" name="telephone" class="form-control"
                 value="<?php echo remove_junk($supplier['telephone'] ?? ''); ?>"></div>
        <div class="mb-3"><label class="form-label">Address</label>
          <textarea name="address" class="form-control" rows="3"><?php
            echo remove_junk($supplier['address'] ?? '');
          ?></textarea></div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="suppliers.php" class="btn btn-secondary ms-2">Cancel</a>
      </form>
    </div>
  </div>
</div></div>
<?php include '../layouts/footer.php'; ?>
```

- [ ] **Step 5: Create `suppliers/delete_supplier.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_SUPERVISOR);
require_permission('suppliers', 'delete');

$id       = (int) ($_GET['id'] ?? 0);
$supplier = find_supplier($id);
if (!$supplier) {
    $session->msg('d', 'Supplier not found.');
    redirect('suppliers.php');
}

delete_supplier($id);
audit('suppliers', 'delete', $id, "Deleted supplier: {$supplier['name']}");
$session->msg('s', 'Supplier removed.');
redirect('suppliers.php');
```

- [ ] **Step 6: Add Suppliers nav link**

In `layouts/admin_menu.php`, add (in the Products/Inventory nav group):

```html
<li class="nav-item">
  <a class="nav-link" href="<?php echo $base; ?>/suppliers/suppliers.php">Suppliers</a>
</li>
```

Also add to `layouts/special_menu.php` (supervisor nav).

- [ ] **Step 7: Run tests**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: no regressions.

- [ ] **Step 8: Commit**

```bash
git add suppliers/ layouts/admin_menu.php layouts/special_menu.php
git commit -m "feat(purchasing): suppliers CRUD module"
```

---

## Task 5: Purchase Orders Module

**Files:**
- Create: `purchasing/index.php`
- Create: `purchasing/purchase_orders.php`
- Create: `purchasing/add_purchase_order.php`
- Create: `purchasing/view_purchase_order.php`
- Create: `purchasing/edit_purchase_order.php` (cancel/update notes on draft POs)
- Create: `purchasing/receive_purchase_order.php`
- Modify: `layouts/admin_menu.php`, `layouts/special_menu.php`

- [ ] **Step 1: Create `purchasing/index.php`**

```php
<?php header('Location: purchase_orders.php'); exit;
```

- [ ] **Step 2: Create `purchasing/purchase_orders.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_SUPERVISOR);

$filter = (isset($_GET['status']) && in_array($_GET['status'], po_statuses(), true))
    ? $_GET['status'] : '';
$orders    = find_all_purchase_orders($filter);
$page_title = 'Purchase Orders';
include '../layouts/header.php';
?>
<div class="row"><div class="col-md-12"><?php echo display_msg($msg); ?></div></div>
<div class="row">
  <div class="col-md-12">
    <nav class="mb-3">
      <a href="purchase_orders.php"
         class="btn btn-sm <?php echo $filter === '' ? 'btn-primary' : 'btn-outline-secondary'; ?>">All</a>
      <?php foreach (po_statuses() as $s): ?>
        <a href="purchase_orders.php?status=<?php echo $s; ?>"
           class="btn btn-sm <?php echo $filter === $s ? 'btn-primary' : 'btn-outline-secondary'; ?>">
          <?php echo ucfirst($s); ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <strong>Purchase Orders (<?php echo count($orders); ?>)</strong>
        <?php if (can('purchase_orders', 'create')): ?>
          <a href="add_purchase_order.php" class="btn btn-primary btn-sm">+ New PO</a>
        <?php endif; ?>
      </div>
      <div class="card-body p-0">
        <table class="table table-striped mb-0">
          <thead>
            <tr><th>#</th><th>Supplier</th><th>Reference</th><th>Status</th>
                <th>Items</th><th>Total Cost</th><th>Date</th><th>Actions</th></tr>
          </thead>
          <tbody>
            <?php foreach ($orders as $po): ?>
            <tr>
              <td><?php echo (int)$po['id']; ?></td>
              <td><?php echo remove_junk($po['supplier_name'] ?? '—'); ?></td>
              <td><?php echo remove_junk($po['reference']     ?? '—'); ?></td>
              <td><span class="badge bg-<?php echo po_status_class($po['status']); ?>">
                <?php echo remove_junk($po['status']); ?></span></td>
              <td><?php echo (int)$po['line_items']; ?></td>
              <td><?php echo number_format((float)$po['total_cost'], 2); ?></td>
              <td><?php echo remove_junk(date('M j, Y', strtotime($po['created_at']))); ?></td>
              <td>
                <a href="view_purchase_order.php?id=<?php echo (int)$po['id']; ?>"
                   class="btn btn-info btn-sm">View</a>
                <?php if ($po['status'] === 'ordered' && can('purchase_orders', 'edit')): ?>
                  <a href="receive_purchase_order.php?id=<?php echo (int)$po['id']; ?>"
                     class="btn btn-success btn-sm">Receive</a>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($orders)): ?>
              <tr><td colspan="8" class="text-center text-muted">No purchase orders yet.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include '../layouts/footer.php'; ?>
```

- [ ] **Step 3: Create `purchasing/add_purchase_order.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_SUPERVISOR);
require_permission('purchase_orders', 'create');

$suppliers = find_all_suppliers();
if (empty($suppliers)) {
    $session->msg('w', 'Add at least one supplier before creating a PO.');
    redirect('../suppliers/suppliers.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $session->msg('d', 'Invalid request token.');
        redirect('add_purchase_order.php');
    }
    $supplier_id = (int) ($_POST['supplier_id'] ?? 0);
    $reference   = sanitize_input($_POST['reference'] ?? '');
    $notes       = sanitize_input($_POST['notes']     ?? '');
    $products    = $_POST['product_id'] ?? [];
    $qtys        = $_POST['qty']        ?? [];
    $costs       = $_POST['unit_cost']  ?? [];

    if (!$supplier_id || empty($products)) {
        $session->msg('d', 'Supplier and at least one line item are required.');
        redirect('add_purchase_order.php');
    }

    $po_id = create_purchase_order($supplier_id, $reference, $notes);
    foreach ($products as $i => $pid) {
        $pid  = (int) $pid;
        $qty  = (int)   ($qtys[$i]  ?? 0);
        $cost = (float) ($costs[$i] ?? 0);
        if ($pid > 0 && $qty > 0) {
            add_po_item($po_id, $pid, $qty, $cost);
        }
    }
    update_po_status($po_id, 'ordered');
    audit('purchase_orders', 'create', $po_id, "Created PO #$po_id for supplier_id=$supplier_id");
    $session->msg('s', "Purchase Order #$po_id created.");
    redirect('purchase_orders.php');
}

$all_products = find_all('products');
$page_title   = 'New Purchase Order';
include '../layouts/header.php';
?>
<div class="row"><div class="col-md-10 offset-md-1"><?php echo display_msg($msg); ?>
  <div class="card">
    <div class="card-header"><strong>New Purchase Order</strong></div>
    <div class="card-body">
      <form method="post" id="po-form">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
          <div class="col-md-4">
            <label class="form-label">Supplier *</label>
            <select name="supplier_id" class="form-select" required>
              <option value="">— Select supplier —</option>
              <?php foreach ($suppliers as $s): ?>
                <option value="<?php echo (int)$s['id']; ?>">
                  <?php echo remove_junk($s['name']); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-4">
            <label class="form-label">Reference / PO Number</label>
            <input type="text" name="reference" class="form-control">
          </div>
          <div class="col-md-4">
            <label class="form-label">Notes</label>
            <input type="text" name="notes" class="form-control">
          </div>
        </div>

        <h6>Line Items</h6>
        <table class="table table-sm" id="line-items">
          <thead><tr><th>Product</th><th>Qty</th><th>Unit Cost</th><th></th></tr></thead>
          <tbody id="items-body">
            <tr class="line-row">
              <td>
                <select name="product_id[]" class="form-select form-select-sm" required>
                  <option value="">— Select product —</option>
                  <?php foreach ($all_products as $p): ?>
                    <option value="<?php echo (int)$p['id']; ?>">
                      <?php echo remove_junk($p['name']); ?>
                      <?php if ($p['sku']): ?>(<?php echo remove_junk($p['sku']); ?>)<?php endif; ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td><input type="number" name="qty[]" class="form-control form-control-sm" min="1" required></td>
              <td><input type="number" name="unit_cost[]" class="form-control form-control-sm" step="0.01" min="0" value="0.00"></td>
              <td><button type="button" class="btn btn-danger btn-sm remove-row">×</button></td>
            </tr>
          </tbody>
        </table>
        <button type="button" class="btn btn-secondary btn-sm mb-3" id="add-row">+ Add item</button>
        <br>
        <button type="submit" class="btn btn-primary">Create PO</button>
        <a href="purchase_orders.php" class="btn btn-secondary ms-2">Cancel</a>
      </form>
    </div>
  </div>
</div></div>
<script>
document.getElementById('add-row').addEventListener('click', function() {
    const row = document.querySelector('#items-body .line-row').cloneNode(true);
    row.querySelectorAll('input').forEach(i => i.value = '');
    row.querySelector('select').value = '';
    document.getElementById('items-body').appendChild(row);
});
document.getElementById('items-body').addEventListener('click', function(e) {
    if (e.target.classList.contains('remove-row')) {
        const rows = document.querySelectorAll('#items-body .line-row');
        if (rows.length > 1) e.target.closest('tr').remove();
    }
});
</script>
<?php include '../layouts/footer.php'; ?>
```

- [ ] **Step 4: Create `purchasing/view_purchase_order.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_SUPERVISOR);

$id = (int) ($_GET['id'] ?? 0);
$po = find_purchase_order($id);
if (!$po) {
    $session->msg('d', 'Purchase order not found.');
    redirect('purchase_orders.php');
}
$page_title = 'PO #' . $id;
include '../layouts/header.php';
?>
<div class="row"><div class="col-md-10 offset-md-1">
  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
      <strong>Purchase Order #<?php echo (int)$po['id']; ?></strong>
      <span class="badge bg-<?php echo po_status_class($po['status']); ?> fs-6">
        <?php echo remove_junk($po['status']); ?></span>
    </div>
    <div class="card-body">
      <dl class="row">
        <dt class="col-sm-3">Supplier</dt>
        <dd class="col-sm-9"><?php echo remove_junk($po['supplier_name'] ?? '—'); ?></dd>
        <dt class="col-sm-3">Reference</dt>
        <dd class="col-sm-9"><?php echo remove_junk($po['reference'] ?? '—'); ?></dd>
        <dt class="col-sm-3">Notes</dt>
        <dd class="col-sm-9"><?php echo remove_junk($po['notes'] ?? ''); ?></dd>
        <dt class="col-sm-3">Created</dt>
        <dd class="col-sm-9"><?php echo remove_junk($po['created_at']); ?></dd>
      </dl>

      <h6>Line Items</h6>
      <table class="table table-sm table-bordered">
        <thead><tr><th>Product</th><th>SKU</th><th>Ordered</th><th>Received</th><th>Unit Cost</th><th>Line Total</th></tr></thead>
        <tbody>
          <?php $total = 0; foreach ($po['items'] as $item):
            $line = (int)$item['qty_ordered'] * (float)$item['unit_cost'];
            $total += $line;
          ?>
          <tr>
            <td><?php echo remove_junk($item['product_name'] ?? '—'); ?></td>
            <td><?php echo remove_junk($item['sku'] ?? ''); ?></td>
            <td><?php echo (int)$item['qty_ordered']; ?></td>
            <td><?php echo (int)$item['qty_received']; ?></td>
            <td><?php echo number_format((float)$item['unit_cost'], 2); ?></td>
            <td><?php echo number_format($line, 2); ?></td>
          </tr>
          <?php endforeach; ?>
          <tr class="table-light fw-bold">
            <td colspan="5" class="text-end">Total:</td>
            <td><?php echo number_format($total, 2); ?></td>
          </tr>
        </tbody>
      </table>

      <div class="mt-3">
        <?php if (in_array($po['status'], ['ordered', 'partial']) && can('purchase_orders', 'edit')): ?>
          <a href="receive_purchase_order.php?id=<?php echo (int)$po['id']; ?>"
             class="btn btn-success">Mark Received</a>
        <?php endif; ?>
        <a href="purchase_orders.php" class="btn btn-secondary ms-2">Back</a>
      </div>
    </div>
  </div>
</div></div>
<?php include '../layouts/footer.php'; ?>
```

- [ ] **Step 5: Create `purchasing/receive_purchase_order.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_SUPERVISOR);
require_permission('purchase_orders', 'edit');

$id = (int) ($_GET['id'] ?? 0);
$po = find_purchase_order($id);
if (!$po || !in_array($po['status'], ['ordered', 'partial'])) {
    $session->msg('d', 'Purchase order not found or cannot be received.');
    redirect('purchase_orders.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $session->msg('d', 'Invalid request token.');
        redirect('receive_purchase_order.php?id=' . $id);
    }
    $received = [];
    foreach ($_POST['received'] ?? [] as $poi_id => $qty) {
        $received[(int) $poi_id] = max(0, (int) $qty);
    }
    if (receive_purchase_order($id, $received)) {
        audit('purchase_orders', 'update', $id, "Received goods for PO #$id");
        $session->msg('s', "PO #$id updated with received quantities.");
    } else {
        $session->msg('d', 'Failed to process receipt. Please try again.');
    }
    redirect('view_purchase_order.php?id=' . $id);
}

$page_title = 'Receive PO #' . $id;
include '../layouts/header.php';
?>
<div class="row"><div class="col-md-10 offset-md-1">
  <?php echo display_msg($msg); ?>
  <div class="card">
    <div class="card-header"><strong>Receive Goods — PO #<?php echo (int)$po['id']; ?></strong>
      (<?php echo remove_junk($po['supplier_name'] ?? ''); ?>)
    </div>
    <div class="card-body">
      <form method="post">
        <?php echo csrf_field(); ?>
        <table class="table table-bordered">
          <thead>
            <tr><th>Product</th><th>Ordered</th><th>Already Received</th><th>Receiving Now</th></tr>
          </thead>
          <tbody>
            <?php foreach ($po['items'] as $item):
              $remaining = (int)$item['qty_ordered'] - (int)$item['qty_received'];
            ?>
            <tr>
              <td><?php echo remove_junk($item['product_name'] ?? '—'); ?>
                  <small class="text-muted"><?php echo remove_junk($item['sku'] ?? ''); ?></small></td>
              <td><?php echo (int)$item['qty_ordered']; ?></td>
              <td><?php echo (int)$item['qty_received']; ?></td>
              <td>
                <input type="number" name="received[<?php echo (int)$item['id']; ?>]"
                       class="form-control form-control-sm" style="width:100px"
                       min="0" max="<?php echo $remaining; ?>"
                       value="<?php echo $remaining; ?>">
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <button type="submit" class="btn btn-success">Confirm Receipt</button>
        <a href="view_purchase_order.php?id=<?php echo (int)$po['id']; ?>"
           class="btn btn-secondary ms-2">Cancel</a>
      </form>
    </div>
  </div>
</div></div>
<?php include '../layouts/footer.php'; ?>
```

- [ ] **Step 6: Create `purchasing/edit_purchase_order.php`** (cancel draft POs)

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_SUPERVISOR);
require_permission('purchase_orders', 'edit');

$id = (int) ($_GET['id'] ?? 0);
$po = find_purchase_order($id);
if (!$po) {
    $session->msg('d', 'Purchase order not found.');
    redirect('purchase_orders.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $session->msg('d', 'Invalid request token.');
        redirect('edit_purchase_order.php?id=' . $id);
    }
    $action = sanitize_input($_POST['action'] ?? '');
    if ($action === 'cancel' && in_array($po['status'], ['draft', 'ordered'], true)) {
        update_po_status($id, 'cancelled');
        audit('purchase_orders', 'update', $id, "Cancelled PO #$id");
        $session->msg('s', "PO #$id cancelled.");
        redirect('purchase_orders.php');
    }
    $session->msg('d', 'Invalid action.');
    redirect('view_purchase_order.php?id=' . $id);
}

redirect('view_purchase_order.php?id=' . $id);
```

- [ ] **Step 7: Add Purchasing nav link to both menus**

In `layouts/admin_menu.php`:

```html
<li class="nav-item">
  <a class="nav-link" href="<?php echo $base; ?>/purchasing/purchase_orders.php">Purchase Orders</a>
</li>
```

In `layouts/special_menu.php` (same link).

- [ ] **Step 8: Run full test suite**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: no regressions.

- [ ] **Step 9: Commit**

```bash
git add purchasing/ layouts/admin_menu.php layouts/special_menu.php
git commit -m "feat(purchasing): purchase orders module (list, add, view, receive, cancel)"
```

---

## Self-Review Checklist

- [x] Suppliers table has `org_id` FK scoped to current session org
- [x] Purchase orders table has `org_id` FK scoped to current session org
- [x] `receive_purchase_order()` uses DB transaction via `$db->connection()->begin_transaction()`
- [x] Stock log entry inserted on receive (matches `inventory`'s stock table pattern)
- [x] `qty_received` capped to `qty_ordered - qty_received` (no over-receive)
- [x] All pages use `page_require_level(ROLE_SUPERVISOR)` + `require_permission()`
- [x] `audit()` called on create, update, delete (requires Plan A Task 4 first)
- [x] CSRF on all POST forms
- [x] `remove_junk()` on all HTML output
- [x] `sanitize_input()` on all POST input
- [x] No `can()` / `require_permission()` calls without Plan A Task 5 being applied first
  — **Dependency:** Plan A Task 5 must be merged before deploying Plan B, or remove the `can()`/`require_permission()` guards from UI files temporarily.
