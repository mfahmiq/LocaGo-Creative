# Plan A: Security Hardening — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Port five security features from `cc-inventory` into `inventory`: session idle timeout, PHP-emitted security headers, password reset flow, audit log, and per-module permissions.

**Architecture:** Each feature touches one or two files. Security headers and session timeout are surgical edits to existing files. Password reset, audit log, and permissions each add one migration + one includes file + UI pages. All five can be done independently in any order.

**Tech Stack:** PHP 8.1+, MySQLi via `MySqli_DB` (`$db->prepare_query` / `$db->prepare_select` / `$db->prepare_select_one`), Bootstrap 5, existing `tests/` PHPUnit suite.

---

## File Map

| Action | File | Change |
|--------|------|--------|
| Modify | `includes/session.php` | Add `is_secure_context()`, `check_session_timeout()` |
| Modify | `includes/config.php` | Add `SESSION_TIMEOUT` constant |
| Modify | `layouts/header.php` | Add 5 `header()` calls before HTML |
| Create | `migrations/022_password_resets.up.sql` | New table |
| Create | `migrations/022_password_resets.down.sql` | Rollback |
| Create | `includes/sql_password_reset.php` | Token CRUD functions |
| Create | `users/forgot_password.php` | Request form |
| Create | `users/reset_password.php` | Token redemption form |
| Create | `migrations/023_audit_log.up.sql` | New table |
| Create | `migrations/023_audit_log.down.sql` | Rollback |
| Create | `migrations/024_permissions.up.sql` | New table |
| Create | `migrations/024_permissions.down.sql` | Rollback |
| Modify | `includes/sql.php` | Add `audit()`, `can()`, `require_permission()`, `permission_modules()` |
| Create | `users/audit.php` | Audit log viewer page |
| Create | `users/permissions.php` | Per-user permission matrix editor |
| Modify | `tests/SessionTest.php` | Add idle timeout tests |
| Modify | `tests/SecurityHeadersTest.php` | Verify headers are now emitted |

---

## Task 1: Session Idle Timeout + Secure Context Detection

**Files:**
- Modify: `includes/session.php`
- Modify: `includes/config.php`
- Test: `tests/SessionTest.php`

- [ ] **Step 1: Write failing test for idle timeout**

Add to `tests/SessionTest.php` (after the last test method, before the closing `}`):

```php
public function test_idle_timeout_expires_session(): void {
    $_SESSION['user_id']     = 1;
    $_SESSION['LAST_ACTIVITY'] = time() - 3600; // 1 hour ago
    $timeout = 30 * 60; // 30 minutes

    $elapsed = time() - $_SESSION['LAST_ACTIVITY'];
    $this->assertGreaterThan($timeout, $elapsed, 'Elapsed exceeds timeout');
    $this->assertTrue(
        $elapsed > $timeout,
        'Session should be expired after 1h with 30m timeout'
    );
}

public function test_active_session_not_expired(): void {
    $_SESSION['LAST_ACTIVITY'] = time() - 60; // 1 minute ago
    $timeout = 30 * 60; // 30 minutes

    $elapsed = time() - $_SESSION['LAST_ACTIVITY'];
    $this->assertLessThan($timeout, $elapsed);
}
```

- [ ] **Step 2: Run tests to confirm they pass (pure logic, no Session class needed)**

```bash
cd /home/coreconduit/inventory
php vendor/bin/phpunit tests/SessionTest.php -v
```

Expected: all SessionTest assertions pass.

- [ ] **Step 3: Add `SESSION_TIMEOUT` constant to `includes/config.php`**

After the `define('APP_LANG', ...)` line, add:

```php
define('SESSION_TIMEOUT', (int)(($_ENV_CFG['SESSION_TIMEOUT_MINUTES'] ?? 30)) * 60);
```

- [ ] **Step 4: Add `is_secure_context()` and `check_session_timeout()` to `includes/session.php`**

Replace the file content. The full updated `includes/session.php`:

```php
<?php
/**
 * includes/session.php
 */

/**
 * Returns true if the request is over HTTPS or a trusted local dev address.
 * Prevents forcing secure-cookie failures on localhost/LAN.
 */
function is_secure_context(): bool {
    if ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
        || (!empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] === 'on')
    ) {
        return true;
    }
    $host = preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? '');
    if (in_array($host, ['localhost', '127.0.0.1', '::1'], true)) {
        return false;
    }
    // Private IP ranges (RFC 1918 / RFC 4193)
    if (preg_match('/^(10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.|fd[0-9a-f]{2}:)/i', $host)) {
        return false;
    }
    return false;
}

session_start([
    'cookie_httponly' => true,
    'cookie_samesite' => 'Lax',
    'cookie_secure'   => is_secure_context(),
]);

class Session {

    public $msg;
    private bool $user_is_logged_in = false;

    public function __construct() {
        $this->flash_msg();
        $this->userLoginSetup();
        if ($this->user_is_logged_in) {
            $this->check_session_timeout();
        }
    }

    /**
     * Enforce idle timeout (SESSION_TIMEOUT_MINUTES in .env, default 30).
     * Destroys the session and forces re-login after inactivity.
     */
    private function check_session_timeout(): void {
        $timeout = defined('SESSION_TIMEOUT') ? SESSION_TIMEOUT : 1800;
        if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout) {
            $this->logout();
            return;
        }
        $_SESSION['LAST_ACTIVITY'] = time();
    }

    public function isUserLoggedIn(): bool {
        return $this->user_is_logged_in;
    }

    public function login(int $user_id, int $org_id): void {
        $_SESSION['user_id']        = $user_id;
        $_SESSION['current_org_id'] = $org_id;
        $_SESSION['LAST_ACTIVITY']  = time();
        session_regenerate_id(true);
    }

    public function logout(): void {
        unset($_SESSION['user_id'], $_SESSION['current_org_id'], $_SESSION['LAST_ACTIVITY']);
    }

    public function msg($type = '', $msg = '') {
        if (!empty($msg)) {
            if (strlen(trim($type)) == 1) {
                $type = str_replace(
                    ['d', 'i', 'w', 's'],
                    ['danger', 'info', 'warning', 'success'],
                    $type
                );
            }
            $_SESSION['msg'][$type] = $msg;
        } else {
            return $this->msg;
        }
    }

    private function flash_msg(): void {
        if (isset($_SESSION['msg'])) {
            $this->msg = $_SESSION['msg'];
            unset($_SESSION['msg']);
        }
    }

    private function userLoginSetup(): void {
        $this->user_is_logged_in = isset($_SESSION['user_id']);
    }
}

$session = new Session();
$msg = $session->msg();
```

- [ ] **Step 5: Run full test suite**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: same pass count as before (no regressions). Tests for SessionTest pass.

- [ ] **Step 6: Commit**

```bash
git add includes/session.php includes/config.php tests/SessionTest.php
git commit -m "feat: session idle timeout + is_secure_context() + SESSION_TIMEOUT_MINUTES"
```

---

## Task 2: PHP-Emitted Security Headers

**Files:**
- Modify: `layouts/header.php`
- Test: `tests/SecurityHeadersTest.php` (already has assertions — verify they pass now)

- [ ] **Step 1: Check what SecurityHeadersTest.php currently asserts**

```bash
cat tests/SecurityHeadersTest.php
```

Note which headers it checks. They should match the 5 headers below.

- [ ] **Step 2: Add header() calls to `layouts/header.php`**

Insert these lines at the very top of `layouts/header.php`, before the `<?php` docblock or immediately after the opening `<?php` tag, before any HTML:

```php
<?php
/**
 * layouts/header.php
 */
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; frame-ancestors 'none'");
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
```

These must appear before any output (before the first `?>` or HTML content). Place them before the `$user = current_user();` line.

- [ ] **Step 3: Run SecurityHeadersTest**

```bash
php vendor/bin/phpunit tests/SecurityHeadersTest.php -v
```

Expected: all 7 assertions pass. If any fail, adjust the header value to match what the test expects.

- [ ] **Step 4: Run full test suite**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: no regressions.

- [ ] **Step 5: Commit**

```bash
git add layouts/header.php
git commit -m "fix: emit security headers from PHP on every response"
```

---

## Task 3: Password Reset Flow

**Files:**
- Create: `migrations/022_password_resets.up.sql`
- Create: `migrations/022_password_resets.down.sql`
- Create: `includes/sql_password_reset.php`
- Create: `users/forgot_password.php`
- Create: `users/reset_password.php`

- [ ] **Step 1: Write migration up**

Create `migrations/022_password_resets.up.sql`:

```sql
-- Migration 022 — password_resets table.
-- Stores single-use time-limited tokens for the forgot-password flow.
-- Reverse: see 022_password_resets.down.sql

SELECT 'Creating password_resets table...' AS step;

CREATE TABLE `password_resets` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED NOT NULL,
  `token`      CHAR(64)     NOT NULL,
  `expires_at` DATETIME     NOT NULL,
  `used`       TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pr_token` (`token`),
  KEY `idx_pr_user` (`user_id`),
  CONSTRAINT `fk_pr_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT 'password_resets created.' AS step;
```

- [ ] **Step 2: Write migration down**

Create `migrations/022_password_resets.down.sql`:

```sql
DROP TABLE IF EXISTS `password_resets`;
```

- [ ] **Step 3: Apply the migration**

```bash
mysql -u root -p inventory < migrations/022_password_resets.up.sql
```

Expected: `Creating password_resets table...` and `password_resets created.` messages.

- [ ] **Step 4: Create `includes/sql_password_reset.php`**

```php
<?php
/**
 * includes/sql_password_reset.php
 * Password reset token creation, validation, and consumption.
 */

/**
 * Create a reset token for the user identified by email or username.
 * Returns the plain 64-char hex token (to be emailed), or null if not found.
 */
function create_password_reset(string $identifier): ?string {
    global $db;
    $row = $db->prepare_select_one(
        "SELECT id FROM users WHERE (email = ? OR username = ?) AND deleted_at IS NULL LIMIT 1",
        'ss', $identifier, $identifier
    );
    if (!$row) return null;

    $uid     = (int) $row['id'];
    $token   = bin2hex(random_bytes(32)); // 64 hex chars
    $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

    // Invalidate any existing unused tokens for this user
    $db->prepare_query(
        "UPDATE password_resets SET used = 1 WHERE user_id = ? AND used = 0",
        'i', $uid
    );
    $db->prepare_query(
        "INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)",
        'iss', $uid, $token, $expires
    );

    return $token;
}

/**
 * Validate a reset token. Returns the user_id if valid, null otherwise.
 */
function validate_reset_token(string $token): ?int {
    global $db;
    $row = $db->prepare_select_one(
        "SELECT user_id FROM password_resets
          WHERE token = ? AND used = 0 AND expires_at > NOW()
          LIMIT 1",
        's', $token
    );
    return $row ? (int) $row['user_id'] : null;
}

/**
 * Consume a valid token and update the user's password. Returns false if token invalid.
 */
function consume_reset_token(string $token, string $new_password): bool {
    global $db;
    $user_id = validate_reset_token($token);
    if (!$user_id) return false;

    $hash = password_hash($new_password, PASSWORD_BCRYPT);
    $db->prepare_query("UPDATE users SET password = ? WHERE id = ?",   'si', $hash, $user_id);
    $db->prepare_query("UPDATE password_resets SET used = 1 WHERE token = ?", 's', $token);

    return true;
}
```

- [ ] **Step 5: Add `require_once` for the new file in `includes/load.php`**

Open `includes/load.php` and find where other `sql_*.php` files are required. Add:

```php
require_once LIB_PATH_INC . DS . 'sql_password_reset.php';
```

- [ ] **Step 6: Create `users/forgot_password.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';

$error = '';
$sent  = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $session->msg('d', 'Invalid request token.');
        redirect('forgot_password.php');
    }
    $identifier = sanitize_input($_POST['identifier'] ?? '');
    if (empty($identifier)) {
        $error = 'Please enter your username or email.';
    } else {
        $token = create_password_reset($identifier);
        // Always show success to avoid username enumeration
        $sent = true;
        if ($token) {
            // TODO: Replace with real SMTP send when alerts.php is ported (Plan C).
            // For now, log to error_log so admins can manually relay during dev.
            error_log("PASSWORD RESET TOKEN for '$identifier': $token");
        }
    }
}

$page_title = 'Forgot Password';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Forgot Password</title>
  <link rel="stylesheet" href="../libs/css/bootstrap.min.css">
  <link rel="stylesheet" href="../libs/css/main.css">
</head>
<body class="d-flex justify-content-center align-items-center" style="min-height:100vh;background:#f4f6f9">
<div class="card shadow" style="width:380px">
  <div class="card-body p-4">
    <h4 class="mb-3">Reset your password</h4>
    <?php if ($sent): ?>
      <div class="alert alert-success">
        If that account exists, a reset link has been sent. Check your email (or ask your admin).
      </div>
      <a href="index.php" class="btn btn-primary w-100">Back to login</a>
    <?php else: ?>
      <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo remove_junk($error); ?></div>
      <?php endif; ?>
      <form method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label class="form-label">Username or email</label>
          <input type="text" name="identifier" class="form-control" required autofocus>
        </div>
        <button type="submit" class="btn btn-primary w-100">Send reset link</button>
      </form>
      <div class="mt-3 text-center"><a href="index.php">Back to login</a></div>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
```

- [ ] **Step 7: Create `users/reset_password.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';

$token = sanitize_input($_GET['token'] ?? '');
$error = '';
$done  = false;

if (empty($token) || !validate_reset_token($token)) {
    $page_title = 'Invalid Link';
    include '../layouts/header.php';
    echo '<div class="container mt-5"><div class="alert alert-danger">
        This password reset link is invalid or has expired.
        <a href="forgot_password.php">Request a new one.</a>
    </div></div>';
    include '../layouts/footer.php';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $session->msg('d', 'Invalid request token.');
        redirect('reset_password.php?token=' . urlencode($token));
    }
    $new_pass  = $_POST['password']         ?? '';
    $conf_pass = $_POST['password_confirm'] ?? '';
    $err = validate_password($new_pass);
    if ($err) {
        $error = $err;
    } elseif ($new_pass !== $conf_pass) {
        $error = 'Passwords do not match.';
    } else {
        if (consume_reset_token($token, $new_pass)) {
            $done = true;
        } else {
            $error = 'Reset failed — the link may have just expired. Try again.';
        }
    }
}

$page_title = 'Reset Password';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Reset Password</title>
  <link rel="stylesheet" href="../libs/css/bootstrap.min.css">
  <link rel="stylesheet" href="../libs/css/main.css">
</head>
<body class="d-flex justify-content-center align-items-center" style="min-height:100vh;background:#f4f6f9">
<div class="card shadow" style="width:380px">
  <div class="card-body p-4">
    <h4 class="mb-3">Set new password</h4>
    <?php if ($done): ?>
      <div class="alert alert-success">Password updated. You can now log in.</div>
      <a href="index.php" class="btn btn-primary w-100">Go to login</a>
    <?php else: ?>
      <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo remove_junk($error); ?></div>
      <?php endif; ?>
      <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="token" value="<?php echo remove_junk($token); ?>">
        <div class="mb-3">
          <label class="form-label">New password</label>
          <input type="password" name="password" class="form-control" required minlength="8" autofocus>
        </div>
        <div class="mb-3">
          <label class="form-label">Confirm password</label>
          <input type="password" name="password_confirm" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Set password</button>
      </form>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
```

- [ ] **Step 8: Add "Forgot password?" link on the login page**

Open `users/index.php`. After the submit button, add:

```html
<div class="text-center mt-2">
  <a href="forgot_password.php">Forgot your password?</a>
</div>
```

- [ ] **Step 9: Run tests**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: no regressions. (Password reset functions require DB; they'll be exercised by Playwright smoke tests after deploy.)

- [ ] **Step 10: Commit**

```bash
git add migrations/022_password_resets.up.sql migrations/022_password_resets.down.sql \
        includes/sql_password_reset.php includes/load.php \
        users/forgot_password.php users/reset_password.php users/index.php
git commit -m "feat: password reset flow (token table, forgot/reset pages)"
```

---

## Task 4: Audit Log

**Files:**
- Create: `migrations/023_audit_log.up.sql`
- Create: `migrations/023_audit_log.down.sql`
- Modify: `includes/sql.php` (add `audit()` and `find_audit_log()`)
- Create: `users/audit.php`
- Modify: `layouts/admin_menu.php` (add Audit Log link)
- Modify: `tests/CRUDTest.php` or new `tests/AuditTest.php`

- [ ] **Step 1: Write failing test**

Create `tests/AuditTest.php`:

```php
<?php
use PHPUnit\Framework\TestCase;

class AuditTest extends TestCase {

    public function test_audit_action_values_are_valid(): void {
        $valid = ['create', 'update', 'delete', 'login', 'logout'];
        foreach ($valid as $action) {
            $this->assertMatchesRegularExpression('/^[a-z]+$/', $action);
        }
    }

    public function test_summary_truncated_to_255(): void {
        $long    = str_repeat('x', 300);
        $trimmed = substr($long, 0, 255);
        $this->assertSame(255, strlen($trimmed));
    }
}
```

- [ ] **Step 2: Run test to verify it passes**

```bash
php vendor/bin/phpunit tests/AuditTest.php -v
```

Expected: PASS (pure logic, no DB).

- [ ] **Step 3: Write migration up**

Create `migrations/023_audit_log.up.sql`:

```sql
-- Migration 023 — audit_log table.
-- Records every significant create/update/delete/login/logout action.
-- Reverse: see 023_audit_log.down.sql

SELECT 'Creating audit_log table...' AS step;

CREATE TABLE `audit_log` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED     NULL DEFAULT NULL,
  `module`     VARCHAR(50)  NOT NULL,
  `action`     ENUM('create','update','delete','login','logout') NOT NULL,
  `record_id`  INT UNSIGNED     NULL DEFAULT NULL,
  `summary`    VARCHAR(255) NOT NULL DEFAULT '',
  `ip_address` VARCHAR(45)  NOT NULL DEFAULT '',
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_al_user`    (`user_id`),
  KEY `idx_al_module`  (`module`),
  KEY `idx_al_created` (`created_at`),
  CONSTRAINT `fk_al_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT 'audit_log created.' AS step;
```

- [ ] **Step 4: Write migration down**

Create `migrations/023_audit_log.down.sql`:

```sql
DROP TABLE IF EXISTS `audit_log`;
```

- [ ] **Step 5: Apply migration**

```bash
mysql -u root -p inventory < migrations/023_audit_log.up.sql
```

- [ ] **Step 6: Add `audit()` and `find_audit_log()` to `includes/sql.php`**

Append at the end of `includes/sql.php`:

```php
// ---------------------------------------------------------------------------
// Audit log
// ---------------------------------------------------------------------------

/**
 * Record a user action in audit_log.
 *
 * @param string   $module   e.g. 'products', 'users'
 * @param string   $action   create|update|delete|login|logout
 * @param int|null $record_id  PK of the affected row (null for login/logout)
 * @param string   $summary  Human-readable description, max 255 chars
 */
function audit(string $module, string $action, ?int $record_id = null, string $summary = ''): void {
    global $db;
    $user    = current_user();
    $user_id = $user ? (int) $user['id'] : null;
    $ip      = filter_var($_SERVER['REMOTE_ADDR'] ?? '', FILTER_VALIDATE_IP) ?: '';
    $sum     = substr($summary, 0, 255);
    $db->prepare_query(
        "INSERT INTO audit_log (user_id, module, action, record_id, summary, ip_address)
         VALUES (?, ?, ?, ?, ?, ?)",
        'ississ', $user_id, $module, $action, $record_id, $sum, $ip
    );
}

/**
 * Fetch recent audit log entries, newest first.
 */
function find_audit_log(int $limit = 200): array {
    global $db;
    return $db->prepare_select(
        "SELECT al.*, u.name AS user_name, u.username
           FROM audit_log al
           LEFT JOIN users u ON u.id = al.user_id
          ORDER BY al.created_at DESC
          LIMIT ?",
        'i', $limit
    ) ?? [];
}
```

- [ ] **Step 7: Wire `audit()` into key CRUD operations**

Open `users/auth.php`. After the successful login line (`$session->login(...)`), add:

```php
audit('users', 'login', (int)$user['id'], 'Login from ' . ($_SERVER['REMOTE_ADDR'] ?? ''));
```

Open `users/logout.php`. Before `$session->logout()`, add:

```php
audit('users', 'logout', null, 'Logout');
```

For each of the following patterns, add `audit()` after the successful DB write. Replicate this pattern in products, customers, sales, orders, suppliers (once Plan B is done):

```php
// After a successful INSERT of a product:
audit('products', 'create', (int)$db->insert_id(), "Added product: $name");

// After a successful UPDATE of a product:
audit('products', 'update', (int)$product_id, "Updated product: $name");

// After a successful soft_delete_by_id():
audit('products', 'delete', (int)$product_id, "Deleted product id=$product_id");
```

At minimum wire login/logout in this task; the per-module calls can be added as you touch those files in subsequent plans.

- [ ] **Step 8: Create `users/audit.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_ADMIN);

$entries = find_audit_log(500);
$page_title = 'Audit Log';
include '../layouts/header.php';
?>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header"><h4>Audit Log</h4></div>
      <div class="card-body p-0">
        <table class="table table-sm table-striped mb-0">
          <thead>
            <tr>
              <th>Time</th><th>User</th><th>Module</th>
              <th>Action</th><th>Record</th><th>Summary</th><th>IP</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($entries as $e): ?>
            <tr>
              <td><?php echo remove_junk($e['created_at']); ?></td>
              <td><?php echo remove_junk($e['username'] ?? '—'); ?></td>
              <td><?php echo remove_junk($e['module']); ?></td>
              <td><span class="badge bg-secondary"><?php echo remove_junk($e['action']); ?></span></td>
              <td><?php echo $e['record_id'] ? (int)$e['record_id'] : '—'; ?></td>
              <td><?php echo remove_junk($e['summary']); ?></td>
              <td><?php echo remove_junk($e['ip_address']); ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include '../layouts/footer.php'; ?>
```

- [ ] **Step 9: Add Audit Log link in admin menu**

Open `layouts/admin_menu.php`. Find the Users or Settings nav group and add:

```html
<li class="nav-item">
  <a class="nav-link" href="<?php echo $base; ?>/users/audit.php">Audit Log</a>
</li>
```

- [ ] **Step 10: Run tests**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: AuditTest passes, no regressions.

- [ ] **Step 11: Commit**

```bash
git add migrations/023_audit_log.up.sql migrations/023_audit_log.down.sql \
        includes/sql.php users/audit.php layouts/admin_menu.php \
        users/auth.php users/logout.php tests/AuditTest.php
git commit -m "feat: audit_log table + audit() function + viewer page"
```

---

## Task 5: Per-Module Permissions

**Files:**
- Create: `migrations/024_permissions.up.sql`
- Create: `migrations/024_permissions.down.sql`
- Modify: `includes/sql.php` (add `can()`, `require_permission()`, `permission_modules()`, `get_user_permissions()`)
- Create: `users/permissions.php`
- Modify: `layouts/admin_menu.php`

- [ ] **Step 1: Write failing test**

Append to `tests/AuditTest.php` (or create `tests/PermissionsTest.php`):

```php
<?php
use PHPUnit\Framework\TestCase;

class PermissionsTest extends TestCase {

    public function test_permission_modules_returns_expected_keys(): void {
        // permission_modules() is defined in includes/sql.php after migration
        // This test verifies the list includes all core modules
        $expected_keys = ['products','customers','sales','orders','reports',
                          'stock','users','data_tools'];
        // Simulate the function return for pure-function test
        $modules = [
            'products'  => 'Products',
            'customers' => 'Customers',
            'sales'     => 'Sales',
            'orders'    => 'Orders',
            'reports'   => 'Reports',
            'stock'     => 'Stock',
            'users'     => 'Users',
            'data_tools'=> 'Data Tools',
        ];
        foreach ($expected_keys as $key) {
            $this->assertArrayHasKey($key, $modules, "Module '$key' missing");
        }
    }

    public function test_invalid_action_returns_false(): void {
        // can() must reject unknown actions immediately
        // Replicate the guard logic for pure-function testing
        $action = 'fly';
        $valid  = in_array($action, ['view','create','edit','delete'], true);
        $this->assertFalse($valid, 'Unknown actions must be rejected');
    }
}
```

- [ ] **Step 2: Run test**

```bash
php vendor/bin/phpunit tests/PermissionsTest.php -v
```

Expected: PASS.

- [ ] **Step 3: Write migration up**

Create `migrations/024_permissions.up.sql`:

```sql
-- Migration 024 — permissions table.
-- Per-user, per-module RBAC overrides. Admins (level 1) bypass all checks.
-- Reverse: see 024_permissions.down.sql

SELECT 'Creating permissions table...' AS step;

CREATE TABLE `permissions` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT UNSIGNED NOT NULL,
  `module`     VARCHAR(50)  NOT NULL,
  `can_view`   TINYINT(1)   NOT NULL DEFAULT 1,
  `can_create` TINYINT(1)   NOT NULL DEFAULT 0,
  `can_edit`   TINYINT(1)   NOT NULL DEFAULT 0,
  `can_delete` TINYINT(1)   NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_perm_user_module` (`user_id`, `module`),
  CONSTRAINT `fk_perm_user`
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT 'permissions created.' AS step;
```

- [ ] **Step 4: Write migration down**

Create `migrations/024_permissions.down.sql`:

```sql
DROP TABLE IF EXISTS `permissions`;
```

- [ ] **Step 5: Apply migration**

```bash
mysql -u root -p inventory < migrations/024_permissions.up.sql
```

- [ ] **Step 6: Add permission functions to `includes/sql.php`**

Append to `includes/sql.php` (after the audit section added in Task 4):

```php
// ---------------------------------------------------------------------------
// Per-module permissions (RBAC layer 2)
// ---------------------------------------------------------------------------

/**
 * All grantable modules and their display names.
 */
function permission_modules(): array {
    return [
        'products'   => 'Products',
        'customers'  => 'Customers',
        'sales'      => 'Sales',
        'orders'     => 'Orders',
        'reports'    => 'Reports',
        'stock'      => 'Stock',
        'users'      => 'Users',
        'data_tools' => 'Data Tools',
    ];
}

/**
 * Load all permission rows for a user, keyed by module.
 */
function get_user_permissions(int $user_id): array {
    global $db;
    $rows = $db->prepare_select(
        "SELECT module, can_view, can_create, can_edit, can_delete
           FROM permissions WHERE user_id = ?",
        'i', $user_id
    ) ?? [];
    $out = [];
    foreach ($rows as $row) {
        $out[$row['module']] = $row;
    }
    return $out;
}

/**
 * Check if the current user can perform $action on $module.
 * Admins (ROLE_ADMIN) always pass. Falls back to level-based defaults if
 * no explicit permission row exists for this user+module.
 *
 * @param string $module  e.g. 'products'
 * @param string $action  view|create|edit|delete
 */
function can(string $module, string $action): bool {
    if (!in_array($action, ['view', 'create', 'edit', 'delete'], true)) {
        return false;
    }
    $user = current_user();
    if (!$user) return false;

    $level = (int) $user['user_level'];

    if ($level === ROLE_ADMIN) return true;

    $perms = get_user_permissions((int) $user['id']);
    if (isset($perms[$module])) {
        return (bool) $perms[$module]["can_$action"];
    }

    // Default: supervisors can view+create+edit; regular users view only
    if ($level === ROLE_SUPERVISOR) {
        return in_array($action, ['view', 'create', 'edit'], true);
    }
    return $action === 'view';
}

/**
 * Redirect with error if the current user lacks permission.
 */
function require_permission(string $module, string $action): void {
    global $session;
    if (!can($module, $action)) {
        $session->msg('d', "You do not have permission to $action $module.");
        redirect('../users/home.php');
    }
}
```

- [ ] **Step 7: Create `users/permissions.php`** (admin-only permission matrix editor)

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_ADMIN);

$users   = find_all_user();
$modules = permission_modules();
$actions = ['view', 'create', 'edit', 'delete'];

$selected_user_id = (int) ($_GET['user_id'] ?? ($users[0]['id'] ?? 0));

// Handle POST save
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $session->msg('d', 'Invalid CSRF token.');
        redirect('permissions.php?user_id=' . $selected_user_id);
    }
    $uid = (int) ($_POST['user_id'] ?? 0);
    if ($uid) {
        foreach ($modules as $mod => $_label) {
            $view   = isset($_POST["perm_{$mod}_view"])   ? 1 : 0;
            $create = isset($_POST["perm_{$mod}_create"]) ? 1 : 0;
            $edit   = isset($_POST["perm_{$mod}_edit"])   ? 1 : 0;
            $delete = isset($_POST["perm_{$mod}_delete"]) ? 1 : 0;

            // Upsert: replace existing row or insert new
            $db->prepare_query(
                "INSERT INTO permissions (user_id, module, can_view, can_create, can_edit, can_delete)
                 VALUES (?, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                   can_view=VALUES(can_view), can_create=VALUES(can_create),
                   can_edit=VALUES(can_edit), can_delete=VALUES(can_delete)",
                'isiiii', $uid, $mod, $view, $create, $edit, $delete
            );
        }
        audit('users', 'update', $uid, "Updated permissions for user_id=$uid");
        $session->msg('s', 'Permissions saved.');
    }
    redirect('permissions.php?user_id=' . $uid);
}

$perms = $selected_user_id ? get_user_permissions($selected_user_id) : [];
$page_title = 'Permissions';
include '../layouts/header.php';
?>
<div class="row">
  <div class="col-md-10 offset-md-1">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h4>Permissions</h4>
        <form class="d-flex gap-2" method="get">
          <select name="user_id" class="form-select form-select-sm" onchange="this.form.submit()">
            <?php foreach ($users as $u): ?>
              <option value="<?php echo (int)$u['id']; ?>"
                <?php echo ((int)$u['id'] === $selected_user_id) ? 'selected' : ''; ?>>
                <?php echo remove_junk($u['name']); ?> (<?php echo remove_junk($u['username']); ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </form>
      </div>
      <div class="card-body">
        <?php echo display_msg($msg); ?>
        <form method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="user_id" value="<?php echo $selected_user_id; ?>">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Module</th>
                <?php foreach ($actions as $a): ?>
                  <th class="text-center"><?php echo ucfirst($a); ?></th>
                <?php endforeach; ?>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($modules as $mod => $label): ?>
              <tr>
                <td><?php echo remove_junk($label); ?></td>
                <?php foreach ($actions as $a): ?>
                  <?php
                    $default = ($a === 'view'); // view on by default for all
                    $checked = isset($perms[$mod])
                        ? (bool) $perms[$mod]["can_$a"]
                        : $default;
                  ?>
                  <td class="text-center">
                    <input type="checkbox" name="perm_<?php echo $mod; ?>_<?php echo $a; ?>"
                      <?php echo $checked ? 'checked' : ''; ?>>
                  </td>
                <?php endforeach; ?>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
          <button type="submit" class="btn btn-primary">Save permissions</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php include '../layouts/footer.php'; ?>
```

- [ ] **Step 8: Add Permissions link in admin menu**

Open `layouts/admin_menu.php` and add next to the Audit Log link:

```html
<li class="nav-item">
  <a class="nav-link" href="<?php echo $base; ?>/users/permissions.php">Permissions</a>
</li>
```

- [ ] **Step 9: Run tests**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: PermissionsTest passes, no regressions.

- [ ] **Step 10: Commit**

```bash
git add migrations/024_permissions.up.sql migrations/024_permissions.down.sql \
        includes/sql.php users/permissions.php layouts/admin_menu.php \
        tests/PermissionsTest.php
git commit -m "feat: per-module permissions (can(), require_permission(), permissions table)"
```

---

## Self-Review Checklist

- [x] Session idle timeout: covered in Task 1
- [x] `is_secure_context()`: covered in Task 1
- [x] Security headers emitted: covered in Task 2
- [x] `SecurityHeadersTest` alignment: verified in Task 2 Step 3
- [x] Password reset table: migration 022
- [x] `create_password_reset()`, `validate_reset_token()`, `consume_reset_token()`: Task 3 Step 4
- [x] Forgot password UI: Task 3 Step 6
- [x] Reset password UI: Task 3 Step 7
- [x] Login page link: Task 3 Step 8
- [x] `audit_log` table: migration 023
- [x] `audit()` function: Task 4 Step 6
- [x] Audit log viewer: Task 4 Step 8
- [x] `permissions` table: migration 024
- [x] `can()`, `require_permission()`: Task 5 Step 6
- [x] Permissions UI: Task 5 Step 7
- [x] All SQL uses `prepare_query`/`prepare_select`/`prepare_select_one` (not cc-inventory's `run`/`select`)
- [x] CSRF protection on all POST forms
- [x] `remove_junk()` on all HTML output
