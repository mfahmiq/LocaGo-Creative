# Branch Cleanup & Documentation Update Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Delete all stale local and remote branches, then update `architecture.md`, `tech-stack.md`, and `setup-and-usage.md` to reflect the current application state after PRs #31–50.

**Architecture:** Branch cleanup is pure git/gh commands with no code changes. Doc updates are targeted text edits to three files in `docs/` — no new files created, no code touched. Tests are run after doc edits as a smoke check that the working tree is clean.

**Tech Stack:** git, gh CLI, PHP test suite (`bash tests/run.sh`), Markdown.

---

## File Map

| File | Action | Changes |
|------|--------|---------|
| `docs/architecture.md` | Modify | Fix schema.sql table count, migrations list (001–021), remove stale `packaging/sql/migrations/` entry, add `orgs/` module section, add `vendor/` entry, add bootstrap-icons to libs, update test suite count, fix tenancy branch note |
| `docs/tech-stack.md` | Modify | Fix MariaDB table count, add Bootstrap Icons row, add Dev Tooling section, update CI/Quality tools test count, add multi-tenancy row to Security Features |
| `docs/setup-and-usage.md` | Modify | Add "Running Tests" section after Installation |

---

## Task 1: Delete stale local branches

**Files:** none (git operations only)

- [ ] **Step 1: Safe-delete the 5 locally merged branches**

```bash
git branch -d backup/pre-cc-merge \
               chore/sync-local-main \
               feature/bs5-migration-and-hardening \
               feature/product-image-linking-fix \
               feature/security-hardening-2026-05
```

Expected: `Deleted branch <name>` for each. No errors.

- [ ] **Step 2: Force-delete the 2 squash-merged branches**

These were merged to main via GitHub's squash-merge, so `git branch --merged` doesn't see them as merged even though PR #47 and PR #49 are fully merged.

```bash
git branch -D feature/phase1-dev-infrastructure \
              feature/phase2-ops-drop-ins
```

Expected: `Deleted branch <name> (was <sha>)` for each.

- [ ] **Step 3: Force-delete the 4 cc-archive branches**

Local-only leftovers from the cancelled cc-inventory merge. Never pushed.

```bash
git branch -D cc-archive/feature/bs5-phase1-icons \
              cc-archive/feature/wcag-2.2-remediation \
              cc-archive/main \
              "cc-archive/theme/coreconduit-brand-v2.1-silver"
```

Expected: `Deleted branch <name>` for each.

- [ ] **Step 4: Verify only main remains locally**

```bash
git branch
```

Expected output:
```
* main
```

---

## Task 2: Delete stale remote branches

**Files:** none (git/gh operations only)

- [ ] **Step 1: Delete all stale remote branches in one push**

```bash
git push origin --delete \
  alert-autofix-1 \
  alert-autofix-2 \
  alert-autofix-3 \
  backup/pre-cc-merge \
  chore/precommit-csrf-form-guard \
  chore/sync-local-main \
  feature/bs5-migration-and-hardening \
  feature/csp-style-src-tighten \
  feature/csrf-form-action-quote-fix \
  feature/phase1-dev-infrastructure \
  feature/phase2-ops-drop-ins \
  feature/playwright-ci \
  feature/precommit-php-lint-hook \
  feature/product-image-linking-fix \
  feature/security-hardening-2026-05 \
  feature/settings-table-currency \
  feature/tenancy-schema \
  feature/tenancy-shim-removal \
  feature/tenancy-ux \
  fix/edit-category-action-target \
  fix/hoist-constants-before-load \
  fix/tenancy-post-smoke
```

Expected: `- [deleted] <name>` for each branch. If any branch no longer exists on origin (already deleted), git will emit a warning but not fail the others.

- [ ] **Step 2: Prune stale remote-tracking refs**

```bash
git remote prune origin
```

Expected: `Pruning origin` then a list of pruned refs.

- [ ] **Step 3: Verify remote state**

```bash
git branch -r
```

Expected output:
```
  origin/main
```

---

## Task 3: Update architecture.md

**Files:**
- Modify: `docs/architecture.md`

- [ ] **Step 1: Fix schema.sql table count on line 10**

Change:
```
├── schema.sql                 # Canonical database schema (9 tables)
```
To:
```
├── schema.sql                 # Canonical database schema (14 tables)
```

- [ ] **Step 2: Add vendor/ entry after uploads/ in directory map**

After the `uploads/` block (around line 112), add:
```
│
├── vendor/                    # Composer-managed dev dependencies (gitignored)
│   └── bin/phpunit            # PHPUnit 11 test runner
│
```

- [ ] **Step 3: Add bootstrap-icons to libs/**

Change:
```
├── libs/                      # Bundled frontend assets (no CDN)
│   ├── bootstrap/             # Bootstrap 5 CSS/JS
│   ├── datepicker/            # Bootstrap Datepicker CSS/JS
│   ├── js/jquery.min.js       # jQuery 3.x
│   └── css/main.css           # Application styles (col-w-* classes, no inline styles)
```
To:
```
├── libs/                      # Bundled frontend assets (no CDN)
│   ├── bootstrap/             # Bootstrap 5 CSS/JS
│   ├── bootstrap-icons/       # Bootstrap Icons SVG sprite (bi.svg)
│   ├── datepicker/            # Bootstrap Datepicker CSS/JS
│   ├── js/jquery.min.js       # jQuery 3.x
│   └── css/main.css           # Application styles (col-w-* classes, no inline styles)
```

- [ ] **Step 4: Add orgs/ module to directory map**

After the `users/` block (after line 91), add:
```
│
├── orgs/                      # Multi-tenant organization management
│   ├── orgs.php               # Organization list (Admin only)
│   ├── edit_org.php           # Create/edit organization form+handler
│   ├── update_org.php         # Edit org POST handler
│   ├── delete_org.php         # Soft-delete an org
│   ├── restore_org.php        # Restore soft-deleted org
│   ├── add_member.php         # Add user to org form+handler
│   ├── remove_member.php      # Remove user from org
│   └── update_member.php      # Update member role
│
```

- [ ] **Step 5: Add switch_org.php and home.php to users/ listing**

Change:
```
│   └── admin.php              # Admin dashboard
```
To:
```
│   ├── home.php               # User home/dashboard page
│   ├── switch_org.php         # Switch active organization (POST handler)
│   └── admin.php              # Admin dashboard
```

- [ ] **Step 6: Fix migrations section — replace stale content**

Replace the entire migrations block:
```
├── migrations/                # Numbered UP/DOWN SQL migration files
│   ├── 001_quantity_int       # quantity columns VARCHAR→INT
│   ├── 002_failed_logins      # Rate-limit tracking table
│   ├── 003_log_user_fk        # log.user_id ON DELETE SET NULL
│   ├── 004_settings_table     # App settings key/value store
│   └── 005–009_soft_delete    # deleted_at on 5 tables
│
├── packaging/sql/migrations/  # Tenancy migrations (feature/tenancy-schema branch)
│   └── 010–021_tenancy        # orgs, org_members, org_id on 7 tables
```
With:
```
├── migrations/                # Numbered UP/DOWN SQL migration files (001–021)
│   ├── 001–004                # Base schema: quantity INT, failed_logins, log FK, settings
│   ├── 005–009                # Soft-delete: deleted_at on users/customers/sales/orders/stock
│   ├── 010–012                # Multi-tenancy: orgs table, org_members, default org seed
│   ├── 013–018                # org_id columns on customers/products/categories/sales/orders/stock
│   ├── 019–020                # media org_id, settings org_id
│   └── 021                   # users.last_active_org_id for org switcher
```

- [ ] **Step 7: Update tests/ section counts**

Change:
```
└── tests/                     # Test suite (62 tests across 6 suites)
    ├── run.sh                 # Test runner
    ├── bootstrap.php          # Test harness bootstrap (ob_start, HARNESS_ prefix)
    ├── CSRFTest.php           # CSRF helpers (unit, 16 tests)
    ├── AuthTest.php           # Authentication (integration, 9 tests)
    ├── CRUDTest.php           # CRUD operations (integration, 11 tests)
    ├── SecurityHeadersTest.php # HTTP security headers (7 tests)
    ├── SettingsTest.php       # Settings class (integration, 6 tests)
    └── SoftDeleteTest.php     # Soft-delete lifecycle (integration, 13 tests)
```
To:
```
└── tests/                     # PHP test suite (7 suites) + Playwright UI tests
    ├── run.sh                 # Test runner (--php-only flag skips Playwright)
    ├── bootstrap.php          # Test harness bootstrap (ob_start, HARNESS_ prefix)
    ├── CSRFTest.php           # CSRF helpers (unit)
    ├── AuthTest.php           # Authentication (integration)
    ├── CRUDTest.php           # CRUD operations (integration)
    ├── SecurityHeadersTest.php # HTTP security headers
    ├── SettingsTest.php       # Settings class (integration)
    ├── SoftDeleteTest.php     # Soft-delete lifecycle (integration)
    ├── TenancyTest.php        # Multi-tenant data isolation (integration)
    ├── OrgManagementTest.php  # Org CRUD + member management (integration)
    └── ui/                    # Playwright end-to-end specs
```

- [ ] **Step 8: Fix the tenancy branch note in the Schema section**

Change:
```
Five business tables (`users`, `customers`, `sales`, `orders`, `stock`) have `deleted_at TIMESTAMP` and `deleted_by INT` for the soft-delete pattern. Tables marked *(tenancy)* are on the `feature/tenancy-schema` branch.
```
To:
```
Five business tables (`users`, `customers`, `sales`, `orders`, `stock`) have `deleted_at TIMESTAMP` and `deleted_by INT` for the soft-delete pattern. All 14 tables are fully merged into main.
```

- [ ] **Step 9: Remove the *(tenancy)* labels from the schema table**

Change:
```
| `orgs` *(tenancy)* | Organization registry | Planned soft-delete |
| `org_members` *(tenancy)* | User ↔ org membership + role | No |
```
To:
```
| `orgs` | Organization registry | No |
| `org_members` | User ↔ org membership + role | No |
```

---

## Task 4: Update tech-stack.md

**Files:**
- Modify: `docs/tech-stack.md`

- [ ] **Step 1: Fix MariaDB table count**

Change:
```
| **MariaDB** | 10.x | Relational database — 9 tables, InnoDB engine, foreign key constraints with CASCADE |
```
To:
```
| **MariaDB** | 10.x | Relational database — 14 tables, InnoDB engine, foreign key constraints with CASCADE |
```

- [ ] **Step 2: Add Bootstrap Icons row to Frontend table**

After the Bootstrap row:
```
| **Bootstrap** | 5.x | `libs/bootstrap/` | CSS framework for responsive layout, forms, tables, alerts, modals |
```
Add:
```
| **Bootstrap Icons** | 1.x | `libs/bootstrap-icons/` | SVG icon sprite — referenced via `<use href="...bi.svg#icon-name">` |
```

- [ ] **Step 3: Add Dev Tooling section before CI / Quality Tools**

After the Offline-First Design section and before the Security Features section (or after Security Features, before CI/Quality Tools), insert:

```markdown
## Dev Tooling

| Tool | Version | Purpose | Config |
|------|---------|---------|--------|
| **Composer** | 2.x | PHP dependency manager — dev dependencies only (not used at runtime) | `composer.json` |
| **PHPUnit** | 11.x | Unit and integration test runner | `tests/` — invoked via `tests/run.sh` or `vendor/bin/phpunit` |
```

- [ ] **Step 4: Update CI/Quality Tools test suite line**

Change:
```
| **Test suite** | Custom harness (`test()` / `check()`), 6 suites / 62 tests, HARNESS_ data isolation | `tests/run.sh` |
```
To:
```
| **Test suite** | Custom harness (`test()` / `check()`), 7 PHP suites + Playwright UI tests, HARNESS_ data isolation | `tests/run.sh` |
```

- [ ] **Step 5: Add multi-tenancy row to Security Features table**

After the **Soft-delete** row, add:
```
| **Multi-tenant isolation** | All queries scoped to `$_SESSION['active_org_id']`; `join_product_table()` / `find_all()` auto-filter by org_id; HARNESS_ORG used in tests | `includes/sql.php`, migrations 010–021 |
```

---

## Task 5: Update setup-and-usage.md

**Files:**
- Modify: `docs/setup-and-usage.md`

- [ ] **Step 1: Add Running Tests section after the Installation section**

Find the `## Default Accounts` heading. Insert this section immediately before it:

```markdown
## Running Tests

### Prerequisites

- `.env` must exist with valid DB credentials (the test harness connects to the live DB using a `HARNESS_` data prefix)
- Composer dev dependencies installed: `composer install`
- Apache must be running (SecurityHeadersTest makes real HTTP requests to `localhost:8080`)

### PHP test suites

```bash
bash tests/run.sh           # all suites (PHP + Playwright)
```

Expected output when app is running at `localhost:8080`:
```
OK--- Authentication (integration) ---
OK: All tenancy tests passed.
OK: All org management tests passed.
OK--- Security Headers (http) ---
=========================================
 Summary: 7/9 suites passed
=========================================
```

The 2 failing suites are Playwright auth setup — see the Playwright section below.

### Playwright UI tests

Requires a running app and seeded auth state:

```bash
npx playwright test                    # headless
npx playwright test --headed           # with browser visible
npx playwright test tests/ui/products  # specific spec
```

> Playwright tests seed their own `HARNESS_` users via `auth.setup.js`. If the setup spec fails, the remaining UI tests won't run — check that the app is accessible at `http://localhost:8080`.

```

---

## Task 6: Commit doc updates

**Files:** all three modified docs

- [ ] **Step 1: Run test suite to confirm clean working tree**

```bash
bash tests/run.sh 2>&1 | tail -5
```

Expected (PHP suites pass; Playwright failures are pre-existing and unrelated to doc edits):
```
=========================================
 Summary: 7/9 suites passed
=========================================
FAILED: 2 test suite(s)
```

- [ ] **Step 2: Stage and commit**

```bash
git add docs/architecture.md docs/tech-stack.md docs/setup-and-usage.md
git commit -m "docs: update architecture, tech-stack, setup to reflect PRs #31-50"
```

- [ ] **Step 3: Final verification**

```bash
git branch -a
```

Expected output — only one branch:
```
* main
  remotes/origin/main
```

```bash
git log --oneline -3
```

Confirm the docs commit is at the top.
