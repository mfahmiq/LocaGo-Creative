# Playwright Coverage Gaps Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add two missing Playwright test paths: zero-stock oversell redirect in `sales.spec.js` and org soft-delete/restore cycle in `org-switcher.spec.js`.

**Architecture:** Both tasks append a new `describe` block to an existing spec file. No PHP changes. The server-side logic already exists; the tests exercise `add_sale_by_search.php:34-36` (zero-stock guard) and `restore_org.php` (org restore). Each task has its own `beforeAll`/`afterAll` fixture lifecycle.

**Tech Stack:** Playwright (Node), PHP/Apache at `http://localhost:8080`. Requires `tests/ui/.auth/admin.json` storageState (run `npx playwright test login.spec.js` first if missing).

---

## Pre-flight check

- [ ] **Verify app is running**

  ```bash
  curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/users/home.php
  ```
  Expected: `302` (redirect to login). If you get `000` or `connection refused`, start Apache: `sudo systemctl start apache2`.

- [ ] **Verify auth fixture exists**

  ```bash
  ls tests/ui/.auth/admin.json
  ```
  Expected: file exists. If missing: `npx playwright test tests/ui/login.spec.js --project=chromium`

---

## Task 1: Zero-stock oversell redirect

**Files:**
- Modify: `tests/ui/sales.spec.js` (append after the final closing `});`)

### Step 1 — Append the new describe block

- [ ] Open `tests/ui/sales.spec.js`. After the final `});` on the last line, append:

```js
// ─── Zero-stock edge case ────────────────────────────────────────────────────

const HARNESS_ZERO_PRODUCT  = 'HARNESS_ZeroStock_' + Date.now();
const HARNESS_ZERO_CUSTOMER = 'HARNESS_ZeroCust_'  + Date.now();

let zeroOrderId;

test.describe('Sales zero-stock edge case', () => {
  test.beforeAll(async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();
    page.on('dialog', d => d.accept());

    await ensureCategoryExists(page, HARNESS_CAT);

    // Create a product with qty=0
    await page.goto('/products/add_product.php');
    await page.fill('input[name="product-title"]',    HARNESS_ZERO_PRODUCT);
    await page.fill('input[name="product-desc"]',     'Playwright zero-stock test');
    await page.fill('input[name="product-sku"]',      'PWZERO-' + Date.now());
    await page.fill('input[name="product-location"]', 'PW-ZERO');
    await page.selectOption('select[name="product-category"]', { label: HARNESS_CAT });
    await page.fill('input[name="product-quantity"]', '0');
    await page.fill('input[name="cost-price"]',       '5');
    await page.fill('input[name="sale-price"]',       '10');
    await page.click('button[name="add_product"]');
    await page.waitForURL(/\/products\/products\.php/);

    // Create an order to sell against
    await page.goto('/sales/add_order.php');
    await page.fill('input[name="customer-name"]',  HARNESS_ZERO_CUSTOMER);
    await page.selectOption('select[name="paymethod"]', 'Cash');
    await page.fill('input[name="notes"]', 'Playwright zero-stock test order');
    await page.click('button[name="add_order"]');
    await page.waitForURL(/add_sale_by_search\.php\?id=(\d+)/);
    zeroOrderId = page.url().match(/id=(\d+)/)[1];

    await ctx.close();
  });

  test.afterAll(async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();
    page.on('dialog', d => d.accept());

    // Delete zero-stock product
    await page.goto('/products/products.php');
    const prodRow = page.locator('tbody tr', { hasText: HARNESS_ZERO_PRODUCT });
    if ((await prodRow.count()) > 0) {
      await prodRow.locator('a.btn-danger').click();
      await page.waitForLoadState('networkidle');
    }

    // Delete zero-stock order
    if (zeroOrderId) {
      await page.goto('/sales/orders.php');
      const orderRow = page.locator('tbody tr', { hasText: HARNESS_ZERO_CUSTOMER });
      if ((await orderRow.count()) > 0) {
        await orderRow.locator('a.btn-danger').click();
        await page.waitForLoadState('networkidle');
      }
    }

    await ctx.close();
  });

  test('oversell attempt redirects to order view', async ({ page }) => {
    await page.goto(`/sales/add_sale_by_search.php?id=${zeroOrderId}`);

    // Search for the zero-stock product
    await page.fill('input[name="search"]', HARNESS_ZERO_PRODUCT);
    await page.click('button[type="submit"]');
    await page.waitForLoadState('networkidle');

    // Product row should appear in results
    const productRow = page.locator('tr', { hasText: HARNESS_ZERO_PRODUCT });
    await expect(productRow).toHaveCount(1);

    // Attempt to add 1 unit (stock is 0 — server guard fires at add_sale_by_search.php:34)
    await productRow.locator('input[name="quantity"]').fill('1');
    await productRow.locator('button[name="add_sale"]').click();

    // Server redirects to sales_by_order (not orders.php) when qty > stock
    await expect(page).toHaveURL(new RegExp(`sales_by_order\\.php\\?id=${zeroOrderId}`));
  });
});
```

### Step 2 — Run to verify the test passes

- [ ] Run only the new describe block:

  ```bash
  npx playwright test tests/ui/sales.spec.js --grep "zero-stock" --project=chromium 2>&1 | tail -20
  ```
  Expected:
  ```
  ✓  Sales zero-stock edge case › oversell attempt redirects to order view
  1 passed
  ```

  If you see `zeroOrderId is undefined`: the `beforeAll` fixture failed. Run with `--reporter=list` for full output. Common cause: `add_order.php` selector mismatch — check `input[name="customer-name"]` exists on that page.

### Step 3 — Run the full sales spec to confirm no regressions

- [ ] ```bash
  npx playwright test tests/ui/sales.spec.js --project=chromium 2>&1 | tail -10
  ```
  Expected: all tests pass (was 3, now 4).

### Step 4 — Commit

- [ ] ```bash
  git add tests/ui/sales.spec.js
  git commit -m "test: add zero-stock oversell redirect Playwright spec"
  ```

---

## Task 2: Org soft-delete and restore cycle

**Files:**
- Modify: `tests/ui/org-switcher.spec.js` (append after the final closing `});`)

### Step 1 — Append the new describe block

- [ ] Open `tests/ui/org-switcher.spec.js`. After the final `});` on the last line, append:

```js
// ─── Soft-delete / restore cycle ─────────────────────────────────────────────

const HARNESS_RESTORE_ORG = 'HARNESS_RestoreOrg';

test.describe('Org soft-delete and restore cycle', () => {
  test.beforeAll(async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();

    await page.goto('/orgs/orgs.php');

    // Clean up any leftover from a prior failed run
    const leftover = page.locator('tr', { hasText: HARNESS_RESTORE_ORG });
    if ((await leftover.count()) > 0) {
      // If it's soft-deleted, restore first so the hard-delete button appears
      const restoreBtn = leftover.locator('button.btn-success');
      if ((await restoreBtn.count()) > 0) {
        await restoreBtn.click();
        await page.waitForURL(/orgs\.php/);
      }
      const deleteBtn = page.locator('tr', { hasText: HARNESS_RESTORE_ORG }).locator('button.btn-danger');
      if ((await deleteBtn.count()) > 0) {
        page.on('dialog', d => d.accept());
        await deleteBtn.click();
        await page.waitForURL(/orgs\.php/);
      }
    }

    // Create HARNESS_RestoreOrg
    await page.fill('form:has(input[name="org_id"][value="0"]) input[name="name"]', HARNESS_RESTORE_ORG);
    await page.click('form:has(input[name="org_id"][value="0"]) button[type="submit"]');
    await expect(page).toHaveURL(/edit_org\.php/);

    await ctx.close();
  });

  test.afterAll(async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();

    await page.goto('/orgs/orgs.php');
    const row = page.locator('tr', { hasText: HARNESS_RESTORE_ORG });

    if ((await row.count()) > 0) {
      // If soft-deleted, restore first so hard-delete button appears
      const restoreBtn = row.locator('button.btn-success');
      if ((await restoreBtn.count()) > 0) {
        await restoreBtn.click();
        await page.waitForURL(/orgs\.php/);
      }
      const deleteBtn = page.locator('tr', { hasText: HARNESS_RESTORE_ORG }).locator('button.btn-danger');
      if ((await deleteBtn.count()) > 0) {
        page.on('dialog', d => d.accept());
        await deleteBtn.click();
        await page.waitForURL(/orgs\.php/);
      }
    }

    await ctx.close();
  });

  test('soft-deleting org removes it from switcher', async ({ page }) => {
    await page.goto('/orgs/orgs.php');

    const row = page.locator('tr', { hasText: HARNESS_RESTORE_ORG });

    // Accept the confirm dialog and soft-delete
    page.on('dialog', d => d.accept());
    await row.locator('button.btn-danger').click();
    await page.waitForURL(/orgs\.php/);

    // Row should now show the Deleted badge
    const deletedRow = page.locator('tr', { hasText: HARNESS_RESTORE_ORG });
    await expect(deletedRow.locator('.badge.bg-danger')).toBeVisible();

    // Org should not appear in the switcher dropdown
    await page.goto('/users/home.php');
    await page.click('li.dropdown > a.toggle');
    await expect(
      page.locator(`.org-switcher-btn:has-text("${HARNESS_RESTORE_ORG}")`)
    ).not.toBeVisible();
  });

  test('restoring org brings it back to switcher', async ({ page }) => {
    await page.goto('/orgs/orgs.php');

    const row = page.locator('tr', { hasText: HARNESS_RESTORE_ORG });

    // Restore (no confirm dialog on restore)
    await row.locator('button.btn-success').click();
    await page.waitForURL(/orgs\.php/);

    // Row should now show the Active badge
    const activeRow = page.locator('tr', { hasText: HARNESS_RESTORE_ORG });
    await expect(activeRow.locator('.badge.bg-success')).toBeVisible();

    // Org should reappear in the switcher dropdown
    await page.goto('/users/home.php');
    await page.click('li.dropdown > a.toggle');
    await expect(
      page.locator(`.org-switcher-btn:has-text("${HARNESS_RESTORE_ORG}")`)
    ).toBeVisible();
  });
});
```

### Step 2 — Run to verify both tests pass

- [ ] ```bash
  npx playwright test tests/ui/org-switcher.spec.js --grep "soft-delete and restore" --project=chromium 2>&1 | tail -20
  ```
  Expected:
  ```
  ✓  Org soft-delete and restore cycle › soft-deleting org removes it from switcher
  ✓  Org soft-delete and restore cycle › restoring org brings it back to switcher
  2 passed
  ```

  If `button.btn-danger` is not found in Test A: the org may still be active — check `orgs.php` renders the delete button for `HARNESS_RestoreOrg`. The `btn-danger` selector matches `class="btn btn-sm btn-danger"` on that page.

  If Test B fails with `button.btn-success` not found: the first test may not have completed the soft-delete — run both tests together so state carries between them within the same describe block.

### Step 3 — Run the full org-switcher spec to confirm no regressions

- [ ] ```bash
  npx playwright test tests/ui/org-switcher.spec.js --project=chromium 2>&1 | tail -10
  ```
  Expected: all tests pass (was 5, now 7).

### Step 4 — Commit

- [ ] ```bash
  git add tests/ui/org-switcher.spec.js
  git commit -m "test: add org soft-delete/restore cycle Playwright spec"
  ```

---

## Task 3: Full suite smoke run

### Step 1 — Run the complete Playwright suite

- [ ] ```bash
  npx playwright test --project=chromium 2>&1 | tail -15
  ```
  Expected: all tests pass. Count was 15 before; now expect 17.

### Step 2 — Run PHP tests to confirm no regressions

- [ ] ```bash
  bash tests/run.sh 2>&1 | tail -5
  ```
  Expected: all suites pass (no PHP files were modified).

### Step 3 — Final commit if any cleanup needed

If no changes were needed beyond Task 1 and Task 2 commits, no further commit required.
