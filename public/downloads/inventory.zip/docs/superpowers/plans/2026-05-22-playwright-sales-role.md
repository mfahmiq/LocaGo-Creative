# Playwright Sales Golden Path + Role-Access Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a Playwright spec that covers the sales golden path (create order → add sale → verify order appears) and verify the existing role-access spec passes with the user storageState already wired in `auth.setup.js`.

**Architecture:** Two independent spec files. `sales.spec.js` is self-contained — it creates its own HARNESS_ product, order, and customer in `beforeAll`, runs the path, then cleans up in `afterAll`. `role-access.spec.js` already exists and uses `user.json` storageState; this plan just verifies it passes cleanly.

**Tech Stack:** Playwright, PHP/MySQL inventory app at `http://localhost:8080`, existing `auth.setup.js` (admin + user storageState), `tests/run.sh`

---

### Task 1: Verify `role-access.spec.js` passes

The spec already exists at `tests/ui/role-access.spec.js` and uses `storageState: 'tests/ui/.auth/user.json'`. The user storageState is created by `auth.setup.js` (seeds `harness_uitest_user` and adds them to org 1). Before writing new tests, confirm the existing ones pass cleanly.

- [ ] **Step 1: Confirm app is running**

```bash
curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/users/index.php
```
Expected: `200`

- [ ] **Step 2: Run only the role-access spec**

```bash
cd /home/coreconduit/inventory && npx playwright test tests/ui/role-access.spec.js --reporter=line 2>&1
```

Expected output (2 tests):
```
  ✓ Role-gated access (regular user) › regular user is redirected away from /orgs/orgs.php
  ✓ Role-gated access (regular user) › regular user does not see Organizations link in topbar
  2 passed
```

If tests fail, check that `tests/ui/.auth/user.json` exists. If not, run setup first:
```bash
npx playwright test tests/ui/auth.setup.js --reporter=line 2>&1
```

---

### Task 2: Write `tests/ui/sales.spec.js`

**Files:**
- Create: `tests/ui/sales.spec.js`

The sales flow requires ROLE_ADMIN for `add_order.php` and `orders.php`. The spec uses admin storageState.

Golden path:
1. `beforeAll`: create HARNESS_ category → create HARNESS_ product → create HARNESS_ order (via `add_order.php` form)
2. **Test A**: Add sale to order via `add_sale_by_search.php` (search for HARNESS_ product, fill quantity, submit)
3. **Test B**: Order with the sale appears in `orders.php`
4. `afterAll`: soft-delete the product; soft-delete the order

- [ ] **Step 1: Write the spec red (before running)**

Create `tests/ui/sales.spec.js`:

```javascript
const { test, expect } = require('@playwright/test');

const HARNESS_CAT     = 'HARNESS_SalesCat';
const HARNESS_PRODUCT = 'HARNESS_SalesProduct_' + Date.now();
const HARNESS_CUSTOMER = 'HARNESS_SalesCust_' + Date.now();
const INITIAL_QTY     = 50;

let orderId;

async function ensureCategoryExists(page, name) {
  await page.goto('/products/categories.php');
  const exists = page.locator(`tbody td:text-is("${name}")`);
  if ((await exists.count()) === 0) {
    await page.fill('input[name="category-name"]', name);
    await page.click('button[name="add_cat"]');
    await page.waitForURL(/categories\.php/);
  }
}

test.describe('Sales golden path', () => {
  test.beforeAll(async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();
    page.on('dialog', d => d.accept());

    // Ensure category exists
    await ensureCategoryExists(page, HARNESS_CAT);

    // Create HARNESS_ product
    await page.goto('/products/add_product.php');
    await page.fill('input[name="product-title"]', HARNESS_PRODUCT);
    await page.fill('input[name="product-desc"]', 'Playwright sales test product');
    await page.fill('input[name="product-sku"]', 'PWSALE-' + Date.now());
    await page.fill('input[name="product-location"]', 'PW-SALES');
    await page.selectOption('select[name="product-category"]', { label: HARNESS_CAT });
    await page.fill('input[name="product-quantity"]', String(INITIAL_QTY));
    await page.fill('input[name="cost-price"]', '10');
    await page.fill('input[name="sale-price"]', '30');
    await page.click('button[name="add_product"]');
    await page.waitForURL(/\/products\/products\.php/);

    // Create HARNESS_ order (add_order.php creates customer if new)
    await page.goto('/sales/add_order.php');
    await page.fill('input[name="customer-name"]', HARNESS_CUSTOMER);
    await page.selectOption('select[name="paymethod"]', 'Cash');
    await page.fill('input[name="notes"]', 'Playwright test order');
    await page.click('button[name="add_order"]');
    // Successful order creation redirects to add_sale_by_search.php?id=N
    await page.waitForURL(/add_sale_by_search\.php\?id=(\d+)/);
    const url = page.url();
    orderId = url.match(/id=(\d+)/)[1];

    await ctx.close();
  });

  test.afterAll(async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();
    page.on('dialog', d => d.accept());

    // Soft-delete the product
    await page.goto('/products/products.php');
    const prodRow = page.locator('tbody tr', { hasText: HARNESS_PRODUCT });
    if ((await prodRow.count()) > 0) {
      await prodRow.locator('a.btn-danger').click();
      await page.waitForLoadState('networkidle');
    }

    // Soft-delete the order
    if (orderId) {
      await page.goto('/sales/orders.php');
      const orderRow = page.locator('tbody tr', { hasText: HARNESS_CUSTOMER });
      if ((await orderRow.count()) > 0) {
        await orderRow.locator('a.btn-danger').click();
        await page.waitForLoadState('networkidle');
      }
    }

    await ctx.close();
  });

  test('add sale to order via product search', async ({ page }) => {
    // Navigate to add_sale_by_search for our order
    await page.goto(`/sales/add_sale_by_search.php?id=${orderId}`);

    // Search for the HARNESS_ product
    await page.fill('input[name="search"]', HARNESS_PRODUCT);
    await page.click('button[type="submit"]');
    await page.waitForLoadState('networkidle');

    // The product row should appear with an "Add Sale" button
    const productRow = page.locator('tr', { hasText: HARNESS_PRODUCT });
    await expect(productRow).toHaveCount(1);

    // Fill quantity and submit
    await productRow.locator('input[name="quantity"]').fill('2');
    await productRow.locator('button[name="add_sale"]').click();

    // Successful add redirects to orders.php
    await page.waitForURL(/\/sales\/orders\.php/);
    await expect(page).toHaveURL(/orders\.php/);
  });

  test('order with sale appears in orders list', async ({ page }) => {
    await page.goto('/sales/orders.php');
    // The order row identified by HARNESS_CUSTOMER name
    const orderRow = page.locator('tbody tr', { hasText: HARNESS_CUSTOMER });
    await expect(orderRow).toHaveCount(1);
    // The order ID cell should contain our orderId
    await expect(orderRow.locator('td').first()).toContainText(orderId);
  });

  test('sold product stock is reduced', async ({ page }) => {
    await page.goto('/products/products.php');
    const row = page.locator('tbody tr', { hasText: HARNESS_PRODUCT });
    await expect(row).toHaveCount(1);
    // Column 6 (index 5) = Stock
    const stockText = await row.locator('td').nth(5).innerText();
    // Sold 2 units from INITIAL_QTY=50 → should be 48
    expect(parseInt(stockText.trim(), 10)).toBe(INITIAL_QTY - 2);
  });
});
```

- [ ] **Step 2: Run the new spec (red phase — will fail if no app running)**

```bash
cd /home/coreconduit/inventory && npx playwright test tests/ui/sales.spec.js --reporter=line 2>&1
```

Expected: 3 tests pass if app is running and admin storageState is valid. If app is not running, confirm it is started first.

---

### Task 3: Run the full Playwright suite

- [ ] **Step 1: Run all UI tests**

```bash
cd /home/coreconduit/inventory && npx playwright test --reporter=line 2>&1
```

Expected: All specs pass. The count should be previous total + 3 new tests.

- [ ] **Step 2: Run the combined test suite**

```bash
bash tests/run.sh 2>&1 | tail -20
```

Expected: PHP suites + Playwright all green.

- [ ] **Step 3: Commit**

```bash
git add tests/ui/sales.spec.js
git commit -m "test(ui): sales golden path — create order, add sale, verify stock reduction"
```
