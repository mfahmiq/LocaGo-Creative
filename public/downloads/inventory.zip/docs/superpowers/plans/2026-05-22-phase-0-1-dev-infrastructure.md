# Phase 0 + Phase 1 — Dev Infrastructure Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Install composer + PHPUnit in `~/inventory`, add a `phpunit.xml` that points at the existing bootstrap, prove the infra works by converting one legacy test (`CSRFTest`) to a PHPUnit `TestCase` class, and rewire `tests/run.sh` to invoke PHPUnit. This is the foundation for porting cc-inventory features that ship as PHPUnit tests.

**Architecture:** Composer is added as a *dev-only* dependency layer — `composer.json` + `composer.lock` are committed; `vendor/` is gitignored. PHPUnit 11 runs under PHP 8.4 and uses the existing `tests/bootstrap.php` (lightly adapted to be PHPUnit-safe). Legacy hand-rolled `test()`-helper scripts remain runnable side-by-side with PHPUnit during the transition; conversion of the remaining 8 legacy tests is deferred to a follow-up "Phase 1.5" plan.

**Tech Stack:** PHP 8.4 (CLI), Composer 2.x, PHPUnit ^11, bash. Inventory mysqli + custom session/SQL helpers stay unchanged.

---

## Spec reference

This plan implements **Phase 0** and **Phase 1** from `docs/superpowers/specs/2026-05-22-cc-inventory-merge-design.md`. Remaining phases (legacy-test migration, ops drop-ins, org-aware crons, brand/a11y, suppliers/purchasing/data_tools, cleanup) each get their own plan when scheduled.

## File structure

| File | Action | Responsibility |
|---|---|---|
| `composer.json` | create | Declare PHPUnit 11 dev dep |
| `composer.lock` | create (via `composer install`) | Pin exact versions |
| `.gitignore` | modify | Ignore `vendor/`, `.phpunit.cache/` |
| `phpunit.xml` | create | PHPUnit config: bootstrap, testsuite, cache dir |
| `tests/bootstrap.php` | modify | Suppress echo banner when running under PHPUnit (env flag) |
| `tests/CSRFTest.php` | rewrite | First test converted from hand-rolled to `class CSRFTest extends TestCase` |
| `tests/InfraSmokeTest.php` | create | Trivial PHPUnit test proving the runner + bootstrap wiring works |
| `tests/run.sh` | rewrite | Thin wrapper invoking `vendor/bin/phpunit` for converted tests + legacy `php tests/*.php` for the rest |
| `.githooks/pre-commit` | modify | Optional hook step: invoke phpunit if available |
| `CLAUDE.md` | modify | Document `vendor/bin/phpunit` workflow |
| `README.md` | modify | Document `composer install` step |
| `docs/superpowers/specs/baselines/pre-cc-merge.md` | create | Phase 0 baseline test snapshot |

---

## Phase 0 — Pre-flight bookkeeping (no PR)

### Task 0.1: Tag current main and create backup branch

**Files:** none — git metadata only.

- [ ] **Step 1: Verify clean working tree**

Run: `git -C /home/coreconduit/inventory status -s`
Expected: empty output (clean tree).

- [ ] **Step 2: Tag pre-merge state**

Run:

```bash
git -C /home/coreconduit/inventory tag -a pre-cc-merge -m "Snapshot of main before cc-inventory feature port (8-phase merge)"
git -C /home/coreconduit/inventory push origin pre-cc-merge
```

Expected: `* [new tag] pre-cc-merge -> pre-cc-merge`.

- [ ] **Step 3: Create and push backup branch**

Run:

```bash
git -C /home/coreconduit/inventory branch backup/pre-cc-merge main
git -C /home/coreconduit/inventory push -u origin backup/pre-cc-merge
```

Expected: branch tracked on origin.

### Task 0.2: Add cc-inventory as a local fetch-only remote

**Files:** `.git/config` (via `git remote`).

- [ ] **Step 1: Add the local cc-inventory clone as a remote**

Run:

```bash
git -C /home/coreconduit/inventory remote add cc-archive /home/coreconduit/cc-inventory
git -C /home/coreconduit/inventory remote set-url --push cc-archive no-push
git -C /home/coreconduit/inventory fetch cc-archive
```

Expected: `* [new branch] main -> cc-archive/main` (and other cc branches).

- [ ] **Step 2: Verify the remote**

Run: `git -C /home/coreconduit/inventory remote -v`
Expected output includes:
```
cc-archive  /home/coreconduit/cc-inventory (fetch)
cc-archive  no-push (push)
origin      https://github.com/bitsandbots/inventory.git (fetch)
origin      https://github.com/bitsandbots/inventory.git (push)
```

### Task 0.3: Snapshot baseline test state

**Files:**
- Create: `docs/superpowers/specs/baselines/pre-cc-merge.md`

- [ ] **Step 1: Run the existing test suite and capture output**

Run:

```bash
cd /home/coreconduit/inventory && bash tests/run.sh 2>&1 | tee /tmp/pre-cc-merge-tests.txt
```

Expected: summary line `Summary: N/N suites passed`. If suites are skipped (no DB or no Apache), note that explicitly.

- [ ] **Step 2: Write the baseline snapshot**

Create `docs/superpowers/specs/baselines/pre-cc-merge.md` with content:

```markdown
# Baseline: pre-cc-merge

**Captured:** 2026-05-22 (commit $(git rev-parse --short HEAD))
**Tag:** pre-cc-merge
**Backup branch:** backup/pre-cc-merge

## tests/run.sh output

```
<paste full output of /tmp/pre-cc-merge-tests.txt here>
```

## Counts

- PHP tests passed: <N>
- Playwright specs passed: <N>
- Skipped suites: <list>

Use this snapshot to detect regressions during Phase 1+ work.
```

- [ ] **Step 3: Commit the baseline**

Run:

```bash
git -C /home/coreconduit/inventory add docs/superpowers/specs/baselines/pre-cc-merge.md
git -C /home/coreconduit/inventory commit -m "docs: snapshot pre-cc-merge test baseline"
```

Expected: 1 file changed, commit created on `main`.

---

## Phase 1 — Dev infrastructure (PR1)

All Phase 1 work happens on branch `feature/phase1-dev-infrastructure`.

### Task 1.1: Create the feature branch

**Files:** none.

- [ ] **Step 1: Branch off main**

Run:

```bash
git -C /home/coreconduit/inventory checkout -b feature/phase1-dev-infrastructure main
```

Expected: `Switched to a new branch 'feature/phase1-dev-infrastructure'`.

### Task 1.2: Add composer.json

**Files:**
- Create: `composer.json`

- [ ] **Step 1: Verify composer is available**

Run: `composer --version`
Expected: `Composer version 2.x.x …`. If missing, install via apt: `sudo apt install composer`.

- [ ] **Step 2: Write composer.json**

Create `/home/coreconduit/inventory/composer.json`:

```json
{
    "name": "coreconduit/inventory",
    "description": "CoreConduit Inventory Management System (multi-tenant)",
    "type": "project",
    "license": "MIT",
    "authors": [
        {
            "name": "CoreConduit",
            "email": "bitsandbots@gmail.com"
        }
    ],
    "require": {
        "php": ">=8.1"
    },
    "require-dev": {
        "phpunit/phpunit": "^11"
    },
    "config": {
        "sort-packages": true,
        "platform": {
            "php": "8.1"
        }
    }
}
```

The platform pin to `8.1` keeps the resolver honest even though the host PHP is 8.4 — production Pi targets might trail.

### Task 1.3: Install vendor and commit lock

**Files:**
- Create: `composer.lock`
- Materializes: `vendor/` (NOT committed)

- [ ] **Step 1: Run composer install**

Run: `cd /home/coreconduit/inventory && composer install --no-interaction`
Expected: `Lock file written. Installing dependencies …`. `vendor/` directory created.

- [ ] **Step 2: Verify phpunit binary**

Run: `/home/coreconduit/inventory/vendor/bin/phpunit --version`
Expected: `PHPUnit 11.x.x by Sebastian Bergmann and contributors.`

### Task 1.4: Update .gitignore

**Files:**
- Modify: `.gitignore`

- [ ] **Step 1: Append vendor and phpunit cache ignores**

Edit `/home/coreconduit/inventory/.gitignore` to append the block below at the end:

```
# Composer
vendor/

# PHPUnit
.phpunit.cache/
.phpunit.result.cache
```

- [ ] **Step 2: Verify vendor is now ignored**

Run: `git -C /home/coreconduit/inventory status --porcelain | grep -c vendor`
Expected: `0` (no untracked files inside `vendor/` listed).

### Task 1.5: Write phpunit.xml

**Files:**
- Create: `phpunit.xml`

- [ ] **Step 1: Create the config**

Create `/home/coreconduit/inventory/phpunit.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<phpunit xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:noNamespaceSchemaLocation="vendor/phpunit/phpunit/phpunit.xsd"
         bootstrap="tests/bootstrap.php"
         colors="true"
         cacheDirectory=".phpunit.cache"
         executionOrder="depends,defects"
         displayDetailsOnTestsThatTriggerWarnings="true"
         displayDetailsOnTestsThatTriggerDeprecations="true"
         displayDetailsOnTestsThatTriggerNotices="true"
         displayDetailsOnTestsThatTriggerErrors="true"
         failOnWarning="true"
         failOnNotice="true">
    <testsuites>
        <testsuite name="Inventory">
            <directory>tests</directory>
            <exclude>tests/bootstrap.php</exclude>
            <exclude>tests/lib</exclude>
            <exclude>tests/ui</exclude>
            <exclude>tests/playwright</exclude>
        </testsuite>
    </testsuites>
    <php>
        <env name="INVENTORY_TEST_RUNNER" value="phpunit"/>
    </php>
</phpunit>
```

Key details:
- `bootstrap="tests/bootstrap.php"` — reuses inventory's existing bootstrap (Task 1.6 makes it quieter under PHPUnit).
- `<env INVENTORY_TEST_RUNNER="phpunit"/>` — lets bootstrap detect PHPUnit and suppress its banner echoes.
- All `tests/*.php` that are not yet PHPUnit classes will be ignored by PHPUnit's classfile discovery (it scans for classes; legacy scripts have no class so they're skipped). The exclude blocks belt-and-braces the `lib/`, `ui/`, and `playwright/` subdirs.

### Task 1.6: Adapt tests/bootstrap.php to be PHPUnit-quiet

**Files:**
- Modify: `tests/bootstrap.php:110-115`

The current bootstrap ends with:

```php
echo "Test bootstrap loaded.\n";
if (!getenv('TESTS_NO_DB')) {
    echo "DB connection: OK\n";
} else {
    echo "DB connection: SKIPPED (TESTS_NO_DB=1)\n";
}
```

Under PHPUnit, these echoes appear as "Risky test output" warnings. Suppress them when `INVENTORY_TEST_RUNNER=phpunit`.

- [ ] **Step 1: Write the failing test first**

Create `tests/InfraSmokeTest.php`:

```php
<?php

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;

class InfraSmokeTest extends TestCase
{
    #[Test]
    public function bootstrap_loaded_constants(): void
    {
        $this->assertTrue(defined('SITE_ROOT'), 'SITE_ROOT should be defined by bootstrap');
        $this->assertTrue(defined('APP_LANG'), 'APP_LANG should be defined by bootstrap');
        $this->assertTrue(defined('ROLE_ADMIN'), 'ROLE_ADMIN should be defined by bootstrap');
    }

    #[Test]
    public function phpunit_runner_env_is_set(): void
    {
        $this->assertSame('phpunit', getenv('INVENTORY_TEST_RUNNER'));
    }

    #[Test]
    public function bootstrap_does_not_print_banner_under_phpunit(): void
    {
        // The bootstrap should detect INVENTORY_TEST_RUNNER=phpunit and skip
        // the "Test bootstrap loaded." echo lines. If those echoes happen,
        // PHPUnit raises a "test printed unexpected output" warning, which
        // failOnWarning="true" promotes to a failure.
        $this->expectNotToPerformAssertions();
    }
}
```

- [ ] **Step 2: Run it to confirm the unexpected-output failure**

Run: `/home/coreconduit/inventory/vendor/bin/phpunit --filter InfraSmokeTest`
Expected: At least `bootstrap_does_not_print_banner_under_phpunit` fails with a "test printed unexpected output" warning, because bootstrap.php still echoes.

- [ ] **Step 3: Make bootstrap PHPUnit-quiet**

Edit `tests/bootstrap.php`. Replace lines 110–115 (the trailing echo block) with:

```php
if (getenv('INVENTORY_TEST_RUNNER') !== 'phpunit') {
    echo "Test bootstrap loaded.\n";
    if (!getenv('TESTS_NO_DB')) {
        echo "DB connection: OK\n";
    } else {
        echo "DB connection: SKIPPED (TESTS_NO_DB=1)\n";
    }
}
```

- [ ] **Step 4: Re-run the smoke test**

Run: `/home/coreconduit/inventory/vendor/bin/phpunit --filter InfraSmokeTest`
Expected: `OK (3 tests, 2 assertions)`. (The third test uses `expectNotToPerformAssertions()`.)

- [ ] **Step 5: Commit the infra foundation**

Run:

```bash
cd /home/coreconduit/inventory
git add composer.json composer.lock .gitignore phpunit.xml tests/bootstrap.php tests/InfraSmokeTest.php
git commit -m "chore: install composer + PHPUnit 11 with quiet bootstrap

Adds composer.json/lock with PHPUnit ^11 as dev dep. phpunit.xml points
at tests/bootstrap.php and sets INVENTORY_TEST_RUNNER=phpunit env so the
bootstrap can suppress its banner echoes that would otherwise trip
failOnWarning. vendor/ and .phpunit.cache/ gitignored. InfraSmokeTest
covers the wiring."
```

### Task 1.7: Convert CSRFTest.php to a PHPUnit class

**Files:**
- Rewrite: `tests/CSRFTest.php`

The current file uses a hand-rolled `test()` helper:

```php
$pass = 0; $fail = 0;
function test(string $name, callable $fn): void { … }
test('csrf_token() generates a hex token', function () { … });
```

We rewrite it as a `class CSRFTest extends TestCase`. This is the proof-of-pattern conversion; the remaining 8 legacy tests stay as-is and are converted in Phase 1.5.

- [ ] **Step 1: Read the existing test to enumerate every `test()` call**

Run: `grep -n "^test(" /home/coreconduit/inventory/tests/CSRFTest.php`
Note each name → it becomes a `#[Test] public function …` method in the new class.

- [ ] **Step 2: Write the new PHPUnit class**

Replace the entire contents of `/home/coreconduit/inventory/tests/CSRFTest.php` with the new class. Use this scaffold and copy each individual test body across, replacing `assert(...)` with `$this->assertTrue(...)`/`$this->assertSame(...)`:

```php
<?php
/**
 * tests/CSRFTest.php
 *
 * Tests for CSRF token generation and validation.
 */

use PHPUnit\Framework\TestCase;
use PHPUnit\Framework\Attributes\Test;

class CSRFTest extends TestCase
{
    protected function setUp(): void
    {
        if (!isset($_SESSION)) {
            $_SESSION = [];
        }
        // Clear any previous token so each test starts fresh.
        unset($_SESSION['csrf_token']);
    }

    #[Test]
    public function csrf_token_generates_a_hex_token(): void
    {
        $token = csrf_token();
        $this->assertNotEmpty($token, 'Token is empty');
        $this->assertSame(64, strlen($token), 'Token should be 64 hex chars (32 bytes)');
        $this->assertArrayHasKey('csrf_token', $_SESSION, 'Token not stored in session');
    }

    // … one #[Test] method per legacy test() call …
}
```

Verbatim mapping rules:
- `test('foo bar baz', function () { … })` → `#[Test] public function foo_bar_baz(): void { … }`
- `assert($x, 'msg')` → `$this->assertTrue((bool)$x, 'msg')` (preferred: pick a more specific assert like `assertSame`, `assertNotEmpty`, `assertArrayHasKey` when the original assertion is a comparison).
- `assert($a === $b)` → `$this->assertSame($b, $a)` (note: PHPUnit puts expected first).
- Diagnostic `echo` lines inside tests should be removed (they trip `failOnWarning`).

- [ ] **Step 3: Run only CSRFTest under PHPUnit**

Run: `/home/coreconduit/inventory/vendor/bin/phpunit --filter CSRFTest`
Expected: `OK (N tests, M assertions)` — where N matches the count of original `test(...)` calls.

If any test fails, the message comes from the original assertion's message string; debug by reading the bound `$_SESSION` state.

- [ ] **Step 4: Run the full PHPUnit suite to confirm nothing else broke**

Run: `/home/coreconduit/inventory/vendor/bin/phpunit`
Expected: `OK` covering `CSRFTest` + `InfraSmokeTest` only — the other 8 legacy tests are auto-skipped because they have no class definition.

- [ ] **Step 5: Confirm the legacy runner still works for the unconverted tests**

Run: `cd /home/coreconduit/inventory && bash tests/run.sh`
Expected: same summary line as the baseline in `docs/superpowers/specs/baselines/pre-cc-merge.md`. CSRFTest no longer runs through the bash runner (Task 1.8 removes it from the bash invocation).

- [ ] **Step 6: Commit the CSRFTest conversion**

```bash
cd /home/coreconduit/inventory
git add tests/CSRFTest.php
git commit -m "test: convert CSRFTest to PHPUnit TestCase (proof-of-pattern)

First of the 9 legacy tests/*.php scripts to migrate from the hand-rolled
test() helper to PHPUnit. Establishes the conversion pattern; remaining 8
tests follow in a Phase 1.5 plan."
```

### Task 1.8: Rewrite tests/run.sh as a thin wrapper

**Files:**
- Rewrite: `tests/run.sh`

Goal: invoke PHPUnit for the PHPUnit-class-style tests (`CSRFTest`, `InfraSmokeTest`) and invoke `php tests/<File>.php` for each unconverted legacy file. Keep the Playwright invocation at the end.

- [ ] **Step 1: Write the failing test first — verify run.sh exits 0**

Run baseline (before edit): `cd /home/coreconduit/inventory && bash tests/run.sh; echo "exit=$?"`
Record exit code. It must remain `0` after the rewrite for non-failure runs.

- [ ] **Step 2: Replace tests/run.sh with the wrapper**

Overwrite `/home/coreconduit/inventory/tests/run.sh` with:

```bash
#!/bin/bash
#
# tests/run.sh
#
# Run all PHP + Playwright tests for the Inventory Management System.
# Usage: bash tests/run.sh
#
# Two runners coexist during the legacy→PHPUnit migration:
#   - vendor/bin/phpunit runs every tests/*Test.php that defines a class.
#   - php tests/<File>.php runs the legacy hand-rolled test scripts that
#     haven't been converted yet (tracked in Phase 1.5).
#
# Requires a valid .env file with database credentials for full suite.
# When .env is missing or DB is unreachable, integration tests are skipped.

cd "$(dirname "$0")/.."

TOTAL=0
PASSED=0
FAILED=0
SKIPPED=0

echo "========================================="
echo " Inventory Management System — Test Suite"
echo " Date: $(date)"
echo "========================================="
echo ""

# ── PHPUnit (CSRFTest + InfraSmokeTest, plus any future PHPUnit class) ──
TOTAL=$((TOTAL + 1))
echo "--- PHPUnit ---"
if vendor/bin/phpunit --colors=never; then
    PASSED=$((PASSED + 1))
else
    FAILED=$((FAILED + 1))
fi
echo ""

# ── Legacy scripts that still use the hand-rolled test() helper ──
run_legacy() {
    local test_file="$1"
    local name="$2"
    local nodb="${3:-}"
    TOTAL=$((TOTAL + 1))
    echo "--- $name (legacy) ---"
    if [ -n "$nodb" ]; then
        export TESTS_NO_DB=1
    fi
    if php "$test_file" 2>&1; then
        PASSED=$((PASSED + 1))
    else
        FAILED=$((FAILED + 1))
    fi
    unset TESTS_NO_DB
    echo ""
}

# DB reachability probe (same as before)
DB_OK=0
if php -r "
define('URL_SEPARATOR', '/');
define('DS', DIRECTORY_SEPARATOR);
define('SITE_ROOT', realpath('includes'));
define('LIB_PATH_INC', SITE_ROOT . DS);
require_once 'includes/config.php';
try {
    \$c = @mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (\$c) { echo 'OK'; exit(0); }
} catch (Exception \$e) {}
exit(1);
" 2>/dev/null; then
    DB_OK=1
fi

if [ "$DB_OK" -eq 1 ]; then
    run_legacy "tests/AuthTest.php"          "Authentication (integration)"
    run_legacy "tests/CRUDTest.php"          "CRUD Operations (integration)"
    run_legacy "tests/SettingsTest.php"      "Settings (integration)"
    run_legacy "tests/SoftDeleteTest.php"    "Soft-Delete (integration)"
    run_legacy "tests/TenancyTest.php"       "Tenancy (integration)"
    run_legacy "tests/OrgManagementTest.php" "Org Management (integration)"
else
    echo "--- Integration tests ---"
    echo "  SKIPPED: Database not accessible."
    SKIPPED=$((SKIPPED + 6))
    TOTAL=$((TOTAL + 6))
    echo ""
fi

# HTTP-dependent legacy test
run_legacy "tests/SecurityHeadersTest.php" "Security Headers (http)" nodb

# ── Playwright ──
HTTP_OK=0
if php -r "
\$base = getenv('INVENTORY_BASE_URL') ?: 'http://localhost:8080';
\$ctx = stream_context_create(['http' => ['method' => 'GET', 'timeout' => 3, 'ignore_errors' => true]]);
@file_get_contents(\$base . '/users/index.php', false, \$ctx);
if (isset(\$http_response_header)) { echo 'OK'; exit(0); }
exit(1);
" 2>/dev/null; then
    HTTP_OK=1
fi

TOTAL=$((TOTAL + 1))
echo "--- Playwright UI Tests ---"
if [ "$HTTP_OK" -eq 1 ] && command -v npx &>/dev/null; then
    if npx playwright test --reporter=line 2>&1; then
        PASSED=$((PASSED + 1))
    else
        FAILED=$((FAILED + 1))
    fi
else
    echo "  SKIPPED: server not reachable or npx not found."
    SKIPPED=$((SKIPPED + 1))
fi
echo ""

echo "========================================="
echo " Summary: $PASSED/$TOTAL suites passed"
[ "$SKIPPED" -gt 0 ] && echo " ($SKIPPED skipped)"
echo "========================================="

if [ "$FAILED" -gt 0 ]; then
    echo "FAILED: $FAILED test suite(s)"
    exit 1
fi

echo "OK: All available test suites passed."
exit 0
```

- [ ] **Step 3: Run the wrapper end-to-end**

Run: `cd /home/coreconduit/inventory && bash tests/run.sh; echo "exit=$?"`
Expected: `exit=0`. The PHPUnit line and each legacy line both print PASS counts. Counts may be `8/8` or `9/9` depending on DB/HTTP availability — match the baseline.

- [ ] **Step 4: Confirm Playwright still runs**

If Apache is up on `:8080`:

Run: `cd /home/coreconduit/inventory && INVENTORY_BASE_URL=http://localhost:8080 bash tests/run.sh 2>&1 | tail -20`
Expected: Playwright suite shows pass.

- [ ] **Step 5: Commit the wrapper**

```bash
cd /home/coreconduit/inventory
git add tests/run.sh
git commit -m "chore: wire tests/run.sh to PHPUnit + legacy scripts

Runs vendor/bin/phpunit first (picks up CSRFTest + InfraSmokeTest), then
falls back to php tests/<File>.php for the 8 unconverted legacy scripts.
Identical exit semantics and summary line preserved for muscle memory.
Legacy block shrinks in Phase 1.5 as each legacy test gets a PHPUnit
class twin."
```

### Task 1.9: Update .githooks/pre-commit

**Files:**
- Modify: `.githooks/pre-commit`

If `vendor/bin/phpunit` exists, run a quick PHPUnit pass on the unit-only `CSRFTest` and `InfraSmokeTest` (no DB) before allowing the commit.

- [ ] **Step 1: Read current pre-commit hook tail**

Run: `tail -20 /home/coreconduit/inventory/.githooks/pre-commit`
Confirm where the hook currently ends (likely after the CSRF action-attribute check).

- [ ] **Step 2: Append the PHPUnit check**

Add at the very end of `.githooks/pre-commit`:

```bash
# PHPUnit quick gate (no-DB tests only)
if [ -x vendor/bin/phpunit ]; then
    if ! TESTS_NO_DB=1 vendor/bin/phpunit --filter "CSRFTest|InfraSmokeTest" --no-progress >/dev/null 2>&1; then
        echo -e "${RED}pre-commit: PHPUnit unit tests failed.${NC}" >&2
        echo "  Run: vendor/bin/phpunit --filter \"CSRFTest|InfraSmokeTest\"" >&2
        exit 1
    fi
fi
```

- [ ] **Step 3: Test the hook manually**

Run (simulate):

```bash
cd /home/coreconduit/inventory
bash .githooks/pre-commit
echo "exit=$?"
```

Expected: `exit=0` if all checks pass.

- [ ] **Step 4: Commit the hook update**

```bash
cd /home/coreconduit/inventory
git add .githooks/pre-commit
git commit -m "chore(hooks): add PHPUnit unit gate to pre-commit

Runs CSRFTest + InfraSmokeTest (no DB) on each commit. Keeps the existing
PHP -l lint and CSRF action-attribute guard intact; new check is additive."
```

### Task 1.10: Update CLAUDE.md and README.md

**Files:**
- Modify: `CLAUDE.md`
- Modify: `README.md`

- [ ] **Step 1: Update CLAUDE.md commands block**

Find the existing test command documentation in `/home/coreconduit/inventory/CLAUDE.md` (search: `tests/run.sh`). Add a new section above it documenting PHPUnit. If the file has no test docs yet, add this block:

```markdown
## Testing

- Run everything: `bash tests/run.sh`
- PHPUnit only: `vendor/bin/phpunit`
- One PHPUnit class: `vendor/bin/phpunit --filter CSRFTest`
- One method: `vendor/bin/phpunit --filter csrf_token_generates_a_hex_token`
- Playwright only: `npx playwright test`
- Skip DB tests: `TESTS_NO_DB=1 vendor/bin/phpunit`

The PHPUnit suite covers tests that have been converted from the legacy
hand-rolled `test()` helper. Conversion progress: see
docs/superpowers/specs/2026-05-22-cc-inventory-merge-design.md (Phase 1.5).
```

- [ ] **Step 2: Update README.md install steps**

Find the "Installation" section in `/home/coreconduit/inventory/README.md` (or the install.sh invocation block). Add:

```markdown
### Development setup

```bash
composer install         # installs PHPUnit and other dev deps to vendor/
vendor/bin/phpunit       # runs the PHPUnit suite
```

PHPUnit 11 requires PHP 8.1+. The repo pins `platform.php` to 8.1 in
`composer.json` so the resolver stays compatible with older deploy
targets.
```

- [ ] **Step 3: Commit the docs**

```bash
cd /home/coreconduit/inventory
git add CLAUDE.md README.md
git commit -m "docs: document composer + PHPUnit workflow"
```

### Task 1.11: Final verification

**Files:** none.

- [ ] **Step 1: Run the full wrapper from a clean shell**

```bash
cd /home/coreconduit/inventory && bash tests/run.sh
```
Expected: exit 0, summary line matches baseline (modulo CSRFTest having moved into the PHPUnit line).

- [ ] **Step 2: Run PHPUnit in isolation**

```bash
cd /home/coreconduit/inventory && vendor/bin/phpunit
```
Expected: `OK (N tests, M assertions)` where N ≥ 4 (CSRFTest tests + 3 InfraSmokeTest tests).

- [ ] **Step 3: Diff-check the changed files**

Run: `git -C /home/coreconduit/inventory diff main..feature/phase1-dev-infrastructure --stat`
Expected file list (no surprises):
```
.githooks/pre-commit                                                | XX +-
.gitignore                                                          | XX +-
CLAUDE.md                                                           | XX +-
README.md                                                           | XX +-
composer.json                                                       | new
composer.lock                                                       | new
docs/superpowers/specs/baselines/pre-cc-merge.md                    | new
phpunit.xml                                                         | new
tests/CSRFTest.php                                                  | XX +-
tests/InfraSmokeTest.php                                            | new
tests/bootstrap.php                                                 | XX +-
tests/run.sh                                                        | XX +-
```

- [ ] **Step 4: Push the branch and open the PR**

```bash
cd /home/coreconduit/inventory
git push -u origin feature/phase1-dev-infrastructure
gh pr create --title "Phase 1: composer + PHPUnit dev infrastructure" --body "$(cat <<'EOF'
## Summary
- Adds composer.json/lock with PHPUnit ^11; `vendor/` gitignored.
- Adds `phpunit.xml` pointing at the existing `tests/bootstrap.php`.
- Adapts bootstrap to suppress its banner echoes when run under PHPUnit (env flag).
- Converts `tests/CSRFTest.php` to a PHPUnit `TestCase` class — proof of pattern.
- Rewires `tests/run.sh` to invoke PHPUnit first, then fall back to the 8 unconverted legacy scripts.
- Adds a pre-commit PHPUnit unit gate.
- Documents the workflow in CLAUDE.md and README.md.

Phase 1 of the 8-phase cc-inventory merge per
docs/superpowers/specs/2026-05-22-cc-inventory-merge-design.md.

## Test plan
- [x] `vendor/bin/phpunit` green (CSRFTest + InfraSmokeTest).
- [x] `bash tests/run.sh` green, exit 0, summary matches `docs/superpowers/specs/baselines/pre-cc-merge.md`.
- [x] Playwright suite still runs and passes.
- [x] `.githooks/pre-commit` PHPUnit gate passes on a real commit.
EOF
)"
```

Expected: PR URL printed.

---

## Definition of done for this plan

1. `composer.json` and `composer.lock` committed; `vendor/` gitignored.
2. `phpunit.xml` exists and runs against `tests/bootstrap.php`.
3. `tests/CSRFTest.php` is a PHPUnit `TestCase` class; `vendor/bin/phpunit --filter CSRFTest` passes.
4. `tests/InfraSmokeTest.php` exists and proves the bootstrap-quiet behavior.
5. `tests/run.sh` invokes both PHPUnit and the 8 unconverted legacy scripts; exit code 0 matches baseline.
6. `.githooks/pre-commit` runs the no-DB PHPUnit gate on every commit.
7. `CLAUDE.md` + `README.md` document the new workflow.
8. PR opened against `bitsandbots/inventory` main, CI (if any) green.
9. Baseline snapshot at `docs/superpowers/specs/baselines/pre-cc-merge.md` committed on `main`.

## What's NOT in this plan (deferred to Phase 1.5)

- Converting `AuthTest.php`, `CRUDTest.php`, `SettingsTest.php`, `SoftDeleteTest.php`, `TenancyTest.php`, `OrgManagementTest.php`, `SecurityHeadersTest.php`, `CSRFTest.php`'s lib subdirectory tests to PHPUnit.
- Removing the legacy block from `tests/run.sh` (happens once Phase 1.5 completes).
- Any cc-inventory feature ports (Phase 2+).

## Self-review notes

- **Spec coverage:** Phase 0 (pre-flight) and Phase 1 (dev infra) from the design spec are both addressed. Phase 1's three sub-goals from the spec — install composer/PHPUnit, ensure existing tests still pass, rewrite run.sh as wrapper — all map to tasks above. Acceptance criteria explicit in §Definition of done.
- **Placeholders:** none. The CSRFTest conversion (Task 1.7) gives a verbatim scaffold with explicit mapping rules; the engineer reads the legacy file and applies them. This is the only step where exact code can't be pre-typed because it depends on the count and names of the legacy `test()` calls.
- **Type/name consistency:** `INVENTORY_TEST_RUNNER` env name used identically in phpunit.xml, bootstrap.php, and the InfraSmokeTest. `CSRFTest` class name matches filename. `feature/phase1-dev-infrastructure` branch name used in every git command.
