# Plan C: Operational Tooling — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Port three operational subsystems from `cc-inventory`: (1) low-stock email+SMS alerting with cooldown, (2) real-time log monitoring with UI, and (3) backup as a proper cron script.

**Architecture:** Three independent subsystems — each adds an env-var group, one PHP include file, and one cron-ready root script. Log monitoring also needs two DB tables (migration 027). Each subsystem can be deployed independently.

**Tech Stack:** PHP 8.1+, native SMTP (fsockopen/STARTTLS), Textbelt HTTP SMS, MySQLi, JSON cooldown file.

**Note on `exec()` in backup.php:** PHP's `exec()` with `escapeshellarg()` is the safe approach for shell commands in PHP. Credentials are passed via a temp file (not the command line) to avoid appearing in `ps` output. The security hook that triggered is for Node.js `child_process.exec()` — not applicable here.

---

## File Map

| Action | File | Change |
|--------|------|--------|
| Modify | `includes/config.php` | Add SMTP, alert, log monitor, backup env constants |
| Create | `includes/alerts.php` | Low-stock detection + email + SMS delivery |
| Create | `alerts_check.php` | Cron: runs alerts, produces plain-text log output |
| Create | `migrations/027_log_events.up.sql` | log_events + log_monitor_state tables |
| Create | `migrations/027_log_events.down.sql` | Rollback |
| Create | `includes/sql_log_monitor.php` | Log event query functions |
| Modify | `includes/load.php` | require_once sql_log_monitor.php |
| Create | `log_monitor_scan.php` | Cron: scan log files, write events |
| Create | `users/log_monitor.php` | UI: event list + clear |
| Create | `users/log_monitor_count.php` | AJAX: badge count |
| Create | `users/log_monitor_clear.php` | POST: clear all events |
| Modify | `layouts/footer.php` | Add log monitor badge polling script |
| Modify | `layouts/admin_menu.php` | Add Log Monitor nav link |
| Modify | `backup.php` | Make cron-compatible (credentials file, summary output) |
| Create | `data/` directory | Runtime data for alert cooldowns |
| Create | `tests/AlertsTest.php` | Port pure-function alert tests |

---

## Task 1: Config Constants for All Three Subsystems

**Files:**
- Modify: `includes/config.php`

- [ ] **Step 1: Add env constant blocks to `includes/config.php`**

Append after the existing `define('APP_LANG', ...)` line:

```php
/*
|--------------------------------------------------------------------------
| Session Timeout (also used by Plan A — safe to add here)
|--------------------------------------------------------------------------
*/
if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', (int)(($_ENV_CFG['SESSION_TIMEOUT_MINUTES'] ?? 30)) * 60);
}

/*
|--------------------------------------------------------------------------
| Alert delivery — email (SMTP) and SMS (Textbelt)
|--------------------------------------------------------------------------
*/
define('SMTP_HOST',            $_ENV_CFG['SMTP_HOST']            ?? '');
define('SMTP_PORT',      (int)($_ENV_CFG['SMTP_PORT']            ?? 587));
define('SMTP_USER',            $_ENV_CFG['SMTP_USER']            ?? '');
define('SMTP_PASS',            $_ENV_CFG['SMTP_PASS']            ?? '');
define('SMTP_FROM',            $_ENV_CFG['SMTP_FROM']            ?? '');
define('SMTP_FROM_NAME',       $_ENV_CFG['SMTP_FROM_NAME']       ?? 'Inventory');
define('ALERT_EMAIL_TO',       $_ENV_CFG['ALERT_EMAIL_TO']       ?? '');
define('TEXTBELT_URL',         $_ENV_CFG['TEXTBELT_URL']         ?? '');
define('TEXTBELT_KEY',         $_ENV_CFG['TEXTBELT_KEY']         ?? 'textbelt');
define('ALERT_SMS_TO',         $_ENV_CFG['ALERT_SMS_TO']         ?? '');
define('ALERT_COOLDOWN_HOURS', (int)($_ENV_CFG['ALERT_COOLDOWN_HOURS'] ?? 24));

/*
|--------------------------------------------------------------------------
| Log Monitor
|--------------------------------------------------------------------------
*/
define('LOG_MONITOR_ENABLED',
    strtolower($_ENV_CFG['LOG_MONITOR_ENABLED'] ?? 'true') !== 'false');
define('LOG_MONITOR_PATHS',
    $_ENV_CFG['LOG_MONITOR_PATHS'] ?? '/var/log/apache2/error.log');
define('LOG_MONITOR_LEVELS',
    $_ENV_CFG['LOG_MONITOR_LEVELS'] ?? 'ERROR,CRITICAL,WARNING');
define('LOG_MONITOR_DEDUP_WINDOW_SEC',
    (int)($_ENV_CFG['LOG_MONITOR_DEDUP_WINDOW_SEC'] ?? 5));
define('LOG_MONITOR_FIRST_SCAN_BYTES',
    (int)($_ENV_CFG['LOG_MONITOR_FIRST_SCAN_BYTES'] ?? 10000));
define('LOG_MONITOR_SMS_RATE_LIMIT',
    (int)($_ENV_CFG['LOG_MONITOR_SMS_RATE_LIMIT'] ?? 900));
define('LOG_MONITOR_WEBHOOK_URL',
    $_ENV_CFG['LOG_MONITOR_WEBHOOK_URL'] ?? '');

/*
|--------------------------------------------------------------------------
| Backup
|--------------------------------------------------------------------------
*/
define('BACKUP_DIR',            $_ENV_CFG['BACKUP_DIR']            ?? CONFIG_ROOT . '/backups');
define('BACKUP_RETAIN_COUNT',   (int)($_ENV_CFG['BACKUP_RETAIN_COUNT']   ?? 7));
define('LOG_RETAIN_DAYS',       (int)($_ENV_CFG['LOG_RETAIN_DAYS']       ?? 90));
define('AUDIT_LOG_RETAIN_DAYS', (int)($_ENV_CFG['AUDIT_LOG_RETAIN_DAYS'] ?? 365));
```

- [ ] **Step 2: Run tests**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: no regressions (constants are defined but nothing uses them yet).

- [ ] **Step 3: Commit**

```bash
git add includes/config.php
git commit -m "feat(ops): add SMTP, alert, log monitor, backup config constants"
```

---

## Task 2: Low-Stock Alerts

**Files:**
- Create: `includes/alerts.php`
- Create: `alerts_check.php`
- Create: `data/` directory (for cooldown JSON)
- Test: `tests/AlertsTest.php`

- [ ] **Step 1: Write failing tests**

Create `tests/AlertsTest.php`:

```php
<?php
use PHPUnit\Framework\TestCase;

class AlertsTest extends TestCase {

    private string $tmp_file;

    protected function setUp(): void {
        $this->tmp_file = sys_get_temp_dir() . '/test_cooldowns_' . uniqid() . '.json';
    }

    protected function tearDown(): void {
        if (file_exists($this->tmp_file)) unlink($this->tmp_file);
    }

    public function test_not_in_cooldown_initially(): void {
        $cooldowns  = [];
        $product_id = 42;
        $last       = $cooldowns[$product_id] ?? 0;
        $this->assertFalse($last > 0 && (time() - $last) < (24 * 3600));
    }

    public function test_in_cooldown_after_recent_send(): void {
        $cooldowns  = [42 => time() - 100];
        $product_id = 42;
        $hours      = 24;
        $last       = $cooldowns[$product_id] ?? 0;
        $this->assertTrue($last > 0 && (time() - $last) < ($hours * 3600));
    }

    public function test_not_in_cooldown_after_expiry(): void {
        $cooldowns  = [42 => time() - (2 * 3600)]; // 2h ago, 1h window
        $product_id = 42;
        $hours      = 1;
        $last       = $cooldowns[$product_id] ?? 0;
        $this->assertFalse($last > 0 && (time() - $last) < ($hours * 3600));
    }

    public function test_cooldown_json_round_trips(): void {
        $cooldowns = [1 => 1716000000, 2 => 1716001000];
        file_put_contents($this->tmp_file, json_encode($cooldowns, JSON_PRETTY_PRINT));
        $loaded = json_decode(file_get_contents($this->tmp_file), true);
        $this->assertSame($cooldowns, $loaded);
    }

    public function test_smtp_subject_contains_count(): void {
        $count   = 3;
        $subject = "Inventory Alert: $count product(s) low on stock";
        $this->assertStringContainsString('3', $subject);
        $this->assertNotEmpty($subject);
    }
}
```

- [ ] **Step 2: Run tests**

```bash
php vendor/bin/phpunit tests/AlertsTest.php -v
```

Expected: PASS (pure logic, no DB, no SMTP).

- [ ] **Step 3: Create `data/` directory**

```bash
mkdir -p /home/coreconduit/inventory/data
touch /home/coreconduit/inventory/data/.gitkeep
echo "data/alert_cooldowns.json" >> .gitignore
```

- [ ] **Step 4: Create `includes/alerts.php`**

```php
<?php
/**
 * includes/alerts.php
 * Low-stock detection and alert delivery (native SMTP + Textbelt SMS).
 * Call get_low_stock_products() for dashboard read-only use.
 * Call send_low_stock_alerts() from the alerts_check.php cron script.
 */

define('ALERT_COOLDOWN_FILE', CONFIG_ROOT . '/data/alert_cooldowns.json');

// ---------------------------------------------------------------------------
// Cooldown helpers
// ---------------------------------------------------------------------------

function load_cooldowns(): array {
    $file = ALERT_COOLDOWN_FILE;
    if (!file_exists($file)) return [];
    $content = file_get_contents($file);
    if ($content === false) { error_log("Cannot read: $file"); return []; }
    $data = json_decode($content, true);
    if (!is_array($data)) { error_log("Corrupt cooldowns file: $file"); return []; }
    return $data;
}

function save_cooldowns(array $cooldowns): void {
    $file = ALERT_COOLDOWN_FILE;
    $dir  = dirname($file);
    if (!is_dir($dir)) mkdir($dir, 0750, true);
    $json = json_encode($cooldowns, JSON_PRETTY_PRINT);
    $fh = fopen($file, 'c');
    if (!$fh) { error_log("Cannot open for write: $file"); return; }
    if (flock($fh, LOCK_EX)) {
        ftruncate($fh, 0);
        fwrite($fh, $json);
        fflush($fh);
        flock($fh, LOCK_UN);
    }
    fclose($fh);
}

function alert_in_cooldown(int $product_id, array $cooldowns): bool {
    $last = $cooldowns[$product_id] ?? 0;
    return ($last > 0 && (time() - $last) < (ALERT_COOLDOWN_HOURS * 3600));
}

// ---------------------------------------------------------------------------
// Stock query (multi-tenant: scoped to current_org_id)
// ---------------------------------------------------------------------------

function get_low_stock_products(): array {
    global $db;
    return $db->prepare_select(
        "SELECT id, name, sku, location, quantity, low_stock_threshold
           FROM products
          WHERE deleted_at IS NULL
            AND org_id = ?
            AND quantity <= low_stock_threshold
          ORDER BY quantity ASC",
        'i', current_org_id()
    ) ?? [];
}

// ---------------------------------------------------------------------------
// Email — native PHP SMTP (STARTTLS + AUTH LOGIN)
// ---------------------------------------------------------------------------

function send_smtp_email(string $to, string $subject, string $body): bool {
    if (empty(SMTP_HOST) || empty($to)) return false;

    $conn = fsockopen(SMTP_HOST, SMTP_PORT, $errno, $errstr, 10);
    if (!$conn) {
        error_log("SMTP connect failed (" . SMTP_HOST . ":" . SMTP_PORT . "): $errno $errstr");
        return false;
    }

    $read = static fn() => fgets($conn, 1024);
    $send = static function(string $cmd) use ($conn): void { fwrite($conn, $cmd . "\r\n"); };

    try {
        $read(); // 220 banner
        $send("EHLO " . gethostname());
        $cap = '';
        while (($line = $read()) !== false) {
            $cap .= $line;
            if (substr($line, 3, 1) === ' ') break;
        }

        if (str_contains($cap, 'STARTTLS')) {
            $send("STARTTLS");
            $read();
            stream_socket_enable_crypto($conn, true, STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT);
            $send("EHLO " . gethostname());
            while (($line = $read()) !== false) {
                if (substr($line, 3, 1) === ' ') break;
            }
        }

        $send("AUTH LOGIN");
        $read();
        $send(base64_encode(SMTP_USER));
        $read();
        $send(base64_encode(SMTP_PASS));
        $resp = $read();
        if (!str_starts_with($resp, '235')) {
            error_log("SMTP AUTH failed: $resp");
            fclose($conn);
            return false;
        }

        $from = SMTP_FROM;
        $name = SMTP_FROM_NAME;
        $mid  = '<' . uniqid('inv', true) . '@' . gethostname() . '>';

        $send("MAIL FROM:<$from>");  $read();
        $send("RCPT TO:<$to>");      $read();
        $send("DATA");               $read();
        $send("Date: " . date('r') . "\r\nFrom: $name <$from>\r\nTo: $to\r\n"
            . "Subject: $subject\r\nMIME-Version: 1.0\r\n"
            . "Content-Type: text/plain; charset=UTF-8\r\nMessage-ID: $mid\r\n\r\n"
            . $body . "\r\n.");
        $resp = $read();
        $send("QUIT");
        fclose($conn);
        return str_starts_with($resp, '250');

    } catch (\Throwable $e) {
        error_log("SMTP exception: " . $e->getMessage());
        if (is_resource($conn)) fclose($conn);
        return false;
    }
}

// ---------------------------------------------------------------------------
// SMS — Textbelt HTTP
// ---------------------------------------------------------------------------

function send_sms(string $phone, string $message): bool {
    if (empty(TEXTBELT_URL) || empty($phone)) return false;
    $payload = http_build_query(['phone' => $phone, 'message' => $message, 'key' => TEXTBELT_KEY]);
    $ctx = stream_context_create(['http' => [
        'method'  => 'POST',
        'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content' => $payload,
        'timeout' => 10,
    ]]);
    $result = @file_get_contents(TEXTBELT_URL . '/text', false, $ctx);
    if ($result === false) { error_log("Textbelt request failed"); return false; }
    $data = json_decode($result, true);
    if (empty($data['success'])) { error_log("Textbelt error: " . ($data['error'] ?? $result)); return false; }
    return true;
}

// ---------------------------------------------------------------------------
// Main entry point
// ---------------------------------------------------------------------------

function send_low_stock_alerts(): int {
    $items     = get_low_stock_products();
    $cooldowns = load_cooldowns();
    $to_alert  = array_filter($items, fn($i) => !alert_in_cooldown((int)$i['id'], $cooldowns));

    if (empty($to_alert)) return 0;

    $count   = count($to_alert);
    $subject = "Inventory Alert: $count product(s) low on stock";
    $lines   = ["These products are at or below their restock threshold:\n"];
    foreach ($to_alert as $item) {
        $lines[] = sprintf("  %-30s  SKU: %-12s  Qty: %d  (threshold: %d)  Loc: %s",
            $item['name'], $item['sku'],
            (int)$item['quantity'], (int)$item['low_stock_threshold'],
            $item['location'] ?? '');
    }
    $body = implode("\n", $lines);

    $email_ok = empty(ALERT_EMAIL_TO) ? false : send_smtp_email(ALERT_EMAIL_TO, $subject, $body);
    $sms_ok   = empty(ALERT_SMS_TO)   ? false : send_sms(ALERT_SMS_TO, "Inventory: $count item(s) low. Check dashboard.");

    if ($email_ok || $sms_ok) {
        $now = time();
        foreach ($to_alert as $item) $cooldowns[(int)$item['id']] = $now;
        save_cooldowns($cooldowns);
        return $count;
    }
    return 0;
}
```

- [ ] **Step 5: Create `alerts_check.php`**

```php
<?php
/**
 * alerts_check.php — Low-stock alert cron script.
 *
 * Cron (every 4 hours):
 *   0 *\/4 * * * /usr/bin/php /var/www/inventory/alerts_check.php >> /var/log/inventory_alerts.log 2>&1
 */
define('SITE_ROOT', __DIR__ . '/includes');
define('DS', DIRECTORY_SEPARATOR);

require_once __DIR__ . '/includes/load.php';
require_once __DIR__ . '/includes/alerts.php';

$is_cli = (PHP_SAPI === 'cli');
if (!$is_cli) {
    if (!isset($_SESSION['user_id'])) { http_response_code(403); exit('Access denied.'); }
    $runner = find_by_id('users', (int) $_SESSION['user_id']);
    if (!$runner || (int) $runner['user_level'] > ROLE_ADMIN) { http_response_code(403); exit('Admin only.'); }
}

header('Content-Type: text/plain');
$timestamp = date('Y-m-d H:i:s');
$low_items = get_low_stock_products();
$triggered = send_low_stock_alerts();

echo "=== Inventory Low-Stock Check — $timestamp ===\n\n";
if (empty($low_items)) {
    echo "All products adequately stocked.\n";
} else {
    printf("  %d product(s) at or below threshold:\n\n", count($low_items));
    printf("  %-30s %-12s %6s %9s  %s\n", 'Product', 'SKU', 'Qty', 'Threshold', 'Location');
    echo '  ' . str_repeat('-', 75) . "\n";
    foreach ($low_items as $item) {
        printf("  %-30s %-12s %6d %9d  %s\n",
            substr($item['name'], 0, 29), $item['sku'],
            (int)$item['quantity'], (int)$item['low_stock_threshold'],
            $item['location'] ?? '');
    }
}
echo "\n" . ($triggered > 0 ? "Alerts triggered for $triggered product(s).\n" : "No new alerts (cooldown or no SMTP/SMS configured).\n");
```

- [ ] **Step 6: Run full test suite**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: AlertsTest passes, no regressions.

- [ ] **Step 7: Commit**

```bash
git add includes/alerts.php alerts_check.php tests/AlertsTest.php \
        data/.gitkeep .gitignore includes/config.php
git commit -m "feat(ops): low-stock alerting (email + SMS + cooldown)"
```

---

## Task 3: Log Monitoring

**Files:**
- Create: `migrations/027_log_events.up.sql`
- Create: `migrations/027_log_events.down.sql`
- Create: `includes/sql_log_monitor.php`
- Modify: `includes/load.php`
- Create: `log_monitor_scan.php`
- Create: `users/log_monitor.php`
- Create: `users/log_monitor_count.php`
- Create: `users/log_monitor_clear.php`
- Modify: `layouts/footer.php`
- Modify: `layouts/admin_menu.php`

- [ ] **Step 1: Create migration up**

Save to `migrations/027_log_events.up.sql`:

```sql
-- Migration 027 — log monitoring tables.
-- log_events: captured error/warning lines from system log files.
-- log_monitor_state: file scan position tracking (handles log rotation).
-- Reverse: see 027_log_events.down.sql

SELECT 'Creating log_events table...' AS step;

CREATE TABLE `log_events` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `source_file` VARCHAR(255)  NOT NULL,
  `level`       VARCHAR(20)   NOT NULL DEFAULT 'ERROR',
  `message`     TEXT          NOT NULL,
  `line_no`     INT UNSIGNED  NULL     DEFAULT NULL,
  `occurred_at` DATETIME      NOT NULL,
  `cleared`     TINYINT(1)    NOT NULL DEFAULT 0,
  `created_at`  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_le_cleared`  (`cleared`),
  KEY `idx_le_occurred` (`occurred_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT 'Creating log_monitor_state table...' AS step;

CREATE TABLE `log_monitor_state` (
  `source_file` VARCHAR(255) NOT NULL,
  `last_byte`   BIGINT       NOT NULL DEFAULT 0,
  `last_sms_at` INT          NOT NULL DEFAULT 0,
  PRIMARY KEY (`source_file`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT 'log monitoring tables created.' AS step;
```

- [ ] **Step 2: Create migration down**

Save to `migrations/027_log_events.down.sql`:

```sql
DROP TABLE IF EXISTS `log_monitor_state`;
DROP TABLE IF EXISTS `log_events`;
```

- [ ] **Step 3: Apply migration**

```bash
mysql -u root -p inventory < migrations/027_log_events.up.sql
```

Expected: `log monitoring tables created.`

- [ ] **Step 4: Create `includes/sql_log_monitor.php`**

```php
<?php
/**
 * includes/sql_log_monitor.php
 * Log monitoring DB helpers: event storage, position tracking, UI queries.
 */

function log_monitor_uncleared_count(): int {
    global $db;
    $row = $db->prepare_select_one("SELECT COUNT(*) AS cnt FROM log_events WHERE cleared = 0");
    return $row ? (int) $row['cnt'] : 0;
}

function log_monitor_get_events(array $filters = [], int $page = 1, int $per_page = 50): array {
    global $db;
    $where  = ['1=1'];
    $types  = '';
    $params = [];

    if (!empty($filters['level'])) {
        $where[] = 'level = ?';
        $types  .= 's';
        $params[] = $filters['level'];
    }
    if (isset($filters['cleared'])) {
        $where[] = 'cleared = ?';
        $types  .= 'i';
        $params[] = (int) $filters['cleared'];
    }

    $offset   = ($page - 1) * $per_page;
    $sql      = "SELECT * FROM log_events WHERE " . implode(' AND ', $where)
              . " ORDER BY occurred_at DESC LIMIT ? OFFSET ?";
    $types   .= 'ii';
    $params[] = $per_page;
    $params[] = $offset;

    return $db->prepare_select($sql, $types, ...$params) ?? [];
}

function log_monitor_clear_all(): int {
    global $db;
    $db->prepare_query("UPDATE log_events SET cleared = 1 WHERE cleared = 0");
    return $db->affected_rows();
}

function log_monitor_get_position(string $path): int {
    global $db;
    $row = $db->prepare_select_one(
        "SELECT last_byte FROM log_monitor_state WHERE source_file = ? LIMIT 1", 's', $path
    );
    return $row ? (int) $row['last_byte'] : -1;
}

function log_monitor_set_position(string $path, int $byte_pos): void {
    global $db;
    $db->prepare_query(
        "INSERT INTO log_monitor_state (source_file, last_byte)
         VALUES (?, ?)
         ON DUPLICATE KEY UPDATE last_byte = VALUES(last_byte)",
        'si', $path, $byte_pos
    );
}

function log_monitor_get_last_sms(string $path): int {
    global $db;
    $row = $db->prepare_select_one(
        "SELECT last_sms_at FROM log_monitor_state WHERE source_file = ? LIMIT 1", 's', $path
    );
    return $row ? (int) $row['last_sms_at'] : 0;
}

function log_monitor_set_last_sms(string $path): void {
    global $db;
    $db->prepare_query(
        "INSERT INTO log_monitor_state (source_file, last_sms_at)
         VALUES (?, ?)
         ON DUPLICATE KEY UPDATE last_sms_at = VALUES(last_sms_at)",
        'si', $path, time()
    );
}

function log_monitor_is_duplicate(string $source_file, string $message, int $window_sec = 5): bool {
    global $db;
    $row = $db->prepare_select_one(
        "SELECT id FROM log_events
          WHERE source_file = ? AND message = ?
            AND occurred_at >= DATE_SUB(NOW(), INTERVAL ? SECOND)
          LIMIT 1",
        'ssi', $source_file, $message, $window_sec
    );
    return (bool) $row;
}

function log_monitor_insert_event(
    string $source_file,
    string $level,
    string $message,
    ?int   $line_no,
    string $occurred_at
): void {
    global $db;
    $db->prepare_query(
        "INSERT INTO log_events (source_file, level, message, line_no, occurred_at)
         VALUES (?, ?, ?, ?, ?)",
        'sssds',
        $source_file, $level, substr($message, 0, 65535), $line_no, $occurred_at
    );
}
```

- [ ] **Step 5: Add require to `includes/load.php`**

Find the block where other sql_*.php files are required and add:

```php
require_once LIB_PATH_INC . DS . 'sql_log_monitor.php';
```

- [ ] **Step 6: Create `log_monitor_scan.php`**

```php
<?php
/**
 * log_monitor_scan.php — Log scanning cron script.
 * Cron (every minute):
 *   * * * * * /usr/bin/php /var/www/inventory/log_monitor_scan.php >> /var/log/inventory_logmon.log 2>&1
 */
defined('SITE_ROOT') || define('SITE_ROOT', __DIR__ . '/includes');
defined('DS')        || define('DS', DIRECTORY_SEPARATOR);

require_once __DIR__ . '/includes/load.php';
require_once __DIR__ . '/includes/sql_log_monitor.php';

$is_cli = (PHP_SAPI === 'cli');
if (!$is_cli) {
    if (!isset($_SESSION['user_id'])) { http_response_code(403); exit('Access denied.'); }
    $runner = find_by_id('users', (int) $_SESSION['user_id']);
    if (!$runner || (int) $runner['user_level'] > ROLE_ADMIN) { http_response_code(403); exit('Admin only.'); }
}

if (!LOG_MONITOR_ENABLED) {
    echo date('[Y-m-d H:i:s]') . " Log monitoring disabled.\n";
    exit(0);
}

header('Content-Type: text/plain');

$paths  = array_filter(array_map('trim', explode(',', LOG_MONITOR_PATHS)));
$levels = array_map('strtoupper', array_map('trim', explode(',', LOG_MONITOR_LEVELS)));
$total  = 0;

foreach ($paths as $log_path) {
    if (!file_exists($log_path) || !is_readable($log_path)) {
        echo date('[Y-m-d H:i:s]') . " SKIP (unreadable): $log_path\n";
        continue;
    }

    $file_size = filesize($log_path);
    $last_byte = log_monitor_get_position($log_path);
    $is_new    = ($last_byte === -1);

    // First scan: only read last N bytes; rotation: reset if file shrank
    if ($is_new) {
        $start = max(0, $file_size - LOG_MONITOR_FIRST_SCAN_BYTES);
    } else {
        $start = ($file_size < $last_byte) ? 0 : $last_byte;
    }

    if ($start >= $file_size) {
        log_monitor_set_position($log_path, $file_size);
        continue;
    }

    $fh = fopen($log_path, 'r');
    if (!$fh) continue;
    fseek($fh, $start);

    $events_found = 0;
    while (($line = fgets($fh)) !== false) {
        $line = trim($line);
        if (empty($line)) continue;

        $line_upper    = strtoupper($line);
        $matched_level = null;
        foreach ($levels as $lvl) {
            if (str_contains($line_upper, $lvl)) { $matched_level = $lvl; break; }
        }
        if (!$matched_level) continue;

        if (log_monitor_is_duplicate($log_path, $line, LOG_MONITOR_DEDUP_WINDOW_SEC)) continue;

        // Parse timestamp from line if available, fall back to now
        $ts = date('Y-m-d H:i:s');
        if (preg_match('/(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2})/', $line, $m)) {
            $ts = str_replace('T', ' ', $m[1]);
        }

        log_monitor_insert_event($log_path, $matched_level, $line, null, $ts);
        $events_found++;
        $total++;
    }

    log_monitor_set_position($log_path, ftell($fh));
    fclose($fh);

    if ($events_found > 0) {
        echo date('[Y-m-d H:i:s]') . " $log_path: $events_found new event(s)\n";

        // Rate-limited SMS
        if (!empty(TEXTBELT_URL) && !empty(ALERT_SMS_TO)) {
            $last_sms = log_monitor_get_last_sms($log_path);
            if ((time() - $last_sms) > LOG_MONITOR_SMS_RATE_LIMIT) {
                if (function_exists('send_sms')) {
                    send_sms(ALERT_SMS_TO, "Log monitor: $events_found new error(s) in " . basename($log_path));
                    log_monitor_set_last_sms($log_path);
                }
            }
        }

        // Webhook
        if (!empty(LOG_MONITOR_WEBHOOK_URL)) {
            $payload = json_encode(['text' => "Log monitor: $events_found new error(s) in `$log_path`"]);
            $ctx = stream_context_create(['http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/json\r\n",
                'content' => $payload,
                'timeout' => 5,
            ]]);
            @file_get_contents(LOG_MONITOR_WEBHOOK_URL, false, $ctx);
        }
    }
}

echo date('[Y-m-d H:i:s]') . " Scan complete. $total event(s) total.\n";
```

- [ ] **Step 7: Create `users/log_monitor.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_ADMIN);

$filters      = [];
$show_cleared = isset($_GET['cleared']) ? (int) $_GET['cleared'] : 0;
$filters['cleared'] = $show_cleared;
if (isset($_GET['level']) && in_array($_GET['level'], ['ERROR','WARNING','CRITICAL'], true)) {
    $filters['level'] = $_GET['level'];
}
$events     = log_monitor_get_events($filters, 1, 200);
$page_title = 'Log Monitor';
include '../layouts/header.php';
?>
<div class="row"><div class="col-md-12">
  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
      <strong>Log Monitor (<?php echo count($events); ?>)</strong>
      <div class="d-flex gap-2">
        <a href="log_monitor.php" class="btn btn-sm btn-outline-secondary">Uncleared</a>
        <a href="log_monitor.php?cleared=1" class="btn btn-sm btn-outline-secondary">All</a>
        <form method="post" action="log_monitor_clear.php" style="display:inline">
          <?php echo csrf_field(); ?>
          <button class="btn btn-sm btn-warning"
                  onclick="return confirm('Clear all events?')">Clear All</button>
        </form>
      </div>
    </div>
    <div class="card-body p-0" style="overflow-x:auto">
      <table class="table table-sm table-striped mb-0" style="font-size:0.85rem">
        <thead><tr><th>Time</th><th>Level</th><th>Source</th><th>Message</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($events as $ev): ?>
          <tr class="<?php echo $ev['cleared'] ? 'table-secondary' : ''; ?>">
            <td style="white-space:nowrap"><?php echo remove_junk($ev['occurred_at']); ?></td>
            <td><span class="badge bg-<?php echo in_array($ev['level'],['ERROR','CRITICAL']) ? 'danger' : 'warning'; ?>">
              <?php echo remove_junk($ev['level']); ?></span></td>
            <td style="white-space:nowrap;font-size:0.8rem">
              <?php echo remove_junk(basename($ev['source_file'])); ?></td>
            <td style="word-break:break-word;max-width:500px">
              <?php echo remove_junk(substr($ev['message'], 0, 300)); ?></td>
            <td><?php echo $ev['cleared']
              ? '<span class="text-muted">cleared</span>'
              : '<span class="text-danger">active</span>'; ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (empty($events)): ?>
            <tr><td colspan="5" class="text-center text-muted p-3">No events found.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div></div>
<?php include '../layouts/footer.php'; ?>
```

- [ ] **Step 8: Create `users/log_monitor_count.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
if (!$session->isUserLoggedIn()) { http_response_code(403); exit; }
header('Content-Type: application/json');
echo json_encode(['count' => log_monitor_uncleared_count()]);
```

- [ ] **Step 9: Create `users/log_monitor_clear.php`**

```php
<?php
// SPDX-License-Identifier: MIT
require_once '../includes/load.php';
page_require_level(ROLE_ADMIN);
if (!verify_csrf()) { $session->msg('d', 'Invalid CSRF token.'); redirect('log_monitor.php'); }
$cleared = log_monitor_clear_all();
$session->msg('s', "$cleared event(s) cleared.");
redirect('log_monitor.php');
```

- [ ] **Step 10: Add Log Monitor badge polling to `layouts/footer.php`**

Before `</body>` in `layouts/footer.php`, add (only when logged in):

```php
<?php if ($session->isUserLoggedIn()): ?>
<script>
(function poll() {
    fetch('/users/log_monitor_count.php')
        .then(r => r.json())
        .then(d => {
            const b = document.getElementById('log-monitor-badge');
            if (b) { b.textContent = d.count; b.style.display = d.count > 0 ? '' : 'none'; }
        }).catch(() => {});
    setTimeout(poll, 60000);
})();
</script>
<?php endif; ?>
```

- [ ] **Step 11: Add Log Monitor nav link to `layouts/admin_menu.php`**

```html
<li class="nav-item">
  <a class="nav-link" href="<?php echo $base; ?>/users/log_monitor.php">
    Log Monitor
    <span id="log-monitor-badge" class="badge bg-danger ms-1" style="display:none"></span>
  </a>
</li>
```

- [ ] **Step 12: Run tests**

```bash
php vendor/bin/phpunit tests/ -q
```

Expected: no regressions.

- [ ] **Step 13: Commit**

```bash
git add migrations/027_log_events.up.sql migrations/027_log_events.down.sql \
        includes/sql_log_monitor.php includes/load.php \
        log_monitor_scan.php \
        users/log_monitor.php users/log_monitor_count.php users/log_monitor_clear.php \
        layouts/footer.php layouts/admin_menu.php
git commit -m "feat(ops): log monitoring (scan cron, log_events table, UI + nav badge)"
```

---

## Task 4: Backup as Cron-Ready Script

**Context:** `inventory/backup.php` exists but may produce HTML output. This makes it cron-compatible: writes credentials to a temp file (never on the command line) and produces plain-text log lines.

**Files:**
- Modify: `backup.php`

- [ ] **Step 1: Read current `backup.php`**

```bash
cat backup.php
```

Understand the current implementation before overwriting.

- [ ] **Step 2: Update `backup.php` to be cron-compatible**

Replace the entire file with:

```php
<?php
/**
 * backup.php — Database backup cron script.
 * Cron (nightly at 2am):
 *   0 2 * * * /usr/bin/php /var/www/inventory/backup.php >> /var/log/inventory_backup.log 2>&1
 *
 * Credentials are passed via a temp file (never on the command line)
 * to avoid appearing in the process list.
 */
define('SITE_ROOT', __DIR__ . '/includes');
define('DS', DIRECTORY_SEPARATOR);

require_once __DIR__ . '/includes/load.php';

$is_cli = (PHP_SAPI === 'cli');
if (!$is_cli) {
    if (!isset($_SESSION['user_id'])) { http_response_code(403); exit('Access denied.'); }
    $runner = find_by_id('users', (int) $_SESSION['user_id']);
    if (!$runner || (int) $runner['user_level'] > ROLE_ADMIN) { http_response_code(403); exit('Admin only.'); }
}

header('Content-Type: text/plain');

$backup_dir = defined('BACKUP_DIR') ? BACKUP_DIR : __DIR__ . '/backups';
if (!is_dir($backup_dir) && !mkdir($backup_dir, 0750, true)) {
    echo date('[Y-m-d H:i:s]') . " ERROR: Cannot create backup dir: $backup_dir\n";
    exit(1);
}

$timestamp   = date('Y-m-d_H-i-s');
$backup_file = "$backup_dir/backup_$timestamp.sql.gz";

// Credentials in a temp file — never passed on the command line
$tmp_cnf = tempnam(sys_get_temp_dir(), 'inv_bkp_');
chmod($tmp_cnf, 0600);
file_put_contents($tmp_cnf,
    "[client]\nhost=" . DB_HOST . "\nuser=" . DB_USER . "\npassword=" . DB_PASS . "\n"
);

// Use proc_open (safer than exec) — no shell expansion of user-controlled strings.
// All arguments passed as array, no shell interpolation.
$descriptors = [0 => ['pipe','r'], 1 => ['pipe','w'], 2 => ['pipe','w']];
$dump_proc = proc_open([
    'mysqldump',
    '--defaults-extra-file=' . $tmp_cnf,
    '--single-transaction',
    '--routines',
    '--triggers',
    DB_NAME,
], $descriptors, $dump_pipes);

$gz_proc = proc_open(
    'gzip > ' . escapeshellarg($backup_file),
    [0 => $dump_pipes[1], 1 => ['file', '/dev/null', 'w'], 2 => ['pipe', 'w']],
    $gz_pipes
);

fclose($dump_pipes[0]);
$dump_err = stream_get_contents($dump_pipes[2]);
fclose($dump_pipes[2]);

$dump_exit = proc_close($dump_proc);
$gz_exit   = proc_close($gz_proc);

unlink($tmp_cnf); // Delete credentials immediately

$ts = date('[Y-m-d H:i:s]');

if ($dump_exit !== 0 || $gz_exit !== 0 || !file_exists($backup_file)) {
    echo "$ts ERROR: Backup failed (mysqldump exit=$dump_exit, gzip exit=$gz_exit). $dump_err\n";
    exit(1);
}

$size_kb = round(filesize($backup_file) / 1024, 1);
echo "$ts Backup created: $backup_file ({$size_kb} KB)\n";

// Prune beyond BACKUP_RETAIN_COUNT
$retain = defined('BACKUP_RETAIN_COUNT') ? BACKUP_RETAIN_COUNT : 7;
$files  = glob("$backup_dir/backup_*.sql.gz") ?: [];
rsort($files);
foreach (array_slice($files, $retain) as $old) {
    unlink($old);
    echo "$ts Pruned: " . basename($old) . "\n";
}
```

- [ ] **Step 3: Run BackupTest**

```bash
php vendor/bin/phpunit tests/BackupTest.php -v
```

Expected: existing BackupTest assertions pass.

- [ ] **Step 4: Commit**

```bash
git add backup.php
git commit -m "feat(ops): backup.php cron-compatible (proc_open, temp credentials, plain-text output)"
```

---

## Self-Review Checklist

- [x] Config constants use `if (!defined(...))` guard where Plan A might define same constant
- [x] `get_low_stock_products()` scoped to `current_org_id()` — multi-tenant
- [x] Cooldown file uses `flock()` for concurrent-safe writes
- [x] SMTP uses `fsockopen()` with STARTTLS before AUTH LOGIN
- [x] `send_sms()` uses PHP stream context (no curl dependency)
- [x] Log scan handles rotation: file shrinks → reset byte offset to 0
- [x] Log scan caps first-scan ingestion to `LOG_MONITOR_FIRST_SCAN_BYTES`
- [x] Log scan deduplication uses `log_monitor_is_duplicate()` with configurable window
- [x] SMS rate-limited per `LOG_MONITOR_SMS_RATE_LIMIT` seconds
- [x] AJAX badge endpoint rejects unauthenticated requests (403)
- [x] `backup.php` uses `proc_open` (array form — no shell injection) not `exec`
- [x] Credentials temp file is `chmod 0600` and deleted immediately after use
- [x] All browser-accessible cron scripts enforce admin session before running
