# Installer Health Pass Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fix session-permission bug in install.sh, add --fix-perms recovery flag, add post-install smoke test, and correct a prepared-statement arity mismatch in sql.php.

**Architecture:** All installer changes are self-contained edits to `install.sh`. The SQL fix is a single-function rewrite in `includes/sql.php`. Two commits: one for the installer, one for the SQL fix. No new files.

**Tech Stack:** Bash (install.sh), PHP 8.x (sql.php), mysqli prepared statements, Apache/www-data permissions model.

---

## File Map

| File | Change |
|------|--------|
| `install.sh` | Step 6: add session dir chown; `--fix-perms` flag; post-install smoke test; vhost comment |
| `includes/sql.php` | `find_all_product_info_by_search()` lines 1117-1134: fix bind_param arity |
| `tests/CRUDTest.php` | Add search function test |

---

## Task 1: Fix session dir permissions in Step 6

**Files:**
- Modify: `install.sh` (Step 6 block, around line 351)

The existing Step 6 block ends after the `uploads/` ownership note. Append the session-dir block immediately after (before the closing `echo ""`).

- [ ] **Step 1.1: Locate the end of Step 6**

Run:
```bash
grep -n "Note: uploads\|Step 6\|step 6\|\[6/7\]" install.sh
```
Identify the line number of the final `echo ""` that closes Step 6.

- [ ] **Step 1.2: Add session directory fix**

In `install.sh`, find this block near the end of Step 6:
```bash
if [ "$CURRENT_OWNER" != "$APACHE_USER" ]; then
    echo -e "${YELLOW}  Note: uploads/ is owned by '$CURRENT_OWNER'.${NC}"
    echo "  To allow image uploads, run:"
    echo "    sudo chown -R ${APACHE_USER}:${APACHE_USER} $PROJECT_ROOT/uploads/"
fi

echo ""
```

Replace with:
```bash
if [ "$CURRENT_OWNER" != "$APACHE_USER" ]; then
    echo -e "${YELLOW}  Note: uploads/ is owned by '$CURRENT_OWNER'.${NC}"
    echo "  To allow image uploads, run:"
    echo "    sudo chown -R ${APACHE_USER}:${APACHE_USER} $PROJECT_ROOT/uploads/"
fi

# Fix PHP session directory so www-data can write session files.
# Without this, session_start() fails with Permission denied and login breaks.
SESSION_PATH=$(php -r "echo session_save_path() ?: '/var/lib/php/sessions';")
if [ -d "$SESSION_PATH" ]; then
    if sudo chown -R "${APACHE_USER}:${APACHE_USER}" "$SESSION_PATH" 2>/dev/null; then
        echo "  Session dir ownership set: $SESSION_PATH → $APACHE_USER"
    else
        echo -e "${YELLOW}  Warning: Could not chown $SESSION_PATH${NC}"
        echo "  Run manually: sudo chown -R ${APACHE_USER}:${APACHE_USER} $SESSION_PATH"
    fi
else
    echo -e "${YELLOW}  Warning: Session path '$SESSION_PATH' not found — skipping.${NC}"
fi

echo ""
```

- [ ] **Step 1.3: Fix stale vhost comment**

In `install.sh`, find the line inside the heredoc vhost template:
```
    # Font MIME types for Bootstrap 3 Glyphicons
```

Replace with:
```
    # Font MIME types (Bootstrap Icons / Bootstrap 5)
```

- [ ] **Step 1.4: Verify bash syntax**

```bash
bash -n install.sh && echo "Syntax OK"
```
Expected: `Syntax OK`

---

## Task 2: Add `--fix-perms` flag

**Files:**
- Modify: `install.sh` (argument parsing block ~line 40, and new early-exit block after argument parsing)

- [ ] **Step 2.1: Add flag to argument parser**

Find the `case "$arg" in` block (~line 43). It currently has `--reinstall|-r` and `--yes|-y`. Add `--fix-perms`:

```bash
for arg in "$@"; do
    case "$arg" in
        --reinstall|-r) REINSTALL=1 ;;
        --yes|-y)       ASSUME_YES=1 ;;
        --fix-perms)    FIX_PERMS=1 ;;
        --help|-h)
            sed -n '2,15p' "$0" | sed 's/^# \{0,1\}//'
            exit 0
            ;;
        *)
            echo "Unknown option: $arg" >&2
            echo "Run with --help for usage." >&2
            exit 1
            ;;
    esac
done
```

Also initialise the variable at the top of the argument-parsing section (alongside `REINSTALL=0`):
```bash
REINSTALL=0
ASSUME_YES=0
FIX_PERMS=0
```

- [ ] **Step 2.2: Guard against --reinstall + --fix-perms**

After the `for arg` loop (before the reinstall teardown block), add:
```bash
if [ "$REINSTALL" = "1" ] && [ "$FIX_PERMS" = "1" ]; then
    echo "Error: --reinstall and --fix-perms are mutually exclusive." >&2
    exit 1
fi
```

- [ ] **Step 2.3: Add --fix-perms early-exit block**

After the mutual-exclusion guard and before the reinstall teardown block, add:
```bash
# ---------------------------------------------------------------------------
# --fix-perms: correct uploads/ and session dir ownership, then run smoke
# test. Skips all install steps.
# ---------------------------------------------------------------------------
if [ "$FIX_PERMS" = "1" ]; then
    echo ""
    echo "========================================="
    echo " Inventory — Fix Permissions"
    echo "========================================="
    echo ""

    # Detect Apache user (same logic as Step 6)
    if command -v apache2 &>/dev/null; then
        APACHE_USER=$(apache2ctl -S 2>&1 | grep "User:" | head -1 \
            | sed -n 's/.*name="\([^"]*\)".*/\1/p')
        APACHE_USER="${APACHE_USER:-www-data}"
    else
        APACHE_USER="www-data"
    fi

    echo "  Apache user: $APACHE_USER"
    echo ""

    # Fix uploads/
    if [ -d "$PROJECT_ROOT/uploads" ]; then
        chmod -R 775 "$PROJECT_ROOT/uploads"
        if sudo chown -R "${APACHE_USER}:${APACHE_USER}" "$PROJECT_ROOT/uploads" 2>/dev/null; then
            echo "  uploads/ → $APACHE_USER OK"
        else
            echo -e "${YELLOW}  Warning: Could not chown uploads/ — run:${NC}"
            echo "    sudo chown -R ${APACHE_USER}:${APACHE_USER} $PROJECT_ROOT/uploads"
        fi
    fi

    # Fix session dir
    SESSION_PATH=$(php -r "echo session_save_path() ?: '/var/lib/php/sessions';")
    if [ -d "$SESSION_PATH" ]; then
        if sudo chown -R "${APACHE_USER}:${APACHE_USER}" "$SESSION_PATH" 2>/dev/null; then
            echo "  $SESSION_PATH → $APACHE_USER OK"
        else
            echo -e "${YELLOW}  Warning: Could not chown $SESSION_PATH — run:${NC}"
            echo "    sudo chown -R ${APACHE_USER}:${APACHE_USER} $SESSION_PATH"
        fi
    else
        echo -e "${YELLOW}  Warning: Session path '$SESSION_PATH' not found — skipping.${NC}"
    fi

    echo ""

    # Run smoke test (defined later in script via function — inline it here)
    _run_smoke_test

    exit 0
fi
```

> **Note:** `_run_smoke_test` is a shell function defined in Task 3. It must be defined before this block executes. In bash with `set -e`, forward-declared functions work fine as long as the function is defined before the call runs at runtime (not parse time). To avoid ordering issues, define the function immediately after the color constants block (before argument parsing), then call it here and at end-of-install.

- [ ] **Step 2.4: Verify bash syntax**

```bash
bash -n install.sh && echo "Syntax OK"
```
Expected: `Syntax OK`

---

## Task 3: Post-install smoke test

**Files:**
- Modify: `install.sh` (new function near top, call at end of file)

- [ ] **Step 3.1: Define `_run_smoke_test` function**

Add this function immediately after the color-constant block (after `NC='\033[0m'` and before the `VHOST_PORT` line):

```bash
# ---------------------------------------------------------------------------
# Smoke test: quick sanity checks after install or --fix-perms.
# Failures are warnings — the install already succeeded.
# ---------------------------------------------------------------------------
_run_smoke_test() {
    echo -e "${CYAN}[smoke]${NC} Running post-install checks..."
    echo ""

    local ok=1

    # Check 1: DB connectivity via .env credentials
    if [ -f "$PROJECT_ROOT/.env" ]; then
        if php -r "
            \$e = parse_ini_file('$PROJECT_ROOT/.env');
            \$c = new mysqli(\$e['DB_HOST'], \$e['DB_USER'], \$e['DB_PASS'], \$e['DB_NAME']);
            exit(\$c->connect_error ? 1 : 0);
        " 2>/dev/null; then
            printf "  [smoke] DB connection ............. ${GREEN}OK${NC}\n"
        else
            printf "  [smoke] DB connection ............. ${RED}FAIL${NC}\n"
            echo "          Check DB_USER/DB_PASS in .env and that '$DB_NAME' exists."
            ok=0
        fi
    else
        printf "  [smoke] DB connection ............. ${YELLOW}SKIP${NC} (.env not found)\n"
    fi

    # Check 2: HTTP reachability (expects 302 redirect to login)
    if command -v curl &>/dev/null; then
        HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" \
            --max-time 5 "http://localhost:${VHOST_PORT}/" 2>/dev/null || echo "000")
        if [ "$HTTP_CODE" = "302" ]; then
            printf "  [smoke] HTTP :${VHOST_PORT} (expect 302) ... ${GREEN}OK${NC}\n"
        else
            printf "  [smoke] HTTP :${VHOST_PORT} (expect 302) ... ${RED}WARN: got $HTTP_CODE${NC}\n"
            echo "          Apache may not be running or the vhost is not enabled."
            echo "          Run: sudo systemctl status apache2"
            ok=0
        fi
    else
        printf "  [smoke] HTTP :${VHOST_PORT} (expect 302) ... ${YELLOW}SKIP${NC} (curl not installed)\n"
    fi

    echo ""
    if [ "$ok" = "1" ]; then
        echo -e "  ${GREEN}All smoke checks passed.${NC}"
    else
        echo -e "  ${YELLOW}One or more smoke checks failed — review warnings above.${NC}"
    fi
    echo ""
}
```

- [ ] **Step 3.2: Call smoke test at end of install**

Find the final summary block at the bottom of `install.sh`. It ends with:
```bash
  echo "  Documentation: docs/README.md"
  echo "  Blueprint:     Blueprint_Overview.html"
  echo ""
```

Add a call to `_run_smoke_test` immediately after that closing `echo ""`:
```bash
_run_smoke_test
```

- [ ] **Step 3.3: Verify bash syntax**

```bash
bash -n install.sh && echo "Syntax OK"
```
Expected: `Syntax OK`

- [ ] **Step 3.4: Dry-run the smoke test in isolation**

```bash
VHOST_PORT=8080 PROJECT_ROOT=$(pwd) bash -c '
    source install.sh --help > /dev/null 2>&1 || true
    # Source just the function
    eval "$(sed -n "/_run_smoke_test()/,/^}/p" install.sh)"
    _run_smoke_test
' 2>/dev/null || bash -c 'grep -A 50 "_run_smoke_test()" install.sh | head -55'
```

If the function extraction is awkward, simply run a full install with `--fix-perms` after the next step to exercise both paths. The key check: no bash errors, both `[smoke]` lines print.

- [ ] **Step 3.5: Update usage comment at top of install.sh**

The comment block at lines 2-15 documents flags. Add `--fix-perms`:
```bash
#   bash install.sh --fix-perms       Fix uploads/ and session dir ownership,
#                                     then run smoke test. No DB or vhost changes.
```

- [ ] **Step 3.6: Commit installer changes**

```bash
git add install.sh
git commit -m "fix(install): session dir perms, --fix-perms flag, smoke test, vhost comment"
```

---

## Task 4: Fix SQL arity bug in `find_all_product_info_by_search`

**Files:**
- Modify: `includes/sql.php` lines 1117-1134
- Modify: `tests/CRUDTest.php` (add search test)

**Root cause:** The SQL at line 1127 concatenates `org_id` as a literal into the query string (3 `?` placeholders), but line 1131 binds "sssi" — 4 parameters. `database.php:109` calls `bind_param()` with 4 values against a statement with 3 placeholders → `ArgumentCountError`.

**Fix:** Move `org_id` into a `?` placeholder and always bind 4 parameters.

- [ ] **Step 4.1: Write the failing test first**

In `tests/CRUDTest.php`, find the end of the file (before or after the final `echo` summary lines) and add:

```php
// Search function — exercises find_all_product_info_by_search()
test('find_all_product_info_by_search() returns array without ArgumentCountError', function () {
    $_SESSION['current_org_id'] = 1;
    $results = find_all_product_info_by_search('HARNESS_');
    check(is_array($results), 'search should return an array');
});

test('find_all_product_info_by_search() with empty string returns array', function () {
    $_SESSION['current_org_id'] = 1;
    $results = find_all_product_info_by_search('');
    check(is_array($results), 'empty search should return an array');
});
```

- [ ] **Step 4.2: Run tests to confirm they fail**

```bash
cd /home/coreconduit/inventory && php tests/CRUDTest.php 2>&1 | tail -10
```

Expected: `FAIL: find_all_product_info_by_search() returns array without ArgumentCountError — The number of variables must match...`

- [ ] **Step 4.3: Fix the function**

In `includes/sql.php`, replace lines 1117-1134:

```php
function find_all_product_info_by_search($search) {
	global $db;
	$p_search = remove_junk($db->escape($search));
	$like = "%{$p_search}%";
	$org_id = (int)(current_org_id_safe() ?? 0);

	$sql  = " SELECT p.id,p.name,p.sku,p.location,p.quantity,p.buy_price,p.sale_price,p.media_id,p.date,c.name";
	$sql .= " AS category,m.file_name AS image";
	$sql .= " FROM products p";
	$sql .= " LEFT JOIN categories c ON c.id = p.category_id";
	$sql .= " LEFT JOIN media m ON m.id = p.media_id";
	$sql .= " WHERE (p.name LIKE ? OR p.sku LIKE ? OR p.description LIKE ?) AND p.org_id = ?";
	$sql .= " ORDER BY p.id ASC";

	return $db->prepare_select($sql, "sssi", $like, $like, $like, $org_id);
}
```

Key changes:
- `org_id` moved from SQL concatenation into a `?` placeholder (fully parameterized)
- `bind_param` is now always "sssi" with exactly 4 values matching 4 `?`
- Branching `if (current_org_id_safe() !== null)` removed — null becomes 0, which matches no real org (safe default)

- [ ] **Step 4.4: Run full test suite**

```bash
cd /home/coreconduit/inventory && bash tests/run.sh 2>&1 | tail -5
```

Expected: all tests pass, no `ArgumentCountError`.

- [ ] **Step 4.5: Commit**

```bash
git add includes/sql.php tests/CRUDTest.php
git commit -m "fix(sql): correct bind_param arity in find_all_product_info_by_search"
```

---

## Verification

After both commits:

```bash
# 1. Bash syntax clean
bash -n install.sh && echo "install.sh syntax OK"

# 2. Full PHP test suite
bash tests/run.sh

# 3. --fix-perms path (requires sudo)
sudo bash install.sh --fix-perms

# 4. Confirm smoke test shows 2× OK
# 5. Confirm login works in browser at http://blueberry.local:8080
```
