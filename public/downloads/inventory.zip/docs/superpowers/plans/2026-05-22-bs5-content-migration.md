# BS5 Content-Page Migration + Dashboard Role-Differentiation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace all BS3 components (panel→card, glyphicon→bi(), btn-xs→btn-sm, label→badge, pull-right→float-end, jumbotron→hero, table-condensed→table-sm, img-circle→rounded-circle) across the 7 highest-traffic content pages. Add role-differentiated panels to `users/home.php` so ROLE_USER sees only recently added products while ROLE_SUPERVISOR and ROLE_ADMIN also see sales stats.

**Architecture:** Pure HTML/PHP template changes; no PHP logic changes except `home.php` which adds `current_user()['user_level']` check to control which panels render. The `bi()` helper is already available via `includes/functions.php`. BS3 compat shims in `libs/css/main.css` are intentionally kept for any pages not yet migrated.

**Tech Stack:** Bootstrap 5.3 (already loaded by `layouts/header.php`), `bi()` SVG helper, existing Playwright suite for regression smoke.

---

## Global Substitution Reference

Apply these substitutions in every file this plan touches:

| BS3 (old) | BS5 (new) |
|-----------|-----------|
| `class="panel panel-default"` | `class="card"` |
| `class="panel-heading clearfix"` | `class="card-header d-flex justify-content-between align-items-center"` |
| `class="panel-heading"` | `class="card-header"` |
| `class="panel-body"` | `class="card-body"` |
| `class="panel-footer"` | `class="card-footer"` |
| `class="panel"` | `class="card"` |
| `<span class="glyphicon glyphicon-th"></span>` | `<?php echo bi('grid'); ?>` |
| `<span class="glyphicon glyphicon-th-large"></span>` | `<?php echo bi('plus-circle'); ?>` |
| `<i class="glyphicon glyphicon-remove"></i>` | `<?php echo bi('x-lg'); ?>` |
| `<span class="glyphicon glyphicon-edit"></span>` | `<?php echo bi('pencil'); ?>` |
| `<span class="glyphicon glyphicon-trash"></span>` | `<?php echo bi('trash'); ?>` |
| `<span class="glyphicon glyphicon-user"></span>` | `<?php echo bi('person'); ?>` |
| `<i class="glyphicon glyphicon-shopping-cart"></i>` | `<?php echo bi('cart'); ?>` |
| `btn-xs` | `btn-sm` |
| `class="pull-right"` | `class="float-end"` |
| `class="pull-left"` | `class="float-start"` |
| `pull-right` (inline on existing class) | `float-end` |
| `pull-left` (inline on existing class) | `float-start` |
| `class="label label-warning"` | `class="badge bg-warning text-dark"` |
| `class="label label-danger"` | `class="badge bg-danger"` |
| `class="label label-success"` | `class="badge bg-success"` |
| `class="label label-info"` | `class="badge bg-info text-dark"` |
| `class="label label-primary"` | `class="badge bg-primary"` |
| `class="label label-default"` | `class="badge bg-secondary"` |
| `table-condensed` | `table-sm` |
| `img-circle` | `rounded-circle` |
| `img-responsive` | `img-fluid` |
| `jumbotron` | `p-4 mb-4 bg-light rounded-3` |

---

### Task 1: Write failing Playwright tests for home dashboard role-diff

**Files:**
- Modify: `tests/ui/role-access.spec.js` (append new describe block)

- [ ] **Step 1: Append home dashboard role-diff tests**

Append to `tests/ui/role-access.spec.js` (after the closing `});` of the existing describe block):

```javascript
test.describe('Home dashboard role-differentiation', () => {
  test('admin sees Highest Selling Products panel', async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();
    await page.goto('/users/home.php');
    await expect(page.locator('.card-header', { hasText: 'Highest Selling Products' })).toHaveCount(1);
    await ctx.close();
  });

  test('admin sees Latest Sales panel', async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/admin.json' });
    const page = await ctx.newPage();
    await page.goto('/users/home.php');
    await expect(page.locator('.card-header', { hasText: 'LATEST SALES' })).toHaveCount(1);
    await ctx.close();
  });

  test('regular user does NOT see Highest Selling Products panel', async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/user.json' });
    const page = await ctx.newPage();
    await page.goto('/users/home.php');
    await expect(page.locator('.card-header', { hasText: 'Highest Selling Products' })).toHaveCount(0);
    await ctx.close();
  });

  test('regular user does NOT see Latest Sales panel', async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/user.json' });
    const page = await ctx.newPage();
    await page.goto('/users/home.php');
    await expect(page.locator('.card-header', { hasText: 'LATEST SALES' })).toHaveCount(0);
    await ctx.close();
  });

  test('regular user sees Recently Added Products panel', async ({ browser }) => {
    const ctx = await browser.newContext({ storageState: 'tests/ui/.auth/user.json' });
    const page = await ctx.newPage();
    await page.goto('/users/home.php');
    await expect(page.locator('.card-header', { hasText: 'Recently Added Products' })).toHaveCount(1);
    await ctx.close();
  });
});
```

- [ ] **Step 2: Run these tests — expect FAIL (panel classes are still BS3)**

```bash
cd /home/coreconduit/inventory && npx playwright test tests/ui/role-access.spec.js --reporter=line 2>&1
```

Expected: the 2 existing tests pass; the 5 new ones fail with "expected to have count 1 but got 0" or similar (because the page still uses `panel-default` not `card`).

---

### Task 2: Rewrite `users/home.php`

**Files:**
- Modify: `users/home.php` (full replacement)

- [ ] **Step 1: Replace the entire file**

```php
<?php
$page_title = 'Home Page';
require_once '../includes/load.php';
if (!$session->isUserLoggedIn(true)) { redirect('index.php', false); }
page_require_level(ROLE_USER);

$current_level   = (int)current_user()['user_level'];
$recent_products = find_recent_product_added('5');
if ($current_level <= ROLE_SUPERVISOR) {
    $products_sold = find_highest_selling_product('10');
    $recent_sales  = find_recent_sale_added('5');
}
?>
<?php include_once '../layouts/header.php'; ?>

<div class="row">
  <div class="col-md-12">
    <?php echo display_msg($msg); ?>
  </div>
</div>

<div class="row" id="myDIV">
  <div class="col-md-12">
    <div class="card mb-3">
      <div class="card-body">
        <div class="float-end">
          <a href="#" data-close-target="#myDIV" class="btn btn-sm btn-danger" data-toggle="tooltip" title="Close"><?php echo bi('x-lg'); ?></a>
        </div>
        <div class="p-4 mb-0 bg-light rounded-3 text-center">
          <h3>Welcome!</h3>Contact support for additional assistance.
        </div>
      </div>
    </div>
  </div>
</div>

<?php if ($current_level <= ROLE_SUPERVISOR): ?>
<div class="row">
  <div class="col-md-6">
    <div class="card mb-3">
      <div class="card-header">
        <strong><?php echo bi('grid'); ?> Highest Selling Products</strong>
      </div>
      <div class="card-body p-0">
        <table class="table table-striped table-bordered table-sm mb-0">
          <thead>
            <tr>
              <th>Product</th>
              <th>Total Sold</th>
              <th>Total Quantity</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($products_sold as $product_sold): ?>
            <tr>
              <td><?php echo first_character($product_sold['name']); ?></td>
              <td><?php echo (int)$product_sold['totalSold']; ?></td>
              <td><?php echo (int)$product_sold['totalQty']; ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card mb-3">
      <div class="card-header">
        <strong><?php echo bi('grid'); ?> LATEST SALES</strong>
      </div>
      <div class="card-body p-0">
        <table class="table table-striped table-bordered table-sm mb-0">
          <thead>
            <tr>
              <th class="text-center col-w-50">#</th>
              <th>Product</th>
              <th>Date</th>
              <th>Total Sale</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($recent_sales as $recent_sale): ?>
            <tr>
              <td class="text-center"><?php echo count_id(); ?></td>
              <td>
                <a href="../sales/edit_sale.php?id=<?php echo (int)$recent_sale['id']; ?>">
                  <?php echo first_character($recent_sale['name']); ?>
                </a>
              </td>
              <td><?php echo ucfirst($recent_sale['date']); ?></td>
              <td><?php echo formatcurrency(first_character($recent_sale['price']), $CURRENCY_CODE); ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<div class="row">
  <div class="col-md-12">
    <div class="card mb-3">
      <div class="card-header">
        <strong><?php echo bi('grid'); ?> Recently Added Products</strong>
      </div>
      <div class="card-body">
        <div class="list-group list-group-flush">
          <?php foreach ($recent_products as $recent_product): ?>
          <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center"
             href="../products/view_product.php?id=<?php echo (int)$recent_product['id']; ?>">
            <span>
              <?php if ((int)$recent_product['media_id'] === 0): ?>
                <img class="img-avatar rounded-circle me-2" src="../uploads/products/no_image.jpg" alt="">
              <?php else: ?>
                <img class="img-avatar rounded-circle me-2" src="../uploads/products/<?php echo $recent_product['image']; ?>" alt="">
              <?php endif; ?>
              <?php echo first_character($recent_product['name']); ?>
            </span>
            <span>
              <span class="badge bg-warning text-dark me-2">
                <?php echo formatcurrency((int)$recent_product['sale_price'], $CURRENCY_CODE); ?>
              </span>
              <small class="text-muted"><?php echo first_character($recent_product['category']); ?></small>
            </span>
          </a>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include_once '../layouts/footer.php'; ?>
```

- [ ] **Step 2: Syntax check**

```bash
php -l users/home.php
```
Expected: `No syntax errors`

- [ ] **Step 3: Run role-diff Playwright tests — expect PASS**

```bash
cd /home/coreconduit/inventory && npx playwright test tests/ui/role-access.spec.js --reporter=line 2>&1
```

Expected: all 7 tests pass (2 original + 5 new).

- [ ] **Step 4: Commit home.php**

```bash
git add users/home.php tests/ui/role-access.spec.js
git commit -m "feat: home dashboard role-diff — supervisors/admins see sales stats, users see products only"
```

---

### Task 3: Migrate `products/products.php`

**Files:**
- Modify: `products/products.php`

Apply the Global Substitution Reference. Specific changes for this file:

- [ ] **Step 1: Apply panel→card substitutions**

In `products/products.php`, make these exact replacements:

Replace:
```html
      <div class="panel panel-default">
        <div class="panel-heading clearfix">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
```
With:
```html
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <strong>
            <?php echo bi('grid'); ?>
```

Replace:
```html
          <div class="pull-right">
            <a href="../products/add_product.php" class="btn btn-primary">Add Product</a>
          </div>
```
With:
```html
          <div>
            <a href="../products/add_product.php" class="btn btn-primary">Add Product</a>
          </div>
```

Replace:
```html
        <div class="panel-body">
```
With:
```html
        <div class="card-body p-0">
```

- [ ] **Step 2: Apply btn-xs and glyphicon in action buttons**

Replace all occurrences of `btn btn-xs btn-warning` with `btn btn-sm btn-warning`, `btn btn-info btn-xs` with `btn btn-info btn-sm`, `btn btn-danger btn-xs` with `btn btn-sm btn-danger`.

Replace:
```html
					<a href="../products/add_stock.php?id=<?php echo (int)$product['id'];?>"  class="btn btn-xs btn-warning" data-toggle="tooltip" title="Add">
					  <span class="glyphicon glyphicon-th-large"></span>
					</a>
                    <a href="../products/edit_product.php?id=<?php echo (int)$product['id'];?>" class="btn btn-info btn-xs"  title="Edit" data-toggle="tooltip">
                      <span class="glyphicon glyphicon-edit"></span>
                    </a>
                    <a href="../products/delete_product.php?id=<?php echo (int)$product['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-danger btn-xs"  title="Delete" data-toggle="tooltip">
                      <span class="glyphicon glyphicon-trash"></span>
```
With:
```html
                    <a href="../products/add_stock.php?id=<?php echo (int)$product['id'];?>" class="btn btn-sm btn-warning" data-toggle="tooltip" title="Add">
                      <?php echo bi('plus-circle'); ?>
                    </a>
                    <a href="../products/edit_product.php?id=<?php echo (int)$product['id'];?>" class="btn btn-sm btn-info" title="Edit" data-toggle="tooltip">
                      <?php echo bi('pencil'); ?>
                    </a>
                    <a href="../products/delete_product.php?id=<?php echo (int)$product['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger" title="Delete" data-toggle="tooltip">
                      <?php echo bi('trash'); ?>
```

- [ ] **Step 3: Syntax check and run nav-shell spec as smoke**

```bash
php -l products/products.php && cd /home/coreconduit/inventory && npx playwright test tests/ui/nav-shell.spec.js --reporter=line 2>&1
```

Expected: no PHP syntax errors, nav-shell spec passes.

- [ ] **Step 4: Commit**

```bash
git add products/products.php
git commit -m "style: products.php BS3→BS5 — panel→card, glyphicons→bi(), btn-xs→btn-sm"
```

---

### Task 4: Migrate `sales/sales.php`

**Files:**
- Modify: `sales/sales.php`

- [ ] **Step 1: Apply panel→card, glyphicon, btn-xs**

Replace:
```html
      <div class="panel panel-default">
        <div class="panel-heading clearfix">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>All Sales</span>
          </strong>
        </div>
        <div class="panel-body">
```
With:
```html
      <div class="card">
        <div class="card-header">
          <strong><?php echo bi('grid'); ?> All Sales</strong>
        </div>
        <div class="card-body p-0">
```

Replace:
```html
                     <a href="../sales/edit_sale.php?id=<?php echo (int)$sale['id'];?>" class="btn btn-warning btn-xs"  title="Edit" data-toggle="tooltip">
                       <span class="glyphicon glyphicon-edit"></span>
                     </a>
                     <a href="../sales/delete_sale.php?id=<?php echo (int)$sale['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-danger btn-xs"  title="Delete" data-toggle="tooltip">
                       <span class="glyphicon glyphicon-trash"></span>
                     </a>
```
With:
```html
                     <a href="../sales/edit_sale.php?id=<?php echo (int)$sale['id'];?>" class="btn btn-sm btn-warning" title="Edit" data-toggle="tooltip">
                       <?php echo bi('pencil'); ?>
                     </a>
                     <a href="../sales/delete_sale.php?id=<?php echo (int)$sale['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger" title="Delete" data-toggle="tooltip">
                       <?php echo bi('trash'); ?>
                     </a>
```

- [ ] **Step 2: Syntax check**

```bash
php -l sales/sales.php
```

- [ ] **Step 3: Commit**

```bash
git add sales/sales.php
git commit -m "style: sales.php BS3→BS5 — panel→card, glyphicons→bi(), btn-xs→btn-sm"
```

---

### Task 5: Migrate `sales/orders.php`

**Files:**
- Modify: `sales/orders.php`

- [ ] **Step 1: Apply panel→card, glyphicon, btn-xs, pull-right**

Replace:
```html
      <div class="panel panel-default">
        <div class="panel-heading clearfix">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>All Orders</span>
          </strong>
          <div class="pull-right">
            <a href="../sales/add_order.php" class="btn btn-primary">Add Order</a>
          </div>
        </div>
        <div class="panel-body">
```
With:
```html
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <strong><?php echo bi('grid'); ?> All Orders</strong>
          <a href="../sales/add_order.php" class="btn btn-primary">Add Order</a>
        </div>
        <div class="card-body p-0">
```

Replace:
```html
                        <a href="../sales/edit_order.php?id=<?php echo (int)$order['id'];?>"  class="btn btn-xs btn-warning" data-toggle="tooltip" title="Edit">
                          <span class="glyphicon glyphicon-edit"></span>
                        </a>
                        <a href="../customers/edit_customer.php?id=<?php echo (int)$customer['id'];?>"  class="btn btn-xs btn-info" data-toggle="tooltip" title="Customer Details">
                          <span class="glyphicon glyphicon-user"></span>
                        </a>
                        <a href="../sales/delete_order.php?id=<?php echo (int)$order['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Remove">
                          <span class="glyphicon glyphicon-trash"></span>
                        </a>
```
With:
```html
                        <a href="../sales/edit_order.php?id=<?php echo (int)$order['id'];?>" class="btn btn-sm btn-warning" data-toggle="tooltip" title="Edit">
                          <?php echo bi('pencil'); ?>
                        </a>
                        <a href="../customers/edit_customer.php?id=<?php echo (int)$customer['id'];?>" class="btn btn-sm btn-info" data-toggle="tooltip" title="Customer Details">
                          <?php echo bi('person'); ?>
                        </a>
                        <a href="../sales/delete_order.php?id=<?php echo (int)$order['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger" data-toggle="tooltip" title="Remove">
                          <?php echo bi('trash'); ?>
                        </a>
```

- [ ] **Step 2: Syntax check and commit**

```bash
php -l sales/orders.php
git add sales/orders.php
git commit -m "style: orders.php BS3→BS5 — panel→card, glyphicons→bi(), btn-xs→btn-sm"
```

---

### Task 6: Migrate `customers/customers.php`

**Files:**
- Modify: `customers/customers.php`

- [ ] **Step 1: Apply panel→card, glyphicon, btn-xs, pull-right**

Replace:
```html
      <div class="panel panel-default">
        <div class="panel-heading clearfix">
          <strong>
            <span class="glyphicon glyphicon-user"></span>
            <span>All Customers</span>
          </strong>
          <div class="pull-right">
            <a href="add_customer.php" class="btn btn-primary">Add Customer</a>
          </div>
        </div>
        <div class="panel-body">
```
With:
```html
      <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
          <strong><?php echo bi('person'); ?> All Customers</strong>
          <a href="add_customer.php" class="btn btn-primary">Add Customer</a>
        </div>
        <div class="card-body p-0">
```

Replace:
```html
                        <a href="../customers/edit_customer.php?id=<?php echo (int)$customer['id'];?>"  class="btn btn-xs btn-warning" data-toggle="tooltip" title="Edit">
                          <span class="glyphicon glyphicon-edit"></span>
                        </a>
                        <a href="../customers/delete_customer.php?id=<?php echo (int)$customer['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-xs btn-danger" data-toggle="tooltip" title="Remove">
                          <span class="glyphicon glyphicon-trash"></span>
                        </a>
```
With:
```html
                        <a href="../customers/edit_customer.php?id=<?php echo (int)$customer['id'];?>" class="btn btn-sm btn-warning" data-toggle="tooltip" title="Edit">
                          <?php echo bi('pencil'); ?>
                        </a>
                        <a href="../customers/delete_customer.php?id=<?php echo (int)$customer['id'];?>&<?php echo csrf_url_param(); ?>" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-sm btn-danger" data-toggle="tooltip" title="Remove">
                          <?php echo bi('trash'); ?>
                        </a>
```

- [ ] **Step 2: Syntax check and commit**

```bash
php -l customers/customers.php
git add customers/customers.php
git commit -m "style: customers.php BS3→BS5 — panel→card, glyphicons→bi(), btn-xs→btn-sm"
```

---

### Task 7: Migrate remaining content pages

**Files:**
- Modify: `products/categories.php`, `products/stock.php`, `products/view_product.php`, `users/users.php`

Apply the Global Substitution Reference to each file. All four follow the same panel→card + glyphicon→bi() + btn-xs→btn-sm pattern. No logic changes.

- [ ] **Step 1: `products/categories.php`**

The file has two panel blocks (add-category form panel + category list panel). Apply:
- `panel panel-default` → `card`
- `panel-heading` → `card-header`
- `panel-body` → `card-body`
- `glyphicon glyphicon-th` → `<?php echo bi('grid'); ?>`
- `btn btn-xs btn-warning` → `btn btn-sm btn-warning`
- `btn btn-xs btn-danger` → `btn btn-sm btn-danger`
- `glyphicon glyphicon-edit` → `<?php echo bi('pencil'); ?>`
- `glyphicon glyphicon-trash` → `<?php echo bi('trash'); ?>`
- `pull-right` → `float-end`

Then syntax check:
```bash
php -l products/categories.php
```

- [ ] **Step 2: `products/stock.php`**

Apply the same set of substitutions. Then:
```bash
php -l products/stock.php
```

- [ ] **Step 3: `products/view_product.php`**

Apply:
- `panel panel-default` → `card`
- `panel-heading clearfix` → `card-header d-flex justify-content-between align-items-center`
- `panel-body` → `card-body`
- `glyphicon glyphicon-th` → `<?php echo bi('grid'); ?>`
- `glyphicon glyphicon-th-large` → `<?php echo bi('plus-circle'); ?>`
- `glyphicon glyphicon-edit` → `<?php echo bi('pencil'); ?>`
- `glyphicon glyphicon-trash` → `<?php echo bi('trash'); ?>`
- `btn btn-xs btn-warning` → `btn btn-sm btn-warning`
- `btn btn-info btn-xs` → `btn btn-sm btn-info`
- `btn btn-danger btn-xs` → `btn btn-sm btn-danger`

Then:
```bash
php -l products/view_product.php
```

- [ ] **Step 4: `users/users.php`**

Check BS3 usage first:
```bash
grep -n "panel-default\|panel-heading\|panel-body\|btn-xs\|glyphicon\|pull-right" users/users.php | head -20
```

Apply all substitutions from the Global Reference. Then:
```bash
php -l users/users.php
```

- [ ] **Step 5: Commit all four files**

```bash
git add products/categories.php products/stock.php products/view_product.php users/users.php
git commit -m "style: categories/stock/view_product/users BS3→BS5 — panel→card, glyphicons→bi(), btn-xs→btn-sm"
```

---

### Task 8: Run full test suite and final commit

- [ ] **Step 1: Run all PHP suites**

```bash
bash tests/run.sh 2>&1 | tail -20
```

Expected: all PHP suites green.

- [ ] **Step 2: Run full Playwright suite**

```bash
cd /home/coreconduit/inventory && npx playwright test --reporter=line 2>&1
```

Expected: all specs pass, including the 5 new role-diff tests.

- [ ] **Step 3: Verify no stray glyphicons remain in migrated files**

```bash
grep -n "glyphicon" users/home.php products/products.php sales/sales.php sales/orders.php customers/customers.php products/categories.php products/stock.php products/view_product.php users/users.php
```

Expected: no output.

- [ ] **Step 4: Verify no stray btn-xs in migrated files**

```bash
grep -n "btn-xs" users/home.php products/products.php sales/sales.php sales/orders.php customers/customers.php products/categories.php products/stock.php products/view_product.php users/users.php
```

Expected: no output.
