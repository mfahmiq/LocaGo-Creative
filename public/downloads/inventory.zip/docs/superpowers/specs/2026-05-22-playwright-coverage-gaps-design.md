# Design: Playwright Coverage Gaps
**Date:** 2026-05-22
**Status:** Approved

---

## Context

The BS3→BS5 migration and PR #46 hardening work are complete. The Playwright suite
currently covers: login, nav shell, CSP compliance, core inventory CRUD, org
switcher (create/switch/delete), role access, and the sales golden path.

Two edge-case paths have no UI-level coverage:

1. **Org soft-delete / restore cycle** — the org-switcher dropdown correctly hides
   a soft-deleted org and should show it again after restore. This is untested.
2. **Zero-stock oversell redirect** — `add_sale_by_search.php` guards against
   selling more units than are in stock (line 34: `$product['quantity'] < $s_qty`)
   and redirects to `sales_by_order.php`. This redirect path is untested.

BS3 remnant scan completed — no remaining Bootstrap 3 artifacts found. The
`panel panel-box` classes in `users/admin.php` are custom CSS (`libs/css/main.css`)
and are not affected.

---

## Spec 1 — Zero-Stock Oversell Redirect

**File:** `tests/ui/sales.spec.js` (new `describe` block appended)

### Fixture

A new `describe('Sales zero-stock edge case')` block with its own `beforeAll` /
`afterAll` lifecycle — fully independent from the existing golden-path block.

- **`HARNESS_ZeroStock_<timestamp>`**: product with `quantity = 0`, seeded via the
  `add_product.php` UI form in `beforeAll`. Uses the existing `HARNESS_SalesCat`
  category (ensured via `ensureCategoryExists`).
- **`HARNESS_ZeroOrder_<timestamp>`**: order created via `add_order.php` in
  `beforeAll`, used as the target order for the sale attempt.
- `afterAll` cleans up both the order (via `orders.php`) and the product (via
  `products.php`).

### Test

**`oversell attempt redirects to order view`**

1. Navigate to `add_sale_by_search.php?id=<zeroOrderId>`.
2. Search for `HARNESS_ZeroStock_*` product by name.
3. Wait for the search result row to appear.
4. Fill `input[name="quantity"]` with `1`.
5. Click `button[name="add_sale"]`.
6. Assert redirect to `sales_by_order.php?id=<zeroOrderId>`.

**Server invariant tested:** `add_sale_by_search.php:34-36` — when
`(int)$product['quantity'] < $s_qty`, the request redirects without modifying
stock or creating a sale row.

---

## Spec 2 — Org Soft-Delete / Restore Cycle

**File:** `tests/ui/org-switcher.spec.js` (new `describe` block appended)

### Fixture

A new `describe('Org soft-delete and restore cycle')` block with its own
`beforeAll` / `afterAll`. Constant: `HARNESS_RestoreOrg = 'HARNESS_RestoreOrg'`.

`beforeAll`:
1. Use `admin.json` storageState.
2. Navigate to `/orgs/orgs.php`; if `HARNESS_RestoreOrg` row exists and has a
   delete button, hard-delete it (cleanup from a prior failed run).
3. Create `HARNESS_RestoreOrg` via the create form
   (`form:has(input[name="org_id"][value="0"])`).
4. Assert redirect to `edit_org.php` confirming creation.

`afterAll`:
1. Navigate to `/orgs/orgs.php`.
2. Find `HARNESS_RestoreOrg` row; if it has a `btn-danger` delete button, click it
   to hard-delete.
3. If only a restore button is present (soft-deleted), first restore then delete.

### Tests

**Test A — `soft-deleting org removes it from switcher`**

1. Navigate to `/orgs/orgs.php`.
2. Locate the `HARNESS_RestoreOrg` row; accept the confirm dialog; click the
   `delete_org.php` form's submit button.
3. Assert the page stays on `orgs.php`.
4. Assert the `HARNESS_RestoreOrg` row has `badge bg-danger` "Deleted" badge.
5. Navigate to `/users/home.php`; open the org-switcher dropdown
   (`li.dropdown > a.toggle`).
6. Assert `.org-switcher-btn:has-text("HARNESS_RestoreOrg")` is not visible.

**Test B — `restoring org brings it back to switcher`**

1. Navigate to `/orgs/orgs.php`.
2. Locate the `HARNESS_RestoreOrg` row (soft-deleted state); click the
   `restore_org.php` form's submit button.
3. Assert the `HARNESS_RestoreOrg` row now has `badge bg-success` "Active" badge.
4. Navigate to `/users/home.php`; open the org-switcher dropdown.
5. Assert `.org-switcher-btn:has-text("HARNESS_RestoreOrg")` is visible.

**System invariant tested:** `restore_org.php` clears `deleted_at`; the
org-switcher query filters on `deleted_at IS NULL`, so restored orgs reappear.

---

## Scope boundaries

- No new PHP is written — these are pure Playwright specs exercising existing
  server-side paths.
- No changes to `beforeAll` / `afterAll` in the *existing* describe blocks.
- HARNESS fixtures follow the `HARNESS_` prefix convention for test isolation.
- Both specs are idempotent: re-running after a failed run cleans up in `beforeAll`.

---

## Success criteria

- `npx playwright test sales.spec.js` passes including the new zero-stock test.
- `npx playwright test org-switcher.spec.js` passes including both new restore tests.
- Full suite (`npx playwright test`) remains green.
