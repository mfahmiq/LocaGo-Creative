# Baseline: pre-cc-merge

**Captured:** 2026-05-22 (commit e62214d)
**Tag:** pre-cc-merge
**Backup branch:** backup/pre-cc-merge

## tests/run.sh output

```
=========================================
 Inventory Management System — Test Suite
 Date: Fri 22 May 13:19:04 CDT 2026
=========================================

--- CSRF & Helpers (unit) ---
Test bootstrap loaded.
DB connection: SKIPPED (TESTS_NO_DB=1)
=== CSRFTest ===

       [token: d4266aec624f5f6b...]
  PASS: csrf_token() generates a hex token
  PASS: csrf_token() returns same token on second call
  PASS: csrf_field() returns hidden input HTML
  PASS: verify_csrf() passes with correct token
  PASS: verify_csrf() rejects wrong token
  PASS: verify_csrf() rejects missing token
  PASS: verify_csrf() returns true for GET requests
  PASS: h() escapes HTML special characters
  PASS: remove_junk() strips tags and escapes
  PASS: randString() produces correct length
  PASS: verify_csrf() rejects stale token after session cleared
  PASS: h() preserves UTF-8 and multibyte characters
  PASS: verify_get_csrf() passes with correct token in GET
  PASS: verify_get_csrf() rejects wrong token
  PASS: verify_get_csrf() rejects missing token
  PASS: csrf_url_param() returns csrf_token=<hex> string

---
Results: 16 passed, 0 failed

OK--- Authentication (integration) ---
PHP Warning:  Constant URL_SEPARATOR already defined in /home/coreconduit/inventory/includes/load.php on line 13
PHP Warning:  Constant DS already defined in /home/coreconduit/inventory/includes/load.php on line 14
PHP Warning:  Constant LIB_PATH_INC already defined in /home/coreconduit/inventory/includes/load.php on line 20
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 25
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 26
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 27
Test bootstrap loaded.
DB connection: OK
=== AuthTest ===

       [authenticated as admin, id=1]
  PASS: authenticate() as admin
       [authenticated as special, id=2]
  PASS: authenticate() as special user
       [authenticated as user, id=3]
  PASS: authenticate() as user
  PASS: authenticate() rejects wrong password
  PASS: authenticate() rejects non-existent user
  PASS: find_by_id() retrieves user
  PASS: find_by_name() returns null for unknown product
       [SHA1 hash upgraded to bcrypt for user HARNESS_sha1migrate_8aeae676]
  PASS: authenticate() rehashes legacy SHA1 password to bcrypt on login
       [session ID changed: 04d94dc4... → ac459736...]
  PASS: Session::login() regenerates session ID to prevent fixation

---
Results: 9 passed, 0 failed

--- CRUD Operations (integration) ---
PHP Warning:  Constant URL_SEPARATOR already defined in /home/coreconduit/inventory/includes/load.php on line 13
PHP Warning:  Constant DS already defined in /home/coreconduit/inventory/includes/load.php on line 14
PHP Warning:  Constant LIB_PATH_INC already defined in /home/coreconduit/inventory/includes/load.php on line 20
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 25
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 26
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 27
Test bootstrap loaded.
DB connection: OK
=== CRUDTest ===

       [25 products in database]
  PASS: join_product_table() returns products
       [created product id=132 name=HARNESS_TestProduct_6a109e1a63c24]
  PASS: Create product via INSERT
       [retrieved: HARNESS_TestProduct_6a109e1a63c24]
  PASS: find_by_id() retrieves created product
       [quantity: 100 -> 150]
  PASS: increase_product_qty() updates quantity
       [quantity: 150 -> 125]
  PASS: decrease_product_qty() updates quantity
       [product id=132 deleted]
  PASS: Delete product via delete_by_id
       [quantity column type: int(11) — OK]
  PASS: Quantity column has the expected type
       [0 sales in range]
  PASS: find_sale_by_dates() executes
  PASS: find_by_id() treats injection string as literal integer 0
  PASS: find_by_name() treats SQL injection payload as literal name
  PASS: delete_by_id() returns false for non-existent ID
  PASS: find_all_product_info_by_search() returns array without ArgumentCountError
  PASS: find_all_product_info_by_search() with empty string returns array

---
Results: 13 passed, 0 failed

--- Settings (integration) ---
PHP Warning:  Constant URL_SEPARATOR already defined in /home/coreconduit/inventory/includes/load.php on line 13
PHP Warning:  Constant DS already defined in /home/coreconduit/inventory/includes/load.php on line 14
PHP Warning:  Constant LIB_PATH_INC already defined in /home/coreconduit/inventory/includes/load.php on line 20
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 25
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 26
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 27
Test bootstrap loaded.
DB connection: OK
=== SettingsTest ===

       [AED ... ZWD, 91 total]
  PASS: supported_currency_codes() returns sorted list including USD
  PASS: Settings::get() returns default for unknown key
  PASS: Settings::set() persists and updates cache
       [EUR sample: &euro;1.234,56]
  PASS: currency_code round-trip changes formatcurrency() output
  PASS: formatcurrency() with unknown code falls back to USD
  PASS: Cleanup HARNESS rows

---
Results: 6 passed, 0 failed

--- Soft-Delete Pattern (integration) ---
PHP Warning:  Constant URL_SEPARATOR already defined in /home/coreconduit/inventory/includes/load.php on line 13
PHP Warning:  Constant DS already defined in /home/coreconduit/inventory/includes/load.php on line 14
PHP Warning:  Constant LIB_PATH_INC already defined in /home/coreconduit/inventory/includes/load.php on line 20
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 25
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 26
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 27
Test bootstrap loaded.
DB connection: OK
=== SoftDeleteTest ===

  PASS: table_has_soft_delete returns true for in-scope tables
  PASS: table_has_soft_delete returns false for out-of-scope tables
  PASS: table_has_soft_delete returns false for unknown table
  PASS: soft_delete_by_id stamps deleted_at and deleted_by
  PASS: restore_by_id clears both timestamp columns
  PASS: purge_by_id refuses to remove an active row
  PASS: purge_by_id removes a soft-deleted row permanently
  PASS: find_all excludes soft-deleted rows
  PASS: find_by_id returns null for a soft-deleted row
  PASS: find_with_deleted returns ALL rows including soft-deleted
  PASS: find_all_user excludes soft-deleted users
  PASS: find_all_sales excludes soft-deleted sales (row-local cascade test)
  PASS: authenticate() rejects a soft-deleted user

---
Results: 13 passed, 0 failed

--- Tenancy / Multi-Org (integration) ---
PHP Warning:  Constant URL_SEPARATOR already defined in /home/coreconduit/inventory/includes/load.php on line 13
PHP Warning:  Constant DS already defined in /home/coreconduit/inventory/includes/load.php on line 14
PHP Warning:  Constant LIB_PATH_INC already defined in /home/coreconduit/inventory/includes/load.php on line 20
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 25
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 26
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 27
Test bootstrap loaded.
DB connection: OK
  PASS: ORG_SCOPED_TABLES constant defined
  PASS: ORG_SCOPED_TABLES is array
  PASS: ORG_SCOPED_TABLES contains customers
  PASS: ORG_SCOPED_TABLES contains products
  PASS: ORG_SCOPED_TABLES contains categories
  PASS: ORG_SCOPED_TABLES contains sales
  PASS: ORG_SCOPED_TABLES contains orders
  PASS: ORG_SCOPED_TABLES contains stock
  PASS: ORG_SCOPED_TABLES contains media
  PASS: table_has_org_id() exists
  PASS: table_has_org_id(customers) returns true
  PASS: table_has_org_id(users) returns false
  PASS: table_has_org_id() caches results
  PASS: current_org_id() exists
  PASS: current_org_id() returns session value
  PASS: current_org_id() throws RuntimeException when session empty
  PASS: find_all(customers) returns only org 1 customers
  PASS: find_all(customers) returns only org 2 customers when session=org 2
  PASS: find_by_id(customers) returns null for cross-org record
  PASS: find_by_id(customers) returns record for same-org id
  PASS: find_all(products) respects org_id filtering
  PASS: find_by_id(products) respects org_id filtering
  PASS: resolve_login_org() exists
  PASS: resolve_login_org() returns org_id for member with last_active_org_id
  PASS: resolve_login_org() returns false for memberless user
  PASS: authenticate() returns array with user_id and org_id
  PASS: require_org_role() passes for member of current org
  PASS: require_org_role() throws for non-member of current org
  PASS: require_org_role("owner") passes for owner
  PASS: require_org_role("owner") throws for member
  PASS: find_org_members() returns all members of an org with correct fields
  PASS: Settings::get() returns org-specific value
  PASS: Settings::set() persists to the correct org
  PASS: switch_org updates session and persists last_active_org_id
  PASS: join_product_table() excludes cross-org products
  PASS: join_product_table() excludes soft-deleted products
  PASS: find_recent_product_added() excludes soft-deleted products

========================================
 Tenancy Tests Summary
 Passed: 37
 Failed: 0
========================================
OK: All tenancy tests passed.

--- Org Management (integration) ---
PHP Warning:  Constant URL_SEPARATOR already defined in /home/coreconduit/inventory/includes/load.php on line 13
PHP Warning:  Constant DS already defined in /home/coreconduit/inventory/includes/load.php on line 14
PHP Warning:  Constant LIB_PATH_INC already defined in /home/coreconduit/inventory/includes/load.php on line 20
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 25
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 26
PHP Warning:  ini_set(): Session ini settings cannot be changed when a session is active in /home/coreconduit/inventory/includes/load.php on line 27
Test bootstrap loaded.
DB connection: OK
=== OrgManagementTest ===

  PASS: find_all_orgs() returns array including seeded org
  PASS: find_org_memberships() returns empty for user with no memberships
  PASS: create_org() inserts org and enrolls creator as owner
  PASS: rename_org() updates name
  PASS: find_org_memberships() returns enrolled orgs for user
  PASS: soft-deleting org hides it from find_org_memberships()
  PASS: restoring org makes it appear in find_org_memberships() again
  PASS: inserting duplicate org_members row is blocked by PRIMARY KEY
  PASS: removing a member deletes org_members row
  PASS: owner count check: zero owners after delete returns false
  PASS: find_all_orgs() includes soft-deleted orgs

========================================
 Org Management Tests Summary
 Passed: 11
 Failed: 0
========================================
OK: All org management tests passed.

OK--- Security Headers (http) ---
=== SecurityHeadersTest ===
Base URL: http://localhost:8080

  PASS: CSP header on login page
  PASS: X-Frame-Options: DENY on login page
  PASS: X-Content-Type-Options: nosniff on login page
  PASS: Referrer-Policy on login page
  PASS: Permissions-Policy on login page
  PASS: CSP also emitted on protected path (302 to login)
  PASS: CSP does not allow unsafe-eval or unsafe-inline

---
Results: 7 passed, 0 failed

--- Playwright UI Tests ---

Running 43 tests using 1 worker

[setup] › tests/ui/auth.setup.js:18:1 › preflight: app server reachable
[setup] › tests/ui/auth.setup.js:27:1 › authenticate as admin and save admin storageState
[setup] › tests/ui/auth.setup.js:41:1 › seed HARNESS_ regular user and save user storageState
[chromium] › tests/ui/core-inventory.spec.js:82:3 › Core inventory: product create + stock add › new product appears in the products list
[chromium] › tests/ui/core-inventory.spec.js:87:3 › Core inventory: product create + stock add › add_stock increases product quantity
[chromium] › tests/ui/csp-compliance.spec.js:7:3 › CSP compliance and asset delivery › no inline style attributes on admin dashboard content
[chromium] › tests/ui/csp-compliance.spec.js:13:3 › CSP compliance and asset delivery › no glyphicon classes anywhere in DOM
[chromium] › tests/ui/csp-compliance.spec.js:19:3 › CSP compliance and asset delivery › bi.svg responds 200
[chromium] › tests/ui/csp-compliance.spec.js:24:3 › CSP compliance and asset delivery › bootstrap.min.css responds 200
[chromium] › tests/ui/csp-compliance.spec.js:29:3 › CSP compliance and asset delivery › Exo 2 font responds 200
[chromium] › tests/ui/csp-compliance.spec.js:34:3 › CSP compliance and asset delivery › Bootstrap Icon SVGs present in admin dashboard content
[chromium] › tests/ui/login.spec.js:7:3 › Login › valid admin credentials redirect to home
[chromium] › tests/ui/login.spec.js:16:3 › Login › wrong password stays on login with error
[chromium] › tests/ui/login.spec.js:25:3 › Login › unknown username stays on login with error
[chromium] › tests/ui/nav-shell.spec.js:7:3 › Navigation shell — admin › CC logo is present
[chromium] › tests/ui/nav-shell.spec.js:12:3 › Navigation shell — admin › brand name shows CoreInventory
[chromium] › tests/ui/nav-shell.spec.js:18:3 › Navigation shell — admin › sidebar has all six top-level entries
[chromium] › tests/ui/nav-shell.spec.js:29:3 › Navigation shell — admin › Organizations link visible under User Management
[chromium] › tests/ui/nav-shell.spec.js:35:3 › Navigation shell — admin › no glyphicon classes in sidebar
[chromium] › tests/ui/nav-shell.spec.js:41:3 › Navigation shell — admin › Bootstrap Icon SVG elements present in sidebar
[chromium] › tests/ui/nav-shell.spec.js:51:3 › Navigation shell — level-3 user › Products submenu has exactly 2 items [FAILED - timeout]
[chromium] › tests/ui/nav-shell.spec.js:60:3 › Navigation shell — level-3 user › Manage Stock is not in sidebar
[chromium] › tests/ui/nav-shell.spec.js:65:3 › Navigation shell — level-3 user › Media is not in sidebar
[chromium] › tests/ui/nav-shell.spec.js:70:3 › Navigation shell — level-3 user › Sales submenu has exactly 3 items [FAILED - timeout]
[chromium] › tests/ui/nav-shell.spec.js:79:3 › Navigation shell — level-3 user › Add Sale by SKU is not in sidebar
[chromium] › tests/ui/org-switcher.spec.js:51:3 › Org switcher › switcher dropdown appears with ≥2 orgs
[chromium] › tests/ui/org-switcher.spec.js:56:3 › Org switcher › current org has active checkmark in dropdown
[chromium] › tests/ui/org-switcher.spec.js:64:3 › Org switcher › switching to HARNESS_ org updates topbar
[chromium] › tests/ui/org-switcher.spec.js:73:3 › Org switcher › switching back to Default Organization updates topbar
[chromium] › tests/ui/org-switcher.spec.js:82:3 › Org switcher › deleting HARNESS_ org removes it from switcher
[chromium] › tests/ui/org-switcher.spec.js:161:3 › Org soft-delete and restore cycle › soft-deleting org removes it from switcher
[chromium] › tests/ui/org-switcher.spec.js:182:3 › Org soft-delete and restore cycle › restoring org brings it back to switcher
[chromium] › tests/ui/role-access.spec.js:9:3 › Role-gated access (regular user) › regular user is redirected away from /orgs/orgs.php
[chromium] › tests/ui/role-access.spec.js:15:3 › Role-gated access (regular user) › regular user does not see Organizations link in topbar
[chromium] › tests/ui/role-access.spec.js:23:3 › Home dashboard role-differentiation › admin sees Highest Selling Products panel
[chromium] › tests/ui/role-access.spec.js:31:3 › Home dashboard role-differentiation › admin sees Latest Sales panel
[chromium] › tests/ui/role-access.spec.js:39:3 › Home dashboard role-differentiation › regular user does NOT see Highest Selling Products panel
[chromium] › tests/ui/role-access.spec.js:47:3 › Home dashboard role-differentiation › regular user does NOT see Latest Sales panel
[chromium] › tests/ui/role-access.spec.js:55:3 › Home dashboard role-differentiation › regular user sees Recently Added Products panel
[chromium] › tests/ui/sales.spec.js:85:3 › Sales golden path › add sale to order via product search
[chromium] › tests/ui/sales.spec.js:101:3 › Sales golden path › order with sale appears in orders list
[chromium] › tests/ui/sales.spec.js:108:3 › Sales golden path › sold product stock is reduced
[chromium] › tests/ui/sales.spec.js:184:3 › Sales zero-stock edge case › oversell attempt redirects to order view
  2 failed
    [chromium] › tests/ui/nav-shell.spec.js:51:3 › Navigation shell — level-3 user › Products submenu has exactly 2 items 
    [chromium] › tests/ui/nav-shell.spec.js:70:3 › Navigation shell — level-3 user › Sales submenu has exactly 3 items 
  41 passed (1.7m)
  (Playwright tests failed — run: npx playwright test --headed)

=========================================
 Summary: 8/9 suites passed
=========================================
FAILED: 1 test suite(s)
```

## Counts

- PHP tests passed: 112 (16 CSRF + 9 Auth + 13 CRUD + 6 Settings + 13 Soft-Delete + 37 Tenancy + 11 Org Management + 7 Security Headers)
- Playwright specs passed: 41/43 (2 timeout failures in level-3 user navigation tests)
- Skipped suites: CSRF & Helpers DB check (TESTS_NO_DB=1)

Use this snapshot to detect regressions during Phase 1+ work.
