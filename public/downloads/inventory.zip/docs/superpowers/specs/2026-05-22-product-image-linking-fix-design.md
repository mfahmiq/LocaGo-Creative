# Product Image Linking Fix — Design Spec

**Status:** Approved (sections 1–5)
**Date:** 2026-05-22
**Branch:** `feature/product-image-linking-fix`
**Migration slot:** `020_media_global_and_fk`

## Problem

Product images are systemically disconnected from the database. Live evidence on `main`:

- `media` table holds exactly **1 row** (the seed `(id=1, org_id=1, file_name='no-image.png')`).
- All **26 products** in org 1 have `media_id = 0`.
- `uploads/products/` holds **5 files**: `no-image.png` (DB-seeded), `no_image.jpg` (hardcoded fallback in `products.php`), and three orphans (`nano.jpg`, `pi3.jpg`, `pothos.jpg`) with no DB row.
- **23 other tenants** have no `media` rows at all; their image-picker dropdown is empty.

Five compounding root causes (from systematic investigation):

1. `Media::insert_media()` is fire-and-forget — never returns the new row's id, so no caller can link the upload to a product in one step.
2. `add_product.php` / `edit_product.php` have **no file input** — only a "pick from library" dropdown. Users must visit `products/media.php` separately to upload.
3. `products.media_id` defaults to `0`, but `media.id` AUTO_INCREMENT starts at 1. `0` is a sentinel that matches no row — the LEFT JOIN always yields NULL.
4. No FK on `products.media_id`. Convention enforced by hope.
5. The no-image seed is per-org (org 1 only). `find_all('media')` is org-scoped, so other tenants see nothing.

## Goals

1. New products can be created with an image in a single form submission.
2. Editing a product without touching the image preserves the existing link.
3. `no-image.png` is available as a usable fallback in every org without per-org seeding.
4. The schema enforces `products.media_id` referential integrity via real FK.
5. Disk and DB are reconciled — no orphan files, no hardcoded fallback paths in PHP views.

## Non-goals

- Image-library UX overhaul (modal picker, thumbnails grid, search).
- Random/unique filename generation on upload (current "reject on collision" stays).
- Multi-image per product. One product → one image (current model).
- General migration of legacy raw-concat SQL in other handlers (`edit_stock.php`, etc.). Only the `add_product`/`edit_product` INSERT/UPDATE statements convert to prepared.

## Architecture

| Layer | Files |
|---|---|
| 1. Schema migration | `migrations/020_media_global_and_fk.{up,down}.sql` |
| 2. Data backfill | same migration (orphan disk files + global no-image row) |
| 3. Query helpers | `includes/sql.php` |
| 4. Upload flow | `includes/upload.php`, `products/add_product.php`, `products/edit_product.php` |
| 5. View consolidation | `products/products.php`, `products/view_product.php` |
| 6. Disk cleanup | `scripts/cleanup_legacy_no_image.sh` (one-shot, post-deploy) |

## Section 1: Schema Migration + Data Backfill

`migrations/020_media_global_and_fk.up.sql`:

```sql
-- 1. media.org_id becomes nullable so NULL = "global / all tenants"
ALTER TABLE `media`
  DROP FOREIGN KEY `fk_media_org`,
  MODIFY COLUMN `org_id` INT(11) UNSIGNED NULL DEFAULT NULL,
  ADD CONSTRAINT `fk_media_org`
    FOREIGN KEY (`org_id`) REFERENCES `orgs` (`id`) ON DELETE CASCADE;

-- 2. Replace legacy per-org seed with a single global no-image row
DELETE FROM `media` WHERE `id` = 1 AND `file_name` = 'no-image.png';
INSERT INTO `media` (`org_id`, `file_name`, `file_type`)
  VALUES (NULL, 'no-image.png', 'image/png');

-- 3. Backfill orphan disk files into media (predate tenancy → org 1)
INSERT INTO `media` (`org_id`, `file_name`, `file_type`) VALUES
  (1, 'nano.jpg',   'image/jpeg'),
  (1, 'pi3.jpg',    'image/jpeg'),
  (1, 'pothos.jpg', 'image/jpeg');

-- 4. products.media_id: 0-sentinel → NULL, then add real FK
UPDATE `products` SET `media_id` = NULL WHERE `media_id` = 0;
ALTER TABLE `products`
  MODIFY COLUMN `media_id` INT(11) UNSIGNED NULL DEFAULT NULL,
  ADD CONSTRAINT `fk_products_media`
    FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL;
```

`migrations/020_media_global_and_fk.down.sql`:

```sql
-- WARNING: lossy if non-org-1 tenants uploaded media post-020.
-- Their rows will be either coerced to org_id=1 or rejected by the new FK.
ALTER TABLE `products`
  DROP FOREIGN KEY `fk_products_media`,
  MODIFY COLUMN `media_id` INT(11) DEFAULT 0;
UPDATE `products` SET `media_id` = 0 WHERE `media_id` IS NULL;

DELETE FROM `media`
  WHERE `file_name` IN ('nano.jpg','pi3.jpg','pothos.jpg') AND `org_id` = 1;
DELETE FROM `media`
  WHERE `org_id` IS NULL AND `file_name` = 'no-image.png';

ALTER TABLE `media`
  DROP FOREIGN KEY `fk_media_org`,
  MODIFY COLUMN `org_id` INT(11) UNSIGNED NOT NULL DEFAULT 1,
  ADD CONSTRAINT `fk_media_org`
    FOREIGN KEY (`org_id`) REFERENCES `orgs` (`id`);

INSERT INTO `media` (`id`, `org_id`, `file_name`, `file_type`)
  VALUES (1, 1, 'no-image.png', 'image/png')
  ON DUPLICATE KEY UPDATE `file_name` = VALUES(`file_name`);
```

`scripts/cleanup_legacy_no_image.sh`:

```bash
#!/usr/bin/env bash
# Run once after migration 020. Removes the underscore-variant no-image file.
set -euo pipefail
target="uploads/products/no_image.jpg"
if [ -f "$target" ]; then
    rm -f -- "$target"
    echo "Removed $target"
else
    echo "Already absent: $target"
fi
```

**Notes:**
- The legacy seed row has `id=1`; after delete+insert it gets a new AUTO_INCREMENT id (likely 2 or higher). No product references the old row (`media_id=0` for all 26), so no orphan risk.
- The down migration is honestly lossy. The warning comment must be preserved.

## Section 2: Query Helper Changes

In `includes/sql.php`:

**Change 1: `find_all($table)` accepts global rows**

```php
if (table_has_org_id($table) && isset($_SESSION['current_org_id'])) {
    $where[]  = '(org_id = ? OR org_id IS NULL)';
    $params[] = current_org_id();
    $types   .= 'i';
}
```

**Change 2: `find_by_id($table, $id)` — same treatment** for symmetry.

**Change 3: Four join helpers use COALESCE**

In `join_product_table()` (`sql.php:900`) and the three search variants (`find_all_product_info_by_title/sku/search` at lines 957, 1005, 1112) and the sale-search join at 1223:

```php
$sql .= " AS category, COALESCE(m.file_name, 'no-image.png') AS image";
```

The `LEFT JOIN media m ON m.id = p.media_id` clause stays — when `media_id IS NULL` the join yields no row, and COALESCE substitutes `'no-image.png'`.

**Implication:** any future table with nullable `org_id` inherits "global row" semantics. Current scope (`media`) is the only such table; all others (`categories`, `customers`, `products`, etc.) keep `NOT NULL org_id`.

## Section 3: Upload Flow

### 3a. `Media::insert_media()` returns new row id

`includes/upload.php`:

```php
private function insert_media() {
    global $db;
    $stmt = $db->prepare_query(
        "INSERT INTO media (file_name, file_type, org_id) VALUES (?, ?, ?)",
        "ssi", $this->fileName, $this->fileType, current_org_id()
    );
    if ($stmt->affected_rows !== 1) {
        $stmt->close();
        return false;
    }
    $new_id = $db->insert_id();
    $stmt->close();
    return $new_id;
}
```

`process_media()` returns the new id (int) on success, `false` on failure. Callers that did `if ($photo->process_media())` continue to work (any positive int is truthy).

### 3b. Form changes (add_product.php + edit_product.php)

- Add `enctype="multipart/form-data"` to the `<form>`.
- Insert a file input above the existing dropdown:

```php
<div class="form-group">
  <div class="row">
    <div class="col-md-6">
      <label class="form-label">Upload new image</label>
      <input type="file" class="form-control" name="product-photo-upload"
             accept="image/png,image/jpeg,image/gif">
    </div>
    <div class="col-md-6">
      <label class="form-label">…or pick from library</label>
      <select class="form-control" name="product-photo">
        <option value=""> No image</option>
        <?php foreach ($all_photo as $photo): ?>
          <option value="<?= (int)$photo['id'] ?>"
            <?php if (isset($product) && (int)$product['media_id'] === (int)$photo['id']) echo 'selected'; ?>>
            <?= h($photo['file_name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
</div>
```

### 3c. Transactional handler (add_product.php)

```php
$db->query("START TRANSACTION");

try {
    // 1. Resolve media_id: upload | dropdown | NULL
    $media_id = null;
    $upload_present = !empty($_FILES['product-photo-upload']['name']);

    if ($upload_present) {
        $photo = new Media();
        if (!$photo->upload($_FILES['product-photo-upload'])) {
            throw new RuntimeException(implode(' ', $photo->errors));
        }
        $new_id = $photo->process_media();
        if ($new_id === false) {
            throw new RuntimeException(implode(' ', $photo->errors));
        }
        $media_id = $new_id;
    } elseif (!empty($_POST['product-photo'])) {
        $media_id = (int) $_POST['product-photo'];
    }

    // 2. INSERT product (prepared)
    $stmt = $db->connection()->prepare(
        "INSERT INTO products
          (name, description, sku, location, quantity, buy_price,
           sale_price, category_id, media_id, date, org_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    if (!$stmt) {
        throw new RuntimeException('Prepare failed: ' . $db->connection()->error);
    }
    $org_id = current_org_id();
    $stmt->bind_param(
        "ssssiddiisi",
        $p_name, $p_desc, $p_sku, $p_loc,
        $p_qty, $p_buy, $p_sale, $p_cat,
        $media_id, $date, $org_id
    );
    if (!$stmt->execute()) {
        $err = $stmt->error;
        $stmt->close();
        throw new RuntimeException('Product insert failed: ' . $err);
    }
    $product_id = $stmt->insert_id;
    $stmt->close();
    if ($product_id <= 0) {
        throw new RuntimeException('Failed to read new product id');
    }

    // 3. INSERT initial stock (prepared)
    $comments = "initial stock";
    $stmt = $db->connection()->prepare(
        "INSERT INTO stock (product_id, quantity, comments, date, org_id)
         VALUES (?, ?, ?, ?, ?)"
    );
    if (!$stmt) {
        throw new RuntimeException('Prepare failed: ' . $db->connection()->error);
    }
    $stmt->bind_param("iissi", $product_id, $p_qty, $comments, $date, $org_id);
    if (!$stmt->execute() || $stmt->affected_rows !== 1) {
        $err = $stmt->error;
        $stmt->close();
        throw new RuntimeException('Stock insert failed: ' . $err);
    }
    $stmt->close();

    $db->query("COMMIT");
    $session->msg('s', "Product Added");
    redirect('../products/products.php', false);

} catch (Throwable $e) {
    $db->query("ROLLBACK");
    if ($upload_present && isset($photo) && !empty($photo->fileName)
        && file_exists($photo->productPath . '/' . $photo->fileName)) {
        @unlink($photo->productPath . '/' . $photo->fileName);
    }
    error_log('add_product transaction failed: ' . $e->getMessage());
    $session->msg('d', 'Sorry, Failed to Add Product.');
    redirect('../products/add_product.php', false);
}
```

**Why inline prepare/execute (not `$db->prepare_query`):** `prepare_query` calls `die()` on failure, which bypasses ROLLBACK and disk cleanup. Inline is the only way to catch and compensate.

### 3d. edit_product.php handler

Mirrors add_product with one difference: if neither upload nor dropdown supplied a value, **preserve** the existing `media_id` (don't strip the image).

```php
$media_id = $existing_product['media_id'];   // start with current

if ($upload_present) {
    // …upload + replace…
    $media_id = $new_id;
} elseif (isset($_POST['product-photo'])) {
    $media_id = $_POST['product-photo'] === '' ? null : (int) $_POST['product-photo'];
}
```

The UPDATE always includes `media_id` in its SET clause; the variable carries either the new value or the existing one.

## Section 4: View Consolidation

`products/products.php:105-108`:

```php
// Before
<?php if ((int)$product['media_id'] === 0): ?>
  <img src="../uploads/products/no_image.jpg" alt="">
<?php else: ?>
  <img src="../uploads/products/<?php echo h($product['image']); ?>" alt="">
<?php endif; ?>

// After
<img src="../uploads/products/<?= h($product['image']) ?>" alt="">
```

`products/view_product.php:65-71`: drop the `foreach ($all_photo)` thumbnail-matching loop. Replace with a single direct render using `$product['image']` (already populated by the COALESCE'd join).

## Section 5: Testing Strategy

### 5a. PHP unit tests — `tests/MediaLinkTest.php`

| Test | Assertion |
|---|---|
| `test_insert_media_returns_new_id` | Returns positive int; row exists with that id |
| `test_insert_media_returns_false_on_db_failure` | Returns `false`; no leaked row |
| `test_find_all_media_includes_global_row` | From HARNESS org session, global `org_id IS NULL` row appears |
| `test_find_all_media_excludes_other_org_rows` | Org A session sees own rows + global, not org B's |
| `test_join_product_table_coalesces_null_media` | Product with `media_id IS NULL` → `image === 'no-image.png'` |
| `test_join_product_table_returns_real_filename` | Linked product → real filename in image column |
| `test_products_media_id_fk_set_null_on_delete` | Delete media row → linked product's media_id becomes NULL |

Fixtures: `tests/lib/media_fixtures.php` (new) with `setUp_media_fixtures()` / `tearDown_media_fixtures()`. HARNESS_-prefixed orgs.

Add `<file>tests/MediaLinkTest.php</file>` to `phpunit.xml` testsuite.

### 5b. PHP integration test — `tests/ProductUploadTest.php`

| Test | Assertion |
|---|---|
| `test_add_product_with_upload_links_atomically` | `$_FILES` fixture → POST handler → 1 product, 1 media, linked |
| `test_add_product_rolls_back_on_stock_insert_failure` | Force stock failure → no product, no media, no disk file |
| `test_edit_product_preserves_image_when_no_input` | media_id unchanged when neither field touched |
| `test_edit_product_clears_image_when_no_image_selected` | `product-photo=""` → media_id becomes NULL |

**Handler testability:** add a `TESTING` constant guard before each `redirect()` and `exit()` call in `add_product.php` / `edit_product.php`. Tests define `TESTING=true` in bootstrap and skip the redirect-and-exit, then inspect DB state directly.

Test image fixture: `tests/fixtures/test_product.png` (1x1 PNG, committed).

### 5c. Playwright e2e — `tests/ui/products.spec.js`

| Test | Flow |
|---|---|
| `add product with new image uploads and displays it` | Login → /add_product → fill + attach `tests/ui/fixtures/test_product.png` → submit → assert image src on list |
| `add product without image shows no-image fallback` | Login → add product, no upload, dropdown empty → assert list row `src` ends with `no-image.png` |
| `library dropdown contains no-image global row in any org` | Login to HARNESS_ org → /add_product → assert `<select>` contains `no-image.png` |

### 5d. Migration round-trip — shell check (in `tests/run.sh` or `scripts/`)

```bash
mysql inventory < migrations/020_media_global_and_fk.up.sql
mysql -N -e "SELECT COUNT(*) FROM media WHERE org_id IS NULL"  # expect 1
mysql -N -e "SELECT COUNT(*) FROM products WHERE media_id IS NULL"  # expect 26
mysql inventory < migrations/020_media_global_and_fk.down.sql
mysql -N -e "SELECT COUNT(*) FROM media WHERE org_id IS NULL"  # expect 0
mysql -N -e "SELECT id FROM media WHERE id = 1 AND file_name='no-image.png'"  # expect 1
```

### 5e. Manual smoke (Chrome DevTools MCP) — post-deploy

1. Log in as admin at `http://localhost:8080/`.
2. Products → Add Product → upload image → confirm list shows it.
3. Edit product → swap via dropdown → confirm change.
4. Edit again, leave fields untouched → confirm image preserved.
5. Topbar org-switch to HARNESS_ org → create no-image product → confirm `no-image.png` renders.

## Risks & Mitigations

| Risk | Mitigation |
|---|---|
| Down migration is lossy if other tenants upload post-deploy | Explicit warning comment in `.down.sql`; document in PR description |
| `mysqli::bind_param` with NULL value | Verified mysqli accepts `null` for any type letter — behavior is documented and stable |
| `TESTING` constant guard pollutes production code | Acceptable trade-off; alternative (handler function extraction) is larger refactor out of scope |
| Existing `process_media()` rejects on filename collision | Pre-existing behavior; users get an error message. Random-filename refactor noted as future work |
| Disk file `no_image.jpg` referenced from somewhere we missed | Grep before delete; cleanup script idempotent |

## Out-of-Scope Future Work

- Random/unique filenames on upload (currently `basename($file['name'])`).
- Multiple images per product.
- Image-library modal picker.
- `prepare_query_or_throw` variant to make all DML transaction-safe.
- General migration of legacy raw-concat SQL across other handlers.

## Acceptance Criteria

1. `migrations/020_*.up.sql` and `.down.sql` both run cleanly against a fresh DB.
2. `media` table contains exactly one row with `org_id IS NULL`, plus 3 backfilled disk-orphan rows in org 1.
3. All 26 existing products have `media_id IS NULL` after migration.
4. New products created via UI with file upload have a real `media_id` linking to a new media row.
5. New products created via UI without an image have `media_id IS NULL` and render `no-image.png` on the products list.
6. All 7 PHP unit + 4 integration + 3 Playwright tests pass.
7. Existing test suites (CSRFTest, InfraSmokeTest, current 32/32 Playwright) continue passing — no regressions.
8. `uploads/products/no_image.jpg` removed; products.php no longer references it.
