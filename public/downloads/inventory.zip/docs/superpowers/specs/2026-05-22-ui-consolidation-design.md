# UI/UX Consolidation — Design Spec
**Date:** 2026-05-22
**Approach:** A — Shell sync from cc-inventory
**Status:** Approved, pending implementation plan

---

## 1. Problem Statement

The inventory app's functionality is complete and security-hardened, but the navigation shell was never redesigned as features were added. Seven concrete gaps were identified in Phase 1 (blueprint verification):

| # | Gap | Severity |
|---|-----|----------|
| 1 | Organizations module not in sidebar — only reachable via dashboard quick-link | Medium |
| 2 | Level-3 user menu shows controls the user cannot access (403 on click) | Medium |
| 3 | 3 inline `style="font-size:2em"` in admin.php violate `style-src 'self'` CSP | High |
| 4 | Three nearly-identical menu files with 80% copy-paste — drift already occurred | Medium |
| 5 | Bootstrap 3 (EOL 2019), Glyphicons; project target stack specifies Bootstrap 5 | Medium |
| 6 | "My Inventory" hardcoded placeholder branding | Low |
| 7 | Dashboards not role-differentiated (both show same data tables) | Low |

---

## 2. Approach: Shell Sync from cc-inventory

Port the cc-inventory layout system into the inventory project. `~/cc-inventory` is the production-branded evolution of the same app; it has already solved the BS3→BS5 migration using a **BS3 compat shim** strategy: the layout shell uses proper BS5, while a set of backward-compat class aliases in `main.css` covers remaining BS3 utilities (`pull-left`, `panel-default`, `btn-xs`, etc.) in content pages.

This means content pages need **zero changes**. Only the layout shell, assets, and two PHP support files are touched.

---

## 3. Navigation Restructure

### 3.1 Admin Menu (`layouts/admin_menu.php`)

- Replace all `<i class="glyphicon glyphicon-*">` with `<?php echo bi('name'); ?>` SVG calls
- Reorder Products submenu: Categories → Manage Products → Product Search → Manage Stock → Media (Media last — it's maintenance, not daily use)
- Add **Organizations** link under User Management (below Trash):
  ```
  User Management
    Manage Groups
    Manage Users
    System Log
    Settings
    Trash
    Organizations   ← add
  ```

### 3.2 Supervisor Menu (`layouts/special_menu.php`)

- Replace glyphicons with `bi()` calls
- No structural changes — Supervisor access level is correct as-is

### 3.3 User Menu (`layouts/user_menu.php`)

Remove all controls the level-3 user cannot access:

**Products submenu** — keep only:
- Products (view list)
- Product Search

Remove: Media, Categories, Manage Products, Manage Stock

**Sales submenu** — keep only:
- Add Order
- Orders
- Sales

Remove: "Add Sale by SKU" (confusing without order context; requires an existing order)

### 3.4 Header (`layouts/header.php`)

- Replace `<div class="logo">My Inventory</div>` with CC logo treatment:
  ```html
  <a href="<?php echo APP_BASE_PATH; ?>/users/admin.php" class="cc-logo">
    <div class="logo-mark"><span class="cc-inner">CC</span></div>
    <span class="brand-name">Core<span class="highlight">Inventory</span></span>
  </a>
  ```
- Add mobile sidebar toggle button (`#sidebar-toggle`)
- Add skip-to-main accessibility link
- Update all asset `href`/`src` to use `APP_BASE_PATH` constant
- Update Bootstrap CSS/JS paths from `../libs/bootstrap/...` to `../libs/css/bootstrap.min.css` and `../libs/js/bootstrap.min.js`
- Add `libs/css/icons.css` link
- Remove org-switcher inline styles (already handled by `.org-switcher-btn` in main.css)

---

## 4. Asset Layer

All binary assets are copied from `~/cc-inventory/libs/` — no external downloads.

### 4.1 Replace

| From | To | Notes |
|------|-----|-------|
| `libs/bootstrap/css/bootstrap.min.css` | `libs/css/bootstrap.min.css` | BS5 |
| `libs/bootstrap/js/bootstrap.min.js` | `libs/js/bootstrap.min.js` | BS5 bundle |
| `libs/datepicker/bootstrap-datepicker.min.css` | `libs/css/bootstrap-datepicker3.min.css` | BS5-compatible |
| `libs/css/main.css` | `libs/css/main.css` | CC token system + BS3 compat shims |

### 4.2 Add

| File | Purpose |
|------|---------|
| `libs/css/icons.css` | Bootstrap Icons sizing/alignment defaults |
| `libs/icons/bi.svg` | Bootstrap Icons SVG sprite (~600 KB, self-hosted) |
| `libs/js/bootstrap-datepicker.min.js` | BS5-compatible datepicker JS |
| `libs/fonts/exo-2-latin-700-normal.woff2` | Exo 2 Bold (display/headings) |
| `libs/fonts/plus-jakarta-sans-latin-400-normal.woff2` | Plus Jakarta Sans Regular (body) |
| `libs/fonts/plus-jakarta-sans-latin-600-normal.woff2` | Plus Jakarta Sans SemiBold |
| `libs/fonts/ibm-plex-mono-latin-400-normal.woff2` | IBM Plex Mono (code) |

### 4.3 Remove

- `libs/bootstrap/` directory (entire BS3 bundle)
- `libs/datepicker/` directory (replaced by flat file above)

---

## 5. PHP Support Changes

### 5.1 `includes/config.php`

Add after `APP_SECRET` definition:
```php
define('APP_NAME',      getenv('APP_NAME')      ?: 'Inventory');
$app_base_path = getenv('APP_BASE_PATH') ?: '';
define('APP_BASE_PATH', $app_base_path);
```

### 5.2 `layouts/footer.php`

Update three JS paths to match new flat directory structure. jQuery is **retained** — `functions.js`, the datepicker, and AJAX autocomplete all depend on it.

```php
// Before
<script src="../libs/js/jquery.min.js"></script>
<script src="../libs/bootstrap/js/bootstrap.min.js"></script>
<script src="../libs/datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="../libs/js/functions.js"></script>

// After
<script src="<?php echo APP_BASE_PATH; ?>/libs/js/jquery.min.js"></script>
<script src="<?php echo APP_BASE_PATH; ?>/libs/js/bootstrap.min.js"></script>
<script src="<?php echo APP_BASE_PATH; ?>/libs/js/bootstrap-datepicker.min.js"></script>
<script src="<?php echo APP_BASE_PATH; ?>/libs/js/functions.js"></script>
```

Also add `libs/js/bootstrap-datepicker.min.js` to asset copy from cc-inventory.

### 5.3 Bootstrap 5 attribute migration in `layouts/header.php` + `libs/js/functions.js`

Bootstrap 5 renamed data attributes: `data-toggle` → `data-bs-toggle`, `data-dismiss` → `data-bs-dismiss`.

**header.php** — two dropdowns need updating:
```html
<!-- Before -->
<a href="#" data-toggle="dropdown" class="toggle">
<!-- After -->
<a href="#" data-bs-toggle="dropdown" class="toggle">
```

**libs/js/functions.js** — tooltip init uses BS3 selector. Replace with dual-selector compat shim that handles both attribute names so content pages need no changes:
```js
// Before (BS3)
$('[data-toggle="tooltip"]').tooltip();
// After (BS5 compat shim)
$('[data-toggle="tooltip"], [data-bs-toggle="tooltip"]').each(function () {
    new bootstrap.Tooltip(this);
});
```

### 5.4 `includes/functions.php`

Add `bi()` helper (copied from cc-inventory):
```php
function bi(string $name, string $extra = '', string $label = ''): string
{
    $name  = preg_replace('/[^a-z0-9-]/', '', $name);
    $cls   = trim('bi ' . $extra);
    $aria  = $label !== ''
        ? 'role="img" aria-label="' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '"'
        : 'aria-hidden="true"';
    $sprite = APP_BASE_PATH . '/libs/icons/bi.svg';
    return '<svg class="' . htmlspecialchars($cls, ENT_QUOTES, 'UTF-8') . '" ' . $aria . '>'
         . '<use href="' . htmlspecialchars($sprite, ENT_QUOTES, 'UTF-8') . '#' . $name . '"/></svg>';
}
```

---

## 6. Targeted Fixes

### 6.1 CSP Violation — `users/admin.php`

Three dashboard quick-link icons use `style="font-size:2em"` which is blocked by `style-src 'self'` CSP.

**Fix:** Add `.icon-2x` utility to `libs/css/main.css`:
```css
.icon-2x { font-size: 2em; }
```

Replace in `users/admin.php` (lines 107, 115, 123):
```php
// Before
<span class="glyphicon glyphicon-user" style="font-size:2em"></span>
// After
<?php echo bi('person', 'icon-2x'); ?>
```

### 6.2 Icon Name Mapping

Glyphicon → Bootstrap Icon equivalents used in menu and dashboard files:

| Glyphicon | BI name |
|-----------|---------|
| `glyphicon-home` | `house` |
| `glyphicon-shopping-cart` | `cart3` |
| `glyphicon-user` | `person` |
| `glyphicon-piggy-bank` | `piggy-bank` |
| `glyphicon-signal` | `bar-chart-line` |
| `glyphicon-cog` | `gear` |
| `glyphicon-th` | `grid` |
| `glyphicon-th-list` | `list-ul` |
| `glyphicon-edit` | `pencil` |
| `glyphicon-trash` | `trash` |
| `glyphicon-plus` | `plus-lg` |
| `glyphicon-refresh` | `arrow-clockwise` |
| `glyphicon-ok` | `check-lg` |
| `glyphicon-off` | `power` |

---

## 7. Playwright Test Additions

Two new spec files validate the UI changes. Existing specs (login, org-switcher, core-inventory) are validated against new HTML before shipping.

### 7.1 `tests/ui/nav-shell.spec.js`

```
admin role:
  - sidebar is visible after login
  - CC logo element present (.cc-logo)
  - 5 top-level menu sections present: Products, Customers, Sales, Reports, User Management
  - Organizations link visible under User Management
  - no glyphicon class anywhere in sidebar DOM

level-3 user role:
  - Products submenu has exactly 2 items
  - "Manage Stock" link not present in sidebar
  - "Media" link not present in sidebar
  - Sales submenu has exactly 3 items
  - "Add Sale by SKU" link not present in sidebar
```

### 7.2 `tests/ui/csp-compliance.spec.js`

```
admin dashboard:
  - no element with inline style attribute on #main content
  - no element with class containing "glyphicon" anywhere in DOM
  - GET /libs/icons/bi.svg returns 200
  - GET /libs/css/bootstrap.min.css returns 200
  - GET /libs/fonts/exo-2-latin-700-normal.woff2 returns 200
```

---

## 8. Files Changed

| File | Action |
|------|--------|
| `libs/bootstrap/` | Remove |
| `libs/bootstrap/` | Remove (replaced by flat libs/css/ + libs/js/) |
| `libs/datepicker/` | Remove (replaced by flat libs/js/) |
| `libs/css/bootstrap.min.css` | Add (BS5) |
| `libs/css/bootstrap-datepicker3.min.css` | Add |
| `libs/css/main.css` | Replace |
| `libs/css/icons.css` | Add |
| `libs/js/bootstrap.min.js` | Add (BS5) |
| `libs/icons/bi.svg` | Add |
| `libs/js/bootstrap-datepicker.min.js` | Add (flat structure) |
| `libs/fonts/*.woff2` (6 files) | Add |
| `includes/config.php` | Update (APP_BASE_PATH, APP_NAME) |
| `includes/functions.php` | Update (add bi()) |
| `layouts/header.php` | Update (CC logo, data-bs-toggle, APP_BASE_PATH paths) |
| `layouts/footer.php` | Update (APP_BASE_PATH JS paths) |
| `layouts/admin_menu.php` | Update (bi() icons, Orgs link) |
| `layouts/special_menu.php` | Update (bi() icons) |
| `layouts/user_menu.php` | Update (bi() icons, trimmed items) |
| `libs/js/functions.js` | Update (BS5 tooltip compat shim) |
| `users/admin.php` | Update (CSP fix: inline styles → bi() + icon-2x) |
| `tests/ui/nav-shell.spec.js` | Add |
| `tests/ui/csp-compliance.spec.js` | Add |

**Content pages: zero changes required** — BS3 compat shims in main.css cover all remaining legacy class names.

---

## 9. Out of Scope

- Purchasing module, Data Tools, Log Monitor (exist in cc-inventory, not in inventory)
- Content page BS5 migration (panel→card, label→badge, etc.)
- Dashboard role-differentiation beyond CSP fix (low priority)
- Tenancy / org_id filtering in queries (separate track)
- Soft-delete for products/categories (separate track)
