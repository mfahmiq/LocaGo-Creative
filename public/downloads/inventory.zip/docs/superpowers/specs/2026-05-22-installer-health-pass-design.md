# Installer Health Pass — Design Spec
**Date:** 2026-05-22
**Status:** Approved

## Problem

Three issues surfaced from the production error log on 2026-05-22:

1. `/var/lib/php/sessions` owned by `root:root` — Apache's `www-data` process
   gets `Permission denied (13)` on `session_start()`. Sessions never persist;
   CSRF tokens and flash messages evaporate between requests. Login appears to
   do nothing.
2. The vhost template in `install.sh` carries a stale "Bootstrap 3 Glyphicons"
   comment (project migrated to Bootstrap 5 + Bootstrap Icons in PR #45/#46).
3. `find_all_product_info_by_search()` in `sql.php` has a prepared-statement
   arity mismatch (`ArgumentCountError` at `database.php:109`).

`install.sh` has no recovery path for post-install permission drift and no
smoke test to catch these failures before the operator walks away.

---

## Scope

| Change | File(s) |
|--------|---------|
| Fix session dir permissions in Step 6 | `install.sh` |
| Add `--fix-perms` flag | `install.sh` |
| Post-install smoke test | `install.sh` |
| Remove stale vhost comment | `install.sh` |
| Fix SQL arity bug | `includes/sql.php` |

---

## Design

### 1. Session Directory Permissions (Step 6)

Append to the existing Step 6 block, after `uploads/` handling.

**Logic:**
```
SESSION_PATH=$(php -r "echo session_save_path() ?: '/var/lib/php/sessions';")

if [ -d "$SESSION_PATH" ]; then
    if sudo chown -R "${APACHE_USER}:${APACHE_USER}" "$SESSION_PATH" 2>/dev/null; then
        echo "  Session dir ownership set: $SESSION_PATH → $APACHE_USER"
    else
        echo -e "${YELLOW}  Warning: Could not chown $SESSION_PATH — run manually:${NC}"
        echo "    sudo chown -R ${APACHE_USER}:${APACHE_USER} $SESSION_PATH"
    fi
else
    echo -e "${YELLOW}  Warning: Session path '$SESSION_PATH' not found — skipping.${NC}"
fi
```

Step counter stays `[6/7]`.

### 2. `--fix-perms` Flag

New argument parsed alongside `--reinstall` in the `case` block.
Mutually exclusive with `--reinstall` (print error and exit 1 if both passed).

**Behavior when `--fix-perms` is set:**
1. Detect `APACHE_USER` (same `apache2ctl -S` logic as Step 6).
2. Fix `uploads/` — `chmod -R 775` + `chown -R`.
3. Fix session dir — same logic as Section 1 above.
4. Run smoke test (Section 3).
5. Exit. Skip all 7 install steps entirely.

Output header:
```
=========================================
 Inventory — Fix Permissions
=========================================
```

### 3. Post-Install Smoke Test

Runs as a new block after the summary, both on full install and on `--fix-perms`.

**Check 1 — DB connectivity:**
```bash
php -r "
  \$env = parse_ini_file('$PROJECT_ROOT/.env');
  \$c = new mysqli(\$env['DB_HOST'], \$env['DB_USER'], \$env['DB_PASS'], \$env['DB_NAME']);
  exit(\$c->connect_error ? 1 : 0);
" && echo "OK" || echo "FAIL"
```

**Check 2 — HTTP reachability:**
```bash
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" \
  --max-time 5 "http://localhost:${VHOST_PORT}/" 2>/dev/null || echo "000")
```
Expected: `302`. Anything else → `WARN: got $HTTP_CODE`.

**Output format:**
```
[smoke] DB connection ............. OK
[smoke] HTTP :8080 (expect 302) ... OK
```

Failures are warnings only — the install already succeeded. Each failure prints
the manual remediation command so the operator knows exactly what to do.

**Guard:** if `curl` is not installed, skip Check 2 with a yellow note.

### 4. Stale Vhost Comment

In the heredoc vhost template, replace:
```
    # Font MIME types for Bootstrap 3 Glyphicons
```
with:
```
    # Font MIME types (Bootstrap Icons / Bootstrap 5)
```
The MIME type entries themselves are unchanged.

### 5. SQL Arity Fix — `find_all_product_info_by_search()`

**Location:** `includes/sql.php` ~line 1131 (called from `sales/add_sale_by_search.php:127`).

**Root cause:** The prepared statement has N `?` placeholders but the `bind_param`
type string and argument list have a different count.

**Fix:** Read the function, count placeholders in the SQL string, verify the
`prepare_select` call passes exactly that many bound values. Correct the
mismatch. No schema change required.

---

## Testing

- Full install on a clean DB: all 7 steps pass, smoke test shows 2× OK.
- `bash install.sh --fix-perms`: permissions corrected, smoke test runs, exits 0.
- `bash install.sh --reinstall --fix-perms`: prints error and exits 1.
- Manual test: break session dir permissions (`sudo chown root /var/lib/php/sessions`),
  run `--fix-perms`, verify login works again.
- `add_sale_by_search.php`: load the search page with a valid org/product,
  confirm no `ArgumentCountError` in `inventory_error.log`.

---

## Commit Plan

Two commits:
1. `fix(install): session dir perms, --fix-perms flag, smoke test, vhost comment`
2. `fix(sql): correct bind_param arity in find_all_product_info_by_search`
