# Branch Cleanup & Documentation Update — Design Spec
**Date:** 2026-05-23
**Status:** Approved

## Goal

Prune all stale branches (local + remote) from the repository and update the three primary docs (`architecture.md`, `tech-stack.md`, `setup-and-usage.md`) to reflect the current state of the application after PRs #31–50.

---

## Phase 1 — Branch Cleanup

### Local branches to safe-delete (`git branch -d`)

These are fully merged into main via normal merge commits:

| Branch | Merged via |
|--------|-----------|
| `backup/pre-cc-merge` | PR #48 / backup ref |
| `chore/sync-local-main` | PR #48 |
| `feature/bs5-migration-and-hardening` | PR #46 |
| `feature/product-image-linking-fix` | PR #50 |
| `feature/security-hardening-2026-05` | PR #50 |

### Local branches to force-delete (`git branch -D`)

PRs are merged but squash-merge created new commits, so `--merged` doesn't see them:

| Branch | Merged via |
|--------|-----------|
| `feature/phase1-dev-infrastructure` | PR #47 (squash) |
| `feature/phase2-ops-drop-ins` | PR #49 (squash) |

### Local cc-archive branches to force-delete (`git branch -D`)

From the cancelled cc-inventory merge project, never pushed to origin:

- `cc-archive/feature/bs5-phase1-icons`
- `cc-archive/feature/wcag-2.2-remediation`
- `cc-archive/main`
- `cc-archive/theme/coreconduit-brand-v2.1-silver`

### Remote branches to delete on origin

All remote branches whose PRs are merged or closed (leaving only `origin/main`):

`alert-autofix-1`, `alert-autofix-2`, `alert-autofix-3`,
`backup/pre-cc-merge`, `chore/precommit-csrf-form-guard`, `chore/sync-local-main`,
`feature/bs5-migration-and-hardening`, `feature/csp-style-src-tighten`,
`feature/csrf-form-action-quote-fix`, `feature/phase1-dev-infrastructure`,
`feature/phase2-ops-drop-ins`, `feature/playwright-ci`,
`feature/precommit-php-lint-hook`, `feature/product-image-linking-fix`,
`feature/security-hardening-2026-05`, `feature/settings-table-currency`,
`feature/tenancy-schema`, `feature/tenancy-shim-removal`, `feature/tenancy-ux`,
`fix/edit-category-action-target`, `fix/hoist-constants-before-load`,
`fix/tenancy-post-smoke`

---

## Phase 2 — Documentation Updates

### `docs/architecture.md`

Add missing directory entries introduced since the last update:

- `migrations/` — numbered SQL migration files (`001_`…`020_`)
- `ops/` — operational drop-in scripts: `health.php`, `backup.php`, `log_rotate.php`
- `vendor/` — Composer autoloader + PHPUnit dev dependencies (gitignored)
- `users/organizations.php` and `users/organization_edit.php` — org management UI
- Update schema table count: 10 tables (added `settings`, `media`, `organizations`)
- Note that `Media` class in `includes/upload.php` handles product image linking with FK to `media` table

### `docs/tech-stack.md`

- Add Bootstrap Icons row to Frontend table (`libs/bootstrap-icons/`)
- Add **Dev Tooling** section: Composer, PHPUnit 10.x, PHPStan (static analysis)
- Update Security Features table: add soft-delete row, add multi-tenant org isolation row

### `docs/setup-and-usage.md`

- Add **Running Tests** section after Installation:
  ```bash
  composer install          # install PHPUnit (dev only)
  vendor/bin/phpunit        # run all suites (~10 PHP suites)
  ```
- Note that tests require a live DB connection via `.env`

---

## Out of Scope

- `docs/gap-analysis.md` — separate concern
- `docs/api-components.md` — separate concern
- `docs/README.md` — no changes needed
- No new features, refactors, or spec files beyond this cleanup

---

## Success Criteria

1. `git branch -a` shows only `main` (local and remote)
2. All three doc files reflect current repo state
3. One commit on `main` with the doc updates
