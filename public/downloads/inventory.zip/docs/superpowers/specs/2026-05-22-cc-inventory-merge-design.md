# cc-inventory → inventory Merge Design

**Date:** 2026-05-22
**Author:** Cory (CoreConduit) + Claude
**Status:** Draft, awaiting user review

## Summary

Port all unique features from `~/cc-inventory` (origin `bitsandbots/cc-inventory.git`)
into `~/inventory` (origin `bitsandbots/inventory.git`), then archive `cc-inventory`.
`~/inventory` remains the canonical CoreConduit Inventory repo. The work lands as
8 dependency-ordered PRs against `inventory` main.

## Why

The two repos are sibling forks of `b2909ff "Initial commit: Inventory Management
System v5"`. They have diverged:

- `cc-inventory` accumulated **breadth**: `purchasing/`, `suppliers/`, `data_tools/`,
  richer `reports/`, composer/vendor + PHPUnit, packaging install scripts,
  Bootstrap Icons sprite system, CC silver theme, WCAG 2.2 a11y work,
  cron hardening (`alerts_check.php`, `log_rotate.php`, `log_monitor_scan.php`),
  ops endpoints (`health.php`, `backup.php`), and a (reverted) accounting Phase 1.
- `inventory` went **deep**: `orgs/` multi-tenancy (PRs #34–#42), `language/es/` i18n,
  Playwright e2e suite (32 specs), versioned `migrations/`, settings/currency,
  and a completed BS3→BS5 migration (PRs #45/#46).

Maintaining two forks is unsustainable. Consolidating onto `inventory` preserves
the deeper architectural investments (tenancy, i18n, e2e) while bringing across
the breadth.

## Target state

```
~/inventory/                                ← canonical, push to bitsandbots/inventory
├── orgs/                                   KEEP (tenancy)
├── language/es/                            KEEP (i18n)
├── migrations/                             KEEP (schema source-of-truth)
├── tests/ + tests/playwright/              KEEP (run via vendor/bin/phpunit + playwright)
├── customers/ products/ sales/ users/ reports/   EXISTS, BS5
│
├── suppliers/                              NEW (BS5 + tenancy + i18n on port)
├── purchasing/                             NEW (BS5 + tenancy + i18n on port)
├── data_tools/                             NEW (BS5 + tenancy + admin-gated)
│
├── alerts_check.php                        NEW (cron, org-scoped)
├── log_rotate.php                          NEW (cron)
├── log_monitor_scan.php                    NEW (cron, org-scoped)
├── health.php                              NEW (ops probe)
├── backup.php                              NEW (admin-only)
│
├── composer.json + composer.lock           NEW (vendor/ gitignored)
├── phpunit.xml                             NEW (replaces tests/run.sh body)
├── packaging/install.sh                    NEW (rebuilds via migrations/*.sql)
└── libs/css/cc-brand-silver.css            NEW (CC Brand v2.1 tokens)
```

`bitsandbots/cc-inventory` GitHub repo: **archived (read-only)**.
Local `~/cc-inventory`: tarballed to `~/archives/cc-inventory-YYYYMMDD.tar.gz`.

## Architectural reconciliations

Three explicit calls that override cc-inventory's choices:

1. **Schema source-of-truth:** `migrations/NNN_*.sql` from `inventory`.
   `packaging/install.sh` is rewritten to apply `migrations/*.sql` in order.
   `cc-inventory/packaging/sql/migrate.sh` and `schema.sql` are discarded.
2. **Test runner:** `vendor/bin/phpunit` driven by `phpunit.xml`.
   Existing `tests/run.sh` becomes a thin wrapper invoking phpunit.
3. **Markup baseline:** Bootstrap 5 (inventory's).
   Every page ported from cc-inventory is BS5-migrated in the same PR that lands it.
   No two-step "port-then-migrate".

## Phased plan (8 PRs)

### Phase 0 — Pre-flight (no PR)

- Tag current `main` as `pre-cc-merge`.
- Push branch `backup/pre-cc-merge` to remote.
- Add cc-inventory as fetch-only remote: `git remote add cc-archive ~/cc-inventory && git fetch cc-archive`.
- Record baseline: `vendor/bin/phpunit` (after Phase 1) and `npx playwright test`
  green; snapshot to `docs/superpowers/specs/baselines/pre-cc-merge.md`.

### Phase 1 — Dev infrastructure (PR1, ~600 LOC)

- Bring in `composer.json`, `composer.lock`. Add `vendor/` to `.gitignore`.
- Run `composer install` to materialize vendor/.
- Add `phpunit.xml` targeting `tests/`.
- Ensure inventory's existing tests (`OrgManagementTest`, `TenancyTest`, `AuthTest`,
  `CSRFTest`, `CRUDTest`, `SoftDeleteTest`, `SecurityHeadersTest`, `SettingsTest`)
  all run under `vendor/bin/phpunit`.
- Rewrite `tests/run.sh` to call `vendor/bin/phpunit` (preserves muscle memory).
- Update `.githooks/` to invoke phpunit.
- **Acceptance:** 9/9 PHP tests + 32/32 Playwright tests green.

### Phase 2 — Ops drop-ins (PR2, ~400 LOC)

- Port `health.php` (no tenancy needs — health probe).
- Port `backup.php` (admin-only via named role constant).
- Port `log_rotate.php` cron (no tenancy needs).
- Wire systemd timers (`scripts/inventory.service`).
- **Acceptance:** `php health.php` returns expected JSON; backup writes to `backups/`;
  admin role required to invoke backup endpoint.

### Phase 3 — Org-aware crons (PR3, ~500 LOC)

- Port `alerts_check.php` and extend to iterate per-org for low-stock alerts.
- Port `log_monitor_scan.php` and scope output per org.
- Migration: add `org_id` + FK to any new alerts/log tables.
- Add TenancyTest cases for cron output isolation.
- **Acceptance:** Tenant A's alerts only reference tenant A's products.

### Phase 4 — Brand + a11y (PR4, ~300 LOC)

- Extract CC Brand v2.1 Silver tokens from `cc-brand-silver.html` into `libs/css/cc-brand-silver.css`.
- Apply navy/silver/blue/orange palette + Exo 2/Plus Jakarta/IBM Plex Mono fonts
  to `layouts/header.php` and `layouts/footer.php`.
- Cherry-pick cc-inventory's a11y commits from main: `f5b4e6b` (rem font-sizes)
  and `9490ff9` (cron+a11y screen-reader context for media uploads).
- **Acceptance:** `csp-compliance.spec.js` still passes; visual diff reviewed
  on local Apache vhost.

### Phase 5 — `suppliers/` module (PR5, ~800 LOC)

- Port `suppliers/{index,add,edit,delete,view}.php`.
- Migration: add `suppliers.org_id BIGINT NOT NULL`, FK + index, soft-delete columns
  (`deleted_at`, `deleted_by`).
- Migrate markup to BS5 in the same PR (panel→card, glyphicon→bi(), etc.).
- Wire into `layouts/admin_menu.php`; add `language/es/suppliers.php`.
- Add `tests/SuppliersTest.php` covering CRUD + tenancy isolation
  (two-org seed, assert isolation in every query path).
- Add `tests/playwright/suppliers.spec.js` (golden-path mirroring `sales.spec.js`).
- **Acceptance:** Tenant A cannot see tenant B's suppliers via UI or API.

### Phase 6 — `purchasing/` module (PR6, ~1000 LOC, depends on Phase 5)

- Same template as Phase 5: port → BS5 → org-scope → i18n → PHPUnit + Playwright.
- FK `purchase_orders.supplier_id` → `suppliers.id`, both in the same org.
- DB-level guard: cross-org PO references rejected.
- **Acceptance:** Cross-org PO creation rejected at DB level (CHECK constraint or trigger).

### Phase 7 — `data_tools/` module (PR7, ~600 LOC)

- Port import/export tools.
- Hard-gate behind super-admin role (no tenant should export another tenant's data).
- BS5 + i18n + tests.
- **Acceptance:** `data_tools/` refuses to run for non-super-admin sessions;
  PHPUnit covers RBAC paths.

### Phase 8 — Cleanup & archive (PR8, ~200 LOC)

- Update `README.md`, `CLAUDE.md`, `docs/Blueprint_Overview.html` for new modules.
- Update memory `MEMORY.md` with checkpoint entry.
- Push final `main` to `bitsandbots/inventory`.
- Tarball `~/cc-inventory` to `~/archives/cc-inventory-YYYYMMDD.tar.gz`.
- Archive `bitsandbots/cc-inventory` repo on GitHub (Settings → Archive).

**Estimated total:** 8 PRs, ~4400 LOC, 2–3 weeks focused work.

## Risks & mitigations

| Risk | Likelihood | Mitigation |
|---|---|---|
| `vendor/` inflates repo size if committed | High | `vendor/` in `.gitignore`. Only `composer.json` + `composer.lock` are versioned. |
| BS3 markup leaks back via ported pages | High | Existing BS3→BS5 lint (added in PR #45/#46) runs in CI; merge blocked on `panel-`/`glyphicon-`/`pull-*` regex matches. |
| Tenancy extension misses a query, leaking cross-org data | Medium | Every new module ships a TenancyTest case that seeds two orgs and asserts isolation in every read path. |
| `packaging/sql/migrate.sh` vs `migrations/` model | Medium | Decided: `migrations/` wins. `packaging/install.sh` rewritten to apply `migrations/*.sql` in order. |
| i18n drift in new modules | Low | Each new module's PR includes `language/es/<module>.php`. CI grep: no untranslated string literal in PHP under new module dirs. |
| PHPUnit version conflicts with PHP 8.x | Low | Pin PHPUnit ≤10 in `composer.json` (PHP 8.1 compatible); document required PHP in `README.md`. |
| Accounting Phase 1 was reverted in cc-inventory | High if revisited | **Out of scope** for this initiative. Reviving accounting requires its own spec. |
| cc-inventory feature branches contain in-flight work we shouldn't take | Medium | Only port from cc-inventory **main**, not feature branches. |

## Testing strategy

**Per-PR CI gates (all must pass):**
- `vendor/bin/phpunit`
- `npx playwright test`
- BS3 regex lint (no `panel-`, `glyphicon-`, `pull-*` outside `vendor/` or `libs/`)
- CSP nonce check (no inline styles in new code)

**Per-phase smoke (manual):**
- `php health.php` returns 200 + JSON.
- Login as 2 orgs via topbar switcher; verify isolation of new module.

**Per-new-module (Phases 5–7):**
- `tests/<Module>Test.php` — CRUD + tenancy isolation.
- `tests/playwright/<module>.spec.js` — golden path mirroring `sales.spec.js`.

**Pre-Phase-8 merge:**
- Visual review on local Apache vhost (`:8080`) with `es` and `en` locales.

## Out of scope (do NOT port)

- Reverted accounting Phase 1 (`cc-inventory#12`/`#15`). Separate spec required to revive.
- HTMX dependency (cc-inventory removed it; inventory never had it).
- `cc-inventory/feature/wcag-2.2-remediation` *branch* — only what's on cc-inventory `main`.
- `cc-brand-silver.html` raw marketing file — we extract the CSS only.
- `cc-inventory/feature/bs5-phase1-icons` *branch* — superseded by inventory's completed BS5.
- `cc-inventory/inventory-release/` and `releases/` artifacts — these are build outputs.
- `cc-inventory/nexus-packaging/` — belongs to a different project.
- `cc-inventory/data/` and `cc-inventory/demo_data.sql` if they conflict with inventory's `scripts/demo_seed.php`.

## Definition of done

1. All 8 PRs merged to `bitsandbots/inventory` main.
2. `vendor/bin/phpunit` green: existing + new PHPUnit tests pass.
3. `npx playwright test` green: existing 32 specs + 3 new module specs.
4. Two-org isolation manually verified for suppliers, purchasing, data_tools.
5. `bitsandbots/cc-inventory` archived on GitHub. Local tarball at `~/archives/`.
6. `CLAUDE.md`, `README.md`, `MEMORY.md` updated; this spec referenced from `MEMORY.md`.

## Open questions to resolve before Phase 1 starts

1. **PHPUnit version pin** — default to 10.x; confirm PHP version in use is 8.1+
   on production Pi target.
2. **Cron scheduling** — systemd timers vs `cron.d` entries. Recommend systemd
   timers, consistent with `scripts/inventory.service`.
3. **`backup.php` storage path** — under `backups/` (existing dir) or external mount?
   Default to `backups/` with rotation managed by `log_rotate.php`.
4. **Brand application scope** — apply CC Silver only to `layouts/` or also paint
   into `libs/css/main.css`? Default: layouts only, main.css unchanged.
