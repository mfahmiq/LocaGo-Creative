<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\PresenceRequest;
use App\Models\Presence;
use App\Models\User;
use App\Services\PresenceService;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;
use Database\Factories\TranslateFactory;
use Illuminate\Http\Request;
use Prologue\Alerts\Facades\Alert;

/**
 * Class PresenceCrudController
 * @package App\Http\Controllers\Admin
 * @property-read \Backpack\CRUD\app\Library\CrudPanel\CrudPanel $crud
 */
class PresenceCrudController extends CrudController
{
    use \Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation {store as storeTrait;}
    use \Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;

    protected $entityField = [
        'name'=>'user_id',
        'entity'=>'user',
        'model'=>User::class,
        'attribute'=>'name',
        'type'=>'select',
        'label'=>'Nama Karyawan'
    ];

    /**
     * Configure the CrudPanel object. Apply settings to all operations.
     *
     * @return void
     */
    public function setup()
    {
        CRUD::setModel(\App\Models\Presence::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/presence');
        CRUD::setEntityNameStrings('Kehadiran', 'Kehadiran');
        $this->crud->addClause('with','user');

        // Controller ini juga melayani route PUBLIK `/scan` dan `POST /presence/record`
        // (pemindai QR di pintu masuk, tanpa login). Di sana tidak ada pengguna
        // terautentikasi, jadi pemeriksaan izin harus dilewati — bukan meledak.
        $me = backpack_auth()->check() ? backpack_user() : null;

        if (! $me) {
            return;
        }

        if (! $me->can('presence.view')) {
            abort(403, 'Anda tidak berhak melihat data kehadiran.');
        }

        // Menyempit lewat pemilik presensinya, memakai definisi tim yang sama
        // dengan daftar karyawan.
        $this->crud->addClause('whereHas', 'user', fn ($q) => $q->visibleTo($me));

        if (! $me->can('presence.create')) CRUD::denyAccess(['create']);
        if (! $me->can('presence.edit'))   CRUD::denyAccess(['update']);
        if (! $me->can('presence.delete')) CRUD::denyAccess(['delete']);
    }

    protected function autoSetupShowOperation()
    {
        CRUD::setFromDb();
        $this->fieldModification();
    }

    protected function setupShowOperation()
    {
        $this->autoSetupShowOperation();
        $this->fieldModification();
    }

    /**
     * Define what happens when the List operation is loaded.
     *
     * @see  https://backpackforlaravel.com/docs/crud-operation-list-entries
     * @return void
     */
    protected function setupListOperation()
    {
        CRUD::setFromDb(); // set columns from db columns.

        /**
         * Columns can be defined using the fluent syntax:
         * - CRUD::column('price')->type('number');
         */

        $this->crud->removeColumn('user_id');
        $this->crud->addColumn($this->entityField)->beforeColumn('in');
        $this->fieldModification();
    }

    public function fieldModification(){
        $this->crud->removeColumn('user_id');
        $this->crud->addColumn($this->entityField)->beforeColumn('in');

        $translate = new TranslateFactory();
        foreach($translate->presences() as $key => $value){
            $this->crud->field($key)->label($value);
            $this->crud->column($key)->label($value);
        }

        $fieldsToRemove = ['created_at', 'updated_at','lat','lng'];

        if($this->crud->getCurrentOperation() !='show'){
            foreach ($fieldsToRemove as $field) {
                $this->crud->removeField($field);
                $this->crud->removeColumn($field);
            }
        }


    }

    /**
     * Define what happens when the Create operation is loaded.
     *
     * @see https://backpackforlaravel.com/docs/crud-operation-create
     * @return void
     */
    protected function setupCreateOperation()
    {
        CRUD::setValidation(PresenceRequest::class);
        CRUD::setFromDb(); // set fields from db columns.

        /**
         * Fields can be defined using the fluent syntax:
         * - CRUD::field('price')->type('number');
         */

        $this->crud->field($this->entityField);
        $this->fieldModification();
    }

    /**
     * Define what happens when the Update operation is loaded.
     *
     * @see https://backpackforlaravel.com/docs/crud-operation-update
     * @return void
     */
    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();

    }

    public function store()
    {

        // Overriding the operation skips Backpack's own access check.
        $this->crud->hasAccessOrFail('create');

        $request = $this->crud->validateRequest();
        $presence  = new Presence();
        $presence->user_id = $request->user_id;
        $presence->in = $request->in;
        $presence->out = $request->out;

        $presence->save();
        Alert::add('success', 'Berhasil input data')->flash();
        return redirect(route('presence.index'));
    }

    public function update()
    {

        // Overriding the operation skips Backpack's own access check.
        $this->crud->hasAccessOrFail('update');
        $request = $this->crud->validateRequest();
        $presence  = $this->crud->getCurrentEntry();
        $presence->user_id = $request->user_id;
        $presence->in = $request->in;
        $presence->out = $request->out;

        $presence->save();
        Alert::add('success', 'Berhasil update data')->flash();
        return redirect(route('presence.index'));
    }

    public function scan(){
        return view('presence.scan');
    }

    /**
     * Custom Show — presents the attendance record as a readable report with
     * the selfie proof, a location map, and source/approval badges instead of a
     * raw column dump (M22-3).
     */
    public function show($id)
    {
        $this->crud->hasAccessOrFail('show');

        $presence = Presence::with(['user', 'branch', 'approver'])->findOrFail($id);

        // Reuse the same team-scoping as the list, so managers can't open a
        // record outside their team by guessing the id.
        $me = backpack_auth()->check() ? backpack_user() : null;
        if ($me && ! $me->can('presence.view')) {
            abort(403, 'Anda tidak berhak melihat data kehadiran.');
        }

        return view('admin.presence.show', [
            'presence' => $presence,
            'crud'     => $this->crud,
        ]);
    }

    public function record(Request $request){
        if($request->qr){
            $user = User::with('schedule')
                ->where("qr",$request->qr)->first();
            if(!$user){
                return response()->json('Failed',500);
            }
            $presenceService = app(PresenceService::class);
            $p = $presenceService->record($user);
            $presenceService->updateCoordinate($p,$request->lat, $request->lng);
            return response()->json($p);
        }
        return response()->json("Not Found",404);
    }

    // ── M22-5 — Approval absen luar-radius (Camera Mode) ───

    /** List camera check-ins awaiting approval, scoped to the viewer's team. */
    public function approvals()
    {
        $me = backpack_user();
        abort_unless($me?->can('presence.edit'), 403, 'Anda tidak berhak menyetujui kehadiran.');

        $pending = Presence::with(['user', 'branch'])
            ->where('source', 'camera')
            ->where('approval_status', 'pending')
            ->whereHas('user', fn ($q) => $q->visibleTo($me))
            ->orderByDesc('in')
            ->get();

        return view('admin.presence.approvals', [
            'pending' => $pending,
            'crud'    => $this->crud,
        ]);
    }

    public function approveAction($id, Request $request)
    {
        return $this->decide($id, 'approve', $request);
    }

    public function rejectAction($id, Request $request)
    {
        return $this->decide($id, 'reject', $request);
    }

    private function decide($id, string $action, Request $request)
    {
        $me = backpack_user();
        abort_unless($me?->can('presence.edit'), 403);

        $presence = Presence::with('user')
            ->where('source', 'camera')
            ->where('approval_status', 'pending')
            ->whereHas('user', fn ($q) => $q->visibleTo($me))
            ->findOrFail($id);

        $service = app(PresenceService::class);
        $note = $request->input('note');

        if ($action === 'approve') {
            $service->approve($presence, $me, $note);
            $type = 'attendance_approved';
            $title = 'Absensi Disetujui';
            $msg = 'Absensi Anda pada ' . \Carbon\Carbon::parse($presence->in)->format('d M Y H:i') . ' telah disetujui.';
        } else {
            $service->reject($presence, $me, $note);
            $type = 'attendance_rejected';
            $title = 'Absensi Ditolak';
            $msg = 'Absensi Anda pada ' . \Carbon\Carbon::parse($presence->in)->format('d M Y H:i') . ' ditolak.'
                . ($note ? ' Alasan: ' . $note : '');
        }

        app(\App\Services\NotificationService::class)->notify($presence->user, $type, [
            'title' => $title,
            'body'  => $msg,
        ]);

        Alert::add('success', $action === 'approve' ? 'Kehadiran disetujui.' : 'Kehadiran ditolak.')->flash();

        return redirect(route('presence.approvals'));
    }
}
