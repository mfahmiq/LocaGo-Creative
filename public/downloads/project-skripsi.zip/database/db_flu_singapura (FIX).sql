-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 18 Feb 2025 pada 18.47
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_flu_singapura`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `consultation_histories`
--

CREATE TABLE `consultation_histories` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `symptoms` text NOT NULL,
  `diagnosis` text NOT NULL,
  `recommended_medicine` text NOT NULL,
  `confidence_level` decimal(5,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `consultation_histories`
--

INSERT INTO `consultation_histories` (`id`, `user_id`, `symptoms`, `diagnosis`, `recommended_medicine`, `confidence_level`, `created_at`, `updated_at`) VALUES
(6, 1, '[1,2,3,5,13]', 'FLU SINGAPURA', '[{\"nama_obat\":\"PARACETAMOL\",\"deskripsi\":\"Digunakan untuk meredakan demam dan nyeri ringan seperti sakit tenggorokan atau nyeri tubuh.\",\"dosis\":\"Anak-anak (usia 2-6 tahun): 10-15 mg/kg berat badan, setiap 4-6 jam, tidak lebih dari 5 dosis dalam 24 jam. Anak-anak(usia 6-12 tahun): 200-400mg, setiap 4-6 jam, maksimal 4 dosis per-hari. Dewasa: 500 mg-1 g setiap 4-6jam, maksimal 4 dosis per-hari.\",\"efek_samping\":\"Efek samping yang mungkin terjadi termasuk reaksi alergi ringan (ruam, gatal), atau lebih serius kerusakan hati jika digunakan dalam dosis berlebihan.\\r\\nJika pasien memiliki riwayat alergi terhadap paracetamol, obat ini harus dihindari.\"},{\"nama_obat\":\"IBUPROFEN\",\"deskripsi\":\"Digunakan untuk meredakan demam tinggi dan nyeri. Ibuprofen lebih efektif dalam mengatasi nyeri inflamasi dibandingkan paracetamol, tetapi harus digunakan dengan hati-hati pada anak-anak di bawah usia 6 bulan.\",\"dosis\":\"Anak-anak (usia 6 bulan – 2 tahun): 5-10 mg/kg berat badan setiap 6-8 jam. Anak-anak (usia 2-12 tahun):  100-200 mg setiap 6-8 jam, maksimal 4 dosis per-hari. Dewasa: 200-400 mg setiap 4-6 jam, maksimal 1,200 mg perhari (untuk penggunaan jangka pendek).\",\"efek_samping\":\"Efek samping termasuk gangguan pencernaan (misalnya, sakit perut, mual), pusing, dan dalam kasus langka, peningkatan tekanan darah atau gangguan fungsi ginjal.\\r\\nHindari pada pasien dengan alergi terhadap NSAID (non-steroidal anti-inflammatory drugs), atau yang memiliki riwayat ulserasi lambung atau penyakit jantung.\"},{\"nama_obat\":\"GEL LIDOCAIN\",\"deskripsi\":\"Digunakan untuk meredakan nyeri sariawan atau luka di mulut. Gel ini bekerja sebagai anestesi lokal dan membantu mengurangi rasa sakit saat makan atau minum.\",\"dosis\":\"Anak-anak: Biasanya digunakan dengan dosis rendah. Dewasa: Oleskan sedikit pada area yang terkena, tidak lebih dari 4 kali per-hari\",\"efek_samping\":\"Efek samping dapat mencakup reaksi alergi (gatal, ruam), pusing, atau dalam kasus lebih serius, gangguan jantung.\\r\\nHindari pada pasien dengan riwayat alergi terhadap lidokain atau penyakit jantung.\"},{\"nama_obat\":\"Cairan Rehidrasi Oral (ORS)\",\"deskripsi\":\"Untuk menghindari dehidrasi yang sering terjadi akibat kesulitan makan atau minum. ORS membantu menggantikan cairan dan elektrolit yang hilang.\",\"dosis\":\"Anak-anak dan Dewasa: Konsumsi sesuai instruksi pada kemasan, yang biasanya 100ml untuk anak usai 1-2 tahun setiap kali dehidrasi ringan. Pada dehidrasi berat, instruksi dari dokter harus diikuti.\",\"efek_samping\":\"Umumnya aman, tetapi pasien dengan pembengkakan ginjal atau penyakit jantung yang memerlukan pembatasan cairan harus mengonsultasikan penggunaan dengan dokter.\"},{\"nama_obat\":\"Aloclair plus spray\",\"deskripsi\":\"obat untuk mempercepat proses penyembuhan dan membantu mengatasi nyeri akibat sariawan\",\"dosis\":\"Anak-anak dan Dewasa: Konsumsi sesuai instruksi pada kemasan bisaanya  1-2 tetes per 3-4 kali sehari atau sesuai kebutuhan \",\"efek_samping\":\"-\"}]', 73.45, '2025-02-13 10:44:20', '2025-02-13 10:44:20'),
(7, 1, '[4,6,10,14]', 'STOMATITIS HERPETIK', '[{\"nama_obat\":\"IBUPROFEN\",\"deskripsi\":\"Digunakan untuk meredakan demam tinggi dan nyeri. Ibuprofen lebih efektif dalam mengatasi nyeri inflamasi dibandingkan paracetamol, tetapi harus digunakan dengan hati-hati pada anak-anak di bawah usia 6 bulan.\",\"dosis\":\"Anak-anak (usia 6 bulan – 2 tahun): 5-10 mg/kg berat badan setiap 6-8 jam. Anak-anak (usia 2-12 tahun):  100-200 mg setiap 6-8 jam, maksimal 4 dosis per-hari. Dewasa: 200-400 mg setiap 4-6 jam, maksimal 1,200 mg perhari (untuk penggunaan jangka pendek).\",\"efek_samping\":\"Efek samping termasuk gangguan pencernaan (misalnya, sakit perut, mual), pusing, dan dalam kasus langka, peningkatan tekanan darah atau gangguan fungsi ginjal.\\r\\nHindari pada pasien dengan alergi terhadap NSAID (non-steroidal anti-inflammatory drugs), atau yang memiliki riwayat ulserasi lambung atau penyakit jantung.\"},{\"nama_obat\":\"Obat Kumur Antiseptik (Chlorhexidine)\",\"deskripsi\":\"Membantu mencegah infeksi sekunder di mulut.\",\"dosis\":\"Kumur 10-15 ml larutan 0,2% selama 30 detik, 2 kal\",\"efek_samping\":\"Chlorhexidine dapat menyebabkan rasa terbakar di mulut.\"},{\"nama_obat\":\"Anestesi Topikal (Benzocaine Gel)\",\"deskripsi\":\"Meredakan nyeri pada luka di mulut.\",\"dosis\":\"Untuk Anak-anak (di atas 2 tahun):\\nOleskan sedikit gel (kira-kira seukuran kacang polong) pada area yang sakit, hingga 4 kali sehari.\\nUntuk Dewasa:\\nOleskan gel ke area yang sakit setiap 2-4 jam, maksimal 4 kali sehari.\",\"efek_samping\":\"Reaksi alergi lokal, seperti kemerahan, bengkak, atau gatal.\\nRisiko methemoglobinemia (sangat jarang, tetapi serius), terutama pada anak-anak. Gejala termasuk kulit kebiruan, napas pendek, dan lemas.\"},{\"nama_obat\":\"Acyclovir (Antiviral)\",\"deskripsi\":\"Membantu mempercepat penyembuhan dan mengurangi gejala Cacar Air.\",\"dosis\":\"Anak-anak: 20 mg/kg berat badan, diberikan 4 kali sehari selama 5 hari\\nDewasa: 800 mg, 5 kali sehari selama 5-7 hari.\",\"efek_samping\":\"Acyclovir dapat menyebabkan mual, pusing, dan gangguan fungsi ginjal jika tidak cukup hidrasi, pada beberapa kasus.\"}]', 41.86, '2025-02-13 10:46:11', '2025-02-13 10:46:11'),
(8, 1, '[4,6,7,10]', 'STOMATITIS HERPETIK', '[{\"nama_obat\":\"IBUPROFEN\",\"deskripsi\":\"Digunakan untuk meredakan demam tinggi dan nyeri. Ibuprofen lebih efektif dalam mengatasi nyeri inflamasi dibandingkan paracetamol, tetapi harus digunakan dengan hati-hati pada anak-anak di bawah usia 6 bulan.\",\"dosis\":\"Anak-anak (usia 6 bulan – 2 tahun): 5-10 mg/kg berat badan setiap 6-8 jam. Anak-anak (usia 2-12 tahun):  100-200 mg setiap 6-8 jam, maksimal 4 dosis per-hari. Dewasa: 200-400 mg setiap 4-6 jam, maksimal 1,200 mg perhari (untuk penggunaan jangka pendek).\",\"efek_samping\":\"Efek samping termasuk gangguan pencernaan (misalnya, sakit perut, mual), pusing, dan dalam kasus langka, peningkatan tekanan darah atau gangguan fungsi ginjal.\\r\\nHindari pada pasien dengan alergi terhadap NSAID (non-steroidal anti-inflammatory drugs), atau yang memiliki riwayat ulserasi lambung atau penyakit jantung.\"},{\"nama_obat\":\"Obat Kumur Antiseptik (Chlorhexidine)\",\"deskripsi\":\"Membantu mencegah infeksi sekunder di mulut.\",\"dosis\":\"Kumur 10-15 ml larutan 0,2% selama 30 detik, 2 kal\",\"efek_samping\":\"Chlorhexidine dapat menyebabkan rasa terbakar di mulut.\"},{\"nama_obat\":\"Anestesi Topikal (Benzocaine Gel)\",\"deskripsi\":\"Meredakan nyeri pada luka di mulut.\",\"dosis\":\"Untuk Anak-anak (di atas 2 tahun):\\nOleskan sedikit gel (kira-kira seukuran kacang polong) pada area yang sakit, hingga 4 kali sehari.\\nUntuk Dewasa:\\nOleskan gel ke area yang sakit setiap 2-4 jam, maksimal 4 kali sehari.\",\"efek_samping\":\"Reaksi alergi lokal, seperti kemerahan, bengkak, atau gatal.\\nRisiko methemoglobinemia (sangat jarang, tetapi serius), terutama pada anak-anak. Gejala termasuk kulit kebiruan, napas pendek, dan lemas.\"},{\"nama_obat\":\"Acyclovir (Antiviral)\",\"deskripsi\":\"Membantu mempercepat penyembuhan dan mengurangi gejala Cacar Air.\",\"dosis\":\"Anak-anak: 20 mg/kg berat badan, diberikan 4 kali sehari selama 5 hari\\nDewasa: 800 mg, 5 kali sehari selama 5-7 hari.\",\"efek_samping\":\"Acyclovir dapat menyebabkan mual, pusing, dan gangguan fungsi ginjal jika tidak cukup hidrasi, pada beberapa kasus.\"}]', 37.89, '2025-02-13 10:56:28', '2025-02-13 10:56:28'),
(9, 2, '[1,2,3,5,13]', 'FLU SINGAPURA', '[{\"nama_obat\":\"PARACETAMOL\",\"deskripsi\":\"Digunakan untuk meredakan demam dan nyeri ringan seperti sakit tenggorokan atau nyeri tubuh.\",\"dosis\":\"Anak-anak (usia 2-6 tahun): 10-15 mg/kg berat badan, setiap 4-6 jam, tidak lebih dari 5 dosis dalam 24 jam. Anak-anak(usia 6-12 tahun): 200-400mg, setiap 4-6 jam, maksimal 4 dosis per-hari. Dewasa: 500 mg-1 g setiap 4-6jam, maksimal 4 dosis per-hari.\",\"efek_samping\":\"Efek samping yang mungkin terjadi termasuk reaksi alergi ringan (ruam, gatal), atau lebih serius kerusakan hati jika digunakan dalam dosis berlebihan.\\r\\nJika pasien memiliki riwayat alergi terhadap paracetamol, obat ini harus dihindari.\"},{\"nama_obat\":\"IBUPROFEN\",\"deskripsi\":\"Digunakan untuk meredakan demam tinggi dan nyeri. Ibuprofen lebih efektif dalam mengatasi nyeri inflamasi dibandingkan paracetamol, tetapi harus digunakan dengan hati-hati pada anak-anak di bawah usia 6 bulan.\",\"dosis\":\"Anak-anak (usia 6 bulan – 2 tahun): 5-10 mg/kg berat badan setiap 6-8 jam. Anak-anak (usia 2-12 tahun):  100-200 mg setiap 6-8 jam, maksimal 4 dosis per-hari. Dewasa: 200-400 mg setiap 4-6 jam, maksimal 1,200 mg perhari (untuk penggunaan jangka pendek).\",\"efek_samping\":\"Efek samping termasuk gangguan pencernaan (misalnya, sakit perut, mual), pusing, dan dalam kasus langka, peningkatan tekanan darah atau gangguan fungsi ginjal.\\r\\nHindari pada pasien dengan alergi terhadap NSAID (non-steroidal anti-inflammatory drugs), atau yang memiliki riwayat ulserasi lambung atau penyakit jantung.\"},{\"nama_obat\":\"GEL LIDOCAIN\",\"deskripsi\":\"Digunakan untuk meredakan nyeri sariawan atau luka di mulut. Gel ini bekerja sebagai anestesi lokal dan membantu mengurangi rasa sakit saat makan atau minum.\",\"dosis\":\"Anak-anak: Biasanya digunakan dengan dosis rendah. Dewasa: Oleskan sedikit pada area yang terkena, tidak lebih dari 4 kali per-hari\",\"efek_samping\":\"Efek samping dapat mencakup reaksi alergi (gatal, ruam), pusing, atau dalam kasus lebih serius, gangguan jantung.\\r\\nHindari pada pasien dengan riwayat alergi terhadap lidokain atau penyakit jantung.\"},{\"nama_obat\":\"Cairan Rehidrasi Oral (ORS)\",\"deskripsi\":\"Untuk menghindari dehidrasi yang sering terjadi akibat kesulitan makan atau minum. ORS membantu menggantikan cairan dan elektrolit yang hilang.\",\"dosis\":\"Anak-anak dan Dewasa: Konsumsi sesuai instruksi pada kemasan, yang biasanya 100ml untuk anak usai 1-2 tahun setiap kali dehidrasi ringan. Pada dehidrasi berat, instruksi dari dokter harus diikuti.\",\"efek_samping\":\"Umumnya aman, tetapi pasien dengan pembengkakan ginjal atau penyakit jantung yang memerlukan pembatasan cairan harus mengonsultasikan penggunaan dengan dokter.\"},{\"nama_obat\":\"Aloclair plus spray\",\"deskripsi\":\"obat untuk mempercepat proses penyembuhan dan membantu mengatasi nyeri akibat sariawan\",\"dosis\":\"Anak-anak dan Dewasa: Konsumsi sesuai instruksi pada kemasan bisaanya  1-2 tetes per 3-4 kali sehari atau sesuai kebutuhan \",\"efek_samping\":\"-\"}]', 73.45, '2025-02-13 11:09:19', '2025-02-13 11:09:19'),
(10, 2, '[2,7,11,13]', 'FLU SINGAPURA', '[{\"nama_obat\":\"PARACETAMOL\",\"deskripsi\":\"Digunakan untuk meredakan demam dan nyeri ringan seperti sakit tenggorokan atau nyeri tubuh.\",\"dosis\":\"Anak-anak (usia 2-6 tahun): 10-15 mg/kg berat badan, setiap 4-6 jam, tidak lebih dari 5 dosis dalam 24 jam. Anak-anak(usia 6-12 tahun): 200-400mg, setiap 4-6 jam, maksimal 4 dosis per-hari. Dewasa: 500 mg-1 g setiap 4-6jam, maksimal 4 dosis per-hari.\",\"efek_samping\":\"Efek samping yang mungkin terjadi termasuk reaksi alergi ringan (ruam, gatal), atau lebih serius kerusakan hati jika digunakan dalam dosis berlebihan.\\r\\nJika pasien memiliki riwayat alergi terhadap paracetamol, obat ini harus dihindari.\"},{\"nama_obat\":\"IBUPROFEN\",\"deskripsi\":\"Digunakan untuk meredakan demam tinggi dan nyeri. Ibuprofen lebih efektif dalam mengatasi nyeri inflamasi dibandingkan paracetamol, tetapi harus digunakan dengan hati-hati pada anak-anak di bawah usia 6 bulan.\",\"dosis\":\"Anak-anak (usia 6 bulan – 2 tahun): 5-10 mg/kg berat badan setiap 6-8 jam. Anak-anak (usia 2-12 tahun):  100-200 mg setiap 6-8 jam, maksimal 4 dosis per-hari. Dewasa: 200-400 mg setiap 4-6 jam, maksimal 1,200 mg perhari (untuk penggunaan jangka pendek).\",\"efek_samping\":\"Efek samping termasuk gangguan pencernaan (misalnya, sakit perut, mual), pusing, dan dalam kasus langka, peningkatan tekanan darah atau gangguan fungsi ginjal.\\r\\nHindari pada pasien dengan alergi terhadap NSAID (non-steroidal anti-inflammatory drugs), atau yang memiliki riwayat ulserasi lambung atau penyakit jantung.\"},{\"nama_obat\":\"GEL LIDOCAIN\",\"deskripsi\":\"Digunakan untuk meredakan nyeri sariawan atau luka di mulut. Gel ini bekerja sebagai anestesi lokal dan membantu mengurangi rasa sakit saat makan atau minum.\",\"dosis\":\"Anak-anak: Biasanya digunakan dengan dosis rendah. Dewasa: Oleskan sedikit pada area yang terkena, tidak lebih dari 4 kali per-hari\",\"efek_samping\":\"Efek samping dapat mencakup reaksi alergi (gatal, ruam), pusing, atau dalam kasus lebih serius, gangguan jantung.\\r\\nHindari pada pasien dengan riwayat alergi terhadap lidokain atau penyakit jantung.\"},{\"nama_obat\":\"Cairan Rehidrasi Oral (ORS)\",\"deskripsi\":\"Untuk menghindari dehidrasi yang sering terjadi akibat kesulitan makan atau minum. ORS membantu menggantikan cairan dan elektrolit yang hilang.\",\"dosis\":\"Anak-anak dan Dewasa: Konsumsi sesuai instruksi pada kemasan, yang biasanya 100ml untuk anak usai 1-2 tahun setiap kali dehidrasi ringan. Pada dehidrasi berat, instruksi dari dokter harus diikuti.\",\"efek_samping\":\"Umumnya aman, tetapi pasien dengan pembengkakan ginjal atau penyakit jantung yang memerlukan pembatasan cairan harus mengonsultasikan penggunaan dengan dokter.\"},{\"nama_obat\":\"Aloclair plus spray\",\"deskripsi\":\"obat untuk mempercepat proses penyembuhan dan membantu mengatasi nyeri akibat sariawan\",\"dosis\":\"Anak-anak dan Dewasa: Konsumsi sesuai instruksi pada kemasan bisaanya  1-2 tetes per 3-4 kali sehari atau sesuai kebutuhan \",\"efek_samping\":\"-\"}]', 56.52, '2025-02-14 08:28:39', '2025-02-14 08:28:39'),
(11, 2, '[1,5,13]', 'FLU SINGAPURA', '[{\"nama_obat\":\"PARACETAMOL\",\"deskripsi\":\"Digunakan untuk meredakan demam dan nyeri ringan seperti sakit tenggorokan atau nyeri tubuh.\",\"dosis\":\"Anak-anak (usia 2-6 tahun): 10-15 mg/kg berat badan, setiap 4-6 jam, tidak lebih dari 5 dosis dalam 24 jam. Anak-anak(usia 6-12 tahun): 200-400mg, setiap 4-6 jam, maksimal 4 dosis per-hari. Dewasa: 500 mg-1 g setiap 4-6jam, maksimal 4 dosis per-hari.\",\"efek_samping\":\"Efek samping yang mungkin terjadi termasuk reaksi alergi ringan (ruam, gatal), atau lebih serius kerusakan hati jika digunakan dalam dosis berlebihan.\\r\\nJika pasien memiliki riwayat alergi terhadap paracetamol, obat ini harus dihindari.\"},{\"nama_obat\":\"IBUPROFEN\",\"deskripsi\":\"Digunakan untuk meredakan demam tinggi dan nyeri. Ibuprofen lebih efektif dalam mengatasi nyeri inflamasi dibandingkan paracetamol, tetapi harus digunakan dengan hati-hati pada anak-anak di bawah usia 6 bulan.\",\"dosis\":\"Anak-anak (usia 6 bulan – 2 tahun): 5-10 mg/kg berat badan setiap 6-8 jam. Anak-anak (usia 2-12 tahun):  100-200 mg setiap 6-8 jam, maksimal 4 dosis per-hari. Dewasa: 200-400 mg setiap 4-6 jam, maksimal 1,200 mg perhari (untuk penggunaan jangka pendek).\",\"efek_samping\":\"Efek samping termasuk gangguan pencernaan (misalnya, sakit perut, mual), pusing, dan dalam kasus langka, peningkatan tekanan darah atau gangguan fungsi ginjal.\\r\\nHindari pada pasien dengan alergi terhadap NSAID (non-steroidal anti-inflammatory drugs), atau yang memiliki riwayat ulserasi lambung atau penyakit jantung.\"},{\"nama_obat\":\"GEL LIDOCAIN\",\"deskripsi\":\"Digunakan untuk meredakan nyeri sariawan atau luka di mulut. Gel ini bekerja sebagai anestesi lokal dan membantu mengurangi rasa sakit saat makan atau minum.\",\"dosis\":\"Anak-anak: Biasanya digunakan dengan dosis rendah. Dewasa: Oleskan sedikit pada area yang terkena, tidak lebih dari 4 kali per-hari\",\"efek_samping\":\"Efek samping dapat mencakup reaksi alergi (gatal, ruam), pusing, atau dalam kasus lebih serius, gangguan jantung.\\r\\nHindari pada pasien dengan riwayat alergi terhadap lidokain atau penyakit jantung.\"},{\"nama_obat\":\"Cairan Rehidrasi Oral (ORS)\",\"deskripsi\":\"Untuk menghindari dehidrasi yang sering terjadi akibat kesulitan makan atau minum. ORS membantu menggantikan cairan dan elektrolit yang hilang.\",\"dosis\":\"Anak-anak dan Dewasa: Konsumsi sesuai instruksi pada kemasan, yang biasanya 100ml untuk anak usai 1-2 tahun setiap kali dehidrasi ringan. Pada dehidrasi berat, instruksi dari dokter harus diikuti.\",\"efek_samping\":\"Umumnya aman, tetapi pasien dengan pembengkakan ginjal atau penyakit jantung yang memerlukan pembatasan cairan harus mengonsultasikan penggunaan dengan dokter.\"},{\"nama_obat\":\"Aloclair plus spray\",\"deskripsi\":\"obat untuk mempercepat proses penyembuhan dan membantu mengatasi nyeri akibat sariawan\",\"dosis\":\"Anak-anak dan Dewasa: Konsumsi sesuai instruksi pada kemasan bisaanya  1-2 tetes per 3-4 kali sehari atau sesuai kebutuhan \",\"efek_samping\":\"-\"}]', 62.96, '2025-02-14 08:36:13', '2025-02-14 08:36:13');

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `gejala`
--

CREATE TABLE `gejala` (
  `id` int(11) NOT NULL,
  `kode_gejala` varchar(10) NOT NULL,
  `nama_gejala` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `gejala`
--

INSERT INTO `gejala` (`id`, `kode_gejala`, `nama_gejala`, `deskripsi`, `created_at`, `updated_at`) VALUES
(1, 'G001', 'DEMAM RINGAN', 'Biasanya terjadi di awal penyakit dan tidak terlalu tinggi (sekitar 38–39°C).', '2024-12-14 10:40:03', '2024-12-27 18:42:45'),
(2, 'G002', 'DEMAM TINGGI', 'Biasanya terjadi di awal penyakit dan demam tinggi (sekitar >39°C).', '2024-12-14 10:40:03', '2025-02-16 16:18:21'),
(3, 'G003', 'RUAM KULIT(TANPA GATAL)', 'Ruam berbentuk bintik merah yang kadang berubah menjadi lenting kecil berisi cairan.(TANPA GATAL)\nLokasi: telapak tangan, telapak kaki, lutut, siku, atau bokong. Lenting ini biasanya tidak terasa gatal.', '2024-12-14 10:40:03', '2025-01-05 11:13:56'),
(4, 'G004', 'RUAM KULIT(BESERTA GATAL)', 'Ruam dimulai dengan bintik merah kecil yang berkembang menjadi lepuhan berisi cairan, biasanya gatal.\nLokasi: cenderung menyebar ke seluruh tubuh termasuk wajah', '2024-12-14 10:40:03', '2024-12-27 18:27:39'),
(5, 'G005', 'LUKA DIMULUT (STOMATITIS)', 'Luka kecil seperti sariawan di bagian dalam pipi, gusi, atau lidah, yang terasa nyeri dan membuat anak sulit makan atau minum.', '2024-12-14 10:40:03', '2024-12-27 18:27:01'),
(6, 'G006', 'LUKA DIMULUT(HERPANGINA)', 'Herpangina/Ulkus menyebabkan luka di bagian belakang mulut/tenggorokan atau langit-langit mulut, Ulkus ini biasanya berwarna merah cerah atau abu-abu dan bisa terasa sakit', '2024-12-14 10:40:03', '2024-12-27 18:29:26'),
(7, 'G007', 'PILEK ATAU BATUK RINGAN', 'Batuk kering, pilek', '2024-12-14 10:40:03', '2024-12-27 19:11:54'),
(8, 'G008', 'MUAL', 'Perasaan tidak nyaman di perut, sering disertai ingin muntah.', '2024-12-14 10:40:03', '2024-12-14 10:40:03'),
(9, 'G009', 'DIARE', 'Frekuensi buang air besar lebih sering dan encer', '2024-12-14 10:40:03', '2024-12-14 10:40:03'),
(10, 'G010', 'SAKIT TENGGOROKAN\n', 'Rasa nyeri atau iritasi pada tenggorokan saat menelan.', '2024-12-14 10:40:03', '2025-02-16 16:18:16'),
(11, 'G011', 'SESAK NAFAS', 'Kesulitan bernapas, sering terkait dengan masalah paru-paru', '2024-12-14 10:40:03', '2024-12-14 10:40:03'),
(12, 'G0012', 'KELELAHAN DAN REWEL', 'Anak-anak sering tampak lesu, mudah rewel, dan sulit tidur karena rasa tidak nyaman.', '2024-12-27 18:22:08', '2025-01-05 11:14:05'),
(13, 'G0013', 'KEHILANGAN NAFSU MAKAN', 'Luka di mulut dan rasa sakit saat menelan dapat membuat anak menolak makanan atau minuman.', '2024-12-27 18:22:08', '2024-12-27 18:36:58'),
(14, 'G014', 'BINTIK KOPLIK', 'Bercak-bercak kecil berwarna putih keabu-abuan yang muncul di dalam mulut, tepatnya pada mukosa bukal (bagian dalam pipi)\nUkuran: Sangat kecil, sekitar 1-2 mm.\nLokasi: Biasanya muncul di mukosa bukal bagian dalam, dekat dengan gigi geraham.\nBentuk: Bulat atau oval.', '2024-12-27 18:22:08', '2025-02-16 16:28:08'),
(15, 'G015', 'MATA MERAH (KONJUNGTIVIS)', 'kondisi peradangan pada selaput bening yang melapisi bagian putih mata (sklera) dan bagian dalam kelopak mata (konjungtiva). Peradangan ini dapat menyebabkan mata menjadi merah, berair, dan terasa gatal. Kondisi ini sering disebut juga dengan mata merah atau pinkeye.', '2024-12-27 19:13:54', '2024-12-27 19:13:54');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_10_30_152421_add_role_to_users_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `obat`
--

CREATE TABLE `obat` (
  `id` int(11) NOT NULL,
  `kode_obat` varchar(10) NOT NULL,
  `nama_obat` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `dosis` text DEFAULT NULL,
  `efek_samping` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `obat`
--

INSERT INTO `obat` (`id`, `kode_obat`, `nama_obat`, `deskripsi`, `dosis`, `efek_samping`, `created_at`, `updated_at`) VALUES
(1, 'O001', 'PARACETAMOL', 'Digunakan untuk meredakan demam dan nyeri ringan seperti sakit tenggorokan atau nyeri tubuh.', 'Anak-anak (usia 2-6 tahun): 10-15 mg/kg berat badan, setiap 4-6 jam, tidak lebih dari 5 dosis dalam 24 jam. Anak-anak(usia 6-12 tahun): 200-400mg, setiap 4-6 jam, maksimal 4 dosis per-hari. Dewasa: 500 mg-1 g setiap 4-6jam, maksimal 4 dosis per-hari.', 'Efek samping yang mungkin terjadi termasuk reaksi alergi ringan (ruam, gatal), atau lebih serius kerusakan hati jika digunakan dalam dosis berlebihan.\nJika pasien memiliki riwayat alergi terhadap paracetamol, obat ini harus dihindari.', '2024-12-14 10:59:27', '2025-02-16 19:04:03'),
(2, 'O002', 'IBUPROFEN', 'Digunakan untuk meredakan demam tinggi dan nyeri. Ibuprofen lebih efektif dalam mengatasi nyeri inflamasi dibandingkan paracetamol, tetapi harus digunakan dengan hati-hati pada anak-anak di bawah usia 6 bulan.', 'Anak-anak (usia 6 bulan – 2 tahun): 5-10 mg/kg berat badan setiap 6-8 jam. Anak-anak (usia 2-12 tahun):  100-200 mg setiap 6-8 jam, maksimal 4 dosis per-hari. Dewasa: 200-400 mg setiap 4-6 jam, maksimal 1,200 mg perhari (untuk penggunaan jangka pendek).', 'Efek samping termasuk gangguan pencernaan (misalnya, sakit perut, mual), pusing, dan dalam kasus langka, peningkatan tekanan darah atau gangguan fungsi ginjal.\nHindari pada pasien dengan alergi terhadap NSAID (non-steroidal anti-inflammatory drugs), atau yang memiliki riwayat ulserasi lambung atau penyakit jantung.', '2024-12-14 10:59:27', '2025-02-16 19:08:51'),
(3, 'O003', 'GEL LIDOCAIN', 'Digunakan untuk meredakan nyeri sariawan atau luka di mulut. Gel ini bekerja sebagai anestesi lokal dan membantu mengurangi rasa sakit saat makan atau minum.', 'Anak-anak: Biasanya digunakan dengan dosis rendah. Dewasa: Oleskan sedikit pada area yang terkena, tidak lebih dari 4 kali per-hari', 'Efek samping dapat mencakup reaksi alergi (gatal, ruam), pusing, atau dalam kasus lebih serius, gangguan jantung.\nHindari pada pasien dengan riwayat alergi terhadap lidokain atau penyakit jantung.', '2024-12-14 10:59:27', '2025-02-16 19:09:26'),
(4, 'O004', 'Cairan Rehidrasi Oral (ORS)', 'Untuk menghindari dehidrasi yang sering terjadi akibat kesulitan makan atau minum. ORS membantu menggantikan cairan dan elektrolit yang hilang.', 'Anak-anak dan Dewasa: Konsumsi sesuai instruksi pada kemasan, yang biasanya 100ml untuk anak usai 1-2 tahun setiap kali dehidrasi ringan. Pada dehidrasi berat, instruksi dari dokter harus diikuti.', 'Umumnya aman, tetapi pasien dengan pembengkakan ginjal atau penyakit jantung yang memerlukan pembatasan cairan harus mengonsultasikan penggunaan dengan dokter.', '2024-12-14 10:59:27', '2025-01-06 17:18:28'),
(5, 'O005', 'Aloclair plus spray', 'obat untuk mempercepat proses penyembuhan dan membantu mengatasi nyeri akibat sariawan', 'Anak-anak dan Dewasa: Konsumsi sesuai instruksi pada kemasan bisaanya  1-2 tetes per 3-4 kali sehari atau sesuai kebutuhan ', '-', '2024-12-23 12:09:46', '2025-01-06 17:18:54'),
(6, 'O006', 'Acyclovir (Antiviral)', 'Membantu mempercepat penyembuhan dan mengurangi gejala Cacar Air.', 'Anak-anak: 20 mg/kg berat badan, diberikan 4 kali sehari selama 5 hari\nDewasa: 800 mg, 5 kali sehari selama 5-7 hari.', 'Acyclovir dapat menyebabkan mual, pusing, dan gangguan fungsi ginjal jika tidak cukup hidrasi, pada beberapa kasus.', '2024-12-27 20:37:33', '2025-01-06 17:22:41'),
(7, 'O007', 'Clamine Lotion (Topikal)', 'Mengurangi rasa gatal pada ruam.', 'Oleskan pada ruam 2-3 kali sehari.', '-', '2024-12-27 20:37:33', '2025-01-06 17:33:46'),
(8, 'O008', 'Antihistamin (Loratadine, Cetirizine)', 'Untuk mengatasi rasa gatal yang parah.', 'Loratadine :\nDosis untuk Anak-anak (2-12 tahun):\nBerat badan <30 kg: 5 mg sekali sehari.\nBerat badan ≥30 kg: 10 mg sekali sehari.\nDosis untuk Dewasa (>12 tahun):\n10 mg sekali sehari.\n\nCetirizine :\nDosis untuk Anak-anak (2-6 tahun):\n2.5 mg sekali atau dua kali sehari.\nDosis untuk Anak-anak (6-12 tahun):\n5-10 mg sekali sehari.\nDosis untuk Dewasa (>12 tahun):\n10 mg sekali sehari.', 'Mengantuk atau lemas (lebih jarang pada loratadine karena non-sedatif).\nMulut kering.\nSakit kepala.\nGangguan pencernaan ringan.', '2024-12-27 20:37:33', '2025-01-06 17:28:54'),
(9, 'O009', 'Obat Kumur Antiseptik (Chlorhexidine)', 'Membantu mencegah infeksi sekunder di mulut.', 'Kumur 10-15 ml larutan 0,2% selama 30 detik, 2 kal', 'Chlorhexidine dapat menyebabkan rasa terbakar di mulut.', '2024-12-27 20:37:33', '2024-12-27 20:37:33'),
(10, 'O010', 'Anestesi Topikal (Benzocaine Gel)', 'Meredakan nyeri pada luka di mulut.', 'Untuk Anak-anak (di atas 2 tahun):\nOleskan sedikit gel (kira-kira seukuran kacang polong) pada area yang sakit, hingga 4 kali sehari.\nUntuk Dewasa:\nOleskan gel ke area yang sakit setiap 2-4 jam, maksimal 4 kali sehari.', 'Reaksi alergi lokal, seperti kemerahan, bengkak, atau gatal.\nRisiko methemoglobinemia (sangat jarang, tetapi serius), terutama pada anak-anak. Gejala termasuk kulit kebiruan, napas pendek, dan lemas.', '2024-12-27 20:37:33', '2025-01-06 17:29:51'),
(11, 'O011', 'Vitamin A', 'Mengurangi keparahan gejala dan komplikasi.', 'Anak-anak: 50,000-200,000 IU sekali sehari selama 2 hari (dosis tergantung usia).\nDewasa: 200,000 IU, sekali sehari selama 2 hari.', 'Vitamin A dosis tinggi dapat menyebabkan mual, muntah, dan nyeri kepala.', '2024-12-27 20:37:33', '2025-01-06 17:32:33'),
(12, 'O012', 'Obat Batuk (Dextromethorphan, Guaifenesin)', 'Untuk mengurangi batuk kering.', 'Anak-anak: 7.5-15 mg setiap 6-8 jam.\nDewasa: 10-20 mg setiap 4-6 jam.', '-', '2024-12-27 20:37:33', '2025-01-06 17:33:36'),
(13, 'O013', 'Larutan Saline', 'Untuk mengatasi pilek.', 'Untuk Anak-anak (semua usia):\nLarutan Saline Nasal Spray: 1-2 semprotan di setiap lubang hidung, 2-4 kali sehari.\nLarutan Saline Kumur: Kumur dengan 10-15 ml larutan selama 30 detik, 2-3 kali sehari.\nUntuk Dewasa:\nLarutan Saline Nasal Spray: 2-3 semprotan di setiap lubang hidung, 3-4 kali sehari.\nLarutan Saline Kumur: Kumur dengan 15-30 ml larutan selama 30 detik, 2-4 kali sehari.', 'Sensasi kering atau sedikit iritasi pada saluran hidung atau tenggorokan.\nJarang menyebabkan reaksi alergi, karena saline biasanya bebas bahan kimia tambahan.', '2024-12-27 20:37:33', '2025-01-06 17:30:52');

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `penyakit`
--

CREATE TABLE `penyakit` (
  `id` int(11) NOT NULL,
  `kode_penyakit` varchar(10) NOT NULL,
  `nama_penyakit` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `penyakit`
--

INSERT INTO `penyakit` (`id`, `kode_penyakit`, `nama_penyakit`, `deskripsi`, `created_at`, `updated_at`) VALUES
(1, 'P001', 'FLU SINGAPURA', 'Penyakit akibat virus yang menyebabkan demam dan ruam kulit', '2024-12-14 10:42:11', '2024-12-14 10:42:11'),
(2, 'P002', 'CACAR AIR (VARISELA)', 'Cacar air disebabkan oleh virus varicella-zoster dan sering menyerang anak-anak. Penyakit ini ditandai dengan ruam berupa bintil berisi cairan yang menyebar ke seluruh tubuh.', '2024-12-27 17:44:15', '2024-12-27 17:44:15'),
(3, 'P003', 'CAMPAK (MEASLES)', 'Campak disebabkan oleh virus campak (paramyxovirus). Penyakit ini sangat menular dan sering dimulai dengan gejala flu-like sebelum muncul ruam.', '2024-12-27 17:44:15', '2024-12-27 17:44:15'),
(4, 'P004', 'STOMATITIS HERPETIK', 'Herpangina disebabkan oleh kelompok virus enterovirus (termasuk Coxsackievirus) dan menyerang anak-anak, mirip dengan Flu Singapura.', '2024-12-27 17:44:15', '2024-12-27 17:44:15');

-- --------------------------------------------------------

--
-- Struktur dari tabel `relasi_gejala_penyakit`
--

CREATE TABLE `relasi_gejala_penyakit` (
  `id` int(11) NOT NULL,
  `penyakit_id` int(11) DEFAULT NULL,
  `gejala_id` int(11) DEFAULT NULL,
  `bobot` decimal(3,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `relasi_gejala_penyakit`
--

INSERT INTO `relasi_gejala_penyakit` (`id`, `penyakit_id`, `gejala_id`, `bobot`) VALUES
(1, 1, 1, 0.95),
(2, 1, 10, 0.85),
(3, 1, 3, 0.75),
(4, 1, 5, 0.85),
(5, 1, 12, 0.65),
(6, 1, 13, 0.75),
(7, 2, 1, 0.80),
(8, 2, 4, 0.90),
(9, 2, 9, 0.10),
(10, 2, 12, 0.70),
(11, 3, 2, 0.90),
(12, 3, 7, 0.80),
(13, 3, 14, 0.70),
(14, 3, 9, 0.30),
(15, 3, 12, 0.80),
(16, 3, 15, 0.80),
(17, 4, 2, 0.90),
(18, 4, 6, 0.90),
(19, 4, 13, 0.70),
(20, 4, 9, 0.15),
(21, 1, 7, 0.35),
(22, 1, 8, 0.15),
(23, 1, 9, 0.15);

-- --------------------------------------------------------

--
-- Struktur dari tabel `relasi_penyakit_obat`
--

CREATE TABLE `relasi_penyakit_obat` (
  `id_relasi` int(11) NOT NULL,
  `id_penyakit` int(11) NOT NULL,
  `id_obat` int(11) NOT NULL,
  `deskripsi_rekomendasi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `relasi_penyakit_obat`
--

INSERT INTO `relasi_penyakit_obat` (`id_relasi`, `id_penyakit`, `id_obat`, `deskripsi_rekomendasi`) VALUES
(1, 1, 1, 'Digunakan untuk meredakan demam dan nyeri ringan seperti sakit tenggorokan atau nyeri tubuh.'),
(2, 1, 2, 'Digunakan untuk meredakan demam tinggi dan nyeri. Ibuprofen lebih efektif dalam mengatasi nyeri inflamasi dibandingkan paracetamol, tetapi harus digunakan dengan hati-hati pada anak-anak di bawah usia 6 bulan.'),
(3, 1, 3, 'Digunakan untuk meredakan nyeri sariawan atau luka di mulut. Gel ini bekerja sebagai anestesi lokal dan membantu mengurangi rasa sakit saat makan atau minum.'),
(4, 1, 4, 'Untuk menghindari dehidrasi yang sering terjadi akibat kesulitan makan atau minum. ORS membantu menggantikan cairan dan elektrolit yang hilang.'),
(5, 1, 5, 'Obat untuk mempercepat proses penyembuhan dan membantu mengatasi nyeri akibat sariawan.'),
(6, 2, 6, 'Membantu mempercepat penyembuhan dan mengurangi gejala Cacar Air.'),
(7, 2, 1, 'Digunakan untuk meredakan demam dan nyeri ringan seperti sakit tenggorokan atau nyeri tubuh.'),
(8, 2, 7, 'Mengurangi rasa gatal pada ruam.'),
(9, 2, 8, 'Untuk mengatasi rasa gatal yang parah.'),
(10, 4, 2, 'Digunakan untuk meredakan demam tinggi dan nyeri. Ibuprofen lebih efektif dalam mengatasi nyeri inflamasi dibandingkan paracetamol, tetapi harus digunakan dengan hati-hati pada anak-anak di bawah usia 6 bulan.'),
(11, 4, 9, 'Membantu mencegah infeksi sekunder di mulut.'),
(12, 4, 10, 'Meredakan nyeri pada luka di mulut.'),
(13, 4, 6, 'Untuk kasus berat, terutama pada pasien imunokompromais.'),
(14, 3, 2, 'Digunakan untuk meredakan demam tinggi dan nyeri tubuh. Ibuprofen lebih efektif dalam mengatasi nyeri inflamasi dibandingkan paracetamol, tetapi harus digunakan dengan hati-hati pada anak-anak di bawah usia 6 bulan.\n'),
(15, 3, 11, 'Mengurangi keparahan gejala dan komplikasi.'),
(16, 3, 12, 'Untuk mengurangi batuk'),
(17, 3, 13, 'Untuk mengatasi pilek.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('1gQXd1NifADQ4GhTuobP9PTPeu59LnKQGLXUlUiz', 2, '192.168.1.7', 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/133.0.6943.33 Mobile/15E148 Safari/604.1', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoieE40c29IRXBJNjZTSW1pcHFWWHFLaHAyTjRack51U3lmR3FpcThJeCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzI6Imh0dHA6Ly8xOTIuMTY4LjEuMjA6ODAwMS9oaXN0b3J5Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mjt9', 1739547374),
('dtaY0lpS5DwxlMIoDgmaY1Dv3tqCVmuGsRcRZQGj', 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoicU1ScE8wNHQzM29zUGUycnNzZmlhVVFyM1NLZ1pMbzVOVjlmcHYzQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9oaXN0b3J5Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mjt9', 1739546920),
('lSEuPvQOd4InO6JN51NgTqv6U3JPZXMJQl6vQZW5', 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiaUpsNDI1Z3JCZEswYXRPeFBESENHWXk3TzJUaHpQVURBQ1NTQzZVTCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9oaXN0b3J5Ijt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mjt9', 1739470835),
('TJp6SwZGEjlNqCpURVBawlbUpRXE2LL0k4MZ2eEq', NULL, '192.168.1.19', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUm1QYjFkREFCNWpWaGtBOGFEc0g1MDBBMlFZdHVLQmlUMkpkQVdkWCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjQ6Imh0dHA6Ly8xOTIuMTY4LjEuMjA6ODAwMSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1739547524);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Hans', 'raydiphan@gmail.com', NULL, '$2y$12$RaM9JLMe1KR8RE7XnBmr4.pdVa.nxJ/x.7PJKVEHjA0meqOYpCWPe', NULL, '2024-12-24 23:06:09', '2024-12-24 23:06:09'),
(2, 'Brisa Windy Felia', 'brisawindyfelia@gmail.com', NULL, '$2y$12$3yncI/M636oob0wl583fUORVFdaW6BI9Uc1MV7/lM/MW3Lseiyi8S', NULL, '2025-02-07 07:50:27', '2025-02-07 07:50:27');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indeks untuk tabel `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indeks untuk tabel `consultation_histories`
--
ALTER TABLE `consultation_histories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indeks untuk tabel `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `obat`
--
ALTER TABLE `obat`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indeks untuk tabel `penyakit`
--
ALTER TABLE `penyakit`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `relasi_gejala_penyakit`
--
ALTER TABLE `relasi_gejala_penyakit`
  ADD PRIMARY KEY (`id`),
  ADD KEY `penyakit_id` (`penyakit_id`),
  ADD KEY `gejala_id` (`gejala_id`);

--
-- Indeks untuk tabel `relasi_penyakit_obat`
--
ALTER TABLE `relasi_penyakit_obat`
  ADD PRIMARY KEY (`id_relasi`),
  ADD KEY `id_penyakit` (`id_penyakit`),
  ADD KEY `id_obat` (`id_obat`);

--
-- Indeks untuk tabel `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `consultation_histories`
--
ALTER TABLE `consultation_histories`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `gejala`
--
ALTER TABLE `gejala`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `obat`
--
ALTER TABLE `obat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `penyakit`
--
ALTER TABLE `penyakit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `relasi_gejala_penyakit`
--
ALTER TABLE `relasi_gejala_penyakit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT untuk tabel `relasi_penyakit_obat`
--
ALTER TABLE `relasi_penyakit_obat`
  MODIFY `id_relasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `consultation_histories`
--
ALTER TABLE `consultation_histories`
  ADD CONSTRAINT `consultation_histories_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `relasi_gejala_penyakit`
--
ALTER TABLE `relasi_gejala_penyakit`
  ADD CONSTRAINT `relasi_gejala_penyakit_ibfk_1` FOREIGN KEY (`penyakit_id`) REFERENCES `penyakit` (`id`),
  ADD CONSTRAINT `relasi_gejala_penyakit_ibfk_2` FOREIGN KEY (`gejala_id`) REFERENCES `gejala` (`id`);

--
-- Ketidakleluasaan untuk tabel `relasi_penyakit_obat`
--
ALTER TABLE `relasi_penyakit_obat`
  ADD CONSTRAINT `relasi_penyakit_obat_ibfk_1` FOREIGN KEY (`id_penyakit`) REFERENCES `penyakit` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `relasi_penyakit_obat_ibfk_2` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
