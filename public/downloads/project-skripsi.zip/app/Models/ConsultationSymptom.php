<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConsultationSymptom extends Model
{
    use HasFactory;
    protected $table = 'consultation_symptoms';
    protected $fillable = ['consultation_id','gejala_id','created_at','updated_at'];

    //relasi ke konsultasi history
    public function consultation(){
        return $this->belongsTo(ConsultationHistory::class, 'consultation_id');
    }

    //relasi ke gejala
    public function gejala(){
        return $this->belongsTo(Gejala::class, 'id');
    }
}
