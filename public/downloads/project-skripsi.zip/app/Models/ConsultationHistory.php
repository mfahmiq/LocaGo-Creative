<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class ConsultationHistory extends Model
{
    use HasFactory;
    //protected $table = 'consultation_histories';
    public $timestamps = true;
    protected $fillable = [
        'user_id',
        'confidence_level',
    ];

    //relasi ke User
    public function user(){
        return $this->belongsTo(User::class);
    }

    //relasi ke Consultationsymptoms (Gejala yang dipilih)
    public function symptoms(){
        return $this->hasMany(ConsultationSymptom::class, 'consultation_id');
    }

    //relasi ke Consultationdiagnosis (Penyakit yang di diagnosis) 
    public function diagnoses(){
        return $this->hasMany(ConsultationDiagnosis::class, 'consultation_id');
    }

    //relasi ke ConsultationMedicine (obat yang di rekomendasian)
    public function medicines(){
        return $this->hasMany(ConsultationMedicine::class, 'consultation_id');
    }
    // public $timestamps = true;

    // protected $fillable= [
    //     'user_id',
    //     'symptoms',
    //     'diagnosis',
    //     'recommended_medicine',
    //     'confidence_level',
    //     'created_at'
    // ];
    // protected $dates = ['create_at', 'updated_at'];
    // public function symptomsList(){
    //     $symptomIds= json_decode($this->symptoms, true);
    //     return Gejala::whereIn('id', $symptomIds)
    //     ->pluck('nama_gejala')
    //     ->implode(', ');
    // }

    // public function recommendedMedicineList(){
    //     return collect(json_decode($this->recommended_medicine, true))
    //     ->pluck('nama_obat')
    //     ->implode(', ');
    // }

    // public function user()
    // {
    //     return $this->belongsTo(User::class);
    // }
}
