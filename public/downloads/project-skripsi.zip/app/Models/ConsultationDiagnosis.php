<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConsultationDiagnosis extends Model
{
    use HasFactory;
    protected $table = 'consultation_diagnoses';
    protected $fillable = ['consultation_id','penyakit_id','created_at','updated_at'];

    //relasi ke konsul history
    public function consultation(){
        return $this->belongsTo(ConsultationHistory::class, 'consultation_id');
    }

    //relasi ke penyakt
    public function penyakit(){
        return $this->belongsTo(Penyakit::class, 'penyakit_id');
    }
}
