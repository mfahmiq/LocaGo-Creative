<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Penyakit extends Model
{
    use HasFactory;

    protected $table = 'penyakit';
    protected $fillable = ['kode_penyakit','nama_penyakit','deskripsi','created_at','updated_at'];
    
    //relasi many to many dengan Gejala
    public function gejala(){
        return $this->belongsToMany(Gejala::class, 'relasi_gejala_penyakit','penyakit_id', 'gejala_id')
        ->withPivot('bobot')
        ->withTimestamps();
    }

    // relasi many to many dengan Obat
    public function obat(){
        return $this->belongsToMany(Obat::class, 'relasi_penyakit_obat','penyakit_id','obat_id')
        ->withTimestamps();
    }
}
