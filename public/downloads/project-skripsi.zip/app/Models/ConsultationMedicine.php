<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ConsultationMedicine extends Model
{
    use HasFactory;
    protected $tabel = 'consultation_medicines';
    protected $fillable = ['consultation_id','obat_id','created_at','updated_at'];

    //relasi ke konsul history
    public function consultation(){
        return $this->belongsTo(ConsultationHistory::class, 'consultation_id');
    }

    //relasi ke obat
    public function obat(){
        return $this->belongsTo(ConsultationMedicine::class, 'obat_id');
    }
}
