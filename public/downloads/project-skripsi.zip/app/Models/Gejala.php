<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Gejala extends Model
{
    use HasFactory;

    protected $table = 'gejala';
    protected $fillable = ['kode_gejala','nama_gejala','deskripsi','created_at','updated_at'];

    //relasi many to many dengan penyakit melalui table relasi penyakit gejala
    public function penyakit(){
        return $this->belongsToMany(Penyakit::class, 'relasi_gejala_penyakit','penyakit_id','gejala_id')
        ->withPivot('bobot')
        ->withTimestamps();
    }
}
