<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Obat extends Model
{
    use HasFactory;

    protected $table = 'obat';
    protected $fillable = ['nama_obat','deskripsi','dosis','efek_samping','note','created_at','updated_at'];

    //relasi many to many dengan penyakit
    public function penyakit(){
        return $this->belongsToMany(Penyakit::class, 'relasi_penyakit_obat','penyakit_id','obat_id')
        ->withTimestamps();
    }
}
