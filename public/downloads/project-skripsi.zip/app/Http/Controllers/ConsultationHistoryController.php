<?php

namespace App\Http\Controllers;

use App\Models\ConsultationHistory;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class ConsultationHistoryController extends Controller
{
    /**
     * Show the ConsultationHistory page.
     */
    public function index()
    {
        $histories = DB::table('consultation_histories AS ch')
    ->leftJoin('consultation_symptoms AS cs', 'ch.id', '=', 'cs.consultation_id')
    ->leftJoin('gejala AS g', 'cs.gejala_id', '=', 'g.id')
    ->leftJoin('consultation_diagnoses AS cd', 'ch.id', '=', 'cd.consultation_id')
    ->leftJoin('penyakit AS p', 'cd.penyakit_id', '=', 'p.id')
    ->leftJoin('consultation_medicines AS cm', 'ch.id', '=', 'cm.consultation_id')
    ->leftJoin('obat AS o', 'cm.obat_id', '=', 'o.id')
    ->where('ch.user_id', Auth::id())
    ->select(
        'ch.id',
        DB::raw('GROUP_CONCAT(DISTINCT g.nama_gejala SEPARATOR ", ") as symptoms'),
        DB::raw('GROUP_CONCAT(DISTINCT p.nama_penyakit SEPARATOR ", ") as diagnosis'),
        DB::raw('GROUP_CONCAT(DISTINCT o.nama_obat SEPARATOR ", ") as recommended_medicine'),
        'ch.confidence_level',
        'ch.created_at'
    )
    ->groupBy('ch.id','ch.confidence_level','ch.created_at')
    ->orderBy('ch.created_at', 'desc')
    ->get();

      //dd($histories);
  return view('history.index', compact('histories'));
    //     $riwayat = DB::table('riwayat_diagnosa')
    //     ->join('penyakit', 'riwayat_diagnosa.penyakit_id', '=', 'penyakit.id')
    //     ->where('user_id', Auth::id()) // Ambil hanya riwayat yang login
    //     ->select('riwayat_diagnosa.*', 'penyakit.nama')
    //     ->get();

    //     return view('history.index', compact('riwayat'));
    // }

    // public function deleteHistory($id)
    // {
    //     DB::table('riwayat_diagnosa')->where('id', $id)->delete();

    //     return redirect()->route('history')->with('succes', 'History Successfully Deleted');
    }
}
