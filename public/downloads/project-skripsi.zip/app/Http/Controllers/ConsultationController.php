<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Models\ConsultationHistory;
use Illuminate\Http\Request;

class ConsultationController extends Controller
{
    // public function index()
    // {
    //     $user = Auth::user();
    //     // $histories = ConsultationHistory::where('user_id', $user->id)->get();
    //     $histories1 = ConsultationHistory::latest()->get()->map(function($history){
    //         return[
    //             'symptoms' => $history->symptomsList(),
    //             'recommended_medicine' => $history->recommendedMedicineList(),
    //         ];
    //     });
    //     $histories = ConsultationHistory::select(
    //         'id',
    //         'symptoms',
    //         'diagnosis',
    //         'recommended_medicine',
    //         'confidence_level',
    //         'created_at'
    //     )->latest()->get();
    //     // $historiesG = ConsultationHistory::with('recommendedMedicineList')->latest()->get();
    //     //dd($histories1);

    //     return view('history.index', compact('histories','histories1'));
    // }
    public function index()
{
    $user = Auth::user();

    // ✅ Ambil data konsultasi dan ubah JSON ke daftar nama
    $histories = ConsultationHistory::select(
        'id',
        'symptoms',
        'diagnosis',
        'recommended_medicine',
        'confidence_level',
        'created_at'
    )->where('user_id', $user->id)->latest()->get()->map(function ($history) {
        return [
            'id' => $history->id,
            'symptoms' => $history->symptomsList(),
            'diagnosis' => $history->diagnosis,
            'recommended_medicine' => $history->recommendedMedicineList(),
            'confidence_level' => $history->confidence_level,
            'created_at' => $history->created_at->format('d M Y H:i'),
        ];
    });

    return view('history.index', compact('histories'));
}


    public function storeConsultationHistory(Request $request)
    {
        $request->validate([
            'gejala' => 'required',
            'penyakit' => 'required|string',
            'persentase' => 'required|numeric|min:0|max:100',
            'recomendasi_obat' => 'required|string',
        ]);

        // ✅ Konversi gejala
        $decodedGejala = json_decode($request->gejala, true);

        // Jika masih dalam bentuk string JSON, decode lagi
        if (is_string($decodedGejala)) {
            $decodedGejala = json_decode($decodedGejala, true);
        }

        $gejalaArray = is_array($decodedGejala) ? $decodedGejala : [];
        $gejalaFormatted = json_encode(array_map('intval', $gejalaArray));
        
        // ✅ Konversi rekomendasi obat
        $decodedObat = json_decode($request->recomendasi_obat, true);
        
        // Jika masih dalam bentuk string JSON, decode lagi
        if (is_string($decodedObat)) {
            $decodedObat = json_decode($decodedObat, true);
        }
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            dd("JSON ERROR: " . json_last_error_msg(), $request->recomendasi_obat);
        }
        
        $rekomendasiObatFormatted = json_encode($decodedObat, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        // dd($rekomendasiObatFormatted);

        // ✅ Simpan hasil konsultasi ke database
        $history = new ConsultationHistory();
        $history->user_id = Auth::id();
        $history->symptoms = $gejalaFormatted;
        $history->diagnosis = $request->penyakit;
        $history->recommended_medicine = $rekomendasiObatFormatted;
        $history->confidence_level = $request->persentase;
        $history->save();

        return redirect()->route('history.index')->with('success', 'History Saved Successfully.');
    }
    // public function show($id){
    //     $consultation = ConsultationHistory::findOrFail($id);
    //     $gejala = $consultation->symptompList();

    //     return response()->json([
    //         'diagnosis' => $consultation->diagnosis,
    //         'confidence_level' => $consultation->confidence_level,
    //         'symptoms' => $gejala,
    //         'recommended_medicine' => json_decode($consultation->recommended_medicine)
    //     ]);
    // }
}
