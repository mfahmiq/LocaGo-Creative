<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Gejala;
use App\Models\Penyakit;
use App\Models\Obat;
use App\Models\ConsultationHistory;
use App\Models\ConsultationSymptom;
use App\Models\ConsultationDiagnosis;
use App\Models\ConsultationMedicine;
use Illuminate\Support\Facades\Auth;

class DiagnosesController extends Controller
{
    /**
     * Show the Diagnoses page.
     */
    public function index()
    {
        // Ambil data gejala dari database
        $gejala = Gejala::all();

        // Kirim data gejala ke view
        return view('diagnoses.index', compact('gejala'));
    }

    /**
     * Store diagnosis and calculate probability.
     */
    public function store(Request $request)
    {
        // Validasi input
        $validated = $request->validate([
            'gejala' => 'required|array|min:1', // Minimal harus memilih satu gejala
            'gejala.*' => 'exists:gejala,id', // Setiap gejala harus ada di tabel gejala
        ]);

        // Ambil gejala yang dipilih
        $selectedGejala = $request->gejala;

        // Step 1: Menghitung total bobot untuk setiap penyakit berdasarkan gejala yang dipilih
        $penyakitScores = DB::table('relasi_gejala_penyakit')
            ->select('penyakit_id', DB::raw('SUM(bobot) as total_bobot'))
            ->whereIn('gejala_id', $selectedGejala)
            ->groupBy('penyakit_id')
            ->get();

        // Jika tidak ada penyakit yang cocok
        if ($penyakitScores->isEmpty()) {
            return back()->with('error', 'Tidak ada penyakit yang terdiagnosis berdasarkan gejala yang dipilih.');
        }

        // Hitung total bobot
        $totalBobot = $penyakitScores->sum('total_bobot');

        // Menambahkan kolom persentase
        $penyakitScores = $penyakitScores->map(function ($item) use ($totalBobot) {
            $item->persentase = ($item->total_bobot / $totalBobot) * 100;
            return $item;
        });

        // Memilih penyakit dengan score tertinggi
        $highestScore = $penyakitScores->sortByDesc('total_bobot')->first();

        $idPenyakit = $highestScore->penyakit_id;
        $persentase = round($highestScore->persentase, 2); // Dibulatkan 2 angka desimal

        // Step 2: Mengambil data penyakit
        $penyakit = Penyakit::find($idPenyakit);

        // Step 3: Mengambil daftar obat yang direkomendasikan
        $rekomendasiObat = Obat::join('relasi_penyakit_obat', 'obat.id', '=', 'relasi_penyakit_obat.id_obat')
            ->where('relasi_penyakit_obat.id_penyakit', $idPenyakit)
            ->select('obat.id', 'obat.nama_obat', 'obat.deskripsi', 'obat.dosis', 'obat.efek_samping','obat.note')
            ->get();

        // Step 4: Simpan ke dalam tabel `consultation_histories`
        $consultation = ConsultationHistory::create([
            'user_id' => Auth::id(),
            'confidence_level' => $persentase,
        ]);

        // Step 5: Simpan gejala yang dipilih ke `consultation_symptom`
        foreach ($selectedGejala as $gejalaId) {
            ConsultationSymptom::create([
                'consultation_id' => $consultation->id,
                'gejala_id' => $gejalaId,
            ]);
        }

        // Step 6: Simpan penyakit yang terdiagnosis ke `consultation_diagnoses`
        ConsultationDiagnosis::create([
            'consultation_id' => $consultation->id,
            'penyakit_id' => $idPenyakit,
        ]);

        // Step 7: Simpan obat rekomendasi ke `consultation_medicines`
        foreach ($rekomendasiObat as $obat) {
            ConsultationMedicine::create([
                'consultation_id' => $consultation->id,
                'obat_id' => $obat->id,
            ]);
        }

        // Redirect dengan hasil diagnosis
        return redirect()->route('recommended.index')->with([
            'gejala' => json_encode($selectedGejala),
            'penyakit' => $penyakit->nama_penyakit,
            'persentase' => $persentase,
            'rekomendasi_obat' => $rekomendasiObat,
        ]);
    }
}
