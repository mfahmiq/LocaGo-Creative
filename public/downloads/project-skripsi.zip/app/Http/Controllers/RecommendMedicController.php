<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Gejala;
use App\Models\Obat;
use Illuminate\Support\Facades\Auth;

class RecommendMedicController extends Controller
{
    /**
     * Show the Recommended Medication page.
     */
    public function index()
    {
        $penyakit = session('penyakit');
        $persentase = session('persentase');
        $rekomendasiObat = session('rekomendasi_obat');
        // dd($penyakit);
        
        return view('recommended.index', compact('penyakit', 'persentase', 'rekomendasiObat'));
    }
    public function DaftarObat(){
        
        $obats = Obat::all();
        // $namaObat = session('nama_obat');
        // $desk= session('deskripsi');
        // $dosis= session('dosis');
        // $efekSamping= session('efek_samping');
        // dd($namaObat);
        return view('recommended.DaftarObat', compact('obats'));
    }

    // public function showRecommended($id)
    // {
    //     $diagnosa = DB::table('riwayat_diagnosa')
    //     ->join('penyakit', 'riwayat_diagnosa.penyakit_id', '=', 'penyakit.id')
    //     ->where('riwayat_diagnosa.id', $id)
    //     ->select('penyakit.nama', 'riwayat_diagnosa.*')
    //     ->first();

    //     $rekomendasiObat = json_decode($diagnosa->rekomendasi_obat);

    //     return view('recommended', compact('diagnosa', 'rekomendasiObat'));
    // }
}
