@if(session('error'))
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
        {{ session('error') }}
    </div>
@endif
<x-app-layout>
    <x-slot name="header" class="fixed top-0 left-0 w-full z-10">
        <h2 class="font-bold text-xl text-gray-800 dark:text-gray-200 leading-tight text-center">
            {{ __('Diagnoses Page') }}
        </h2>
        <h3 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight text-center">
            {{ __('SINGAPORE FLU') }}
        </h3>
    </x-slot>

    <div class="container mx-auto mt-6 p-4 bg-white shadow rounded-lg overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200">
        <!-- <div class="max-h-screen overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200"> -->
            <h1 class="text-2xl font-bold mb-4">Silakan pilih gejala yang Anda alami untuk memulai diagnosa.</h1>
            <p class="mb-4 text-gray-600">Centang satu atau beberapa gejala yang sesuai dengan kondisi Anda. Setelah itu, klik tombol <b>"Proses Gejala"</b> untuk melihat hasil diagnosa dan rekomendasi pengobatan.</p>
            <form action="{{ route('diagnoses.store') }}" method="post">
                @csrf
                <div class="gejala-list grid grid-cols-1 md:grid-cols-2 gap-4">
                    @forelse ($gejala as $item)
                    <div class="gejala-item p-4 border rounded-lg bg-black-50 ">
                        <label class="flex items-start space-x-3 ">
                            <input type="checkbox" name="gejala[]" value="{{ $item->id }}" class="mt-1 h-5 w-5  mr-3">
                            <span class="text-gray-800 dark:text-black-200">
                                <span class="font-semibold">{{ $item->nama_gejala }}</span>
                                <p class="text-sm text-black-600 dark:text-black-400">{{ $item->deskripsi }}</p>
                            </span>
                        </label>
                    </div>
                    @empty
                    <p class="text-red-500">Tidak ada data gejala.</p>
                    @endforelse
                </div>
                <div class="mt-5 text-center">
                    <button type="submit" class="button-center">
                        Proses Gejala
                    </button>
                </div>
            </form>
        <!-- </div> -->
    </div>
</x-app-layout>
