<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-x1 text-gray-800 dark:text-gray-200 leading-tight text-center">
            {{ __('Hasil Diagnosa')}}
        </h2>
    </x-slot>
    <div class="container mt-5">
        <!-- <h1 class="text-center font-bold text-2x1">Hasil Diagnosa</h1> -->
        <div class="text-center mt-3">
            <!-- <h2 class="text-x1 font-semibold">Penyakit Terdiagnosa : </h2> -->
            <p class="text-lg text-red-600">{{ number_format($persentase, 2) }}% {{ $penyakit->nama_penyakit }}</p>
            <p class="text-sm font-semibold">{{ $deskripsi->deskripsi }}</p>
        </div>
        <div class="mt-5">
            <br>
            <h3>Rekomendasi Obat : </h3>
            <ul>
            <div class="gejala-list grid grid-cols-1 md:grid-cols-2 gap-4">
                @foreach ($obat as $item)
                <div class="gejala-item p-4 border rounded-lg bg-gray-50">
                <li>
                    <strong class="text-sm text-gray-600 dark:text-gray-400">{{ $item->nama_obat }}</strong><br>
                    <p class="text-sm text-gray-600 dark:text-gray-400">Deskripsi: {{ $item->deskripsi }}</p>
                    <p class="text-sm text-gray-600 dark:text-gray-400">Dosis : {{ $item->dosis }}</p>
                    <p class="text-sm text-gray-600 dark:text-gray-400">Efek Samping : {{ $item->efek_samping }}</p>
                </li>
                </div>
                @endforeach
            </div>
            </ul>
        </div>
        
        <div class="mt-5 text-center">
            <a href="{{ route('diagnoses.index') }}" class="text-blue-500 underline">Kembali ke halaman Diagnosa</a>
        </div>
    </div>
</x-app-layout>