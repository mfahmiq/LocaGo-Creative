@extends('layouts.app')

@section('content')
    <h1>Welcome to My Laravel App</h1>
    <p>This is a simple example of using Bootstrap in Laravel.</p>
    <button type="button" class="btn btn-primary">Primary Button</button>
@endsection
