<x-app-layout>
    <x-slot name="header">
        <h2 class="font-bold text-xl text-gray-800 dark:text-gray-200 leading-tight text-center">
            {{ __('Consultation History Page') }}
        </h2>
    </x-slot>

    {{-- Notifikasi sukses --}}
    @if (session('success'))
        <div class="alert alert-success text-center text-green-600 p-3">
            {{ session('success') }}
        </div>
    @endif

    {{-- Jika tidak ada riwayat konsultasi --}}
    @if ($histories->isEmpty())
        <h2 class="font-bold text-xl text-gray-800 dark:text-gray-200 leading-tight text-center p-4">
            {{ __('Belum ada riwayat konsultasi.') }}
        </h2>
    @else
        <div class="overflow-x-auto overflow-y-auto">
            <table class="min-w-full bg-white border border-gray-300 shadow-md">
                <thead class="text-white bg-blue-900">
                    <tr>
                        <th class="px-6 py-3 text-left text-sm font-medium uppercase">No</th>
                        <th class="px-6 py-3 text-left text-sm font-medium uppercase">Gejala</th>
                        <th class="px-6 py-3 text-left text-sm font-medium uppercase">Diagnosa</th>
                        <th class="px-6 py-3 text-left text-sm font-medium uppercase">Obat Rekomendasi</th>
                        <th class="px-6 py-3 text-left text-sm font-medium uppercase">Tingkat Keyakinan</th>
                        <th class="px-6 py-3 text-left text-sm font-medium uppercase">Waktu</th>
                    </tr>
                </thead>
                <tbody class="text-gray-700">
                @foreach ($histories as $index => $history)
                    <tr>
                        <td class="px-6 py-4 border">{{ $index + 1 }}</td>
                        <td class="px-6 py-4 border">{{ $history->symptoms ?? '-' }}</td>
                        <td class="px-6 py-4 border">{{ $history->diagnosis ?? '-' }}</td>
                        <td class="px-6 py-4 border">{{ $history->recommended_medicine ?? '-' }}</td>
                        <td class="px-6 py-4 border">{{ $history->confidence_level }}%</td>
                        <td class="px-6 py-4 border">{{ \Carbon\Carbon::parse($history->created_at)->format('d-m-Y H:i') }}</td>
                    </tr>
                @endforeach

                </tbody>
            </table>
        </div>
    @endif

    {{-- Tombol Kembali --}}
    <div class="mt-5 text-center">
        <a href="/dashboard">
            <button class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">BACK</button>
        </a>
    </div>
</x-app-layout>
