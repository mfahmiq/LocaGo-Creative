<footer class="block bg-navy-800 text-white py-6 px-4 mt-10" style="background-color: #203864;">
    <div class="container mx-auto text-center">
        <div class="max-w-lg mx-auto text-sm mb-4">
          <div class="text-red p-4 border rounded-lg bg-gray-50">
    <p class="font-bold text-base bg-white" style="color:red; font-size:larger;">⚠️PENTING!!!</p>
    <p class="text-sm leading-relaxed text-black">Terutama pada anak-anak dan orang dengan sistem imun yang lemah. Jika gejalanya memburuk atau tidak membaik dalam beberapa hari, 
      konsultasikan dengan dokter untuk pengobatan lebih lanjut. <b>Silahkan klik tombol dibawah ini untuk buat janji temu.</b> 😊
      <br>Jika gejala-gejala Flu Singapura muncul, penting untuk menghindari kontak dekat dengan orang lain untuk mencegah penularan, 
    </p>
          </div>
      <!-- Tombol untuk mengarahkan ke aplikasi rumah sakit -->
<div class="mt-5 text-center">
  <button onclick="openAppOrPlayStore()" class="button-center">
    Buka Aplikasi Rumah Sakit
  </button>
</div>
</div>
    <script>
        function openAppOrPlayStore(){
            var packageName = "com.siloam.android";
            //var appIntent = "intent://package."+ packageName +"#Intent;scheme=android-app;end;";
            var playStoreUrl ="https://play.google.com/store/apps/details?id="+packageName;

            //Coba buka aplikasi rs jika sudah terinstal
            //window.location.href = "intent://package/"+packageName +"#Intent;scheme=android-app;end;";

            //Jika dalam 2 detik aplikasi tidak terbuka, arahkan ke Play Store
            setTimeout(function(){
                window.location.href = playStoreUrl;
            }, 2000);
        }
    </script>
            <!-- Logo deskripsi -->
             <div class="mb-4 md:mb-0">
             <!-- <x-application-bg /> -->
                <p class="text-xs mt-4">Secure with Expert Flu</p>
             </div>
             <div class="flex flex-col md:flex-row justify-center items-center space-y-2 md:space-y-0 md:space-x-6 text-xs mt-4">
                <a href="/about" class="hover:text-gray-300">About</a>
                <a href="/contact" class="hover:text-gray-300">Contact</a>
                <a href="/privacy" class="hover:text-gray-300">Privacy Policy</a>
                <br>
                <!-- copyright -->
                <p> &copy; 2024 FLUBOT. All rights reserved.</p>
             </div>
        </div>
    </div>
</footer>