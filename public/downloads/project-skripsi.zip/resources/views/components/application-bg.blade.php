<div style="padding: 1em;">
    <img src="{{asset('images/LOGO FLUBOT2.png')}}" alt="Logo Flu Bot" width="100px" height="100px">
</div>