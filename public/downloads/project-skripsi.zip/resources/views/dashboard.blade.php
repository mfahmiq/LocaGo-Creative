<x-app-layout>
    <x-slot name="header">
        <h2 class="font-bold text-xl text-gray-800 dark:text-gray-200 leading-tight text-center">
            {{ __('SINGAPORE FLU') }}
        </h2>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200 leading-tight text-center">
            {{ __('Sistem Diagnosa Flu Singapura') }}
        </h3>
    </x-slot>
    
    <div class="container mx-auto px-4 py-6 bg-white">
        <div class="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div class="p-4 bg-white shadow rounded-lg text-justify">
                <p>Selamat datang di Aplikasi Sistem Pakar Flu Singapura - Aplikasi ini membantu Anda mengenali gejala penyakit Flu Singapura secara mandiri dan memberikan rekomendasi pengobatan awal. Gunakan aplikasi ini sebagai panduan sebelum berkonsultasi dengan dokter.</p>
            </div>
        </div>
    </div>

    <div class="container mx-auto px-4 py-6 bg-white">
        <h2 class="text-xl font-bold mb-4 text-center md:text-left bg-white">Statistik Singkat</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div class="p-4 bg-white shadow rounded-lg text-center">
                <h3 class="text-lg font-semibold text-gray-700">Total Diagnosa</h3>
                <p class="text-2xl font-bold text-blue-600">120</p>
            </div>
            <div class="p-4 bg-white shadow rounded-lg text-center">
                <h3 class="text-lg font-semibold text-gray-700">Pengguna Aktif</h3>
                <p class="text-2xl font-bold text-green-600">45</p>
            </div>
            <div class="p-4 bg-white shadow rounded-lg text-center">
                <h3 class="text-lg font-semibold text-gray-700">Obat Terpopuler</h3>
                <p class="text-2xl font-bold text-red-600">Paracetamol</p>
            </div>
        </div>
    </div>

    <div class="container mx-auto px-4 py-6 bg-white">
        <h2 class="text-xl font-bold mb-4 text-center md:text-left">Visualisasi Data</h2>
        <div class="bg-white p-4 shadow rounded-lg">
            <canvas id="chart" class="w-full h-64"></canvas>
        </div>
    </div>

    <div class="container mx-auto px-4 py-6 bg-white">
        <h2 class="text-xl font-bold mb-4 text-center md:text-left">Tips Kesehatan</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div class="p-4 bg-white shadow rounded-lg text-center">
                <h3 class="font-bold">Cuci Tangan Rutin</h3>
                <p>Mencuci tangan dengan sabun secara rutin untuk menghindari virus dan bakteri.</p>
            </div>
            <div class="p-4 bg-white shadow rounded-lg text-center">
                <h3 class="font-bold">Pola Hidup Sehat</h3>
                <p>Pastikan mengonsumsi makanan bergizi dan cukup tidur untuk menjaga imun tubuh.</p>
            </div>
            <div class="p-4 bg-white shadow rounded-lg text-center">
                <h3 class="font-bold">Bersihkan Lingkungan</h3>
                <p>Jaga kebersihan rumah dan mainan anak untuk mencegah penyebaran penyakit.</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctx = document.getElementById('chart').getContext('2d');
        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['CAMPAK', 'FLU SINGAPURA', 'CACAR AIR', 'STOMATITIS HERPETIK'],
                datasets: [{
                    label: 'Jumlah Diagnosa Berdasarkan Penyakit',
                    data: [12, 19, 3, 5],
                    backgroundColor: ['rgba(255, 99, 132, 0.2)', 'rgba(54, 162, 235, 0.2)', 'rgba(255, 206, 86, 0.2)', 'rgba(75, 192, 192, 0.2)'],
                    borderColor: ['rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)', 'rgba(255, 206, 86, 1)', 'rgba(75, 192, 192, 1)'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

    <div class="mt-5 text-center bg-white">
        <p class="mt-2 text-blue-700 font-semibold text-center">
            Silakan klik tombol di bawah ini untuk memulai diagnosa berdasarkan gejala yang Anda alami.
        </p>
        <a href="/diagnoses">
            <button class="button-center">🔍Diagnosa Sekarang</button>
        </a>
    </div>
</x-app-layout>
