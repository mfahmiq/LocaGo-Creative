<x-app-layout>
    <x-slot name="header">
        <h3 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight text-center">
        <p class="text-lg text-red-600 font-semibold">
            Berdasarkan gejala yang Anda pilih, kemungkinan besar Anda mengalami:<br> 
            <span class="underline">{{ $penyakit }}</span> 
            ({{ number_format($persentase, 2) }}%)
        </p>
        </h3>
    </x-slot>
    <div class="container mt-5">
        <div class="mt-5">
            <br>
            <div class="p-4 bg-red-100 border-l-4 border-red-500 text-red-700 rounded shadow mb-6">
                <p class="font-bold flex items-center gap-2">
                    ⚠️ PENTING!
                </p>
                <p class="mt-1">
                    Jika Anda memiliki riwayat alergi atau kondisi medis tertentu, sebaiknya konsultasikan dengan dokter sebelum menggunakan obat-obatan berikut, untuk memastikan pengobatan yang aman dan efektif. 😊
                </p>
            </div>
            <h3>Rekomendasi Obat : </h3>
            <ul>
            <div class="gejala-list grid grid-cols-1 md:grid-cols-2 gap-4">
                @php
                    $rekomendasiObat =$rekomendasiObat ?? [];
                @endphp
    @foreach ($rekomendasiObat as $obat)
    <div class="gejala-item p-4 border rounded-lg bg-gray-50 shadow">
        <h4 class="font-bold text-lg text-blue-800">{{ $obat->nama_obat ?? 'Nama Obat Tidak Tersedia' }}</h4>
        <p class="text-sm text-gray-700 mb-1">{{ $obat->deskripsi ?? 'Deskripsi Tidak Tersedia' }}</p>
        <p class="text-sm"><strong>Dosis:</strong> {{ $obat->dosis ?? 'Informasi Tidak Tersedia' }}</p>
        <p class="text-sm"><strong>Efek Samping:</strong> {{ $obat->efek_samping ?? 'Informasi Tidak Tersedia' }}</p>

        @if(!empty($obat->note))
            <p class="mt-2 text-sm text-red-600 font-semibold flex items-center gap-1">
                ⚠️ Note: {{ $obat->note }}
            </p>
        @endif
    </div>
@endforeach
</div>

            </ul>
        </div>
        @php
            $gejala = session('gejala', '[]');
            $decodeGejala = json_decode($gejala, true);
        @endphp
        <p class="mt-6 text-sm text-gray-600 text-center">
            Hasil ini hanya sebagai referensi awal. Segera konsultasikan dengan dokter untuk penanganan lebih lanjut.
        </p>

        <!-- <ul>
            @foreach ($decodeGejala as $gejalaId)
            <li>Gejala Id: {{ $gejalaId}}</li>
            @endforeach
        </ul> -->
    
        <!-- Tombol Simpan Data -->
        <!-- <form action="{{ route('history.storeConsultationHistory')}}" method="POST">
    @csrf
    <input type="hidden" name="gejala" value="{{ json_encode($gejala)}}">
    <input type="hidden" name="penyakit" value="{{ $penyakit }}">
    <input type="hidden" name="persentase" value="{{ $persentase }}">
    <input type="hidden" name="recomendasi_obat" value="{{ json_encode($rekomendasiObat) }}">
    <div class="mt-5 text-center">
        <button type="submit" class="button-center">SAVE</button>
    </div> -->
</form>
</div>
</x-app-layout>
