<x-app-layout>
    <x-slot name="header">
        <h2 class="font-bold text-xl text-gray-800 dark:text-gray-200 leading-tight text-center">
            {{ __('DRUGS STORAGE ') }}
        </h2>
    </x-slot>
    <div class="container">
    <div class="overflow-x-auto overflow-y-auto">
        <table class="min-w-full bg-white border broder-gray-300">
            <thead class="text-white" style="background-color:#203864;">
                <tr>
                    <th class="px-6 py-3 text-left text-sm font-medium uppercase">No</th>
                    <th class="px-6 py-3 text-left text-sm font-medium uppercase">Nama Obat</th>
                    <th class="px-6 py-3 text-left text-sm font-medium uppercase">Deskripsi</th>
                    <th class="px-6 py-3 text-left text-sm font-medium uppercase">Dosis</th>
                    <th class="px-6 py-3 text-left text-sm font-medium uppercase">Efek Samping</th>
                    <th class="px-6 py-3 text-left text-sm font-medium uppercase">Note</th>
                </tr>
            </thead>
            <tbody class="text-gray-700">
                @foreach ($obats as $obat)
                    <tr>
                        <td class="px-6 py-4  border">{{ $obat->id }}</td>
                        <td class="px-6 py-4 border">{{ $obat->nama_obat }}</td>
                        <td class="px-6 py-4 mx-auto border">{{ $obat->deskripsi }}</td>
                        <td class="px-6 py-4 mx-auto border">{{ $obat->dosis }}</td>
                        <td class="px-6 py-4 mx-auto border">{{ $obat->efek_samping }}</td>
                        <td class="px-6 py-4 mx-auto border">{{ $obat->note }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    </div>
    <div class="mt-5 text-center">
        <a href="/dashboard">
            <button class="button-center">BACK</button>
        </a>
    </div>
</x-app-layout>
