<?php

use App\Http\Controllers\ConsultationController;
use App\Http\Controllers\ConsultationHistoryController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DiagnosesController;
use App\Http\Controllers\RecommendMedicController;
use App\Models\ConsultationHistory;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('/auth/login');
});

Route::middleware(['auth', 'verified'])->group(function () {
    // Dashboard
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');

    // Rute Diagnosa
    Route::get('/diagnoses', [DiagnosesController::class, 'index'])->name('diagnoses.index');
    Route::post('/diagnoses/store', [DiagnosesController::class, 'store'])->name('diagnoses.store');

    // Rute Recommended
    Route::get('/recommended', [RecommendMedicController::class, 'index'])->name('recommended.index');
    Route::get('/recommended/DaftarObat', [RecommendMedicController::class, 'DaftarObat'])->name('recommended.DaftarObat');

    // Rute History
    Route::get('/history', [ConsultationHistoryController::class, 'index'])->name('history.index');
    Route::post('/history/storeConsultationHistory', [ConsultationController::class, 'storeConsultationHistory'])->name('history.storeConsultationHistory');
    Route::get('/consultation/{id}', [ConsultationController::class, 'show']);

    // Rute Profile
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
