import defaultTheme from 'tailwindcss/defaultTheme';
import forms from '@tailwindcss/forms';
import theme from 'tailwindcss/defaultTheme';

/** @type {import('tailwindcss').Config} */
export default {
    content: [
        './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
        './storage/framework/views/*.php',
        './resources/views/**/*.blade.php',
    ],

    theme: {
        extend: {
            fontFamily: {
                sans: ['Figtree', ...defaultTheme.fontFamily.sans],
            },
        },
    },

    plugins: [forms],
};
module.exports = {
    content: [
        '.resource/**/*.blade.php',
        './resource/**/*.js',
        './resource/**/*.vue',
    ],
    theme: {
        extend: {
            colors: {
                navy: {
                    800: '#203864',
                },
            },
        },
    },
    plugins: [
        require('tailwind-scrollbar'),
    ],
};