## Sistem Pakar Rekomendasi Obat Flu Singapura
Aplikasi berbasis web untuk membantu mendiagnosa dan merekomdasikan obat berdasarkan penyakit Flu Singapura / Hand, Foot, and Mouth Disease menggunakan Metode **Naive Bayes Classifier**.

Dibuat sebagai bagian dari Proyek Skripsi.
## Sceenshot
![LOGO](public/images/LOGO%20FLUBOT2.png)
![DASHBOARD](public/images/Halaman%20dashboard.png)
![DIAGNOSES](public/images/Halaman%20diagnosis.png)
![HASIL](public/images/Halaman%20hasil%20dan%20recomendasi%20obat.png)
![LOGIN](public/images/Input%20login.png)

## Fitur Utama
- **Form Diagnosa Gejala**: User input gejala yang dialami pasien
- **Perhitungan Naive Bayes**: Sistem Menghitung probabilitas dan memberikan hasil diagnosa
- **Rekomendasi Obat**: Memberikan rekomendasi obat berdasarkan hasil diagnosa
- **Manajemen Data**: CRUD untuk data Gejala,Penyakit, dan Obat
- **Login Admin**: Autentikasi untuk mengelola data sistem

## Tech Stack
- **Framework** : Laravel 10
- **Bahasa** : PHP 8.2
- **Database** : Mysql / phpMyAdmin
- **Fronted** : Blade, Bootstrap 5, JavaScript
- **Server local** : XAMPP
- **Algoritma** : Naive Bayes Classifier

## Cara Install & Menjalankan
1. **Clone Repositaory**
   '''bash
   git clone https://github.com/raydiphan/Project-SKRIPSI.git
2. Install Dependencis
   composer install
   npm install && npm run build
3. Konfigurasi Environment
   Salin file .env.example menjadi .env
   copy .env.exemple .env
   Lalu generate application key
   Setting database di file .env
   DB_DATABASE=db_rekomendasi_obat
   DB_USERNAME=root
   DB_PASSWORD=
4. Migrasi Database
   Buat database kosong
   db_rekomendasi_obat di phpMyAdmin terlebih dahulu
   php artisan migrate --seed
5. Jalankan Server
   php artisan serve
   Buka dibrowser:http://127.0.0.1:8000

## AUTHOR
**RAYDIPHAN**
- Github : @raydiphan
- Instagram : raydiphan31

## Lisensi
Project ini dibuat untuk keperluan akademik.
