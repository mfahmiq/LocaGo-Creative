<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Hooks
| -------------------------------------------------------------------------
| This file lets you define "hooks" to extend CI without hacking the core
| files.  Please see the user guide for info:
|
|	https://codeigniter.com/user_guide/general/hooks.html
|
*/

// compress output
$hook['display_override'][] = array(
	'class'	   => '',
	'function' => 'compress',
	'filename' => 'compress.php',
	'filepath' => 'hooks'
);

// maintenance mode
$hook['pre_system'][] = array(
    'class'    => 'maintenance',
    'function' => 'offline',
    'filename' => 'maintenance.php',
    'filepath' => 'hooks'
);