<?Php

session_start();
if(!isset($_SESSION['email']))
{
die(include('../user/error.html'));
}
require('../pdf/fpdf.php');
function connectDB()
{
    $appConfig = require __DIR__ . '/../config/app.php';
    $host = $appConfig['db']['host'];
    $username = $appConfig['db']['user'];
    $password = $appConfig['db']['pass'];
    $dbname = $appConfig['db']['name'];

    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
}

function getAdminData()
{
    $conn = connectDB();
    $stmt = $conn->prepare("select name,email,mobile from admins where email='$_SESSION[email]'");
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $result;
}

function getDuesData()
{
    $conn = connectDB();
    $stmt = $conn->prepare("select issued_books.book_name,issued_books.book_author,issued_books.book_no,issued_books.s_no,issued_books.dues_status,users.name,users.id,datediff(current_date,adddate(issued_books.issue_date,30)) as dues from issued_books left join users on issued_books.student_id = users.id where current_date > adddate(issued_books.issue_date,30)");
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $result;
}


$pdf = new FPDF();
$pdf->AddPage();
// $pdf->Image('../images/pdf_logo.png', 0, -1, 90);
// $pdf->Ln(5);
// Set line width
$pdf->SetLineWidth(0.5);

// Draw a line
$pdf->Line(10, 10, 100, 10);
$pdf->SetFont('Arial', 'B', 13);
$pdf->SetFillColor(4, 216, 209); // Set background color
$pdf->Cell(0, 10, 'Library Management System', 1, 1, 'C', true); // Add 'true' parameter to fill the background
$pdf->Ln(3);


$userList = getAdminData();
$pdf->Ln(6);

$pdf->SetFont('Arial', 'B', 12);
$pdf->SetFillColor(129,219,153); // Set background color
$pdf->Cell(0, 10, 'Your Profile', 1, 1, 'C', true); // Add 'true' parameter to fill the background
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(95, 10, 'Name: ', 1, 0, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(95, 10, $userList[0]['name'], 1, 1, 'C');
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(95, 10, 'Email ID: ', 1, 0, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(95, 10, $userList[0]['email'], 1, 1, 'C');
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(95, 10, 'Mobile NO: ', 1, 0, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(95, 10, $userList[0]['mobile'], 1, 1, 'C');


$pdf->SetLineWidth(0.5);

// Draw a line
$pdf->Line(10, 10, 100, 10);
$pdf->Ln(10);

$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 14); // Set font to bold and increase font size
$pdf->SetFillColor(200, 200, 200); // Set background color for title
$pdf->Cell(0, 10, 'Available Books', 1, 1, 'C', true); // Add 'true' parameter to fill the background
$pdf->SetFont('Arial', '', 12); // Reset font to regular
$pdf->Ln(3);
$pdf->AliasNbPages();

$pdf->SetFont('Arial', '', 12);

$duesList = getDuesData();
$pdf->SetFillColor(236, 229,14);
$pdf->Cell(65, 10, 'Book Name', 1,0,'C',true); 
$pdf->Cell(30, 10, 'Book Author', 1,0,'C',true); 
$pdf->Cell(35, 10, 'Student Name', 1,0,'C',true); 
$pdf->Cell(30, 10, 'Roll Number', 1,0,'C',true); 
$pdf->Cell(15, 10, 'Dues', 1,0,'C',true); 
$pdf->Cell(15, 10, 'Status', 1,0,'C',true);
$pdf->SetFillColor(236, 229,14);
$pdf->Ln();

foreach ($duesList as $dues) {

    $pdf->Cell(65, 10, $dues['book_name'], 1);
    $pdf->Cell(30, 10, $dues['book_author'], 1);
  
    $pdf->Cell(35, 10, $dues['name'], 1);
    $pdf->Cell(30, 10, $dues['id'], 1);
    $pdf->Cell(15, 10, $dues['dues'], 1);
    $pdf->Cell(15, 10, $dues['dues_status'], 1);
    $pdf->Ln();
}
$pdf->Output('Not Returned Books List.pdf', 'I');
?>
