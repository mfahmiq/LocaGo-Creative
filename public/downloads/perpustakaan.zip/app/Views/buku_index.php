<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Perpustakaan Digital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar-brand {
            font-weight: 700;
            letter-spacing: 0.5px;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
        .cover-img {
            width: 50px;
            height: 70px;
            object-fit: cover;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.15);
        }
        .pagination a, .pagination span {
            padding: 6px 12px;
            margin: 0 2px;
            border-radius: 5px;
            text-decoration: none;
            border: 1px solid #dee2e6;
            color: #0d6efd;
        }
        .pagination .active span, .pagination a:hover {
            background-color: #0d6efd;
            color: #fff;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm mb-4">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url('index.php/buku') ?>">
                <i class="fa-solid fa-book-open me-2"></i>Perpustakaan Digital
            </a>
            <div class="d-flex align-items-center text-white">
                <span class="me-3"><i class="fa-solid fa-user-circle me-1"></i> Halo, <b><?= session()->get('nama_lengkap') ?></b></span>
                <a href="<?= base_url('index.php/auth/logout') ?>" class="btn btn-outline-light btn-sm" onclick="return confirm('Apakah Anda yakin ingin logout?');">
                    <i class="fa-solid fa-right-from-bracket me-1"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container pb-5">
        
        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i><?= session()->getFlashdata('success') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card mb-4">
            <div class="card-header bg-white py-3">
                <h5 class="card-title mb-0 text-primary fw-bold">
                    <i class="fa-solid fa-plus-circle me-2"></i>Tambah Buku Baru
                </h5>
            </div>
            <div class="card-body">
                <form action="<?= base_url('index.php/buku/create') ?>" method="post" enctype="multipart/form-data">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label font-semibold">Judul Buku</label>
                            <input type="text" name="judul" class="form-control" placeholder="Judul Buku" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label font-semibold">Penulis</label>
                            <input type="text" name="penulis" class="form-control" placeholder="Penulis" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label font-semibold">Penerbit</label>
                            <input type="text" name="penerbit" class="form-control" placeholder="Penerbit">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label font-semibold">Tahun Terbit</label>
                            <input type="number" name="tahun_terbit" class="form-control" placeholder="2026">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label font-semibold">Cover Buku</label>
                            <input type="file" name="cover" class="form-control" accept="image/*">
                        </div>
                        <div class="col-12 d-flex justify-content-end mt-3">
                            <button type="submit" class="btn btn-primary px-4">
                                <i class="fa-solid fa-save me-1"></i> Simpan Buku
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center flex-wrap">
                <h5 class="card-title mb-0 text-primary fw-bold">
                    <i class="fa-solid fa-list me-2"></i>Daftar Koleksi Buku
                </h5>
                
                <form action="<?= base_url('index.php/buku') ?>" method="get" class="d-flex mt-2 mt-md-0" style="max-width: 350px;">
                    <div class="input-group">
                        <input type="text" name="keyword" class="form-control" value="<?= esc($keyword ?? '') ?>" placeholder="Cari judul / penulis...">
                        <button class="btn btn-outline-primary" type="submit">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </button>
                        <?php if (!empty($keyword)): ?>
                            <a href="<?= base_url('index.php/buku') ?>" class="btn btn-outline-secondary" title="Reset">
                                <i class="fa-solid fa-xmark"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="text-center" style="width: 50px;">No</th>
                                <th class="text-center" style="width: 80px;">Cover</th>
                                <th>Judul Buku</th>
                                <th>Penulis</th>
                                <th>Penerbit</th>
                                <th class="text-center">Tahun</th>
                                <th class="text-center" style="width: 120px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($buku) && is_array($buku)): ?>
                                <?php $i = 1; foreach ($buku as $b): ?>
                                <tr>
                                    <td class="text-center fw-bold text-secondary"><?= $i++ ?></td>
                                    <td class="text-center">
                                        <img src="<?= base_url('uploads/' . esc($b['cover'])) ?>" alt="Cover Buku" class="cover-img" onerror="this.src='<?= base_url('uploads/default.jpg') ?>'">
                                    </td>
                                    <td class="fw-semibold">
                                     <a href="<?= site_url('buku/detail/' . $b['id']) ?>" class="text-decoration-none text-primary" title="Lihat Detail Buku">
                                    <?= esc($b['judul']) ?>
                                    </a>
                                    </td>
                                    <td><span class="badge bg-info text-dark me-1"><i class="fa-solid fa-pen-nib"></i></span> <?= esc($b['penulis']) ?></td>
                                    <td><?= esc($b['penerbit']) ?></td>
                                    <td class="text-center"><span class="badge bg-secondary"><?= esc($b['tahun_terbit']) ?></span></td>
                                    <td class="text-center">
                                        <a href="<?= base_url('index.php/buku/delete/' . $b['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus buku ini?');">
                                            <i class="fa-solid fa-trash me-1"></i> Hapus
                                        </a>
                                        <!-- Mengirimkan ID buku ke halaman edit -->
                                        <a href="<?= site_url('buku/edit/' . $b['id']) ?>" class="btn btn-warning btn-sm">
                                         <i class="fa-solid fa-edit me-1"></i> Edit
                                    </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4 text-muted">
                                        <i class="fa-solid fa-folder-open fa-2x mb-2 d-block"></i>
                                        Data buku tidak ditemukan.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card-footer bg-white py-3 d-flex justify-content-end">
                <div class="pagination mb-0">
                    <?= isset($pager) ? $pager->links('buku') : '' ?>
                </div>
            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>