<?php
$buku = $buku ?? [
    'id' => '',
    'judul' => '',
    'penulis' => '',
    'penerbit' => '',
    'tahun_terbit' => '',
    'cover' => 'default.jpg',
    'sinopsis' => '',
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Buku - <?= esc($buku['judul'] ?? '') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body style="background-color: #f8f9fa;">

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm mb-4">
        <div class="container">
            <a class="navbar-brand" href="<?= site_url('buku') ?>">
                <i class="fa-solid fa-book-open me-2"></i>Perpustakaan Digital
            </a>
        </div>
    </nav>

    <div class="container pb-5" style="max-width: 900px;">
        
        <div class="mb-3">
            <a href="<?= site_url('buku') ?>" class="btn btn-outline-secondary btn-sm">
                <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Daftar Buku
            </a>
        </div>

        <?php if (session()->getFlashdata('success')): ?>
            <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i><?= session()->getFlashdata('success') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card shadow-sm border-0 rounded-3">
            <div class="card-body p-4">
                <div class="row">
                    <!-- Sisi Kiri: Cover Buku -->
                    <div class="col-md-4 text-center mb-4 mb-md-0">
                        <img src="<?= base_url('uploads/' . esc($buku['cover'])) ?>" class="img-fluid rounded shadow" style="max-height: 350px; object-fit: cover;" alt="Cover Buku" onerror="this.src='<?= base_url('uploads/default.jpg') ?>'">
                    </div>
                    
                    <!-- Sisi Kanan: Informasi & Sinopsis -->
                    <div class="col-md-8">
                        <h2 class="fw-bold text-dark mb-1"><?= esc($buku['judul']) ?></h2>
                        <p class="text-muted mb-4"><i class="fa-solid fa-pen-nib me-1"></i> Oleh <b><?= esc($buku['penulis']) ?></b></p>
                        
                        <table class="table table-borderless table-sm mb-4">
                            <tbody>
                                <tr>
                                    <td class="text-muted" style="width: 120px;">Penerbit</td>
                                    <td class="fw-semibold">: <?= esc($buku['penerbit'] ?? '-') ?></td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Tahun Terbit</td>
                                    <td class="fw-semibold">: <span class="badge bg-secondary"><?= esc($buku['tahun_terbit'] ?? '-') ?></span></td>
                                </tr>
                            </tbody>
                        </table>

                        <hr>

                        <!-- Form Edit Sinopsis -->
                        <form action="<?= site_url('buku/updatesinopsis/' . $buku['id']) ?>" method="post">
                            <div class="mb-3">
                                <label class="form-label fw-bold text-primary">
                                    <i class="fa-solid fa-align-left me-1"></i> Sinopsis Singkat
                                </label>
                                <textarea name="sinopsis" class="form-control" rows="5" placeholder="Tuliskan sinopsis singkat buku ini di sini..."><?= esc($buku['sinopsis']) ?></textarea>
                            </div>
                            <div class="d-flex justify-content-end">
                                <button type="submit" class="btn btn-success">
                                    <i class="fa-solid fa-save me-1"></i> Simpan Sinopsis
                                </button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>