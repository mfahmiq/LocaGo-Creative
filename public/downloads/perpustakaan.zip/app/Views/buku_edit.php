<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body style="background-color: #f8f9fa;">
    <div class="container mt-5" style="max-width: 600px;">
        <div class="card shadow-sm border-0 rounded-3">
            <div class="card-header bg-white py-3">
                <h5 class="mb-0 text-primary fw-bold">
                    <i class="fa-solid fa-pen-to-square me-2"></i>Edit Data Buku
                </h5>
            </div>
            <div class="card-body">
                <!-- Aksi form mengarah ke rute proses update dengan POST -->
                <form action="<?= site_url('buku/update/' . ($buku['id'] ?? '')) ?>" method="post" enctype="multipart/form-data">
                    
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Judul Buku</label>
                        <input type="text" name="judul" class="form-control" value="<?= esc($buku['judul'] ?? '') ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Penulis</label>
                        <input type="text" name="penulis" class="form-control" value="<?= esc($buku['penulis'] ?? '') ?>" required>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Penerbit</label>
                            <input type="text" name="penerbit" class="form-control" value="<?= esc($buku['penerbit'] ?? '') ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Tahun Terbit</label>
                            <input type="number" name="tahun_terbit" class="form-control" value="<?= esc($buku['tahun_terbit'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold">Ganti Cover Buku</label>
                        <div class="d-flex align-items-center mb-2">
                            <img src="<?= base_url('uploads/' . esc($buku['cover'] ?? '')) ?>" class="rounded me-3 border" style="width: 50px; height: 70px; object-fit: cover;" alt="Cover Saat Ini">
                            <span class="text-muted small">Biarkan kosong jika tidak ingin mengganti cover.</span>
                        </div>
                        <input type="file" name="cover" class="form-control" accept="image/*">
                    </div>
                    
                    <div class="d-flex justify-content-end">
                        <a href="<?= site_url('buku') ?>" class="btn btn-outline-secondary me-2">Batal</a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fa-solid fa-save me-1"></i> Simpan Perubahan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>