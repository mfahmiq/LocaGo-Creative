<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */

// Rute default saat web pertama kali dibuka, langsung arahkan ke halaman Login
$routes->get('/', 'Auth::index');

// --- Rute untuk Penanganan Session (Auth / Login) ---
$routes->get('/auth', 'Auth::index');
$routes->post('/auth/loginProcess', 'Auth::loginProcess');
$routes->get('/auth/logout', 'Auth::logout');

// --- Rute untuk Fitur Perpustakaan (Buku) ---
$routes->get('/buku', 'Buku::index');
$routes->post('/buku/create', 'Buku::create');
$routes->get('/buku/delete/(:num)', 'Buku::delete/$1');
$routes->get('/buku/edit/(:num)', 'Buku::edit/$1');
$routes->post('/buku/update/(:num)', 'Buku::update/$1');
$routes->get('/buku/detail/(:num)', 'Buku::detail/$1');
$routes->post('/buku/updatesinopsis/(:num)', 'Buku::updateSinopsis/$1');