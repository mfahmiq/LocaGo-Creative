<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function index()
    {
        // Pastikan penulisan URL-nya menggunakan index.php/ agar tidak nyasar
        if (session()->get('isLoggedIn')) {
            return redirect()->to(base_url('index.php/buku'));
        }
        
        return view('login');
    }
    public function loginProcess()
    {
        $session = session();
        $userModel = new UserModel();

        $username = $this->request->getPost('username');
        $password = md5($this->request->getPost('password')); 

        $user = $userModel->where('username', $username)
                          ->where('password', $password)
                          ->first();

        if ($user) {
            $ses_data = [
                'id'           => $user['id'],
                'username'     => $user['username'],
                'nama_lengkap' => $user['nama_lengkap'],
                'isLoggedIn'   => true,
            ];
            
            // Simpan session
            $session->set($ses_data);
            
            // Gunakan base_url() untuk redirect agar rutenya absolut
            return redirect()->to(base_url('buku'));
        } else {
            $session->setFlashdata('error', 'Username atau Password salah!');
            return redirect()->to(base_url('auth'));
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to(base_url('auth'));
    }
}