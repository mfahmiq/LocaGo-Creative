<?php

namespace App\Controllers;

use App\Models\BukuModel;

class Buku extends BaseController
{
    protected $bukuModel;

    public function __construct()
    {
        $this->bukuModel = new BukuModel();
    }

    public function index()
    {
        // Pengecekan session
        if (!session()->get('isLoggedIn')) {
            return redirect()->to(base_url('index.php/auth'));
        }
        // Fitur Pencarian
        $keyword = $this->request->getGet('keyword');
        if ($keyword) {
            $bukuData = $this->bukuModel->like('judul', $keyword)->orLike('penulis', $keyword);
        } else {
            $bukuData = $this->bukuModel;
        }

        // Pagination
        $data = [
            'buku'    => $bukuData->paginate(5, 'buku'),
            'pager'   => $this->bukuModel->pager,
            'keyword' => $keyword
        ];

        return view('buku_index', $data);
    }

    public function create()
    {
        // Pengecekan session
        if (!session()->get('isLoggedIn')) {
            return redirect()->to(base_url('auth'));
        }

        // 1. Ambil file cover dari form
        $fileCover = $this->request->getFile('cover');

        // 2. Cek apakah ada file gambar yang diunggah
        if ($fileCover && $fileCover->isValid() && !$fileCover->hasMoved()) {
            // Generate nama file unik baru
            $namaCover = $fileCover->getRandomName();
            // Pindahkan file ke folder 'uploads' di dalam direktori public/
            $fileCover->move(FCPATH . 'uploads', $namaCover);
        } else {
            // Jika tidak upload gambar, gunakan gambar default
            $namaCover = 'default.jpg';
        }

        // 3. Simpan data ke database
        $this->bukuModel->save([
            'judul'        => $this->request->getPost('judul'),
            'penulis'      => $this->request->getPost('penulis'),
            'penerbit'     => $this->request->getPost('penerbit'),
            'tahun_terbit' => $this->request->getPost('tahun_terbit'),
            'cover'        => $namaCover
        ]);

        session()->setFlashdata('success', 'Data buku beserta cover berhasil ditambahkan!');
        
        return redirect()->to(base_url('buku'));
    }

    public function delete($id = null)
    {
        // Pengecekan session
        if (!session()->get('isLoggedIn')) {
            return redirect()->to(base_url('auth'));
        }

        // Ambil data buku untuk menghapus gambar sampulnya dari server
        $buku = $this->bukuModel->find($id);

       if ($buku) {
            // Hapus file fisik gambar jika bukan gambar default dan nama file tidak kosong
            if (!empty($buku['cover']) && $buku['cover'] != 'default.jpg' && file_exists(FCPATH . 'uploads/' . $buku['cover'])) {
                unlink(FCPATH . 'uploads/' . $buku['cover']);
            }

            // Hapus data dari database
            $this->bukuModel->delete($id);
            session()->setFlashdata('success', 'Data buku berhasil dihapus!');
        }

        return redirect()->to(base_url('buku'));
    }
    public function edit($id = null)
    {
        // Pengecekan session
        if (!session()->get('isLoggedIn')) {
            return redirect()->to(site_url('auth'));
        }

        // Ambil data buku berdasarkan ID
        $buku = $this->bukuModel->find($id);

        // Jika buku tidak ditemukan, lempar kembali ke halaman utama
        if (!$buku) {
            session()->setFlashdata('error', 'Data buku tidak ditemukan!');
            return redirect()->to(site_url('buku'));
        }

        $data = [
            'buku' => $buku
        ];

        return view('buku_edit', $data);
    }

    public function update($id = null)
    {
        // Pengecekan session
        if (!session()->get('isLoggedIn')) {
            return redirect()->to(site_url('auth'));
        }

        // Ambil data cover baru jika ada
        $fileCover = $this->request->getFile('cover');
        $bukuLama = $this->bukuModel->find($id);
        $namaCover = $bukuLama['cover']; // Default gunakan nama cover lama

        // Cek apakah ada file gambar baru yang diunggah
        if ($fileCover && $fileCover->isValid() && !$fileCover->hasMoved()) {
            $namaCover = $fileCover->getRandomName();
            $fileCover->move(FCPATH . 'uploads', $namaCover);

            // Hapus cover lama dari folder (jika bukan default.jpg)
            if (!empty($bukuLama['cover']) && $bukuLama['cover'] != 'default.jpg' && file_exists(FCPATH . 'uploads/' . $bukuLama['cover'])) {
                unlink(FCPATH . 'uploads/' . $bukuLama['cover']);
            }
        }

        // Simpan pembaruan data ke database
        $this->bukuModel->update($id, [
            'judul'        => $this->request->getPost('judul'),
            'penulis'      => $this->request->getPost('penulis'),
            'penerbit'     => $this->request->getPost('penerbit'),
            'tahun_terbit' => $this->request->getPost('tahun_terbit'),
            'cover'        => $namaCover
        ]);

        session()->setFlashdata('success', 'Data buku berhasil diperbarui!');
        return redirect()->to(site_url('buku'));
    }
    public function detail($id = null)
    {
        // Pengecekan session
        if (!session()->get('isLoggedIn')) {
            return redirect()->to(site_url('auth'));
        }

        // Cari data buku spesifik berdasarkan ID
        $buku = $this->bukuModel->find($id);

        // Jika buku tidak ditemukan, kembalikan ke halaman index
        if (!$buku) {
            session()->setFlashdata('error', 'Buku tidak ditemukan.');
            return redirect()->to(site_url('buku'));
        }

        $data = [
            'buku' => $buku
        ];

        // Tampilkan halaman detail
        return view('buku_detail', $data);
    }

    public function updateSinopsis($id = null)
    {
        // Pengecekan session
        if (!session()->get('isLoggedIn')) {
            return redirect()->to(site_url('auth'));
        }

        // Simpan sinopsis baru ke database
        $this->bukuModel->update($id, [
            'sinopsis' => $this->request->getPost('sinopsis')
        ]);

        session()->setFlashdata('success', 'Sinopsis buku berhasil diperbarui!');
        
        // Kembalikan pengguna ke halaman detail tersebut
        return redirect()->to(site_url('buku/detail/' . $id));
    }
}