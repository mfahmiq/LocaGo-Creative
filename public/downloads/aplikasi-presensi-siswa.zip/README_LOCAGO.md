# Sistem Presensi Karyawan & Absensi Online - Aplikasi Presensi Siswa

```
========================================================================
📦 Sistem Presensi Karyawan & Absensi Online - Aplikasi Presensi Siswa
Kategori     : HRD & Keuangan
Tech Stack   : PHP Native • PHP • MySQL
Database     : MySQL (.sql) (File: db_presensi_neswara (2).sql)
Sumber Asli  : https://github.com/0051Nasrulhakim/Aplikasi_presensi_siswa (GitHub Open Source)
Stars GitHub : ⭐ 2 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/aplikasi-presensi-siswa`
     * Untuk Laragon: `C:/laragon/www/aplikasi-presensi-siswa`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `aplikasi_presensi_siswa`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `db_presensi_neswara (2).sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = aplikasi_presensi_siswa

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/aplikasi-presensi-siswa

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
