<?php
require_once "include/auth.php";
require_once "include/conn.php";

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($id) {
    // Hapus data evaluasi terkait terlebih dahulu
    $stmtEval = $db->prepare("DELETE FROM saw_evaluations WHERE id_alternative = ?");
    $stmtEval->bind_param("i", $id);
    $stmtEval->execute();
    $stmtEval->close();

    // Hapus data alternatif
    $stmtAlt = $db->prepare("DELETE FROM saw_alternatives WHERE id_alternative = ?");
    $stmtAlt->bind_param("i", $id);
    $stmtAlt->execute();
    $stmtAlt->close();
}

header("location:./alternatif.php");
exit();
?>
