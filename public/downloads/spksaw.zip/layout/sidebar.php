<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
        <div class="sidebar-header">
            <div class="d-flex justify-content-between">
                <div class="logo">
                    <a href="./" style="font-size: 1.1rem; font-weight: 800; color: #435EBE;">SPK JURUSAN</a>
                </div>
                <div class="toggler">
                    <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                </div>
            </div>
        </div>
        <div class="sidebar-menu">
            <ul class="menu">
                <li class="sidebar-item">
                    <a href="./" class='sidebar-link' style="color: #435EBE;">
                        <i class="bi bi-grid-1x2-fill" style="color: #435EBE;"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                <li class="sidebar-item has-sub">
                    <a href="#" class='sidebar-link' style="color: #435EBE;">
                        <i class="bi bi-mortarboard-fill" style="color: #435EBE;"></i>
                        <span>Data Master</span>
                    </a>
                    <ul class="submenu">
                        <li class="submenu-item">
                            <a href="alternatif.php"><i class="bi bi-book-half" style="color: #435EBE;"></i><span style="margin-left: 8px; color: #435EBE;">Jurusan (Alternatif)</span></a>
                        </li>
                        <li class="submenu-item">
                            <a href="bobot.php"><i class="bi bi-sliders" style="color: #435EBE;"></i><span style="margin-left: 8px; color: #435EBE;">Kriteria &amp; Bobot</span></a>
                        </li>
                    </ul>
                </li>

                <li class="sidebar-item">
                    <a href="matrik.php" class='sidebar-link' style="color: #435EBE;">
                        <i class="bi bi-table" style="color: #435EBE;"></i>
                        <span>Matriks Keputusan</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="preferensi.php" class='sidebar-link' style="color: #435EBE;">
                        <i class="bi bi-award-fill" style="color: #435EBE;"></i>
                        <span>Hasil Rekomendasi</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="logout.php" class='sidebar-link' style="color: #dc3545;">
                        <i class="bi bi-box-arrow-left" style="color: #dc3545;"></i>
                        <span style="color: #dc3545;">Logout</span>
                    </a>
                </li>

            </ul>
        </div>
        <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
    </div>
</div>
