<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p><strong>SPK Pemilihan Jurusan Kuliah</strong> &bull; Metode Simple Additive Weighting (SAW)</p>
        </div>
        <div class="float-end">
            <p>
                &copy; <span id="year"></span> 
                Tugas Kelompok 6 &bull; Sistem Informasi
            </p>
        </div>
    </div>
</footer>

<script>
    // Set current year
    const yearElem = document.getElementById('year');
    if (yearElem) {
        yearElem.textContent = new Date().getFullYear();
    }
</script>