<?php
require_once "include/auth.php";
require_once "include/conn.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $criteria = trim($_POST['criteria'] ?? '');
    $weight = filter_input(INPUT_POST, 'weight', FILTER_VALIDATE_FLOAT);
    $attribute = trim($_POST['attribute'] ?? 'benefit');

    if (!empty($criteria) && $weight !== false && in_array($attribute, ['benefit', 'cost'])) {
        $stmt = $db->prepare("INSERT INTO saw_criterias (criteria, weight, attribute) VALUES (?, ?, ?)");
        $stmt->bind_param("sds", $criteria, $weight, $attribute);
        $stmt->execute();
        $stmt->close();
    }
}

header("location:./bobot.php");
exit();
?>
