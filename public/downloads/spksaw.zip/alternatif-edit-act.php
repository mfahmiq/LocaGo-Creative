<?php
require_once "include/auth.php";
require_once "include/conn.php";

$id = filter_input(INPUT_POST, 'id_alternative', FILTER_VALIDATE_INT);
$name = trim($_POST['name'] ?? '');

if ($id && !empty($name)) {
    $stmt = $db->prepare("UPDATE saw_alternatives SET name = ? WHERE id_alternative = ?");
    $stmt->bind_param("si", $name, $id);
    $stmt->execute();
    $stmt->close();
}

header("location:./alternatif.php");
exit();
?>
