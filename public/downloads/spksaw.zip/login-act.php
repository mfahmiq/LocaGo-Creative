<?php
require "include/conn.php";
session_start();

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if (empty($username) || empty($password)) {
    header("location:login.php?error=empty");
    exit();
}

// Gunakan Prepared Statement untuk mencegah SQL Injection
$stmt = $db->prepare("SELECT id_user, username, password FROM saw_users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($user = $result->fetch_object()) {
    $isValid = false;
    
    // Cek password hash (Bcrypt modern) atau MD5 lama
    if (password_verify($password, $user->password)) {
        $isValid = true;
    } elseif ($user->password === md5($password)) {
        $isValid = true;
        // Upgrade otomatis hash MD5 ke BCRYPT modern
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        $upd = $db->prepare("UPDATE saw_users SET password = ? WHERE id_user = ?");
        $upd->bind_param("si", $newHash, $user->id_user);
        $upd->execute();
        $upd->close();
    }

    if ($isValid) {
        session_regenerate_id(true);
        $_SESSION['id_user'] = $user->id_user;
        $_SESSION['username'] = $user->username;
        $_SESSION['status'] = "login";
        header("location:index.php");
        exit();
    }
}

$stmt->close();
header("location:login.php?error=invalid");
exit();
?>
