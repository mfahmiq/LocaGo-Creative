<!DOCTYPE html>
<html lang="id">
<?php
require "layout/head.php";
require "include/conn.php";
?>

<body>
    <div id="app">
        <?php require "layout/sidebar.php"; ?>
        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                </a>
            </header>
            <div class="page-heading">
                <h3 style="color: #435EBE;">Data Alternatif Jurusan Kuliah</h3>
                <p class="text-subtitle text-muted">Daftar program studi dan perguruan tinggi yang dievaluasi sebagai opsi rekomendasi bagi siswa SMA.</p>
            </div>
            <div class="page-content">
                <section class="row">
                    <div class="col-12">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                <h5 class="card-title mb-0">Tabel Alternatif Jurusan ($A_i$)</h5>
                                <button type="button" class="btn btn-primary btn-sm shadow" data-bs-toggle="modal" data-bs-target="#inlineForm">
                                    <i class="bi bi-plus-circle me-1"></i> Tambah Jurusan
                                </button>
                            </div>
                            <div class="card-body mt-3">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover mb-0" style="width: 100%; font-size: 14px;">
                                        <thead style="background-color: #435EBE; color: #fff;">
                                            <tr>
                                                <th style="width: 80px; text-align: center;">No</th>
                                                <th style="width: 100px; text-align: center;">Kode</th>
                                                <th>Nama Jurusan &amp; Universitas</th>
                                                <th style="width: 150px; text-align: center;">Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $sql = 'SELECT id_alternative, name FROM saw_alternatives ORDER BY id_alternative ASC';
                                            $result = $db->query($sql);
                                            $i = 0;
                                            while ($row = $result->fetch_object()) {
                                                $i++;
                                                $safe_name = htmlspecialchars($row->name, ENT_QUOTES, 'UTF-8');
                                                echo "<tr>
                                                    <td class='text-center'>{$i}</td>
                                                    <td class='text-center font-bold'>A<sub>{$i}</sub></td>
                                                    <td><strong>{$safe_name}</strong></td>
                                                    <td class='text-center'>
                                                        <a href='alternatif-edit.php?id={$row->id_alternative}' class='btn btn-outline-info btn-sm me-1'><i class='bi bi-pencil'></i> Edit</a>
                                                        <a href='alternatif-hapus.php?id={$row->id_alternative}' onclick=\"return confirm('Yakin ingin menghapus jurusan {$safe_name}?');\" class='btn btn-outline-danger btn-sm'><i class='bi bi-trash'></i> Hapus</a>
                                                    </td>
                                                </tr>";
                                            }
                                            $result->free();
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <?php require "layout/footer.php"; ?>
        </div>
    </div>

    <!-- Modal Tambah Jurusan -->
    <div class="modal fade text-left" id="inlineForm" tabindex="-1" role="dialog" aria-labelledby="modalTambahLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title text-white" id="modalTambahLabel">Tambah Pilihan Jurusan Kuliah</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="alternatif-simpan.php" method="POST">
                    <div class="modal-body">
                        <div class="form-group mb-3">
                            <label class="form-label font-bold">Nama Program Studi &amp; Perguruan Tinggi:</label>
                            <input type="text" name="name" placeholder="Contoh: Teknik Informatika UNILA, Ilmu Komputer UI..." class="form-control" required autocomplete="off">
                            <small class="text-muted">Masukkan nama program studi beserta universitasnya.</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Jurusan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php require "layout/js.php"; ?>
</body>

</html>