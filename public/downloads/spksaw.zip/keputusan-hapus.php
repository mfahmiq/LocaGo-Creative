<?php
require_once "include/auth.php";
require_once "include/conn.php";

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($id) {
    $stmt = $db->prepare("DELETE FROM saw_evaluations WHERE id_alternative = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

header("location:./matrik.php");
exit();
?>
