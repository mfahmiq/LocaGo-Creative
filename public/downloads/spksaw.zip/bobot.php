<!DOCTYPE html>
<html lang="id">
<?php
require "layout/head.php";
require "include/conn.php";
?>

<body>
  <div id="app">
    <?php require "layout/sidebar.php"; ?>
    <div id="main">
      <header class="mb-3">
        <a href="#" class="burger-btn d-block d-xl-none">
          <i class="bi bi-justify fs-3"></i>
        </a>
      </header>
      <div class="page-heading">
        <h3 style="color: #435EBE;">Kriteria &amp; Bobot Penilaian</h3>
        <p class="text-subtitle text-muted">Penentuan tingkat kepentingan (bobot) dan sifat atribut setiap kriteria pemilihan jurusan kuliah.</p>
      </div>
      <div class="page-content">
        <section class="row">
          <div class="col-12">
            <div class="card shadow-sm border-0">
              <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Tabel Kriteria Penilaian ($C_j$)</h5>
                <button type="button" class="btn btn-primary btn-sm shadow" data-bs-toggle="modal" data-bs-target="#inlineForm">
                  <i class="bi bi-plus-circle me-1"></i> Tambah Kriteria
                </button>
              </div>
              <div class="card-body mt-3">
                <div class="alert alert-info py-2">
                  <i class="bi bi-info-circle-fill me-2"></i>
                  <strong>Aturan Sifat Kriteria:</strong>
                  <span class="ms-1"><strong>Benefit</strong> (Semakin tinggi nilainya semakin baik, contoh: Nilai Akademik, Minat).</span>
                  <span class="ms-2"><strong>Cost</strong> (Semakin rendah nilainya semakin baik, contoh: Biaya Kuliah).</span>
                </div>

                <div class="table-responsive mt-3">
                  <table class="table table-striped table-hover mb-0" style="width: 100%; font-size: 14px;">
                    <thead style="background-color: #435EBE; color: #fff;">
                      <tr>
                        <th style="width: 70px; text-align: center;">No</th>
                        <th style="width: 90px; text-align: center;">Simbol</th>
                        <th>Nama Kriteria</th>
                        <th style="text-align: center;">Bobot Desimal</th>
                        <th style="text-align: center;">Persentase</th>
                        <th style="text-align: center;">Tipe Atribut</th>
                        <th style="width: 160px; text-align: center;">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $sql = 'SELECT id_criteria, criteria, weight, attribute FROM saw_criterias ORDER BY id_criteria ASC';
                      $result = $db->query($sql);
                      $i = 0;
                      $total_weight = 0;
                      while ($row = $result->fetch_object()) {
                        $i++;
                        $total_weight += (float)$row->weight;
                        $pct = round($row->weight * 100, 1) . '%';
                        $badge_attr = ($row->attribute === 'benefit') 
                            ? '<span class="badge bg-success">Benefit (Keuntungan)</span>' 
                            : '<span class="badge bg-warning text-dark">Cost (Biaya)</span>';
                        $safe_criteria = htmlspecialchars($row->criteria, ENT_QUOTES, 'UTF-8');

                        echo "<tr>
                          <td class='text-center'>{$i}</td>
                          <td class='text-center font-bold'>C<sub>{$i}</sub></td>
                          <td><strong>{$safe_criteria}</strong></td>
                          <td class='text-center'>{$row->weight}</td>
                          <td class='text-center font-bold text-primary'>{$pct}</td>
                          <td class='text-center'>{$badge_attr}</td>
                          <td class='text-center'>
                              <a href='bobot-edit.php?id={$row->id_criteria}' class='btn btn-outline-info btn-sm me-1'><i class='bi bi-pencil'></i> Edit</a>
                              <a href='bobot-hapus.php?id={$row->id_criteria}' onclick=\"return confirm('Yakin ingin menghapus kriteria {$safe_criteria}?');\" class='btn btn-outline-danger btn-sm'><i class='bi bi-trash'></i> Hapus</a>
                          </td>
                        </tr>";
                      }
                      $result->free();
                      ?>
                    </tbody>
                    <tfoot>
                      <tr class="table-light font-bold">
                        <td colspan="3" class="text-end"><strong>Total Bobot Kumulatif:</strong></td>
                        <td class="text-center font-bold"><?= round($total_weight, 2); ?></td>
                        <td class="text-center font-bold text-success"><?= round($total_weight * 100, 1); ?>%</td>
                        <td colspan="2"><small class="text-muted"><?= ($total_weight == 1.0) ? '✅ Normalisasi bobot ideal (100%)' : '⚠️ Total bobot disarankan berjumlah 1.0 (100%)'; ?></small></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
      <?php require "layout/footer.php"; ?>
    </div>
  </div>

  <!-- Modal Tambah Kriteria -->
  <div class="modal fade text-left" id="inlineForm" tabindex="-1" role="dialog" aria-labelledby="modalKriteriaLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title text-white" id="modalKriteriaLabel">Tambah Kriteria Penilaian Baru</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="bobot-simpan.php" method="POST">
          <div class="modal-body">
            <div class="form-group mb-3">
              <label class="form-label font-bold">Nama Kriteria:</label>
              <input type="text" name="criteria" placeholder="Contoh: Akreditasi Prodi, Prospek Karir..." class="form-control" required autocomplete="off">
            </div>
            <div class="form-group mb-3">
              <label class="form-label font-bold">Bobot (dalam desimal 0.01 - 1.00):</label>
              <input type="number" name="weight" step="0.01" min="0.01" max="1" placeholder="Contoh: 0.20 untuk 20%" class="form-control" required>
              <small class="text-muted">Total seluruh bobot kriteria sebaiknya berjumlah 1.00 (100%).</small>
            </div>
            <div class="form-group mb-3">
              <label class="form-label font-bold">Tipe Atribut:</label>
              <select name="attribute" class="form-select" required>
                <option value="benefit">Benefit (Makin besar nilainya makin baik)</option>
                <option value="cost">Cost (Makin kecil nilainya makin baik / biaya)</option>
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" name="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Kriteria</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <?php require "layout/js.php"; ?>
</body>

</html>