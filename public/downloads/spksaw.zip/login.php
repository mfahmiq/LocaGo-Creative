<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SPK Pemilihan Jurusan Kuliah (SAW)</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/vendors/bootstrap-icons/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="assets/css/pages/auth.css">
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">
</head>

<body>
    <div id="auth">
        <div class="container d-flex justify-content-center align-items-center min-vh-100">
            <div class="row border rounded p-3 bg-white shadow box-area">
                <div class="col-md-6 rounded d-flex justify-content-center align-items-center flex-column left-box" style="background: #435EBE;">
                    <div class="featured-image mb-3 text-center">
                        <i class="bi bi-mortarboard-fill text-white" style="font-size: 5rem;"></i>
                    </div>
                    <p class="text-white text-center fs-4 font-bold" style="font-weight: 700;">SPK Jurusan Kuliah</p>
                    <small class="text-white text-center px-3" style="font-size: 13px;">Temukan rekomendasi jurusan kuliah terbaik berdasarkan minat, prestasi akademik, budget, dan lokasi dengan metode SAW.</small>
                </div>

                <div class="col-md-6 right-box">
                    <div class="row align-items-center p-3">
                        <div class="mb-4">
                            <h2>Selamat Datang</h2>
                            <p class="text-muted">Masuk ke Sistem Pendukung Keputusan</p>
                        </div>

                        <?php if (isset($_GET['error'])): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong>Login Gagal!</strong> Username atau password tidak sesuai.
                            </div>
                        <?php endif; ?>

                        <form action="login-act.php" method="post">
                            <div class="form-group position-relative has-icon-left mb-4">
                                <input type="text" class="form-control form-control-xl" placeholder="Username..." name="username" required autocomplete="off">
                                <div class="form-control-icon">
                                    <i class="bi bi-person-circle"></i>
                                </div>
                            </div>
                            <div class="form-group position-relative has-icon-left mb-4">
                                <input type="password" class="form-control form-control-xl" placeholder="Password..." name="password" required>
                                <div class="form-control-icon">
                                    <i class="bi bi-lock"></i>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block btn-lg shadow-lg mt-4">Masuk ke Sistem</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <style>
            @media only screen and (max-width: 768px) {
                .box-area {
                    margin: 0 10px;
                }
                .left-box {
                    padding: 30px 15px;
                }
                .right-box {
                    padding: 20px;
                }
            }
        </style>
    </div>
</body>

</html>