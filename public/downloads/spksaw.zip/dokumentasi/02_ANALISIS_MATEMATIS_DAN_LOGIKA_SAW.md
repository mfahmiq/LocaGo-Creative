# Bagian 2: Analisis Matematis dan Logika Algoritma SAW

## 2.1 Konsep Teori Simple Additive Weighting (SAW)

Metode **Simple Additive Weighting (SAW)** adalah metode pengambilan keputusan multikriteria (*Multi-Criteria Decision Making*) yang mengevaluasi sejumlah alternatif dengan cara menjumlahkan hasil kali nilai kinerja ternormalisasi dengan bobot preferensi dari masing-masing kriteria.

### Persamaan Matematis SAW:

1. **Normalisasi Matriks Keputusan ($R_{ij}$)**:
   $$R_{ij} = \begin{cases} \dfrac{X_{ij}}{\max_i(X_{ij})}, & \text{jika } j \text{ adalah atribut keuntungan (benefit)} \\[1.2em] \dfrac{\min_i(X_{ij})}{X_{ij}}, & \text{jika } j \text{ adalah atribut biaya (cost)} \end{cases}$$
   Di mana:
   - $R_{ij}$ = nilai kinerja ternormalisasi dari alternatif jurusan $A_i$ pada kriteria $C_j$.
   - $X_{ij}$ = nilai awal (skor mentah) alternatif $A_i$ pada kriteria $C_j$.
   - $\max_i(X_{ij})$ = nilai tertinggi dari kriteria $C_j$ di antara seluruh pilihan jurusan.
   - $\min_i(X_{ij})$ = nilai terendah (termurah) dari kriteria $C_j$ di antara seluruh pilihan jurusan.

2. **Perhitungan Nilai Preferensi ($P_i$)**:
   $$P_i = \sum_{j=1}^{n} w_j \cdot R_{ij}$$
   Di mana:
   - $P_i$ = nilai preferensi akhir (skor kesesuaian) untuk pilihan jurusan $A_i$.
   - $w_j$ = tingkat kepentingan atau bobot dari kriteria ke-$j$.
   - Nilai $P_i$ yang lebih tinggi mengindikasikan jurusan yang lebih direkomendasikan untuk siswa.

---

## 2.2 Data Kasus Pemilihan Jurusan Kuliah (Sesuai PPT Kelompok)

### A. Kriteria Penilaian dan Bobot ($W$)
| Simbol | Nama Kriteria | Tipe Atribut | Bobot ($w_j$) | Persentase | Rasionale Penentuan Sifat Atribut |
|:---:|---|:---:|:---:|:---:|---|
| **$C_1$** | **Nilai Akademik** | **Benefit** | **0.40** | **40%** | Semakin tinggi prestasi akademik dan nilai rapor, semakin besar peluang lolos dan sukses. |
| **$C_2$** | **Kesesuaian Minat** | **Benefit** | **0.30** | **30%** | Semakin cocok dengan minat/passion siswa, semakin kecil risiko salah jurusan. |
| **$C_3$** | **Biaya Kuliah** | **Cost** | **0.20** | **20%** | Semakin terjangkau besaran UKT/semester, semakin meringankan beban finansial. |
| **$C_4$** | **Preferensi Lokasi** | **Benefit** | **0.10** | **10%** | Semakin strategis, dekat, atau nyaman lokasinya, semakin tinggi nilai kepuasan. |
| **Total** | | | **1.00** | **100%** | **Total bobot ternormalisasi sempurna** |

### B. Alternatif Pilihan Jurusan Kuliah
| Kode | Nama Program Studi &amp; Perguruan Tinggi | Deskripsi Singkat |
|:---:|---|---|
| **$A_1$** | **Ilmu Komputer UI** | Universitas Indonesia (Depok, Jawa Barat) |
| **$A_2$** | **STEI ITB** | Institut Teknologi Bandung (Bandung, Jawa Barat) |
| **$A_3$** | **Teknik Informatika UNILA** | Universitas Lampung (Bandar Lampung, Lampung) |
| **$A_4$** | **Bisnis Digital UNPAD** | Universitas Padjadjaran (Jatinangor, Jawa Barat) |
| **$A_5$** | **Sistem Informasi ITS** | Institut Teknologi Sepuluh Nopember (Surabaya, Jawa Timur) |

---

## 2.3 Pembuktian Matematis Manual Step-by-Step

### Langkah 1: Membentuk Matriks Keputusan ($X$)

Nilai evaluasi kuantitatif dari kelima alternatif jurusan:
- Nilai Akademik ($C_1$): skala 0–100 (Nilai rapor/prestasi).
- Kesesuaian Minat ($C_2$): skala 0–100 (Skor hasil asesmen psikometri).
- Biaya Kuliah ($C_3$): dalam satuan juta rupiah per semester (UKT).
- Preferensi Lokasi ($C_4$): skala 0–100 (Skor kenyamanan &amp; jarak akomodasi).

$$X = \begin{pmatrix}
X_{11} & X_{12} & X_{13} & X_{14} \\
X_{21} & X_{22} & X_{23} & X_{24} \\
X_{31} & X_{32} & X_{33} & X_{34} \\
X_{41} & X_{42} & X_{43} & X_{44} \\
X_{51} & X_{52} & X_{53} & X_{54}
\end{pmatrix} = \begin{pmatrix}
88.0 & 95.0 & 15.0 & 90.0 \\
85.0 & 85.0 & 12.0 & 80.0 \\
80.0 & 75.0 & 10.0 & 95.0 \\
82.0 & 80.0 & 11.0 & 85.0 \\
84.0 & 82.0 & 13.0 & 82.0
\end{pmatrix}$$

### Langkah 2: Menentukan Nilai Ekstremum (Maksimum & Minimum)
- Kriteria $C_1$ (Benefit): $\max(88, 85, 80, 82, 84) = \mathbf{88.0}$
- Kriteria $C_2$ (Benefit): $\max(95, 85, 75, 80, 82) = \mathbf{95.0}$
- Kriteria $C_3$ (Cost): $\min(15, 12, 10, 11, 13) = \mathbf{10.0}$
- Kriteria $C_4$ (Benefit): $\max(90, 80, 95, 85, 82) = \mathbf{95.0}$

---

### Langkah 3: Menghitung Matriks Ternormalisasi ($R$)

#### A. Alternatif $A_1$ (Ilmu Komputer UI)
- $R_{11} = \frac{88.0}{88.0} = \mathbf{1.0000}$
- $R_{12} = \frac{95.0}{95.0} = \mathbf{1.0000}$
- $R_{13} = \frac{10.0}{15.0} = \frac{2}{3} \approx \mathbf{0.6667}$ *(kriteria cost)*
- $R_{14} = \frac{90.0}{95.0} \approx \mathbf{0.9474}$

#### B. Alternatif $A_2$ (STEI ITB)
- $R_{21} = \frac{85.0}{88.0} \approx \mathbf{0.9659}$
- $R_{22} = \frac{85.0}{95.0} \approx \mathbf{0.8947}$
- $R_{23} = \frac{10.0}{12.0} = \frac{5}{6} \approx \mathbf{0.8333}$ *(kriteria cost)*
- $R_{24} = \frac{80.0}{95.0} \approx \mathbf{0.8421}$

#### C. Alternatif $A_3$ (Teknik Informatika UNILA)
- $R_{31} = \frac{80.0}{88.0} \approx \mathbf{0.9091}$
- $R_{32} = \frac{75.0}{95.0} \approx \mathbf{0.7895}$
- $R_{33} = \frac{10.0}{10.0} = \mathbf{1.0000}$ *(kriteria cost)*
- $R_{34} = \frac{95.0}{95.0} = \mathbf{1.0000}$

#### D. Alternatif $A_4$ (Bisnis Digital UNPAD)
- $R_{41} = \frac{82.0}{88.0} \approx \mathbf{0.9318}$
- $R_{42} = \frac{80.0}{95.0} \approx \mathbf{0.8421}$
- $R_{43} = \frac{10.0}{11.0} \approx \mathbf{0.9091}$ *(kriteria cost)*
- $R_{44} = \frac{85.0}{95.0} \approx \mathbf{0.8947}$

#### E. Alternatif $A_5$ (Sistem Informasi ITS)
- $R_{51} = \frac{84.0}{88.0} \approx \mathbf{0.9545}$
- $R_{52} = \frac{82.0}{95.0} \approx \mathbf{0.8632}$
- $R_{53} = \frac{10.0}{13.0} \approx \mathbf{0.7692}$ *(kriteria cost)*
- $R_{54} = \frac{82.0}{95.0} \approx \mathbf{0.8632}$

Matriks Ternormalisasi $R$:
$$R = \begin{pmatrix}
1.0000 & 1.0000 & 0.6667 & 0.9474 \\
0.9659 & 0.8947 & 0.8333 & 0.8421 \\
0.9091 & 0.7895 & 1.0000 & 1.0000 \\
0.9318 & 0.8421 & 0.9091 & 0.8947 \\
0.9545 & 0.8632 & 0.7692 & 0.8632
\end{pmatrix}$$

---

### Langkah 4: Menghitung Nilai Preferensi ($P_i$)

Vektor Bobot:
$$W = \begin{pmatrix} 0.40 & 0.30 & 0.20 & 0.10 \end{pmatrix}$$

Perhitungan skor akhir preferensi masing-masing alternatif jurusan:

$$P(A_1) = (1.0000 \times 0.40) + (1.0000 \times 0.30) + (0.6667 \times 0.20) + (0.9474 \times 0.10)$$
$$P(A_1) = 0.4000 + 0.3000 + 0.1333 + 0.0947 = \mathbf{0.9280} \quad (\mathbf{92.80\%})$$

$$P(A_2) = (0.9659 \times 0.40) + (0.8947 \times 0.30) + (0.8333 \times 0.20) + (0.8421 \times 0.10)$$
$$P(A_2) = 0.3864 + 0.2684 + 0.1667 + 0.0842 = \mathbf{0.9057} \quad (\mathbf{90.57\%})$$

$$P(A_3) = (0.9091 \times 0.40) + (0.7895 \times 0.30) + (1.0000 \times 0.20) + (1.0000 \times 0.10)$$
$$P(A_3) = 0.3636 + 0.2368 + 0.2000 + 0.1000 = \mathbf{0.9004} \quad (\mathbf{90.04\%})$$

$$P(A_4) = (0.9318 \times 0.40) + (0.8421 \times 0.30) + (0.9091 \times 0.20) + (0.8947 \times 0.10)$$
$$P(A_4) = 0.3727 + 0.2526 + 0.1818 + 0.0895 = \mathbf{0.8966} \quad (\mathbf{89.66\%})$$

$$P(A_5) = (0.9545 \times 0.40) + (0.8632 \times 0.30) + (0.7692 \times 0.20) + (0.8632 \times 0.10)$$
$$P(A_5) = 0.3818 + 0.2590 + 0.1538 + 0.0863 = \mathbf{0.8809} \quad (\mathbf{88.09\%})$$

---

### Langkah 5: Tabel Hasil Perangkingan Akhir Rekomendasi Jurusan

| Peringkat | Kode | Pilihan Program Studi &amp; Universitas | Nilai Preferensi ($P_i$) | Persentase Kecocokan | Status Rekomendasi |
|:---:|:---:|---|:---:|:---:|:---:|
| 🥇 **1** | **$A_1$** | **Ilmu Komputer UI** | **0.9280** | **92.80%** | **Rekomendasi Utama (Terbaik)** |
| 🥈 **2** | **$A_2$** | **STEI ITB** | **0.9057** | **90.57%** | Rekomendasi Alternatif 2 |
| 🥉 **3** | **$A_3$** | **Teknik Informatika UNILA** | **0.9004** | **90.04%** | Rekomendasi Alternatif 3 |
| 4 | **$A_4$** | **Bisnis Digital UNPAD** | **0.8966** | **89.66%** | Pilihan Alternatif 4 |
| 5 | **$A_5$** | **Sistem Informasi ITS** | **0.8809** | **88.09%** | Pilihan Alternatif 5 |

---

## 2.4 Verifikasi Kesesuaian Implementasi Kode

Hasil kalkulasi manual di atas terbukti **100% identik dan konsisten** dengan output yang dihitung oleh berkas [`preferensi.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/preferensi.php) dan [`R.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/R.php).

Kini sistem telah berjalan secara dinamis, sehingga jika guru BK atau admin menambahkan jurusan baru atau kriteria baru, sistem secara otomatis melakukan normalisasi dan perankingan tanpa menimbulkan galat.
