# Bagian 1: Profil Proyek, Arsitektur, dan Inventarisasi Sistem

## 1.1 Profil Proyek dan Latar Belakang
- **Nama Sistem**: Sistem Pendukung Keputusan (SPK) Pemilihan Jurusan Kuliah Siswa SMA Menggunakan Metode Simple Additive Weighting (SAW)
- **Instansi / Mata Kuliah**: Tugas Kelompok 6 &bull; Program Studi Sistem Informasi
- **Tim Pengembang (Kelompok 6)**:
  1. 2415061039 - Ridho Azhari Putra
  2. 2415061059 - Kanaya Traylingga Pratama
  3. 2415061090 - Rifki Yudika Perdana
  4. 2415061XXX - Hengky Kurniawan
  5. 2415061072 - Kadek Dwi Octo Lesa Candigo
  6. 2415061091 - Riffa Yudika Permana

### Latar Belakang Masalah (Sesuai Slide 2 & 3 PPT)
Setiap tahun ribuan siswa SMA menghadapi dilema dalam memilih program studi di perguruan tinggi:
- **70% Siswa Tidak Yakin** dengan pilihan jurusannya saat mendaftar.
- **40% Mahasiswa Merasa Salah Jurusan**, memicu penurunan motivasi kuliah dan prestasi akademik.
- **Wasted Resources**: Pemborosan waktu dan biaya kuliah puluhan juta rupiah.
- **Keterbatasan Fasilitas BK**: Guru BK di sekolah umumnya hanya mampu menangani 5–10 siswa per hari secara tatap muka.

### Solusi Sistem Pendukung Keputusan (DSS)
Aplikasi ini menghadirkan sistem rekomendasi *data-driven* yang menggabungkan 4 parameter utama secara objektif:
1. **Kemampuan Akademik** (prestasi rapor).
2. **Kesesuaian Minat & Bakat** (passion siswa).
3. **Kesesuaian Budget / Biaya Kuliah** (kemampuan finansial).
4. **Preferensi Lokasi** (kenyamanan jarak dan akomodasi).

---

## 1.2 Diagram Alur Arsitektur Sistem

Aplikasi menggunakan arsitektur web client-server dua lapis (*two-tier architecture*):

```mermaid
flowchart TD
    Client["Browser Siswa / Laptop / Smartphone"] -->|Request HTTP| Router["Endpoint PHP (*.php)"]
    
    subgraph Security_Middleware["Security & Auth Layer"]
        AuthCheck["include/auth.php\n(Pengecekan Sesi & Anti-EAR)"]
    end
    
    subgraph Logic_Tier["Business Logic Layer (SAW Engine)"]
        W_Engine["W.php (Vektor Bobot Kriteria)"]
        R_Engine["R.php (Matriks Normalisasi R Dinamis)"]
        Preference_Calc["preferensi.php (Kalkulasi Skor P & Ranking)"]
    end

    subgraph Data_Tier["Storage Layer (MySQL / MariaDB)"]
        DB[(db_saw)]
        T_Users[("saw_users")]
        T_Alts[("saw_alternatives")]
        T_Crits[("saw_criterias")]
        T_Evals[("saw_evaluations")]
    end

    Router --> AuthCheck
    Router --> Logic_Tier
    Logic_Tier --> DB
    T_Users --- DB
    T_Alts --- DB
    T_Crits --- DB
    T_Evals --- DB
```

---

## 1.3 Inventarisasi Berkas Kode Sumber

| Nama Berkas | Lokasi | Peran & Deskripsi dalam Kasus Jurusan Kuliah |
|---|---|---|
| [`index.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/index.php) | Root | Dashboard utama, menampilkan statistik pilihan jurusan, kriteria penilaian, dan alur SAW. |
| [`login.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/login.php) | Root | Antarmuka otentikasi pengguna dan siswa. |
| [`login-act.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/login-act.php) | Root | Pemroses otentikasi login aman menggunakan *Prepared Statements* dan verifikasi *Bcrypt*. |
| [`logout.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/logout.php) | Root | Mengakhiri sesi pengguna (`session_destroy`). |
| [`alternatif.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/alternatif.php) | Root | Pengelolaan data pilihan program studi dan universitas (Alternatif $A_i$). |
| [`alternatif-simpan.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/alternatif-simpan.php) | Root | Menyimpan jurusan baru ke database menggunakan parameter query terproteksi. |
| [`alternatif-edit.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/alternatif-edit.php) | Root | Form pengubahan nama program studi & universitas. |
| [`alternatif-edit-act.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/alternatif-edit-act.php) | Root | Pemroses update data alternatif ke database. |
| [`alternatif-hapus.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/alternatif-hapus.php) | Root | Menghapus alternatif jurusan dan riwayat nilai evaluasinya. |
| [`bobot.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/bobot.php) | Root | Tabel kriteria penilaian jurusan (Akademik 40%, Minat 30%, Biaya 20%, Lokasi 10%). |
| [`bobot-simpan.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/bobot-simpan.php) | Root | Menyimpan kriteria baru dengan validasi float. |
| [`bobot-edit.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/bobot-edit.php) | Root | Form pengubahan bobot dan tipe atribut (Benefit/Cost). |
| [`bobot-edit-act.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/bobot-edit-act.php) | Root | Pemroses update kriteria ke database. |
| [`bobot-hapus.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/bobot-hapus.php) | Root | Menghapus kriteria penilaian beserta nilai evaluasi terkait. |
| [`matrik.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/matrik.php) | Root | Menghitung Matriks Keputusan ($X$), Matriks Normalisasi ($R$), dan input rating kecocokan jurusan. |
| [`matrik-simpan.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/matrik-simpan.php) | Root | Menyimpan nilai evaluasi dengan penanganan `ON DUPLICATE KEY UPDATE`. |
| [`keputusan-hapus.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/keputusan-hapus.php) | Root | Mereset seluruh nilai evaluasi alternatif jurusan tertentu. |
| [`W.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/W.php) | Root | Menghasilkan vektor bobot kriteria ($W$). |
| [`R.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/R.php) | Root | Menghitung matriks normalisasi ($R$) secara dinamis untuk seluruh kriteria jurusan. |
| [`preferensi.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/preferensi.php) | Root | Menghitung skor akhir preferensi ($P$) dan menyajikan ranking rekomendasi jurusan terbaik. |
| [`include/auth.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/include/auth.php) | `include/` | Middleware pengaman sesi login pengguna di seluruh endpoint aplikasi. |
| [`include/conn.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/include/conn.php) | `include/` | Konfigurasi koneksi MySQL Server (`mysqli`). |
| [`layout/*`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/layout/) | `layout/` | Berkas layout modular (`head.php`, `sidebar.php`, `footer.php`, `js.php`). |
| [`db/db_saw.sql`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/db/db_saw.sql) | `db/` | Skrip skema database InnoDB dan data awal jurusan kuliah. |

---

## 1.4 Pemodelan Data dan Relasi Entitas (ERD)

```mermaid
erDiagram
    saw_users {
        int id_user PK
        varchar username
        varchar password
    }

    saw_alternatives {
        smallint id_alternative PK
        varchar name
    }

    saw_criterias {
        tinyint id_criteria PK
        varchar criteria
        float weight
        enum attribute
    }

    saw_evaluations {
        smallint id_alternative PK, FK
        tinyint id_criteria PK, FK
        float value
    }

    saw_alternatives ||--o{ saw_evaluations : "memiliki nilai rating"
    saw_criterias ||--o{ saw_evaluations : "diukur pada kriteria"
```

### Relasi Integritas Data (InnoDb Engine):
- Tabel `saw_evaluations` memiliki Foreign Key ke `saw_alternatives` dan `saw_criterias` dengan klausul `ON DELETE CASCADE ON UPDATE CASCADE`.
- Ketika suatu alternatif jurusan atau kriteria dihapus, nilai evaluasi yang berelasi otomatis dibersihkan oleh DBMS sehingga tidak meninggalkan *orphan records*.
