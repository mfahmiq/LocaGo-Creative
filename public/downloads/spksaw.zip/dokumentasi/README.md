# Dokumentasi Lengkap Sistem Pendukung Keputusan (SPK) Pemilihan Jurusan Kuliah
## Metode Simple Additive Weighting (SAW)
### Tugas Kelompok 6 - Program Studi Sistem Informasi

**Anggota Tim Pengembang:**
1. 2415061039 - Ridho Azhari Putra
2. 2415061059 - Kanaya Traylingga Pratama
3. 2415061090 - Rifki Yudika Perdana
4. 2415061XXX - Hengky Kurniawan
5. 2415061072 - Kadek Dwi Octo Lesa Candigo
6. 2415061091 - Riffa Yudika Permana

---

## 📑 Daftar Berkas Dokumentasi

Sistem ini telah disinkronkan 100% dengan materi presentasi kelompok (**`SISTEM PENDUKUNG KEPUTUSAN PEMILIHAN JURUSAN KULIAH.pptx`** dan **`ISI PPT NYA.pdf`**). Modul-modul dokumentasi berikut merangkum seluruh aspek teknis, matematika, keamanan, dan perbaikan sistem:

| No | Modul Dokumen | Ringkasan Isi |
|---|---|---|
| ⚡ | [**PANDUAN_CEPAT_LARAGON.md**](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/dokumentasi/PANDUAN_CEPAT_LARAGON.md) | **PANDUAN CEPAT (Jejak Singkat)**: 3 langkah menjalankan sistem di Laragon & perintah impor database via Terminal (Opsi A). |
| **00** | [README.md](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/dokumentasi/README.md) | Indeks navigasi dan ringkasan eksekutif sistem SPK Jurusan Kuliah. |
| **01** | [01_PROFIL_DAN_ARSITEKTUR_SISTEM.md](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/dokumentasi/01_PROFIL_DAN_ARSITEKTUR_SISTEM.md) | Profil sistem, latar belakang masalah salah jurusan, arsitektur software, ERD database InnoDB, dan struktur berkas program. |
| **02** | [02_ANALISIS_MATEMATIS_DAN_LOGIKA_SAW.md](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/dokumentasi/02_ANALISIS_MATEMATIS_DAN_LOGIKA_SAW.md) | Landasan teori SAW, data 5 alternatif jurusan (UI, ITB, UNILA, UNPAD, ITS), 4 kriteria (Akademik 40%, Minat 30%, Biaya 20%, Lokasi 10%), serta kalkulasi matematis manual step-by-step. |
| **03** | [03_AUDIT_KEAMANAN_DAN_KERENTANAN.md](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/dokumentasi/03_AUDIT_KEAMANAN_DAN_KERENTANAN.md) | Audit keamanan OWASP Top 10, demonstrasi eksploitasi SQL Injection form login, bypass otentikasi sesi, serta implementasi remedi Prepared Statement & Bcrypt sesuai materi PPT. |
| **04** | [04_TEMUAN_BUG_KUALITAS_KODE_DAN_UI.md](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/dokumentasi/04_TEMUAN_BUG_KUALITAS_KODE_DAN_UI.md) | Pembahasan bug runtime JavaScript (`main.js`), penghapusan skrip grafik yang tidak digunakan, perbaikan form label, dan penanganan tabrakan Primary Key evaluasi. |
| **05** | [05_PANDUAN_REFACTORING_DAN_REKOMENDASI.md](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/dokumentasi/05_PANDUAN_REFACTORING_DAN_REKOMENDASI.md) | Panduan refactoring kode aman, migrasi database InnoDB dengan Foreign Key Cascade, dan checklist pengujian sistem. |
| **Lengkap** | [LAPORAN_LENGKAP_ANALISIS_SPK_SAW.md](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/dokumentasi/LAPORAN_LENGKAP_ANALISIS_SPK_SAW.md) | **Laporan Induk Terintegrasi**: Menggabungkan seluruh bab pembahasan dalam satu dokumen akademik lengkap yang siap dikumpulkan atau dicetak. |

---

## 🎯 Intisari Studi Kasus Pemilihan Jurusan Kuliah

### Kriteria & Bobot Penilaian (Sesuai Slide 4 & 9 PPT)
1. **$C_1$ - Nilai Akademik**: Bobot **40% (0.40)**, Sifat: **Benefit** (Prestasi akademik & nilai rapor).
2. **$C_2$ - Kesesuaian Minat**: Bobot **30% (0.30)**, Sifat: **Benefit** (Kesesuaian bakat & passion siswa).
3. **$C_3$ - Biaya Kuliah**: Bobot **20% (0.20)**, Sifat: **Cost** (Besaran UKT/semester; semakin murah semakin baik).
4. **$C_4$ - Preferensi Lokasi**: Bobot **10% (0.10)**, Sifat: **Benefit** (Jarak, kemudahan akses, & akomodasi).

### Alternatif Pilihan Jurusan Kuliah
1. **$A_1$ - Ilmu Komputer UI**
2. **$A_2$ - STEI ITB**
3. **$A_3$ - Teknik Informatika UNILA**
4. **$A_4$ - Bisnis Digital UNPAD**
5. **$A_5$ - Sistem Informasi ITS**

### Hasil Akhir Perangkingan Rekomendasi
- 🥇 **Peringkat 1**: **Ilmu Komputer UI** ($0.9280$ / $92.80\%$) — **Rekomendasi Utama**
- 🥈 **Peringkat 2**: **STEI ITB** ($0.9057$ / $90.57\%$) — Rekomendasi Alternatif 2
- 🥉 **Peringkat 3**: **Teknik Informatika UNILA** ($0.9004$ / $90.04\%$) — Rekomendasi Alternatif 3
- 4️⃣ **Peringkat 4**: **Bisnis Digital UNPAD** ($0.8966$ / $89.66\%$)
- 5️⃣ **Peringkat 5**: **Sistem Informasi ITS** ($0.8809$ / $88.09\%$)
