# Bagian 4: Analisis Bug Kode, Cacat Antarmuka, dan Solusi Perbaikan

## 4.1 Ringkasan Perbaikan Cacat dan Bug

Selama proses audit dan refactoring sistem, ditemukan 7 masalah non-keamanan yang mencakup kegagalan runtime JavaScript, kesalahan markup HTML, dan cacat antarmuka. Seluruh masalah tersebut kini **telah diperbaiki secara tuntas** di dalam kode sumber aplikasi:

| ID Masalah | Kategori Masalah | Status Awal | Status Terkini |
|:---:|---|:---:|:---:|
| **BUG-01** | Runtime Crash `main.js` (`scrollIntoView`) | Eror Fatal di Konsol Browser | **SOLVED** (Ditambahkan *Null Check*) |
| **BUG-02** | Target Hilang ApexCharts `dashboard.js` | Eror Elemen Grafis Tidak Ditemukan | **SOLVED** (Skrip Berlebih Dibersihkan) |
| **BUG-03** | Duplikasi Tag `<head>` & CSS di `index.php` | Pelanggaran Standar W3C HTML | **SOLVED** (Struktur HTML Dinormalisasi) |
| **BUG-04** | Label Modal Salah ("Login Form") | Teks Cacat Salinan Template | **SOLVED** (Diubah ke "Tambah Jurusan") |
| **BUG-05** | Cacat Pilihan Otomatis di `bobot-edit.php` | Nilai Atribut Berubah Otomatis | **SOLVED** (Ditambahkan Logika `selected`) |
| **BUG-06** | Tabrakan Primary Key di `matrik-simpan.php` | Gagal Update Nilai Evaluasi | **SOLVED** (Memakai `ON DUPLICATE KEY UPDATE`) |
| **BUG-07** | Berkas Sampah `keputusan-simpan.php` | Berkas Kosong 0 Byte | **SOLVED** (Berkas Dihapus Bersih) |

---

## 4.2 Ulasan Detail dan Solusi Teknis Perbaikan

---

### BUG-01: Galat Runtime JavaScript pada `main.js`
- **Gejala Awal**: Konsol browser selalu memunculkan pesan merah:
  `Uncaught TypeError: Cannot read properties of null (reading 'scrollIntoView')`
- **Penyebab**: Baris kode memanggil method `.scrollIntoView(false)` pada elemen `.sidebar-item.active` yang tidak ada di halaman.
- **Solusi yang Diterapkan ([`assets/js/main.js`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/assets/js/main.js#L50-L54))**:
  ```javascript
  const activeSidebarItem = document.querySelector('.sidebar-item.active');
  if (activeSidebarItem) {
      activeSidebarItem.scrollIntoView(false);
  }
  ```
  *Hasil*: Konsol peramban kini bersih dari galat runtime JavaScript.

---

### BUG-02: Kegagalan Inisialisasi Pustaka Grafik Demo (`dashboard.js`)
- **Gejala Awal**: Muncul peringatan ApexCharts karena elemen bagan demo (`#chart-profile-visit`, `#chart-visitors-profile`, dll.) tidak ada di DOM halaman.
- **Solusi yang Diterapkan ([`layout/js.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/layout/js.php))**:
  Menghapus pemanggilan berkas `apexcharts.js` dan `dashboard.js` dari layout global sehingga tidak lagi membebani memori browser.

---

### BUG-03: Duplikasi Tag `<head>` dan Pustaka Ganda di `index.php`
- **Gejala Awal**: Berkas `index.php` membuka tag `<head>` sebanyak dua kali dan memuat pustaka Bootstrap CSS lokal sekaligus dari CDN luar.
- **Solusi yang Diterapkan ([`index.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/index.php))**:
  Menghilangkan tag `<head>` kedua dan impor CDN yang redundan, menyatukan seluruh pengelolaan aset di [`layout/head.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/layout/head.php) sesuai standar W3C.

---

### BUG-04: Cacat Label Judul Modal pada Formulir Tambah Jurusan
- **Gejala Awal**: Saat pengguna mengeklik tombol "Tambah Jurusan", jendela pop-up modal memunculkan judul "Login Form" (bawaan template Mazer).
- **Solusi yang Diterapkan ([`alternatif.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/alternatif.php#L68))**:
  Mengganti teks judul modal menjadi **"Tambah Pilihan Jurusan Kuliah"** dengan formulir yang informatif dan relevan.

---

### BUG-05: Cacat Pilihan Otomatis (*Pre-selected*) pada Form Edit Kriteria
- **Gejala Awal**: Membuka form edit kriteria bertipe *Cost* (Biaya Kuliah) akan otomatis beralih ke *Benefit* jika disimpan tanpa sengaja karena ketiadaan atribut `selected`.
- **Solusi yang Diterapkan ([`bobot-edit.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/bobot-edit.php#L48-L51))**:
  ```html
  <select class="form-select" name="attribute" required>
      <option value="benefit" <?= ($row['attribute'] === 'benefit') ? 'selected' : ''; ?>>Benefit (Makin besar nilainya makin baik)</option>
      <option value="cost" <?= ($row['attribute'] === 'cost') ? 'selected' : ''; ?>>Cost (Makin kecil nilainya makin baik / biaya)</option>
  </select>
  ```

---

### BUG-06: Tabrakan Primary Key saat Menginput Nilai Evaluasi
- **Gejala Awal**: Jika administrator ingin mengoreksi nilai kriteria untuk alternatif yang sudah ada di menu matriks, query gagal dengan pesan galat *Duplicate entry for key PRIMARY*.
- **Solusi yang Diterapkan ([`matrik-simpan.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/matrik-simpan.php#L10-L16))**:
  Menggunakan sintaks SQL `ON DUPLICATE KEY UPDATE`:
  ```sql
  INSERT INTO saw_evaluations (id_alternative, id_criteria, value) 
  VALUES (?, ?, ?) 
  ON DUPLICATE KEY UPDATE value = VALUES(value)
  ```
  *Hasil*: Sistem dapat menyimpan nilai baru maupun memperbarui nilai lama secara mulus tanpa galat.

---

### BUG-07: Pembersihan Berkas Mati (*Dead Code*)
- Berkas kosong berukuran 0 byte `keputusan-simpan.php` telah dihapus dari repositori demi menjaga kebersihan struktur proyek.
