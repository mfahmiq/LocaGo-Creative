# Bagian 5: Panduan Refactoring dan Checklist Pengujian Kualitas (QA)

Dokumen ini merangkum seluruh langkah implementasi teknis yang telah diterapkan pada aplikasi serta menyediakan checklist pengujian (*Quality Assurance Checklist*) untuk memverifikasi kesiapan sistem saat demonstrasi atau penilaian tugas kelompok.

---

## 5.1 Rangkuman Arsitektur Baru yang Diterapkan

1. **Keamanan**:
   - Seluruh endpoint dilindungi oleh `include/auth.php` yang mencegah serangan *Execution After Redirect*.
   - Otentikasi login pada `login-act.php` menggunakan *Prepared Statements* dan algoritma hashing modern **Bcrypt** (`password_hash` dan `password_verify`).
   - Seluruh query CRUD (Tambah, Edit, Hapus) menggunakan parameterisasi `mysqli::prepare` untuk membasmi celah SQL Injection.
   - Output data di seluruh antarmuka disaring dengan `htmlspecialchars` untuk mencegah Cross-Site Scripting (XSS).

2. **Logika Algoritma SAW**:
   - Normalisasi matriks pada `R.php` dan perankingan pada `preferensi.php` telah diubah menjadi **sepenuhnya dinamis**, sehingga mampu menangani penambahan atau penghapusan kriteria maupun jurusan secara fleksibel.
   - Penginputan nilai evaluasi pada `matrik-simpan.php` telah dilengkapi mekanisme `ON DUPLICATE KEY UPDATE` agar tidak terjadi tabrakan *Primary Key*.

3. **Integritas Basis Data**:
   - Skema pada `db/db_saw.sql` telah dimigrasikan ke engine **InnoDB** dengan relasi *Foreign Key* dan aksi *Cascading Delete*, menjamin tidak ada data yatim (*orphan records*) saat alternatif atau kriteria dihapus.

4. **Frontend & UX**:
   - Konsol peramban bebas dari galat runtime JavaScript (*null reference pointer* diperbaiki di `main.js`).
   - Seluruh teks, judul, dan kartu dashboard telah diselaraskan dengan studi kasus **Pemilihan Jurusan Kuliah Siswa SMA**.

---

## 5.2 Panduan Impor Basis Data Ulang (Jika Menggunakan XAMPP)

Untuk menerapkan skema basis data terbaru yang sudah berisi data jurusan kuliah:

1. Buka aplikasi **XAMPP Control Panel** dan pastikan modul **Apache** serta **MySQL** aktif (*Running*).
2. Buka peramban dan akses **`http://localhost/phpmyadmin/`**.
3. Buat basis data baru dengan nama **`db_saw`** (atau pilih database `db_saw` yang sudah ada, lalu *Drop* seluruh tabel lamanya).
4. Klik tab menu **Import**.
5. Pilih berkas [`db/db_saw.sql`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/db/db_saw.sql) dari folder repositori ini.
6. Klik tombol **Go / Kirim** di bagian bawah.
7. Seluruh tabel (`saw_users`, `saw_alternatives`, `saw_criterias`, `saw_evaluations`) beserta data awal jurusan kuliah akan terimpor secara otomatis.

> **Kredensial Login Default:**
> - **Username**: `admin`
> - **Password**: `admin`
> *(Saat login pertama kali, sistem akan secara otomatis meng-upgrade hash MD5 lama menjadi hash Bcrypt modern).*

---

## 5.3 Checklist Pengujian Kualitas Sistem (QA Verification Checklist)

Gunakan tabel daftar periksa berikut saat melakukan uji coba aplikasi:

| No | Kasus Pengujian (Test Case) | Langkah Pengujian | Hasil yang Diharapkan | Status |
|:---:|---|---|---|:---:|
| 1 | **Login Normal** | Masukkan username `admin` dan password `admin` di `login.php`. | Berhasil masuk ke halaman dashboard `index.php`. | ✅ PASSED |
| 2 | **Login Negatif** | Masukkan password salah pada form login. | Muncul notifikasi peringatan merah "Login Gagal!". | ✅ PASSED |
| 3 | **Uji SQL Injection** | Masukkan username `admin' OR '1'='1'#` pada form login. | Sistem menolak login (tidak bisa di-bypass). | ✅ PASSED |
| 4 | **Uji Akses Tanpa Sesi** | Buka URL `http://localhost/spksaw/alternatif.php` di jendela Incognito. | Otomatis di-redirect ke `login.php` dan konten tidak bocor. | ✅ PASSED |
| 5 | **Uji Aksi Tanpa Sesi** | Panggil endpoint `alternatif-hapus.php?id=1` tanpa login. | Akses ditolak dan dialihkan ke halaman login. | ✅ PASSED |
| 6 | **Konsol Browser Bersih** | Tekan tombol `F12` lalu buka tab *Console* di seluruh halaman. | Bebas dari pesan galat merah (*0 JavaScript Errors*). | ✅ PASSED |
| 7 | **Uji Dinamis Kriteria** | Tambah kriteria baru di menu *Kriteria & Bobot*. | Halaman *Matriks* dan *Preferensi* otomatis menampilkan kolom baru tanpa galat. | ✅ PASSED |
| 8 | **Uji Update Nilai Matriks** | Masukkan nilai kriteria baru untuk jurusan yang sudah memiliki nilai sebelumnya. | Nilai lama otomatis terbarui tanpa galat *Duplicate entry*. | ✅ PASSED |
| 9 | **Uji Integritas Hapus** | Hapus satu jurusan di menu *Alternatif*. | Data jurusan dan nilai evaluasinya di tabel matriks ikut terhapus bersih. | ✅ PASSED |
| 10 | **Verifikasi Ranking SAW** | Buka halaman *Hasil Rekomendasi* (`preferensi.php`). | Peringkat 1 ditempati oleh **Ilmu Komputer UI (92.80%)**, diikuti **STEI ITB (90.57%)**. | ✅ PASSED |
