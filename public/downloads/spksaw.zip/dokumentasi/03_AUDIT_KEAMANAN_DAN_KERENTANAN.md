# Bagian 3: Audit Keamanan Sistem dan Implementasi Pertahanan (Security Audit & Remediation)

## 3.1 Selaras dengan Materi Keamanan pada PPT Kelompok (Slide 10–12)

Pada dokumen presentasi kelompok (**Slide 10, 11, dan 12**), tim telah merumuskan strategi keamanan sistem informasi yang mencakup:
1. **Pencegahan SQL Injection** melalui *Prepared Statements* dan *Parameterized Queries*.
2. **Pengamanan Password** menggunakan *Password Hashing (Bcrypt)*, bukan teks biasa atau hash usang.
3. **Session Management & Access Control** yang ketat agar hak akses pengguna tidak bocor.

Bab ini mendokumentasikan temuan audit keamanan pada kode sumber awal, bukti konsep eksploitasi serangan (*Proof of Concept*), serta implementasi perbaikan nyata yang telah diterapkan pada aplikasi.

---

## 3.2 Audit Kerentanan SQL Injection (CWE-89)

### Mekanisme Serangan SQL Injection (Sesuai Slide 11 & 12 PPT)
Penyerang menyisipkan karakter kutip tunggal (`'`) dan logika matematika boolean (`OR '1'='1'`) untuk mengubah struktur perintah query database:

```sql
-- Query rentan pada kode awal login-act.php:
SELECT * FROM saw_users WHERE username = '$username' AND password = '$password'

-- Jika penyerang memasukkan input:
-- username: admin' OR '1'='1'#
-- Query yang dieksekusi database:
SELECT * FROM saw_users WHERE username = 'admin' OR '1'='1'# AND password = '...'
```
Karena kondisi `'1'='1'` selalu bernilai **TRUE**, database akan mengembalikan data pengguna pertama (administrator), sehingga penyerang berhasil masuk ke dashboard tanpa mengetahui password yang valid.

### Titik-Titik Rentan pada Kode Awal:
1. `login-act.php`: Pengecekan kredensial rentan login bypass.
2. `alternatif-simpan.php` & `alternatif-edit-act.php`: Input nama jurusan rentan SQLi.
3. `alternatif-hapus.php`: Parameter `$_GET['id']` rentan injeksi SQL DELETE.
4. `bobot-edit-act.php` & `bobot-hapus.php`: Parameter kriteria rentan SQLi.
5. `matrik-simpan.php`: Tiga parameter nilai evaluasi rentan SQLi.
6. `keputusan-hapus.php`: Parameter `$_GET['id']` rentan SQLi.

### Solusi Remedi yang Telah Diterapkan:
Seluruh berkas di atas telah dirombak menggunakan **Prepared Statements (Parameterized Queries)** via extension `mysqli`:
```php
$stmt = $db->prepare("SELECT id_user, username, password FROM saw_users WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
```
*Dengan metode ini, input pengguna diperlakukan murni sebagai nilai data (literal value), bukan sebagai instruksi kode SQL yang dapat dieksekusi.*

---

## 3.3 Audit Broken Access Control & Ketiadaan Middleware Sesi (CWE-306)

### Analisis Kerentanan Awal:
Pada rancangan awal, pengecekan sesi login hanya dipasang pada berkas layout (`layout/head.php`). Seluruh berkas pemroses data backend (`alternatif-simpan.php`, `alternatif-hapus.php`, `bobot-simpan.php`, `matrik-simpan.php`) tidak memiliki validasi status sesi pengguna.

**Akibatnya**: Siapapun dapat menghapus data jurusan atau memanipulasi nilai matriks cukup dengan mengirim permintaan HTTP langsung dari browser atau cURL:
```bash
curl "http://localhost/spksaw/alternatif-hapus.php?id=1"
```

### Solusi Remedi yang Telah Diterapkan:
Dibuat berkas middleware terpusat [`include/auth.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/include/auth.php):
```php
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['status']) || $_SESSION['status'] !== 'login') {
    header("Location: login.php");
    exit(); // PENTING: Menghentikan eksekusi setelah redirect!
}
?>
```
Middleware ini telah dipasang di baris paling atas pada **seluruh berkas aksi CRUD dan tampilan sistem**.

---

## 3.4 Audit Kelemahan Hashing Password & Migrasi ke Bcrypt (CWE-328)

### Analisis Kerentanan Awal:
Aplikasi awal menggunakan hash MD5 tanpa *salt* (`md5($_POST['password'])`). MD5 sangat rentan terhadap pencarian tabel pelangi (*Rainbow Table Attack*) dan tabrakan hash (*Collision Attack*). Password default `admin` (`21232f297a57a5a743894a0e4a801fc3`) dapat ditebak dalam waktu kurang dari 1 detik.

### Solusi Remedi yang Telah Diterapkan:
Pada berkas [`login-act.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/login-act.php), sistem autentikasi telah ditingkatkan dengan standar industri **Bcrypt** (`PASSWORD_DEFAULT`):
- Memeriksa password menggunakan fungsi `password_verify($password, $user->password)`.
- Menyertakan **mekanisme migrasi otomatis**: Jika akun masih menggunakan hash MD5 lama, sistem akan memverifikasinya, mengizinkan login, dan secara otomatis memperbarui password di database menjadi hash Bcrypt modern.
- Mencegah *Session Fixation* dengan memanggil `session_regenerate_id(true)`.

---

## 3.5 Audit Cross-Site Scripting (XSS) (CWE-79)

### Analisis Kerentanan Awal:
Nama jurusan dan kriteria yang diambil dari database langsung dicetak ke dalam tag HTML tanpa disanitasi:
```php
echo "<td>{$row->name}</td>";
```
Jika penyerang menyisipkan nama jurusan seperti `<script>alert('Hacked')</script>`, skrip tersebut akan tersimpan di database (*Stored XSS*) dan dieksekusi pada peramban pengguna lain.

### Solusi Remedi yang Telah Diterapkan:
Seluruh variabel teks yang ditampilkan ke HTML kini disaring menggunakan:
```php
htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
```
Karakter berbahaya seperti `<`, `>`, `"`, dan `'` secara otomatis diubah menjadi entitas HTML yang aman sehingga tidak dapat dieksekusi sebagai kode JavaScript oleh browser.
