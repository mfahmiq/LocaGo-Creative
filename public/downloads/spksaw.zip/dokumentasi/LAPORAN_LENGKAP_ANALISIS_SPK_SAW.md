# LAPORAN LENGKAP ANALISIS DAN PENYEMPURNAAN SISTEM INFORMASI
## SISTEM PENDUKUNG KEPUTUSAN (SPK) PEMILIHAN JURUSAN KULIAH SISWA SMA
### MENGGUNAKAN METODE SIMPLE ADDITIVE WEIGHTING (SAW)
**Tugas Kelompok 6 &bull; Program Studi Sistem Informasi**

---

### TIM PENYUSUN (KELOMPOK 6):
1. **2415061039** - Ridho Azhari Putra
2. **2415061059** - Kanaya Traylingga Pratama
3. **2415061090** - Rifki Yudika Perdana
4. **2415061XXX** - Hengky Kurniawan
5. **2415061072** - Kadek Dwi Octo Lesa Candigo
6. **2415061091** - Riffa Yudika Permana

---

## DAFTAR ISI LAPORAN

1. [BAB I: PENDAHULUAN &amp; LATAR BELAKANG SISTEM](#bab-i-pendahuluan--latar-belakang-sistem)
   - 1.1 Latar Belakang Masalah Salah Jurusan
   - 1.2 Rumusan Masalah &amp; Tujuan Sistem
   - 1.3 Ruang Lingkup &amp; Spesifikasi Kebutuhan Sistem
   - 1.4 Arsitektur Perangkat Lunak &amp; Siklus Permintaan
   - 1.5 Inventarisasi Seluruh Berkas Program
2. [BAB II: PERANCANGAN DAN PEMODELAN BASIS DATA](#bab-ii-perancangan-dan-pemodelan-basis-data)
   - 2.1 Entity Relationship Diagram (ERD)
   - 2.2 Struktur Kamus Data Tabel
   - 2.3 Relasi Integritas Data &amp; Storage Engine InnoDB
3. [BAB III: LANDASAN TEORI &amp; PEMBUKTIAN ALGORITMA SAW](#bab-iii-landasan-teori--pembuktian-algoritma-saw)
   - 3.1 Konsep Metode Simple Additive Weighting (SAW)
   - 3.2 Kriteria Penilaian dan Bobot Preferensi
   - 3.3 Alternatif Pilihan Jurusan Kuliah
   - 3.4 Pembuktian Matematis Manual Step-by-Step
   - 3.5 Tabel Hasil Perangkingan Rekomendasi
4. [BAB IV: AUDIT KEAMANAN SISTEM &amp; IMPLEMENTASI PERTAHANAN](#bab-iv-audit-keamanan-sistem--implementasi-pertahanan)
   - 4.1 Selaras dengan Strategi Keamanan PPT (Slide 10–12)
   - 4.2 Analisis dan Penanganan SQL Injection via Prepared Statements
   - 4.3 Analisis Broken Access Control &amp; Middleware Autentikasi
   - 4.4 Pengamanan Password Menggunakan Bcrypt
   - 4.5 Pencegahan Cross-Site Scripting (XSS)
5. [BAB V: PERBAIKAN CACAT KODE, BUG RUNTIME, DAN ANTARMUKA](#bab-v-perbaikan-cacat-kode-bug-runtime-dan-antarmuka)
   - 5.1 Perbaikan Error JavaScript `main.js`
   - 5.2 Pembersihan Modul Grafik Berlebih pada Layout
   - 5.3 Normalisasi Standar Markup HTML di Dashboard
   - 5.4 Penyesuaian Label Form &amp; Dropdown Otomatis
   - 5.5 Penanganan Tabrakan Primary Key Nilai Evaluasi
6. [BAB VI: PANDUAN PENGUJIAN DAN VERIFIKASI KUALITAS (QA)](#bab-vi-panduan-pengujian-dan-verifikasi-kualitas-qa)
   - 6.1 Prosedur Impor Database
   - 6.2 Matriks Checklist Pengujian Kualitas Sistem
7. [BAB VII: KESIMPULAN DAN PENUTUP](#bab-vii-kesimpulan-dan-penutup)

---

# BAB I: PENDAHULUAN &amp; LATAR BELAKANG SISTEM

## 1.1 Latar Belakang Masalah Salah Jurusan
Pemilihan program studi di perguruan tinggi merupakan salah satu keputusan paling krusial bagi siswa Sekolah Menengah Atas (SMA). Berdasarkan data survei pendidikan:
- **70% Siswa Tidak Yakin** dengan pilihan program studi saat proses pendaftaran kuliah.
- **40% Mahasiswa Merasa Salah Jurusan** di tengah masa studinya.
- Dampak dari fenomena ini adalah penurunan motivasi belajar, penurunan indeks prestasi kumulatif (IPK), hingga pemborosan waktu dan biaya kuliah puluhan juta rupiah.
- Di sisi lain, keterbatasan fasilitas guru Bimbingan Konseling (BK) di sekolah yang rata-rata hanya mampu melayani 5–10 siswa per hari secara tatap muka menjadi kendala dalam memberikan konsultasi yang merata.

## 1.2 Rumusan Masalah &amp; Tujuan Sistem
- **Rumusan Masalah**: Bagaimana membangun sebuah Sistem Pendukung Keputusan berbasis web yang mampu memberikan rekomendasi pilihan jurusan kuliah secara cepat, objektif, dan akurat berdasarkan multi-kriteria?
- **Tujuan Sistem**:
  1. Membantu siswa SMA menemukan jurusan kuliah yang paling sesuai dengan kemampuan akademik, minat/bakat, kondisi finansial keluarga, serta preferensi lokasi.
  2. Menerapkan metode **Simple Additive Weighting (SAW)** dalam memproses pembobotan dan perankingan secara transparan dan terukur.
  3. Menyediakan sistem yang aman dari serangan siber umum seperti SQL Injection dan pencurian kredensial.

## 1.3 Ruang Lingkup &amp; Spesifikasi Kebutuhan Sistem
- **Platform**: Web-based application (responsive untuk desktop, tablet, dan smartphone).
- **Backend**: PHP Native (dengan driver `mysqli`).
- **Database**: MySQL / MariaDB (Server MariaDB 10.4.x via XAMPP).
- **Frontend**: Bootstrap 5, Template Dashboard Mazer v1.x, Feather &amp; Bootstrap Icons, KaTeX/MathJax.

## 1.4 Arsitektur Perangkat Lunak &amp; Siklus Permintaan

```mermaid
flowchart TD
    Client["Klien (Siswa / Guru BK / Admin)"] -->|HTTP Request| PageRouter["Controller Halaman (*.php)"]
    
    subgraph Security_Gate["Security Layer"]
        AuthMiddleware["include/auth.php\n(Validasi Sesi Aktif)"]
    end
    
    subgraph Calculation_Engine["SAW Engine Layer"]
        WeightModule["W.php (Ekstraksi Bobot W)"]
        NormalizationModule["R.php (Matriks Ternormalisasi R Dinamis)"]
        RankingModule["preferensi.php (Perhitungan Nilai P & Ranking)"]
    end
    
    subgraph Database_Layer["Storage Tier (db_saw)"]
        DB[(MariaDB)]
        UsersTable[("saw_users")]
        AltsTable[("saw_alternatives")]
        CritsTable[("saw_criterias")]
        EvalsTable[("saw_evaluations")]
    end

    PageRouter --> AuthMiddleware
    PageRouter --> Calculation_Engine
    Calculation_Engine --> DB
    UsersTable --- DB
    AltsTable --- DB
    CritsTable --- DB
    EvalsTable --- DB
```

## 1.5 Inventarisasi Seluruh Berkas Program

Aplikasi tersusun atas struktur berkas yang rapi dan modular:
1. `index.php`: Dashboard utama penyaji ringkasan data dan panduan sistem.
2. `login.php` &amp; `login-act.php`: Modul otentikasi aman pengguna.
3. `logout.php`: Mengakhiri sesi pengguna.
4. `alternatif.php`, `alternatif-simpan.php`, `alternatif-edit.php`, `alternatif-edit-act.php`, `alternatif-hapus.php`: Manajemen data pilihan jurusan kuliah.
5. `bobot.php`, `bobot-simpan.php`, `bobot-edit.php`, `bobot-edit-act.php`, `bobot-hapus.php`: Manajemen kriteria penilaian dan bobot preferensi.
6. `matrik.php`, `matrik-simpan.php`, `keputusan-hapus.php`: Komputasi matriks keputusan $X$, matriks normalisasi $R$, dan pengelolaan nilai kecocokan jurusan.
7. `W.php` &amp; `R.php`: Engine ekstraksi vektor bobot dan normalisasi dinamis.
8. `preferensi.php`: Modul perangkingan akhir rekomendasi program studi.
9. `include/auth.php`: Middleware keamanan sesi terpusat.
10. `include/conn.php`: Konfigurasi koneksi basis data.
11. `layout/*`: Template tampilan modular (`head.php`, `sidebar.php`, `footer.php`, `js.php`).
12. `db/db_saw.sql`: Skrip skema database InnoDB dan data awal jurusan kuliah.

---

# BAB II: PERANCANGAN DAN PEMODELAN BASIS DATA

## 2.1 Entity Relationship Diagram (ERD)

```mermaid
erDiagram
    saw_users {
        int id_user PK
        varchar username
        varchar password
    }

    saw_alternatives {
        smallint id_alternative PK
        varchar name
    }

    saw_criterias {
        tinyint id_criteria PK
        varchar criteria
        float weight
        enum attribute
    }

    saw_evaluations {
        smallint id_alternative PK, FK
        tinyint id_criteria PK, FK
        float value
    }

    saw_alternatives ||--o{ saw_evaluations : "memiliki evaluasi"
    saw_criterias ||--o{ saw_evaluations : "menilai kriteria"
```

## 2.2 Struktur Kamus Data Tabel

1. **Tabel `saw_users` (Pengguna &amp; Hak Akses)**:
   - `id_user`: INT AUTO_INCREMENT, Primary Key.
   - `username`: VARCHAR(50), Akun pengguna login.
   - `password`: VARCHAR(255), Hash kata sandi terenkripsi (mendukung BCRYPT modern).

2. **Tabel `saw_alternatives` (Alternatif Jurusan Kuliah)**:
   - `id_alternative`: SMALLINT UNSIGNED AUTO_INCREMENT, Primary Key.
   - `name`: VARCHAR(100), Nama program studi dan universitas (misal: "Ilmu Komputer UI").

3. **Tabel `saw_criterias` (Kriteria Penilaian)**:
   - `id_criteria`: TINYINT UNSIGNED AUTO_INCREMENT, Primary Key.
   - `criteria`: VARCHAR(100), Deskripsi kriteria (Nilai Akademik, Minat, Biaya, Lokasi).
   - `weight`: FLOAT, Bobot kepentingan kriteria dalam bentuk desimal (0.40, 0.30, 0.20, 0.10).
   - `attribute`: ENUM('benefit', 'cost'), Sifat atribut kriteria.

4. **Tabel `saw_evaluations` (Nilai Matriks Evaluasi)**:
   - `id_alternative`: SMALLINT UNSIGNED, Composite Primary Key (1), Foreign Key ke `saw_alternatives`.
   - `id_criteria`: TINYINT UNSIGNED, Composite Primary Key (2), Foreign Key ke `saw_criterias`.
   - `value`: FLOAT, Skor kuantitatif kecocokan jurusan pada kriteria terkait.

## 2.3 Relasi Integritas Data &amp; Storage Engine InnoDB
Seluruh tabel telah menggunakan storage engine **InnoDB** dengan constraint *Foreign Key* dan relasi `ON DELETE CASCADE ON UPDATE CASCADE`. Apabila suatu jurusan dihapus dari sistem, seluruh data nilai evaluasinya di tabel `saw_evaluations` otomatis terhapus secara aman tanpa menyisakan *orphan records*.

---

# BAB III: LANDASAN TEORI &amp; PEMBUKTIAN ALGORITMA SAW

## 3.1 Konsep Metode Simple Additive Weighting (SAW)
Metode Simple Additive Weighting (SAW) mencari penjumlahan terbobot dari rating kinerja pada setiap alternatif di semua kriteria. Metode ini membutuhkan proses normalisasi matriks keputusan ($X$) ke dalam skala ternormalisasi ($R$) yang dapat diperbandingkan antar atribut yang memiliki satuan berbeda.

## 3.2 Kriteria Penilaian dan Bobot Preferensi
Sesuai rancangan pada presentasi kelompok:
1. **$C_1$ - Nilai Akademik**: Bobot **0.40 (40%)**, Atribut **Benefit** (semakin besar nilainya semakin baik).
2. **$C_2$ - Kesesuaian Minat**: Bobot **0.30 (30%)**, Atribut **Benefit** (semakin tinggi skor minat bakat semakin baik).
3. **$C_3$ - Biaya Kuliah**: Bobot **0.20 (20%)**, Atribut **Cost** (semakin murah biaya UKT semakin baik).
4. **$C_4$ - Preferensi Lokasi**: Bobot **0.10 (10%)**, Atribut **Benefit** (semakin strategis/nyaman semakin baik).
*Total Akumulasi Bobot = 0.40 + 0.30 + 0.20 + 0.10 = 1.00 (100% ideal).*

## 3.3 Alternatif Pilihan Jurusan Kuliah
1. **$A_1$**: Ilmu Komputer UI
2. **$A_2$**: STEI ITB
3. **$A_3$**: Teknik Informatika UNILA
4. **$A_4$**: Bisnis Digital UNPAD
5. **$A_5$**: Sistem Informasi ITS

## 3.4 Pembuktian Matematis Manual Step-by-Step

### A. Matriks Keputusan ($X$):
$$X = \begin{pmatrix}
88.0 & 95.0 & 15.0 & 90.0 \\
85.0 & 85.0 & 12.0 & 80.0 \\
80.0 & 75.0 & 10.0 & 95.0 \\
82.0 & 80.0 & 11.0 & 85.0 \\
84.0 & 82.0 & 13.0 & 82.0
\end{pmatrix}$$

### B. Nilai Ekstremum:
- Kriteria $C_1$ (Benefit): $\max = 88.0$
- Kriteria $C_2$ (Benefit): $\max = 95.0$
- Kriteria $C_3$ (Cost): $\min = 10.0$
- Kriteria $C_4$ (Benefit): $\max = 95.0$

### C. Normalisasi Matriks ($R$):
- **$A_1$ (Ilmu Komputer UI)**:
  - $R_{11} = 88/88 = 1.0000$
  - $R_{12} = 95/95 = 1.0000$
  - $R_{13} = 10/15 = 0.6667$ *(Cost: Min / X)*
  - $R_{14} = 90/95 = 0.9474$
- **$A_2$ (STEI ITB)**:
  - $R_{21} = 85/88 = 0.9659$
  - $R_{22} = 85/95 = 0.8947$
  - $R_{23} = 10/12 = 0.8333$
  - $R_{24} = 80/95 = 0.8421$
- **$A_3$ (Teknik Informatika UNILA)**:
  - $R_{31} = 80/88 = 0.9091$
  - $R_{32} = 75/95 = 0.7895$
  - $R_{33} = 10/10 = 1.0000$
  - $R_{34} = 95/95 = 1.0000$
- **$A_4$ (Bisnis Digital UNPAD)**:
  - $R_{41} = 82/88 = 0.9318$
  - $R_{42} = 80/95 = 0.8421$
  - $R_{43} = 10/11 = 0.9091$
  - $R_{44} = 85/95 = 0.8947$
- **$A_5$ (Sistem Informasi ITS)**:
  - $R_{51} = 84/88 = 0.9545$
  - $R_{52} = 82/95 = 0.8632$
  - $R_{53} = 10/13 = 0.7692$
  - $R_{54} = 82/95 = 0.8632$

### D. Perhitungan Nilai Preferensi ($P_i$):
$$P(A_1) = (1.0000 \times 0.40) + (1.0000 \times 0.30) + (0.6667 \times 0.20) + (0.9474 \times 0.10) = \mathbf{0.9280} \quad (\mathbf{92.80\%})$$
$$P(A_2) = (0.9659 \times 0.40) + (0.8947 \times 0.30) + (0.8333 \times 0.20) + (0.8421 \times 0.10) = \mathbf{0.9057} \quad (\mathbf{90.57\%})$$
$$P(A_3) = (0.9091 \times 0.40) + (0.7895 \times 0.30) + (1.0000 \times 0.20) + (1.0000 \times 0.10) = \mathbf{0.9004} \quad (\mathbf{90.04\%})$$
$$P(A_4) = (0.9318 \times 0.40) + (0.8421 \times 0.30) + (0.9091 \times 0.20) + (0.8947 \times 0.10) = \mathbf{0.8966} \quad (\mathbf{89.66\%})$$
$$P(A_5) = (0.9545 \times 0.40) + (0.8632 \times 0.30) + (0.7692 \times 0.20) + (0.8632 \times 0.10) = \mathbf{0.8809} \quad (\mathbf{88.09\%})$$

## 3.5 Tabel Hasil Perangkingan Rekomendasi
1. 🥇 **Peringkat 1**: **Ilmu Komputer UI** ($0.9280$ / $92.80\%$) &mdash; **Rekomendasi Utama Siswa**
2. 🥈 **Peringkat 2**: **STEI ITB** ($0.9057$ / $90.57\%$) &mdash; Rekomendasi Alternatif 2
3. 🥉 **Peringkat 3**: **Teknik Informatika UNILA** ($0.9004$ / $90.04\%$) &mdash; Rekomendasi Alternatif 3
4. **Peringkat 4**: **Bisnis Digital UNPAD** ($0.8966$ / $89.66\%$)
5. **Peringkat 5**: **Sistem Informasi ITS** ($0.8809$ / $88.09\%$)

---

# BAB IV: AUDIT KEAMANAN SISTEM &amp; IMPLEMENTASI PERTAHANAN

## 4.1 Selaras dengan Strategi Keamanan PPT (Slide 10–12)
Dalam dokumen presentasi tugas kelompok (**Slide 10–12**), tim merancang tiga pilar keamanan:
1. *Authentication &amp; Authorization* (Login aman, Bcrypt, Session Management).
2. *Data Protection* (Input validation, Pencegahan SQL Injection).
3. *Backup &amp; Recovery*.

Bab ini membuktikan implementasi nyata dari strategi tersebut pada kode sumber aplikasi:

## 4.2 Analisis dan Penanganan SQL Injection via Prepared Statements
- **Masalah Awal**: Seluruh query SQL di 10 berkas aksi awal menyambungkan input pengguna secara langsung tanpa filter:
  `$db->query("SELECT * FROM saw_users WHERE username='$username' ...")`
  Celah ini memungkinkan penyerang melakukan *authentication bypass* menggunakan input `' OR '1'='1`.
- **Implementasi Solusi**: Seluruh berkas pemrosesan query kini telah dimigrasikan menggunakan **Prepared Statements (Parameterized Queries)**:
  `$stmt = $db->prepare("SELECT id_user, username, password FROM saw_users WHERE username = ?");`
  `$stmt->bind_param("s", $username);`
  Metode ini memisahkan struktur query dari data masukan pengguna, sehingga kode SQL penyerang tidak akan pernah dapat dieksekusi.

## 4.3 Analisis Broken Access Control &amp; Middleware Autentikasi
- **Masalah Awal**: Berkas backend seperti `alternatif-hapus.php` dan `matrik-simpan.php` tidak mengecek sesi login, sehingga orang luar dapat mengubah data tanpa login.
- **Implementasi Solusi**: Dibuat middleware [`include/auth.php`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/include/auth.php) dengan proteksi pemutusan eksekusi (`exit()`) setelah perintah redirect. Middleware ini dipasang pada seluruh berkas sistem.

## 4.4 Pengamanan Password Menggunakan Bcrypt
- **Masalah Awal**: Password disimpan dalam bentuk hash MD5 polos tanpa salt.
- **Implementasi Solusi**: Berkas `login-act.php` kini menggunakan fungsi bawaan PHP `password_verify()` dan `password_hash()` berbasis algoritma **Bcrypt**. Sistem juga dilengkapi auto-upgrade: akun dengan password MD5 lama akan otomatis diperbarui menjadi hash Bcrypt modern saat pertama kali login.

## 4.5 Pencegahan Cross-Site Scripting (XSS)
- Seluruh teks dari database yang ditampilkan ke antarmuka HTML disaring menggunakan fungsi `htmlspecialchars($val, ENT_QUOTES, 'UTF-8')`.

---

# BAB V: PERBAIKAN CACAT KODE, BUG RUNTIME, DAN ANTARMUKA

1. **Perbaikan Error JavaScript `main.js`**: Menambahkan *null-check* pada selektor `.sidebar-item.active` sehingga konsol peramban bersih dari pesan merah fatal (*Uncaught TypeError*).
2. **Pembersihan Modul Grafik Demo**: Menghapus pemanggilan `apexcharts.js` dan `dashboard.js` yang tidak terpakai dari `layout/js.php`.
3. **Normalisasi Standar Markup HTML**: Menghapus deklarasi tag `<head>` duplikat dan pemuatan pustaka ganda pada `index.php`.
4. **Penyesuaian Label Form**: Memperbaiki teks modal tambah jurusan yang sebelumnya bertuliskan "Login Form" menjadi "Tambah Pilihan Jurusan Kuliah".
5. **Dropdown Edit Atribut Kriteria**: Menambahkan logika `selected` otomatis pada `bobot-edit.php` agar atribut tidak berubah secara tidak sengaja.
6. **Penanganan Tabrakan Primary Key Matriks**: Memperbarui `matrik-simpan.php` dengan query `INSERT ... ON DUPLICATE KEY UPDATE` agar pembaruan nilai tidak gagal dengan galat duplicate key.
7. **Pembersihan Berkas Sampah**: Berkas mati `keputusan-simpan.php` (0 byte) telah dihapus dari repositori.

---

# BAB VI: PANDUAN PENGUJIAN DAN VERIFIKASI KUALITAS (QA)

## 6.1 Prosedur Impor Database
1. Buka browser dan akses `http://localhost/phpmyadmin/`.
2. Pilih atau buat basis data `db_saw`.
3. Impor berkas [`db/db_saw.sql`](file:///D:/Tugas/Sistem%20Informasi/Tugas%20kelompok%20ber%206/spksaw/db/db_saw.sql).
4. Login menggunakan akun default: **Username**: `admin`, **Password**: `admin`.

## 6.2 Matriks Checklist Pengujian Kualitas Sistem

| Pengujian | Skenario Uji | Hasil Uji Sistem | Status |
|---|---|---|:---:|
| **Uji Login** | Input user &amp; password valid (`admin:admin`) | Masuk ke dashboard sistem | ✅ PASSED |
| **Uji Anti-Bypass** | Coba SQL Injection username `' OR '1'='1` | Login ditolak | ✅ PASSED |
| **Uji Hak Akses** | Akses halaman tanpa login | Otomatis di-redirect ke `login.php` | ✅ PASSED |
| **Uji Konsol Browser** | Periksa tab Console di browser (F12) | 0 Galat Merah JavaScript | ✅ PASSED |
| **Uji Normalisasi SAW** | Cek Matriks Normalisasi ($R$) | Nilai benefit &amp; cost terhitung akurat | ✅ PASSED |
| **Uji Perangkingan** | Buka halaman *Hasil Rekomendasi* | Ilmu Komputer UI peringkat 1 (92.80%) | ✅ PASSED |

---

# BAB VII: KESIMPULAN DAN PENUTUP

Aplikasi **Sistem Pendukung Keputusan (SPK) Pemilihan Jurusan Kuliah Siswa SMA Menggunakan Metode Simple Additive Weighting (SAW)** yang disusun oleh **Kelompok 6 - Program Studi Sistem Informasi** kini telah disempurnakan secara menyeluruh:

1. **Sinkronisasi Kasus**: Seluruh komponen basis data, antarmuka, dan dokumentasi telah **100% selaras dengan dokumen presentasi kelompok (PPT)**.
2. **Keandalan Matematika**: Metode SAW bekerja secara dinamis dan menghasilkan keputusan yang objektif, menempatkan **Ilmu Komputer UI** ($92.80\%$) dan **STEI ITB** ($90.57\%$) sebagai rekomendasi program studi terbaik.
3. **Standar Keamanan Tinggi**: Celah keamanan kritis seperti SQL Injection, session hijacking, dan hashing MD5 usang telah ditutup dengan penerapan *Prepared Statements*, *Bcrypt*, serta middleware autentikasi modern.
4. **Kualitas Kode**: Bug runtime JavaScript dan cacat tampilan telah dibersihkan secara tuntas, menjadikan sistem ini siap didemonstrasikan di hadapan dosen penguji dengan hasil yang profesional dan memuaskan.
