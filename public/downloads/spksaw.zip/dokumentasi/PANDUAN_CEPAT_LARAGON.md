# 🚀 PANDUAN CEPAT MENJALANKAN SISTEM DI LARAGON
### Pengingat Langkah & Checklist Eksekusi (Quick Cheat Sheet)

File ini dibuat sebagai pengingat praktis agar Anda bisa langsung menjalankan sistem dan mengimpor database dengan cepat tanpa perlu membaca ulang seluruh dokumen teknis.

---

## 📌 Status Terkini Proyek Anda
- **Lokasi Kode Asli**: `D:\Tugas\Sistem Informasi\Tugas kelompok ber 6\spksaw`
- **Junction Link Laragon**: `D:\laragon\www\spksaw` *(Sudah otomatis terhubung, tidak perlu copy-paste file lagi!)*
- **File Database SQL**: `D:\laragon\www\spksaw\db_saw.sql`

---

## ⚡ 3 LANGKAH MUDAH MENJALANKAN SISTEM

### Langkah 1: Buka & Nyalakan Laragon
1. Buka aplikasi **Laragon** di komputer Anda.
2. Klik tombol **Start All** (pastikan Apache dan MySQL sudah menyala / aktif).

---

### Langkah 2: Impor Database (⚡ Opsi A - Lewat Terminal Laragon / 5 Detik)
1. Di jendela aplikasi Laragon, klik tombol **Terminal**.
2. Salin dan tempel perintah berikut, lalu tekan **Enter**:

```bash
mysql -u root -e "CREATE DATABASE IF NOT EXISTS db_saw;"
mysql -u root db_saw < "D:/laragon/www/spksaw/db_saw.sql"
```

> **Catatan:**
> - Jika database berhasil terisi, tidak akan ada pesan error (terminal kembali ke baris perintah baru).
> - Seluruh data kriteria (Akademik 40%, Minat 30%, Biaya 20%, Lokasi 10%) dan 5 jurusan kuliah (UI, ITB, UNILA, UNPAD, ITS) langsung siap digunakan.

---

### Langkah 3: Buka Sistem di Browser
Buka peramban (Chrome, Edge, dll.) lalu akses salah satu alamat ini:
- 🌐 **`http://localhost/spksaw/`** atau
- 🌐 **`http://spksaw.test/`**

### 🔑 Kredensial Login:
- **Username**: `admin`
- **Password**: `admin`

---

## 🖱️ Opsi Cadangan (Jika Ingin Pakai HeidiSQL):
1. Di jendela Laragon, klik tombol **Database** &rarr; klik **Open / Buka**.
2. Klik kanan di panel kiri &rarr; **Create new (Buat baru)** &rarr; **Database** &rarr; beri nama **`db_saw`** &rarr; OK.
3. Klik menu **File (Berkas)** &rarr; **Load SQL file...** &rarr; pilih file `D:\laragon\www\spksaw\db_saw.sql`.
4. Tekan tombol **F9** (atau klik tombol segitiga biru / Run).
