<?php
/**
 * Middleware Autentikasi Pengguna
 * Memastikan sesi login aktif dan mencegah Execution After Redirect (EAR)
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['status']) || $_SESSION['status'] !== 'login') {
    header("Location: login.php");
    exit();
}
?>
