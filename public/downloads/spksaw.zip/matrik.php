<!DOCTYPE html>
<html lang="id">
<?php
require "layout/head.php";
require "include/conn.php";
?>

<body>
  <div id="app">
    <?php require "layout/sidebar.php"; ?>
    <div id="main">
      <header class="mb-3">
        <a href="#" class="burger-btn d-block d-xl-none">
          <i class="bi bi-justify fs-3"></i>
        </a>
      </header>

      <div class="page-heading">
        <h3 style="color: #435EBE;">Matriks Keputusan (X) &amp; Ternormalisasi (R)</h3>
        <p class="text-subtitle text-muted">Pemetaan rating kecocokan alternatif jurusan pada setiap kriteria serta proses normalisasinya.</p>
      </div>

      <div class="page-content">
        <section class="row">
          <div class="col-12">
            <div class="card shadow-sm border-0">
              <div class="card-header bg-light d-flex flex-wrap justify-content-between align-items-center">
                <h5 class="card-title mb-2 mb-md-0">Tabel Matriks Keputusan &amp; Normalisasi</h5>
                <div class="btn-group">
                  <button type="button" class="btn btn-outline-primary btn-sm me-1" data-bs-toggle="modal" data-bs-target="#benefitModal">
                    <i class="bi bi-info-circle me-1"></i> Rumus Benefit
                  </button>
                  <button type="button" class="btn btn-outline-warning btn-sm me-1" data-bs-toggle="modal" data-bs-target="#costModal">
                    <i class="bi bi-info-circle me-1"></i> Rumus Cost
                  </button>
                  <button type="button" class="btn btn-primary btn-sm shadow" data-bs-toggle="modal" data-bs-target="#inlineForm">
                    <i class="bi bi-plus-circle me-1"></i> Isi / Edit Nilai Jurusan
                  </button>
                </div>
              </div>

              <div class="card-body mt-3">
                <!-- Modal Rumus Benefit -->
                <div class="modal fade" id="benefitModal" tabindex="-1" aria-labelledby="benefitModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header bg-success text-white">
                        <h5 class="modal-title text-white" id="benefitModalLabel">Rumus Normalisasi Kriteria Benefit</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <p>Digunakan untuk kriteria keuntungan di mana <strong>semakin besar nilainya semakin baik</strong> (contoh: Nilai Akademik, Minat, Lokasi):</p>
                        <div class="text-center p-3 my-2 bg-light rounded border">
                          $$ R_{ij} = \frac{X_{ij}}{\max_i(X_{ij})} $$
                        </div>
                        <ul class="mb-0 mt-3">
                          <li><strong>$R_{ij}$</strong>: Nilai ternormalisasi jurusan $i$ pada kriteria $j$.</li>
                          <li><strong>$X_{ij}$</strong>: Nilai asli jurusan $i$ pada kriteria $j$.</li>
                          <li><strong>$\max_i(X_{ij})$</strong>: Nilai maksimum pada kriteria $j$ dari seluruh pilihan jurusan.</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Modal Rumus Cost -->
                <div class="modal fade" id="costModal" tabindex="-1" aria-labelledby="costModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header bg-warning text-dark">
                        <h5 class="modal-title" id="costModalLabel">Rumus Normalisasi Kriteria Cost</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <p>Digunakan untuk kriteria biaya di mana <strong>semakin kecil nilainya semakin baik</strong> (contoh: Biaya Kuliah):</p>
                        <div class="text-center p-3 my-2 bg-light rounded border">
                          $$ R_{ij} = \frac{\min_i(X_{ij})}{X_{ij}} $$
                        </div>
                        <ul class="mb-0 mt-3">
                          <li><strong>$R_{ij}$</strong>: Nilai ternormalisasi jurusan $i$ pada kriteria $j$.</li>
                          <li><strong>$\min_i(X_{ij})$</strong>: Nilai minimum (terkecil/termurah) pada kriteria $j$.</li>
                          <li><strong>$X_{ij}$</strong>: Nilai asli jurusan $i$ pada kriteria $j$.</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                <?php
                // Ambil daftar kriteria secara dinamis
                $criterias_result = $db->query("SELECT id_criteria, criteria, attribute FROM saw_criterias ORDER BY id_criteria ASC");
                $criterias = [];
                $attributes = [];
                while ($c_row = $criterias_result->fetch_object()) {
                  $criterias[$c_row->id_criteria] = $c_row->criteria;
                  $attributes[$c_row->id_criteria] = $c_row->attribute;
                }

                // Ambil data alternatif & evaluasi
                $sql = "SELECT
                          a.id_alternative,
                          b.name,
                          a.id_criteria,
                          a.value
                        FROM
                          saw_evaluations a
                          JOIN saw_alternatives b ON a.id_alternative = b.id_alternative
                        ORDER BY a.id_alternative, a.id_criteria";
                $result = $db->query($sql);

                $alternatives = [];
                while ($row = $result->fetch_object()) {
                  $alternatives[$row->id_alternative]['name'] = $row->name;
                  $alternatives[$row->id_alternative]['criteria'][$row->id_criteria] = (float)$row->value;
                }

                // Kumpulkan nilai matriks X per kriteria untuk mencari max & min
                $X = [];
                foreach ($alternatives as $id_alt => $data) {
                  foreach ($data['criteria'] as $id_crit => $val) {
                    $X[$id_crit][] = $val;
                  }
                }

                $maxValues = [];
                $minValues = [];
                foreach ($criterias as $id_crit => $name) {
                  $vals = $X[$id_crit] ?? [];
                  $maxValues[$id_crit] = !empty($vals) ? max($vals) : 1;
                  $minValues[$id_crit] = !empty($vals) ? min($vals) : 1;
                }

                // TABEL 1: MATRIKS KEPUTUSAN (X)
                if (!empty($alternatives)) {
                  echo "<div class='mb-4'>";
                  echo "<h6 class='font-bold text-primary mb-2'><i class='bi bi-1-circle-fill me-1'></i> Matriks Keputusan ($X$)</h6>";
                  echo "<div class='table-responsive'>";
                  echo "<table class='table table-bordered table-striped mb-0' style='width: 100%; font-size: 14px;'>";
                  echo "<thead style='background-color: #435EBE; color: #fff;'>";
                  echo "<tr>
                          <th rowspan='2' class='align-middle text-center' style='width: 70px;'>Kode</th>
                          <th rowspan='2' class='align-middle' style='min-width: 200px;'>Pilihan Jurusan &amp; Universitas</th>";

                  $idx = 1;
                  foreach ($criterias as $id => $name) {
                    $attr_lbl = ($attributes[$id] === 'benefit') ? 'Benefit' : 'Cost';
                    echo "<th class='text-center'>C<sub>$idx</sub> ($attr_lbl)<br><small style='font-size: 11px; font-weight: normal;'>" . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . "</small></th>";
                    $idx++;
                  }

                  echo "<th rowspan='2' class='align-middle text-center' style='width: 100px;'>Aksi</th>
                        </tr>";
                  echo "</thead>";
                  echo "<tbody>";

                  $c_num = 1;
                  foreach ($alternatives as $id_alternative => $data) {
                    $safe_name = htmlspecialchars($data['name'], ENT_QUOTES, 'UTF-8');
                    echo "<tr>
                            <td class='text-center font-bold'>A<sub>{$c_num}</sub></td>
                            <td><strong>{$safe_name}</strong></td>";

                    foreach ($criterias as $id_criteria => $name) {
                      $val = isset($data['criteria'][$id_criteria]) ? round($data['criteria'][$id_criteria], 2) : 0;
                      echo "<td class='text-center'>{$val}</td>";
                    }

                    echo "<td class='text-center'>
                            <button type='button' class='btn btn-outline-danger btn-sm' data-bs-toggle='modal' data-bs-target='#deleteModal' data-id='{$id_alternative}' data-name='{$safe_name}'><i class='bi bi-trash'></i> Reset</button>
                          </td>
                        </tr>";
                    $c_num++;
                  }

                  // Baris Nilai Ekstremum (Max / Min)
                  echo "<tr class='table-warning font-bold'>
                          <td colspan='2' class='text-end'><strong>Nilai Ekstremum Acuan:</strong></td>";
                  foreach ($criterias as $id_criteria => $name) {
                    if ($attributes[$id_criteria] === 'benefit') {
                      echo "<td class='text-center'>Max: <strong>{$maxValues[$id_criteria]}</strong></td>";
                    } else {
                      echo "<td class='text-center'>Min: <strong>{$minValues[$id_criteria]}</strong></td>";
                    }
                  }
                  echo "<td></td></tr>";

                  echo "</tbody>";
                  echo "</table>";
                  echo "</div></div>";

                  // TABEL 2: MATRIKS TERNORMALISASI (R)
                  $R = [];
                  foreach ($alternatives as $id_alt => $data) {
                    foreach ($criterias as $id_crit => $name) {
                      $val = $data['criteria'][$id_crit] ?? 0;
                      if ($attributes[$id_crit] === 'benefit') {
                        $norm = ($maxValues[$id_crit] > 0) ? ($val / $maxValues[$id_crit]) : 0;
                      } else {
                        $norm = ($val > 0) ? ($minValues[$id_crit] / $val) : 0;
                      }
                      $R[$id_alt][$id_crit] = $norm;
                    }
                  }

                  echo "<div class='mt-4'>";
                  echo "<h6 class='font-bold text-success mb-2'><i class='bi bi-2-circle-fill me-1'></i> Matriks Ternormalisasi ($R$)</h6>";
                  echo "<div class='table-responsive'>";
                  echo "<table class='table table-bordered table-striped mb-0' style='width: 100%; font-size: 14px;'>";
                  echo "<thead style='background-color: #198754; color: #fff;'>";
                  echo "<tr>
                          <th class='align-middle text-center' style='width: 70px;'>Kode</th>
                          <th class='align-middle' style='min-width: 200px;'>Pilihan Jurusan &amp; Universitas</th>";

                  $idx = 1;
                  foreach ($criterias as $id => $name) {
                    echo "<th class='text-center'>C<sub>$idx</sub><br><small style='font-size: 11px; font-weight: normal;'>" . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . "</small></th>";
                    $idx++;
                  }

                  echo "</tr></thead>";
                  echo "<tbody>";

                  $c_num = 1;
                  foreach ($alternatives as $id_alternative => $data) {
                    $safe_name = htmlspecialchars($data['name'], ENT_QUOTES, 'UTF-8');
                    echo "<tr>
                            <td class='text-center font-bold'>A<sub>{$c_num}</sub></td>
                            <td><strong>{$safe_name}</strong></td>";

                    foreach ($criterias as $id_criteria => $name) {
                      $norm_val = isset($R[$id_alternative][$id_criteria]) ? round($R[$id_alternative][$id_criteria], 4) : 0;
                      echo "<td class='text-center font-bold text-primary'>{$norm_val}</td>";
                    }

                    echo "</tr>";
                    $c_num++;
                  }

                  echo "</tbody>";
                  echo "</table>";
                  echo "</div></div>";

                } else {
                  echo '<div class="alert alert-warning"><i class="bi bi-exclamation-triangle me-2"></i>Belum ada data evaluasi. Silakan isi nilai kriteria untuk alternatif jurusan melalui tombol di atas.</div>';
                }
                ?>
              </div>
            </div>
          </div>
        </section>
      </div>
      <?php require "layout/footer.php"; ?>
    </div>
  </div>

  <!-- Modal Isi / Edit Nilai Jurusan -->
  <div class="modal fade text-left" id="inlineForm" tabindex="-1" role="dialog" aria-labelledby="modalNilaiLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title text-white" id="modalNilaiLabel">Isi / Perbarui Nilai Jurusan</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form action="matrik-simpan.php" method="POST">
          <div class="modal-body">
            <div class="form-group mb-3">
              <label class="form-label font-bold">Pilih Alternatif Jurusan:</label>
              <select class="form-select" name="id_alternative" required>
                <?php
                $res_alts = $db->query('SELECT id_alternative, name FROM saw_alternatives ORDER BY id_alternative ASC');
                while ($a = $res_alts->fetch_object()) {
                  echo '<option value="' . $a->id_alternative . '">' . htmlspecialchars($a->name, ENT_QUOTES, 'UTF-8') . '</option>';
                }
                $res_alts->free();
                ?>
              </select>
            </div>
            <div class="form-group mb-3">
              <label class="form-label font-bold">Pilih Kriteria Penilaian:</label>
              <select class="form-select" name="id_criteria" required>
                <?php
                $res_crits = $db->query('SELECT id_criteria, criteria, attribute FROM saw_criterias ORDER BY id_criteria ASC');
                while ($c = $res_crits->fetch_object()) {
                  echo '<option value="' . $c->id_criteria . '">' . htmlspecialchars($c->criteria, ENT_QUOTES, 'UTF-8') . ' (' . ucfirst($c->attribute) . ')</option>';
                }
                $res_crits->free();
                ?>
              </select>
            </div>
            <div class="form-group mb-3">
              <label class="form-label font-bold">Nilai Kecocokan (Rating):</label>
              <input type="number" step="0.01" name="value" placeholder="Contoh: 85 untuk nilai, 12 untuk biaya..." class="form-control" required>
              <small class="text-muted">Jika nilai untuk jurusan dan kriteria ini sudah ada, sistem akan otomatis memperbaruinya.</small>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" name="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Nilai</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Modal Konfirmasi Reset Nilai -->
  <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title text-white" id="deleteModalLabel">Konfirmasi Reset Nilai</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p>Apakah Anda yakin ingin mereset seluruh data evaluasi nilai untuk jurusan <strong id="alternativeName"></strong>?</p>
          <p class="text-muted mb-0"><small>Data nilai evaluasi ini akan dihapus dari tabel matriks keputusan.</small></p>
        </div>
        <div class="modal-footer">
          <form id="deleteForm" method="GET" action="keputusan-hapus.php">
            <input type="hidden" name="id" id="alternativeId">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-danger">Ya, Reset Nilai</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <?php require "layout/js.php"; ?>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const deleteModal = document.getElementById('deleteModal');
      deleteModal.addEventListener('show.bs.modal', function(event) {
        const button = event.relatedTarget;
        const id = button.getAttribute('data-id');
        const name = button.getAttribute('data-name');

        document.getElementById('alternativeName').textContent = name;
        document.getElementById('alternativeId').value = id;
      });
    });
  </script>
</body>

</html>