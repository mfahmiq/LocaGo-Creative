<!DOCTYPE html>
<html lang="id">
<?php
require "layout/head.php";
require "include/conn.php";

// Menghitung jumlah alternatif jurusan
$sql_alternatives = 'SELECT COUNT(*) AS total_alternatives FROM saw_alternatives';
$result_alternatives = $db->query($sql_alternatives);
$total_alternatives = $result_alternatives ? $result_alternatives->fetch_object()->total_alternatives : 0;

// Menghitung jumlah kriteria
$sql_criterias = 'SELECT COUNT(*) AS total_criterias FROM saw_criterias';
$result_criterias = $db->query($sql_criterias);
$total_criterias = $result_criterias ? $result_criterias->fetch_object()->total_criterias : 0;
?>

<body>
    <div id="app">
        <?php require "layout/sidebar.php"; ?>
        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                </a>
            </header>
            <div class="page-heading">
                <h3 style="color: #435EBE;">Dashboard SPK Pemilihan Jurusan Kuliah</h3>
                <p class="text-subtitle text-muted">Sistem Pendukung Keputusan untuk Siswa SMA Menggunakan Metode Simple Additive Weighting (SAW)</p>
            </div>
            
            <div class="row">
                <!-- Card Jurusan / Alternatif -->
                <div class="col-6 col-lg-4 col-md-6">
                    <div class="card shadow-sm border-0">
                        <div class="card-body px-4 py-4-5">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon purple">
                                        <i class="bi bi-mortarboard-fill"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold">Total Pilihan Jurusan</h6>
                                    <h5 class="font-extrabold mb-0"><?php echo $total_alternatives; ?> Alternatif</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Card Kriteria Penilaian -->
                <div class="col-6 col-lg-4 col-md-6">
                    <div class="card shadow-sm border-0">
                        <div class="card-body px-4 py-4-5">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="stats-icon blue">
                                        <i class="bi bi-sliders"></i>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <h6 class="text-muted font-semibold">Kriteria Penilaian</h6>
                                    <h5 class="font-extrabold mb-0"><?php echo $total_criterias; ?> Kriteria</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="page-content">
                <section class="row">
                    <div class="col-12">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-light">
                                <h4 class="card-title text-primary mb-0"><i class="bi bi-info-circle me-2"></i>Tentang Sistem &amp; Metode SAW</h4>
                            </div>
                            <div class="card-body mt-3">
                                <p class="card-text">
                                    <strong>Latar Belakang Pemilihan Jurusan Kuliah:</strong><br>
                                    Banyak siswa SMA mengalami kebingungan dalam menentukan program studi perguruan tinggi yang sesuai dengan bakat dan kondisi mereka. Kesalahan pemilihan jurusan berdampak pada penurunan motivasi belajar, penurunan prestasi akademik, hingga pemborosan waktu dan biaya.
                                </p>
                                <p class="card-text">
                                    Sistem Pendukung Keputusan (SPK) ini hadir memberikan solusi rekomendasi objektif berbasis data (*data-driven*) dengan menggunakan metode <strong>Simple Additive Weighting (SAW)</strong>. Metode SAW melakukan penjumlahan terbobot dari rating kinerja setiap pilihan jurusan pada setiap kriteria yang ditetapkan.
                                </p>

                                <hr>

                                <div class="row mt-4">
                                    <div class="col-md-6 mb-3">
                                        <div class="border rounded p-3 h-100 bg-light">
                                            <h6 class="font-bold text-dark"><i class="bi bi-check2-circle text-success me-2"></i>Kriteria &amp; Bobot Penilaian (PPT):</h6>
                                            <ul class="mb-0 mt-2">
                                                <li><strong>Nilai Akademik (40% / 0.40)</strong> &bull; Atribut <em>Benefit</em>: Prestasi rapor &amp; tes akademik.</li>
                                                <li><strong>Kesesuaian Minat (30% / 0.30)</strong> &bull; Atribut <em>Benefit</em>: Hasil tes minat, bakat, &amp; passion.</li>
                                                <li><strong>Biaya Kuliah (20% / 0.20)</strong> &bull; Atribut <em>Cost</em>: Besaran UKT / semester (semakin terjangkau semakin baik).</li>
                                                <li><strong>Preferensi Lokasi (10% / 0.10)</strong> &bull; Atribut <em>Benefit</em>: Kenyamanan, akses jarak, dan akomodasi.</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="border rounded p-3 h-100 bg-light">
                                            <h6 class="font-bold text-dark"><i class="bi bi-gear-fill text-primary me-2"></i>Tahapan Perhitungan SAW:</h6>
                                            <ol class="mb-0 mt-2">
                                                <li><strong>Input Data:</strong> Masukkan pilihan alternatif jurusan dan nilai kecocokan masing-masing kriteria.</li>
                                                <li><strong>Normalisasi Matriks ($R$):</strong> Menyesuaikan skala nilai berdasarkan jenis kriteria (benefit atau cost).</li>
                                                <li><strong>Perangkingan Nilai Preferensi ($P$):</strong> Mengalikan nilai ternormalisasi dengan vektor bobot ($W$). Skor tertinggi adalah rekomendasi utama.</li>
                                            </ol>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <?php require "layout/footer.php"; ?>
        </div>
    </div>
    <?php require "layout/js.php"; ?>
</body>

</html>
