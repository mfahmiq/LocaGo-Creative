<?php
require_once "include/auth.php";
require_once "include/conn.php";

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($id) {
    // Hapus data evaluasi terkait terlebih dahulu
    $stmtEval = $db->prepare("DELETE FROM saw_evaluations WHERE id_criteria = ?");
    $stmtEval->bind_param("i", $id);
    $stmtEval->execute();
    $stmtEval->close();

    // Hapus data kriteria
    $stmtCrit = $db->prepare("DELETE FROM saw_criterias WHERE id_criteria = ?");
    $stmtCrit->bind_param("i", $id);
    $stmtCrit->execute();
    $stmtCrit->close();
}

header("Location: ./bobot.php");
exit();
?>
