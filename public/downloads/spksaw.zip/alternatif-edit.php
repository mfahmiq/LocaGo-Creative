<?php
require_once "include/auth.php";
require_once "include/conn.php";

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    header("location:./alternatif.php");
    exit();
}

$stmt = $db->prepare("SELECT * FROM saw_alternatives WHERE id_alternative = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if (!$row) {
    header("location:./alternatif.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<?php require "layout/head.php"; ?>

<body>
    <div id="app">
        <?php require "layout/sidebar.php"; ?>
        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                </a>
            </header>
            <div class="page-heading">
                <h3 style="color: #435EBE;">Edit Data Jurusan Kuliah</h3>
            </div>
            <div class="page-content">
                <section class="row">
                    <div class="col-md-8 col-12">
                        <div class="card shadow-sm border-0">
                            <div class="card-header bg-light">
                                <h5 class="card-title mb-0">Ubah Data Alternatif</h5>
                            </div>
                            <div class="card-body mt-3">
                                <form action="alternatif-edit-act.php" method="POST">
                                    <input type="hidden" name="id_alternative" value="<?= (int)$row['id_alternative']; ?>">
                                    <div class="form-group mb-3">
                                        <label class="form-label font-bold">Nama Program Studi &amp; Universitas:</label>
                                        <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8'); ?>" required autocomplete="off">
                                    </div>
                                    <div class="form-group mt-4">
                                        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                                        <a href="alternatif.php" class="btn btn-secondary ms-2">Batal</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <?php require "layout/footer.php"; ?>
        </div>
    </div>
    <?php require "layout/js.php"; ?>
</body>

</html>