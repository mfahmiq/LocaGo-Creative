<?php
require_once "include/auth.php";
require_once "include/conn.php";

$id = filter_input(INPUT_POST, 'id_criteria', FILTER_VALIDATE_INT);
$criteria = trim($_POST['criteria'] ?? '');
$weight = filter_input(INPUT_POST, 'weight', FILTER_VALIDATE_FLOAT);
$attribute = trim($_POST['attribute'] ?? 'benefit');

if ($id && !empty($criteria) && $weight !== false && in_array($attribute, ['benefit', 'cost'])) {
    $stmt = $db->prepare("UPDATE saw_criterias SET criteria = ?, weight = ?, attribute = ? WHERE id_criteria = ?");
    $stmt->bind_param("sdsi", $criteria, $weight, $attribute, $id);
    $stmt->execute();
    $stmt->close();
}

header("location:./bobot.php");
exit();
?>
