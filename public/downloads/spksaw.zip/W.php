<?php
/**
 * W.php - Ekstraksi Vektor Bobot Kriteria (W)
 */
require_once "include/conn.php";

$sql = "SELECT weight FROM saw_criterias ORDER BY id_criteria ASC";
$result = $db->query($sql);
$W = array();
while ($row = $result->fetch_object()) {
    $W[] = (float)$row->weight;
}
$result->free();
?>
