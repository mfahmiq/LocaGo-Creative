<!DOCTYPE html>
<html lang="id">
<?php
require "layout/head.php";
require "include/conn.php";
require "W.php";
require "R.php";

// Ambil data alternatif jurusan dari database
$sql = 'SELECT id_alternative, name FROM saw_alternatives ORDER BY id_alternative ASC';
$result = $db->query($sql);
$alternatives = [];
while ($row = $result->fetch_object()) {
  $alternatives[$row->id_alternative] = $row->name;
}
$result->free();
?>

<body>
  <div id="app">
    <?php require "layout/sidebar.php"; ?>
    <div id="main">
      <header class="mb-3">
        <a href="#" class="burger-btn d-block d-xl-none">
          <i class="bi bi-justify fs-3"></i>
        </a>
      </header>
      
      <div class="page-heading">
        <h3 style="color: #435EBE;">Hasil Rekomendasi &amp; Nilai Preferensi ($P_i$)</h3>
        <p class="text-subtitle text-muted">Perangkingan pilihan jurusan kuliah terbaik berdasarkan penjumlahan perkalian matriks ternormalisasi ($R$) dan vektor bobot ($W$).</p>
      </div>

      <div class="page-content">
        <section class="row">
          <div class="col-12">
            <div class="card shadow-sm border-0">
              <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Peringkat Rekomendasi Jurusan Kuliah Siswa</h5>
                <button type="button" class="btn btn-primary btn-sm shadow" data-bs-toggle="modal" data-bs-target="#preferenceModal">
                  <i class="bi bi-info-circle me-1"></i> Rumus Nilai Preferensi
                </button>
              </div>

              <div class="card-body mt-3">
                <!-- Accordion Simulasi Perhitungan Sesuai PPT Kelompok -->
                <div class="accordion mb-4" id="preferenceExampleAccordion">
                  <div class="accordion-item border rounded">
                    <h2 class="accordion-header" id="headingExample">
                      <button class="accordion-button collapsed py-2" type="button" data-bs-toggle="collapse" data-bs-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                        <i class="bi bi-calculator me-2 text-primary"></i> <strong>Contoh Simulasi Perhitungan Skor SAW (Sesuai Slide 9 PPT)</strong>
                      </button>
                    </h2>
                    <div id="collapseExample" class="accordion-collapse collapse" aria-labelledby="headingExample" data-bs-parent="#preferenceExampleAccordion">
                      <div class="accordion-body bg-light">
                        <p class="mb-2">Formula perhitungan skor preferensi terbobot pada setiap alternatif jurusan:</p>
                        <div class="p-2 border rounded bg-white text-center font-monospace mb-3">
                          $$ P_i = \sum_{j=1}^{n} w_j \cdot R_{ij} $$
                          $$ \text{Skor Akhir} = (\text{Nilai Akademik} \times 0.4) + (\text{Kesesuaian Minat} \times 0.3) + (\text{Kesesuaian Budget} \times 0.2) + (\text{Preferensi Lokasi} \times 0.1) $$
                        </div>
                        <p class="mb-1"><strong>Simulasi untuk Siswa dengan Profil Nilai:</strong></p>
                        <ul class="mb-0">
                          <li>Nilai Akademik Ternormalisasi: $0.85 \times 0.40 = 0.3400$ ($34\%$)</li>
                          <li>Kesesuaian Minat Ternormalisasi: $0.90 \times 0.30 = 0.2700$ ($27\%$)</li>
                          <li>Kesesuaian Budget Ternormalisasi: $0.80 \times 0.20 = 0.1600$ ($16\%$)</li>
                          <li>Preferensi Lokasi Ternormalisasi: $0.70 \times 0.10 = 0.0700$ ($7\%$)</li>
                          <li><strong class="text-success">Total Skor Akhir = 0.8400 (84.00% Cocok)</strong></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Modal Rumus Nilai Preferensi -->
                <div class="modal fade" id="preferenceModal" tabindex="-1" aria-labelledby="preferenceModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title text-white" id="preferenceModalLabel">Rumus Nilai Preferensi (Metode SAW)</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                        <p>Nilai preferensi untuk setiap alternatif jurusan ($P_i$) dihitung dengan menjumlahkan hasil kali elemen baris matriks ternormalisasi ($R_{ij}$) dengan bobot kriteria ($w_j$):</p>
                        <div class="text-center p-3 my-2 bg-light rounded border">
                          $$ P_i = \sum_{j=1}^{n} w_j \cdot R_{ij} $$
                        </div>
                        <ul class="mb-0 mt-3">
                          <li><strong>$P_i$</strong>: Nilai preferensi akhir alternatif jurusan ke-$i$.</li>
                          <li><strong>$w_j$</strong>: Nilai bobot dari kriteria ke-$j$.</li>
                          <li><strong>$R_{ij}$</strong>: Nilai rating kinerja ternormalisasi jurusan $i$ pada kriteria $j$.</li>
                          <li><strong>$n$</strong>: Jumlah total kriteria penilaian.</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Tabel Hasil Perangkingan -->
                <div class="table-responsive">
                  <table class="table table-striped table-hover mb-0" style="width: 100%; font-size: 14px;">
                    <thead style="background-color: #435EBE; color: #fff;">
                      <tr>
                        <th style="width: 80px; text-align: center;">Peringkat</th>
                        <th>Program Studi &amp; Perguruan Tinggi</th>
                        <th style="text-align: center;">Nilai Preferensi ($P_i$)</th>
                        <th style="text-align: center;">Tingkat Kecocokan (%)</th>
                        <th style="width: 200px; text-align: center;">Status Rekomendasi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $P = array();

                      if (empty($W) || empty($R)) {
                        echo "<tr>
                                <td colspan='5' class='text-center py-4 text-muted'>Belum ada data evaluasi. Silakan isi nilai jurusan terlebih dahulu di menu <strong>Matriks Keputusan</strong>.</td>
                              </tr>";
                      } else {
                        $m = count($W);

                        // Hitung nilai preferensi (P)
                        foreach ($R as $id_alt => $r_row) {
                          $score = 0;
                          for ($j = 0; $j < $m; $j++) {
                            $r_val = isset($r_row[$j]) ? (float)$r_row[$j] : 0;
                            $w_val = isset($W[$j]) ? (float)$W[$j] : 0;
                            $score += ($r_val * $w_val);
                          }
                          $P[$id_alt] = $score;
                        }

                        // Urutkan nilai preferensi dari tertinggi ke terendah
                        arsort($P);

                        $rank = 1;
                        foreach ($P as $id_alt => $score) {
                          $alt_name = isset($alternatives[$id_alt]) ? htmlspecialchars($alternatives[$id_alt], ENT_QUOTES, 'UTF-8') : "Jurusan #{$id_alt}";
                          $score_formatted = number_format($score, 4);
                          $percentage = number_format($score * 100, 2) . '%';

                          // Badge perankingan
                          if ($rank === 1) {
                            $badge_rank = "<span class='badge bg-warning text-dark fs-6'><i class='bi bi-trophy-fill me-1'></i> 1</span>";
                            $status = "<span class='badge bg-success'><i class='bi bi-check-circle-fill me-1'></i> Rekomendasi Utama</span>";
                            $row_class = "table-success";
                          } elseif ($rank === 2) {
                            $badge_rank = "<span class='badge bg-secondary fs-6'>2</span>";
                            $status = "<span class='badge bg-primary'>Rekomendasi Alternatif 2</span>";
                            $row_class = "";
                          } elseif ($rank === 3) {
                            $badge_rank = "<span class='badge bg-danger fs-6'>3</span>";
                            $status = "<span class='badge bg-info text-dark'>Rekomendasi Alternatif 3</span>";
                            $row_class = "";
                          } else {
                            $badge_rank = "<span class='badge bg-light text-dark border fs-6'>{$rank}</span>";
                            $status = "<span class='badge bg-light text-muted border'>Pilihan {$rank}</span>";
                            $row_class = "";
                          }

                          echo "<tr class='{$row_class}'>
                                  <td class='text-center align-middle'>{$badge_rank}</td>
                                  <td class='align-middle font-bold'>{$alt_name}</td>
                                  <td class='text-center align-middle font-monospace font-bold text-primary'>{$score_formatted}</td>
                                  <td class='text-center align-middle font-bold text-success'>{$percentage}</td>
                                  <td class='text-center align-middle'>{$status}</td>
                                </tr>";
                          $rank++;
                        }
                      }
                      ?>
                    </tbody>
                  </table>
                </div>

              </div>
            </div>
          </div>
        </section>
      </div>
      <?php require "layout/footer.php"; ?>
    </div>
  </div>
  <?php require "layout/js.php"; ?>
</body>

</html>