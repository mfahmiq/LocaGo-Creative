-- Database: `db_saw`
-- Sistem Pendukung Keputusan Pemilihan Jurusan Kuliah (Metode SAW)
-- Tugas Kelompok 6 - Sistem Informasi

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------

--
-- Struktur dari tabel `saw_users`
--

CREATE TABLE IF NOT EXISTS `saw_users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `saw_users`
-- Hash MD5 default: 21232f297a57a5a743894a0e4a801fc3 (admin)
--

INSERT INTO `saw_users` (`id_user`, `username`, `password`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `saw_alternatives`
--

CREATE TABLE IF NOT EXISTS `saw_alternatives` (
  `id_alternative` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id_alternative`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data alternatif pilihan jurusan kuliah
--

INSERT INTO `saw_alternatives` (`id_alternative`, `name`) VALUES
(1, 'Ilmu Komputer UI'),
(2, 'STEI ITB'),
(3, 'Teknik Informatika UNILA'),
(4, 'Bisnis Digital UNPAD'),
(5, 'Sistem Informasi ITS');

-- --------------------------------------------------------

--
-- Struktur dari tabel `saw_criterias`
--

CREATE TABLE IF NOT EXISTS `saw_criterias` (
  `id_criteria` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT,
  `criteria` varchar(100) NOT NULL,
  `weight` float NOT NULL,
  `attribute` enum('benefit','cost') NOT NULL DEFAULT 'benefit',
  PRIMARY KEY (`id_criteria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data kriteria pemilihan jurusan (Sesuai PPT Kelompok: 40%, 30%, 20%, 10%)
--

INSERT INTO `saw_criterias` (`id_criteria`, `criteria`, `weight`, `attribute`) VALUES
(1, 'Nilai Akademik', 0.4, 'benefit'),
(2, 'Kesesuaian Minat', 0.3, 'benefit'),
(3, 'Biaya Kuliah', 0.2, 'cost'),
(4, 'Preferensi Lokasi', 0.1, 'benefit');

-- --------------------------------------------------------

--
-- Struktur dari tabel `saw_evaluations`
--

CREATE TABLE IF NOT EXISTS `saw_evaluations` (
  `id_alternative` smallint(5) UNSIGNED NOT NULL,
  `id_criteria` tinyint(3) UNSIGNED NOT NULL,
  `value` float NOT NULL,
  PRIMARY KEY (`id_alternative`,`id_criteria`),
  CONSTRAINT `fk_eval_alternative` FOREIGN KEY (`id_alternative`) REFERENCES `saw_alternatives` (`id_alternative`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_eval_criteria` FOREIGN KEY (`id_criteria`) REFERENCES `saw_criterias` (`id_criteria`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data evaluasi rating kecocokan jurusan
--

INSERT INTO `saw_evaluations` (`id_alternative`, `id_criteria`, `value`) VALUES
(1, 1, 88), -- Ilmu Komputer UI: Akademik 88
(1, 2, 95), -- Minat 95
(1, 3, 15), -- Biaya (juta/smt) 15
(1, 4, 90), -- Lokasi 90

(2, 1, 85), -- STEI ITB: Akademik 85
(2, 2, 85), -- Minat 85
(2, 3, 12), -- Biaya 12
(2, 4, 80), -- Lokasi 80

(3, 1, 80), -- Teknik Informatika UNILA: Akademik 80
(3, 2, 75), -- Minat 75
(3, 3, 10), -- Biaya 10
(3, 4, 95), -- Lokasi 95

(4, 1, 82), -- Bisnis Digital UNPAD: Akademik 82
(4, 2, 80), -- Minat 80
(4, 3, 11), -- Biaya 11
(4, 4, 85), -- Lokasi 85

(5, 1, 84), -- Sistem Informasi ITS: Akademik 84
(5, 2, 82), -- Minat 82
(5, 3, 13), -- Biaya 13
(5, 4, 82); -- Lokasi 82

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
