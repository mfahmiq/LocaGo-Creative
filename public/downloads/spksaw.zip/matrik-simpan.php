<?php
require_once "include/auth.php";
require_once "include/conn.php";

$id_alternative = filter_input(INPUT_POST, 'id_alternative', FILTER_VALIDATE_INT);
$id_criteria = filter_input(INPUT_POST, 'id_criteria', FILTER_VALIDATE_INT);
$value = filter_input(INPUT_POST, 'value', FILTER_VALIDATE_FLOAT);

if ($id_alternative && $id_criteria && $value !== false) {
    // Gunakan ON DUPLICATE KEY UPDATE agar tidak terjadi tabrakan primary key
    $sql = "INSERT INTO saw_evaluations (id_alternative, id_criteria, value) 
            VALUES (?, ?, ?) 
            ON DUPLICATE KEY UPDATE value = VALUES(value)";
            
    $stmt = $db->prepare($sql);
    $stmt->bind_param("iid", $id_alternative, $id_criteria, $value);
    $stmt->execute();
    $stmt->close();
}

header("location:./matrik.php");
exit();
?>
