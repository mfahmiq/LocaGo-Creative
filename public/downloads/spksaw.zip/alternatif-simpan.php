<?php
require_once "include/auth.php";
require_once "include/conn.php";

$name = trim($_POST['name'] ?? '');

if (!empty($name)) {
    $stmt = $db->prepare("INSERT INTO saw_alternatives (name) VALUES (?)");
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $stmt->close();
}

header("location:./alternatif.php");
exit();
?>
