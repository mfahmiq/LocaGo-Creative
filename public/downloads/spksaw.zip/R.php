<?php
/**
 * R.php - Modul Normalisasi Matriks (R) Dinamis
 * Menghitung nilai ternormalisasi berdasarkan tipe kriteria (Benefit atau Cost)
 * Tanpa hardcoded kriteria sehingga fleksibel untuk berapapun jumlah kriteria.
 */
require_once "include/conn.php";

// 1. Ambil seluruh data kriteria dan atributnya
$crit_res = $db->query("SELECT id_criteria, attribute FROM saw_criterias ORDER BY id_criteria ASC");
$criterias_attr = [];
while ($c = $crit_res->fetch_object()) {
    $criterias_attr[$c->id_criteria] = $c->attribute;
}

// 2. Ambil nilai evaluasi dan kumpulkan nilai per kriteria untuk mencari max & min
$eval_res = $db->query("SELECT id_alternative, id_criteria, value FROM saw_evaluations ORDER BY id_alternative, id_criteria");
$raw_values = [];
$evaluations = [];
while ($e = $eval_res->fetch_object()) {
    $raw_values[$e->id_criteria][] = (float)$e->value;
    $evaluations[$e->id_alternative][$e->id_criteria] = (float)$e->value;
}

// 3. Tentukan nilai ekstremum (Max untuk Benefit, Min untuk Cost)
$extremum = [];
foreach ($criterias_attr as $id_crit => $attr) {
    $vals = $raw_values[$id_crit] ?? [];
    if (!empty($vals)) {
        $extremum[$id_crit] = ($attr === 'benefit') ? max($vals) : min($vals);
    } else {
        $extremum[$id_crit] = 1;
    }
}

// 4. Hitung Matriks Ternormalisasi R secara dinamis
$R = [];
foreach ($evaluations as $id_alt => $crit_vals) {
    $R[$id_alt] = [];
    foreach ($criterias_attr as $id_crit => $attr) {
        $val = $crit_vals[$id_crit] ?? 0;
        $ext = $extremum[$id_crit] ?? 1;

        if ($attr === 'benefit') {
            $normalized = ($ext > 0) ? ($val / $ext) : 0;
        } else { // cost
            $normalized = ($val > 0) ? ($ext / $val) : 0;
        }
        $R[$id_alt][] = $normalized; // Urut sesuai indeks kriteria
    }
}
?>
