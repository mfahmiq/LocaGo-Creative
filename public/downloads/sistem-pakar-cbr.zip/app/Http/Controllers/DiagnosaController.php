<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DiagnosaController extends Controller
{
    //Menampilkan Semua Kasus, Gejala, & Matriks Relasi
    public function index()
    {
        $allKasus = DB::table('kasuss')->orderByRaw('LENGTH(kode_kasus) ASC, kode_kasus ASC')->get();
        $allGejala = DB::table('gejalas')->orderByRaw('LENGTH(kode_gejala) ASC, kode_gejala ASC')->get(); 
        $relasiRaw = DB::table('relasiss')->get();
        $matriksRelasi = [];
        foreach ($relasiRaw as $rel) {
            $matriksRelasi[$rel->gejala_id][$rel->kasus_id] = $rel->weight;
        }
        return view('diagnosa', compact('allKasus', 'allGejala', 'matriksRelasi'));
    }
    //Input Kasus
    public function showProsesForm()
    {
        $dataKasus = DB::table('kasuss')
            ->orderByRaw('LENGTH(kode_kasus) ASC, kode_kasus ASC')
            ->get();
        return view('diagnosa_proses', compact('dataKasus'));
    }

    //LOGIKA PROSES: Hitung CBR & Simpan Hasil ke Session, Lalu Redirect
    public function proses(Request $request)
    {
        $kasusInputIds = $request->input('kasus_ids', []);

        if (empty($kasusInputIds)) {
            return redirect()->route('admin.diagnosa.proses.form')->with('error', 'Silakan pilih minimal satu kasus acuan!');
        }
        $dataRelasiKasusInput = DB::table('relasiss')
            ->whereIn('kasus_id', $kasusInputIds)
            ->get();
        $petaBobotKasus = [];
        foreach ($dataRelasiKasusInput as $r) {
            $petaBobotKasus[$r->kasus_id] = $r->weight;
        }
        $penyebut = array_sum($petaBobotKasus);
        if ($penyebut == 0) { $penyebut = 1; }
        $pembentukPenyebut = [];
        foreach ($kasusInputIds as $kasusId) {
            $pembentukPenyebut[] = $petaBobotKasus[$kasusId] ?? 0;
        }
        $tracePenyebutString = implode(' + ', $pembentukPenyebut);
        $allGejala = DB::table('gejalas')->orderByRaw('LENGTH(kode_gejala) ASC, kode_gejala ASC')->get();
        $matriksKalkulasiGejala = [];
        foreach ($allGejala as $gejala) {
            $pembilang = 0;
            $partStep1 = [];
            $partStep2 = []; 

            foreach ($kasusInputIds as $kasusId) {
                $relasi = DB::table('relasiss')
                    ->where('gejala_id', $gejala->id)
                    ->where('kasus_id', $kasusId)
                    ->first();

                $bobotKasus = $petaBobotKasus[$kasusId] ?? 0;
                if ($relasi) {
                    $pembilang += (1 * $bobotKasus);
                    $partStep1[] = "(1 * " . $bobotKasus . ")";
                    $partStep2[] = $bobotKasus;
                } else {
                    $pembilang += (0 * $bobotKasus);
                    $partStep1[] = "(0 * " . $bobotKasus . ")";
                    $partStep2[] = "0";
                }
            }
            $stringStep1 = implode(' + ', $partStep1);
            $stringStep2 = implode(' + ', $partStep2);

            $score = $penyebut > 0 ? ($pembilang / $penyebut) : 0;
            $scoreRounded = round($score, 3);
            $persentase = round($scoreRounded * 100, 1);

            $matriksKalkulasiGejala[] = [
                'kode_gejala'       => $gejala->kode_gejala,
                'nama_gejala'       => $gejala->gejala,
                'pembilang'         => $pembilang,
                'penyebut'          => $penyebut,
                'trace_pembilang_1' => $stringStep1, // Teks langkah perkalian
                'trace_pembilang_2' => $stringStep2, // Teks langkah penjumlahan
                'trace_penyebut'    => $tracePenyebutString, // Teks baris bawah penyebut
                'score'             => $scoreRounded,
                'persentase'        => $persentase
            ];
        }
        usort($matriksKalkulasiGejala, function ($a, $b) {
            return $b['score'] <=> $a['score'];
        });
        session(['hasil_cbr' => $matriksKalkulasiGejala]);
        return redirect()->route('admin.diagnosa.hasil');
    }
    public function hasil()
    {
        $matriksKalkulasiGejala = session('hasil_cbr');
        if (!$matriksKalkulasiGejala) {
            return redirect()->route('admin.diagnosa.proses.form')->with('error', 'Belum ada data diagnosa.');
        }
        return view('diagnosa_hasil', compact('matriksKalkulasiGejala'));
    }
}