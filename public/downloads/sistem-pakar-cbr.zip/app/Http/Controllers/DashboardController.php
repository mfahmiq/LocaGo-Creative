<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        // Mengambil statistik langsung dari tabel database lama Anda
        $totalKasus = DB::table('kasuss')->count();
        $totalGejala = DB::table('gejalas')->count();
        $totalRelasi = DB::table('relasiss')->count();

        return view('dashboard', compact('totalKasus', 'totalGejala', 'totalRelasi'));
    }
}