<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KasusController extends Controller
{
    //Menampilkan Data Kasus
    public function index()
    {
        $dataKasus = DB::table('kasuss')->orderByRaw('LENGTH(kode_kasus) ASC, kode_kasus ASC')->get();
        return view('kasus', compact('dataKasus'));
    }

    //Form Tambah Kasus
    public function create()
    {
        return view('kasus_create');
    }
    //Menyimpan Data Kasus Baru
    public function store(Request $request)
    {
        // Validasi Input Form
        $request->validate([
            'kode_kasus' => 'required|unique:kasuss,kode_kasus',
            'kasus' => 'required',
        ], [
            'kode_kasus.required' => 'Kode kasus wajib diisi!',
            'kode_kasus.unique' => 'Kode kasus sudah terdaftar!',
            'kasus.required' => 'Nama kerusakan kasus wajib diisi!',
        ]);
        // Simpan Ke Database
        DB::table('kasuss')->insert([
            'kode_kasus' => strtoupper($request->kode_kasus),
            'kasus' => $request->kasus,
        ]);
        return redirect()->route('admin.kasus.index')->with('success', 'Data Kasus berhasil ditambahkan!');
    }
    //Form Edit Kasus
    public function edit($id)
    {
        $kasus = DB::table('kasuss')->where('id', $id)->first();
        if (!$kasus) {
            return redirect()->route('admin.kasus.index')->with('error', 'Data tidak ditemukan!');
        }
        return view('kasus_edit', compact('kasus'));
    }
    //Update Data Kasus
    public function update(Request $request, $id)
    {
        $request->validate([
            'kode_kasus' => 'required|unique:kasuss,kode_kasus,' . $id,
            'kasus' => 'required',
        ], [
            'kode_kasus.required' => 'Kode kasus wajib diisi!',
            'kode_kasus.unique' => 'Kode kasus sudah digunakan oleh data lain!',
            'kasus.required' => 'Nama kerusakan kasus wajib diisi!',
        ]);
        DB::table('kasuss')->where('id', $id)->update([
            'kode_kasus' => strtoupper($request->kode_kasus),
            'kasus' => $request->kasus,
        ]);
        return redirect()->route('admin.kasus.index')->with('success', 'Data Kasus berhasil diperbarui!');
    }
    //Hapus Data Kasus
    public function destroy($id)
    {
        DB::table('relasiss')->where('kasus_id', $id)->delete();
        DB::table('kasuss')->where('id', $id)->delete();
        return redirect()->route('admin.kasus.index')->with('success', 'Data Kasus berhasil dihapus!');
    }
}