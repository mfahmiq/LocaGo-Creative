<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RelasiController extends Controller
{
    //Menampilkan Tabel Relasi
    public function index()
    {
        $dataRelasi = DB::table('relasiss')
            ->join('kasuss', 'relasiss.kasus_id', '=', 'kasuss.id')
            ->join('gejalas', 'relasiss.gejala_id', '=', 'gejalas.id')
            ->select('relasiss.*', 'kasuss.kode_kasus', 'kasuss.kasus', 'gejalas.kode_gejala', 'gejalas.gejala')
            ->orderByRaw('LENGTH(kasuss.kode_kasus) ASC, kasuss.kode_kasus ASC')
            ->orderByRaw('LENGTH(gejalas.kode_gejala) ASC, gejalas.kode_gejala ASC')
            ->get();
        return view('relasi', compact('dataRelasi'));
    }
    //Form Tambah Relasi
    public function create()
    {
        $allKasus = DB::table('kasuss')->orderByRaw('LENGTH(kode_kasus) ASC, kode_kasus ASC')->get();
        $allGejala = DB::table('gejalas')->orderByRaw('LENGTH(kode_gejala) ASC, kode_gejala ASC')->get();
        return view('relasi_create', compact('allKasus', 'allGejala'));
    }
    //Menyimpan Data Relasi Baru
    public function store(Request $request)
    {
        $request->validate([
            'kasus_id' => 'required',
            'gejala_id' => 'required',
            'weight' => 'required|numeric|min:1|max:5',
        ], [
            'kasus_id.required' => 'Silakan pilih kasus permasalahan!',
            'gejala_id.required' => 'Silakan pilih gejala kerusakan!',
            'weight.required' => 'Nilai bobot wajib ditentukan!',
            'weight.numeric' => 'Bobot harus berupa angka!',
            'weight.min' => 'Bobot minimal berbobot 1!',
            'weight.max' => 'Bobot maksimal berbobot 5!',
        ]);
        // Mengecek Kombinasi Antar Kasus Dan Gejala
        $cekDuplikat = DB::table('relasiss')
            ->where('kasus_id', $request->kasus_id)
            ->where('gejala_id', $request->gejala_id)
            ->first();
        if ($cekDuplikat) {
            return redirect()->back()->withInput()->with('error', 'Kombinasi Kasus dan Gejala tersebut sudah terdaftar! Silakan edit data yang sudah ada.');
        }
        DB::table('relasiss')->insert([
            'kasus_id' => $request->kasus_id,
            'gejala_id' => $request->gejala_id,
            'weight' => $request->weight,
        ]);
        return redirect()->route('admin.relasi.index')->with('success', 'Hubungan relasi bobot berhasil ditambahkan!');
    }
    //Form Edit Relasi
    public function edit($id)
    {
        $relasi = DB::table('relasiss')->where('id', $id)->first();
        if (!$relasi) {
            return redirect()->route('admin.relasi.index')->with('error', 'Data tidak ditemukan!');
        }
        $allKasus = DB::table('kasuss')->orderByRaw('LENGTH(kode_kasus) ASC, kode_kasus ASC')->get();
        $allGejala = DB::table('gejalas')->orderByRaw('LENGTH(kode_gejala) ASC, kode_gejala ASC')->get();
        return view('relasi_edit', compact('relasi', 'allKasus', 'allGejala'));
    }
    //Update Data Relasi
    public function update(Request $request, $id)
    {
        $request->validate([
            'kasus_id' => 'required',
            'gejala_id' => 'required',
            'weight' => 'required|numeric|min:1|max:5',
        ], [
            'weight.required' => 'Nilai bobot wajib ditentukan!',
            'weight.numeric' => 'Bobot harus berupa angka!',
        ]);
        // Cek Duplikat
        $cekDuplikat = DB::table('relasiss')
            ->where('kasus_id', $request->kasus_id)
            ->where('gejala_id', $request->gejala_id)
            ->where('id', '!=', $id)
            ->first();
        if ($cekDuplikat) {
            return redirect()->back()->withInput()->with('error', 'Gagal update! Kombinasi Kasus dan Gejala tersebut sudah digunakan pada relasi lain.');
        }
        DB::table('relasiss')->where('id', $id)->update([
            'kasus_id' => $request->kasus_id,
            'gejala_id' => $request->gejala_id,
            'weight' => $request->weight,
        ]);
        return redirect()->route('admin.relasi.index')->with('success', 'Hubungan relasi bobot berhasil diperbarui!');
    }
    //Hapus Data Relasi
    public function destroy($id)
    {
        DB::table('relasiss')->where('id', $id)->delete();
        return redirect()->route('admin.relasi.index')->with('success', 'Hubungan relasi bobot berhasil dihapus!');
    }
}