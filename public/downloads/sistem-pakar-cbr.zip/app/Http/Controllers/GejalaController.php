<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GejalaController extends Controller
{
    //Menampilkan Data Gejala
    public function index()
    {
        $dataGejala = DB::table('gejalas')
            ->orderByRaw('LENGTH(kode_gejala) ASC, kode_gejala ASC')
            ->get();
            
        return view('gejala', compact('dataGejala'));
    }
    //Form Tambah Gejala
    public function create()
    {
        return view('gejala_create');
    }
    //Menyimpan Data Gejala Baru
    public function store(Request $request)
    {
        $request->validate([
            'kode_gejala' => 'required|unique:gejalas,kode_gejala',
            'gejala' => 'required',
        ], [
            'kode_gejala.required' => 'Kode gejala wajib diisi!',
            'kode_gejala.unique' => 'Kode gejala sudah terdaftar!',
            'gejala.required' => 'Nama gejala kerusakan wajib diisi!',
        ]);
        DB::table('gejalas')->insert([
            'kode_gejala' => strtoupper($request->kode_gejala),
            'gejala' => $request->gejala,
        ]);
        return redirect()->route('admin.gejala.index')->with('success', 'Data Gejala berhasil ditambahkan!');
    }
    //Form Edit Gejala
    public function edit($id)
    {
        $gejala = DB::table('gejalas')->where('id', $id)->first();
        if (!$gejala) {
            return redirect()->route('admin.gejala.index')->with('error', 'Data tidak ditemukan!');
        }
        return view('gejala_edit', compact('gejala'));
    }
    //Update Data Gejala
    public function update(Request $request, $id)
    {
        $request->validate([
            'kode_gejala' => 'required|unique:gejalas,kode_gejala,' . $id,
            'gejala' => 'required',
        ], [
            'kode_gejala.required' => 'Kode gejala wajib diisi!',
            'kode_gejala.unique' => 'Kode gejala sudah digunakan oleh data lain!',
            'gejala.required' => 'Nama gejala kerusakan wajib diisi!',
        ]);

        DB::table('gejalas')->where('id', $id)->update([
            'kode_gejala' => strtoupper($request->kode_gejala),
            'gejala' => $request->gejala,
        ]);

        return redirect()->route('admin.gejala.index')->with('success', 'Data Gejala berhasil diperbarui!');
    }
    //Hapus Data Gejala
    public function destroy($id)
    {
        DB::table('relasiss')->where('gejala_id', $id)->delete();
        DB::table('gejalas')->where('id', $id)->delete();
        return redirect()->route('admin.gejala.index')->with('success', 'Data Gejala berhasil dihapus!');
    }
}