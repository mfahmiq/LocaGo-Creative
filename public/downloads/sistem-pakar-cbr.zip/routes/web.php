<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\KasusController;
use App\Http\Controllers\GejalaController;
use App\Http\Controllers\RelasiController;
use App\Http\Controllers\DiagnosaController;

Route::get('/', function () {
    return view('login');
});
//Login
Route::get('/', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/', [AuthController::class, 'login'])->name('login.proses');
//Logout
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
//Register
Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register');
Route::post('/register', [AuthController::class, 'register']);
//Lupa Password
Route::get('/forgot_password', [AuthController::class, 'showForgotPasswordForm'])->name('password.request');
Route::post('/forgot_password', [AuthController::class, 'resetPassword'])->name('password.update');

Route::middleware(['auth'])->name('admin.')->group(function () {
    //Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    //Kasus
    Route::get('/kasus', [KasusController::class, 'index'])->name('kasus.index');
    Route::get('/kasus/create', [KasusController::class, 'create'])->name('kasus.create');
    Route::post('/kasus/store', [KasusController::class, 'store'])->name('kasus.store');
    Route::get('/kasus/{id}/edit', [KasusController::class, 'edit'])->name('kasus.edit');
    Route::post('/kasus/{id}', [KasusController::class, 'update'])->name('kasus.update');
    Route::delete('/kasus/{id}', [KasusController::class, 'destroy'])->name('kasus.destroy');
    //Gejala
    Route::get('/gejala', [GejalaController::class, 'index'])->name('gejala.index');
    Route::get('/gejala/create', [GejalaController::class, 'create'])->name('gejala.create');
    Route::post('/gejala/store', [GejalaController::class, 'store'])->name('gejala.store');
    Route::get('/gejala/{id}/edit', [GejalaController::class, 'edit'])->name('gejala.edit');
    Route::post('/gejala/{id}', [GejalaController::class, 'update'])->name('gejala.update');
    Route::delete('/gejala/{id}', [GejalaController::class, 'destroy'])->name('gejala.destroy');
    //Relasi
    Route::get('/relasi', [RelasiController::class, 'index'])->name('relasi.index');
    Route::get('/relasi/create', [RelasiController::class, 'create'])->name('relasi.create');
    Route::post('/relasi/store', [RelasiController::class, 'store'])->name('relasi.store');
    Route::get('/relasi/{id}/edit', [RelasiController::class, 'edit'])->name('relasi.edit');
    Route::post('/relasi/{id}', [RelasiController::class, 'update'])->name('relasi.update');
    Route::delete('/relasi/{id}', [RelasiController::class, 'destroy'])->name('relasi.destroy');
    //Diagnosa
    Route::get('/diagnosa', [DiagnosaController::class, 'index'])->name('diagnosa.index');
    Route::get('/diagnosa/proses', [DiagnosaController::class, 'showProsesForm'])->name('diagnosa.proses.form');
    Route::post('/diagnosa/proses', [DiagnosaController::class, 'proses'])->name('diagnosa.proses');
    Route::get('/diagnosa/hasil', [DiagnosaController::class, 'hasil'])->name('diagnosa.hasil');
});