-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 04, 2026 at 03:17 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sistempakarcbr`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gejalas`
--

CREATE TABLE `gejalas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kode_gejala` varchar(50) NOT NULL,
  `gejala` varchar(50) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gejalas`
--

INSERT INTO `gejalas` (`id`, `kode_gejala`, `gejala`, `deskripsi`, `created_at`, `updated_at`) VALUES
(1, 'G01', 'Kipas Pendingin (Fan) Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(2, 'G02', 'GPU/Grafis Error', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(3, 'G03', 'CPU/Prosesor Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(4, 'G04', 'Layar/Display Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(5, 'G05', 'Daya/Power Supply Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(6, 'G06', 'Input Device (Keyboard, Touchpad) Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(7, 'G07', 'Sistem Operasi/Driver Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(8, 'G08', 'Frame Rate/FPS Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(9, 'G09', 'Sistem Pendingin (Cooling System) Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(10, 'G10', 'Baterai/Pengisian Daya Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(11, 'G11', 'Port/Konektivitas Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(12, 'G12', 'Audio/Speaker Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(13, 'G13', 'Motherboard/VRM Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(14, 'G14', 'BIOS/Firmware Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(15, 'G15', 'Kipas Pendingin (Fan) Bermasalah', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kasuss`
--

CREATE TABLE `kasuss` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kode_kasus` varchar(50) NOT NULL,
  `kasus` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kasuss`
--

INSERT INTO `kasuss` (`id`, `kode_kasus`, `kasus`, `deskripsi`, `created_at`, `updated_at`) VALUES
(1, 'K1', 'Overheat Berlebihan Saat Menjalankan Game Berat', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(2, 'K2', 'Thermal Throttling (Frekuensi CPU/GPU Turun Drastis)', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(3, 'K3', 'Blue Screen (BSOD) Dengan Kode Error Video Atau Graphics', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(4, 'K4', 'Artifact Pada Layar (Bintik/Gambar Pecah) Saat Game', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(5, 'K5', 'Frame Rate (FPS) Turun Tidak Wajar Meski Suhu Normal', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(6, 'K6', 'Laptop Mati Mendadak Saat Bermain Game Tanpa Overheat', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(7, 'K7', 'Kipas Pendingin Berputar Sangat Kencang Terus-Menerus', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(8, 'K8', 'Laptop Tidak Mau Menyala Setelah Digunakan Bermain Game', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(9, 'K9', 'Keyboard Ghosting Atau Tombol Tertentu Tidak Berfungsi Dalam Game', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(10, 'K10', 'Layar Berkedip (Flicker) Saat Refresh Rate Tinggi (120Hz/144Hz)', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(11, 'K11', 'Charging Terputus-Putus Saat Game (Daya Tidak Stabil)', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(12, 'K12', 'Performa Menurun Drastis Setelah Beberapa Menit Bermain', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(13, 'K13', 'Driver GPU Sering Crash Atau Not Responding', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(14, 'K14', 'Display Tiba-Tiba Berganti Ke Resolusi Rendah (640x480)', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(15, 'K15', 'Suara Kipas Tidak Normal (Berisik, Menggerinda)', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(16, 'K16', 'Touchpad Tidak Responsif Saat Suhu Laptop Tinggi', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(17, 'K17', 'Boot Gagal Atau Stuck Di Logo Setelah Instalasi Driver GPU Baru', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(18, 'K18', 'Game Keluar Sendiri (Crash To Desktop) Tanpa Pesan Error', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(19, 'K19', 'Muncul Pesan \"Power Surge On USB Port\" Saat Game', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(20, 'K20', 'Lampu Indikator Baterai Berkedip Merah Meski Terhubung Adaptor', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(21, 'K21', 'Refresh Rate Tidak Bisa Diatur Ke Nilai Maksimal', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(22, 'K22', 'BIOS Tidak Mendeteksi GPU Diskrit (NVIDIA/AMD Tidak Muncul)', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(23, 'K23', 'Suhu CPU/GPU Di Atas 95°C Meski Kipas Maksimal', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(24, 'K24', 'Warna Layar Pucat/Kuning Saat Game (Beda Profil Warna)', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(25, 'K25', 'FPS Tinggi Namun Terasa Stutter (Tidak Mulus)', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(26, 'K26', 'Fan Tidak Berputar Sama Sekali Meski Suhu Tinggi', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(27, 'K27', 'Motherboard Tidak Menyuplai Daya Ke GPU Diskrit', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(28, 'K28', 'VBIOS Korup Sehingga Resolusi Game Tidak Normal', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(29, 'K29', 'Thermal Paste Kering Menyebabkan Lonjakan Suhu', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(30, 'K30', 'Laptop Panas Berlebih Di Area Palm Rest Atau Keyboard', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(31, 'K31', 'GPU Overclocking Tidak Stabil Saat Game Berat', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(32, 'K32', 'Frame Drop Saat Mengaktifkan Ray Tracing', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(33, 'K33', 'Sistem Pendingin Cair (Liquid Cooling) Tidak Berfungsi', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(34, 'K34', 'Layar Mati Total Saat Memasuki Game Mode', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(35, 'K35', 'Suara Buzzing Pada Speaker Saat Volume Tinggi', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(36, 'K36', 'Port HDMI/USB-C Tidak Mengenali Monitor Eksternal', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(37, 'K37', 'Baterai Tidak Mengisi Daya Saat Laptop Digunakan Untuk Gaming', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(38, 'K38', 'Overheating Pada VRM (Voltage Regulator Module)', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(39, 'K39', 'Keyboard Backlight Mati Saat Suhu Meningkat', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(40, 'K40', 'Game Stuttering Parah Pada Setting Ultra', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(41, 'K41', 'Windows Tidak Mendeteksi GPU Kedua (Optimus/MUX Switch)', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(42, 'K42', 'Heatpipe Rusak Menyebabkan Distribusi Panas Tidak Merata', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(43, 'K43', 'Screen Tearing Parah Meski V-Sync Aktif', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(44, 'K44', 'Laptop Mati Total Saat Proses Rendering 3D', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(45, 'K45', 'Fan Curve Tidak Responsif Terhadap Beban Game', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(46, 'K46', 'Speaker Mengeluarkan Suara Distorsi Saat Game', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(47, 'K47', 'Tombol Power Tidak Responsif Setelah Overheat', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(48, 'K48', 'Performa GPU Turun Drastis Setelah Update Driver', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(49, 'K49', 'Chassis Laptop Terlalu Panas Untuk Digunakan Di Pangkuan', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21'),
(50, 'K50', 'Game Tidak Bisa Menjalankan DirectX 12 Mode', NULL, '2026-07-27 16:49:21', '2026-07-27 16:49:21');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2026_06_04_145735_create_kasuss_table', 1),
(5, '2026_06_04_145736_create_gejalas_table', 1),
(6, '2026_06_04_145736_create_relasiss_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `relasiss`
--

CREATE TABLE `relasiss` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kasus_id` bigint(20) UNSIGNED NOT NULL,
  `gejala_id` bigint(20) UNSIGNED NOT NULL,
  `weight` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `relasiss`
--

INSERT INTO `relasiss` (`id`, `kasus_id`, `gejala_id`, `weight`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 5, NULL, NULL),
(2, 1, 2, 5, NULL, NULL),
(3, 1, 4, 5, NULL, NULL),
(4, 1, 9, 5, NULL, NULL),
(8, 2, 1, 5, NULL, NULL),
(9, 2, 2, 5, NULL, NULL),
(10, 2, 3, 5, NULL, NULL),
(11, 2, 4, 5, NULL, NULL),
(12, 2, 8, 5, NULL, NULL),
(13, 2, 9, 5, NULL, NULL),
(15, 3, 3, 5, NULL, NULL),
(16, 3, 7, 5, NULL, NULL),
(17, 3, 14, 5, NULL, NULL),
(18, 4, 3, 5, NULL, NULL),
(19, 4, 5, 5, NULL, NULL),
(21, 5, 3, 3, NULL, NULL),
(22, 5, 4, 3, NULL, NULL),
(23, 5, 8, 3, NULL, NULL),
(24, 5, 9, 3, NULL, NULL),
(28, 6, 5, 5, NULL, NULL),
(29, 6, 13, 5, NULL, NULL),
(31, 7, 2, 1, NULL, NULL),
(32, 7, 9, 1, NULL, NULL),
(34, 8, 5, 5, NULL, NULL),
(35, 8, 13, 5, NULL, NULL),
(36, 8, 14, 5, NULL, NULL),
(37, 9, 6, 3, NULL, NULL),
(38, 10, 4, 1, NULL, NULL),
(39, 10, 14, 1, NULL, NULL),
(41, 11, 5, 3, NULL, NULL),
(42, 11, 10, 3, NULL, NULL),
(44, 12, 1, 5, NULL, NULL),
(45, 12, 2, 5, NULL, NULL),
(46, 12, 3, 5, NULL, NULL),
(47, 12, 4, 5, NULL, NULL),
(48, 12, 8, 5, NULL, NULL),
(49, 12, 9, 5, NULL, NULL),
(50, 12, 10, 5, NULL, NULL),
(51, 13, 3, 5, NULL, NULL),
(52, 13, 7, 5, NULL, NULL),
(54, 14, 3, 1, NULL, NULL),
(55, 14, 5, 1, NULL, NULL),
(56, 14, 8, 1, NULL, NULL),
(57, 15, 2, 1, NULL, NULL),
(58, 15, 9, 1, NULL, NULL),
(59, 15, 12, 1, NULL, NULL),
(60, 16, 1, 3, NULL, NULL),
(61, 16, 6, 3, NULL, NULL),
(63, 17, 7, 5, NULL, NULL),
(64, 17, 14, 5, NULL, NULL),
(66, 18, 3, 1, NULL, NULL),
(67, 18, 7, 1, NULL, NULL),
(69, 19, 5, 3, NULL, NULL),
(70, 19, 11, 3, NULL, NULL),
(72, 20, 5, 5, NULL, NULL),
(73, 20, 10, 5, NULL, NULL),
(75, 21, 3, 1, NULL, NULL),
(76, 21, 5, 1, NULL, NULL),
(77, 21, 8, 1, NULL, NULL),
(78, 22, 3, 5, NULL, NULL),
(79, 22, 14, 5, NULL, NULL),
(81, 23, 1, 5, NULL, NULL),
(82, 23, 2, 5, NULL, NULL),
(83, 23, 3, 5, NULL, NULL),
(84, 23, 4, 5, NULL, NULL),
(85, 23, 9, 5, NULL, NULL),
(88, 24, 4, 1, NULL, NULL),
(89, 25, 3, 3, NULL, NULL),
(90, 25, 4, 3, NULL, NULL),
(91, 25, 8, 3, NULL, NULL),
(92, 25, 9, 3, NULL, NULL),
(96, 26, 2, 5, NULL, NULL),
(97, 26, 9, 5, NULL, NULL),
(99, 27, 3, 5, NULL, NULL),
(100, 27, 5, 5, NULL, NULL),
(101, 27, 13, 5, NULL, NULL),
(102, 28, 3, 5, NULL, NULL),
(103, 28, 5, 5, NULL, NULL),
(104, 28, 8, 5, NULL, NULL),
(105, 28, 14, 5, NULL, NULL),
(109, 29, 1, 5, NULL, NULL),
(110, 29, 4, 5, NULL, NULL),
(111, 29, 9, 5, NULL, NULL),
(112, 30, 1, 1, NULL, NULL),
(113, 30, 9, 1, NULL, NULL),
(115, 31, 3, 3, NULL, NULL),
(116, 31, 8, 3, NULL, NULL),
(117, 31, 14, 3, NULL, NULL),
(118, 32, 3, 3, NULL, NULL),
(119, 32, 8, 3, NULL, NULL),
(121, 33, 9, 5, NULL, NULL),
(122, 34, 4, 5, NULL, NULL),
(123, 35, 12, 1, NULL, NULL),
(124, 36, 4, 3, NULL, NULL),
(125, 36, 11, 3, NULL, NULL),
(127, 37, 5, 5, NULL, NULL),
(128, 37, 10, 5, NULL, NULL),
(130, 38, 1, 5, NULL, NULL),
(131, 38, 9, 5, NULL, NULL),
(132, 38, 13, 5, NULL, NULL),
(133, 39, 1, 1, NULL, NULL),
(134, 40, 3, 5, NULL, NULL),
(135, 40, 4, 5, NULL, NULL),
(136, 40, 8, 5, NULL, NULL),
(137, 40, 9, 5, NULL, NULL),
(141, 41, 3, 5, NULL, NULL),
(142, 41, 7, 5, NULL, NULL),
(143, 41, 14, 5, NULL, NULL),
(144, 42, 9, 3, NULL, NULL),
(145, 43, 4, 3, NULL, NULL),
(146, 43, 8, 3, NULL, NULL),
(148, 44, 5, 5, NULL, NULL),
(149, 44, 13, 5, NULL, NULL),
(151, 45, 2, 3, NULL, NULL),
(152, 45, 9, 3, NULL, NULL),
(154, 46, 12, 1, NULL, NULL),
(155, 47, 5, 5, NULL, NULL),
(156, 48, 3, 5, NULL, NULL),
(157, 48, 7, 5, NULL, NULL),
(158, 48, 8, 5, NULL, NULL),
(159, 49, 1, 1, NULL, NULL),
(160, 49, 9, 1, NULL, NULL),
(162, 50, 3, 5, NULL, NULL),
(163, 50, 7, 5, NULL, NULL),
(164, 50, 14, 5, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('3SWcUCzaEPr0SvzlJPkOqTxutDoaV1WZA4PbDC2M', 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoiZU5TMHRlNU5qbVU4Y1VYRklsRlIzM3pnMm9YSHliUWhKUDE4OFVkbSI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjM2OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvZGlhZ25vc2EvaGFzaWwiO3M6NToicm91dGUiO3M6MjA6ImFkbWluLmRpYWdub3NhLmhhc2lsIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MjtzOjk6Imhhc2lsX2NiciI7YToxNTp7aTowO2E6OTp7czoxMToia29kZV9nZWphbGEiO3M6MzoiRzAxIjtzOjExOiJuYW1hX2dlamFsYSI7czozMjoiS2lwYXMgUGVuZGluZ2luIChGYW4pIEJlcm1hc2FsYWgiO3M6OToicGVtYmlsYW5nIjtkOjE1O3M6ODoicGVueWVidXQiO2Q6MTU7czoxNzoidHJhY2VfcGVtYmlsYW5nXzEiO3M6Mjc6IigxICogNSkgKyAoMSAqIDUpICsgKDEgKiA1KSI7czoxNzoidHJhY2VfcGVtYmlsYW5nXzIiO3M6OToiNSArIDUgKyA1IjtzOjE0OiJ0cmFjZV9wZW55ZWJ1dCI7czo5OiI1ICsgNSArIDUiO3M6NToic2NvcmUiO2Q6MTtzOjEwOiJwZXJzZW50YXNlIjtkOjEwMDt9aToxO2E6OTp7czoxMToia29kZV9nZWphbGEiO3M6MzoiRzAyIjtzOjExOiJuYW1hX2dlamFsYSI7czoxNjoiR1BVL0dyYWZpcyBFcnJvciI7czo5OiJwZW1iaWxhbmciO2Q6MTU7czo4OiJwZW55ZWJ1dCI7ZDoxNTtzOjE3OiJ0cmFjZV9wZW1iaWxhbmdfMSI7czoyNzoiKDEgKiA1KSArICgxICogNSkgKyAoMSAqIDUpIjtzOjE3OiJ0cmFjZV9wZW1iaWxhbmdfMiI7czo5OiI1ICsgNSArIDUiO3M6MTQ6InRyYWNlX3BlbnllYnV0IjtzOjk6IjUgKyA1ICsgNSI7czo1OiJzY29yZSI7ZDoxO3M6MTA6InBlcnNlbnRhc2UiO2Q6MTAwO31pOjI7YTo5OntzOjExOiJrb2RlX2dlamFsYSI7czozOiJHMDMiO3M6MTE6Im5hbWFfZ2VqYWxhIjtzOjIzOiJDUFUvUHJvc2Vzb3IgQmVybWFzYWxhaCI7czo5OiJwZW1iaWxhbmciO2Q6MTU7czo4OiJwZW55ZWJ1dCI7ZDoxNTtzOjE3OiJ0cmFjZV9wZW1iaWxhbmdfMSI7czoyNzoiKDEgKiA1KSArICgxICogNSkgKyAoMSAqIDUpIjtzOjE3OiJ0cmFjZV9wZW1iaWxhbmdfMiI7czo5OiI1ICsgNSArIDUiO3M6MTQ6InRyYWNlX3BlbnllYnV0IjtzOjk6IjUgKyA1ICsgNSI7czo1OiJzY29yZSI7ZDoxO3M6MTA6InBlcnNlbnRhc2UiO2Q6MTAwO31pOjM7YTo5OntzOjExOiJrb2RlX2dlamFsYSI7czozOiJHMDQiO3M6MTE6Im5hbWFfZ2VqYWxhIjtzOjI0OiJMYXlhci9EaXNwbGF5IEJlcm1hc2FsYWgiO3M6OToicGVtYmlsYW5nIjtkOjE1O3M6ODoicGVueWVidXQiO2Q6MTU7czoxNzoidHJhY2VfcGVtYmlsYW5nXzEiO3M6Mjc6IigxICogNSkgKyAoMSAqIDUpICsgKDEgKiA1KSI7czoxNzoidHJhY2VfcGVtYmlsYW5nXzIiO3M6OToiNSArIDUgKyA1IjtzOjE0OiJ0cmFjZV9wZW55ZWJ1dCI7czo5OiI1ICsgNSArIDUiO3M6NToic2NvcmUiO2Q6MTtzOjEwOiJwZXJzZW50YXNlIjtkOjEwMDt9aTo0O2E6OTp7czoxMToia29kZV9nZWphbGEiO3M6MzoiRzA5IjtzOjExOiJuYW1hX2dlamFsYSI7czo0NDoiU2lzdGVtIFBlbmRpbmdpbiAoQ29vbGluZyBTeXN0ZW0pIEJlcm1hc2FsYWgiO3M6OToicGVtYmlsYW5nIjtkOjE1O3M6ODoicGVueWVidXQiO2Q6MTU7czoxNzoidHJhY2VfcGVtYmlsYW5nXzEiO3M6Mjc6IigxICogNSkgKyAoMSAqIDUpICsgKDEgKiA1KSI7czoxNzoidHJhY2VfcGVtYmlsYW5nXzIiO3M6OToiNSArIDUgKyA1IjtzOjE0OiJ0cmFjZV9wZW55ZWJ1dCI7czo5OiI1ICsgNSArIDUiO3M6NToic2NvcmUiO2Q6MTtzOjEwOiJwZXJzZW50YXNlIjtkOjEwMDt9aTo1O2E6OTp7czoxMToia29kZV9nZWphbGEiO3M6MzoiRzA4IjtzOjExOiJuYW1hX2dlamFsYSI7czoyNToiRnJhbWUgUmF0ZS9GUFMgQmVybWFzYWxhaCI7czo5OiJwZW1iaWxhbmciO2Q6MTA7czo4OiJwZW55ZWJ1dCI7ZDoxNTtzOjE3OiJ0cmFjZV9wZW1iaWxhbmdfMSI7czoyNzoiKDEgKiA1KSArICgxICogNSkgKyAoMCAqIDUpIjtzOjE3OiJ0cmFjZV9wZW1iaWxhbmdfMiI7czo5OiI1ICsgNSArIDAiO3M6MTQ6InRyYWNlX3BlbnllYnV0IjtzOjk6IjUgKyA1ICsgNSI7czo1OiJzY29yZSI7ZDowLjY2NztzOjEwOiJwZXJzZW50YXNlIjtkOjY2Ljc7fWk6NjthOjk6e3M6MTE6ImtvZGVfZ2VqYWxhIjtzOjM6IkcxMCI7czoxMToibmFtYV9nZWphbGEiO3M6MzM6IkJhdGVyYWkvUGVuZ2lzaWFuIERheWEgQmVybWFzYWxhaCI7czo5OiJwZW1iaWxhbmciO2Q6NTtzOjg6InBlbnllYnV0IjtkOjE1O3M6MTc6InRyYWNlX3BlbWJpbGFuZ18xIjtzOjI3OiIoMCAqIDUpICsgKDEgKiA1KSArICgwICogNSkiO3M6MTc6InRyYWNlX3BlbWJpbGFuZ18yIjtzOjk6IjAgKyA1ICsgMCI7czoxNDoidHJhY2VfcGVueWVidXQiO3M6OToiNSArIDUgKyA1IjtzOjU6InNjb3JlIjtkOjAuMzMzO3M6MTA6InBlcnNlbnRhc2UiO2Q6MzMuMzt9aTo3O2E6OTp7czoxMToia29kZV9nZWphbGEiO3M6MzoiRzA1IjtzOjExOiJuYW1hX2dlamFsYSI7czoyODoiRGF5YS9Qb3dlciBTdXBwbHkgQmVybWFzYWxhaCI7czo5OiJwZW1iaWxhbmciO2Q6MDtzOjg6InBlbnllYnV0IjtkOjE1O3M6MTc6InRyYWNlX3BlbWJpbGFuZ18xIjtzOjI3OiIoMCAqIDUpICsgKDAgKiA1KSArICgwICogNSkiO3M6MTc6InRyYWNlX3BlbWJpbGFuZ18yIjtzOjk6IjAgKyAwICsgMCI7czoxNDoidHJhY2VfcGVueWVidXQiO3M6OToiNSArIDUgKyA1IjtzOjU6InNjb3JlIjtkOjA7czoxMDoicGVyc2VudGFzZSI7ZDowO31pOjg7YTo5OntzOjExOiJrb2RlX2dlamFsYSI7czozOiJHMDYiO3M6MTE6Im5hbWFfZ2VqYWxhIjtzOjQ0OiJJbnB1dCBEZXZpY2UgKEtleWJvYXJkLCBUb3VjaHBhZCkgQmVybWFzYWxhaCI7czo5OiJwZW1iaWxhbmciO2Q6MDtzOjg6InBlbnllYnV0IjtkOjE1O3M6MTc6InRyYWNlX3BlbWJpbGFuZ18xIjtzOjI3OiIoMCAqIDUpICsgKDAgKiA1KSArICgwICogNSkiO3M6MTc6InRyYWNlX3BlbWJpbGFuZ18yIjtzOjk6IjAgKyAwICsgMCI7czoxNDoidHJhY2VfcGVueWVidXQiO3M6OToiNSArIDUgKyA1IjtzOjU6InNjb3JlIjtkOjA7czoxMDoicGVyc2VudGFzZSI7ZDowO31pOjk7YTo5OntzOjExOiJrb2RlX2dlamFsYSI7czozOiJHMDciO3M6MTE6Im5hbWFfZ2VqYWxhIjtzOjMyOiJTaXN0ZW0gT3BlcmFzaS9Ecml2ZXIgQmVybWFzYWxhaCI7czo5OiJwZW1iaWxhbmciO2Q6MDtzOjg6InBlbnllYnV0IjtkOjE1O3M6MTc6InRyYWNlX3BlbWJpbGFuZ18xIjtzOjI3OiIoMCAqIDUpICsgKDAgKiA1KSArICgwICogNSkiO3M6MTc6InRyYWNlX3BlbWJpbGFuZ18yIjtzOjk6IjAgKyAwICsgMCI7czoxNDoidHJhY2VfcGVueWVidXQiO3M6OToiNSArIDUgKyA1IjtzOjU6InNjb3JlIjtkOjA7czoxMDoicGVyc2VudGFzZSI7ZDowO31pOjEwO2E6OTp7czoxMToia29kZV9nZWphbGEiO3M6MzoiRzExIjtzOjExOiJuYW1hX2dlamFsYSI7czoyODoiUG9ydC9Lb25la3Rpdml0YXMgQmVybWFzYWxhaCI7czo5OiJwZW1iaWxhbmciO2Q6MDtzOjg6InBlbnllYnV0IjtkOjE1O3M6MTc6InRyYWNlX3BlbWJpbGFuZ18xIjtzOjI3OiIoMCAqIDUpICsgKDAgKiA1KSArICgwICogNSkiO3M6MTc6InRyYWNlX3BlbWJpbGFuZ18yIjtzOjk6IjAgKyAwICsgMCI7czoxNDoidHJhY2VfcGVueWVidXQiO3M6OToiNSArIDUgKyA1IjtzOjU6InNjb3JlIjtkOjA7czoxMDoicGVyc2VudGFzZSI7ZDowO31pOjExO2E6OTp7czoxMToia29kZV9nZWphbGEiO3M6MzoiRzEyIjtzOjExOiJuYW1hX2dlamFsYSI7czoyNDoiQXVkaW8vU3BlYWtlciBCZXJtYXNhbGFoIjtzOjk6InBlbWJpbGFuZyI7ZDowO3M6ODoicGVueWVidXQiO2Q6MTU7czoxNzoidHJhY2VfcGVtYmlsYW5nXzEiO3M6Mjc6IigwICogNSkgKyAoMCAqIDUpICsgKDAgKiA1KSI7czoxNzoidHJhY2VfcGVtYmlsYW5nXzIiO3M6OToiMCArIDAgKyAwIjtzOjE0OiJ0cmFjZV9wZW55ZWJ1dCI7czo5OiI1ICsgNSArIDUiO3M6NToic2NvcmUiO2Q6MDtzOjEwOiJwZXJzZW50YXNlIjtkOjA7fWk6MTI7YTo5OntzOjExOiJrb2RlX2dlamFsYSI7czozOiJHMTMiO3M6MTE6Im5hbWFfZ2VqYWxhIjtzOjI2OiJNb3RoZXJib2FyZC9WUk0gQmVybWFzYWxhaCI7czo5OiJwZW1iaWxhbmciO2Q6MDtzOjg6InBlbnllYnV0IjtkOjE1O3M6MTc6InRyYWNlX3BlbWJpbGFuZ18xIjtzOjI3OiIoMCAqIDUpICsgKDAgKiA1KSArICgwICogNSkiO3M6MTc6InRyYWNlX3BlbWJpbGFuZ18yIjtzOjk6IjAgKyAwICsgMCI7czoxNDoidHJhY2VfcGVueWVidXQiO3M6OToiNSArIDUgKyA1IjtzOjU6InNjb3JlIjtkOjA7czoxMDoicGVyc2VudGFzZSI7ZDowO31pOjEzO2E6OTp7czoxMToia29kZV9nZWphbGEiO3M6MzoiRzE0IjtzOjExOiJuYW1hX2dlamFsYSI7czoyNDoiQklPUy9GaXJtd2FyZSBCZXJtYXNhbGFoIjtzOjk6InBlbWJpbGFuZyI7ZDowO3M6ODoicGVueWVidXQiO2Q6MTU7czoxNzoidHJhY2VfcGVtYmlsYW5nXzEiO3M6Mjc6IigwICogNSkgKyAoMCAqIDUpICsgKDAgKiA1KSI7czoxNzoidHJhY2VfcGVtYmlsYW5nXzIiO3M6OToiMCArIDAgKyAwIjtzOjE0OiJ0cmFjZV9wZW55ZWJ1dCI7czo5OiI1ICsgNSArIDUiO3M6NToic2NvcmUiO2Q6MDtzOjEwOiJwZXJzZW50YXNlIjtkOjA7fWk6MTQ7YTo5OntzOjExOiJrb2RlX2dlamFsYSI7czozOiJHMTUiO3M6MTE6Im5hbWFfZ2VqYWxhIjtzOjMyOiJLaXBhcyBQZW5kaW5naW4gKEZhbikgQmVybWFzYWxhaCI7czo5OiJwZW1iaWxhbmciO2Q6MDtzOjg6InBlbnllYnV0IjtkOjE1O3M6MTc6InRyYWNlX3BlbWJpbGFuZ18xIjtzOjI3OiIoMCAqIDUpICsgKDAgKiA1KSArICgwICogNSkiO3M6MTc6InRyYWNlX3BlbWJpbGFuZ18yIjtzOjk6IjAgKyAwICsgMCI7czoxNDoidHJhY2VfcGVueWVidXQiO3M6OToiNSArIDUgKyA1IjtzOjU6InNjb3JlIjtkOjA7czoxMDoicGVyc2VudGFzZSI7ZDowO319fQ==', 1785230378),
('iZ0VKNWLTLiFkWi2NL7uxzVVKZ2XfElLG6WK05Hy', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiTjR6MkdCWDNBcWhkdTBnSU9OZ3BrOE95NTZDTWc1WTZaWDN3Ujl4eSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozNjoiaHR0cDovLzEyNy4wLjAuMTo4MDAwL2RpYWdub3NhL2hhc2lsIjt9czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1785769266),
('lgjnoFaa7hmC7ZIwY6qPWcQAJrVTsLPvifuJOeqa', 2, '192.168.18.233', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiemQwNndHQWFKREJVak1XU0plbER4WjhVTjJvYmh3NU5Pc2QxUGhEYiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly8xOTIuMTY4LjE4Ljc6ODAwMC9kYXNoYm9hcmQiO3M6NToicm91dGUiO3M6MTU6ImFkbWluLmRhc2hib2FyZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjI7fQ==', 1785769526),
('lWe1xEzMe9AiGVjWY9eG2yJ8cDdQeHClSlSCSSpv', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36 OPR/133.0.0.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiSXNGU0lobjdxSjQwVWpkZzIwczNGcGFHOUZLa0RsbkE1cjNrZTRYQSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozNjoiaHR0cDovLzEyNy4wLjAuMTo4MDAwL2RpYWdub3NhL2hhc2lsIjt9czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9kaWFnbm9zYS9oYXNpbCI7czo1OiJyb3V0ZSI7czoyMDoiYWRtaW4uZGlhZ25vc2EuaGFzaWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1785769258);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(2, 'Admin123', 'admin123@gmail.com', NULL, '$2y$12$nkGXG0KYuxWuILO9w1BZQ.ZGnhq4hGSiOxhq5a9YKiqxDhvZUTW3.', NULL, '2026-06-07 16:01:07', '2026-06-07 09:02:13'),
(3, 'Adit', 'admin456@gmail.ccom', NULL, '$2y$12$XaTg1pH.TAoSwdNzbCzmO.0POskOSZeWy5aTL6eDbWsd9NULkH6vC', NULL, '2026-06-15 10:14:19', '2026-06-15 10:20:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`),
  ADD KEY `cache_expiration_index` (`expiration`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`),
  ADD KEY `cache_locks_expiration_index` (`expiration`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `gejalas`
--
ALTER TABLE `gejalas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kasuss`
--
ALTER TABLE `kasuss`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `relasiss`
--
ALTER TABLE `relasiss`
  ADD PRIMARY KEY (`id`),
  ADD KEY `relasiss_kasus_id_foreign` (`kasus_id`),
  ADD KEY `relasiss_gejala_id_foreign` (`gejala_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gejalas`
--
ALTER TABLE `gejalas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kasuss`
--
ALTER TABLE `kasuss`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `relasiss`
--
ALTER TABLE `relasiss`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `relasiss`
--
ALTER TABLE `relasiss`
  ADD CONSTRAINT `relasiss_gejala_id_foreign` FOREIGN KEY (`gejala_id`) REFERENCES `gejalas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `relasiss_kasus_id_foreign` FOREIGN KEY (`kasus_id`) REFERENCES `kasuss` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
