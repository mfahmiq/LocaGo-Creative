<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sistem Pakar - Cek Keterhubungan Data</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4">
        <a class="navbar-brand fw-bold" href="#">SISTEM PAKAR DIAGNOSA KERUSAKAN LAPTOP GAMING</a>
    </nav>

    <div class="container-fluid my-4 px-4">
        <div class="row">
            <div class="col-md-2 mb-4">
                <div class="list-group shadow-sm">
                    <a href="{{ route('admin.dashboard') }}" class="list-group-item list-group-item-action text-muted">Dashboard</a>
                    <a href="{{ route('admin.kasus.index') }}" class="list-group-item list-group-item-action text-muted">Manajemen Kasus</a>
                    <a href="{{ route('admin.gejala.index') }}" class="list-group-item list-group-item-action text-muted">Manajemen Gejala</a>
                    <a href="{{ route('admin.relasi.index') }}" class="list-group-item list-group-item-action text-muted">Manajemen Relasi</a>
                    <a href="{{ route('admin.diagnosa.index') }}" class="list-group-item list-group-item-action active bg-dark border-dark fw-bold">Diagnosa Kerusakan</a>
                </div>
            </div>
            
            <div class="col-md-10">
                <div class="card p-4 border-0 shadow-sm bg-white">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4 class="fw-bold mb-0 text-dark">Halaman Diagnosa</h4>
                            <p class="text-muted small">Tampilan Relasi Hubungan Antar Kasus dan Gejala</p>
                        </div>
                        <a href="{{ route('admin.diagnosa.proses.form') }}" class="btn btn-dark fw-bold btn-sm px-3">➔ INPUT KASUS PERMASALAHAN</a>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered align-middle small text-center table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th></th>
                                    @foreach($allKasus as $kasus)
                                        <th style="font-size: 0.75rem;">{{ $kasus->kode_kasus }}</th>
                                    @endforeach
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($allGejala as $gejala)
                                <tr>
                                    <td class="text-start fw-bold text-secondary">{{ $gejala->kode_gejala }}</td>
                                    @foreach($allKasus as $kasus)
                                        @if(isset($matriksRelasi[$gejala->id][$kasus->id]))
                                            <td class="table-warning fw-bold text-danger" style="font-size: 0.8rem;">
                                                {{ $matriksRelasi[$gejala->id][$kasus->id] }}
                                            </td>
                                        @else
                                            <td class="text-muted text-opacity-25" style="font-size: 0.75rem;">-</td>
                                        @endif
                                    @endforeach
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</body>
</html>