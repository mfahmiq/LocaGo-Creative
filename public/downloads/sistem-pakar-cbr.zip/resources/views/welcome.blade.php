<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Pakar CBR - Deteksi Kerusakan Laptop Gaming???</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #1e1e2f 0%, #0f0f1a 100%);
            color: white;
            padding: 100px 0;
        }
        .cbr-step-card {
            transition: transform 0.2s;
        }
        .cbr-step-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">
                <span class="text-warning">GAMING</span>LAPTOP - EXPERT
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-collapse navbar-nav ms-auto justify-content-end">
                    <li class="nav-item">
                        <a class="nav-link active fw-semibold" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#tentang-cbr">Metode CBR</a>
                    </li>
                    <li class="nav-item ms-lg-3">
                        <a href="{{ route('login') }}" class="btn btn-outline-warning btn-sm px-3 fw-bold">
                            Portal Admin
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <header class="hero-section text-center shadow-sm">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <span class="badge bg-warning text-dark fw-bold mb-3 px-3 py-2 text-uppercase">Case-Based Reasoning (CBR)</span>
                    <h1 class="display-5 fw-bold mb-3">Sistem Pakar Deteksi Kerusakan<br>Laptop Gaming</h1>
                    <p class="lead text-muted mb-5" style="color: #a0a0b0 !important;">
                        Solusi cerdas mendiagnosis masalah hardware dan software laptop gaming Anda secara cepat dan akurat berdasarkan basis pengetahuan teknisi berpengalaman.
                    </p>
                    <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
                        <a href="#" class="btn btn-warning btn-lg px-4 gap-3 fw-bold text-dark shadow">
                            Mulai Diagnosa Sekarang 🚀
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <section id="tentang-cbr" class="container my-5 py-4">
        <div class="text-center mb-5">
            <h2 class="fw-bold text-dark">Bagaimana Sistem CBR Bekerja?</h2>
            <p class="text-muted">Aplikasi menyelesaikan kasus baru dengan membandingkannya terhadap basis kasus lama melalui 4 tahapan (*4R Process*)</p>
        </div>

        <div class="row g-4">
            <div class="col-md-3">
                <div class="card h-100 border-0 shadow-sm p-3 text-center cbr-step-card">
                    <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3 mx-auto" style="width: 50px; height: 50px; font-weight: bold;">1</div>
                    <h5 class="fw-bold">Retrieve</h5>
                    <p class="text-muted small">Sistem mengambil (*retrieve*) kasus kerusakan masa lalu yang memiliki kemiripan gejala paling dekat dengan keluhan Anda.</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card h-100 border-0 shadow-sm p-3 text-center cbr-step-card">
                    <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3 mx-auto" style="width: 50px; height: 50px; font-weight: bold;">2</div>
                    <h5 class="fw-bold">Reuse</h5>
                    <p class="text-muted small">Sistem menggunakan kembali (*reuse*) informasi solusi dari kasus lama tersebut untuk dicoba diterapkan pada masalah saat ini.</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card h-100 border-0 shadow-sm p-3 text-center cbr-step-card">
                    <div class="bg-warning text-dark rounded-circle d-inline-flex align-items-center justify-content-center mb-3 mx-auto" style="width: 50px; height: 50px; font-weight: bold;">3</div>
                    <h5 class="fw-bold">Revise</h5>
                    <p class="text-muted small">Solusi dievaluasi atau diperbaiki (*revise*) oleh teknisi pakar jika terdapat ketidaksesuaian minor pada laptop spesifikasi tinggi.</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card h-100 border-0 shadow-sm p-3 text-center cbr-step-card">
                    <div class="bg-info text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3 mx-auto" style="width: 50px; height: 50px; font-weight: bold;">4</div>
                    <h5 class="fw-bold">Retain</h5>
                    <p class="text-muted small">Kasus baru yang telah berhasil diselesaikan akan disimpan kembali (*retain*) ke dalam database sebagai pengetahuan baru.</p>
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-dark text-white text-center py-4 mt-5 border-top border-warning border-3">
        <div class="container">
            <p class="mb-1 small fw-semibold">Sistem Pakar Berbasis Kasus (CBR) — Tugas Akhir Skripsi</p>
            <p class="text-muted small mb-0">&copy; 2026 Inovasi Cahaya Teknik. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="{{ asset('js/bootstrap.bundle.min.js') }}"></script>
</body>
</html>