<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Relasi Baru</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
</head>
<body class="bg-light">

    <div class="container my-5" style="max-width: 650px;">
        <div class="card border-0 shadow-sm p-4">
            <h4 class="fw-bold text-dark mb-1">Tambah Relasi Gejala & Bobot</h4>
            <p class="text-muted small mb-4">Hubungkan gejala ke dalam suatu kasus permasalahan beserta nilai kepentingannya.</p>

            @if(session('error'))
                <div class="alert alert-danger small fw-semibold mb-3">{{ session('error') }}</div>
            @endif

            <form action="{{ route('admin.relasi.store') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">PILIH KASUS PERMASALAHAN</label>
                    <select name="kasus_id" class="form-select @error('kasus_id') is-invalid @enderror">
                        <option value="">-- Pilih Kasus --</option>
                        @foreach($allKasus as $kasus)
                            <option value="{{ $kasus->id }}" {{ old('kasus_id') == $kasus->id ? 'selected' : '' }}>
                                [{{ $kasus->kode_kasus }}] - {{ $kasus->kasus }}
                            </option>
                        @endforeach
                    </select>
                    @error('kasus_id') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">PILIH GEJALA YANG TERJADI</label>
                    <select name="gejala_id" class="form-select @error('gejala_id') is-invalid @enderror">
                        <option value="">-- Pilih Gejala --</option>
                        @foreach($allGejala as $gejala)
                            <option value="{{ $gejala->id }}" {{ old('gejala_id') == $gejala->id ? 'selected' : '' }}>
                                [{{ $gejala->kode_gejala }}] - {{ $gejala->gejala }}
                            </option>
                        @endforeach
                    </select>
                    @error('gejala_id') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold small text-muted">NILAI BOBOT GEJALA (1 - 5)</label>
                    <select name="weight" class="form-select @error('weight') is-invalid @enderror">
                        <option value="">-- Tentukan Bobot --</option>
                        @for($i=1; $i<=5; $i++)
                            <option value="{{ $i }}" {{ old('weight') == $i ? 'selected' : '' }}>{{ $i }}</option>
                        @endfor
                    </select>
                    @error('weight') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-dark fw-bold w-100">SIMPAN RELASI BOBOT</button>
                    <a href="{{ route('admin.relasi.index') }}" class="btn btn-outline-secondary fw-bold">BATAL</a>
                </div>
            </form>
        </div>
    </div>

</body>
</html>