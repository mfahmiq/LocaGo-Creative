<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kasus Baru</title>
    <link class="js-css" rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
</head>
<body class="bg-light">

    <div class="container my-5" style="max-width: 600px;">
        <div class="card border-0 shadow-sm p-4">
            <h4 class="fw-bold text-dark mb-1">Tambah Kasus Kerusakan</h4>
            <p class="text-muted small mb-4">Input data master kasus baru ke dalam sistem pakar.</p>

            <form action="{{ route('admin.kasus.store') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">KODE KASUS (Contoh: K01)</label>
                    <input type="text" name="kode_kasus" value="{{ old('kode_kasus') }}" class="form-control @error('kode_kasus') is-invalid @enderror" placeholder="Kxx" autofocus>
                    @error('kode_kasus') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold small text-muted">NAMA KERUSAKAN KASUS</label>
                    <textarea name="kasus" rows="3" class="form-control @error('kasus') is-invalid @enderror" placeholder="Masukkan detail kerusakan..."></textarea>
                    @error('kasus') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-dark fw-bold w-100">SIMPAN DATA KASUS</button>
                    <a href="{{ route('admin.kasus.index') }}" class="btn btn-outline-secondary fw-bold">BATAL</a>
                </div>
            </form>
        </div>
    </div>

</body>
</html>