<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Relasi - CBR Laptop Gaming</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="{{ route('admin.dashboard') }}">SISTEM PAKAR DIAGNOSA KERUSAKAN LAPTOP GAMING</a>
        </div>
    </nav>

    <div class="container-fluid my-5 px-4">
        <div class="row">
            <div class="col-md-2 mb-4">
                <div class="list-group shadow-sm">
                    <a href="{{ route('admin.dashboard') }}" class="list-group-item list-group-item-action text-muted">Dashboard</a>
                    <a href="{{ route('admin.kasus.index') }}" class="list-group-item list-group-item-action text-muted">Manajemen Kasus</a>
                    <a href="{{ route('admin.gejala.index') }}" class="list-group-item list-group-item-action text-muted">Manajemen Gejala</a>
                    <a href="{{ route('admin.relasi.index') }}" class="list-group-item list-group-item-action active bg-dark border-dark fw-bold">Manajemen Relasi</a>
                    <a href="{{ route('admin.diagnosa.index') }}" class="list-group-item list-group-item-action text-muted">Diagnosa Kerusakan</a>
                </div>
            </div>

            <div class="col-md-10">
                @if(session('success'))
                    <div class="alert alert-success shadow-sm mb-4 fw-semibold">{{ session('success') }}</div>
                @endif
                @if(session('error'))
                    <div class="alert alert-danger shadow-sm mb-4 fw-semibold">{{ session('error') }}</div>
                @endif

                <div class="card border-0 shadow-sm p-4">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h4 class="fw-bold text-dark mb-1">Daftar Relasi Bobot (Kasus & Gejala)</h4>
                        </div>
                        <a href="{{ route('admin.relasi.create') }}" class="btn btn-dark btn-sm fw-bold shadow-sm px-3">
                            + Tambah Relasi Baru
                        </a>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered table-hover align-middle bg-white m-0">
                            <thead class="table-dark text-center">
                                <tr>
                                    <th width="5%">No</th>
                                    <th width="30%">Basis Kasus</th>
                                    <th width="35%">Indikasi Gejala</th>
                                    <th width="10%">Nilai Bobot</th>
                                    <th width="20%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($dataRelasi as $index => $relasi)
                                <tr>
                                    <td class="text-center text-muted">{{ $index + 1 }}</td>
                                    <td><strong class="text-dark">[{{ $relasi->kode_kasus }}]</strong> {{ $relasi->kasus }}</td>
                                    <td><strong class="text-secondary">[{{ $relasi->kode_gejala }}]</strong> {{ $relasi->gejala }}</td>
                                    <td class="text-center fw-bold text-primary fs-5">{{ $relasi->weight }}</td>
                                    <td class="text-center">
                                        <a href="{{ route('admin.relasi.edit', $relasi->id) }}" class="btn btn-warning btn-sm fw-bold px-3 me-1">
                                            Edit
                                        </a>
                                        <form action="{{ route('admin.relasi.destroy', $relasi->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Hapus hubungan relasi bobot ini?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger btn-sm fw-bold px-3">
                                                Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">Belum ada pemetaan relasi antar data.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>