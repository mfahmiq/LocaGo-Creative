<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Gejala</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
</head>
<body class="bg-light">

    <div class="container my-5" style="max-width: 600px;">
        <div class="card border-0 shadow-sm p-4">
            <h4 class="fw-bold text-dark mb-1">Ubah Data Gejala</h4>
            <p class="text-muted small mb-4">Perbarui informasi kode atau indikasi nama gejala [{{ $gejala->kode_gejala }}].</p>

            <form action="{{ route('admin.gejala.update', $gejala->id) }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label class="form-label fw-bold small text-muted">KODE GEJALA</label>
                    <input type="text" name="kode_gejala" value="{{ old('kode_gejala', $gejala->kode_gejala) }}" class="form-control @error('kode_gejala') is-invalid @enderror">
                    @error('kode_gejala') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <div class="mb-4">
                    <label class="form-label fw-bold small text-muted">NAMA INDIKATOR GEJALA</label>
                    <textarea name="gejala" rows="3" class="form-control @error('gejala') is-invalid @enderror">{{ old('gejala', $gejala->gejala) }}</textarea>
                    @error('gejala') <div class="invalid-feedback">{{ $message }}</div> @enderror
                </div>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-dark fw-bold w-100">SIMPAN PERUBAHAN</button>
                    <a href="{{ route('admin.gejala.index') }}" class="btn btn-outline-secondary fw-bold">BATAL</a>
                </div>
            </form>
        </div>
    </div>

</body>
</html>