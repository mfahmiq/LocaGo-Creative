<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sistem Pakar - Input Kasus Uji</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4">
        <a class="navbar-brand fw-bold" href="#">SISTEM PAKAR DIAGNOSA KERUSAKAN LAPTOP GAMING</a>
    </nav>

    <div class="container-fluid my-4 px-4">
        <div class="row">
            <div class="col-md-2 mb-4">
                <div class="list-group shadow-sm">
                    <a href="{{ route('admin.dashboard') }}" class="list-group-item list-group-item-action text-muted">Dashboard</a>
                    <a href="{{ route('admin.kasus.index') }}" class="list-group-item list-group-item-action text-muted">Manajemen Kasus</a>
                    <a href="{{ route('admin.gejala.index') }}" class="list-group-item list-group-item-action text-muted">Manajemen Gejala</a>
                    <a href="{{ route('admin.relasi.index') }}" class="list-group-item list-group-item-action text-muted">Manajemen Relasi</a>
                    <a href="{{ route('admin.diagnosa.index') }}" class="list-group-item list-group-item-action active bg-dark border-dark fw-bold">Diagnosa Kerusakan</a>
                </div>
            </div>

            <div class="col-md-10">
                <div class="card p-4 border-0 shadow-sm bg-white">
                    <div class="mb-3">
                        <h4 class="fw-bold text-dark mb-1">Halaman Proses</h4>
                    </div>

                    @if(session('error'))
                        <div class="alert alert-danger small">{{ session('error') }}</div>
                    @endif

                    <form action="{{ route('admin.diagnosa.proses') }}" method="POST">
                        @csrf
                        <div class="table-responsive mb-4">
                            <table class="table table-bordered table-hover align-middle small">
                                <thead class="table-light">
                                    <tr class="text-secondary text-uppercase" style="font-size: 0.75rem; font-family: monospace;">
                                        <th width="8%" class="text-center">Pilih</th>
                                        <th width="15%" class="text-center">Kode Kasus</th>
                                        <th>Nama Kasus Permasalahan Laptop Gaming</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($dataKasus as $kasus)
                                    <tr>
                                        <td class="text-center">
                                            <input type="checkbox" name="kasus_ids[]" value="{{ $kasus->id }}" 
                                                class="form-check-input border-secondary" style="width: 1.2rem; height: 1.2rem;">
                                        </td>
                                        <td class="text-center fw-bold text-dark" style="font-family: monospace;">{{ $kasus->kode_kasus }}</td>
                                        <td class="text-dark fw-semibold">{{ $kasus->kasus }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <button type="submit" class="btn btn-dark fw-bold px-4" style="font-size: 0.85rem; font-family: monospace;">PROSES PERHITUNGAN SIMILARITY ➔</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>