<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - CBR Laptop Gaming</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
</head>
<body class="bg-secondary d-flex align-items-center" style="height: 100vh;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card border-0 shadow-lg p-4">
                    <h3 class="fw-bold text-center text-dark mb-4">LOGIN ADMIN</h3>
                    
                    @if($errors->has('loginError'))
                        <div class="alert alert-danger text-center small p-2">
                            {{ $errors->first('loginError') }}
                        </div>
                    @endif
                    
                    <form action="{{ route('login.proses') }}" method="POST">
                        @csrf
                        
                        @if(session('success'))
                            <div class="alert alert-success">{{ session('success') }}</div>
                        @endif

                        <div class="mb-3">
                            <label>Email Address</label>
                            <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email') }}" required>
                            @error('email') <div class="invalid-feedback">{{ $message }}</div> @enderror
                        </div>

                        <div class="mb-3">
                            <div class="d-flex justify-content-between">
                                <label>Password</label>
                                <a href="{{ route('password.request') }}" class="text-decoration-none small text-muted">Lupa Password?</a>
                            </div>
                            <input type="password" name="password" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 mb-3">Login</button>

                        <div class="text-center">
                            <span class="text-muted small">Belum punya akun? </span>
                            <a href="{{ route('register') }}" class="text-decoration-none small fw-bold">Daftar Sekarang</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>