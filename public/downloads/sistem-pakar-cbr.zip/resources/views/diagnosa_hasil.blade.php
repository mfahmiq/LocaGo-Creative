<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Pakar - Hasil Diagnosa & Log Analisis</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <style>
        .font-monospace { font-family: SFMono-Regular, Menlo, Monaco, Consolas, monospace; }
        
        /* KELOMPOK KOTAK HASIL GEJALA */
        .result-symptom-box {
            border: 1.5px solid #dee2e6;
            border-radius: 12px;
            padding: 16px;
            background-color: #fff;
            box-shadow: 0 2px 6px rgba(0,0,0,0.03);
            height: 100%;
        }

        /* BADGE PERCENT BULAT */
        .percent-badge-box {
            border: 1.5px solid #212529;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            height: 42px;
            width: auto;
            min-width: 80px;
            padding: 0 10px;
            font-size: 1rem;
            color: #212529;
            background-color: #fff;
        }

        /* BASE STYLE BADGE RANK (WARNA DIATUR DINAMIS VIA BLADE) */
        .rank-badge-box {
            border: 1.5px solid #212529;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 900;
            height: 42px;
            width: 42px;
            font-size: 1rem;
            transition: all 0.2s ease;
        }

        .symptom-title-text { font-size: 1.05rem; font-weight: 700; text-align: left; }
        .formula-card-area { background-color: #f8f9fa; border-radius: 8px; padding: 2px; margin-top: 10px; }

        /* KOTAK HITAM TRACE RUMUS */
        .dark-trace-box {
            background-color: #1e2227;
            border-radius: 8px;
            padding: 12px 16px;
            color: #ffffff;
            font-family: 'Courier New', Courier, monospace;
            text-align: left;
            overflow-x: auto;
        }

        /* FORMAT PECAHAN MATEMATIKA */
        .math-row {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
            flex-wrap: nowrap;
        }
        .math-label {
            font-size: 0.95rem;
            margin-right: 6px;
            white-space: nowrap;
        }
        .math-fraction {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            padding: 0 4px;
        }
        .math-numerator {
            border-bottom: 2px solid #ffffff;
            padding-bottom: 2px;
            width: 100%;
            font-size: 0.9rem;
        }
        .math-denominator {
            padding-top: 2px;
            width: 100%;
            font-size: 0.9rem;
        }
        .math-equal {
            font-size: 1.1rem;
            margin: 0 6px;
        }
    </style>
</head>
<body class="bg-light">

    <nav class="navbar navbar-dark bg-dark mb-4">
        <div class="container-fluid px-4">
            <a class="navbar-brand fw-bold" href="#">SISTEM PAKAR DIAGNOSA KERUSAKAN LAPTOP GAMING</a>
        </div>
    </nav>

    <div class="container mt-2">
        <div class="row justify-content-center">
            <div class="col-xl-11 col-12">
                
                <div class="card border-0 shadow-sm p-4 bg-white rounded-3">
                    
                    <div class="mb-4 border-bottom pb-3">
                        <h1 class="fw-bold text-dark mb-2" style="font-size: 1.85rem;">Hasil Diagnosa</h1>
                        
                        @php
                            $highestScore = $matriksKalkulasiGejala[0]['score'] ?? 0;
                            
                            $pemenangGroup = [];
                            $pemenangDetails = [];
                            foreach($matriksKalkulasiGejala as $item) {
                                if($item['score'] == $highestScore) {
                                    $pemenangGroup[] = $item['kode_gejala'];
                                    $pemenangDetails[] = $item['kode_gejala'] . ': ' . $item['nama_gejala'];
                                }
                            }
                            $teksPemenang = implode(' dan ', $pemenangGroup);
                            $teksPemenangDetail = implode(' dan ', $pemenangDetails);
                            $teksPersentaseMaksimal = number_format($highestScore * 100, 2, ',', '.') . '%';
                        @endphp

                        <p class="text-secondary mb-0" style="font-size: 1rem; line-height: 1.6;">
                            Gejala yang paling mirip dengan input Anda adalah <strong>{{ $teksPemenangDetail }}</strong> dengan nilai kemiripan tertinggi sebesar <strong class="text-dark">{{ $teksPersentaseMaksimal }}</strong>.
                        </p>
                        <div class="mt-2 pt-1 border-top">
                            <h6 class="text-muted fw-bold" style="font-size: 0.7rem; margin-bottom: 2px;">Rincian Semua Gejala:</h6>
                            @foreach($matriksKalkulasiGejala as $item)
                                <div class="d-flex justify-content-between align-items-center" style="font-size: 0.65rem; border-bottom: 1px dashed #e9ecef; padding: 1px 0; line-height: 1.3;">
                                    <span>
                                        <strong>{{ $item['kode_gejala'] }}</strong> {{ $item['nama_gejala'] }}
                                    </span>
                                    <span class="fw-bold">{{ number_format($item['score'] * 100, 1, ',', '.') }}%</span>
                                </div>
                            @endforeach
                        </div>

                        <div class="mt-4">
                            <a href="{{ route('admin.diagnosa.proses.form') }}" class="btn btn-sm btn-outline-dark fw-bold px-3 py-2 rounded-3 text-uppercase font-monospace" style="font-size: 0.85rem;">
                                Kembali ke Halaman Proses
                            </a>
                        </div>
                    </div>

                    <div class="row g-3">
                        @foreach($matriksKalkulasiGejala as $calc)
                            
                            @php
                                // LOGIKA PENENTUAN WARNA MEDALI PODIUM SECARA DINAMIS
                                $rankNum = $loop->iteration;
                                if ($rankNum == 1) {
                                    // #1 GOLD (Emas Mengkilap, Teks Gelap)
                                    $badgeStyle = "background-color: #ffd700; color: #212529; border-color: #212529;";
                                } elseif ($rankNum == 2) {
                                    // #2 SILVER (Perak, Teks Gelap)
                                    $badgeStyle = "background-color: #e2e6ea; color: #212529; border-color: #212529;";
                                } elseif ($rankNum == 3) {
                                    // #3 BRONZE (Tembaga/Perunggu, Teks Putih Kontras)
                                    $badgeStyle = "background-color: #cd7f32; color: #212529; border-color: #212529;";
                                } else {
                                    // Peringkat 4 ke bawah (Netral standar bawaan)
                                    $badgeStyle = "background-color: #ffffff; color: #212529; border-color: #212529;";
                                }
                            @endphp

                            <div class="col-lg-6 col-12 d-flex align-items-stretch">
                                <div class="result-symptom-box w-100">
                                    
                                    <div class="row align-items-center g-2 mb-2">
                                        <div class="col-auto">
                                            <div class="rank-badge-box" style="{{ $badgeStyle }}">#{{ $rankNum }}</div>
                                        </div>
                                        <div class="col text-start ps-2">
                                            <div class="symptom-title-text text-dark">
                                                <span class="text-danger">[{{ $calc['kode_gejala'] ?? '' }}]</span> 
                                                {{ $calc['nama_gejala'] ?? 'Nama Gejala Belum Ditentukan' }}
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <div class="percent-badge-box">
                                                {{ number_format(($calc['score'] ?? 0) * 100, 1, ',', '.') }}%
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="formula-card-area">
                                        <div class="dark-trace-box">
                                            
                                            <div class="math-row">
                                                <div class="math-label">S<sub>{{ $calc['kode_gejala'] ?? '' }}</sub> =</div>
                                                <div class="math-fraction">
                                                    <div class="math-numerator">{{ $calc['trace_pembilang_1'] ?? '0' }}</div>
                                                    <div class="math-denominator">{{ $calc['trace_penyebut'] ?? '18' }}</div>
                                                </div>
                                            </div>

                                            <div class="math-row mb-0">
                                                <div class="math-label">S<sub>{{ $calc['kode_gejala'] ?? '' }}</sub> =</div>
                                                <div class="math-fraction">
                                                    <div class="math-numerator">{{ $calc['trace_pembilang_2'] ?? '0' }}</div>
                                                    <div class="math-denominator">{{ $calc['penyebut'] ?? '18' }}</div>
                                                </div>
                                                <div class="math-equal">=</div>
                                                <div class="math-fraction">
                                                    <div class="math-numerator" style="border-bottom: none; padding-bottom: 0;">{{ $calc['pembilang'] ?? '0' }}</div>
                                                    <div class="math-denominator" style="border-top: 2px solid #fff; padding-top: 2px;">{{ $calc['penyebut'] ?? '18' }}</div>
                                                </div>
                                                <div class="math-equal">=</div>
                                                <div class="fw-bold text-warning font-monospace" style="font-size: 1.15rem;">
                                                    {{ number_format($calc['score'] ?? 0, 3, ',', '') }}
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        @endforeach
                    </div> 

                </div>
                
            </div>
        </div>
    </div>

</body>
</html>