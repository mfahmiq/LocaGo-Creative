<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - CBR</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">SISTEM PAKAR DIAGNOSA KERUSAKAN LAPTOP GAMING</a>
            <div class="ms-auto">
                <form action="{{ route('logout') }}" method="POST" onsubmit="return confirm('Yakin ingin keluar?')">
                    @csrf
                    <button type="submit" class="btn btn-danger btn-sm fw-bold">LOGOUT</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <div class="row">
            <div class="col-md-3 mb-4">
                <div class="list-group shadow-sm">
                    <a href="#" class="list-group-item list-group-item-action active bg-dark border-dark fw-bold">
                        Dashboard
                    </a>
                    <a href="{{ route('admin.kasus.index') }}" class="list-group-item list-group-item-action text-muted">Manajemen Kasus</a>
                    <a href="{{ route('admin.gejala.index') }}" class="list-group-item list-group-item-action text-muted">Manajemen Gejala</a>
                    <a href="{{ route('admin.relasi.index') }}" class="list-group-item list-group-item-action text-muted">Manajemen Relasi</a>
                    <a href="{{ route('admin.diagnosa.index') }}" class="list-group-item list-group-item-action text-muted">Diagnosa Kerusakan</a>
                </div>
            </div>

            <div class="col-md-9">
                <div class="card card-body border-0 shadow-sm p-4 mb-4">
                    <h4 class="fw-bold text-dark">Selamat Datang, Admin Pakar!</h4>
                    <p class="text-muted mb-0">Sistem Telah Terhubung ke Database.</p>
                </div>

                <div class="row">
                    <div class="col-md-4 mb-3">
                        <div class="card bg-primary text-white border-0 shadow-sm text-center p-3">
                            <h6 class="text-uppercase small fw-bold opacity-75">Total Kasus</h6>
                            <h2 class="fw-bold my-2">{{ $totalKasus }}</h2>
                            <small>Data Basis Kasus</small>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card bg-success text-white border-0 shadow-sm text-center p-3">
                            <h6 class="text-uppercase small fw-bold opacity-75">Total Gejala</h6>
                            <h2 class="fw-bold my-2">{{ $totalGejala }}</h2>
                            <small>Data Basis Gejala</small>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card bg-warning text-dark border-0 shadow-sm text-center p-3">
                            <h6 class="text-uppercase small fw-bold opacity-75">Total Relasi</h6>
                            <h2 class="fw-bold my-2">{{ $totalRelasi }}</h2>
                            <small>Matriks Bobot CBR</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="{{ asset('js/bootstrap.bundle.min.js') }}"></script>
</body>
</html>