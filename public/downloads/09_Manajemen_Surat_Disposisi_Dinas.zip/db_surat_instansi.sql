CREATE DATABASE IF NOT EXISTS `db_surat_instansi`;
USE `db_surat_instansi`;

CREATE TABLE IF NOT EXISTS `surat_masuk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_agenda` varchar(50) NOT NULL,
  `no_surat` varchar(100) NOT NULL,
  `asal_surat` varchar(150) NOT NULL,
  `perihal` text NOT NULL,
  `tgl_terima` date NOT NULL,
  `disposisi` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `surat_masuk` (`no_agenda`, `no_surat`, `asal_surat`, `perihal`, `tgl_terima`, `disposisi`) VALUES
('AG-0421', '005/DISDIK/X/2026', 'Dinas Pendidikan', 'Undangan Rapat Koordinasi', '2026-11-01', 'Kepala Sekolah'),
('AG-0422', '120/KEC-SMD/XI/2026', 'Kecamatan', 'Himbauan Hari Pahlawan', '2026-11-02', 'Wakasek Kesiswaan');
