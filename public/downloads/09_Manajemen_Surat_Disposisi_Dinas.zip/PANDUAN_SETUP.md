# Panduan Aplikasi Manajemen Surat & Disposisi
1. Ekstrak ke htdocs/www.
2. Import `db_surat_instansi.sql` via phpMyAdmin.
3. Buka `http://localhost/09_Manajemen_Surat_Disposisi_Dinas`.
