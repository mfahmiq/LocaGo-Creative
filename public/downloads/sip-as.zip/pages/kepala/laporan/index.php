<?php
session_start();
require_once '../../../config/koneksi.php';

if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin2') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

require_once '../../../includes/header.php';
$pdo = getConnection();

try {
    // Ambil daftar jenis pembayaran untuk dropdown filter
    $stmtJenis = $pdo->query("SELECT id_jenis, nama_pembayaran FROM jenis_pembayaran ORDER BY nama_pembayaran ASC");
    $list_jenis = $stmtJenis->fetchAll();

    // Ambil Riwayat Pembuatan Laporan
    $stmtHistory = $pdo->query("SELECT * FROM laporan ORDER BY tanggal_dibuat DESC LIMIT 50");
    $data_history = $stmtHistory->fetchAll();
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!-- Style Bawaan dari Halaman Tambah Transaksi -->
<style>
    .form-control-modern,
    .form-select-modern {
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
        padding: 0.75rem 1rem;
        border-radius: 0.5rem;
        color: #212529;
        transition: all 0.2s;
    }

    .form-control-modern:focus,
    .form-select-modern:focus {
        background-color: #ffffff;
        border-color: #4e73df;
        box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.15);
    }

    .custom-item:hover {
        background-color: #f8f9fc;
        border-left: 4px solid #4e73df;
    }

    .custom-item {
        border-left: 4px solid transparent;
        transition: all 0.2s ease;
    }
</style>

<div class="row mb-4 align-items-center">
    <div class="col-md-8">
        <h4 class="mb-0 fw-bold text-dark">Laporan Keuangan</h4>
        <p class="text-muted mb-0" style="font-size: 0.9rem;">Cetak rekapitulasi pembayaran dan pantau riwayat pelaporan</p>
    </div>
</div>

<div class="row">
    <!-- FORM CETAK LAPORAN -->
    <div class="col-lg-5 mb-4">
        <div class="card border-0 shadow-sm" style="border-radius: 1rem;">
            <div class="bg-primary bg-opacity-10 py-3 px-4 border-bottom border-primary border-opacity-10" style="border-radius: 1rem 1rem 0 0;">
                <h6 class="fw-bold text-white mb-0"><i class="bi bi-printer me-2"></i>Filter & Cetak Laporan</h6>
            </div>
            <div class="card-body p-4">

                <form method="GET" target="_blank" id="formLaporan">

                    <!-- KOTAK PENCARIAN JENIS PEMBAYARAN (CUSTOM) -->
                    <div class="mb-4">
                        <label class="form-label fw-semibold text-dark">Filter Jenis Pembayaran</label>
                        <!-- Hidden input untuk menyimpan ID yang dipilih -->
                        <input type="hidden" name="id_jenis" id="id_jenis_input" value="">

                        <div class="dropdown">
                            <button class="form-select form-select-modern text-start d-flex justify-content-between align-items-center w-100 shadow-none bg-light" type="button" id="dropdownJenis" data-bs-toggle="dropdown" aria-expanded="false">
                                <span id="selected_jenis_text" class="text-muted">-- Semua Jenis Pembayaran --</span>
                            </button>

                            <div class="dropdown-menu w-100 p-2 shadow border-0" aria-labelledby="dropdownJenis" style="border-radius: 0.8rem; margin-top: 5px;">
                                <div class="p-1 mb-2">
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0 text-muted"><i class="bi bi-search"></i></span>
                                        <input type="text" class="form-control border-start-0 shadow-none" id="searchJenis" placeholder="Cari Jenis Pembayaran..." autocomplete="off">
                                    </div>
                                </div>
                                <ul class="list-unstyled mb-0" style="max-height: 250px; overflow-y: auto;">

                                    <!-- Opsi Default: Semua Jenis -->
                                    <li>
                                        <a class="dropdown-item rounded-2 py-2 mb-1 custom-item jenis-item" href="javascript:void(0)" data-id="" data-nama="-- Semua Jenis Pembayaran --">
                                            <div class="fw-bold text-dark">-- Semua Jenis Pembayaran --</div>
                                        </a>
                                    </li>

                                    <!-- Looping Data dari Database -->
                                    <?php foreach ($list_jenis as $jenis): ?>
                                        <li>
                                            <a class="dropdown-item rounded-2 py-2 mb-1 custom-item jenis-item" href="javascript:void(0)" data-id="<?= $jenis['id_jenis'] ?>" data-nama="<?= htmlspecialchars($jenis['nama_pembayaran']) ?>">
                                                <div class="fw-bold text-dark"><?= htmlspecialchars($jenis['nama_pembayaran']) ?></div>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>

                                    <li id="noResultJenis" class="text-center text-muted py-3 d-none">
                                        <i class="bi bi-tags fs-4 d-block mb-1"></i> Jenis tidak ditemukan
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-dark">Status Pembayaran</label>
                        <select class="form-select form-select-modern bg-light" name="jenis_laporan" required>
                            <option value="Semua Transaksi">Semua Transaksi (Lunas & Tunggakan)</option>
                            <option value="Pemasukan Lunas">Hanya Pemasukan (Status Lunas)</option>
                            <option value="Tunggakan">Hanya Tunggakan (Status Belum Lunas)</option>
                        </select>
                    </div>

                    <div class="row mb-4">
                        <div class="col-6">
                            <label class="form-label fw-semibold text-dark">Dari Tanggal</label>
                            <input type="date" class="form-control form-control-modern bg-light" name="tgl_awal" value="<?= date('Y-m-01') ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-semibold text-dark">Sampai Tanggal</label>
                            <input type="date" class="form-control form-control-modern bg-light" name="tgl_akhir" value="<?= date('Y-m-t') ?>" required>
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" formaction="cetak-pdf.php" class="btn btn-danger w-100 fw-medium shadow-sm rounded-3">
                            <i class="bi bi-file-earmark-pdf me-1"></i> Cetak PDF
                        </button>
                        <button type="submit" formaction="cetak-excel.php" class="btn btn-success w-100 fw-medium shadow-sm rounded-3">
                            <i class="bi bi-file-earmark-excel me-1"></i> Export Excel
                        </button>
                    </div>

                </form>

            </div>
        </div>
    </div>

    <!-- TABEL RIWAYAT LAPORAN -->
    <div class="col-lg-7">
        <div class="card border-0 shadow-sm" style="border-radius: 1rem;">
            <div class="card-body p-4">
                <h6 class="fw-bold text-dark mb-3">Riwayat Pembuatan Laporan Oleh Bendahara</h6>
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-hover align-middle mb-0" style="font-size: 0.9rem;">
                        <thead class="table-light" style="position: sticky; top: 0; z-index: 1;">
                            <tr>
                                <th width="5%" class="text-center">No</th>
                                <th width="40%">Laporan Dicetak</th>
                                <th width="30%">Periode Data</th>
                                <th width="25%">Waktu</th>
                            </tr>
                        </thead>
                        <tbody class="border-top-0">
                            <?php if (count($data_history) > 0): ?>
                                <?php $no = 1;
                                foreach ($data_history as $row): ?>
                                    <tr>
                                        <td class="text-center text-muted"><?= $no++ ?></td>
                                        <td><span class="fw-bold text-primary" style="font-size: 0.85rem;"><?= htmlspecialchars($row['jenis_laporan']) ?></span></td>
                                        <td><span class="badge bg-secondary bg-opacity-10 text-white"><?= htmlspecialchars($row['periode']) ?></span></td>
                                        <td class="text-muted"><i class="bi bi-clock me-1"></i> <?= date('d M, H:i', strtotime($row['tanggal_dibuat'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center py-4 text-muted">Belum ada riwayat.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../../includes/footer.php'; ?>

<!-- Javascript Custom Dropdown -->
<script>
    document.addEventListener("DOMContentLoaded", function() {

        const searchJenis = document.getElementById('searchJenis');
        const itemJenis = document.querySelectorAll('.jenis-item');
        const noResultJenis = document.getElementById('noResultJenis');
        const inputJenisId = document.getElementById('id_jenis_input');
        const textJenis = document.getElementById('selected_jenis_text');

        // Mencegah dropdown tertutup saat mengklik kotak pencarian
        searchJenis.addEventListener('click', e => e.stopPropagation());

        // Fitur Pencarian / Filter
        searchJenis.addEventListener('keyup', function() {
            let filter = this.value.toLowerCase();
            let visibleCount = 0;
            itemJenis.forEach(item => {
                let textData = item.getAttribute('data-nama').toLowerCase();
                if (textData.includes(filter)) {
                    item.parentElement.style.display = '';
                    visibleCount++;
                } else {
                    item.parentElement.style.display = 'none';
                }
            });
            visibleCount === 0 ? noResultJenis.classList.remove('d-none') : noResultJenis.classList.add('d-none');
        });

        // Fitur Pemilihan Item
        itemJenis.forEach(item => {
            item.addEventListener('click', function() {
                // Set nilai ID ke input type="hidden"
                let id_pilih = this.getAttribute('data-id');
                let nama_pilih = this.getAttribute('data-nama');

                inputJenisId.value = id_pilih;

                // Ubah tampilan teks di tombol
                if (id_pilih === "") {
                    textJenis.innerHTML = `<span class="text-muted">${nama_pilih}</span>`;
                } else {
                    textJenis.innerHTML = `<span class="text-dark fw-bold">${nama_pilih}</span>`;
                }
            });
        });

        // Otomatis fokus ke kolom pencarian saat dropdown diklik
        document.getElementById('dropdownJenis').addEventListener('shown.bs.dropdown', () => searchJenis.focus());
    });
</script>