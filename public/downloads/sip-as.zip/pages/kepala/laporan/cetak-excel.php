<?php
session_start();
require_once '../../../config/koneksi.php';
require_once '../../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;

// 1. PROTEKSI HALAMAN
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin2') {
    die("Akses ditolak!");
}

// 2. VALIDASI PARAMETER
$id_jenis      = isset($_GET['id_jenis']) ? $_GET['id_jenis'] : '';
$jenis_laporan = isset($_GET['jenis_laporan']) ? $_GET['jenis_laporan'] : '';
$tgl_awal      = isset($_GET['tgl_awal']) ? $_GET['tgl_awal'] : '';
$tgl_akhir     = isset($_GET['tgl_akhir']) ? $_GET['tgl_akhir'] : '';

if (empty($jenis_laporan) || empty($tgl_awal) || empty($tgl_akhir)) {
    die("Parameter laporan tidak lengkap!");
}

$pdo = getConnection();

try {
    // 3. SUSUN LOGIKA FILTER & NAMA LAPORAN
    $where_clause = "";
    $params = [':awal' => $tgl_awal, ':akhir' => $tgl_akhir];
    $nama_pembayaran_teks = "Semua Jenis Pembayaran";

    if (!empty($id_jenis)) {
        $where_clause .= " AND t.id_jenis = :id_jenis ";
        $params[':id_jenis'] = $id_jenis;

        $stmtNama = $pdo->prepare("SELECT nama_pembayaran FROM jenis_pembayaran WHERE id_jenis = :id");
        $stmtNama->execute([':id' => $id_jenis]);
        $nama_pembayaran_teks = $stmtNama->fetchColumn();
    }

    if ($jenis_laporan === 'Pemasukan Lunas') {
        $where_clause .= " AND t.status = 'Lunas' ";
    } elseif ($jenis_laporan === 'Tunggakan') {
        $where_clause .= " AND t.status = 'Belum Lunas' ";
    }

    $sql = "SELECT t.*, s.nama, s.nisn, j.nama_pembayaran 
            FROM transaksi_pembayaran t
            JOIN data_siswa s ON t.nisn = s.nisn
            JOIN jenis_pembayaran j ON t.id_jenis = j.id_jenis
            WHERE t.tanggal_bayar BETWEEN :awal AND :akhir 
            $where_clause
            ORDER BY t.tanggal_bayar ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $data_transaksi = $stmt->fetchAll();

    // 4. CATAT AKTIVITAS KE TABEL LAPORAN
    $nama_log_final = $nama_pembayaran_teks . " - " . $jenis_laporan;
    $periode_teks = date('d M Y', strtotime($tgl_awal)) . " s/d " . date('d M Y', strtotime($tgl_akhir));

    // $stmtLog = $pdo->prepare("INSERT INTO laporan (jenis_laporan, periode) VALUES (:jenis, :periode)");
    // $stmtLog->execute([
    //     ':jenis'   => $nama_log_final,
    //     ':periode' => $periode_teks
    // ]);
} catch (PDOException $e) {
    die("Error memproses laporan: " . $e->getMessage());
}

// =========================================================================
// PROSES PEMBUATAN EXCEL NATIVE (.xlsx) ESTETIK
// =========================================================================

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// --- A. SETTING JUDUL LAPORAN ---
$sheet->setCellValue('A1', 'LAPORAN TRANSAKSI PEMBAYARAN');
$sheet->mergeCells('A1:F1');
$sheet->getStyle('A1')->getFont()->setBold(true)->setSize(16)->setColor(new \PhpOffice\PhpSpreadsheet\Style\Color(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_DARKBLUE));
$sheet->getStyle('A1')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

$sheet->setCellValue('A2', 'Kategori: ' . $nama_log_final);
$sheet->mergeCells('A2:F2');
$sheet->setCellValue('A3', 'Periode: ' . $periode_teks);
$sheet->mergeCells('A3:F3');
$sheet->getStyle('A2:A3')->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle('A2:A3')->getFont()->setItalic(true);

// --- B. HEADER TABEL ---
$sheet->setCellValue('A5', 'No');
$sheet->setCellValue('B5', 'Tanggal Bayar');
$sheet->setCellValue('C5', 'NISN');
$sheet->setCellValue('D5', 'Nama Siswa');
$sheet->setCellValue('E5', 'Jenis Pembayaran');
$sheet->setCellValue('F5', 'Jumlah Bayar (Rp)');

// Styling Header (Warna Background Biru, Teks Putih, Tengah, Bold)
$styleHeader = [
    'font' => ['bold' => true, 'color' => ['argb' => 'FFFFFFFF']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['argb' => 'FF0d6efd'] // Warna Biru Bootstrap
    ]
];
$sheet->getStyle('A5:F5')->applyFromArray($styleHeader);
$sheet->getRowDimension(5)->setRowHeight(25); // Tinggikan baris header sedikit

// --- C. ISI DATA TABEL ---
$baris = 6;
$no = 1;
$total_uang = 0;

if (count($data_transaksi) > 0) {
    foreach ($data_transaksi as $row) {
        $total_uang += $row['jumlah_bayar'];
        $tgl_format = date('d/m/Y', strtotime($row['tanggal_bayar']));

        $sheet->setCellValue('A' . $baris, $no++);
        $sheet->setCellValue('B' . $baris, $tgl_format);
        $sheet->setCellValueExplicit('C' . $baris, $row['nisn'], DataType::TYPE_STRING);
        $sheet->setCellValue('D' . $baris, $row['nama']);
        $sheet->setCellValue('E' . $baris, $row['nama_pembayaran']);
        $sheet->setCellValue('F' . $baris, $row['jumlah_bayar']);

        // Rata Tengah untuk kolom tertentu
        $sheet->getStyle('A' . $baris . ':C' . $baris)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

        $baris++;
    }
} else {
    $sheet->setCellValue('A' . $baris, 'Tidak ada data transaksi pada periode ini.');
    $sheet->mergeCells('A' . $baris . ':F' . $baris);
    $sheet->getStyle('A' . $baris)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $baris++;
}

// --- D. FOOTER TOTAL ---
$sheet->setCellValue('A' . $baris, 'TOTAL KESELURUHAN');
$sheet->mergeCells('A' . $baris . ':E' . $baris);
$sheet->setCellValue('F' . $baris, $total_uang);

// Styling Baris Total (Warna Background Abu-abu terang)
$styleTotal = [
    'font' => ['bold' => true],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_RIGHT],
    'fill' => [
        'fillType' => Fill::FILL_SOLID,
        'startColor' => ['argb' => 'FFF2F2F2']
    ]
];
$sheet->getStyle('A' . $baris . ':F' . $baris)->applyFromArray($styleTotal);

// --- E. FORMATTING ANGKA & BORDER ---
// 1. Format Accounting (Mata Uang Rp) untuk kolom Jumlah Bayar
// Format ini menaruh "Rp" di kiri sel, angka di kanan sel, dengan pemisah ribuan.
$formatAccounting = '_-Rp* #,##0_-;-Rp* #,##0_-;_-Rp* "-"_-;_-@_-';
$sheet->getStyle('F6:F' . $baris)->getNumberFormat()->setFormatCode($formatAccounting);

// 2. Beri Garis Pembatas (Border) ke seluruh tabel
$styleBorder = [
    'borders' => [
        'allBorders' => [
            'borderStyle' => Border::BORDER_THIN,
            'color' => ['argb' => 'FF000000'],
        ],
    ],
];
$sheet->getStyle('A5:F' . $baris)->applyFromArray($styleBorder);

// --- F. AUTO-SIZE LEBAR KOLOM ---
foreach (range('A', 'F') as $col) {
    $sheet->getColumnDimension($col)->setAutoSize(true);
}

// =========================================================================
// OUTPUT FILE
// =========================================================================
$nama_file = "Laporan_Keuangan_" . str_replace(' ', '_', $jenis_laporan) . "_" . date('Ymd') . ".xlsx";

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $nama_file . '"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
