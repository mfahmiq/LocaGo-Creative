<?php
session_start();
require_once '../../config/koneksi.php';

// Proteksi halaman: Pastikan user sudah login dan berstatus admin2 (Kepala Sekolah)
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin2') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

require_once '../../includes/header.php';

$pdo = getConnection();

try {
    // 1. Ambil Total Siswa
    $stmtSiswa = $pdo->query("SELECT COUNT(*) FROM data_siswa");
    $total_siswa = $stmtSiswa->fetchColumn();

    // 2. Ambil Total Pemasukan Keseluruhan (Lunas)
    $stmtPemasukan = $pdo->query("SELECT SUM(jumlah_bayar) FROM transaksi_pembayaran WHERE status = 'Lunas'");
    $total_pemasukan = $stmtPemasukan->fetchColumn() ?? 0;

    // 3. Ambil Pemasukan Bulan Ini
    $bulan_ini = date('Y-m');
    $stmtBulanIni = $pdo->prepare("SELECT SUM(jumlah_bayar) FROM transaksi_pembayaran WHERE status = 'Lunas' AND DATE_FORMAT(tanggal_bayar, '%Y-%m') = :bulan_ini");
    $stmtBulanIni->execute([':bulan_ini' => $bulan_ini]);
    $pemasukan_bulan_ini = $stmtBulanIni->fetchColumn() ?? 0;

    // 4. Ambil Total Transaksi Belum Lunas (Tunggakan)
    $stmtTunggakan = $pdo->query("SELECT COUNT(*) FROM transaksi_pembayaran WHERE status = 'Belum Lunas'");
    $total_tunggakan = $stmtTunggakan->fetchColumn();

    // 5. Ambil 5 Transaksi Terakhir (Untuk Pantauan)
    $sqlRecent = "SELECT t.*, s.nama, j.nama_pembayaran 
                  FROM transaksi_pembayaran t
                  JOIN data_siswa s ON t.nisn = s.nisn
                  JOIN jenis_pembayaran j ON t.id_jenis = j.id_jenis
                  ORDER BY t.tanggal_bayar DESC, t.id_transaksi DESC 
                  LIMIT 5";
    $stmtRecent = $pdo->query($sqlRecent);
    $recent_transactions = $stmtRecent->fetchAll();

    // 6. Ambil 3 Riwayat Laporan Terakhir yang Dicetak Bendahara
    $stmtReports = $pdo->query("SELECT * FROM laporan ORDER BY tanggal_dibuat DESC LIMIT 3");
    $recent_reports = $stmtReports->fetchAll();
} catch (PDOException $e) {
    die("Error memuat data dashboard: " . $e->getMessage());
}

// Sapaan berdasarkan waktu
$jam = date('H');
if ($jam < 12) $sapaan = "Selamat Pagi";
elseif ($jam < 15) $sapaan = "Selamat Siang";
elseif ($jam < 18) $sapaan = "Selamat Sore";
else $sapaan = "Selamat Malam";
?>

<!-- WIDGETS STATISTIK KHUSUS KEPALA SEKOLAH -->
<div class="row mb-4">
    <div class="col-12 mb-4">
        <div class="card border-0 shadow-sm bg-success bg-gradient text-white" style="border-radius: 1rem;">
            <div class="card-body p-4 d-flex align-items-center">
                <div class="me-4 d-none d-md-block">
                    <i class="bi bi-bar-chart-line" style="font-size: 3.5rem; opacity: 0.8;"></i>
                </div>
                <div>
                    <h4 class="fw-bold mb-1"><?= $sapaan ?>, Bapak/Ibu <?= htmlspecialchars($_SESSION['username']) ?>!</h4>
                    <p class="mb-0 text-white-50">Pantau ringkasan keuangan dan aktivitas administrasi sekolah secara real-time di sini.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Card Total Siswa -->
    <div class="col-xl-3 col-sm-6 mb-4">
        <div class="card border-0 shadow-sm h-100 py-2" style="border-radius: 1rem; border-left: 5px solid #4e73df !important;">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col me-2">
                        <div class="text-xs fw-bold text-primary text-uppercase mb-1" style="font-size: 0.8rem;">Total Siswa Aktif</div>
                        <div class="h3 mb-0 fw-bold text-gray-800"><?= number_format($total_siswa, 0, ',', '.') ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-people fa-2x text-muted" style="font-size: 2rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Card Pemasukan Bulan Ini -->
    <div class="col-xl-3 col-sm-6 mb-4">
        <div class="card border-0 shadow-sm h-100 py-2" style="border-radius: 1rem; border-left: 5px solid #1cc88a !important;">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col me-2">
                        <div class="text-xs fw-bold text-success text-uppercase mb-1" style="font-size: 0.8rem;">Pemasukan Bulan Ini</div>
                        <div class="h4 mb-0 fw-bold text-gray-800">Rp <?= number_format($pemasukan_bulan_ini, 0, ',', '.') ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-graph-up-arrow text-muted" style="font-size: 2rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Card Total Pemasukan -->
    <div class="col-xl-3 col-sm-6 mb-4">
        <div class="card border-0 shadow-sm h-100 py-2" style="border-radius: 1rem; border-left: 5px solid #36b9cc !important;">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col me-2">
                        <div class="text-xs fw-bold text-info text-uppercase mb-1" style="font-size: 0.8rem;">Total Pemasukan</div>
                        <div class="h4 mb-0 fw-bold text-gray-800">Rp <?= number_format($total_pemasukan, 0, ',', '.') ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-safe text-muted" style="font-size: 2rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Card Tunggakan -->
    <div class="col-xl-3 col-sm-6 mb-4">
        <div class="card border-0 shadow-sm h-100 py-2" style="border-radius: 1rem; border-left: 5px solid #e74a3b !important;">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col me-2">
                        <div class="text-xs fw-bold text-danger text-uppercase mb-1" style="font-size: 0.8rem;">Tunggakan Aktif</div>
                        <div class="h3 mb-0 fw-bold text-gray-800"><?= number_format($total_tunggakan, 0, ',', '.') ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-exclamation-triangle text-muted" style="font-size: 2rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- TABEL PANTAUAN -->
<div class="row">
    <!-- Tabel 5 Transaksi Terakhir -->
    <div class="col-lg-8 mb-4">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 1rem;">
            <div class="card-header bg-white py-3 border-bottom-0" style="border-radius: 1rem 1rem 0 0;">
                <h6 class="m-0 fw-bold text-success"><i class="bi bi-clock-history me-2"></i>Aliran Dana Terakhir (Live)</h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="px-4" width="20%">Tanggal</th>
                                <th width="30%">Siswa</th>
                                <th width="30%">Pembayaran</th>
                                <th class="text-end px-4" width="20%">Nominal</th>
                            </tr>
                        </thead>
                        <tbody class="border-top-0">
                            <?php if (count($recent_transactions) > 0): ?>
                                <?php foreach ($recent_transactions as $row): ?>
                                    <tr>
                                        <td class="px-4 text-muted" style="font-size: 0.9rem;">
                                            <?= date('d M Y', strtotime($row['tanggal_bayar'])) ?>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-dark"><?= htmlspecialchars($row['nama']) ?></div>
                                        </td>
                                        <td>
                                            <span class="text-dark d-block"><?= htmlspecialchars($row['nama_pembayaran']) ?></span>
                                            <?php if ($row['status'] === 'Lunas'): ?>
                                                <span class="badge bg-success bg-opacity-10 text-white" style="font-size: 0.7rem;">Lunas</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger bg-opacity-10 text-white" style="font-size: 0.7rem;">Belum Lunas</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end px-4 fw-bold text-dark">
                                            Rp <?= number_format($row['jumlah_bayar'], 0, ',', '.') ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center py-4 text-muted">Belum ada aliran dana tercatat.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Aktivitas Pelaporan Bendahara -->
    <div class="col-lg-4 mb-4">
        <div class="card border-0 shadow-sm h-100" style="border-radius: 1rem;">
            <div class="card-header bg-white py-3 border-bottom-0 d-flex justify-content-between align-items-center" style="border-radius: 1rem 1rem 0 0;">
                <h6 class="m-0 fw-bold text-dark"><i class="bi bi-activity text-primary me-2"></i>Aktivitas Bendahara</h6>
                <a href="laporan/index.php" class="text-decoration-none" style="font-size: 0.85rem;">Lihat Laporan</a>
            </div>
            <div class="card-body">
                <?php if (count($recent_reports) > 0): ?>
                    <div class="timeline">
                        <?php foreach ($recent_reports as $log): ?>
                            <div class="d-flex mb-4">
                                <div class="me-3 mt-1">
                                    <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 35px; height: 35px;">
                                        <i class="bi bi-printer"></i>
                                    </div>
                                </div>
                                <div>
                                    <h6 class="mb-1 fw-bold text-dark" style="font-size: 0.9rem;">Cetak Laporan: <?= htmlspecialchars($log['jenis_laporan']) ?></h6>
                                    <p class="mb-0 text-muted" style="font-size: 0.8rem;">Periode: <?= htmlspecialchars($log['periode']) ?></p>
                                    <small class="text-primary fw-medium" style="font-size: 0.75rem;">
                                        <i class="bi bi-clock me-1"></i> <?= date('d M Y, H:i', strtotime($log['tanggal_dibuat'])) ?>
                                    </small>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="bi bi-journal-x text-muted fs-1 mb-2 d-block"></i>
                        <span class="text-muted" style="font-size: 0.9rem;">Belum ada laporan yang dicetak bulan ini.</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>