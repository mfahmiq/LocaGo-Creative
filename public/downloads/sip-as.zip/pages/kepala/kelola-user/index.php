<?php
session_start();
require_once '../../../config/koneksi.php';

if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin2') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

require_once '../../../includes/header.php';

$pdo = getConnection();

// --- LOGIKA PENCARIAN & PAGINATION ---
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$search = isset($_GET['cari']) ? trim($_GET['cari']) : '';
$searchQuery = '';
$params = [];

if (!empty($search)) {
    $searchQuery = " WHERE username LIKE :search1 OR kontak LIKE :search2 ";
    $params[':search1'] = "%$search%";
    $params[':search2'] = "%$search%";
}

try {
    // 1. Hitung total data
    $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM users" . $searchQuery);
    $stmtCount->execute($params);
    $total_data = $stmtCount->fetchColumn();
    $total_pages = ceil($total_data / $limit);

    // 2. Ambil data users
    $stmt = $pdo->prepare("SELECT id_user, username, kontak, role FROM users" . $searchQuery . " ORDER BY id_user DESC LIMIT $limit OFFSET $offset");
    $stmt->execute($params);
    $data_users = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error mengambil data user: " . $e->getMessage());
}
?>

<div class="row mb-4 align-items-center">
    <div class="col-md-5">
        <h4 class="mb-0 fw-bold text-dark">Kelola Pengguna</h4>
        <p class="text-muted mb-0" style="font-size: 0.9rem;">Atur hak akses dan akun administrator sistem</p>
    </div>
    <div class="col-md-7 d-flex justify-content-md-end align-items-center gap-2 mt-3 mt-md-0">
        <!-- Form Cari -->
        <form method="GET" action="index.php" class="d-flex w-100" style="max-width: 300px;">
            <div class="input-group shadow-sm" style="border-radius: 50rem;">
                <input type="text" name="cari" class="form-control border-end-0 bg-white" style="border-radius: 50rem 0 0 50rem; padding-left: 1.2rem;" placeholder="Cari username..." value="<?= htmlspecialchars($search) ?>">
                <button class="btn btn-white border border-start-0 bg-white" type="submit" style="border-radius: 0 50rem 50rem 0; padding-right: 1.2rem;">
                    <i class="bi bi-search text-primary"></i>
                </button>
            </div>
        </form>
        <!-- Tombol Tambah -->
        <a href="tambah.php" class="btn btn-primary rounded-pill shadow-sm px-4 flex-shrink-0">
            <i class="bi bi-person-plus-fill me-1"></i> Tambah User
        </a>
    </div>
</div>

<!-- Notifikasi -->
<?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm rounded-3" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i> <?= $_SESSION['success'] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm rounded-3" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $_SESSION['error'] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<!-- Card Tabel -->
<div class="card border-0 shadow-sm" style="border-radius: 1rem;">
    <div class="card-body p-4">

        <?php if (!empty($search)): ?>
            <div class="mb-3">
                <span class="text-muted">Hasil pencarian untuk: <strong>"<?= htmlspecialchars($search) ?>"</strong></span>
                <a href="index.php" class="text-decoration-none ms-2 badge bg-secondary bg-opacity-10 text-white">Reset Pencarian</a>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="text-center rounded-start" width="5%">No</th>
                        <th width="25%">Username</th>
                        <th width="20%">No. Kontak</th>
                        <th width="20%">Level Akses</th>
                        <th class="text-center rounded-end" width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <?php if (count($data_users) > 0): ?>
                        <?php
                        $no = $offset + 1;
                        foreach ($data_users as $row):
                        ?>
                            <tr>
                                <td class="text-center text-muted"><?= $no++ ?></td>
                                <td>
                                    <div class="fw-bold text-dark"><i class="bi bi-person-circle text-muted me-2"></i> <?= htmlspecialchars($row['username']) ?></div>
                                </td>
                                <td>
                                    <span class="text-muted"><i class="bi bi-telephone text-secondary me-1" style="font-size: 0.85rem;"></i> <?= htmlspecialchars($row['kontak']) ?></span>
                                </td>
                                <td>
                                    <?php if ($row['role'] === 'admin1'): ?>
                                        <span class="badge bg-primary bg-opacity-10 text-white px-3 py-2 rounded-pill"><i class="bi bi-shield-lock-fill me-1"></i> Admin 1 (Super)</span>
                                    <?php else: ?>
                                        <span class="badge bg-info bg-opacity-10 text-white px-3 py-2 rounded-pill"><i class="bi bi-person-badge-fill me-1"></i> Admin 2 (Kepala)</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <!-- LOGIKA TOMBOL EDIT -->
                                    <?php if (isset($_SESSION['username']) && $_SESSION['username'] === $row['username']): ?>
                                        <!-- Jika ini akunnya sendiri, arahkan ke halaman profil -->
                                        <a href="../../edit-admin.php" class="btn btn-light btn-sm text-success shadow-sm rounded-3 me-1" title="Edit Profil Saya">
                                            <i class="bi bi-person-lines-fill"></i>
                                        </a>
                                    <?php else: ?>
                                        <!-- Jika akun orang lain, arahkan ke form edit user -->
                                        <a href="edit.php?id=<?= $row['id_user'] ?>" class="btn btn-light btn-sm text-primary shadow-sm rounded-3 me-1" title="Edit Data">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>
                                    <?php endif; ?>

                                    <!-- LOGIKA TOMBOL HAPUS -->
                                    <?php if (isset($_SESSION['username']) && $_SESSION['username'] !== $row['username']): ?>
                                        <a href="hapus.php?id=<?= $row['id_user'] ?>" class="btn btn-light btn-sm text-danger shadow-sm rounded-3" title="Hapus Data" onclick="return confirm('PENTING!\nApakah Anda yakin ingin menghapus user [<?= htmlspecialchars($row['username']) ?>]?')">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    <?php else: ?>
                                        <button class="btn btn-light btn-sm text-muted shadow-sm rounded-3 disabled" title="Anda tidak bisa menghapus akun Anda sendiri" style="opacity: 0.5;">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-5">
                                <div class="text-muted">
                                    <i class="bi bi-people fs-1 d-block mb-3"></i>
                                    <p class="mb-0">Data pengguna tidak ditemukan.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center mb-0">
                    <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                        <a class="page-link rounded-start-pill px-3" href="?page=<?= $page - 1 ?><?= !empty($search) ? '&cari=' . urlencode($search) : '' ?>">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= ($page == $i) ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?><?= !empty($search) ? '&cari=' . urlencode($search) : '' ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= ($page >= $total_pages) ? 'disabled' : '' ?>">
                        <a class="page-link rounded-end-pill px-3" href="?page=<?= $page + 1 ?><?= !empty($search) ? '&cari=' . urlencode($search) : '' ?>">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>

    </div>
</div>

<?php require_once '../../../includes/footer.php'; ?>