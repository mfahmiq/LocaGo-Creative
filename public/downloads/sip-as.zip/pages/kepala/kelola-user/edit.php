<?php
session_start();
require_once '../../../config/koneksi.php';

if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin2') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

$error = '';
$pdo = getConnection();

// Cek apakah ada parameter ID di URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = "Data pengguna tidak ditemukan!";
    header("Location: index.php");
    exit;
}

$id_user = $_GET['id'];

// 1. Tarik Data User Lama
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id_user = :id");
    $stmt->execute([':id' => $id_user]);
    $user = $stmt->fetch();

    if (!$user) {
        $_SESSION['error'] = "Data pengguna tidak ditemukan!";
        header("Location: index.php");
        exit;
    }
} catch (PDOException $e) {
    die("Error mengambil data: " . $e->getMessage());
}

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password']; // Ingat: Password opsional saat edit
    $kontak   = trim($_POST['kontak']);
    $role     = $_POST['role'];

    // Validasi Input (Password tidak dicek kosong karena boleh dikosongkan)
    if (empty($username) || empty($kontak) || empty($role)) {
        $error = "Username, No Kontak, dan Level Akses wajib diisi!";
    } else {
        try {
            // 2. Cek username ganda (TETAPI abaikan milik user ini sendiri)
            $stmtCheck = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = :username AND id_user != :id");
            $stmtCheck->execute([
                ':username' => $username,
                ':id'       => $id_user
            ]);
            $is_exists = $stmtCheck->fetchColumn();

            if ($is_exists > 0) {
                $error = "Username <strong>$username</strong> sudah digunakan oleh orang lain!";
            } else {

                // 3. Logika Update Data (Dengan atau Tanpa merubah Password)
                if (empty($password)) {
                    // JIKA PASSWORD KOSONG: Update data lain saja, biarkan password lama
                    $sql = "UPDATE users SET username = :username, kontak = :kontak, role = :role WHERE id_user = :id";
                    $stmtUpdate = $pdo->prepare($sql);
                    $stmtUpdate->execute([
                        ':username' => $username,
                        ':kontak'   => $kontak,
                        ':role'     => $role,
                        ':id'       => $id_user
                    ]);
                } else {
                    // JIKA PASSWORD DIISI: Enkripsi password baru dan update semua data
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $sql = "UPDATE users SET username = :username, password = :password, kontak = :kontak, role = :role WHERE id_user = :id";
                    $stmtUpdate = $pdo->prepare($sql);
                    $stmtUpdate->execute([
                        ':username' => $username,
                        ':password' => $hashed_password,
                        ':kontak'   => $kontak,
                        ':role'     => $role,
                        ':id'       => $id_user
                    ]);
                }

                $_SESSION['success'] = "Data pengguna <strong>$username</strong> berhasil diperbarui!";

                // Jika user mengedit akunnya sendiri dan merubah username, perbarui session username-nya agar tidak error
                if ($_SESSION['username'] === $user['username'] && $username !== $user['username']) {
                    $_SESSION['username'] = $username;
                }

                header("Location: index.php");
                exit;
            }
        } catch (PDOException $e) {
            $error = "Terjadi kesalahan sistem: " . $e->getMessage();
        }
    }
}

require_once '../../../includes/header.php';
?>

<style>
    .form-control-modern,
    .form-select-modern {
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
        padding: 0.75rem 1rem;
        border-radius: 0.5rem;
        color: #212529;
        transition: all 0.2s;
    }

    .form-control-modern:focus,
    .form-select-modern:focus {
        background-color: #ffffff;
        border-color: #4e73df;
        box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.15);
    }

    .input-group-text-modern {
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
        border-right: none;
        color: #6c757d;
        border-radius: 0.5rem 0 0 0.5rem;
        font-weight: 600;
    }

    .form-control-modern.with-icon {
        border-left: none;
        border-radius: 0 0.5rem 0.5rem 0;
    }
</style>

<div class="row justify-content-center">
    <div class="col-xl-8 col-lg-10">

        <div class="mb-3">
            <a href="index.php" class="btn btn-white shadow-sm rounded-pill text-muted fw-medium border-0 px-3 py-2" style="font-size: 0.9rem;">
                <i class="bi bi-arrow-left me-2"></i> Kembali ke Kelola Pengguna
            </a>
        </div>

        <div class="card border-0 shadow-sm" style="border-radius: 1.2rem; overflow: hidden;">
            <div class="bg-primary bg-opacity-10 py-4 px-4 px-md-5 border-bottom border-primary border-opacity-10">
                <h5 class="fw-bold text-white mb-1">Edit Data Pengguna</h5>
                <p class="text-white text-opacity-75 mb-0" style="font-size: 0.85rem;">Perbarui rincian atau hak akses untuk <strong class="text-white"><?= htmlspecialchars($user['username']) ?></strong>.</p>
            </div>

            <div class="card-body p-4 p-md-5 bg-white">

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm rounded-3" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="" method="POST">

                    <div class="mb-4">
                        <label for="username" class="form-label fw-semibold text-dark">Username <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text input-group-text-modern"><i class="bi bi-person"></i></span>
                            <input type="text" class="form-control form-control-modern with-icon" id="username" name="username" value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : htmlspecialchars($user['username']) ?>" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="password" class="form-label fw-semibold text-dark">Password Baru</label>
                        <div class="input-group">
                            <span class="input-group-text input-group-text-modern"><i class="bi bi-key"></i></span>
                            <!-- Atribut required dihilangkan karena opsional -->
                            <input type="password" class="form-control form-control-modern with-icon" id="password" name="password" placeholder="Ketik password baru di sini...">
                        </div>
                        <small class="text-primary d-block mt-2 fw-medium" style="font-size: 0.8rem;"><i class="bi bi-info-circle me-1"></i> Biarkan kosong jika Anda tidak ingin mengubah password user ini.</small>
                    </div>

                    <div class="row mb-5">
                        <div class="col-md-6 mb-4 mb-md-0">
                            <label for="kontak" class="form-label fw-semibold text-dark">No. Kontak / WhatsApp <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text input-group-text-modern"><i class="bi bi-telephone"></i></span>
                                <input type="text" pattern="[0-9]+" title="Hanya boleh berisi angka" class="form-control form-control-modern with-icon" id="kontak" name="kontak" value="<?= isset($_POST['kontak']) ? htmlspecialchars($_POST['kontak']) : htmlspecialchars($user['kontak']) ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="role" class="form-label fw-semibold text-dark">Level Akses (Role) <span class="text-danger">*</span></label>
                            <select class="form-select form-select-modern" id="role" name="role" required>
                                <?php $role_saat_ini = isset($_POST['role']) ? $_POST['role'] : $user['role']; ?>
                                <option value="admin2" <?= ($role_saat_ini == 'admin2') ? 'selected' : '' ?>>Admin 2 (Kepala)</option>
                                <option value="admin1" <?= ($role_saat_ini == 'admin1') ? 'selected' : '' ?>>Admin 1 (Super Admin / Bendahara)</option>
                            </select>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-3 pt-3 border-top">
                        <a href="edit.php?id=<?= $user['id_user'] ?>" class="btn btn-light rounded-pill px-4 fw-medium border shadow-sm text-muted">Reset</a>
                        <button type="submit" class="btn btn-primary rounded-pill shadow-sm px-5 fw-medium">
                            <i class="bi bi-pencil-square me-1"></i> Update Pengguna
                        </button>
                    </div>

                </form>
            </div>
        </div>

    </div>
</div>

<?php require_once '../../../includes/footer.php'; ?>