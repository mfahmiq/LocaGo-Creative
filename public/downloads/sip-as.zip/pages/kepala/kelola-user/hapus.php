<?php
session_start();
require_once '../../../config/koneksi.php';

if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin2') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

// Mengecek apakah ada parameter ID yang dikirim melalui URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $pdo = getConnection();
    $id_user = $_GET['id'];

    try {
        // 1. Cek dulu datanya dan ambil username untuk pesan notifikasi
        $stmtCheck = $pdo->prepare("SELECT username FROM users WHERE id_user = :id");
        $stmtCheck->execute([':id' => $id_user]);
        $user = $stmtCheck->fetch();

        if ($user) {
            $username = $user['username'];

            // 2. PROTEKSI BACKEND (Mencegah Bunuh Diri)
            // Mengecek apakah username yang akan dihapus sama dengan username yang sedang login saat ini
            if (isset($_SESSION['username']) && $_SESSION['username'] === $username) {
                $_SESSION['error'] = "Tindakan Ditolak! Anda tidak dapat menghapus akun Anda sendiri yang sedang aktif.";
            } else {
                // 3. Jika aman, jalankan perintah DELETE
                $stmtDelete = $pdo->prepare("DELETE FROM users WHERE id_user = :id");
                $stmtDelete->execute([':id' => $id_user]);

                // Set pesan sukses
                $_SESSION['success'] = "Akun pengguna <strong>" . htmlspecialchars($username) . "</strong> berhasil dihapus secara permanen.";
            }
        } else {
            // Jika data tidak ditemukan di database
            $_SESSION['error'] = "Gagal! Data pengguna tidak ditemukan.";
        }
    } catch (PDOException $e) {
        // Menangkap error sistem/database
        $_SESSION['error'] = "Terjadi kesalahan sistem saat menghapus data: " . $e->getMessage();
    }
} else {
    // Jika file diakses langsung tanpa parameter ID
    $_SESSION['error'] = "Akses tidak valid!";
}

// Redirect kembali ke halaman utama Kelola User
header("Location: index.php");
exit;
