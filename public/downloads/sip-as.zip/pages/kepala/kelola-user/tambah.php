<?php
session_start();
require_once '../../../config/koneksi.php';

if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin2') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

$error = '';
$pdo = getConnection();

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $kontak   = trim($_POST['kontak']);
    $role     = $_POST['role'];

    // 1. Validasi Input Kosong
    if (empty($username) || empty($password) || empty($kontak) || empty($role)) {
        $error = "Semua kolom wajib diisi!";
    } else {
        try {
            // 2. Cek apakah username sudah ada di database (Mencegah Duplicate Entry)
            $stmtCheck = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = :username");
            $stmtCheck->execute([':username' => $username]);
            $is_exists = $stmtCheck->fetchColumn();

            if ($is_exists > 0) {
                $error = "Username <strong>$username</strong> sudah digunakan! Silakan gunakan kombinasi lain.";
            } else {
                // 3. Enkripsi Password menggunakan standar Bcrypt
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // 4. Insert ke Database
                $stmt = $pdo->prepare("INSERT INTO users (username, password, kontak, role) 
                                       VALUES (:username, :password, :kontak, :role)");
                $stmt->execute([
                    ':username' => $username,
                    ':password' => $hashed_password,
                    ':kontak'   => $kontak,
                    ':role'     => $role
                ]);

                $_SESSION['success'] = "Pengguna baru <strong>$username</strong> berhasil ditambahkan!";
                header("Location: index.php");
                exit;
            }
        } catch (PDOException $e) {
            $error = "Terjadi kesalahan sistem: " . $e->getMessage();
        }
    }
}

require_once '../../../includes/header.php';
?>

<style>
    .form-control-modern,
    .form-select-modern {
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
        padding: 0.75rem 1rem;
        border-radius: 0.5rem;
        color: #212529;
        transition: all 0.2s;
    }

    .form-control-modern:focus,
    .form-select-modern:focus {
        background-color: #ffffff;
        border-color: #4e73df;
        box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.15);
    }

    .input-group-text-modern {
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
        border-right: none;
        color: #6c757d;
        border-radius: 0.5rem 0 0 0.5rem;
        font-weight: 600;
    }

    .form-control-modern.with-icon {
        border-left: none;
        border-radius: 0 0.5rem 0.5rem 0;
    }
</style>

<div class="row justify-content-center">
    <div class="col-xl-8 col-lg-10">

        <div class="mb-3">
            <a href="index.php" class="btn btn-white shadow-sm rounded-pill text-muted fw-medium border-0 px-3 py-2" style="font-size: 0.9rem;">
                <i class="bi bi-arrow-left me-2"></i> Kembali ke Kelola Pengguna
            </a>
        </div>

        <div class="card border-0 shadow-sm" style="border-radius: 1.2rem; overflow: hidden;">
            <div class="bg-primary bg-opacity-10 py-4 px-4 px-md-5 border-bottom border-primary border-opacity-10">
                <h5 class="fw-bold text-white mb-1">Tambah Pengguna Baru</h5>
                <p class="text-white text-opacity-75 mb-0" style="font-size: 0.85rem;">Buat akun baru untuk memberikan akses kepada staf atau administrator.</p>
            </div>

            <div class="card-body p-4 p-md-5 bg-white">

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm rounded-3" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="" method="POST">

                    <div class="mb-4">
                        <label for="username" class="form-label fw-semibold text-dark">Username <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text input-group-text-modern"><i class="bi bi-person"></i></span>
                            <input type="text" class="form-control form-control-modern with-icon" id="username" name="username" placeholder="Contoh: staf_tu" value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>" required>
                        </div>
                        <small class="text-muted d-block mt-1" style="font-size: 0.8rem;">Gunakan huruf kecil tanpa spasi untuk memudahkan login.</small>
                    </div>

                    <div class="mb-4">
                        <label for="password" class="form-label fw-semibold text-dark">Password <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text input-group-text-modern"><i class="bi bi-key"></i></span>
                            <input type="password" class="form-control form-control-modern with-icon" id="password" name="password" placeholder="Masukkan password yang kuat" required>
                        </div>
                    </div>

                    <div class="row mb-5">
                        <div class="col-md-6 mb-4 mb-md-0">
                            <label for="kontak" class="form-label fw-semibold text-dark">No. Kontak / WhatsApp <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text input-group-text-modern"><i class="bi bi-telephone"></i></span>
                                <input type="text" pattern="[0-9]+" title="Hanya boleh berisi angka" class="form-control form-control-modern with-icon" id="kontak" name="kontak" placeholder="08..." value="<?= isset($_POST['kontak']) ? htmlspecialchars($_POST['kontak']) : '' ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="role" class="form-label fw-semibold text-dark">Level Akses (Role) <span class="text-danger">*</span></label>
                            <select class="form-select form-select-modern" id="role" name="role" required>
                                <option value="">-- Pilih Level Akses --</option>
                                <option value="admin2" <?= (isset($_POST['role']) && $_POST['role'] == 'admin2') ? 'selected' : '' ?>>Admin 2 (Kepala)</option>
                                <option value="admin1" <?= (isset($_POST['role']) && $_POST['role'] == 'admin1') ? 'selected' : '' ?>>Admin 1 (Super Admin / Bendahara)</option>
                            </select>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-3 pt-3 border-top">
                        <button type="reset" class="btn btn-light rounded-pill px-4 fw-medium border shadow-sm text-muted">Reset</button>
                        <button type="submit" class="btn btn-primary rounded-pill shadow-sm px-5 fw-medium">
                            <i class="bi bi-save me-1"></i> Simpan Pengguna
                        </button>
                    </div>

                </form>
            </div>
        </div>

    </div>
</div>

<?php require_once '../../../includes/footer.php'; ?>