<?php
session_start();

// Perhatikan path ini, menyesuaikan dengan posisi file di folder /pages/
require_once '../config/koneksi.php';

// Proteksi halaman: Cukup pastikan dia sudah login (Bisa admin1 maupun admin2)
if (!isset($_SESSION['is_logged_in'])) {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

$error = '';
$success = '';
$pdo = getConnection();

// 1. AMBIL DATA BERDASARKAN SESSION YANG SEDANG AKTIF
// Kita asumsikan saat login, Anda menyimpan 'username' di dalam session
$username_aktif = $_SESSION['username'];

try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute([':username' => $username_aktif]);
    $user = $stmt->fetch();

    if (!$user) {
        die("Data akun Anda tidak ditemukan di sistem!");
    }
} catch (PDOException $e) {
    die("Error mengambil data: " . $e->getMessage());
}

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password']; // Opsional
    $kontak   = trim($_POST['kontak']);

    // Validasi
    if (empty($username) || empty($kontak)) {
        $error = "Username dan No Kontak wajib diisi!";
    } else {
        try {
            // Cek username ganda (Abaikan jika itu adalah username lama milik sendiri)
            $stmtCheck = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = :username AND id_user != :id");
            $stmtCheck->execute([
                ':username' => $username,
                ':id'       => $user['id_user']
            ]);

            if ($stmtCheck->fetchColumn() > 0) {
                $error = "Username <strong>$username</strong> sudah digunakan oleh pengguna lain!";
            } else {

                // Proses Update
                if (empty($password)) {
                    // Update tanpa rubah password
                    $sql = "UPDATE users SET username = :username, kontak = :kontak WHERE id_user = :id";
                    $stmtUpdate = $pdo->prepare($sql);
                    $stmtUpdate->execute([
                        ':username' => $username,
                        ':kontak'   => $kontak,
                        ':id'       => $user['id_user']
                    ]);
                } else {
                    // Update beserta enkripsi password baru
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $sql = "UPDATE users SET username = :username, password = :password, kontak = :kontak WHERE id_user = :id";
                    $stmtUpdate = $pdo->prepare($sql);
                    $stmtUpdate->execute([
                        ':username' => $username,
                        ':password' => $hashed_password,
                        ':kontak'   => $kontak,
                        ':id'       => $user['id_user']
                    ]);
                }

                // Tampilkan pesan sukses di halaman yang sama
                $success = "Profil Anda berhasil diperbarui!";

                // Jika username diubah, segera perbarui session agar sistem tidak menolak aksesnya
                if ($username !== $user['username']) {
                    $_SESSION['username'] = $username;
                }

                // Refresh variabel $user agar form langsung menampilkan data terbaru
                $user['username'] = $username;
                $user['kontak'] = $kontak;
            }
        } catch (PDOException $e) {
            $error = "Terjadi kesalahan sistem: " . $e->getMessage();
        }
    }
}

// Include Header (Perhatikan path-nya)
require_once '../includes/header.php';
?>

<style>
    .form-control-modern {
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
        padding: 0.75rem 1rem;
        border-radius: 0.5rem;
        color: #212529;
        transition: all 0.2s;
    }

    .form-control-modern:focus {
        background-color: #ffffff;
        border-color: #4e73df;
        box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.15);
    }

    .input-group-text-modern {
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
        border-right: none;
        color: #6c757d;
        border-radius: 0.5rem 0 0 0.5rem;
        font-weight: 600;
    }

    .form-control-modern.with-icon {
        border-left: none;
        border-radius: 0 0.5rem 0.5rem 0;
    }
</style>

<div class="row justify-content-center">
    <div class="col-xl-7 col-lg-9">

        <div class="mb-3">
            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin2'): ?>
                <!-- Jika yang login adalah Kepala Sekolah -->
                <a href="<?= BASE_URL ?>pages/kepala/dashboard.php" class="btn btn-white shadow-sm rounded-pill text-muted fw-medium border-0 px-3 py-2" style="font-size: 0.9rem;">
                    <i class="bi bi-arrow-left me-2"></i> Kembali ke Dashboard
                </a>
            <?php else: ?>
                <!-- Jika yang login adalah Bendahara (Admin 1) -->
                <a href="<?= BASE_URL ?>pages/admin/kelola-user/index.php" class="btn btn-white shadow-sm rounded-pill text-muted fw-medium border-0 px-3 py-2" style="font-size: 0.9rem;">
                    <i class="bi bi-arrow-left me-2"></i> Kembali ke Kelola Pengguna
                </a>
            <?php endif; ?>
        </div>

        <div class="card border-0 shadow-sm" style="border-radius: 1.2rem; overflow: hidden;">
            <div class="bg-primary bg-opacity-10 py-4 px-4 px-md-5 border-bottom border-primary border-opacity-10">
                <h5 class="fw-bold text-white mb-1">Pengaturan Akun Saya</h5>
                <p class="text-white text-opacity-75 mb-0" style="font-size: 0.85rem;">Perbarui rincian login dan kontak pribadi Anda di sini.</p>
            </div>

            <div class="card-body p-4 p-md-5 bg-white">

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger border-0 shadow-sm rounded-3">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($success)): ?>
                    <div class="alert alert-success border-0 shadow-sm rounded-3">
                        <i class="bi bi-check-circle-fill me-2"></i> <?= $success ?>
                    </div>
                <?php endif; ?>

                <form action="" method="POST">

                    <div class="mb-4">
                        <label class="form-label fw-semibold text-dark">Level Akses (Role)</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-shield-lock"></i></span>
                            <!-- Dibuat readonly agar user tidak bisa merubah rolenya sendiri -->
                            <input type="text" class="form-control bg-light text-muted border-start-0" value="<?= $user['role'] === 'admin1' ? 'Admin 1 (Super Admin)' : 'Admin 2 (Kepala)' ?>" readonly>
                        </div>
                        <small class="text-muted d-block mt-1" style="font-size: 0.8rem;">Anda tidak dapat mengubah level akses Anda sendiri.</small>
                    </div>

                    <div class="mb-4">
                        <label for="username" class="form-label fw-semibold text-dark">Username <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text input-group-text-modern"><i class="bi bi-person"></i></span>
                            <input type="text" class="form-control form-control-modern with-icon" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="kontak" class="form-label fw-semibold text-dark">No. Kontak / WhatsApp <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text input-group-text-modern"><i class="bi bi-telephone"></i></span>
                            <input type="text" pattern="[0-9]+" class="form-control form-control-modern with-icon" id="kontak" name="kontak" value="<?= htmlspecialchars($user['kontak']) ?>" required>
                        </div>
                    </div>

                    <div class="mb-5">
                        <label for="password" class="form-label fw-semibold text-dark">Password Baru</label>
                        <div class="input-group">
                            <span class="input-group-text input-group-text-modern"><i class="bi bi-key"></i></span>
                            <input type="password" class="form-control form-control-modern with-icon" id="password" name="password" placeholder="Ketik password baru di sini...">
                        </div>
                        <small class="text-primary d-block mt-2 fw-medium" style="font-size: 0.8rem;"><i class="bi bi-info-circle me-1"></i> Kosongkan bagian ini jika Anda tidak ingin mengubah password.</small>
                    </div>

                    <div class="d-flex justify-content-end pt-3 border-top">
                        <button type="submit" class="btn btn-primary rounded-pill shadow-sm px-5 fw-medium">
                            <i class="bi bi-save me-1"></i> Simpan Profil
                        </button>
                    </div>

                </form>
            </div>
        </div>

    </div>
</div>

<?php require_once '../includes/footer.php'; ?>