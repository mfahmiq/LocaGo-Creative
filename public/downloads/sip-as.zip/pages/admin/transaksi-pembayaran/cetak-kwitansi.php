<?php
session_start();
require_once '../../../config/koneksi.php';

// Wajib panggil autoload dari Composer agar Dompdf berfungsi
require_once '../../../vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// Pastikan user sudah login
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin1') {
    die("Akses ditolak!");
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Data transaksi tidak ditemukan!");
}

$id_transaksi = $_GET['id'];
$pdo = getConnection();

try {
    // 1. Tarik Data Transaksi (JOIN dengan tabel siswa dan jenis pembayaran)
    $stmt = $pdo->prepare("SELECT t.*, s.nama, s.nisn, j.nama_pembayaran 
                           FROM transaksi_pembayaran t
                           JOIN data_siswa s ON t.nisn = s.nisn
                           JOIN jenis_pembayaran j ON t.id_jenis = j.id_jenis
                           WHERE t.id_transaksi = :id");
    $stmt->execute([':id' => $id_transaksi]);
    $data = $stmt->fetch();

    if (!$data) {
        die("Data transaksi tidak ditemukan!");
    }

    // 2. Tarik Data Profil Sekolah
    $stmtProfil = $pdo->query("SELECT * FROM profil_sekolah LIMIT 1");
    $profil = $stmtProfil->fetch();
} catch (PDOException $e) {
    die("Error mengambil data: " . $e->getMessage());
}

// Fungsi Terbilang (Mengubah Angka menjadi Teks)
function penyebut($nilai)
{
    $nilai = abs($nilai);
    $huruf = array("", "Satu", "Dua", "Tiga", "Empat", "Lima", "Enam", "Tujuh", "Delapan", "Sembilan", "Sepuluh", "Sebelas");
    $temp = "";
    if ($nilai < 12) {
        $temp = " " . $huruf[$nilai];
    } else if ($nilai < 20) {
        $temp = penyebut($nilai - 10) . " Belas";
    } else if ($nilai < 100) {
        $temp = penyebut($nilai / 10) . " Puluh" . penyebut($nilai % 10);
    } else if ($nilai < 200) {
        $temp = " Seratus" . penyebut($nilai - 100);
    } else if ($nilai < 1000) {
        $temp = penyebut($nilai / 100) . " Ratus" . penyebut($nilai % 100);
    } else if ($nilai < 2000) {
        $temp = " Seribu" . penyebut($nilai - 1000);
    } else if ($nilai < 1000000) {
        $temp = penyebut($nilai / 1000) . " Ribu" . penyebut($nilai % 1000);
    } else if ($nilai < 1000000000) {
        $temp = penyebut($nilai / 1000000) . " Juta" . penyebut($nilai % 1000000);
    }
    return $temp;
}

function terbilang($nilai)
{
    if ($nilai < 0) {
        $hasil = "Minus " . trim(penyebut($nilai));
    } else {
        $hasil = trim(penyebut($nilai));
    }
    return $hasil . " Rupiah";
}

$no_kuitansi = "TRX-" . date('ymd', strtotime($data['tanggal_bayar'])) . "-" . sprintf("%04d", $data['id_transaksi']);
$tanggal_indo = date('d M Y', strtotime($data['tanggal_bayar']));

// =========================================================================
// HTML UNTUK DOMPDF (Versi 1 Halaman Presisi)
// =========================================================================
$html = '
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kuitansi - ' . $no_kuitansi . '</title>
    <style>
        /* Paksa margin kertas menjadi sangat kecil agar muat 1 halaman */
        @page {
            margin: 20px 30px; 
        }
        body {
            font-family: "Helvetica", "Arial", sans-serif;
            font-size: 11px; /* Ukuran font sedikit dikecilkan */
            margin: 0;
            padding: 0;
            color: #111;
        }
        .header {
            width: 100%;
            border-bottom: 2px solid #000;
            padding-bottom: 5px;
            margin-bottom: 10px; /* Jarak dirapatkan */
        }
        .header table { width: 100%; }
        .header td { vertical-align: top; }
        .sekolah-nama { font-size: 15px; font-weight: bold; text-transform: uppercase; margin: 0 0 2px 0; }
        .sekolah-alamat { font-size: 9px; margin: 0; color: #444; }
        .title-box { text-align: right; }
        .title-box h1 { font-size: 18px; margin: 0; letter-spacing: 2px; }
        .title-box p { font-size: 10px; margin: 3px 0 0 0; }

        .content table { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
        .content table td { padding: 4px 0; vertical-align: top; }
        .content table td.label { width: 110px; font-weight: bold; }
        .content table td.separator { width: 15px; text-align: center; }
        .content table td.value { border-bottom: 1px dotted #999; }
        
        .terbilang-box {
            background-color: #f0f0f0;
            padding: 5px 10px;
            font-style: italic;
            font-weight: bold;
            display: block;
            border: 1px dashed #aaa;
        }

        .footer { width: 100%; margin-top: 10px; }
        .footer table { width: 100%; }
        .nominal-box {
            border: 2px solid #000;
            padding: 8px 15px;
            font-size: 15px;
            font-weight: bold;
            background-color: #e9e9e9;
            display: inline-block;
        }
        .ttd-box { text-align: center; font-size: 11px; }
        .ttd-nama { margin-top: 40px; font-weight: bold; text-decoration: underline; } /* Jarak ttd sedikit dikurangi */
    </style>
</head>
<body>

    <div class="header">
        <table>
            <tr>
                <td width="60%">
                    <h2 class="sekolah-nama">' . htmlspecialchars($profil['nama_sekolah']) . '</h2>
                    <p class="sekolah-alamat">
                        ' . nl2br(htmlspecialchars($profil['alamat'])) . '<br>
                        Telp: ' . htmlspecialchars($profil['telepon']) . ' | Email: ' . htmlspecialchars($profil['email_sekolah']) . '
                    </p>
                </td>
                <td width="40%" class="title-box">
                    <h1>KUITANSI</h1>
                    <p>No: <strong>' . $no_kuitansi . '</strong></p>
                </td>
            </tr>
        </table>
    </div>

    <div class="content">
        <table>
            <tr>
                <td class="label">Telah terima dari</td>
                <td class="separator">:</td>
                <td class="value"><strong>' . htmlspecialchars($data['nama']) . '</strong> (NISN: ' . htmlspecialchars($data['nisn']) . ')</td>
            </tr>
            <tr>
                <td class="label">Uang sejumlah</td>
                <td class="separator">:</td>
                <td>
                    <div class="terbilang-box"># ' . terbilang($data['jumlah_bayar']) . ' #</div>
                </td>
            </tr>
            <tr>
                <td class="label">Untuk pembayaran</td>
                <td class="separator">:</td>
                <td class="value">
                    ' . htmlspecialchars($data['nama_pembayaran']) . ' 
                    ' . ($data['status'] == 'Belum Lunas' ? '<i>(Belum Lunas / Cicilan)</i>' : '') . '
                </td>
            </tr>
        </table>
    </div>

    <div class="footer">
        <table>
            <tr>
                <td width="60%" style="vertical-align: bottom;">
                    <div class="nominal-box">
                        Rp ' . number_format($data['jumlah_bayar'], 0, ',', '.') . '
                    </div>
                </td>
                <td width="40%" class="ttd-box">
                    <p style="margin:0 0 5px 0;">Pekanbaru, ' . $tanggal_indo . '<br>Penerima / Bendahara,</p>
                    <div class="ttd-nama">' . htmlspecialchars($_SESSION['username']) . '</div>
                </td>
            </tr>
        </table>
    </div>

</body>
</html>
';

// =========================================================================
// INISIALISASI DOMPDF
// =========================================================================
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true); // Aktifkan jika nanti ada logo/gambar dari URL luar

$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);

// Set Ukuran Kertas Custom (Width: 21cm, Height: 9.9cm)
// Dalam ukuran poin: 21cm = ~595.28 pt, 9.9cm = ~280.63 pt
$customPaper = array(0, 0, 595.28, 280.63);
$dompdf->setPaper($customPaper);

// Render HTML ke PDF
$dompdf->render();

// Outputkan ke Browser
// "Attachment" => false artinya PDF akan tampil di browser (tidak langsung ter-download paksa)
$dompdf->stream("Kuitansi_" . $no_kuitansi . ".pdf", array("Attachment" => false));
