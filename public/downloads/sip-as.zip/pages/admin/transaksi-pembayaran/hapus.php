<?php
session_start();
require_once '../../../config/koneksi.php';

// Proteksi halaman: pastikan user sudah login dan merupakan admin1 (Bendahara)
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin1') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

// Mengecek apakah ada parameter ID yang dikirim melalui URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $pdo = getConnection();
    $id_transaksi = $_GET['id'];

    try {
        // 1. Cek dulu datanya dan ambil nama siswa & nama tagihan untuk pesan notifikasi
        // Kita gunakan JOIN agar bisa mendapatkan nama dari tabel relasinya
        $stmtCheck = $pdo->prepare("SELECT s.nama, j.nama_pembayaran 
                                    FROM transaksi_pembayaran t
                                    JOIN data_siswa s ON t.nisn = s.nisn
                                    JOIN jenis_pembayaran j ON t.id_jenis = j.id_jenis
                                    WHERE t.id_transaksi = :id");
        $stmtCheck->execute([':id' => $id_transaksi]);
        $data = $stmtCheck->fetch();

        if ($data) {
            $nama_siswa = $data['nama'];
            $nama_tagihan = $data['nama_pembayaran'];

            // 2. Jika data ada, jalankan perintah DELETE
            $stmtDelete = $pdo->prepare("DELETE FROM transaksi_pembayaran WHERE id_transaksi = :id");
            $stmtDelete->execute([':id' => $id_transaksi]);

            // Set pesan sukses yang detail
            $_SESSION['success'] = "Riwayat pembayaran <strong>" . htmlspecialchars($nama_tagihan) . "</strong> atas nama <strong>" . htmlspecialchars($nama_siswa) . "</strong> berhasil dihapus dari sistem.";
        } else {
            // Jika data tidak ditemukan di database
            $_SESSION['error'] = "Gagal! Data transaksi tidak ditemukan.";
        }
    } catch (PDOException $e) {
        // Menangkap error sistem/database
        $_SESSION['error'] = "Terjadi kesalahan sistem saat menghapus data: " . $e->getMessage();
    }
} else {
    // Jika file diakses langsung tanpa parameter ID
    $_SESSION['error'] = "Akses tidak valid!";
}

// Redirect kembali ke halaman utama Transaksi Pembayaran
header("Location: index.php");
exit;
