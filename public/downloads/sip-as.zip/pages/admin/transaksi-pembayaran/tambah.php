<?php
session_start();
require_once '../../../config/koneksi.php';

// Proteksi halaman
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin1') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

$error = '';
$pdo = getConnection();

// 1. Ambil Data Siswa
try {
    $stmtSiswa = $pdo->query("SELECT nisn, nama FROM data_siswa ORDER BY nama ASC");
    $data_siswa = $stmtSiswa->fetchAll();
} catch (PDOException $e) {
    die("Error mengambil data siswa: " . $e->getMessage());
}

// 2. Ambil Data Jenis Pembayaran
try {
    $stmtJenis = $pdo->query("SELECT id_jenis, nama_pembayaran, nominal FROM jenis_pembayaran ORDER BY id_jenis DESC");
    $data_jenis = $stmtJenis->fetchAll();
} catch (PDOException $e) {
    die("Error mengambil data jenis pembayaran: " . $e->getMessage());
}

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tanggal_bayar = $_POST['tanggal_bayar'];
    $nisn          = $_POST['nisn'];       // Diambil dari input hidden custom dropdown
    $id_jenis      = $_POST['id_jenis'];   // Diambil dari input hidden custom dropdown
    $jumlah_bayar  = trim($_POST['jumlah_bayar']);
    $status        = $_POST['status'];

    if (empty($tanggal_bayar) || empty($nisn) || empty($id_jenis) || empty($jumlah_bayar) || empty($status)) {
        $error = "Semua kolom wajib diisi (Pastikan Siswa dan Tagihan sudah dipilih)!";
    } elseif (!is_numeric($jumlah_bayar) || $jumlah_bayar <= 0) {
        $error = "Jumlah bayar harus berupa angka dan lebih dari 0!";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO transaksi_pembayaran (tanggal_bayar, nisn, id_jenis, jumlah_bayar, status) 
                                   VALUES (:tanggal_bayar, :nisn, :id_jenis, :jumlah_bayar, :status)");
            $stmt->execute([
                ':tanggal_bayar' => $tanggal_bayar,
                ':nisn'          => $nisn,
                ':id_jenis'      => $id_jenis,
                ':jumlah_bayar'  => $jumlah_bayar,
                ':status'        => $status
            ]);

            $_SESSION['success'] = "Transaksi pembayaran berhasil dicatat!";
            header("Location: index.php");
            exit;
        } catch (PDOException $e) {
            $error = "Terjadi kesalahan sistem: " . $e->getMessage();
        }
    }
}

require_once '../../../includes/header.php';
?>

<style>
    .form-control-modern,
    .form-select-modern {
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
        padding: 0.75rem 1rem;
        border-radius: 0.5rem;
        color: #212529;
        transition: all 0.2s;
    }

    .form-control-modern:focus,
    .form-select-modern:focus {
        background-color: #ffffff;
        border-color: #4e73df;
        box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.15);
    }

    .input-group-text-modern {
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
        border-right: none;
        color: #6c757d;
        border-radius: 0.5rem 0 0 0.5rem;
        font-weight: 600;
    }

    .form-control-modern.with-icon {
        border-left: none;
        border-radius: 0 0.5rem 0.5rem 0;
    }

    /* Styling List Dropdown */
    .custom-item:hover {
        background-color: #f8f9fc;
        border-left: 4px solid #4e73df;
    }

    .custom-item {
        border-left: 4px solid transparent;
        transition: all 0.2s ease;
    }
</style>

<div class="row justify-content-center">
    <div class="col-xl-8 col-lg-10">

        <div class="mb-3">
            <a href="index.php" class="btn btn-white shadow-sm rounded-pill text-muted fw-medium border-0 px-3 py-2" style="font-size: 0.9rem;">
                <i class="bi bi-arrow-left me-2"></i> Kembali ke Data Transaksi
            </a>
        </div>

        <div class="card border-0 shadow-sm" style="border-radius: 1.2rem; overflow: hidden;">
            <div class="bg-primary bg-opacity-10 py-4 px-4 px-md-5 border-bottom border-primary border-opacity-10">
                <h5 class="fw-bold text-white mb-1">Input Pembayaran Siswa</h5>
                <p class="text-white text-opacity-75 mb-0" style="font-size: 0.85rem;">Catat transaksi penerimaan uang tagihan dari siswa dengan teliti.</p>
            </div>

            <div class="card-body p-4 p-md-5 bg-white">

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm rounded-3" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="" method="POST" id="formTransaksi">

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label for="tanggal_bayar" class="form-label fw-semibold text-dark">Tanggal Pembayaran <span class="text-danger">*</span></label>
                            <input type="date" class="form-control form-control-modern" id="tanggal_bayar" name="tanggal_bayar" value="<?= isset($_POST['tanggal_bayar']) ? $_POST['tanggal_bayar'] : date('Y-m-d') ?>" required>
                        </div>
                    </div>

                    <!-- KOTAK PENCARIAN SISWA -->
                    <div class="mb-4">
                        <label class="form-label fw-semibold text-dark">Pilih Siswa <span class="text-danger">*</span></label>
                        <input type="hidden" name="nisn" id="nisn_input">

                        <div class="dropdown">
                            <button class="form-select form-select-modern text-start d-flex justify-content-between align-items-center w-100 shadow-none" type="button" id="dropdownSiswa" data-bs-toggle="dropdown" aria-expanded="false">
                                <span id="selected_siswa_text" class="text-muted">-- Klik untuk Mencari & Memilih Siswa --</span>
                            </button>

                            <div class="dropdown-menu w-100 p-2 shadow border-0" aria-labelledby="dropdownSiswa" style="border-radius: 0.8rem; margin-top: 5px;">
                                <div class="p-1 mb-2">
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0 text-muted"><i class="bi bi-search"></i></span>
                                        <input type="text" class="form-control border-start-0 shadow-none" id="searchSiswa" placeholder="Ketik Nama atau NISN..." autocomplete="off">
                                    </div>
                                </div>
                                <ul class="list-unstyled mb-0" style="max-height: 250px; overflow-y: auto;">
                                    <?php foreach ($data_siswa as $s): ?>
                                        <li>
                                            <a class="dropdown-item rounded-2 py-2 mb-1 custom-item siswa-item" href="javascript:void(0)" data-nisn="<?= htmlspecialchars($s['nisn']) ?>" data-nama="<?= htmlspecialchars($s['nama']) ?>">
                                                <div class="fw-bold text-dark"><?= htmlspecialchars($s['nama']) ?></div>
                                                <small class="text-muted"><i class="bi bi-upc-scan me-1"></i> <?= htmlspecialchars($s['nisn']) ?></small>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>
                                    <li id="noResultSiswa" class="text-center text-muted py-3 d-none">
                                        <i class="bi bi-person-x fs-4 d-block mb-1"></i> Siswa tidak ditemukan
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- KOTAK PENCARIAN JENIS TAGIHAN -->
                    <div class="mb-4">
                        <label class="form-label fw-semibold text-dark">Pilih Jenis Tagihan <span class="text-danger">*</span></label>
                        <input type="hidden" name="id_jenis" id="id_jenis_input">

                        <div class="dropdown">
                            <button class="form-select form-select-modern text-start d-flex justify-content-between align-items-center w-100 shadow-none" type="button" id="dropdownJenis" data-bs-toggle="dropdown" aria-expanded="false">
                                <span id="selected_jenis_text" class="text-muted">-- Klik untuk Mencari & Memilih Tagihan --</span>
                            </button>

                            <div class="dropdown-menu w-100 p-2 shadow border-0" aria-labelledby="dropdownJenis" style="border-radius: 0.8rem; margin-top: 5px;">
                                <div class="p-1 mb-2">
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0 text-muted"><i class="bi bi-search"></i></span>
                                        <input type="text" class="form-control border-start-0 shadow-none" id="searchJenis" placeholder="Ketik Nama Pembayaran/Tagihan..." autocomplete="off">
                                    </div>
                                </div>
                                <ul class="list-unstyled mb-0" style="max-height: 250px; overflow-y: auto;">
                                    <?php foreach ($data_jenis as $j): ?>
                                        <li>
                                            <a class="dropdown-item rounded-2 py-2 mb-1 custom-item jenis-item" href="javascript:void(0)" data-id="<?= $j['id_jenis'] ?>" data-nama="<?= htmlspecialchars($j['nama_pembayaran']) ?>" data-nominal="<?= round($j['nominal']) ?>" data-nominal-format="Rp <?= number_format($j['nominal'], 0, ',', '.') ?>">
                                                <div class="fw-bold text-dark"><?= htmlspecialchars($j['nama_pembayaran']) ?></div>
                                                <small class="text-success fw-bold"><i class="bi bi-tag-fill me-1"></i> Rp <?= number_format($j['nominal'], 0, ',', '.') ?></small>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>
                                    <li id="noResultJenis" class="text-center text-muted py-3 d-none">
                                        <i class="bi bi-tags fs-4 d-block mb-1"></i> Tagihan tidak ditemukan
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-5">
                        <div class="col-md-6 mb-4 mb-md-0">
                            <label for="jumlah_bayar" class="form-label fw-semibold text-dark">Jumlah Uang Diterima <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text input-group-text-modern">Rp</span>
                                <input type="number" min="0" step="1000" class="form-control form-control-modern with-icon" id="jumlah_bayar" name="jumlah_bayar" placeholder="0" value="<?= isset($_POST['jumlah_bayar']) ? htmlspecialchars($_POST['jumlah_bayar']) : '' ?>" required>
                            </div>
                            <small class="text-primary d-block mt-2 fw-medium" style="font-size: 0.8rem;"><i class="bi bi-magic me-1"></i> Terisi otomatis saat tagihan dipilih.</small>
                        </div>
                        <div class="col-md-6">
                            <label for="status" class="form-label fw-semibold text-dark">Status Pembayaran <span class="text-danger">*</span></label>
                            <select class="form-select form-select-modern fw-semibold" id="status" name="status" required>
                                <option value="Lunas" <?= (isset($_POST['status']) && $_POST['status'] == 'Lunas') ? 'selected' : '' ?> class="text-success">Lunas</option>
                                <option value="Belum Lunas" <?= (isset($_POST['status']) && $_POST['status'] == 'Belum Lunas') ? 'selected' : '' ?> class="text-warning">Belum Lunas / Nyicil</option>
                            </select>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-3 pt-3 border-top">
                        <button type="reset" class="btn btn-light rounded-pill px-4 fw-medium border shadow-sm text-muted">Reset</button>
                        <button type="submit" class="btn btn-primary rounded-pill shadow-sm px-5 fw-medium">
                            <i class="bi bi-save me-1"></i> Simpan Transaksi
                        </button>
                    </div>

                </form>
            </div>
        </div>

    </div>
</div>

<?php require_once '../../../includes/footer.php'; ?>

<!-- Javascript Logic -->
<script>
    document.addEventListener("DOMContentLoaded", function() {

        // --- LOGIKA UNTUK DROPDOWN SISWA ---
        const searchSiswa = document.getElementById('searchSiswa');
        const itemSiswa = document.querySelectorAll('.siswa-item');
        const noResultSiswa = document.getElementById('noResultSiswa');
        const inputNisn = document.getElementById('nisn_input');
        const textSiswa = document.getElementById('selected_siswa_text');

        searchSiswa.addEventListener('click', e => e.stopPropagation());

        searchSiswa.addEventListener('keyup', function() {
            let filter = this.value.toLowerCase();
            let visibleCount = 0;
            itemSiswa.forEach(item => {
                let textData = item.getAttribute('data-nama').toLowerCase() + " " + item.getAttribute('data-nisn').toLowerCase();
                if (textData.includes(filter)) {
                    item.parentElement.style.display = '';
                    visibleCount++;
                } else {
                    item.parentElement.style.display = 'none';
                }
            });
            visibleCount === 0 ? noResultSiswa.classList.remove('d-none') : noResultSiswa.classList.add('d-none');
        });

        itemSiswa.forEach(item => {
            item.addEventListener('click', function() {
                inputNisn.value = this.getAttribute('data-nisn');
                textSiswa.innerHTML = `<span class="text-dark fw-bold">${this.getAttribute('data-nama')}</span> <small class="text-muted ms-1">(NISN: ${this.getAttribute('data-nisn')})</small>`;
            });
        });

        document.getElementById('dropdownSiswa').addEventListener('shown.bs.dropdown', () => searchSiswa.focus());


        // --- LOGIKA UNTUK DROPDOWN JENIS TAGIHAN ---
        const searchJenis = document.getElementById('searchJenis');
        const itemJenis = document.querySelectorAll('.jenis-item');
        const noResultJenis = document.getElementById('noResultJenis');
        const inputJenisId = document.getElementById('id_jenis_input');
        const textJenis = document.getElementById('selected_jenis_text');
        const inputJumlahBayar = document.getElementById('jumlah_bayar'); // Input nominal
        const inputStatus = document.getElementById('status');

        searchJenis.addEventListener('click', e => e.stopPropagation());

        searchJenis.addEventListener('keyup', function() {
            let filter = this.value.toLowerCase();
            let visibleCount = 0;
            itemJenis.forEach(item => {
                let textData = item.getAttribute('data-nama').toLowerCase();
                if (textData.includes(filter)) {
                    item.parentElement.style.display = '';
                    visibleCount++;
                } else {
                    item.parentElement.style.display = 'none';
                }
            });
            visibleCount === 0 ? noResultJenis.classList.remove('d-none') : noResultJenis.classList.add('d-none');
        });

        itemJenis.forEach(item => {
            item.addEventListener('click', function() {
                // Set ID tagihan ke hidden input
                inputJenisId.value = this.getAttribute('data-id');
                // Ganti teks pada tombol
                textJenis.innerHTML = `<span class="text-dark fw-bold">${this.getAttribute('data-nama')}</span> <small class="text-success ms-1 fw-bold">(${this.getAttribute('data-nominal-format')})</small>`;

                // FITUR AJAIB: Otomatis isi nominal pembayaran sesuai harga tagihan!
                inputJumlahBayar.value = this.getAttribute('data-nominal');

                // Pastikan status kembali ke Lunas (jika bayar pas)
                inputStatus.value = 'Lunas';
            });
        });

        document.getElementById('dropdownJenis').addEventListener('shown.bs.dropdown', () => searchJenis.focus());


        // --- VALIDASI FORM SAAT SUBMIT ---
        document.getElementById('formTransaksi').addEventListener('submit', function(e) {
            if (!inputNisn.value) {
                e.preventDefault();
                alert('PERINGATAN: Anda belum memilih Siswa!');
                document.getElementById('dropdownSiswa').click();
                return;
            }
            if (!inputJenisId.value) {
                e.preventDefault();
                alert('PERINGATAN: Anda belum memilih Jenis Tagihan!');
                document.getElementById('dropdownJenis').click();
                return;
            }
        });
    });
</script>