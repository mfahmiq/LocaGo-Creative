<?php
session_start();
require_once '../../../config/koneksi.php';

// Pastikan user sudah login dan merupakan admin1 (Bendahara)
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin1') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

require_once '../../../includes/header.php';

$pdo = getConnection();

// --- LOGIKA PENCARIAN, FILTER & PAGINATION ---
$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$search = isset($_GET['cari']) ? trim($_GET['cari']) : '';
$filter_status = isset($_GET['status']) ? $_GET['status'] : '';

// Menggunakan trik "WHERE 1=1" agar mudah menambahkan kondisi AND secara dinamis
$searchQuery = " WHERE 1=1 ";
$params = [];

if (!empty($search)) {
    $searchQuery .= " AND (s.nama LIKE :search1 OR s.nisn LIKE :search2) ";
    $params[':search1'] = "%$search%";
    $params[':search2'] = "%$search%";
}

if (in_array($filter_status, ['Lunas', 'Belum Lunas'])) {
    $searchQuery .= " AND t.status = :status ";
    $params[':status'] = $filter_status;
}

// Buat string URL untuk mempertahankan status filter saat pindah halaman (Pagination)
$queryString = '';
if (!empty($search)) $queryString .= '&cari=' . urlencode($search);
if (!empty($filter_status)) $queryString .= '&status=' . urlencode($filter_status);

try {
    // 1. Hitung total data
    $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM transaksi_pembayaran t 
                                JOIN data_siswa s ON t.nisn = s.nisn" . $searchQuery);
    $stmtCount->execute($params);
    $total_data = $stmtCount->fetchColumn();
    $total_pages = ceil($total_data / $limit);

    // 2. Ambil data transaksi
    $sql = "SELECT t.*, s.nama, j.nama_pembayaran, j.nominal 
            FROM transaksi_pembayaran t
            JOIN data_siswa s ON t.nisn = s.nisn
            JOIN jenis_pembayaran j ON t.id_jenis = j.id_jenis
            $searchQuery
            ORDER BY t.tanggal_bayar DESC, t.id_transaksi DESC 
            LIMIT $limit OFFSET $offset";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $data_transaksi = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error mengambil data transaksi: " . $e->getMessage());
}
?>

<style>
    .table-responsive {
        padding-bottom: 100px;
    }

    @media (min-width: 768px) {
        .table-responsive {
            overflow: visible !important;
        }
    }
</style>

<div class="row mb-4 align-items-center">
    <div class="col-md-4">
        <h4 class="mb-0 fw-bold text-dark">Data Transaksi</h4>
        <p class="text-muted mb-0" style="font-size: 0.9rem;">Kelola pencatatan pembayaran siswa</p>
    </div>
    <div class="col-md-8 d-flex flex-wrap justify-content-md-end align-items-center gap-2 mt-3 mt-md-0">
        <!-- TABS FILTER STATUS -->
        <div class="bg-white rounded-pill p-1 shadow-sm border" style="font-size: 0.9rem;">
            <a href="index.php<?= !empty($search) ? '?cari=' . urlencode($search) : '' ?>" class="btn rounded-pill px-3 py-1 fw-medium <?= empty($filter_status) ? 'btn-primary' : 'btn-white text-muted' ?>">Semua</a>
            <a href="index.php?status=Belum Lunas<?= !empty($search) ? '&cari=' . urlencode($search) : '' ?>" class="btn rounded-pill px-3 py-1 fw-medium <?= $filter_status == 'Belum Lunas' ? 'btn-warning text-dark' : 'btn-white text-warning' ?>"><i class="bi bi-clock-history me-1"></i> Belum Lunas</a>
            <a href="index.php?status=Lunas<?= !empty($search) ? '&cari=' . urlencode($search) : '' ?>" class="btn rounded-pill px-3 py-1 fw-medium <?= $filter_status == 'Lunas' ? 'btn-success' : 'btn-white text-success' ?>"><i class="bi bi-check-circle me-1"></i> Lunas</a>
        </div>

        <!-- FORM CARI -->
        <form method="GET" action="index.php" class="d-flex" style="max-width: 250px;">
            <?php if (!empty($filter_status)): ?>
                <input type="hidden" name="status" value="<?= htmlspecialchars($filter_status) ?>">
            <?php endif; ?>
            <div class="input-group shadow-sm" style="border-radius: 50rem;">
                <input type="text" name="cari" class="form-control border-end-0 bg-white py-1" style="border-radius: 50rem 0 0 50rem; padding-left: 1.2rem; font-size: 0.9rem;" placeholder="Cari nama / NISN..." value="<?= htmlspecialchars($search) ?>">
                <button class="btn btn-white border border-start-0 bg-white py-1" type="submit" style="border-radius: 0 50rem 50rem 0; padding-right: 1.2rem;">
                    <i class="bi bi-search text-primary" style="font-size: 0.9rem;"></i>
                </button>
            </div>
        </form>

        <!-- TOMBOL TAMBAH -->
        <a href="tambah.php" class="btn btn-primary rounded-pill shadow-sm px-3 py-1 flex-shrink-0" style="font-size: 0.9rem;">
            <i class="bi bi-plus-lg me-1"></i> Input Pembayaran
        </a>
    </div>
</div>

<?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm rounded-3" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i> <?= $_SESSION['success'] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm rounded-3" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $_SESSION['error'] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<div class="card border-0 shadow-sm" style="border-radius: 1rem;">
    <div class="card-body p-4">

        <?php if (!empty($search)): ?>
            <div class="mb-3">
                <span class="text-muted">Hasil pencarian untuk: <strong>"<?= htmlspecialchars($search) ?>"</strong></span>
                <a href="index.php<?= !empty($filter_status) ? '?status=' . urlencode($filter_status) : '' ?>" class="text-decoration-none ms-2 badge bg-secondary bg-opacity-10 text-white">Reset Pencarian</a>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="text-center rounded-start" width="5%">No</th>
                        <th width="15%">Tanggal</th>
                        <th width="20%">Siswa</th>
                        <th width="25%">Pembayaran</th>
                        <th width="15%">Jumlah Bayar</th>
                        <th class="text-center" width="10%">Status</th>
                        <th class="text-center rounded-end" width="10%">Aksi</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <?php if (count($data_transaksi) > 0): ?>
                        <?php
                        $no = $offset + 1;
                        foreach ($data_transaksi as $row):
                        ?>
                            <tr>
                                <td class="text-center text-muted"><?= $no++ ?></td>
                                <td>
                                    <div class="text-dark fw-medium"><?= date('d M Y', strtotime($row['tanggal_bayar'])) ?></div>
                                </td>
                                <td>
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($row['nama']) ?></div>
                                    <small class="text-muted">NISN: <?= htmlspecialchars($row['nisn']) ?></small>
                                </td>
                                <td>
                                    <div class="text-dark"><?= htmlspecialchars($row['nama_pembayaran']) ?></div>
                                    <small class="text-muted">Tagihan: Rp <?= number_format($row['nominal'], 0, ',', '.') ?></small>
                                </td>
                                <td>
                                    <span class="fw-semibold text-dark">Rp <?= number_format($row['jumlah_bayar'], 0, ',', '.') ?></span>
                                </td>
                                <td class="text-center">
                                    <?php if ($row['status'] === 'Lunas'): ?>
                                        <span class="badge bg-success bg-opacity-10 text-white px-3 py-2 rounded-pill"><i class="bi bi-check-circle me-1"></i> Lunas</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning bg-opacity-10 text-white px-3 py-2 rounded-pill"><i class="bi bi-clock-history me-1"></i> Belum Lunas</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <div class="dropdown">
                                        <button class="btn btn-light btn-sm shadow-sm rounded-3 text-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Opsi
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end shadow border-0" style="font-size: 0.9rem;">
                                            <li><a class="dropdown-item py-2" href="cetak-kwitansi.php?id=<?= $row['id_transaksi'] ?>" target="_blank"><i class="bi bi-printer text-secondary me-2"></i> Cetak Kuitansi</a></li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li><a class="dropdown-item py-2" href="edit.php?id=<?= $row['id_transaksi'] ?>"><i class="bi bi-pencil-square text-primary me-2"></i> Edit Data</a></li>
                                            <li><a class="dropdown-item py-2 text-danger fw-medium" href="hapus.php?id=<?= $row['id_transaksi'] ?>" onclick="return confirm('Yakin ingin menghapus riwayat transaksi ini?')"><i class="bi bi-trash text-danger me-2"></i> Hapus</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center py-5">
                                <div class="text-muted">
                                    <i class="bi bi-wallet2 fs-1 d-block mb-3"></i>
                                    <p class="mb-0">Tidak ada riwayat transaksi yang ditemukan.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center mb-0">
                    <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                        <a class="page-link rounded-start-pill px-3" href="?page=<?= $page - 1 ?><?= $queryString ?>"><i class="bi bi-chevron-left"></i></a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= ($page == $i) ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?><?= $queryString ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= ($page >= $total_pages) ? 'disabled' : '' ?>">
                        <a class="page-link rounded-end-pill px-3" href="?page=<?= $page + 1 ?><?= $queryString ?>"><i class="bi bi-chevron-right"></i></a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>

    </div>
</div>

<?php require_once '../../../includes/footer.php'; ?>