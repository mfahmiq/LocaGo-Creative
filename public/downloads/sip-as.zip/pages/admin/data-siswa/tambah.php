<?php
session_start();
require_once '../../../config/koneksi.php';

// Proteksi halaman
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin1') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

$error = '';

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nisn          = trim($_POST['nisn']);
    $nama          = trim($_POST['nama']);
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $tempat_lahir  = trim($_POST['tempat_lahir']);
    $tanggal_lahir = $_POST['tanggal_lahir'];

    if (empty($nisn) || empty($nama) || empty($jenis_kelamin) || empty($tempat_lahir) || empty($tanggal_lahir)) {
        $error = "Semua kolom wajib diisi!";
    } else {
        $pdo = getConnection();
        try {
            $stmtCheck = $pdo->prepare("SELECT nisn FROM data_siswa WHERE nisn = :nisn");
            $stmtCheck->execute([':nisn' => $nisn]);

            if ($stmtCheck->rowCount() > 0) {
                $error = "Gagal! NISN <strong>$nisn</strong> sudah terdaftar di sistem.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO data_siswa (nisn, nama, jenis_kelamin, tempat_lahir, tanggal_lahir) 
                                       VALUES (:nisn, :nama, :jenis_kelamin, :tempat_lahir, :tanggal_lahir)");
                $stmt->execute([
                    ':nisn'          => $nisn,
                    ':nama'          => $nama,
                    ':jenis_kelamin' => $jenis_kelamin,
                    ':tempat_lahir'  => $tempat_lahir,
                    ':tanggal_lahir' => $tanggal_lahir
                ]);

                $_SESSION['success'] = "Data siswa <strong>$nama</strong> berhasil ditambahkan!";
                header("Location: index.php");
                exit;
            }
        } catch (PDOException $e) {
            $error = "Terjadi kesalahan sistem: " . $e->getMessage();
        }
    }
}

require_once '../../../includes/header.php';
?>

<style>
    /* Custom Styling untuk Form Input Modern */
    .form-control-modern {
        background-color: #f8f9fa;
        border: 1px solid #e9ecef;
        padding: 0.75rem 1rem;
        border-radius: 0.5rem;
        transition: all 0.2s;
    }

    .form-control-modern:focus {
        background-color: #ffffff;
        border-color: #4e73df;
        box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.1);
    }

    .input-group-text-modern {
        background-color: #f8f9fa;
        border: 1px solid #e9ecef;
        border-right: none;
        color: #858796;
        border-radius: 0.5rem 0 0 0.5rem;
    }

    .form-control-modern.with-icon {
        border-left: none;
        border-radius: 0 0.5rem 0.5rem 0;
    }
</style>

<div class="row justify-content-center">
    <div class="col-xl-8 col-lg-10">

        <!-- Tombol Kembali (Di atas Card) -->
        <div class="mb-3">
            <a href="index.php" class="btn btn-white shadow-sm rounded-pill text-muted fw-medium border-0 px-3 py-2" style="font-size: 0.9rem;">
                <i class="bi bi-arrow-left me-2"></i> Kembali ke Daftar Siswa
            </a>
        </div>

        <!-- Card Form -->
        <div class="card border-0 shadow-sm" style="border-radius: 1.2rem; overflow: hidden;">
            <!-- Header Aksen Biru Halus -->
            <div class="bg-primary bg-opacity-10 py-4 px-4 px-md-5 border-bottom border-primary border-opacity-10">
                <h5 class="fw-bold text-white mb-1">Tambah Data Siswa</h5>
                <p class="text-white text-opacity-75 mb-0" style="font-size: 0.85rem;">Pastikan data yang diinputkan valid dan sesuai dengan dokumen resmi siswa.</p>
            </div>

            <div class="card-body p-4 p-md-5">

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm rounded-3" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="" method="POST">

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label for="nisn" class="form-label fw-semibold text-dark">NISN <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text input-group-text-modern"><i class="bi bi-upc-scan"></i></span>
                                <input type="text" pattern="[0-9]+" title="Hanya boleh berisi angka" class="form-control form-control-modern with-icon" id="nisn" name="nisn" placeholder="Nomor Induk Siswa Nasional" value="<?= isset($_POST['nisn']) ? htmlspecialchars($_POST['nisn']) : '' ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="nama" class="form-label fw-semibold text-dark">Nama Lengkap <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text input-group-text-modern"><i class="bi bi-person"></i></span>
                            <input type="text" class="form-control form-control-modern with-icon" id="nama" name="nama" placeholder="Sesuai Akta Kelahiran" value="<?= isset($_POST['nama']) ? htmlspecialchars($_POST['nama']) : '' ?>" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold text-dark d-block mb-3">Jenis Kelamin <span class="text-danger">*</span></label>
                        <div class="d-flex gap-3">
                            <!-- Toggle Button Modern untuk Laki-laki -->
                            <input type="radio" class="btn-check" name="jenis_kelamin" id="jk_l" value="L" <?= (isset($_POST['jenis_kelamin']) && $_POST['jenis_kelamin'] == 'L') ? 'checked' : '' ?> required>
                            <label class="btn btn-outline-primary px-4 py-2 rounded-3 w-100 fw-medium" for="jk_l">
                                <i class="bi bi-gender-male me-2"></i> Laki-laki
                            </label>

                            <!-- Toggle Button Modern untuk Perempuan -->
                            <input type="radio" class="btn-check" name="jenis_kelamin" id="jk_p" value="P" <?= (isset($_POST['jenis_kelamin']) && $_POST['jenis_kelamin'] == 'P') ? 'checked' : '' ?> required>
                            <label class="btn btn-outline-danger px-4 py-2 rounded-3 w-100 fw-medium" for="jk_p">
                                <i class="bi bi-gender-female me-2"></i> Perempuan
                            </label>
                        </div>
                    </div>

                    <div class="row mb-5">
                        <div class="col-md-6 mb-4 mb-md-0">
                            <label for="tempat_lahir" class="form-label fw-semibold text-dark">Tempat Lahir <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text input-group-text-modern"><i class="bi bi-geo-alt"></i></span>
                                <input type="text" class="form-control form-control-modern with-icon" id="tempat_lahir" name="tempat_lahir" placeholder="Kota Kelahiran" value="<?= isset($_POST['tempat_lahir']) ? htmlspecialchars($_POST['tempat_lahir']) : '' ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="tanggal_lahir" class="form-label fw-semibold text-dark">Tanggal Lahir <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text input-group-text-modern"><i class="bi bi-calendar-event"></i></span>
                                <input type="date" class="form-control form-control-modern with-icon" id="tanggal_lahir" name="tanggal_lahir" value="<?= isset($_POST['tanggal_lahir']) ? $_POST['tanggal_lahir'] : '' ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-3 pt-3 border-top">
                        <button type="reset" class="btn btn-light rounded-pill px-4 fw-medium border shadow-sm">Reset</button>
                        <button type="submit" class="btn btn-primary rounded-pill shadow-sm px-5 fw-medium">
                            <i class="bi bi-check-circle me-1"></i> Simpan Data Siswa
                        </button>
                    </div>

                </form>
            </div>
        </div>

    </div>
</div>

<?php require_once '../../../includes/footer.php'; ?>