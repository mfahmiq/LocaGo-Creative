<?php
session_start();
require_once '../../../config/koneksi.php';

// Proteksi halaman
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin1') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

$error = '';
$pdo = getConnection();

// Cek apakah ada parameter NISN di URL (Ini adalah NISN LAMA)
if (!isset($_GET['nisn']) || empty($_GET['nisn'])) {
    $_SESSION['error'] = "Data siswa tidak ditemukan!";
    header("Location: index.php");
    exit;
}

$nisn_lama = $_GET['nisn'];

// Tarik data siswa berdasarkan NISN Lama
try {
    $stmt = $pdo->prepare("SELECT * FROM data_siswa WHERE nisn = :nisn");
    $stmt->execute([':nisn' => $nisn_lama]);
    $siswa = $stmt->fetch();

    if (!$siswa) {
        $_SESSION['error'] = "Data siswa tidak ditemukan!";
        header("Location: index.php");
        exit;
    }
} catch (PDOException $e) {
    die("Error mengambil data: " . $e->getMessage());
}

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nisn_baru     = trim($_POST['nisn']);
    $nama          = trim($_POST['nama']);
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $tempat_lahir  = trim($_POST['tempat_lahir']);
    $tanggal_lahir = $_POST['tanggal_lahir'];

    // Validasi input kosong
    if (empty($nisn_baru) || empty($nama) || empty($jenis_kelamin) || empty($tempat_lahir) || empty($tanggal_lahir)) {
        $error = "Semua kolom wajib diisi!";
    } else {
        try {
            // Cek apakah NISN baru sudah dipakai orang lain
            if ($nisn_baru !== $nisn_lama) {
                $cekNisn = $pdo->prepare("SELECT nisn FROM data_siswa WHERE nisn = :nisn");
                $cekNisn->execute([':nisn' => $nisn_baru]);

                if ($cekNisn->rowCount() > 0) {
                    $error = "Gagal Update! NISN <strong>$nisn_baru</strong> sudah terdaftar milik siswa lain.";
                }
            }

            // Jika tidak ada error, jalankan UPDATE
            if (empty($error)) {
                $stmtUpdate = $pdo->prepare("UPDATE data_siswa SET 
                                                nisn = :nisn_baru,
                                                nama = :nama, 
                                                jenis_kelamin = :jenis_kelamin, 
                                                tempat_lahir = :tempat_lahir, 
                                                tanggal_lahir = :tanggal_lahir 
                                             WHERE nisn = :nisn_lama");

                $stmtUpdate->execute([
                    ':nisn_baru'     => $nisn_baru,
                    ':nama'          => $nama,
                    ':jenis_kelamin' => $jenis_kelamin,
                    ':tempat_lahir'  => $tempat_lahir,
                    ':tanggal_lahir' => $tanggal_lahir,
                    ':nisn_lama'     => $nisn_lama
                ]);

                $_SESSION['success'] = "Data siswa <strong>$nama</strong> berhasil diperbarui!";
                header("Location: index.php");
                exit;
            }
        } catch (PDOException $e) {
            $error = "Terjadi kesalahan saat mengupdate data: " . $e->getMessage();
        }
    }
}

require_once '../../../includes/header.php';
?>

<style>
    .form-control-modern {
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
        padding: 0.75rem 1rem;
        border-radius: 0.5rem;
        color: #212529;
        transition: all 0.2s;
    }

    .form-control-modern:focus {
        background-color: #ffffff;
        border-color: #4e73df;
        box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.15);
    }

    .input-group-text-modern {
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
        border-right: none;
        color: #6c757d;
        border-radius: 0.5rem 0 0 0.5rem;
    }

    .form-control-modern.with-icon {
        border-left: none;
        border-radius: 0 0.5rem 0.5rem 0;
    }
</style>

<div class="row justify-content-center">
    <div class="col-xl-8 col-lg-10">

        <div class="mb-3">
            <a href="index.php" class="btn btn-white shadow-sm rounded-pill text-muted fw-medium border-0 px-3 py-2" style="font-size: 0.9rem;">
                <i class="bi bi-arrow-left me-2"></i> Kembali ke Daftar Siswa
            </a>
        </div>

        <div class="card border-0 shadow-sm" style="border-radius: 1.2rem; overflow: hidden;">
            <!-- Menggunakan skema warna biru lembut yang sama dengan tambah.php -->
            <div class="bg-primary bg-opacity-10 py-4 px-4 px-md-5 border-bottom border-primary border-opacity-10">
                <h5 class="fw-bold text-white mb-1">Edit Data Siswa</h5>
                <p class="text-white text-opacity-75 mb-0" style="font-size: 0.85rem;">Anda sedang mengubah data milik siswa: <strong class="text-white"><?= htmlspecialchars($siswa['nama']) ?></strong>.</p>
            </div>

            <div class="card-body p-4 p-md-5 bg-white">

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm rounded-3" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="" method="POST">

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <label for="nisn" class="form-label fw-semibold text-dark">NISN <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text input-group-text-modern"><i class="bi bi-upc-scan"></i></span>
                                <input type="text" pattern="[0-9]+" title="Hanya boleh berisi angka" class="form-control form-control-modern with-icon" id="nisn" name="nisn" value="<?= isset($_POST['nisn']) ? htmlspecialchars($_POST['nisn']) : htmlspecialchars($siswa['nisn']) ?>" required>
                            </div>
                            <small class="text-primary d-block mt-2" style="font-size: 0.8rem;"><i class="bi bi-info-circle me-1"></i> Jika diubah, data transaksi siswa ini otomatis menyesuaikan.</small>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="nama" class="form-label fw-semibold text-dark">Nama Lengkap <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <span class="input-group-text input-group-text-modern"><i class="bi bi-person"></i></span>
                            <input type="text" class="form-control form-control-modern with-icon" id="nama" name="nama" value="<?= isset($_POST['nama']) ? htmlspecialchars($_POST['nama']) : htmlspecialchars($siswa['nama']) ?>" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold text-dark d-block mb-3">Jenis Kelamin <span class="text-danger">*</span></label>
                        <div class="d-flex gap-3">
                            <?php $jk_val = isset($_POST['jenis_kelamin']) ? $_POST['jenis_kelamin'] : $siswa['jenis_kelamin']; ?>
                            <input type="radio" class="btn-check" name="jenis_kelamin" id="jk_l" value="L" <?= ($jk_val == 'L') ? 'checked' : '' ?> required>
                            <label class="btn btn-outline-primary px-4 py-2 rounded-3 w-100 fw-medium" for="jk_l">
                                <i class="bi bi-gender-male me-2"></i> Laki-laki
                            </label>

                            <input type="radio" class="btn-check" name="jenis_kelamin" id="jk_p" value="P" <?= ($jk_val == 'P') ? 'checked' : '' ?> required>
                            <label class="btn btn-outline-danger px-4 py-2 rounded-3 w-100 fw-medium" for="jk_p">
                                <i class="bi bi-gender-female me-2"></i> Perempuan
                            </label>
                        </div>
                    </div>

                    <div class="row mb-5">
                        <div class="col-md-6 mb-4 mb-md-0">
                            <label for="tempat_lahir" class="form-label fw-semibold text-dark">Tempat Lahir <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text input-group-text-modern"><i class="bi bi-geo-alt"></i></span>
                                <input type="text" class="form-control form-control-modern with-icon" id="tempat_lahir" name="tempat_lahir" value="<?= isset($_POST['tempat_lahir']) ? htmlspecialchars($_POST['tempat_lahir']) : htmlspecialchars($siswa['tempat_lahir']) ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="tanggal_lahir" class="form-label fw-semibold text-dark">Tanggal Lahir <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text input-group-text-modern"><i class="bi bi-calendar-event"></i></span>
                                <input type="date" class="form-control form-control-modern with-icon" id="tanggal_lahir" name="tanggal_lahir" value="<?= isset($_POST['tanggal_lahir']) ? $_POST['tanggal_lahir'] : $siswa['tanggal_lahir'] ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end gap-3 pt-3 border-top">
                        <a href="edit.php?nisn=<?= urlencode($siswa['nisn']) ?>" class="btn btn-light rounded-pill px-4 fw-medium border shadow-sm text-muted">Reset</a>
                        <!-- Menggunakan tombol primary agar senada -->
                        <button type="submit" class="btn btn-primary rounded-pill shadow-sm px-5 fw-medium">
                            <i class="bi bi-pencil-square me-1"></i> Update Data
                        </button>
                    </div>

                </form>
            </div>
        </div>

    </div>
</div>

<?php require_once '../../../includes/footer.php'; ?>