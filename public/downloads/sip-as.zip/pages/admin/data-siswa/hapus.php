<?php
session_start();
require_once '../../../config/koneksi.php';

// Proteksi halaman: pastikan user sudah login dan merupakan admin1 (Bendahara)
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin1') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

// Mengecek apakah ada parameter NISN yang dikirim melalui URL
if (isset($_GET['nisn']) && !empty($_GET['nisn'])) {
    $pdo = getConnection();
    $nisn = $_GET['nisn'];

    try {
        // 1. Cek dulu apakah data siswanya ada di database, sekaligus mengambil namanya untuk pesan notifikasi
        $stmtCheck = $pdo->prepare("SELECT nama FROM data_siswa WHERE nisn = :nisn");
        $stmtCheck->execute([':nisn' => $nisn]);
        $siswa = $stmtCheck->fetch();

        if ($siswa) {
            $nama_siswa = $siswa['nama'];

            // 2. Jika data ada, jalankan perintah DELETE
            $stmtDelete = $pdo->prepare("DELETE FROM data_siswa WHERE nisn = :nisn");
            $stmtDelete->execute([':nisn' => $nisn]);

            // Set pesan sukses
            $_SESSION['success'] = "Data siswa <strong>" . htmlspecialchars($nama_siswa) . "</strong> berhasil dihapus permanen.";
        } else {
            // Jika data tidak ditemukan di database
            $_SESSION['error'] = "Gagal! Data siswa tidak ditemukan.";
        }
    } catch (PDOException $e) {
        // Menangkap error sistem/database
        $_SESSION['error'] = "Terjadi kesalahan sistem saat menghapus data: " . $e->getMessage();
    }
} else {
    // Jika file diakses langsung tanpa parameter NISN
    $_SESSION['error'] = "Akses tidak valid!";
}

// Redirect kembali ke halaman utama Data Siswa
header("Location: index.php");
exit;
