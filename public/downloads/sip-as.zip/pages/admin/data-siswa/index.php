<?php
session_start();
require_once '../../../config/koneksi.php';

// Pastikan user sudah login dan merupakan admin1 (Bendahara)
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin1') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

require_once '../../../includes/header.php';

$pdo = getConnection();

// --- LOGIKA PENCARIAN & PAGINATION ---
$limit = 5; // Menampilkan 5 data per halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$search = isset($_GET['cari']) ? trim($_GET['cari']) : '';
$searchQuery = '';
$params = [];

// Jika ada inputan pencarian
if (!empty($search)) {
    $searchQuery = " WHERE nama LIKE :search_nama OR nisn LIKE :search_nisn ";
    $params[':search_nama'] = "%$search%";
    $params[':search_nisn'] = "%$search%";
}

try {
    // 1. Hitung total data untuk mengetahui jumlah halaman
    $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM data_siswa" . $searchQuery);
    $stmtCount->execute($params);
    $total_data = $stmtCount->fetchColumn();
    $total_pages = ceil($total_data / $limit);

    // 2. Ambil data sesuai halaman dan filter pencarian
    $stmt = $pdo->prepare("SELECT * FROM data_siswa" . $searchQuery . " ORDER BY nisn DESC LIMIT $limit OFFSET $offset");
    $stmt->execute($params);
    $data_siswa = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error mengambil data: " . $e->getMessage());
}
?>

<!-- Header Halaman & Form Pencarian -->
<div class="row mb-4 align-items-center">
    <div class="col-md-5">
        <h4 class="mb-0 fw-bold text-dark">Data Siswa</h4>
        <p class="text-muted mb-0" style="font-size: 0.9rem;">Kelola informasi data siswa terdaftar</p>
    </div>
    <div class="col-md-7 d-flex justify-content-md-end align-items-center gap-2 mt-3 mt-md-0">
        <!-- Form Cari -->
        <form method="GET" action="" class="d-flex w-100" style="max-width: 300px;">
            <div class="input-group shadow-sm" style="border-radius: 50rem;">
                <input type="text" name="cari" class="form-control border-end-0 bg-white" style="border-radius: 50rem 0 0 50rem; padding-left: 1.2rem;" placeholder="Cari NISN atau Nama..." value="<?= htmlspecialchars($search) ?>">
                <button class="btn btn-white border border-start-0 bg-white" type="submit" style="border-radius: 0 50rem 50rem 0; padding-right: 1.2rem;">
                    <i class="bi bi-search text-primary"></i>
                </button>
            </div>
        </form>
        <!-- Tombol Tambah -->
        <a href="tambah.php" class="btn btn-primary rounded-pill shadow-sm px-4 flex-shrink-0">
            <i class="bi bi-plus-lg me-1"></i> Tambah Siswa
        </a>
    </div>
</div>

<!-- Menampilkan Notifikasi (Tetap dipertahankan) -->
<?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm rounded-3" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i> <?= $_SESSION['success'] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>

<!-- Card Tabel Data Siswa -->
<div class="card border-0 shadow-sm" style="border-radius: 1rem;">
    <div class="card-body p-4">

        <?php if (!empty($search)): ?>
            <div class="mb-3">
                <span class="text-muted">Hasil pencarian untuk: <strong>"<?= htmlspecialchars($search) ?>"</strong></span>
                <a href="index.php" class="text-decoration-none ms-2 badge bg-secondary bg-opacity-10 text-white">Reset Pencarian</a>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="text-center rounded-start" width="5%">No</th>
                        <th width="15%">NISN</th>
                        <th>Nama Lengkap</th>
                        <th class="text-center" width="15%">J. Kelamin</th>
                        <th width="20%">Tempat, Tgl Lahir</th>
                        <th class="text-center rounded-end" width="12%">Aksi</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <?php if (count($data_siswa) > 0): ?>
                        <?php
                        // Nomor urut menyesuaikan offset halaman
                        $no = $offset + 1;
                        foreach ($data_siswa as $row):
                        ?>
                            <tr>
                                <td class="text-center text-muted"><?= $no++ ?></td>
                                <td class="fw-semibold text-dark"><?= htmlspecialchars($row['nisn']) ?></td>
                                <td>
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($row['nama']) ?></div>
                                </td>
                                <td class="text-center">
                                    <?php if ($row['jenis_kelamin'] === 'L'): ?>
                                        <span class="badge bg-primary bg-opacity-10 text-white px-3 py-2 rounded-pill">Laki-laki</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger bg-opacity-10 text-white px-3 py-2 rounded-pill">Perempuan</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="text-dark"><?= htmlspecialchars($row['tempat_lahir']) ?></div>
                                    <small class="text-muted"><?= date('d M Y', strtotime($row['tanggal_lahir'])) ?></small>
                                </td>
                                <td class="text-center">
                                    <a href="edit.php?nisn=<?= urlencode($row['nisn']) ?>" class="btn btn-light btn-sm text-primary shadow-sm rounded-3 me-1" title="Edit Data">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>
                                    <a href="hapus.php?nisn=<?= urlencode($row['nisn']) ?>" class="btn btn-light btn-sm text-danger shadow-sm rounded-3" title="Hapus Data" onclick="return confirm('Apakah Anda yakin ingin menghapus data siswa bernama <?= htmlspecialchars($row['nama']) ?>?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center py-5">
                                <div class="text-muted">
                                    <i class="bi bi-search fs-1 d-block mb-3"></i>
                                    <p class="mb-0">Data siswa tidak ditemukan.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Tampilan Pagination -->
        <?php if ($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center mb-0">

                    <!-- Tombol Sebelumnya -->
                    <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                        <a class="page-link rounded-start-pill px-3" href="?page=<?= $page - 1 ?><?= !empty($search) ? '&cari=' . urlencode($search) : '' ?>">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                    </li>

                    <!-- Nomor Halaman -->
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= ($page == $i) ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?><?= !empty($search) ? '&cari=' . urlencode($search) : '' ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>

                    <!-- Tombol Selanjutnya -->
                    <li class="page-item <?= ($page >= $total_pages) ? 'disabled' : '' ?>">
                        <a class="page-link rounded-end-pill px-3" href="?page=<?= $page + 1 ?><?= !empty($search) ? '&cari=' . urlencode($search) : '' ?>">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                    </li>

                </ul>
            </nav>
        <?php endif; ?>

    </div>
</div>

<?php require_once '../../../includes/footer.php'; ?>