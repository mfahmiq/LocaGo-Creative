<?php
session_start();
require_once '../../../config/koneksi.php';
require_once '../../../vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

// 1. PROTEKSI HALAMAN
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin1') {
    die("Akses ditolak!");
}

// 2. VALIDASI PARAMETER
$id_jenis      = isset($_GET['id_jenis']) ? $_GET['id_jenis'] : '';
$jenis_laporan = isset($_GET['jenis_laporan']) ? $_GET['jenis_laporan'] : '';
$tgl_awal      = isset($_GET['tgl_awal']) ? $_GET['tgl_awal'] : '';
$tgl_akhir     = isset($_GET['tgl_akhir']) ? $_GET['tgl_akhir'] : '';

if (empty($jenis_laporan) || empty($tgl_awal) || empty($tgl_akhir)) {
    die("Parameter laporan tidak lengkap!");
}

$pdo = getConnection();

try {
    $stmtProfil = $pdo->query("SELECT * FROM profil_sekolah LIMIT 1");
    $profil = $stmtProfil->fetch();

    // 3. SUSUN LOGIKA FILTER & NAMA LAPORAN
    $where_clause = "";
    $params = [':awal' => $tgl_awal, ':akhir' => $tgl_akhir];
    $nama_pembayaran_teks = "Semua Jenis Pembayaran";

    // Jika user memilih jenis pembayaran spesifik
    if (!empty($id_jenis)) {
        $where_clause .= " AND t.id_jenis = :id_jenis ";
        $params[':id_jenis'] = $id_jenis;

        // Cari tahu nama pembayarannya untuk judul
        $stmtNama = $pdo->prepare("SELECT nama_pembayaran FROM jenis_pembayaran WHERE id_jenis = :id");
        $stmtNama->execute([':id' => $id_jenis]);
        $nama_pembayaran_teks = $stmtNama->fetchColumn();
    }

    // Filter status
    if ($jenis_laporan === 'Pemasukan Lunas') {
        $where_clause .= " AND t.status = 'Lunas' ";
    } elseif ($jenis_laporan === 'Tunggakan') {
        $where_clause .= " AND t.status = 'Belum Lunas' ";
    }

    // 4. EKSEKUSI QUERY
    $sql = "SELECT t.*, s.nama, s.nisn, j.nama_pembayaran 
            FROM transaksi_pembayaran t
            JOIN data_siswa s ON t.nisn = s.nisn
            JOIN jenis_pembayaran j ON t.id_jenis = j.id_jenis
            WHERE t.tanggal_bayar BETWEEN :awal AND :akhir 
            $where_clause
            ORDER BY t.tanggal_bayar ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $data_transaksi = $stmt->fetchAll();

    // 5. CATAT AKTIVITAS KE TABEL LAPORAN (LOGGING)
    // Format gabungan: "SPP April - Tunggakan"
    $nama_log_final = $nama_pembayaran_teks . " - " . $jenis_laporan;
    $periode_teks = date('d M Y', strtotime($tgl_awal)) . " s/d " . date('d M Y', strtotime($tgl_akhir));

    $stmtLog = $pdo->prepare("INSERT INTO laporan (jenis_laporan, periode) VALUES (:jenis, :periode)");
    $stmtLog->execute([
        ':jenis'   => $nama_log_final,
        ':periode' => $periode_teks
    ]);
} catch (PDOException $e) {
    die("Error memproses laporan: " . $e->getMessage());
}

// =========================================================================
// HTML UNTUK DOMPDF (Desain Laporan A4)
// =========================================================================
$html = '
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan - ' . htmlspecialchars($jenis_laporan) . '</title>
    <style>
        @page { margin: 30px 40px; }
        body { font-family: "Helvetica", "Arial", sans-serif; font-size: 11px; color: #111; }
        
        /* Kop Surat */
        .kop-surat { width: 100%; border-bottom: 3px solid #000; padding-bottom: 10px; margin-bottom: 20px; text-align: center; }
        .kop-surat h2 { margin: 0 0 5px 0; font-size: 18px; text-transform: uppercase; letter-spacing: 1px; }
        .kop-surat p { margin: 0; font-size: 11px; }
        
        /* Judul Laporan */
        .judul-laporan { text-align: center; margin-bottom: 20px; }
        .judul-laporan h3 { margin: 0 0 5px 0; font-size: 14px; text-transform: uppercase; text-decoration: underline; }
        .judul-laporan p { margin: 0; font-size: 11px; }

        /* Tabel Data */
        table.data-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        table.data-table th, table.data-table td { border: 1px solid #000; padding: 6px 8px; vertical-align: middle; }
        table.data-table th { background-color: #f0f0f0; font-weight: bold; text-align: center; }
        
        /* Footer / Tanda Tangan */
        .footer-ttd { width: 100%; margin-top: 30px; }
        .footer-ttd table { width: 100%; border: none; }
        .footer-ttd td { border: none; padding: 0; text-align: center; width: 33%; }
        .nama-ttd { margin-top: 60px; font-weight: bold; text-decoration: underline; }
    </style>
</head>
<body>

    <!-- KOP SURAT -->
    <div class="kop-surat">
        <h2>' . htmlspecialchars($profil['nama_sekolah']) . '</h2>
        <p>' . htmlspecialchars($profil['alamat']) . '<br>
        Telepon: ' . htmlspecialchars($profil['telepon']) . ' | Email: ' . htmlspecialchars($profil['email_sekolah']) . '</p>
    </div>

    <!-- JUDUL LAPORAN -->
    <div class="judul-laporan">
        <h3>Laporan Transaksi Pembayaran</h3>
        <p>Kategori: <strong>' . htmlspecialchars($nama_log_final) . '</strong> | Periode: <strong>' . $periode_teks . '</strong></p>
    </div>

    <!-- TABEL DATA -->
    <table class="data-table">
        <thead>
            <tr>
                <th width="5%">No</th>
                <th width="12%">Tanggal</th>
                <th width="23%">Siswa (NISN)</th>
                <th width="25%">Jenis Pembayaran</th>
                <th width="15%">Status</th>
                <th width="20%">Jumlah (Rp)</th>
            </tr>
        </thead>
        <tbody>';

$total_uang = 0;
if (count($data_transaksi) > 0) {
    $no = 1;
    foreach ($data_transaksi as $row) {
        $total_uang += $row['jumlah_bayar'];
        $status_text = ($row['status'] === 'Lunas') ? 'Lunas' : 'Belum Lunas';

        $html .= '
                <tr>
                    <td style="text-align: center;">' . $no++ . '</td>
                    <td style="text-align: center;">' . date('d/m/Y', strtotime($row['tanggal_bayar'])) . '</td>
                    <td><strong>' . htmlspecialchars($row['nama']) . '</strong><br><span style="font-size: 9px; color: #444;">' . htmlspecialchars($row['nisn']) . '</span></td>
                    <td>' . htmlspecialchars($row['nama_pembayaran']) . '</td>
                    <td style="text-align: center;">' . $status_text . '</td>
                    <td style="text-align: right; font-weight: bold;">' . number_format($row['jumlah_bayar'], 0, ',', '.') . '</td>
                </tr>';
    }
} else {
    $html .= '
            <tr>
                <td colspan="6" style="text-align: center; padding: 20px;">Tidak ada data transaksi pada periode ini.</td>
            </tr>';
}

$html .= '
        </tbody>
        <!-- Baris Total -->
        <tfoot>
            <tr>
                <th colspan="5" style="text-align: right; background-color: #f0f0f0;">TOTAL KESELURUHAN</th>
                <th style="text-align: right; background-color: #f0f0f0;">Rp ' . number_format($total_uang, 0, ',', '.') . '</th>
            </tr>
        </tfoot>
    </table>

    <!-- TANDA TANGAN -->
    <div class="footer-ttd">
        <table>
            <tr>
                <td></td>
                <td></td>
                <td>
                    <p style="margin: 0;">Pekanbaru, ' . date('d M Y') . '<br>Mengetahui,<br>Bendahara Administrasi</p>
                    <div class="nama-ttd">' . htmlspecialchars($_SESSION['username']) . '</div>
                </td>
            </tr>
        </table>
    </div>

</body>
</html>
';

// =========================================================================
// INISIALISASI DOMPDF
// =========================================================================
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);

$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);

// Ukuran kertas A4 Portrait (Laporan resmi)
$dompdf->setPaper('A4', 'portrait');

$dompdf->render();

// Output ke Browser (Buka di tab baru, bukan langsung download)
$dompdf->stream("Laporan_" . str_replace(' ', '_', $jenis_laporan) . "_" . date('Ymd') . ".pdf", array("Attachment" => false));
