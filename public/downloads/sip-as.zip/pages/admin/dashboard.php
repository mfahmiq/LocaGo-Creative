<?php
session_start();
require_once '../../config/koneksi.php';

// Proteksi halaman: Pastikan user sudah login
if (!isset($_SESSION['is_logged_in'])) {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

require_once '../../includes/header.php';

$pdo = getConnection();

try {
    // 1. Ambil Total Siswa
    $stmtSiswa = $pdo->query("SELECT COUNT(*) FROM data_siswa");
    $total_siswa = $stmtSiswa->fetchColumn();

    // 2. Ambil Total Pemasukan Keseluruhan (Hanya yang Lunas)
    $stmtPemasukan = $pdo->query("SELECT SUM(jumlah_bayar) FROM transaksi_pembayaran WHERE status = 'Lunas'");
    $total_pemasukan = $stmtPemasukan->fetchColumn() ?? 0;

    // 3. Ambil Pemasukan Hari Ini
    $hari_ini = date('Y-m-d');
    $stmtHariIni = $pdo->prepare("SELECT SUM(jumlah_bayar) FROM transaksi_pembayaran WHERE status = 'Lunas' AND DATE(tanggal_bayar) = :hari_ini");
    $stmtHariIni->execute([':hari_ini' => $hari_ini]);
    $pemasukan_hari_ini = $stmtHariIni->fetchColumn() ?? 0;

    // 4. Ambil Total Transaksi Belum Lunas (Tunggakan/Cicilan)
    $stmtTunggakan = $pdo->query("SELECT COUNT(*) FROM transaksi_pembayaran WHERE status = 'Belum Lunas'");
    $total_tunggakan = $stmtTunggakan->fetchColumn();

    // 5. Ambil 5 Transaksi Terakhir untuk Tabel Riwayat
    $sqlRecent = "SELECT t.*, s.nama, j.nama_pembayaran 
                  FROM transaksi_pembayaran t
                  JOIN data_siswa s ON t.nisn = s.nisn
                  JOIN jenis_pembayaran j ON t.id_jenis = j.id_jenis
                  ORDER BY t.tanggal_bayar DESC, t.id_transaksi DESC 
                  LIMIT 5";
    $stmtRecent = $pdo->query($sqlRecent);
    $recent_transactions = $stmtRecent->fetchAll();
} catch (PDOException $e) {
    die("Error memuat data dashboard: " . $e->getMessage());
}

// Sapaan berdasarkan waktu
$jam = date('H');
if ($jam < 12) $sapaan = "Selamat Pagi";
elseif ($jam < 15) $sapaan = "Selamat Siang";
elseif ($jam < 18) $sapaan = "Selamat Sore";
else $sapaan = "Selamat Malam";
?>

<!-- WIDGETS STATISTIK -->
<div class="row mb-4">
    <div class="col-12 mb-4">
        <div class="card border-0 shadow-sm bg-primary bg-gradient text-white" style="border-radius: 1rem;">
            <div class="card-body p-4 d-flex align-items-center">
                <div class="me-4 d-none d-md-block">
                    <i class="bi bi-person-workspace" style="font-size: 3.5rem; opacity: 0.8;"></i>
                </div>
                <div>
                    <h4 class="fw-bold mb-1"><?= $sapaan ?>, <?= htmlspecialchars($_SESSION['username']) ?>! 👋</h4>
                    <p class="mb-0 text-white">Selamat datang di Panel Administrasi Sistem Pembayaran Sekolah. Apa yang ingin Anda kerjakan hari ini?</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Card Total Siswa -->
    <div class="col-xl-3 col-sm-6 mb-4">
        <div class="card border-0 shadow-sm h-100 py-2" style="border-radius: 1rem; border-left: 5px solid #4e73df !important;">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col me-2">
                        <div class="text-xs fw-bold text-primary text-uppercase mb-1" style="font-size: 0.8rem;">Total Siswa Aktif</div>
                        <div class="h3 mb-0 fw-bold text-gray-800"><?= number_format($total_siswa, 0, ',', '.') ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-people fa-2x text-muted" style="font-size: 2rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Card Pemasukan Hari Ini -->
    <div class="col-xl-3 col-sm-6 mb-4">
        <div class="card border-0 shadow-sm h-100 py-2" style="border-radius: 1rem; border-left: 5px solid #1cc88a !important;">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col me-2">
                        <div class="text-xs fw-bold text-success text-uppercase mb-1" style="font-size: 0.8rem;">Pemasukan Hari Ini</div>
                        <div class="h4 mb-0 fw-bold text-gray-800">Rp <?= number_format($pemasukan_hari_ini, 0, ',', '.') ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-wallet2 text-muted" style="font-size: 2rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Card Total Pemasukan -->
    <div class="col-xl-3 col-sm-6 mb-4">
        <div class="card border-0 shadow-sm h-100 py-2" style="border-radius: 1rem; border-left: 5px solid #36b9cc !important;">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col me-2">
                        <div class="text-xs fw-bold text-info text-uppercase mb-1" style="font-size: 0.8rem;">Total Pemasukan</div>
                        <div class="h4 mb-0 fw-bold text-gray-800">Rp <?= number_format($total_pemasukan, 0, ',', '.') ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-cash-stack text-muted" style="font-size: 2rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Card Tunggakan -->
    <div class="col-xl-3 col-sm-6 mb-4">
        <div class="card border-0 shadow-sm h-100 py-2" style="border-radius: 1rem; border-left: 5px solid #f6c23e !important;">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col me-2">
                        <div class="text-xs fw-bold text-warning text-uppercase mb-1" style="font-size: 0.8rem;">Transaksi Belum Lunas</div>
                        <div class="h3 mb-0 fw-bold text-gray-800"><?= number_format($total_tunggakan, 0, ',', '.') ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-exclamation-circle text-muted" style="font-size: 2rem; opacity: 0.3;"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- TABEL & QUICK ACTIONS -->
<div class="row">
    <!-- Tabel 5 Transaksi Terakhir -->
    <div class="col-lg-8 mb-4">
        <div class="card border-0 shadow-sm" style="border-radius: 1rem;">
            <div class="card-header bg-white py-3 d-flex flex-row align-items-center justify-content-between" style="border-radius: 1rem 1rem 0 0;">
                <h6 class="m-0 fw-bold text-primary"><i class="bi bi-clock-history me-2"></i>5 Transaksi Pembayaran Terakhir</h6>
                <a href="transaksi-pembayaran/index.php" class="btn btn-sm btn-light text-primary fw-bold shadow-sm rounded-pill px-3">Lihat Semua</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="px-4" width="20%">Tanggal</th>
                                <th width="30%">Siswa</th>
                                <th width="30%">Pembayaran</th>
                                <th class="text-end px-4" width="20%">Nominal</th>
                            </tr>
                        </thead>
                        <tbody class="border-top-0">
                            <?php if (count($recent_transactions) > 0): ?>
                                <?php foreach ($recent_transactions as $row): ?>
                                    <tr>
                                        <td class="px-4 text-muted" style="font-size: 0.9rem;">
                                            <?= date('d M Y', strtotime($row['tanggal_bayar'])) ?>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-dark"><?= htmlspecialchars($row['nama']) ?></div>
                                        </td>
                                        <td>
                                            <span class="text-dark d-block"><?= htmlspecialchars($row['nama_pembayaran']) ?></span>
                                            <?php if ($row['status'] === 'Lunas'): ?>
                                                <span class="badge bg-success bg-opacity-10 text-white" style="font-size: 0.7rem;">Lunas</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning bg-opacity-10 text-white" style="font-size: 0.7rem;">Belum Lunas</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end px-4 fw-bold text-dark">
                                            Rp <?= number_format($row['jumlah_bayar'], 0, ',', '.') ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center py-4 text-muted">Belum ada transaksi yang dicatat.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Akses Cepat (Quick Actions) -->
    <div class="col-lg-4 mb-4">
        <div class="card border-0 shadow-sm" style="border-radius: 1rem;">
            <div class="card-header bg-white py-3" style="border-radius: 1rem 1rem 0 0;">
                <h6 class="m-0 fw-bold text-dark"><i class="bi bi-lightning-charge me-2 text-warning"></i>Akses Cepat</h6>
            </div>
            <div class="card-body">
                <div class="d-grid gap-3">
                    <a href="transaksi-pembayaran/tambah.php" class="btn btn-outline-primary text-start px-4 py-3 rounded-3 shadow-sm d-flex align-items-center">
                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                            <i class="bi bi-cart-plus"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 fw-bold">Input Pembayaran</h6>
                            <small class="fw-light">Catat transaksi baru</small>
                        </div>
                    </a>

                    <a href="data-siswa/tambah.php" class="btn btn-outline-success text-start px-4 py-3 rounded-3 shadow-sm d-flex align-items-center">
                        <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                            <i class="bi bi-person-plus"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 fw-bold">Tambah Data Siswa</h6>
                            <small class="fw-light">Daftarkan siswa baru</small>
                        </div>
                    </a>

                    <?php if ($_SESSION['role'] === 'admin1'): ?>
                        <a href="laporan/index.php" class="btn btn-outline-info text-start px-4 py-3 rounded-3 shadow-sm d-flex align-items-center">
                            <div class="bg-info text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                <i class="bi bi-printer"></i>
                            </div>
                            <div>
                                <h6 class="mb-0 fw-bold">Cetak Laporan</h6>
                                <small class="fw-light">Export PDF & Excel</small>
                            </div>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>