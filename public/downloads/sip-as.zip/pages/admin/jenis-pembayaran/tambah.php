<?php
session_start();
require_once '../../../config/koneksi.php';

// Proteksi halaman
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin1') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

$error = '';

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama_pembayaran = trim($_POST['nama_pembayaran']);
    $nominal         = trim($_POST['nominal']);
    $keterangan      = trim($_POST['keterangan']);

    // Validasi input kosong (Keterangan boleh kosong, jadi tidak dimasukkan ke validasi)
    if (empty($nama_pembayaran) || empty($nominal)) {
        $error = "Nama pembayaran dan nominal wajib diisi!";
    } elseif (!is_numeric($nominal) || $nominal <= 0) {
        $error = "Nominal harus berupa angka dan lebih dari 0!";
    } else {
        $pdo = getConnection();
        try {
            // Proses INSERT ke database
            $stmt = $pdo->prepare("INSERT INTO jenis_pembayaran (nama_pembayaran, nominal, keterangan) 
                                   VALUES (:nama_pembayaran, :nominal, :keterangan)");
            $stmt->execute([
                ':nama_pembayaran' => $nama_pembayaran,
                ':nominal'         => $nominal,
                ':keterangan'      => $keterangan
            ]);

            $_SESSION['success'] = "Jenis pembayaran tagihan <strong>$nama_pembayaran</strong> berhasil ditambahkan!";
            header("Location: index.php");
            exit;
        } catch (PDOException $e) {
            $error = "Terjadi kesalahan sistem: " . $e->getMessage();
        }
    }
}

require_once '../../../includes/header.php';
?>

<style>
    .form-control-modern {
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
        padding: 0.75rem 1rem;
        border-radius: 0.5rem;
        color: #212529;
        transition: all 0.2s;
    }

    .form-control-modern:focus {
        background-color: #ffffff;
        border-color: #4e73df;
        box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.15);
    }

    .input-group-text-modern {
        background-color: #f8f9fa;
        border: 1px solid #ced4da;
        border-right: none;
        color: #6c757d;
        border-radius: 0.5rem 0 0 0.5rem;
        font-weight: 600;
    }

    .form-control-modern.with-icon {
        border-left: none;
        border-radius: 0 0.5rem 0.5rem 0;
    }
</style>

<div class="row justify-content-center">
    <div class="col-xl-8 col-lg-10">

        <div class="mb-3">
            <a href="index.php" class="btn btn-white shadow-sm rounded-pill text-muted fw-medium border-0 px-3 py-2" style="font-size: 0.9rem;">
                <i class="bi bi-arrow-left me-2"></i> Kembali ke Daftar Tagihan
            </a>
        </div>

        <div class="card border-0 shadow-sm" style="border-radius: 1.2rem; overflow: hidden;">
            <div class="bg-primary bg-opacity-10 py-4 px-4 px-md-5 border-bottom border-primary border-opacity-10">
                <h5 class="fw-bold text-white mb-1">Tambah Jenis Pembayaran</h5>
                <p class="text-white text-opacity-75 mb-0" style="font-size: 0.85rem;">Buat kategori tagihan baru yang nantinya akan dibebankan kepada siswa.</p>
            </div>

            <div class="card-body p-4 p-md-5 bg-white">

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm rounded-3" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="" method="POST">

                    <div class="mb-4">
                        <label for="nama_pembayaran" class="form-label fw-semibold text-dark">Nama Pembayaran / Tagihan <span class="text-danger">*</span></label>
                        <input type="text" class="form-control form-control-modern" id="nama_pembayaran" name="nama_pembayaran" placeholder="Contoh: SPP Bulan Maret 2026 atau Uang Seragam" value="<?= isset($_POST['nama_pembayaran']) ? htmlspecialchars($_POST['nama_pembayaran']) : '' ?>" required>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-8">
                            <label for="nominal" class="form-label fw-semibold text-dark">Nominal Tagihan <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text input-group-text-modern">Rp</span>
                                <input type="number" min="0" step="1000" class="form-control form-control-modern with-icon" id="nominal" name="nominal" placeholder="0" value="<?= isset($_POST['nominal']) ? htmlspecialchars($_POST['nominal']) : '' ?>" required>
                            </div>
                            <small class="text-muted d-block mt-1" style="font-size: 0.8rem;">Masukkan angka saja tanpa titik atau koma (contoh: 150000).</small>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="keterangan" class="form-label fw-semibold text-dark">Keterangan (Opsional)</label>
                        <textarea class="form-control form-control-modern" id="keterangan" name="keterangan" rows="3" placeholder="Tambahkan detail atau penjelasan tentang tagihan ini..."><?= isset($_POST['keterangan']) ? htmlspecialchars($_POST['keterangan']) : '' ?></textarea>
                    </div>

                    <div class="d-flex justify-content-end gap-3 pt-3 border-top">
                        <button type="reset" class="btn btn-light rounded-pill px-4 fw-medium border shadow-sm text-muted">Reset</button>
                        <button type="submit" class="btn btn-primary rounded-pill shadow-sm px-5 fw-medium">
                            <i class="bi bi-save me-1"></i> Simpan Tagihan
                        </button>
                    </div>

                </form>
            </div>
        </div>

    </div>
</div>

<?php require_once '../../../includes/footer.php'; ?>