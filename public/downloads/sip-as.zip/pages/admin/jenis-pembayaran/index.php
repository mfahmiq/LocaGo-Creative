<?php
session_start();
require_once '../../../config/koneksi.php';

// Pastikan user sudah login dan merupakan admin1 (Bendahara)
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin1') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

require_once '../../../includes/header.php';

$pdo = getConnection();

// --- LOGIKA PENCARIAN & PAGINATION ---
$limit = 5; // Menampilkan 5 data per halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$search = isset($_GET['cari']) ? trim($_GET['cari']) : '';
$searchQuery = '';
$params = [];

if (!empty($search)) {
    // Pencarian berdasarkan nama pembayaran
    $searchQuery = " WHERE nama_pembayaran LIKE :search ";
    $params[':search'] = "%$search%";
}

try {
    // 1. Hitung total data
    $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM jenis_pembayaran" . $searchQuery);
    $stmtCount->execute($params);
    $total_data = $stmtCount->fetchColumn();
    $total_pages = ceil($total_data / $limit);

    // 2. Ambil data dengan LIMIT dan OFFSET
    $stmt = $pdo->prepare("SELECT * FROM jenis_pembayaran" . $searchQuery . " ORDER BY id_jenis DESC LIMIT $limit OFFSET $offset");
    $stmt->execute($params);
    $data_pembayaran = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error mengambil data: " . $e->getMessage());
}
?>

<!-- Header Halaman & Form Pencarian -->
<div class="row mb-4 align-items-center">
    <div class="col-md-5">
        <h4 class="mb-0 fw-bold text-dark">Jenis Pembayaran</h4>
        <p class="text-muted mb-0" style="font-size: 0.9rem;">Kelola master data tagihan dan pembayaran sekolah</p>
    </div>
    <div class="col-md-7 d-flex justify-content-md-end align-items-center gap-2 mt-3 mt-md-0">
        <!-- Form Cari -->
        <form method="GET" action="index.php" class="d-flex w-100" style="max-width: 300px;">
            <div class="input-group shadow-sm" style="border-radius: 50rem;">
                <input type="text" name="cari" class="form-control border-end-0 bg-white" style="border-radius: 50rem 0 0 50rem; padding-left: 1.2rem;" placeholder="Cari nama pembayaran..." value="<?= htmlspecialchars($search) ?>">
                <button class="btn btn-white border border-start-0 bg-white" type="submit" style="border-radius: 0 50rem 50rem 0; padding-right: 1.2rem;">
                    <i class="bi bi-search text-primary"></i>
                </button>
            </div>
        </form>
        <!-- Tombol Tambah -->
        <a href="tambah.php" class="btn btn-primary rounded-pill shadow-sm px-4 flex-shrink-0">
            <i class="bi bi-plus-lg me-1"></i> Tambah Tagihan
        </a>
    </div>
</div>

<!-- Notifikasi -->
<?php if (isset($_SESSION['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm rounded-3" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i> <?= $_SESSION['success'] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm rounded-3" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $_SESSION['error'] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['error']); ?>
<?php endif; ?>

<!-- Card Tabel -->
<div class="card border-0 shadow-sm" style="border-radius: 1rem;">
    <div class="card-body p-4">

        <?php if (!empty($search)): ?>
            <div class="mb-3">
                <span class="text-muted">Hasil pencarian untuk: <strong>"<?= htmlspecialchars($search) ?>"</strong></span>
                <a href="index.php" class="text-decoration-none ms-2 badge bg-secondary bg-opacity-10 text-white">Reset Pencarian</a>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="text-center rounded-start" width="5%">No</th>
                        <th width="30%">Nama Pembayaran</th>
                        <th width="20%">Nominal (Rp)</th>
                        <th>Keterangan</th>
                        <th class="text-center rounded-end" width="12%">Aksi</th>
                    </tr>
                </thead>
                <tbody class="border-top-0">
                    <?php if (count($data_pembayaran) > 0): ?>
                        <?php
                        $no = $offset + 1;
                        foreach ($data_pembayaran as $row):
                        ?>
                            <tr>
                                <td class="text-center text-muted"><?= $no++ ?></td>
                                <td>
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($row['nama_pembayaran']) ?></div>
                                </td>
                                <td>
                                    <!-- Format Rupiah -->
                                    <span class="fw-semibold text-success">
                                        Rp <?= number_format($row['nominal'], 0, ',', '.') ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="text-muted" style="font-size: 0.9rem;">
                                        <?= htmlspecialchars($row['keterangan']) ?: '<i class="text-light-muted">- Tidak ada keterangan -</i>' ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <a href="edit.php?id=<?= $row['id_jenis'] ?>" class="btn btn-light btn-sm text-primary shadow-sm rounded-3 me-1" title="Edit Data">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>
                                    <a href="hapus.php?id=<?= $row['id_jenis'] ?>" class="btn btn-light btn-sm text-danger shadow-sm rounded-3" title="Hapus Data" onclick="return confirm('PENTING!\nMenghapus jenis pembayaran ini akan menghapus semua riwayat transaksi siswa yang terkait dengan tagihan ini.\n\nApakah Anda yakin ingin menghapus [<?= htmlspecialchars($row['nama_pembayaran']) ?>]?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-5">
                                <div class="text-muted">
                                    <i class="bi bi-tags fs-1 d-block mb-3"></i>
                                    <p class="mb-0">Data jenis pembayaran belum tersedia atau tidak ditemukan.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <nav class="mt-4">
                <ul class="pagination justify-content-center mb-0">
                    <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                        <a class="page-link rounded-start-pill px-3" href="?page=<?= $page - 1 ?><?= !empty($search) ? '&cari=' . urlencode($search) : '' ?>">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= ($page == $i) ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?><?= !empty($search) ? '&cari=' . urlencode($search) : '' ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= ($page >= $total_pages) ? 'disabled' : '' ?>">
                        <a class="page-link rounded-end-pill px-3" href="?page=<?= $page + 1 ?><?= !empty($search) ? '&cari=' . urlencode($search) : '' ?>">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>

    </div>
</div>

<?php require_once '../../../includes/footer.php'; ?>