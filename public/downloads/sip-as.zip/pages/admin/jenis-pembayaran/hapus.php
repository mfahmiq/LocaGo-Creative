<?php
session_start();
require_once '../../../config/koneksi.php';

// Proteksi halaman: pastikan user sudah login dan merupakan admin1 (Bendahara)
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin1') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

// Mengecek apakah ada parameter id yang dikirim melalui URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $pdo = getConnection();
    $id_jenis = $_GET['id'];

    try {
        // 1. Cek dulu datanya dan ambil nama pembayarannya untuk pesan notifikasi
        $stmtCheck = $pdo->prepare("SELECT nama_pembayaran FROM jenis_pembayaran WHERE id_jenis = :id");
        $stmtCheck->execute([':id' => $id_jenis]);
        $pembayaran = $stmtCheck->fetch();

        if ($pembayaran) {
            $nama_pembayaran = $pembayaran['nama_pembayaran'];

            // 2. Jika data ada, jalankan perintah DELETE
            $stmtDelete = $pdo->prepare("DELETE FROM jenis_pembayaran WHERE id_jenis = :id");
            $stmtDelete->execute([':id' => $id_jenis]);

            // Set pesan sukses
            $_SESSION['success'] = "Tagihan <strong>" . htmlspecialchars($nama_pembayaran) . "</strong> berhasil dihapus secara permanen.";
        } else {
            // Jika data tidak ditemukan di database
            $_SESSION['error'] = "Gagal! Data tagihan tidak ditemukan.";
        }
    } catch (PDOException $e) {
        // Menangkap error sistem/database
        $_SESSION['error'] = "Terjadi kesalahan sistem saat menghapus data: " . $e->getMessage();
    }
} else {
    // Jika file diakses langsung tanpa parameter ID
    $_SESSION['error'] = "Akses tidak valid!";
}

// Redirect kembali ke halaman utama Jenis Pembayaran
header("Location: index.php");
exit;
