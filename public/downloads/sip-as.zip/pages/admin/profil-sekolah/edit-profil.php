<?php
session_start();
require_once '../../../config/koneksi.php';

// Proteksi halaman
if (!isset($_SESSION['is_logged_in']) || $_SESSION['role'] !== 'admin1') {
    header("Location: " . BASE_URL . "login.php");
    exit;
}

$pdo = getConnection();
$error = '';
$success = '';

// 1. Ambil data profil (asumsi ID selalu 1)
try {
    $stmt = $pdo->query("SELECT * FROM profil_sekolah LIMIT 1");
    $profil = $stmt->fetch();
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

// 2. Proses Update jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama   = trim($_POST['nama_sekolah']);
    $alamat = trim($_POST['alamat']);
    $telp   = trim($_POST['telepon']);
    $email  = trim($_POST['email_sekolah']);

    if (empty($nama) || empty($alamat) || empty($telp) || empty($email)) {
        $error = "Semua kolom wajib diisi!";
    } else {
        try {
            $sql = "UPDATE profil_sekolah SET 
                    nama_sekolah = :nama, 
                    alamat = :alamat, 
                    telepon = :telp, 
                    email_sekolah = :email 
                    WHERE id_profil = :id";
            $stmtUpdate = $pdo->prepare($sql);
            $stmtUpdate->execute([
                ':nama'   => $nama,
                ':alamat' => $alamat,
                ':telp'   => $telp,
                ':email'  => $email,
                ':id'     => $profil['id_profil']
            ]);

            $_SESSION['success_profil'] = "Profil sekolah berhasil diperbarui!";
            // Refresh data terbaru
            header("Location: edit-profil.php");
            exit;
        } catch (PDOException $e) {
            $error = "Gagal memperbarui data: " . $e->getMessage();
        }
    }
}

// Ambil pesan sukses dari session jika ada
if (isset($_SESSION['success_profil'])) {
    $success = $_SESSION['success_profil'];
    unset($_SESSION['success_profil']);
}

require_once '../../../includes/header.php';

?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="mb-4">
            <h4 class="fw-bold text-dark">Profil Sekolah</h4>
            <p class="text-muted">Data ini akan digunakan untuk identitas pada Kuitansi dan Laporan.</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger border-0 shadow-sm rounded-3"><?= $error ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success border-0 shadow-sm rounded-3">
                <i class="bi bi-check-circle-fill me-2"></i> <?= $success ?>
            </div>
        <?php endif; ?>

        <div class="card border-0 shadow-sm" style="border-radius: 1rem;">
            <div class="card-body p-4 p-md-5">
                <form action="" method="POST">
                    <div class="mb-4">
                        <label class="form-label fw-bold">Nama Sekolah</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-end-0"><i class="bi bi-building text-primary"></i></span>
                            <input type="text" name="nama_sekolah" class="form-control border-start-0 bg-light focus-white"
                                value="<?= htmlspecialchars($profil['nama_sekolah']) ?>" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold">Alamat Lengkap</label>
                        <textarea name="alamat" class="form-control bg-light focus-white" rows="3" required><?= htmlspecialchars($profil['alamat']) ?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-4">
                            <label class="form-label fw-bold">Nomor Telepon</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0"><i class="bi bi-telephone text-primary"></i></span>
                                <input type="text" name="telepon" class="form-control border-start-0 bg-light focus-white"
                                    value="<?= htmlspecialchars($profil['telepon']) ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <label class="form-label fw-bold">Email Sekolah</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0"><i class="bi bi-envelope text-primary"></i></span>
                                <input type="email" name="email_sekolah" class="form-control border-start-0 bg-light focus-white"
                                    value="<?= htmlspecialchars($profil['email_sekolah']) ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="pt-3 border-top d-flex justify-content-end">
                        <button type="submit" class="btn btn-primary rounded-pill px-5 fw-bold shadow-sm">
                            <i class="bi bi-check-lg me-1"></i> Simpan Perubahan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    .focus-white:focus {
        background-color: #fff !important;
        border-color: #4e73df !important;
        box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.1) !important;
    }

    .input-group-text {
        border-color: #ced4da;
    }
</style>

<?php require_once '../../../includes/header.php'; ?>