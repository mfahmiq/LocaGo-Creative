<?php
session_start();
require_once 'config/koneksi.php'; // Pastikan path koneksi benar

$pdo = getConnection();

// 1. Ambil Data Profil Sekolah untuk ditampilkan di halaman depan
try {
    $stmtProfil = $pdo->query("SELECT * FROM profil_sekolah LIMIT 1");
    $profil = $stmtProfil->fetch();
    $nama_sekolah = $profil ? htmlspecialchars($profil['nama_sekolah']) : 'Sistem Pembayaran Administrasi Sekolah';
    $alamat_sekolah = $profil ? htmlspecialchars($profil['alamat']) : '-';
} catch (PDOException $e) {
    die("Error mengambil data profil: " . $e->getMessage());
}

// 2. Logika Pencarian NISN oleh Siswa/Orang Tua
$siswa = null;
$transaksi = [];
$pesan_error = '';

if (isset($_GET['nisn']) && !empty(trim($_GET['nisn']))) {
    $nisn_cari = trim($_GET['nisn']);

    try {
        // Cari data siswa
        $stmtSiswa = $pdo->prepare("SELECT * FROM data_siswa WHERE nisn = :nisn");
        $stmtSiswa->execute([':nisn' => $nisn_cari]);
        $siswa = $stmtSiswa->fetch();

        if ($siswa) {
            // Jika siswa ditemukan, ambil riwayat pembayarannya
            $stmtTrans = $pdo->prepare("
                SELECT t.*, j.nama_pembayaran, j.nominal
                FROM transaksi_pembayaran t
                JOIN jenis_pembayaran j ON t.id_jenis = j.id_jenis
                WHERE t.nisn = :nisn
                ORDER BY t.tanggal_bayar DESC, t.id_transaksi DESC
            ");
            $stmtTrans->execute([':nisn' => $nisn_cari]);
            $transaksi = $stmtTrans->fetchAll();
        } else {
            $pesan_error = "Mohon maaf, data siswa dengan NISN <strong>" . htmlspecialchars($nisn_cari) . "</strong> tidak ditemukan dalam sistem kami.";
        }
    } catch (PDOException $e) {
        $pesan_error = "Terjadi kesalahan sistem: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Pembayaran - <?= $nama_sekolah ?></title>

    <!-- Bootstrap 5 -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f4f7fc;
            color: #2c3e50;
        }

        /* Navbar Custom */
        .navbar-custom {
            background: rgba(255, 255, 255, 0.95) !important;
            backdrop-filter: blur(10px);
        }

        /* Hero Section Bergelombang */
        .hero-section {
            background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
            padding: 6rem 0 8rem 0;
            color: white;
            position: relative;
        }

        .hero-wave {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            overflow: hidden;
            line-height: 0;
        }

        .hero-wave svg {
            position: relative;
            display: block;
            width: calc(100% + 1.3px);
            height: 60px;
        }

        .hero-wave .shape-fill {
            fill: #f4f7fc;
        }

        /* Kotak Pencarian melayang */
        .search-card {
            margin-top: -5rem;
            border-radius: 1.2rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            border: none;
            position: relative;
            z-index: 10;
        }

        .form-control-lg {
            border-radius: 0.8rem;
            padding: 1rem 1.5rem;
            font-size: 1.1rem;
            background-color: #f8f9fa;
            border: 1px solid #e2e8f0;
        }

        .form-control-lg:focus {
            background-color: #fff;
            border-color: #4e73df;
            box-shadow: 0 0 0 0.25rem rgba(78, 115, 223, 0.15);
        }

        .btn-cari {
            border-radius: 0.8rem;
            padding: 0 2rem;
            font-weight: 600;
        }
    </style>
</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-light navbar-custom fixed-top shadow-sm py-3">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary d-flex align-items-center" href="index.php">
                <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 35px; height: 35px;">
                    <i class="bi bi-shield-check"></i>
                </div>
                SIP-AS
            </a>
            <div class="d-flex">
                <?php if (isset($_SESSION['is_logged_in'])): ?>
                    <!-- Jika sudah login, tombol berubah mengarah ke Dashboard -->
                    <a href="<?= ($_SESSION['role'] === 'admin1') ? 'pages/admin/dashboard.php' : 'pages/kepala/dashboard.php' ?>" class="btn btn-primary rounded-pill px-4 fw-semibold shadow-sm">
                        <i class="bi bi-grid-fill me-1"></i> Dashboard Admin
                    </a>
                <?php else: ?>
                    <!-- Jika belum login -->
                    <a href="login.php" class="btn btn-outline-primary rounded-pill px-4 fw-semibold">
                        <i class="bi bi-box-arrow-in-right me-1"></i> Login Admin
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- HERO SECTION -->
    <div class="hero-section text-center">
        <div class="container">
            <span class="badge bg-white text-primary px-3 py-2 rounded-pill mb-3 fw-bold" style="letter-spacing: 1px;">PORTAL INFORMASI WALI MURID</span>
            <h1 class="display-5 fw-extrabold mb-3">Cek Riwayat Pembayaran Siswa</h1>
            <p class="lead fw-normal opacity-75 mb-0" style="max-width: 600px; margin: 0 auto;">
                <?= $nama_sekolah ?>
            </p>
        </div>

        <!-- Gelombang SVG di bawah Hero -->
        <div class="hero-wave">
            <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
                <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V120H0V95.8C59.71,118.08,130.83,121.22,200.28,111.4,242.15,105.52,283.82,85.25,321.39,56.44Z" class="shape-fill"></path>
            </svg>
        </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="container mb-5">

        <!-- FORM PENCARIAN -->
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card search-card bg-white">
                    <div class="card-body p-4 p-md-5">
                        <form action="index.php" method="GET">
                            <label class="form-label fw-bold text-dark mb-3">Masukkan NISN Siswa:</label>
                            <div class="input-group input-group-lg">
                                <span class="input-group-text bg-light border-end-0 text-muted px-4"><i class="bi bi-upc-scan"></i></span>
                                <input type="text" name="nisn" class="form-control form-control-lg border-start-0" placeholder="Contoh: 0012345678" value="<?= isset($_GET['nisn']) ? htmlspecialchars($_GET['nisn']) : '' ?>" required autocomplete="off">
                                <button type="submit" class="btn btn-primary btn-cari">Cari Data</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- AREA HASIL PENCARIAN -->
        <?php if (!empty($pesan_error)): ?>
            <!-- Pesan Error -->
            <div class="row justify-content-center mt-5">
                <div class="col-lg-8 text-center">
                    <div class="alert alert-warning border-0 shadow-sm rounded-3 py-4" role="alert">
                        <i class="bi bi-search fs-1 text-warning d-block mb-3"></i>
                        <h5 class="fw-bold text-dark mb-1">Opsi Pencarian Gagal</h5>
                        <p class="text-muted mb-0"><?= $pesan_error ?></p>
                    </div>
                </div>
            </div>
        <?php elseif ($siswa): ?>
            <!-- Hasil Ditemukan -->
            <div class="row justify-content-center mt-5">
                <div class="col-lg-10">

                    <!-- Kartu Info Siswa -->
                    <div class="d-flex align-items-center mb-4 p-4 bg-white rounded-3 shadow-sm border-start border-4 border-primary">
                        <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center me-4" style="width: 60px; height: 60px; font-size: 1.5rem;">
                            <i class="bi bi-person-fill"></i>
                        </div>
                        <div>
                            <h4 class="fw-bold text-dark mb-1"><?= htmlspecialchars($siswa['nama']) ?></h4>
                            <span class="text-muted"><i class="bi bi-upc-scan me-1"></i> NISN: <?= htmlspecialchars($siswa['nisn']) ?></span>
                        </div>
                    </div>

                    <!-- Tabel Riwayat Pembayaran -->
                    <div class="card border-0 shadow-sm rounded-3 overflow-hidden">
                        <div class="card-header bg-white py-3 border-bottom d-flex align-items-center">
                            <i class="bi bi-clock-history text-primary me-2 fs-5"></i>
                            <h6 class="m-0 fw-bold text-dark">Riwayat Transaksi Pembayaran</h6>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th class="px-4 py-3" width="5%">No</th>
                                            <th class="py-3" width="20%">Tanggal Bayar</th>
                                            <th class="py-3" width="35%">Jenis Tagihan</th>
                                            <th class="py-3" width="20%">Nominal (Rp)</th>
                                            <th class="px-4 py-3 text-end" width="20%">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="border-top-0">
                                        <?php if (count($transaksi) > 0): ?>
                                            <?php $no = 1;
                                            foreach ($transaksi as $trx): ?>
                                                <tr>
                                                    <td class="px-4 text-muted"><?= $no++ ?></td>
                                                    <td class="fw-medium text-dark"><?= date('d M Y', strtotime($trx['tanggal_bayar'])) ?></td>
                                                    <td>
                                                        <span class="d-block fw-bold text-dark"><?= htmlspecialchars($trx['nama_pembayaran']) ?></span>
                                                    </td>
                                                    <td class="fw-bold text-dark">Rp <?= number_format($trx['jumlah_bayar'], 0, ',', '.') ?></td>
                                                    <td class="px-4 text-end">
                                                        <?php if ($trx['status'] === 'Lunas'): ?>
                                                            <span class="badge bg-success px-3 py-2 rounded-pill"><i class="bi bi-check-circle me-1"></i> Lunas</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-warning text-dark px-3 py-2 rounded-pill"><i class="bi bi-clock me-1"></i> Belum Lunas</span>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="5" class="text-center py-5 text-muted">
                                                    <i class="bi bi-folder-x fs-1 d-block mb-3 text-light"></i>
                                                    Belum ada riwayat pembayaran yang tercatat untuk siswa ini.
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        <?php endif; ?>

    </div>

    <!-- FOOTER -->
    <footer class="bg-white py-4 mt-auto border-top">
        <div class="container text-center">
            <p class="text-muted mb-0" style="font-size: 0.9rem;">
                &copy; <?= date('Y') ?> <strong><?= $nama_sekolah ?></strong>. Dikembangkan untuk administrasi sekolah yang lebih baik.
            </p>
        </div>
    </footer>

    <!-- Bootstrap JS Bundle -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>