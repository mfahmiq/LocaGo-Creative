# Sistem Pembayaran Administrasi

Aplikasi web untuk mengelola pembayaran administrasi sekolah dengan fitur manajemen siswa, user, dan laporan.

## Fitur Utama

- **Dashboard** - Ringkasan data pembayaran dan siswa
- **Manajemen Data Siswa** - Tambah, edit, hapus data siswa
- **Manajemen Transaksi Pembayaran** - Pencatatan dan pelacakan pembayaran
- **Jenis Pembayaran** - Kelola jenis-jenis pembayaran
- **Manajemen User** - Kelola akun pengguna (Admin, Kepala Sekolah)
- **Laporan** - Export data pembayaran ke Excel dan PDF
- **Profil Sekolah** - Kelola informasi sekolah

## Persyaratan Sistem

- PHP 7.4+
- MySQL/MariaDB
- Composer
- XAMPP atau server lokal lainnya

## Instalasi

1. **Clone atau download repository**

   ```bash
   cd xampp/htdocs/sistem-pembayaran-administrasi
   ```

2. **Install dependencies**

   ```bash
   composer install
   ```

3. **Setup Database**
   - Buat database baru di MySQL
   - Import file `db/schema.sql`

   ```bash
   mysql -u root -p nama_database < db/schema.sql
   ```

4. **Konfigurasi Koneksi Database**
   - Edit file `config/koneksi.php`
   - Sesuaikan host, username, password, dan nama database

5. **Akses Aplikasi**
   - Buka browser dan akses `http://localhost/sistem-pembayaran-administrasi`
   - Login dengan akun admin default

## Struktur Folder

```
├── assets/          # File CSS dan JavaScript
├── config/          # Konfigurasi database
├── db/              # File skema database
├── includes/        # Header dan footer
├── pages/           # Halaman aplikasi
│   ├── admin/       # Halaman untuk admin
│   └── kepala/      # Halaman untuk kepala sekolah
├── vendor/          # Dependencies dari Composer
├── index.php        # Halaman utama
├── login.php        # Login page
└── logout.php       # Logout action
```

## Penggunaan

### Login

- Masuk ke aplikasi menggunakan username dan password yang sudah didaftarkan
- Setiap user memiliki role yang menentukan akses yang diberikan

### Dashboard

- Melihat ringkasan data pembayaran dan siswa

### Manajemen Data

- Tambah, edit, atau hapus data melalui menu yang tersedia
- Export data ke Excel atau PDF

## Teknologi yang Digunakan

- PHP (Backend)
- MySQL (Database)
- Bootstrap (Frontend Framework)
- PhpOffice/PhpSpreadsheet (Export Excel)
- Dompdf (Export PDF)

## License

Proprietary - Hak cipta dilindungi

## Dukungan

Untuk pertanyaan atau laporan bug, silakan hubungi administrator sistem.
