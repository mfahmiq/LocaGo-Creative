<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Admin - SPP Sekolah</title>

    <!-- Memanggil CSS Bootstrap Lokal -->
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/bootstrap.min.css">

    <!-- Bootstrap Icons (via CDN untuk icon menu) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8f9fc;
            overflow-x: hidden;
        }

        /* Layout Wrapper */
        #wrapper {
            display: flex;
            width: 100%;
            align-items: stretch;
        }

        /* Sidebar Styling */
        #sidebar {
            min-width: 260px;
            max-width: 260px;
            background: #ffffff;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            transition: all 0.3s ease-in-out;
            z-index: 1040;
            display: flex;
            flex-direction: column;
            height: 100vh;
            position: sticky;
            top: 0;
        }

        #sidebar.toggled {
            margin-left: -260px;
        }

        .sidebar-brand {
            height: 4.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            font-weight: 800;
            color: #4e73df;
            text-decoration: none;
            border-bottom: 1px solid #eaecf4;
            letter-spacing: 0.5px;
        }

        .nav-item .nav-link {
            color: #858796;
            font-weight: 600;
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.2s ease-in-out;
            border-left: 4px solid transparent;
        }

        /* Efek Hover & Menu Aktif */
        .nav-item .nav-link:hover,
        .nav-item .nav-link.active {
            color: #4e73df;
            background-color: #f8f9fc;
            border-left: 4px solid #4e73df;
        }

        .nav-item .nav-link i {
            font-size: 1.2rem;
        }

        /* Content Wrapper */
        #content-wrapper {
            width: 100%;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Topbar */
        .topbar {
            height: 4.5rem;
            background-color: #ffffff;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            display: flex;
            align-items: center;
            padding: 0 1.5rem;
            justify-content: space-between;
            z-index: 1030;
        }

        #sidebarToggle {
            background: none;
            border: none;
            color: #4e73df;
            font-size: 1.8rem;
            cursor: pointer;
            transition: transform 0.2s;
        }

        #sidebarToggle:hover {
            transform: scale(1.1);
        }

        .main-content {
            flex-grow: 1;
            padding: 2rem 1.5rem;
        }

        /* Responsive Mobile */
        @media (max-width: 768px) {
            #sidebar {
                margin-left: -260px;
                position: fixed;
            }

            #sidebar.toggled {
                margin-left: 0;
            }
        }
    </style>
</head>

<body>

    <div id="wrapper">
        <!-- SIDEBAR -->
        <nav id="sidebar">
            <a class="sidebar-brand" href="#">
                <i class="bi bi-shield-check me-2"></i> SIP-AS
            </a>
            <div class="nav flex-column mt-3 w-100">

                <?php
                // Mendapatkan URL saat ini untuk fitur active menu
                $current_url = $_SERVER['REQUEST_URI'];
                ?>

                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin1'): ?>
                    <!-- Menu Admin 1 (Bendahara) -->
                    <div class="nav-item">
                        <a class="nav-link <?= strpos($current_url, 'dashboard.php') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>pages/admin/dashboard.php">
                            <i class="bi bi-grid-fill"></i> Dashboard
                        </a>
                    </div>
                    <div class="nav-item">
                        <a class="nav-link <?= strpos($current_url, 'data-siswa') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>pages/admin/data-siswa/index.php">
                            <i class="bi bi-people-fill"></i> Data Siswa
                        </a>
                    </div>
                    <div class="nav-item">
                        <a class="nav-link <?= strpos($current_url, 'jenis-pembayaran') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>pages/admin/jenis-pembayaran/index.php">
                            <i class="bi bi-tags-fill"></i> Jenis Pembayaran
                        </a>
                    </div>
                    <div class="nav-item">
                        <a class="nav-link <?= strpos($current_url, 'transaksi-pembayaran') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>pages/admin/transaksi-pembayaran/index.php">
                            <i class="bi bi-wallet2"></i> Transaksi
                        </a>
                    </div>
                    <div class="nav-item">
                        <a class="nav-link <?= strpos($current_url, 'laporan') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>pages/admin/laporan/index.php">
                            <i class="bi bi-file-earmark-bar-graph-fill"></i> Laporan
                        </a>
                    </div>
                    <div class="nav-item">
                        <a class="nav-link <?= strpos($current_url, 'kelola-user') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>pages/admin/kelola-user/index.php">
                            <i class="bi bi-person-badge-fill"></i> Kelola User
                        </a>
                    </div>
                    <div class="nav-item">
                        <a class="nav-link <?= strpos($current_url, 'profil-sekolah') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>pages/admin/profil-sekolah/edit-profil.php">
                            <i class="bi bi-building-fill-gear"></i> Profil Sekolah
                        </a>
                    </div>

                <?php elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'admin2'): ?>
                    <!-- Menu Admin 2 (Kepala Sekolah) -->
                    <div class="nav-item">
                        <a class="nav-link <?= strpos($current_url, 'dashboard.php') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>pages/kepala/dashboard.php">
                            <i class="bi bi-grid-fill"></i> Dashboard
                        </a>
                    </div>
                    <div class="nav-item">
                        <a class="nav-link <?= strpos($current_url, 'laporan') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>pages/kepala/laporan/index.php">
                            <i class="bi bi-file-earmark-bar-graph-fill"></i> Laporan
                        </a>
                    </div>
                    <div class="nav-item">
                        <a class="nav-link <?= strpos($current_url, 'kelola-user') !== false ? 'active' : '' ?>" href="<?= BASE_URL ?>pages/kepala/kelola-user/index.php">
                            <i class="bi bi-person-badge-fill"></i> Kelola User
                        </a>
                    </div>
                <?php endif; ?>

            </div>
        </nav>

        <!-- KONTEN UTAMA -->
        <div id="content-wrapper">

            <!-- Topbar -->
            <header class="topbar">
                <button id="sidebarToggle">
                    <i class="bi bi-list"></i>
                </button>

                <div class="d-flex align-items-center gap-3">
                    <div class="text-end d-none d-md-block">
                        <div class="fw-bold text-dark" style="font-size: 0.95rem;">
                            <?= isset($_SESSION['username']) ? htmlspecialchars(ucfirst($_SESSION['username'])) : 'Admin' ?>
                        </div>
                        <div class="text-muted" style="font-size: 0.8rem;">
                            <?= (isset($_SESSION['role']) && $_SESSION['role'] === 'admin1') ? 'Bendahara Sekolah' : 'Kepala Sekolah' ?>
                        </div>
                    </div>

                    <!-- Dropdown Profil -->
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="dropdownUser" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php $inisial = isset($_SESSION['username']) ? urlencode($_SESSION['username']) : 'A'; ?>
                            <img src="https://ui-avatars.com/api/?name=<?= $inisial ?>&background=4e73df&color=fff&bold=true" alt="Profile" width="40" height="40" class="rounded-circle shadow-sm">
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2" aria-labelledby="dropdownUser">
                            <li><a class="dropdown-item text-primary fw-semibold" href="<?= BASE_URL ?>pages/edit-admin.php">
                                    <i class="bi bi-person-circle me-2"></i>Edit Profil
                                </a></li>
                            <li><a class="dropdown-item text-danger fw-semibold" href="<?= BASE_URL ?>logout.php">
                                    <i class="bi bi-box-arrow-right me-2"></i>Keluar
                                </a></li>
                        </ul>
                    </div>
                </div>
            </header>

            <!-- Container Isi Halaman -->
            <main class="main-content">