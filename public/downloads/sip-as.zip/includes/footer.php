</main> <!-- Penutup .main-content -->

<!-- FOOTER -->
<footer class="bg-white text-center py-3 mt-auto shadow-sm" style="border-top: 1px solid #eaecf4;">
    <p class="mb-0 text-muted fw-medium" style="font-size: 0.85rem;">
        &copy; <?= date('Y') ?> Sistem Pembayaran Administrasi Sekolah.
    </p>
</footer>

</div> <!-- Penutup #content-wrapper -->
</div> <!-- Penutup #wrapper -->

<!-- Memanggil JS Bootstrap Lokal -->
<script src="<?= BASE_URL ?>assets/js/bootstrap.bundle.min.js"></script>

<!-- Script untuk interaksi Sidebar -->
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');

        // 1. Fungsi klik tombol toggle
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function(event) {
                event.preventDefault();
                sidebar.classList.toggle('toggled');
            });
        }

        // 2. Fungsi klik di luar sidebar untuk menutup (Khusus Mobile)
        document.addEventListener('click', function(event) {
            const isClickInsideSidebar = sidebar.contains(event.target);
            const isClickOnToggle = sidebarToggle.contains(event.target);

            // Cek apakah layar berukuran mobile (lebar <= 768px)
            if (window.innerWidth <= 768) {
                // Jika klik bukan di sidebar, bukan di tombol, dan sidebar sedang terbuka
                if (!isClickInsideSidebar && !isClickOnToggle && sidebar.classList.contains('toggled')) {
                    sidebar.classList.remove('toggled');
                }
            }
        });
    });
</script>

</body>

</html>