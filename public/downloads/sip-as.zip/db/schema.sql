-- Buat Database
CREATE DATABASE IF NOT EXISTS pembayaran_administrasi_db;
USE pembayaran_administrasi_db;

-- 1. Tabel Kelola User
CREATE TABLE users (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    kontak VARCHAR(15) NOT NULL,
    role ENUM('admin1', 'admin2') NOT NULL,
    UNIQUE KEY idx_username (username)
);

-- 2. Tabel Profil Sekolah
CREATE TABLE profil_sekolah (
    id_profil INT AUTO_INCREMENT PRIMARY KEY,
    nama_sekolah VARCHAR(100) NOT NULL,
    alamat TEXT NOT NULL,
    telepon VARCHAR(15) NOT NULL,
    email_sekolah VARCHAR(50) NOT NULL
);

-- 3. Tabel Data Siswa
CREATE TABLE data_siswa (
    nisn VARCHAR(20) PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    jenis_kelamin ENUM('L', 'P') NOT NULL,
    tempat_lahir VARCHAR(50) NOT NULL,
    tanggal_lahir DATE NOT NULL,
    INDEX idx_nama_siswa (nama)
);

-- 4. Tabel Jenis Pembayaran
CREATE TABLE jenis_pembayaran (
    id_jenis INT AUTO_INCREMENT PRIMARY KEY,
    nama_pembayaran VARCHAR(100) NOT NULL,
    nominal DECIMAL(15,2) NOT NULL,
    keterangan TEXT NOT NULL,
    INDEX idx_nama_pembayaran (nama_pembayaran)
);

-- 5. Tabel Transaksi Pembayaran
CREATE TABLE transaksi_pembayaran (
    id_transaksi INT AUTO_INCREMENT PRIMARY KEY,
    tanggal_bayar DATE NOT NULL,
    nisn VARCHAR(20) NOT NULL,
    id_jenis INT NOT NULL,
    jumlah_bayar DECIMAL(15,2) NOT NULL,
    status ENUM('Lunas', 'Belum Lunas') NOT NULL,
    FOREIGN KEY (nisn) REFERENCES data_siswa(nisn) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_jenis) REFERENCES jenis_pembayaran(id_jenis) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_tanggal_bayar (tanggal_bayar),
    INDEX idx_status_pembayaran (status)
);

-- 6. Tabel Laporan (Untuk pencatatan riwayat tutup buku)
CREATE TABLE laporan (
    id_laporan INT AUTO_INCREMENT PRIMARY KEY,
    jenis_laporan VARCHAR(100) NOT NULL,
    periode VARCHAR(50) NOT NULL,
    tanggal_dibuat TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_filter_laporan (jenis_laporan, periode)
);