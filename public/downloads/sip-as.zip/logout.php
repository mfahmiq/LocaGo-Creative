<?php
// Jalankan session untuk bisa mengaksesnya
session_start();

// Load koneksi untuk mendapatkan BASE_URL (sesuaikan path-nya dengan struktur folder Anda)
// Jika file logout.php ini ada di root folder, maka path-nya 'config/koneksi.php'
require_once 'config/koneksi.php';

// Kosongkan semua variabel session yang sedang aktif
$_SESSION = [];

// Hapus cookie session di browser (Langkah Keamanan Ekstra)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// 4. Hancurkan session secara permanen dari server
session_destroy();

// 5. Arahkan kembali ke halaman login dengan membawa pesan lewat URL
header("Location: " . BASE_URL . "login.php?status=logout");
exit;
