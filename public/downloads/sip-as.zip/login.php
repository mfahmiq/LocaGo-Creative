<?php
session_start();
require_once 'config/koneksi.php';

// Jika user sudah login, arahkan langsung ke dashboard masing-masing
if (isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in'] === true) {
    if ($_SESSION['role'] === 'admin1') {
        header("Location: " . BASE_URL . "pages/admin/dashboard.php");
    } else if ($_SESSION['role'] === 'admin2') {
        header("Location: " . BASE_URL . "pages/kepala/dashboard.php");
    }
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $error = 'Username dan Password wajib diisi!';
    } else {
        $pdo = getConnection();

        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username LIMIT 1");
            $stmt->execute([':username' => $username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {

                $_SESSION['is_logged_in'] = true;
                $_SESSION['id_user']      = $user['id_user'];
                $_SESSION['username']     = $user['username'];
                $_SESSION['role']         = $user['role'];

                if ($user['role'] === 'admin1') {
                    header("Location: " . BASE_URL . "pages/admin/dashboard.php");
                } else {
                    header("Location: " . BASE_URL . "pages/kepala/dashboard.php");
                }
                exit;
            } else {
                $error = 'Username atau Password salah!';
            }
        } catch (PDOException $e) {
            $error = "Terjadi kesalahan sistem: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Pembayaran Administrasi</title>
    <!-- Memanggil CSS Bootstrap -->
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/bootstrap.min.css">
    <style>
        body {
            /* Background gradient yang elegan dan lembut */
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        .login-card {
            width: 100%;
            max-width: 400px;
            border: none;
            border-radius: 1rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            /* Shadow halus */
            background-color: #ffffff;
            overflow: hidden;
        }

        .login-header {
            padding: 40px 30px 20px 30px;
            text-align: center;
        }

        .login-header h4 {
            font-weight: 700;
            color: #2c3e50;
            margin-bottom: 5px;
            letter-spacing: -0.5px;
        }

        .login-header p {
            color: #7f8c8d;
            font-size: 0.9rem;
            margin-bottom: 0;
        }

        .login-body {
            padding: 0 30px 40px 30px;
        }

        .form-floating>.form-control {
            border-radius: 0.5rem;
            border: 1px solid #dee2e6;
        }

        .form-floating>.form-control:focus {
            border-color: #0d6efd;
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.15);
        }

        .btn-login {
            border-radius: 0.5rem;
            padding: 0.8rem 1rem;
            font-weight: 600;
            font-size: 1rem;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(13, 110, 253, 0.3);
        }
    </style>
</head>

<body>

    <div class="login-card">
        <div class="login-header">
            <!-- Bisa diganti dengan tag <img> untuk logo sekolah nantinya -->
            <div class="mb-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="#0d6efd" class="bi bi-wallet2" viewBox="0 0 16 16">
                    <path d="M12.136.326A1.5 1.5 0 0 1 14 1.78V3h.5A1.5 1.5 0 0 1 16 4.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 13.5v-9a1.5 1.5 0 0 1 1.432-1.499L12.136.326zM5.562 3H13V1.78a.5.5 0 0 0-.621-.484L5.562 3zM1.5 4a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-13z" />
                </svg>
            </div>
            <h4>SIP-AS Admin</h4>
            <p>Sistem Informasi Pembayaran Administrasi Sekolah</p>
        </div>

        <div class="login-body">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert" style="border-radius: 0.5rem;">
                    <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <!-- Menggunakan Floating Labels bawaan Bootstrap -->
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="username" name="username" placeholder="Username" required autofocus>
                    <label for="username">Username</label>
                </div>

                <div class="form-floating mb-4">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                    <label for="password">Password</label>
                </div>

                <!-- Modifikasi: Menambahkan gap-2 dan tombol kembali -->
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary btn-login">Login Masuk</button>
                    <a href="<?= BASE_URL ?>index.php" class="btn btn-light btn-login text-secondary border">Kembali ke Portal</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Memanggil JS Bootstrap -->
    <script src="<?= BASE_URL ?>assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>