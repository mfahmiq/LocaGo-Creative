<?php
session_start();
include '../inc/functions.php';

// 🔒 wajib login admin
check_login_api('admin');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    if (!is_ajax_request()) {
        header("Location: ../admin/dashboard.php?notallowed=1");
        exit;
    }

    http_response_code(405);
    echo 'SESSION_EXPIRED';
    exit;
}
include '../koneksi/koneksi.php';
header('Content-Type: application/json');

$id    = $_POST['id_soal'] ?? '';
$kelas = $_POST['kelas'] ?? '';

if(empty($id) || empty($kelas)){
    echo json_encode(['status'=>'error','msg'=>'Data kosong']);
    exit;
}

$stmt = $koneksi->prepare("UPDATE soal SET kelas=? WHERE id_soal=?");
$stmt->bind_param("si", $kelas, $id);

if($stmt->execute()){
    echo json_encode(['status'=>'ok']);
}else{
    echo json_encode(['status'=>'error','msg'=>$stmt->error]);
}