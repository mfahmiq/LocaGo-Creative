// Basket
//==============================================================================

// Add to basket - the button carries its goods, so the markup around it is free
$(document).on('click', '.melbis_btn_add', function(event)
{
    var name = $(this).data('name');
    $.post('/?mod=melbis_basket',        
        { func: 'Plus', id: $(this).data('id') },
        function(data) 
        {             
            $('#melbis_win_basket .modal-body').html('<p>' + name + '</p><p>Product has been successfully added to your cart!</p>');
            $('#melbis_win_basket').modal('show');                       
        }
    );    
});

// Remove from basket
$('#melbis_win_checkout').on('click', '.melbis_btn_remove', function(event)
{    
    $.post('/?mod=melbis_basket',        
        { func: 'Minus', id: $(this).data('id') },
        function(data) 
        {                                     
            $('#melbis_order_goods').html(data);                           
        }
    );    
});

// Go to checkout
$('#melbis_btn_checkout').on('click', function(event)
{
    $('#melbis_win_basket').modal('hide');
    $('#melbis_win_checkout').modal('show');      
});

// Load checkout
$('#melbis_win_checkout').on('show.bs.modal', function (event) 
{
    $('.alert').hide();
    $('#melbis_order_fields').html('<li class="d-flex justify-content-center"><div class="spinner-border m-3"><span class="sr-only"></span></div></li>');
    $('#melbis_order_goods').html('<li class="d-flex justify-content-center"><div class="spinner-border m-3"><span class="sr-only"></span></div></li>');
    $('#melbis_order_options').html('<li class="d-flex justify-content-center"><div class="spinner-border m-3"><span class="sr-only"></span></div></li>');
    $.post('/?mod=melbis_basket', { func: 'Fields' }, function(data) { $('#melbis_order_fields').html(data); } );
    $.post('/?mod=melbis_basket', { func: 'Goods' }, function(data) { $('#melbis_order_goods').html(data); } );
    $.post('/?mod=melbis_basket', { func: 'Options' }, function(data) { $('#melbis_order_options').html(data); } );       
});


// Finish
$('#melbis_btn_finish').on('click', function(event)
{
    for( var item of $('#melbis_form_order select') )
    { 
        $(item).prev('input').val($('option:selected', $(item)).text());
    }
        
    var form = $('#melbis_form_order').melbis_serial();
    form.func = 'Save';
    $.post('/?mod=melbis_basket', form, function(data) 
        {                     
            if ( data.result != 'OK' )
            {
                $('.alert span').html('[' + data.result + '] ' + data.message);
                $('.alert').addClass('show').show();        
            }
            else
            {
                $('#melbis_win_checkout').modal('hide');    
                $('#melbis_win_finish').modal('show');
            }         
        }, 
        'json');                
});
