<?php
/***************************************************************************************************
 * @version 6.5.1.550 @ 2026-11-25
 * @copyright 2002-2026 Melbis
 * @link https://melbis.com
 * @author Dmytro Kasianov
 **************************************************************************************************
 *
 * People         - The people with their tables
 * Login          - Weighs a login
 *
 **************************************************************************************************/


// Name space
namespace MELBIS_AGENT_USER;

// Libraries
use MELBIS_INC_AGENT_TABLE as TABLE;

// The columns a read gives
const FIELDS_READ = "id, group_id, login, name, params, is_blocked";


// ————— Public —————
//==================================================================================================

// People
//==================================================================================================


/**
 * Function CmdListCut
 **/
function CmdListCut($mUserId, $mParam)
{
    return People(['user_group']);
}


/**
 * Function CmdListFull
 **/
function CmdListFull($mUserId, $mParam)
{
    $more = ['user_group', 'oper', 'oper_right', 'oper_table',
             'user_key_set', 'user_group_key_set'];

    return People($more);
}


/**
 * Function CmdAdd
 **/
function CmdAdd($mUserId, $mParam)
{
    $weighed = Login($mParam['login'], 0);
    if ( !$weighed['result'] ) return $weighed;

    // No password here: the owner gives it in the Program
    return TABLE\Add($mUserId, 'user', $mParam);
}


/**
 * Function CmdUpdate
 **/
function CmdUpdate($mUserId, $mParam)
{
    $ids = $mParam['id'];

    // A login weighed against taken
    if ( isset($mParam['login']) )
    {
        if ( count($ids) > 1 )
        {
            return [
                'result'  => false,
                'message' => 'A login belongs to one person'
                ];
        }

        $weighed = Login($mParam['login'], reset($ids));
        if ( !$weighed['result'] ) return $weighed;

        // The key is made of the login and the password together
        $user_id = reset($ids);
        $login = $mParam['login'];
        $command = "SELECT COUNT(*)
                      FROM {DBNICK}_user
                     WHERE id = :ID
                       AND login <> :LOGIN
                       AND pass_key <> ''
                   ";
        $param_user = [
            'id'    => $user_id,
            'login' => $login
            ];
        $keyed = (int)MELBIS()->SqlSelectValue(__LINE__, $command, 0, $param_user);
        if ( $keyed > 0 )
        {
            return [
                'result'  => false,
                'message' => 'A new login goes with a new password, given in [MShop:FUserRightUser:LPass]'
                ];
        }
    }

    // The branch under the session
    if ( $mParam['is_blocked'] ?? false )
    {
        if ( in_array($mUserId, $ids) )
        {
            return [
                'result'  => false,
                'message' => 'This session does not block itself'
                ];
        }

        if ( in_array(1, $ids) )
        {
            return [
                'result'  => false,
                'message' => 'The owner [1] is not blocked'
                ];
        }
    }

    return TABLE\Update($mUserId, 'user', $ids, $mParam);
}


/**
 * Function CmdRemove
 **/
function CmdRemove($mUserId, $mParam)
{
    $ids = $mParam['id'];

    if ( in_array($mUserId, $ids) )
    {
        return [
            'result'  => false,
            'message' => 'This session does not remove itself'
            ];
    }

    // The owner stays, as in program
    if ( in_array(1, $ids) )
    {
        return [
            'result'  => false,
            'message' => 'The owner [1] is not removed'
            ];
    }

    return TABLE\Remove($mUserId, 'user', $ids, $mParam);
}


// Groups
//==================================================================================================


/**
 * Function CmdGroupAdd
 **/
function CmdGroupAdd($mUserId, $mParam)
{
    return TABLE\Add($mUserId, 'user_group', $mParam);
}


/**
 * Function CmdGroupUpdate
 **/
function CmdGroupUpdate($mUserId, $mParam)
{
    return TABLE\Update($mUserId, 'user_group', $mParam['id'], $mParam);
}


/**
 * Function CmdGroupRemove
 **/
function CmdGroupRemove($mUserId, $mParam)
{
    $list = implode(',', $mParam['id']);

    // A group with people stays
    $command = "SELECT COUNT(*)
                  FROM {DBNICK}_user
                 WHERE group_id IN ( $list )
               ";
    $people = (int)MELBIS()->SqlSelectValue(__LINE__, $command, 0);

    if ( $people > 0 )
    {
        return [
            'result'  => false,
            'message' => $people.' person(s) would lose their group'
            ];
    }

    return TABLE\Remove($mUserId, 'user_group', $mParam['id'], $mParam);
}


/**
 * Function CmdGroupPos
 **/
function CmdGroupPos($mUserId, $mParam)
{
    return TABLE\Pos($mUserId, 'user_group', [], $mParam);
}


// Rights
//==================================================================================================


/**
 * Function CmdRightAdd
 **/
function CmdRightAdd($mUserId, $mParam)
{
    // A right names one owner
    $user_id = $mParam['user_id'] ?? 0;
    $group_id = $mParam['group_id'] ?? 0;
    if ( $user_id == 0 && $group_id == 0 )
    {
        return [
            'result'  => false,
            'message' => 'Name user_id or group_id'
            ];
    }

    return TABLE\Add($mUserId, 'oper_right', $mParam);
}


/**
 * Function CmdRightUpdate
 **/
function CmdRightUpdate($mUserId, $mParam)
{
    return TABLE\Update($mUserId, 'oper_right', $mParam['id'], $mParam);
}


/**
 * Function CmdRightRemove
 **/
function CmdRightRemove($mUserId, $mParam)
{
    $mParam['apply'] = true;
    return TABLE\Remove($mUserId, 'oper_right', $mParam['id'], $mParam);
}


// Options
//==================================================================================================


/**
 * Function CmdKeyAdd
 **/
function CmdKeyAdd($mUserId, $mParam)
{
    return TABLE\KeySetAdd($mUserId, 'user', $mParam['user_id'], $mParam);
}


/**
 * Function CmdKeyUpdate
 **/
function CmdKeyUpdate($mUserId, $mParam)
{
    return TABLE\KeySetUpdate($mUserId, 'user', $mParam['id'], $mParam);
}


/**
 * Function CmdKeyRemove
 **/
function CmdKeyRemove($mUserId, $mParam)
{
    return TABLE\KeySetRemove($mUserId, 'user', $mParam['id']);
}


// Group options
//==================================================================================================


/**
 * Function CmdGroupKeyAdd
 **/
function CmdGroupKeyAdd($mUserId, $mParam)
{
    return TABLE\KeySetAdd($mUserId, 'user_group', $mParam['user_group_id'], $mParam);
}


/**
 * Function CmdGroupKeyUpdate
 **/
function CmdGroupKeyUpdate($mUserId, $mParam)
{
    return TABLE\KeySetUpdate($mUserId, 'user_group', $mParam['id'], $mParam);
}


/**
 * Function CmdGroupKeyRemove
 **/
function CmdGroupKeyRemove($mUserId, $mParam)
{
    return TABLE\KeySetRemove($mUserId, 'user_group', $mParam['id']);
}


// ————— Private —————
//==================================================================================================


/**
 * Function People
 **/
function People($mMore)
{
    // Read by name of column
    $fields = FIELDS_READ;

    $command = "SELECT $fields
                  FROM {DBNICK}_user
               ";
    $users = MELBIS()->SqlSelect(__LINE__, $command);

    $said = TABLE\Read($mMore);
    $tables = $said['tables'];
    $tables['user'] = $users;

    return [
        'result'  => true,
        'message' => 'The people of the shop',
        'tables'  => $tables
        ];
}


/**
 * Function Login
 **/
function Login($mLogin, $mSelfId)
{
    // The shape, then the taken
    $login = trim((string)$mLogin);
    $is_clean = preg_match('/^[a-z0-9_]+$/i', $login);
    if ( !$is_clean )
    {
        return [
            'result'  => false,
            'message' => 'A login takes latin, digits, underscore'
            ];
    }

    $command = "SELECT id
                  FROM {DBNICK}_user
                 WHERE login = :LOGIN
                   AND id <> :SELF_ID
               ";
    $param_login = [
        'login'   => $login,
        'self_id' => $mSelfId
        ];
    $busy = MELBIS()->SqlSelectValue(__LINE__, $command, 0, $param_login);
    if ( $busy != 0 )
    {
        return [
            'result'  => false,
            'message' => 'The login ['.$login.'] is taken'
            ];
    }

    return [
        'result' => true
        ];
}


?>
