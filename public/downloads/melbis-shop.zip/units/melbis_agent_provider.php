<?php
/***************************************************************************************************
 * @version 6.5.1.550 @ 2026-11-25
 * @copyright 2002-2026 Melbis
 * @link https://melbis.com
 * @author Dmytro Kasianov
 **************************************************************************************************/


// Name space
namespace MELBIS_AGENT_PROVIDER;

// Libraries
use MELBIS_INC_AGENT_TABLE as TABLE;


// ————— Public —————
//==================================================================================================

// Providers
//==================================================================================================


/**
 * Function CmdListCut
 **/
function CmdListCut($mUserId, $mParam)
{
    $said = TABLE\Read(['provider_group', 'provider']);

    // Temporary: provider columns cut
    $columns = ['id', 'group_id', 'skey', 'name', 'pos'];
    $keep = array_flip($columns);
    foreach ( $said['tables']['provider'] as $num => $row )
    {
        $said['tables']['provider'][$num] = array_intersect_key($row, $keep);
    }

    return $said;
}


/**
 * Function CmdListFull
 **/
function CmdListFull($mUserId, $mParam)
{
    $tables = ['provider_group', 'provider', 'provider_stock', 'provider_brand', 'provider_key_set', 'provider_stock_key_set'];

    return TABLE\Read($tables);
}


/**
 * Function CmdAdd
 **/
function CmdAdd($mUserId, $mParam)
{
    return TABLE\Add($mUserId, 'provider', $mParam);
}


/**
 * Function CmdUpdate
 **/
function CmdUpdate($mUserId, $mParam)
{
    return TABLE\Update($mUserId, 'provider', $mParam['id'], $mParam);
}


/**
 * Function CmdRemove
 **/
function CmdRemove($mUserId, $mParam)
{
    return TABLE\Remove($mUserId, 'provider', $mParam['id'], $mParam);
}


/**
 * Function CmdPos
 **/
function CmdPos($mUserId, $mParam)
{
    return TABLE\Pos($mUserId, 'provider', [], $mParam);
}


// Groups
//==================================================================================================


/**
 * Function CmdGroupAdd
 **/
function CmdGroupAdd($mUserId, $mParam)
{
    return TABLE\Add($mUserId, 'provider_group', $mParam);
}


/**
 * Function CmdGroupUpdate
 **/
function CmdGroupUpdate($mUserId, $mParam)
{
    return TABLE\Update($mUserId, 'provider_group', $mParam['id'], $mParam);
}


/**
 * Function CmdGroupRemove
 **/
function CmdGroupRemove($mUserId, $mParam)
{
    return TABLE\Remove($mUserId, 'provider_group', $mParam['id'], $mParam);
}


/**
 * Function CmdGroupPos
 **/
function CmdGroupPos($mUserId, $mParam)
{
    return TABLE\Pos($mUserId, 'provider_group', [], $mParam);
}


// Warehouses
//==================================================================================================


/**
 * Function CmdStockAdd
 **/
function CmdStockAdd($mUserId, $mParam)
{
    return TABLE\Add($mUserId, 'provider_stock', $mParam);
}


/**
 * Function CmdStockUpdate
 **/
function CmdStockUpdate($mUserId, $mParam)
{
    return TABLE\Update($mUserId, 'provider_stock', $mParam['id'], $mParam);
}


/**
 * Function CmdStockRemove
 **/
function CmdStockRemove($mUserId, $mParam)
{
    return TABLE\Remove($mUserId, 'provider_stock', $mParam['id'], $mParam);
}


/**
 * Function CmdStockPos
 **/
function CmdStockPos($mUserId, $mParam)
{
    // The warehouses of one provider
    $scope['provider_id'] = $mParam['provider_id'];

    return TABLE\Pos($mUserId, 'provider_stock', $scope, $mParam);
}


// Options
//==================================================================================================


/**
 * Function CmdKeyAdd
 **/
function CmdKeyAdd($mUserId, $mParam)
{
    return TABLE\KeySetAdd($mUserId, 'provider', $mParam['provider_id'], $mParam);
}


/**
 * Function CmdKeyUpdate
 **/
function CmdKeyUpdate($mUserId, $mParam)
{
    return TABLE\KeySetUpdate($mUserId, 'provider', $mParam['id'], $mParam);
}


/**
 * Function CmdKeyRemove
 **/
function CmdKeyRemove($mUserId, $mParam)
{
    return TABLE\KeySetRemove($mUserId, 'provider', $mParam['id']);
}


// Warehouse options
//==================================================================================================


/**
 * Function CmdStockKeyAdd
 **/
function CmdStockKeyAdd($mUserId, $mParam)
{
    return TABLE\KeySetAdd($mUserId, 'provider_stock', $mParam['provider_stock_id'], $mParam);
}


/**
 * Function CmdStockKeyUpdate
 **/
function CmdStockKeyUpdate($mUserId, $mParam)
{
    return TABLE\KeySetUpdate($mUserId, 'provider_stock', $mParam['id'], $mParam);
}


/**
 * Function CmdStockKeyRemove
 **/
function CmdStockKeyRemove($mUserId, $mParam)
{
    return TABLE\KeySetRemove($mUserId, 'provider_stock', $mParam['id']);
}


// Brands
//==================================================================================================


/**
 * Function CmdBrandAdd
 **/
function CmdBrandAdd($mUserId, $mParam)
{
    // A pair stands once, as the tick in the program
    $list = implode(',', $mParam['brand_id']);
    $command = "SELECT brand_id
                  FROM {DBNICK}_provider_brand
                 WHERE provider_id = :PROVIDER_ID
                   AND brand_id IN ( $list )
               ";
    $param_link = [
        'provider_id' => $mParam['provider_id']
        ];
    $linked = MELBIS()->SqlSelect(__LINE__, $command, $param_link);
    if ( count($linked) > 0 )
    {
        $brand_set = array_column($linked, 'brand_id');
        $said = implode(', ', $brand_set);

        return [
            'result'  => false,
            'message' => 'The brands ['.$said.'] are linked to this provider already'
            ];
    }

    return TABLE\AddBlock($mUserId, 'provider_brand', 'brand_id', $mParam['brand_id'], $mParam);
}


/**
 * Function CmdBrandUpdate
 **/
function CmdBrandUpdate($mUserId, $mParam)
{
    return TABLE\Update($mUserId, 'provider_brand', $mParam['id'], $mParam);
}


/**
 * Function CmdBrandRemove
 **/
function CmdBrandRemove($mUserId, $mParam)
{
    $mParam['apply'] = true;
    return TABLE\Remove($mUserId, 'provider_brand', $mParam['id'], $mParam);
}

?>
