<?php
/***************************************************************************************************
 * @version 6.5.1.550 @ 2026-11-25
 * @copyright 2002-2026 Melbis
 * @link https://melbis.com
 * @author Dmytro Kasianov
 **************************************************************************************************
 *
 * Main - Prints a section page
 *
 **************************************************************************************************/

namespace MELBIS_PAGE_TOPIC;

use MELBIS_INC_PAGE_MENU as PAGE_MENU;


// ————— Public —————
//==================================================================================================


/** 
 * Function Main
 **/
function Main($mVars)
{ 
    // Create 
    $tpl = MELBIS()->TplCreate();
            
    // Vars
    $id = $mVars['id'];
    
    // Sub topic 
    PAGE_MENU\Sub($id);
    
    $command = "SELECT s.id 
                  FROM {DBNICK}_topic_sub t_sub
                  JOIN {DBNICK}_topic t  
                    ON t_sub.id = t.id
                  JOIN {DBNICK}_topic_store ts
                    ON ts.topic_id = t.id
                  JOIN {DBNICK}_store s
                    ON ts.store_id = s.id
                 WHERE s.no_visible = 0 
              GROUP BY s.id
              ORDER BY MIN(t.absindex), MIN(ts.pos)
                 LIMIT 100 
                ";                    
    $goods = MELBIS()->SqlSelect(__LINE__, $command);     
    
    // Goods
    MELBIS()->TplAssign($tpl, 'GOODS', $goods);   
                                                         
    // Save store for static      
    $ids = array_column($goods, 'id');
    MELBIS()->EnumSet('store', $ids);

    // Final
    return MELBIS()->TplFinal($tpl, 'main');
} 



?>
