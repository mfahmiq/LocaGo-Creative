# Server

The **"Server"** window manages the store's server directly over SSH: it installs and updates it, shows its state, runs commands, transfers files, and edits configuration files. Everything is done as **root**, so the section is available to the store owner and is meant for one-off jobs rather than for everyday operation.

The progress of any operation is visible in the **log** at the bottom of the window; the **"Save log"** button writes it out to a text file. The connection is opened for the duration of the operation and closed when it finishes.

## Connection

The **"Connection"** tab holds the parameters shared by the whole window: the server's **IP address**, the **root password**, and the store's **domain name**. The password is not saved: the field is cleared when the window closes.

The **"Allow the AI assistant to access the server while this window is open"** checkbox lets the AI assistant onto the server: it runs commands and transfers files as root by itself instead of dictating them to you. The program gives it the address and the password only while the window is open, the password is entered and the checkbox is ticked; when the window closes, the checkbox is cleared. The assistant never sees the password itself, and Claude Code shows you each of its actions on the server for confirmation. In detail — "[Server](../MCP/remote.md)" in the section about the MCP server.

## Installation

The **"Installation"** tab, the **"Install server"** button — a full automatic installation: the application downloads the project's setup script and deploys the server for the given domain and the current version of the platform.

> **Warning!** Installation deletes all current settings and store data. The
> application asks for confirmation, but once started the operation cannot be
> cancelled.

When the installation is over, the program writes the address `https://<domain>` into the connection parameters and opens the "[Installation](installation.md)" window by itself: there the parameters are checked and the store's tables are created.

The **"Enable Demo Mode"** button puts the `admin.here` file into the store's root and switches the store into demonstration mode — this is how access is brought back if the password has not been set or has been forgotten. While the mode is on, anyone who signs in becomes an administrator, so the program asks for confirmation. In detail — "[Demonstration Mode](installation.md#demo-mode)" in the "Installation" section.

## Maintenance

The **"Maintenance"** tab:

* **"Update server"** — updating the server to the version matching the current
  version of the application. The update removes the containers of services that
  are not in the Docker configuration file. The result is unpredictable if the server was
  configured by hand, so make a backup before updating.
* **"Status report"** — server diagnostics. It changes nothing and only writes
  information about the state of the store's services and the certificate's
  expiry date to the log.

## Console

The **"Console"** tab runs arbitrary commands: a command is typed into the **"Run command"** field and sent with the **"Send"** button or the Enter key, and the reply goes to the log.

Files are transferred here as well. The full path to the file from `/` is typed into the **"File on the server"** field:

* **"Get File"** — downloads the file; the program asks where to save it on the
  computer.
* **"Send File"** — the program asks which file on the computer to send and writes
  it to this path. The file is created or replaced as a whole, without
  confirmation and without a backup copy.

The **"Inside the web container"** checkbox moves both the command and the file from the server into the store's container, where they work as the web server's user — this is how the engine's environment is checked (versions, file permissions, availability of PHP extensions). The path to the file is then given inside the container. The site root there is `/var/www/html`, the same folder as `/var/melbis/www` on the server. The exception is the engine code in `core/`: it comes from the image, and anything written there is lost when the server restarts.

> **Careful!** Without this checkbox the command runs and the file is written on
> the server as root. A new file in the site folder gets root as its owner: the
> engine will read it but cannot change it until the server is restarted or
> updated. Site files are easier to send with the checkbox.

## Settings

The **"Settings"** tab edits the server's configuration files: **Nginx**, the **MySQL database**, and the **Docker containers**. The order of work: choose the file, press **"Load from server"**, edit the text, press **"Save to server"**.

Only the file that was loaded in this same window can be saved — this rules out writing your edits into someone else's file. The server keeps the previous contents next to it with the `.bak` extension, so one step back is always available.

The **"Restart server"** button stops and starts the store's containers again — this is what applies the edits you have made. The containers of services that are not in the Docker configuration file are removed. The store is unavailable for that time. After the start, the program gives all the site's files back to their owner — the web server's user.

> **Careful!** A mistake in a configuration file can stop the store from working.

## What Stands on the Server After Installation

This is how the server looks right after the installation from the program. A real store server may be arranged differently: other versions, edits of one's own in the configuration files, an external database, several sites on one machine. So every value below is a sample rather than a fact about your server until it has been checked on the "Settings" tab.

The installation, update and report scripts the program does not keep. At the press of a button it sends the server one command, and the server itself downloads `setup.sh`, `update.sh` or `verify.sh` from the branch of its own version (`v<version>`) of the public repository [melbis/melbis-shop](https://github.com/melbis/melbis-shop). The `Dockerfile` is there as well — what the store's image is built from. If the server has no way out to GitHub, none of these buttons will work.

### The Folders

The whole household of the store lies in `/var/melbis`:

| Path | What it is |
|---|---|
| `www/` | the site's root: `index.php`, `units/`, `templates/`, `files/`, `config.json` |
| `db/` | the MySQL database files |
| `cache/` | a disk in RAM (1 GB) for the file cache; after a server restart it is empty, and that is normal |
| `trick/`, `log/` | the engine's `core/trick` and `core/log` folders; the apache and nginx logs are written there too |
| `certs/`, `certbot/` | the Let's Encrypt certificate and the folder for its verification |
| `docker-compose.yml`, `nginx.conf`, `my.cnf` | the three files that are edited on the "Settings" tab |

### The Containers

| Container | Image | What is inside |
|---|---|---|
| `melbis_db` | `mysql:8.4` | the database and the `melbis` user, the `utf8mb4` encoding |
| `melbis_shop` | `melbis/melbis-shop:v<version>` | `php:8.3-apache` with the curl, mysqli, xml, zip, iconv, gd, intl and APCu extensions and the ionCube Loader; the engine's core in the image is encoded |
| `melbis_proxy` | `nginx:latest` | ports 80 and 443, encryption, passing the requests on to apache |

nginx answers only to the domain given at installation — it is written in `server_name` in `nginx.conf`. A request with another name or to the bare IP address nginx drops without an answer, and an HTTPS one as early as the handshake. This way scanners that go through addresses do not reach the store. A new domain or subdomain is written into `server_name`, and a certificate is issued for it; the assistant will do this itself if it is let onto the server.

The containers have no logs of their own: everything is written as files into `/var/melbis/log`.

In the nginx log (`log/nginx/access.log`) the first field of a line is the visitor's address as the `CF-Connecting-IP` header named it, and the last one, in quotes, is the address the request actually came from. Through Cloudflare the last one is its server; on a direct visit the addresses match. Different addresses where the last one does not belong to Cloudflare mean the header was forged.

On the machine itself there are a 4 GB swap file, a daily log rotation that keeps seven copies, `fail2ban` and the `ufw` firewall with SSH, 80 and 443 open. The certificate is renewed by the system timer `certbot.timer`, and the hook `/etc/letsencrypt/renewal-hooks/deploy/melbis.sh` copies the new certificate into `/var/melbis/certs` after each renewal and rereads the nginx settings — without a restart, the site does not stop. There is one cron job: the store's `cron.php` once a minute (see "[Task Scheduler](../Dev/cron.md)").

### The Default Limits

| Limit | Value | Where it is set | What happens above it |
|---|---|---|---|
| request size | 64 MB | `client_max_body_size` in `nginx.conf` | nginx answers 413, the request does not reach PHP |
| upload size in PHP | 100 MB | `post_max_size`, `upload_max_filesize` of the image | unreachable: the nginx limit fires earlier |
| files in one request | 100 | `max_file_uploads` of the image | the request is rejected as a whole |
| script run time | 30 s | `max_execution_time` of the image | a long import breaks off, though the proxy waits 300 s |
| script memory | 512 MB | `memory_limit` of the image | the script stops with an error |
| APCu | 64 MB | `apc.shm_size` of the image | the static query cache and the Smart statistics live here; after a container restart it is empty |
| file cache | 1 GB | the disk in memory `/var/melbis/cache` | |
| MySQL index buffer | 512 MB | `key_buffer_size` in `my.cnf` | the main buffer of the MyISAM tables; `innodb_buffer_pool_size` (128 MB) hardly works here |
| nginx connections | 512 | `events` in `nginx.conf`, the nginx default | new visitors wait, the nginx error log shows `worker_connections are not enough` |
| Apache processes | 150 | `MaxRequestWorkers` of the image | requests wait their turn at nginx |

The installation is designed for a small store and for a minimum of looking after, so its limits work as a brake. A wave of requests from a bot or an attack runs into them, and the server fends it off instead of bringing the database down with a thousand simultaneous queries.

When the store grows, the limits are raised deliberately and in this order: first the resources — the hosting plan; then protection against bots in front of the site — Cloudflare or per-address limits in nginx; and only then the nginx connections, the Apache processes and the MySQL buffers. Without protection, raised limits will let the same attack straight into the database.

The memory of a minimal server is already spread out, and the reserve is held by the swap. Raising the MySQL buffers "for speed" on such a machine is a straight path to the system starting to stop processes. Resources are added by changing the hosting plan, not by editing `my.cnf`.
