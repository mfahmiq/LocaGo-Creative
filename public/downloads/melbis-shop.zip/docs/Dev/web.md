# Web Modules

Web modules are a special integration mechanism between the Melbis server platform and its Windows client, Melbis Shop. The core idea: a full-featured Chromium-based browser is embedded inside the application, capable of opening website pages directly within the application's windows and communicating with them in both directions — passing the manager's current working context to the server and receiving results back. A developer creates a standard Melbis module, and the application opens it inside its own window.

This allows extending the application's functionality without modifying its code: analytics, reports, management tools — all of this can be implemented in PHP and connected through settings.

---

## Embedded Web Modules

Embedded modules work directly inside the application's working windows — the windows of products, orders, customers, the scheduler and translations. To open an embedded web module in any of these windows, press `Ctrl+W` — a panel with an embedded browser will appear.

The key feature: when a manager navigates through records (selects a product, opens an order, switches to a customer), the application **automatically** sends a POST request to the module with the current window's context. The module always knows which object the manager is currently working with and can display relevant information — without any additional actions on their part.

There can be multiple such modules for each section — they are switched using tabs. Access rights can be configured for each module: which user groups can see it.

**Examples of embedded modules for the "Products / Prices" section:**

- Viewing extended product information
- Product sales statistics
- Product inventory tracking
- Price change history

**Examples for the "Business / Orders" and "Business / Customers" sections:**

- Customer purchase history
- Sending SMS / E-mail
- Complaint management tools

### Configuration

Embedded modules are configured in the application: **"Development → Modules and Options", the "Embedded Modules" tab**. Select a place in the "Placement" list and add a module with the following parameters. A module of the "Products: everywhere" and "Orders: everywhere" places is visible in all the windows of its branch, a module of any other place only in its own window, and "Hidden" ones are shown nowhere.

- **Name** — displayed in the module list and on the tab in the panel.
- **Module URL** — the module's URL, e.g. `http://my-shop.com/?mod=melbis_web_sample`.
- **Key** — the module's symbolic code (e.g., `melbis_web_sample`). Used for access rights verification.
- **User identification required** — if this flag is enabled, the application additionally passes the `login`, `stamp` and `sign` fields in POST — the login, the time and the sign-in signature. This allows the module to authenticate the user and verify their permissions.

### Parameters Passed by the Application

With each request to an embedded module, the application sends a POST request with the current window's context. The `place` field is always sent — it is the key of the window or of its panel the module is opened from: by it a module of the "Products: everywhere" place learns which products window it works in. Any other field is sent only when its record is selected in the window; if several rows are selected, their numbers go separated by `;` in the field ending in `_set`.

| Window | `place` | Fields |
|---|---|---|
| "Placement", "Prices", "Browser", "Product Selection", "Descriptions" | `store_location`, `store_price`, `store_browse`, `store_select`, `store_frame` | `melbis` — an empty field that starts the window's request; `topic_id` — the section; `store_id` — the product; `store_set` — the selected products |
| "Descriptions", the attribute values panel | `store_frame_value` | the same fields plus `info_id` — the attribute, `info_value_id` — the value, `info_value_set` — the selected values |
| "Orders" | `order_list` | `order_id` — the order; `order_version_id` — the order version; `order_version_client_id` — the version's customer; `order_version_user_id` — the version's manager; `order_client_field_id` — the selected row of the order's customer fields; `order_store_id` — the selected row of the order's products; `order_option_id` — the selected row of the order's options; `order_set` — the selected orders |
| "Edit Order", the panels of the "Customer", "Products and Order Options" and "Web Module" tabs | `order_edit_client`, `order_edit_store`, `order_edit_service` | `order_id`, `parent_version_id` — the parent version, `order_version_id`, `order_version_client_id`, `order_version_user_id`, `order_client_field_id`, `client_field_id` — the customer field, `order_store_id`, `store_id` — the product of the selected row, `store_option_id` — the product option, `order_option_id` — the order option, and `order` — the whole order being edited |
| "Customers" | `client` | `client_id` — the customer; `client_field_id` — the selected row of the customer's fields; `client_set` — the selected customers |
| "Scheduler" | `schedule` | `melbis`; `task_id` — the task; `note_id` — the task's entry |
| "Translations" | `trans` | `melbis`; `trans_id` — the translations section; `origin_id` — the source string; `origin_set` — the selected strings; `lang_id` — the selected translation row, the number of a `trans_lang` row, not of a language |

`place` matches the key of the window's place in the "Placement" list everywhere except the panels: "Descriptions" has one place, `store_frame`, while the values panel sends `store_frame_value`; the order editor also has one place, `order_edit`, while each of its three panels sends a key of its own.

In "Descriptions", the numbers of products and values are numbers of the main catalog, not of the rows of the Personal Workspace. The `order` field of the "Edit Order" window is JSON with the order's unsaved rows: the keys `new_orders_version`, `new_orders_client_field`, `new_orders_store`, `new_orders_store_option` and `new_orders_option`, each holding a list of rows with all their fields.

Rows of options and fields with the "Do not display" flag come in `order` together with the rest, and `MELBIS_ORDER_UPDATE` writes into them the same way. The note of such an option is a place for the module's service data: the employee does not see it, and the order keeps it.

With the "User identification required" flag, `login`, `stamp` and `sign` are added to any set: `stamp` is the time in GMT, `sign` is a signature of the string `login|time|WEB` with a key computed from the password. The password itself never leaves the application. This is how a module's `$mVars` looks in the "Orders" window:

```php
// $mVars in the module:
[
    'get'  => ['mod' => 'melbis_web_sample'],
    'post' => [
        'order_id'                => '1',
        'place'                   => 'order_list',
        'order_version_id'        => '2',
        'order_version_client_id' => '1',
        'order_version_user_id'   => '1',
        'order_client_field_id'   => '3',
        'order_store_id'          => '2',
        'order_option_id'         => '3',
        'login'                   => 'admin',
        'stamp'                   => '2026-10-27 09:15:00',
        'sign'                    => 'RjaLSFiSrdVFBXJ/r+Ud+TtICKvNeF5s3s/hlQwXatv37woccBwsDvduIBM6fh0Pp2lJxA4PvA0zzwwCVYvODw==',
    ]
]
```

The AI assistant opens a module the same way — with the [`shop_module`](../MCP/shop_module.md) tool: it passes the window fields itself, and the MCP server adds the `login`, `stamp` and `sign` of the session's user.

### The User's Language

The application's browser works in the language chosen in the application and puts it first in the `Accept-Language` header of every request. The module learns it by the same method as the language of a storefront visitor (see "[Visitor](visitor.md)", the "Browser Language" section):

```php
$lang = MELBIS()->AgentLanguage(['ru', 'uk', 'en'], 'en');
```

An external module opened in an ordinary browser gets the language of that browser this way, so the same code works in both cases. When the AI assistant opens the module, there is no header, and the method returns the default value.

---

## The melbis_inc_logic_auth Library

For web modules, the standard demo store distribution includes the `melbis_inc_logic_auth` library. It handles all the boilerplate code: user authentication by signature (`login`, `stamp`, `sign`), storing the authentication state in a PHP session, checking access rights to the module, and routing POST calls between module functions.

**The central function — `MELBIS_INC_LOGIC_AUTH\Router($mModule, $mVars)`** — performs the following steps in order:

1. Checks whether a logout has been requested (`logout` in POST).
2. Authenticates the user: via `login`, `stamp` and `sign` from POST — through `SysUserSignCheck` — or from a previously saved session.
3. Verifies the user's right to access the given module (based on the permissions table in the database).
4. Writes global variables via `GlobalAssign('PAGE', [...])`, available in all templates: authentication status (`auth`), `user_id`, and `mod` — the URL of the current module. The `{PAGE:MOD}` variable is used in templates as the base URL for AJAX requests.
5. Routes the call: if the `func` parameter is passed in POST — calls the module function with that name (`GetCataloge`), passing it `$userId` and `$mVars`. Without `func`, `Page` is called. Any function other than `Page` works only after login and with the right to the module — otherwise the answer is `Access denied`.

Thanks to this, the entire main module function reduces to a single line:

```php
namespace MELBIS_WEB_SAMPLE;

use MELBIS_INC_LOGIC_AUTH as LOGIC_AUTH;

function Main($mVars)
{
    return LOGIC_AUTH\Router(MELBIS()->UnitName(), $mVars);
}
```

`MELBIS()->UnitName()` returns the name of the current module — it is passed to the router for rights verification and for finding the module's functions.

The function name arrives as data, from POST, so the router calls it through `UnitFunc`: it assembles the full name from the running module — `MELBIS_WEB_SAMPLE\GetCataloge`, and in a module of the former form, without a namespace, `MELBIS_WEB_SAMPLE_GetCataloge`. One and the same router serves both forms.

---

## Module Structure: the Page Function

The `Page` function outputs the module's page: the router calls it when `func` is not passed. It is the only function the router calls even without login — it is also the one that shows the authentication form. It receives `$mUserId` (or `null` if no login took place) and the full `$mVars` array.

```php
function Page($mUserId, $mVars)
{
    $tpl = MELBIS()->TplCreate();

    if ( $mUserId > 0 )
    {
        // Pass input variables to the template
        MELBIS()->TplAssign($tpl, 'VARS', var_export($mVars, true));

        // Pass order data for the reverse data transfer mechanism
        MELBIS()->TplAssign($tpl, 'ORDER', $mVars['post']['order'] ?? '{}');

        MELBIS()->TplParse($tpl, 'CONTENT', 'page');
    }
    else
    {
        // User is not authenticated — show the login form
        MELBIS()->TplAssign($tpl, 'ORDER', '{}');
        MELBIS()->TplParse($tpl, 'CONTENT', 'auth');
    }

    MELBIS()->GlobalAppend('PAGE:TITLE', 'Sample Web module');

    return MELBIS()->TplFinal($tpl, 'main');
}
```

The `auth.htm` template contains a call to the `melbis_web_auth` module — it renders the login form. After the form is submitted, the router `LOGIC_AUTH\Router` processes the POST again, authenticates the user, and this time `Page` parses the main `page.htm` template.

---

## AJAX Requests from the Template

For interactive actions within the module, JavaScript passes the `func` parameter in POST. The router will find and call the corresponding function — provided the user is authenticated and has access to the module.

In the template, the `{PAGE:MOD}` variable contains the ready-made URL of the current module (`/?mod=melbis_web_sample`) — it is convenient to use as the endpoint for all AJAX requests:

```javascript
$('#melbis_table_cataloge').bootstrapTable({
    url: '{PAGE:MOD}',
    method: 'post',
    queryParams: function(params) {
        params.func = 'GetCataloge';  // the router will call GetCataloge of this module
        return params;
    },
    pagination: true,
    sidePagination: 'server',
    pageSize: 20,
    sortName: 'absindex',
    sortOrder: 'asc'
});
```

On the PHP side, the function receives control only if the user is authenticated, executes the query, and returns JSON:

```php
function GetCataloge($mUserId, $mVars)
{
    $limit  = (int) $mVars['post']['limit'];
    $offset = (int) $mVars['post']['offset'];
    $sort   = preg_replace('/[^a-z_]/', '', $mVars['post']['sort']);
    $sort  .= ($mVars['post']['order'] == 'asc') ? ' ASC' : ' DESC';

    $command = "SELECT t.id, t.name, t.tlevel, COUNT(ts.id) AS amount
                  FROM {DBNICK}_topic t
             LEFT JOIN {DBNICK}_topic_store ts ON t.id = ts.topic_id
              GROUP BY t.id
              ORDER BY $sort";

    $data = MELBIS()->SqlSelectLimit(__LINE__, $command, $offset, $limit);

    return json_encode($data);
}
```

The same principle applies to any other module functions — searching, filtering, saving data to the database, sending notifications, and so on.

---

## Reverse Data Transfer to the Application

The most unique capability of embedded web modules is the ability to pass data **from the browser back to the Windows application** without additional HTTP requests.

The page sends the application a message with the `window.chrome.webview.postMessage` method: an object with the event name in the `event` field and the data in the `data` field.

```javascript
window.chrome.webview.postMessage({ event: 'MELBIS_ORDER_UPDATE', data: update });
```

The application understands three events:

| Event | Where it works | What the application does |
|---|---|---|
| `MELBIS_ORDER_UPDATE` | the order editing window | applies `data` to the fields of the order being edited |
| `MELBIS_ORDER_REFRESH` | the "Orders" window | loads the current order from the server anew, like the "Refresh Order" button |
| `MELBIS_PRINT` | any browser of the application | opens the Windows print dialog for the page |

The `window.chrome.webview` object exists only in the application's browser. A module that is also opened in an ordinary browser checks for it before sending (an example is in the "Printing" section below).

`MELBIS_ORDER_UPDATE` works while the order has not yet been saved. In other sections (products, customers), the web module writes changes directly to the database via the standard SQL parser methods when needed.

`MELBIS_ORDER_REFRESH` is needed by a module that has itself changed a saved order on the server: the "Orders" window shows its own copy of the order and will not reread it without a command. After the refresh the program sends the window's context to the module again, and the page loads anew. So the event is sent in answer to a manager's action, not when the page loads, otherwise the refresh goes round in circles. Which window the module is open in can be told by the `order` field: the order editing window always sends it, the "Orders" window never does.

A practical example: the module receives all the data of the open order from the application in JSON format, displays it in interactive tables, and allows the manager to edit individual fields directly in the browser.

```php
// PHP: retrieve the order data passed by the application and send it to the template
MELBIS()->TplAssign($tpl, 'ORDER', $mVars['post']['order'] ?? '{}');
```

```javascript
// Template: parse JSON and build tables
var melbis_order = {ORDER};

function melbis_init_back() {
    for (var table in melbis_order) {
        var data    = melbis_order[table];
        var columns = [];
        for (var c in data[0]) {
            columns.push({field: c, title: c});
        }
        $('.melbis_table_order[data-table="' + table + '"]').bootstrapTable({
            columns: columns,
            data:    data
        });
    }
}

// Click on a cell — edit dialog
$('.melbis_table_order').on('click-cell.bs.table', function(event, field, value, row) {
    var table = event.target.dataset.table;
    bootbox.prompt({
        title: 'Edit value of "' + field + '"',
        value: value,
        callback: function(result) {
            if (result != null) {
                var update = {};
                update[table] = [{id: row.id, [field]: result}];
                // Pass the change to the application
                window.chrome.webview.postMessage({ event: 'MELBIS_ORDER_UPDATE', data: update });
            }
        }
    });
});
```

The application receives the `MELBIS_ORDER_UPDATE` event and applies the changes to the order fields in its interface.

### Printing

The `MELBIS_PRINT` event opens the classic Windows print dialog for the page: the choice of printer, number of copies and pages. The standard `window.print()` shows the browser's print preview inside the module panel itself instead.

A print button that works both in the application and in an ordinary browser:

```javascript
function melbis_print() {
    if (window.chrome && window.chrome.webview) {
        window.chrome.webview.postMessage({ event: 'MELBIS_PRINT' });
    } else {
        window.print();
    }
}
```

---

## External Web Modules

External modules differ from embedded ones in one fundamental way: they are not tied to a specific application window and do not receive the current record's context. Instead, when opened from the application, only the user's authentication parameters (`login`, `stamp`, `sign`) are passed.

Access to external modules is available through the **"Business / Web Modules"** section — this contains a browser with a catalog of all available modules in the left panel. In addition, any of these modules can be opened in a regular browser on any device — a tablet, smartphone, or a workstation without the application installed.

This makes external modules a universal tool for dashboards, analytical reports, and administrative panels — anything that does not require binding to a specific product or order. The screenshot above shows an example of a real external module with sales analytics, financial accounting, inventory analysis, and management tools built directly into the application.

Configuring external modules — **"Development → Modules and Options", the "External Web Modules" tab**: a name, URL, and symbolic key are set for each module, along with access rights by user groups.

---

## Authentication in External Modules

Since external modules can also be opened from a regular browser, authentication here works in two modes automatically:

**When opened from the application** — Melbis Shop passes `login`, `stamp` and `sign` in POST. `LOGIC_AUTH\Router` authenticates the user without a form and immediately displays the content.

**When opened directly in a browser** — POST does not contain credentials, the router passes `$mUserId = null`, and the `Page` function substitutes the authentication form template. After a successful login, the data is saved in the PHP session, and the form is no longer shown on subsequent requests.

The sign-in form signs by itself: the `melbis_crypto_sign` function from `statics/melbis/main.js` computes the key from the password in the browser and sends the same `login`, `stamp` and `sign` — the password never leaves the browser. The signature is made by the browser's built-in WebCrypto, so the form works only over https and in browsers with Ed25519: Chrome 137, Firefox 129, Safari 17 and newer.

The same module code works in both cases — the branching happens entirely automatically inside the `melbis_inc_logic_auth` library. The developer only needs to correctly handle the `$mUserId == null` case in the `Page` function.

---

## Summary Diagram

```
Windows Melbis Shop
    │
    │  POST: store_id / order_id / login / stamp / sign
    ▼
index.php → Run('melbis_web_sample')
    │
    ▼
MELBIS_WEB_SAMPLE\Main($mVars)
    │
    ▼
MELBIS_INC_LOGIC_AUTH\Router(...)
    ├─ authentication + rights verification
    ├─ func absent          → MELBIS_WEB_SAMPLE\Page($userId, $mVars)         → HTML
    ├─ func = 'GetCataloge' → MELBIS_WEB_SAMPLE\GetCataloge($userId, $mVars)  → JSON
    └─ func = 'GetGoods'    → MELBIS_WEB_SAMPLE\GetGoods($userId, $mVars)     → JSON

HTML page in the application's browser
    │  (only for the order editing window)
    ▼
postMessage({ event: 'MELBIS_ORDER_UPDATE', data: {"version":[...]} })
    │
    ▼
Windows Melbis Shop — applies changes to the order
```