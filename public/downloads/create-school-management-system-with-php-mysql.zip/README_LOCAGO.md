# Comprehensive School Management System - Create School Management System With Php Mysql

```
========================================================================
📦 Comprehensive School Management System - Create School Management System With Php Mysql
Kategori     : Pendidikan & Akademik
Tech Stack   : PHP Native • PHP • MySQL • Bootstrap • AdminLTE
Database     : MySQL (.sql) (File: Database/DemoSMS.sql)
Sumber Asli  : https://github.com/GetProjectsIdea/Create-School-Management-System-with-PHP-MySQL (GitHub Open Source)
Stars GitHub : ⭐ 34 Bintang
Kurasi       : LocaGo Creative (https://www.locagocreative.my.id)
Standar Mutu : Proyek Riil Siap Pakai (Papicode.id Standard)
========================================================================

📋 PANDUAN CARA INSTALASI & MENJALANKAN (XAMPP / LARAGON):

1. PERSIAPAN FOLDER:
   - Ekstrak seluruh isi arsip ZIP ini ke dalam direktori web server lokal Anda:
     * Untuk XAMPP  : `C:/xampp/htdocs/create-school-management-system-with-php-mysql`
     * Untuk Laragon: `C:/laragon/www/create-school-management-system-with-php-mysql`

2. IMPORT DATABASE (.SQL):
   - Nyalakan modul Apache dan MySQL di XAMPP / Laragon Control Panel.
   - Buka browser dan buka phpMyAdmin di: http://localhost/phpmyadmin
   - Buat database baru (misalnya dengan nama `create_school_management_system_with_php_mysql`).
   - Klik tab 'Import', pilih file SQL yang disertakan pada:
     `Database/DemoSMS.sql`
   - Klik 'Go' / 'Kirim' dan pastikan seluruh tabel berhasil diimport.

3. KONFIGURASI KONEKSI DATABASE:
   - Sesuaikan file konfigurasi database proyek (misal: `.env`, `config.php`, `database.php`):
     * DB_HOST = localhost
     * DB_USER = root
     * DB_PASS = (kosongkan jika default XAMPP, atau isi 'root' jika Laragon)
     * DB_NAME = create_school_management_system_with_php_mysql

4. JALANKAN APLIKASI:
   - Buka browser Anda dan akses:
     http://localhost/create-school-management-system-with-php-mysql

5. AKUN LOGIN DEFAULT UMUM:
   - Username / Email: admin / admin@gmail.com / admin@admin.com
   - Password        : admin / admin123 / password / 123456
   *(Tips: Anda juga dapat mengecek tabel `users` atau `admin` pada database phpMyAdmin)*

========================================================================
Dikurasi & Divalidasi Otomatis oleh Armada LocaGo Creative
Bebas dikembangkan dan dimodifikasi untuk skripsi, tugas akhir, atau UMKM.
========================================================================

```
